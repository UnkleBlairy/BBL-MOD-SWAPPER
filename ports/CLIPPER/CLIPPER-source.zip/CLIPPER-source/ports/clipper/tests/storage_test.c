/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Host test of firmware/src/storage.c against a simulated NOR flash:
 * erase -> 0xFF, program can only clear bits, page writes must not wrap. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static uint8_t nor[0x100000];
static int fail_after = -1;            /* torn-write injection: stop after N programs */

static int st_read(uint32_t off, void *dst, uint32_t n) { memcpy(dst, nor + off, n); return 0; }
static int st_erase(uint32_t off) { memset(nor + off, 0xFF, 4096); return 0; }
static int st_prog(uint32_t off, const void *src, uint32_t n)
{
    const uint8_t *s = src;
    uint32_t i;
    if (fail_after == 0)
        return -9;
    if (fail_after > 0)
        fail_after--;
    if ((off & 0xFFu) + n > 256u) {
        printf("page wrap at %#x\n", off);
        exit(1);
    }
    for (i = 0; i < n; i++)
        nor[off + i] &= s[i];
    return 0;
}
#include "../firmware/src/storage.c"

static int check(const char *what, int ok)
{
    printf("%-46s %s\n", what, ok ? "ok" : "FAIL");
    return ok ? 0 : 1;
}

int main(void)
{
    char a[600], b[600], got[600];
    int bad = 0, n;
    memset(nor, 0xFF, sizeof nor);
    memset(a, 'A', sizeof a);
    memset(b, 'B', sizeof b);
    bad += check("empty flash loads nothing", st_load(OBJ_PROJECT0, got, sizeof got) < 0);
    bad += check("save A", st_save(OBJ_PROJECT0, a, sizeof a) == 0);
    n = st_load(OBJ_PROJECT0, got, sizeof got);
    bad += check("load returns A", n == (int)sizeof a && !memcmp(got, a, sizeof a));
    bad += check("save B", st_save(OBJ_PROJECT0, b, sizeof b) == 0);
    n = st_load(OBJ_PROJECT0, got, sizeof got);
    bad += check("load returns B (newer seq)", n == (int)sizeof b && !memcmp(got, b, sizeof b));
    fail_after = 1;                                  /* payload page 1 written, the rest torn */
    st_save(OBJ_PROJECT0, a, sizeof a);
    fail_after = -1;
    n = st_load(OBJ_PROJECT0, got, sizeof got);
    bad += check("torn save keeps B", n == (int)sizeof b && !memcmp(got, b, sizeof b));
    fail_after = 3;                                  /* all payload pages, header torn */
    st_save(OBJ_PROJECT0, a, sizeof a);
    fail_after = -1;
    n = st_load(OBJ_PROJECT0, got, sizeof got);
    bad += check("header not written keeps B", n == (int)sizeof b && !memcmp(got, b, sizeof b));
    bad += check("save A again", st_save(OBJ_PROJECT0, a, sizeof a) == 0);
    n = st_load(OBJ_PROJECT0, got, sizeof got);
    bad += check("load returns A", n == (int)sizeof a && !memcmp(got, a, sizeof a));
    nor[st_sector(OBJ_PROJECT0, 0) + ST_PAYLOAD_OFF + 10] ^= 0x01;   /* bit rot in one copy */
    nor[st_sector(OBJ_PROJECT0, 1) + ST_PAYLOAD_OFF + 10] ^= 0x01;
    n = st_load(OBJ_PROJECT0, got, sizeof got);
    bad += check("both copies corrupt -> nothing", n < 0);
    bad += check("other objects untouched", st_load(OBJ_PROJECT0 + 1, got, sizeof got) < 0);
    bad += check("settings save/load",
                 st_save(OBJ_SETTINGS, "hello", 5) == 0 && st_load(OBJ_SETTINGS, got, 5) == 5 && !memcmp(got, "hello", 5));
    bad += check("CRC-32 is zlib's (check value 0xCBF43926)", st_crc32("123456789", 9) == 0xCBF43926u);
    memset(nor, 0xFF, sizeof nor);
    st_save(OBJ_PROJECT0 + 2, a, sizeof a);
    st_save(OBJ_PROJECT0 + 2, b, sizeof b);              /* B is newer, in the other copy */
    {
        st_hdr_t h;
        int cur = st_current(OBJ_PROJECT0 + 2, &h);
        nor[st_sector(OBJ_PROJECT0 + 2, (uint32_t)cur) + ST_PAYLOAD_OFF + 300] ^= 0x10;   /* rot in the newer copy */
    }
    n = st_load(OBJ_PROJECT0 + 2, got, sizeof got);
    bad += check("newer copy rotten -> the older one loads", n == (int)sizeof a && !memcmp(got, a, sizeof a));
    bad += check("save over the rotten copy", st_save(OBJ_PROJECT0 + 2, b, sizeof b) == 0);
    n = st_load(OBJ_PROJECT0 + 2, got, sizeof got);
    bad += check("... loads the new data", n == (int)sizeof b && !memcmp(got, b, sizeof b));
    nor[st_sector(OBJ_PROJECT0 + 2, 0) + 8] ^= 0x01;    /* both headers broken */
    nor[st_sector(OBJ_PROJECT0 + 2, 1) + 8] ^= 0x01;
    bad += check("both headers broken -> nothing", st_load(OBJ_PROJECT0 + 2, got, sizeof got) < 0);
    {   /* every copy of every object in the Felucca regions, off the sample slots (0xA0000..0xDBFFF) and
         * the update staging (0xE0000..0xE4FFF; the FM6 bank's two sectors follow it), and no two sectors shared */
        uint32_t o, c, o2, c2, inside = 1, apart = 1;
        for (o = 0; o < OBJ_COUNT; o++)
            for (c = 0; c < 2u; c++) {
                uint32_t a = st_sector(o, c);
                int data = a >= 0x97000u && a + 4096u <= 0xA0000u, ups = a >= 0xDC000u && a + 4096u <= 0xE0000u;
                int glob = a >= 0xFC000u && a + 4096u <= 0xFF000u, fm6 = a >= 0xE5000u && a + 4096u <= 0xE7000u;
                inside &= (data || ups || glob || fm6) && !(a & 0xFFFu);
                for (o2 = 0; o2 < OBJ_COUNT; o2++)
                    for (c2 = 0; c2 < 2u; c2++)
                        if ((o2 != o || c2 != c) && st_sector(o2, c2) == a)
                            apart = 0;
            }
        bad += check("data stays in the Felucca regions (autosave too)", inside);
        bad += check("every object copy has its own sector", apart);
    }
    {   /* SLOOP 2.5: the settings in two parts (persist_t, then the SYN kits): one record, A/B as any other */
        static char p1[88], p2[1464], all[88 + 1464], got2[88 + 1464];
        memset(p1, 'P', sizeof p1);
        memset(p2, 'K', sizeof p2);
        memcpy(all, p1, sizeof p1);
        memcpy(all + sizeof p1, p2, sizeof p2);
        bad += check("2.5: save in two parts", st_save2(OBJ_SETTINGS, p1, sizeof p1, p2, sizeof p2) == 0);
        n = st_load(OBJ_SETTINGS, got2, sizeof got2);
        bad += check("2.5: ... loads as one object", n == (int)sizeof all && !memcmp(got2, all, sizeof all));
        n = st_load(OBJ_SETTINGS, got2, sizeof p1);
        bad += check("2.5: ... a 2.4 load takes its part only", n == (int)sizeof p1 && !memcmp(got2, p1, sizeof p1));
        memset(p2, 'L', sizeof p2);
        fail_after = 4;                              /* a torn second save: the first copy stays */
        st_save2(OBJ_SETTINGS, p1, sizeof p1, p2, sizeof p2);
        fail_after = -1;
        n = st_load(OBJ_SETTINGS, got2, sizeof got2);
        bad += check("2.5: ... a torn save keeps the last one", n == (int)sizeof all && !memcmp(got2, all, sizeof all));
        bad += check("2.5: ... too big for a sector: refused", st_save2(OBJ_SETTINGS, p2, 3000, p2, 1000) == -1);
    }
    printf("%s\n", bad ? "STORAGE TEST FAILED" : "storage test passed");
    {   /* 0.7 (SLOOP 2.7's layout): a side record with its copy, before the header; an older save leaves it erased */
        uint8_t side[44], back[44], ff[44];
        memset(side, 0x5A, sizeof side);
        side[0] = 'C';
        memset(ff, 0xFF, sizeof ff);
        st_side = side;
        st_side_len = sizeof side;
        bad += check("0.7 side record: saved with its copy", st_save(OBJ_SETTINGS, a, 100) == 0);
        st_side = 0;
        bad += check("0.7 side record: read back as written",
                     st_side_load(OBJ_SETTINGS, back, sizeof back) == 0 && !memcmp(back, side, sizeof side));
        n = st_load(OBJ_SETTINGS, got, sizeof got);
        bad += check("0.7 side record: the payload untouched", n == 100 && !memcmp(got, a, 100));
        bad += check("0.7 side record: an older save (none) leaves it erased",
                     st_save(OBJ_SETTINGS, b, 100) == 0 && st_side_load(OBJ_SETTINGS, back, sizeof back) == 0 &&
                     !memcmp(back, ff, sizeof ff));
        bad += check("0.7 side record: none bigger than its room", st_side_load(OBJ_SETTINGS, got, ST_SIDE_MAX + 1u) < 0);
    }
    {   /* Clipper 1.0: a tail after the payload (user presets: 3080 B + 472), the payload's length and CRC as before;
         * an older save (none) leaves it erased; no tail past the sector */
        static uint8_t big[3080], tail[472], back[472], ff[472], gb[3600];
        uint32_t i;
        for (i = 0; i < sizeof big; i++)
            big[i] = (uint8_t)(i * 7u + 3u);
        for (i = 0; i < sizeof tail; i++)
            tail[i] = (uint8_t)(i * 13u + 1u);
        memset(ff, 0xFF, sizeof ff);
        st_tail = tail;
        st_tail_len = sizeof tail;
        bad += check("1.0 tail: saved after the payload (no page wraps)", st_save(OBJ_SETTINGS, big, sizeof big) == 0);
        st_tail = 0;
        n = st_load(OBJ_SETTINGS, gb, sizeof gb);
        bad += check("1.0 tail: the payload as before (length, CRC)", n == (int)sizeof big && !memcmp(gb, big, sizeof big));
        bad += check("1.0 tail: read back as written",
                     st_tail_load(OBJ_SETTINGS, back, sizeof back) == 0 && !memcmp(back, tail, sizeof tail));
        bad += check("1.0 tail: an older save (none) leaves it erased",
                     st_save(OBJ_SETTINGS, big, sizeof big) == 0 && st_tail_load(OBJ_SETTINGS, back, sizeof back) == 0 &&
                     !memcmp(back, ff, sizeof ff));
        bad += check("1.0 tail: none past the sector", st_tail_load(OBJ_SETTINGS, back, ST_PAYLOAD_MAX) < 0);
        st_tail = tail;
        st_tail_len = sizeof tail;
        memcpy(gb, big, sizeof big);
        bad += check("1.0 tail: a payload too big for it: saved without", st_save(OBJ_SETTINGS, gb, 3500) == 0 &&
                     st_load(OBJ_SETTINGS, gb, sizeof gb) == 3500 && st_tail_load(OBJ_SETTINGS, back, sizeof back) < 0);
        st_tail = 0;
    }
    return bad != 0;
}
