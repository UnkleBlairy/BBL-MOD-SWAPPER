Penumbra 1.12 for the BBL Mod Swapper

Original by MadMooneyham: https://github.com/MadMooneyham/Penumbra
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: PENUMBRA-source.zip on the ports page.
