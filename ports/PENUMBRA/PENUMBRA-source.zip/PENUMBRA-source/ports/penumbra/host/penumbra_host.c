/* SPDX-License-Identifier: GPL-3.0-only */
/* Penumbra on the host: the whole app (UI, settings, engine, every voice) run against a simulated
 * FM-1 driven by a script. Audio goes to a WAV, the screen to PNGs, the key / button lights to a
 * text dump, MIDI out to a log. The device-only parts (HAL, USB, OTA, flash driver) are replaced
 * by plat.h implemented here. Its timing is this machine's, not the FM-1's: the benchmark's
 * numbers here say what costs most, never whether the FM-1 keeps up (that is the BENCH page's job).
 *
 *   penumbra_host SCRIPT [OUTDIR]
 *
 * Script, one command per line (# comments):
 *   wait MS                      run the device for MS milliseconds
 *   press BTN | release BTN | tap BTN     (BTN: FX SEL ENV LFO EDIT GLO HOME SAVE ARP SEQ PLAY REC OCT- OCT+)
 *   key K down|up | tapkey K     (K: 0..26 = F3..G5, or w0..w15 white keys, b0..b10 black keys)
 *   turn ENC N [MS]              (ENC: SELECT ALGO PRESET K1 K2 K3 K4; N detents, signed, MS apart)
 *   master N                     MASTER pot 0..4096
 *   midi B0 [B1 B2]              an incoming MIDI message (hex bytes)
 *   clockin BPM MS               MIDI clock arriving at BPM for MS milliseconds (24 ppqn)
 *   wav FILE | wavstop           start / stop recording the output (FILE in OUTDIR)
 *   load N                       the overload guard sees every block cost N% (-1: as measured)
 *   peakreset                    restart the output peak (expect peak_db_min / peak_db_max)
 *   shot FILE.png                save the screen
 *   leds                         print the lit buttons and keys
 *   expect WHAT VALUE            check state: exit 1 on mismatch; VALUE "<N" / ">N" is a bound
 *   reboot | powercut            re-run boot from the simulated flash (persistence)
 *   autoplay 0|1                 PLAY AT POWER-ON saved, then boot again (scenarios that start in silence)
 *   listen | where               a screen reader listens (HELLO, again every 2 s) | asks for the screen
 *   said TEXT | said_none        some SAY since the last check has TEXT in it | nothing was said
 */
#define PEN_HOST 1
#define _POSIX_C_SOURCE 199309L                  /* clock_gettime */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include <time.h>
#define __attribute__(x)

/* ------------------------------------------------------------ screen --- */
/* teensy-fm1: X0X_LCD_PUT(i, v) writes pixel i (the Teensy build marks what changed for its display link) */
#ifndef X0X_LCD_PUT
#define X0X_LCD_PUT(i, v) (fb[i] = (v))
#endif
static uint16_t fb[240 * 240];          /* RGB565, byte-swapped as the panel takes it (gfx.c) */
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    uint16_t sc = (uint16_t)(((c >> 8) & 0xFFu) | ((c & 0xFFu) << 8));
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            X0X_LCD_PUT(j * 240u + i, sc);
}
static uint32_t blits;                  /* the browser build sends the screen only when it changed */
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    blits++;
    for (j = 0; j < h; j++)
        for (i = 0; i < w; i++)
            if (x + i < 240u && y + j < 240u)
                X0X_LCD_PUT((y + j) * 240u + x + i, px[j * w + i]);
}
#include "../firmware/src/gfx.c"
#include "../firmware/src/install_screen.c"       /* (the install screen: 'install', for its screenshots) */

/* ---------------------------------------------------------- platform --- */
#include "../firmware/src/app/plat.h"

static uint32_t now_ms, held_btn, held_keys, master = 2048;
static int32_t enc_acc[NE];
static uint32_t lit_btn, lit_keys, dim_keys;

uint32_t plat_ms(void) { return now_ms; }
uint32_t plat_buttons(void) { return held_btn; }
uint32_t plat_keys(void) { return held_keys; }
int32_t plat_enc(int role)
{
    int32_t v = enc_acc[role];
    enc_acc[role] = 0;
    return v;
}
uint32_t plat_master(void) { return master; }
int plat_battery(void) { return 3; }
void plat_leds(uint32_t b, uint32_t k)
{
    lit_btn = b;
    lit_keys = k;
}
void plat_glow(int on) { (void)on; }
void plat_play_red(int red) { (void)red; }
void plat_keys_dim(uint32_t k) { dim_keys = k; }

static int usb_audio_on;                         /* 'usbaudio 1': a computer takes the USB audio */
int plat_usb_audio_on(void) { return usb_audio_on; }
#define MQ 1024
static uint32_t min_q[MQ], mi_w, mi_r;
static FILE *midi_log;
int plat_midi_in(uint32_t *pkt)
{
    if (mi_r == mi_w)
        return 0;
    *pkt = min_q[mi_r++ % MQ];
    return 1;
}
static uint32_t clock_out_count, starts_out, stops_out;
static uint32_t notes_out[17], ccs_out;           /* note-ons out by channel (1..16); CCs out */
static int cc_out_last[128], pc_out_last = -1, note_out_last = -1;
void plat_midi_out(uint32_t pkt)
{
    uint32_t st = (pkt >> 8) & 0xFF, d1 = (pkt >> 16) & 0x7F, d2 = (pkt >> 24) & 0x7F;
#ifdef X0X_MIDI_PUT
    X0X_MIDI_PUT(pkt);                               /* teensy-fm1: to the Teensy's USB MIDI */
#endif
    if (st == 0xF8)
        clock_out_count++;
    else {
        starts_out += st == 0xFA || st == 0xFB;
        stops_out += st == 0xFC;
        if ((st & 0xF0) == 0x90 && d2) {
            notes_out[(st & 15) + 1]++;
            note_out_last = (int)d1;
        } else if ((st & 0xF0) == 0xB0) {
            ccs_out++;
            cc_out_last[d1] = (int)d2 + 1;                /* (0: never) */
        } else if ((st & 0xF0) == 0xC0) {
            pc_out_last = (int)d1;
        }
        if (midi_log)
            fprintf(midi_log, "%u ms: %02X %02X %02X\n", now_ms, st, (pkt >> 16) & 0xFF, (pkt >> 24) & 0xFF);
    }
}

/* flash: one buffer per object, kept across a simulated reboot */
#define NOBJ 16
static uint8_t store[NOBJ][PLAT_STORE_MAX];
static int store_len[NOBJ] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
static uint32_t store_writes;
int plat_store_load(uint32_t obj, void *dst, uint32_t max)
{
    int n = obj < NOBJ ? store_len[obj] : -1;
    if (n < 0)
        return -1;
    if ((uint32_t)n > max)
        n = (int)max;
    memcpy(dst, store[obj], (size_t)n);
    return n;
}
int plat_store_save(uint32_t obj, const void *src, uint32_t len)
{
    if ((obj != OBJ_SET && obj != OBJ_PANEL && obj != OBJ_WORK && obj != OBJ_USER && obj != OBJ_LOOP &&
         obj != OBJ_SOUNDS) || len > PLAT_STORE_MAX)
        return -1;
    memcpy(store[obj], src, len);
    store_len[obj] = (int)len;
    store_writes++;
    return 0;
}

static uint32_t cpu_pct, cpu_peak;
static int load_force = -1;
/* the second core, simulated: a job runs at once, in order (the same sums as the device's split) */
static int cpu2_on;
int plat_cpu2_set(int on) { cpu2_on = on; return 0; }
int plat_cpu2_on(void) { return cpu2_on; }
int plat_cpu2_run(void (*fn)(uint32_t), uint32_t arg)
{
    if (!cpu2_on)
        return 0;
    fn(arg);
    return 1;
}
int plat_cpu2_wait(void) { return 0; }
int plat_cpu2_gave_up(void) { return 0; }
uint32_t plat_cpu2_bad(void) { return 0; }
int plat_cpu2_barred(void) { return 0; }
int plat_last_crash(uint32_t v[5]) { (void)v; return 0; }
uint32_t plat_cpu_pct(void) { return cpu_pct; }
uint32_t plat_cpu_peak_pct(void)
{
    uint32_t p = cpu_peak;
    cpu_peak = 0;
    return p;
}
uint32_t plat_xruns(void) { return 0; }
static uint64_t host_ns(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint64_t)t.tv_sec * 1000000000u + (uint64_t)t.tv_nsec;
}
uint32_t plat_ticks24(void) { return (uint32_t)(host_ns() * 24u / 1000u); }
uint32_t plat_cpu_mhz10(void) { return 0; }
uint32_t plat_irq_stack_used(void) { return 0; }
uint32_t plat_irq_stack_size(void) { return 0; }

/* -------------------------------------------------------------- app --- */
#include "../firmware/src/app/penumbra.h"
#define ANN_NAME FW_NAME " " PEN_VERSION
#include "ann_words.h"
#include "../firmware/src/announce.c"
static char said_log[16384];                         /* every SAY since the last "said" check */
static uint32_t said_len;
#ifdef PEN_WEB
static void web_said(const uint8_t *p, uint32_t n);
#endif
static int ann_wire_send(const uint8_t *p, uint32_t n)
{
#ifdef PEN_WEB
    web_said(p, n);
    return 0;
#endif
    if (n >= 7u && p[4] == ANN_SAY) {
        char t[ANN_MAX + 1];
        uint32_t i, k = 0;
        for (i = 6; i + 1u < n && k < ANN_MAX; i++)
            t[k++] = (char)p[i];
        t[k] = 0;
        printf("said%s: %s\n", (p[5] & ANN_NOW) ? "!" : "", t);
        if (said_len + k + 2u < sizeof said_log) {
            memcpy(said_log + said_len, t, k);
            said_len += k;
            said_log[said_len++] = '\n';
            said_log[said_len] = 0;
        }
    }
    return 0;
}
#include "../firmware/src/app/settings.c"
#include "../firmware/src/app/ui.c"
/* backups (backup.c): what it answers goes to the page (the browser build) or is kept for 'backup' / 'restore';
 * its restart is a boot after the millisecond it asked in */
static uint8_t bk_heard[8192];
static uint32_t bk_heard_n;
static int bk_boot_due;
static int bk_wire_send(const uint8_t *p, uint32_t n)
{
#ifdef PEN_WEB
    web_said(p, n);
    return 0;
#endif
    if (bk_heard_n + n <= sizeof bk_heard) {
        memcpy(bk_heard + bk_heard_n, p, n);
        bk_heard_n += n;
    }
    return 0;
}
static void bk_restart(void) { bk_boot_due = 1; }
#include "../firmware/src/app/backup.c"

/* ---------------------------------------------------------- outputs --- */
static void png_write(const char *path)
{
    /* RGB PNG with stored (uncompressed) deflate blocks: no zlib needed */
    static uint8_t raw[240 * (1 + 240 * 3)];
    FILE *f = fopen(path, "wb");
    uint32_t crc_t[256], i, j, k, n = 0, a = 1, b = 0, pos, len = sizeof raw;
    uint8_t hdr[8] = {137, 80, 78, 71, 13, 10, 26, 10};
    if (!f) {
        fprintf(stderr, "cannot write %s\n", path);
        return;
    }
    for (i = 0; i < 256; i++) {
        uint32_t c = i;
        for (k = 0; k < 8; k++)
            c = c & 1 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
        crc_t[i] = c;
    }
    for (j = 0; j < 240; j++) {
        raw[n++] = 0;
        for (i = 0; i < 240; i++) {
            uint16_t p = fb[j * 240 + i];
            p = (uint16_t)((p >> 8) | (p << 8));
            raw[n++] = (uint8_t)(((p >> 11) & 31) * 255 / 31);
            raw[n++] = (uint8_t)(((p >> 5) & 63) * 255 / 63);
            raw[n++] = (uint8_t)((p & 31) * 255 / 31);
        }
    }
    for (i = 0; i < len; i++) {
        a = (a + raw[i]) % 65521;
        b = (b + a) % 65521;
    }
#define PUT32(v) do { uint8_t q_[4] = {(uint8_t)((v) >> 24), (uint8_t)((v) >> 16), (uint8_t)((v) >> 8), (uint8_t)(v)}; fwrite(q_, 1, 4, f); } while (0)
    fwrite(hdr, 1, 8, f);
    {
        uint8_t ih[17] = {'I', 'H', 'D', 'R', 0, 0, 0, 240, 0, 0, 0, 240, 8, 2, 0, 0, 0};
        uint32_t c = 0xFFFFFFFFu;
        PUT32(13u);
        fwrite(ih, 1, 17, f);
        for (i = 0; i < 17; i++)
            c = crc_t[(c ^ ih[i]) & 255] ^ (c >> 8);
        PUT32(~c);
    }
    {
        uint32_t nblk = (len + 65534) / 65535, zlen = 2 + len + nblk * 5 + 4, c = 0xFFFFFFFFu;
        uint8_t *z = malloc(zlen + 4), *q = z;
        memcpy(q, "IDAT", 4);
        q += 4;
        *q++ = 0x78;
        *q++ = 0x01;
        for (pos = 0; pos < len;) {
            uint32_t m = len - pos > 65535 ? 65535 : len - pos;
            *q++ = pos + m >= len ? 1 : 0;
            *q++ = (uint8_t)m;
            *q++ = (uint8_t)(m >> 8);
            *q++ = (uint8_t)~m;
            *q++ = (uint8_t)(~m >> 8);
            memcpy(q, raw + pos, m);
            q += m;
            pos += m;
        }
        *q++ = (uint8_t)(b >> 8);
        *q++ = (uint8_t)b;
        *q++ = (uint8_t)(a >> 8);
        *q++ = (uint8_t)a;
        PUT32(zlen);
        fwrite(z, 1, zlen + 4, f);
        for (i = 0; i < zlen + 4; i++)
            c = crc_t[(c ^ z[i]) & 255] ^ (c >> 8);
        PUT32(~c);
        free(z);
    }
    {
        uint8_t ie[4] = {'I', 'E', 'N', 'D'};
        uint32_t c = 0xFFFFFFFFu;
        PUT32(0u);
        fwrite(ie, 1, 4, f);
        for (i = 0; i < 4; i++)
            c = crc_t[(c ^ ie[i]) & 255] ^ (c >> 8);
        PUT32(~c);
    }
    fclose(f);
}

static FILE *wav;
static uint32_t wav_frames;
static float peak_out;
static void wav_open(const char *path)
{
    static const uint8_t h[44] = {0};
    wav = fopen(path, "wb");
    if (wav)
        fwrite(h, 1, 44, wav);
    wav_frames = 0;
}
static void wav_close(void)
{
    uint32_t bytes = wav_frames * 4, v;
    if (!wav)
        return;
    fseek(wav, 0, SEEK_SET);
    fwrite("RIFF", 1, 4, wav);
    v = 36 + bytes;
    fwrite(&v, 4, 1, wav);
    fwrite("WAVEfmt ", 1, 8, wav);
    v = 16;
    fwrite(&v, 4, 1, wav);
    {
        uint16_t fmt[2] = {1, 2};
        uint32_t r[2] = {44100, 44100 * 4};
        uint16_t al[2] = {4, 16};
        fwrite(fmt, 2, 2, wav);
        fwrite(r, 4, 2, wav);
        fwrite(al, 2, 2, wav);
    }
    fwrite("data", 1, 4, wav);
    fwrite(&bytes, 4, 1, wav);
    fclose(wav);
    wav = 0;
}

/* --------------------------------------------------------- the device --- */
static double audio_due_ms, clockin_next_ms, clockin_end_ms, clockin_period_ms;
static uint32_t ui_due;
static int sim_listen;

static void boot(void)
{
    engine_init();
    settings_load();
    settings_apply();
    journey_load_work();
    loop_load_work();
    plat_cpu2_set(!cfg.one_core);
    lcd_fill(0, 0, 240, 240, C_BG);
    ui_init();
    ui.btn = ui.keys = 0;
    ui_start();
}

static void run_ms(uint32_t ms)
{
    static int32_t blk[512];
    uint32_t i, k;
    for (i = 0; i < ms; i++) {
        now_ms++;
        while (clockin_end_ms > 0.0 && clockin_next_ms <= (double)now_ms) {   /* MIDI clock arriving */
            if (clockin_next_ms > clockin_end_ms) {
                clockin_end_ms = 0.0;
                break;
            }
            min_q[mi_w++ % MQ] = 0x1Fu | 0xF8u << 8 | (((now_ms * 24000u) >> 12) & 0xFFFFu) << 16;   /* (timed as
                                                       * usb.c midi_stamp: to the ms, as USB's frames bring it) */
            clockin_next_ms += clockin_period_ms;
        }
        while (audio_due_ms <= (double)now_ms) {      /* 256-frame blocks, as engine_render takes them */
            uint64_t t0 = host_ns();
            double dt;
            engine_render(blk, 256);
            engine_volume(blk, 256);
#ifdef PEN_WEB
            web_audio(blk, 256);                         /* the browser build: to the AudioWorklet */
#endif
            dt = (double)(host_ns() - t0);
            cpu_pct = (uint32_t)(100.0 * dt / (256.0 * 1e9 / 44100.0));
            if (cpu_pct > cpu_peak)
                cpu_peak = cpu_pct;
#ifdef PEN_WEB
            engine_load(load_force >= 0 ? (uint32_t)load_force : 0u, 256);   /* a browser's timing is not the FM-1's */
#else
            engine_load(load_force >= 0 ? (uint32_t)load_force : cpu_pct, 256);
#endif
            for (k = 0; k < 256; k++) {
                float l = (float)blk[2 * k] / 8388608.0f, r = (float)blk[2 * k + 1] / 8388608.0f;
                int16_t s[2];
                if (fabsf(l) > peak_out)
                    peak_out = fabsf(l);
                if (fabsf(r) > peak_out)
                    peak_out = fabsf(r);
                s[0] = (int16_t)(l * 32767.0f);
                s[1] = (int16_t)(r * 32767.0f);
                if (wav) {
                    fwrite(s, 2, 2, wav);
                    wav_frames++;
                }
            }
            audio_due_ms += 256.0 * 1000.0 / 44100.0;
        }
        if (sim_listen && now_ms % 2000u == 0) {        /* the reader's HELLO, as fm1-reader sends it */
            static const uint8_t HELLO[] = {ANN_H0, ANN_H1, ANN_H2, ANN_HELLO, ANN_VER};
            ann_frame(HELLO, sizeof HELLO, now_ms);
        }
        if (now_ms >= ui_due) {
            ui_due = now_ms + 16;
            ui_frame();
        } else {
            ui_input_only();
        }
        if (bk_boot_due) {                            /* a restore: the unit starts again with it */
            bk_boot_due = 0;
            held_btn = held_keys = 0;
            boot();
        }
    }
}

/* ---------------------------------------------------------- script --- */
static const char *const BTN_N[NB] = {"FX", "SEL", "ENV", "LFO", "EDIT", "GLO", "HOME", "SAVE", "ARP", "SEQ",
                                      "PLAY", "REC", "OCT-", "OCT+"};
static const char *const ENC_N[NE] = {"SELECT", "ALGO", "PRESET", "K1", "K2", "K3", "K4"};
static const int WHITE_K[16] = {0, 2, 4, 6, 7, 9, 11, 12, 14, 16, 18, 19, 21, 23, 24, 26};
static const int BLACK_K[11] = {1, 3, 5, 8, 10, 13, 15, 17, 20, 22, 25};

static int find_name(const char *const *t, int n, const char *s)
{
    int i;
    for (i = 0; i < n; i++)
        if (!strcmp(t[i], s))
            return i;
    return -1;
}
static int key_of(const char *s)
{
    if (s[0] == 'w')
        return WHITE_K[atoi(s + 1) & 15];
    if (s[0] == 'b')
        return BLACK_K[atoi(s + 1) % 11];
    return atoi(s);
}

static int journey_index(void)
{
    int i;
    for (i = 0; i < JR_PRESETS; i++)
        if (!strcmp(eng_jr.name, jr_preset_name(i)))
            return i + 1;
    return 0;
}

static int expect(const char *what, const char *val)
{
    int got;
    bench_t b;
    if (!strcmp(what, "playing"))
        got = eng_clock.playing;
    else if (!strcmp(what, "view"))                 /* ui.c V_*: 0 HOME, 1 SHAPE, 2 SCENE, 3 FX, 4 JOURNEY, 5 SYSTEM, 6 BENCH, 7 SOUNDS, 8 LOOP */
        got = ui.view;
    else if (!strcmp(what, "row"))
        got = ui.row;
    else if (!strncmp(what, "drone", 5))            /* droneN: voice N (1-5) is on (latched, or in its swell) */
        got = engine_drone_on(atoi(what + 5) - 1);
    else if (!strcmp(what, "kicks"))                /* PULSE's kicks so far */
        got = (int)eng_kicks;
    else if (!strcmp(what, "vox"))                  /* a VOX voice sounds */
        got = engine_vox_sounding();
    else if (!strcmp(what, "guard"))
        got = engine_guard_active();
    else if (!strcmp(what, "guardcount"))
        got = (int)eng_guard_count;
    else if (!strcmp(what, "tempo"))
        got = (int)(tclock_tempo(&eng_clock) + 0.5f);
    else if (!strcmp(what, "tempo_x10"))            /* (a DAW's clock, how near) */
        got = (int)(tclock_tempo(&eng_clock) * 10.0f + 0.5f);
    else if (!strncmp(what, "notes_out", 9))        /* notes_outC: note-ons sent on channel C */
        got = (int)notes_out[atoi(what + 9) % 17];
    else if (!strcmp(what, "note_out"))             /* the last note-on's note */
        got = note_out_last;
    else if (!strcmp(what, "ccs_out"))
        got = (int)ccs_out;
    else if (!strncmp(what, "cc_out", 6))           /* cc_outN: CC N's last value sent (-1: never) */
        got = cc_out_last[atoi(what + 6) % 128] - 1;
    else if (!strcmp(what, "pc_out"))               /* the last program change sent (-1: never) */
        got = pc_out_last;
    else if (!strcmp(what, "loop_pos"))             /* where the loop is, 16ths (its ticks / LP_TPS) */
        got = (int)(engine_looper_state()->pos / LP_TPS);
    else if (!strncmp(what, "thr", 3))              /* thrN: a throw, as the hands hold it */
        got = (int)(ui.thr[atoi(what + 3) % 4] + (ui.thr[atoi(what + 3) % 4] < 0.0f ? -0.5f : 0.5f));
    else if (!strcmp(what, "ext"))
        got = eng_clock.ext;
    else if (!strcmp(what, "steps"))
        got = (int)eng_steps;
    else if (!strcmp(what, "clocks_out"))
        got = (int)clock_out_count;
    else if (!strcmp(what, "starts_out"))
        got = (int)starts_out;
    else if (!strcmp(what, "stops_out"))
        got = (int)stops_out;
    else if (!strcmp(what, "store_writes"))
        got = (int)store_writes;
    else if (!strcmp(what, "blits")) {              /* screen transfers since the last look (the horizon's motion: few) */
        static uint32_t last;
        got = (int)(blits - last);
        last = blits;
    }
    else if (!strcmp(what, "dirty"))
        got = ui.dirty;
    else if (!strcmp(what, "testing"))
        got = engine_load_testing();
    else if (!strcmp(what, "clips"))
        got = (int)eng_out_clips;
    else if (!strcmp(what, "quiet_ms"))
        got = (int)engine_quiet_ms();
    else if (!strcmp(what, "set_clk_out"))
        got = cfg.clk_out;
    else if (!strcmp(what, "set_midi_ch"))
        got = cfg.midi_ch;
    else if (!strncmp(what, "stays", 5))            /* staysS, skipS, srootS: scene S's (1..) STAYS, SKIPPED, key */
        got = eng_jr.scene[(atoi(what + 5) - 1) % JR_SCENES].stays;
    else if (!strncmp(what, "skip", 4))
        got = eng_jr.scene[(atoi(what + 4) - 1) % JR_SCENES].skip;
    else if (!strncmp(what, "sroot", 5))
        got = eng_jr.scene[(atoi(what + 5) - 1) % JR_SCENES].root;
    else if (!strcmp(what, "srow"))                 /* SCENE's field shown */
        got = ui.srow;
    else if (!strcmp(what, "ssel"))                 /* SCENE, SCENES: the scene shown (0..; SCENES: nscenes, the row for a scene more) */
        got = ui.ssel;
    else if (!strcmp(what, "bring_on"))             /* SCENES: K3 has picked a scene to bring in */
        got = ui.bring_on;
    else if (!strcmp(what, "morph"))                /* MORPH: how far toward the next (or the one before), % */
        got = (int)(engine_jr()->mamt * 100.0f + 0.5f);
    else if (!strcmp(what, "knobs"))                /* KNOBS: 0 PENUMBRA, 1 CONTROLLER */
        got = cfg.knobs;
    else if (!strncmp(what, "ctl", 3) && what[3] >= '0' && what[3] <= '6')   /* ctlN: CONTROLLER's knob N's value
                                                                              * (0-3 K1-K4, 4 SELECT, 5 ALGO, 6 PRESETS) */
        got = cfg.ctl[what[3] - '0'];
    else if (!strcmp(what, "set_usb"))              /* USB AUDIO: 0 MASTER, 1 FULL, 2 USB ONLY */
        got = cfg.usb_full;
    else if (!strcmp(what, "set_bpm"))
        got = cfg.bpm_x10 / 10;
    else if (!strcmp(what, "jr_playing"))           /* the journey: playing */
        got = engine_jr()->playing;
    else if (!strcmp(what, "scene"))                /* the scene it is in, 1.. */
        got = engine_jr()->cur + 1;
    else if (!strcmp(what, "nscenes"))
        got = eng_jr.nscenes;
    else if (!strcmp(what, "travelling"))
        got = engine_jr()->travelling;
    else if (!strcmp(what, "looper"))               /* the looper: 0 empty, 1 recording, 2 playing, 3 overdub, 4 stopped */
        got = engine_looper_state()->state;
    else if (!strcmp(what, "layers"))
        got = engine_looper_state()->layers;
    else if (!strcmp(what, "looplen"))              /* its length, 16ths */
        got = (int)(engine_looper_state()->len / LP_TPS);
    else if (!strcmp(what, "frozen"))               /* VOX's notes frozen */
        got = engine_frozen();
    else if (!strncmp(what, "macro", 5))            /* macroN: 1 DRONE, 2 VOX, 3 SPACE, 4 TONE */
        got = eng_jr.macro[(atoi(what + 5) - 1) & 3];
    else if (!strcmp(what, "vox_notes")) {          /* the journey's VOX notes since the last check */
        static uint32_t last;
        got = (int)(eng_vox_notes - last);
        last = eng_vox_notes;
    }
    else if (!strcmp(what, "journey"))              /* the journey playing: 1..6 a preset (by name), 0 another */
        got = journey_index();
    else if (!strncmp(what, "slot", 4))             /* slotN: user slot N holds a journey */
        got = journey_slot_used(atoi(what + 4) - 1);
    else if (!strncmp(what, "shape", 5))            /* shapeVF: voice V (1 DRONE .. 4 TEXTURE), F 0 level, 1-4 its knobs, 5 the hidden one */
        got = eng_jr.shape[(what[5] - '1') % EV_N][(what[6] - '0') % SH_N];
    else if (!strncmp(what, "vs", 2) && what[3] == '.')   /* vsS.F: VOX's sound S (1-4), field F (engine.h VS_*) */
        got = eng_jr.vsound[(what[2] - '1') % JR_VSOUNDS][atoi(what + 4) % JR_VS];
    else if (!strcmp(what, "vox_sounds"))           /* the VOX sounds with a note held now (bit 0 GLASS .. 3 LOW) */
        got = engine_vox_sounds();
    else if (!strcmp(what, "vsing"))                /* every sound's singing, packed two bits each (0: none sings) */
        got = JR_SING(&eng_jr, 0) | JR_SING(&eng_jr, 1) << 2 | JR_SING(&eng_jr, 2) << 4 | JR_SING(&eng_jr, 3) << 6;
    else if (!strncmp(what, "sgF", 3) && what[3] >= '0' && what[3] <= '3' && what[4] >= '1' && what[4] <= '4')
        got = eng_jr.sing[what[3] - '0'][what[4] - '1'];   /* sgF S: a sound's singing (F 0 how, 1 place, 2 drift,
                                                            * 3 octave; S 1 GLASS .. 4 LOW), e.g. sgF12 */
    else if (!strcmp(what, "bloom_auto"))           /* BLOOM by itself: 0 by hand .. 3 often; blooms: how many so far */
        got = eng_jr.bloom_auto;
    else if (!strcmp(what, "blooms")) {
        extern volatile uint32_t eng_blooms;
        got = (int)eng_blooms;
    }
    else if (!strncmp(what, "vsing", 5) && what[5] >= '1' && what[5] <= '4')   /* vsingS: sound S's (1 GLASS .. 4 LOW),
                                                                                * 0 not .. 3 often */
        got = JR_SING(&eng_jr, what[5] - '1');
    else if (!strcmp(what, "sung")) {               /* the sounds that have sung since the last look (bit 0 GLASS ..) */
        extern volatile uint8_t eng_sung;
        got = eng_sung;
        eng_sung = 0;
    }
    else if (!strcmp(what, "vcur"))                 /* VOX's sound playing, 1-4 */
        got = eng_jr.vcur + 1;
    else if (!strncmp(what, "dvoice", 6))           /* dvoiceVF: drone voice V (1-5) field F (1 LEVEL .. 4 OCTAVE) */
        got = eng_jr.dvoice[(what[6] - '1') % ENG_DRONES][(what[7] - '1') % DV_N];
    else if (!strncmp(what, "perf", 4))             /* perfN: the hands' move N (engine.h PF_*) the engine has */
        got = ui.sent[atoi(what + 4) % PF_N];
    else if (!strncmp(what, "dnote", 5))            /* dnoteV: drone voice V's note (MIDI), the journey's */
        got = engine_jr()->drone[(atoi(what + 5) - 1) % ENG_DRONES];
    else if (!strcmp(what, "dmoving"))              /* the drone voices still to move to the scene's */
        got = engine_jr()->dpend;
    else if (!strncmp(what, "fxrow", 5))            /* the FX page's row: 0 REVERB, 1 REVERB 2, 2 DELAY, 3 DELAY 2 */
        got = ui.fxrow;
    else if (!strncmp(what, "fx", 2) && what[2] >= '0' && what[2] <= '9')   /* fxN: the FX page's setting N (engine.h EF_*) */
        got = cfg.fx[atoi(what + 2) % EF_N];
    else if (!strcmp(what, "kicks_since")) {        /* the kicks since the last look */
        static uint32_t last;
        got = (int)(eng_kicks - last);
        last = eng_kicks;
    }
    else if (!strncmp(what, "kick_", 5)) {          /* the kick's own: kick_tune, kick_drive, kick_duck, kick_auto; kick_land */
        const char *f = what + 5;
        got = !strcmp(f, "land") ? eng_jr.kick_land
              : eng_jr.kick[!strcmp(f, "tune") ? JR_KK_TUNE : !strcmp(f, "drive") ? JR_KK_DRIVE : !strcmp(f, "duck") ? JR_KK_DUCK : JR_KK_AUTO];
    }
    else if (!strcmp(what, "page"))                 /* SHAPE's page (ui.c PG_*: 0 DRONE .. 6 PULSE, 7 PULSE 2, 8 TEXTURE, 9 TIDES) */
        got = ui.vsel;
    else if (!strncmp(what, "dmotion", 7))          /* dmotionN: the drone's movement, 0 RATE .. 3 DRIFT */
        got = eng_jr.dmotion[atoi(what + 7) % JR_DMOTION];
    else if (!strncmp(what, "tide", 4) && what[4] >= '0' && what[4] <= '9')   /* tideN: TIDES, 0 RATE .. 4 SHAPE */
        got = eng_jr.tide[atoi(what + 4) % JR_TIDE];
    else if (!strcmp(what, "tide_now"))             /* the tide now, -100 .. 100 */
        got = (int)(engine_tide() * 100.0f);
    else if (!strncmp(what, "pan_now", 7))          /* pan_nowV: voice V's place now (the tide's sway in it), 0 .. 127 */
        got = (int)(engine_pan_now(atoi(what + 7) % EV_N) + 0.5f);
    else if (!strncmp(what, "pan", 3) && what[3] >= '0' && what[3] <= '9')   /* panV: PAN, 0 DRONE .. 3 TEXTURE */
        got = eng_jr.pan[atoi(what + 3) % JR_PAN];
    else if (!strcmp(what, "sway_rate"))            /* PAN's RATE: 0 the tide */
        got = eng_jr.sway_rate;
    else if (!strcmp(what, "sway_off"))             /* PAN 2's OFFSET */
        got = eng_jr.sway_off;
    else if (!strncmp(what, "sway", 4) && what[4] >= '0' && what[4] <= '9')   /* swayV: PAN 2, how far voice V sways */
        got = eng_jr.sway[atoi(what + 4) % JR_PAN];
    else if (!strncmp(what, "room", 4))             /* roomS / haloS: scene S's (1..) */
        got = eng_jr.scene[(atoi(what + 4) - 1) % JR_SCENES].room;
    else if (!strncmp(what, "halo", 4))
        got = eng_jr.scene[(atoi(what + 4) - 1) % JR_SCENES].halo;
    else if (!strncmp(what, "lay", 3) && what[3] >= '1' && what[3] <= '8')   /* layYF: the loop's layer Y (1 ..),
                                                                              * F 0 LEVEL, 1 SOUND, 2 OCTAVE, 3 MUTE */
        got = ((const uint8_t *)&engine_looper_state()->lay[what[3] - '1'])[(unsigned)(what[4] - '0') % sizeof(lp_layer_t)];
    else if (!strcmp(what, "vpan"))                 /* a looped note sounding: its place (-1: none); vtone: its filter x100 */
        got = engine_vox_probe(0);
    else if (!strcmp(what, "vtone"))
        got = engine_vox_probe(1);
    else if (!strcmp(what, "span"))                 /* a sound singing now: its place (-1: none); snote: its note */
        got = engine_vox_probe(2);
    else if (!strcmp(what, "snote"))
        got = engine_vox_probe(3);
    else if (!strcmp(what, "voices_on"))            /* VOX's voices holding a note */
        got = engine_vox_probe(4);
    else if (!strcmp(what, "lpage"))                /* LOOP's knob page: 0 LEVEL.., 1 PAN.. */
        got = ui.lpage;
    else if (!strcmp(what, "lrow"))                 /* LOOP's layer shown, 1 .. */
        got = ui.lrow + 1;
    else if (!strcmp(what, "hpage"))                /* HOME's knob page (ALGO there): 0 MIX, 1 SPACE, 2 MOTION, 3 ALIVE, 4 TONE */
        got = cfg.home_page;
    else if (!strcmp(what, "travel"))
        got = eng_jr.travel;
    else if (!strcmp(what, "sound_lock"))           /* JOURNEY's lock: 1 the sound playing stays when a journey opens */
        got = cfg.sound_lock;
    else if (!strcmp(what, "jtravel"))              /* the journey travels by itself: 0 not, 1 .. 4 every 8 .. 64 bars */
        got = eng_jr.travel;
    else if (!strcmp(what, "nscenes"))
        got = eng_jr.nscenes;
    else if (!strcmp(what, "ab_have"))              /* A/B: bit 0 A kept, bit 1 B */
        got = sound_ab.have;
    else if (!strcmp(what, "ab_t"))                 /* the blend, 0 A .. 127 B */
        got = sound_ab.t;
    else if (!strncmp(what, "snd", 3))              /* sndN: the library's slot N (1..) holds a sound */
        got = sound_slot_used(atoi(what + 3) - 1);
    else if (!strcmp(what, "jr_format"))            /* the journey playing's format */
        got = eng_jr.format;
    else if (!strcmp(what, "set_format"))
        got = (int)cfg.format;
    else if (!strncmp(what, "bloom", 5))            /* bloomN: BLOOM's 0 level, 1 length, 2 height, 3 fifth */
        got = what[5] == '0' ? eng_jr.shape[EV_PULSE][SH_HIDE] : eng_jr.bloom[(what[5] - '1') % BL_N];
    else if (!strcmp(what, "sleep"))                /* SLEEP's choice: 0 off, 1 20 min .. */
        got = ui.sleep;
    else if (!strcmp(what, "dswell"))               /* the drone voices that come and go (bit v) */
        got = eng_jr.dswell;
    else if (!strcmp(what, "autoplay"))
        got = cfg.autoplay;
    else if (!strcmp(what, "bench")) {               /* the benchmark has published (a second rendered) */
        got = engine_bench(&b) != 0;
    } else if (!strncmp(what, "bench_peak", 10) || !strncmp(what, "bench_avg", 9)) {   /* bench_avgK: stage K's, x 10 */
        int k = atoi(what + (what[6] == 'p' ? 10 : 9));
        engine_bench(&b);
        got = k >= 0 && k < ST_N ? (what[6] == 'p' ? b.peak[k] : b.avg[k]) : -1;
    } else if (!strcmp(what, "peak_db_max") || !strcmp(what, "peak_db_min")) {
        double db = 20.0 * log10(peak_out > 1e-9f ? peak_out : 1e-9f);
        int max = what[9] == 'a', bad = max ? db > atof(val) : db < atof(val);
        printf("%s peak %.1f dBFS (%s %s)\n", bad ? "FAIL" : "  ok", db, max ? "<=" : ">=", val);
        return bad;
    } else {
        printf("FAIL unknown expect %s\n", what);
        return 1;
    }
    if (val[0] == '<' || val[0] == '>') {
        int lim = (int)strtol(val + 1, 0, 0);
        if (val[0] == '<' ? got >= lim : got <= lim) {
            printf("FAIL expect %s %s, got %d\n", what, val, got);
            return 1;
        }
        printf("  ok %s == %d (%s)\n", what, got, val);
        return 0;
    }
    if (got != (int)strtol(val, 0, 0)) {
        printf("FAIL expect %s == %s, got %d\n", what, val, got);
        return 1;
    }
    printf("  ok %s == %d\n", what, got);
    return 0;
}

#ifndef PEN_WEB
extern uint8_t knobs_exact;
/* --presets: the preset journeys as the site's journey editor reads them (web/journey/presets.json; the tests
 * check it is this firmware's): each journey_t's bytes, and where its fields are */
static int dump_presets(void)
{
    int i;
    uint32_t k;
    printf("{\n  \"what\": \"Penumbra's preset journeys, as the firmware makes them (host/penumbra_host --presets)\",\n");
    printf("  \"format\": %u, \"size\": %u, \"scenes_max\": %d, \"name_len\": %d,\n", (unsigned)JR_FORMAT,
           (unsigned)sizeof(journey_t), JR_SCENES, JR_NAME);
    printf("  \"at\": {\"name\": %u, \"nscenes\": %u, \"travel\": %u, \"scene\": %u, \"scene_size\": %u, \"root\": %u, "
           "\"scale\": %u, \"stays\": %u, \"skip\": %u},\n",
           (unsigned)offsetof(journey_t, name), (unsigned)offsetof(journey_t, nscenes), (unsigned)offsetof(journey_t, travel),
           (unsigned)offsetof(journey_t, scene), (unsigned)sizeof(scene_t), (unsigned)offsetof(scene_t, root),
           (unsigned)offsetof(scene_t, scale), (unsigned)offsetof(scene_t, stays), (unsigned)offsetof(scene_t, skip));
    printf("  \"presets\": [\n");
    for (i = 0; i < JR_PRESETS; i++) {
        journey_t j;
        const uint8_t *b = (const uint8_t *)&j;
        jr_preset(i, &j);
        printf("    {\"name\": \"%s\", \"hex\": \"", jr_preset_name(i));
        for (k = 0; k < sizeof j; k++)
            printf("%02x", b[k]);
        printf("\"}%s\n", i + 1 < JR_PRESETS ? "," : "");
    }
    printf("  ]\n}\n");
    return 0;
}

int main(int argc, char **argv)
{
    FILE *sc;
    char line[512], out[400];
    const char *dir = argc > 2 ? argv[2] : ".";
    int lineno = 0, fails = 0;
    if (argc == 2 && !strcmp(argv[1], "--presets"))
        return dump_presets();
    if (argc < 2) {
        fprintf(stderr, "usage: penumbra_host SCRIPT [OUTDIR]  |  penumbra_host --presets\n");
        return 2;
    }
    sc = fopen(argv[1], "r");
    if (!sc) {
        perror(argv[1]);
        return 2;
    }
    snprintf(out, sizeof out, "%s/midi_out.txt", dir);
    midi_log = fopen(out, "w");
    plat_cpu2_set(1);
    journey_first = 0;                           /* (the scenarios play ECLIPSE; 'fresh N' another, as a new unit) */
    knobs_exact = 1;                             /* (the knobs exact: 'knobs real' for the detents' and speed's way) */
    boot();
    while (fgets(line, sizeof line, sc)) {
        char cmd[32] = {0}, a[256] = {0}, b[64] = {0}, c[64] = {0};
        lineno++;
        if (line[0] == '#' || sscanf(line, "%31s %255s %63s %63s", cmd, a, b, c) < 1)
            continue;
        if (!strcmp(cmd, "wait"))
            run_ms((uint32_t)atoi(a));
        else if (!strcmp(cmd, "press") || !strcmp(cmd, "release") || !strcmp(cmd, "tap")) {
            int i = find_name(BTN_N, NB, a);
            if (i < 0) {
                printf("line %d: no button %s\n", lineno, a);
                return 2;
            }
            if (cmd[0] != 'r')
                held_btn |= 1u << i;
            if (cmd[0] == 't')
                run_ms(40);
            if (cmd[0] != 'p')
                held_btn &= ~(1u << i);
            run_ms(cmd[0] == 't' ? 40 : 2);
        } else if (!strcmp(cmd, "key") || !strcmp(cmd, "tapkey")) {
            int k = key_of(a);
            if (cmd[0] == 't') {
                held_keys |= 1u << k;
                run_ms(60);
                held_keys &= ~(1u << k);
                run_ms(30);
            } else {
                if (!strcmp(b, "down"))
                    held_keys |= 1u << k;
                else
                    held_keys &= ~(1u << k);
                run_ms(2);
            }
        } else if (!strcmp(cmd, "turn")) {
            int e = find_name(ENC_N, NE, a), n = atoi(b), s = n > 0 ? 1 : -1;
            uint32_t gap = c[0] ? (uint32_t)atoi(c) : 80u;
            if (e < 0) {
                printf("line %d: no encoder %s\n", lineno, a);
                return 2;
            }
            for (; n; n -= s) {
                enc_acc[e] += s;
                run_ms(gap);
            }
        } else if (!strcmp(cmd, "master"))
            master = (uint32_t)atoi(a);
        else if (!strcmp(cmd, "midi")) {
            uint32_t s = (uint32_t)strtoul(a, 0, 16), d1 = (uint32_t)strtoul(b, 0, 16), d2 = (uint32_t)strtoul(c, 0, 16);
            uint32_t cin = s >= 0xF0 ? 0x0F : s >> 4;
            min_q[mi_w++ % MQ] = cin | s << 8 | d1 << 16 | d2 << 24;
        } else if (!strcmp(cmd, "clockin")) {        /* clockin BPM MS */
            clockin_period_ms = 60000.0 / (atof(a) * 24.0);
            clockin_next_ms = (double)now_ms + 1.0;
            clockin_end_ms = (double)now_ms + atof(b);
        } else if (!strcmp(cmd, "wav")) {
            snprintf(out, sizeof out, "%s/%s", dir, a);
            wav_open(out);
        } else if (!strcmp(cmd, "wavstop"))
            wav_close();
        else if (!strcmp(cmd, "load"))
            load_force = atoi(a);
        else if (!strcmp(cmd, "peakreset"))
            peak_out = 0.0f;
        else if (!strcmp(cmd, "shot")) {
            snprintf(out, sizeof out, "%s/%s", dir, a);
            png_write(out);
        } else if (!strcmp(cmd, "leds")) {
            int i;
            printf("lit:");
            for (i = 0; i < NB; i++)
                if (lit_btn >> i & 1u)
                    printf(" %s", BTN_N[i]);
            printf("  keys:");
            for (i = 0; i < NKEYS; i++)
                printf("%c", lit_keys >> i & 1u ? '#' : dim_keys >> i & 1u ? 'o' : '.');
            printf("\n");
        } else if (!strcmp(cmd, "expect"))
            fails += expect(a, b);
        else if (!strcmp(cmd, "reboot")) {
            held_btn = held_keys = 0;
            boot();
        } else if (!strcmp(cmd, "autoplay")) {        /* autoplay 0|1: PLAY AT POWER-ON saved, then power on again */
            cfg.autoplay = (uint8_t)atoi(a);
            settings_save();
            store_writes = 0;
            held_btn = held_keys = 0;
            boot();
        } else if (!strcmp(cmd, "fresh")) {           /* fresh N: a new unit (nothing saved) whose journey is preset N
                                                       * (0 ..; the firmware's own: JR_PRESETS - 1, TOTALITY) */
            int k;
            for (k = 0; k < NOBJ; k++)
                store_len[k] = -1;
            store_writes = 0;
            journey_first = (uint8_t)(atoi(a) % JR_PRESETS);
            held_btn = held_keys = 0;
            boot();
        } else if (!strcmp(cmd, "install")) {         /* install prep STEP | install write PERCENT: the install screen as
                                                       * Penumbra (penumbra.c ota_show) or its loader (loader.c) draws it,
                                                       * for a 'shot' straight after (the next ms of the UI draws over it) */
            int n = atoi(b);
            if (!strcmp(a, "prep")) {
                static const char *const STEP[] = {"", "READING THE PACKAGE", "CHECKING IT", "COPYING ITS INSTALLER",
                                                   "WAITING FOR THE COMPUTER", "STARTING ITS INSTALLER"};
                is_open("PREPARING THE INSTALL");
                is_note("NOTHING CHANGES UNTIL IT IS ALL HERE");
                is_step(STEP[n >= 1 && n <= 5 ? n : 1]);
                is_bar((uint32_t)n, 5);
            } else {
                is_open("INSTALLING PENUMBRA " PEN_VERSION);
                is_note("THE FM-1 STARTS AGAIN WHEN IT IS DONE");
                is_step(n ? "WRITING" : "WAITING FOR THE COMPUTER");
                is_bar((uint32_t)n, 100);
            }
        } else if (!strcmp(cmd, "usbaudio")) {        /* usbaudio 1|0: a computer takes the USB audio, or lets it go */
            usb_audio_on = atoi(a) != 0;
        } else if (!strcmp(cmd, "knobs")) {           /* knobs real: as on the FM-1 (a click from rest wakes the knob, a
                                                       * snap back is not taken, a fast turn goes further); exact: a click
                                                       * a step */
            knobs_exact = strcmp(a, "real") != 0;
        } else if (!strcmp(cmd, "dswell")) {          /* dswell N: the drone voices that come and go (bit v); 0 all held,
                                                       * for scenarios about held voices (ECLIPSE's all come and go) */
            eng_jr.dswell = (uint8_t)(atoi(a) & 0x1F);
        } else if (!strcmp(cmd, "legacy10")) {        /* 1.0's flash: settings format 3 (the FX page's 8 at byte 40, 0.14's
                                                       * bytes before them), the journey playing and user slot 1 as format 5
                                                       * (what are ROOM and HALO now: 1.0's old values; the movement's bytes spare) */
            uint8_t s[52];
            static journey_t slots[JR_USER];
            journey_t j;
            int k;
            settings_defaults();
            memcpy(s, &cfg, sizeof s);
            ((uint32_t *)s)[1] = 3u;
            for (k = 24; k < 40; k++)
                s[k] = 64;                            /* (0.14's VOICES page, as 1.0 kept it) */
            for (k = 0; k < 8; k++)
                s[40 + k] = cfg.fx[k];
            s[40 + EF_RV_SIZE] = 70;                  /* (one of them changed: it must come over) */
            plat_store_save(OBJ_SET, s, sizeof s);
            jr_preset(1, &j);
            j.format = 5;
            for (k = 0; k < JR_SCENES; k++)
                j.scene[k].room = j.scene[k].halo = 90;   /* (1.0's density and swarm, unused) */
            memset(j.dmotion, 0, sizeof j.dmotion);
            memset(j.tide, 0, sizeof j.tide);
            memset(j.pan, 0, sizeof j.pan);
            j.sway_rate = 0;                          /* (what was SWAY's byte) */
            j.at = 1;
            plat_store_save(OBJ_WORK, &j, sizeof j);
            memset(slots, 0, sizeof slots);
            slots[0] = j;
            plat_store_save(OBJ_USER, slots, sizeof slots);
            store_writes = 0;
            held_btn = held_keys = 0;
            boot();
        } else if (!strcmp(cmd, "legacy12b") || !strcmp(cmd, "legacy12c")) {
            /* 1.2's betas: the journey playing as format 7 (the first: its one SWAY where RATE is now, PAN 2's
             * bytes spare) or 8 (the next two: PAN 2's switches where each part's sway is now) */
            journey_t j;
            jr_preset(3, &j);
            j.format = cmd[8] == 'b' ? 7 : 8;
            memset(j.sway, 0, sizeof j.sway);
            j.sway_off = 0;
            if (j.format == 8) {
                j.sway[EV_DRONE] = j.sway[EV_PULSE] = 1;   /* (switched on) */
                j.sway_off = 64;
            }
            j.pan[EV_VOX] = 20;
            j.sway_rate = 90;                         /* (its own PAN and SWAY: they must come over) */
            plat_store_save(OBJ_WORK, &j, sizeof j);
            store_writes = 0;
            held_btn = held_keys = 0;
            boot();
        } else if (!strcmp(cmd, "legacy11")) {        /* 1.1's flash: the journey playing and user slot 1 as format 6
                                                       * (PAN's and SWAY's bytes spare, so 0: hard left, were they read) */
            static journey_t slots[JR_USER];
            journey_t j;
            jr_preset(2, &j);
            j.format = 6;
            memset(j.pan, 0, sizeof j.pan);
            j.sway_rate = 0;                          /* (what was SWAY's byte) */
            j.tide[TD_RATE] = 30;                     /* (its own TIDES: they must come over) */
            plat_store_save(OBJ_WORK, &j, sizeof j);
            memset(slots, 0, sizeof slots);
            slots[0] = j;
            plat_store_save(OBJ_USER, slots, sizeof slots);
            store_writes = 0;
            held_btn = held_keys = 0;
            boot();
        } else if (!strcmp(cmd, "legacy16")) {        /* 1.6 / 1.7's flash: the journey playing as format 10 (TOTALITY, its
                                                       * PAN 2 and singing its own; the kick's bytes spare, so 0) */
            journey_t j;
            jr_preset(JR_PRESETS - 1, &j);
            j.format = 10;
            memset(j.kick, 0, sizeof j.kick);
            j.kick_land = 0;
            j.sway[EV_DRONE] = 77;                    /* (its own: it must come over, not be converted) */
            plat_store_save(OBJ_WORK, &j, sizeof j);
            store_writes = 0;
            held_btn = held_keys = 0;
            boot();
        } else if (!strcmp(cmd, "legacy18")) {        /* 1.8 .. 1.10's flash: the journey playing as format 11, its kick its
                                                       * own, its scenes' STAYS and PLAYS bytes 0.15's leftovers */
            journey_t j;
            jr_preset(0, &j);
            j.format = 11;
            j.kick[JR_KK_DRIVE] = 77;
            j.scene[0].stays = 7;
            j.scene[1].skip = 1;
            plat_store_save(OBJ_WORK, &j, sizeof j);
            store_writes = 0;
            held_btn = held_keys = 0;
            boot();
        } else if (!strcmp(cmd, "powercut")) {        /* the power goes: nothing more is saved; then on again */
            held_btn = held_keys = 0;
            boot();
        } else if (!strcmp(cmd, "listen")) {
            static const uint8_t HELLO[] = {ANN_H0, ANN_H1, ANN_H2, ANN_HELLO, ANN_VER};
            sim_listen = 1;
            ann_frame(HELLO, sizeof HELLO, now_ms);
            said_len = 0;
            said_log[0] = 0;
        } else if (!strcmp(cmd, "where")) {
            static const uint8_t WHERE[] = {ANN_H0, ANN_H1, ANN_H2, ANN_WHERE};
            ann_frame(WHERE, sizeof WHERE, now_ms);
        } else if (!strcmp(cmd, "said") || !strcmp(cmd, "said_none")) {
            const char *want = line + 5;
            char w[512];
            size_t n;
            snprintf(w, sizeof w, "%s", want);
            n = strlen(w);
            while (n && (w[n - 1] == '\n' || w[n - 1] == '\r' || w[n - 1] == ' '))
                w[--n] = 0;
            if (cmd[4] == '_' ? said_len != 0 : !strstr(said_log, w)) {
                printf("FAIL %s %s (said: %s)\n", cmd, cmd[4] == '_' ? "" : w, said_log);
                fails++;
            } else
                printf("  ok %s %s\n", cmd, cmd[4] == '_' ? "" : w);
            said_len = 0;
            said_log[0] = 0;
        } else {
            printf("line %d: unknown command %s\n", lineno, cmd);
            return 2;
        }
    }
    wav_close();
    if (midi_log)
        fclose(midi_log);
    if (fails)
        printf("%d expectation(s) failed\n", fails);
    return fails ? 1 : 0;
}
#endif /* PEN_WEB */
