/* SPDX-License-Identifier: GPL-3.0-only */
/* Penumbra's audio engine. engine_render() runs in the audio ISR; everything else is called from
 * the main loop and reaches the ISR only through the command queue, so the voices' state is only
 * ever touched by one context (and the second core's job, while the first waits for it).
 *
 * The voices (docs: "Penumbra: rewrite design"): DRONE (five voices, SWARM; black keys 1-5 latch
 * them, the journey holds them on its pedal), VOX (four voices: the white keys in PLAY, MIDI
 * notes and the looper's, far back in the shimmer), PULSE (a deep kick, black key 6, and BLOOM, a deep
 * slow swell in the key, black key 7, far into the reverb) and TEXTURE (the wind), into the shimmer reverb, the tape delay
 * and the master stage. The journey (seq/journey.c) runs in CTRL, its steps on the clock's 16ths, and
 * its scene and the HOME macros set the voices each block (conduct). Every stage of every block is
 * timed on the 24 MHz timer, per core, published once a second for the BENCH page.
 *
 * The render, per block:
 *   core 1: CTRL (commands, MIDI in, the clock and the journey's steps, the drone's control steps)
 *   core 2: DRN BUS (the drone's bus: wind, drive and filter, then SWARM, on the last block's
 *           voices), DRONE 2 (its share of this block's drone voices), VOX, PULSE, TEXTURE
 *   core 1: DRONE 1 (the rest of the drone voices), FX WET (the reverb and delay returns of the last
 *           block's sends), then WAIT for core 2, OUTPUT (the voices' gains and sends, the distortion
 *           and glue compressor, the master's compressor, filter and limiter, the output's scale)
 * The effects and the drone's bus run a block behind (5.8 ms), so each core works while the other
 * does. DRONE CORE says whose the drone voices are: all the first's, all the second's, or SPLIT (the
 * default): each block, the share of the sounding voices that has the two cores finish closest
 * together, from what the blocks before measured (engine.c drone_mask2). */
#pragma once
#include <stdint.h>
#include "../seq/clock.h"
#include "../seq/journey.h"
#include "../seq/looper.h"

extern tclock_t eng_clock;
#define ENG_DRONES 5                           /* the drone voices (dsp/drone.h): black keys 1-5 */

/* the journey that plays (seq/journey.h): the main loop writes it a byte at a time (and loads a
 * whole one, then engine_journey_loaded); the ISR reads it, and writes its loops and its scene */
extern journey_t eng_jr;
const jrun_t *engine_jr(void);                 /* (main loop, read only) the director: where the journey is */

/* the sound, saved with the journey (eng_jr.shape, eng_jr.dvoice), read by the ISR each block (conduct).
 * SHAPE: each voice's LEVEL (100 = as made) and four knobs (64 = as made where it is an offset):
 *   DRONE    FILTER, BODY (resonance), SWARM (the crowd, and the voices' detune with it), WAVE (soft .. reedy)
 *   VOX      BRIGHT (over the scene's), ATTACK, RELEASE, SHIMMER (how far into the reverb)
 *   PULSE    DROP (the kick's fall of pitch), DECAY, CLICK, SPACE
 *   TEXTURE  COLOUR (over the scene's), SWEEP, RATE, WIDTH
 * SH_HIDE is set only by a held note's SAVE: VOX's vibrato. Each drone voice, its black key held:
 * LEVEL, TONE, DETUNE (64: none), OCTAVE (0 down, 1 as the journey has it, 2 up) */
enum { EV_DRONE, EV_VOX, EV_PULSE, EV_TEX, EV_N };
enum { SH_LEVEL, SH_K1, SH_K2, SH_K3, SH_K4, SH_HIDE, SH_N };
enum { DV_LEVEL, DV_TONE, DV_DETUNE, DV_OCT, DV_N };
/* PULSE's BLOOM, black key 7 held (eng_jr.bloom; its level PULSE's SH_HIDE): LENGTH, HEIGHT (0 the root,
 * 1 an octave over, 2 two), FIFTH */
enum { BL_LENGTH, BL_HEIGHT, BL_FIFTH, BL_N };
/* the drone's own movement (eng_jr.dmotion, SHAPE's DRONE 2): its LFO's RATE (~1 s .. 100 s), SWEEP (the
 * LFO over its filter), WIDTH (the voices swinging apart in the field), DRIFT (their tuning wandering) */
enum { DM_RATE, DM_SWEEP, DM_WIDTH, DM_DRIFT, DM_N };
/* TIDES (eng_jr.tide, SHAPE's TIDES): one slow swell under everything, RATE (8 s .. 4 min a tide) and how
 * far it moves the DRONE's filter, the SPACE (every send) and VOX's brightness; SHAPE (ALGO): 0 an even
 * sine, 127 a wandering, uneven one */
enum { TD_RATE, TD_DRONE, TD_SPACE, TD_VOX, TD_SHAPE, TD_N };
_Static_assert(DM_N == JR_DMOTION && TD_N == JR_TIDE, "the journey keeps the movement");
float engine_tide(void);                         /* (main loop) the tide now, -1 .. 1 (the corona breathes with it) */
/* PAN (eng_jr.pan, SHAPE's PAN): each voice's place in the field, 0 left .. 64 the middle .. 127 right (the
 * drone's voices keep their spread around it; BLOOM goes with PULSE); its ALGO the RATE they sway at
 * (eng_jr.sway_rate: 0 the tide's, else engine_sway_period). PAN 2 (eng_jr.sway): how far each sways (VOX's
 * echoes half as far); its ALGO the OFFSET between them */
float engine_pan_now(int voice);                 /* (main loop) EV_*'s place now, the sway in it: 0 .. 127 */
float engine_echo(float *gain, int *ping);        /* (main loop) VOX's echoes: ms apart (0: none heard), each
                                                   * gain of the last, and whether they cross sides */
float engine_sway_period(int rate);              /* RATE 1 .. 127: seconds a sway */
_Static_assert(EV_N == JR_VOICES && SH_N == JR_SHAPE && DV_N == JR_DVOICE, "the journey keeps the sound");
/* VOX's sounds (eng_jr.vsound[vcur]: VOX's row of shape is unused): its SHAPE pages are VOX (BRIGHT,
 * ATTACK, RELEASE, SHIMMER), VOX 2 (WAVE, FILTER: low-pass .. band-pass, RESO, GLIDE) and VOX 3 (DETUNE,
 * B OCTAVE, B MIX, ENV: how far its envelope opens the filter); VIBRATO a held note's SAVE sets */
enum { VS_LEVEL, VS_BRIGHT, VS_ATTACK, VS_RELEASE, VS_SHIMMER, VS_VIB, VS_WAVE, VS_FILTER, VS_RESO, VS_GLIDE,
       VS_DETUNE, VS_BOCT, VS_BMIX, VS_ENV, VS_N };
_Static_assert(VS_N <= JR_VS, "a VOX sound fits its bytes");
_Static_assert(DV_OCT == 3 && VS_BOCT == 11 && BL_HEIGHT == 1, "the switches jr_sound_mix knows by place");
/* the hands' moves, on top of the sound and gone when they spring back (the UI glides them):
 *   THROWS (FX held)        SHIMMER, FEEDBACK (the delay's), FREEZE (the reverb holds, the sends close):
 *                           0 none .. 127 all the way; DIP: -127 a low-pass closed .. +127 a high-pass
 *                           open; WARP (ALGO): the delay's time bent, -127 slower (the echoes dive) .. +127
 *   BENDS (a white key held) VOX's BRIGHT, VIBRATO, SHIMMER, RELEASE: -64 .. +64
 *   PITCH (a white key held, ALGO) every VOX note's: -127 .. +127, the bend range either way */
enum { PF_SHIMMER, PF_FDBK, PF_FREEZE, PF_DIP, PF_BRIGHT, PF_VIB, PF_VSEND, PF_VREL, PF_PITCH, PF_WARP, PF_N };
void engine_perf(int i, int value);
void engine_bend_range(int semitones);           /* PITCH's and MIDI pitch bend's, either way */
/* the effects, as the FX page sets them: REVERB, DELAY (1.0's), then REVERB 2 (MOTION: the lines'
 * modulation, LOW CUT on its send, the shimmer's INTERVAL, the return's LEVEL) and DELAY 2 (its LEVEL,
 * LOW CUT, PING-PONG, and how far the WARP throw bends its time) */
enum { EF_RV_DECAY, EF_RV_SIZE, EF_RV_SHIMMER, EF_RV_TONE, EF_DL_TIME, EF_DL_FDBK, EF_DL_TONE, EF_DL_WEAR,
       EF_RV_MOD, EF_RV_LOWCUT, EF_RV_INTERVAL, EF_RV_LEVEL, EF_DL_LEVEL, EF_DL_LOWCUT, EF_DL_PING, EF_DL_WARP,
       EF_N };
void engine_fx(int i, int value);
int engine_fx_max(int i);
const char *engine_fx_value_name(int i, int value);   /* a switch's label (the delay's time), else 0 */

/* the benchmark: what each stage cost, in % of the block's real-time budget x 10 (so 1000 = the
 * whole block), averaged over a second and its worst block in that second */
enum { ST_CTRL, ST_DRN1, ST_DRN2, ST_DRNBUS, ST_VOX, ST_PULSE, ST_TEX, ST_FXWET, ST_WAIT, ST_OUT,
       ST_CORE1, ST_CORE2, ST_N };
enum { DRONE_CORE1, DRONE_CORE2, DRONE_SPLIT };
typedef struct {
    uint16_t avg[ST_N], peak[ST_N];
    uint32_t blocks;                   /* blocks in the window */
    uint8_t two_cores, drone_core;     /* how the window ran */
} bench_t;
uint32_t engine_bench(bench_t *out);   /* main loop: the last second's numbers; returns their serial (0: none yet) */
const char *engine_stage_name(int st);

/* overload guard: the platform reports each block's load after rendering it */
void engine_load(uint32_t pct, uint32_t frames);           /* ISR, after engine_render */
int engine_guard_active(void);
extern volatile uint32_t eng_guard_count;                   /* times it engaged */
extern volatile uint16_t eng_level;                         /* the output's peak, Q15, held for the UI to fall */
extern volatile uint32_t eng_steps;                         /* 16ths since PLAY (the clock's), for the screen */
extern volatile uint32_t eng_kicks;                         /* PULSE's kicks so far (the corona flares on each) */
extern volatile uint32_t eng_vox_notes;                     /* VOX's notes so far (the hands', the looper's) */
extern uint32_t eng_out_clips;                              /* output samples past full scale, since power-on */

void engine_init(void);
void engine_render(int32_t *out_lr, uint32_t n);   /* ISR: n stereo frames (<= 256), 24-bit in int32 */
void engine_volume(int32_t *out_lr, uint32_t n);   /* ISR, after engine_render (and the USB tap) */

/* main loop -> ISR */
void engine_white_key(int w, int down, int oct);   /* a white key (0..15): VOX in the scene's key */
void engine_looper(int op);                        /* seq/looper.h: REC, PLAY, UNDO, CLEAR, its speed */
enum { LOOPER_REC, LOOPER_PLAY, LOOPER_UNDO, LOOPER_CLEAR, LOOPER_SLOWER, LOOPER_FASTER };
uint32_t engine_looper_save(void *dst, uint32_t max);   /* (main loop) the loop as it is, to keep: bytes (0: not now) */
int engine_looper_load(const void *src, uint32_t n);    /* (before the audio, or between blocks) */
const looper_t *engine_looper_state(void);         /* (main loop, read only) */
#define LOOP_LAYER_DELETE LL_N                     /* engine_loop_layer's field: the layer taken out */
void engine_loop_layer(int layer, int field, int value);   /* a kept layer's LEVEL, SOUND, OCTAVE or MUTE (looper.h LL_*) */
void engine_freeze(void);                          /* the notes held keep sounding (again: they let go) */
int engine_frozen(void);                           /* (main loop) notes frozen */
void engine_travel(int scene);                     /* the scene glides there */
void engine_scene_swap(int a, int b);              /* two scenes change places (SCENE: SEL held, K1); the one playing
                                                    * plays on, wherever it now is */
/* MIDI for a DAW. In: the channel's CCs and program changes, and the next channel's notes (the black keys),
 * for the UI to take (main loop); out (the audio ISR sends it, so nothing else writes the ring): a message
 * from the UI, and the white keys' notes as they sound (engine_midi_notes_out) */
int engine_midi_take(uint32_t *pkt);
void engine_midi_send(int status, int d1, int d2);
void engine_midi_notes_out(int on);
void engine_morph(int detents);                    /* MORPH: toward the next scene (+), the one before (-) */
void engine_journey_loaded(void);                  /* eng_jr is a new journey: start it from its scene */
void engine_drone_key(int voice);                  /* a black key: the voice by its MODE (HOLD: latch) */
int engine_drone_on(int voice);                    /* (main loop) the voice is on: latched, or in its swell */
float engine_drone_level(int voice);               /* (main loop) how loud it is now, 0..1 of its LEVEL (it rises, falls) */
void engine_pulse(int which, int vel);             /* PULSE_KICK (0) or PULSE_BLOOM (1), vel 0..127 */
int engine_vox_sounding(void);                     /* (main loop) a VOX voice sounds */
float engine_layer_place(int layer);           /* (main loop) a loop layer's place now, 0 .. 127 (drifting) */
int engine_vox_probe(int what);                /* (tests) a looped note sounding: 0 its place, 1 its filter x100 */
int engine_vox_sounds(void);                    /* (tests) the VOX sounds with a note held now (bit s) */
void engine_load_test(int on);                     /* every voice at its heaviest: the worst case */
int engine_load_testing(void);
void engine_out_loud(int on);                      /* 1: the output at the codec's full scale */
void engine_usb_full(int on);                      /* 1: USB audio at full level, MASTER after it */
void engine_drone_core(int mode);                  /* DRONE_CORE1, DRONE_CORE2, DRONE_SPLIT */
void engine_midi_ch(int ch);                       /* VOX's channel in: 1..16, 0 = off */
uint32_t engine_quiet_ms(void);                    /* how long the output has been silent */
