/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Small-canvas renderer (no full framebuffer). Draw text/lines into
 * an off-screen strip, then blit it in one DMA transfer. Pixels are stored
 * byte-swapped (the panel takes RGB565 big-endian). */
typedef struct {               /* proportional, see tools/gen_font.py */
    uint8_t h;
    uint8_t pad;               /* bitmap starts this many pixels left of the pen */
    uint8_t first, last;
    const uint8_t *adv;        /* advance per glyph */
    const uint8_t *bw;         /* bitmap width per glyph (starts FONT_PAD left of the pen) */
    const uint16_t *off;       /* byte offset of each glyph */
    const uint8_t *data;
} felucca_font_t;
#include "felucca_font.h"

#define CV_MAX (240u * 144u)      /* the main area, both bands, is 240 x 144 */
static uint16_t cv_px[CV_MAX] __attribute__((section(".pool")));
static uint32_t cv_w, cv_h;
static int32_t cv_oy;            /* y offset for graph drawing */
static int32_t cv_y0, cv_y1;     /* the rows drawing may touch */

#define RGB(r, g, b) ((uint16_t)((((r) >> 3) << 11) | (((g) >> 2) << 5) | ((b) >> 3)))
#define C_BLACK 0x0000u
#define C_WHITE 0xFFFFu              /* accent only: what is being touched / where we are */
/* Penumbra's one palette, ECLIPSE: the night sky. Five steps, darkest to brightest, on a blue-black:
 * blue-grey structure (rules, empty cells, labels), the corona's orange for what is secondary or
 * active, moonlight for values. Colour on the screen then means something. */
#define C_LINE RGB(30, 33, 52)       /* 1 rules, separators */
#define C_DIM RGB(66, 71, 102)       /* 2 inactive, units */
#define C_GRAY RGB(138, 143, 174)    /* 3 labels */
#define C_AMB RGB(255, 150, 70)      /* 4 the corona: secondary, active */
#define C_HI RGB(236, 234, 246)      /* 5 moonlight: values */
#define C_BG RGB(7, 8, 16)           /* the night behind everything */

static inline uint16_t swap16(uint32_t c) { return (uint16_t)(((c >> 8) & 0xFFu) | ((c & 0xFFu) << 8)); }

static void cv_begin(uint32_t w, uint32_t h, uint16_t bg)
{
    uint32_t i, n;
    if (w * h > CV_MAX)
        h = CV_MAX / w;
    lcd_sync();                     /* the last blit may still read cv_px */
    cv_w = w;
    cv_h = h;
    cv_oy = cv_y0 = 0;
    cv_y1 = (int32_t)h;
    n = w * h;
    for (i = 0; i < n; i++)
        cv_px[i] = swap16(bg);
}

static void cv_blit(uint32_t x, uint32_t y) { lcd_blit(x, y, cv_w, cv_h, cv_px); }

static inline void cv_pset(int32_t x, int32_t y, uint16_t c)
{
    y += cv_oy;
    if ((uint32_t)x < cv_w && y >= cv_y0 && y < cv_y1)
        cv_px[(uint32_t)y * cv_w + (uint32_t)x] = swap16(c);
}

static void cv_rect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c)
{
    int32_t x1 = x + w, y1 = y + h + cv_oy, i;
    uint16_t sc = swap16(c);
    y += cv_oy;                             /* clipped once, then filled row by row */
    if (x < 0)
        x = 0;
    if (y < cv_y0)
        y = cv_y0;
    if (x1 > (int32_t)cv_w)
        x1 = (int32_t)cv_w;
    if (y1 > cv_y1)
        y1 = cv_y1;
    for (; y < y1; y++)
        for (i = x; i < x1; i++)
            cv_px[(uint32_t)y * cv_w + (uint32_t)i] = sc;
}

/* glyph index of a character: lower case folds to upper case when the font
 * has none, anything missing (and C1 controls) draws as '?' */
static uint32_t glyph(const felucca_font_t *f, uint32_t ch)
{
    if (ch >= 'a' && ch <= 'z' && f->last < 'a')
        ch -= 32u;
    if (ch < f->first || ch > f->last || (ch >= 127u && ch < 160u))
        ch = '?';
    return ch - f->first;
}

/* text in colour c, each pixel's coverage blended over what is already on the canvas (an
 * anti-aliased face on a coloured box gets no dark fringe); returns the end x */
static int32_t cv_text(int32_t x, int32_t y, const felucca_font_t *f, const char *s, uint16_t c)
{
    uint32_t r = c >> 11, g = (c >> 5) & 63u, b = c & 31u;
    for (; *s; s++) {
        uint32_t gi = glyph(f, (uint8_t)*s), gx, gy, w, bpr;
        const uint8_t *gd;
        w = f->bw[gi];
        bpr = (w + 1u) / 2u;
        gd = f->data + f->off[gi];
        for (gy = 0; gy < f->h; gy++)
            for (gx = 0; gx < w; gx++) {
                uint32_t a = gd[gy * bpr + gx / 2u];
                int32_t px = x - f->pad + (int32_t)gx, py = y + (int32_t)gy + cv_oy;
                a = (gx & 1u) ? (a & 15u) : (a >> 4);
                if (!a || (uint32_t)px >= cv_w || py < cv_y0 || py >= cv_y1)
                    continue;
                if (a == 15u) {
                    cv_px[(uint32_t)py * cv_w + (uint32_t)px] = swap16(c);
                } else {
                    uint32_t bg = swap16(cv_px[(uint32_t)py * cv_w + (uint32_t)px]);
                    uint32_t br = bg >> 11, bgg = (bg >> 5) & 63u, bb = bg & 31u;
                    uint32_t nr = (r * a + br * (15u - a)) / 15u, ng = (g * a + bgg * (15u - a)) / 15u,
                             nb = (b * a + bb * (15u - a)) / 15u;
                    cv_px[(uint32_t)py * cv_w + (uint32_t)px] = swap16((nr << 11) | (ng << 5) | nb);
                }
            }
        x += f->adv[gi];
    }
    return x;
}

static int32_t text_w(const felucca_font_t *f, const char *s)
{
    int32_t w = 0;
    for (; *s; s++)
        w += f->adv[glyph(f, (uint8_t)*s)];
    return w;
}

/* one-shot: text in a box, cleared to black, blitted */
static void draw_text_box(uint32_t x, uint32_t y, uint32_t w, const felucca_font_t *f, const char *s,
                          uint16_t c, int align)
{
    int32_t tw = text_w(f, s), tx = 0;
    cv_begin(w, f->h, C_BLACK);
    if (align == 1)
        tx = ((int32_t)w - tw) / 2;
    else if (align == 2)
        tx = (int32_t)w - tw;
    cv_text(tx, 0, f, s, c);
    cv_blit(x, y);
    lcd_sync();                     /* one-shots (boot, crash, UBOOT, update) finish here */
}

/* Penumbra: the boot screen. The Lunar Eclipse Forge mark (tools/gen_logo.py) in moonlight, in an
 * eclipse's corona: a ring that glows out from its edge into the dark, and a few stars. */
#include "logo.h"
#include "dsp/fastmath.h"
#define C_NIGHT C_BG
static uint16_t mix565(uint16_t a, uint16_t b, uint32_t t)   /* a to b, t 0..255 */
{
    uint32_t r = ((a >> 11) * (255u - t) + (b >> 11) * t) / 255u;
    uint32_t g = (((a >> 5) & 63u) * (255u - t) + ((b >> 5) & 63u) * t) / 255u;
    uint32_t bl = ((a & 31u) * (255u - t) + (b & 31u) * t) / 255u;
    return (uint16_t)((r << 11) | (g << 5) | bl);
}

static void draw_splash(const char *name, const char *sub)
{
    static const uint8_t STARS[][2] = {{14, 18}, {206, 10}, {226, 96}, {22, 120}, {58, 54},
                                       {188, 132}, {120, 4}, {34, 76}, {214, 52}};
    const uint16_t moon = RGB(226, 224, 236), corona = RGB(255, 150, 70);
    const int32_t cx = 120, cy = 70, R = 64;
    int32_t x, y, ox = cx - LOGO_W / 2, oy = cy - LOGO_H / 2;
    uint32_t k;
    lcd_fill(0, 0, 240, 240, C_NIGHT);
    cv_begin(240, 140, C_NIGHT);
    for (k = 0; k < sizeof STARS / sizeof STARS[0]; k++)
        cv_pset(STARS[k][0], STARS[k][1], RGB(150, 150, 170));
    for (y = cy - R - 14; y <= cy + R + 14; y++)      /* the corona: bright at the ring, fading outwards */
        for (x = cx - R - 14; x <= cx + R + 14; x++) {
            float d = fm_sqrtf((float)((x - cx) * (x - cx) + (y - cy) * (y - cy))) - (float)R;
            float a = d < 0.0f ? 1.0f + d * 0.9f : 1.0f - d / 14.0f;
            if (a > 0.0f && (uint32_t)x < cv_w && (uint32_t)y < cv_h) {
                uint16_t bg = swap16(cv_px[(uint32_t)y * cv_w + (uint32_t)x]);
                cv_px[(uint32_t)y * cv_w + (uint32_t)x] = swap16(mix565(bg, corona, (uint32_t)(a * a * 255.0f)));
            }
        }
    for (y = cy - R + 2; y < cy + R - 1; y++)        /* the moon's dark face inside it */
        for (x = cx - R + 2; x < cx + R - 1; x++)
            if ((x - cx) * (x - cx) + (y - cy) * (y - cy) < (R - 1) * (R - 1))
                cv_pset(x, y, C_NIGHT);
    for (y = 0; y < LOGO_H; y++)                      /* the mark, its edges blended */
        for (x = 0; x < LOGO_W; x++) {
            uint32_t a = LOGO_PX[y * ((LOGO_W + 1) / 2) + x / 2];
            a = (x & 1) ? (a & 15u) : (a >> 4);
            if (a) {
                uint32_t i = (uint32_t)(oy + y) * cv_w + (uint32_t)(ox + x);
                cv_px[i] = swap16(mix565(swap16(cv_px[i]), moon, a * 17u));
            }
        }
    cv_blit(0, 6);
    cv_begin(240, 60, C_NIGHT);                      /* the names, on the same night */
    cv_text((240 - text_w(&FONT_M, name)) / 2, 6, &FONT_M, name, RGB(240, 238, 246));
    cv_text((240 - text_w(&FONT_XS, sub)) / 2, 40, &FONT_XS, sub, RGB(138, 138, 160));
    cv_blit(0, 160);
    lcd_sync();
}
