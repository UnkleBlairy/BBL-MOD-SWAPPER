#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Make Penumbra's site (GitHub Pages, .github/workflows/pages.yml; locally: python3 -m http.server in OUT_DIR):

  index.html                     what Penumbra is, and the way in
  install/index.html             the web installer (web/installer.html, with fm1pkg.js, fm1ota.js and the
                                 package's metadata inlined; Chrome or Edge, Web MIDI)
  firmware/penumbra-VERSION.fwsc the package the installer writes; also the download
  words/                         the screen reader's words files (fm1-reader), every one ever made
  cheatsheet/                    one printable page (web/cheatsheet), with its PDF
  backup/                        what the FM-1 keeps, to a file and back (web/backup; Chrome or Edge, Web MIDI)
  journey/                       a journey of one's own, onto the FM-1 (web/journey; Web MIDI too)
  emu/                           Penumbra in the browser, when build/emu exists (web/emu/build.sh, first)

  tools/make_pages.py build/penumbra-0.7-beta.fwsc 0.7-beta OUT_DIR

The package must be a release build (./build.sh --release X.Y): its identity, FM-1_73XXYYZZ (0.x betas:
FM-1_9XXYYZZ), is what the installer checks the download against and what the FM-1 reports after the install."""
import html
import json
import re
import shutil
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
BLOCKS, BLK, KEEP = 20, 0x30, 0x2F                # the package's first blocks (Felucca's format, fm1pkg.js)


def strip_module(src):
    """an ES module's source as a plain script, to inline it"""
    src = re.sub(r"^export\s+", "", src, flags=re.M)
    return re.sub(r"^import .*?;\n", "", src, flags=re.M)


def product_of(raw):
    """the package identity: one marker byte after each of the first 20 blocks (fm1pkg.js productOf)"""
    return "".join(chr((m - i - 1) & 0xFF) for i in range(BLOCKS) if (m := raw[i * BLK + KEEP]) != 0x7D)

LANDING = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Penumbra for the FM-1</title>
<style>
  :root { color-scheme: dark; }
  body { margin: 0; background: #07080f; color: #ecebf6; font: 17px/1.5 system-ui, sans-serif; }
  main { max-width: 36rem; margin: 0 auto; padding: 3rem 1rem; }
  h1 { font-weight: 600; letter-spacing: .02em; margin: 0 0 .25rem; }
  .sub { color: #8a8fae; margin: 0 0 2rem; }
  a { color: #ff9646; }
  .go { display: inline-block; padding: .7rem 1.2rem; border: 1px solid #ff9646; border-radius: 8px; text-decoration: none; }
  .small { color: #8a8fae; font-size: 14px; margin-top: 2rem; }
</style>
</head>
<body>
<main>
<h1>Penumbra</h1>
<p class="sub">A space-drone instrument for the M-VAVE FM-1, by Lunar Eclipse Forge. __VERSION__</p>
<p>An ambient space-drone synth that plays itself until you do. Switched on, its drone swells in, a far-off
voice sings, and it glides from scene to scene. It is played by shaping it: HOME's knobs on the drone, VOX,
the tides and the space; throws of shimmer and frozen rooms; a slow walk to the next scene. Every key is in
tune, and loops follow each key change.</p>
<p><a class="go" href="emu/">Play it in the browser</a> &nbsp; <a class="go" href="install/">Install __VERSION__</a></p>
<p><a href="cheatsheet/">Cheat sheet</a> &nbsp;·&nbsp; <a href="journey/">Journeys</a> &nbsp;·&nbsp; <a href="backup/">Backup</a> &nbsp;·&nbsp; <a href="https://github.com/MadMooneyham/Penumbra/blob/main/MANUAL.md">Manual</a>
&nbsp;·&nbsp; <a href="firmware/__PKG__">Download the package</a> &nbsp;·&nbsp; <a href="https://github.com/MadMooneyham/Penumbra">Source</a></p>
<p class="small">To go back to the official firmware, the installer can write it, or use M-VAVE's updater, M-UPGRADE,
from <a href="https://www.m-vave.com/download">m-vave.com/download</a>. M-VAVE and FM-1 are trademarks of their owners.</p>
</main>
</body>
</html>
"""


def main(pkg, version, out):
    pkg, out = Path(pkg), Path(out)
    raw = pkg.read_bytes()
    product = product_of(raw)
    if not re.fullmatch(r"FM-1_73\d{6}|FM-1_9\d{6}", product):
        raise SystemExit(f"{pkg}: identity {product!r}: make a release build (./build.sh --release X.Y)")
    if b"FELUCCA-LOADER-1" not in raw:
        raise SystemExit(f"{pkg}: no update loader in it")
    name = f"penumbra-{re.sub(r'[^A-Za-z0-9.-]', '-', version)}.fwsc"
    if out.exists():
        shutil.rmtree(out)
    for d in ("install", "firmware"):
        (out / d).mkdir(parents=True)
    shutil.copy(pkg, out / "firmware" / name)
    page = (SRC / "web" / "installer.html").read_text(encoding="utf-8")
    lib = strip_module((SRC / "web" / "fm1pkg.js").read_text(encoding="utf-8")) + "\n" + \
        strip_module((SRC / "web" / "fm1ota.js").read_text(encoding="utf-8"))
    meta = json.dumps({"version": version, "product": product, "pkg": "../firmware/" + name})
    for mark in ("/*LIB*/", "/*META*/"):
        if page.count(mark) != 1:
            raise SystemExit(f"installer.html must contain {mark} once")
    (out / "install" / "index.html").write_text(page.replace("/*LIB*/", lib).replace("/*META*/", meta), encoding="utf-8")
    (out / "index.html").write_text(LANDING.replace("__VERSION__", html.escape(version)).replace("__PKG__", name),
                                    encoding="utf-8")
    shutil.copytree(SRC / "web" / "words", out / "words")
    shutil.copytree(SRC / "web" / "cheatsheet", out / "cheatsheet")
    shutil.copytree(SRC / "web" / "backup", out / "backup")
    shutil.copytree(SRC / "web" / "journey", out / "journey")
    emu = SRC / "build" / "emu"
    if (emu / "penumbra.wasm").is_file():
        shutil.copytree(emu, out / "emu")
    else:
        print("note: no build/emu/penumbra.wasm (web/emu/build.sh, needs emcc): the site has no emulator")
    (out / ".nojekyll").write_text("")
    print(f"site: {out}: index.html, install/ ({product}), firmware/{name} ({len(raw)} B), words/, cheatsheet/, backup/, journey/"
          + (", emu/" if (out / "emu").is_dir() else ""))


if __name__ == "__main__":
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    main(*sys.argv[1:4])
