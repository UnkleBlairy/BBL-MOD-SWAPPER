TRAPSTATION OS 1.1.0.2 for the BBL Mod Swapper

Original by sog-maker: https://github.com/sog-maker/trapstation-os
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: TRAPSTAT-source.zip on the ports page.
