/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Blair (blairysbeatlab), BBL JAM BOX; based on Felucca by Leo Kuroshita (@kurogedelic), Hügelton Instruments */

#define GB_MACH 6u
_Static_assert(GB_NPOOL <= GB_MACH, "more pools: more sound objects (GB_SOBJ, storage.c)");
#define GB_SLOTS 16u
#define GB_KITS 11u
#define GB_SOBJ 3u
#define GB_KOBJ 4u
#define GB_KPER 3u
#define GB_MAGIC 0x31534247u
#define GB_KMAGIC 0x324B4247u
#define GB_PMAGIC 0x33534247u
#define GB_K3MAGIC 0x334B4247u
#define GB_KLK 264u

#define GB_KG 27u

typedef struct { uint8_t used, np; int8_t p[P_COUNT]; } gb_snd_t;

typedef struct { uint32_t magic; uint16_t np, kind; gb_snd_t s[2u * GB_SLOTS]; } gb_sobj_t;
typedef struct {
    uint8_t used, rel, fade, rsv;
    gb_snd_t s[NTRK];
    perf_mac_t mac[PM_NM];
    int16_t g[GB_KG];
    uint8_t lk[GB_KLK];
} gb_kit_t;
typedef struct { uint32_t magic; uint16_t np, kind; gb_kit_t k[GB_KPER]; } gb_kobj_t;

#define GB_NTB (2u + NTRK * 5u)
#define GB_KLK_LK (GB_KLK - GB_NTB)
#define GB_NT0 0x5Au
#define GB_NT1 0xA5u

typedef struct {
    uint8_t used, rel, fade, rsv;
    gb_snd_t s[NTRK];
    perf_mac_t mac[PM_NM];
    int16_t g[GB_KG];
} gb_kit2_t;
typedef struct { uint32_t magic; uint16_t np, kind; gb_kit2_t k[GB_KPER]; } gb_kobj2_t;

typedef struct {
    uint8_t used, rel, fade, rsv;
    gb_snd_t s[4];
    perf_mac_t mac[PM_NM];
    int16_t g[GB_KG];
} gb_kit_old_t;
typedef struct { uint32_t magic; uint16_t np, kind; gb_kit_old_t k[4]; } gb_kobj_old_t;
_Static_assert(sizeof(gb_kobj_old_t) == 3136u, "the four-track build's kit objects");
_Static_assert(sizeof(gb_sobj_t) <= 3840u, "32 sounds in a storage object");
_Static_assert(sizeof(gb_kobj_t) <= 3840u, "3 kits in a storage object");
_Static_assert(GB_KOBJ * GB_KPER >= GB_KITS, "every kit has a place");
static gb_sobj_t gb_so[GB_SOBJ] __attribute__((unused));
static gb_kobj_t gb_ko[GB_KOBJ] __attribute__((unused));
static uint8_t gb_dirty, gb_ready;

static int gb_sound_id(uint32_t id)
{
    return id != P_SLEN && id != P_SDIV && id != P_SSWING && id != P_SGATE && id != P_SQNT && id != P_APROB && id != P_MUTE;
}

static const uint8_t GB_KIT_G[] = {G_SWING, G_DTIME, G_DFDBK, G_DCOLOR, G_DMIX, G_RSIZE, G_RDAMP, G_RTYPE,
                                   G_SYNC, G_CRATE, G_CDEPTH, G_INFO};

static const uint8_t GB_KIT_FXL[] = {G_F1RATE, G_F1DEST, G_F1AMT, G_F2RATE, G_F2DEST, G_F2AMT, G_F3RATE, G_F3DEST, G_F3AMT};
_Static_assert(G_F3AMT < GB_KG && G_AMP < GB_KG && G_F1WAVE >= GB_KG, "the kit's g: the old ids");

static gb_kit_t *gb_kit(uint32_t k);

static void gb_kit_old_load(uint32_t o)
{
    static gb_kobj_old_t old __attribute__((unused));
    uint32_t i, j, k;
    if (st_load(OBJ_GB0 + GB_SOBJ + o, &old, sizeof old) != (int)sizeof old || old.magic != GB_MAGIC)
        return;
    for (i = 0; i < 4u; i++) {
        const gb_kit_old_t *ok = &old.k[i];
        gb_kit_t *kt;
        k = o * 4u + i;
        if (k >= GB_KITS || !ok->used)
            continue;
        kt = gb_kit(k);
        memset(kt, 0, sizeof *kt);
        kt->used = 1;
        kt->rel = ok->rel;
        kt->fade = ok->fade;
        for (j = 0; j < 4u; j++)
            kt->s[j] = ok->s[j];
        memcpy(kt->mac, ok->mac, sizeof kt->mac);
        for (j = 0; j < PM_NM; j++) {
            uint32_t n;
            for (n = 0; n < PM_N; n++)
                if (kt->mac[j].trk[n] == 4u)
                    kt->mac[j].trk[n] = PM_G;
        }
        memcpy(kt->g, ok->g, sizeof kt->g);
        gb_ko[k / GB_KPER].magic = GB_K3MAGIC;
        gb_ko[k / GB_KPER].np = old.np;
        gb_dirty |= (uint8_t)(1u << (GB_SOBJ + k / GB_KPER));
    }
}

static gb_snd_t *gb_slot(uint32_t mach, uint32_t slot);

static void gb_pool_move(void)
{
    static gb_snd_t old[GB_SOBJ * 2u * GB_SLOTS] __attribute__((unused));
    uint8_t fill[GB_MACH] = {0};
    uint32_t o, i, n = 0;
    for (o = 0; o < GB_SOBJ; o++) {
        if (gb_so[o].magic == GB_MAGIC)
            for (i = 0; i < 2u * GB_SLOTS; i++)
                if (gb_so[o].s[i].used)
                    old[n++] = gb_so[o].s[i];
        memset(&gb_so[o], 0, sizeof gb_so[o]);
        gb_so[o].magic = GB_PMAGIC;
        gb_so[o].np = (uint16_t)P_COUNT;
        gb_dirty |= (uint8_t)(1u << o);
    }
    for (i = 0; i < n; i++) {
        int16_t in[P_COUNT], def[P_COUNT], out[P_COUNT];
        uint32_t j, np = old[i].np > P_COUNT ? P_COUNT : old[i].np, eng, m, pl;
        for (j = 0; j < P_COUNT; j++)
            def[j] = TP[j].def;
        for (j = 0; j < np; j++)
            in[j] = (int16_t)(old[i].p[j] + 64);
        params_by_count(out, in, np, def);
        eng = old[i].used == 2u ? ENGI_ANALOG : old[i].used == 3u ? ENGI_SAMPLER : old[i].used == 4u ? ENGI_MONO : ENGI_DIGITAL;
        for (m = 0; m < NMACH && !(MACHINES[m].engine == eng && MACHINES[m].sub == (uint32_t)out[P_E7]); m++)
            ;
        pl = gb_pool(m < NMACH ? m : 0u);
        if (fill[pl] < GB_SLOTS)
            *gb_slot(pl, fill[pl]++) = old[i];
    }
}

static void gb_store_init(void)
{
    uint32_t o, old = 0;
    if (gb_ready)
        return;
    gb_ready = 1;
    for (o = 0; o < GB_SOBJ; o++) {
#if FELUCCA_FLASH
        if (st_load(OBJ_GB0 + o, &gb_so[o], sizeof gb_so[o]) == (int)sizeof gb_so[o] &&
            (gb_so[o].magic == GB_PMAGIC || gb_so[o].magic == GB_MAGIC)) {
            old |= gb_so[o].magic == GB_MAGIC;
            continue;
        }
#endif
        memset(&gb_so[o], 0, sizeof gb_so[o]);
    }
    if (old)
        gb_pool_move();
    for (o = 0; o < GB_KOBJ; o++) {
#if FELUCCA_FLASH
        static gb_kobj2_t k2 __attribute__((unused));
        if (st_load(OBJ_GB0 + GB_SOBJ + o, &gb_ko[o], sizeof gb_ko[o]) == (int)sizeof gb_ko[o] && gb_ko[o].magic == GB_K3MAGIC)
            continue;
        if (st_load(OBJ_GB0 + GB_SOBJ + o, &k2, sizeof k2) == (int)sizeof k2 && k2.magic == GB_KMAGIC) {
            uint32_t i;
            memset(&gb_ko[o], 0, sizeof gb_ko[o]);
            gb_ko[o].magic = GB_K3MAGIC;
            gb_ko[o].np = k2.np;
            for (i = 0; i < GB_KPER; i++)
                memcpy(&gb_ko[o].k[i], &k2.k[i], sizeof k2.k[i]);
            gb_dirty |= (uint8_t)(1u << (GB_SOBJ + o));
            continue;
        }
#endif
        memset(&gb_ko[o], 0, sizeof gb_ko[o]);
    }
#if FELUCCA_FLASH
    for (o = 0; o < GB_KOBJ && gb_ko[o].magic != GB_K3MAGIC; o++)
        ;
    if (o == GB_KOBJ)
        for (o = 0; o < 3u; o++)
            gb_kit_old_load(o);
#endif
}

static void gb_store_poll(void)
{
#if FELUCCA_FLASH
    uint32_t o;
    if (!gb_dirty || !autosave_quiet())
        return;
    for (o = 0; o < GB_SOBJ + GB_KOBJ; o++)
        if ((gb_dirty >> o) & 1u) {
            const void *src = o < GB_SOBJ ? (const void *)&gb_so[o] : (const void *)&gb_ko[o - GB_SOBJ];
            uint32_t len = o < GB_SOBJ ? sizeof gb_so[0] : sizeof gb_ko[0];
            if (st_save(OBJ_GB0 + o, src, len) != 0)
                ui_message("SAVE FAILED");
            gb_dirty &= (uint8_t)~(1u << o);
            return;
        }
#else
    gb_dirty = 0;
#endif
}

#define GB_SN_MARK 0x5A
#define GB_F6_MARK 100
_Static_assert(GB_F6_MARK > 63 && GB_F6_MARK + TF6_COUNT <= 127, "an FM6 slot mark never reads as a value");
static void gb_snd_take(gb_snd_t *s, const track_t *t)
{
    uint32_t i;
    s->used = eng_idx(t->eng_req) == ENGI_ANALOG ? 2u : eng_idx(t->eng_req) == ENGI_SAMPLER ? 3u : eng_idx(t->eng_req) == ENGI_MONO ? 4u : 1u;
    s->np = (uint8_t)P_COUNT;
    for (i = 0; i < P_COUNT; i++)
        s->p[i] = (int8_t)(clamp(motion_base_value(t, i), -64, 127) - 64);

    i = (uint32_t)(t - trk) % NTRK;
    s->p[P_MUTE] = GB_SN_MARK;
    s->p[P_SLEN] = (int8_t)(lastc[i] > 4u ? 4u : lastc[i]);
    s->p[P_SDIV] = (int8_t)lastn[i][0];
    s->p[P_SSWING] = (int8_t)lastn[i][1];
    s->p[P_SGATE] = (int8_t)lastn[i][2];
    s->p[P_SQNT] = (int8_t)lastn[i][3];
#if TRAP_FM6_TEST

    if (t->eng_req == ENGI_FM6)
        s->p[P_APROB] = (int8_t)(GB_F6_MARK + (tf6_slot_of(i) < TF6_COUNT ? tf6_slot_of(i) : 0u));
#endif
}

static void gb_snd_put(const gb_snd_t *s, track_t *t)
{
    int16_t in[P_COUNT], def[P_COUNT], out[P_COUNT];
    uint32_t i, np = s->np > P_COUNT ? P_COUNT : s->np;
    for (i = 0; i < P_COUNT; i++)
        def[i] = t->p[i];
    for (i = 0; i < np; i++)
        in[i] = (int16_t)(s->p[i] + 64);
    params_by_count(out, in, np, def);
    xf_leave(trk_index(t));
    motion_restore(t);
    fm1_irq_off();
    t->eng_req = s->used == 2u ? ENGI_ANALOG : s->used == 3u ? ENGI_SAMPLER : s->used == 4u ? ENGI_MONO : ENGI_DIGITAL;
#if TRAP_FM6_TEST
    if (s->used == 1u && P_APROB < np && s->p[P_APROB] >= GB_F6_MARK && s->p[P_APROB] < GB_F6_MARK + (int)TF6_COUNT) {
        t->eng_req = ENGI_FM6;
        tf6_load(trk_index(t), (uint32_t)(s->p[P_APROB] - GB_F6_MARK));
    }
#endif
    t->p[P_E7] = out[P_E7];
    for (i = 0; i < P_COUNT; i++)
        if (gb_sound_id(i))
            t->p[i] = (int16_t)param_fit(track_desc(t, i), out[i]);
    fm1_irq_on();
    motion_rebase(t);
}

static uint32_t gb_mach_of(const track_t *t) { return gb_pool(trk_mach(t)); }
static gb_snd_t *gb_slot(uint32_t mach, uint32_t slot)
{
    mach %= GB_MACH;
    return &gb_so[mach / 2u].s[(mach & 1u) * GB_SLOTS + slot % GB_SLOTS];
}
static gb_kit_t *gb_kit(uint32_t k) { return &gb_ko[(k % GB_KITS) / GB_KPER].k[(k % GB_KITS) % GB_KPER]; }

static int gbs_used(uint32_t mach, uint32_t slot) { gb_store_init(); return gb_slot(mach, slot)->used; }
static int gbk_used(uint32_t k) { gb_store_init(); return k < GB_KITS && (gb_kit(k)->used || trap_kit_has(k)); }

static int gbs_save_sound(uint32_t slot)
{
    uint32_t m = gb_mach_of(TSEL);
    gb_store_init();
    xf_save(1);
    gb_snd_take(gb_slot(m, slot), TSEL);
    xf_save(0);
    gb_so[m / 2u].magic = GB_PMAGIC;
    gb_so[m / 2u].np = (uint16_t)P_COUNT;
    gb_dirty |= (uint8_t)(1u << (m / 2u));
    return 1;
}
static int gbs_load_sound(uint32_t slot)
{
    const gb_snd_t *s;
    gb_store_init();
    s = gb_slot(gb_mach_of(TSEL), slot);
    if (!s->used) {
        ui_message("EMPTY SLOT");
        return 0;
    }
    gb_snd_put(s, TSEL);
    {
        uint32_t i = song.sel % NTRK;
        int has = P_MUTE < s->np && s->p[P_MUTE] == GB_SN_MARK && s->p[P_SLEN] >= 0 && s->p[P_SLEN] <= 4;
        lastc[i] = (uint8_t)(has ? s->p[P_SLEN] : 0);
        if (has) {
            lastn[i][0] = (uint8_t)s->p[P_SDIV];
            lastn[i][1] = (uint8_t)s->p[P_SSWING];
            lastn[i][2] = (uint8_t)s->p[P_SGATE];
            lastn[i][3] = (uint8_t)s->p[P_SQNT];
        }
    }
    ui.force = 1;
    return 1;
}

static int gbk_lk_pack(uint8_t *lk)
{
    uint32_t k, o = 1, n = 0;
    memset(lk, 0, GB_KLK);
    for (k = 0; k < NTRK * 16u; k++) {
        const kit_key_t *kk = &kit[k / 16u][k % 16u];
        uint32_t c = kk->n > KIT_N ? KIT_N : kk->n;
        if (!c || k % 16u >= KIT_KEYS)
            continue;
        if (o + 2u + 3u * c > GB_KLK_LK || n == 255u) {
            lk[0] = (uint8_t)n;
            return 0;
        }
        lk[o++] = (uint8_t)((k / 16u) << 4 | (k % 16u));
        lk[o++] = (uint8_t)c;
        memcpy(lk + o, kk->id, c);
        o += c;
        memcpy(lk + o, kk->v, 2u * c);
        o += 2u * c;
        n++;
    }
    lk[0] = (uint8_t)n;
    return 1;
}

static void gbk_lk_unpack(const uint8_t *lk)
{
    uint32_t i, o = 1, k;
    for (k = 0; k < NTRK; k++)
        if (kit_cur[k])
            kit_undo(&trk[k]);
    memset(kit, 0, sizeof kit);
    for (i = 0; i < lk[0]; i++) {
        uint32_t at = lk[o], c = lk[o + 1u];
        kit_key_t *kk;
        if (c > KIT_N || o + 2u + 3u * c > GB_KLK)
            break;
        kk = (at >> 4) < NTRK ? &kit[at >> 4][at & 15u] : 0;
        if (kk) {
            kk->n = (uint8_t)c;
            memcpy(kk->id, lk + o + 2u, c);
            memcpy(kk->v, lk + o + 2u + c, 2u * c);
        }
        o += 2u + 3u * c;
    }
}
static int gbk_save(uint32_t k)
{
    gb_kit_t *kt;
    uint32_t i;
    if (k >= GB_KITS)
        return 0;
    gb_store_init();
    kt = gb_kit(k);
    memset(kt, 0, sizeof *kt);
    kt->used = 1;
    xf_save(1);
    for (i = 0; i < NTRK; i++)
        gb_snd_take(&kt->s[i], &trk[i]);
    memcpy(kt->mac, pm_mac, sizeof kt->mac);
    kt->rel = pm_rel;
    kt->fade = pm_fade;
    for (i = 0; i < GB_KG; i++)
        kt->g[i] = song.g[i];
    kt->rsv = (uint8_t)(1u + (uint32_t)song.g[G_F1WAVE] % 6u + 6u * ((uint32_t)song.g[G_F2WAVE] % 6u) +
                        36u * ((uint32_t)song.g[G_F3WAVE] % 6u));
    xf_save(0);
    if (!gbk_lk_pack(kt->lk))
        ui_message("KEY LOCKS PART SAVED");
    kt->lk[GB_KLK_LK] = GB_NT0;
    kt->lk[GB_KLK_LK + 1u] = GB_NT1;
    for (i = 0; i < NTRK; i++) {
        uint8_t *n = &kt->lk[GB_KLK_LK + 2u + 5u * i];
        n[0] = lastc[i] > 4u ? 4u : lastc[i];
        memcpy(n + 1, lastn[i], 4);
    }
    gb_ko[k / GB_KPER].magic = GB_K3MAGIC;
    gb_ko[k / GB_KPER].np = (uint16_t)P_COUNT;
    gb_dirty |= (uint8_t)(1u << (GB_SOBJ + k / GB_KPER));
    return 1;
}
static int gbk_load(uint32_t k)
{
    const gb_kit_t *kt;
    uint32_t i;
    if (k >= GB_KITS)
        return 0;
    gb_store_init();
    kt = gb_kit(k);
    if (!kt->used && !trap_kit_has(k)) {
        ui_message("EMPTY KIT");
        return 0;
    }
    if (pm_h.n) {
        ui_message("LET GO OF THE MACROS");
        return 0;
    }
    if (!kt->used) {
        trap_kit_load(k);
        return 1;
    }
    xf_leave(XF_ALL);
    for (i = 0; i < NTRK; i++)
        if (kt->s[i].used)
            gb_snd_put(&kt->s[i], &trk[i]);
    memcpy(pm_mac, kt->mac, sizeof pm_mac);
    for (i = 0; i < PM_NM; i++)
        if (pm_mac[i].n > PM_N)
            pm_mac[i].n = 0;
    pm_rel = kt->rel > 16u ? 16u : kt->rel;
    pm_fade = kt->fade > 4u ? 0u : kt->fade;
    for (i = 0; i < NELEM(GB_KIT_G); i++)
        song.g[GB_KIT_G[i]] = (int16_t)clamp(kt->g[GB_KIT_G[i]], GP[GB_KIT_G[i]].min, GP[GB_KIT_G[i]].max);
    if (kt->rsv) {
        uint32_t w = kt->rsv - 1u;
        for (i = 0; i < NELEM(GB_KIT_FXL); i++)
            song.g[GB_KIT_FXL[i]] = (int16_t)clamp(kt->g[GB_KIT_FXL[i]], GP[GB_KIT_FXL[i]].min, GP[GB_KIT_FXL[i]].max);
        song.g[G_F1WAVE] = (int16_t)(w % 6u);
        song.g[G_F2WAVE] = (int16_t)(w / 6u % 6u);
        song.g[G_F3WAVE] = (int16_t)(w / 36u % 6u);
    }
    gbk_lk_unpack(kt->lk);
    for (i = 0; i < NTRK; i++)
        if (kt->s[i].used) {
            const uint8_t *n = &kt->lk[GB_KLK_LK + 2u + 5u * i];
            int has = kt->lk[GB_KLK_LK] == GB_NT0 && kt->lk[GB_KLK_LK + 1u] == GB_NT1 && n[0] <= 4u;
            lastc[i] = (uint8_t)(has ? n[0] : 0u);
            if (has)
                memcpy(lastn[i], n + 1, 4);
        }
    ui.force = 1;
    return 1;
}

static inline uint32_t smp_u32(const uint8_t *p) { return p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }
static inline uint32_t smp_u16(const uint8_t *p) { return p[0] | (uint32_t)p[1] << 8; }
static int smp_scan_ok;
static void smp_scan(void)
{
    static smp_chunk_t tb[SMP_MAX];
    const uint8_t *h = SMP_XIP(SMP_BASE), *e;
    uint32_t cnt = 0, dlen = 0, i, k, ok;
    ok = smp_u32(h) == SMP_MAGIC && smp_u16(h + 4) == 1u && (cnt = smp_u16(h + 6)) <= SMP_MAX &&
         (dlen = smp_u32(h + 8)) <= SMP_CAP;
    if (ok)
        ok = ~st_crc32_add(st_crc32_add(0xFFFFFFFFu, h, 28u), h + 32, cnt * 24u) == smp_u32(h + 28);
    for (i = 0; ok && i < cnt; i++) {
        uint32_t off, len, rate;
        e = h + 32 + i * 24u;
        off = smp_u32(e + 12);
        len = smp_u32(e + 16);
        rate = smp_u16(e + 20);
        ok = len >= 64u && off <= dlen && len <= dlen - off && rate >= 4000u && rate <= 48000u && !smp_u16(e + 22);
        for (k = 0; k < 12u; k++)
            tb[i].name[k] = e[k] >= ' ' && e[k] < 127 ? (char)e[k] : (e[k] ? '?' : 0);
        tb[i].name[12] = 0;
        tb[i].off = SMP_DATA + off;
        tb[i].len = len;
        tb[i].rate = (uint16_t)rate;
    }
    if (ok)
        ok = st_crc32(SMP_XIP(SMP_DATA), dlen) == smp_u32(h + 12);
    if (!ok)
        cnt = 0;
    fm1_irq_off();
    for (i = 0; i < cnt; i++)
        smp_tab[i] = tb[i];
    smp_user = (uint8_t)cnt;
    smp_n = (uint8_t)cnt;
    smp_scan_ok = (int)ok;
    smp_gen++;
    fm1_irq_on();
    ui.force = 1;
}

static uint8_t smp_pk[GB_WAVE];
static uint32_t smp_pk_of = 0xFFFFFFFFu;

static uint8_t smp_zpk[GB_WAVE];
static const uint8_t *smp_zpeaks(uint32_t sl, int32_t x0, uint32_t w)
{
    uint32_t x, i;
    const smp_chunk_t *c;
    const uint8_t *d;
    if (sl >= smp_n)
        return 0;
    c = &smp_tab[sl];
    d = SMP_PTR(c->off);
    for (x = 0; x < GB_WAVE; x++) {
        int32_t a = x0 + (int32_t)(x * w / GB_WAVE), b = x0 + (int32_t)((x + 1u) * w / GB_WAVE), m = 0;
        b = b > a ? b : a + 1;
        for (i = (uint32_t)(a < 0 ? 0 : a); (int32_t)i < b && i < c->len; i++) {
            int32_t s = SMP_ULAW[d[i]];
            s = s < 0 ? -s : s;
            m = s > m ? s : m;
        }
        smp_zpk[x] = (uint8_t)(m >> 7);
    }
    return smp_zpk;
}

static const uint8_t *smp_peaks(uint32_t sl)
{
    uint32_t key = sl | smp_gen << 8, x, i;
    if (sl >= smp_n)
        return 0;
    if (smp_pk_of != key) {
        const smp_chunk_t *c = &smp_tab[sl];
        const uint8_t *d = SMP_PTR(c->off);
        for (x = 0; x < GB_WAVE; x++) {
            uint32_t a = x * c->len / GB_WAVE, b = (x + 1u) * c->len / GB_WAVE;
            int32_t m = 0;
            b = b > a ? b : a + 1u;
            for (i = a; i < b && i < c->len; i++) {
                int32_t s = SMP_ULAW[d[i]];
                s = s < 0 ? -s : s;
                m = s > m ? s : m;
            }
            smp_pk[x] = (uint8_t)(m >> 7);
        }
        smp_pk_of = key;
    }
    return smp_pk;
}

#define JAM_MAGIC (TRAP_FM6_TEST ? 0x374D414Au : 0x314D414Au)
#define JAM_MAGIC6 0x364D414Au

#define JAM_PART (ST_PAYLOAD_MAX - 4u)
#define JAM_CAP (2u * JAM_PART)
#define TF6_JAM_TRK (155u + 3u * 2u)
static uint8_t jam_buf[JAM_CAP] __attribute__((unused));
static uint8_t jam_old[JAM_CAP] __attribute__((unused));
static uint8_t jam_img[ST_PAYLOAD_MAX] __attribute__((unused));
static uint32_t jam_n, jam_oldn, jam_gen, jam_q0, jam_t;
static uint8_t jam_pend;

typedef struct { uint8_t *p; uint32_t n, cap, bad, pk; } jam_io_t;
static void jam_w(jam_io_t *w, const void *src, uint32_t len)
{
    if (w->n + len > w->cap) {
        w->bad = 1;
        return;
    }
    memcpy(w->p + w->n, src, len);
    w->n += len;
}
static void jam_w8(jam_io_t *w, uint32_t v) { uint8_t b = (uint8_t)v; jam_w(w, &b, 1); }
static void jam_w16(jam_io_t *w, uint32_t v) { uint16_t b = (uint16_t)v; jam_w(w, &b, 2); }
static int jam_r(jam_io_t *r, void *dst, uint32_t len)
{
    if (r->bad || r->n + len > r->cap) {
        r->bad = 1;
        return 0;
    }
    if (dst)
        memcpy(dst, r->p + r->n, len);
    r->n += len;
    return 1;
}
static uint32_t jam_r8(jam_io_t *r) { uint8_t b = 0; jam_r(r, &b, 1); return b; }
static uint32_t jam_r16(jam_io_t *r) { uint16_t b = 0; jam_r(r, &b, 2); return b; }

static int jam_step_used(const step_t *s)
{
    return s->n || s->hit || s->acc || s->probability || s->flags || s->roll || s->time == ST_TIE || s->time == ST_LOCK;
}

#define JAM_SPACK 0x80u
_Static_assert(sizeof(step_t) <= 16u && sizeof(step_t) < JAM_SPACK, "a step is one packed piece");
static void jam_wb(jam_io_t *w, const void *src, uint32_t len)
{
    const uint8_t *b = (const uint8_t *)src;
    uint32_t o, i, e, m;
    if (!w->pk) {
        jam_w(w, src, len);
        return;
    }
    for (o = 0; o < len; o += 16u) {
        e = len - o < 16u ? len - o : 16u;
        for (i = m = 0; i < e; i++)
            m |= (uint32_t)(b[o + i] != 0u) << i;
        jam_w16(w, m);
        for (i = 0; i < e; i++)
            if (b[o + i])
                jam_w8(w, b[o + i]);
    }
}
static int jam_rb(jam_io_t *r, void *dst, uint32_t len)
{
    uint8_t *b = (uint8_t *)dst;
    uint32_t o, i, e, m;
    if (!r->pk)
        return jam_r(r, dst, len);
    for (o = 0; o < len && !r->bad; o += 16u) {
        e = len - o < 16u ? len - o : 16u;
        m = jam_r16(r);
        if (m >> e)
            r->bad = 1;
        for (i = 0; i < e && !r->bad; i++) {
            uint32_t v = (m >> i) & 1u ? jam_r8(r) : 0u;
            if (b)
                b[o + i] = (uint8_t)v;
        }
    }
    return !r->bad;
}

typedef struct {
 uint8_t version,var[NTRK],live[NTRK],fresh[NTRK];
 gen_recipe_t recipe[NTRK];uint8_t eu[NTRK][3];
} gen_store_t;
_Static_assert(sizeof(gen_store_t)==109u,"compact generation session tail");
static uint32_t jam_make(uint8_t *out)
{
    jam_io_t w = {out, 0, JAM_CAP, 0, TRAP_FM6_TEST};
    uint32_t k, i, n;
    jam_w(&w, &(uint32_t){JAM_MAGIC}, 4);
    jam_w8(&w, song.sel);
    jam_w8(&w, pm_rel);
    jam_w8(&w, pm_fade);
    jam_w8(&w, G_COUNT);
    jam_w(&w, song.g, sizeof song.g);
    jam_w16(&w, sizeof pm_mac);
    jam_wb(&w, pm_mac, sizeof pm_mac);
    jam_w16(&w, sizeof fxl);
    jam_wb(&w, &fxl, sizeof fxl);
    jam_w8(&w, motion.count);
    jam_w8(&w, motion.on);
    jam_w(&w, motion.event, motion.count * sizeof motion.event[0]);
    jam_w8(&w, P_COUNT);
    jam_w8(&w, (TRAP_FM6_TEST ? JAM_SPACK : 0u) | sizeof(step_t));
    for (k = 0; k < NTRK; k++) {
        const track_t *t = &trk[k];
        jam_w8(&w, t->eng_req);
        jam_wb(&w, t->p, sizeof t->p);
        for (i = n = 0; i < NSTEP; i++)
            n += (uint32_t)jam_step_used(&t->step[i]);
        jam_w8(&w, n);
        for (i = 0; i < NSTEP; i++)
            if (jam_step_used(&t->step[i])) {
                jam_w8(&w, i);
                jam_wb(&w, &t->step[i], sizeof(step_t));
            }
    }
    for (k = n = 0; k < NTRK * 16u; k++)
        n += kit[k / 16u][k % 16u].n != 0u;
    jam_w8(&w, n);
    for (k = 0; k < NTRK * 16u; k++) {
        const kit_key_t *kk = &kit[k / 16u][k % 16u];
        if (!kk->n)
            continue;
        jam_w8(&w, k);
        jam_w8(&w, kk->n);
        jam_w(&w, kk->id, kk->n);
        jam_w(&w, kk->v, kk->n * sizeof kk->v[0]);
    }
    if (!w.bad) {
        jam_w16(&w, sizeof acid);
        jam_wb(&w, acid, sizeof acid);
    }
    if (!w.bad) {
        jam_w16(&w, sizeof lastc + sizeof lastn);
        jam_w(&w, lastc, sizeof lastc);
        jam_w(&w, lastn, sizeof lastn);
    }
    if (!w.bad) {
        jam_w16(&w, sizeof chord_cfg);
        jam_w(&w, chord_cfg, sizeof chord_cfg);
    }
    if (!w.bad) {
        jam_w16(&w,sizeof tape_cfg);
        jam_w(&w,tape_cfg,sizeof tape_cfg);
    }
    if(!w.bad) {
        int16_t ph[6];ph[0]=ph_time;ph[1]=ph_scene;memcpy(ph+2,ph_masks,sizeof ph_masks);
        jam_w16(&w,sizeof ph);jam_w(&w,ph,sizeof ph);
    }
    if(!w.bad) {
        gen_store_t gs;memset(&gs,0,sizeof gs);gs.version=1;
        for(k=0;k<NTRK;k++){
            gs.var[k]=(uint8_t)gen_var[k];gs.live[k]=(uint8_t)gen_live[k];gs.fresh[k]=gen_fresh[k];
            gs.recipe[k]=gen_recipe[k];for(i=0;i<3u;i++)gs.eu[k][i]=(uint8_t)eu_cfg[k][i];
        }
        jam_w16(&w,sizeof gs);jam_wb(&w,&gs,sizeof gs);
    }
    if (!w.bad) {
        jam_w16(&w, sizeof smp_sl);
        jam_wb(&w, smp_sl, sizeof smp_sl);
    }
#if TRAP_FM6_TEST
    if (!w.bad) {
        uint32_t mask = 0, cnt = 0;
        for (k = 0; k < NTRK; k++)
            if (trk[k].eng_req == ENGI_FM6) {
                mask |= 1u << k;
                cnt++;
            }
        if (w.n + 2u + 1u + cnt * TF6_JAM_TRK > w.cap)
            return 0;
        jam_w16(&w, 1u + cnt * TF6_JAM_TRK);
        jam_w8(&w, mask);
        for (k = 0; k < NTRK; k++) {
            uint8_t b[155];
            if (!(mask & (1u << k)))
                continue;
            for (i = 0; i < 155u; i++)
                b[i] = (uint8_t)clamp(tf6_edit[k][i], 0, 255);
            jam_w(&w, b, 155);
            for (i = 155u; i < 158u; i++)
                jam_w16(&w, (uint16_t)tf6_edit[k][i]);
        }
    }
#endif
    return w.bad?0:w.n;
}

static int jam_apply(uint8_t *in, uint32_t len)
{
    jam_io_t r = {in, 0, len, 0};
    uint32_t magic = 0, sel, rel, fade, ng, sz, np, ssz, k, i, n;
    xf_leave(XF_ALL);
    static const uint8_t JAM_G[] = {G_BPM, G_SWING, G_DTIME, G_DFDBK, G_DCOLOR, G_DMIX, G_RSIZE, G_RDAMP, G_RTYPE,
                                    G_SYNC, G_CRATE, G_CDEPTH, G_INFO, G_AMP, G_F1RATE, G_F1WAVE, G_F1DEST, G_F1AMT,
                                    G_F2RATE, G_F2WAVE, G_F2DEST, G_F2AMT, G_F3RATE, G_F3WAVE, G_F3DEST, G_F3AMT, G_PAN};

    int16_t g[G_COUNT];
    jam_r(&r, &magic, 4);
    if (magic != JAM_MAGIC && !(TRAP_FM6_TEST && magic == JAM_MAGIC6))
        return 0;
    r.pk = TRAP_FM6_TEST && magic == JAM_MAGIC;
    sel = jam_r8(&r);
    rel = jam_r8(&r);
    fade = jam_r8(&r);
    ng = jam_r8(&r);
    memcpy(g, song.g, sizeof g);
    for (i = 0; i < ng; i++) {
        int16_t v = 0;
        jam_r(&r, &v, 2);
        if (i < G_COUNT)
            g[i] = v;
    }
    for (i = 0; i < NELEM(JAM_G); i++)
        song.g[JAM_G[i]] = (int16_t)clamp(g[JAM_G[i]], GP[JAM_G[i]].min, GP[JAM_G[i]].max);
    sz = jam_r16(&r);
    if (sz == sizeof pm_mac) {
        jam_rb(&r, pm_mac, sz);
        for (i = 0; i < PM_NM; i++)
            if (pm_mac[i].n > PM_N)
                pm_mac[i].n = 0;
    } else {
        jam_rb(&r, 0, sz);
    }
    pm_rel = (uint8_t)(rel > 16u ? 16u : rel);
    pm_fade = (uint8_t)(fade > 4u ? 0u : fade);
    sz = jam_r16(&r);
    if (r.pk) {
        jam_rb(&r, sz == sizeof fxl ? (void *)&fxl : 0, sz);
    } else if (sz == 2u + 32u + 16u * 11u || sz == 2u + 32u + 16u * 15u) {
        uint8_t ob[2u + 32u + 16u * 15u];
        uint32_t ng = (sz - 34u) / 16u;
        uint16_t t16;
        memset(&fxl, 0, sizeof fxl);
        fxl.len = 16;
        jam_r(&r, ob, sz);
        memcpy(&t16, ob, 2);
        fxl.trig = t16;
        memcpy(fxl.lk, ob + 2, 32);
        for (i = 0; i < 16u; i++)
            memcpy(fxl.v[i], ob + 34u + ng * i, ng);
    } else if (sz == 8u + 2u + 2u * FXN + FXN * 15u + 6u) {
        static uint8_t ob[8u + 2u + 2u * FXN + FXN * 15u + 6u];
        jam_r(&r, ob, sz);
        memset(&fxl, 0, sizeof fxl);
        memcpy(&fxl.trig, ob, 8);
        memcpy(&fxl.len, ob + 8, 2);
        memcpy(fxl.lk, ob + 10, 2u * FXN);
        for (i = 0; i < FXN; i++)
            memcpy(fxl.v[i], ob + 10u + 2u * FXN + 15u * i, 15);
    } else {
        jam_r(&r, sz == sizeof fxl ? (void *)&fxl : 0, sz);
    }
    n = jam_r8(&r);
    motion.on = (uint8_t)jam_r8(&r);
    motion.count = 0;
    for (i = 0; i < n; i++) {
        motion_event_t e;
        if (!jam_r(&r, &e, sizeof e))
            break;
        if ((e.place >> 6) < NTRK && motion.count < MOTION_MAX)
            motion.event[motion.count++] = e;
    }
    np = jam_r8(&r);
    ssz = jam_r8(&r);
    for (k = 0; k < NTRK && !r.bad; k++) {
        track_t *t = &trk[k];
        int16_t in[128], def[P_COUNT], out[P_COUNT];
        uint32_t eng = jam_r8(&r);
        if (r.pk) {
            if (np > 128u)
                return 0;
            jam_rb(&r, in, np * 2u);
        } else {
            for (i = 0; i < np && i < 128u; i++)
                in[i] = (int16_t)jam_r16(&r);
        }
        for (i = 0; i < P_COUNT; i++)
            def[i] = t->p[i];
        params_by_count(out, in, np > P_COUNT ? P_COUNT : np, def);
        fm1_irq_off();
        t->eng_req = (uint8_t)(eng < NENGINES ? eng : t->eng_req);
        t->p[P_E7] = out[P_E7];
        for (i = 0; i < P_COUNT; i++)
            t->p[i] = (int16_t)param_fit(track_desc(t, i), out[i]);
        fm1_irq_on();
        for (i = 0; i < NSTEP; i++)
            step_clear(&t->step[i]);
        n = jam_r8(&r);
        for (i = 0; i < n; i++) {
            uint32_t at = jam_r8(&r);
            step_t s;
            uint8_t raw[32];
            memset(&s, 0, sizeof s);
            if (r.pk) {
                uint32_t sn = ssz & ~JAM_SPACK;
                if (!(ssz & JAM_SPACK) || sn < sizeof s - 1u || sn > 16u)
                    return 0;
                memset(raw, 0, sizeof raw);
                jam_rb(&r, raw, sn);
                memcpy(&s, raw, sn < sizeof s ? sn : sizeof s);
                if (at < NSTEP && !r.bad)
                    t->step[at] = s;
                continue;
            }

            jam_r(&r, ssz <= sizeof raw ? (void *)raw : 0, ssz);
            if (ssz <= sizeof raw && ssz >= sizeof s - 1u)
                memcpy(&s, raw, ssz < sizeof s ? ssz : sizeof s);
            if (at < NSTEP && ssz >= sizeof s - 1u && ssz <= sizeof raw)
                t->step[at] = s;
        }
    }
    memset(kit, 0, sizeof kit);
    n = jam_r8(&r);
    for (i = 0; i < n && !r.bad; i++) {
        uint32_t at = jam_r8(&r), c = jam_r8(&r);
        kit_key_t kk;
        memset(&kk, 0, sizeof kk);
        if (c > KIT_N)
            break;
        jam_r(&r, kk.id, c);
        jam_r(&r, kk.v, c * sizeof kk.v[0]);
        kk.n = (uint8_t)c;
        if (at < NTRK * 16u && !r.bad)
            kit[at / 16u][at % 16u] = kk;
    }
    for (k = 0; k < NTRK; k++)
        acid_reset(&acid[k]);
    if (!r.bad && r.n + 2u <= r.cap) {
        sz = jam_r16(&r);
        jam_rb(&r, sz == sizeof acid ? (void *)acid : 0, sz);
    }
    memset(lastc, 0, sizeof lastc);
    if (!r.bad && r.n + 2u <= r.cap) {
        sz = jam_r16(&r);
        if (sz == sizeof lastc + sizeof lastn) {
            jam_r(&r, lastc, sizeof lastc);
            jam_r(&r, lastn, sizeof lastn);
            for (k = 0; k < NTRK; k++)
                lastc[k] = (uint8_t)(lastc[k] > 4u ? 0u : lastc[k]);
        } else {
            jam_r(&r, 0, sz);
        }
    }
    memset(chord_cfg, 0, sizeof chord_cfg);
    if (!r.bad && r.n + 2u <= r.cap) {
        sz = jam_r16(&r);
        jam_r(&r, sz == sizeof chord_cfg ? (void *)chord_cfg : 0, sz);
        for (k = 0; k < NTRK; k++)
            for (i = 0; i < 4u; i++)
                chord_cfg[k][i] = (int16_t)param_fit(&CG_DESC[i], chord_cfg[k][i]);
        for (k = 0; k < NTRK; k++)
            chord_cfg[k][CG_FOLLOW] = 0;
    }
    memcpy(tape_cfg,TAPE_DEF,sizeof tape_cfg);
    if(!r.bad && r.n+2u<=r.cap) {
        sz=jam_r16(&r);
        jam_r(&r,sz==sizeof tape_cfg?(void *)tape_cfg:0,sz);
        for(i=0;i<TF_COUNT;i++) tape_cfg[i]=(int16_t)param_fit(&TF_D[i],tape_cfg[i]);
    }
    ph_time=1;ph_scene=0;
    { static const int16_t defaults[4]={36,47,63,32};memcpy(ph_masks,defaults,sizeof ph_masks); }
    if(!r.bad && r.n+2u<=r.cap) {
        int16_t ph[6]={1,0,36,47,63,32};sz=jam_r16(&r);
        jam_r(&r,sz==sizeof ph?(void *)ph:0,sz);
        ph_time=(int16_t)clamp(ph[0],0,3);ph_scene=(int16_t)clamp(ph[1],0,3);
        for(i=0;i<4u;i++)ph_masks[i]=(int16_t)clamp(ph[i+2u],0,127);
    }
    memset(gen_recipe,0,sizeof gen_recipe);gen_undo_ready=0;
    for(k=0;k<NTRK;k++){gen_var[k]=1;gen_live[k]=1;gen_fresh[k]=0;eu_cfg[k][0]=16;eu_cfg[k][1]=4;eu_cfg[k][2]=0;}
    if(!r.bad && r.n+2u<=r.cap){
        gen_store_t gs;memset(&gs,0,sizeof gs);sz=jam_r16(&r);
        jam_rb(&r,sz==sizeof gs?(void *)&gs:0,sz);
        if(!r.bad && sz==sizeof gs && gs.version==1u)for(k=0;k<NTRK;k++){
            gen_recipe_t *g=&gs.recipe[k];
            gen_var[k]=(int16_t)clamp(gs.var[k],1,20);gen_live[k]=gs.live[k]!=0;gen_fresh[k]=gs.fresh[k]!=0;
            eu_cfg[k][0]=(int16_t)clamp(gs.eu[k][0],1,64);eu_cfg[k][1]=(int16_t)clamp(gs.eu[k][1],0,eu_cfg[k][0]);eu_cfg[k][2]=(int16_t)clamp(gs.eu[k][2],0,63);

            if(g->active==1u && g->style<NELEM(N_CSTYLE) && g->rhythm<4u && g->variation<20u && g->oct>=-2 && g->oct<=2 &&
               g->root<12u && g->scale<NELEM(SCALE_MASK) && g->chrd<=CH_LAST && g->voic<=VC_BASS && g->vmode<=V_UNISON && g->len>=1u && g->len<=NSTEP &&
               (g->reserved==0u || g->reserved==GEN_V2))
                gen_recipe[k]=*g;
        }
    }
    memset(smp_sl, 0, sizeof smp_sl);
    memset((void *)smp_sl_last, 0, sizeof smp_sl_last);
    if (!r.bad && r.n + 2u <= r.cap) {
        sz = jam_r16(&r);
        jam_rb(&r, sz == sizeof smp_sl ? (void *)smp_sl : 0, sz);
        for (k = 0; k < NPART; k++) {
            smp_sl_t *s = &smp_sl[k];
            uint32_t ok = s->n <= SMP_SLN;
            for (i = 0; ok && s->n && i < s->n; i++)
                ok = s->pos[i] < s->pos[i + 1u];
            if (!ok || r.bad || sz != sizeof smp_sl)
                s->n = 0;
        }
    }
#if TRAP_FM6_TEST
    sz=jam_r16(&r);
    if(r.bad || r.n+sz>r.cap) return 0;
    if(!r.pk && sz==sizeof tf6_edit) {
        fm1_irq_off();
        jam_r(&r,tf6_edit,sizeof tf6_edit);
        for(k=0;k<NTRK;k++) { tf6_ready[k]=1; tf6[k].valid=0; }
        fm1_irq_on();
    } else {
        uint32_t mask, cnt=0;
        if(sz<1u) return 0;
        mask=r.p[r.n];
        for(k=0;k<NTRK;k++) cnt+=(mask>>k)&1u;
        if((mask>>NTRK) || sz!=1u+cnt*TF6_JAM_TRK) return 0;
        r.n++;
        fm1_irq_off();
        for(k=0;k<NTRK;k++) {
            tf6[k].valid=0;
            if(!(mask&(1u<<k))) { tf6_ready[k]=0; continue; }
            for(i=0;i<155u;i++) tf6_edit[k][i]=(int16_t)r.p[r.n++];
            for(i=155u;i<158u;i++) { memcpy(&tf6_edit[k][i],r.p+r.n,2); r.n+=2u; }
            tf6_ready[k]=1;
        }
        fm1_irq_on();
    }
#endif
    for (k = 0; k < NTRK; k++) {
        acid[k].scale = acid[k].root = 0;
        for (i = 0; i < ACID_N; i++) {
            acid[k].st[i].flags &= AF_SLIDE;
            acid[k].st[i].stime = acid[k].st[i].stime ? acid[k].st[i].stime : 40u;
        }
    }
    for (k = 0; k < NTRK; k++)
        motion_rebase(&trk[k]);
    song.sel = (uint8_t)(sel < NTRK ? sel : 0u);
    return 1;
}

static void jam_boot(void)
{
#if FELUCCA_FLASH
    uint32_t g0, len;
    int n0, n1;
    if (!flash_ok)
        return;
    n0 = st_load(OBJ_AUTOSAVE, jam_img, ST_PAYLOAD_MAX);
    if (n0 < 8)
        return;
    memcpy(&g0, jam_img, 4);
    len = (uint32_t)n0 - 4u;
    memcpy(jam_buf, jam_img + 4, len);
    if (len == JAM_PART) {
        uint32_t g1;
        n1 = st_load(OBJ_JAM2, jam_img, ST_PAYLOAD_MAX);
        if (n1 >= 4) {
            memcpy(&g1, jam_img, 4);
            if (g1 != g0)
                return;
            memcpy(jam_buf + len, jam_img + 4, (uint32_t)n1 - 4u);
            len += (uint32_t)n1 - 4u;
        }
    }
    jam_gen = g0;
    memcpy(jam_old, jam_buf, len);
    jam_oldn = len;
    if (jam_apply(jam_buf, len))
        ui_message("LAST JAM");
#endif
}

#ifndef JAM_REST_MS
#define JAM_REST_MS 3000u
#endif
static void jam_poll(void)
{
#if FELUCCA_FLASH
    uint32_t o;
    if (!flash_ok)
        return;
    if (!autosave_quiet() || (int32_t)(fm1_ms - scrn.idle) < (int32_t)JAM_REST_MS) {
        jam_q0 = 0;
        return;
    }
    if (!jam_q0)
        jam_q0 = fm1_ms | 1u;
    if ((int32_t)(fm1_ms - jam_q0) < 1000)
        return;
    if (!jam_pend) {
        if (jam_t && (int32_t)(fm1_ms - jam_t) < 1000)
            return;
        jam_t = fm1_ms | 1u;
        xf_save(1);
        jam_n = jam_make(jam_buf);
        xf_save(0);
        if(!jam_n){ui_message("LAST JAM FULL");return;}
        if (jam_n == jam_oldn && !memcmp(jam_buf, jam_old, jam_n))
            return;
        jam_gen++;
        jam_pend = jam_n > JAM_PART ? 3u : 1u;
    }
    o = (jam_pend & 2u) ? 1u : 0u;
    memcpy(jam_img, &jam_gen, 4);
    {
        uint32_t off = o * JAM_PART, part = jam_n - off > JAM_PART ? JAM_PART : jam_n - off;
        memcpy(jam_img + 4, jam_buf + off, part);
        if (st_save(o ? OBJ_JAM2 : OBJ_AUTOSAVE, jam_img, 4u + part) != 0) {
            jam_pend = 0;
            return;
        }
    }
    jam_pend &= (uint8_t)~(1u << o);
    if (!jam_pend) {
        memcpy(jam_old, jam_buf, jam_n);
        jam_oldn = jam_n;
    }
#endif
}
