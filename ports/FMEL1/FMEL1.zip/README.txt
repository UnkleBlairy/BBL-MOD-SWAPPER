FMEL-1 1.3 for the BBL Mod Swapper

Original by AntonioAltea: https://github.com/AntonioAltea/fmel-1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: FMEL1-source.zip on the ports page.
