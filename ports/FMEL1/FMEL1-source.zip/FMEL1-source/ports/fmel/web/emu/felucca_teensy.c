/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: FMEL-1 1.3 (https://github.com/AntonioAltea/fmel-1) on the Teensy 4.1: its own browser build (firmware/src/mel.c) inside ports/common's shell */
#include "../../../common/shell_pre.h"
#include <stdlib.h>
#include <time.h>
#ifndef CLOCK_MONOTONIC
#define CLOCK_MONOTONIC 1
static int clock_gettime(int c, struct timespec *t) { (void)c; t->tv_sec = 0; t->tv_nsec = 0; return 0; }
#endif
#define getenv(n) ((char *)0)
#define memset mel_memset
#define memcpy mel_memcpy
#define memcmp mel_memcmp
#define web_boot o_web_boot
#define web_out_l o_web_out_l
#define web_out_r o_web_out_r
#define web_render o_web_render
#define web_buttons o_web_buttons
#define web_keys o_web_keys
#define web_enc o_web_enc
#define web_master o_web_master
#define web_nor_erase o_web_nor_erase
#define web_ms o_web_ms
#define web_frame o_web_frame
#include "../../firmware/src/mel.c"
#undef __attribute__
#undef EXPORT
#undef memset
#undef memcpy
#undef memcmp
#undef memmove
#undef web_boot
#undef web_out_l
#undef web_out_r
#undef web_render
#undef web_buttons
#undef web_keys
#undef web_enc
#undef web_master
#undef web_nor_erase
#undef web_ms
#undef web_frame
#define SH_FLOAT
#define SH_OUT_L o_web_out_l
#define SH_OUT_R o_web_out_r
#define SH_RENDERF(n) o_web_render(n)
#define SH_ADC(m) o_web_master(m)
static void SH_BOOT(void) { o_web_boot(); }
static void SH_FRAME(uint32_t ms)
{
    const uint16_t *p = (const uint16_t *)web_screen();
    uint32_t i;
    (void)ms;
    for (i = 0; i < 57600u; i++) if (shl_fb[i] != sh_be16(p[i])) sh_put(i, sh_be16(p[i]));
}
static uint32_t sh_raw_m;
#define SH_BTN(i, d) web_button((i), (d))
#define SH_ENC(e, n) o_web_enc((e), (n))
static uint32_t sh_keys_m;
#define SH_KEY(k, d) (sh_keys_m = (sh_keys_m & ~(1u << (k))) | (uint32_t)(d) << (k), o_web_keys(sh_keys_m))
static uint32_t sh_l(uint32_t i) { return web_leds(i >> 5) >> (i & 31u) & 1u ? 2 : 0; }
#define SH_KEY_LED(k) sh_l(14u + (k))
#define SH_BTN_LED(i) sh_l(i)
#include "../../../common/shell_post.h"
