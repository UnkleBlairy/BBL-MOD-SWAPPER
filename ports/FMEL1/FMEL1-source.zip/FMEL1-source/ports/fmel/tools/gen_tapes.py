#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Build MEL's tapes (firmware/src/mel.c) from WAV files into a C header.

  tools/gen_tapes.py OUT.h [--src tapes/wav] [--sets MkII_Flute,8_Choir,...] [--budget BYTES] [--step 3] [--rate 22050]

The tapes are the Taijiguy Mellotron M400S samples (one WAV per key, G2..F5, ~7 s, named like
"A#3.wav"), in tapes/wav/<SET>/: they are not in this tree (free to use, not to redistribute in
commercial software). tapes/README.md says where they come from.

Per set, one root every STEP semitones (the keys between play the nearest root, at most STEP/2
semitones off), each:
  - from 44.1 kHz down to RATE >> SHIFT (the tapes hold almost nothing above 5 kHz: 11025 Hz, half of RATE, keeps
    it all);
  - from its onset (the head meeting the tape stays in), as long as the budget allows;
  - with a loop over the end, crossfaded in the samples (equal power), so a note can sound for
    ever (MEL's "inf" tape) as well as for the 8 s of a real tape;
  - block ADPCM, 4 bit, with the decoder's state every CK samples (MEL_CK): a note can start
    anywhere on its tape (a key pressed again before its tape is back) and the loop jumps exactly.
The flute (IMA) is release 1.0's, to the byte: IMA ADPCM, its 12 tapes of 1.72 s, its levels evened half way, its loops
as they were (blind test 2026-11-04: its 8-bit, fewer-tape remake of 1.1 had a whoosh on its low keys, and nothing else
sounded like it). The sax (PCM8) is 8-bit PCM packed without loss (pack8).
The levels of a set are evened out (in dB) between its roots; then every set is brought to the same
loudness (RMS of its sustain), so a change of tape is not a change of level.
A set that dies away by itself (DECAYS: the vibraphone) has its decay measured per root (dB/s, after its peak) and
flattened out of the samples, so its loop is level; the zone carries the decay and the firmware applies it as the
tape runs: a held note dies as the real one does, and a note restarted mid-tape starts as quiet as the tape is.
The piano (tools/get_piano.sh: SLOOP's four keys of a Steinway B from VCSL, CC0) is not a Mellotron tape, and is
played clean: FIXED_LEN of each key at 22050 Hz, outside the budget, its decay measured and put back by the firmware
as the vibraphone's (DECAYS), struck anew at every press, an octave up from its keys (OCTAVE). (SLOOP_PIANO, empty now, still makes
SLOOP's LOFI KEYS: its kind "piano", levelled and looped, played by mel.c as SLOOP's SAMPLE engine, kind 1.)
"""
import argparse
import re
import wave
from pathlib import Path

import numpy as np

NAMES = {"MkII_Violins": "VIOLINS", "MkII_Flute": "FLUTE", "8_Choir": "CHOIR", "Cello": "CELLO", "Vibes": "VIBES",
         "Woodwind_2": "WOODWIND", "Piano": "PIANO", "Tenor_Sax": "SAX"}
SETS = ["MkII_Flute", "8_Choir", "Cello", "Vibes", "Tenor_Sax", "Piano"]  # A B C (the M400's three tracks), D, E, F
DECAYS = {"Vibes": 0.6, "Piano": 0}                           # sets that die away by themselves, and their share of the flash:
                                                   # their decay is taken out of the samples (a flat loop) and
                                                   # measured; the firmware puts it back as the tape runs
STEP = {"Cello": 4, "Vibes": 8, "Tenor_Sax": 4}   # sets with their own semitones between roots (else --step):
                                                   # the voices keep theirs, the plainer sounds bear more pitching
SLOOP_PIANO = set()                                # sets made as SLOOP makes its piano (sloop_piano): every file a
                                                   # root, outside the budget, played by mel.c as SLOOP's SAMPLE engine
FIXED_LEN = {"Piano": 1.0, "MkII_Flute": 1.72}     # sets outside the budget, this long (s) a root
IMA = {"MkII_Flute"}                               # sets as release 1.0 made them (kind 3; the top of this file says why)
PCM8 = {"Tenor_Sax"}                               # sets stored as 8-bit PCM (kind 2, packed: pack8), near full scale,
                                                   # their level in the zone's gain: where block ADPCM's grain is heard
                                                   # (blind tests, 2026-10-30: the sax; the choir, the cello, the
                                                   # vibraphone and the piano as clean in blocks)
DARKEN = {"Piano"}                                 # sets that darken as they ring (their zones' brightness floor: lpred)
SHIFT = {"Piano": 0}                               # sets at RATE >> SHIFT (the firmware steps them so); the rest at
SHIFT_ELSE = 1                                     # RATE >> 1: the tapes at 11025 Hz, the piano at 22050
UPCUT = set()                                      # (none now) sets whose notes well above their tape's root play through its band's
                                                   # low-pass (mel.c: the hiss and breath sped up above it; heard on the
                                                   # flute over F5, blind test 2026-10-30)
STRUCK = {"Piano"}                                 # sets a key strikes anew: its tape from the start at every press
                                                   # (a tape's key pressed again goes on where its tape is: the
                                                   # vibraphone as quiet as it has died away to, a piano never)
PLAY = {"Piano": (100, 0, 0, 31)}                  # a set's own PLAY to start from (TONE PITCH ATTACK RELEASE; else
PLAY_ELSE = (72, 0, 4, 18)                         # the tapes'): the piano TONE open, ATK 0 (its strike as recorded),
                                                   # REL 31 (the dampers: ~0.1 s)
# SLOOP's LOFI KEYS (gen_samples.py EXTRA_PRESETS: SAMPLE BITS 45, CUT 78, DRV 30; ENV 0 108 0 60; LFO to pitch 1 at
# RATE 38, a sine), as mel.c's constants for a kind 1 zone
PNO_BITS = 45 // 10                                # bits taken off (eng_sample.c: sh = BITS / 10)
PNO_DRV = 30 * 150                                 # s + (s >> 2) * PNO_DRV >> 11, into the tanh
PNO_CUT = 4000 + ((78 << 8) * 28767 >> 15)         # its one-pole, Q15 (CUT 78: ~7.5 kHz)
PNO_GAIN = 25                                      # its level, Q5: its first half second as loud as a tape's chord
OCTAVE = {"Piano": 1}                              # sets that sound octaves up from their keys (their zones' roots
                                                   # and ranges moved down: a key plays the sample of the key above)
TARGET_RMS = 0.13                                # every set's sustain, full scale 1
SLOOP_FS = 22050                                 # SLOOP's stored rate (gen_samples.py TR)
NOTE = {"C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5, "F#": 6, "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11}
CK = 256                                         # samples between decoder states
SRC_RATE = 44100

IMA_STEP = [
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97,
    107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796,
    876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428,
    4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350,
    22385, 24623, 27086, 29794, 32767]
IMA_IDX = [-1, -1, -1, -1, 2, 4, 6, 8]


def midi_of(name):
    m = re.fullmatch(r"([A-G]#?)(-?\d)", name)
    return 12 * (int(m[2]) + 1) + NOTE[m[1]] if m else None


def read_wav(path):
    with wave.open(str(path)) as w:
        if w.getsampwidth() != 2 or w.getframerate() != SRC_RATE:
            raise SystemExit(f"{path}: want 16-bit {SRC_RATE} Hz")
        x = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2").astype(np.float64) / 32768
        return x[::w.getnchannels()]


def lowpass(fc, taps=255):
    """windowed sinc, fc in cycles per sample"""
    n = np.arange(taps) - (taps - 1) / 2
    h = 2 * fc * np.sinc(2 * fc * n) * np.blackman(taps)
    return h / h.sum()


def resample(x, rate, sh=0):
    if SRC_RATE % rate:
        raise SystemExit(f"--rate must divide {SRC_RATE}")
    d = SRC_RATE // rate << sh
    return np.convolve(x, lowpass(0.45 / d), mode="same")[::d] if d > 1 else x


def onset(x, rel=0.08):
    a = np.abs(x)
    env = np.convolve(a, np.ones(32) / 32, mode="same")
    return int(np.argmax(env > rel * env.max()))


def rms(x):
    return float(np.sqrt(np.mean(x * x)) + 1e-12)


def level_tail(x, rate):
    """a sustained tape's loop part evened out: from where its loop may start, its loudness (50 ms windows, smoothed
    over 0.2 s) brought to its mean there, eased in over 0.1 s; the attack untouched. (A slow attack, the flute's
    A#2 still swelling at 1.4 s, otherwise jumps back down at every turn of the loop)"""
    n = len(x)
    xf = int(0.35 * rate)
    t0 = max(xf + CK, int(n * 0.3)) - xf
    w = max(1, int(0.05 * rate))
    env = np.sqrt(np.convolve(x * x, np.ones(w) / w, mode="same"))
    sm = max(1, int(0.2 * rate))
    env = np.convolve(env, np.ones(sm) / sm, mode="same") + 1e-9
    ref = env[t0:n - sm // 2].mean()
    g = np.ones(n)
    g[t0:] = ref / env[t0:]
    g[n - sm // 2:] = g[n - sm // 2 - 1]                          # (the smoothing's edge: the last value held)
    ease = min(n - t0, int(0.1 * rate))
    g[t0:t0 + ease] = 1 + (g[t0:t0 + ease] - 1) * np.linspace(0, 1, ease)
    return x * g


def loop(x, rate, grid=CK, even=True):
    """x with a crossfaded loop over its end -> (samples, loop start); the loop is [ls, len). ADPCM (grid CK, its
    state a checkpoint): a 0.35 s fade from the likest piece on the grid. 8-bit PCM (grid 1): a shorter fade (0.12 s)
    from the sample whose piece is likest, in phase: a long fade of a tape with wow drifts out of phase and dips once
    a loop. Either fade keeps the level whatever the two pieces' likeness (an equal-power fade of alike pieces swells);
    not even: a plain equal-power fade (release 1.0's)"""
    n = len(x)
    xf = int((0.35 if grid > 1 else 0.12) * rate)
    target = max(int(0.35 * rate) + CK, int(n * 0.3))
    a = x[n - xf:]
    na = np.linalg.norm(a) + 1e-12
    def likeness(cand):
        b = x[cand - xf:cand]
        return float(np.dot(a, b) / (na * (np.linalg.norm(b) + 1e-12)))
    hi = int(n * (0.6 if grid > 1 else 0.75)) - xf
    if grid > 1:
        cands = range(target - target % grid, hi, grid)
        ls = max(cands, key=likeness) if len(cands) else target - target % grid   # (a short tape: where it must)
    else:                                        # (every sample: the windows' dot products at once, then their norms)
        cs = np.arange(target, max(target + 1, hi))
        dots = np.correlate(x[target - xf:hi], a, mode="valid")[:len(cs)]
        e2 = np.concatenate([[0.0], np.cumsum(x * x)])
        norms = np.sqrt(e2[cs] - e2[cs - xf]) + 1e-12
        ls = int(cs[np.argmax(dots / (na * norms[:len(dots)]))])
    c = max(0.0, likeness(ls))
    t = np.linspace(0, np.pi / 2, xf)
    co, si = np.cos(t), np.sin(t)
    y = x.copy()
    y[n - xf:] = (a * co + x[ls - xf:ls] * si) / (np.sqrt(1 + 2 * c * co * si) if even else 1)   # at the end it has become what precedes ls
    return y, ls






def ima_encode(s):
    """int16 samples -> (bytes, [(pred, idx) at every CK-th sample]); low nibble first"""
    pred, idx, out, cks, cur = 0, 0, bytearray(), [], 0
    for i, v in enumerate(s):
        if i % CK == 0:
            cks.append((pred, idx))
        step = IMA_STEP[idx]
        d = int(v) - pred
        code = 8 if d < 0 else 0
        d = abs(d)
        vd = step >> 3
        if d >= step:
            code |= 4; d -= step; vd += step
        if d >= step >> 1:
            code |= 2; d -= step >> 1; vd += step >> 1
        if d >= step >> 2:
            code |= 1; vd += step >> 2
        pred = max(-32768, min(32767, pred - vd if code & 8 else pred + vd))
        idx = max(0, min(88, idx + IMA_IDX[code & 7]))
        if i & 1:
            out.append(cur | code << 4)
        else:
            cur = code
    if len(s) & 1:
        out.append(cur)
    return bytes(out), cks






# Block ADPCM (genkigenki's Erik37 erk_codec.h, MPL-2.0: the format): 32 samples in 17 bytes, a header byte (filter
# << 4 | shift) and 16 bytes of signed 4-bit residuals, low nibble first; s = clamp(((c1 s1 + c2 s2 + 32) >> 6) + q 2^sh).
# On the tapes 6-11 dB cleaner than IMA for 6 % more bytes.
BLK = 32
BLKB = 17
BLK_FILT = np.array([(0, 0), (60, 0), (122, -60), (115, -52), (126, -63), (124, -61), (118, -58), (108, -52),
                     (98, -55), (88, -50), (76, -46), (60, -40), (40, -36), (16, -32), (30, 0), (-30, -24)])


def blk_encode(s):
    """int16 samples -> (bytes, [(s1, s2) at every CK-th sample]): every block's filter and shift found by trying
    them all at once (each a lane of numpy arrays), the one with the least squared error kept"""
    s = np.concatenate([np.asarray(s, dtype=np.int64), np.zeros(-len(s) % BLK, dtype=np.int64)])
    combos = [(f, sh) for f in range(len(BLK_FILT)) for sh in range(13)]
    c1 = np.array([BLK_FILT[f][0] for f, _ in combos])
    c2 = np.array([BLK_FILT[f][1] for f, _ in combos])
    q = np.array([1 << sh for _, sh in combos])
    hdr = np.array([f << 4 | sh for f, sh in combos])
    out, cks, s1, s2 = bytearray(), [], 0, 0
    for b in range(0, len(s), BLK):
        if b % CK == 0:
            cks.append((s1, s2))
        a1 = np.full(len(combos), s1)
        a2 = np.full(len(combos), s2)
        err = np.zeros(len(combos))
        codes = np.zeros((BLK, len(combos)), dtype=np.int64)
        for i in range(BLK):
            p = (c1 * a1 + c2 * a2 + 32) >> 6
            r = np.clip(np.floor((s[b + i] - p) / q + 0.5), -8, 7).astype(np.int64)
            y = np.clip(p + r * q, -32768, 32767)
            err += (s[b + i] - y) ** 2
            codes[i] = r & 15
            a2, a1 = a1, y
        k = int(np.argmin(err))
        out.append(int(hdr[k]))
        for i in range(0, BLK, 2):
            out.append(int(codes[i, k]) | int(codes[i + 1, k]) << 4)
        s1, s2 = int(a1[k]), int(a2[k])
    return bytes(out), cks


# 8-bit PCM packed without loss: 16 samples a block, a header byte (filter << 4 | width), then each sample's residual
# from BLK_FILT's prediction, exact, in width bits (2 x width bytes). Every CK-th sample and the loop start (one more
# entry, last) have their state: the last two samples and the byte of their block.
PK = 16


def pack8(s, ls):
    """int8 samples, loop start -> (bytes, [(s1 | s2 << 8, byte) at every CK-th sample, then at ls])"""
    x = np.asarray(s, dtype=np.int64)
    s1, s2 = np.concatenate([[0], x[:-1]]), np.concatenate([[0, 0], x[:-2]])
    e = np.array([x - ((c1 * s1 + c2 * s2 + 32) >> 6) for c1, c2 in BLK_FILT]).reshape(len(BLK_FILT), -1, PK)
    need = np.maximum(e.max(2), -e.min(2) - 1)
    width = np.ceil(np.log2(need + 1.0)).astype(int) + 1  # (signed)
    best = width.argmin(0)
    out, at = bytearray(), []
    for b in range(len(x) // PK):
        f, w = int(best[b]), int(width[best[b], b])
        at.append(len(out))
        out.append(f << 4 | w)
        acc = sum((int(r) & ((1 << w) - 1)) << (i * w) for i, r in enumerate(e[f, b]))
        out += acc.to_bytes(2 * w, "little")
    out.append(0)                                # (the decoder reads a byte past a residual)
    def state(p):
        return int(s1[p]) & 255 | (int(s2[p]) & 255) << 8, at[p // PK]
    if not np.array_equal(unpack8(out, len(x)), x):
        raise SystemExit("pack8: not what went in")
    return bytes(out), [state(p) for p in range(0, len(x), CK)] + [state(ls)]


def unpack8(d, n):
    """pack8's bytes -> the samples, as mel.c's adpcm_next reads them"""
    y, o, s1, s2 = [], 0, 0, 0
    for p in range(n):
        i, w = p % PK, d[o] & 15
        c1, c2 = BLK_FILT[d[o] >> 4]
        bit = i * w
        u = (d[o + 1 + bit // 8] | d[o + 2 + bit // 8] << 8) >> bit % 8 & ((1 << w) - 1)
        s = ((int(c1) * s1 + int(c2) * s2 + 32) >> 6) + (u - (1 << w) if u >> (w - 1) else u)
        s2, s1 = s1, s
        y.append(s)
        if i == PK - 1:
            o += 1 + 2 * w
    return y


def sloop_onset(x, rel=0.02):
    """sampleio.py onset: the first sample over rel x its peak"""
    thr = rel * max(1e-9, max(map(abs, x)))
    return next((i for i, v in enumerate(x) if abs(v) > thr), 0)


def sloop_resample(x, sr, to):
    """sampleio.py resample: a crude anti-alias (the mean of ratio samples), then linear interpolation"""
    if sr == to:
        return x
    k = max(1, int(round(sr / to)))
    if k == 2:
        x = [(a + b) / 2 for a, b in zip(x, x[1:])] + [x[-1] / 2]
    elif k > 1:
        x = [sum(x[i:i + k]) / k for i in range(len(x))]
    step, out, p, last = sr / to, [], 0.0, len(x) - 1
    while p < last:
        i = int(p)
        f = p - i
        out.append(x[i] * (1 - f) + x[i + 1] * f)
        p += step
    return out


def sloop_piano(path):
    """SLOOP's gen_samples.py cc0_entries, kind "piano": from 16 samples before its onset, 1 s at 22050 Hz; its
    attack as recorded, from 0.3 s levelled (its loudness every 20 ms taken out: the tone the envelope fades), looped
    from the best start in 0.45-0.65 s to its end, crossfaded over 80 ms; to a peak of 30000 -> (int16 list, ls)"""
    x = [float(v) for v in read_wav(path)]
    x = x[max(0, sloop_onset(x) - 16):]
    TR = SLOOP_FS
    x = sloop_resample(x, SRC_RATE, TR)[:int(1.0 * TR)]
    n = len(x)
    ls, le, xf, a0 = int(0.55 * TR), n - 1, int(0.08 * TR), int(0.30 * TR)
    w = int(0.02 * TR)
    env = [max(1e-6, (sum(v * v for v in x[max(0, i - w):i + w]) / (2 * w)) ** 0.5) for i in range(0, n, w)]
    ref = env[a0 // w]
    x = [v * (ref / env[min(len(env) - 1, i // w)] if i >= a0 else 1.0) for i, v in enumerate(x)]
    lo, hi = int(0.45 * TR), int(0.65 * TR)     # best_loop_start: its last xf samples most like the loop end's
    tail = x[le - xf:le:4]
    tn = sum(v * v for v in tail) ** 0.5 + 1e-9
    best, ls = -2.0, (lo + hi) // 2
    for c in range(lo, hi, 2):
        seg = x[c - xf:c:4]
        k = sum(a * b for a, b in zip(seg, tail)) / ((sum(v * v for v in seg) ** 0.5 + 1e-9) * tn)
        if k > best:
            best, ls = k, c
    for i in range(xf):
        a = i / xf
        x[le - xf + i] = x[le - xf + i] * (1 - a) + x[ls - xf + i] * a
    pk = max(1e-9, max(map(abs, x)))
    return [int(v * 30000 / pk) for v in x], ls


def ima_state(s, at):
    """the IMA encoder's (predictor, step index) before sample at"""
    pred, idx = 0, 0
    for v in s[:at]:
        step = IMA_STEP[idx]
        d, code = int(v) - pred, 0
        if d < 0:
            code, d = 8, -d
        vd = step >> 3
        if d >= step:
            code |= 4; d -= step; vd += step
        if d >= step >> 1:
            code |= 2; d -= step >> 1; vd += step >> 1
        if d >= step >> 2:
            code |= 1; vd += step >> 2
        pred = max(-32768, min(32767, pred - vd if code & 8 else pred + vd))
        idx = max(0, min(88, idx + IMA_IDX[code & 7]))
    return pred, idx


def decay_of(x, rate):
    """(peak sample, decay in dB/s after it) of a sound that dies away"""
    w = max(1, int(0.05 * rate))
    env = np.sqrt(np.convolve(x * x, np.ones(w) / w, mode="same")) + 1e-9
    pk = int(np.argmax(env[:int(0.5 * rate)]))
    a, b = pk + int(0.1 * rate), min(len(x), pk + int(3.0 * rate))
    t = np.arange(a, b) / rate
    db = 20 * np.log10(env[a:b])
    slope = -np.polyfit(t, db, 1)[0] if b - a > w * 4 else 6.0
    return pk, float(min(40.0, max(1.0, slope)))


def build(src, budget, step, rate, which):
    sets = [(d, NAMES.get(d, d.upper())) for d in which if (src / d).is_dir()]
    if not sets:
        raise SystemExit(f"no tapes in {src} (see tapes/README.md)")
    plan = []
    for d, name in sets:
        files = {midi_of(p.stem): p for p in (src / d).glob("*.wav") if midi_of(p.stem) is not None}
        lo, hi = min(files), max(files)
        st = STEP.get(d, step)
        roots = [r for r in range(lo + st // 2, hi + 1, st)]
        if roots[-1] + st // 2 < hi:
            roots.append(hi)
        if d in SLOOP_PIANO or (d in FIXED_LEN and d not in IMA):
            roots = sorted(files)
        plan.append((name, files, roots))
    shares = [0.0 if d in SLOOP_PIANO or d in FIXED_LEN else DECAYS.get(d, 1.0) for d, _ in sets]
    bps = [1.0 if d in PCM8 else BLKB / BLK * (1 + 8 / CK) for d, _ in sets]   # bytes a sample (+ the checkpoints)
    per0 = budget / sum(len(r) * w * b for (_, _, r), w, b in zip(plan, shares, bps))   # every tape as long
    out = {"sets": [], "zones": [], "data": bytearray(), "ck": []}
    for (d, _), (name, files, roots), share in zip(sets, plan, shares):
        z0 = len(out["zones"])
        if d in SLOOP_PIANO:                     # SLOOP's piano: its own making, its zones played as SLOOP plays them
            for i, r in enumerate(roots):
                pcm, ls = sloop_piano(files[r])
                data, cks = ima_encode(np.array(pcm, dtype=np.int16))
                lp, li = ima_state(pcm, ls)
                lo = roots[i - 1] + (r - roots[i - 1]) // 2 + 1 if i else 0
                hi = r + (roots[i + 1] - r) // 2 if i + 1 < len(roots) else 127
                up = 12 * OCTAVE.get(d, 0)
                out["zones"].append(dict(off=len(out["data"]), n=len(pcm), ls=ls, ck=len(out["ck"]), root=r - up,
                                         lo=max(0, lo - up) if i else 0, hi=hi - up if i + 1 < len(roots) else 127, sh=SHIFT.get(d, SHIFT_ELSE), kind=1, gain=PNO_GAIN, lpred=lp, lidx=li,
                                         dk=0, d1k=32767, pk=0))
                out["data"] += data
                out["ck"] += cks
            out["sets"].append((name, z0, len(roots), d in STRUCK))
            out.setdefault("play", []).append(PLAY.get(d, PLAY_ELSE))
            out.setdefault("upcut", []).append(d in UPCUT)
            continue
        segs, decs = [], []
        sh = SHIFT.get(d, SHIFT_ELSE)
        zr = SRC_RATE / (SRC_RATE // rate << sh)    # this set's rate, Hz
        per = int(FIXED_LEN[d] * zr) // CK * CK if d in FIXED_LEN else int(per0 * share) // CK * CK
        for r in roots:
            x = resample(read_wav(files[r]), rate, sh)
            o = max(0, onset(x) - int(0.004 * zr))
            seg = x[o:o + per]
            if d in DECAYS:                      # take the decay out: a level loop
                pk, dbs = decay_of(x[o:], zr)
                t = np.maximum(0, np.arange(len(seg)) - pk) / zr
                seg = seg * 10 ** (dbs * t / 20)
                decs.append((pk, dbs))
            else:
                decs.append((0, 0.0))
            segs.append((r, seg))
        lv = np.array([20 * np.log10(rms(s[len(s) // 3:])) for _, s in segs])
        gains = 10 ** ((lv.mean() - lv) / (40 if d in IMA else 20))   # all the way to the set's mean level (half way left
                                                                       # a 1.7 dB step at a root's edge, heard; IMA: half way)
        segs = [(r, s * g) for (r, s), g in zip(segs, gains)]
        level = np.sqrt(np.mean([rms(s[len(s) // 3:]) ** 2 for _, s in segs]))
        segs = [(r, s * TARGET_RMS / level) for r, s in segs]      # every set as loud as the others
        peak = max(np.abs(s).max() for _, s in segs)
        if peak > 0.95:
            raise SystemExit(f"{name}: peaks at {peak:.2f} at the common loudness; lower TARGET_RMS")
        sc8 = 0.99 / peak if d in PCM8 else 1.0      # (8-bit: as loud as it can be stored, its gain brings it back)
        for i, (r, s) in enumerate(segs):
            if d not in DECAYS and d not in IMA: # (a sustained tape: its loop part as loud all through)
                s = level_tail(s, zr)
            s, ls = loop(s, zr, 1 if d in PCM8 else CK, d not in IMA)
            pcm = np.clip(np.round(s * 32767), -32767, 32767).astype(np.int16)
            if d in PCM8:
                p8 = np.clip(np.round(s * sc8 * 127), -127, 127).astype(np.int8)
                data, cks = pack8(p8, ls)
            elif d in IMA:
                data, cks = ima_encode(pcm)
            else:
                data, cks = blk_encode(pcm)
            up = 12 * OCTAVE.get(d, 0)          # (an octave up: its zones' roots and ranges moved down)
            lo = max(0, roots[i - 1] + (r - roots[i - 1]) // 2 + 1 - up) if i else 0
            hi = r + (roots[i + 1] - r) // 2 - up if i + 1 < len(roots) else 127
            pk, dbs = decs[i]
            dk = round((1 - 10 ** (-dbs / 20 / zr)) * (1 << 24)) if dbs else 0       # per tape sample, Q24
            lp, li = 0, 0                         # (block ADPCM: the loop's state is the checkpoint at ls, on the CK grid)
            if d in DARKEN:                       # (lpred, no use to these formats: its brightness floor, the
                fc = min(5000.0, max(500.0, 3 * 440 * 2 ** ((r - 69) / 12)))   # one-pole the note darkens to, Q15,
                lp, li = round(32767 * (1 - np.exp(-2 * np.pi * fc / SRC_RATE))), 0   # ~3 x its fundamental)
            out["zones"].append(dict(off=len(out["data"]), n=len(pcm), ls=ls, ck=len(out["ck"]), root=r - up, lo=lo, hi=hi,
                                     sh=sh, kind=2 if d in PCM8 else 3 if d in IMA else 0, gain=round(32 / sc8), lpred=lp, lidx=li, dk=dk,
                                     d1k=round(32767 * 10 ** (-dbs * 1024 / zr / 20)), pk=pk))
            out["data"] += data
            out["ck"] += cks
        out["sets"].append((name, z0, len(roots), d in STRUCK))
        out.setdefault("play", []).append(PLAY.get(d, PLAY_ELSE))
        out.setdefault("upcut", []).append(d in UPCUT)
    return out, int(per0) // CK * CK


def sloop_env_exp(v):
    """SLOOP's gen_tables.py ENV_EXP[v]: an exponential's step per 32 frames, Q16, ~99 % of the way in 10000^(v/127) ms"""
    tau = 10000 ** (v / 127) / 1000 / 4.6
    return max(1, min(65535, int(65536 * (1 - np.exp(-32 / (tau * SRC_RATE))))))


def tables():
    """the firmware has no float: its curves, computed here"""
    def arr(decl, vals, per_line=10):
        L = [decl + " = {"]
        for i in range(0, len(vals), per_line):
            L.append("    " + " ".join(f"{v}u," for v in vals[i:i + per_line]))
        return L + ["};"]
    pow2 = [round(2 ** 30 * 2 ** (c / 1200)) for c in range(1201)]
    # EQ's screen: how the SPEAKER settings' filters (mel_fx.c, as they run: one-poles y += a (x - y)) answer, across
    # the screen (224 px, 20 Hz .. 20 kHz), dB x 4 down (0 .. 96: -24 dB); and BASS+'s harmonics' band, its shape
    zx = np.exp(-2j * np.pi * (20 * 10 ** (3 * np.arange(224) / 224)) / SRC_RATE)
    lp1 = lambda a: a / (1 - (1 - a) * zx)
    spk = []
    for h in (np.ones(224), (1 - lp1(1 / 64)) ** 2, (1 - lp1(1 / 32)) ** 2, lp1(1 / 2) ** 2):
        spk += [int(min(96, round(-4 * 20 * np.log10(max(1e-9, v))))) for v in np.abs(h)]
    harm = np.abs((1 - lp1(1 / 32)) ** 2 * lp1(1 / 8))
    harm = [round(255 * v / harm.max()) for v in harm]
    tone = []                                    # TONE 0..100: a one-pole's coefficient, 350 Hz .. 16 kHz
    for v in range(101):
        fc = 350 * (16000 / 350) ** (v / 100)
        tone.append(round(32768 * (1 - np.exp(-2 * np.pi * fc / SRC_RATE))))
    sat = []                                     # tape saturation: |x| 0..2 full scale -> 0..1, linear up to 0.6
    for i in range(257):
        x = 2 * i / 256
        y = x if x < 0.6 else 0.6 + 0.4 * np.tanh((x - 0.6) / 0.4)
        sat.append(round(32767 * min(y, 1)))
    atk = []                                     # ATTACK 0..100: 3 ms .. 2 s, the rise per 32 frames, Q24; as v^1.5, so
    for v in range(101):                         # the knob is felt from ~10 on (10: 66 ms, 20: 0.18 s, 50: 0.71 s; an
        t = 0.003 + 2.0 * (v / 100) ** 1.5       # exponential spent its first 40 under the tapes' own rise, 40-70 ms)
        atk.append(min(1 << 24, round((1 << 24) * 32 / (t * SRC_RATE))))
    lfo = [round(0.5 * 20 ** (v / 100) * 2 ** 32 / SRC_RATE) for v in range(101)]   # VIBRATO RATE: 0.5 .. 10 Hz
    lfo10 = [round(0.5 * 20 ** (v / 100) * 10) for v in range(101)]
    rel = []                                     # REL 0..100: 20 ms .. 6 s to -60 dB, per 32 frames, Q16
    for v in range(101):
        t = 0.02 * 300 ** (v / 100)
        rel.append(round(65536 * (1 - np.exp(-6.9 * 32 / (SRC_RATE * t)))))
    def onepole(fc):
        return round(32768 * (1 - np.exp(-2 * np.pi * fc / SRC_RATE)))
    genlp = [onepole(9000 * (1100 / 9000) ** (v / 100)) for v in range(101)]   # AGE: a copy of a copy of a copy
    genhp = [onepole(20 * (380 / 20) ** (v / 100)) for v in range(101)]         # (two poles each: mel_fx.c)
    # DRIVE, after the JHS 424 (a Tascam Portastudio's cassette preamp): 0 dB .. +36 dB into a soft clipper that keeps
    # going (linear to half scale, then a tanh that never quite gets there), a bias for the even harmonics, a low-pass
    # that closes as it drives (warm, not fizzy), and the level given back so a turn of DRIVE is not a turn of volume
    def clip(x):
        x = np.abs(x)
        return np.where(x < 0.5, x, 0.5 + 0.5 * np.tanh((x - 0.5) / 0.5))
    clipt = [round(32767 * float(clip(np.array([i * 1024 / 32768]))[0])) for i in range(257)]   # |u| 0 .. 8 x full
    drv, drvmk, drvlp = [], [], []
    tt = np.arange(4410) / SRC_RATE
    sig = 0.16 * np.sin(2 * np.pi * 220 * tt)   # a note at -19 dBFS RMS, as the tapes play
    for v in range(101):
        g = 10 ** (36 * (v / 100) ** 1.4 / 20)
        b = 0.15 * v / 100
        u = sig * g + b
        y = np.sign(u) * clip(u)
        y = y - y.mean()
        mk = min(1.0, max(0.08, np.sqrt(np.mean(sig ** 2)) / np.sqrt(np.mean(y ** 2))))
        drv.append(round(256 * g))
        drvmk.append(round(32767 * mk))
        drvlp.append(onepole(12000 * (4500 / 12000) ** (v / 100)))
    return (arr("static const uint32_t MEL_POW2[1201]   /* 2^(c/1200), Q30 */", pow2, 6) +
            arr("static const uint16_t MEL_CLIP[257]    /* DRIVE's clipper: |u| / 1024 (to 8 x full scale) -> Q15 */", clipt) +
            arr("static const uint16_t MEL_DRV[101]     /* DRIVE -> its gain, Q8 (0 .. +36 dB) */", drv) +
            arr("static const uint16_t MEL_DRVMK[101]   /* -> the level given back, Q15 */", drvmk) +
            arr("static const uint16_t MEL_DRVLP[101]   /* -> its low-pass, 12 .. 4.5 kHz, Q15 */", drvlp) +
            arr("static const uint32_t MEL_ATK[101]     /* ATTACK -> the rise per 32 frames, Q24 */", atk) +
            arr("static const uint32_t MEL_LFO[101]     /* VIBRATO RATE -> phase per frame */", lfo, 6) +
            arr("static const uint8_t MEL_LFO_HZ10[101] /* (its Hz x 10, shown) */", lfo10) +
            arr("static const uint16_t MEL_GENLP[101]   /* AGE -> the tape's top end, 9 kHz .. 1.1 kHz, Q15 */", genlp) +
            arr("static const uint16_t MEL_GENHP[101]   /* AGE -> its bottom end, 20 .. 380 Hz, Q15 */", genhp) +
            arr("static const uint16_t MEL_REL[101]     /* REL -> decay per 32 frames, Q16 */", rel) +
            arr("static const uint8_t MEL_SPK_DB[4 * 224]   /* EQ SPEAKER: its curve, per pixel, dB x 4 down */", spk, 16) +
            arr("static const uint8_t MEL_SPK_HARM[224]     /* BASS+: its harmonics' band, per pixel, 0..255 */", harm, 16) +
            arr("static const uint16_t MEL_TONE[101]    /* TONE -> one-pole coefficient, Q15 */", tone) +
            arr("static const uint16_t MEL_SAT[257]     /* saturation: |x| / 2^8 of 2 x full scale -> Q15 */", sat) +
            arr("static const uint16_t MEL_TANH[257]    /* tanh(x / 32768) x 32767, x = i x 256 (SLOOP's TANH_Q15) */",
                [int(32767 * np.tanh(i / 256 * 2)) for i in range(257)]))


def write(out, path, rate, per):
    z, data = out["zones"], out["data"]
    L = ["/* generated by tools/gen_tapes.py: MEL's tapes (Taijiguy's Mellotron M400S samples; the piano, VCSL's (CC0):"
         " README.md, LICENSING.md) */",
         f"#define MEL_RATE {rate}u",
         f"#define MEL_RATE_Q16 {rate * 65536 // 44100}u          /* MEL_RATE / 44100, Q16 (a zone's: >> its sh) */",
         f"#define MEL_CK {CK}u",
         f"#define MEL_NSETS {len(out['sets'])}u",
         f"#define MEL_NZONES {len(z)}u",
         f"/* {len(z)} zones, the tapes' of {per} samples ({per / (rate >> SHIFT_ELSE):.2f} s), {len(data)} B of samples (ADPCM; 8-bit PCM: PCM8), "
         f"{4 * len(out['ck'])} B of checkpoints */",
         "static const char *const MEL_SET_NAME[MEL_NSETS] = {" + ", ".join(f'"{n}"' for n, _, _, _ in out["sets"]) + "};",
         "static const uint8_t MEL_SET_Z0[MEL_NSETS] = {" + ", ".join(str(a) for _, a, _, _ in out["sets"]) + "};",
         "static const uint8_t MEL_SET_NZ[MEL_NSETS] = {" + ", ".join(str(b) for _, _, b, _ in out["sets"]) + "};",
         "static const uint8_t MEL_SET_STRUCK[MEL_NSETS] = {" + ", ".join(str(int(k)) for *_, k in out["sets"]) + "};",
         "static const uint8_t MEL_SET_UPCUT[MEL_NSETS] = {" + ", ".join(str(int(k)) for k in out["upcut"]) + "};   /* well above a root: its band's low-pass */",
         "static const int8_t MEL_SET_PLAY[MEL_NSETS][4] = {   /* its own PLAY to start from: TONE PITCH ATTACK RELEASE */",
         "    " + ", ".join("{" + ", ".join(str(v) for v in q) + "}" for q in out["play"]) + "};",
         "/* a kind 1 zone (the piano): SLOOP's SAMPLE engine with LOFI KEYS (gen_tapes.py PNO_) */",
         f"#define MEL_PNO_BITS {PNO_BITS}                   /* bits taken off */",
         f"#define MEL_PNO_DRV {PNO_DRV}                  /* its drive into the tanh */",
         f"#define MEL_PNO_CUT {PNO_CUT}                 /* its one-pole, Q15 */",
         f"#define MEL_PNO_DEC {sloop_env_exp(108)}u                 /* its decay per 32 frames, Q16 (DEC 108: -40 dB in 2.5 s) */",
         f"#define MEL_PNO_LFO {int(0.05 * 800 ** (38 / 127) * 32 / SRC_RATE * 2 ** 32)}u          /* its pitch LFO, a sine, per 32 frames (RATE 38: 0.37 Hz) */",
         "#define MEL_PNO_LFO_C16 300               /* its depth, 1/16 cent (PIT 1: +-18.75 cents) */",
         "static const mel_zone_t MEL_ZONE[MEL_NZONES] = {"]
    for q in z:
        L.append(f"    {{{q['off']}u, {q['n']}u, {q['ls']}u, {q['ck']}u, {q['root']}, {q['lo']}, {q['hi']}, {q['sh']}, {q['kind']}, "
                 f"{q['gain']}, {q['lidx']}, {q['dk']}u, {q['d1k']}u, {q['pk']}u, {q['lpred']}}},")
    L.append("};")
    L.append("static const uint32_t MEL_CKS[] = {   /* (uint16_t)predictor | step index << 16 */")
    for i in range(0, len(out["ck"]), 8):
        L.append("    " + " ".join(f"0x{(p & 0xFFFF) | (k & 0xFFFF) << 16:08x}u," for p, k in out["ck"][i:i + 8]))
    L.append("};")
    L += tables()
    L.append("static const uint8_t MEL_DATA[] = {")
    for i in range(0, len(data), 24):
        L.append("    " + ",".join(str(b) for b in data[i:i + 24]) + ",")
    L.append("};")
    Path(path).write_text("\n".join(L) + "\n")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("out")
    ap.add_argument("--src", default=str(Path(__file__).resolve().parents[1] / "tapes" / "wav"))
    ap.add_argument("--sets", default=",".join(SETS), help="the tapes, in order (A, B, C, ...): folders of --src")
    ap.add_argument("--budget", type=int, default=338_000, help="bytes of tape data (block ADPCM + checkpoints; 8-bit PCM as if unpacked) in all, but FIXED_LEN's")
    ap.add_argument("--step", type=int, default=3, help="semitones between roots (but STEP's sets)")
    ap.add_argument("--rate", type=int, default=22050, help="the firmware's rate (MEL_RATE): a set's is it >> SHIFT")
    a = ap.parse_args()
    out, per = build(Path(a.src), a.budget, a.step, a.rate, a.sets.split(","))
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    write(out, a.out, a.rate, per)
    print(f"tapes: {', '.join(n for n, *_ in out['sets'])}: {len(out['zones'])} zones of {per / (a.rate >> SHIFT_ELSE):.2f} s, "
          f"{len(out['data']) + 4 * len(out['ck'])} B -> {a.out}")


if __name__ == "__main__":
    main()
