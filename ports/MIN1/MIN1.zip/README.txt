Min-1 0.2.1 for the BBL Mod Swapper

Original by Reytian: https://github.com/Reytian/fm1-min1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: MIN1-source.zip on the ports page.
