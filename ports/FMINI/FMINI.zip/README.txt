FMini-1 2.6.0 for the BBL Mod Swapper

Original by ruppert: https://github.com/ruppert/fmini-1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: FMINI-source.zip on the ports page.
