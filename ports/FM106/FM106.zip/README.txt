FM-106 1.02 for the BBL Mod Swapper

Original by PatttF: https://github.com/PatttF/fm-106
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: FM106-source.zip on the ports page.
