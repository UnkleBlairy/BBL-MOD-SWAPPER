/* SPDX-License-Identifier: GPL-3.0-only */
/* FM-106: Roland Juno-106 System Exclusive (SysEx) Librarian & Real-Time Protocol */
#pragma once
#include <stdint.h>

#define FM106_PRESETS_FLASH_ADDR 0x00098000u
#define FM106_PRESETS_FLASH_SIZE 0x4000u    /* 16 KiB (4 x 4 KiB sectors) */
#define FM106_PRESETS_MAGIC      0x36303142u /* "J10B" v1 user banks (preset p[44], FX 1 only) */
#define FM106_PRESETS_MAGIC2     0x36303143u /* "J10C" v2 user banks (preset p[60], FX 1..4) */
#define FM106_PRESETS_MAGIC3     0x36303144u /* "J10D" v3 user banks (preset p[66], FX 1..4 + SEQ) */

typedef struct {
    uint32_t magic;
    uint32_t count;
    uint32_t crc;
    uint32_t reserved;
} fm106_flash_header_t;

/* Global RAM user bank (128 presets = 10,496 bytes: 64 in User A, 64 in User B) */
extern fm106_preset_t g_user_presets[FM106_NUM_USER_PRESETS];
extern fm106_engine_t g_synth;
extern uint32_t g_dirty_screen;

#if FELUCCA_BLE
static void bt_page_on(void);
static void bt_page_off(void);
static void bt_host_scan_start(void);
static void bt_add_close(void);
void ble_ui_get_diag(uint32_t out[16]);
static uint32_t bt_st_diag(void);
#endif

static inline uint32_t fm106_crc32(const uint8_t *p, uint32_t n)
{
    uint32_t c = 0xFFFFFFFFu, k;
    while (n--) {
        c ^= *p++;
        for (k = 0; k < 8u; k++)
            c = c & 1u ? (c >> 1) ^ 0xEDB88320u : c >> 1;
    }
    return ~c;
}

/* Reset user presets in RAM back to completely blank */
static void fm106_user_presets_restore_factory(void)
{
    memset(g_user_presets, 0, sizeof(g_user_presets));
}

static uint8_t g_presets_flash_buf[sizeof(fm106_flash_header_t) + sizeof(g_user_presets)];

/* Initialize user presets: load from SPI flash if valid, else initialize as completely blank.
 * v1 banks ("J10B", p[44]) and v2 banks ("J10C", p[60]) still load: widened in place. */
static void fm106_user_presets_init(void)
{
    fm106_flash_header_t hdr;

    if (presets_flash_read(&hdr, sizeof(hdr)) == 0 &&
        hdr.count == FM106_NUM_USER_PRESETS &&
        (hdr.magic == FM106_PRESETS_MAGIC3 || hdr.magic == FM106_PRESETS_MAGIC2 || hdr.magic == FM106_PRESETS_MAGIC)) {
        if (hdr.magic == FM106_PRESETS_MAGIC3) {
            if (presets_flash_read(g_presets_flash_buf, sizeof(g_presets_flash_buf)) == 0 &&
                fm106_crc32(g_presets_flash_buf + sizeof(hdr), sizeof(g_user_presets)) == hdr.crc) {
                memcpy(g_user_presets, g_presets_flash_buf + sizeof(hdr), sizeof(g_user_presets));
                return;
            }
        } else if (hdr.magic == FM106_PRESETS_MAGIC2) {
            /* v2: 128 records of {name[16], p[60]} = 76 B each */
            const uint32_t v2_size = FM106_NUM_USER_PRESETS * 76u;
            if (presets_flash_read(g_presets_flash_buf, sizeof(fm106_flash_header_t) + v2_size) == 0 &&
                fm106_crc32(g_presets_flash_buf + sizeof(hdr), v2_size) == hdr.crc) {
                const uint8_t *src = g_presets_flash_buf + sizeof(hdr);
                for (uint32_t i = FM106_NUM_USER_PRESETS; i-- > 0; ) {
                    /* descending: each widened record sits above the old record it came from */
                    memcpy(g_user_presets[i].name, src + i * 76u, 16);
                    memset(g_user_presets[i].p, 0, sizeof(g_user_presets[i].p));
                    memcpy(g_user_presets[i].p, src + i * 76u + 16, 60);
                }
                return;
            }
        } else {
            /* v1: 128 records of {name[16], p[44]} = 60 B each */
            const uint32_t oldn = FM106_NUM_USER_PRESETS * 60u;
            if (presets_flash_read(g_presets_flash_buf, sizeof(fm106_flash_header_t) + oldn) == 0 &&
                fm106_crc32(g_presets_flash_buf + sizeof(hdr), oldn) == hdr.crc) {
                const uint8_t *src = g_presets_flash_buf + sizeof(hdr);
                for (uint32_t i = FM106_NUM_USER_PRESETS; i-- > 0; ) {
                    /* descending: each widened record sits above the old record it came from */
                    memcpy(g_user_presets[i].name, src + i * 60u, 16);
                    memset(g_user_presets[i].p, 0, sizeof(g_user_presets[i].p));
                    memcpy(g_user_presets[i].p, src + i * 60u + 16, 44);
                }
                return;
            }
        }
    }

    /* Fallback: initialize user presets as completely blank */
    memset(g_user_presets, 0, sizeof(g_user_presets));
}

/* Burn user presets RAM bank into SPI flash */
static int fm106_user_presets_save_flash(void)
{
#if DINGHY_DUAL_CORE
    if (audio_worker_online) audio_worker_join();
#endif
    fm106_flash_header_t *hdr = (fm106_flash_header_t *)g_presets_flash_buf;

    hdr->magic = FM106_PRESETS_MAGIC3;
    hdr->count = FM106_NUM_USER_PRESETS;
    hdr->crc = fm106_crc32((const uint8_t *)g_user_presets, sizeof(g_user_presets));
    hdr->reserved = 0;

    memcpy(g_presets_flash_buf + sizeof(fm106_flash_header_t), g_user_presets, sizeof(g_user_presets));
    return presets_flash_save(g_presets_flash_buf, sizeof(g_presets_flash_buf));
}

/* ---- Persistent 128-Step Sequencer Pattern in SPI Flash (0x0009C000, 4 KiB) ----
 * Reuses g_presets_flash_buf (~10.5 KiB) as staging buffer for 0 bytes extra SRAM. */
#define FM106_SEQ_FLASH_MAGIC 0x53363031u /* "106S" */

typedef struct {
    uint32_t magic;
    uint32_t crc;
    uint16_t slen;
    uint16_t nplock;
    uint8_t  bpm;
    uint8_t  sdiv;
    uint8_t  sgate;
    uint8_t  swing;
    fm106_step_t  step[FM106_NSTEP];
    fm106_plock_t plock[FM106_PLOCK_SLOTS];
} fm106_seq_flash_t;

typedef char fm106_seq_flash_fit_check[(sizeof(fm106_seq_flash_t) <= 0x1000u &&
                                        sizeof(fm106_seq_flash_t) <= sizeof(g_presets_flash_buf)) ? 1 : -1];

static int fm106_seq_load_flash(fm106_seq_t *s)
{
    fm106_seq_flash_t *img = (fm106_seq_flash_t *)g_presets_flash_buf;
    if (seq_flash_read(img, 8u) != 0 || img->magic != FM106_SEQ_FLASH_MAGIC)
        return -1;
    if (seq_flash_read(img, sizeof(fm106_seq_flash_t)) != 0)
        return -1;
    uint32_t crc = fm106_crc32((const uint8_t *)img + 8u, (uint32_t)(sizeof(fm106_seq_flash_t) - 8u));
    if (crc != img->crc)
        return -1;

    fm1_irq_off();
    s->slen   = (img->slen < 1u) ? 16u : (img->slen > FM106_NSTEP ? FM106_NSTEP : img->slen);
    s->bpm    = (img->bpm < 40u) ? 120u : (img->bpm > 240u ? 240u : img->bpm);
    s->sdiv   = (img->sdiv > 9u) ? 3u : img->sdiv;
    s->sgate  = (img->sgate < 1u) ? 128u : (img->sgate > 128u ? 128u : img->sgate);
    s->swing  = (img->swing > 100u) ? 0u : img->swing;
    memcpy(s->step, img->step, sizeof(s->step));
    uint16_t np = img->nplock > FM106_PLOCK_SLOTS ? FM106_PLOCK_SLOTS : img->nplock;
    uint16_t w = 0;
    for (uint16_t i = 0; i < np; i++) {
        if (img->plock[i].step < FM106_NSTEP && img->plock[i].param < FM106_NPARAM) {
            s->plock[w++] = img->plock[i];
        }
    }
    s->nplock = w;
    fm1_irq_on();
    return 0;
}

static int fm106_seq_save_flash(const fm106_seq_t *s)
{
#if DINGHY_DUAL_CORE
    if (audio_worker_online) audio_worker_join();
#endif
    fm106_seq_flash_t *img = (fm106_seq_flash_t *)g_presets_flash_buf;
    memset(img, 0, sizeof(fm106_seq_flash_t));
    img->magic  = FM106_SEQ_FLASH_MAGIC;
    img->slen   = s->slen ? s->slen : 16u;
    img->nplock = s->nplock > FM106_PLOCK_SLOTS ? FM106_PLOCK_SLOTS : s->nplock;
    img->bpm    = s->bpm;
    img->sdiv   = s->sdiv;
    img->sgate  = s->sgate;
    img->swing  = s->swing;
    memcpy(img->step, s->step, sizeof(img->step));
    if (img->nplock > 0u) {
        memcpy(img->plock, s->plock, (uint32_t)img->nplock * sizeof(fm106_plock_t));
    }
    img->crc = fm106_crc32((const uint8_t *)img + 8u, (uint32_t)(sizeof(fm106_seq_flash_t) - 8u));
    return seq_flash_save(img, sizeof(fm106_seq_flash_t));
}

static void fm106_load_init_preset(fm106_engine_t *e, const char *name)
{
    if (name) {
        str_cpy(e->patch_name, name, sizeof(e->patch_name));
    } else {
        e->patch_name[0] = '\0';
    }
    e->bender_dco = 0; e->bender_vcf = 0;
    e->arp_rate = 120; e->lfo_rate = 60; e->lfo_delay = 0;
    e->dco_lfo_depth = 0; e->dco_pwm_depth = 0; e->dco_sub_level = 0; e->dco_noise_level = 0;
    e->hpf.mode = 1;
    e->vcf_cutoff = 100; e->vcf_resonance = 0; e->vcf_env_mod = 0; e->vcf_lfo_mod = 0;
    e->vcf_kbd_track = 0; e->vca_level = 100;
    e->env_a = 0; e->env_d = 64; e->env_s = 127; e->env_r = 20;
    e->dco_pulse_on = 0; e->dco_saw_on = 1; e->dco_sub_on = 0;
    e->chorus.mode = FM106_CHORUS_OFF;
    e->dco_range = 1; e->arp_mode = 0; e->arp_range = 1;
    e->dco_pwm_mode = 0; e->vcf_env_polarity = 0; e->vca_mode = 0;
    e->fx[0].type = FM106_FX_OFF; e->fx[0].mix = 0;
    e->fx[1].type = FM106_FX_OFF; e->fx[1].mix = 0;
    e->fx[2].type = FM106_FX_OFF; e->fx[2].mix = 0;
    e->fx[3].type = FM106_FX_OFF; e->fx[3].mix = 0;
    e->reverb.on = 0u; e->reverb.mix = 48u; e->reverb.decay = 84u; e->reverb.shimmer = 68u;
    for (uint32_t i = 0; i < FM106_NUM_VOICES; i++) {
        fm106_adsr_params(&e->voice[i].adsr, e->env_a, e->env_d, e->env_s, e->env_r);
        e->voice[i].dco.saw_on = 1; e->voice[i].dco.pulse_on = 0; e->voice[i].dco.sub_on = 0;
        e->voice[i].dco.sub_level = 0; e->voice[i].dco.noise_level = 0;
        if (e->voice[i].note != 255u) {
            e->voice[i].base_inc = fm106_calc_inc(e->voice[i].note, 0, e->dco_range);
            if (!e->voice[i].gliding) e->voice[i].curr_inc = e->voice[i].base_inc;
        }
    }
    fm106_param_snapshot(e);
}

/* Load a preset from the 4 banks (Factory A, Factory B, User A, User B) into the synth engine */
static void fm106_load_user_preset(fm106_engine_t *e, uint32_t idx)
{
    fm1_irq_off();
#if DINGHY_DUAL_CORE
    if (audio_worker_online) audio_worker_join();
#endif
    if (idx >= FM106_TOTAL_PRESETS) idx = 0;
    e->patch_idx = (uint16_t)idx;
    uint32_t bank_idx = idx / 65u;
    uint32_t local = idx % 65u;

    if (local == 0u) {
        /* Slot 00 of any bank is the Init preset */
        const char *init_name = "Init Saw";
        if (bank_idx == 0u) init_name = "A00 Init";
        else if (bank_idx == 1u) init_name = "B00 Init";
        else if (bank_idx == 2u) init_name = "UA00 Init";
        else init_name = "UB00 Init";
        fm106_load_init_preset(e, init_name);
        fm1_irq_on();
        return;
    }

    uint32_t slot_in_bank = local - 1u;
    const fm106_preset_t *p;
    if (bank_idx < 2u) {
        p = &FM106_PRESETS[bank_idx * 64u + slot_in_bank];
    } else {
        uint32_t uidx = (bank_idx - 2u) * 64u + slot_in_bank;
        p = &g_user_presets[uidx];
        if (p->name[0] == '\0') {
            /* Blank user preset: load clean default initialized sound */
            char default_name[16];
            uint32_t b_num = (slot_in_bank / 8u) + 1u;
            uint32_t p_num = (slot_in_bank % 8u) + 1u;
            default_name[0] = 'U';
            default_name[1] = (bank_idx == 2u) ? 'A' : 'B';
            default_name[2] = (char)('0' + b_num);
            default_name[3] = (char)('0' + p_num);
            default_name[4] = ' ';
            default_name[5] = 'I'; default_name[6] = 'n'; default_name[7] = 'i'; default_name[8] = 't';
            default_name[9] = '\0';
            fm106_load_init_preset(e, default_name);
            fm1_irq_on();
            return;
        }
    }

    uint32_t pi = 0;
    while (p->name[pi] && pi < sizeof(e->patch_name) - 1u) {
        e->patch_name[pi] = p->name[pi];
        pi++;
    }
    e->patch_name[pi] = '\0';

    e->bender_dco     = p->p[0];
    e->bender_vcf     = p->p[1];
    e->arp_rate       = p->p[2];
    e->lfo_rate       = p->p[3];
    e->lfo_delay      = p->p[4];
    e->dco_lfo_depth  = p->p[5];
    e->dco_pwm_depth  = p->p[6];
    e->dco_sub_level  = p->p[7];
    e->dco_noise_level= p->p[8];
    e->hpf.mode       = p->p[9] > 3 ? 1 : p->p[9];
    e->vcf_cutoff     = p->p[10];
    e->vcf_resonance  = p->p[11];
    e->vcf_env_mod    = p->p[12];
    e->vcf_lfo_mod    = p->p[13];
    e->vcf_kbd_track  = p->p[14];
    e->vca_level      = p->p[15];
    e->env_a          = p->p[16];
    e->env_d          = p->p[17];
    e->env_s          = p->p[18];
    e->env_r          = p->p[19];

    e->dco_pulse_on   = p->p[23];
    e->dco_saw_on     = p->p[24];
    e->dco_sub_on     = p->p[25];

    if (p->p[27] && p->p[28]) e->chorus.mode = FM106_CHORUS_I_II;
    else if (p->p[28]) e->chorus.mode = FM106_CHORUS_II;
    else if (p->p[27]) e->chorus.mode = FM106_CHORUS_I;
    else e->chorus.mode = FM106_CHORUS_OFF;

    e->dco_range        = p->p[29] > 2 ? 1 : p->p[29];
    e->arp_mode         = p->p[30] > 2 ? 0 : p->p[30];
    e->arp_range        = p->p[31] ? p->p[31] : 1;
    e->dco_pwm_mode     = p->p[33];
    e->vcf_env_polarity = p->p[34];
    e->vca_mode         = p->p[35];

    e->fx[0].type      = p->p[36] >= FM106_FX_COUNT ? 0 : p->p[36];
    e->fx[0].mix       = p->p[37] > 127 ? 127 : p->p[37];
    e->fx[0].rate      = p->p[38] > 127 ? 127 : p->p[38];
    e->fx[0].character = p->p[39] > 127 ? 127 : p->p[39];
    fm106_reverb_apply_preset(&e->reverb, p);

    /* Voice allocation mode (0 = default/Poly I, 1 = Mono unison, 2 = Poly I, 3 = Poly II) */
    if (p->p[49] == 1u) {
        fm106_set_voice_mode(e, FM106_MODE_MONO);
    } else if (p->p[49] == 3u) {
        fm106_set_voice_mode(e, FM106_MODE_POLY2);
    } else {
        fm106_set_voice_mode(e, FM106_MODE_POLY1);
    }

    for (uint32_t i = 0; i < FM106_NUM_VOICES; i++) {
        fm106_adsr_params(&e->voice[i].adsr, e->env_a, e->env_d, e->env_s, e->env_r);
        e->voice[i].dco.saw_on = e->dco_saw_on;
        e->voice[i].dco.pulse_on = e->dco_pulse_on;
        e->voice[i].dco.sub_on = e->dco_sub_on;
        e->voice[i].dco.sub_level = e->dco_sub_level;
        e->voice[i].dco.noise_level = e->dco_noise_level;
        if (e->voice[i].note != 255u) {
            e->voice[i].base_inc = (e->voice_mode == FM106_MODE_MONO)
                ? fm106_calc_unison_inc(e->voice[i].note, 0, e->dco_range, i)
                : fm106_calc_inc(e->voice[i].note, 0, e->dco_range);
            if (!e->voice[i].gliding) e->voice[i].curr_inc = e->voice[i].base_inc;
        }
    }
    fm106_param_snapshot(e); /* p-lock cache follows the loaded sound */
    fm1_irq_on();
}

/* Save the current synth engine state into a preset struct */
static void fm106_save_engine_to_preset(fm106_preset_t *p, const fm106_engine_t *e, const char *name)
{
    memset(p, 0, sizeof(*p));
    uint32_t len = 0;
    while (name && name[len] && len < sizeof(p->name) - 1u) {
        p->name[len] = name[len];
        len++;
    }
    p->name[len] = '\0';

    p->p[0]  = e->bender_dco;
    p->p[1]  = e->bender_vcf;
    p->p[2]  = e->arp_rate;
    p->p[3]  = e->lfo_rate;
    p->p[4]  = e->lfo_delay;
    p->p[5]  = e->dco_lfo_depth;
    p->p[6]  = e->dco_pwm_depth;
    p->p[7]  = e->dco_sub_level;
    p->p[8]  = e->dco_noise_level;
    p->p[9]  = e->hpf.mode & 3u;
    p->p[10] = e->vcf_cutoff;
    p->p[11] = e->vcf_resonance;
    p->p[12] = e->vcf_env_mod;
    p->p[13] = e->vcf_lfo_mod;
    p->p[14] = e->vcf_kbd_track;
    p->p[15] = e->vca_level;
    p->p[16] = e->env_a;
    p->p[17] = e->env_d;
    p->p[18] = e->env_s;
    p->p[19] = e->env_r;

    p->p[23] = e->dco_pulse_on & 1u;
    p->p[24] = e->dco_saw_on & 1u;
    p->p[25] = e->dco_sub_on & 1u;

    p->p[27] = (e->chorus.mode == FM106_CHORUS_I || e->chorus.mode == FM106_CHORUS_I_II) ? 1u : 0u;
    p->p[28] = (e->chorus.mode == FM106_CHORUS_II || e->chorus.mode == FM106_CHORUS_I_II) ? 1u : 0u;

    p->p[29] = e->dco_range & 3u;
    p->p[30] = e->arp_mode & 3u;
    p->p[31] = e->arp_range ? e->arp_range : 1u;
    p->p[33] = e->dco_pwm_mode & 1u;
    p->p[34] = e->vcf_env_polarity & 1u;
    p->p[35] = e->vca_mode & 1u;

    p->p[36] = e->fx[0].type < FM106_FX_COUNT ? e->fx[0].type : 0u;
    p->p[37] = (uint8_t)e->fx[0].mix;
    p->p[38] = (uint8_t)e->fx[0].rate;
    p->p[39] = (uint8_t)e->fx[0].character;

    /* SEQ track params (bpm/sdiv/slen/sgate/swing) */
    p->p[40] = (uint8_t)e->seq.bpm;
    p->p[41] = (uint8_t)e->seq.sdiv;
    p->p[42] = (uint8_t)(e->seq.slen & 0xFFu);
    p->p[65] = (uint8_t)(e->seq.slen >> 8);
    p->p[43] = (uint8_t)e->seq.sgate;
    p->p[44] = (uint8_t)e->seq.swing;

    /* 80s Shimmer Reverb params */
    p->p[45] = e->reverb.on & 1u;
    p->p[46] = e->reverb.mix;
    p->p[47] = e->reverb.decay;
    p->p[48] = e->reverb.shimmer;

    /* Voice Mode (1 = Mono unison, 2 = Poly I, 3 = Poly II) */
    p->p[49] = (e->voice_mode == FM106_MODE_MONO) ? 1u : (e->voice_mode == FM106_MODE_POLY2) ? 3u : 2u;
}

/* Decode Switch Byte 1 (SW1): Octave, Pulse, Saw, Chorus */
static inline void fm106_decode_sw1(uint8_t sw1, uint8_t *oct, uint8_t *pulse, uint8_t *saw, uint8_t *chorus)
{
    *oct = (sw1 & 4u) ? 2u : (sw1 & 2u) ? 1u : 0u;
    *pulse = (sw1 & 8u) ? 1u : 0u;
    *saw = (sw1 & 16u) ? 1u : 0u;
    if ((sw1 & 96u) == 96u) {
        *chorus = FM106_CHORUS_I_II;
    } else if (sw1 & 32u) {
        *chorus = FM106_CHORUS_OFF;
    } else if (sw1 & 64u) {
        *chorus = FM106_CHORUS_I;
    } else {
        *chorus = FM106_CHORUS_II;
    }
}

/* Encode Switch Byte 1 (SW1) */
static inline uint8_t fm106_encode_sw1(uint8_t oct, uint8_t pulse, uint8_t saw, uint8_t chorus)
{
    uint8_t sw1 = (oct == 2u) ? 4u : (oct == 1u) ? 2u : 1u;
    if (pulse) sw1 |= 8u;
    if (saw) sw1 |= 16u;
    if (chorus == FM106_CHORUS_OFF) sw1 |= 32u;
    else if (chorus == FM106_CHORUS_I) sw1 |= 64u;
    else if (chorus == FM106_CHORUS_I_II) sw1 |= (32u | 64u);
    return sw1;
}

/* Decode Switch Byte 2 (SW2): PWM Mode, VCF Env Inv, VCA Mode, HPF */
static inline void fm106_decode_sw2(uint8_t sw2, uint8_t *pwm_mode, uint8_t *vcf_inv, uint8_t *vca_mode, uint8_t *hpf)
{
    *pwm_mode = (sw2 & 1u) ? 1u : 0u;
    *vcf_inv = (sw2 & 2u) ? 1u : 0u;
    *vca_mode = (sw2 & 4u) ? 1u : 0u;
    *hpf = (3u - ((sw2 >> 3) & 3u)) & 3u;
}

/* Encode Switch Byte 2 (SW2) */
static inline uint8_t fm106_encode_sw2(uint8_t pwm_mode, uint8_t vcf_inv, uint8_t vca_mode, uint8_t hpf)
{
    uint8_t sw2 = 0;
    if (pwm_mode) sw2 |= 1u;
    if (vcf_inv) sw2 |= 2u;
    if (vca_mode) sw2 |= 4u;
    sw2 |= (((3u - (hpf & 3u)) & 3u) << 3);
    return sw2;
}

/* Apply 18 APR parameters directly to live engine edit buffer */
static void fm106_apply_apr_to_engine(fm106_engine_t *e, const uint8_t *s, uint8_t sw1, uint8_t sw2)
{
    e->lfo_rate        = s[0] & 0x7Fu;
    e->lfo_delay       = s[1] & 0x7Fu;
    e->dco_lfo_depth   = s[2] & 0x7Fu;
    e->dco_pwm_depth   = s[3] & 0x7Fu;
    e->dco_noise_level = s[4] & 0x7Fu;
    e->vcf_cutoff      = s[5] & 0x7Fu;
    e->vcf_resonance   = s[6] & 0x7Fu;
    e->vcf_env_mod     = s[7] & 0x7Fu;
    e->vcf_lfo_mod     = s[8] & 0x7Fu;
    e->vcf_kbd_track   = s[9] & 0x7Fu;
    e->vca_level       = s[10] & 0x7Fu;
    e->env_a           = s[11] & 0x7Fu;
    e->env_d           = s[12] & 0x7Fu;
    e->env_s           = s[13] & 0x7Fu;
    e->env_r           = s[14] & 0x7Fu;
    e->dco_sub_level   = s[15] & 0x7Fu;
    e->dco_sub_on      = (e->dco_sub_level > 0);

    uint8_t oct, pulse, saw, chorus;
    fm106_decode_sw1(sw1, &oct, &pulse, &saw, &chorus);
    e->dco_range    = oct;
    e->dco_pulse_on = pulse;
    e->dco_saw_on   = saw;
    e->chorus.mode  = chorus;

    uint8_t pwm_m, vcf_inv, vca_m, hpf_m;
    fm106_decode_sw2(sw2, &pwm_m, &vcf_inv, &vca_m, &hpf_m);
    e->dco_pwm_mode     = pwm_m;
    e->vcf_env_polarity = vcf_inv;
    e->vca_mode         = vca_m;
    e->hpf.mode         = hpf_m;

    /* Update voices */
    for (uint32_t i = 0; i < FM106_NUM_VOICES; i++) {
        fm106_adsr_params(&e->voice[i].adsr, e->env_a, e->env_d, e->env_s, e->env_r);
        e->voice[i].dco.saw_on      = e->dco_saw_on;
        e->voice[i].dco.pulse_on    = e->dco_pulse_on;
        e->voice[i].dco.sub_on      = e->dco_sub_on;
        e->voice[i].dco.sub_level   = e->dco_sub_level;
        e->voice[i].dco.noise_level = e->dco_noise_level;
        if (e->voice[i].note != 255u) {
            e->voice[i].base_inc = fm106_calc_inc(e->voice[i].note, 0, e->dco_range);
            if (!e->voice[i].gliding) e->voice[i].curr_inc = e->voice[i].base_inc;
        }
    }
}

/* Store 18 APR parameters into a preset slot */
static void fm106_store_apr_to_preset(fm106_preset_t *p, const uint8_t *s, uint8_t sw1, uint8_t sw2, const char *name, int is_vintage)
{
    p->name[0] = '\0';
    p->p[0]  = 64;           /* bender_dco */
    p->p[1]  = 64;           /* bender_vcf */
    p->p[2]  = 64;           /* arp_rate */
    p->p[3]  = s[0] & 0x7Fu; /* lfo_rate */
    p->p[4]  = s[1] & 0x7Fu; /* lfo_delay */
    p->p[5]  = s[2] & 0x7Fu; /* dco_lfo_depth */
    p->p[6]  = s[3] & 0x7Fu; /* dco_pwm_depth */
    p->p[7]  = s[15] & 0x7Fu;/* dco_sub_level */
    p->p[8]  = s[4] & 0x7Fu; /* dco_noise_level */

    uint8_t pwm_m, vcf_inv, vca_m, hpf_m;
    fm106_decode_sw2(sw2, &pwm_m, &vcf_inv, &vca_m, &hpf_m);
    p->p[9]  = hpf_m;
    p->p[10] = s[5] & 0x7Fu; /* vcf_cutoff */
    p->p[11] = s[6] & 0x7Fu; /* vcf_resonance */
    p->p[12] = s[7] & 0x7Fu; /* vcf_env_mod */
    p->p[13] = s[8] & 0x7Fu; /* vcf_lfo_mod */
    p->p[14] = s[9] & 0x7Fu; /* vcf_kbd_track */
    p->p[15] = s[10] & 0x7Fu;/* vca_level */
    p->p[16] = s[11] & 0x7Fu;/* env_a */
    p->p[17] = s[12] & 0x7Fu;/* env_d */
    p->p[18] = s[13] & 0x7Fu;/* env_s */
    p->p[19] = s[14] & 0x7Fu;/* env_r */

    uint8_t oct, pulse, saw, chorus;
    fm106_decode_sw1(sw1, &oct, &pulse, &saw, &chorus);
    p->p[23] = pulse;
    p->p[24] = saw;
    p->p[25] = (s[15] > 0);
    p->p[27] = (chorus == FM106_CHORUS_I || chorus == FM106_CHORUS_I_II);
    p->p[28] = (chorus == FM106_CHORUS_II || chorus == FM106_CHORUS_I_II);
    p->p[29] = oct;
    p->p[30] = 0;            /* arp_mode */
    p->p[31] = 1;            /* arp_range */
    p->p[33] = pwm_m;
    p->p[34] = vcf_inv;
    p->p[35] = vca_m;
    /* Classic APR carries no FX/assign: reset them so a stale sound never leaks in */
    p->p[36] = 0; p->p[37] = 0; p->p[38] = 0; p->p[39] = 0;
    p->p[45] = 0; p->p[46] = 0; p->p[47] = 0; p->p[48] = 0;
    p->p[49] = 2;            /* POLY I */

    if (name && name[0]) {
        while (*name == ' ') name++;
        uint32_t len = 0;
        while (name[len] && len < 15u) {
            ((char *)p->name)[len] = name[len];
            len++;
        }
        while (len > 0 && ((char *)p->name)[len - 1] == ' ') len--;
        ((char *)p->name)[len] = '\0';
    }
    if (is_vintage && p->name[0] == '\0') {
        const char *def_nm = "User Patch";
        uint32_t di = 0;
        while (def_nm[di] && di < 15u) { ((char *)p->name)[di] = def_nm[di]; di++; }
        ((char *)p->name)[di] = '\0';
    }
}

/* ---- FM-106 extended patch block (appended after the 16 name bytes of 0x30/0x31) ----
 * 15 bytes, all 7-bit: B.DCO, B.VCF, ARP RATE, ARP MODE, ARP RANGE(1..3), SUB SW,
 * TAPE TYPE, TAPE MIX, TAPE RATE, TAPE CHAR, REV ON, REV MIX, REV DECAY, REV SHIM,
 * ASSIGN (0 MONO, 1 POLY I, 2 POLY II). Old firmware ignores the extra bytes. */
#define FM106_EXT_N 15u

static void fm106_ext_from_preset(const fm106_preset_t *p, uint8_t *x)
{
    x[0]  = p->p[0] & 0x7Fu;
    x[1]  = p->p[1] & 0x7Fu;
    x[2]  = p->p[2] & 0x7Fu;
    x[3]  = p->p[30] > 2u ? 0u : p->p[30];
    x[4]  = (p->p[31] < 1u || p->p[31] > 3u) ? 1u : p->p[31];
    x[5]  = p->p[25] ? 1u : 0u;
    x[6]  = p->p[36] >= FM106_FX_COUNT ? 0u : p->p[36];
    x[7]  = p->p[37] & 0x7Fu;
    x[8]  = p->p[38] & 0x7Fu;
    x[9]  = p->p[39] & 0x7Fu;
    x[10] = p->p[45] ? 1u : 0u;
    x[11] = p->p[46] & 0x7Fu;
    x[12] = p->p[47] & 0x7Fu;
    x[13] = p->p[48] & 0x7Fu;
    x[14] = (p->p[49] == 1u) ? 0u : (p->p[49] == 3u) ? 2u : 1u;
}

static void fm106_ext_to_preset(fm106_preset_t *p, const uint8_t *x)
{
    p->p[0]  = x[0] & 0x7Fu;
    p->p[1]  = x[1] & 0x7Fu;
    p->p[2]  = x[2] & 0x7Fu;
    p->p[30] = x[3] > 2u ? 0u : x[3];
    p->p[31] = (x[4] < 1u || x[4] > 3u) ? 1u : x[4];
    p->p[25] = x[5] ? 1u : 0u;
    p->p[36] = x[6] >= FM106_FX_COUNT ? 0u : x[6];
    p->p[37] = x[7] & 0x7Fu;
    p->p[38] = x[8] & 0x7Fu;
    p->p[39] = x[9] & 0x7Fu;
    p->p[45] = x[10] ? 1u : 0u;
    p->p[46] = x[11] & 0x7Fu;
    p->p[47] = x[12] & 0x7Fu;
    p->p[48] = x[13] & 0x7Fu;
    p->p[49] = (x[14] == 0u) ? 1u : (x[14] == 2u) ? 3u : 2u;
}

/* Apply an extended block to the live engine (audition) */
static void fm106_ext_to_engine(fm106_engine_t *e, const uint8_t *x)
{
    fm106_param_set(e, 0, x[0] & 0x7Fu);
    fm106_param_set(e, 1, x[1] & 0x7Fu);
    fm106_param_set(e, 2, x[2] & 0x7Fu);
    fm106_param_set(e, 30, x[3]);
    fm106_param_set(e, 31, (x[4] < 1u || x[4] > 3u) ? 1u : x[4]);
    fm106_param_set(e, 25, x[5] ? 1u : 0u);
    fm106_param_set(e, 36, x[6]);
    fm106_param_set(e, 37, x[7] & 0x7Fu);
    fm106_param_set(e, 38, x[8] & 0x7Fu);
    fm106_param_set(e, 39, x[9] & 0x7Fu);
    fm106_param_set(e, 45, x[10] ? 1u : 0u);
    fm106_param_set(e, 46, x[11] & 0x7Fu);
    fm106_param_set(e, 47, x[12] & 0x7Fu);
    fm106_param_set(e, 48, x[13] & 0x7Fu);
    fm106_param_set(e, 49, x[14] > 2u ? 1u : x[14]);
}

/* Transmit a patch dump APR SysEx message over USB-MIDI */
static void fm106_sysex_dump_patch(uint16_t patch_idx)
{
    uint32_t bank_idx = (uint32_t)patch_idx / 65u;
    uint32_t local = (uint32_t)patch_idx % 65u;
    uint8_t bank_opt = (uint8_t)(bank_idx + 1u); /* 1=Fact A, 2=Fact B, 3=User A, 4=User B */
    uint8_t ch = (g_synth.midi_channel - 1u) & 0x0Fu;
    uint8_t ch_byte = ((bank_opt << 4) & 0x70u) | ch;

    fm106_preset_t temp_preset;
    const fm106_preset_t *p;

    if (local == 0u) {
        memset(&temp_preset, 0, sizeof(temp_preset));
        const char *nm = "A00 Init";
        if (bank_idx == 1u) nm = "B00 Init";
        else if (bank_idx == 2u) nm = "UA00 Init";
        else if (bank_idx == 3u) nm = "UB00 Init";
        uint32_t nli = 0;
        while (nm[nli] && nli < sizeof(temp_preset.name) - 1u) {
            temp_preset.name[nli] = nm[nli];
            nli++;
        }
        temp_preset.name[nli] = '\0';
        temp_preset.p[3] = 60;   /* lfo_rate */
        temp_preset.p[10] = 100; /* vcf_cutoff */
        temp_preset.p[15] = 100; /* vca_level */
        temp_preset.p[17] = 64;  /* env_d */
        temp_preset.p[18] = 127; /* env_s */
        temp_preset.p[19] = 20;  /* env_r */
        temp_preset.p[24] = 1;   /* saw_on */
        temp_preset.p[29] = 1;   /* dco_range = 8' */
        temp_preset.p[9] = 1;    /* hpf = 1 */
        p = &temp_preset;
    } else {
        uint32_t slot_in_bank = local - 1u;
        if (bank_idx < 2u) {
            p = &FM106_PRESETS[bank_idx * 64u + slot_in_bank];
        } else {
            p = &g_user_presets[(bank_idx - 2u) * 64u + slot_in_bank];
        }
    }

    uint8_t msg[40 + FM106_EXT_N];
    msg[0]  = 0xF0;
    msg[1]  = 0x41; /* Roland */
    msg[2]  = 0x30; /* APR patch format */
    msg[3]  = ch_byte;
    msg[4]  = (uint8_t)(local & 0x7Fu);

    /* 16 sliders */
    msg[5]  = p->p[3] & 0x7Fu;  /* lfo_rate */
    msg[6]  = p->p[4] & 0x7Fu;  /* lfo_delay */
    msg[7]  = p->p[5] & 0x7Fu;  /* dco_lfo_depth */
    msg[8]  = p->p[6] & 0x7Fu;  /* dco_pwm_depth */
    msg[9]  = p->p[8] & 0x7Fu;  /* dco_noise_level */
    msg[10] = p->p[10] & 0x7Fu; /* vcf_cutoff */
    msg[11] = p->p[11] & 0x7Fu; /* vcf_resonance */
    msg[12] = p->p[12] & 0x7Fu; /* vcf_env_mod */
    msg[13] = p->p[13] & 0x7Fu; /* vcf_lfo_mod */
    msg[14] = p->p[14] & 0x7Fu; /* vcf_kbd_track */
    msg[15] = p->p[15] & 0x7Fu; /* vca_level */
    msg[16] = p->p[16] & 0x7Fu; /* env_a */
    msg[17] = p->p[17] & 0x7Fu; /* env_d */
    msg[18] = p->p[18] & 0x7Fu; /* env_s */
    msg[19] = p->p[19] & 0x7Fu; /* env_r */
    msg[20] = p->p[7] & 0x7Fu;  /* dco_sub_level */

    uint8_t chorus = FM106_CHORUS_OFF;
    if (p->p[27] && p->p[28]) chorus = FM106_CHORUS_I_II;
    else if (p->p[28]) chorus = FM106_CHORUS_II;
    else if (p->p[27]) chorus = FM106_CHORUS_I;

    msg[21] = fm106_encode_sw1(p->p[29], p->p[23], p->p[24], chorus);
    msg[22] = fm106_encode_sw2(p->p[33], p->p[34], p->p[35], p->p[9]);

    /* Transmit 40-byte extended SysEx if name present, or 24-byte vintage APR if blank */
    if (p->name[0]) {
        uint32_t len = 0;
        while (p->name[len] && len < 15u) {
            msg[23 + len] = (uint8_t)p->name[len] & 0x7Fu;
            len++;
        }
        while (len < 16u) {
            msg[23 + len] = ' ';
            len++;
        }
        fm106_ext_from_preset(p, msg + 39);
        msg[39 + FM106_EXT_N] = 0xF7;
        fm106_sysex_send(msg, 40 + FM106_EXT_N);

        /* Also transmit patch name in 0x33 message for vintage compatibility */
        uint8_t nmsg[28];
        nmsg[0] = 0xF0;
        nmsg[1] = 0x41;
        nmsg[2] = 0x33;
        nmsg[3] = ch_byte;
        nmsg[4] = (uint8_t)(local & 0x7Fu);
        nmsg[5] = (uint8_t)bank_idx;
        uint32_t nlen = 0;
        while (p->name[nlen] && nlen < 15u) {
            nmsg[6 + nlen] = (uint8_t)p->name[nlen] & 0x7Fu;
            nlen++;
        }
        nmsg[6 + nlen] = 0xF7;
        fm106_sysex_send(nmsg, 7 + nlen);
    } else {
        msg[23] = 0xF7;
        fm106_sysex_send(msg, 24);
    }
}

/* Parse and process incoming Roland SysEx message (bytes after F0 up to F7) */
static void fm106_sysex_handle(const uint8_t *p, uint32_t n)
{
    if (n < 3 || p[0] != 0x41) return;

    uint8_t cmd = p[1];
    uint8_t ch  = p[2] & 0x0Fu;
    uint8_t bank_opt = (p[2] >> 4) & 0x07u;

    /* 1. IPR (Individual Parameter Real-Time): 41 32 0n ctrl val */
    if (cmd == 0x32 && n >= 5) {
        uint8_t ctrl = p[3];
        uint8_t val  = p[4] & 0x7Fu;

        if (ctrl <= 0x0Fu) {
            switch (ctrl) {
            case 0x00: g_synth.lfo_rate = val; break;
            case 0x01: g_synth.lfo_delay = val; break;
            case 0x02: g_synth.dco_lfo_depth = val; break;
            case 0x03: g_synth.dco_pwm_depth = val; break;
            case 0x04: g_synth.dco_noise_level = val;
                       for (uint32_t v=0; v<FM106_NUM_VOICES; v++) g_synth.voice[v].dco.noise_level = val;
                       break;
            case 0x05: g_synth.vcf_cutoff = val; break;
            case 0x06: g_synth.vcf_resonance = val; break;
            case 0x07: g_synth.vcf_env_mod = val; break;
            case 0x08: g_synth.vcf_lfo_mod = val; break;
            case 0x09: g_synth.vcf_kbd_track = val; break;
            case 0x0A: g_synth.vca_level = val; break;
            case 0x0B: g_synth.env_a = val;
                       for (uint32_t v=0; v<FM106_NUM_VOICES; v++) fm106_adsr_params(&g_synth.voice[v].adsr, g_synth.env_a, g_synth.env_d, g_synth.env_s, g_synth.env_r);
                       break;
            case 0x0C: g_synth.env_d = val;
                       for (uint32_t v=0; v<FM106_NUM_VOICES; v++) fm106_adsr_params(&g_synth.voice[v].adsr, g_synth.env_a, g_synth.env_d, g_synth.env_s, g_synth.env_r);
                       break;
            case 0x0D: g_synth.env_s = val;
                       for (uint32_t v=0; v<FM106_NUM_VOICES; v++) fm106_adsr_params(&g_synth.voice[v].adsr, g_synth.env_a, g_synth.env_d, g_synth.env_s, g_synth.env_r);
                       break;
            case 0x0E: g_synth.env_r = val;
                       for (uint32_t v=0; v<FM106_NUM_VOICES; v++) fm106_adsr_params(&g_synth.voice[v].adsr, g_synth.env_a, g_synth.env_d, g_synth.env_s, g_synth.env_r);
                       break;
            case 0x0F: g_synth.dco_sub_level = val;
                       g_synth.dco_sub_on = (val > 0);
                       for (uint32_t v=0; v<FM106_NUM_VOICES; v++) {
                           g_synth.voice[v].dco.sub_level = val;
                           g_synth.voice[v].dco.sub_on = g_synth.dco_sub_on;
                       }
                       break;
            }
        } else if (ctrl == 0x10) {
            /* SW1 */
            uint8_t oct, pulse, saw, chorus;
            fm106_decode_sw1(val, &oct, &pulse, &saw, &chorus);
            g_synth.dco_range    = oct;
            g_synth.dco_pulse_on = pulse;
            g_synth.dco_saw_on   = saw;
            g_synth.chorus.mode  = chorus;
            for (uint32_t v=0; v<FM106_NUM_VOICES; v++) {
                g_synth.voice[v].dco.pulse_on = pulse;
                g_synth.voice[v].dco.saw_on   = saw;
                if (g_synth.voice[v].note != 255u) {
                    g_synth.voice[v].base_inc = fm106_calc_inc(g_synth.voice[v].note, 0, oct);
                    if (!g_synth.voice[v].gliding) g_synth.voice[v].curr_inc = g_synth.voice[v].base_inc;
                }
            }
        } else if (ctrl == 0x11) {
            /* SW2 */
            uint8_t pwm_m, vcf_inv, vca_m, hpf_m;
            fm106_decode_sw2(val, &pwm_m, &vcf_inv, &vca_m, &hpf_m);
            g_synth.dco_pwm_mode     = pwm_m;
            g_synth.vcf_env_polarity = vcf_inv;
            g_synth.vca_mode         = vca_m;
            g_synth.hpf.mode         = hpf_m;
        } else if (ctrl == 0x12) {
            /* Voice Assign Mode: 0 = MONO, 1 = POLY I, 2 = POLY II */
            fm106_set_voice_mode(&g_synth, val > 2u ? FM106_MODE_POLY1 : val);
        } else if (ctrl == 0x13) {
            /* Arpeggiator on/off (live performance state) */
            fm106_arp_enable(&g_synth, val ? 1 : 0);
        } else if (ctrl >= 0x40u && (uint32_t)(ctrl - 0x40u) < FM106_NPARAM) {
            /* Extended IPR: 0x40 + engine param index (B.DCO, ARP, TAPE, REVERB, ...) */
            fm106_param_set(&g_synth, (uint8_t)(ctrl - 0x40u), val);
        }
        g_dirty_screen = 1;
        return;
    }

    /* 2. APR Manual Mode (Audition to live buffer): 41 31 0n pp [16 sliders] [sw1] [sw2] */
    if (cmd == 0x31 && n >= 22) {
        fm106_apply_apr_to_engine(&g_synth, p + 4, p[20], p[21]);
        if (n >= 38) {
            uint32_t len = 0;
            while (len < 15u && (22u + len) < n && p[22 + len]) {
                g_synth.patch_name[len] = (char)p[22 + len];
                len++;
            }
            g_synth.patch_name[len] = '\0';
        }
        if (n >= 38u + FM106_EXT_N) fm106_ext_to_engine(&g_synth, p + 38);
        g_dirty_screen = 1;
        return;
    }

    /* 3. APR Patch Store to Slot: 41 30 0n pp [16 sliders] [sw1] [sw2] (opt: name) */
    if (cmd == 0x30 && n >= 22) {
        uint8_t user_slot;
        if (bank_opt == 3u) {
            user_slot = p[3] % 64u;         /* Explicit User A: 0..63 */
        } else if (bank_opt == 4u) {
            user_slot = 64u + (p[3] % 64u); /* Explicit User B: 64..127 */
        } else {
            user_slot = p[3] % FM106_NUM_USER_PRESETS; /* Standard 0..127 */
        }
        char nm[16] = {0};
        if (n >= 38) {
            for (uint32_t i = 0; i < 15u && (22u + i) < n; i++) nm[i] = (char)p[22 + i];
        }
        fm106_store_apr_to_preset(&g_user_presets[user_slot], p + 4, p[20], p[21], nm[0] ? nm : 0, (n < 38u));
        if (n >= 38u + FM106_EXT_N) fm106_ext_to_preset(&g_user_presets[user_slot], p + 38);

        uint16_t cur_user_patch = fm106_user_slot_to_patch(user_slot);
        if (cur_user_patch == g_synth.patch_idx) {
            fm106_load_user_preset(&g_synth, cur_user_patch);
            g_dirty_screen = 1;
        }
        return;
    }

    /* 4. Patch Rename: 41 33 0n pp [name bytes] */
    if (cmd == 0x33 && n >= 5) {
        uint8_t user_slot;
        if (bank_opt == 3u) {
            user_slot = p[3] % 64u;
        } else if (bank_opt == 4u) {
            user_slot = 64u + (p[3] % 64u);
        } else {
            user_slot = p[3] % FM106_NUM_USER_PRESETS;
        }
        uint32_t len = 0;
        while (len < 15u && (4u + len) < n && p[4 + len]) {
            ((char *)g_user_presets[user_slot].name)[len] = (char)p[4 + len];
            len++;
        }
        ((char *)g_user_presets[user_slot].name)[len] = '\0';
        uint16_t cur_user_patch = fm106_user_slot_to_patch(user_slot);
        if (cur_user_patch == g_synth.patch_idx) {
            for (uint32_t i = 0; i < 16u; i++) {
                g_synth.patch_name[i] = g_user_presets[user_slot].name[i];
            }
            g_dirty_screen = 1;
        }
        return;
    }

    /* 5. Request Patch Dump: 41 34 0n pp */
    if (cmd == 0x34 && n >= 4) {
        uint16_t target_patch;
        uint32_t local = p[3] % 65u;
        if (bank_opt == 1u) {
            target_patch = (uint16_t)local;
        } else if (bank_opt == 2u) {
            target_patch = (uint16_t)(65u + local);
        } else if (bank_opt == 3u) {
            target_patch = (uint16_t)(130u + local);
        } else if (bank_opt == 4u) {
            target_patch = (uint16_t)(195u + local);
        } else {
            /* Vintage Roland fallback: follows active synth bank */
            uint32_t cur_bank = (uint32_t)g_synth.patch_idx / 65u;
            target_patch = (uint16_t)(cur_bank * 65u + local);
        }
        fm106_sysex_dump_patch(target_patch);
        return;
    }

    /* 6. Commit All User Presets to SPI Flash: 41 35 0n 01 */
    if (cmd == 0x35 && n >= 4 && p[3] == 0x01) {
        fm106_user_presets_save_flash();
        g_dirty_screen = 1;
        /* Send ACK */
        uint8_t ack[6] = {0xF0, 0x41, 0x35, ch, 0x00, 0xF7};
        fm106_sysex_send(ack, sizeof(ack));
        return;
    }

    /* 7. Reset User Presets to Factory Defaults: 41 36 0n 01 */
    if (cmd == 0x36 && n >= 4 && p[3] == 0x01) {
        fm106_user_presets_restore_factory();
        fm106_user_presets_save_flash();
        fm106_load_user_preset(&g_synth, g_synth.patch_idx);
        uint8_t ack[6] = {0xF0, 0x41, 0x36, ch, 0x00, 0xF7};
        fm106_sysex_send(ack, sizeof(ack));
        g_dirty_screen = 1;
        return;
    }

    /* 8. Remote Patch / Bank Select: 41 37 0n pp */
    if (cmd == 0x37 && n >= 4) {
        uint16_t target_patch;
        if (bank_opt >= 1u && bank_opt <= 4u) {
            target_patch = (uint16_t)((bank_opt - 1u) * 65u + (p[3] % 65u));
        } else {
            target_patch = (uint16_t)(p[3] % 260u);
        }
        fm106_load_user_preset(&g_synth, target_patch);
        g_dirty_screen = 1;
        fm106_sysex_dump_patch(target_patch);
        return;
    }

    /* 9. Diagnostic / Battery Query: 41 39 0n */
    if (cmd == 0x39) {
        int32_t bval = fm1_adc_read(FM1_ADC_BATT);
        if (bval < 0) bval = 0;
        uint8_t resp[7] = {0xF0, 0x41, 0x39, ch, (uint8_t)((bval >> 7) & 0x7Fu), (uint8_t)(bval & 0x7Fu), 0xF7};
        fm106_sysex_send(resp, 7);
        return;
    }

    /* 10. Crash & Diag Query: 41 3A 0n */
    if (cmd == 0x3A) {
        uint8_t resp[310];
        resp[0] = 0xF0;
        resp[1] = 0x41;
        resp[2] = 0x3A;
        resp[3] = ch;
        uint32_t pos = 4;

        /* 16 words of fm1_crash */
        const uint32_t *cw = (const uint32_t *)&fm1_crash;
        for (uint32_t i = 0; i < 16u; i++) {
            uint32_t w = cw[i];
            resp[pos++] = (uint8_t)(w & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 7) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 14) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 21) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 28) & 0x0Fu);
        }

        /* 20 words of fm1_crash_ctx */
        uint32_t cidx = (fm1_crash.magic == FM1_CRASH_MAGIC) ? (fm1_crash.count % FM1_CRASH_CTX_N) : 0u;
        const uint32_t *xw = (const uint32_t *)&fm1_crash_ctx[cidx];
        for (uint32_t i = 0; i < 20u; i++) {
            uint32_t w = xw[i];
            resp[pos++] = (uint8_t)(w & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 7) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 14) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 21) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 28) & 0x0Fu);
        }

        /* 16 words of BLE diag */
        uint32_t bd[16];
#if FELUCCA_BLE
        ble_ui_get_diag(bd);
#else
        memset(bd, 0, sizeof(bd));
#endif
        for (uint32_t i = 0; i < 16u; i++) {
            uint32_t w = bd[i];
            resp[pos++] = (uint8_t)(w & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 7) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 14) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 21) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 28) & 0x0Fu);
        }

        /* 8 words of system diag: reset cause, where the last run was, BT store, CPU1 worker */
        uint32_t sd[8];
        sd[0] = fm1_boot.p3_rst;                /* bit2 watchdog, bit6 soft reset, bit0 power-on */
        sd[1] = g_where_boot;                   /* the main loop's step when the last run ended */
#if FELUCCA_BLE
        sd[2] = bt_st_diag();
#else
        sd[2] = 0;
#endif
#if DINGHY_DUAL_CORE
        sd[3] = audio_worker.timeouts;
        sd[4] = audio_worker.max_wait_ticks;
        sd[7] = audio_worker.jobs;
#else
        sd[3] = 0;
        sd[4] = 0;
        sd[7] = 0;
#endif
        sd[5] = audio_lates;
        sd[6] = fm1_ms;
        for (uint32_t i = 0; i < 8u; i++) {
            uint32_t w = sd[i];
            resp[pos++] = (uint8_t)(w & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 7) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 14) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 21) & 0x7Fu);
            resp[pos++] = (uint8_t)((w >> 28) & 0x0Fu);
        }

        resp[pos++] = 0xF7;
        fm106_sysex_send(resp, pos);
        return;
    }

    /* 11. Bluetooth Control: 41 3B 0n act (1=ON, 2=OFF, 3=SCAN_START, 4=SCAN_CLOSE) */
    if (cmd == 0x3B && n >= 4) {
        uint8_t act = p[3];
#if FELUCCA_BLE
        if (act == 1) bt_page_on();
        else if (act == 2) bt_page_off();
        else if (act == 3) {
            g_where = 0x81;
            bt_page_on();
            g_where = 0x82;
            bt_host_scan_start();
            g_where = 0x83;
            g_ui_mode = UI_MODE_BT_SCAN;
            g_bt_scan_sel = 0;
        }
        else if (act == 4) {
            bt_add_close();
            g_ui_mode = UI_MODE_BLUETOOTH;
        }
#endif
        uint8_t ack[6] = {0xF0, 0x41, 0x3B, ch, act, 0xF7};
        fm106_sysex_send(ack, sizeof(ack));
        g_dirty_screen = 1;
        return;
    }
}

