MONK-1 0.10 for the BBL Mod Swapper

Original by charlesvestal: https://github.com/charlesvestal/fm1-monk
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: MONK1-source.zip on the ports page.
