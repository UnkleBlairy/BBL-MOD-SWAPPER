/* SPDX-License-Identifier: GPL-3.0-only */
/* Portions Copyright (C) 2026 Kerem Kilic (Ellic Studio) */
/* The render in passes over sub-blocks, the drive in passes, the oversampling loop per wave, the fixed
 * coefficients shared by every instance (bass303_k) and the cold paths' maths out of line: after Optimist
 * (henri / hdavid, github.com/w0ts/optimist 7faf1452, 3b695372, 50a5ed5a, b735cf0d, 0a9fcfcb, a64ca03b, d6eef1d9,
 * GPL-3.0-only); the same samples, bit for bit (tests/host/dsp_hash_test.c). */
/* X0X TB-303 bass engine - see bass303.h for what is ported and what is not.
 *
 * Reference: schwung-303 src/dsp/open303/rosic_Open303.{h,cpp} (getSample, triggerNote,
 * slideToNote, calculateEnvModScalerAndOffset), rosic_TeeBeeFilter.h (TB_303 mode),
 * rosic_AnalogEnvelope / DecayEnvelope / LeakyIntegrator / OnePoleFilter / BiquadFilter,
 * rosic_MipMappedWaveTable.cpp (fillWithSaw303 / fillWithSquare303), src/dsp/plugin.cpp
 * (pot ranges) and src/dsp/drive.h (Soft / RAT). */
#include "bass303.h"
#include "fastmath.h"

#define FSO (BASS303_SR * (float)BASS303_OS)    /* oversampled rate */

/* The maths of the cold paths (pots, init, notes, idle) out of line: one copy of each function instead of one
 * per call site (the same code, so the same values: no fused multiply-add across a call either way). The
 * render keeps its inline calls. */
#define BASS303_COLD __attribute__((noinline))
static BASS303_COLD float c_expf(float x) { return fm_expf(x); }
static BASS303_COLD float c_exp2f(float x) { return fm_exp2f(x); }
static BASS303_COLD float c_log2f(float x) { return fm_log2f(x); }
static BASS303_COLD float c_powf(float x, float y) { return fm_powf(x, y); }
static BASS303_COLD float c_sinf(float x) { return fm_sinf(x); }
static BASS303_COLD float c_cosf(float x) { return fm_cosf(x); }
static float c_db2lin(float db) { return c_exp2f(db * 0.166096405f); }      /* fm_db2lin */
/* The render's passes (one call a sub-block): each register-allocated on its own, so a change elsewhere in the
 * render does not reshuffle (and spill) the hot loops */
#define BASS303_PASS __attribute__((noinline))
/* Unroll the loop that follows by two: clang's pragma; other compilers (the host tests' gcc) unroll as they choose */
#if defined(__clang__)
#define BASS303_UNROLL2 _Pragma("clang loop unroll_count(2)")
#else
#define BASS303_UNROLL2
#endif

static bass303_fixed_t bass303_k;     /* the coefficients every instance shares (bass303.h) */

/* ---- parameters ------------------------------------------------------------------------ */

static const char *const wave_names[] = { "Saw", "Sqr" };
static const char *const drv_names[] = { "Off", "Soft", "RAT" };

/* defaults are schwung-303's (every knob at 0.5, Devilfish values stock), except Volume,
 * lowered from 0.8 so the nominal peak is ~0.5 */
static const x0x_param_t params[BASS303_NPARAMS] = {
    { "Cutoff", 127, 64, 0 },        /* 314 .. 2394 Hz, exponential */
    { "Reso", 127, 64, 0 },          /* 0 .. 100 % */
    { "EnvMod", 127, 64, 0 },        /* 0 .. 100 % */
    { "Decay", 127, 64, 0 },         /* 200 .. 2000 ms, exponential (stock 303 range) */
    { "Accent", 127, 64, 0 },        /* 0 .. 100 % */
    { "Wave", 1, 0, wave_names },
    { "Tune", 127, 64, 0 },          /* A4 = 440 + (pot - 64) * 0.625 Hz: 400 .. 479.4 */
    { "Volume", 127, 96, 0 },        /* -60 .. 0 dB; 96 = -14.6 dB: peaks ~0.5 (schwung-303: 102) */
    { "Drive", 127, 0, 0 },          /* 0 = bypass */
    { "DrvTyp", 2, 1, drv_names },
    { "Slide", 127, 21, 0 },         /* 2 .. 360 ms (Devilfish); 21 = 61 ms, stock is 60 */
    { "AccDec", 127, 7, 0 },         /* 30 .. 3000 ms (Devilfish); 7 = 194 ms, stock is 200 */
};

/* ---- drive scaling (X0X; not in drive.h) ------------------------------------------------
 * The drive always sees the voice at one level, DRV_REF, and Volume is applied after it, so
 * Volume no longer sets how hard the drive is hit. A makeup gain per Drive value keeps the
 * loudness level with Drive 0 (K-weighted, ITU-R BS.1770, measured on tools/drive_line.h's
 * acid line, patch 0), and a deliberate rise on top of it, linear in dB, reaches +3 dB at full
 * Drive. Drive 0 is still a bypass. tools/measure_drive_makeup.py measures the tables;
 * re-measure them after changing what the drive does to the level. */
#define DRV_REF 0.18620871f              /* -14.6 dB: about Volume 96's level (-14.65 dB) */
#define DRV_RISE 3.0f
#define RAT_TONE_HZ 936.48098f           /* the stock tone: 1 / (2 pi (0.5 * 100k + 1.5k) 3.3n) */

static const float makeup_soft[128] = {
    1.0000f, 1.0294f, 1.0329f, 1.0366f, 1.0403f, 1.0444f, 1.0485f, 1.0531f,
    1.0576f, 1.0627f, 1.0678f, 1.0734f, 1.0790f, 1.0854f, 1.0919f, 1.0983f,
    1.1049f, 1.1124f, 1.1200f, 1.1277f, 1.1354f, 1.1442f, 1.1530f, 1.1619f,
    1.1708f, 1.1813f, 1.1918f, 1.2024f, 1.2131f, 1.2238f, 1.2347f, 1.2457f,
    1.2568f, 1.2698f, 1.2829f, 1.2961f, 1.3095f, 1.3230f, 1.3366f, 1.3504f,
    1.3643f, 1.3802f, 1.3962f, 1.4123f, 1.4287f, 1.4453f, 1.4620f, 1.4790f,
    1.4961f, 1.5152f, 1.5345f, 1.5541f, 1.5739f, 1.5940f, 1.6143f, 1.6349f,
    1.6558f, 1.6787f, 1.7019f, 1.7254f, 1.7492f, 1.7734f, 1.7979f, 1.8228f,
    1.8480f, 1.8752f, 1.9029f, 1.9311f, 1.9596f, 1.9885f, 2.0179f, 2.0477f,
    2.0780f, 2.1104f, 2.1433f, 2.1768f, 2.2107f, 2.2452f, 2.2803f, 2.3159f,
    2.3520f, 2.3904f, 2.4294f, 2.4691f, 2.5094f, 2.5504f, 2.5920f, 2.6343f,
    2.6773f, 2.7227f, 2.7688f, 2.8157f, 2.8633f, 2.9118f, 2.9611f, 3.0113f,
    3.0623f, 3.1157f, 3.1701f, 3.2253f, 3.2816f, 3.3389f, 3.3971f, 3.4564f,
    3.5166f, 3.5794f, 3.6434f, 3.7084f, 3.7746f, 3.8420f, 3.9107f, 3.9805f,
    4.0516f, 4.1252f, 4.2002f, 4.2766f, 4.3543f, 4.4334f, 4.5140f, 4.5961f,
    4.6796f, 4.7657f, 4.8534f, 4.9427f, 5.0337f, 5.1263f, 5.2206f, 5.3166f,
};
static const float makeup_rat[128] = {
    1.0000f, 1.6276f, 1.6302f, 1.6332f, 1.5906f, 1.5451f, 1.5002f, 1.4562f,
    1.4136f, 1.3730f, 1.3335f, 1.2973f, 1.2621f, 1.2332f, 1.2050f, 1.1775f,
    1.1506f, 1.1342f, 1.1181f, 1.1022f, 1.0865f, 1.0826f, 1.0788f, 1.0750f,
    1.0712f, 1.0785f, 1.0859f, 1.0934f, 1.1009f, 1.1171f, 1.1335f, 1.1502f,
    1.1671f, 1.1631f, 1.1350f, 1.1077f, 1.0810f, 1.0554f, 1.0304f, 1.0059f,
    0.9821f, 0.9603f, 0.9389f, 0.9180f, 0.8976f, 0.8776f, 0.8581f, 0.8390f,
    0.8204f, 0.8041f, 0.7882f, 0.7726f, 0.7573f, 0.7423f, 0.7276f, 0.7132f,
    0.6990f, 0.6868f, 0.6747f, 0.6629f, 0.6512f, 0.6398f, 0.6286f, 0.6176f,
    0.6067f, 0.5972f, 0.5878f, 0.5785f, 0.5694f, 0.5604f, 0.5516f, 0.5429f,
    0.5344f, 0.5269f, 0.5196f, 0.5123f, 0.5052f, 0.4981f, 0.4912f, 0.4843f,
    0.4776f, 0.4717f, 0.4660f, 0.4603f, 0.4547f, 0.4492f, 0.4437f, 0.4383f,
    0.4330f, 0.4284f, 0.4239f, 0.4195f, 0.4151f, 0.4107f, 0.4064f, 0.4021f,
    0.3979f, 0.3945f, 0.3912f, 0.3880f, 0.3847f, 0.3815f, 0.3783f, 0.3751f,
    0.3720f, 0.3696f, 0.3672f, 0.3648f, 0.3624f, 0.3600f, 0.3576f, 0.3553f,
    0.3530f, 0.3508f, 0.3487f, 0.3466f, 0.3446f, 0.3425f, 0.3404f, 0.3384f,
    0.3363f, 0.3340f, 0.3318f, 0.3295f, 0.3272f, 0.3250f, 0.3228f, 0.3206f,
};

int bass303_nparams(void) { return BASS303_NPARAMS; }

const x0x_param_t *bass303_param(int i)
{
    return (i >= 0 && i < BASS303_NPARAMS) ? &params[i] : 0;
}

int bass303_get(const bass303_t *b, int i)
{
    return (i >= 0 && i < BASS303_NPARAMS) ? b->pot[i] : 0;
}

/* exp(-1/(tau_ms * fs / 1000)): one-pole / RC coefficient */
static float rc_coeff(float tau_ms, float fs)
{
    return tau_ms > 0.0f ? c_expf(-1000.0f / (tau_ms * fs)) : 0.0f;
}

/* pw[m] = c^m, m = 0..BASS303_CTRL */
static void powers(float *pw, float c)
{
    int m;
    pw[0] = 1.0f;
    for (m = 1; m <= BASS303_CTRL; m++)
        pw[m] = pw[m - 1] * c;
}

/* the main envelope's multiplier changed: its powers, and the closed-form gains of the two RC
 * followers it drives, g[m] = (1-a) sum_{n=1..m} a^(m-n) c^n (so r_m = a^m r_0 + g[m] e_0) */
static void env_tables(bass303_t *b)
{
    int m;
    powers(b->env_pw, b->env_c);
    b->g1[0] = b->g2[0] = 0.0f;
    for (m = 1; m <= BASS303_CTRL; m++) {
        b->g1[m] = bass303_k.rc1_c * b->g1[m - 1] + (1.0f - bass303_k.rc1_c) * b->env_pw[m];
        b->g2[m] = bass303_k.rc2_c * b->g2[m - 1] + (1.0f - bass303_k.rc2_c) * b->env_pw[m];
    }
}

/* Open303::calculateEnvModScalerAndOffset, the measured mapping */
static void calc_envmod(bass303_t *b)
{
    float e = (float)b->pot[BASS303_ENVMOD] * (1.0f / 127.0f);
    float c = c_log2f(b->cutoff * (1.0f / 313.8152786f)) * (1.0f / 2.931683907f); /* log2(c1/c0) */
    float slo = 3.773996325f * e + 0.736965594f;
    float shi = 4.194548788f * e + 0.864344901f;
    b->env_scaler = (1.0f - c) * slo + c * shi;
    b->env_offset = 0.048292931f * c + 0.294391201f;
}

/* drive.h set_lowpass / set_low_shelf (TDF-II coefficients, a0-normalised) */
static void bq_lowpass(bass303_bq_t *q, float fc, float fs)
{
    float w = FM_TWO_PI * fc / fs, cs = c_cosf(w), sn = c_sinf(w);
    float alpha = sn * 0.707106781f, a0 = 1.0f + alpha;     /* sn / (2 q), q = 1/sqrt2 */
    q->b0 = 0.5f * (1.0f - cs) / a0;
    q->b1 = (1.0f - cs) / a0;
    q->b2 = q->b0;
    q->a1 = -2.0f * cs / a0;
    q->a2 = (1.0f - alpha) / a0;
}

static void bq_low_shelf(bass303_bq_t *q, float fc, float gain_db, float fs)
{
    float A = c_db2lin(0.5f * gain_db);                       /* 10^(g/40) */
    float w = FM_TWO_PI * fc / fs, cs = c_cosf(w), sn = c_sinf(w);
    float alpha = sn * 0.707106781f;                           /* S = 1: sn/2 * sqrt(2) */
    float s2 = 2.0f * fm_sqrtf(A) * alpha;
    float a0 = (A + 1.0f) + (A - 1.0f) * cs + s2;
    q->b0 = A * ((A + 1.0f) - (A - 1.0f) * cs + s2) / a0;
    q->b1 = 2.0f * A * ((A - 1.0f) - (A + 1.0f) * cs) / a0;
    q->b2 = A * ((A + 1.0f) - (A - 1.0f) * cs - s2) / a0;
    q->a1 = -2.0f * ((A - 1.0f) + (A + 1.0f) * cs) / a0;
    q->a2 = ((A + 1.0f) + (A - 1.0f) * cs - s2) / a0;
}

/* Return the gain in dB at Volume v (the voice's level; with the drive on, after it). */
static float vol_db(int v) { return -60.0f + 60.0f * ((float)v * (1.0f / 127.0f)); }

/* Return Soft's input gain in dB at Drive d (0..127, between the steps too while it slews), at the drive's
 * fixed input level DRV_REF: -2 + 32 t^0.75 dB, t = d / 127. Even in dB, the knob's first quarter barely
 * distorts; the curve moves more of the change to the bottom, with the same gain at both ends. */
static float soft_db(float d)
{
    if (d <= 0.0f)
        return -2.0f;
    return -2.0f + 32.0f * c_exp2f(0.75f * c_log2f(d * (1.0f / 127.0f)));
}

/* Return where Drive d is on the RAT's taper, 0..1 over Drive 1..127. */
static float rat_t(float d)
{
    return fm_clampf((d - 1.0f) * (1.0f / 126.0f), 0.0f, 1.0f);
}

/* Return the RAT's distortion resistance, 0..1 (drive.h's dist), at Drive d. drive.h maps the
 * knob to it linearly, so the op-amp's gain at 1 kHz, 1 + dist * 100k / |Z1| (|Z1| ~ 81 ohm), is
 * already +21 dB at the first step and most of the knob is used up in its first tenth. Here the knob
 * is linear in that gain in dB, up to drive.h's maximum (dist = 1, ~61.8 dB). */
static float rat_dist(float d)
{
    float t = rat_t(d);
    if (t <= 0.0f)
        return 0.0f;
    return fm_minf((c_db2lin(61.8f * t) - 1.0f) * 81e-5f, 1.0f);
}

/* Set the RAT's tone one-pole (drive.h: fixed at the stock 936 Hz) for the current Drive: open to
 * 12 kHz at the bottom of the taper, closing, log-interpolated, to the stock tone a quarter of the
 * way up (Drive ~33), about where the distortion's harmonics make up for it. So low Drive brightens
 * the voice, as the distortion would, instead of dulling it before the distortion arrives; open for
 * longer, it leaves the op-amp's mid boost unchecked and the voice hollow. */
static void rat_tone(bass303_t *b)
{
    float u = fm_minf(4.0f * rat_t(b->drv_x), 1.0f);
    float fc = RAT_TONE_HZ * c_exp2f((1.0f - u) * 3.6796409f);   /* log2(12000 / RAT_TONE_HZ) */
    b->r_tone_b1 = c_expf(-FM_TWO_PI / BASS303_SR * fc);
}

/* Set the gain after the drive for the current Drive: the makeup (interpolated between the steps) with its
 * rise. */
static void drv_gains(bass303_t *b)
{
    const float x = b->drv_x, *t = b->drv_cur == BASS303_DRV_RAT ? makeup_rat : makeup_soft;
    int p = (int)x;
    float rise = DRV_RISE * x * (1.0f / 127.0f), f = x - (float)p, m = t[p];
    if (f > 0.0f && p < 127)
        m += (t[p + 1] - m) * f;
    b->drv_makeup = m * c_db2lin(rise);
}

/* Return the gain after the drive: Volume and the makeup (the drive runs at DRV_REF). */
static float drv_out_gain(const bass303_t *b) { return b->vol_g * (1.0f / DRV_REF) * b->drv_makeup; }

/* Return whether the drive is on (a type, and Drive above 0). */
static int drive_on(const bass303_t *b) { return b->drv_type != BASS303_DRV_OFF && b->pot[BASS303_DRIVE] > 0; }

/* The migration of a project saved before the drive was rescaled (project.c, sound revision 7):
 * the new Drive and Volume that sound as an old setting did.
 *
 * Soft: the same level into its shaper, to the nearest Drive value, so its output is the old one
 * times the makeup, which the Volume takes back out. Past the new range's top (old Volume above
 * about 106, with Drive high) the new maximum saturates less than the old setting did; the Volume
 * still matches the level, to within about 1 dB. (tools/fit_drive_migration.py --check measures
 * both types.)
 *
 * RAT: drive.h's dist sets the op-amp's tone as well as its gain, so no rule in its gain matches
 * the sound. tools/fit_drive_migration.py measures it instead: for each old (Volume, Drive), the
 * new Drive closest in spectral shape and the Volume that matches its loudness, at a grid of
 * nodes (Volume every 8; Drive denser low down, where the old gain rose fastest), interpolated
 * between them. The Drive table is monotone, so a lane sweeping either pot moves it one way, and
 * smooth: where the old knob hardly changed the sound, nor does the mapping. */
/* tools/fit_drive_migration.py, from here to the end of rat_mig_volume */
#define RAT_MIG_NV 17
#define RAT_MIG_ND 20
static const uint8_t rat_mig_vn[RAT_MIG_NV] = {0, 8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 127};
static const uint8_t rat_mig_dn[RAT_MIG_ND] = {1, 2, 4, 8, 12, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 127};
static const uint8_t rat_mig_drive[RAT_MIG_NV][RAT_MIG_ND] = {
    { 45,  45,  45,  45,  45,  46,  50,  58,  77,  85,  94, 103, 109, 114, 118, 121, 123, 124, 125, 126},
    { 45,  45,  45,  45,  45,  46,  50,  58,  77,  85,  94, 103, 109, 114, 118, 121, 123, 124, 125, 126},
    { 45,  45,  45,  45,  45,  46,  51,  59,  77,  85,  95, 104, 110, 114, 118, 121, 123, 124, 125, 126},
    { 45,  45,  45,  45,  45,  47,  53,  63,  77,  85,  95, 105, 111, 115, 119, 121, 123, 124, 125, 126},
    { 45,  45,  45,  45,  45,  48,  56,  69,  78,  86,  96, 106, 112, 116, 119, 121, 123, 124, 125, 126},
    { 45,  45,  45,  45,  48,  52,  62,  74,  83,  92, 100, 107, 112, 116, 119, 121, 123, 124, 125, 126},
    { 45,  45,  45,  45,  49,  55,  69,  80,  89,  97, 103, 109, 113, 116, 119, 121, 123, 124, 125, 126},
    { 45,  45,  45,  49,  55,  62,  76,  86,  94, 101, 106, 111, 114, 117, 119, 121, 123, 124, 125, 126},
    { 47,  47,  47,  55,  63,  70,  82,  91,  98, 104, 108, 112, 115, 117, 119, 121, 123, 124, 125, 126},
    { 50,  50,  52,  63,  71,  78,  88,  95, 101, 106, 110, 113, 116, 118, 120, 122, 123, 124, 125, 126},
    { 54,  54,  59,  70,  78,  84,  93,  99, 104, 108, 111, 114, 116, 118, 120, 122, 123, 124, 125, 126},
    { 60,  60,  67,  77,  84,  89,  96, 102, 106, 109, 112, 115, 117, 119, 121, 122, 123, 124, 125, 126},
    { 66,  67,  74,  83,  88,  93,  99, 103, 107, 110, 113, 115, 117, 119, 121, 122, 123, 124, 125, 126},
    { 72,  74,  80,  87,  92,  96, 101, 105, 108, 111, 113, 115, 117, 119, 121, 122, 123, 124, 125, 126},
    { 78,  80,  85,  91,  95,  98, 102, 105, 108, 111, 113, 115, 117, 119, 121, 122, 123, 124, 125, 126},
    { 83,  85,  89,  94,  97,  99, 103, 106, 109, 111, 113, 115, 117, 119, 121, 122, 123, 124, 125, 126},
    { 86,  87,  91,  95,  98, 100, 103, 106, 109, 111, 113, 115, 117, 119, 121, 122, 123, 124, 125, 126},
};
static const uint8_t rat_mig_volume[RAT_MIG_NV][RAT_MIG_ND] = {
    { 12,  23,  35,  47,  53,  58,  64,  67,  68,  69,  70,  71,  72,  73,  74,  75,  76,  77,  78,  79},
    { 20,  31,  43,  55,  61,  65,  71,  74,  75,  76,  77,  78,  79,  80,  81,  82,  83,  84,  85,  85},
    { 28,  39,  51,  62,  68,  72,  78,  81,  81,  82,  83,  84,  85,  86,  87,  88,  88,  89,  90,  91},
    { 36,  47,  58,  69,  75,  79,  84,  86,  87,  88,  88,  89,  90,  91,  92,  93,  93,  94,  95,  96},
    { 44,  55,  66,  76,  81,  85,  89,  90,  91,  92,  93,  93,  94,  95,  96,  97,  98,  98,  99, 100},
    { 51,  62,  73,  82,  87,  90,  93,  94,  95,  96,  97,  97,  98,  99, 100, 100, 101, 102, 102, 103},
    { 59,  69,  79,  87,  91,  94,  96,  97,  98,  99, 100, 101, 101, 102, 103, 103, 104, 105, 105, 105},
    { 66,  76,  85,  92,  95,  97,  99, 100, 101, 102, 103, 103, 104, 105, 105, 106, 106, 107, 107, 107},
    { 73,  82,  90,  95,  98,  99, 101, 103, 104, 104, 105, 106, 106, 107, 107, 108, 108, 108, 108, 109},
    { 79,  87,  94,  98, 100, 102, 104, 105, 106, 107, 107, 108, 108, 108, 109, 109, 109, 109, 109, 110},
    { 85,  92,  97, 101, 103, 104, 106, 107, 108, 108, 108, 109, 109, 109, 109, 110, 110, 110, 110, 110},
    { 90,  95,  99, 103, 105, 106, 107, 108, 109, 109, 109, 109, 110, 110, 110, 110, 110, 110, 110, 111},
    { 93,  98, 101, 105, 106, 107, 108, 109, 109, 109, 110, 110, 110, 110, 110, 110, 110, 111, 111, 111},
    { 96, 100, 104, 106, 107, 108, 109, 109, 110, 110, 110, 110, 110, 110, 110, 110, 111, 111, 111, 111},
    { 99, 102, 105, 107, 108, 109, 110, 110, 110, 110, 110, 110, 110, 110, 110, 111, 111, 111, 111, 111},
    {102, 105, 107, 108, 109, 109, 110, 110, 110, 110, 110, 110, 110, 110, 111, 111, 111, 111, 111, 111},
    {103, 106, 108, 109, 109, 110, 110, 110, 110, 110, 110, 110, 110, 110, 111, 111, 111, 111, 111, 111},
};

/* Return the index of the node at or below x (the last but one at most), and in *off and *w how far
 * x is from it and the distance to the next node. */
static int mig_node(const uint8_t *nodes, int n, int x, int *off, int *w)
{
    int i = 0;
    while (i < n - 2 && x >= nodes[i + 1])
        i++;
    *off = x - nodes[i];
    *w = nodes[i + 1] - nodes[i];
    return i;
}

/* Return table t at old (Volume, Drive), interpolated between its nodes and rounded to the nearest
 * whole value. In integers, so that a table monotone in either pot interpolates monotone: in floats
 * a value on a half can round up at one setting and down at the next. */
static int mig_lookup(const uint8_t t[RAT_MIG_NV][RAT_MIG_ND], int volume, int drive)
{
    int fv, wv, fd, wd;
    int a = mig_node(rat_mig_vn, RAT_MIG_NV, volume, &fv, &wv);
    int b = mig_node(rat_mig_dn, RAT_MIG_ND, drive, &fd, &wd);
    int x = (t[a][b] * (wd - fd) + t[a][b + 1] * fd) * (wv - fv)
            + (t[a + 1][b] * (wd - fd) + t[a + 1][b + 1] * fd) * fv;      /* the value x (wv wd) */
    return (2 * x + wv * wd) / (2 * wv * wd);
}

void bass303_pre_rescale(int type, int volume, int drive, int *new_drive, int *new_volume)
{
    const float DB = 6.02059991f;                              /* 20 log10(2): dB from log2 */
    const float OLD_SOFT_DB = 24.0f;                           /* drive.h's Soft: 24 n dB, at the Volume's level */
    float vdb = vol_db(volume), want, over, mk, r;
    int p;
    *new_drive = drive;
    *new_volume = volume;
    if (drive <= 0 || type == BASS303_DRV_OFF)                 /* 0: a bypass, then and now */
        return;
    if (type == BASS303_DRV_RAT) {
        *new_drive = mig_lookup(rat_mig_drive, volume, drive);
        *new_volume = mig_lookup(rat_mig_volume, volume, drive);
        return;
    }
    /* Soft: the gain the old shaper had, as one at the drive's level now (DRV_REF), and the Drive
     * that gives it: soft_db's inverse, then whichever neighbouring value is nearer in dB */
    want = OLD_SOFT_DB * (float)drive * (1.0f / 127.0f) + vdb - DB * c_log2f(DRV_REF);
    r = fm_clampf((want - soft_db(0)) / (soft_db(127) - soft_db(0)), 1e-6f, 1.0f);
    p = (int)fm_clampf(127.0f * c_exp2f(1.33333333f * c_log2f(r)), 1.0f, 127.0f);
    if (p < 127 && soft_db(p + 1) - want < want - soft_db(p))
        p++;
    /* past the new range's top the shaper is hit less hard than it was; deep in saturation its
     * output goes as 1 / its input gain, so the old one was quieter by the gain the new one lacks */
    over = fm_maxf(want - soft_db(127), 0.0f);
    mk = DB * c_log2f(makeup_soft[p]) + DRV_RISE * (float)p * (1.0f / 127.0f);
    *new_drive = p;
    *new_volume = (int)fm_clampf((vdb - mk - over + 60.0f) * (127.0f / 60.0f) + 0.5f, 0.0f, 127.0f);
}

/* RAT op-amp: drive.h rat::State::update_op_amp_coeffs + the correction one-pole cutoff */
static void rat_coeffs(bass303_t *b)
{
    const float R1 = 100000.0f, C1 = 1e-10f, Z1_B0 = 2.72149e-7f, Z1_B1 = 0.0027354f;
    const float Z1_A0 = 6.27638e-9f, Z1_A1 = 0.0000069f;
    const float t = 1.0f / BASS303_SR, s0 = t * 0.5f, s1 = t * t * 0.25f, s2 = t * t * t * 0.125f;
    float dist = fm_maxf(rat_dist(b->drv_x), 0.0001f);
    float z2_b0 = fm_maxf(dist * R1, 1.0f), z2_a0 = z2_b0 * C1;
    float a0 = Z1_B0 * z2_a0, a1 = Z1_B0 + Z1_B1 * z2_a0, a2 = Z1_B1 + z2_a0;
    float num[4], den[4], nz[4], dz[4], inv;
    int i;
    num[0] = a0; num[1] = a1 + Z1_A0 * z2_b0; num[2] = Z1_A1 * z2_b0 + Z1_B1 + z2_a0; num[3] = 1.0f;
    den[0] = a0; den[1] = a1; den[2] = a2; den[3] = 1.0f;
    for (i = 0; i < 2; i++) {                                  /* bilinear transform */
        const float *x = i ? den : num;
        float *o = i ? dz : nz;
        float x0 = x[0], x1 = x[1] * s0, x2 = x[2] * s1, x3 = x[3] * s2;
        o[0] = x0 + x1 + x2 + x3;
        o[1] = -3.0f * x0 - x1 + x2 + 3.0f * x3;
        o[2] = 3.0f * x0 - x1 - x2 + 3.0f * x3;
        o[3] = -x0 + x1 - x2 + x3;
    }
    inv = 1.0f / dz[0];
    for (i = 0; i < 4; i++) {
        b->r_b[i] = nz[i] * inv;
        b->r_a[i] = dz[i] * inv;
    }
    /* correction cutoff = MAX_GAIN_AT_1HZ / (dist * (MAX_DIST_GAIN - 1) + 1) */
    b->r_corr_b1 = c_expf(-FM_TWO_PI / BASS303_SR * 1119360.558f / (dist * 2306.231003f + 1.0f));
}

/* Clear the drive's filter and DC-blocker state: a fresh start (drive.h set_model). */
static void clear_drive_state(bass303_t *b)
{
    b->s_pre.z1 = b->s_pre.z2 = b->s_post.z1 = b->s_post.z2 = 0.0f;
    b->up_lp.z1 = b->up_lp.z2 = b->down_lp.z1 = b->down_lp.z2 = 0.0f;
    b->r_z[0] = b->r_z[1] = b->r_z[2] = b->r_corr_z = b->r_tone_z = 0.0f;
    b->dcb_x1 = b->dcb_y1 = 0.0f;
}

void bass303_set(bass303_t *b, int i, int v)
{
    float n;
    if (i < 0 || i >= BASS303_NPARAMS)
        return;
    if (v < 0)
        v = 0;
    if (v > params[i].max)
        v = params[i].max;
    b->pot[i] = (uint8_t)v;
    n = (float)v * (1.0f / 127.0f);
    switch (i) {
    case BASS303_CUTOFF:
        b->cutoff = 314.0f * c_exp2f(n * 2.930586688f);       /* log2(2394/314) */
        calc_envmod(b);
        break;
    case BASS303_ENVMOD:
        calc_envmod(b);
        break;
    case BASS303_RESO:                                         /* TeeBeeFilter::setResonance */
        b->reso = (1.0f - c_expf(-3.0f * n)) * (1.0f / 0.950212932f);
        break;
    case BASS303_DECAY:                                        /* applied at the next note */
        b->decay_c = rc_coeff(200.0f * c_exp2f(n * 3.321928095f), BASS303_SR);
        break;
    case BASS303_ACCDEC:
        b->accdec_c = rc_coeff(30.0f + 2970.0f * n, BASS303_SR);
        break;
    case BASS303_ACCENT:
        b->accent = n;
        break;
    case BASS303_WAVE:
        b->wave = v;
        break;
    case BASS303_TUNE:
        b->tuning = 440.0f + (float)(v - 64) * 0.625f;
        break;
    case BASS303_VOLUME:                                       /* vol_g slews to it */
        b->amp_scaler = c_db2lin(vol_db(v));
        break;
    case BASS303_SLIDE:                                        /* slew tau = 0.2 * slide time */
        b->slew_c = rc_coeff(0.2f * (2.0f + 358.0f * n), BASS303_SR);
        powers(b->slew_pw, b->slew_c);
        break;
    case BASS303_DRVTYPE:                                      /* (Drive and the type: drive_block, slew) */
        b->drv_type = v;
        break;
    }
}

/* ---- slew: the moves of Drive, Volume and the drive type, smoothed ----------------------------------------
 * Each step of Drive or Volume is ~0.5 dB, and the drive's gains and filters jumped with it at a block's edge:
 * a zipper as the knob turns, a click at a jump (tests/host/bass303_slew_test.c). Drive and Volume now glide
 * (slew_to: one pole, ~10 ms, as the pans' x0x_glide_block), the drive's coefficients recomputed from the glide
 * every BASS303_DSUB samples and its gains and coefficients ramped linearly over them (drive_block); the bypass
 * at Drive 0 and a change of type fade (WET_RATE) between the drive's output and the voice without it, the drive
 * starting fresh from a fade's bottom (drive.h set_model). Every value reaches its pot's exactly, so a pot that
 * has not moved renders the samples it always did. */
#define WET_RATE (1.0f / 441.0f)         /* a fade: 10 ms */

/* Move *cur n samples (at most BASS303_SUB) on toward tgt, one pole, ~10 ms, landing on tgt once within snap of
 * it; return the per-sample step of a linear ramp from where it was. x0x_glide_block's, with the snap the
 * caller's: its fixed 1e-5 leaves a value far from 1 short of its target by a step too small to add. */
static float slew_to(float *cur, float tgt, int n, float snap)
{
    float c = *cur, e;
    if (c == tgt)
        return 0.0f;
    e = (tgt - c) * ((float)n * (1.0f / 441.0f));
    if (fm_fabsf(tgt - (c + e)) <= snap)
        e = tgt - c;
    *cur = c + e;
    return e / (float)n;
}

/* Return whether the drive runs: it is on, or fading out. */
static int drv_running(const bass303_t *b) { return drive_on(b) || b->drv_wet > 0.0f; }

/* Set the drive's coefficients for its type and drv_x. */
static void drv_params(bass303_t *b)
{
    if (b->drv_cur == BASS303_DRV_SOFT) {
        b->s_gain = c_db2lin(soft_db(b->drv_x));
        b->s_inv = 1.0f / b->s_gain;
    } else if (b->drv_cur == BASS303_DRV_RAT) {
        rat_coeffs(b);
        rat_tone(b);
    }
    drv_gains(b);
}

/* Start the drive at its pot's type and Drive, fresh. */
static void drv_start(bass303_t *b)
{
    b->drv_cur = b->drv_type;
    b->drv_x = (float)b->pot[BASS303_DRIVE];
    clear_drive_state(b);
    drv_params(b);
}

/* Jump every slewed value to its pot (init, and a note after idle: nothing sounds to glide from). */
static void slew_snap(bass303_t *b)
{
    drv_start(b);
    b->drv_wet = drive_on(b) ? 1.0f : 0.0f;
    b->vol_g = b->amp_scaler;
}

/* clear everything that only matters while sound is running (Open303::triggerNote after idle) */
static void clear_audio_state(bass303_t *b)
{
#if BASS303_OS >= 2
    int i;
#endif
    b->dc.x1 = b->dc.x2 = b->dc.y1 = b->dc.y2 = 0.0f;
    b->hp1_x1 = b->hp1_y1 = 0.0f;
    b->f_y1 = b->f_y2 = b->f_y3 = b->f_y4 = b->fb_x1 = b->fb_y1 = 0.0f;
#if BASS303_OS >= 2
    for (i = 0; i < 6; i++)
        b->hb1[i].x1 = b->hb1[i].y1 = 0.0f;
#endif
#if BASS303_OS == 4
    for (i = 0; i < 3; i++)
        b->hb2[i].x1 = b->hb2[i].y1 = 0.0f;
#endif
    b->ap_x1 = b->ap_y1 = b->hp2_x1 = b->hp2_y1 = 0.0f;
    b->nt.x1 = b->nt.x2 = b->nt.y1 = b->nt.y2 = 0.0f;
    clear_drive_state(b);
    b->amp_y = 0.0f;
}

/* the shared coefficients (Open303 constructor + setSampleRate) */
static void fixed_init(void)
{
    float w, sn, cs, alpha, scale, x, F, O, ln_cosh_p, ln_cosh_m;

    bass303_k.rc1_c = rc_coeff(3.0f, BASS303_SR);           /* normalAttack */
    bass303_k.rc2_c = rc_coeff(15.0f, BASS303_SR);
    powers(bass303_k.rc1_pw, bass303_k.rc1_c);
    powers(bass303_k.rc2_pw, bass303_k.rc2_c);
    powers(bass303_k.ampd_pw, rc_coeff(1230.0f, BASS303_SR));         /* amp: y += (1 - c)(0 - y) */
    powers(bass303_k.ampn_pw, rc_coeff(1.0f, BASS303_SR));            /* release, normal: 1 ms */
    powers(bass303_k.ampa_pw, rc_coeff(50.0f, BASS303_SR));           /* release, accented: 50 ms */

    w = FM_TWO_PI * 200.0f / BASS303_SR;             /* de-clicker: LOWPASS12, q = sqrt(.5) */
    sn = c_sinf(w);
    cs = c_cosf(w);
    alpha = sn * 0.707106781f;
    scale = 1.0f / (1.0f + alpha);
    bass303_k.dc_a1 = 2.0f * cs * scale;
    bass303_k.dc_a2 = (alpha - 1.0f) * scale;
    bass303_k.dc_b1 = (1.0f - cs) * scale;
    bass303_k.dc_b0 = 0.5f * bass303_k.dc_b1;

    x = c_expf(-FM_TWO_PI * 44.486f / FSO);         /* OnePoleFilter HIGHPASS (dspguide) */
    bass303_k.hp1_b0 = 0.5f * (1.0f + x);
    bass303_k.hp1_a1 = x;
    x = c_expf(-FM_TWO_PI * 150.0f / FSO);          /* feedback highpass (stock 150 Hz) */
    bass303_k.fbhp_b0 = 0.5f * (1.0f + x);
    bass303_k.fbhp_a1 = x;
    x = c_expf(-FM_TWO_PI * 44.486f / BASS303_SR);  /* the same two at the base rate (lite) */
    bass303_k.hp1l_b0 = 0.5f * (1.0f + x);
    bass303_k.hp1l_a1 = x;
    x = c_expf(-FM_TWO_PI * 150.0f / BASS303_SR);
    bass303_k.fbhpl_b0 = 0.5f * (1.0f + x);
    bass303_k.fbhpl_a1 = x;
    x = c_expf(-FM_TWO_PI * 24.167f / BASS303_SR);
    bass303_k.hp2_b0 = 0.5f * (1.0f + x);
    bass303_k.hp2_a1 = x;
    x = fm_tanf(FM_PI * 14.008f / BASS303_SR);       /* OnePoleFilter ALLPASS (DAFX) */
    bass303_k.ap_b0 = (x - 1.0f) / (x + 1.0f);

    w = FM_TWO_PI * 7.5164f / BASS303_SR;            /* BANDREJECT, 4.7 octaves */
    sn = c_sinf(w);
    x = c_sinf(0.5f * w);
    cs = 1.0f - 2.0f * x * x;                        /* cos w without the cancellation */
    x = 0.5f * FM_LN2 * 4.7f * w / sn;               /* alpha = sn * sinh(x) */
    alpha = sn * 0.5f * (c_expf(x) - c_expf(-x));
    scale = 1.0f / (1.0f + alpha);
    bass303_k.nt_a1 = 2.0f * cs * scale;
    bass303_k.nt_a2 = (alpha - 1.0f) * scale;
    bass303_k.nt_b0 = scale;
    bass303_k.nt_b1 = -2.0f * cs * scale;

    /* 303 square = -tanh(F * (2p - 1) + O), F = dB2amp(36.9), O = 4.37 (fillWithSquare303,
     * after its 180 degree circular shift). Mean over a cycle, for the DC the mip-map drops:
     * -(ln cosh(F + O) - ln cosh(F - O)) / 2F; ln cosh(y) = y - ln 2 + ln(1 + e^-2y), y > 0. */
    F = c_db2lin(36.9f);
    O = 4.37f;
    ln_cosh_p = (F + O) + (c_log2f(1.0f + c_expf(-2.0f * (F + O))) * FM_LN2);
    ln_cosh_m = (F - O) + (c_log2f(1.0f + c_expf(-2.0f * (F - O))) * FM_LN2);
    bass303_k.sq_dc = -(ln_cosh_p - ln_cosh_m) / (2.0f * F);
    bass303_k.sq_h = fm_tanhf(F + O) + fm_tanhf(F - O);    /* height of the hard edge at p = 0 */

    /* drive.h prepare() */
    bq_low_shelf(&bass303_k.s_pre, 400.0f, 6.0f, BASS303_SR);
    bq_low_shelf(&bass303_k.s_post, 400.0f, -6.0f, BASS303_SR);
    bq_lowpass(&bass303_k.up_lp, 19000.0f, 2.0f * BASS303_SR);
    bq_lowpass(&bass303_k.down_lp, 19000.0f, 2.0f * BASS303_SR);
    /* (the RAT's tone: rat_tone, with Drive) */
    bass303_k.ready = 1;
}

void bass303_init(bass303_t *b)
{
    uint8_t *p = (uint8_t *)b;
    unsigned k;
    int i;

    for (k = 0; k < sizeof(*b); k++)
        p[k] = 0;
    if (!bass303_k.ready)
        fixed_init();
    b->drv_type = -1;
    for (i = 0; i < BASS303_NPARAMS; i++)
        bass303_set(b, i, params[i].def);

    b->osc_freq = b->slew_y = 440.0f;
    b->env_c = b->decay_c;
    env_tables(b);
    b->env_y = 0.0f;
    b->idle = 1;
    b->snap = 1;
    slew_snap(b);
}

/* ---- notes ----------------------------------------------------------------------------- */

static void set_accent_state(bass303_t *b, int accent)
{
    if (accent) {
        b->accent_gain = b->accent;
        b->env_c = b->accdec_c;          /* setMainEnvDecay(accentDecay) */
    } else {
        b->accent_gain = 0.0f;
        b->env_c = b->decay_c;
    }
    b->amp_acc = accent != 0;            /* release: accentAmpRelease 50 ms, normal 1 ms */
    env_tables(b);
}

void bass303_note_on(bass303_t *b, int note, int accent, int slide)
{
    float f;
    if (note < 0)
        note = 0;
    if (note > 127)
        note = 127;
    f = b->tuning * c_exp2f((float)(note - 69) * (1.0f / 12.0f));
    set_accent_state(b, accent);
    b->osc_freq = f;
    if (!(slide && b->gate)) {           /* triggerNote; else slideToNote (no retrigger) */
        b->slew_y = f;                   /* pitchSlewLimiter.setState */
        b->env_y = 1.0f / b->env_c;      /* mainEnv.trigger: the next sample is 1 */
        b->amp_trig = 1;                 /* ampEnv.noteOn: attack time 0 */
        b->trig = 1;
    }
    if (b->idle) {
        b->snap = 1;                     /* no interpolation from the stale control values */
        slew_snap(b);                    /* nor glides */
    }
    b->gate = 1;
    b->idle = 0;
    b->quiet = 0;
    b->started = 1;
}

void bass303_note_off(bass303_t *b) { b->gate = 0; }
void bass303_set_lite(bass303_t *b, int on) { b->lite = on != 0; }
void bass303_all_off(bass303_t *b) { b->gate = 0; }

/* ---- render ---------------------------------------------------------------------------- */

/* polyBLEP residual for a unit (2-high) step at phase 0, t in [0, 1), dt = increment. The
 * divides happen only on the two samples per period next to the step. */
static inline float blep(float t, float dt)
{
    float x;
    if (t < dt) {
        x = t / dt;
        return x + x - x * x - 1.0f;
    }
    if (t > 1.0f - dt) {
        x = (t - 1.0f) / dt;
        return x * x + x + x + 1.0f;
    }
    return 0.0f;
}

#if BASS303_OS == 4                     /* (at 2x run_decim runs the sections in its own loop) */
static inline float hb(bass303_ap_t *s, float a, float x)
{
    float y = a * (x - s->y1) + s->x1;
    s->x1 = x;
    s->y1 = y;
    return y;
}
#endif

/* Halfband decimators: polyphase allpass pairs (de Soras' hiir structure; coefficients from
 * its closed-form elliptic design, response checked numerically). 2x -> 1x: 6 coefficients,
 * transition 0.04 (passband flat to 18.5 kHz, -74.5 dB from 25.6 kHz at the 2x rate). 4x -> 2x:
 * 3 coefficients, transition 0.137 (flat to 19.9 kHz, -62 dB over the band that folds below
 * 20 kHz). 8 / 4 coefficients (-99 / -81 dB) measured the same alias floor in
 * tests/host/run_bass303.sh: what reaches the decimator is already low-passed by the ladder.
 * Paths: even coefficients take the newer sample, odd ones the older. */
#if BASS303_OS == 4
static inline float decim_hb1(bass303_ap_t *s, float x_old, float x_new)
{
    float a = x_new, c = x_old;
    a = hb(&s[0], 0.068204076f, a);
    c = hb(&s[1], 0.240270358f, c);
    a = hb(&s[2], 0.448676236f, a);
    c = hb(&s[3], 0.641122367f, c);
    a = hb(&s[4], 0.799997564f, a);
    c = hb(&s[5], 0.934482236f, c);
    return 0.5f * (a + c);
}
#endif
#if BASS303_OS == 4
static inline float decim_hb2(bass303_ap_t *s, float x_old, float x_new)
{
    float a = x_new, c = x_old;
    a = hb(&s[0], 0.104996100f, a);
    c = hb(&s[1], 0.375357314f, c);
    a = hb(&s[2], 0.754467339f, a);
    return 0.5f * (a + c);
}
#endif

/* While idle, advance what Open303 keeps running so the next note starts where the
 * reference would: oscillator phase, slew, the main envelope and its RC followers
 * (closed forms of N steps of each recursion). */
static void idle_advance(bass303_t *b, int n)
{
    float N = (float)n, cn, an, ph;
    if (!b->started)
        return;                                       /* Open303 does not run before note 1 */
    ph = b->phase + N * b->slew_y * (1.0f / BASS303_SR);    /* N base samples */
    b->phase = ph - fm_floorf(ph);
    an = c_powf(b->slew_c, N);
    b->slew_y = b->osc_freq + an * (b->slew_y - b->osc_freq);
    cn = c_powf(b->env_c, N);
    an = c_powf(bass303_k.rc1_c, N);
    /* r[n] = a r[n-1] + (1-a) u[n], u[n] = E c^n:  r_N = a^N r0 + (1-a) E c (c^N - a^N)/(c - a) */
    b->rc1_y = an * b->rc1_y + (1.0f - bass303_k.rc1_c) * b->env_y * b->env_c * (cn - an) / (b->env_c - bass303_k.rc1_c);
    an = c_powf(bass303_k.rc2_c, N);
    if (b->accent_gain > 0.0f)
        b->rc2_y = an * b->rc2_y + (1.0f - bass303_k.rc2_c) * b->env_y * b->env_c * (cn - an) / (b->env_c - bass303_k.rc2_c);
    else
        b->rc2_y *= an;
    b->env_y = fm_flush(b->env_y * cn);
    b->rc1_y = fm_flush(b->rc1_y);
    b->rc2_y = fm_flush(b->rc2_y);
}

/* The drive (schwung-303 drive.h) in passes over sub-blocks of BASS303_DSUB samples, as the voice: each
 * filter's state and coefficients in registers for its pass, the same operations in the same order. The 2x
 * upsampler's odd input is 0 and the lowpass's b0, b1, b2 are positive, so b * 0 is +0: its zero-input step is
 * written without the three products (0 + z1, (0 - a1 y) + z2, 0 - a2 y), which is the same to the bit. */
#define BASS303_DSUB 32

typedef struct { float b0, b1, b2, a1, a2, z1, z2; } bass303_bql_t;   /* a biquad in locals */

static inline void bq_get(bass303_bql_t *l, const bass303_bq_t *q, const bass303_bqz_t *z)
{
    l->b0 = q->b0, l->b1 = q->b1, l->b2 = q->b2, l->a1 = q->a1, l->a2 = q->a2, l->z1 = z->z1, l->z2 = z->z2;
}

static inline void bq_put(const bass303_bql_t *l, bass303_bqz_t *z) { z->z1 = l->z1, z->z2 = l->z2; }

static inline float bql_run(bass303_bql_t *q, float x)          /* bq_run */
{
    float y = q->b0 * x + q->z1;
    q->z1 = q->b1 * x - q->a1 * y + q->z2;
    q->z2 = q->b2 * x - q->a2 * y;
    return y;
}

static inline float bql_run0(bass303_bql_t *q)                  /* bq_run(q, 0.0f), b0, b1, b2 > 0 */
{
    float y = 0.0f + q->z1;
    q->z1 = (0.0f - q->a1 * y) + q->z2;
    q->z2 = 0.0f - q->a2 * y;
    return y;
}

/* biquad q (state z) over x[0..n) in place, times g (rising by dg a sample: the slew) */
static void bq_pass(const bass303_bq_t *q, bass303_bqz_t *z, float *x, int n, float g, float dg)
{
    bass303_bql_t l;
    int i;
    bq_get(&l, q, z);
    for (i = 0; i < n; i++) {
        x[i] = bql_run(&l, x[i]) * g;
        g += dg;
    }
    bq_put(&l, z);
}

/* the 2x upsampler: x[i], 0 through up_lp, times 2, into u[2i], u[2i + 1] */
static void up_pass(bass303_t *b, const float *x, float *u, int n)
{
    bass303_bql_t l;
    int i;
    bq_get(&l, &bass303_k.up_lp, &b->up_lp);
    for (i = 0; i < n; i++) {
        u[2 * i] = 2.0f * bql_run(&l, x[i]);
        u[2 * i + 1] = 2.0f * bql_run0(&l);
    }
    bq_put(&l, &b->up_lp);
}

/* the 2x downsampler: u[2i], u[2i + 1] through down_lp, the second kept, times g (+ dg a sample) */
static void down_pass(bass303_t *b, const float *u, float *y, int n, float g, float dg)
{
    bass303_bql_t l;
    int i;
    bq_get(&l, &bass303_k.down_lp, &b->down_lp);
    for (i = 0; i < n; i++) {
        bql_run(&l, u[2 * i]);
        y[i] = bql_run(&l, u[2 * i + 1]) * g;
        g += dg;
    }
    bq_put(&l, &b->down_lp);
}

/* the DC blocker (0.9996) in place, times g (+ dg a sample) */
static void dcb_pass(bass303_t *b, float *x, int n, float g, float dg)
{
    float x1 = b->dcb_x1, y1 = b->dcb_y1;
    int i;
    for (i = 0; i < n; i++) {
        float y = x[i], yh = y - x1 + 0.9996f * y1;
        x1 = y;
        y1 = yh;
        x[i] = g * yh;
        g += dg;
    }
    b->dcb_x1 = x1;
    b->dcb_y1 = y1;
}

/* Soft: pre shelf x gain, 2x up, tanh(u + 0.15) - its value at 0, 2x down, x 1/gain, post shelf, DC blocker,
 * x wg; each gain from g[k] rising by g[k + 1] a sample (the slew: g, dg for the gain, its inverse, wg) */
static BASS303_PASS void drive_soft(bass303_t *b, float *out, int n, const float *g)
{
    float u[2 * BASS303_DSUB];
    int i;
    bq_pass(&bass303_k.s_pre, &b->s_pre, out, n, g[0], g[1]);
    up_pass(b, out, u, n);
    for (i = 0; i < 2 * n; i++)
        u[i] = fm_tanhf(u[i] + 0.15f) - 0.14888503f;
    down_pass(b, u, out, n, g[2], g[3]);
    bq_pass(&bass303_k.s_post, &b->s_post, out, n, 1.0f, 0.0f);
    dcb_pass(b, out, n, g[4], g[5]);
}

/* The RAT's op-amp and correction one-pole while Drive glides: each coefficient interpolated linearly from c0
 * (its value at the sub-block's start: b0..b3, a1..a3, the correction's b1) to its value now */
static BASS303_PASS void rat_glide(bass303_t *b, float *out, int n, const float *c0)
{
    const float r = 1.0f / (float)n;
    int i;
    {
        float b0 = c0[0], b1 = c0[1], b2 = c0[2], b3 = c0[3], a1 = c0[4], a2 = c0[5], a3 = c0[6];
        const float db0 = (b->r_b[0] - b0) * r, db1 = (b->r_b[1] - b1) * r, db2 = (b->r_b[2] - b2) * r;
        const float db3 = (b->r_b[3] - b3) * r, da1 = (b->r_a[1] - a1) * r, da2 = (b->r_a[2] - a2) * r;
        const float da3 = (b->r_a[3] - a3) * r;
        float z0 = b->r_z[0], z1 = b->r_z[1], z2 = b->r_z[2];
        for (i = 0; i < n; i++) {
            float x = out[i], y;
            b0 += db0, b1 += db1, b2 += db2, b3 += db3, a1 += da1, a2 += da2, a3 += da3;
            y = x * b0 + z0;
            z0 = x * b1 - y * a1 + z1;
            z1 = x * b2 - y * a2 + z2;
            z2 = x * b3 - y * a3;
            out[i] = y;
        }
        b->r_z[0] = z0, b->r_z[1] = z1, b->r_z[2] = z2;
    }
    {
        float cb1 = c0[7], z = b->r_corr_z;
        const float dcb = (b->r_corr_b1 - cb1) * r;
        for (i = 0; i < n; i++) {
            cb1 += dcb;
            z = out[i] * (1.0f - cb1) + z * cb1;
            out[i] = z * 1.877f;
        }
        b->r_corr_z = z;
    }
}

/* RAT: op-amp (3rd-order TDF-II), the correction one-pole x 1.877, 2x up, the clipper, 2x down x 0.3204805,
 * the tone one-pole, DC blocker, x wg (g as drive_soft's); c0: the coefficients at the sub-block's start while
 * Drive glides (rat_glide; the tone's b1 at c0[8]), else 0 */
static BASS303_PASS void drive_rat(bass303_t *b, float *out, int n, const float *g, const float *c0)
{
    float u[2 * BASS303_DSUB];
    int i;
    if (c0) {
        rat_glide(b, out, n, c0);
    } else {
        {
            const float b0 = b->r_b[0], b1 = b->r_b[1], b2 = b->r_b[2], b3 = b->r_b[3];
            const float a1 = b->r_a[1], a2 = b->r_a[2], a3 = b->r_a[3];
            float z0 = b->r_z[0], z1 = b->r_z[1], z2 = b->r_z[2];
            for (i = 0; i < n; i++) {
                float x = out[i], y = x * b0 + z0;
                z0 = x * b1 - y * a1 + z1;
                z1 = x * b2 - y * a2 + z2;
                z2 = x * b3 - y * a3;
                out[i] = y;
            }
            b->r_z[0] = z0, b->r_z[1] = z1, b->r_z[2] = z2;
        }
        {
            const float cb1 = b->r_corr_b1, cb0 = 1.0f - cb1;
            float z = b->r_corr_z;
            for (i = 0; i < n; i++) {
                z = out[i] * cb0 + z * cb1;
                out[i] = z * 1.877f;
            }
            b->r_corr_z = z;
        }
    }
    up_pass(b, out, u, n);
    for (i = 0; i < 2 * n; i++) {   /* x / (1 + x^4)^(1/4) = x s t, s = y^(-1/2), t = s^(-1/2) = y^(1/4): no divide */
        float x = u[i], x2 = x * x, s = fm_rsqrtf(1.0f + x2 * x2);
        u[i] = x * (s * fm_rsqrtf(s));
    }
    down_pass(b, u, out, n, 0.3204805f, 0.0f);
    if (c0) {
        float tb1 = c0[8], z = b->r_tone_z;
        const float dtb = (b->r_tone_b1 - tb1) / (float)n;
        for (i = 0; i < n; i++) {
            tb1 += dtb;
            z = out[i] * (1.0f - tb1) + z * tb1;
            out[i] = z;
        }
        b->r_tone_z = z;
    } else {
        const float tb1 = b->r_tone_b1, tb0 = 1.0f - tb1;
        float z = b->r_tone_z;
        for (i = 0; i < n; i++) {
            z = out[i] * tb0 + z * tb1;
            out[i] = z;
        }
        b->r_tone_z = z;
    }
    dcb_pass(b, out, n, g[4], g[5]);
}

/* The drive over a block (at DRV_REF: run_amp), by sub-blocks: each moves the slewed values on (slew, above),
 * ramps the gains from their values at its start to those at its end, and fades with the voice without the
 * drive (Volume's gain, the voice at DRV_REF times vol_g / DRV_REF) while drv_wet is below 1. */
static void drive_block(bass303_t *b, float *out, int n)
{
    float dry[BASS303_DSUB];
    int i, j, ns;
    for (i = 0; i < n; i += ns) {
        float *o = out + i, g[6], c0[9], w0, w1, v0, r;
        int on, glide = 0;
        ns = n - i < BASS303_DSUB ? n - i : BASS303_DSUB;
        if (b->drv_wet <= 0.0f)                                /* from the bypass: fresh, at the pot */
            drv_start(b);
        on = drive_on(b) && b->drv_cur == b->drv_type;         /* (another type: fade out first) */
        w0 = b->drv_wet;
        v0 = b->vol_g;
        if (!on && w0 <= 0.0f) {                               /* off, faded out: the voice alone */
            float a = v0 * (1.0f / DRV_REF), da;
            da = slew_to(&b->vol_g, b->amp_scaler, ns, b->amp_scaler * 1e-4f) * (1.0f / DRV_REF);
            for (j = 0; j < ns; j++, a += da)
                o[j] *= a;
            continue;
        }
        g[0] = b->s_gain;
        g[2] = b->s_inv;
        g[4] = drv_out_gain(b);
        if (on && b->drv_x != (float)b->pot[BASS303_DRIVE]) {  /* Drive glides */
            if (b->drv_cur == BASS303_DRV_RAT) {               /* (its coefficients glide too: rat_glide) */
                for (j = 0; j < 4; j++)
                    c0[j] = b->r_b[j];
                c0[4] = b->r_a[1], c0[5] = b->r_a[2], c0[6] = b->r_a[3];
                c0[7] = b->r_corr_b1, c0[8] = b->r_tone_b1;
                glide = 1;
            }
            slew_to(&b->drv_x, (float)b->pot[BASS303_DRIVE], ns, 0.02f);
            drv_params(b);
        }
        slew_to(&b->vol_g, b->amp_scaler, ns, b->amp_scaler * 1e-4f);
        w1 = on ? fm_minf(w0 + (float)ns * WET_RATE, 1.0f) : fm_maxf(w0 - (float)ns * WET_RATE, 0.0f);
        b->drv_wet = w1;
        r = 1.0f / (float)ns;
        g[1] = (b->s_gain - g[0]) * r;
        g[3] = (b->s_inv - g[2]) * r;
        g[5] = (drv_out_gain(b) - g[4]) * r;
        if (w0 < 1.0f || w1 < 1.0f)
            for (j = 0; j < ns; j++)
                dry[j] = o[j];
        if (b->drv_cur == BASS303_DRV_SOFT)
            drive_soft(b, o, ns, g);
        else
            drive_rat(b, o, ns, g, glide ? c0 : 0);
        if (w0 < 1.0f || w1 < 1.0f) {                         /* the fade: dry (1 - w) vol_g / DRV_REF + wet w */
            float a = (1.0f - w0) * v0 * (1.0f / DRV_REF), w = w0;
            float da = ((1.0f - w1) * b->vol_g * (1.0f / DRV_REF) - a) * r, dw = (w1 - w0) * r;
            for (j = 0; j < ns; j++, a += da, w += dw)
                o[j] = dry[j] * a + o[j] * w;
        }
    }
}

static const float recip[5] = { 0.0f, 1.0f, 0.5f, 0.333333343f, 0.25f };

/* The render runs in passes over sub-blocks of BASS303_SUB samples (a multiple of BASS303_CTRL, so the control
 * steps fall where they would in one pass): the voice (control steps, the amp's ramp, the oversampled
 * oscillator and filters), the de-clicker on the amp, the decimator, the filters after it. Each pass keeps its
 * state in registers (the FPU works on the 16 general registers: one pass for everything spilled on every
 * sample); every value is computed by the same operations in the same order as one pass would, so the output
 * is the same to the bit. */
#define BASS303_SUB 32

/* Pass 1 runs as three loops over the sub-block: the control steps (which also advance the per-sample linear
 * interpolation and keep each sample's values in cs[]), the oscillator and the highpass, the TeeBeeFilter.
 * One loop for all three holds ~24 values on the 16 registers and spills some on every oversample (which ones
 * depends on the code around it); each of these fits. */
typedef struct { float inc, f_b0, k, g2; } bass303_cs_t;      /* a sample's interpolated control values */

/* 1a: per control step, Open303's per-sample recursions advanced m samples in closed form (exact), the cutoff
 * and amp they produce at the chunk's last sample; per sample, the linear interpolation of the increment, the
 * filter's coefficients and the amp into cs[] and ab[] */
static BASS303_PASS void run_control(bass303_t *b, bass303_cs_t *cs, float *ab, int n)
{
    int i, j, m;
    float inc = b->c_inc, f_b0 = b->c_b0, k = b->c_k, g2 = b->c_g2, a = b->c_a;
    const float osc_freq = b->osc_freq, acc = b->accent_gain;
    const float scaler = b->env_scaler, offset = b->env_offset, cutoff = b->cutoff, r = b->reso;
    const float *amp_pw = b->gate ? bass303_k.ampd_pw : b->amp_acc ? bass303_k.ampa_pw : bass303_k.ampn_pw;
    const float amp_boost = b->gate ? 0.45f + 4.0f * acc : 0.0f;
    /* the overload guard's lite mode: no oversampling; a change of rate jumps to the new rate's
     * coefficients (snap) rather than gliding between the two rates' values */
    const int lite = BASS303_LITE && b->lite;
    const float fso = lite ? BASS303_SR : FSO;

    for (i = 0; i < n; i += m) {
        float e0, fc, fx, n_b0, n_k, n_g2, n_inc, n_a, rm, d_inc, d_b0, d_k, d_g2, d_a;
        m = n - i < BASS303_CTRL ? n - i : BASS303_CTRL;

        e0 = b->env_y;                                         /* main envelope: y *= c */
        b->env_y = e0 * b->env_pw[m];
        b->rc1_y = bass303_k.rc1_pw[m] * b->rc1_y + b->g1[m] * e0;    /* RC followers of it */
        b->rc2_y = bass303_k.rc2_pw[m] * b->rc2_y + (acc > 0.0f ? b->g2[m] * e0 : 0.0f);
        b->slew_y = osc_freq + b->slew_pw[m] * (b->slew_y - osc_freq);
        if (b->amp_trig) {                                     /* attack 0: 1, then decay */
            b->amp_y = amp_pw[m - 1];
            b->amp_trig = 0;
        } else {
            b->amp_y *= amp_pw[m];
        }
        if (lite != b->lite_cur) {
            b->lite_cur = lite;
            b->snap = 1;
        }
        n_inc = b->slew_y * (1.0f / fso);
        n_a = b->amp_y + amp_boost * b->env_y;
        fc = cutoff * fm_exp2f(scaler * (b->rc1_y - offset) + acc * b->rc2_y);   /* n1 = n2 = 1 */
        fc = fm_clampf(fc, 200.0f, 20000.0f);
        /* TeeBeeFilter::calculateCoefficientsApprox4, TB_303 branch only (the a1 polynomial
         * it computes first is overwritten there, so it is skipped) */
        fx = fc * (0.707106781f / fso);
        n_b0 = (0.00045522346f + 6.1922189f * fx) / (1.0f + 12.358354f * fx + 4.4156345f * (fx * fx));
        n_k = fx * (fx * (fx * (fx * (fx * (fx + 7198.6997f) - 5837.7917f) - 476.47308f) + 614.95611f) + 213.87126f) + 16.998792f;
        n_g2 = 2.0f * ((n_k * (1.0f / 17.0f) - 1.0f) * r + 1.0f) * (1.0f + r);
        n_k *= r;
        if (b->snap) {                                         /* first chunk after init / idle */
            inc = n_inc; f_b0 = n_b0; k = n_k; g2 = n_g2; a = n_a;
            d_inc = d_b0 = d_k = d_g2 = d_a = 0.0f;
            b->snap = 0;
        } else {                                               /* per-sample linear interpolation */
            rm = recip[m];
            d_inc = (n_inc - inc) * rm;
            d_b0 = (n_b0 - f_b0) * rm;
            d_k = (n_k - k) * rm;
            d_g2 = (n_g2 - g2) * rm;
            d_a = (n_a - a) * rm;
            if (b->trig) {               /* a trigger jumps pitch and amp in Open303: no ramp */
                inc = n_inc;
                a = n_a;
                d_inc = d_a = 0.0f;
            }
        }
        b->trig = 0;

        for (j = i; j < i + m; j++) {
            inc += d_inc;
            f_b0 += d_b0;
            k += d_k;
            g2 += d_g2;
            a += d_a;
            cs[j].inc = inc;
            cs[j].f_b0 = f_b0;
            cs[j].k = k;
            cs[j].g2 = g2;
            ab[j] = a;                                         /* (pass 2 de-clicks it) */
        }
    }
    b->c_inc = inc;
    b->c_b0 = f_b0;
    b->c_k = k;
    b->c_g2 = g2;
    b->c_a = a;
}

/* 1b: n samples of the oversampled oscillator -> highpass, nos values a sample into hb; inlined with nos and
 * square constant where they are (no test of the wave per oversample) */
static inline __attribute__((always_inline)) void osc_samples(bass303_t *b, const bass303_cs_t *cs, float *hb,
                                                              int n, int nos, int square)
{
    const int lite = BASS303_LITE && b->lite;
    const float hp1_b0 = lite ? bass303_k.hp1l_b0 : bass303_k.hp1_b0, hp1_a1 = lite ? bass303_k.hp1l_a1 : bass303_k.hp1_a1;
    const float sq_dc = bass303_k.sq_dc, sq_h2 = 0.5f * bass303_k.sq_h;
    float phase = b->phase, hp1x = b->hp1_x1, hp1y = b->hp1_y1;
    int i, q;
    for (i = 0; i < n; i++) {
        const float inc = cs[i].inc;
        for (q = 0; q < nos; q++) {
            float s, t, ym;
            if (!square) {
                t = phase + 0.5f;                               /* Saw303: rises -1..1, jump at p = .5 */
                if (t >= 1.0f)
                    t -= 1.0f;
                s = -(t + t - 1.0f - blep(t, inc));             /* Open303 inverts the osc */
            } else {
                /* Square303 (shaped saw, minus its mean, polyBLEP on the hard rising edge
                 * at p = 0), times 0.5 as BlendOscillator scales it, inverted */
                s = 0.5f * (fm_tanhf(69.98419960f * (phase + phase - 1.0f) + 4.37f) + sq_dc - sq_h2 * blep(phase, inc));
            }
            phase += inc;
            if (phase >= 1.0f)
                phase -= 1.0f;

            ym = hp1_b0 * (s - hp1x) + hp1_a1 * hp1y;
            hp1x = s;
            hp1y = ym;
            *hb++ = ym;
        }
    }
    b->phase = phase;
    b->hp1_x1 = hp1x;
    b->hp1_y1 = hp1y;
}

static BASS303_PASS void run_osc_saw(bass303_t *b, const bass303_cs_t *cs, float *hb, int n)
{
    osc_samples(b, cs, hb, n, BASS303_OS, 0);
}

static BASS303_PASS void run_osc_sqr(bass303_t *b, const bass303_cs_t *cs, float *hb, int n)
{
    osc_samples(b, cs, hb, n, BASS303_OS, 1);
}

/* 1c: the TeeBeeFilter (its feedback through the highpass) on x's n * nos values, in place */
static inline __attribute__((always_inline)) void ladder_samples(bass303_t *b, const bass303_cs_t *cs, float *x,
                                                                 int n, int nos)
{
    const int lite = BASS303_LITE && b->lite;
    const float fb_b0 = lite ? bass303_k.fbhpl_b0 : bass303_k.fbhp_b0, fb_a1 = lite ? bass303_k.fbhpl_a1 : bass303_k.fbhp_a1;
    float y1 = b->f_y1, y2 = b->f_y2, y3 = b->f_y3, y4 = b->f_y4, fbx = b->fb_x1, fby = b->fb_y1;
    int i, q;
    for (i = 0; i < n; i++) {
        const float f_b0 = cs[i].f_b0, k = cs[i].k, g2 = cs[i].g2;
        for (q = 0; q < nos; q++) {
            float t = k * y4;                                   /* feedback through the highpass */
            fby = fb_b0 * (t - fbx) + fb_a1 * fby;
            fbx = t;
            t = *x - fby;
            y1 += 2.0f * f_b0 * (t - y1 + y2);
            y2 += f_b0 * (y1 - 2.0f * y2 + y3);
            y3 += f_b0 * (y2 - 2.0f * y3 + y4);
            y4 += f_b0 * (y3 - 2.0f * y4);
            *x++ = g2 * y4;
        }
    }
    b->f_y1 = y1;
    b->f_y2 = y2;
    b->f_y3 = y3;
    b->f_y4 = y4;
    b->fb_x1 = fbx;
    b->fb_y1 = fby;
}

static BASS303_PASS void run_ladder(bass303_t *b, const bass303_cs_t *cs, float *x, int n)
{
    ladder_samples(b, cs, x, n, BASS303_OS);
}

/* pass 1: the voice, nos values a sample into osb */
static void run_voice(bass303_t *b, float *ab, float *osb, int n, int nos)
{
    bass303_cs_t cs[BASS303_SUB];
    run_control(b, cs, ab, n);
    if (nos == BASS303_OS) {
        if (b->wave)
            run_osc_sqr(b, cs, osb, n);
        else
            run_osc_saw(b, cs, osb, n);
        run_ladder(b, cs, osb, n);
    } else {                                                   /* (lite) */
        osc_samples(b, cs, osb, n, nos, b->wave);
        ladder_samples(b, cs, osb, n, nos);
    }
}

/* pass 2: the amp de-clicked (200 Hz Butterworth), times the volume (driven: the drive's level, the volume after
 * it), in place */
static BASS303_PASS void run_amp(bass303_t *b, float *ab, int n)
{
    const float b0 = bass303_k.dc_b0, b1 = bass303_k.dc_b1, a1 = bass303_k.dc_a1, a2 = bass303_k.dc_a2;
    const int drv = drv_running(b);
    float g = drv ? DRV_REF : b->vol_g;
    float x1 = b->dc.x1, x2 = b->dc.x2, y1 = b->dc.y1, y2 = b->dc.y2;
    int i;
    if (!drv && g != b->amp_scaler) {          /* Volume glides (slew) */
        const float dg = slew_to(&b->vol_g, b->amp_scaler, n, b->amp_scaler * 1e-4f);
        for (i = 0; i < n; i++, g += dg) {
            float x = ab[i], y = b0 * (x + x2) + b1 * x1 + a1 * y1 + a2 * y2;
            x2 = x1;
            x1 = x;
            y2 = y1;
            y1 = y;
            ab[i] = y * g;
        }
    } else {
        BASS303_UNROLL2                        /* (no register moves for the state between samples) */
        for (i = 0; i < n; i++) {
            float x = ab[i], y = b0 * (x + x2) + b1 * x1 + a1 * y1 + a2 * y2;
            x2 = x1;
            x1 = x;
            y2 = y1;
            y1 = y;
            ab[i] = y * g;
        }
    }
    b->dc.x1 = x1;
    b->dc.x2 = x2;
    b->dc.y1 = y1;
    b->dc.y2 = y2;
}

#if BASS303_OS == 2
/* pass 3: decim_hb1 on each pair. In a chain of allpass sections a section's input is the one before's output,
 * so its x1 is the previous section's y1: each path keeps four values (x, then the three y1) */
static BASS303_PASS void run_decim(bass303_t *b, const float *osb, float *out, int n)
{
    bass303_ap_t *s = b->hb1;
    float a0 = s[0].x1, a1 = s[0].y1, a2 = s[2].y1, a3 = s[4].y1;    /* newer samples: s[0], s[2], s[4] */
    float c0 = s[1].x1, c1 = s[1].y1, c2 = s[3].y1, c3 = s[5].y1;    /* older: s[1], s[3], s[5] */
    int i;
    BASS303_UNROLL2                            /* (no register moves for the state between samples) */
    for (i = 0; i < n; i++) {
        float xo = osb[2 * i], xn = osb[2 * i + 1], p0, p1, p2, q0, q1, q2;
        p0 = 0.068204076f * (xn - a1) + a0;
        q0 = 0.240270358f * (xo - c1) + c0;
        p1 = 0.448676236f * (p0 - a2) + a1;
        q1 = 0.641122367f * (q0 - c2) + c1;
        p2 = 0.799997564f * (p1 - a3) + a2;
        q2 = 0.934482236f * (q1 - c3) + c2;
        a0 = xn, a1 = p0, a2 = p1, a3 = p2;
        c0 = xo, c1 = q0, c2 = q1, c3 = q2;
        out[i] = 0.5f * (p2 + q2);
    }
    s[0].x1 = a0, s[0].y1 = s[2].x1 = a1, s[2].y1 = s[4].x1 = a2, s[4].y1 = a3;
    s[1].x1 = c0, s[1].y1 = s[3].x1 = c1, s[3].y1 = s[5].x1 = c2, s[5].y1 = c3;
}
#elif BASS303_OS == 4
static BASS303_PASS void run_decim(bass303_t *b, const float *osb, float *out, int n)
{
    int i;
    for (i = 0; i < n; i++, osb += 4)
    {
        /* Both calls advance hb2: sequence older samples first on every compiler. */
        float older = decim_hb2(b->hb2, osb[0], osb[1]);
        float newer = decim_hb2(b->hb2, osb[2], osb[3]);
        out[i] = decim_hb1(b->hb1, older, newer);
    }
}
#endif

/* pass 4: allpass 14 Hz, highpass 24 Hz, notch 7.5 Hz at the base rate, times the amp. A section's x1 is the
 * one before's y1 here too (hp2_x1 = ap_y1, nt.x1 = hp2_y1) */
static BASS303_PASS void run_post(bass303_t *b, const float *ab, float *out, int n)
{
    const float ap_b0 = bass303_k.ap_b0, hp2_b0 = bass303_k.hp2_b0, hp2_a1 = bass303_k.hp2_a1;
    const float nt_b0 = bass303_k.nt_b0, nt_b1 = bass303_k.nt_b1, nt_a1 = bass303_k.nt_a1, nt_a2 = bass303_k.nt_a2;
    float ap_x1 = b->ap_x1, ap_y1 = b->ap_y1, hp2_y1 = b->hp2_y1, nt_x2 = b->nt.x2, nt_y1 = b->nt.y1, nt_y2 = b->nt.y2;
    int i;
    BASS303_UNROLL2                            /* (no register moves for the state between samples) */
    for (i = 0; i < n; i++) {
        float s = out[i], t, u;
        t = ap_b0 * (s - ap_y1) + ap_x1;
        ap_x1 = s;
        s = hp2_b0 * (t - ap_y1) + hp2_a1 * hp2_y1;
        ap_y1 = t;
        u = nt_b0 * (s + nt_x2) + nt_b1 * hp2_y1 + nt_a1 * nt_y1 + nt_a2 * nt_y2;
        nt_x2 = hp2_y1;
        hp2_y1 = s;
        nt_y2 = nt_y1;
        nt_y1 = u;
        out[i] = u * ab[i];
    }
    b->ap_x1 = ap_x1;
    b->ap_y1 = b->hp2_x1 = ap_y1;
    b->hp2_y1 = b->nt.x1 = hp2_y1;
    b->nt.x2 = nt_x2;
    b->nt.y1 = nt_y1;
    b->nt.y2 = nt_y2;
}

static void run(bass303_t *b, float *out, int n)
{
    float ab[BASS303_SUB];
#if BASS303_OS > 1
    float osb[BASS303_SUB * BASS303_OS];
#endif
    int i, ns;
    for (i = 0; i < n; i += ns) {
        ns = n - i < BASS303_SUB ? n - i : BASS303_SUB;
#if BASS303_OS > 1
        if (!BASS303_LITE || !b->lite) {
            run_voice(b, ab, osb, ns, BASS303_OS);
            run_decim(b, osb, out + i, ns);
        } else
#endif
        {
            run_voice(b, ab, out + i, ns, 1);
        }
        run_amp(b, ab, ns);
        run_post(b, ab, out + i, ns);
    }
    b->env_y = fm_flush(b->env_y);
    b->rc1_y = fm_flush(b->rc1_y);
    b->rc2_y = fm_flush(b->rc2_y);
    b->amp_y = fm_flush(b->amp_y);
}

void bass303_render(bass303_t *b, float *out, int n)
{
    int i;
    if (b->idle) {
        for (i = 0; i < n; i++)
            out[i] = 0.0f;
        idle_advance(b, n);
        return;
    }
    run(b, out, n);

    if (drv_running(b))
        drive_block(b, out, n);

    /* states that decay toward zero while the engine still runs (the idle hold-off, where the
     * amp is exactly 0): flushed once per block, before they can reach denormals */
    b->dc.x1 = fm_flush(b->dc.x1);
    b->dc.x2 = fm_flush(b->dc.x2);
    b->dc.y1 = fm_flush(b->dc.y1);
    b->dc.y2 = fm_flush(b->dc.y2);
    b->s_pre.z1 = fm_flush(b->s_pre.z1);
    b->s_pre.z2 = fm_flush(b->s_pre.z2);
    b->s_post.z1 = fm_flush(b->s_post.z1);
    b->s_post.z2 = fm_flush(b->s_post.z2);
    b->up_lp.z1 = fm_flush(b->up_lp.z1);
    b->up_lp.z2 = fm_flush(b->up_lp.z2);
    b->down_lp.z1 = fm_flush(b->down_lp.z1);
    b->down_lp.z2 = fm_flush(b->down_lp.z2);
    b->r_z[0] = fm_flush(b->r_z[0]);
    b->r_z[1] = fm_flush(b->r_z[1]);
    b->r_z[2] = fm_flush(b->r_z[2]);
    b->r_corr_z = fm_flush(b->r_corr_z);
    b->r_tone_z = fm_flush(b->r_tone_z);
    b->dcb_x1 = fm_flush(b->dcb_x1);
    b->dcb_y1 = fm_flush(b->dcb_y1);

    /* idle: gate off, amp envelope and de-clicker below -120 dB and the drive's DC blocker
     * settled (below -120 dB at the output: its state is at DRV_REF, scaled after it), for
     * BASS303_IDLE_HOLD samples in a row (see bass303.h) */
    if (!b->gate && b->amp_y < 1e-6f && fm_fabsf(b->dc.y1) < 1e-6f && fm_fabsf(b->dc.y2) < 1e-6f
        && fm_fabsf(b->dcb_y1) * drv_out_gain(b) < 1e-6f) {
        b->quiet += n;
        if (b->quiet >= BASS303_IDLE_HOLD) {
            clear_audio_state(b);
            b->idle = 1;
        }
    } else {
        b->quiet = 0;
    }
}
