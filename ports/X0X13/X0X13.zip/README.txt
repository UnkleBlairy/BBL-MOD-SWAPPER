X0X 1.3 for the BBL Mod Swapper

Original by charlesvestal: https://github.com/charlesvestal/fm1-x0x
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: X0X13-source.zip on the ports page.
