/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: Hortator 1.0.1 (https://github.com/deadactive/hortator) on the Teensy 4.1: its own browser build (tests/sim_core.c) inside ports/common's shell */
#include "../../../common/shell_pre.h"
#include <stdlib.h>
#include <time.h>
#ifndef CLOCK_MONOTONIC
#define CLOCK_MONOTONIC 1
static int clock_gettime(int c, struct timespec *t) { (void)c; t->tv_sec = 0; t->tv_nsec = 0; return 0; }
#endif
#define getenv(n) ((char *)0)
#define web_boot o_web_boot
#define web_out_l o_web_out_l
#define web_out_r o_web_out_r
#define web_render o_web_render
#define web_buttons o_web_buttons
#define web_keys o_web_keys
#define web_enc o_web_enc
#define web_master o_web_master
#define web_nor_erase o_web_nor_erase
#define web_ms o_web_ms
#define web_frame o_web_frame
#include "../../tests/sim_core.c"
#undef __attribute__
#undef EXPORT
#undef memset
#undef memcpy
#undef memcmp
#undef memmove
#undef web_boot
#undef web_out_l
#undef web_out_r
#undef web_render
#undef web_buttons
#undef web_keys
#undef web_enc
#undef web_master
#undef web_nor_erase
#undef web_ms
#undef web_frame
#define SH_FLOAT
#define SH_OUT_L sh_lp
#define SH_OUT_R sh_rp
#define SH_RENDERF(n) sh_hr(n)
#define SH_ADC(m) sim_master(m)
static void SH_BOOT(void) { sim_init(1); }
static void SH_FRAME(uint32_t ms)
{
    const uint16_t *p = (const uint16_t *)sim_fb();
    uint32_t i;
    (void)ms;
    for (i = 0; i < 57600u; i++) if (shl_fb[i] != sh_be16(p[i])) sh_put(i, sh_be16(p[i]));
}
static float sh_l[1024], sh_r[1024];
static float *sh_lp(void) { return sh_l; }
static float *sh_rp(void) { return sh_r; }
static void sh_hr(uint32_t n)
{
    uint32_t i;
    const float *a = sim_audio();
    sim_render(n);
    for (i = 0; i < n; i++) { sh_l[i] = a[2u * i]; sh_r[i] = a[2u * i + 1u]; }
}
static uint32_t sh_label(uint32_t raw) { return raw < 2u ? raw + 12u : raw - 2u; }
static int sh_role(uint32_t hw) { static const uint8_t R[7] = {0, 1, 3, 4, 5, 6, 2}; return R[hw]; }
#define SH_ENC(e, n) sim_enc(sh_role(e), (n))
#define SH_BTN(i, d) sim_btn(sh_label(i), (d))
#define SH_KEY(k, d) sim_key((k), (d))
#define SH_KEY_LED(k) (sim_key_leds() >> (k) & 1u ? 2 : 0)
#define SH_BTN_LED(i) (sim_leds() >> sh_label(i) & 1u ? 2 : 0)
#include "../../../common/shell_post.h"

/* ---------------------------------------------------------------- MIDI (teensy-fm1) --- */
/* The runtime (src/main.rs) hands in whole messages from the FM-1's TRS jack and the Teensy's USB MIDI port, and takes
 * the firmware's MIDI out for USB. usb.config stands in for "a USB MIDI host is there", as on the FM-1 itself.
 * (added by tools_night/addmidi.py, docs/MIDI.md) */
EXPORT void teensy_midi_in(uint32_t st, uint32_t d1, uint32_t d2, uint32_t source)
{
    if (st >= 0xF8u) {
        if (st == 0xF8u || st == 0xFAu || st == 0xFBu || st == 0xFCu)
            (void)midi_enqueue(0xFu | st << 8, source);
        return;
    }
    if (st < 0x80u || st >= 0xF0u)
        return;
    (void)midi_enqueue((st >> 4) | st << 8 | (d1 & 127u) << 16 | (d2 & 127u) << 24, source);
}
EXPORT void teensy_midi_link(uint32_t on) { usb.config = on ? 1u : 0u; }
EXPORT uint32_t teensy_midi_out(uint32_t *out, uint32_t cap)
{
    uint32_t n = 0;
    while (n < cap && mo_r != mo_w) {
        out[n++] = midi_out_q[mo_r % MQ];
        mo_r++;
    }
    return n;
}
