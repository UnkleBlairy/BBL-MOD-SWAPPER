/* SPDX-License-Identifier: GPL-3.0-only */
/* DUELL 0.2.9: OCT- held + a knob turned = that card to its DEFAULT (ui_input.c knob_reset), and OCT- / OCT+ move the octave when LET GO (oct_rel).
 *   RESET      a plain parameter (AMP ENV ATK), PERFORM's four cards, MIXER's LEVEL 1 / LEVEL 2 / PAN 1 / PAN 2 (0.2.25: GLO's first page; item 117 order), MODE's BAL, TEMPO (BPM, SWG): to the table's default / the natural
 *              zero; once per gesture ("RESET .." in the header), the turn is not applied, further detents are ignored until the knob has been still ~300 ms
 *              (also after OCT- is let go); a card that is not drawn (MIXER PAN in DUEL mode) and an action page: nothing; normal turning is unchanged
 *   OCTAVE     a tap moves it on release (not on press); OCT- used as a modifier moves no octave; both together still reset it to 0
 * Built and run by DUELL/host_tests.sh (name: reset): the UI sources against ui_test.c's stub display and knobs. */
#define UI_TEST_NO_MAIN 1
#include "ui_test.c"

static int bad, ncheck;
static int expect(const char *what, int ok)
{
    ncheck++;
    if (!ok) {
        printf("reset: FAIL %s\n", what);
        bad++;
    }
    return ok;
}
static int said_reset(void) { return ui.msg_t && ui.msg[0] == 'R' && ui.msg[1] == 'E' && ui.msg[2] == 'S' && ui.msg[3] == 'E' && ui.msg[4] == 'T' && ui.msg[5] == ' '; }
static void quiet(void) { frames(400); }                    /* the knob still for > 300 ms */
static void page(const char *title) { ui_power_on(); go_title(title); song.octave = 0; ui.msg_t = 0; frames(400); }

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    /* a plain parameter */
    page("AMP ENV");
    TSEL->p[P_ATK] = 90;
    turn(EN_K1, 3);
    expect("no OCT-: a turn is a turn (ATK moved up)", TSEL->p[P_ATK] == 93 && !said_reset());
    btn_down(B_OCTDN); frame();
    turn(EN_K1, 3);
    expect("OCT- + KNOB 1: ATK to its default, said once", TSEL->p[P_ATK] == TP[P_ATK].def);
    ui.msg_t = 0;
    turn(EN_K1, 5); turn(EN_K1, -2); turn(EN_K1, 1);
    expect("  .. further detents of the gesture are ignored, no creeping, no second message", TSEL->p[P_ATK] == TP[P_ATK].def && !said_reset());
    btn_up(B_OCTDN); frame();
    turn(EN_K1, 4);
    expect("  .. also after OCT- is let go while the knob goes on", TSEL->p[P_ATK] == TP[P_ATK].def);
    expect("  .. and OCT- used as a modifier moved no octave", song.octave == 0);
    quiet();
    turn(EN_K1, 4);
    expect("  .. the knob still for 300 ms: it turns again", TSEL->p[P_ATK] == TP[P_ATK].def + 4);
    TSEL->p[P_DEC] = 5;
    btn_down(B_OCTDN); frame();
    turn(EN_K2, 1);
    expect("another knob of the same hold resets its own card", TSEL->p[P_DEC] == TP[P_DEC].def);
    btn_up(B_OCTDN); frame(); frame();
    expect("  .. no octave on release", song.octave == 0);

    /* the octave: on release; a tap; both together */
    page("AMP ENV");
    btn_down(B_OCTUP); frame(); frame();
    expect("OCT+ held: the octave has not moved yet", song.octave == 0);
    btn_up(B_OCTUP); frame();
    expect("  .. let go: +1", song.octave == 1);
    btn_down(B_OCTDN); frame(); btn_up(B_OCTDN); frame(); frame();
    expect("OCT- tapped: -1 on release", song.octave == 0);
    btn_down(B_OCTDN); frame(); btn_up(B_OCTDN); frame(); frame();
    expect("OCT- tapped again: -1", song.octave == -1);
    song.octave = 2;
    btn_down(B_OCTDN); frame(); btn_down(B_OCTUP); frame();
    expect("OCT- + OCT+ together: the octave to 0", song.octave == 0);
    btn_up(B_OCTDN); frame(); btn_up(B_OCTUP); frame(); frame();
    expect("  .. and no step on their release", song.octave == 0);
    song.octave = 1;
    btn_down(B_OCTUP); frame(); btn_down(B_OCTDN); frame(); btn_up(B_OCTUP); frame(); btn_up(B_OCTDN); frame(); frame();
    expect("  .. either order", song.octave == 0);
    song.octave = 3;
    press(B_OCTUP);
    expect("OCT+ at +3 stays", song.octave == 3);
    song.octave = 0;

    /* a modifier turn does not move the octave, even when OCT+ is tapped meanwhile? (that is the chord: 0) */
    page("AMP ENV");
    btn_down(B_OCTDN); frame(); turn(EN_K1, 1); btn_up(B_OCTDN); frame(); frame();
    expect("OCT- + a knob + let go: no octave", song.octave == 0);
    btn_down(B_OCTDN); frame(); btn_up(B_OCTDN); frame(); frame();
    expect("  .. the next tap is a tap again (the modifier flag is gone)", song.octave == -1);

    /* PERFORM */
    page("AMP ENV");
    ui.perf = 1; frames(32);
    morph_act(MQ_FADER, morph_mask(song.sel), 60u, song.sel);
    perf_space = 40; perf_filt = -50; perf_depth = 30;
    btn_down(B_OCTDN); frame();
    turn(EN_K1, -1);                                    /* (DUELL 1.3: K1 DEPTH, fixed; K2 K3 K4 the picks, by default MORPH SPACE KILL) */
    expect("PERFORM K1 DEPTH: 100", perf_depth == 100);
    quiet(); turn(EN_K2, 1);
    expect("PERFORM K2 MORPH: 0 (A)", morph_fader_of(song.sel) == 0u);
    quiet(); turn(EN_K3, 1);
    expect("PERFORM K3 SPACE: 0", perf_space == 0);
    quiet(); turn(EN_K4, -1);
    expect("PERFORM K4 KILL: 0", perf_filt == 0);
    btn_up(B_OCTDN); frame(); frame();
    quiet();
    turn(EN_K4, 5);
    expect("PERFORM without OCT-: normal turn", perf_filt == 5);
    ui.perf = 0;

    /* MIXER (0.2.25 layout round: GLO's first page, item 117 order K1 LEVEL 1, K2 LEVEL 2, K3 PAN 1, K4 PAN 2; the mutes are keys, SPACE is PERFORM's) */
    page("MIXER");
    duell_mode_req = DM_STEREO;
    trk[0].p[P_LEVEL] = 40; trk[0].p[P_PAN] = 20; trk[1].p[P_LEVEL] = 30; trk[1].p[P_PAN] = -20; trk[0].p[P_REV] = 60; perf_space = 40;
    btn_down(B_OCTDN); frame();
    turn(EN_K1, 1);
    expect("MIXER K1 LEVEL 1: its default", trk[0].p[P_LEVEL] == TP[P_LEVEL].def);
    quiet(); turn(EN_K2, 1);
    expect("MIXER K2 LEVEL 2: its default", trk[1].p[P_LEVEL] == TP[P_LEVEL].def);
    quiet(); turn(EN_K3, 1);
    expect("MIXER K3 PAN 1: centre", trk[0].p[P_PAN] == 0);
    quiet(); turn(EN_K4, -1);
    expect("MIXER K4 PAN 2: centre; SPACE and the REV send untouched", trk[1].p[P_PAN] == 0 && perf_space == 40 && trk[0].p[P_REV] == 60);
    btn_up(B_OCTDN); frame(); frame();
    expect("  .. (the hold was a modifier: no octave on release)", song.octave == 0);
    song.octave = 0;
    duell_mode_req = DM_SPLIT;
    trk[0].p[P_PAN] = 20;
    quiet();
    btn_down(B_OCTDN); frame(); turn(EN_K3, 1); btn_up(B_OCTDN); frame(); frame();
    expect("MIXER PAN 1 (K3) in DUEL mode (no card): nothing", trk[0].p[P_PAN] == 20 && song.octave == 0);
    duell_mode_req = DM_STEREO;
    perf_space = 0;

    /* MODE: K2 (item 157: no BALANCE card; nothing to reset; item 160: the balance is the two MIXER LEVELs, PERFORM's SELECT, not touched here) */
    page("MODE");
    trk[0].p[P_LEVEL] = 100, trk[1].p[P_LEVEL] = 112;
    btn_down(B_OCTDN); frame(); turn(EN_K2, -1); btn_up(B_OCTDN); frame();
    printf("reset: MODE OCT- + K2: octave after %d\n", (int)song.octave);
    expect("MODE K2 (no card): OCT- + the knob resets nothing, the LEVELs stay", trk[0].p[P_LEVEL] == 100 && trk[1].p[P_LEVEL] == 112 && !said_reset());
    trk[0].p[P_LEVEL] = trk[1].p[P_LEVEL] = 112;
    song.octave = 0;

    /* the REVERB page's LOCUT (0.2.14): K4, to its default 75 (299 Hz; 61 = 88 Hz up to 0.2.21); and a turn is a turn, 1 step */
    page("REVERB");
    song.g[G_RLOCUT] = 0;
    turn(EN_K4, 3);
    expect("REVERB K4 LOCUT: a plain turn moves it", song.g[G_RLOCUT] == 3 && !said_reset());
    btn_down(B_OCTDN); frame(); turn(EN_K4, 1);
    expect("REVERB K4 LOCUT: OCT- + the knob, its default 75", song.g[G_RLOCUT] == GP[G_RLOCUT].def && GP[G_RLOCUT].def == 75);
    btn_up(B_OCTDN); frame(); frame();

    /* TEMPO */
    page("TEMPO");
    song.g[G_BPM] = 150; song.g[G_SWING] = 40; song.g[G_CLOCK] = 0;
    btn_down(B_OCTDN); frame(); turn(EN_K2, 1); quiet(); turn(EN_K4, 1);
    expect("TEMPO K2 / K4: their defaults", song.g[G_BPM] == GP[G_BPM].def && song.g[G_SWING] == GP[G_SWING].def);
    quiet(); ui.msg_t = 0;
    turn(EN_K3, 1);
    expect("TEMPO K3 TAP is no parameter: no reset", !said_reset());
    btn_up(B_OCTDN); frame();

    /* item 94: OCT- + a knob with no reset (SCALE K3 OFF-SCALE): the turn is swallowed, the value stays, no octave on release */
    page("SCALE");
    scale_g = 2; offscale_g = OS_SNAP; ui.msg_t = 0;
    btn_down(B_OCTDN); frame(); turn(EN_K3, 1);
    expect("OCT- + a knob without a reset: the value does not change", offscale_g == OS_SNAP);
    btn_up(B_OCTDN); frame(); frame();
    expect("  .. and no octave on release", song.octave == 0);
    quiet();
    turn(EN_K3, 1);
    expect("  .. without OCT- the same knob turns", offscale_g == OS_PLAY);

    /* item 94: OCT- merely HELD shows no OCTAVE page; it shows after the octave has really moved */
    page("AMP ENV");
    btn_down(B_OCTDN); frames(400);
    expect("OCT- held 400 ms: no OCTAVE overlay", !oct_show_on());
    btn_up(B_OCTDN); frame(); frame();
    expect("  .. after the release the octave moved and the overlay shows", song.octave == -1 && oct_show_on());
    song.octave = 0;

    /* an action page: OCT- stays "back" */
    page("TOOLS");
    expect("TOOLS is an action page", act_cols() != 0u);
    TSEL->p[P_ATK] = 90;
    btn_down(B_OCTDN); frame(); turn(EN_K1, 1);
    expect("action page: no reset", !said_reset());
    btn_up(B_OCTDN); frame(); frame();

    /* 0.2.10: the QUICK EDIT layers reset their cards too (ui_layer.c layer_quick_reset); OCT- then neither puts back nor moves the octave */
    page("MIXER");
    btn_down(B_ENV); frames(640);
    expect("QUICK ENV open", ui.layer == LAYER_ENV);
    TSEL->p[P_ATK] = 90; ui.msg_t = 0;
    btn_down(B_OCTDN); frame();
    turn(EN_K1, 3);
    expect("QUICK ENV + OCT- + KNOB 1: AMP ATK to its default, said", TSEL->p[P_ATK] == TP[P_ATK].def && ui.layer == LAYER_ENV);
    ui.msg_t = 0;
    turn(EN_K1, 4);
    expect("  .. further detents ignored (no creeping)", TSEL->p[P_ATK] == TP[P_ATK].def && !said_reset());
    btn_up(B_OCTDN); frame(); frame();
    expect("  .. OCT- let go: no octave", song.octave == 0);
    btn_up(B_ENV); frames(64); quiet();
    page("MIXER");
    btn_down(B_ARP); frames(640);
    TSEL->p[P_AOCT] = (int16_t)(TP[P_AOCT].def + 2);
    btn_down(B_OCTDN); frame(); turn(EN_K4, -1); btn_up(B_OCTDN); frame(); frame();
    expect("QUICK ARP + OCT- + KNOB 4: OCT to its default, no octave", ui.layer == LAYER_ARP && TSEL->p[P_AOCT] == TP[P_AOCT].def && song.octave == 0);
    btn_down(B_OCTDN); frame(); btn_up(B_OCTDN); frame(); frame();
    expect("  .. a plain OCT- tap there is still the octave", song.octave == -1);
    btn_up(B_ARP); frames(64); quiet();
    page("MIXER");
    init_engine_of(TSEL, 2u);                                 /* PHASE: QUICK FILTER is the multimode filter's CUT RES MODE + AMP REL */
    {
        int16_t c0, r0;
        TSEL->p[P_FREEB] = (int16_t)(TP[P_FREEB].def + 20);
        r0 = TSEL->p[P_FREEB];
        c0 = TSEL->p[P_FREEA];
        btn_down(B_EDIT); frames(640);
        expect("QUICK FILTER open", ui.layer == LAYER_EDIT);
        turn(EN_K1, -4);
        expect("  CUT turned", TSEL->p[P_FREEA] != c0);
        quiet(); ui.msg_t = 0;
        btn_down(B_OCTDN); frame(); turn(EN_K2, 1);
        expect("QUICK FILTER + OCT- + KNOB 2: RES to its default, said", TSEL->p[P_FREEB] == TP[P_FREEB].def);
        btn_up(B_OCTDN); frame(); frame();
        expect("  .. OCT- let go after the reset: no put back (CUT stays turned), no octave",
               TSEL->p[P_FREEA] != c0 && TSEL->p[P_FREEB] == TP[P_FREEB].def && song.octave == 0 && !msg_is("VALUES PUT BACK"));
        quiet();
        btn_down(B_OCTDN); frame(); btn_up(B_OCTDN); frame(); frame();
        expect("  .. a plain OCT- tap: put back as it opened (CUT and RES), no octave",
               TSEL->p[P_FREEA] == c0 && TSEL->p[P_FREEB] == r0 && song.octave == 0 && msg_is("VALUES PUT BACK"));
        btn_up(B_EDIT); frames(64);
    }

    printf("reset: %d checks, %d failed\n", ncheck, bad);
    return bad ? 1 : 0;
}
