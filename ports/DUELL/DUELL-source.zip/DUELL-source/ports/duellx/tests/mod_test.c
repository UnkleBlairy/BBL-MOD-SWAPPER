/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Host test of the modulation matrix (firmware/src/mod.c), same sources as the firmware (through hostsim.c):
 *   build/host/mod_test [DEMO_DIR]      (run_tests.sh builds and runs it; demos in build/mod_demo/)
 * 1. off: slots that do nothing (SRC, DST or AMT at 0) render bit-identically to no matrix at all; the
 *    stored parameters are never left modulated after a block.
 * 2. the math: every source on each kind of destination (per voice: PITCH CUT SHP AMP; per block: PAN, the
 *    sends, RATE, VIB, an engine parameter), bipolar sources and amounts, sums, clamping to the ranges,
 *    per-voice sources on per-block destinations (the latest note-on), RAND without the shared rng.
 * 3. MIDI: CC1 / CC11 / CC121 and channel aftertouch over USB (packets) and TRS (bytes, running status) reach
 *    the matrix of the channel's track (ch 1..4 the parts, others ignored with ROUT CH1-4; with ROUT SEL every
 *    channel the selected track).
 * 4. cost: instructions per sample (kernel-counted) of the heaviest PHYS preset and of a 4-part mix with every
 *    slot of every part active, against the same with the matrix off; fails above MOD_COST_MAX.
 * 5. demos: LFO -> CUT, VEL -> AMP, MODW -> VIB, LFO -> TRIO PW, AT -> WHEEL DRV as WAVs in DEMO_DIR. */
#define main hostsim_main
#include "hostsim.c"
#undef main
#ifdef __APPLE__
#include <libproc.h>
#include <sys/resource.h>
#endif

#define MOD_COST_MAX 9.2          /* % more instructions per sample with every slot active, at most (0.2.25: was 8.0; the source slew, mod.c mx_slew, adds about 1 instruction a sample for 8 active slots, the 4-part case read 8.1 %; was 7.0: the optimised PHASE engine made the base cheaper, the same +59 instructions is now 7.1 %; was 5.0 earlier: the hidden parts 3 and 4 no longer render, so the idle mix is smaller and the same absolute cost is a larger percentage; DUELL: 8 slots, ENV2, LFO2, MORPH) */

static int bad;
static void check(const char *what, int ok)
{
    printf("mod: %-74s %s\n", what, ok ? "ok" : "FAIL");
    bad += !ok;
}

static int32_t out_buf[2 * CTL];
static uint64_t hash;
static void blocks(uint32_t n)
{
    uint32_t i, k;
    while (n--) {
        mix_block(out_buf, CTL);
        for (i = 0; i < 2u * CTL; i++)
            for (k = 0; k < 4u; k++) {
                hash ^= ((uint32_t)out_buf[i] >> (8u * k)) & 0xFFu;
                hash *= 0x100000001B3ull;
            }
    }
}

static void slot(track_t *t, uint32_t k, int32_t s, int32_t d, int32_t a)
{
    t->p[P_M1SRC + 3u * k] = (int16_t)s;
    t->p[P_M1DST + 3u * k] = (int16_t)d;
    t->p[P_M1AMT + 3u * k] = (int16_t)a;
}

/* 0.2.25: the matrix's source slew (mod.c mx_slew) forgets the values of the block before: the next mod_begin takes every source at once */
static void unslew(void) { uint32_t i; for (i = 0; i < NLIVE; i++) mx_sl[i].ok = 0; }

static uint32_t eng_by_name(const char *n)
{
    uint32_t e;
    for (e = 0; e < NENGINES; e++)
        if (str_eq(ENGINES[e]->name, n))
            return e;
    return 0;
}
static uint32_t edit_by_label(uint32_t e, const char *l, uint32_t fallback)   /* E index 0..7 */
{
    uint32_t k;
    for (k = 0; k < 8u; k++)
        if (str_eq(ENGINES[e]->edit[k].label, l))
            return k;
    return fallback;
}
static uint32_t preset_by_name(uint32_t e, const char *n)
{
    uint32_t k;
    for (k = 0; k < ENGINES[e]->npresets; k++)
        if (str_eq(ENGINES[e]->presets[k].name, n))
            return k;
    return 0;
}

static void fresh(uint32_t e, uint32_t pi)        /* the boot state (no FX tails), track 1 = engine e preset pi */
{
    uint32_t k;
    memset(dly_buf, 0, sizeof dly_buf);
    memset(cho_buf, 0, sizeof cho_buf);
    memset(rev_comb, 0, sizeof rev_comb);
    memset(rev_ap, 0, sizeof rev_ap);
    memset(&fx, 0, sizeof fx);
    lim_env = LIM_T;
    memset(trk, 0, sizeof trk);
    memset(&trk[0].mdw, 0, sizeof trk[0].mdw);
    memset(mod_goff, 0, sizeof mod_goff);           /* (0.2.7: no bus offset, DUCK flag or written bus value left over) */
    trk[0].mgon = trk[1].mgon = trk[0].mdk = trk[1].mdk = 0, mod_gw = 0;
    unslew();
    host_tracks_init();
    for (k = 0; k < NPART; k++)
        host_preset(&trk[k], k ? 0u : e, k ? 0u : pi);
    song.sel = 0;
    hash = 0xCBF29CE484222325ull;
}

/* a phrase on track 1: a chord, a note, releases; the hash of the output */
static uint64_t phrase(void)
{
    track_t *t = &trk[0];
    trk_note_on(t, 60, 100);
    trk_note_on(t, 64, 70);
    trk_note_on(t, 67, 120);
    blocks(FS / 2u / CTL);
    trk_note_on(t, 72, 90);
    blocks(FS / 4u / CTL);
    trk_note_off(t, 60);
    trk_note_off(t, 64);
    trk_note_off(t, 67);
    trk_note_off(t, 72);
    blocks(FS / CTL);
    return hash;
}

/* ------------------------------------------------------------------ 1 --- */
/* the phrase's hash in a fork()ed child (the seeds as they were: the same in each); setup k:
 * 0 no matrix, 1 slots that do nothing, 2 an active matrix. The child answers 0 when p[] was left changed */
static uint64_t phrase_child(uint32_t k)
{
    int fd[2];
    uint64_t h = 0;
    pid_t pid;
    if (pipe(fd))
        return 0;
    fflush(stdout);
    if (!(pid = fork())) {
        int16_t keep[P_COUNT];
        fresh(0, 0);
        if (k == 1u) {
            slot(&trk[0], 0, MS_LFO, MD_CUT, 0);   /* AMT 0 */
            slot(&trk[0], 1, MS_OFF, MD_PAN, 40);  /* SRC OFF */
            slot(&trk[0], 2, MS_VEL, MD_OFF, -30); /* DST OFF */
        } else if (k == 2u) {
            slot(&trk[0], 0, MS_LFO, MD_CUT, 40);
            slot(&trk[0], 1, MS_MODW, MD_PAN, 63);
            slot(&trk[0], 2, MS_LFO, MD_E1 + 4, -50);
            slot(&trk[0], 3, MS_ENV, MD_REV, 30);
            trk[0].mw = 100;
        }
        memcpy(keep, trk[0].p, sizeof keep);
        h = phrase();
        if (memcmp(keep, trk[0].p, sizeof keep) || trk[0].mdw.on)
            h = 0;
        if (write(fd[1], &h, sizeof h) != sizeof h)
            _exit(1);
        _exit(0);
    }
    close(fd[1]);
    if (read(fd[0], &h, sizeof h) != sizeof h)
        h = 0;
    close(fd[0]);
    waitpid(pid, 0, 0);
    return h;
}

static void test_off(void)
{
    uint64_t h0 = phrase_child(0), h1 = phrase_child(1), h2 = phrase_child(2);
    check("slots that do nothing: bit-identical to the matrix off", h0 && h0 == h1);
    check("an active matrix changes the sound, and leaves no modulated value in p[]", h2 && h2 != h0);
}

/* ------------------------------------------------------------------ 2 --- */
static void lfo_at(track_t *t, int32_t v)          /* the LFO value the next block's matrix sees */
{
    t->lfo_val = v;
    t->lfo_fade = 32767;
}

static void test_math(void)
{
    track_t *t = &trk[0];
    int32_t lfo;
    vmod_t m;
    voice_t *v;
    uint32_t e_trio, k_pw;

    /* per-track sources on per-voice destinations */
    fresh(0, 0);
    lfo_at(t, 32767);
    lfo = mulq15(32767, 32767);
    slot(t, 0, MS_LFO, MD_CUT, 63);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("LFO -> CUT +63: +64 steps at the top of the LFO (63 acts as 64, 1.0)", trk[0].mdw.on && trk[0].mdw.cut == (lfo * 64) >> 7 && trk[0].mdw.cut / 256 == 63);   /* (1.0: AMT +63 acts as 64, a true 100 %: mod.c MX_AMT) */
    mod_end(t);
    slot(t, 0, MS_LFO, MD_PITCH, 63);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("LFO -> PITCH +63: +12 semitones (63 acts as 64, 1.0)", trk[0].mdw.pit == (lfo * 64 * 3) >> 15 && trk[0].mdw.pit == 191);
    mod_end(t);
    lfo_at(t, -32768);
    slot(t, 0, MS_LFO, MD_SHP, 63);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("LFO bipolar: the bottom of the LFO pulls SHP down", trk[0].mdw.shp < -16000);
    mod_end(t);
    slot(t, 0, MS_LFO, MD_SHP, -64);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("a negative AMT inverts it", trk[0].mdw.shp > 16000);
    mod_end(t);
    lfo_at(t, 0);
    slot(t, 0, MS_MODW, MD_AMP, 64 - 1);
    t->mw = 0;
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("MODW -> AMP +63: the wheel down closes the amp (gain 0, 1.0: it was 1.6 % open)", trk[0].mdw.amp && trk[0].mdw.gain == 0);
    mod_end(t);
    t->mw = 127;
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("MODW -> AMP +63: the wheel up opens it fully", trk[0].mdw.gain >= 32760);
    mod_end(t);
    slot(t, 0, MS_AT, MD_AMP, -64);
    t->at = 127;
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("AT -> AMP -64: full pressure closes it", trk[0].mdw.gain < 200);
    mod_end(t);
    slot(t, 0, MS_EXPR, MD_AMP, 63);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("EXPR before any CC11 is full (the MIDI default): AMP open", trk[0].mdw.gain >= 32760);
    mod_end(t);
    slot(t, 0, MS_LFO, MD_AMP, 64 - 1);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("LFO -> AMP: bipolar as 0..1 (half way at an LFO of 0)", trk[0].mdw.gain > 16000 && trk[0].mdw.gain < 17000);
    mod_end(t);

    /* per-voice sources on per-voice destinations (mod_voice) */
    fresh(0, 0);
    t->p[P_VOICE] = V_POLY;
    slot(t, 0, MS_KEY, MD_CUT, 63);
    slot(t, 1, MS_VEL, MD_AMP, 63);
    slot(t, 2, MS_ENV, MD_SHP, 40);
    slot(t, 3, MS_RAND, MD_PITCH, 20);
    {
        uint32_t rs = rng_state;
        trk_note_on(t, 72, 127);
        trk_note_on(t, 48, 1);
        check("RAND per note-on: its own generator (the shared rng untouched)", rng_state == rs && t->v[0].mrnd != t->v[1].mrnd);
    }
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    memset(&m, 0, sizeof m);
    m.envq15 = 16384;
    m.shape = 64 << 8;
    m.pitch16 = 1000;
    m.inc = pitch_inc(1000);
    m.amp1 = 20000;
    v = &t->v[0];
    mod_voice(t, v, &m, 0);
    check("KEY -> CUT +63: an octave above C4 = +12 steps (key tracking 1:1; 63 acts as 64, 1.0)", m.cutoff == (12 * 512 * 64) >> 7 && m.cutoff / 256 == 12);
    check("VEL -> AMP +63: velocity 127 keeps the amplitude", m.amp1 == mulq15(20000, mulq15(32767, mod_gain(MS_VEL, 127 * 258, 64))) && m.amp1 > 19900 && v->env_out == m.amp1);
    check("ENV -> SHP +40: half the envelope = +20 steps", m.shape == (64 << 8) + ((16384 * 41) >> 7));   /* (+40 acts as 41, 1.0) */
    check("RAND -> PITCH: the voice's own random offset", m.pitch16 == 1000 + ((v->mrnd * 20 * 3) >> 15) && m.inc == pitch_inc(m.pitch16));
    memset(&m, 0, sizeof m);
    m.amp1 = 20000;
    mod_voice(t, &t->v[1], &m, 0);
    check("KEY below C4 negative, VEL 1 -> AMP almost closed", m.cutoff == -((12 * 512 * 64) >> 7) && m.amp1 < 600);
    mod_end(t);

    /* clamping of the per-voice sums */
    fresh(0, 0);
    lfo_at(t, 32767);
    for (k_pw = 0; k_pw < 4u; k_pw++)
        slot(t, k_pw, MS_LFO, k_pw < 2u ? MD_CUT : MD_PITCH, 63);
    trk_note_on(t, 120, 100);
    lfo_at(t, 32767);                              /* (a note-on restarts the LFO and its FADE) */
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    memset(&m, 0, sizeof m);
    m.cutoff = 100 << 8;
    m.pitch16 = 1920;
    mod_voice(t, &t->v[0], &m, 0);
    check("CUT sums clamp to what the fixed routings reach (+150), PITCH to 2047", m.cutoff == 150 * 256 && m.pitch16 == 2047);
    mod_end(t);

    /* per-block destinations: AMT 64 = the whole range, clamped, restored */
    fresh(0, 0);
    t->p[P_PAN] = 0;
    t->mw = 127;
    slot(t, 0, MS_MODW, MD_PAN, 16);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("MODW -> PAN +16: a quarter of the range (+31)", t->p[P_PAN] == ((((127 * 258) * 16) >> 6) * 127 >> 15) && t->p[P_PAN] == 31);
    mod_end(t);
    check("PAN restored after the block", t->p[P_PAN] == 0);
    slot(t, 1, MS_MODW, MD_PAN, 16);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("two slots on PAN add up (+62)", t->p[P_PAN] == 62);
    mod_end(t);
    slot(t, 1, MS_MODW, MD_PAN, 63);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("PAN clamps to +63", t->p[P_PAN] == 63);
    mod_end(t);
    slot(t, 1, MS_OFF, MD_OFF, 0);
    slot(t, 0, MS_AT, MD_REV, -64);
    t->at = 127;
    t->p[P_REV] = 50;
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("AT -> REV -64: the send down to 0 (clamped)", t->p[P_REV] == 0);
    mod_end(t);
    lfo_at(t, -32768);
    slot(t, 0, MS_LFO, MD_DIST, 32);
    slot(t, 1, MS_LFO, MD_CHO, -32);
    slot(t, 2, MS_LFO, MD_RATE, 32);
    slot(t, 3, MS_LFO, MD_VIB, 32);
    t->p[P_DIST] = t->p[P_CHOR] = 64;
    t->p[P_LRATE] = 100;
    t->p[P_LD_PIT] = 0;
    lfo = mulq15(-32768, 32767);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    {
        int32_t up = (((lfo * 33) >> 7) * 127) >> 15, dn = (((lfo * -32) >> 7) * 127) >> 15;
        check("LFO -> DIST / CHO (+-32), RATE, VIB: bipolar, a quarter of the range each way",
              up < -15 && dn > 15 && t->p[P_DIST] == 64 + up && t->p[P_CHOR] == 64 + dn && t->p[P_LRATE] == 100 + up &&
              t->p[P_LD_PIT] == up);
    }
    mod_end(t);
    check("every per-block value restored", t->p[P_DIST] == 64 && t->p[P_CHOR] == 64 && t->p[P_LRATE] == 100 && t->p[P_LD_PIT] == 0);

    /* an engine parameter: its descriptor's range */
    e_trio = eng_by_name("TRIO");
    k_pw = edit_by_label(e_trio, "PW", 7);
    fresh(e_trio, 0);
    lfo_at(t, 32767);
    t->p[P_E0 + k_pw] = 100;
    slot(t, 0, MS_LFO, MD_E1 + (int32_t)k_pw, 40);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("LFO -> TRIO PW: clamped to its range (0..127)", t->p[P_E0 + k_pw] == 127);
    mod_end(t);
    t->p[P_E0 + 1] = 0;                            /* INT2: -24..24 */
    slot(t, 0, MS_MODW, MD_E1 + 1, -32);
    t->mw = 127;
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    check("MODW -> E2 -32: half its range down (TRIO INT2 -24..24: -24)",
          t->p[P_E0 + 1] == (((((127 * 258) * -32) >> 6) * (ENGINES[e_trio]->edit[1].max - ENGINES[e_trio]->edit[1].min)) >> 15) &&
          t->p[P_E0 + 1] < -10);
    mod_end(t);
    check("the engine parameters restored", t->p[P_E0 + k_pw] == 100 && t->p[P_E0 + 1] == 0);
    check("DST names: E1..E8 by the engine's labels", str_eq(mod_dst_name(t, MD_E1 + (int32_t)k_pw), "PW") &&
                                                          str_eq(mod_dst_name(t, MD_CUT), "MULTI\nCUTOFF"));

    /* per-voice sources on a per-block destination: the latest note-on */
    fresh(0, 0);
    slot(t, 0, MS_VEL, MD_PAN, 63);
    trk_note_on(t, 60, 20);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    {
        int32_t p1 = t->p[P_PAN];
        mod_end(t);
        trk_note_on(t, 64, 127);
        unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
        mod_begin(t);
        check("VEL -> PAN: the latest note-on's velocity", p1 == ((((20 * 258) * 63) >> 6) * 127 >> 15) && t->p[P_PAN] == 63);
        mod_end(t);
    }
    slot(t, 0, MS_KEY, MD_DLY, 63);
    t->p[P_DLY] = 64;
    mod_begin(t);
    check("KEY -> DLY: the latest note (E4: +4 semitones)", t->p[P_DLY] == 64 + ((((4 * 512) * 63) >> 7) * 127 >> 15));
    mod_end(t);
    slot(t, 0, MS_ENV, MD_PAN, 63);
    blocks(FS / 10u / CTL);
    mod_begin(t);
    check("ENV -> PAN: the latest note's envelope (sounding: > 0)", t->p[P_PAN] > 20 && t->m_env > 0);
    mod_end(t);
}

/* ------------------------------------------------------------------ 3 --- */
static void pkt(uint32_t st, uint32_t d1, uint32_t d2)
{
    midi_in_q[mi_w++ % MQ] = (st >> 4) | st << 8 | d1 << 16 | d2 << 24;
}
/* fn() in a fork()ed child (the tests' state stays as it was); its result */
static int in_child(int (*fn)(void))
{
    int st = 0;
    pid_t pid;
    fflush(stdout);
    if (!(pid = fork()))
        _exit(fn() ? 0 : 1);
    waitpid(pid, &st, 0);
    return WIFEXITED(st) && WEXITSTATUS(st) == 0;
}
static int pan_e2e(void)                       /* MODW -> PAN moves the pan the mix uses */
{
    int64_t l = 0, r = 0;
    uint32_t i, k;
    fresh(0, 0);
    slot(&trk[0], 0, MS_MODW, MD_PAN, 63);
    trk[0].p[P_CHOR] = trk[0].p[P_DLY] = trk[0].p[P_REV] = 0;   /* (the buses are in the middle) */
    pkt(0xB0, 1, 127);
    trk_note_on(&trk[0], 60, 100);
    blocks(FS / 10u / CTL);
    for (k = 0; k < FS / 10u / CTL; k++) {
        blocks(1);
        for (i = 0; i < CTL; i++) {
            l += labs(out_buf[2u * i]);
            r += labs(out_buf[2u * i + 1u]);
        }
    }
    return r > 20 * l && l > 0 && trk[0].p[P_PAN] == 0;
}

static void test_midi(void)
{
    static const uint8_t TRS[] = {0xB0, 1, 0x40, 1, 0x7F, 0xF8, 11, 0x20, 0xD1, 0x33, 0x34, 0x90, 60, 0, 0xB4, 1, 9};
    uint32_t i;
    fresh(0, 0);
    song.sel = 1;
    pkt(0xB0, 1, 100);                           /* ch 1 CC1 */
    pkt(0xB1, 11, 40);                           /* ch 2 CC11 */
    pkt(0xB2, 11, 99);                           /* ch 3 CC11: DUELL has two parts, ignored */
    pkt(0xD3, 77, 0);                            /* ch 4 aftertouch: ignored */
    pkt(0xB6, 1, 55);                            /* ch 7: ignored with ROUT CH1-4 (#68) */
    pkt(0xB0, 7, 10);                            /* other CCs: ignored */
    blocks(1);
    check("USB: CC1 ch 1 -> part 1, CC11 ch 2 -> part 2, ch 3 CC11 and ch 4 AT ignored (two parts)",
          trk[0].mw == 100 && trk[1].ex_off == 127 - 40 &&
          trk[0].at == 0 && trk[0].ex_off == 0);
    check("USB: ROUT CH1-4: CC1 on ch 7 reaches no track", trk[1].mw == 0);
    song.g[G_ROUTE] = 1;
    pkt(0xB6, 1, 55);                            /* ROUT SEL: ch 7 -> the selected track (2) */
    blocks(1);
    check("USB: ROUT SEL: CC1 on ch 7 -> the selected track (2)", trk[1].mw == 55);
    song.g[G_ROUTE] = 0;
    pkt(0xB0, 121, 0);                           /* reset all controllers */
    blocks(1);
    check("CC121 resets MODW / AT / EXPR of the channel's track", trk[0].mw == 0 && trk[1].mw == 55);
    fresh(0, 0);
    song.sel = 1;
    for (i = 0; i < sizeof TRS; i++)
        um_byte(TRS[i]);
    blocks(1);
    check("TRS: CC1, running status, realtime between, CC11, AT (1 data byte, running status) -> parts",
          trk[0].mw == 0x7F && trk[0].ex_off == 127 - 0x20 && trk[1].at == 0x34 && trk[0].at == 0);
    check("TRS: ROUT CH1-4: ch 5 is ignored", trk[1].mw == 0);
    song.g[G_ROUTE] = 1;
    for (i = 14; i < sizeof TRS; i++)           /* the ch 5 CC1 again with ROUT SEL */
        um_byte(TRS[i]);
    blocks(1);
    song.g[G_ROUTE] = 0;
    check("TRS: ROUT SEL: ch 5 -> the selected track (2)", trk[1].mw == 9);
    check("MODW -> PAN +63 through MIDI: the part is on the right (fresh FX)", in_child(pan_e2e));
}
/* ------------------------------------------------------------------ 4 --- */
static uint64_t instr_now(void)
{
#ifdef __APPLE__
    struct rusage_info_v4 ri;
    if (!proc_pid_rusage(getpid(), RUSAGE_INFO_V4, (rusage_info_t *)&ri))
        return ri.ri_instructions;
#endif
    return 0;
}

/* instructions per sample: parts[k] = {engine, preset, notes}; on: every slot of every sounding part active
 * (LFO -> CUT, VEL -> AMP, MODW -> VIB, LFO -> E3: per voice and per block) */
static double cost(const uint8_t parts[NPART][3], int on)
{
    static const uint8_t NOTES[8] = {48, 52, 55, 59, 60, 64, 67, 71};
    uint32_t p, i, rep;
    double best = 1e30;
    fresh(0, 0);
    for (p = 0; p < NPART; p++) {
        track_t *t = &trk[p];
        host_preset(t, parts[p][0], parts[p][1]);
        t->p[P_VOICE] = V_POLY;
        t->p[P_SUS] = 127;
        t->p[P_AMODE] = 0;
        t->mw = 90;
        if (on && parts[p][2]) {
            /* (the universal-filter engines: a route to CUT now runs their filter even at CUT OFF, costing what uf_test measures; the matrix's own cost is measured on SHP there) */
            slot(t, 0, MS_LFO, ENGINES[t->engine]->ufilt ? MD_SHP : MD_CUT, 30);
            slot(t, 1, MS_VEL, MD_AMP, 40);
            slot(t, 2, MS_MODW, MD_VIB, 8);
            slot(t, 3, MS_LFO, MD_E1 + 2, 20);
        }
        for (i = 0; i < parts[p][2]; i++)
            trk_note_on(t, NOTES[i] + 12u * p, 100);
    }
    blocks(FS / 2u / CTL);
    for (rep = 0; rep < 3u; rep++) {
        uint64_t i0 = instr_now();
        double ipc;
        blocks(FS / CTL);
        ipc = (double)(instr_now() - i0) / FS;
        best = ipc < best ? ipc : best;
    }
    return best;
}

static void test_cost(void)
{
    uint32_t e_phys = eng_by_name("PHYS"), pp = preset_by_name(e_phys, "BOWED METAL");
    uint8_t phys[NPART][3] = {{(uint8_t)e_phys, (uint8_t)pp, 8}}, idle[NPART][3] = {{0}};
    uint8_t mix[NPART][3] = {{1, 0, 8}, {2, 0, 8}, {(uint8_t)e_phys, (uint8_t)pp, 4}, {6, 0, 4}};
    double c_idle, c0, c1, m0, m1;
    if (!instr_now()) {
        printf("mod: cost: no instruction counter on this host (proc_pid_rusage), skipped\n");
        return;
    }
    c_idle = cost(idle, 0);
    c0 = cost(phys, 0);
    c1 = cost(phys, 1);
    m0 = cost(mix, 0);
    m1 = cost(mix, 1);
    printf("mod: cost: PHYS %s (plays 4 voices): %.0f -> %.0f instructions / sample with 4 slots (+%.0f, +%.1f %% of "
           "the part over the idle mix %.0f)\n", ENGINES[e_phys]->presets[pp].name, c0, c1, c1 - c0,
           (c1 - c0) * 100 / (c0 - c_idle), c_idle);
    printf("mod: cost: 4 parts (DIGITAL / its FM6 conversion 8 + PHASE 8 + PHYS 4 + TRIO 4 asked, the budget plays 8), every slot of "
           "every part active: %.0f -> %.0f (+%.1f %%)\n", m0, m1, (m1 - m0) * 100 / m0);
    check("cost: 4 active slots add at most a few percent (PHYS part, the 4-part mix)",
          (c1 - c0) * 100 / (c0 - c_idle) <= MOD_COST_MAX && (m1 - m0) * 100 / m0 <= MOD_COST_MAX);
}

/* ------------------------------------------------------------------ 5 --- */
static FILE *demo_open(const char *dir, const char *name, uint32_t frames)
{
    char path[512];
    FILE *f;
    snprintf(path, sizeof path, "%s/%s.wav", dir, name);
    f = fopen(path, "wb");
    if (f)
        wav_hdr(f, frames);
    return f;
}
static void demo_blocks(FILE *f, uint32_t n)
{
    uint32_t i;
    while (n--) {
        blocks(1);
        for (i = 0; i < CTL; i++)
            wav_put(f, out_buf[2u * i], out_buf[2u * i + 1u]);
    }
}

static int demos(const char *dir)
{
    uint32_t e, k, n = 0;
    FILE *f;
    track_t *t = &trk[0];
    /* LFO -> CUT: ANALOG SAW LEAD, a held chord, a slow sine LFO opens and closes the filter */
    fresh(0, 0);
    t->p[P_LRATE] = 30;
    slot(t, 0, MS_LFO, MD_CUT, 48);
    if ((f = demo_open(dir, "lfo_cut", 6u * FS / CTL * CTL))) {
        trk_note_on(t, 48, 100);
        trk_note_on(t, 55, 100);
        trk_note_on(t, 60, 100);
        demo_blocks(f, 5u * FS / CTL);
        trk_note_off(t, 48);
        trk_note_off(t, 55);
        trk_note_off(t, 60);
        demo_blocks(f, FS / CTL);
        fclose(f);
        n++;
    }
    /* VEL -> AMP: FM6 TINE EP (DIGITAL E.PIANO until 0.2.13), the same note at velocities 10 .. 127, twice as much dynamics */
    fresh(ENGI_FM6, 0);
    slot(t, 0, MS_VEL, MD_AMP, 63);
    slot(t, 1, MS_VEL, MD_CUT, 30);
    if ((f = demo_open(dir, "vel_amp", 16u * (FS / 4u / CTL) * CTL + FS / CTL * CTL))) {
        for (k = 0; k < 16u; k++) {
            trk_note_on(t, 60u + (k & 3u) * 4u, 10u + k * 117u / 15u);
            demo_blocks(f, FS / 4u / CTL);
            trk_note_off(t, 60u + (k & 3u) * 4u);
        }
        demo_blocks(f, FS / CTL);
        fclose(f);
        n++;
    }
    /* MODW -> VIB: LOFI WAVE LEAD, the mod wheel (CC1) rises over 4 s: vibrato from none to deep */
    e = eng_by_name("LOFI");
    fresh(e, preset_by_name(e, "WAVE LEAD"));
    t->p[P_LRATE] = 70;
    t->p[P_LD_PIT] = 0;
    t->p[P_LFADE] = 0;
    slot(t, 0, MS_MODW, MD_VIB, 12);
    if ((f = demo_open(dir, "modw_vib", 5u * FS / CTL * CTL))) {
        trk_note_on(t, 69, 100);
        for (k = 0; k < 4u * FS / CTL; k++) {
            if (k % 32u == 0u)
                pkt(0xB0, 1, k * 127u / (4u * FS / CTL));
            demo_blocks(f, 1);
        }
        trk_note_off(t, 69);
        demo_blocks(f, FS / CTL);
        fclose(f);
        n++;
    }
    /* LFO -> TRIO PW: TRIO ARP LEAD's pulse width swept by a triangle LFO */
    e = eng_by_name("TRIO");
    fresh(e, preset_by_name(e, "ARP LEAD"));
    t->p[P_LRATE] = 45;
    t->p[P_LWAVE] = 1;
    t->p[P_AMODE] = 0;
    t->p[P_VOICE] = V_POLY;
    slot(t, 0, MS_LFO, MD_E1 + (int32_t)edit_by_label(e, "PW", 7), 40);
    if ((f = demo_open(dir, "lfo_trio_pw", 5u * FS / CTL * CTL))) {
        trk_note_on(t, 57, 100);
        demo_blocks(f, 4u * FS / CTL);
        trk_note_off(t, 57);
        demo_blocks(f, FS / CTL);
        fclose(f);
        n++;
    }
    /* AT -> WHEEL DRV: an organ chord, channel aftertouch pushes the drive up and down */
    e = eng_by_name("WHEEL");
    fresh(e, 0);
    slot(t, 0, MS_AT, MD_E1 + (int32_t)edit_by_label(e, "DRV", 6), 63);
    slot(t, 1, MS_AT, MD_CUT, 20);
    if ((f = demo_open(dir, "at_wheel_drv", 6u * FS / CTL * CTL))) {
        trk_note_on(t, 48, 100);
        trk_note_on(t, 55, 100);
        trk_note_on(t, 64, 100);
        for (k = 0; k < 5u * FS / CTL; k++) {
            uint32_t ph = k * 254u / (5u * FS / CTL);
            if (k % 16u == 0u)
                pkt(0xD0, ph < 127u ? ph : 254u - ph, 0);
            demo_blocks(f, 1);
        }
        trk_note_off(t, 48);
        trk_note_off(t, 55);
        trk_note_off(t, 64);
        demo_blocks(f, FS / CTL);
        fclose(f);
        n++;
    }
    printf("mod: %u demos in %s (lfo_cut, vel_amp, modw_vib, lfo_trio_pw, at_wheel_drv)\n", n, dir);
    return n == 5u;
}

/* a sine LFO (1 or 2) on PAN sweeps: the stereo balance of a held note reaches both sides within a few LFO periods */
static void pan_sweep(const char *what, int32_t src, int32_t amt, uint32_t lfo2dest, int32_t *minb, int32_t *maxb)
{
    track_t *t = &trk[0];
    uint32_t b, i;
    int32_t lo = 1000, hi = -1000;
    fresh(0, 0);
    t->p[P_PAN] = 0;
    t->p[P_LRATE] = t->p[P_L2RATE] = 60;
    t->p[P_LFADE] = t->p[P_L2FADE] = 0;
    if (lfo2dest)
        t->p[P_L2PIT] = 0;
    slot(t, 0, src, MD_PAN, amt);
    trk_note_on(t, 60, 100);
    for (b = 0; b < 6u * FS / CTL; b++) {
        int64_t l = 0, r = 0;
        mix_block(out_buf, CTL);
        for (i = 0; i < CTL; i++) {
            l += out_buf[2u * i] < 0 ? -out_buf[2u * i] : out_buf[2u * i];
            r += out_buf[2u * i + 1u] < 0 ? -out_buf[2u * i + 1u] : out_buf[2u * i + 1u];
        }
        if (b > FS / CTL / 4u && l + r > 1000) {
            int32_t bal = (int32_t)((r - l) * 100 / (l + r));
            lo = bal < lo ? bal : lo;
            hi = bal > hi ? bal : hi;
        }
    }
    *minb = lo;
    *maxb = hi;
    printf("mod: %s balance %d..%d\n", what, lo, hi);
}

static void test_pan_lfo(void)
{
    int32_t a, b, c, d;
    track_t *t = &trk[0];
    fresh(0, 0);                                   /* the swing itself: PAN +-62 (not pinned at the ends) around its centre */
    slot(t, 0, MS_LFO, MD_PAN, 63);
    t->p[P_PAN] = 0;
    lfo_at(t, 32767);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    a = t->p[P_PAN];
    mod_end(t);
    lfo_at(t, -32768);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    b = t->p[P_PAN];
    mod_end(t);
    check("LFO -> PAN +63 swings -63..+62 around the centre (full left to full right)", a >= 60 && a <= 63 && b <= -60 && b >= -64);
    slot(t, 0, MS_LFO, MD_PAN, -64);
    t->p[P_PAN] = 20;                              /* a base off the centre: the swing follows it */
    lfo_at(t, 16384);
    unslew();                                      /* (0.2.25: a mapping probe: the value at once, not the source slew) */
    mod_begin(t);
    c = t->p[P_PAN];
    mod_end(t);
    check("LFO -> PAN -64: inverted phase around the base value (20 - 32 = -12)", c == -12 && t->p[P_PAN] == 20);
    pan_sweep("LFO1 -> PAN +63", MS_LFO, 63, 0, &a, &b);
    check("LFO 1 sine -> PAN +63: sweeps full left to full right", a < -80 && b > 80);
    pan_sweep("LFO2 -> PAN +63", MS_LFO2, 63, 0, &a, &b);
    check("LFO 2 sine -> PAN +63: sweeps full left to full right", a < -80 && b > 80);
    pan_sweep("LFO1 -> PAN -64", MS_LFO, -64, 0, &c, &d);
    check("LFO 1 sine -> PAN -64: sweeps both ways too (inverted phase)", c < -80 && d > 80);
}


/* PART 2's LFO -> PAN in each output mode (the owner's report: LAYER, LFO 1 -> PAN did nothing): STEREO and LAYER mix the parts
 * alike and swing both channels; SPLIT keeps part 2 hard right. Then every class of destination (per-block PAN, DIST, a send,
 * an engine parameter, and per-voice CUT) changes part 2's sound in LAYER */
static void part2_run(uint32_t mode, int32_t src, int32_t dst, int32_t amt, int32_t *lo, int32_t *hi, double *rms, int32_t *rec)
{
    track_t *t = &trk[1];
    uint32_t b, i, k = 0;
    int64_t sq = 0;
    fresh(0, 0);
    duell_mode_force(mode);
    trk[0].p[P_LEVEL] = 0;                         /* (part 1 silent: only part 2 is measured) */
    t->p[P_PAN] = 0;
    t->p[P_LRATE] = t->p[P_L2RATE] = 60;
    t->p[P_LFADE] = t->p[P_L2FADE] = 0;
    t->p[P_LTRIG] = 1;                             /* FREE: the held note does not restart it */
    t->p[P_SUS] = 127;
    t->p[P_CHOR] = t->p[P_DLY] = t->p[P_REV] = 0;
    if (src)
        slot(t, 0, src, dst, amt);
    trk_note_on(t, 60, 100);
    *lo = 1000;
    *hi = -1000;
    for (b = 0; b < 4u * FS / CTL; b++) {
        int64_t l = 0, r = 0;
        mix_block(out_buf, CTL);
        for (i = 0; i < CTL; i++) {
            l += out_buf[2u * i] < 0 ? -out_buf[2u * i] : out_buf[2u * i];
            r += out_buf[2u * i + 1u] < 0 ? -out_buf[2u * i + 1u] : out_buf[2u * i + 1u];
            sq += (int64_t)out_buf[2u * i] * out_buf[2u * i];
            if (rec && k < 200000u)
                rec[k++] = out_buf[2u * i];
        }
        if (b > FS / CTL / 4u && l + r > 1000) {
            int32_t bal = (int32_t)((r - l) * 100 / (l + r));
            *lo = bal < *lo ? bal : *lo;
            *hi = bal > *hi ? bal : *hi;
        }
    }
    *rms = sqrt((double)sq);
    duell_mode_force(DM_STEREO);
}

static void test_part2_modes(void)
{
    static int32_t ref[200000], cur[200000];
    int32_t lo, hi, lo2, hi2;
    double r;
    uint32_t k, ok;
    static const int32_t DST[5] = {MD_PAN, MD_DIST, MD_CHO, MD_E1, MD_CUT};
    part2_run(DM_LAYER, MS_LFO, MD_PAN, 63, &lo, &hi, &r, 0);
    printf("mod: LAYER part 2 LFO1 -> PAN +63: balance %d..%d\n", lo, hi);
    check("LAYER: part 2's LFO 1 -> PAN +63 swings the stereo balance left and right", lo < -80 && hi > 80);
    part2_run(DM_STEREO, MS_LFO, MD_PAN, 63, &lo2, &hi2, &r, 0);
    check("  .. STEREO the same numbers", lo2 == lo && hi2 == hi);
    part2_run(DM_LAYER, MS_LFO2, MD_PAN, -64, &lo, &hi, &r, 0);
    check("LAYER: part 2's LFO 2 -> PAN -64 swings both ways too", lo < -80 && hi > 80);
    part2_run(DM_SPLIT, MS_LFO, MD_PAN, 63, &lo, &hi, &r, 0);
    check("SPLIT: part 2 stays hard right (PAN and its modulation are not heard, by design)", lo == 100 && hi == 100);
    for (k = 0, ok = 1; k < 5u; k++) {             /* every destination class: part 2's sound changes in LAYER */
        double d = 0, e = 0;
        uint32_t i;
        part2_run(DM_LAYER, 0, 0, 0, &lo, &hi, &r, ref);
        part2_run(DM_LAYER, MS_LFO, DST[k], 63, &lo, &hi, &r, cur);
        for (i = 0; i < 200000u; i++) {
            d += (double)(cur[i] - ref[i]) * (cur[i] - ref[i]);
            e += (double)ref[i] * ref[i];
        }
        printf("mod: LAYER part 2 LFO1 -> dest %d: change %.1f %%\n", DST[k], 100.0 * sqrt(d / (e + 1)));
        ok &= d > 0.005 * e;
    }
    check("LAYER: LFO 1 -> PAN, DIST, CHO, an engine parameter and CUT all change part 2's sound (>= 7 %)", ok);
}

/* ------------------------------------------------------------------ 6 --- */
/* DUELL 0.2.7: the destinations added (owner: "the matrix does not have enough destinations") */
static int32_t want_off(uint32_t s, int32_t x, int32_t a, int32_t range)   /* mod_begin's per-block offset */
{
    if (a > 0)
        a += (a + 32) >> 6;                              /* (1.0: mod.c MX_AMT, +63 acts as 64) */
    return (((x * a) >> (MS_BIPOLAR(s) ? 7 : 6)) * range) >> 15;
}
/* fork()ed: SPLIT / STEREO, both parts a held note into all three sends, part p's slot 0 SRC -> DST AMT (routes: n of
 * {part, src, dst, amt}); the hash of the left and the right channel apart */
static void lr_child(uint32_t mode, const int16_t (*r)[4], uint32_t n, uint64_t *hl, uint64_t *hr)
{
    int fd[2];
    uint64_t h[2] = {0, 0};
    pid_t pid;
    if (pipe(fd))
        return;
    fflush(stdout);
    if (!(pid = fork())) {
        uint32_t b, i, k;
        uint64_t x[2] = {0xCBF29CE484222325ull, 0xCBF29CE484222325ull};
        fresh(0, 0);
        duell_mode_force(mode);
        for (k = 0; k < 2u; k++) {
            trk[k].p[P_CHOR] = 70;
            trk[k].p[P_DLY] = 70;
            trk[k].p[P_REV] = 90;
            trk[k].p[P_SUS] = 127;
            trk[k].p[P_LTRIG] = trk[k].p[P_L2TRIG] = 1;
            trk[k].mw = 127;
        }
        song.g[G_DMDEP] = 20;
        for (k = 0; k < n; k++)
            slot(&trk[r[k][0]], k, r[k][1], r[k][2], r[k][3]);
        trk_note_on(&trk[0], 57, 110);
        trk_note_on(&trk[1], 64, 110);
        for (b = 0; b < 3u * FS / CTL; b++) {
            mix_block(out_buf, CTL);
            for (i = 0; i < 2u * CTL; i++) {
                x[i & 1u] ^= (uint32_t)out_buf[i];
                x[i & 1u] *= 0x100000001B3ull;
            }
            if (b == FS / CTL)
                trk_note_off(&trk[0], 57), trk_note_off(&trk[1], 64);
        }
        h[0] = x[0];
        h[1] = x[1] ^ (uint64_t)(mod_gw != 0) ^ (uint64_t)(song.g[G_RSIZE] != GP[G_RSIZE].def) << 1;   /* (nothing left written) */
        if (write(fd[1], h, sizeof h) != sizeof h)
            _exit(1);
        _exit(0);
    }
    close(fd[1]);
    if (read(fd[0], h, sizeof h) != sizeof h)
        h[0] = h[1] = 0;
    close(fd[0]);
    waitpid(pid, 0, 0);
    *hl = h[0];
    *hr = h[1];
}

/* fork()ed: engine e's first sound, MODW (127) -> DST d by AMT a on slot 1 (d 0: no route), a phrase: its hash */
static uint64_t route_child(uint32_t e, int32_t d, int32_t a)
{
    int fd[2];
    uint64_t h = 0;
    pid_t pid;
    if (pipe(fd))
        return 0;
    fflush(stdout);
    if (!(pid = fork())) {
        fresh(e, 0);
        if (e == ENGI_WAVE)
            wave_build_now(&trk[0]);
        trk[0].mw = 127;
        if (d)
            slot(&trk[0], 0, MS_MODW, d, a);
        h = phrase();
        if (write(fd[1], &h, sizeof h) != sizeof h)
            _exit(1);
        _exit(0);
    }
    close(fd[1]);
    if (read(fd[0], &h, sizeof h) != sizeof h)
        h = 0;
    close(fd[0]);
    waitpid(pid, 0, 0);
    return h;
}

static void test_dest027(void)
{
    static const char *const OLD[MD_N_026] = {"OFF", "PITCH", "CUT", "SHP", "AMP", "PAN", "SAT", "CHO", "DLY", "REV", "RAT1", "VIB",
                                              "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8", "DEP1", "RAT2", "DEP2"};
    static const uint8_t PART[] = {MD_LEVEL, MD_INSA, MD_INSB, MD_INSC, MD_IMIX, MD_EQLO, MD_EQMID, MD_EQHI, MD_DUCK, MD_E2ATK,
                                   MD_E2DEC, MD_E2SUS, MD_E2REL, MD_E2FLT, MD_E2SHP, MD_RES};
    track_t *t = &trk[0];
    uint32_t k, ok, e_phase = eng_by_name("PHASE");
    int16_t keep[P_COUNT];
    uint64_t l0, r0, l1, r1;

    for (k = 0, ok = MD_N == 56 && MD_FMODE == 46 && MD_AATK == 47 && MD_N_026 == 23 && MD_DEPTH == 20 && MD_DEPTH2 == 22; k < MD_N_026; k++)
        ok &= str_eq(N_MDST[k], OLD[k]);
    check("0.2.7: DST 0..22 are 0.2.6's (a stored matrix means what it meant); 23 new ones appended (46), 0.2.25 FMODE the 47th, T0229 the AMP ENV times 48th .. 51st", ok);
    check("  the editor's DESC lists every DST name (the limit is 64 now)", MD_N <= 64);
    {   /* no new DST name is an engine's EDIT label: gen_duell_sounds.py reads a sound's MOD route "RES" (ANALOG's E6) by N_MDST
         * first, so a DST called RES moved ANALOG SQUELCH's route to the universal filter's RES (its golden changed) */
        uint32_t e, j, d;
        for (d = MD_N_026, ok = 1; d < MD_N; d++)
            for (e = 0; e < NENGINES; e++)
                for (j = 0; j < 8u; j++)
                    if (ENGINES[e]->edit[j].label && str_eq(N_MDST[d], ENGINES[e]->edit[j].label)) {
                        printf("mod:   DST %u \"%s\" is engine %u's EDIT label\n", d, N_MDST[d], e);
                        ok = 0;
                    }
        check("  no new DST name is an engine knob's label (the default sounds name engine slots by label)", ok);
    }
    {   /* the DEST line: every destination has words (none empty), a few by name */
        char b[32];
        const char *more;
        int32_t v;
        fresh(0, 0);
        duell_mode_force(DM_STEREO);
        duell_mode_req = DM_STEREO;
        for (v = 0, ok = 1; v < MD_N; v++) {
            mod_dst_line(&trk[0], v, b, &more);
            ok &= str_len(b) > 6u && (!MD_IS_BUS(v) || more);   /* (a bus value: always which bus; a faded one: why; 0.2.25: FMODE, after the bus values, is a part value) */
        }
        mod_dst_line(&trk[0], MD_RDAMP, b, &more);
        ok &= str_eq(b, "DEST: REVERB DAMP") && str_eq(more, "SHARED BUS: BOTH PARTS ADD");
        mod_dst_line(&trk[0], MD_LEVEL, b, &more);
        ok &= str_eq(b, "DEST: PATCH LEVEL");   /* (0.2.25 layout round: TRIM is shown PATCH LEVEL) */
        mod_dst_line(&trk[0], MD_DEPTH, b, &more);
        ok &= str_eq(b, "DEST: LFO 1 DEPTH");
        mod_dst_line(&trk[0], MD_E1 + 2, b, &more);
        ok &= str_eq(b, "DEST: ANALOG ") == 0 && b[13] != 0;
        duell_mode_req = DM_SPLIT;
        mod_dst_line(&trk[1], MD_CRATE, b, &more);
        ok &= str_eq(b, "DEST: CHORUS RATE") && str_eq(more, "MOVES BUS B ONLY (PART 2)");
        duell_mode_req = DM_STEREO;
        check("  the MATRIX page's DEST line names every destination in words (\"DEST: REVERB DAMP\", which bus it moves)", ok);
    {   /* 0.2.25: FILTER MODE (MD_FMODE 46): the multimode filter's MODE per block, put back after; named FMODE, "DEST: FILTER 1 MODE" */
        char b2[32];
        const char *more2;
        int16_t fm;
        fresh(0, 0);
        trk[0].p[P_FREEC] = 0;
        trk[0].mw = 127;
        slot(&trk[0], 0, MS_MODW, MD_FMODE, 63);
        unslew();
        mod_begin(&trk[0]);
        fm = trk[0].p[P_FREEC];
        mod_end(&trk[0]);
        mod_dst_line(&trk[0], MD_FMODE, b2, &more2);
        check("0.2.25 FILTER MODE: MODW -> FMODE +63 moves the filter's MODE (LP 0 -> 125, near HP), the stored MODE back after; DEST: MULTI MODE (DUELL 1.1: the card MULTI / MODE, the line MULTI MODE)",
              fm == ((((127 * 258) * 64) >> 6) * 127 >> 15) && trk[0].p[P_FREEC] == 0 && str_eq(mod_dst_name(&trk[0], MD_FMODE), "MULTI\nMODE") &&
              str_eq(b2, "DEST: MULTI MODE") && !mod_dst_why(&trk[0], MD_FMODE));
        slot(&trk[0], 0, 0, 0, 0);
    }
    }

    /* every per-block part destination moves its own parameter by the rule (MODW 127 at AMT +40), in the block only */
    for (k = 0, ok = 1; k < sizeof PART; k++) {
        uint32_t d = PART[k], id = mod_param(d);
        const param_desc_t *pd = &TP[id];
        int32_t base = (pd->min + pd->max) / 2, w;
        fresh(e_phase, 0);
        t->mw = 127;
        t->p[P_ITYPE] = 4;                          /* (INSERT FUZZ: A B C mean DRIVE TONE LEVEL) */
        t->p[id] = (int16_t)base;
        slot(t, 0, MS_MODW, (int32_t)d, 40);
        memcpy(keep, t->p, sizeof keep);
        w = clamp(base + want_off(MS_MODW, 127 * 258, 40, pd->max - pd->min), pd->min, pd->max);
        mod_begin(t);
        ok &= t->p[id] == w && w != base;
        if (t->p[id] != w || w == base)
            printf("mod:   DST %u (%s, id %u): %d, want %d\n", d, N_MDST[d], id, t->p[id], w);
        mod_end(t);
        ok &= !memcmp(keep, t->p, sizeof keep);
    }
    check("LEVEL, INSERT A B C MIX, EQ LOW MID HIGH, DUCK DEPTH, ENV 2 ATK..REL FLT SHP, RES: each moves its own value, by the rule", ok);

    /* the engine slots: WAVE's POS moves, its TABLE never (no rebuild), E7 (STEPS, cloud job F) moves, an unused slot, FM6's SLOT: skipped */
    fresh(ENGI_WAVE, 0);
    wave_build_now(t);
    t->mw = 127;
    slot(t, 0, MS_MODW, MD_E1 + 1, 40);
    slot(t, 1, MS_MODW, MD_E1, 63);
    slot(t, 2, MS_MODW, MD_E1 + 6, 63);
    {
        int16_t pos = t->p[P_E1], tab = t->p[P_E0];
        const wv_mem_t *w = (const wv_mem_t *)ENG_MEM(0);
        uint32_t want = w->h.want, b;
        mod_begin(t);
        ok = t->p[P_E1] == clamp(pos + want_off(MS_MODW, 127 * 258, 40, 127), 0, 127) && t->p[P_E1] != pos && t->p[P_E0] == tab &&
             t->p[P_E6] > 10;                           /* (E7 is STEPS: the route moves the count; was an unused slot) */
        mod_end(t);
        trk_note_on(t, 60, 100);
        for (b = 0; b < 200u; b++)
            mix_block(out_buf, CTL);
        ok &= w->h.want == want && w->h.have == want && !w->h.fade && t->p[P_E0] == tab;
        check("WAVE: MODW -> POS and -> E7 (STEPS) move them; -> TABLE (REBUILD) does nothing: no table change, no rebuild", ok);
        check("  the MATRIX page: TABLE faded REBUILD, E7 (STEPS) and POS live (E8 faded UNUSED); its line \"DEST: WAVE POS\"",
              str_eq(mod_dst_why(t, MD_E1), "REBUILD") && !mod_dst_why(t, MD_E1 + 6) && str_eq(mod_dst_why(t, MD_E1 + 7), "UNUSED") && !mod_dst_why(t, MD_E1 + 1));
        {
            char b2[32];
            const char *more;
            mod_dst_line(t, MD_E1 + 1, b2, &more);
            ok = str_eq(b2, "DEST: WAVE POS") && !more;
            mod_dst_line(t, MD_E1 + 7, b2, &more);
            check("  .. \"DEST: WAVE POS\"; the unused slot \"DEST: WAVE EDIT 2 KNOB 4\" + NOT USED BY THIS ENGINE",
                  ok && str_eq(b2, "DEST: WAVE EDIT 2 KNOB 4") && more && str_eq(more, "NOT USED BY THIS ENGINE"));
            mod_dst_line(t, MD_E1 + 6, b2, &more);
            check("  .. E7: \"DEST: WAVE STEPS\", nothing against it", str_eq(b2, "DEST: WAVE STEPS") && !more);
        }
    }
    {   /* a faded slot does nothing: the phrase bit for bit as with no route (FM6 SLOT, a retired engine's slot (SAMPLE, GRAIN, SLICE:
         * DUELL 0.2.9, silent, every slot "-"), WAVE TABLE and E8; E7 is STEPS since cloud job F) */
        static const uint8_t EK[6][2] = {{ENGI_FM6, 7}, {13, 0}, {4, 0}, {8, 3}, {ENGI_WAVE, 0}, {ENGI_WAVE, 7}};
        static const char *const WHY[6] = {"LOADS", "UNUSED", "UNUSED", "UNUSED", "REBUILD", "UNUSED"};
        for (k = 0, ok = 1; k < 6u; k++) {
            uint64_t h0 = route_child(EK[k][0], 0, 0), h1 = route_child(EK[k][0], MD_E1 + EK[k][1], 63);
            fresh(EK[k][0], 0);
            ok &= h0 && h0 == h1 && mod_dst_why(t, MD_E1 + EK[k][1]) && str_eq(mod_dst_why(t, MD_E1 + EK[k][1]), WHY[k]);
            if (h0 != h1)
                printf("mod:   engine %u slot %u: the route changes the sound\n", EK[k][0], EK[k][1]);
        }
        check("faded engine slots do nothing (FM6 SLOT, a retired engine's (SAMPLE GRAIN SLICE: UNUSED), WAVE TABLE, WAVE E8: bit for bit)", ok);
    }

    /* a slot keeps its destination over an engine change: then it is the new engine's slot of that index (named, or faded) */
    fresh(0, 0);
    slot(t, 0, MS_LFO, MD_E1 + 6, 30);
    ok = !mod_dst_why(t, MD_E1 + 6);
    host_preset_req(t, ENGI_WAVE, 0);
    {
        uint32_t b;
        for (b = 0; b < 20u; b++) {
            memcpy(keep, t->p, sizeof keep);
            mix_block(out_buf, CTL);
            ok &= !memcmp(keep, t->p, sizeof keep);  /* (no value left modulated after any block, across the switch) */
        }
    }
    ok &= t->engine == ENGI_WAVE && t->p[MSLOT_ID(0) + 1u] == MD_E1 + 6 && !mod_dst_why(t, MD_E1 + 6);
    check("an engine change: the slot keeps E7 (ANALOG's, live) and shows it live on WAVE (STEPS since cloud job F); no value left modulated", ok);

    /* the bus values: per part offsets; STEREO / LAYER add them, DUEL keeps them on the part's own bus */
    fresh(0, 0);
    trk[0].mw = trk[1].mw = 127;
    slot(&trk[0], 0, MS_MODW, MD_RSIZE, 16);
    slot(&trk[1], 0, MS_MODW, MD_RSIZE, 20);
    slot(&trk[1], 1, MS_MODW, MD_DFB, -32);
    mod_begin(&trk[0]);
    mod_end(&trk[0]);
    mod_begin(&trk[1]);
    mod_end(&trk[1]);
    {
        int16_t rs = song.g[G_RSIZE], fb = song.g[G_DFDBK];
        int32_t o0 = want_off(MS_MODW, 127 * 258, 16, 127), o1 = want_off(MS_MODW, 127 * 258, 20, 127);
        int32_t of = want_off(MS_MODW, 127 * 258, -32, 120);
        mod_bus(~0u);
        ok = song.g[G_RSIZE] == clamp(rs + o0 + o1, 0, 127) && song.g[G_DFDBK] == clamp(fb + of, 0, 120);
        mod_bus(1u);                                 /* (bus A: part 1's alone) */
        ok &= song.g[G_RSIZE] == clamp(rs + o0, 0, 127) && song.g[G_DFDBK] == fb;
        mod_bus(2u);
        ok &= song.g[G_RSIZE] == clamp(rs + o1, 0, 127) && song.g[G_DFDBK] == clamp(fb + of, 0, 120);
        mod_bus_end();
        ok &= song.g[G_RSIZE] == rs && song.g[G_DFDBK] == fb && !mod_gw;
        check("bus values: STEREO / LAYER both parts' offsets add, DUEL bus A part 1's, bus B part 2's; the stored values back", ok);
        slot(&trk[0], 0, 0, 0, 0);
        slot(&trk[1], 0, 0, 0, 0);
        slot(&trk[1], 1, 0, 0, 0);
        mix_block(out_buf, CTL);
        check("  a route taken away: no offset left after one block (mod_gon 0), song.g never left written",
              !mod_gon_any() && !mod_gw && song.g[G_RSIZE] == rs);
    }
    {
        static const int16_t NONE[1][4] = {{0, 0, 0, 0}};
        static const int16_t P1[4][4] = {{0, MS_LFO, MD_RSIZE, 63}, {0, MS_MODW, MD_DFB, 40}, {0, MS_LFO, MD_CDEP, -50}, {0, MS_LFO, MD_DMDEP, 63}};
        static const int16_t P2[2][4] = {{1, MS_LFO, MD_RDAMP, 63}, {1, MS_MODW, MD_CRATE, 50}};
        lr_child(DM_SPLIT, NONE, 0, &l0, &r0);
        lr_child(DM_SPLIT, P1, 4, &l1, &r1);
        ok = l0 && r0 && l1 != l0 && r1 == r0;
        lr_child(DM_SPLIT, P2, 2, &l1, &r1);
        check("DUEL: part 1's routes to SIZE FDBK CDP DMDEP change the left (bus A) only, the right bit for bit; part 2's the right only",
              ok && l1 == l0 && r1 != r0);
        lr_child(DM_STEREO, NONE, 0, &l0, &r0);
        lr_child(DM_STEREO, P2, 2, &l1, &r1);
        check("STEREO: part 2's routes move the shared buses (both channels change)", l1 != l0 && r1 != r0);
    }

    /* DUCK DEPTH from 0: the matrix alone ducks the pump (a stored 0 is no reason for it to do nothing) */
    fresh(0, 0);
    t->p[P_DKSRC] = 0;
    t->p[P_DKDEP] = 0;
    t->p[P_SUS] = 127;
    t->mw = 127;
    slot(t, 0, MS_MODW, MD_DUCK, 63);
    trk_note_on(t, 60, 100);
    {
        uint32_t b;
        int32_t dn = 0;
        for (b = 0; b < FS / CTL; b++) {
            mix_block(out_buf, CTL);
            dn = duck_st[0].dn > dn ? duck_st[0].dn : dn;
        }
        check("DUCK DEPTH 0 + MODW -> DUCK +63: the pump ducks (the matrix's depth starts it)", dn > 30000 && t->p[P_DKDEP] == 0);
    }

    /* the morph: WILD rolls a route only among 0.2.6's destinations (saved seeds roll the same); a route into a new one rolls its AMT */
    {
        int8_t o[P_COUNT], end[P_COUNT];
        uint32_t sd, nn = 0, kept = 1, newd = 0;
        uint8_t sv = mrc;
        memset(o, 0, sizeof o);
        for (sd = 0; sd < 400u; sd++) {
            uint32_t rs = morph_state(sd, 0);
            o[MSLOT_ID(0)] = MS_LFO;
            o[MSLOT_ID(0) + 1u] = (int8_t)(sd & 1u ? MD_CUT : MD_RSIZE);
            o[MSLOT_ID(0) + 2u] = 40;
            memcpy(end, o, sizeof end);
            mrc = MC_WILD | MC_PIT;
            morph_slot(&rs, ENGINES[0], o, end, 0, 100, 1);
            newd += (sd & 1u) && (uint8_t)end[MSLOT_ID(0) + 1u] >= MD_N_026;
            nn += end[MSLOT_ID(0) + 1u] != o[MSLOT_ID(0) + 1u];
            rs = morph_state(sd, 1);
            mrc = MC_PIT;
            memcpy(end, o, sizeof end);
            morph_slot(&rs, ENGINES[0], o, end, 0, 100, 1);
            kept &= end[MSLOT_ID(0)] == o[MSLOT_ID(0)] && end[MSLOT_ID(0) + 1u] == o[MSLOT_ID(0) + 1u];
        }
        mrc = sv;
        check("MORPH WILD: a rolled route never lands on a new destination; SMART: a route into REVERB SIZE keeps SRC and DST",
              !newd && nn > 100u && kept);
    }
}

/* 8 slots, every kind (per voice, per block, an engine slot, the part's mix, a bus value): instructions per sample over the matrix off,
 * slot by slot. The EQ and the INSERT are run in both (a stored EQ MID gain, INSERT SOFT): what a route switches ON costs what that
 * effect costs (eq / insert tests), the matrix's own cost is the rest; PHYS has no filter of its own, so slot 1 is SHP, not CUT (a CUT
 * route runs the universal filter, +122 / sample here: uf_test's cost, as test_cost notes) */
static void test_cost8(void)
{
    static const int16_t R[8][3] = {{MS_LFO, MD_SHP, 30}, {MS_VEL, MD_AMP, 40}, {MS_MODW, MD_VIB, 8}, {MS_LFO, MD_E1 + 2, 20},
                                    {MS_LFO2, MD_LEVEL, 20}, {MS_ENV, MD_EQMID, 20}, {MS_LFO, MD_RSIZE, 20}, {MS_MODW, MD_DFB, 20}};
    uint32_t e_phys = eng_by_name("PHYS"), pp = preset_by_name(e_phys, "BOWED METAL"), b, rep, i, k;
    double c[9];
    if (!instr_now())
        return;
    for (i = 0; i < 9u; i++) {
        double best = 1e30;
        fresh(e_phys, pp);
        trk[0].p[P_VOICE] = V_POLY;
        trk[0].p[P_SUS] = 127;
        trk[0].p[P_EQMG] = 3;
        trk[0].p[P_ITYPE] = 1;
        trk[0].p[P_REV] = 40;
        trk[0].mw = 90;
        for (k = 0; k < i; k++)
            slot(&trk[0], k, R[k][0], R[k][1], R[k][2]);
        for (b = 0; b < 4u; b++)
            trk_note_on(&trk[0], 48 + 7 * b, 100);
        blocks(FS / 2u / CTL);
        for (rep = 0; rep < 3u; rep++) {
            uint64_t i0 = instr_now();
            double ipc;
            blocks(FS / CTL);
            ipc = (double)(instr_now() - i0) / FS;
            best = ipc < best ? ipc : best;
        }
        c[i] = best;
    }
    printf("mod: cost: PHYS 4 voices (EQ, INSERT, reverb on), slots added one by one, instructions / sample:");
    for (i = 0; i < 9u; i++)
        printf(" %.0f", c[i]);
    printf("\nmod: cost: 8 slots of every kind (SHP AMP VIB E3 LEVEL EQ MID REVERB SIZE DELAY FDBK): +%.0f / sample (+%.1f %%), "
           "%.0f per %u-sample block\n", c[8] - c[0], (c[8] - c[0]) * 100 / c[0], (c[8] - c[0]) * CTL, (unsigned)CTL);
    check("cost: 8 slots of every kind add at most MOD_COST_MAX % to the part", (c[8] - c[0]) * 100 / c[0] <= MOD_COST_MAX);
}

int main(int argc, char **argv)
{
    test_off();
    test_math();
    test_pan_lfo();
    test_part2_modes();
    test_midi();
    test_dest027();
    test_cost();
    test_cost8();
    if (argc > 1)
        check("demos written", demos(argv[1]));
    printf("%s\n", bad ? "MOD MATRIX TEST FAILED" : "mod matrix test passed");
    return bad != 0;
}
