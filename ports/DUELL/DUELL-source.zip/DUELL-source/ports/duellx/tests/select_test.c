/* SPDX-License-Identifier: GPL-3.0-only */
/* DUELL (SPEC 1.1 / 1.2 / 1.3 / 5): the SELECT knob is the select knob and never the tempo.
 *   SELECT     turned left / right on every screen (every page the UI has, for every engine the selected part can have,
 *              stopped and playing; HOME; the menu; ABOUT and INFO; a dialog; NAME; with a layer button held): the tempo
 *              (song.g[G_BPM]) never changes. On a page of a family with sub-pages it steps to the previous / next
 *              sub-page (wrapping), the one the page button pressed again goes to; with one page it stays; HOME has
 *              its own round (HOME, its pages); in the menu it moves the row (continuously across the tabs, clamped, sweep_menu); in a dialog, NAME and a layer: nothing.
 *   TEMPO      GLO's TEMPO page: KNOB 1 is TEMPO (G_BPM) and sets it; with an external clock (CLK USB / TRS, set on the same page's
 *              KNOB 4) it is inert and shows EXT; KNOB 2 TAP: a detent either way is one tap, the BPM is the mean of the last taps.
 *   no BPM LOCK  the MENU has no such row (the tempo has no lock to keep).
 * Built and run by DUELL/host_tests.sh (name: select): the UI sources against ui_test.c's stub display and knobs. */
#define UI_TEST_NO_MAIN 1
#define UI_TEXT_CAPTURE 1                              /* (the grid cards are read from the texts drawn in them: ui_test.c card_match) */
#include "ui_test.c"

static int bad;
static int ncheck;
static uint32_t scn_eng_s(const char *n)
{
    uint32_t e;
    for (e = 0; e < NENGINES; e++)
        if (str_eq(ENGINES[e]->name, n))
            return e;
    return 0;
}

static int expect(const char *what, int ok)
{
    ncheck++;
    if (!ok) {
        printf("select: FAIL %s\n", what);
        bad++;
    }
    return ok;
}

static int card_is(uint32_t c, const char *s)       /* the card c as drawn: its label, value and unit among the texts drawn in it (ui_test.c card_match; the cache key "LABEL|VALUE|UNIT|.." is a hash on the grid pages) */
{
    return card_match(c, s);
}

static uint32_t fam_count(uint32_t fam)             /* the visible pages of a family */
{
    uint32_t i, n = 0;
    for (i = 0; i < NPAGES; i++)
        n += PAGES[i].fam == fam && page_visible(i);
    return n;
}
static uint32_t fam_step(uint32_t from, int dir)    /* the table walk the page button's taps make (open_family) */
{
    uint32_t i = from, n;
    for (n = 0; n < NPAGES; n++) {
        i = dir > 0 ? (i + 1u) % NPAGES : (i + NPAGES - 1u) % NPAGES;
        if (PAGES[i].fam == PAGES[from].fam && page_visible(i))
            break;
    }
    return i;
}
/* HOME's round (SPEC 3.5): HOME's pages in table order (MORPH, MORPH SET, MODE, MIXER); 0.2.14: no OVERVIEW after them */
static uint32_t home_round(uint8_t *r)
{
    uint32_t i, m = 0;
    for (i = 0; i < NPAGES; i++)
        if (PAGES[i].fam == FAM_TRK && page_visible(i))
            r[m++] = (uint8_t)i;
    return m;
}
static uint32_t where(void) { return ui.page; }
static void row_turn(uint32_t row, int32_t n)          /* DUELL 1.3: a MENU row picked (the section open) and turned n detents, one a turn (a MENU row steps one value per pass) */
{
    ui.menu = 1;
    ui.menu_sel = (uint8_t)row;
    for (; n; n -= n > 0 ? 1 : -1)
        turn(EN_K1, n > 0 ? 1 : -1);
}
static void enter(uint32_t i)
{
    ui.menu = 0; ui.confirm = 0; ui.layer = 0;
    ui.page = (uint8_t)i; page_entered();
    frames(48);
}
static void settle(void) { fm1_in.buttons = 0; frames(64); }

/* every page, every engine, stopped and playing */
static void sweep_pages(void)
{
    uint32_t e, i, pass, pages = 0, moved = 0, kept = 0;
    for (pass = 0; pass < 2u; pass++)
        for (e = 0; e < NENGINES; e++) {
            if (!eng_ok(e))
                continue;
            for (i = 0; i < NPAGES; i++) {
                uint32_t n, nxt, prv;
                char w[96];
                ui_power_on();
                set_engine_of(TSEL, e);
                TSEL->engine = TSEL->eng_req;
                song.g[G_BPM] = 117;
                if (pass) song.playing = 1;
                if (!page_visible(i))
                    continue;
                enter(i);
                n = fam_count(PAGES[i].fam);
                nxt = fam_step(i, 1);
                prv = fam_step(i, -1);
                pages++;
                snprintf(w, sizeof w, "%s/%s%s", ENGINES[e]->name, PAGES[i].title, pass ? " (playing)" : "");
                if (PAGES[i].fam == FAM_TRK) {                   /* HOME's pages: the round with HOME (sweep_home) */
                    uint8_t r[8];
                    uint32_t m = home_round(r), at = 0;
                    while (at < m && r[at] != i)
                        at++;
                    turn(EN_SELECT, 1);
                    expect(w, song.g[G_BPM] == 117 && where() == r[(at + 1u) % m]);
                    enter(i);
                    turn(EN_SELECT, -1);
                    expect(w, song.g[G_BPM] == 117 && where() == r[(at + m - 1u) % m]);
                    kept++;
                    continue;
                }

                turn(EN_SELECT, 1);
                expect(w, song.g[G_BPM] == 117 && !ui.menu);
                if (n > 1) {
                    expect("SELECT right: the next sub-page", ui.page == nxt);
                    moved++;
                } else {
                    expect("SELECT right: one page only, it stays", ui.page == i);
                    kept++;
                }
                turn(EN_SELECT, -1);
                expect("SELECT left: back", ui.page == i && song.g[G_BPM] == 117);
                turn(EN_SELECT, -1);
                expect("SELECT left: the previous sub-page", ui.page == (n > 1 ? prv : i) && song.g[G_BPM] == 117);
                turn(EN_SELECT, 3);                       /* several detents in a frame: still the tempo untouched */
                expect("SELECT 3 detents: tempo untouched", song.g[G_BPM] == 117);
                if (n > 1 && pass == 0u && ui.page != i) {   /* round the whole family: back where it began */
                    uint32_t k;
                    enter(i);
                    for (k = 0; k < n; k++)
                        turn(EN_SELECT, 1);
                    expect("SELECT right x pages: round the family", ui.page == i);
                    for (k = 0; k < n; k++)
                        turn(EN_SELECT, -1);
                    expect("SELECT left x pages: round the family", ui.page == i);
                }
            }
        }
    printf("select: %u page screens (all engines, stopped and playing); %u stepped, %u single-page or HOME's\n", pages, moved, kept);
}

/* SELECT does what the page button pressed again does (taps of the button), family by family */
static void sweep_buttons(void)
{
    static const uint8_t BTN[] = {B_ENV, B_LFO, B_FX, B_SCL, B_EDIT, B_GLO, B_SAVE, B_ARP, B_SEQ};
    uint32_t b, i;
    for (b = 0; b < sizeof BTN; b++)
        for (i = 0; i < NPAGES; i++) {
            uint32_t sel_page;
            char w[64];
            ui_power_on();
            song.g[G_BPM] = 117;
            if (!page_visible(i) || FAM_BTN[PAGES[i].fam] != BTN[b] || fam_count(PAGES[i].fam) < 2u)
                continue;
            enter(i);
            turn(EN_SELECT, 1);
            sel_page = ui.page;
            enter(i);
            press(BTN[b]);
            snprintf(w, sizeof w, "SELECT right = the button again (%s)", PAGES[i].title);
            expect(w, ui.page == sel_page && song.g[G_BPM] == 117);
            settle();
        }
}

/* HOME has its own round (SPEC 3.5): MORPH, MORPH SET, MODE, MIXER, MORPH again (0.2.14: OVERVIEW, the old HOME screen, is no
 * longer on it); SELECT right and HOME's taps go round it the same way, SELECT left backwards */
static void sweep_home(void)
{
    static const char *const ORDER[3] = {"MORPH", "MACROS 1/2", "MACROS 2/2"};   /* (2026-11-15: MORPH SET and MODE are SETTINGS rows now) */   /* (0.2.25 layout round: the MIXER is GLO's first page; DUELL 1.3: MACROS 1/2 and 2/2 after MORPH) */
    uint8_t r[8];
    uint32_t m, k, ok, c;
    ui_power_on();
    song.g[G_BPM] = 117;
    m = home_round(r);
    c = 0;
    ok = m == 3u;
    for (k = 0; ok && k < m; k++)
        ok &= str_eq(PAGES[r[k]].title, ORDER[k]);
    expect("HOME's round: MORPH, MACROS 1/2, MACROS 2/2 (0.2.14: no OVERVIEW; 0.2.25: no MIXER; 1.3: the MACROS; 2026-11-15: no MORPH SET, no MODE)", ok);
    {   /* item 155: SPLIT in LAYER (2026-11-15: SETTINGS > PLAYING > SPLIT, was the MODE page's K3): OFF, the first turn either way starts at the middle key F#4 (stored 67), then goes on; the bottom is OFF again */
        uint8_t s0 = mix_split;
        int ok2;
#define SPL(d) menu_put(MI_SPLIT, menu_step(MI_SPLIT, (d)))
        mix_split = 0;  SPL(1);
        ok2 = mix_split == 67u;
        SPL(1);   ok2 &= mix_split == 68u;
        SPL(-2);  ok2 &= mix_split == 66u;
        mix_split = 0;  SPL(-1);
        ok2 &= mix_split == 67u;
        mix_split = 0;  SPL(3);
        ok2 &= mix_split == 69u;
        mix_split = 1;  SPL(-1);
        ok2 &= mix_split == 0u;
        expect("SETTINGS > PLAYING > SPLIT (item 158): OFF + a turn either way = F#4 (middle of F3..G5), then +-1; C-1 - 1 = OFF", ok2);
        mix_split = 128;  SPL(5);
        expect("  .. SPLIT stays at G9 at the top", mix_split == 128u);
#undef SPL
        mix_split = s0;
    }
    {   /* ENV's last two pages are the matrix pages again (MOD 1 / MOD 2): the same slots and graph as LFO's */
        uint32_t e = 0, l = 0, n = 0, i, j;
        for (i = 0; i < NPAGES; i++) {
            n += PAGES[i].fam == FAM_ENV;
            if (PAGES[i].fam == FAM_ENV && PAGES[i].graph == GR_MOD) {
                for (j = 0; j < NPAGES; j++)
                    if (PAGES[j].fam == FAM_LFO && str_eq(PAGES[j].title, PAGES[i].title)) l = j;
                e = i;
                ok = PAGES[l].graph == GR_MOD && !memcmp(PAGES[e].id, PAGES[l].id, 4) &&
                     (PAGES[e].id[1] == P_M1SRC || PAGES[e].id[1] == P_M5SRC);
                expect(PAGES[e].id[1] == P_M1SRC ? "ENV's MOD 1 edits LFO's MOD 1 slots" : "ENV's MOD 2 edits LFO's MOD 2 slots", ok);
            }
        }
        expect("ENV family: AMP ENV, AMP DEST, ENV 2, ENV 2 DEST, CYCLE ENV 1/2, 2/2, MOD 1, MOD 2 (the last two MOD pages)", n == 8u && str_eq(PAGES[fam_step(e, -1)].title, "MATRIX 1-4"));
    }
    {   /* the classic arrangement (SPEC 2.4): each family's pages in this order (index order, the button's round) */
        static const char *const EF[] = {"AMP ENV", "AMP DEST", "ENV 2", "ENV 2 DEST", "CYCLE ENV 1/2", "CYCLE ENV 2/2", "MATRIX 1-4", "MATRIX 5-8"};   /* (cloud job H: the CYCLE pages after ENV 2 DEST) */
        static const char *const LF[] = {"LFO 1", "LFO 1 TRIG", "LFO 1 DEST", "LFO 2", "LFO 2 TRIG", "LFO 2 DEST", "MATRIX 1-4", "MATRIX 5-8"};
        uint32_t i, ne = 0, nl = 0, e2 = 0, l2 = 0;
        ok = 1;
        for (i = 0; i < NPAGES; i++) {
            e2 = str_eq(PAGES[i].title, "ENV 2 DEST") ? i : e2;
            l2 = str_eq(PAGES[i].title, "LFO 2 DEST") ? i : l2;
            if (PAGES[i].fam == FAM_ENV)
                ok &= ne < 8u && str_eq(PAGES[i].title, EF[ne++]);
            if (PAGES[i].fam == FAM_LFO)
                ok &= nl < 8u && str_eq(PAGES[i].title, LF[nl++]);
        }
        ok &= ne == 8u && nl == 8u && PAGES[e2].id[0] == P_E2FLT && PAGES[e2].id[1] == XW_BASE + X_E2BLD && PAGES[e2].id[2] == XW_BASE + X_E2DRV && PAGES[e2].id[3] == XW_BASE + X_E2RES &&
              PAGES[l2].id[0] == XW_BASE + X_LFO2 && PAGES[l2].id[1] == XW_BASE + X_L2RES2 && PAGES[l2].id[2] == XW_BASE + X_L2FMODE && PAGES[l2].id[3] == XW_BASE + X_L2BLD;   /* (DUELL 1.1: the DEST pages carry the second filter's cards) */
        expect("ENV: AMP ENV, AMP DEST, ENV 2, ENV 2 DEST, CYCLE ENV 1/2, 2/2, MOD 1, MOD 2; LFO: LFO 1, 1 TRIG, 1 DEST, LFO 2, 2 TRIG, 2 DEST, MOD 1, MOD 2", ok);
    }
    expect("the harness starts on HOME OPENS' page: MORPH, the round's first", where() == r[0] && at_home());
    ok = 1;
    for (k = 1; k <= m; k++) {
        turn(EN_SELECT, 1);
        ok &= where() == r[(c + k) % m];
    }
    expect("SELECT right: MORPH SET, MODE, MIXER, MORPH", ok);
    for (ok = 1, k = 1; k <= m; k++) {
        turn(EN_SELECT, -1);
        ok &= where() == r[(c + m * 2u - k) % m];
    }
    expect("SELECT left: the round backwards, back to MORPH", ok && where() == r[c]);
    for (ok = 1, k = 1; k <= m; k++) {
        press(B_HOME);
        frames(64);
        ok &= where() == r[(c + k) % m];
    }
    expect("HOME tapped: the same round (MIXER, then MORPH)", ok);
    expect("HOME: tempo untouched", song.g[G_BPM] == 117);
}

/* the screens that are not pages */
static void sweep_other(void)
{
    uint32_t r, k;
    /* the menu: SELECT moves the row */
    ui_power_on();
    song.g[G_BPM] = 117;
    ui.menu = 1; ui.menu_sel = 0; frames(48);
    for (r = 0; r < MI_COUNT; r++)
        expect("the menu has no BPM LOCK row", strcmp(MI_NAME[r], "BPM LOCK") != 0);
    r = ui.menu_sel;
    turn(EN_SELECT, 1);
    expect("menu: SELECT right moves the row down", ui.menu_sel != r && ui.menu == 1u && song.g[G_BPM] == 117);
    turn(EN_SELECT, -1);
    expect("menu: SELECT left moves it back", ui.menu_sel == r && song.g[G_BPM] == 117);
    for (k = 0; k < MI_COUNT * 2u; k++)
        turn(EN_SELECT, k & 1u ? -2 : 3);
    expect("menu: any number of turns, tempo untouched", song.g[G_BPM] == 117 && ui.menu == 1u);
    ui.menu = 2; ui.menu_scroll = 0; frames(48);
    turn(EN_SELECT, 1);
    expect("ABOUT: SELECT goes to the next section, tempo untouched, stays in ABOUT", ui.menu == 2u && ui.menu_scroll > 0u && song.g[G_BPM] == 117);
    ui.menu = 3; frames(48);
    turn(EN_SELECT, 1); turn(EN_SELECT, -1);
    expect("TEST: tempo untouched, stays in TEST", ui.menu == 3u && song.g[G_BPM] == 117);
    ui.menu = 0; frames(16);
    /* a dialog: nothing, the dialog stays */
    ui_power_on();
    song.g[G_BPM] = 117;
    enter(0);
    confirm_open(CF_CLEAR_SEQ, 0); frames(16);
    turn(EN_SELECT, 1); turn(EN_SELECT, -1);
    expect("dialog: SELECT does nothing (it stays, tempo untouched)", ui.confirm == CF_CLEAR_SEQ && song.g[G_BPM] == 117);
    ui.confirm = 0; frames(16);
    /* NAME */
    ui_power_on();
    song.g[G_BPM] = 117;
    name_open(NK_PROJ_SAVE, 0); frames(16);
    expect("NAME opened", name_on());
    turn(EN_SELECT, 1); turn(EN_SELECT, -1);
    expect("NAME: SELECT does nothing (it stays, tempo untouched)", name_on() && song.g[G_BPM] == 117);
}

/* SPEC 1.1a, the MENU: ALGORITHM and PRESETS do nothing there; KNOB 1 changes the selected row's value. DUELL 1.3 (owner 2026-11-13): the MENU opens on
 * the list of its seven sections; there SELECT picks a section (clamped at both ends) and OCT+ opens it; in a section SELECT walks its rows, stopping
 * at its first and last row (no wrap, a row without a place passed by), OCT- goes back to the list (MIDI's SIDECHAIN: back to its row) */
static void sweep_menu(void)
{
    uint32_t r, t, i, ok;
    static const uint8_t VR[] = {MI_ANIM, MI_HOLD, MI_ACCEL, MI_TUNE, MI_CLICK};
    ui_power_on();
    song.g[G_BPM] = 117;
    ui.menu = 6; ui.menu_sel = 0; frames(48);
    expect("menu: opened on the list at its first section, PLAYING", ui.menu == 6u && ui.menu_sel == 0u && menu_tab() == MTAB_PLAYING);   /* (2026-11-15: the new order) */
    ok = MTAB_LIST == 7u && str_eq(MTAB_NAME[0], "PLAYING") && str_eq(MTAB_NAME[1], "RECORDING") && str_eq(MTAB_NAME[2], "MORPH") && str_eq(MTAB_NAME[3], "PERFORM") &&
         str_eq(MTAB_NAME[4], "MODULES") && str_eq(MTAB_NAME[5], "MIDI") && str_eq(MTAB_NAME[6], "SYSTEM") && str_eq(MTAB_NAME[MTAB_SCHAIN], "SIDECHAIN");   /* (2026-11-15: the owner's order) */
    for (t = 0; t + 1u < MTAB_LIST; t++) {                     /* the list: SELECT right, a section a detent */
        turn(EN_SELECT, 1);
        ok &= ui.menu == 6u && menu_tab() == t + 1u;
    }
    turn(EN_SELECT, 1); turn(EN_SELECT, 5);
    ok &= ui.menu == 6u && menu_tab() == MTAB_LIST - 1u;
    turn(EN_SELECT, -20);
    ok &= ui.menu == 6u && menu_tab() == 0u;
    expect("menu: the list holds PLAYING RECORDING MORPH PERFORM MODULES MIDI SYSTEM; SELECT walks it, clamped at both ends (SIDECHAIN is no section of the list)", ok);
    for (t = 0; t < MTAB_LIST; t++) {                          /* each section: OCT+ opens it, SELECT walks every row with a place, clamped; OCT- back to the list */
        uint8_t vis[MI_COUNT];
        uint32_t nv = 0, k;
        for (r = mtab_first(t); r < mtab_end(t); r++)
            if (menu_shown(r))
                vis[nv++] = (uint8_t)r;
        ui.menu = 6; ui.menu_sel = (uint8_t)mtab_first(t); ui.menu_row[t] = 0; frames(4);
        press(B_OCTUP);
        ok = nv > 0u && ui.menu == 1u && menu_tab() == t && ui.menu_sel == vis[0];
        for (k = 0; k + 1u < nv; k++) {
            turn(EN_SELECT, 1);
            ok &= ui.menu == 1u && ui.menu_sel == vis[k + 1u];
        }
        turn(EN_SELECT, 1); turn(EN_SELECT, 4);
        ok &= ui.menu_sel == vis[nv - 1u] && menu_tab() == t;
        for (k = nv - 1u; k > 0; k--) {
            turn(EN_SELECT, -1);
            ok &= ui.menu == 1u && ui.menu_sel == vis[k - 1u];
        }
        turn(EN_SELECT, -1); turn(EN_SELECT, -6);
        ok &= ui.menu_sel == vis[0] && menu_tab() == t;
        press(B_OCTDN);
        ok &= ui.menu == 6u && menu_tab() == t;
        expect("menu: OCT+ opens a section at its first row; SELECT walks its rows in order (a row without a place passed by), stops at its last and first row; OCT- back to the list", ok);
    }
    ui.menu = 1; ui.menu_sel = MI_SCHAIN; frames(4);
    press(B_OCTUP);
    ok = ui.menu == 1u && menu_tab() == MTAB_SCHAIN && ui.menu_sel == MI_SC1CH;
    press(B_OCTDN);
    expect("menu: MIDI's SIDECHAIN row opens its four values (OCT+), OCT- goes back to the row", ok && ui.menu == 1u && ui.menu_sel == MI_SCHAIN);
    ui.menu = 1; ui.menu_sel = (uint8_t)mtab_first(MTAB_RECORDING); frames(4);   /* (a section with five rows; 2026-11-15: CONTROL is gone) */
    turn(EN_SELECT, 3);
    expect("menu: 3 detents in a frame move 3 rows", ui.menu_sel == mtab_first(MTAB_RECORDING) + 3u);
    /* ALGORITHM and PRESETS: nothing in the menu, wherever the selection is */
    for (i = 0; i < 4u; i++) {
        static const uint8_t AT[4] = {0, MI_HOLD, MI_TEST, MI_ERASE};
        uint32_t sel = AT[i], prefs = ui_prefs, sk = song.sel;
        ui.menu_sel = (uint8_t)sel; frames(4);
        turn(EN_ALGO, 1); turn(EN_ALGO, -1); turn(EN_ALGO, 3);
        turn(EN_PRESET, 1); turn(EN_PRESET, -1); turn(EN_PRESET, 4);
        expect("menu: ALGORITHM and PRESETS are inert (no row, no tab, no value, no part, no sound)",
               ui.menu_sel == sel && ui.menu == 1u && ui_prefs == prefs && song.sel == sk && song.g[G_BPM] == 117);
    }
    /* KNOB 1 changes the selected row's value, and only that row's */
    for (i = 0; i < sizeof VR; i++) {
        uint32_t v, w[MI_COUNT], j, other = 1;
        ui.menu_sel = VR[i]; frames(4);
        for (j = 0; j < MI_COUNT; j++)
            w[j] = menu_valued(j) ? menu_get(j) : 0u;
        v = menu_get(VR[i]);
        turn(EN_K1, 1);
        if (menu_get(VR[i]) == v)                              /* at its top: the other way */
            turn(EN_K1, -1);
        for (j = 0; j < MI_COUNT; j++)
            other &= j == VR[i] || !menu_valued(j) || menu_get(j) == w[j];
        expect(MI_NAME[VR[i]], menu_get(VR[i]) != v && other && ui.menu_sel == VR[i] && ui.menu == 1u);
    }
    ui.menu = 0; frames(16);
}

/* a layer button held: SELECT is nobody's (not the tempo, not the page) */
static void sweep_layers(void)
{
    static const uint8_t LB[] = {B_SCL, B_EDIT, B_SEQ, B_REC, B_LFO, B_ENV, B_ARP};   /* (GLO is a page, not a held layer, since step 6; FX neither,
                                                                                         * since 0.2.2; LFO ENV ARP: 0.2.9's QUICK EDIT layers) */
    uint32_t l;
    for (l = 0; l < sizeof LB; l++) {
        uint32_t pg;
        ui_power_on();
        song.g[G_BPM] = 117;
        enter(page_first(FAM_ENV));
        pg = ui.page;
        btn_down(LB[l]);
        frames(1200);                                    /* held past the threshold: the layer is open */
        turn(EN_SELECT, 1); turn(EN_SELECT, -2);
        expect("layer held: tempo untouched", song.g[G_BPM] == 117);
        expect("layer held: SELECT turns no page", ui.page == pg);
        btn_up(LB[l]);
        frames(64);
        turn(EN_SELECT, 0);
        expect("layer let go: the held-back turns do not land later", song.g[G_BPM] == 117 && ui.page == pg);
        settle();
    }
}

/* TEMPO (0.2.18): the TEMPO page KNOB 1 CLK, KNOB 2 TEMPO, KNOB 3 TAP, KNOB 4 SWG */
static void test_tempo(void)
{
    char val[8];
    const char *unit;
    int16_t b0;
    uint32_t c, glo1 = page_first(FAM_GLO), ck = 0, i, g0;
    ui_power_on();
    for (i = 0; i < NPAGES; i++)
        ck = PAGES[i].fam == FAM_GLO && str_eq(PAGES[i].title, "TEMPO") ? i : ck;
    expect("GLO's pages in order (0.2.25 layout round): MIXER (graph GR_GLO, scope SC_GMIX), TEMPO, CHORUS, DELAY 1/2, DELAY 2/2, REVERB, SHIMMER, STEREO MASTER (K1 BASS MONO, K2 WIDTH), COMPRESSOR (K1 RATIO, K2 THRESH, K3 ATTACK, K4 RELEASE), the last (1.3: MODULES, SIDECHAIN, MIDI, MIDI LEARN are MENU's); no TEST page (it is MENU > SYSTEM > TEST); TEMPO: KNOB 1 is G_CLOCK, KNOB 2 G_BPM, KNOB 3 TAP, KNOB 4 G_SWING",
           str_eq(PAGES[glo1].title, "MIXER") && PAGES[glo1].graph == GR_GLO && PAGES[glo1].scope == SC_GMIX &&
           str_eq(PAGES[glo1 + 1u].title, "TEMPO") && str_eq(PAGES[glo1 + 2u].title, "CHORUS") && str_eq(PAGES[glo1 + 3u].title, "DELAY 1/2") &&
           str_eq(PAGES[glo1 + 4u].title, "DELAY 2/2") && str_eq(PAGES[glo1 + 5u].title, "REVERB") && str_eq(PAGES[glo1 + 6u].title, "SHIMMER") &&
           str_eq(PAGES[glo1 + 7u].title, MASTER_PAGE_TITLE) && str_eq(MASTER_PAGE_TITLE, "STEREO MASTER") && PAGES[glo1 + 7u].scope == SC_GLOBAL && PAGES[glo1 + 7u].id[0] == G_BM && PAGES[glo1 + 7u].id[1] == G_WD && PAGES[glo1 + 7u].id[2] == 0xFFu &&
           str_eq(PAGES[glo1 + 8u].title, "COMPRESSOR") && PAGES[glo1 + 8u].scope == SC_GLOBAL && PAGES[glo1 + 8u].id[0] == G_CR && PAGES[glo1 + 8u].id[1] == G_CT &&
           PAGES[glo1 + 9u].fam != FAM_GLO &&           /* (DUELL 1.3: MODULES, SIDECHAIN, MIDI, MIDI LEARN are MENU's: COMPRESSOR is GLO's last page) */
           ck == glo1 + 1u && PAGES[ck].id[0] == G_CLOCK && PAGES[ck].id[1] == G_BPM && PAGES[ck].id[TEMPO_TAP_SLOT] == 0xFFu && TEMPO_TAP_SLOT == 2u &&
           PAGES[ck].id[3] == G_SWING &&
           PAGES[ck].scope == SC_GLOBAL && PAGES[ck].graph == GR_TEMPO);
    {
        uint32_t n = 0, gl = 0;
        for (i = 0; i < NPAGES; i++) {
            n += PAGES[i].graph == GR_GLO;
            gl += PAGES[i].fam == FAM_GLO && PAGES[i].scope == SC_GLOBAL;
        }
        expect("  .. one page draws GR_GLO (GLO's MIXER); the global effects are SC_GLOBAL pages of GLO (TEMPO, CHORUS, DELAY x2, REVERB, SHIMMER, STEREO MASTER, COMPRESSOR = 8)", n == 1u && gl == 8u);
    }
    for (i = 0, g0 = 0; i < NPAGES; i++)
        g0 += PAGES[i].scope == SC_TEST || PAGES[i].graph == GR_TEST || str_eq(PAGES[i].title, "TEST");
    expect("  .. no page named TEST or of its kind is in the table at all", g0 == 0u);
    expect("the label is TEMPO", str_eq(GP[G_BPM].label, "TEMPO"));
    {
        uint32_t i, c, n = 0;
        for (i = 0; i < NPAGES; i++)
            for (c = 0; c < 4u; c++)
                n += PAGES[i].scope == SC_GLOBAL && PAGES[i].id[c] == G_BPM;
        expect("no other page holds G_BPM", n == 1u);
    }
    press(B_GLO);                                    /* the first tap of GLO */
    expect("GLO tapped from HOME: the first page of GLO, MIXER (0.2.25 layout round)", ui.page == glo1 && str_eq(cur_page()->title, "MIXER"));
    settle();
    enter(ck);                                       /* the clock page */
    b0 = song.g[G_BPM];
    expect("CLK AUTO (the default since 0.2.14), no clock arriving: the internal clock", song.g[G_CLOCK] == CLK_AUTO && clock_src() == 0u);
    turn(EN_K2, 3);
    expect("KNOB 2 right x3: TEMPO +3", song.g[G_BPM] == b0 + 3);
    turn(EN_K2, -5);
    expect("KNOB 2 left x5: TEMPO -2 from the start", song.g[G_BPM] == b0 - 2);
    turn(EN_K2, 1000);
    expect("KNOB 2 clamps at 240", song.g[G_BPM] == 240);
    turn(EN_K2, -1000);
    expect("KNOB 2 clamps at 40", song.g[G_BPM] == 40);
    song.g[G_BPM] = 100;
    turn(EN_K4, 1); turn(EN_K3, 0);
    expect("KNOB 3, 3 are not the tempo", song.g[G_BPM] == 100);
    param_format(&GP[G_BPM], 100, val, &unit);
    expect("INT clock: the card shows 100 BPM", str_eq(val, "100") && str_eq(unit, "BPM"));
    for (c = 1; c <= 3u; c++) {              /* USB, TRS, AUTO locked on USB */
        song.g[G_CLOCK] = (int16_t)c;
        midi_clock.lock = (uint8_t)(c == CLK_AUTO);
        song.g[G_BPM] = 100;
        turn(EN_K2, 7); turn(EN_K2, -3);
        expect("external clock: KNOB 2 is inert", song.g[G_BPM] == 100);
        param_format(&GP[G_BPM], 100, val, &unit);
        expect("external clock: the card shows EXT", str_eq(val, "EXT") && str_eq(unit, ""));
        turn(EN_SELECT, 1); turn(EN_SELECT, -1);
        expect("external clock: SELECT leaves it", song.g[G_BPM] == 100);
        draw_columns();
    }
    midi_clock.lock = 0;
    param_format(&GP[G_BPM], 100, val, &unit);
    expect("AUTO, the clock gone: numbers again", str_eq(val, "100"));
    song.g[G_CLOCK] = 0;
    param_format(&GP[G_BPM], 100, val, &unit);
    expect("INT again: numbers", str_eq(val, "100"));
    turn(EN_K2, 1);
    expect("INT again: KNOB 2 edits", song.g[G_BPM] == 101);
    /* KNOB 3 TAP: each detent, either way, one tap; 2 s of rest start over; the tempo is the mean of the last 4 taps */
    song.g[G_BPM] = 90; song.g[G_SWING] = 0;
    frames(2200);
    turn(EN_K3, 1);
    expect("TAP: the first tap alone changes nothing", song.g[G_BPM] == 90 && ui.tap_n == 1u);
    fm1_ms += 484; turn(EN_K3, -1);                  /* 500 ms after the first, turned the other way */
    expect("TAP: a second tap (the other direction) 500 ms later: 120 BPM", song.g[G_BPM] == 120 && ui.tap_n == 2u);
    fm1_ms += 484; turn(EN_K3, 1);
    fm1_ms += 484; turn(EN_K3, 1);
    expect("TAP: four taps 500 ms apart: still 120", song.g[G_BPM] == 120 && ui.tap_n == 4u);
    fm1_ms += 384; turn(EN_K3, 1);                   /* 400 ms: the last four taps are 500, 500, 400 apart */
    expect("TAP: the fifth tap, 400 ms after the fourth: the mean of the last 4 taps (3 intervals in 1400 ms = 129 BPM)", song.g[G_BPM] == 129 && ui.tap_n == 4u);
    expect("  .. the card shows the BPM while tapping", tempo_tapping() == 4u);
    draw_columns();
    fm1_ms += 2100;
    expect("  .. 2 s later the card is TAP again", tempo_tapping() == 0u);
    b0 = song.g[G_BPM];
    turn(EN_K3, 1);
    expect("TAP: after the 2 s a new run starts, one tap changes nothing", song.g[G_BPM] == b0 && ui.tap_n == 1u);
    fm1_ms += 584; turn(EN_K3, 1);
    expect("  .. the next 600 ms later: 100 BPM", song.g[G_BPM] == 100 && ui.tap_n == 2u);
    turn(EN_K3, 40);
    expect("  .. a fast twist is one tap per frame, not one per detent", ui.tap_n == 3u);
    song.g[G_BPM] = 100; frames(2200);
    song.g[G_CLOCK] = 1;
    ui.msg_t = 0;
    turn(EN_K3, 1); fm1_ms += 484; turn(EN_K3, 1);
    draw_columns();
    expect("TAP with an external clock: the TEMPO and TAP cards are not drawn, CLOCK and SWING take K1 and K2; K3 does nothing and says nothing", song.g[G_BPM] == 100 && !ui.msg_t &&
           ui.col[2][0] == 0x7f && ui.col[3][0] == 0x7f && ui.col[0][0] != 0x7f && card_is(1, "SWING|"));   /* (T0227: CLOCK and SWING move left: K1, K2) */
    song.g[G_CLOCK] = 0;
    g0 = (uint32_t)song.g[G_SWING];
    turn(EN_K4, 4);
    expect("TEMPO KNOB 4 is SWING", (uint32_t)song.g[G_SWING] != g0);
    /* KNOB 1 CLK (moved here from the MIDI page): INT / USB / TRS, a detent a step, clamped; the tempo and the MIDI settings untouched */
    song.g[G_BPM] = 100; song.g[G_ROUTE] = 0; song.g[G_CLOCK] = 0;
    turn(EN_K1, 1);
    expect("TEMPO KNOB 1 CLK right: USB", song.g[G_CLOCK] == 1);
    turn(EN_K1, 1);
    expect("  .. right again: TRS", song.g[G_CLOCK] == 2);
    turn(EN_K1, 3);
    expect("  .. clamps at TRS", song.g[G_CLOCK] == 2);
    draw_columns();
    turn(EN_K1, -1);
    expect("  .. left: USB", song.g[G_CLOCK] == 1);
    turn(EN_K1, -4);
    expect("  .. left: INT (clamped), the tempo and MIDI IN untouched", song.g[G_CLOCK] == 0 && song.g[G_ROUTE] == 0 && song.g[G_BPM] == 100);
    /* the keys play notes on the TEMPO page (the page is not a layer) */
    frames(48);
    expect("TEMPO: the keys are notes (no layer, no kb_lock)", kb_lock == 0u && !ui.layer);
    key_down(3);
    expect("  .. a key held plays a note and is no layer key", !((kb_layer >> 3) & 1u) && kb_note[3] != KB_SILENT && gates() > 0u);
    key_up(3);
}

/* DUELL step 6, 0.2.21: GLO's pages. A tap of GLO opens TEMPO (the old first page, MUTE / LEVEL, is no page: it is the hold-GLO QUICK layer and the MIXER page), the global effects follow,
 * then MODULES and the MIDI pages */
static void test_glo_page(void)
{
    uint32_t glo1 = page_first(FAM_GLO);
    int16_t lvl;
    ui_power_on();
    song.g[G_BPM] = 117;
    go_title("AMP ENV");
    frames(48);
    press(B_GLO);
    frames(48);
    expect("GLO tapped: its first page, MIXER (0.2.25 layout round: graph GR_GLO, drawn as the hold-GLO layer), no layer held, the keys are the page's (kb_lock 0)",
           ui.page == glo1 && !ui.layer && kb_lock == 0u && cur_page()->graph == GR_GLO && str_eq(cur_page()->title, "MIXER") && badge_lit() == 3u);
    frames(48);
    expect("  .. its cards: LEVEL 1, LEVEL 2 (DUEL, ui_power_on's mode: no PAN cards; item 117 order)", card_is(0, "LEVEL 1|") && card_is(1, "LEVEL 2|") && str_eq(ui.col[2], "\x7f") && str_eq(ui.col[3], "\x7f"));
    lvl = trk[1].p[P_LEVEL];
    turn(EN_K2, -2);
    expect("  .. K2 on the page: LEVEL 2", trk[1].p[P_LEVEL] == lvl - 2);
    trk[1].p[P_LEVEL] = lvl;
    turn(EN_SELECT, 1);
    frames(48);
    expect("  .. SELECT right: TEMPO", cur_page()->graph == GR_TEMPO && ui.page == glo1 + 1u);
    trk[0].p[P_MUTE] = trk[1].p[P_MUTE] = 0;
    key_down(1);                                         /* F#3 plays a note: it was MUTE part 1 */
    frames(48);
    expect("  .. F#3 held: it plays a note (no layer key)", !((kb_layer >> 1) & 1u) && kb_note[1] != KB_SILENT && gates() > 0u);
    key_up(1);
    frames(48);
    key_down(10);                                        /* D4 was MIDI LEARN: no more */
    frames(48); key_up(10); frames(48);
    expect("  .. D4: no MIDI LEARN here", !ui.ml.on);
    /* the QUICK GLO layer (hold GLO), 0.2.24 (owner; item 117 order): K1 LEVEL 1, K2 LEVEL 2, K3 PAN 1, K4 PAN 2 over any page; OCT- / OCT+ with GLO held mute part 1 / part 2 */
    duell_mode_req = DM_STEREO;
    btn_down(B_GLO); frames(640);
    expect("GLO held: the QUICK GLO layer over TEMPO", ui.layer == LAYER_GLO && cur_page()->graph == GR_TEMPO && badge_lit() == 3u);
    expect("  .. its cards: LEVEL 1, LEVEL 2, PAN 1, PAN 2", card_is(0, "LEVEL 1|") && card_is(1, "LEVEL 2|") && card_is(2, "PAN 1|") && card_is(3, "PAN 2|"));
    lvl = trk[0].p[P_LEVEL];
    turn(EN_K1, 5);
    expect("KNOB 1: LEVEL 1 (part 1)", trk[0].p[P_LEVEL] != lvl && trk[1].p[P_LEVEL] == TP[P_LEVEL].def);
    lvl = trk[0].p[P_PAN];
    turn(EN_K3, 5);
    expect("KNOB 3: PAN 1 (part 1), the pan can be set from the panel", trk[0].p[P_PAN] == lvl + 5 && trk[1].p[P_PAN] == 0);
    lvl = trk[1].p[P_LEVEL];
    turn(EN_K2, -5);
    expect("KNOB 2: LEVEL 2 (part 2)", trk[1].p[P_LEVEL] != lvl);
    turn(EN_K4, -7);
    expect("KNOB 4: PAN 2 (part 2)", trk[1].p[P_PAN] == -7 && trk[0].p[P_PAN] == 5);
    trk[0].p[P_PAN] = trk[1].p[P_PAN] = 0;
    btn_down(B_OCTDN); frame();
    expect("OCT- pressed with GLO held: part 1 muted at once, said (PART 1: MUTE)", trk[0].p[P_MUTE] == 1 && trk[1].p[P_MUTE] == 0 && !glo_sounding(0) && glo_sounding(1) && msg_is("PART 1: MUTE"));
    btn_up(B_OCTDN); frames(48);
    expect("  .. its release moves no octave", song.octave == 0 && trk[0].p[P_MUTE] == 1);
    btn_down(B_OCTDN); frame(); btn_up(B_OCTDN); frames(48);
    expect("  .. OCT- again: part 1 UNMUTED", trk[0].p[P_MUTE] == 0 && glo_sounding(0) && song.octave == 0);
    btn_down(B_OCTUP); frame();
    expect("OCT+ with GLO held: part 2 muted (part 1 untouched)", trk[1].p[P_MUTE] == 1 && trk[0].p[P_MUTE] == 0 && msg_is("PART 2: MUTE"));
    btn_up(B_OCTUP); frames(48);
    btn_down(B_OCTUP); frame(); btn_up(B_OCTUP); frames(48);
    expect("  .. OCT+ again: part 2 UNMUTED, no octave moved", trk[1].p[P_MUTE] == 0 && song.octave == 0);
    expect("  .. the layer is still open (a key with GLO is a combo, not a tap)", ui.layer == LAYER_GLO && (ui.ly_t0 & LY_COMBO));
    duell_mode_req = DM_SPLIT;
    frames(48);
    expect("DUEL: the PAN cards (K3, K4 since item 117) are not drawn (part 1 left, part 2 right), LEVEL 1 and LEVEL 2 stay", card_hidden(2) && card_hidden(3) && card_is(0, "LEVEL 1|") && card_is(1, "LEVEL 2|"));
    lvl = trk[0].p[P_PAN];
    turn(EN_K2, 3);
    expect("  .. K2 does nothing in DUEL", trk[0].p[P_PAN] == lvl);
    duell_mode_req = DM_STEREO;
    frames(48);
    expect("  .. the tempo untouched, the keys still notes", song.g[G_BPM] == 117 && kb_lock == 0u);
    btn_up(B_GLO);
    frames(64);
    expect("  .. let go: the layer is closed, TEMPO is back", !ui.layer && ui.page == glo1 + 1u);
    frames(600);                                         /* (the layer's hold: the knobs are quiet a moment after it) */
    ui.page = (uint8_t)(glo1 + 1u); page_entered();
    {   /* the round: TEMPO, CHORUS, DELAY 1/2, DELAY 2/2, REVERB, (SHIMMER only with TYPE SHIM), MODULES, SIDECHAIN, MIDI, MIDI LEARN, MIXER. Item 158 (owner, nothing to adjust = no page): in DUEL, where
         * ui_power_on leaves the mode, STEREO MASTER and COMPRESSOR hide every card, so they are not in the round (STEREO / LAYER: ui_test.c test_item158_pages) */
        static const char *const R[] = {"CHORUS", "DELAY 1/2", "DELAY 2/2", "REVERB", "MIXER", "TEMPO"};   /* (DUELL 1.3: MODULES, SIDECHAIN, MIDI, MIDI LEARN left GLO for the MENU) */
        uint32_t i, ok = 1, glob = 1;
        for (i = 0; i < sizeof R / sizeof R[0]; i++) {
            turn(EN_SELECT, 1);
            frames(48);
            ok &= (uint32_t)str_eq(cur_page()->title, R[i]) && kb_lock == 0u && song.g[G_BPM] == 117;
            if (i < 4u)
                glob &= (uint32_t)(cur_page()->scope == SC_GLOBAL && badge_lit() == 3u);
        }
        expect("SELECT right x6: CHORUS, DELAY 1/2, DELAY 2/2, REVERB (SHIMMER skipped: TYPE is not SHIM; DUEL: STEREO MASTER and COMPRESSOR skipped, nothing to adjust), MIXER, round to TEMPO; the keys play notes", ok);
        expect("  .. the global effect pages light both parts' badges", glob);
        enter(glo1 + 1u);
        song.g[G_RTYPE] = 3;
        for (i = 0; i < 5u; i++)
            turn(EN_SELECT, 1);
        expect("  .. with the reverb TYPE SHIM the SHIMMER page follows REVERB", str_eq(cur_page()->title, "SHIMMER"));
        song.g[G_RTYPE] = 2;
        enter(glo1 + 1u);
    }
    turn(EN_SELECT, 1);
    frames(48);
    expect("  .. SELECT right: CHORUS", str_eq(cur_page()->title, "CHORUS"));
    {
        uint32_t k5;
        for (k5 = 0; k5 < 4u; k5++)
            turn(EN_SELECT, 1);
    }
    frames(48);
    expect("  .. four more detents: MIXER, GLO's first page again (DUEL: STEREO MASTER and COMPRESSOR, every card hidden, are not in the round; item 158; 1.3: MODULES is MENU's)", str_eq(cur_page()->title, "MIXER") && song.bm == BM_DEF && song.ms[0] == 100 && song.g[G_BPM] == 117);
    expect("  .. MIXER: the keys play notes; MODULES all four ON", kb_lock == 0u && mods_get() == 0u);
    {   /* DUELL 1.3 (owner 2026-11-13): GLO > SIDECHAIN (0.2.22) is MENU > MIDI > SIDECHAIN, four rows (any knob sets the picked row, one step a turn) */
        int16_t src0 = TSEL->p[P_DKSRC], note0 = TSEL->p[P_CUT2];
        uint8_t b1[4];
        expect("SIDECHAIN (0.2.22; 1.3: MENU > MIDI > SIDECHAIN): the sidechain's MIDI setup, four rows PART 1 CHANNEL, PART 1 NOTE, PART 2 CHANNEL, PART 2 NOTE (a device setting)",
               mtab_first(MTAB_SCHAIN) == MI_SC1CH && mtab_end(MTAB_SCHAIN) == MI_SC2NT + 1u && str_eq(MI_NAME[MI_SC1CH], "PART 1 CHANNEL") && str_eq(MI_NAME[MI_SC1NT], "PART 1 NOTE") &&
               str_eq(MI_NAME[MI_SC2CH], "PART 2 CHANNEL") && str_eq(MI_NAME[MI_SC2NT], "PART 2 NOTE") && MI_TAB[MI_SCHAIN] == MTAB_MIDI);
        expect("  .. its defaults: P1 CH 10, P1 NOTE 36 (C2), P2 CH 10, P2 NOTE 36", sc_midi[0] == 9u && sc_midi[1] == 36u && sc_midi[2] == 9u && sc_midi[3] == 36u);
        expect("  .. all four rows while the part's DUCK SRC is OFF (0.2.24's default; the setup is editable whatever the SRC is)", TSEL->p[P_DKSRC] == 3 && menu_shown(MI_SCHAIN) &&
               menu_shown(MI_SC1CH) && menu_shown(MI_SC1NT) && menu_shown(MI_SC2CH) && menu_shown(MI_SC2NT));
        row_turn(MI_SC1CH, 3); row_turn(MI_SC1NT, 2); row_turn(MI_SC2CH, -2); row_turn(MI_SC2NT, 5);
        expect("  .. P1 CH 13, P1 NOTE up, P2 CH 8, P2 NOTE up (settings bytes, a save queued)", sc_midi[0] == 12u && sc_midi[1] > 36u && sc_midi[2] == 7u && sc_midi[3] > 36u && ui_sc_set[0] == 13u &&
               ui_sc_set[2] == 8u && ui_sc_set[1] == sc_midi[1] + 1u && ui_sc_set[3] == sc_midi[3] + 1u && ui.mset_dirty);
        expect("  .. no DUCK parameter of either part moved", TSEL->p[P_DKSRC] == src0 && TSEL->p[P_CUT2] == note0 && trk[0].p[P_DKSRC] == 3 && trk[1].p[P_DKSRC] == 3 && song.g[G_ROUTE] == 0 && song.g[G_BPM] == 117);
        memcpy(b1, ui_sc_set, 4);
        row_turn(MI_SC1CH, -20); row_turn(MI_SC1NT, -60);
        expect("  .. the channel stops at 1, the note at ANY", sc_midi[0] == 0u && sc_midi[1] == 0u && ui_sc_set[0] == 1u && ui_sc_set[1] == 1u);
        row_turn(MI_SC1CH, 20); row_turn(MI_SC1NT, 140);
        expect("  .. and at 16 and 127", sc_midi[0] == 15u && sc_midi[1] == 127u);
        song.sel = 1;
        frames(48);
        expect("  .. the rows read the same four whichever part is selected", menu_get(MI_SC1CH) == sc_get(0) && sc_midi[0] == 15u && sc_midi[1] == 127u);
        song.sel = 0;
        memcpy(ui_sc_set, b1, 4);
        mods_put(MODS_PFX, 1u);
        frames(48);
        expect("  .. PART FX OFF: the ducker is skipped, the SIDECHAIN row and its four values not shown", !menu_shown(MI_SCHAIN) && !menu_shown(MI_SC1CH) && !menu_shown(MI_SC2NT));
        mods_put(MODS_PFX, 0u);
        ui.menu = 0;
        frames(48);
        sc_put(0, SC_CH_DEF); sc_put(1, SC_NOTE_DEF); sc_put(2, SC_CH_DEF); sc_put(3, SC_NOTE_DEF);
        {
            uint32_t i, ok = 0;
            for (i = 0; i < NPAGES; i++)
                ok |= str_eq(PAGES[i].title, "DUCK 1/2") && PAGES[i].id[0] == P_DKSRC && PAGES[i].id[1] == P_DKRATE;
            TSEL->p[P_DKSRC] = 0;
            ok &= duck_ctx_id(TSEL) == P_DKRATE;
            TSEL->p[P_DKSRC] = 1;
            ok &= duck_ctx_id(TSEL) == P_DKTHR;
            TSEL->p[P_DKSRC] = 3;
            expect("  .. DUCK 1/2 keeps SRC, then RATE (PUMP) / THR (PART); MIDI and OFF have no second card", ok && duck_ctx_id(TSEL) == 0xFFu);
            TSEL->p[P_DKSRC] = 1;
            ok = duck_ctx_id(TSEL) == P_DKTHR;
            TSEL->p[P_DKSRC] = 2;
            ok &= duck_ctx_id(TSEL) == 0xFFu && str_eq(TP[P_CUT2].label, "CUTOFF");   /* (the retired NOTE id, the EQ switch of 0.2.24, is the TWIN FILTER's CUTOFF 2 now) */
            TSEL->p[P_DKSRC] = 0;
            expect("  .. (SRC MIDI: no second card; the retired NOTE id is the TWIN FILTER's CUTOFF 2 now)", ok);
            go_title("DUCK 1/2"); frames(48);
            ok = card_is(0, "SOURCE|TEMPO PUMP|") && card_is(1, "RATE|") && card_is(2, "DEPTH|") && card_hidden(3);   /* (PUMP: SOURCE, RATE, DEPTH; no SETUP card, nothing on K4) */
            TSEL->p[P_DKSRC] = 2;
            frames(48);
            ok &= card_is(2, "SETUP|SETTINGS|") && card_is(1, "DEPTH|") && card_is(0, "SOURCE|MIDI NOTE|") && card_hidden(3);   /* (T0227: K2 RATE has no card, the rest move left; the source reads MIDI NOTE) */
            {
                int16_t sv = TSEL->p[P_DKSRC];
                uint8_t c0 = sc_midi[0];
                turn(EN_K3, 1);
                frames(8);
                fm1_ms += 400; frames(2);               /* (the jump swallows the rest of that knob's twist for KR_QUIET_MS) */
                ok &= ui.menu == 1u && menu_tab() == MTAB_SCHAIN && TSEL->p[P_DKSRC] == sv && sc_midi[0] == c0;   /* (DUELL 1.3: MENU > MIDI > SIDECHAIN) */
                ui.menu = 0;
            }
            TSEL->p[P_DKSRC] = 0;
            expect("  .. DUCK 1/2 (0.2.22; T0227: moved left): with SOURCE MIDI a SETUP / GLO card on K3, a twist jumps to MENU > MIDI > SIDECHAIN (nothing edited); with PUMP / PART no such card", ok);
        }
    }
    {
        uint32_t pg = ui.page;
        row_turn(MI_P1CH, 0);                            /* DUELL 1.3: GLO > MIDI is MENU > MIDI, rows PART 1 CHANNEL, PART 2 CHANNEL, MIDI IN */
        frames(48);
        expect("  .. MENU > MIDI open over the page, the keys play notes", ui.menu == 1u && menu_tab() == MTAB_MIDI && ui.page == pg && kb_lock == 0u && song.g[G_BPM] == 117);
    }
    row_turn(MI_P1CH, 4);
    row_turn(MI_P2CH, 5);
    expect("MIDI PART 1 CHANNEL, PART 2 CHANNEL: P1 CH 5, P2 CH 7 (MIDI IN untouched: OWN CH)", midi_pch[0] == 4u && midi_pch[1] == 6u && song.g[G_ROUTE] == 0);
    row_turn(MI_MIDIIN, 1);
    expect("  .. MIDI IN, a knob right: SELECTED", song.g[G_ROUTE] == 1);
    frames(48);
    {   /* GLO > MIDI (item 86, owner 2026-10-25): the three cards are always there and always adjustable, whatever MIDI IN says; K3 sets MIDI IN, a detent either way */
        uint8_t vis[4];
        expect("  .. SELECTED: the three cards stay (PART 1 CHANNEL, PART 2 CHANNEL, MIDI IN), none hidden or moved (item 86; was: the channel cards gone, MIDI IN on K1)",
               ((void)vis, menu_shown(MI_P1CH) && menu_shown(MI_P2CH) && menu_shown(MI_MIDIIN))   /* (DUELL 1.3: GLO > MIDI is MENU > MIDI: its three rows always shown) */);
    }
    fm1_ms += 400;
    row_turn(MI_MIDIIN, -1);
    expect("  .. MIDI IN, a knob left: PART CHANNEL again (item 86: a detent either way sets it)", song.g[G_ROUTE] == 0);
    row_turn(MI_P1CH, -1);
    expect("  .. PART 1 CHANNEL, a knob left: one down, MIDI IN untouched", midi_pch[0] == 3u && song.g[G_ROUTE] == 0 && song.g[G_BPM] == 117);
    frames(48);
    song.g[G_CLOCK] = 0;
    expect("  .. the clock untouched (CLK is on TEMPO)", song.g[G_CLOCK] == 0 && midi_pch[0] == 3u && song.g[G_ROUTE] == 0 && song.g[G_BPM] == 117);
    ui.menu_sel = MI_MLEARN;
    frames(4);
    press(B_OCTUP);
    frames(48);
    expect("  .. MIDI LEARN's row, OCT+: its screen (1.3: MENU > MIDI > MIDI LEARN, was GLO's page)", ui.menu == 4u && ui.menu_sel == MI_MLEARN);
    /* (owner 2026-11-15: as TOOLS, a knob picks a card, OCT+ does it; CLEAR ALL asks; OCT- drops the pick, else back) */
    turn(EN_K1, 1);
    expect("MIDI LEARN KNOB 1: LEARN picked, nothing started yet", ml_act == 1u && !ui.ml.on);
    press(B_OCTUP);
    expect("  .. OCT+: learning ON", ui.ml.on == 1u);
    press(B_OCTUP);
    expect("  .. OCT+ again (the card says DONE): learning OFF", ui.ml.on == 0u && ui.menu == 4u);
    ml_learn(26, 0, P_LEVEL);                            /* one CC learned (a line of the MIDI MAP) */
    expect("  .. a CC is learned", ml_count() == 1u);
    turn(EN_K2, 1);
    expect("  .. KNOB 2: CLEAR ALL picked, nothing cleared", ml_act == 2u && ml_count() == 1u);
    press(B_OCTUP);
    expect("  .. OCT+: the CLEAR ALL dialog, nothing cleared yet", ui.confirm == CF_ML_CLEAR && ml_count() == 1u);
    press(B_OCTDN);
    expect("  .. OCT- in the dialog: NO, nothing cleared", !ui.confirm && ml_count() == 1u && msg_is("NOTHING CLEARED"));
    turn(EN_K2, 1); press(B_OCTUP); press(B_OCTUP);
    expect("  .. KNOB 2, OCT+, OCT+ (YES): every learned CC gone", !ui.confirm && ml_count() == 0u && msg_is("LEARN CLEARED"));
    turn(EN_K1, 1);
    press(B_OCTDN);
    expect("  .. OCT- with a card picked: the pick dropped, the screen stays", ml_act == 0u && ui.menu == 4u);
    press(B_OCTDN);
    frames(48);
    expect("  .. OCT-: back to SETTINGS > MIDI at MIDI LEARN's row; the keys still play notes", ui.menu == 1u && ui.menu_sel == MI_MLEARN && kb_lock == 0u && song.g[G_BPM] == 117);
    ui.menu = 1;
    frames(48);
    expect("  .. the menu over it: the keys play", kb_lock == 0u);
    ui.menu = 0;
    frames(48);
}

/* DUELL 0.1: TEST (was INFO) and ABOUT open with KNOB 1 turned right as well as OCT+; OCT- closes them (on TEST KNOB 1 is MORPH, both ways; in ABOUT, 0.2.9,
 * KNOB 1 scrolls and SELECT goes between its sections); CALIBRATION (a setup) still takes OCT+ only */
static void sweep_readonly(void)
{
    ui_power_on();
    ui.menu = 1; ui.menu_sel = MI_TEST; frames(8);
    expect("the item is called TEST", str_eq(MI_NAME[MI_TEST], "TEST") && MI_TAB[MI_TEST] == MTAB_SYSTEM);
    turn(EN_K1, 1);
    expect("TEST: KNOB 1 right does not open it (owner 2026-11-16: the knobs never open)", ui.menu == 1u);
    press(B_OCTUP);
    expect("TEST: OCT+ opens it", ui.menu == 3u);
    turn(EN_K1, 2);
    expect("  .. KNOB 1 right again: stays (it is MORPH there)", ui.menu == 3u);
    turn(EN_K1, -1);
    expect("  .. KNOB 1 left: stays too (MORPH goes both ways); OCT- is the way back", ui.menu == 3u);
    press(B_OCTDN);
    expect("  .. OCT-: back to the tabs, TEST still the row", ui.menu == 1u && ui.menu_sel == MI_TEST);
    press(B_OCTUP);
    expect("  .. OCT+ still opens it", ui.menu == 3u);
    press(B_OCTDN);
    expect("  .. OCT- closes it", ui.menu == 1u);
    ui.menu_sel = MI_ABOUT; frames(4);
    turn(EN_K1, 1);
    expect("ABOUT: KNOB 1 right does not open it (the knobs never open)", ui.menu == 1u);
    press(B_OCTUP);
    expect("ABOUT: OCT+ opens it", ui.menu == 2u && ui.menu_scroll == 0u);
    {   /* 0.2.9 (the owner): KNOB 1 scrolls down and up, SELECT right / left the next / previous section, PRESETS and KNOB 2..4 nothing */
        uint32_t s1, s2, s3, s4, max = (uint32_t)menu_scroll_max(), ok = 1;
        turn(EN_K1, 2);
        s1 = ui.menu_scroll;
        turn(EN_K1, -1);
        ok &= ui.menu == 2u && s1 == 36u && ui.menu_scroll == 18u;
        turn(EN_K1, -5);
        ok &= ui.menu == 2u && ui.menu_scroll == 0u;     /* (at the top: the animation; KNOB 1 left stays in ABOUT) */
        turn(EN_K1, 2000);
        ok &= ui.menu_scroll == max;                      /* (bounded) */
        expect("  .. KNOB 1 scrolls: right down 18 px a detent, left up, bounded at the top (the animation) and the end; it never leaves ABOUT", ok);
        ui.menu_scroll = 0;
        turn(EN_SELECT, 1); s1 = ui.menu_scroll;
        turn(EN_SELECT, 1); s2 = ui.menu_scroll;
        turn(EN_SELECT, 1); s3 = ui.menu_scroll;
        turn(EN_SELECT, 1); s4 = ui.menu_scroll;
        ok = s1 == 1u && (int32_t)s2 == (about_sec[0] < (int32_t)max ? about_sec[0] : (int32_t)max) &&
             (int32_t)s3 == (about_sec[1] < (int32_t)max ? about_sec[1] : (int32_t)max) && s4 == s3 && s3 > s2;
        turn(EN_SELECT, -1);
        ok &= ui.menu_scroll == s2;
        turn(EN_SELECT, -3);
        ok &= ui.menu_scroll == 0u && ui.menu == 2u;
        expect("  .. SELECT right: the information, CREDITS, LICENSES (then stays); left back to the animation, no wrap", ok);
        ui.menu_scroll = s2;
        turn(EN_PRESET, 3); turn(EN_K2, 2); turn(EN_K3, -2); turn(EN_K4, 1); turn(EN_ALGO, 1);
        expect("  .. PRESETS, ALGORITHM, KNOB 2..4: nothing (no scroll, no way back)", ui.menu == 2u && ui.menu_scroll == s2);
    }
    press(B_OCTDN);
    expect("  .. OCT-: back to the tabs", ui.menu == 1u && ui.menu_sel == MI_ABOUT);
    press(B_OCTUP);
    expect("  .. OCT+ still opens it", ui.menu == 2u && ui.menu_scroll == 0u);
    press(B_OCTDN);
    ui.menu_sel = MI_PANEL; frames(4);
    turn(EN_K1, 1);
    expect("BUTTON MAP (was CALIBRATION): KNOB 1 right does not start it (OCT+ only)", ui.menu == 1u && ui.menu_sel == MI_PANEL);
    ui.menu = 0; frames(8);
}

/* DUELL 0.1: MENU > CONTROL > HOME OPENS: the page HOME opens from another page, at power-on and when the menu closes.
 * 0.2.14: MORPH, MODE, MIXER (OVERVIEW is gone with its page; a stored 3, OVERVIEW up to 0.2.13, reads as MORPH) */
static void sweep_homepg(void)
{
    static const char *const T[4] = {"MORPH", "MACROS 1/2", "MACROS 2/2", "PERFORM"};   /* (DUELL 1.3: PERFORM, opened over MORPH; 2026-11-15: the MACROS pages, no MODE) */
    uint32_t v, ok;
    expect("HOME OPENS: four values, MORPH, MACROS 1/2, MACROS 2/2, PERFORM (2026-11-15: the MACROS pages; MODE left HOME)", HP_COUNT == 4 && menu_n(MI_HOMEPG) == 4u &&
           str_eq(menu_vname(MI_HOMEPG, 1), "MACROS 1/2") && str_eq(menu_vname(MI_HOMEPG, 2), "MACROS 2/2") && str_eq(menu_vname(MI_HOMEPG, 3), "PERFORM"));
    for (v = 0; v < HP_COUNT; v++) {
        ui_power_on();
        menu_put(MI_HOMEPG, v);
        go_main(); frames(32);
        ok = str_eq(cur_page()->title, T[v]) && ui.perf == (v == HP_PERF);
        go_title("AMP ENV"); frames(16);
        press(B_HOME); frames(32);
        ok &= str_eq(cur_page()->title, T[v]) && ui.perf == (v == HP_PERF);
        hold(B_HOME); frames(16);                         /* the menu, then HOME closes it: the same page */
        press(B_HOME); frames(32);
        ok &= !ui.menu && str_eq(cur_page()->title, T[v]) && ui.perf == (v == HP_PERF);
        expect(T[v], ok);
        ui.perf = 0;
    }
    ui_power_on();
    ui_home_pg = 3;                                       /* OVERVIEW stored by 0.2.13: MORPH, never the old page */
    go_main(); frames(16);
    ok = str_eq(cur_page()->title, "MORPH") && menu_get(MI_HOMEPG) == 0u && ui_home_pg == 3u;
    go_title("AMP ENV"); frames(16);
    press(B_HOME); frames(16);
    expect("HOME OPENS stored OVERVIEW (0.2.13): MORPH, the byte kept as stored", ok && str_eq(cur_page()->title, "MORPH"));
    ui_home_pg = 77;
    expect("  an unknown stored code reads as MORPH", menu_get(MI_HOMEPG) == 0u);
    ui_power_on();
}

/* 0.2.9 (the owner: "hide the step strip except on sequencer pages"): the footer's step bars only on SEQ's pages (STEP, AUTOMATION) and the SEQ TOOLS
 * layer; elsewhere the footer is not redrawn for a changed step or the playhead */
#define SEQ_STRIP(pg) (PAGES[pg].fam == FAM_SEQ && PAGES[pg].graph != GR_ROLL && PAGES[pg].graph != GR_SEQHELP)
static void sweep_footstrip(void)
{
    uint32_t pg, ok = 1, seq = 0;
    ui_power_on();
    for (pg = 0; pg < NPAGES; pg++) {
        ui.page = (uint8_t)pg;
        ok &= foot_steps() == SEQ_STRIP(pg);
        seq += foot_steps();
    }
    go_main_to(HP_MORPH);
    ok &= !foot_steps();
    ui.layer = LAYER_SEQ;
    ok &= foot_steps() != 0;
    ui.layer = 0;
    expect("footer: the step strip on SEQ's PARAMETER LOCKS page only (item 118: not on STEP, whose roll shows its steps, nor SEQUENCER HELP) and SEQ TOOLS; not on HOME, not on any other page", ok && seq == 1u);
    {   /* 0.2.9: the ARP pages show it too, while the part's arp MODE is SEQUENCER (AM_SEQ); the playhead is the arp's own step */
        uint32_t arp = 0, none = 1, five = 1;
        TSEL->p[P_AMODE] = AM_SEQ;
        TSEL->p[P_SLEN] = 16;
        for (pg = 0; pg < NPAGES; pg++) {
            ui.page = (uint8_t)pg;
            ok &= foot_steps() == (SEQ_STRIP(pg) || PAGES[pg].fam == FAM_ARP);
            arp += PAGES[pg].fam == FAM_ARP && foot_steps();
        }
        go_main_to(HP_MORPH);
        ok &= !foot_steps();
        TSEL->p[P_AMODE] = AM_UP;
        for (pg = 0; pg < NPAGES; pg++) {
            ui.page = (uint8_t)pg;
            ok &= foot_steps() == SEQ_STRIP(pg);
        }
        go_title("ARP 1/3");
        TSEL->p[P_AMODE] = AM_SEQ;
        TSEL->nheld = 0; TSEL->arp_idx = 0xFFFFFFFFu; song.playing = 0; TSEL->seq_idx = 9;
        none &= foot_playhead(TSEL) == 0xFFu;                          /* no key held: no playhead (the sequencer's seq_idx is not it) */
        TSEL->nheld = 1; TSEL->arp_idx = 21;
        five &= foot_playhead(TSEL) == 5u;                              /* 21 % 16: the arp's own step, with PLAY stopped */
        song.playing = 1;
        five &= foot_playhead(TSEL) == 5u;                              /* (seq_idx 9 is not what the arp plays) */
        go_title("STEP");
        none &= foot_playhead(TSEL) == 9u;                              /* SEQ's pages: the sequencer's step, as before */
        song.playing = 0;
        none &= foot_playhead(TSEL) == 0xFFu;
        TSEL->nheld = 0; TSEL->p[P_AMODE] = AM_OFF;
        expect("footer: the ARP pages show the strip only with MODE SEQUENCER, and mark the arp's own step (arp_idx % LEN)", ok && arp == 3u && none && five);
    }
    go_title("AMP ENV");
    frame();
    {
        uint32_t s0 = ui.foot_sig;
        TSEL->step[3].time = TSEL->step[3].time == ST_REST ? ST_NOTE : ST_REST;   /* (a step changed) */
        ui.force = 0;
        draw_foot();
        expect("  AMP ENV: a changed step does not redraw the footer (its signature has no steps there)", ui.foot_sig == s0);
        go_title("STEP");
        frame();
        s0 = ui.foot_sig;
        TSEL->step[3].time = TSEL->step[3].time == ST_REST ? ST_NOTE : ST_REST;
        ui.force = 0;
        draw_foot();
        expect("  STEP (item 118: the roll shows its steps itself, the footer is the shared one): a changed step does not redraw the footer", ui.foot_sig == s0);
        go_page(GR_EVENTS);
        frame();
        s0 = ui.foot_sig;
        TSEL->step[3].time = TSEL->step[3].time == ST_REST ? ST_NOTE : ST_REST;
        ui.force = 0;
        draw_foot();
        expect("  PARAMETER LOCKS (a SEQ page with the step strip): a changed step redraws it", ui.foot_sig != s0);
    }
}

/* 0.2.11: REC as HOLD acts on every part the keys play. M01-like LAYER: part 1 arp UP, part 2 arp off; DUEL (SPLIT): the selected part only */
static uint32_t sr_gated(const track_t *t)
{
    uint32_t i, n = 0;
    for (i = 0; i < NVOICE_PLAY; i++)
        n += t->v[i].gate != 0;
    return n;
}
static void sr_keys(uint32_t mask)
{
    fm1_in.notes = mask;
    keyboard_block();
}
static void sweep_rec_hold_layer(void)
{
    uint32_t i;
    ui_power_on();
    song.rec = 0;
    go_title("AMP ENV");
    duell_mode_force(DM_LAYER); ui_mode_set = ui.mode_seen = DM_LAYER;
    trk[0].p[P_AMODE] = AM_UP; trk[1].p[P_AMODE] = AM_OFF;
    trk[0].p[P_AHOLD] = trk[1].p[P_AHOLD] = 0;
    song.sel = 0;
    press(B_REC);
    frames(600);
    expect("LAYER, REC: HOLD ARP on part 1 (arp on) and HOLD ALL on part 2 (arp off), one message", trk[0].p[P_AHOLD] == 1 && trk[1].p[P_AHOLD] == 2 && msg_is("HOLD ON") && song.rec == 0u && hold_any());
    kb_prev = 0;
    sr_keys((1u << 0) | (1u << 4) | (1u << 7));
    sr_keys(0);
    for (i = 0; i < 4; i++)
        events_block(CTL);
    expect("  .. chord down and up: part 2 still sounds all 3 notes, part 1 holds it for its arp", sr_gated(&trk[1]) == 3 && trk[1].nheld == 3 && trk[0].nheld == 3);
    arp_tick(&trk[0], div_samples((uint32_t)trk[0].p[P_ARATE]));
    expect("  .. part 1 arpeggiates the latched chord", trk[0].arp_note != 0u && sr_gated(&trk[0]) >= 1u);
    press(B_REC);
    frames(600);
    for (i = 0; i < 4; i++)
        events_block(CTL);
    expect("  .. REC again: HOLD OFF, both parts release", trk[0].p[P_AHOLD] == 0 && trk[1].p[P_AHOLD] == 0 && msg_is("HOLD OFF") && !hold_any() && trk[0].nheld == 0 && trk[1].nheld == 0 && sr_gated(&trk[1]) == 0);
    trk[1].p[P_AHOLD] = 2;                              /* mixed: any on -> all off (not inverted) */
    press(B_REC);
    frames(600);
    expect("  .. one part on, one off: REC turns both OFF", trk[0].p[P_AHOLD] == 0 && trk[1].p[P_AHOLD] == 0 && msg_is("HOLD OFF"));
    duell_mode_force(DM_SPLIT); ui_mode_set = ui.mode_seen = DM_SPLIT;
    press(B_REC);
    frames(600);
    expect("DUEL: REC acts on the selected part only", trk[0].p[P_AHOLD] == 1 && trk[1].p[P_AHOLD] == 0);
    press(B_REC);
    frames(600);
    song.sel = 1;
    press(B_REC);
    frames(600);
    expect("  .. part 2 selected: part 2 only (arp off: ALL)", trk[1].p[P_AHOLD] == 2 && trk[0].p[P_AHOLD] == 0);
    press(B_REC);
    frames(600);
    song.sel = 0;
}

/* 0.2.9: REC is the HOLD switch on every page but the sequencer's (arp on: OFF <-> ARP; arp off: OFF <-> ALL); on SEQ's pages (STEP, AUTOMATION) it records as ever */
static void sweep_rec_hold(void)
{
    ui_power_on();
    song.rec = 0;
    go_title("AMP ENV");
    TSEL->p[P_AMODE] = AM_OFF;
    TSEL->p[P_AHOLD] = 0;
    press(B_REC);
    frames(600);
    expect("REC, arp off, an ordinary page: HOLD switch OFF -> ALL, nothing armed", rec_is_hold() && TSEL->p[P_AHOLD] == 2 && msg_is("HOLD ON") && song.rec == 0u);
    press(B_REC);
    frames(600);
    expect("  .. ALL -> OFF", TSEL->p[P_AHOLD] == 0 && msg_is("HOLD OFF"));
    song.rec = 1u << song.sel;
    press(B_REC);
    frames(600);
    expect("  .. an armed recording stays armed while REC switches HOLD", song.rec == (1u << song.sel) && TSEL->p[P_AHOLD] == 2);
    press(B_REC);
    frames(600);
    song.rec = 0; song.playing = 0; transport_req = 0;
    TSEL->p[P_AHOLD] = 0;
    TSEL->p[P_AMODE] = AM_UP;
    press(B_REC);
    frames(600);
    expect("REC, arp on: HOLD ARP, the message says it, no recording armed", TSEL->p[P_AHOLD] == 1 && msg_is("HOLD ON") && song.rec == 0u && rec_is_hold());
    press(B_REC);
    frames(600);
    expect("  .. again: HOLD OFF", TSEL->p[P_AHOLD] == 0 && msg_is("HOLD OFF"));
    TSEL->p[P_AHOLD] = 2;
    press(B_REC);
    frames(600);
    expect("  .. HOLD ALL with the arp on: off", TSEL->p[P_AHOLD] == 0);
    go_title("STEP");
    press(B_REC);
    frames(600);
    expect("  .. the sequencer's page (STEP), arp on: REC records, HOLD untouched", song.rec != 0u && TSEL->p[P_AHOLD] == 0 && !rec_is_hold());
    press(B_REC);
    frames(600);
    song.rec = 0; song.playing = 0; transport_req = 0;
    TSEL->p[P_AMODE] = AM_OFF;
    ui.perf = 1;
    expect("PERFORM, arp off: REC is the HOLD switch", rec_is_hold());
    TSEL->p[P_AHOLD] = 0;
    press(B_REC);
    frames(600);
    expect("  .. OFF -> ALL", TSEL->p[P_AHOLD] == 2 && msg_is("HOLD ON") && song.rec == 0u);
    press(B_REC);
    frames(600);
    expect("  .. ALL -> OFF", TSEL->p[P_AHOLD] == 0 && msg_is("HOLD OFF"));
    ui.perf = 0;
    {   /* 0.2.9: in PERFORM SELECT is BALANCE (no page to turn to), PRESETS the sound; item 160: BALANCE moves LEVEL 1 against LEVEL 2, never above 0 dB, tests/perf_level_test.c */
        int16_t l0 = trk[0].p[P_LEVEL], l1 = trk[1].p[P_LEVEL];
        uint8_t pg = ui.page;
        ui.perf = 1;
        trk[0].p[P_LEVEL] = 112, trk[1].p[P_LEVEL] = 112;
        turn(EN_SELECT, 3);
        /* 1.3 (2026-11-13): the numbers were the old half-a-dB-a-step balance. BALANCE is a position (item 160): 3 detents of 32 toward part 2 scale part 1's
         * gain to 29/32 of 0 dB = 3712 Q12, whose nearest level index is 110 (-1.0 dB). Part 2 is already at 0 dB and cannot be raised */
        expect("PERFORM: SELECT turns BALANCE (3 right: LEVEL 1 -1.0 dB, LEVEL 2 stays 0 dB: capped), the page stays", trk[0].p[P_LEVEL] == 110 && trk[1].p[P_LEVEL] == 112 && ui.page == pg && ui.perf);
        ui.perf = 0;
        trk[0].p[P_LEVEL] = l0, trk[1].p[P_LEVEL] = l1;
    }
    ui_power_on();
    {   /* VOICE 2/2 (0.2.19): the glide, SPREAD (step-lockable) and the sound's TRIM last (a patch setting: no step lock); PAN (a mixer setting) and MUTE are on no VOICE page */
        uint32_t p, vp = 0, mute = 0, ok = 0;
        for (p = 0; p < NPAGES; p++) {
            vp += str_eq(PAGES[p].title, "VOICE 2/2");
            mute += PAGES[p].fam == FAM_EDIT && (PAGES[p].id[0] == P_MUTE || PAGES[p].id[1] == P_MUTE || PAGES[p].id[2] == P_MUTE || PAGES[p].id[3] == P_MUTE);
            if (str_eq(PAGES[p].title, "VOICE 2/2")) {
                go_title("VOICE 2/2");
                ok = PAGES[p].id[3] == P_TRIM && mod_lock_ok(TSEL, P_TRIM);   /* (the matrix offers PATCH LEVEL: step-lockable. DUELL 1.0 B.8: the page-remembering hold-a-step gesture, lock_page_ok / ui.plk_src, is gone; lock_id is HOME's knobs now) */
            }
        }
        for (p = 0; p < NPAGES; p++)
            mute += PAGES[p].fam == FAM_EDIT && (PAGES[p].id[0] == P_PAN || PAGES[p].id[1] == P_PAN || PAGES[p].id[2] == P_PAN || PAGES[p].id[3] == P_PAN);
        expect("VOICE: two pages, TRIM on VOICE 2/2 K4 (step-lockable: the matrix offers PATCH LEVEL), SPRD not step-lockable (no matrix destination), PAN and MUTE on no EDIT page", vp == 1u && mute == 0u && ok);
    }
}


/* DUELL 0.2.9, the QUICK EDIT layers (SPEC 1.2 "Quick edit layers"): EDIT, LFO, ENV, ARP held past HOLD open their layer over the page shown,
 * the selected part's four (ly_page); a tap opens the page as before (two quick taps: the next page, no lock, for LFO ENV ARP); the keys
 * play notes in all four (none is the layer's, a key is no combo; 0.2.11: QUICK FILTER has no INIT key and no engine actions); the knobs edit the ids
 * with motion; QUICK GLO (0.2.11, hold GLO: the GLO page's MUTE / LEVEL cards over any page, the keys play); in a quick layer the header lights the
 * selected part alone (GLO's and SCL's: both); every layer's header is "QUICK <PAGE>" with the bolt, in the accent, in M */
static int head_has(uint16_t c)                      /* a pixel of colour c in the header's rows */
{
    uint32_t k;
    uint16_t w = (uint16_t)((c >> 8) | (c << 8));
    for (k = 0; k < 240u * 24u; k++)
        if (host_screen[k] == w)
            return 1;
    return 0;
}
static void sweep_quick(void)
{
    static const uint8_t QB[4] = {B_EDIT, B_LFO, B_ENV, B_ARP}, QL[4] = {LAYER_EDIT, LAYER_LFO, LAYER_ENV, LAYER_ARP};
    static const uint8_t QF[4] = {FAM_EDIT, FAM_LFO, FAM_ENV, FAM_ARP};
    static const char *const QH[4] = {"QUICK MULTI", "QUICK LFO", "QUICK ENV", "QUICK ARP"};
    static const uint16_t QID[4][4] = {{P_FREEA, P_FREEB, P_FREEC, P_REL}, {P_LRATE, P_LD_FLT, P_L2RATE, XW_BASE + X_LFO2},   /* (DUELL 1.1: QUICK LFO K4 is LFO 2's TWIN CUTOFF depth) */
                                      {P_ATK, P_REL, P_E2FLT, P_E2DEC}, {P_AMODE, P_ARATE, P_AGATE, P_AOCT}};
    uint32_t q, k, l;
    char w[96];
    for (q = 0; q < 4u; q++) {
        const page_t *qp;
        uint32_t pg, first;
        ui_power_on();
        set_engine_of(TSEL, 2u);                         /* PHASE: the multimode filter (ufilt) */
        TSEL->p[P_TWTYPE] = 0;                           /* (0.2.31: the power-on sound runs filter 2, QUICK MULTI then shows its cutoff on K3; this test wants the one-filter mapping) */
        go_title("MIXER");
        pg = ui.page;
        /* a tap: the family's page, as before; the second tap soon after: its next page (no lock) */
        press(QB[q]);
        first = ui.page;
        snprintf(w, sizeof w, "%s tap: its page when let go, no layer", QH[q]);
        expect(w, cur_page()->fam == QF[q] && !ui.layer && !ui.lock);
        if (q) {
            frames(96);                                  /* (within the 300 ms of a double tap) */
            press(QB[q]);
            snprintf(w, sizeof w, "  %s: a second quick tap, the next page as before (no lock)", QH[q]);
            expect(w, ui.page != first && cur_page()->fam == QF[q] && !ui.lock && !ui.layer);
        }
        settle(); frames(400);
        /* held past HOLD: the layer over the page, the page stays */
        go_title("MIXER");
        btn_down(QB[q]);
        frames(240);
        expect("  held 0.24 s: no layer yet", !ui.layer);
        frames(400);
        snprintf(w, sizeof w, "  %s held past HOLD: its layer, the page under it unchanged", QH[q]);
        expect(w, ui.layer == QL[q] && ui.page == pg);
        snprintf(w, sizeof w, "  header \"%s\"", QH[q]);
        expect(w, str_eq(layer_head(), QH[q]));
        frame();
        expect("  .. drawn in the text colour, not the accent (item 119: a title is never coloured, a quick layer's label too)", head_has(vt(T_TEXT, T_BG)) && !head_has(vt(T_ACCENT, T_BG)));
        qp = ly_page(QL[q]);
        for (k = 0; k < 4u; k++) {
            snprintf(w, sizeof w, "  %s KNOB %u: id %u", QH[q], k + 1u, QID[q][k]);
            expect(w, qp->id[k] == QID[q][k]);
        }
        btn_up(QB[q]); frames(64);
        expect("  let go: no page, no layer", !ui.layer && ui.page == pg);
        settle(); frames(400);
        /* a knob with the button held: the layer at once (a combo), the id edited and recorded as a knob move; let go: no tap */
        {
            uint32_t id = QID[q][1], mc;
            int16_t v0;
            go_title("MIXER");
            song.rec = 1u << song.sel; song.playing = 1;
            mc = motion_count(TSEL);
            v0 = TSEL->p[id];
            btn_down(QB[q]); frame();
            turn(EN_K2, -3);
            turn(EN_K2, 5);
            snprintf(w, sizeof w, "  %s + KNOB 2: the layer at once, its id turned (and recorded)", QH[q]);
            expect(w, ui.layer == QL[q] && TSEL->p[id] != v0 && (!motion_param(id) || motion_count(TSEL) > mc));
            btn_up(QB[q]); frames(64);
            expect("  .. let go: no page (a combo)", ui.page == pg);
            song.rec = 0; song.playing = 0; transport_req = 0;
            settle(); frames(400);
        }
        /* the keys: notes in all four (no combo: a quick tap is still a tap) */
        {
            ui_power_on();
            usb.config = 1;
            go_title("MIXER");
            btn_down(QB[q]); key_down(white(3));
            frame();
            snprintf(w, sizeof w, "  %s held + a key: the note plays, the key is not the layer's", QH[q]);
            expect(w, gates() > 0 && !((kb_layer >> white(3)) & 1u) && !ui.layer);
            frames(400);
            expect("  .. held on: the layer opens over the note", ui.layer == QL[q] && gates() > 0 && !(key_leds(0) == 0u));
            key_up(white(3)); btn_up(QB[q]); frames(64);
            settle(); frames(400);
            btn_down(QB[q]); key_down(white(5)); frame(); key_up(white(5)); frame(); btn_up(QB[q]); frame();
            snprintf(w, sizeof w, "  %s + a quick key, let go soon: still a tap (its page)", QH[q]);
            expect(w, cur_page()->fam == QF[q]);
            usb.config = 0;
        }
    }
    /* QUICK FILTER: F3 plays, it does not INIT (0.2.11, owner: playing an F erased the sound), and no black key does an engine action */
    ui_power_on();
    usb.config = 1;
    go_title("MIXER");
    {
        int16_t e0 = TSEL->p[P_E0];
        uint32_t kk, ok = 1;
        btn_down(B_EDIT);
        for (kk = 0; kk < 27u; kk++) {
            key_down(kk); frame();
            ok &= gates() > 0 && !ui.confirm && !((kb_layer >> kk) & 1u);
            key_up(kk); frame(); frames(8);
        }
        btn_up(B_EDIT); frames(64);
        expect("QUICK FILTER (EDIT held): all 27 keys play notes, none opens INIT's dialog or is the layer's", ok && TSEL->p[P_E0] == e0);
    }
    /* QUICK GLO (0.2.11): hold GLO over the PERFORM page, the page stays under it and comes back; a tap is GLO's page as before */
    ui_power_on();
    usb.config = 1;
    perf_enter(); frames(48);
    {
        uint8_t pg = ui.page, pm = ui.perf;
        int16_t l0 = trk[0].p[P_LEVEL], l1 = trk[1].p[P_LEVEL];
        btn_down(B_GLO); frames(240);
        expect("QUICK GLO: held 0.24 s, no layer yet", !ui.layer);
        frames(400);
        expect("QUICK GLO: held past HOLD, the layer over PERFORM", ui.layer == LAYER_GLO && ui.perf && ui.page == pg);
        expect("  .. header \"QUICK GLO\"", str_eq(layer_head(), "QUICK GLO"));
        frame();
        expect("  .. drawn in the text colour, not the accent (item 119: a title is never coloured, a quick layer's label too)", head_has(vt(T_TEXT, T_BG)) && !head_has(vt(T_ACCENT, T_BG)));
        expect("  .. the header lights both parts (K1 K3 part 1, K2 K4 part 2)", badge_lit() == 3u);
        turn(EN_K1, 5); turn(EN_K2, -5);
        expect("  .. K1 LEVEL 1, K2 LEVEL 2 (item 117 order)", trk[0].p[P_LEVEL] != l0 && trk[1].p[P_LEVEL] != l1);
        btn_down(B_OCTDN); frame(); btn_up(B_OCTDN); frame();
        expect("  .. OCT- with GLO held: MUTE 1 (0.2.24)", trk[0].p[P_MUTE] == 1);
        frames(600);
        btn_down(B_OCTDN); frame(); btn_up(B_OCTDN); frame();
        expect("  .. OCT- again unmutes", trk[0].p[P_MUTE] == 0);
        key_down(white(3)); frame();
        expect("  .. the keys are not the layer's", !((kb_layer >> white(3)) & 1u) && ui.layer == LAYER_GLO);
        key_up(white(3)); frame();
        btn_up(B_GLO); frames(64);
        expect("  .. let go: closed, PERFORM and its page back, no GLO page", !ui.layer && ui.perf == pm && ui.page == pg &&
               cur_page()->graph != GR_GLO);
        settle(); frames(400);
    }
    perf_leave(); frames(48);
    usb.config = 0;
    ui_power_on();
    go_title("AMP ENV");
    press(B_GLO);
    expect("GLO tap: GLO's first page, MIXER (0.2.25 layout round)", cur_page()->graph == GR_GLO && str_eq(cur_page()->title, "MIXER") && !ui.layer);
    press(B_GLO);
    expect("  .. a second tap: the next GLO page, TEMPO", str_eq(cur_page()->title, "TEMPO") && cur_page()->fam == FAM_GLO);
    /* the header in a quick layer: the selected part alone, even with ALGORITHM at BOTH on PERFORM / MORPH */
    ui_power_on();
    morph.target = MT_BOTH; song.sel = 1;
    perf_enter(); frames(48);
    expect("PERFORM, ALGORITHM BOTH: both badges", badge_lit() == 3u);
    for (q = 0; q < 4u; q++) {
        btn_down(QB[q]); frames(640);
        snprintf(w, sizeof w, "  %s open over PERFORM (BOTH): the badge of the selected part alone", QH[q]);
        expect(w, ui.layer == QL[q] && badge_lit() == 2u);
        btn_up(QB[q]); frames(64); settle(); frames(400);
    }
    btn_down(B_GLO); frames(640);
    expect("  QUICK GLO over PERFORM (BOTH): both badges (its cards are per part)", ui.layer == LAYER_GLO && badge_lit() == 3u);
    btn_up(B_GLO); frames(64);
    perf_leave(); frames(48);
    morph.target = MT_SELECTED; song.sel = 0;
    /* OCT- in QUICK FILTER puts its four back; in QUICK LFO it is the octave */
    ui_power_on();
    set_engine_of(TSEL, 2u);
    go_title("MIXER");
    {
        int16_t c0 = TSEL->p[P_FREEA];
        btn_down(B_EDIT); frames(640);
        turn(EN_K1, -4);
        k = TSEL->p[P_FREEA] != c0;
        press(B_OCTDN);
        expect("QUICK FILTER: OCT- puts CUT back, no octave", k && TSEL->p[P_FREEA] == c0 && song.octave == 0 && msg_is("VALUES PUT BACK"));
        btn_up(B_EDIT); frames(64);
    }
    settle(); frames(400);
    btn_down(B_LFO); frames(640);
    press(B_OCTUP);
    expect("QUICK LFO: OCT+ is the octave (no put back)", ui.layer == LAYER_LFO && song.octave != 0);
    btn_up(B_LFO); frames(64);
    song.octave = 0;
    /* 0.2.14 (owner): QUICK FILTER is the MULTIMODE filter's CUT RES MODE and REL on every engine that can be picked (ANALOG TRIO NOISE
     * too: their own filters stay on their EDIT pages); a synced LFO's SYNC card */
    ui_power_on();
    TSEL->p[P_TWTYPE] = 0;                               /* (0.2.31: see above) */
    {
        uint32_t ok = 1, n = 0;
        for (k = 0; k < NENGINES; k++) {
            const page_t *qp;
            if (!eng_ok(k))
                continue;
            set_engine_of(TSEL, k);
            qp = ly_page(LAYER_EDIT);
            n++;
            ok &= qp->id[0] == P_FREEA && qp->id[1] == P_FREEB && qp->id[2] == P_FREEC && qp->id[3] == P_REL && ENGINES[k]->ufilt;
        }
        expect("QUICK FILTER: CUT RES MODE (ids 45..47) + REL on all ten engines, one mapping", ok && n == 10u);
        set_engine_of(TSEL, 0u);                         /* ANALOG: K3 is the multimode MODE (ANALOG's own TYPE switch is retired: id 101 is the TWIN FILTER's BLEND, which stays) */
        {
            int16_t ft = TSEL->p[P_BLEND], m0 = TSEL->p[P_FREEC];
            go_title("MIXER");
            btn_down(B_EDIT); frames(640);
            turn(EN_K3, 6);
            btn_up(B_EDIT); frames(64);
            expect("  ANALOG: QUICK FILTER K3 turns the multimode MODE, not the TWIN FILTER's BLEND (id 101, once the VCF's TYPE)", TSEL->p[P_FREEC] != m0 && TSEL->p[P_BLEND] == ft);
            settle(); frames(400);
        }
    }
    TSEL->p[P_LSYNC] = 5;
    expect("QUICK LFO: LFO 1 synced, KNOB 1 is its SYNC; LFO 2 free, KNOB 3 RATE2", ly_page(LAYER_LFO)->id[0] == P_LSYNC &&
           ly_page(LAYER_LFO)->id[2] == P_L2RATE);
    TSEL->p[P_LSYNC] = 0; TSEL->p[P_L2SYNC] = 3;
    expect("  LFO 2 synced: KNOB 3 its SYNC2, KNOB 1 RATE", ly_page(LAYER_LFO)->id[0] == P_LRATE && ly_page(LAYER_LFO)->id[2] == P_L2SYNC);
    /* every quick layer's header fits in M with the bolt (and the lock) */
    for (l = LAYER_SCL; l < LAYER_N; l++) {
        int32_t b[4];
        icon_ink(12, ICON_X_QUICK, b);
        snprintf(w, sizeof w, "header \"%s\": QUICK, fits in M with the bolt and the lock", LAYERS[l].head);
        expect(w, !strncmp(LAYERS[l].head, "QUICK ", 6) && text_w(&AF_M, LAYERS[l].head) + b[2] - b[0] + KH_GAP + 15 <= HEAD_MSG_W);
    }
}

/* 0.2.25 layout round (owner): the MIXER is GLO's first page (graph GR_GLO, drawn as the hold-GLO layer, the same layout): both parts' cells side by side, the word always MUTE,
 * a muted part's cell lit in its colour, a sounding one dark (RAISE); the cards K1 LEVEL 1, K2 LEVEL 2, K3 PAN 1, K4 PAN 2 (item 117, TEMPLATE 4: round MUTE cards on the card colour, the meter at their right); a GLOBAL page: ALGORITHM moves no part; nothing is drawn
 * again while nothing changes (the panel's signature, the meters' own strip) */
static uint16_t mx_px(int32_t x, int32_t y) { return swap16(host_screen[(uint32_t)y * 240u + (uint32_t)x]); }
static void sweep_mixer(void)
{
    uint32_t k, ok = 1;
    int16_t l0, l1;
    ui_power_on();
    trk[0].peak = trk[1].peak = 0;
    trk[0].p[P_MUTE] = 0; trk[1].p[P_MUTE] = 1;
    ui_mode_set = DM_STEREO; duell_mode_req = DM_STEREO;
    go_title("MIXER");
    frames(48);
    expect("MIXER: GLO's first page (graph GR_GLO, scope SC_GMIX), cards LEVEL 1, LEVEL 2, PAN 1, PAN 2", cur_page()->graph == GR_GLO && cur_page()->scope == SC_GMIX &&
           ui.page == page_first(FAM_GLO) && card_is(0, "LEVEL 1|") && card_is(1, "LEVEL 2|") && card_is(2, "PAN 1|") && card_is(3, "PAN 2|") && badge_lit() == 3u);
    for (k = 0; k < 2u; k++) {                           /* the cell's fill: part 2 muted, lit in its colour; part 1 sounding, dark (RAISE) */
        int32_t x = UT_T4_X0 + UT_T4_DX * (int32_t)k + 90, y = UT_T4_MUTE_Y + 30;   /* (inside the card, clear of its texts, keycaps and meter) */
        ok &= mx_px(x, y) == (k ? T_PTHEME(1) : T_BG);
    }
    expect("MIXER: the MUTE cells: part 2's (muted) lit in its colour, part 1's (sounding) on the card colour", ok);
    l0 = trk[0].p[P_LEVEL]; l1 = trk[1].p[P_LEVEL];
    turn(EN_K1, -3); frame();
    expect("MIXER: K1 turns part 1's LEVEL only", trk[0].p[P_LEVEL] != l0 && trk[1].p[P_LEVEL] == l1);
    l0 = trk[0].p[P_LEVEL];
    turn(EN_K2, 2); frame();
    expect("MIXER: K2 turns part 2's LEVEL only", trk[1].p[P_LEVEL] != l1 && trk[0].p[P_LEVEL] == l0);
    turn(EN_ALGO, 1); frames(4);
    expect("MIXER: a GLOBAL page: ALGORITHM moves no part", song.sel == 0u && badge_lit() == 3u);
    frames(600);                                         /* (past the knob's accent) */
    trk[0].peak = trk[1].peak = 0;
    frames(80);                                          /* (the meters fall to rest) */
    host_blit_rows = 0;
    for (k = 0; k < 8u; k++) { trk[0].peak = trk[1].peak = 0; frame(); }
    expect("MIXER: nothing changes, nothing is drawn (8 frames, no blit)", host_blit_rows == 0u);
    trk[1].p[P_MUTE] = 0;
    host_blit_rows = 0; frame();
    expect("  .. part 2 unmuted: the MUTE cards are drawn again (TEMPLATE 4, UT_T4_MUTE_Y strip), its cell dark (the card colour, as part 1's)", host_blit_rows > 0u && mx_px(UT_T4_X0 + UT_T4_DX + 90, UT_T4_MUTE_Y + 30) == T_BG);
}

/* ALGORITHM (0.2.9, owner 2026-10-14): on the MORPH page (HOME 1/5) PART 1, BOTH, PART 2 from left to right, clamped, BOTH the
 * morph's target (both badges); on every other page PART 1 / PART 2 only, BOTH never set there and kept for MORPH / PERFORM, the
 * badge the selected part's alone (both only on a GLOBAL page); OVERVIEW too */
static void sweep_algo(void)
{
    uint32_t i, ok = 1, ok2 = 1, mp = NPAGES;
    for (i = 0; i < NPAGES; i++) {
        if (!page_visible(i) || PAGES[i].graph == GR_PERF || PAGES[i].scope == SC_MACRO)   /* (DUELL 1.3: the MACROS pages act on ALGORITHM's part(s), BOTH too, as PERFORM: ui_draw.c badge) */
            continue;
        if (PAGES[i].graph == GR_MORPH) {
            mp = i;
            continue;
        }
        morph.target = MT_SELECTED;
        song.sel = 0;
        enter(i);
        if (page_global(&PAGES[i]) || PAGES[i].scope == SC_MODE) {   /* 0.2.24 (owner): a GLOBAL page edits no part: ALGORITHM does nothing there (no part switch, no colour switch); the MODE page counts as global (ui_draw.c screen_global, badge_lit; ui_input.c algo_input; items 128, 138) */
            turn(EN_ALGO, 1); turn(EN_ALGO, -1); turn(EN_ALGO, 1);
            ok &= song.sel == 0u && morph.target == MT_SELECTED && badge_lit() == 3u && ux.glob == 1u;
            morph.target = MT_BOTH;
            turn(EN_ALGO, 1);
            frame();
            ok2 &= song.sel == 0u && morph.target == MT_BOTH && badge_lit() == 3u;
            if (!ok || !ok2) {
                printf("select: ALGORITHM on page %u (%s)\n", (unsigned)i, PAGES[i].title);
                break;
            }
            continue;
        }
        turn(EN_ALGO, 1); turn(EN_ALGO, 1);
        ok &= song.sel == 1u && morph.target == MT_SELECTED && ux.glob == 0u;
        turn(EN_ALGO, -1);
        ok &= song.sel == 0u && morph.target == MT_SELECTED;
        morph.target = MT_BOTH;                         /* (BOTH left on the MORPH page) */
        turn(EN_ALGO, 1);
        frame();
        ok2 &= song.sel == 1u && morph.target == MT_BOTH && badge_lit() == 2u;
        turn(EN_ALGO, -1);
        ok2 &= song.sel == 0u && morph.target == MT_BOTH;
        if (!ok || !ok2) {
            printf("select: ALGORITHM on page %u (%s)\n", (unsigned)i, PAGES[i].title);
            break;
        }
    }
    expect("ALGORITHM on every part page but MORPH: PART 1 / PART 2 only, clamped, never BOTH; on a GLOBAL page nothing (0.2.24: the global colour, both badges)", ok);
    expect("  .. BOTH (set on MORPH) kept, the page's badge the selected part's alone (a GLOBAL page: both)", ok2);
    morph.target = MT_SELECTED;
    song.sel = 0;
    enter(mp);
    ok = mp < NPAGES && badge_lit() == 1u;
    turn(EN_ALGO, -1);
    ok &= song.sel == 0u && morph.target == MT_SELECTED;
    turn(EN_ALGO, 1);
    ok &= song.sel == 0u && morph.target == MT_BOTH && badge_lit() == 3u;
    turn(EN_ALGO, 1);
    ok &= song.sel == 1u && morph.target == MT_SELECTED && badge_lit() == 2u;
    turn(EN_ALGO, 1);
    ok &= song.sel == 1u && morph.target == MT_SELECTED;
    turn(EN_ALGO, -1);
    ok &= song.sel == 1u && morph.target == MT_BOTH && badge_lit() == 3u;
    expect("MORPH page: ALGORITHM PART 1 | BOTH | PART 2, clamped; BOTH keeps the selected part, both badges", ok);
    morph.target = MT_SELECTED;
    song.sel = 0;
    frames(48);
}

/* DUELL 0.2.10: PLAY's two LEDs (stopped: green; playing or counting in: red) and REC's (outside the sequencer: HOLD, lit when on, the idle level
 * when off; on the sequencer's pages: armed). The armed mark is in the footer on every page; the header has none */
static void sweep_leds_play_rec(void)
{
    uint8_t qp, qr;
    ui_power_on();
    settings_leds = LEDS_DIM;
    ui_leds();
    memset(led_pos, 0xFF, sizeof led_pos);              /* (the host's stub key map has none: PLAY and REC in column 0) */
    led_pos[panel.btn[B_PLAY]] = 0u << 3 | 3u; led_pos[panel.btn[B_REC]] = 0u << 3 | 4u;
    song.rec = 0; song.playing = 0;
    go_title("AMP ENV");
    TSEL->p[P_AMODE] = AM_OFF; TSEL->p[P_AHOLD] = 0;
    ui_leds();
    qp = led_pos[panel.btn[B_PLAY]]; qr = led_pos[panel.btn[B_REC]];
    expect("PLAY stopped: green lit, its red LED not", (fm1_led[LED_PLAY_GREEN >> 3] >> (LED_PLAY_GREEN & 7u) & 1u) && !(fm1_led[qp >> 3] >> (qp & 7u) & 1u));
    expect("REC outside the sequencer, HOLD off: not lit", !(fm1_led[qr >> 3] >> (qr & 7u) & 1u));
    TSEL->p[P_AHOLD] = 2;
    ui_leds();
    expect("  .. HOLD on: lit (the idle level when off is 1 frame in 4)", fm1_led[qr >> 3] >> (qr & 7u) & 1u);
    song.rec = 1u << song.sel;
    TSEL->p[P_AHOLD] = 0;
    ui_leds();
    expect("  .. armed recording is not shown on REC's LED here (HOLD is)", !(fm1_led[qr >> 3] >> (qr & 7u) & 1u));
    song.playing = 1;
    ui_leds();
    expect("PLAY running: red lit, green dark", !(fm1_led[LED_PLAY_GREEN >> 3] >> (LED_PLAY_GREEN & 7u) & 1u) && (fm1_led[qp >> 3] >> (qp & 7u) & 1u));
    song.playing = 0; song.rec = 0;
    open_family(FAM_SEQ);
    song.rec = 1u << song.sel;
    ui_leds();
    expect("STEP / AUTOMATION: REC's LED shows the armed recording (lit)", !rec_is_hold() && (fm1_led[qr >> 3] >> (qr & 7u) & 1u));
    song.rec = 0;
    ui_power_on();
}

/* 0.2.18, the page-order audit (docs/PAGE_ORDER_AUDIT.md), the UI-only reorders: top-down (a mode or type first, an amount next, a level or mix last). The stored ids never move */
static const page_t *pg_titled(const char *t)
{
    uint32_t i;
    for (i = 0; i < NPAGES; i++)
        if (str_eq(PAGES[i].title, t))
            return &PAGES[i];
    return &PAGES[0];
}
static void test_page_order(void)
{
    const page_t *a1 = pg_titled("ARP 1/3"), *a2 = pg_titled("ARP 2/3"), *a3 = pg_titled("ARP 3/3"), *v1 = pg_titled("VOICE 1/2"), *v2 = pg_titled("VOICE 2/2");
    const page_t *d2 = pg_titled("DUCK 2/2"), *mf = pg_titled("MULTI FILTER 1/2"), *mf2 = pg_titled("MULTI FILTER 2/2");
    uint32_t k, ok = 1;
    expect("ARP: 1/3 MODE HOLD ORD OCT, 2/3 RATE GATE SWG PROB, 3/3 TRGT",
           a1->id[0] == P_AMODE && a1->id[1] == P_AHOLD && a1->id[2] == P_AORDER && a1->id[3] == P_AOCT &&
           a2->id[0] == P_ARATE && a2->id[1] == P_AGATE && a2->id[2] == P_ASWING && a2->id[3] == P_APROB && a3->id[0] == P_ATGT);
    expect("VOICE: 1/2 MODE PRIORITY DETUNE TRANSPOSE (T0227: no ALLOCATION; DUELL 1.1: TRANSPOSE is the patch's), 2/2 GLIDE MODE, GLIDE, SPREAD, PATCH LEVEL",
           v1->id[0] == P_VOICE && v1->id[1] == P_PRIO && v1->id[2] == P_DETUNE && v1->id[3] == P_TRANS &&
           v2->id[0] == P_GLMODE && v2->id[1] == P_GLIDE && v2->id[2] == P_SPRD && v2->id[3] == P_TRIM);
    expect("CHORD: CHRD VOIC STRUM, K4 none (DUELL 1.1: TRANSPOSE moved to VOICE 1/2, the KEY OFFSET is gone; item 144: K3 STRUM, ext slot X27)", pg_titled("CHORD")->id[0] == P_CHRD && pg_titled("CHORD")->id[1] == P_VOIC &&
           pg_titled("CHORD")->id[2] == XW_BASE + X_STRUM && pg_titled("CHORD")->id[3] == 0xFFu);
    expect("DUCK 2/2: CURVE ATK RLS", d2->id[0] == P_DKCRV && d2->id[1] == P_DKATK && d2->id[2] == P_DKRLS);
    expect("MULTI FILTER 1/2: CUT RES MODE SLOPE", mf->id[0] == P_FREEA && mf->id[1] == P_FREEB && mf->id[2] == P_FREEC && mf->id[3] == P_FREED);
    expect("MULTI FILTER 2/2 (0.2.22; DUELL 1.1): KTRK, ENV 2, LFO 1, no K4 (the LFO 2 cutoff depth no longer acts; the DEST pages' P_E2FLT, P_LD_FLT: one stored value each, shown on both; no AMP ENV card)",
           mf2 != &PAGES[0] && mf2 == mf + 1 && mf2->id[0] == P_KTRK && mf2->id[1] == P_E2FLT && mf2->id[2] == P_LD_FLT && mf2->id[3] == 0xFFu);
    /* every id of a reordered page is still on exactly that page set (nothing lost or doubled) */
    {
        static const uint8_t ARPIDS[9] = {P_AMODE, P_AHOLD, P_AORDER, P_AOCT, P_ARATE, P_AGATE, P_ASWING, P_APROB, P_ATGT};
        uint32_t n[9] = {0}, i, c;
        for (i = 0; i < NPAGES; i++)
            if (PAGES[i].fam == FAM_ARP)
                for (c = 0; c < 4u; c++)
                    for (k = 0; k < 9u; k++)
                        n[k] += PAGES[i].id[c] == ARPIDS[k];
        for (k = 0; k < 9u; k++)
            ok &= n[k] == 1u;
        expect("ARP: each of the nine cards is on exactly one page", ok);
    }
    /* FM6: SLOT first (stored ids unchanged: the card shows P_E7, then ALG is P_E0 ...). T0227: the ENGINE page holds the first three after K1 ENGINE, EDIT 1 the next four, EDIT 2 the eighth */
    ui_power_on();
    set_engine_of(TSEL, ENGI_FM6);
    {
        const page_t *e0 = pg_titled("ENGINE"), *e1 = pg_titled("EDIT 1"), *e2 = pg_titled("EDIT 2");
        int16_t *vp;
        static const uint8_t WANT0[4] = {0xFF, 7, 0, 1}, WANT1[4] = {2, 3, 4, 5}, WANT2[4] = {6, 0xFF, 0xFF, 0xFF};
        ok = 1;
        for (k = 0; k < 4u; k++) {
            ok &= WANT0[k] == 0xFF ? !page_desc(e0, k, &vp) : page_desc(e0, k, &vp) && vp == &TSEL->p[P_E0 + WANT0[k]];
            ok &= page_desc(e1, k, &vp) && vp == &TSEL->p[P_E0 + WANT1[k]];
            ok &= WANT2[k] == 0xFF ? !page_desc(e2, k, &vp) : page_desc(e2, k, &vp) && vp == &TSEL->p[P_E0 + WANT2[k]];
        }
        expect("FM6 ENGINE: ENGINE SLOT ALG FB, EDIT 1: MLVL MRAT MEG VMOD, EDIT 2: DTUN (the cards move, the stored E slots do not)", ok && !strcmp(page_desc(e0, 1, &vp)->label, "SLOT") &&
               !strcmp(page_desc(e1, 0, &vp)->label, "MLVL"));
        set_engine_of(TSEL, 0u);
        ok = page_desc(e0, 1, &vp) && vp == &TSEL->p[P_E0] && page_desc(e1, 0, &vp) && vp == &TSEL->p[P_E3] && page_desc(e2, 0, &vp) && vp == &TSEL->p[P_E7];
        expect("every other engine: ENGINE E1..E3, EDIT 1 E4..E7, EDIT 2 E8 in the engine's own order", ok);
    }
}

/* DUELL 0.2.22: FX's pages are the part's own; its second page, SEND FX, shows the SELECTED part's three send levels (K1 CHORUS, K2 DELAY, K3 REVERB: the FX page's P_CHOR, P_DLY, P_REV) with the effect beside them
 * (the delay's mode and time, the reverb's type and size); a twist of K1 / K2 / K3 only jumps to GLO's CHORUS / DELAY 1/2 / REVERB. Part-scoped: only the selected part's badge */
#define SETMODE(m) do { duell_mode_force(m); ui_mode_set = ui.mode_seen = (m); } while (0)
static void test_fxsum(void)                           /* (owner 2026-11-15: the SEND FX page is removed; the FX page says where the global effects are edited) */
{
    static const char *const R[] = {"FX", "INSERT 1/2", "INSERT 2/2", "EQ 1/2", "EQ 2/2", "DUCK 1/2", "DUCK 2/2"};
    uint32_t i, n = 0, ok = 1, fx1 = page_first(FAM_FX), glob = 0, sum = 0;
    int16_t bpm0;
    for (i = 0; i < NPAGES; i++) {
        if (PAGES[i].fam == FAM_FX && n < 7u)
            ok &= (uint32_t)str_eq(PAGES[i].title, R[n]);
        n += PAGES[i].fam == FAM_FX;
        glob += PAGES[i].fam == FAM_FX && PAGES[i].scope == SC_GLOBAL;
        sum += PAGES[i].scope == SC_FXSUM;
    }
    expect("FX's pages: FX, INSERT 1/2, 2/2, EQ 1/2, 2/2, DUCK 1/2, 2/2 (7 in all, no SEND FX, none of the global effects' own)", n == 7u && ok && glob == 0u && sum == 0u);
    ui_power_on();
    SETMODE(DM_STEREO);
    bpm0 = song.g[G_BPM];
    enter(page_first(FAM_GLO) + 1u);                   /* the GLO family's pages keep both badges */
    frames(8);
    expect("GLO's CHORUS page: both badges (global scope)", badge_lit() == 3u);
    enter(fx1);                                        /* SELECT: round the FX family */
    turn(EN_SELECT, 1);
    frames(48);
    expect("SELECT right from FX: on to INSERT 1/2", ui.page == fx1 + 1u && song.g[G_BPM] == bpm0);
}

/* T0227 (owner): CONTROLS MOVE LEFT. A page with a hidden card in the middle: the cards that show take K1, K2, .. in the page's order, the columns after
 * them are empty, the knobs address the visible cards in order (and OCT- + a knob resets that card), the stored ids stay; MIDI LEARN picks the control */
static void test_move_left(void)
{
    int16_t sp, tr;
    int32_t g, mx;
    ui_power_on();
    init_engine_of(TSEL, 0u);                            /* (ANALOG) */
    TSEL->p[P_VOICE] = V_MONO;                           /* VOICE 2/2: GLIDE MODE, GLIDE, SPREAD (hidden: one voice), PATCH LEVEL */
    go_title("VOICE 2/2"); frames(48);
    expect("move left: VOICE 2/2 in MONO: GLIDE MODE, GLIDE, PATCH LEVEL on K1..K3, K4 empty", card_is(0, "GLIDE MODE|") && card_is(1, "GLIDE|") &&
           card_is(2, "PATCH\nLEVEL|") && str_eq(ui.col[3], "\x7f"));
    sp = TSEL->p[P_SPRD]; tr = TSEL->p[P_TRIM];
    turn(EN_K3, -3);
    expect("  .. K3 turns PATCH LEVEL (the third card that shows), SPREAD untouched", TSEL->p[P_TRIM] == tr - 3 && TSEL->p[P_SPRD] == sp);
    tr = TSEL->p[P_TRIM];
    turn(EN_K4, 5);
    expect("  .. K4 (no card) does nothing", TSEL->p[P_TRIM] == tr && TSEL->p[P_SPRD] == sp && TSEL->p[P_GLIDE] == 0);
    btn_down(B_OCTDN); frame(); turn(EN_K3, 1); btn_up(B_OCTDN); frames(400);
    expect("  .. OCT- + K3 resets PATCH LEVEL (said in full)", TSEL->p[P_TRIM] == TP[P_TRIM].def && TSEL->p[P_SPRD] == sp);
    ui.ml.on = 1; ui.ml.pick = 0;
    turn(EN_K3, 1);
    expect("  .. MIDI LEARN picks the control under K3 (PATCH LEVEL), not the knob's slot", ui.ml.pick && ui.ml.id == P_TRIM);
    ui.ml.on = 0; ui.ml.pick = 0;
    duell_mode_req = DM_STEREO;                          /* (SPREAD has no card in DUEL either) */
    TSEL->p[P_VOICE] = V_POLY; frames(48);
    expect("  .. POLY: SPREAD back on K3, PATCH LEVEL on K4 (nothing hidden: the page as it is)", card_is(2, "SPREAD|") && card_is(3, "PATCH\nLEVEL|"));
    /* DELAY 2/2 in RANDOM: SPREAD, MOD RATE (hidden: the event modes have no modulation), CHANCE, MIX -> SPREAD, CHANCE, MIX on K1..K3 */
    duell_mode_req = DM_STEREO;
    song.g[G_DMODE] = DMD_RAND;
    go_title("DELAY 2/2"); frames(48);
    expect("move left: DELAY 2/2 in RANDOM: SPREAD, CHANCE, MIX on K1..K3", card_is(0, "SPREAD|") && card_is(1, "CHANCE|") && card_is(2, "MIX|") && str_eq(ui.col[3], "\x7f"));
    g = song.g[G_DMDEP]; mx = song.g[G_DMIX];
    turn(EN_K2, 4);
    expect("  .. K2 is CHANCE (MOD RATE untouched)", song.g[G_DMDEP] == g + 4 && song.g[G_DMIX] == mx);
    turn(EN_K3, -4);
    expect("  .. K3 is MIX", song.g[G_DMIX] == mx - 4);
    song.g[G_DMODE] = DMD_DIGITAL;
    frames(48);
    expect("  .. DIGITAL: SPREAD hidden, MOD RATE back: MOD RATE, MOD DEPTH, MIX on K1..K3", card_is(0, "MOD RATE|") && card_is(1, "MOD DEPTH|") && card_is(2, "MIX|"));
    /* DUCK 2/2 with SOURCE OFF: all its cards hidden: item 158 (no empty pages): the page is not in the order; the page shown is another, the knobs leave CURVE alone */
    TSEL->p[P_DKSRC] = 3;
    go_title("DUCK 2/2"); frames(48);
    g = TSEL->p[P_DKCRV];
    turn(EN_K1, 1);
    expect("move left: DUCK 2/2 with SOURCE OFF: not in the page order (another page shown), CURVE untouched", page_visible(ui.page) && !str_eq(PAGES[ui.page].title, "DUCK 2/2") && TSEL->p[P_DKCRV] == g);
    TSEL->p[P_DKSRC] = 0;
}

/* 0.2.25 (owner: the hide rule applies to modulation; docs/MOD_INERT_TABLE.md): the SHAPE depth cards hide with a wave that has no shape input (they move left), and the
 * matrix's DEST knob passes the removed destinations and the ones the current wave leaves without effect; a stored route to one stays */
static void dst_walk(uint8_t *seen)
{
    int32_t i;
    memset(seen, 0, MD_N);
    duell_mode_req = DM_STEREO;                          /* (PAN is offered outside DUEL) */
    TSEL->p[P_M1DST] = 0;
    for (i = 0; i < 2 * MD_N; i++) {
        turn(EN_K3, 1);
        seen[clamp(TSEL->p[P_M1DST], 0, MD_N - 1)] = 1;
    }
    for (i = 0; i < 2 * MD_N; i++) {
        turn(EN_K3, -1);
        seen[clamp(TSEL->p[P_M1DST], 0, MD_N - 1)] = 1;
    }
}
static void test_mod_hide(void)
{
    uint8_t vis[4], seen[MD_N];
    uint32_t n, d, ok;
    ui_power_on();
    duell_mode_req = DM_STEREO;                          /* (PAN is offered outside DUEL) */
    init_engine_of(TSEL, 0u);                            /* (ANALOG) */
    TSEL->p[P_E0] = 0;                                   /* SAW: no shape input */
    go_title("LFO 1 DEST"); frames(48);
    n = page_cards(cur_page(), vis);
    expect("mod hide: ANALOG SAW: LFO 1 DEST shows PITCH, CUTOFF, AMP (SHAPE hidden, the cards moved left)", n == 3u && vis[0] == 0u && vis[1] == 1u && vis[2] == 3u);
    go_title("ENV 2 DEST"); frames(48);
    n = page_cards(cur_page(), vis);
    expect("mod hide: ANALOG SAW: ENV 2 DEST (twin filter off) shows MULTI CUTOFF and MULTI RES (FILTER BLEND and DRIVE hidden, the cards moved left: DUELL 1.1)", n == 2u && vis[0] == 0u && vis[1] == 3u);
    TSEL->p[P_E0] = 4;                                   /* PWM: the pulse width */
    go_title("LFO 1 DEST"); frames(48);
    n = page_cards(cur_page(), vis);
    expect("mod hide: ANALOG PWM: LFO 1 DEST shows all four (SHAPE is the width)", n == 4u);
    TSEL->p[P_E0] = 0;
    go_title("MATRIX 1-4"); frames(48);
    mod_ui_slot = 0;
    TSEL->p[P_M1SRC] = MS_LFO;
    TSEL->p[P_M1AMT] = 30;
    dst_walk(seen);
    for (d = 1, ok = 1; d < (uint32_t)MD_N; d++)
        ok &= !seen[d] || mod_dst_offered(TSEL, (int32_t)d);
    expect("mod hide: ANALOG SAW: the DEST knob stops on offered destinations only", ok);
    expect("  .. not the EQ gains, not ANALOG WAVE (E1), not SHAPE nor ENV 2 -> SHAPE (SAW)", !seen[MD_EQLO] && !seen[MD_EQMID] && !seen[MD_EQHI] && !seen[MD_E1] && !seen[MD_SHP] && !seen[MD_E2SHP]);
    expect("  .. the new FILTER MODE, CUT, PAN, PATCH LEVEL and ANALOG's continuous slots (DTN, MIX, NOIS, DRV; CUT RES KTR are unused slots since cloud job J) are offered", seen[MD_FMODE] && seen[MD_CUT] && seen[MD_PAN] && seen[MD_LEVEL] &&
           seen[MD_E1 + 1] && seen[MD_E1 + 2] && seen[MD_E1 + 3] && seen[MD_E1 + 6] && !seen[MD_E1 + 4] && !seen[MD_E1 + 5] && !seen[MD_E1 + 7] && seen[0]);
    TSEL->p[P_E0] = 4;                                   /* PWM */
    dst_walk(seen);
    expect("mod hide: ANALOG PWM: SHAPE is offered, ENV 2 -> SHAPE is not (DUELL 1.1: FILTER ENV TIMBRE no longer acts, mod.c mod_dst_removed)", seen[MD_SHP] && !seen[MD_E2SHP] && !seen[MD_E1]);
    init_engine_of(TSEL, scn_eng_s("TRIO"));
    TSEL->p[P_E0] = 8;                                   /* NOIS: one noise oscillator */
    go_title("MATRIX 1-4"); frames(48);
    TSEL->p[P_M1SRC] = MS_LFO;
    TSEL->p[P_M1AMT] = 30;
    dst_walk(seen);
    expect("mod hide: TRIO NOIS: INT2 INT3 DTN PW and SHAPE not offered (no oscillator takes them); MODE CUT RES are unused slots (cloud job J: not offered either); WAVE removed",
           !seen[MD_E1 + 1] && !seen[MD_E1 + 2] && !seen[MD_E1 + 3] && !seen[MD_E1 + 7] && !seen[MD_SHP] && !seen[MD_E1 + 5] && !seen[MD_E1 + 6] && !seen[MD_E1] && !seen[MD_E1 + 4]);
    TSEL->p[P_M1DST] = MD_EQHI;                          /* a stored route to a removed destination (an older sound) */
    frames(8);
    expect("mod hide: a stored route to EQ HIGH stays (the value is kept, the route plays)", TSEL->p[P_M1DST] == MD_EQHI);
    turn(EN_K3, 1);
    d = (uint32_t)TSEL->p[P_M1DST];
    turn(EN_K3, -1);
    expect("  .. the knob leaves it for an offered one and does not come back to it", d != MD_EQHI && mod_dst_offered(TSEL, (int32_t)d) && TSEL->p[P_M1DST] != MD_EQHI &&
           mod_dst_offered(TSEL, TSEL->p[P_M1DST]));
    TSEL->p[P_M1SRC] = TSEL->p[P_M1DST] = TSEL->p[P_M1AMT] = 0;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    sweep_homepg();
    sweep_readonly();
    sweep_pages();
    sweep_buttons();
    sweep_home();
    sweep_other();
    sweep_menu();
    sweep_layers();
    test_tempo();
    test_glo_page();
    sweep_footstrip();
    sweep_rec_hold();
    sweep_rec_hold_layer();
    sweep_quick();
    sweep_mixer();
    test_page_order();
    test_fxsum();
    sweep_algo();
    sweep_leds_play_rec();
    test_move_left();
    test_mod_hide();
    printf("select: %d checks, %d failed\n", ncheck, bad);
    return bad ? 1 : 0;
}
