/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* FELUCCA boot and main loop. Boot order: WDT first, boot-loop guard, fatal vectors,
 * guards; then LCD, input (TIMER5 IRQ, 10 kHz), audio (ALNK0 IRQ). */
extern uint32_t _data_start[], _data_end[], _data_load[], _bss_start[], _bss_end[];
extern uint32_t _pool_start[], _pool_end[], _rt_start[], _rt_end[], _rt_load[];
#if DUELL_BENCH
extern char _ustack_top[];                       /* core 0's user and exception stacks (the linker scripts; the others: hal/fm1_guard.h) */
static void c0_stack_bounds(uint32_t **b)
{
    b[0] = (uint32_t *)(uintptr_t)_ustack_lo; b[1] = (uint32_t *)(uintptr_t)_ustack_top;
    b[2] = (uint32_t *)(uintptr_t)_sstack_lo; b[3] = (uint32_t *)(uintptr_t)_sstack_top;
}
/* developer builds only: core 0's stack high-water marks (bench.c c0_stack_peak, the BENCH,INFO line's c0stack). fm1_cstart paints both stacks below its own frame; the 32 KB of
 * core 0's stacks were never measured (memory audit, option J). The painted words are the not-yet-used part. */
static void c0_stack_paint(void)
{
    uint32_t here, *p, *b[4], *e = (uint32_t *)((uintptr_t)&here - 256u);
    c0_stack_bounds(b);
    for (p = b[0]; p < e && p < b[1]; p++)
        *p = C0_STK_FILL;
    for (p = b[2]; p < b[3]; p++)
        *p = C0_STK_FILL;
}
#endif


/* TIMER5 outranks ALNK0, so the scan keeps its 100 us pace while a half buffer renders: before,
 * the ticks stopped for the whole render (0.7 ms idle, several ms loaded), the column lit when it
 * began stayed lit that long (a ~16 Hz flicker over all LEDs, beating with the scan) and the
 * encoders lost frames. Nested in ALNK0 it only scans (GPIO + fm1_in, nothing the audio ISR touches)
 * and counts ms; USB and UART polls wait for the first tick after the render, as they always did,
 * and the time spent nested is handed to the audio ISR so its load figures stay render-only.
 * The USB audio stream cannot wait for the render (one packet per 1 ms frame, a render takes up to
 * ~5 ms): uac_service also runs nested. It touches only EP4 (INDEX is set on every access) and the
 * consumer side of the audio ring, and usb_poll never runs nested, so the two never interleave. */
void fm1_timer5_irq(void)
{
    static uint32_t sub, owed;
    uint32_t t0 = fm1_ticks(), usb_due = sub % 5u == 0u;
    fm1_timer5_ack();
    felucca_dbg.timer_irqs++;
    /* the scan, every tick (2026-11-10, owner: "b"): 2026-11-08 skipped every second tick inside the render (a tick from the flash cost ~7.3 us there), but a column stays lit
     * until the next tick, so a skipped tick lit its column twice as long and the LEDs flickered in the rhythm of the render's load. The tick's code (fm1_input_tick and the
     * key sensing it calls) runs from RAM now (tools/ram_fns_z.py BUTTON SCAN): every column the same time, whatever plays */
    fm1_input_tick();
    {   /* milliseconds from the 24 MHz TIMER4 (robust to a late tick) */
        static uint32_t last, acc;
        acc += t0 - last;
        last = t0;
        while (acc >= 1000u * FM1_TICKS_PER_US) {
            acc -= 1000u * FM1_TICKS_PER_US;
            fm1_ms++;
        }
    }
    if (usb_due)
        owed |= 1u;                             /* 2 kHz: all USB SIE traffic lives here */
#if FELUCCA_UART
    if (sub % 5u == 2u)
        owed |= 2u;                             /* 2 kHz: <= ~7 bytes per call at 31250 baud */
#endif
    if (++sub == 10u)
        sub = 0;
    if (felucca_dbg.in_audio) {
        felucca_dbg.nested++;
#if FELUCCA_UAC
        if (usb_due)
            uac_service();
#endif
        t5_nested_ticks += fm1_ticks() - t0;
        return;
    }
    if (owed & 1u)
        usb_poll();
#if FELUCCA_UART
    if (owed & 2u)
        uart_midi_poll();
#endif
    owed = 0;
}
extern void isr_timer5(void);

static void timer5_start(void)                 /* OSC /4 = 6 MHz, PRD 600 -> 10 kHz */
{
#ifdef BENCH_T5_PRIO                  /* (bench builds, BENCH_T5_PRIO=3 in the environment: the test "does the crash need the nesting", 2026-11-06) */
    fm1_timer5_start(isr_timer5, BENCH_T5_PRIO);
#else
    fm1_timer5_start(isr_timer5, 4);   /* above ALNK0 (3): the scan nests into the render (see fm1_timer5_irq) */
#endif
}

static void hexs(char *b, uint32_t v)
{
    uint32_t i;
    for (i = 0; i < 8u; i++)
        b[i] = "0123456789ABCDEF"[(v >> (28u - 4u * i)) & 15u];
    b[8] = 0;
}

static void fm1_fault(const fm1_crash_t *c)
{
    char b[12];
    uint32_t t0;
    fm1_audio_stop();
    scr_wake_now();                                   /* (MENU > SCREEN OFF: the panel on first) */
    lcd_fill(0, 0, 240, 240, UI_CRASH_BG);            /* fixed, outside the palettes */
    draw_text_line(0, 8, 240, &AF_M, "DUELL CRASH", UI_CRASH_INK, UI_CRASH_BG, 1);
    hexs(b, c->vec);
    draw_text_line(10, 40, 220, &AF_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->pc);
    draw_text_line(10, 60, 220, &AF_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->emu);
    draw_text_line(10, 84, 220, &AF_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->dbg);
    draw_text_line(10, 102, 220, &AF_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->rets);
    draw_text_line(10, 120, 220, &AF_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    t0 = fm1_ticks();
    while ((uint32_t)(fm1_ticks() - t0) < 4000u * 1000u * FM1_TICKS_PER_US)
        ;
    fm1_reboot();
}

/* power-on: the parts with their default sounds (TRK_DEF); the sequencers empty */
static void felucca_init(void)
{
    uint32_t i;
    for (i = 0; i < G_COUNT; i++)
        song.g[i] = GP[i].def;
    undo_depth++;                             /* (no undo copy of the power-on loads) */
    fm6_init();                               /* every track's FM6 patch: the init voice */
    for (i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        track_defaults(t);
        init_engine_of(t, TRK_DEF[i][0]);            /* (0.2.24: the full INIT: defaults + the first preset; set_engine_of keeps the common settings now) */
        apply_preset_to(t, TRK_DEF[i][1]);    /* with its sends */
        t->engine = t->eng_req;
        eng_mem_claim(t);                     /* (zeros already: no note can come before) */
        track_defaults_steps(t);              /* (a sound load never touches them) */
        if (TRK_DEF[i][2])
            pat_load_def(t, TRK_DEF[i][2] - 1u);
        pat_sig[i] = steps_sig(t);            /* a default pattern, not the user's */
        pat_last[i] = TRK_DEF[i][2];
    }
    undo_depth--;
    song.sel = 0;
    song.master_q12 = 2048;                   /* (the pot's level replaces it before the audio starts: master_boot) */
    go_main();                                /* DUELL 3.5: the device opens on MORPH */
}

/* The power-on LED sweep (1.1, hal/fm1_led_anim.h: a soft light over the keys left to right, then the buttons swell
 * and settle on the glow; ~0.70 s), started before the scan and run by it: nothing waits for it, the splash's 430 ms
 * and the first ~0.27 s of the UI go by under it (the UI's LEDs from its end, or at once on a key or a button down).
 * Every LEDS setting: it is no idle glow; with MEDIUM / LOW it ends on that glow (and is drawn over that glow
 * level), with OFF / MAX dark. Not with MENU > ANIM OFF (no motion: the LEDs as the UI has them at once), not after a crash (a crash record newer than the last boot saw: the crash screen's
 * reset), a hang (a WDT reset) or a failed boot (bootguard: the last one died within its first 30 s): straight to the
 * UI. The UBOOT paths never get here. */
static uint32_t crash_seen __attribute__((unused));   /* fm1_crash.count at the last boot */
static uint8_t boot_clean;                    /* no crash, hang (WDT) or failed boot before this one (boot_leds):
                                               * the sweep runs and the autosave is restored (project.c autosave_boot) */
static void boot_leds(void)
{
    uint32_t crashed = fm1_crash.magic == FM1_CRASH_MAGIC && fm1_crash.count != crash_seen;
    crash_seen = fm1_crash.count;
    boot_clean = !crashed && !bootguard.failed && !(fm1_boot.p3_rst & 4u);
    fm1_led_dim_level(settings_leds == LEDS_DIM_LO);
    if (boot_clean && !(ui_prefs & PREF_ANIM_OFF))
        fm1_led_anim_start(settings_leds == LEDS_DIM || settings_leds == LEDS_DIM_LO);
}

static void fm1_main(void)
{
    persist_boot();
#if FELUCCA_OTA
    if (flash_ok)
        ota_boot_cleanup();                             /* staging area left by an update */
#endif
    settings_init();
    usb_serial_apply();                                 /* (#67: the saved USB SERIAL before usb_start) */
    lcd_init();
    draw_splash();                                      /* ui_draw.c (1.1.5) */
    if (felucca_dbg.magic != DBG_MAGIC) {
        memset(&felucca_dbg, 0, sizeof felucca_dbg);
        felucca_dbg.magic = DBG_MAGIC;
    }
    felucca_dbg.boots++;
    felucca_dbg.max_us = 0;
    felucca_dbg.erase_max_us = felucca_dbg.erase_last_us = felucca_dbg.prog_max_us = felucca_dbg.erases = 0;   /* (0.2.11: since this boot) */
    felucca_dbg.in_audio = 0;                       /* .noinit: a reset inside the audio ISR left it set, and
                                                       TIMER5 would treat every tick as nested (no USB poll) */
    felucca_dbg.prev_stage = felucca_dbg.stage;     /* a WDT reset leaves the last breadcrumb here */
    felucca_dbg.prev_page = felucca_dbg.page;
    felucca_dbg.prev_home = felucca_dbg.home;
    felucca_dbg.prev_frames = felucca_dbg.ui_frames;
    felucca_dbg.prev_rst = fm1_boot.p3_rst;
    fm1_input_init();
    fm1_adc_init();
    panel_init();
    felucca_init();
#if DUELL_VELO
    sense_cal_restore();                      /* the stored key calibration (velo_cal_load) */
#endif
    master_boot();
    kb_boot_hold = 1;                         /* #137: no notes from the keys before the UI (seq.c keyboard_block) */
#if DUELL_TWOCORE
    tc_boot(fm1_boot.p3_rst, fm1_crash.magic == FM1_CRASH_MAGIC && fm1_crash.count != crash_seen, bootguard.failed != 0);   /* (an armed start
                                               * of core 1, at the stock supplies, before the audio: twocore.c; crash_seen is boot_leds' below) */
#endif
    audio_init();
    usb_start();
#if FELUCCA_UART
    uart_midi_init();
#endif
    boot_leds();
    timer5_start();
    fm1_guard_lock_top();
    fm1_irq_enable_all();
    fm1_delay_ms(30);
#if !BOARD_SMK37                              /* (the SMK-37's table is fixed: panel.c) */
    if ((fm1_in.buttons & 3u) == 3u) {
        panel_setup();                        /* OCT- + OCT+ held at power-on */
        settings_save();
    }
#endif
    if (autosave_boot(boot_clean))            /* (1.2) the last session's music, under the splash */
        first_boot_pending = 0;               /* (DUELL 0.1: a restored session is not a new unit's start) */
    splash_begin();                           /* DUELL: the splash proper (ui_draw.c): drawn by the main loop, the synth already
                                               * runs, MIDI IN and (after 0.1 s) the keys play through it, any key ends it */
    scrn.idle = fm1_ms;                        /* (MENU > SCREEN OFF: from here) */

    for (;;) {
        uint32_t m = fm1_ms;
        fm1_wdt_feed();
        usb_retry(fm1_ms);
        if (erase_restart_due()) {                      /* DUELL 0.2.2: ERASE DATA done (erase_data.c): the first-start path */
            BG_ERASE_ALL(bootguard);   /* DUELL 1.1 (item 92 addendum 2): ERASE wipes the boot guard whole (pending, failed = the update-mode counter, magic) .. */
#if DUELL_TWOCORE
            tc_forget();               /* .. and the second-core record (strike, last, SKIPBOOT): a clean start always tries two cores */
#endif
            /* (item 92 first fix, now covered by the wipe above:) DUELL 1.1 (item 92): an intended restart, not a failed start. Left set, an erase inside the first 30 s after a start (the installer does exactly that) made the boot guard see "the last start died": tc_boot then skipped core 1 (SKIPBOOT) for that whole session */
            fm1_reboot();
        }
        if (fm1_ms > 30000u && bootguard.pending) {     /* a crash or hang in the first 30 s counts */
            bootguard.pending = 0;
            bootguard.failed = 0;
        }
        {
#if DUELL_VELO
            static uint32_t seen;                       /* battery: read in the scan tick's slot (there is one converter, the tick owns it: after Velo's method) */
            int32_t b = fm1_an.batt_n != seen ? fm1_an.batt : 0;   /* (a new reading only, once) */
            seen = fm1_an.batt_n;
#else
            int32_t b = fm1_adc_read(FM1_ADC_BATT);     /* battery: slow IIR */
#endif
            if (b > 0)
                song.batt_raw = song.batt_raw ? song.batt_raw + (b - song.batt_raw) / 32 : b;
        }
        master_poll();
#if DUELL_VELO
        sense_service(fm1_ms, !fm1_in.notes);           /* the key calibration, stored when due and no key is held (never from the tick) */
#endif
        {   /* OCT- + OCT+ held 5 s: enter UBOOT with RAM intact (debug / update); a countdown
             * shows from 2 s over the whole screen (the menu and the dialogs too: ui_draw), letting
             * go cancels it */
            static uint32_t t0;
            uint32_t both = (1u << panel.btn[B_OCTDN]) | (1u << panel.btn[B_OCTUP]);
            if ((fm1_in.buttons & both) != both) {
                if (ui.uboot) {
                    ui.uboot = 0;
                    ui.force = 1;                       /* what the countdown covered */
                    ui_message("UPDATE CANCELLED");
                }
                t0 = fm1_ms;
            } else if (fm1_ms - t0 > 2000u && fm1_ms - t0 <= 5000u) {
                uint32_t left = (5000u - (fm1_ms - t0) + 999u) / 1000u;
                if (left != ui.uboot) {
                    ui.uboot = (uint8_t)left;
                    ui.force = 1;
                }
            } else if (fm1_ms - t0 > 5000u) {
                fm1_audio_stop();
                scr_wake_now();
                lcd_fill(0, 0, 240, 240, T_BG);
                draw_text_box(0, 110, 240, &AF_M, "UBOOT", T_THEME, 1);
                usb_detach();
                fm1_delay_ms(30);
                bootguard.pending = 0;                  /* intentional reset: not a failed boot */
                fm1_enter_uboot();
            }
        }
#if FELUCCA_OTA
        ann_poll();                                     /* DUELL 1.4: a screen reader's SysEx, before the editor and the updater look */
        ed_service();                                   /* web editor SysEx */
        ota_service();                                  /* M-UPGRADE handshake */
        if (usb.ota_req) {                              /* M-UPGRADE upgrade command */
            usb.ota_req = 0;
            panic_req = (1u << NTRK) - 1u;               /* every track (bit per track) */
            scr_wake_now();                             /* (its progress on the screen) */
#if DUELL_TWOCORE
            tc_hold_clean();                            /* (core 1 held before an update) */
#endif
            if (flash_ok)
                ota_session();                          /* returns only if nothing was committed */
            lcd_fill(0, 0, 240, 240, T_BG);
            ui.force = 1;
        }
#endif
        if (usb.uboot_req) {                            /* SysEx F0 22 24 35 7D F7 from the host */
            fm1_audio_stop();
            scr_wake_now();
            lcd_fill(0, 0, 240, 240, T_BG);
            draw_text_box(0, 110, 240, &AF_M, "UBOOT (USB)", T_THEME, 1);
            fm1_delay_ms(20);
            usb_detach();
            fm1_delay_ms(30);
            bootguard.pending = 0;
            fm1_enter_uboot();
        }
#if FELUCCA_CDC
        cdc_task();
#if DUELL_VELO_CAPTURE
        velocap_drain();                              /* developer capture build only: the queued key readings to the serial console (never waits) */
#endif
#endif
        felucca_dbg.ui_frames++;
        felucca_dbg.page = ui.page;
        felucca_dbg.stage = 1;
        ui_input();
        wave_service();                               /* DUELL WAVE: a frame of a table build, if one waits (eng_wave.c) */
        vcap_poll();                                  /* DUELL 0.2.11: the parts' VOICE CAP (voice.c) */
        budget_poll();                                /* DUELL: the parts' NOTES budget (budget.c; the stricter of it and the VOICE CAP holds) */
#if DUELL_TWOCORE
        tc_watch(fm1_ms);                             /* the second core's safety net (twocore.c) */
        tc_trim_poll();                               /* (the jobs paused or core 1 stopped: notes above a part's number fade at once: twocore_run.c) */
#endif
        settings_poll();                              /* queued settings save: only while stopped */
        autosave_poll();                              /* (1.2) the music, stopped and idle: project.c */
        felucca_dbg.stage = 2;
        ui_leds();
        ui_draw();
        ui_speak();                                   /* DUELL 1.4: what changed on the screen, to a listening screen reader (ui_speak.c) */
        ann_tick(fm1_ms);
        felucca_dbg.stage = 9;
        while (fm1_ms - m < 15u) {                               /* ~60 UI frames/s at most */
            ui_input();
#if DUELL_VELO_CAPTURE
            velocap_drain();
#endif
            wave_service();                     /* (the table builds use the wait: ~0.3 ms a frame) */
#if FELUCCA_OTA
            ann_poll();                         /* (DUELL 1.4: the screen reader's first) */
            ed_service();                       /* editor replies without waiting for the next frame */
#endif
        }
    }
}

void fm1_cstart(void)
{
    uint32_t *s, *d, p3, src, wdt;
    int bg_enter;
#if DUELL_TWOCORE
    fm1_cpu1_halt();                           /* (after Felucca 1.6.1: a second core still running from before this reset would read the
                                                * RAM cleared below; hal/fm1_sys.h) */
#endif
#if DUELL_BENCH
    c0_stack_paint();
#endif
    fm1_time_init();
    fm1_reset_reason();
    p3 = fm1_boot.p3_rst;
    src = fm1_boot.rst_src;
    wdt = fm1_boot.wdt_con;
    fm1_wdt_arm(0x0D);
    BG_START(bootguard, BOOTGUARD_MAGIC, bg_enter);   /* (bootguard.h) */
    if (bg_enter)
        fm1_enter_uboot();
#if DUELL_RAMPLACE
    ramplace_copy();                            /* the RAM ranges X and Z before anything can call them (memset, memcpy are in Z; ramplace.c);
                                                 * after the boot guard: a start that dies here counts as a failed one (2: the update mode) */
#endif
    fm1_irq_init();
    for (d = _bss_start; d < _bss_end; d++)
        *d = 0;
    for (d = _pool_start; d < _pool_end; d++)
        *d = 0;
    for (s = _data_load, d = _data_start; d < _data_end; s++, d++)
        *d = *s;
    for (s = _rt_load, d = _rt_start; d < _rt_end; s++, d++)
        *d = *s;                                /* flash driver code that must run from RAM */
#if DUELL_RAMPLACE
    ramplace_boot();                            /* X and Z compared with their load images (the update mode if they stay wrong) */
#endif
    fm1_mailbox_clear();
    fm1_guard_enable(FM1_GUARD_STACK | FM1_GUARD_WRITE | FM1_GUARD_BUS | FM1_GUARD_PC);
    fm1_boot.p3_rst = (uint8_t)p3;
    fm1_boot.rst_src = src;
    fm1_boot.wdt_con = (uint8_t)wdt;
    fm1_main();
    for (;;)
        ;
}
