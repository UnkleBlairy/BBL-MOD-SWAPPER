/* SPDX-License-Identifier: GPL-3.0-only */
/* DUELL MULTI (SAVE > MULTI, SPEC 5b.4): sixteen slots M01..M16, each the whole instrument state of both parts. Included by
 * project.c (it replaces Felucca's four PROJECT slots: the project format FUN11 stays for the autosave and the editor's
 * backup and restore of the music, project_capture / project_restore_runtime below are shared). The functions keep the
 * project_* names the UI and the editor call (project_save, project_load, ..): a slot number is a multi now, 0..15.
 *
 * What a multi holds: per part (1 and 2) the engine and preset, every P_* value (the sound with its matrix, LFO / ENV 2,
 * INSERT, EQ, DUCK, its TRIM (the PATCH TRIM); the arp; the MIXER LEVEL, PAN, MUTE and the sends; LEN DIV SWING GATE QUANTIZE), the 64 steps, the FM6 patch (an
 * FM6 part only), the morph's AMOUNT and End B (MU_VER 8, ROLL CHAINED storage 2026-10-29: its exact values, morph.c's MBV block as a patch record and the
 * project file hold it: morph_bv_make / morph_bv_load); the parts' automation and parameter locks; the globals of the music
 * (MU_GLOBAL: TEMPO, SWING, CHORUS, DLY 1 / 2 with PING-PONG and its SPREAD, REVERB with its TYPE; BASS MONO is not held since 0.2.21: a master effect, the device's), the output MODE
 * (duell_mode), MORPH SET's SMART / ARP / PITCH (TARGET: written, not loaded, 0.2.9), the selected part, the name (12 characters). Not held (the
 * device's, MENU's and the settings'): the clock source (G_CLOCK), MIDI IN's routing (G_ROUTE), TUNE (G_TUNE), the colour
 * theme, MIDI channels, display, LEDs, USB. Loading replaces everything held; each part's MORPH starts at fader A with the
 * multi's End B (a patch load's rule). Loading while playing keeps the transport running: every note off, an engine change
 * fades as ever (project_restore_runtime with proj_keep_play).
 *
 * Record (version MU_VER 8, little endian, variable length, at most MU_REC_MAX = 1916 bytes):
 *   0  version, np (P_COUNT when saved), ng (MU_NG: the globals stored), the selected part, MODE, byte 5: bit 0 TARGET (1 BOTH: ALGORITHM's BOTH when saved;
 *      1.3.x: loaded again, a shipped multi always BOTH), bits 1..4 unused since 0.2.21 (0.2.19 / 0.2.20 stored BASS MONO there: written 0, ignored when read), MORPH SET bits (morph.c
 *      MC_SET), the parts' automation PLAY bits (motion.on)
 *   8  the name, 12 bytes (ASCII 32..126, 0-padded)
 *  20  the MU_NG globals a multi loads (MU_GLOBAL, in id order), int16 each (MU_VER 8: the 9 it never loaded are not stored)
 *      per part (2): engine, preset, AMOUNT, flags (bit 0: an FM6 patch follows); End B: a length byte (0 = none: a load rolls a fresh B at AMOUNT) and morph.c's
 *      MBV block; np values (+64, a byte each, as FUN11); the NX extension values (+64, dense); the steps sparse: a 64-bit map (8 bytes, bit i = step i stored),
 *      then MU_STEP = 7 bytes per stored step (patslot.c ps_pack_step without its bytes 6 and 7, the drum lane of before 0.2.14, always 0; a step not stored is an
 *      empty step, step_clear); the FM6 patch packed 8 to 7 (UPF_PK = 112 bytes, upreset.c upf_pk_put: its 128 bytes are 7-bit), when flag bit 0
 *      the automation: a count, then (place, param, value) per event of parts 1..2 (core.h motion_event_t)
 *      then XFADE (0..100), SPLIT (0 OFF, else note + 1): core.h mix_xf, mix_split (the spare byte of before is gone)
 *   Sizes: 56 bytes of header and globals, a part 168 + End B (at most MBV_MAX 195) + 7 per used step (+ 112 FM6), the automation 1 + 3 per event, 2 mix bytes.
 *   Two FM6 parts with every value of End B moved and all 64 steps used take at most 1905 bytes (1827 measured at the worst ranges): the record always holds the
 *   sound with its End B, the slots and the steps; the automation gets the rest of the 1916 (3 events at the very worst), a save that has more keeps the first
 *   that fit and says PARAMETER LOCKS CUT.
 *   DUELL 0.2.14: only a record of exactly this version (MU_VER 8) with np = P_COUNT and ng = MU_NG loads. A record of firmware
 *   before 0.2.14 (versions 1 and 2, an older P_COUNT) or of a newer one does not: the slot lists as empty ("--") and a LOAD says
 *   EMPTY SLOT / DAMAGED; the first SAVE there replaces it, and a default slot shows its default multi instead.
 *
 * Default multis (build/gen/duell_multis.h, tools/gen_duell_multis.py from tools/default_multis/M01..M16.bin, made by tools/default_multis.py), DUELL 0.2.23:
 * all sixteen slots, M01 REESE SWAMP (a new unit's first start loads it, ui_input.c first_boot_poll) .. M15 WOOD & SKIN and M16 STRESS TEST (a CPU
 * test to play on the unit, free to overwrite; SPEC 5b.4 lists them; 0.2.24: the owner's COLD CHAPEL, ACID ETHER, GARGLE ACID of 0.2.22 in M06, M09, M14)
 * are in the firmware image (ROM), not in flash. While a slot's stored record is
 * empty (first boot, a flash erase, ERASE of a saved overwrite) it shows and loads the default multi (mu_fact bit); SAVE
 * over it stores an ordinary record that wins from then on and survives firmware updates (the ROM copy is only the default);
 * ERASE of such a slot restores the default multi ("ALREADY DEFAULT" when it is not overwritten); a rename of an unchanged
 * default slot stores its record under the new name (an overwrite). (Until 0.2.22 M11, M12 were empty and M13..M16 the four CPU TEST multis of developer
 * builds; those are test scenes since 0.2.23: tests/scenes/, tests/scenes.h.)
 * The records name their sounds by engine + default index (checked at build time) and hold End B as its values (MU_VER 8: converted once from the seed blocks of
 * MU_VER 7 by the firmware's own roll, so they sound as before), so they need nothing else from the sound list.
 *
 * Store: two multis per storage.c object (OBJ_MULTI0..7: M01 M02 in object 0, ..): magic "MUL1", the two records' lengths
 * (u16; 0 = empty), record 1, record 2; at most 8 + 2 x 1916 = 3840 bytes, a whole object (ST_PAYLOAD_MAX). Each object is an
 * A/B sector pair (commit record last, the newest valid copy wins): a save reads the pair's current copy, replaces its
 * record and writes the whole object to the other sector, so a power cut at any point leaves both multis of the pair as
 * they were, and a write never disturbs the partner. Flash (fm1_flash.h FL_MULTI_*): objects 0..3 at 0x97000..0x9EFFF
 * (Felucca's project sectors), 4..7 at 0xCE000..0xD5FFF (the end of USR3's stride). A Felucca project left in those sectors
 * has another object type in its commit record (OBJ_PROJECT0..3, retired): it reads as no multi (the slot shows "--"), and
 * the first save there replaces it. Writes only while stopped (STOP TO SAVE), as the projects' were.
 * RAM: the names and which slots are used (multi_boot reads the eight objects once at power-on); a record is read from flash
 * when it is loaded or written, through proj_wire (the serialized scratch). Without FELUCCA_FLASH (host builds) the objects
 * live in RAM (mu_ram). */
#define MU_NOBJ (MU_SLOTS / 2u)
#define MU_MAGIC 0x314C554Du                      /* "MUL1" */
#define MU_VER 8u                                 /* 8 (ROLL CHAINED storage, 2026-10-29): End B as values (morph.c MBV, after a length byte), only the MU_NG globals a multi loads, the NX slots dense without a count, no edit list, steps in 7 bytes, the FM6 patch packed 8 to 7, no spare byte; 7 (the cloud plan's job A): per part the NX extension slots and the hand-set B edit list; 6 (0.2.22): DUCK SRC 2 is MIDI; 5 (0.2.19): P_LEVEL is the MIXER level and P_TRIM the sound's loudness; 4 (0.2.16): G_DMODE; 3 (0.2.14): CRUSH's BITS curve, BALANCE, XFADE, SPLIT. The only version that loads (7 and before: refused) */
#define MU_HDR 8u
#define MU_OBJ_MAX 3840u
#define MU_REC_MAX ((MU_OBJ_MAX - MU_HDR) / 2u)
#define MU_NAME_AT 8u
#define MU_G_AT 20u
#define MU_STEP 7u                                /* MU_VER 8: a stored step (ps_pack_step's bytes 0..5 and 8) */
#define MU_PART_FIX (4u + 1u + P_COUNT + NX + 8u) /* a part without its End B block, steps and patch: engine, preset, AMOUNT, flags, End B's length, the values, the slots, the step map */
_Static_assert(sizeof proj_wire_u.raw >= MU_OBJ_MAX && PROJ_NAME_LEN == 12u && NSHOWN == 2u, "multi object staging");
#if FELUCCA_FLASH
_Static_assert(MU_OBJ_MAX <= ST_PAYLOAD_MAX && OBJ_PATCH0 == OBJ_MULTI0 + MU_NOBJ, "a multi object is one storage object");
#endif
/* the globals a multi loads (the music's; not the device's: clock source, TUNE, MIDI, the SAVE pages' own) */
#define MU_GLOBAL(i) ((i) == G_BPM || (i) == G_SWING || ((i) >= G_DTIME && (i) <= G_CDEPTH) || (i) == G_RTYPE || \
                      (i) == G_RLOCUT || (i) == G_PINGSPREAD || (i) == G_DMDEP || (i) == G_DMRATE || \
                      (i) == G_DMODE || (i) == G_SHPITCH || (i) == G_SHMOD)
#define MU_G1(i) ((i) < G_COUNT && MU_GLOBAL(i))
#define MU_NG (MU_G1(0) + MU_G1(1) + MU_G1(2) + MU_G1(3) + MU_G1(4) + MU_G1(5) + MU_G1(6) + MU_G1(7) + MU_G1(8) + MU_G1(9) + MU_G1(10) + MU_G1(11) + MU_G1(12) + \
               MU_G1(13) + MU_G1(14) + MU_G1(15) + MU_G1(16) + MU_G1(17) + MU_G1(18) + MU_G1(19) + MU_G1(20) + MU_G1(21) + MU_G1(22) + MU_G1(23) + MU_G1(24) + \
               MU_G1(25) + MU_G1(26))                           /* the globals a multi stores (18) */
_Static_assert(G_COUNT == 27u, "MU_NG counts the globals 0..26");
_Static_assert(MU_G_AT + 2u * MU_NG + NSHOWN * (MU_PART_FIX + MBV_MAX + NSTEP * MU_STEP + UPF_PK) + 1u + 2u <= MU_REC_MAX,
               "a multi's sound with its End B and its steps always fit its record (only the automation can be cut)");
#define mu_buf (proj_wire_u.raw)
static char mu_names[MU_SLOTS][PROJ_NAME_LEN + 1u] __attribute__((unused));
static uint16_t mu_used;                          /* bit k: M(k + 1) holds a multi that loads */
#if !FELUCCA_FLASH
static uint8_t mu_ram[MU_NOBJ][MU_OBJ_MAX];       /* (host builds: the store) */
static uint16_t mu_ram_len[MU_NOBJ];
#endif
static int project_restore_runtime(const project_t *input);
#include "duell_multis.h"                         /* DF_N default multis: DF_SLOT (their slots) / DM_REC / DM_AT / DM_LEN (M01..M16) */
static uint32_t df_of(uint32_t k)                 /* the default multi of slot k (index into DM_*); DF_N none */
{
    uint32_t i;
    for (i = 0; i < DF_N; i++)
        if (DF_SLOT[i] == k)
            return i;
    return DF_N;
}
_Static_assert(DF_TEST_MULTIS == DUELL_TEST_MODE, "duell_multis.h was generated with another DUELL_TEST_MODE: run tools/gen_duell_multis.py (tools/build.py) with the same switch");
_Static_assert(DF_N <= MU_SLOTS, "default multis: slots below MU_SLOTS");
static uint16_t mu_fact;                          /* bit k: M(k + 1) is empty in flash and shows its default multi */

static uint32_t mu_rd16(const uint8_t *b) { return (uint32_t)b[0] | (uint32_t)b[1] << 8; }
static void mu_wr16(uint8_t *b, uint32_t v) { b[0] = (uint8_t)v; b[1] = (uint8_t)(v >> 8); }
static void mu_move(uint8_t *d, const uint8_t *s, uint32_t n)   /* overlapping copy */
{
    if (d < s)
        while (n--) *d++ = *s++;
    else
        while (n--) d[n] = s[n];
}
static void mu_label(char *b, uint32_t k)         /* "M01" .. "M16" (b: 4 bytes) */
{
    b[0] = 'M';
    b[1] = (char)('0' + (k + 1u) / 10u);
    b[2] = (char)('0' + (k + 1u) % 10u);
    b[3] = 0;
}

/* object o -> mu_buf, always a well-formed one (none, torn or damaged: both records empty); its length */
static uint32_t mu_obj_read(uint32_t o)
{
    int n;
    uint32_t l0, l1, magic;
    proj_wire_gen++;                              /* (the editor's staging lives there too) */
#if FELUCCA_FLASH
    n = flash_ok ? st_load(OBJ_MULTI0 + o, mu_buf, MU_OBJ_MAX) : -1;
#else
    n = mu_ram_len[o];
    memcpy(mu_buf, mu_ram[o], (uint32_t)n);
#endif
    if (n >= (int)MU_HDR) {
        memcpy(&magic, mu_buf, 4);
        l0 = mu_rd16(mu_buf + 4);
        l1 = mu_rd16(mu_buf + 6);
        if (magic == MU_MAGIC && l0 <= MU_REC_MAX && l1 <= MU_REC_MAX && MU_HDR + l0 + l1 == (uint32_t)n)
            return (uint32_t)n;
    }
    magic = MU_MAGIC;
    memcpy(mu_buf, &magic, 4);
    mu_wr16(mu_buf + 4, 0);
    mu_wr16(mu_buf + 6, 0);
    return MU_HDR;
}
static const uint8_t *mu_rec(uint32_t h, uint32_t *len)   /* record h (0, 1) of the object in mu_buf */
{
    uint32_t l0 = mu_rd16(mu_buf + 4);
    *len = h ? mu_rd16(mu_buf + 6) : l0;
    return mu_buf + MU_HDR + (h ? l0 : 0u);
}
static int mu_obj_write(uint32_t o, uint32_t len)   /* mu_buf -> object o; 0 written */
{
#if FELUCCA_FLASH
    return flash_ok ? st_save(OBJ_MULTI0 + o, mu_buf, len) : -1;
#else
    memcpy(mu_ram[o], mu_buf, len);
    mu_ram_len[o] = (uint16_t)len;
    return 0;
#endif
}

static void mu_rest(uint8_t *q)                   /* an empty step, packed (what a record leaves out) */
{
    step_t s;
    memset(&s, 0, sizeof s);
    step_clear(&s);
    ps_pack_step(&s, q);
}

/* the bytes of record b that are not the automation: header, globals, the parts with End B, their steps and patch, the automation's count and the two mix bytes.
 * MU_REC_MAX less this is what the automation may take (the _Static_assert above: never below 0) */
static uint32_t mu_base_len(const project_t *p)
{
    uint32_t t, i, n = MU_G_AT + 2u * MU_NG + 1u + 2u;
    uint8_t rest[PS_STEP], q[PS_STEP];
    mu_rest(rest);
    for (t = 0; t < NSHOWN; t++) {
        n += MU_PART_FIX + (p->bvn[t] <= MBV_MAX ? p->bvn[t] : 0u) + (p->t[t].engine == ENGI_FM6 ? UPF_PK : 0u);
        for (i = 0; i < NSTEP; i++) {
            ps_pack_step(&p->t[t].step[i], q);
            if (memcmp(q, rest, PS_STEP))
                n += MU_STEP;
        }
    }
    return n;
}
/* p (project_capture: the music as it is, End B as values in p->bv) and the live MODE / MORPH -> record b; its length. *cut: bit 0 automation left out (only
 * when the sound, End B, the steps and the automation together do not fit MU_REC_MAX: the last events go) */
static uint32_t mu_pack(uint8_t *b, const project_t *p, uint32_t *cut)
{
    uint32_t pos, t, i, n = 0, at;
    uint8_t rest[PS_STEP];
    char nm[PROJ_NAME_LEN + 1u];
    mu_rest(rest);
    (void)mu_base_len;
    *cut = 0;
    memset(b, 0, MU_G_AT);
    b[0] = MU_VER;
    b[1] = P_COUNT;
    b[2] = MU_NG;
    b[3] = (uint8_t)(p->sel < NSHOWN ? p->sel : 0u);
    b[4] = (uint8_t)(duell_mode_req < DM_N ? duell_mode_req : DM_SPLIT);
    b[5] = (uint8_t)(morph.target == MT_BOTH);       /* bit 0 TARGET (ALGORITHM's BOTH, loaded since 1.3.x); bits 1..4 were BASS MONO (0.2.19), a device setting since 0.2.21: written 0, ignored on read */
    b[6] = (uint8_t)(morph.cfg & MC_SET);
    b[7] = (uint8_t)(p->motion.on & ((1u << NSHOWN) - 1u));
    memcpy(b + MU_NAME_AT, nm, proj_name_get(nm, (const uint8_t *)p->name));
    pos = MU_G_AT;
    for (i = 0; i < G_COUNT; i++)
        if (MU_GLOBAL(i)) {
            mu_wr16(b + pos, (uint16_t)p->g[i]);
            pos += 2u;
        }
    for (t = 0; t < NSHOWN; t++) {
        const proj_trk_t *s = &p->t[t];
        uint32_t fm = s->engine == ENGI_FM6, nb = p->bvn[t] <= MBV_MAX ? p->bvn[t] : 0u;
        uint8_t *map;
        b[pos++] = s->engine;
        b[pos++] = s->preset;
        b[pos++] = (uint8_t)morph_amount_of(t);
        b[pos++] = (uint8_t)fm;
        b[pos++] = (uint8_t)nb;                        /* MU_VER 8: End B as values (project_capture made it: morph.c morph_bv_make) */
        memcpy(b + pos, p->bv[t], nb);
        pos += nb;
        for (i = 0; i < P_COUNT; i++)
            b[pos++] = (uint8_t)(clamp(s->p[i], -64, 127) + 64);
        for (i = 0; i < NX; i++)
            b[pos++] = (uint8_t)(clamp(s->x[i], -64, 127) + 64);
        map = b + pos;
        memset(map, 0, 8);
        pos += 8u;
        for (i = 0; i < NSTEP; i++) {
            uint8_t q[PS_STEP];
            ps_pack_step(&s->step[i], q);
            if (memcmp(q, rest, PS_STEP)) {
                map[i >> 3] |= (uint8_t)(1u << (i & 7u));
                memcpy(b + pos, q, 6u);                  /* (bytes 6 and 7, the drum lane, always 0: left out) */
                b[pos + 6u] = q[8];
                pos += MU_STEP;
            }
        }
        if (fm) {
            upf_pk_put(p->fm6[t], b + pos);              /* (128 7-bit bytes, 8 to 7) */
            pos += UPF_PK;
        }
    }
    at = pos++;
    for (i = 0; i < p->motion.count && i < MOTION_MAX; i++) {
        const motion_event_t *e = &p->motion.event[i];
        if (MOTION_TRK(e) >= NSHOWN)
            continue;
        if (pos + 3u + 2u > MU_REC_MAX) {                 /* (room kept for the 2 bytes at the end) */
            *cut |= 1u;
            continue;
        }
        b[pos++] = e->place;
        b[pos++] = e->param;
        b[pos++] = (uint8_t)e->value;
        n++;
    }
    b[at] = (uint8_t)n;
    b[pos++] = mix_xf;                              /* XFADE, SPLIT (0 OFF, else note + 1) */
    b[pos++] = mix_split;
    return pos;
}

/* record b (len bytes) -> q (the music as it is: what a multi does not hold stays; End B as values into q->bv, q->bvn); set[]: MODE, TARGET, MORPH SET bits;
 * amt[]: each part's AMOUNT. 0 = not a multi this firmware loads */
static int mu_unpack(project_t *q, uint8_t amt[NSHOWN], uint8_t set[6], const uint8_t *b, uint32_t len)
{
    uint32_t pos, t, i, n;
    if (len < MU_G_AT || b[0] != MU_VER || b[1] != P_COUNT || b[2] != MU_NG)
        return 0;
    if (b[3] >= NSHOWN || b[4] >= DM_N || (b[5] >> 5) || (b[6] & ~MC_SET) ||
        (b[7] >> NSHOWN) || MU_G_AT + 2u * MU_NG > len)
        return 0;
    pos = MU_G_AT;
    for (i = 0; i < G_COUNT; i++)
        if (MU_GLOBAL(i)) {
            q->g[i] = (int16_t)mu_rd16(b + pos);
            pos += 2u;
        }
    for (t = 0; t < NSHOWN; t++) {
        proj_trk_t *d = &q->t[t];
        uint32_t e, fl, nb;
        const uint8_t *map;
        if (pos + MU_PART_FIX > len || (e = b[pos]) >= NENGINES || (b[pos + 3] & ~1u))
            return 0;
        d->engine = (uint8_t)e;
        d->preset = b[pos + 1];
        amt[t] = b[pos + 2];
        fl = b[pos + 3];
        nb = b[pos + 4];
        pos += 5u;
        if (nb > MBV_MAX || pos + nb + MU_PART_FIX - 5u > len || (nb && morph_bv_size(b + pos, nb, e) != nb))
            return 0;
        memset(q->bv[t], 0, sizeof q->bv[t]);
        memcpy(q->bv[t], b + pos, nb);
        q->bvn[t] = (uint8_t)nb;
        q->xe_n[t] = 0;                                 /* (MU_VER 8: the values set by hand are End B's marks) */
        memset(q->mb[t], 0, sizeof q->mb[t]);
        pos += nb;
        for (i = 0; i < P_COUNT; i++) {
            if (b[pos] > 191u)
                return 0;
            d->p[i] = (int16_t)(b[pos++] - 64);
        }
        for (i = 0; i < NX; i++) {
            if (b[pos] > 191u)
                return 0;
            d->x[i] = (int16_t)(b[pos++] - 64);
        }
        map = b + pos;
        pos += 8u;
        for (i = 0; i < NSTEP; i++) {
            uint8_t st[PS_STEP];
            memset(&d->step[i], 0, sizeof d->step[i]);
            if (!((map[i >> 3] >> (i & 7u)) & 1u)) {
                step_clear(&d->step[i]);
                continue;
            }
            if (pos + MU_STEP > len)
                return 0;
            memcpy(st, b + pos, 6u);
            st[6] = st[7] = 0;
            st[8] = b[pos + 6u];
            if (!ps_unpack_step(st, &d->step[i]))
                return 0;
            pos += MU_STEP;
        }
        if (fl & 1u) {
            if (pos + UPF_PK > len)
                return 0;
            upf_pk_get(b + pos, q->fm6[t]);              /* (7-bit bytes by their form) */
            pos += UPF_PK;
        } else {
            memcpy(q->fm6[t], FM6_INIT, FM6_PACKED);
        }
    }
    if (pos >= len || (n = b[pos++]) > MOTION_MAX || pos + 3u * n + 2u != len)
        return 0;
    memset(&q->motion, 0, sizeof q->motion);       /* (tracks 3..4: none in DUELL) */
    for (i = 0; i < n; i++, pos += 3u) {
        if ((b[pos] >> 6) >= NSHOWN)
            return 0;
        q->motion.event[i].place = b[pos];
        q->motion.event[i].param = b[pos + 1];
        q->motion.event[i].value = (int8_t)b[pos + 2];
    }
    q->motion.count = (uint8_t)n;
    q->motion.on = b[7];
    motion_sanitize(&q->motion);                    /* (DUELL 1.1: events an older firmware recorded on a target that is no longer one are dropped, not the multi) */
    if (!motion_valid(&q->motion))
        return 0;
    q->sel = b[3];
    memset(q->name, 0, sizeof q->name);
    {
        char nm[PROJ_NAME_LEN + 1u];
        memcpy(q->name, nm, proj_name_get(nm, b + MU_NAME_AT));
    }
    set[3] = 0u;                                    /* XFADE, SPLIT (after the events): out of range = the defaults */
    set[4] = b[pos] <= 100u ? b[pos] : 0u;
    set[5] = b[pos + 1u] <= 128u ? b[pos + 1u] : 0u;
    set[0] = b[4];
    set[1] = b[5] & 1u;
    set[2] = b[6];
    /* b[5] bits 1..4 (BASS MONO of a 0.2.19 / 0.2.20 multi): ignored, q->bm stays what the device has (0.2.21: master effects are not part of a multi) */
    q->sum = proj_sum(q);
    return 1;
}

/* the RAM view of object o (in mu_buf): which of its two multis load, their names */
static void mu_note(uint32_t o)
{
    uint32_t h, len, k;
    for (h = 0; h < 2u; h++) {
        const uint8_t *r = mu_rec(h, &len);
        uint8_t amt[NSHOWN], set[6];
        k = 2u * o + h;
        mu_names[k][0] = 0;
        mu_used &= (uint16_t)~(1u << k);
        mu_fact &= (uint16_t)~(1u << k);
        int ok = len && mu_unpack(&proj_scratch, amt, set, r, len);
        if (!ok && df_of(k) < DF_N) {             /* nothing stored, or a record this firmware does not load (one of before 0.2.14): the default multi (ROM) */
            r = DM_REC + DM_AT[df_of(k)];
            len = DM_LEN[df_of(k)];
            mu_fact |= (uint16_t)(1u << k);
            ok = mu_unpack(&proj_scratch, amt, set, r, len);
        }
        if (ok) {
            mu_used |= (uint16_t)(1u << k);
            proj_name_get(mu_names[k], r + MU_NAME_AT);
        }
    }
}
static void multi_boot(void)                      /* persist_boot: the names from flash */
{
    uint32_t o;
    mu_used = 0;
    mu_fact = 0;
    for (o = 0; o < MU_NOBJ; o++) {
        mu_obj_read(o);
        mu_note(o);
    }
}
static void multi_ram_reset(void)                 /* (host tests: a power-on; without flash every slot empty but the default ones) */
{
    uint32_t o;
#if !FELUCCA_FLASH
    memset(mu_ram_len, 0, sizeof mu_ram_len);
#endif
    memset(mu_names, 0, sizeof mu_names);
    mu_used = 0;
    mu_fact = 0;
    for (o = 0; o < MU_NOBJ; o++) {                 /* (nothing stored: the default multis) */
        mu_obj_read(o);
        mu_note(o);
    }
}

static int project_used(uint32_t slot) { return (mu_used >> (slot % MU_SLOTS)) & 1u; }
static int project_default(uint32_t slot) { return (mu_fact >> (slot % MU_SLOTS)) & 1u; }   /* shows its default multi */
/* slot's name -> b (PROJ_NAME_LEN + 1 bytes); 0 = an empty slot (b "") */
static int project_info(uint32_t slot, char *b)
{
    str_cpy(b, project_used(slot) ? mu_names[slot % MU_SLOTS] : "", PROJ_NAME_LEN + 1u);
    return project_used(slot);
}
static int project_name(uint32_t slot, char *b) { return project_info(slot, b); }
static uint32_t project_cur_slot(void) { return proj_cur; }   /* (0..15, PROJ_NO_SLOT none) */
static void project_cur_name(char *b) { str_cpy(b, proj_name, PROJ_NAME_LEN + 1u); }   /* b: 13 bytes */

/* DUELL 1.3.x (owner 2026-11-18): which parts play the multi's own sound (ui.c foot_mu): a part whose values are exactly its patch's (slot_of: the
 * slot the sound is in; every value a patch load sets, param_kept left out as the load leaves it) keeps the patch's name in the footer; any
 * other shows the multi's name. Not compared: the extension slots and the FM6 operator data */
static void foot_mu_check(void)
{
    uint32_t pi;
    foot_mu = 0;
    for (pi = 0; pi < NSHOWN; pi++)
        if (snd_differs(&trk[pi], 0u))
            foot_mu |= (uint8_t)(1u << pi);
}

static void mu_say(const char *what, uint32_t k)  /* "SAVED M05" */
{
    char b[4];
    mu_label(b, k);
    ui_say(what, b);
}

/* object o in mu_buf with record h replaced by rec (n bytes, 0: emptied) built in place by mu_pack, or its bytes moved;
 * the partner kept as it is. fill: 1 = pack the music into it (*cut), 0 = empty it. Returns the object's length */
static uint32_t mu_put_rec(uint32_t h, int fill, uint32_t *cut, const uint8_t *raw, uint32_t rawlen);
static uint32_t mu_put(uint32_t h, int fill, uint32_t *cut)
{
    return mu_put_rec(h, fill, cut, 0, 0);
}
static uint32_t mu_put_rec(uint32_t h, int fill, uint32_t *cut, const uint8_t *raw, uint32_t rawlen)
{
    uint32_t l0 = mu_rd16(mu_buf + 4), l1 = mu_rd16(mu_buf + 6), n;
    *cut = 0;
    if (h == 0u) {                                /* the partner (record 2) to the end of the buffer, record 1 at 8, the */
        mu_move(mu_buf + MU_OBJ_MAX - l1, mu_buf + MU_HDR + l0, l1);   /* partner back after it */
        n = raw ? rawlen : fill ? mu_pack(mu_buf + MU_HDR, &proj_scratch, cut) : 0u;
        if (raw)
            memcpy(mu_buf + MU_HDR, raw, rawlen);
        mu_move(mu_buf + MU_HDR + n, mu_buf + MU_OBJ_MAX - l1, l1);
        l0 = n;
    } else {
        l1 = raw ? rawlen : fill ? mu_pack(mu_buf + MU_HDR + l0, &proj_scratch, cut) : 0u;
        if (raw)
            memcpy(mu_buf + MU_HDR + l0, raw, rawlen);
    }
    mu_wr16(mu_buf + 4, l0);
    mu_wr16(mu_buf + 6, l1);
    return MU_HDR + l0 + l1;
}

/* the music as it is now -> multi slot, named `name` (0: the current name; "" none); 0 saved, nonzero refused or failed.
 * The current name becomes the saved one */
static int project_save_as(uint32_t slot, const char *name)
{
    uint32_t k = slot % MU_SLOTS, o = k / 2u, len, cut, pi;
    project_t *p = &proj_scratch;
    if (transport_busy()) {                            /* a flash erase silences the audio and stalls the */
        ui_message("STOP TO SAVE");                     /* sequencer (storage_hw.c): only while stopped */
        return 1;
    }
    for (pi = 0; pi < NSHOWN; pi++)                    /* (End B as values: project_capture, morph_bv_make; a part never used gets its first End B now, as before) */
        (void)morph_ready(pi);
    project_capture(p);
    if (name) {
        memset(p->name, 0, sizeof p->name);
        memcpy(p->name, name, str_len(name) < PROJ_NAME_LEN ? str_len(name) : PROJ_NAME_LEN);
    }
    mu_obj_read(o);
    len = mu_put(k & 1u, 1, &cut);
    if (mu_obj_write(o, len)) {
        mu_obj_read(o);                                /* (the slots as they are) */
        mu_note(o);
        ui_message("SAVE ERROR");
        return 2;
    }
    proj_name_get(proj_name, (const uint8_t *)p->name);   /* (before mu_note: it decodes into proj_scratch) */
    mu_note(o);
    proj_cur = (uint8_t)k;
    pat_from_set(k + 1u);
    if (cut & 2u)
        ui_message("B EDITS CUT");
    else if (cut)
        ui_message("PARAMETER LOCKS CUT");
    else
        mu_say("SAVED ", k);
    return 0;
}
static int project_save(uint32_t slot) { return project_save_as(slot, 0); }

/* ERASE: the multi gone, its partner kept; 0 done, 1 refused (playing, empty), 2 failed */
static int project_erase(uint32_t slot)
{
    uint32_t k = slot % MU_SLOTS, o = k / 2u, len, cut;
    if (transport_busy()) {
        ui_message("STOP TO SAVE");
        return 1;
    }
    if (project_default(k)) {                          /* never overwritten: nothing stored to erase */
        ui_message("ALREADY DEFAULT");
        return 1;
    }
    if (!project_used(k)) {
        ui_message("EMPTY");
        return 1;
    }
    mu_obj_read(o);
    len = mu_put(k & 1u, 0, &cut);
    if (mu_obj_write(o, len)) {
        mu_obj_read(o);
        mu_note(o);
        ui_message("SAVE ERROR");
        return 2;
    }
    mu_note(o);
    if (proj_cur == k)
        proj_cur = PROJ_NO_SLOT;
    mu_say("ERASED ", k);                              /* (a default slot: the default multi is back, mu_note) */
    return 0;
}

/* a stored multi renamed in place (nothing else of it changes; the music playing is not touched, but the slot it was loaded
 * from / saved to: its name is the new one, the next SAVE's prefill): 0 done, 1 refused (playing, an empty slot), 2 failed */
static int project_rename(uint32_t slot, const char *name)
{
    uint32_t k = slot % MU_SLOTS, o = k / 2u, len, n;
    uint8_t *r;
    if (transport_busy()) {
        ui_message("STOP TO SAVE");
        return 1;
    }
    if (!project_used(k)) {
        ui_message("EMPTY SLOT");
        return 1;
    }
    len = mu_obj_read(o);
    if (project_default(k)) {                          /* an unchanged default multi: its record stored, renamed (an overwrite) */
        uint32_t cut;
        len = mu_put_rec(k & 1u, 1, &cut, DM_REC + DM_AT[df_of(k)], DM_LEN[df_of(k)]);
    }
    r = (uint8_t *)mu_rec(k & 1u, &n);
    memset(r + MU_NAME_AT, 0, PROJ_NAME_LEN);
    {
        char nm[PROJ_NAME_LEN + 1u];
        uint32_t i;
        for (i = 0; i < PROJ_NAME_LEN && name[i]; i++)
            nm[i] = name[i];
        nm[i] = 0;
        memcpy(r + MU_NAME_AT, nm, proj_name_get(nm, (const uint8_t *)nm));
    }
    if (mu_obj_write(o, len)) {
        mu_obj_read(o);
        mu_note(o);
        ui_message("SAVE ERROR");
        return 2;
    }
    mu_note(o);
    if (proj_cur == k)
        str_cpy(proj_name, mu_names[k], sizeof proj_name);
    ui_message("RENAMED");
    return 0;
}

/* LOAD: everything the multi holds replaces the music (see the top); each part's MORPH at A with the multi's End B */
static void project_load(uint32_t slot)
{
    uint32_t k = slot % MU_SLOTS, len, pi;
    uint8_t amt[NSHOWN], set[6];
    const uint8_t *r;
    int rc, shipped = 0;
    mu_obj_read(k / 2u);
    r = mu_rec(k & 1u, &len);
    if (!len && df_of(k) < DF_N) {                     /* nothing stored: the default multi */
        shipped = 1;
        r = DM_REC + DM_AT[df_of(k)];
        len = DM_LEN[df_of(k)];
    }
    if (!len) {
        ui_message("EMPTY SLOT");
        return;
    }
    project_capture(&proj_scratch);                    /* (what a multi does not hold stays as it is) */
    if (!mu_unpack(&proj_scratch, amt, set, r, len)) {
        ui_message("DAMAGED");
        return;
    }
    proj_bound(&proj_scratch);
    {
        int32_t hold[NSHOWN];                          /* (1.3.x, owner 2026-11-18: HOLD stays as the player left it, ui.c hold_keep) */
        for (pi = 0; pi < NSHOWN; pi++)
            hold[pi] = trk[pi].p[P_AHOLD];
        proj_keep_play = 1;                            /* (playing: it goes on; every note off) */
        proj_morph_skip = 1;                           /* (End B: below, from the record's own block and AMOUNT) */
        rc = project_restore_runtime(&proj_scratch);
        if (!rc)
            for (pi = 0; pi < NSHOWN; pi++)
                hold_keep(&trk[pi], hold[pi]);
    }
    proj_keep_play = 0;
    proj_morph_skip = 0;
    if (rc) {
        ui_message("DAMAGED");
        return;
    }
    /* 0.2.11: the MODE saved in the multi is applied only when MENU > CONTROL > MODE RECALL is ON (default OFF: the unit stays in its
     * mode, and XFADE and SPLIT stay as set; a PC recall too). (Until 0.2.22 the CPU TEST multis M13..M16 of developer builds
     * always set theirs; since 0.2.23 they are test scenes, tests/scenes.h, and every slot follows MODE RECALL.) */
    if (ui_prefs2 & (PREF_MODE_RECALL >> 16)) {
        mix_xf = set[4];                               /* (the settings bytes follow: ui_input.c mode_settings) */
        mix_split = set[5];
        duell_mode_req = set[0];                       /* (the audio takes it at its next block: seq.c mode_apply) */
    }
    /* set[1] TARGET: ALGORITHM's position (DUELL 1.3.x, owner 2026-11-18: each multi remembers it; with b[3] the selected part):
     * a shipped multi (the ROM record: nothing stored in the slot) always starts on BOTH, the owner's default; a multi the user saved loads what it was saved with */
    morph.target = (shipped || set[1]) ? MT_BOTH : MT_SELECTED;
    morph.cfg = set[2];
    for (pi = 0; pi < NSHOWN; pi++)                    /* MU_VER 8: End B as its values, the multi's AMOUNT; no block: a fresh B at that AMOUNT (a patch load's rule) */
        if (proj_scratch.bvn[pi]) {
            morph_load_part_v(pi, proj_scratch.bv[pi]);
            mph[pi].amount = (uint8_t)(amt[pi] > 100u ? 100u : amt[pi]);
        } else
            morph_load_part(pi, 0, amt[pi], 0, 0);
    proj_cur = (uint8_t)k;
    foot_mu_check();                                   /* (1.3.x: the footer: the multi's name for a part that is no exact patch) */
    pat_from_set(k + 1u);
    perf_fade_begin(1);                                /* 0.2.14: PERF LEAVE FADE glides SPACE and KILL to neutral, KEEP leaves them (was: both set to 0 at once, 0.2.11: a new multi starts the performance macros neutral (not saved with it; SPACE glides: fx.c sv.spc; */
                                                       /* a patch / sound load now does the same (ui.c load_begin); DEPTH and MORPH are left as they are) */
    mac_neutral(3u);                                   /* (DUELL 1.3: both parts' MACROS too, ui.c) */
    mu_say(pc_multi ? MSG_TITLE "LOADED " : "LOADED ", k);   /* (item 157: a MIDI program change's load in the title's face; the MULTI page's LOAD as before) */
}
