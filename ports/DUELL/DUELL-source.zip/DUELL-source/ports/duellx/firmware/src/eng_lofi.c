/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Chip voice: pulse/triangle/saw/noise/wave RAM, quantised amplitude and a held
 * (downsampled) output; SWEEP bends the pitch down after note-on.
 *
 * WAVE is ONE list (DUELL 1.1): PLS TRI SAW NOISE, then 11 wave-RAM tables (SIN .. STAIR), each a 32-sample, 4-bit wave,
 * read step-wise (no interpolation). K4 (E2, "PULSE WIDTH") is the pulse width and is shown with WAVE = PLS only
 * (ui_draw.c card_hidden_vp); the table is WAVE - RW_SINE.
 * BITS = STEP: a 4-bit stepped volume envelope with a frame-clock divider replaces the
 * ADSR curve (lofi_amp), the triangle becomes a 32-step 4-bit staircase, the pulse
 * duties are 12.5 / 25 / 50 / 75 %; CRSH then sets the envelope (shown as "DCY").
 * SHP (the track's shape input: ENV / LFO DEST SHP, the matrix's SHP; DUELL): pulse-width modulation around DUTY (PLS,
 * STEP's pulse), smooth, not in DUTY's steps (+-64 = +-12.5 % of the period, as ANALOG's PW; 6.25 .. 93.75 % at most). Not the
 * WRAM table: a table switch is a step, and the morph fades the SHP depths (tests/morph_test.c: no cliff). Centre
 * (64 << 8): DUTY as set, bit for bit. */
static const char *const N_BITS[] = {"4BIT", "4B/2", "8BIT", "1BIT", "STEP"};
static const char *const N_RWAVE[] = {"PLS", "TRI", "SAW", "NOISE", "SIN", "SAW 2", "BASS 1", "BASS 2",
                                      "ORGAN", "HOLLOW", "AH", "OH", "EE", "BUZZ", "STAIR"};
static const char *const N_RARP[] = {"OFF", "OCT", "MAJ", "MIN"};
enum { BITS_4BIT, BITS_4B2, BITS_8BIT, BITS_1BIT, BITS_STEP };
enum { RW_PLS, RW_TRI, RW_SAW, RW_NOIS, RW_SINE, RW_SAW2, RW_BAS1, RW_BAS2, RW_ORGN, RW_HOLW, RW_VOXA, RW_VOXO, RW_VOXE,
       RW_BUZZ, RW_STAIR, RW_NWAVE };   /* RW_SINE .. RW_STAIR: wave RAM, table RW - RW_SINE */

/* wave RAM: 11 tables x 32 samples x 4 bits, two samples a byte (high nibble first);
 * our own shapes, from simple formulas (squares, sine, triangle, saws, harmonic sums,
 * one formant peak for the vowels). DC is taken out per table in lofi_render. */
static const uint8_t WRAM[11][16] = {
    {0x89, 0xAC, 0xDE, 0xEF, 0xFF, 0xEE, 0xDC, 0xA9, 0x86, 0x53, 0x21, 0x10, 0x00, 0x11, 0x23, 0x56},   /* SINE */
    {0x01, 0x12, 0x33, 0x45, 0x56, 0x77, 0x89, 0x9A, 0x56, 0x67, 0x88, 0x9A, 0xAB, 0xCC, 0xDE, 0xEF},   /* SAW2: + its octave */
    {0xEE, 0xEF, 0xFF, 0xFF, 0xFF, 0xEE, 0xED, 0xDC, 0x11, 0x10, 0x00, 0x00, 0x00, 0x11, 0x12, 0x23},   /* BAS1: sloped square */
    {0xCE, 0xFF, 0xED, 0xBA, 0x9A, 0xBD, 0xEF, 0xFE, 0xC9, 0x64, 0x21, 0x00, 0x00, 0x01, 0x24, 0x69},   /* BAS2: 1 + 2 + 3 */
    {0x8B, 0xEF, 0xED, 0xBA, 0x9A, 0xAA, 0x98, 0x77, 0x88, 0x87, 0x65, 0x55, 0x65, 0x42, 0x10, 0x14},   /* ORGN: 1..4 */
    {0x8D, 0xFE, 0xDD, 0xDD, 0xCD, 0xDD, 0xDE, 0xFD, 0x82, 0x01, 0x22, 0x22, 0x32, 0x22, 0x21, 0x02},   /* HOLW: odd */
    {0x8F, 0xFC, 0xA7, 0x67, 0x89, 0x88, 0x88, 0x87, 0x88, 0x77, 0x77, 0x76, 0x78, 0x98, 0x53, 0x00},   /* VOXA: "ah" */
    {0x8F, 0xEE, 0xFD, 0xDB, 0x98, 0x66, 0x66, 0x77, 0x88, 0x89, 0x99, 0x97, 0x64, 0x22, 0x01, 0x10},   /* VOXO: "oh" */
    {0x7F, 0x96, 0xCF, 0xBB, 0xCC, 0xBB, 0xAA, 0x98, 0x77, 0x65, 0x54, 0x43, 0x34, 0x40, 0x39, 0x60},   /* VOXE: "ee" */
    {0xF3, 0x00, 0x12, 0x22, 0x11, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22},   /* BUZZ: spike + ring */
    {0xFF, 0xFF, 0xFF, 0xFF, 0xAA, 0xAA, 0xAA, 0xAA, 0x55, 0x55, 0x55, 0x55, 0x00, 0x00, 0x00, 0x00},   /* STAIR: 4 levels */
};
#define Q4 2184                  /* one 4-bit step (2 * 2184 * 7.5 = 32760) */

/* BITS = STEP: CRSH as the envelope, CRSH / 4 = b: 0 constant volume, 1..16 a one-shot decay
 * (divider period 0..15), 17..31 a looping one (period 1..15) */
static const char *const N_DCY[] = {"CONST", "D0", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10",
                                    "D11", "D12", "D13", "D14", "D15", "L1", "L2", "L3", "L4", "L5", "L6", "L7",
                                    "L8", "L9", "L10", "L11", "L12", "L13", "L14", "L15", 0};
static const param_desc_t LOFI_DCY = {"DCY", F_INT, 0, 127, 0, N_DCY, 0};        /* = edit[3] but the names */

static const param_desc_t *lofi_desc(const track_t *t, uint32_t k)
{
    if (k == 3u && t->p[P_E0] == BITS_STEP)
        return &LOFI_DCY;
    return 0;
}

/* the stepped envelope: volume 15..0 in v->s[6] bits 0..3, its divider in bits 4..7, a 240 Hz
 * frame clock (Q16 phase in v->s[7]); each frame the divider counts down and, at 0, reloads the
 * period and takes one step off the volume (a looping one starts again at 15 after 0) */
#define FRAME_Q16 ((240u * CTL * 65536u) / FS)       /* frames per control tick, Q16 */
static int32_t step_period(int32_t b) { return b <= 16 ? b - 1 : b - 16; }

static void lofi_note_on(track_t *t, voice_t *v)
{
    v->s[0] = 0;                 /* held sample */
    v->s[1] = 0;                 /* hold counter */
    v->s[2] = 0x7FFF;            /* LFSR */
    v->s[3] = 0;                 /* sweep, 1/16 st */
    v->s[4] = 0;                 /* 1-pole lp state */
    v->s[5] = 0;                 /* arp counter */
    v->s[6] = 15 | (step_period(t->p[P_E3] >> 2) & 15) << 4;   /* stepped env: every note-on restarts it */
    v->s[7] = 0;
}

/* BITS = STEP: the voice amplitude is the stepped envelope, not the ADSR curve. The ADSR only
 * gates: held, it is kept at full; after note-off the staircase keeps running (as the chip's
 * envelope never sees a note-off) and the voice is cut when the ADSR release has fallen to 1 %
 * (about the REL time; REL 0 cuts at once) or a one-shot decay has reached 0. */
static int32_t lofi_amp(track_t *t, voice_t *v, int32_t adsr)
{
    int32_t b = t->p[P_E3] >> 2, vol = v->s[6] & 15, div = (v->s[6] >> 4) & 15;
    if (t->p[P_E0] != BITS_STEP)
        return adsr;
    if (!v->active)                                     /* the ADSR ended it (or the voice was given up) */
        return 0;
    if (v->stage == 3u) {
        if (v->env < (1 << 24) / 100 || (b >= 1 && b <= 16 && !vol)) {
            v->env = 0;
            v->stage = 0;
            v->active = 0;
            return 0;
        }
    } else {
        v->env = 1 << 24;                               /* the release starts from full */
    }
    if (!b)
        return 15 * Q4;
    v->s[7] += (int32_t)FRAME_Q16;
    while (v->s[7] >= 65536) {
        v->s[7] -= 65536;
        if (div) {
            div--;
        } else {
            div = step_period(b);
            if (vol)
                vol--;
            else if (b > 16)
                vol = 15;
        }
    }
    v->s[6] = vol | div << 4;
    return vol * Q4;
}

/* DUELL MORPH (morph.c, core.h mxf): WAVE PLS / TRI / SAW of the other end (the morph never fades to or from NOISE or a wave-RAM table,
 * which carry state), cross-faded at each held sample before the quantiser. lofi_body with xf 0 is the render as it was
 * (the constant drops the fade); lofi_render_m (xf 1) runs only while a fade is under way */
static inline int32_t lofi_basic(uint32_t wave, uint32_t ph0, uint32_t duty, uint32_t stepc)
{
    if (wave == RW_TRI) {
        uint32_t k = ph0 >> 27;
        return stepc ? (int32_t)(k < 16u ? 15u - k : k - 16u) * (2 * Q4) - 15 * Q4 : osc_tri(ph0);
    }
    if (wave == RW_SAW)
        return (int32_t)(ph0 >> 16) - 32768;
    return (ph0 < duty ? 32767 : -32768) - ((int32_t)(duty >> 16) - 32768);
}
static inline __attribute__((always_inline)) void lofi_body(track_t *t, voice_t *v, int32_t *out, uint32_t n,
                                                            const vmod_t *m, const int xf)
{
    static const uint8_t STEP_DUTY[4] = {1, 2, 4, 6};   /* eighths: 12.5 / 25 / 50 / 75 % */
    const int16_t *p = t->p;
    uint32_t chip = (uint32_t)p[P_E0], wave = (uint32_t)p[P_E1], i;
    uint32_t stepc = chip == BITS_STEP;
    uint32_t duty = stepc ? 0x20000000u * STEP_DUTY[(p[P_E2] / 32) & 3]
                          : 0x20000000u * (1u + (uint32_t)p[P_E2] / 32u);   /* 12.5 / 25 / 37.5 / 50 % */
    int32_t crush = stepc ? 0 : p[P_E3];                /* STEP: CRSH is the envelope */
    int32_t bits = chip == BITS_8BIT ? 8 : chip == BITS_1BIT ? 1 : 4;
    int32_t hold = 1 + crush / 8 + (chip == 1u ? 1 : 0);
    int32_t lpk = 3000 + (p[P_E7] << 8) + (m->cutoff > 0 ? m->cutoff : 0);
    static const int8_t ARPS[4][3] = {{0, 0, 0}, {0, 12, 0}, {0, 4, 7}, {0, 3, 7}};
    int32_t ar = p[P_E6];
    int32_t pitch, held = v->s[0], cnt = v->s[1], lp = v->s[4];   /* state in locals: out[] may alias v->s[] */
    uint32_t inc, ph0 = v->ph[0], lfsr = (uint32_t)v->s[2];
    const uint8_t *wr = WRAM[(wave >= RW_SINE && wave < RW_NWAVE ? wave - RW_SINE : 0u)];
    int32_t wdc = 0;
    if (m->shape != (64 << 8)) {                        /* SHP (DUELL): the pulse's width around DUTY */
        int64_t d = (int64_t)duty + (int64_t)(m->shape - (64 << 8)) * 32768;   /* 64 << 8 -> 0x20000000 */
        duty = (uint32_t)(d < 0x10000000 ? 0x10000000 : d > 0xF0000000LL ? 0xF0000000LL : d);
    }
    if (wave >= RW_SINE) {                              /* the table's mean: no DC from lopsided shapes */
        int32_t sum = 0;
        for (i = 0; i < 16u; i++)
            sum += bits == 1 ? ((wr[i] >> 7) + ((wr[i] >> 3) & 1)) * 2 - 2 : (wr[i] >> 4) + (wr[i] & 15) - 15;
        wdc = bits == 1 ? sum * 32767 / 32 : sum * 2 * Q4 / 32;   /* (2 v - 15) Q4, or +-32767 at 1 bit */
    }
    /* sweep down, vibrato (uses the track LFO through m->pitch16 already) */
    if (v->s[3] < 4096)                                 /* past 2047 + an arp step the pitch is 0 anyway */
        v->s[3] += p[P_E4] / 8;
    v->s[5]++;
    pitch = m->pitch16 - v->s[3] + ARPS[ar & 3][(v->s[5] / 28) % 3] * 16;   /* ~50 Hz, chip-style */
    inc = pitch_inc(clamp(pitch, 0, 2047));
    if (p[P_E5])
        inc += (uint32_t)(((int32_t)(inc >> 12) * (((osc_sine(v->ph[1]) >> 8) * p[P_E5]) >> 4)) >> 4);   /* no overflow */
    v->ph[1] += 0x01000000u;
    if (lpk > 32767)
        lpk = 32767;
    for (i = 0; i < n; i++) {
        int32_t s;
        if (--cnt <= 0) {
            uint32_t q = bits < 16;                     /* quantise (the 4-bit tables are already) */
            cnt = hold;
            switch (wave >= RW_SINE ? (uint32_t)RW_SINE : wave) {   /* (the wave-RAM tables folded into one case: the same five-way switch as before the one list; a jump table over all 15 waves cost the others ~30 % in instructions) */
            case RW_TRI:
                if (stepc) {                            /* 32 steps, 4 bits: 15..0, 0..15 */
                    uint32_t k = ph0 >> 27;
                    s = (int32_t)(k < 16u ? 15u - k : k - 16u) * (2 * Q4) - 15 * Q4;
                    q = 0;
                } else {
                    s = osc_tri(ph0);
                }
                break;
            case RW_SAW:
                s = (int32_t)(ph0 >> 16) - 32768;
                break;
            case RW_NOIS: {
                uint32_t l = lfsr;
                if ((ph0 + inc * (uint32_t)hold) < ph0 || chip == 3u)
                    l = (l >> 1) | (((l ^ (l >> 1)) & 1u) << 14);
                lfsr = l;
                s = (l & 1u) ? 32767 : -32768;
                break;
            }
            case RW_SINE: {                /* wave RAM: step-wise, no interpolation */
                uint32_t k = ph0 >> 27, b = wr[k >> 1];
                b = (k & 1u) ? b & 15u : b >> 4;
                s = (bits == 1 ? (b >= 8u ? 32767 : -32767) : ((int32_t)b * 2 - 15) * Q4) - wdc;
                q = 0;
                break;
            }
            default:                                    /* minus its mean: no DC for narrow pulses */
                s = (ph0 < duty ? 32767 : -32768) - ((int32_t)(duty >> 16) - 32768);
                break;
            }
            if (xf && MXF(t).w[MX_E0 + 1u] && wave <= RW_SAW)
                s += (int32_t)(((int64_t)(lofi_basic(MXF(t).b[MX_E0 + 1u], ph0, duty, stepc) - s) * MXF(t).w[MX_E0 + 1u]) >> 15);
                                                        /* (64 bit: a narrow pulse minus its mean against a saw is up to ~90000 apart, x the weight
                                                         * overflowed 32 bits from a weight of ~0.73: the cliff the owner heard near 80 %) */
            if (q)                                      /* rounded, not floored (floor = DC) */
                s = ((s + (1 << (15 - bits))) >> (16 - bits)) << (16 - bits);
            if (crush > 64)
                s = (s >> 12) << 12;
            held = s;
        }
        ph0 += inc;
        lp += mulq15(held - lp, lpk);
        out[i] += voice_amp(lp, m, i);
    }
    v->ph[0] = ph0;
    v->s[0] = held;
    v->s[1] = cnt;
    v->s[2] = (int32_t)lfsr;
    v->s[4] = lp;
}
static __attribute__((noinline)) void lofi_render_m(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    lofi_body(t, v, out, n, m, 1);
}
static void lofi_render(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    if (MXF(t).on && MXF(t).w[MX_E0 + 1u])
        lofi_render_m(t, v, out, n, m);                 /* DUELL MORPH: a WAVE cross-fade */
    else
        lofi_body(t, v, out, n, m, 0);
}

static const preset_t LOFI_PRESETS[] = {
    {"PULSE LD", {0, 0, 32, 0, 0, 20, 0, 127}, {0, 60, 90, 30}, 0, 1, FX(0, 0, 40, 20), PAT(4)},
    {"WAVE BASS", {1, 1, 0, 0, 0, 0, 0, 90}, {0, 50, 70, 20}, 0, 1, FX(0, 0, 10, 0), PAT(2)},
    {"ARP 8BIT", {2, 0, 96, 0, 0, 0, 2, 110}, {0, 60, 80, 40}, 0, 0, FX(0, 0, 30, 20), PAT(13)},
    /* wave RAM AH (old VOXA), a little vibrato */
    {"WAVE LEAD", {0, 10, 64, 0, 0, 18, 0, 110}, {0, 70, 90, 30}, 0, 1, FX(0, 0, 40, 25), PAT(3)},
    /* STEP: 25 % pulse, DCY 34 = D7 (a 15-step decay over 0.5 s), REL ~54 ms of staircase after note-off */
    {"STEP LEAD", {4, 0, 40, 34, 0, 16, 0, 127}, {0, 64, 127, 55}, 0, 1, FX(0, 0, 40, 20), PAT(4)},
};

static const engine_t ENG_LOFI = {
    .name = "LOFI",
    .page_title = {"LOFI", "MOTN"},
    .edit = {
        {"BITS", F_ENUM, 0, 4, 0, N_BITS, 0},
        {"WAVE", F_ENUM, 0, RW_NWAVE - 1, 0, N_RWAVE, 0},
        {"PULSE WIDTH", F_INT, 0, 127, 64, 0, 0},       /* PLS only (ui_draw.c card_hidden_vp); in STEP 12.5 / 25 / 50 / 75 % */
        {"CRSH", F_PCT, 0, 127, 0, 0, 0},               /* STEP: the envelope (lofi_desc) */
        {"SWP", F_PCT, 0, 127, 0, 0, 0},
        {"VIB", F_PCT, 0, 127, 0, 0, 0},
        {"ARP", F_ENUM, 0, 3, 0, N_RARP, 0},
        {"TONE", F_PCT, 0, 127, 127, 0, 0},
    },
    .presets = LOFI_PRESETS,
    .npresets = NELEM(LOFI_PRESETS),
    .note_on = lofi_note_on,
    .render = lofi_render,
    .knob = {P_E1, P_E2, P_E3, P_REL},
    .keep = 0x11,                /* the held sample and the low-pass */
    .amp = lofi_amp,
    .desc = lofi_desc,
    .ufilt = 1,                 /* no filter of its own: the multimode filter (DUELL 0.2.9; voice.c uf_run: CUT RES MODE SLOPE, P_FREEA..D) */
};
