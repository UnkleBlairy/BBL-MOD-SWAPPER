/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Small-canvas renderer (no full framebuffer). Draw text/lines into
 * an off-screen strip, then blit it in one DMA transfer. Pixels are stored
 * byte-swapped (the panel takes RGB565 big-endian).
 * Text and icons are 4-bit alpha bitmaps made at build time (tools/gen_aa_font.py: Inter Tight;
 * tools/gen_aa_icons.py: Fukiai). A glyph is trimmed to its ink box, advances are in 1/16 px, and
 * each glyph is rasterised at 1 << psh horizontal phases (S M 4, L 2: drawn at a pen of +0, +1/4 .. px);
 * cv_text takes the phase that puts it within a phase step of its true place. Blending uses a 16-entry
 * ramp per (ink, background) pair, cached, so a pixel costs a nibble read and a store. Colours come from the theme tokens. */
typedef struct { uint16_t off, adv; int8_t bx; uint8_t by, bw, bh; } aag_t;
typedef struct {
    uint8_t h, asc, first, last, nex;   /* line height, baseline; ASCII range; extras */
    uint16_t nk;                        /* kerning pairs */
    const aag_t *g;
    const uint8_t *data;
    const uint16_t *kkey;               /* a << 8 | b, sorted */
    const int8_t *kd;                   /* 1/16 px */
    const uint8_t *ex;                  /* codes of the extra glyphs */
    uint8_t psh;                        /* log2 of the phases per glyph: g[i << psh] .. g[(i << psh) + phases - 1] */
    const uint8_t *hc;                  /* data's Huffman code (cv_alpha_hc), 0 = 2 px per byte (cv_alpha) */
} aafont_t;
/* a theme (tools/gen_ui_palettes.py): per-part backgrounds, the layer one, shared surfaces, and per part A, B: c the brief's
 * colours (fills), r the same readable as values, a the accent; hc: no gradients (the morph colour jumps at the middle) */
typedef struct { const char *name; uint16_t bg[2], bgl, surf[2], text, mid, line[2], raise[2], rec, c[4], r[4], a[4], g, ga; uint8_t hc; } ui_pal_t;   /* (0.2.24: g / ga the GLOBAL colour and its accent) */
typedef struct { uint16_t off; uint8_t w; const char *label; } kc_t;
#include "ui_fonts.h"                   /* the faces S M L T D N X B (tools/gen_aa_font.py preset barlow) */
#include "ui_tokens.h"                  /* the FACE ROLE MAP (aliases of retired faces) and the shared UI numbers */
#include "ui_palettes.h"
#include "splash_logo.h"            /* the splash lockup mask (tools/gen_splash_logo.py) */
#include "ui_keycaps.h"                 /* KC_*: the keycaps / badges (tools/gen_aa_keycaps.py), KNOB_* arcs */
#define ELLIPSIS '\x85'                 /* the ellipsis glyph of AF_S and AF_M */

/* host tests hook in here (layout lint, draw cost); nothing in the firmware */
#ifndef GFX_HOOK_TEXT
#define GFX_HOOKS 0                     /* (the firmware: what only the hooks read is not even computed) */
#define GFX_HOOK_TEXT(x0, y0, x1, y1, s, flags) ((void)0)   /* an ink box; flags 1 ellipsised, 2 cut, 4 icon, 8 free text, 32 in a scrolled view */
#define GFX_HOOK_BLIT(x, y, r0) ((void)0)
#define GFX_HOOK_BEGIN() ((void)0)
#define GFX_HOOK_PIXELS(n) ((void)0)
#endif
#ifndef GFX_HOOKS
#define GFX_HOOKS 1
#endif
#ifndef GFX_HOOK_CELL
#define GFX_HOOK_CELL(x0, y0, x1, y1) ((void)0)    /* a cell, card, row or button (cv_rrect): a box touching it lies inside it */
#endif
#ifndef GFX_HOOK_ALLOW
#define GFX_HOOK_ALLOW(x0, y0, x1, y1) ((void)0)   /* item 122: the fill drawn here is an ALLOWED one (a selected row / option, a lit card, a meter, data); the box lint skips it */
#endif
#define CV_HL(x, y, w, h) GFX_HOOK_ALLOW((x), (y), (x) + (w), (y) + (h))
#ifndef GFX_HOOK_INK
#define GFX_HOOK_INK(ink, bg) ((void)0)            /* a text, icon or keycap label's ink and what it is drawn on */
#endif
#ifndef GFX_HOOK_RULE
#endif
/* the alignment check (tests/ui_render.c): GFX_HOOK_ALIGN declares that the next item(s) drawn (a text, an icon, a
 * keycap, a cushion) are meant to sit centred in the box x0..x1, y0..y1 (canvas drawing coordinates, x1 y1 past it)
 * along AL_H and / or AL_V; AL_N(n): the next n items together. A text's ink is measured across (its glyphs' boxes)
 * and its capitals' band up and down (GFX_HOOK_PEN: its line top and face); an icon's ink from its cell
 * (GFX_HOOK_ITEM). The tag names the place in the report. */
#ifndef GFX_HOOK_PEN
#define GFX_HOOK_PEN(y, f) ((void)0)
#endif
#ifndef GFX_HOOK_ALIGN
#define GFX_HOOK_ALIGN(x0, y0, x1, y1, mode, tag) ((void)0)
#define GFX_HOOK_ITEM(x0, y0, x1, y1) ((void)0)
#define GFX_HOOK_ICON(x, y, size, id) ((void)0)        /* (an icon drawn: GFX_HOOK_ITEM with its ink, icons.c icon_ink) */
#endif
#define AL_H 1u                                    /* centred across */
#define AL_V 2u                                    /* centred up and down (a row's items: on the same centre line) */
#define AL_HV 3u
#define AL_B 4u                                    /* on the baseline y1 (a text: its capitals' bottom) */
#define AL_R 8u                                    /* the ink ending at x1 */
#define AL_PASS 16u                                /* (its item counts for the place declared before it too) */
#define AL_CELLS 32u                               /* the next cells (cv_rrect), not ink: a row of keys, a fill */
#define AL_N(n) ((uint32_t)(n) << 8)

#ifndef CV_ROWS
#define CV_ROWS 124u              /* (the unit: 104, tools/build.py; a taller canvas is drawn in bands, CV_BANDS below) */
#endif
#define CV_MAX (240u * CV_ROWS)   /* the graph strip is 240 x 124 */
static uint16_t cv_px[CV_MAX] __attribute__((unused));
static uint32_t cv_w, cv_h;
static uint16_t cv_bg;           /* what cv_begin cleared the canvas to */
static uint8_t cv_scroll;        /* 1: drawing a scrolled view (its text may run past the canvas) */
static int32_t cv_oy;            /* y offset for graph drawing */
static int32_t cv_by;            /* a canvas drawn in bands (CV_BANDS): the band's first row in the whole canvas; 0 otherwise */
#define CV_OY (cv_oy - cv_by)    /* the offset the pixels land at (cv_oy: the drawing's own, as without bands; the lint's hooks use it) */
static int16_t cv_cy0, cv_cy1;   /* text clip: canvas rows cv_cy0 .. cv_cy1 - 1 (cv_begin: the whole canvas) */
static uint8_t cv_flip;          /* cv_alpha_hc: the cell mirrored left <-> right (the header's metronome, ui_draw.c) */

#define RGB(r, g, b) ((uint16_t)((((r) >> 3) << 11) | (((g) >> 2) << 5) | ((b) >> 3)))

/* ------------------------------------------------------------- theme --- */
/* Five stored colours per palette, the rest derived with fixed blends (tools/gen_ui_palettes.py) */
static struct {
    uint16_t bg, base, text, theme, accent;
    uint16_t mid, dim, line, sel, tint, ink, rec, raise, key, lane, grid;
    uint16_t kink;               /* a keycap label: the background (INK, the label on a THEME / SEL fill, follows the part colour) */
    uint8_t light, mono;
    /* DUELL (SPEC 5a): part 1 draws with THEME, part 2 with THEME2; theme, sel, tint and lane are the SELECTED part's
     * (part_theme), pth / psel / ptint / plane both parts' (T_PTHEME(k) ...: a screen about both parts, ui_graph.c) */
    uint16_t pth[2], psel[2], ptint[2], plane[2];
    uint16_t pend[2][2];         /* both parts' pure A and B colours (the fader-free ends of pth: the header's A / B letter, ui_draw.c head_ab) */
    uint16_t pacc[2], pfill[2];  /* both parts' ACCENT and the brief's A -> B colour at their MORPH fader (pfill: the MORPH bar) */
    uint16_t gth, gacc;          /* DUELL 0.2.24 (owner): the GLOBAL colour and its accent (the palette's g / ga): a third colour, apart from both parts', for the pages that edit the
                                  * instrument (params.c page_global: GLO's pages, SCALE); on them theme / accent / sel / tint / lane are these (glob below), the background the LAYER one */
    uint8_t fader[2], layer, pal;   /* what part_theme blends by: the parts' MORPH faders 0..127, MODE LAYER, the palette */
    uint8_t glob;                /* a GLOBAL page is shown (theme_follow): the global colour set */
    uint8_t part, bw;            /* the part the theme follows; MONO (black and white: part 2 is an outline, cv_part) */
    uint32_t gen;                /* bumped by palette_set (the text ramps follow) */
} ux;
/* The look is FLAT only (DUELL 0.2.2: the LINE style, black areas divided by 1 px rules, was removed) */
#define T_BG ux.bg               /* background */
#define T_BASE ux.base           /* the palette's card tone: the BASE of every derived colour (bar tracks, greys, data fills, roll lanes); never drawn as a fill (no boxes) */
#define T_BASE_P1 (UI_PALETTES[ux.pal % NPALETTES].surf[0])   /* part 1's tone whatever the page (the MIXER's greys and tracks) */
#define T_TEXT ux.text           /* primary text */
#define T_THEME ux.theme         /* values, curves, the gauge's end line */
#define T_ACCENT ux.accent       /* the one active thing: hot knob, cursor, playhead */
#define T_MID ux.mid             /* labels, units, secondary text */
#define T_DIM ux.dim             /* inactive, empty */
#define T_LINE ux.line           /* 1 px dividers, gauge track */
#define T_SEL ux.sel             /* selection and gauge fill */
#define T_TINT ux.tint           /* a faint theme area */
#define T_KINK ux.kink           /* a keycap's label (on T_KEY / T_DIM fills) */
#define T_INK ux.ink             /* text on T_SEL / T_THEME */
#define T_REC ux.rec             /* REC: fixed red (GREY, MONO: the accent) */
#define T_RAISE ux.raise         /* a raised area on a surface: stubs, guides, slots, chips, button wells */
#define T_KEY ux.key             /* a keycap's fill (its label: T_INK; unavailable: a T_DIM fill) */
#define T_PFILL(k) ux.pfill[(k) & 1u]   /* part k's brief colour at its MORPH fader (the MORPH bar) */
#define T_PACC(k) ux.pacc[(k) & 1u]
#define T_PEND(k, b) ux.pend[(k) & 1u][(b) & 1u]   /* part k's colour at its A (0) or B (1) end, whatever the fader */
#define T_PTHEME(k) ux.pth[(k) & 1u]     /* part k's THEME, SEL, TINT (T_THEME: the selected part's) */
#define T_PSEL(k) ux.psel[(k) & 1u]
#define T_PTINT(k) ux.ptint[(k) & 1u]
#define T_LANE ux.lane           /* the piano roll: an in-scale row (SURF -> THEME 10 %) */
#define T_GRID ux.grid           /* the piano roll: a step line (SURF -> TEXT 6 %; beats and C rows: RAISE) */
#define NPALETTES UI_NPALETTES

static inline uint16_t ux_gray(uint32_t x5) { return (uint16_t)((x5 << 11) | (x5 << 6) | x5); }
/* a + (b - a) * pct / 100 per channel, rounded; GREY on the red channel, so it stays gray */
static uint16_t ux_mix(uint16_t a, uint16_t b, int32_t pct)
{
    static const uint8_t SH[3] = {11, 5, 0}, MK[3] = {31, 63, 31};
    uint32_t out = 0, k;
    if (ux.mono) {
        int32_t x = a >> 11, d = ((b >> 11) - x) * pct;
        return ux_gray((uint32_t)(x + (d + (d >= 0 ? 50 : -50)) / 100));
    }
    for (k = 0; k < 3u; k++) {
        int32_t x = (a >> SH[k]) & MK[k], d = (((b >> SH[k]) & MK[k]) - x) * pct;
        out |= (uint32_t)(x + (d + (d >= 0 ? 50 : -50)) / 100) << SH[k];
    }
    return (uint16_t)out;
}
static uint32_t ux_luma(uint16_t c)        /* 0..255 */
{
    return ((c >> 11) * 255u / 31u * 54u + ((c >> 5) & 63u) * 255u / 63u * 183u + (c & 31u) * 255u / 31u * 19u) >> 8;
}

/* WCAG-style contrast of two RGB565 colours, x100, from a gamma-2 luminance (integer; a few draws per frame) */
static uint32_t ux_y(uint16_t c)
{
    uint32_t r = (c >> 11) * 255u / 31u, g = ((c >> 5) & 63u) * 255u / 63u, b = (c & 31u) * 255u / 31u;
    return (54u * r * r + 183u * g * g + 19u * b * b) >> 8;
}
static uint32_t ux_cr(uint16_t a, uint16_t b)
{
    uint32_t x = ux_y(a), y = ux_y(b);
    if (x < y) { uint32_t t = x; x = y; y = t; }
    return (x + 3251u) * 100u / (y + 3251u);
}
/* the colour for a text of part colour c on bg: c itself, or the primary text colour where c would be hard to read (< 3:1) */
static uint16_t vt(uint16_t c, uint16_t bg) { return ux_cr(c, bg) >= 300u ? c : ux.text; }

/* The whole screen's theme follows the selected part: its background (LAYER mode: the layer one), its THEME / ACCENT, and
 * the colour travels A -> B with the part's MORPH fader (POLICE: a smooth blend like the others). Both parts' pth / psel /
 * ptint / plane / pacc are kept (T_PTHEME(k) ...). Runs when the palette, the style, the part, a fader or the mode changed
 * (theme_follow), never per pixel */
static void part_theme(uint32_t part)
{
    const ui_pal_t *p = &UI_PALETTES[ux.pal % NPALETTES];
    uint32_t k;
    uint32_t both = ux.layer || ux.glob;                /* (LAYER mode, or a GLOBAL page: the backgrounds of both parts mixed) */
    part &= 1u;
    ux.part = (uint8_t)part;
    ux.bg = both ? p->bgl : p->bg[part];
    /* panel, borders and elevated surface are per part like the background (LAYER, a global page: the mix of both) */
    {
        uint16_t sf = both ? ux_mix(p->surf[0], p->surf[1], 50) : p->surf[part];
        ux.base = sf;
        ux.line = both ? ux_mix(p->line[0], p->line[1], 50) : p->line[part];
        ux.raise = both ? ux_mix(p->raise[0], p->raise[1], 50) : p->raise[part];
    }
    ux.dim = ux_mix(ux.bg, p->text, UI_DIM_PCT);
    ux.key = ux_mix(ux.bg, p->text, UI_KEY_PCT);
    ux.kink = ux.bg;
    ux.light = ux_luma(ux.bg) > 128u;
    ux.grid = ux_mix(ux.base, p->text, 6);
    for (k = 0; k < 2u; k++) {
        uint32_t f = ux.fader[k] > 127u ? 127u : ux.fader[k], i = 2u * k;
        ux.pend[k][0] = p->r[i];
        ux.pend[k][1] = p->r[i + 1u];
        if (p->hc) {
            i += f >= 64u;
            ux.pth[k] = p->r[i]; ux.pfill[k] = p->c[i]; ux.pacc[k] = p->a[i];
        } else {
            int32_t pct = (int32_t)(f * 100u / 127u);
            ux.pth[k] = ux_mix(p->r[i], p->r[i + 1u], pct);
            ux.pfill[k] = ux_mix(p->c[i], p->c[i + 1u], pct);
            ux.pacc[k] = ux_mix(p->a[i], p->a[i + 1u], pct);
        }
        ux.psel[k] = ux_mix(ux.bg, ux.pth[k], UI_SEL_PCT);
        ux.ptint[k] = ux_mix(ux.bg, ux.pth[k], UI_TINT_PCT);
        ux.plane[k] = ux_mix(ux.base, ux.pth[k], 10);
    }
    if (ux.bw) {                                 /* MONO: black and white, set, not blended (tools/gen_ui_palettes.py) */
        ux.mid = ux.key = ux.rec = p->text;      /* a selection, a keycap, REC: white, its INK black */
        ux.dim = ux.line = ux.raise = ux.lane = UI_BW_GREY;
        ux.tint = ux.grid = p->bg[0];
        ux.psel[0] = ux.psel[1] = p->text;
        ux.ptint[0] = ux.ptint[1] = p->bg[0];
        ux.plane[0] = ux.plane[1] = UI_BW_GREY;
    }
    /* DUELL 1.1 (owner 2026-10-25, items 65b, 67, 78): a GLOBAL page's colour is the smooth gradient between the palette's two colours (part 1's and part 2's first colour: #DC38FF to #FF1F8E in
     * the violet palette), no third colour: gth is its middle (what a flat fill takes), gacc that lightened toward the text colour; grad_col(x) is the colour at a screen column */
    ux.gth = ux_mix(p->r[0], p->r[2], 50);
    ux.gacc = ux_mix(ux.gth, p->text, 45);
    if (ux.bw)
        ux.gth = ux.gacc = p->text;
    if (ux.glob) {                                      /* a GLOBAL page: the third colour as THEME, SEL, TINT, LANE and its accent (0.2.24) */
        ux.ink = ux_cr(ux.bg, ux.gth) >= ux_cr(p->text, ux.gth) ? ux.bg : p->text;
        ux.theme = ux.gth;
        ux.accent = ux.gacc;
        ux.sel = ux.bw ? p->text : ux_mix(ux.bg, ux.gth, UI_SEL_PCT);
        ux.tint = ux.bw ? p->bg[0] : ux_mix(ux.bg, ux.gth, UI_TINT_PCT);
        ux.lane = ux.bw ? UI_BW_GREY : ux_mix(ux.base, ux.gth, 10);
    } else {
        ux.ink = ux_cr(ux.bg, ux.pth[part]) >= ux_cr(p->text, ux.pth[part]) ? ux.bg : p->text;   /* text on a part-colour fill */
        ux.theme = ux.pth[part];
        ux.accent = ux.pacc[part];
        ux.sel = ux.psel[part];
        ux.tint = ux.ptint[part];
        ux.lane = ux.plane[part];
    }
    if (ux.bw) { ux.tint = p->bg[0]; ux.ink = ux.bg; }
    ux.gen++;                                    /* the text ramps change with the coverage curve and the background */
}
/* the global gradient's colour at screen column x (0 .. 239): part 1's first colour to part 2's first colour; MONO: the text colour */
static uint16_t grad_col(int32_t x)
{
    if (ux.bw)
        return ux.text;
    return ux_mix(ux.pend[0][0], ux.pend[1][0], (x < 0 ? 0 : x > 239 ? 239 : x) * 100 / 239);
}
/* the selected part, the parts' MORPH faders, the layer mode and whether a GLOBAL page is shown (0.2.24) into the theme; 1 if anything changed (redraw all) */
static int theme_follow(uint32_t part, uint32_t f0, uint32_t f1, uint32_t layer, uint32_t glob)
{
    part &= 1u;
    layer = layer != 0u;
    glob = glob != 0u;
    if (part == ux.part && f0 == ux.fader[0] && f1 == ux.fader[1] && layer == ux.layer && glob == ux.glob)
        return 0;
    ux.fader[0] = (uint8_t)f0; ux.fader[1] = (uint8_t)f1; ux.layer = (uint8_t)layer; ux.glob = (uint8_t)glob;
    part_theme(part);
    return 1;
}
static void palette_set(uint32_t i)
{
    const ui_pal_t *p = &UI_PALETTES[i % NPALETTES];
    i %= NPALETTES;
    ux.pal = (uint8_t)i;
    ux.mono = i == UI_GREY_INDEX;
    ux.bw = i == UI_BW_INDEX;
    ux.text = p->text; ux.mid = p->mid; ux.rec = p->rec;
    part_theme(ux.part);
}

/* settings store a tagged id (UI_PAL_TAG + index); an untagged one (the palettes of Felucca's firmware, ids below 20; DUELL 0.2.14 no longer
 * maps them) is the default theme */
static uint32_t palette_from_stored(uint32_t v)
{
    return v >= UI_PAL_TAG && v - UI_PAL_TAG < NPALETTES ? v - UI_PAL_TAG : UI_DEFAULT_INDEX;
}
static uint32_t palette_to_stored(uint32_t i) { return UI_PAL_TAG + i % NPALETTES; }
static int palette_stored_ok(uint32_t v) { return v >= UI_PAL_TAG && v - UI_PAL_TAG < NPALETTES; }

static inline uint16_t swap16(uint32_t c) { return (uint16_t)(((c >> 8) & 0xFFu) | ((c & 0xFFu) << 8)); }

/* ------------------------------------------------------------ canvas --- */
static void cv_begin(uint32_t w, uint32_t h, uint16_t bg)
{
    uint32_t i, n;
    uint16_t s = swap16(bg);
    if (w * h > CV_MAX)
        h = CV_MAX / w;
    lcd_sync();                    /* the last blit may still read cv_px */
    GFX_HOOK_BEGIN();
    cv_w = w;
    cv_h = h;
    cv_cy0 = 0;
    cv_cy1 = (int16_t)h;
    cv_bg = bg;
    n = w * h;
    for (i = 0; i < n; i++)
        cv_px[i] = s;
}

static void cv_blit(uint32_t x, uint32_t y)
{
    GFX_HOOK_BLIT(x, y, 0u);
    lcd_blit(x, y, cv_w, cv_h, cv_px);
}

/* A canvas taller than the buffer holds (2026-11-10, owner yes: the buffer lost 20 rows so that the event step's code fits in RAM): the same
 * drawing runs once per band of at most CV_MAX / w rows, each band blitted below the one before; the screen is the same pixel for pixel.
 * cv_by: the band's first row in the whole canvas (0: the first band, and every canvas that fits). Inside the loop a drawing draws in the
 * whole canvas's rows with its own cv_oy, as without bands (the pixels land at CV_OY), and blits at y + cv_by:
 *   CV_BANDS(w, h, bg) { ...; cv_blit(x, y + cv_by); } */
static uint32_t cv_bw, cv_bh;
static uint16_t cv_bbg;
static uint32_t cv_band_rows(void)
{
    uint32_t r = CV_MAX / cv_bw, left = cv_bh - (uint32_t)cv_by;
    return left < r ? left : r;
}
static int cv_band_first(uint32_t w, uint32_t h, uint16_t bg)
{
    cv_bw = w;
    cv_bh = h;
    cv_bbg = bg;
    cv_by = 0;
    cv_begin(w, cv_band_rows(), bg);
    return 1;
}
static int cv_band_next(void)
{
    cv_by += (int32_t)cv_h;
    if ((uint32_t)cv_by >= cv_bh) {
        cv_by = 0;
        cv_bh = 0;
        return 0;
    }
    cv_begin(cv_bw, cv_band_rows(), cv_bbg);
    return 1;
}
#define CV_FULL_H (cv_bh ? cv_bh : cv_h)         /* the whole canvas's rows (a drawing that centres on the canvas: graph_scope) */
#define CV_BANDS(w, h, bg) for (int cv_b_ = cv_band_first((w), (h), (bg)); cv_b_; cv_b_ = cv_band_next())

static inline void cv_pset(int32_t x, int32_t y, uint16_t c)
{
    y += CV_OY;
    if ((uint32_t)x < cv_w && (uint32_t)y < cv_h)
        cv_px[(uint32_t)y * cv_w + (uint32_t)x] = swap16(c);
}

static void cv_rect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c)
{
    int32_t x1 = x + w, y1 = y + h + CV_OY, i;
    uint16_t sc = swap16(c);
    y += CV_OY;                             /* clipped once, then filled row by row */
    if (x < 0)
        x = 0;
    if (y < 0)
        y = 0;
    if (x1 > (int32_t)cv_w)
        x1 = (int32_t)cv_w;
    if (y1 > (int32_t)cv_h)
        y1 = (int32_t)cv_h;
    for (; y < y1; y++)
        for (i = x; i < x1; i++)
            cv_px[(uint32_t)y * cv_w + (uint32_t)i] = sc;
}

/* a 1 px outline */
static void cv_frame(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c)
{
    cv_rect(x, y, w, 1, c);
    cv_rect(x, y + h - 1, w, 1, c);
    cv_rect(x, y, 1, h, c);
    cv_rect(x + w - 1, y, 1, h, c);
}

static void cv_line(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c)
{
    int32_t dx = x1 > x0 ? x1 - x0 : x0 - x1, sx = x0 < x1 ? 1 : -1;
    int32_t dy = y1 > y0 ? y0 - y1 : y1 - y0, sy = y0 < y1 ? 1 : -1;
    int32_t err = dx + dy, guard = 2000;
    while (guard--) {                       /* bounded: a line is never longer than 480 px */
        int32_t e2 = 2 * err;               /* both tests use the same error value */
        cv_pset(x0, y0, c);
        if (x0 == x1 && y0 == y1)
            break;
        if (e2 >= dy) {
            err += dy;
            x0 += sx;
        }
        if (e2 <= dx) {
            err += dx;
            y0 += sy;
        }
    }
}

/* a line `thick` px tall (the scope's trace: 2) */
static void cv_line_t(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c, int32_t thick)
{
    int32_t t;
    for (t = 0; t < thick; t++)
        cv_line(x0, y0 + t, x1, y1 + t, c);
}

/* coverage (0..16) of corner pixel (i, j) of a radius-r corner, (0, 0) the outermost: 4 x 4 samples */
static uint32_t rr_cov(int32_t r, int32_t i, int32_t j)
{
    int32_t sx, sy, n = 0;
    for (sy = 0; sy < 4; sy++)
        for (sx = 0; sx < 4; sx++) {
            int32_t dx = r * 8 - ((i * 4 + sx) * 2 + 1), dy = r * 8 - ((j * 4 + sy) * 2 + 1);   /* 1/8 px */
            n += dx * dx + dy * dy <= r * r * 64;
        }
    return (uint32_t)n;
}
/* a filled rectangle with rounded corners (r <= 8), the corners anti-aliased against `under` (what lies
 * behind it): the flat look's cards, panels, rows, bars and buttons */
static void cv_rrect(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c, uint16_t under)
{
    int32_t i, j;
    GFX_HOOK_CELL(x, y + cv_oy, x + w, y + h + cv_oy);   /* (the lint: what is drawn on it stays inside it) */
    if (r < 0) r = -r;                           /* (-r: rounded in every style: a keycap-like cushion) */
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    if (r < 1) {
        cv_rect(x, y, w, h, c);
        return;
    }
    cv_rect(x + r, y, w - 2 * r, h, c);
    cv_rect(x, y + r, r, h - 2 * r, c);
    cv_rect(x + w - r, y + r, r, h - 2 * r, c);
    for (j = 0; j < r; j++)
        for (i = 0; i < r; i++) {
            uint32_t a = rr_cov(r, i, j);
            uint16_t px = a >= 16u ? c : a == 0u ? under : ux_mix(under, c, (int32_t)(a * 100u / 16u));
            cv_pset(x + i, y + j, px);
            cv_pset(x + w - 1 - i, y + j, px);
            cv_pset(x + i, y + h - 1 - j, px);
            cv_pset(x + w - 1 - i, y + h - 1 - j, px);
        }
}

/* the template-1 card (item 114, ui_tokens.h UT_CARD_CORNER_*): a filled rectangle with HARD corners as the design pictures draw them (row 0 loses 2 px at each end, row 1 loses 1, no anti-aliasing);
 * `under` is what lies behind it. The graph area's card and the four cards of a part page */
static void cv_card(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c, uint16_t under)
{
    GFX_HOOK_CELL(x, y + cv_oy, x + w, y + h + cv_oy);
    cv_rect(x, y, w, h, c);
    cv_rect(x, y, UT_CARD_CORNER_A, 1, under);
    cv_rect(x + w - UT_CARD_CORNER_A, y, UT_CARD_CORNER_A, 1, under);
    cv_rect(x, y + h - 1, UT_CARD_CORNER_A, 1, under);
    cv_rect(x + w - UT_CARD_CORNER_A, y + h - 1, UT_CARD_CORNER_A, 1, under);
    cv_rect(x, y + 1, UT_CARD_CORNER_B, 1, under);
    cv_rect(x + w - UT_CARD_CORNER_B, y + 1, UT_CARD_CORNER_B, 1, under);
    cv_rect(x, y + h - 2, UT_CARD_CORNER_B, 1, under);
    cv_rect(x + w - UT_CARD_CORNER_B, y + h - 2, UT_CARD_CORNER_B, 1, under);
}

/* ------------------------------------------------- 4-bit alpha blit --- */
/* coverage curves: a little heavier for light ink on dark, lighter for dark ink on light */
static const uint8_t CURVE_DARK[16] = {0, 24, 43, 62, 80, 97, 114, 130, 147, 163, 178, 194, 210, 225, 240, 255};
static const uint8_t CURVE_LIGHT[16] = {0, 12, 27, 42, 58, 75, 91, 109, 126, 144, 162, 180, 199, 217, 236, 255};
#define NRAMP 6u
static struct {
    uint16_t fg[NRAMP], bg[NRAMP], v[NRAMP][16];   /* v: byte-swapped panel values */
    uint32_t gen;
    uint8_t next, n;
} rc;

static const uint16_t *ramp(uint16_t fg, uint16_t bg)
{
    static const uint8_t SH[3] = {11, 5, 0}, MK[3] = {31, 63, 31};
    const uint8_t *cv = ux.light ? CURVE_LIGHT : CURVE_DARK;
    uint32_t i, a, k;
    uint16_t *v;
    if (fg == bg)                                /* MONO: DIM on a RAISE well (one grey): black, recessed */
        fg = ux.bg;
    GFX_HOOK_INK(fg, bg);
    if (rc.gen != ux.gen) {
        rc.gen = ux.gen;
        rc.n = rc.next = 0;
    }
    for (i = 0; i < rc.n; i++)
        if (rc.fg[i] == fg && rc.bg[i] == bg)
            return rc.v[i];
    i = rc.next;
    rc.next = (uint8_t)((i + 1u) % NRAMP);
    if (rc.n < NRAMP)
        rc.n++;
    rc.fg[i] = fg;
    rc.bg[i] = bg;
    v = rc.v[i];
    for (a = 0; a < 16u; a++) {
        uint32_t out = 0;
        int32_t w = cv[a];
        if (ux.mono) {
            int32_t x = bg >> 11;
            out = ux_gray((uint32_t)(x + ((((fg >> 11) - x) * w + 128) >> 8)));
        } else {
            for (k = 0; k < 3u; k++) {
                int32_t x = (bg >> SH[k]) & MK[k], y = (fg >> SH[k]) & MK[k];
                out |= (uint32_t)(x + (((y - x) * w + 128) >> 8)) << SH[k];
            }
        }
        v[a] = swap16(out);
    }
    return v;
}

/* the 16 panel values of the LINEAR ramp bg -> fg (coverage n / 15: the design pictures' text and battery; ramp's curve is a little heavier) into v (byte-swapped), no cache: the caller's
 * own array (the stack), so it costs no RAM */
static void ramp_lin(uint16_t *v, uint16_t fg, uint16_t bg)
{
    static const uint8_t SH[3] = {11, 5, 0}, MK[3] = {31, 63, 31};
    uint32_t a, k;
    if (fg == bg)
        fg = ux.bg;
    GFX_HOOK_INK(fg, bg);
    for (a = 0; a < 16u; a++) {
        uint32_t out = 0;
        int32_t w = (int32_t)a * 17;
        if (ux.mono) {
            int32_t x = bg >> 11;
            out = ux_gray((uint32_t)(x + ((((fg >> 11) - x) * w + 128) >> 8)));
        } else {
            for (k = 0; k < 3u; k++) {
                int32_t x = (bg >> SH[k]) & MK[k], y = (fg >> SH[k]) & MK[k];
                out |= (uint32_t)(x + (((y - x) * w + 128) >> 8)) << SH[k];
            }
        }
        v[a] = swap16(out);
    }
}

/* w x h nibbles, rows back to back, at canvas (x, y) */
static void cv_alpha(int32_t x, int32_t y, uint32_t w, uint32_t h, const uint8_t *d, const uint16_t *rv)
{
    uint32_t k = 0, gx, gy;
    y += CV_OY;
    for (gy = 0; gy < h; gy++) {
        int32_t py = y + (int32_t)gy;
        uint16_t *row;
        if (py < cv_cy0 || py >= cv_cy1) {
            k += w;
            continue;
        }
        row = cv_px + (uint32_t)py * cv_w;
        for (gx = 0; gx < w; gx++, k++) {
            uint32_t v = (d[k >> 1] >> ((k & 1u) ? 0 : 4)) & 15u;
            int32_t px = x + (int32_t)gx;
            if (v && (uint32_t)px < cv_w)
                row[px] = rv[v];
        }
    }
    GFX_HOOK_PIXELS(w * h);
}

/* the same from a glyph's Huffman-coded bit stream (tools/gen_aa_font.py huff_pack): canonical codes, MSB
 * first; hc = the number of codes of each length 1..15, then the symbols in code order, each a value and
 * its repeat count ((count - 1) << 4 | value: runs of zeros and 15s). Codes of up to 8 bits come from a
 * 256-entry table made once per font in RAM (symbol | length << 8; 0 = a longer code: bit by bit). The
 * stream is read in order, so rows outside the clip are decoded and dropped; a run spans rows */
#define HC_FONTS 3                       /* the codes: the faces M and L (gen_aa_font.py HUFF), the icons (AI_HC) */
static struct { const uint8_t *hc; uint16_t lut[256]; } hc_tab[HC_FONTS] __attribute__((unused));
static const uint16_t *hc_lut(const uint8_t *hc)
{
    uint32_t k, len, code = 0, sym = 15, i;
    for (k = 0; k < HC_FONTS - 1u && hc_tab[k].hc && hc_tab[k].hc != hc; k++)
        ;
    if (hc_tab[k].hc != hc) {                        /* (more fonts than slots: the last slot is rebuilt) */
        hc_tab[k].hc = hc;
        for (i = 0; i < 256u; i++)
            hc_tab[k].lut[i] = 0;
        for (len = 1; len <= 8u; len++, code <<= 1)
            for (i = 0; i < hc[len - 1u]; i++, code++, sym++) {
                uint32_t a = code << (8u - len), n = 1u << (8u - len);
                while (n--)
                    hc_tab[k].lut[a + n] = (uint16_t)(hc[sym] | len << 8);
            }
    }
    return hc_tab[k].lut;
}

static void cv_alpha_hc(int32_t x, int32_t y, uint32_t w, uint32_t h, const uint8_t *d, const uint8_t *hc,
                        const uint16_t *rv)
{
    const uint16_t *lut = hc_lut(hc);
    uint32_t gy, v = 0, run = 0, acc = 0, nb = 0;
    y += CV_OY;
    for (gy = 0; gy < h; gy++) {
        int32_t py = y + (int32_t)gy;
        uint16_t *row = py < cv_cy0 || py >= cv_cy1 ? 0 : cv_px + (uint32_t)py * cv_w;
        uint32_t gx = 0;
        while (gx < w) {
            uint32_t n;
            if (!run) {                              /* the next symbol */
                uint32_t e, s;
                while (nb < 16u) {                   /* (the data ends with 2 spare bytes) */
                    acc = acc << 8 | *d++;
                    nb += 8;
                }
                e = lut[(acc >> (nb - 8u)) & 255u];
                if (e) {
                    nb -= e >> 8;
                    s = e & 255u;
                } else {                             /* a code over 8 bits */
                    uint32_t code = 0, first = 0, idx = 0, len = 0;
                    for (;;) {
                        code |= (acc >> --nb) & 1u;
                        if (code - first < hc[len])
                            break;
                        idx += hc[len];
                        first = (first + hc[len]) << 1;
                        code <<= 1;
                        len++;
                    }
                    s = hc[15u + idx + code - first];
                }
                v = s & 15u;
                run = (s >> 4) + 1u;
            }
            n = run < w - gx ? run : w - gx;
            if (v && row) {
                int32_t px = cv_flip ? x + (int32_t)(w - 1u - gx) : x + (int32_t)gx, dx = cv_flip ? -1 : 1;
                uint32_t k;
                for (k = 0; k < n; k++, px += dx)
                    if ((uint32_t)px < cv_w)
                        row[px] = rv[v];
            }
            gx += n;
            run -= n;
        }
    }
    GFX_HOOK_PIXELS(w * h);
}

/* ------------------------------------------------------------- text --- */
/* the glyph number of ch in f, -1 = not in the face */
static int32_t glyph_at(const aafont_t *f, uint32_t ch)
{
    uint32_t i;
    if (ch >= f->first && ch <= f->last)
        return (int32_t)(ch - f->first);
    for (i = 0; i < f->nex; i++)
        if (f->ex[i] == ch)
            return (int32_t)(f->last - f->first + 1u + i);
    return -1;
}

/* the table entry of ch at phase 0 (its other phases follow it). Not in the face: the ellipsis as '.',
 * else '?', else the face's first glyph (D, N, X, B are figures only: their space) */
static uint32_t glyph(const aafont_t *f, uint32_t ch)
{
    int32_t k;
    if (ch >= 'a' && ch <= 'z' && f->last < 'a')
        ch -= 32u;                                   /* a capitals-only face (T) */
    if ((k = glyph_at(f, ch)) < 0 && (ch != (uint8_t)ELLIPSIS || (k = glyph_at(f, '.')) < 0) &&
        (k = glyph_at(f, '?')) < 0)
        k = 0;
    return (uint32_t)k << f->psh;
}

static int32_t kern(const aafont_t *f, uint32_t a, uint32_t b)       /* 1/16 px */
{
    uint32_t key = (a << 8) | b, lo = 0, hi = f->nk;
    while (lo < hi) {
        uint32_t m = (lo + hi) / 2u;
        if (f->kkey[m] == key)
            return f->kd[m];
        if (f->kkey[m] < key)
            lo = m + 1u;
        else
            hi = m;
    }
    return 0;
}

static uint32_t fold(const aafont_t *f, uint32_t c) { return c >= 'a' && c <= 'z' && f->last < 'a' ? c - 32u : c; }

static int32_t text_w16(const aafont_t *f, const char *s)   /* the advance, 1/16 px (kerning included): for placing a text on a fraction of a pixel */
{
    int32_t pen = 0;
    uint32_t prev = 0;
    for (; *s; s++) {
        uint32_t c = fold(f, (uint8_t)*s);
        if (prev)
            pen += kern(f, prev, c);
        pen += f->g[glyph(f, c)].adv;
        prev = c;
    }
    return pen;
}

static int32_t text_w(const aafont_t *f, const char *s)
{
    int32_t pen = 0;
    uint32_t prev = 0;
    for (; *s; s++) {
        uint32_t c = fold(f, (uint8_t)*s);
        if (prev)
            pen += kern(f, prev, c);
        pen += f->g[glyph(f, c)].adv;
        prev = c;
    }
    return (pen + 8) >> 4;
}

static const uint16_t *text_rv;                      /* cv_text_x16: its linear ramp (on its caller's stack) while it draws, else 0: ramp() */
static uint8_t text_exact;                           /* cv_text_x16: the design pictures' placement: every glyph on the phase nearest its own pen (a tie to the even phase), no memory of the glyph before */
static int32_t text_trk;                             /* item 158: added to every glyph's advance, 1/16 px (0, or negative: a card label tightened to fit its card, ui_draw.c lbl_trk) */
static int32_t text_pen0;                            /* the pen the next text_run starts at, 1/16 px (0 .. 15: cv_text_x16's fraction; every other caller: 0) */
static int32_t text_run(int32_t x, int32_t y, const aafont_t *f, const char *s, const uint16_t *rv, int32_t *bb)
{
    int32_t pen = text_pen0, err = 0, x0 = 0x7FFF, y0 = 0x7FFF, x1 = -0x7FFF, y1 = -0x7FFF;
    const int32_t step = 16 >> f->psh;
    uint32_t prev = 0;
    for (; *s; s++) {
        uint32_t c = fold(f, (uint8_t)*s);
        const aag_t *g;
        int32_t pos, d0, d1;
        if (prev)
            pen += kern(f, prev, c);
        g = &f->g[glyph(f, c)];
        if (text_exact) {                            /* (the header / footer words, ui_tokens.h: as the pictures set them: round, half to even, per glyph) */
            int32_t st = f->psh && g[1].off != g->off ? step : 16, q = pen / st, rm = pen - q * st;
            if (rm * 2 > st || (rm * 2 == st && (q & 1)))
                q++;
            pos = q * st;
            if (st != 16)
                g += ((uint32_t)pos >> (4u - f->psh)) & ((1u << f->psh) - 1u);
        } else if (f->psh && g[1].off != g->off) {
            pos = pen - (pen & (step - 1));          /* the phase position at or left of the pen */
            d0 = pos - pen - err;                    /* .. and the one right of it: which keeps the gap truer */
            d1 = d0 + step;
            if ((d0 < 0 ? -d0 : d0) > (d1 < 0 ? -d1 : d1))
                pos += step;
            g += ((uint32_t)pos >> (4u - f->psh)) & ((1u << f->psh) - 1u);
        } else {
            pos = (pen + 8) & ~15;                   /* one phase (figures, ., blanks): the rounded pen */
        }
        err = pos - pen;
        if (g->bw) {
            int32_t gx = x + (pos >> 4) + g->bx, gy = y + g->by;
            if (!rv)
                ;                                    /* (text_ink: measured only) */
            else if (f->hc)
                cv_alpha_hc(gx, gy, g->bw, g->bh, f->data + g->off, f->hc, rv);
            else
                cv_alpha(gx, gy, g->bw, g->bh, f->data + g->off, rv);
            if (gx < x0) x0 = gx;
            if (gx + g->bw > x1) x1 = gx + g->bw;
            if (GFX_HOOKS && gy < y0) y0 = gy;       /* (the rows: for the host's lint only) */
            if (GFX_HOOKS && gy + g->bh > y1) y1 = gy + g->bh;
        }
        pen += g->adv + text_trk;
        prev = c;
    }
    bb[0] = x0;
    bb[2] = x1;
    if (GFX_HOOKS) {
        bb[1] = y0;
        bb[3] = y1;
    }
    return pen;
}
/* y = top of the line box (the baseline is y + f->asc); returns the pen x at the end.
 * fg on bg: bg is what lies under the text (the canvas, a card, a selection).
 * Placement (text_run): the pen (1/16 px) lies between two phase positions a step (16 >> psh) apart; the glyph takes
 * the one whose offset from the pen is nearer the previous glyph's offset, so the space between neighbours stays
 * truest and no glyph is a whole step from its true place (tools/aa_raster.py, text_spacing_test.py).
 * A glyph with one phase (its phases share one bitmap: figures and .) sits at the rounded pen, as when it
 * is drawn alone at text_w of what precedes it (ui_draw.c roll_text). */
static int32_t cv_text_flags(int32_t x, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg,
                             uint32_t flags)
{
    int32_t b[4], pen = text_run(x, y, f, s, text_rv ? text_rv : ramp(fg, bg), b);
    if (GFX_HOOKS && b[2] > b[0]) {
        int32_t y0 = b[1], y1 = b[3];
        if (b[0] < 0 || b[2] > (int32_t)cv_w || y0 + cv_oy < cv_cy0 || y1 + cv_oy > cv_cy1)
            flags |= 2u;                             /* cut by the canvas */
        if (cv_scroll) {                             /* a scrolled view: what lands on the screen is its visible part */
            flags |= 32u;
            if (y0 + cv_oy < cv_cy0) y0 = cv_cy0 - cv_oy;
            if (y1 + cv_oy > cv_cy1) y1 = cv_cy1 - cv_oy;
        }
        GFX_HOOK_PEN(y, f);
        GFX_HOOK_TEXT(b[0], y0 + cv_oy, b[2], y1 + cv_oy, s, flags);
    }
    (void)flags;
    return x + ((pen + 8) >> 4);
}
/* DUELL 1.4: the words a screen draws, for the screen reader (ui_speak.c): while gfx_said is set, cv_text_on and cv_keycap add what they
 * draw to it (gfx_said_max bytes), each text an item (". " before it; a space after a keycap, a ':' or a ','). Set around one drawing pass only
 * (ui_guide.c guide_draw); a caller that draws one sentence in pieces adds it whole and clears gfx_said around the pieces */
static char *gfx_said;
static uint32_t gfx_said_max;
static uint8_t gfx_said_glue;                          /* the next item joins with a space (it follows a keycap: "HOME SKIP") */
static void gfx_said_add(const char *s)
{
    uint32_t n = 0;
    while (gfx_said[n])
        n++;
    if (n && !gfx_said_glue && gfx_said[n - 1u] != ':' && gfx_said[n - 1u] != ',' && n + 2u < gfx_said_max)
        gfx_said[n++] = '.';
    if (n && n + 1u < gfx_said_max)
        gfx_said[n++] = ' ';
    gfx_said_glue = 0;
    while (*s && n + 1u < gfx_said_max)
        gfx_said[n++] = *s++;
    gfx_said[n] = 0;
}
static int32_t cv_text_on(int32_t x, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg)
{
    if (gfx_said)
        gfx_said_add(s);
    return cv_text_flags(x, y, f, s, fg, bg, 0);
}
/* a text whose pen starts at x16 / 16 px (the header's centred title, the capsules' letters, the footer's words: the design pictures place them on a fraction of a pixel; the glyph
 * phases take it up, text_run); returns the pen x at the end (whole px) */
static int32_t cv_text_x16(int32_t x16, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg)
{
    int32_t r;
    uint16_t v[16];
    ramp_lin(v, fg, bg);
    text_rv = v;
    text_pen0 = x16 & 15;
    text_exact = 1;
    r = cv_text_flags(x16 >> 4, y, f, s, fg, bg, 0);
    text_exact = 0;
    text_pen0 = 0;
    text_rv = 0;
    return r;
}
/* .. on the canvas background */
static int32_t cv_text(int32_t x, int32_t y, const aafont_t *f, const char *s, uint16_t fg)
{
    return cv_text_flags(x, y, f, s, fg, cv_bg, 0);
}
/* a text in the global gradient: each character in the colour of its own screen column (x0 = the screen column of x, for a canvas that sits elsewhere); the pens are the string's own
 * (the width of the prefix up to the character, kerning with its left neighbour included) */
static int32_t cv_text_grad(int32_t x, int32_t y, const aafont_t *f, const char *s, int32_t x0)
{
    char pre[48], ch[2] = {0, 0};
    uint32_t i;
    if (ux.bw)
        return cv_text(x, y, f, s, ux.text);
    for (i = 0; s[i] && i + 1u < sizeof pre; i++) {
        int32_t px;
        pre[i] = s[i];
        pre[i + 1u] = 0;
        ch[0] = s[i];
        px = x + text_w(f, pre) - text_w(f, ch);
        cv_text(px, y, f, ch, grad_col(x0 + (px - x) + text_w(f, ch) / 2));
    }
    return x + text_w(f, s);
}
/* a page TITLE in the global gradient. POLICE: (a) the title plain white, the gradient on the rule, the bars and the values (owner 2026-10-25, the default); (b) the gradient on the title too: set POLICE_TITLE_PLAIN to 0 (the one line to change) */
#define POLICE_TITLE_PLAIN 1
static int32_t cv_text_title(int32_t x, int32_t y, const aafont_t *f, const char *s, int32_t x0)
{
    if (POLICE_TITLE_PLAIN && str_eq(UI_PALETTES[ux.pal % NPALETTES].name, "POLICE"))
        return cv_text(x, y, f, s, ux.text);
    return cv_text_grad(x, y, f, s, x0);
}
/* a horizontal rule or bar in the global gradient: 6 px slices, each its own colour (x0: the screen column of x) */
static void cv_rect_grad(int32_t x, int32_t y, int32_t w, int32_t h, int32_t x0)
{
    int32_t i, n;
    for (i = 0; i < w; i += 6) {
        n = w - i < 6 ? w - i : 6;
        cv_rect(x + i, y, n, h, grad_col(x0 + i + n / 2));
    }
}
/* right-aligned: the advance ends at xr */
static int32_t cv_text_r(int32_t xr, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg)
{
    int32_t w = text_w(f, s);
    cv_text_on(xr - w, y, f, s, fg, bg);
    return xr - w;
}
/* (centred: cv_text_in, by the ink; by the advance a text sat up to 1.5 px off) */

/* centring by ink: the ink of s in f drawn at (0, 0) across (b[0] .. b[2], past it; b[2] <= b[0]: none); up and down
 * a text is centred by its face's capitals' band (AF_S_CAP_Y ..: the ink of H; figures and round letters reach at most
 * a faint row past it), so the words of a row keep one baseline */
static void text_ink(const aafont_t *f, const char *s, int32_t *b) { text_run(0, 0, f, s, 0, b); }
#define HALF_UP(v) ((v) >> 1)                       /* half, a pixel left over going left / up (also below 0) */
/* the line top that centres face F's (S M) capitals' band in h rows (a row, a cell, a button): constant */
#define CAP_IN(F, h) (HALF_UP((h) - AF_##F##_CAP_H) - AF_##F##_CAP_Y)
/* the pen x that centres s's ink in w px */
static int32_t ink_in(const aafont_t *f, const char *s, int32_t w)
{
    int32_t b[4];
    text_ink(f, s, b);
    return HALF_UP(w - (b[2] - b[0])) - b[0];
}
/* s with its ink centred across x0 .. x0 + w (y: its line top, CAP_IN to centre it up and down too); a pixel left
 * over goes left / up, as everywhere (the cushions too) */
static int32_t cv_text_in(int32_t x0, int32_t y, int32_t w, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg)
{
    return cv_text_on(x0 + ink_in(f, s, w), y, f, s, fg, bg);
}

/* s into d (n bytes), at most maxw px wide: never a smaller font, the end ellipsised. 1 = cut */
static int text_fit(char *d, uint32_t n, const char *s, const aafont_t *f, int32_t maxw)
{
    uint32_t k = 0;
    while (s[k] && k + 1u < n) {
        d[k] = s[k];
        k++;
    }
    d[k] = 0;
    if (!s[k] && text_w(f, d) <= maxw)
        return 0;
    if (k + 2u > n)
        k = n - 2u;
    for (;;) {                                       /* drop characters until "text..." fits */
        while (k && d[k - 1u] == ' ')
            k--;
        d[k] = ELLIPSIS;
        d[k + 1u] = 0;
        if (!k || text_w(f, d) <= maxw)
            return 1;
        k--;
    }
}
/* text in maxw px, ellipsised when it is longer: a label or a value should always fit (the host
 * layout lint reports a cut one), free text (cv_free_text: a preset name, a message) may be cut */
static int32_t cv_text_fit(int32_t x, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg,
                           int32_t maxw)
{
    char b[48];
    int cut = text_fit(b, sizeof b, s, f, maxw);
    return cv_text_flags(x, y, f, b, fg, bg, cut ? 1u : 0u);
}
static int32_t cv_free_text(int32_t x, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg,
                            int32_t maxw)
{
    char b[48];
    int cut = text_fit(b, sizeof b, s, f, maxw);
    return cv_text_flags(x, y, f, b, fg, bg, cut ? 9u : 8u);
}

/* ---------------------------------------------------------- keycaps --- */
/* a pre-rendered pill (tools/gen_aa_keycaps.py): nibble 0 outside, 1..4 the edge over `under`, 5 the fill,
 * 6..15 the label over the fill; the 16 colours per (under, fill, ink) are cached like the text ramps */
#define NKRAMP 4u
static struct {
    uint16_t key[NKRAMP][3], v[NKRAMP][16];
    uint32_t gen;
    uint8_t next, n;
} kr __attribute__((unused));      /* (zero-initialised; outside .bss) */
static const uint16_t *kc_ramp(uint16_t under, uint16_t fill, uint16_t ink)
{
    uint32_t i, a;
    uint16_t *v;
    if (ink == fill)                             /* (as ramp) */
        ink = ux.bg;
    GFX_HOOK_INK(ink, fill);
    if (kr.gen != ux.gen) {
        kr.gen = ux.gen;
        kr.n = kr.next = 0;
    }
    for (i = 0; i < kr.n; i++)
        if (kr.key[i][0] == under && kr.key[i][1] == fill && kr.key[i][2] == ink)
            return kr.v[i];
    i = kr.next;
    kr.next = (uint8_t)((i + 1u) % NKRAMP);
    if (kr.n < NKRAMP)
        kr.n++;
    kr.key[i][0] = under;
    kr.key[i][1] = fill;
    kr.key[i][2] = ink;
    v = kr.v[i];
    v[0] = swap16(under);
    for (a = 1; a < 16u; a++) {
        int32_t p = a < 5u ? (int32_t)a * 20 : (int32_t)(a - 5u) * 10;
        v[a] = swap16(a < 5u ? ux_mix(under, fill, p) : ux_mix(fill, ink, p));
    }
    return v;
}
#define KC_IS_KNOB(id) ((id) >= KC_K1 && (id) <= KC_K4)       /* DUELL 1.1: the knob legends are the numbered white dot of the pages, not a keycap */
static int32_t kc_w(uint32_t id) { return KC_IS_KNOB(id) ? 12 : id < KC_COUNT ? KC[id].w : 0; }
/* keycap / badge `id` with its top-left at (x, y), KC_H tall: fill and label tinted with tokens, `under` what lies
 * behind its corners; returns its right edge */
static int32_t cv_keycap(int32_t x, int32_t y, uint32_t id, uint16_t fill, uint16_t ink, uint16_t under)
{
    const kc_t *k = &KC[id < KC_COUNT ? id : 0u];
    const uint16_t *rv;
    char *said = gfx_said;                                                 /* (DUELL 1.4: the screen reader's words: the key's name, then its word joined;
                                                                            *  nothing drawn inside the cap, the knob's digit, is added) */
    if (said) {
        static const char *const KNOB_SAID[4] = {"KNOB 1", "KNOB 2", "KNOB 3", "KNOB 4"};
        gfx_said_add(KC_IS_KNOB(id) ? KNOB_SAID[id - KC_K1] : k->label);
        gfx_said_glue = 1;
        gfx_said = 0;
    }
    if (KC_IS_KNOB(id)) {                                                  /* the numbered dot: 1 .. 4 */
        char d[2] = {(char)('1' + (id - KC_K1)), 0};
        y += (KC_H - 11) / 2;                                              /* DUELL 1.3 (owner 2026-11-13: the dot sat 1 px above its word): centred on the pill's KC_H rows, as the word is */
        cv_rrect(x, y, 11, 11, 5, T_TEXT, under);
        cv_text_in(x, y + HALF_UP(11 - AF_D_CAP_H) - AF_D_CAP_Y, 11, &AF_DOT, d, T_BG, T_TEXT);
        gfx_said = said;
        return x + 12;
    }
    rv = kc_ramp(under, fill, ink);
    cv_alpha(x, y, k->w, KC_H, KC_DATA + k->off, rv);
    if (x < 0 || x + k->w > (int32_t)cv_w || y + cv_oy < 0 || y + KC_H + cv_oy > (int32_t)cv_h)
        GFX_HOOK_TEXT(x, y + cv_oy, x + k->w, y + KC_H + cv_oy, k->label, 6u);      /* cut by the canvas */
    else
        GFX_HOOK_TEXT(x, y + cv_oy, x + k->w, y + KC_H + cv_oy, k->label, 4u);
    gfx_said = said;
    return x + k->w;
}

/* a key hint: the keycap, then what it does (S, TEXT); unavailable: a DIM keycap and a DIM word. The word sits on
 * the keycap's centre line (item 122: S 15's 11 capital rows centred on the pill's 13: the word's line top is 3 rows above the pill's). act may be 0 (the keycap alone); returns the end x */
#define KH_GAP 4                                  /* keycap -> its word */
static int32_t kh_w(uint32_t id, const char *act) { return kc_w(id) + (act && act[0] ? KH_GAP + text_w(&AF_S, act) : 0); }
/* .. its ink: the keycap to the word's last inked column (centring a hint by what is seen) */
static int32_t kh_ink(uint32_t id, const char *act)
{
    int32_t b[4];
    if (!act || !act[0])
        return kc_w(id);
    text_ink(&AF_S, act, b);
    return kc_w(id) + KH_GAP + b[2];
}
static int32_t cv_key_hint(int32_t x, int32_t y, uint32_t id, const char *act, int on, uint16_t under)
{
    x = cv_keycap(x, y, id, on ? T_KEY : T_DIM, T_KINK, under);
    if (act && act[0]) {
        GFX_HOOK_ALIGN(0, y, 0, y + KC_H, AL_V | AL_PASS, "key hint word on its keycap's line");
        x = cv_text_on(x + KH_GAP, y - 3, &AF_S, act, on ? T_TEXT : T_DIM, under);   /* item 122: the word's capitals are centred on the pill's rows (S 15: 11 capital rows, the pill 13: the word's line top 3 rows above the pill's, was 1) */
    }
    return x;
}
/* a row of key hints from x0 to x1: the first at x0, the last ending at x1, the space shared between them. When
 * the row is too wide the action words go first, from the last hint back (the keycaps never shrink).
 * on: a bit per hint (1 = available) */
typedef struct { uint8_t key; const char *act; } khint_t;
static void cv_key_row(int32_t x0, int32_t x1, int32_t y, const khint_t *h, uint32_t n, uint32_t on, uint16_t under)
{
    uint32_t i, words = n;                         /* hints 0 .. words-1 keep their word */
    int32_t w, gap, x = x0;
    for (;;) {
        w = 0;
        for (i = 0; i < n; i++)
            w += kh_w(h[i].key, i < words ? h[i].act : 0);
        if (w + 6 * (int32_t)(n - 1u) <= x1 - x0 || !words)
            break;
        words--;
    }
    gap = n > 1u ? (x1 - x0 - w) / (int32_t)(n - 1u) : 0;
    for (i = 0; i < n; i++) {
        if (n > 1u && i + 1u == n)
            x = x1 - kh_w(h[i].key, i < words ? h[i].act : 0);   /* the last one flush right */
        x = cv_key_hint(x, y, h[i].key, i < words ? h[i].act : 0, (on >> i) & 1u, under) + gap;
    }
}

/* "[OCT+]..." -> the keycap's id and the length of the bracket, else -1 (a bracketed word that is no keycap is text) */
static int32_t kc_tag(const char *s, uint32_t *len)
{
    uint32_t i, n;
    if (s[0] != '[')
        return -1;
    for (n = 1; s[n] && s[n] != ']'; n++)
        if (n > 8u)
            return -1;
    if (s[n] != ']')
        return -1;
    for (i = 0; i < KC_COUNT; i++) {
        const char *l = KC[i].label;
        uint32_t k = 0;
        while (k + 1u < n && l[k] == s[k + 1u])
            k++;
        if (k + 1u == n && !l[k]) {
            *len = n + 1u;
            return (int32_t)i;
        }
    }
    return -1;
}
/* free text (S) with ONE keycap tag anywhere in it: "[SAVE] HOLD TO UNDO", "HOLD [GLO] QUICK", "HOLD A NOTE + [OCT+], TURN A KNOB" (item 124: any words before it): the words before, the keycap
 * (its centre on the capitals' centre, y + 3), a mark right after it ("," ".") with no gap, then the rest, cut to maxw. A keycap that does not fit leaves the text as it is, plain */
static int32_t cv_free_hint(int32_t x, int32_t y, const char *s, uint16_t fg, uint16_t bg, int32_t maxw)
{
    uint32_t n = 0, p;
    int32_t id = -1, x0 = x;
    for (p = 0; s[p]; p++)
        if (s[p] == '[' && (id = kc_tag(s + p, &n)) >= 0)
            break;
    if (id >= 0 && p) {
        char w[48];
        uint32_t j, e = p;
        while (e && s[e - 1u] == ' ')
            e--;
        for (j = 0; j < e && j + 1u < sizeof w; j++)
            w[j] = s[j];
        w[j] = 0;
        GFX_HOOK_ALIGN(0, y + 3, 0, y + 3 + KC_H, AL_V | AL_PASS, "free hint words on the keycap's line");
        x = cv_text_on(x, y, &AF_S, w, fg, bg) + KH_GAP;
        s += p;
    }
    if (id >= 0 && kc_w((uint32_t)id) + KH_GAP < maxw - (x - x0)) {
        x = cv_keycap(x, y + 3, (uint32_t)id, T_KEY, T_KINK, bg);
        s += n;
        if (*s != ',' && *s != '.' && *s != ':' && *s != ';')
            x += KH_GAP;
        while (*s == ' ')
            s++;
        if (!*s)
            return x - KH_GAP;
        GFX_HOOK_ALIGN(0, y + 3, 0, y + 3 + KC_H, AL_V | AL_PASS, "free hint words on the keycap's line");
    }
    return cv_free_text(x, y, &AF_S, s, fg, bg, maxw - (x - x0));
}

/* one-shot: a line of text in a box of colour bg, blitted (align: 0 left, 1 centre, 2 right) */
static void draw_text_line(uint32_t x, uint32_t y, uint32_t w, const aafont_t *f, const char *s,
                           uint16_t c, uint16_t bg, int align)
{
    int32_t tw = text_w(f, s), tx = 0;
    cv_begin(w, f->h, bg);
    if (align == 1) {
        tx = ink_in(f, s, (int32_t)w);
        GFX_HOOK_ALIGN(0, 0, (int32_t)w, 0, AL_H, "one-shot line centred");
    }
    else if (align == 2)
        tx = (int32_t)w - tw;
    cv_text(tx, 0, f, s, c);
    cv_blit(x, y);
    lcd_sync();                     /* one-shots (boot, crash, UBOOT, update) finish here */
}
static void draw_text_box(uint32_t x, uint32_t y, uint32_t w, const aafont_t *f, const char *s,
                          uint16_t c, int align)
{
    draw_text_line(x, y, w, f, s, c, T_BG, align);
}
