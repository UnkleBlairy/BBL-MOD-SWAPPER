/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Felucca menu (HOME held): its rows in tabs (1.0.5: DISPLAY CONTROL AUDIO SYSTEM; 1.2: MIDI before SYSTEM; SELECT
 * walks the rows across the tabs, SPEC 1.1a; no scrolling), the rows in menu_items.c (the settings, shared with the editor's
 * MENU_DESC / MENU_SET; 1.2: TUNE and MIDI IN, the project's). No BACK row: HOME closes it (ui_input.c). The two-valued
 * rows are bits of ui_prefs (MENU_FLAGS). In ABOUT KNOB 1 scrolls through all credits and SELECT jumps between its sections (0.2.9;
 * OCT- back to the tabs).
 * ui.menu: 1 the tabs, 2 ABOUT (information and credits: the firmware, the USB link and the CPU readings, which INFO showed before
 * DUELL 0.2.2), 3 TEST (DUELL 0.2.2: the CPU test screen, MENU > SYSTEM > TEST; it was GLO's TEST page, then the INFO item). */
/* ------------------------------------------------------------ menu --- */
/* (the rows, their values and names, usb_serial_apply: menu_items.c) */


/* DUELL CPU LOAD METER (MENU > SYSTEM > TEST: the full card, graph_test below; ABOUT keeps a line). The audio ISR (audio.c) adds each I2S half's
 * render time to cpu_sum / cpu_n, keeps the longest in cpu_pk and counts the halves that missed their time (cpu_miss); this
 * reads them once a second, only while TEST or ABOUT is shown (cpu_meter_poll from their signature), so nothing runs for it
 * otherwise. AVERAGE = the sum / (halves x the half's time) of the last second; PEAK = the longest half of the last second,
 * held (the highest of the last CPU_HOLD_MS, then it falls to the latest); MISSED = halves over their time or overtaken
 * by the DMA since power-on. Colours (fixed, flat): below 80 % the theme, 80 % and up amber (NEAR LIMIT), 95 % and up or a
 * miss in the last 5 s red (the word says it too: MONO has no colours). Emulator: FELUCCA_METER_EST, a voice-count
 * ESTIMATE (audio.c), shown as such */
#define CPU_WIN_MS 1000u
#define CPU_HOLD_MS 4000u
#define CPU_RECENT_MS 5000u
#define CPU_WARN 80u
#define CPU_HOT 95u
static struct {
    uint16_t avg, peak, hold;                          /* % (peak and hold up to 999) */
    uint32_t miss, miss_t, t, hold_t, n0, sum0;        /* the misses seen, when the last one was seen, window start, ... */
    uint32_t base;                                     /* TEST's RESET: the misses counted from here (ABOUT: since power-on) */
    uint8_t seen;                                      /* a miss was ever seen (miss_t valid) */
} cpum;
static void cpu_meter_open(void)                       /* TEST / ABOUT opened: a fresh window (the IIR load until it is over) */
{
    cpum.n0 = cpu_n;
    cpum.sum0 = cpu_sum;
    cpu_pk = 0;
    cpum.t = fm1_ms;
    cpum.avg = cpum.peak = cpum.hold = (uint16_t)(song.cpu_q8 * 100u / 256u);
    cpum.hold_t = fm1_ms;
    cpum.miss = cpu_miss;
    cpum.seen = 0;
}
static void cpu_meter_poll(void)                       /* once a window, and only when asked */
{
    uint32_t n, sum, pk;
    if (fm1_ms - cpum.t < CPU_WIN_MS)
        return;
    do {
        n = cpu_n;
        sum = cpu_sum;
    } while (n != cpu_n);
    pk = cpu_pk;
    cpu_pk = 0;
    cpum.t = fm1_ms;
    if (n != cpum.n0)
        cpum.avg = (uint16_t)clamp((int32_t)((uint64_t)(sum - cpum.sum0) * 100u / ((uint64_t)(n - cpum.n0) * CPU_BUDGET_US)), 0, 999);
    cpum.n0 = n;
    cpum.sum0 = sum;
    cpum.peak = (uint16_t)clamp((int32_t)((uint64_t)pk * 100u / CPU_BUDGET_US), 0, 999);
    if (cpum.peak >= cpum.hold || fm1_ms - cpum.hold_t >= CPU_HOLD_MS) {
        cpum.hold = cpum.peak;
        cpum.hold_t = fm1_ms;
    }
    if (cpu_miss != cpum.miss) {
        cpum.miss = cpu_miss;
        cpum.miss_t = fm1_ms;
        cpum.seen = 1;
    }
}
static uint32_t cpu_recent(void) { return cpum.seen && fm1_ms - cpum.miss_t < CPU_RECENT_MS; }
static uint32_t cpu_level(void)                        /* 0 fine, 1 near the limit, 2 at it or blocks missed */
{
    return cpu_recent() || cpum.avg >= CPU_HOT ? 2u : cpum.avg >= CPU_WARN ? 1u : 0u;
}
static const char *cpu_word(void)
{
    return cpu_recent() ? "BLOCKS MISSED JUST NOW" : cpum.avg >= CPU_HOT ? "AT THE LIMIT" : cpum.avg >= CPU_WARN ? "NEAR THE LIMIT" : "OK";
}
static uint16_t cpu_col(uint32_t lvl, uint16_t bg)     /* flat colours; MONO: the text colour */
{
    if (lvl == 0u)                                     /* (POLICE's theme colour is red: no warning colour then) */
        return UI_PALETTES[ux.pal % NPALETTES].hc ? T_TEXT : vt(T_THEME, bg);
    if (ux.mono || ux.bw)
        return T_TEXT;
    return lvl == 2u ? T_REC : ux.light ? 0xB2C0u : 0xFD20u;
}
static uint32_t cpu_sig(void)                          /* what a redraw depends on */
{
    return cpum.avg * 7u + cpum.hold * 31u + cpum.miss * 211u + cpum.base * 4099u + cpu_level() * 1009u + 1u;
}
static void cpu_pct(char *d, uint32_t v)               /* "37%" */
{
    fmt_int(d, (int32_t)v);
    str_cpy(d + str_len(d), "%", 2);
}

/* https://hugelton.github.io/Felucca, QR version 3, correction M, generated by CoreImage.
 * One row per word, leftmost module in bit 0; the constant matrix needs no encoder or RAM. */
static const uint32_t ABOUT_QR[29] = {
    0x1FCD247Fu, 0x1059C541u, 0x1745765Du, 0x1758E85Du, 0x174E575Du, 0x104C3A41u,
    0x1FD5557Fu, 0x000B7000u, 0x091BCA55u, 0x1270DC8Au, 0x1DB4375Au, 0x083E9FA1u,
    0x1A63124Eu, 0x12513981u, 0x1AE2524Du, 0x0A2E78A0u, 0x1A7F4FC3u, 0x167154B0u,
    0x19A228D5u, 0x0A561C2Au, 0x01F10B4Du, 0x1D1B3F00u, 0x1B5A467Fu, 0x1B13F641u,
    0x11F24D5Du, 0x1D1B625Du, 0x1389315Du, 0x08DFD641u, 0x1813977Fu,
};

static void draw_about_qr(int32_t x, int32_t y)
{
    uint32_t row, col;
    cv_rect(x, y, 74, 74, UI_QR_LIGHT);             /* fixed light / dark, independent of the palette */
    for (row = 0; row < 29u; row++)
        for (col = 0; col < 29u; col++)
            if ((ABOUT_QR[row] >> col) & 1u)
                cv_rect(x + 8 + (int32_t)col * 2, y + 8 + (int32_t)row * 2, 2, 2, UI_QR_DARK);
}

/* All notices are in flash. Wrap at the font's actual width, without dropping URL
 * characters; the same layout computes the scroll limit and draws clipped bands.
 * Mixed case here (long text); S throughout, the title in L. */
static uint32_t about_t0;                              /* ABOUT opened (fm1_ms): its animation's clock */
static uint32_t about_step(void)                       /* the animation's step (ANIM OFF: the first frame, still); 0 off the first view */
{
    return ui.menu == 2 && !ui.menu_scroll && !(ui_prefs & PREF_ANIM_OFF) ? (fm1_ms - about_t0) / SPL_STEP_MS : 0u;
}
#define MENU_DOC_H 178                                /* the document: screen rows 24..201 (item 119: the legend under it has two rows) */
enum { MC_TEXT, MC_TITLE, MC_URL };
typedef struct { const char *text; uint8_t kind; } menu_credit_t;
static const menu_credit_t MENU_CREDITS[] = {
    {"H\xFCgelton Instruments", MC_TITLE},  /* Felucca's own: above; these are ours too */
    {"Leo Kuroshita", MC_TEXT},
    {"CrispyZebra (PHASE waveforms): GPL-3.0", MC_TEXT},
    {"Fukiai icon font: MIT", MC_TEXT},
    {"https://github.com/hugelton", MC_URL},
    {"", MC_TEXT},
    {"KLATTSCH", MC_TITLE},
    {"Tony Gies / MIT", MC_TEXT},
    {"https://github.com/tgies/klattsch", MC_URL},
    {"", MC_TEXT},
    {"DAISYSP", MC_TITLE},
    {"Electrosmith, Emilie Gillet", MC_TEXT},
    {"MIT", MC_TEXT},
    {"https://github.com/electro-smith/DaisySP", MC_URL},
    {"", MC_TEXT},
    {"DEXED + MSFA", MC_TITLE},
    {"Pascal Gauthier, Google Inc.", MC_TEXT},
    {"msfa: Apache-2.0, Dexed: GPL-3.0", MC_TEXT},
    {"https://github.com/asb2m10/dexed", MC_URL},
    {"", MC_TEXT},
    {"RINGS", MC_TITLE},
    {"Emilie Gillet / MIT", MC_TEXT},
    {"https://github.com/pichenettes/eurorack", MC_URL},
    {"", MC_TEXT},
    {"CHOMPI CLUB", MC_TITLE},
    {"The PLATE reverb and the delay modes RAND and OCT+ are based on the CHOMPI firmware (MIT)", MC_TEXT},
    {"https://github.com/CHOMPI-Club/CHOMPI", MC_URL},
    {"", MC_TEXT},
    {"INTER TIGHT", MC_TITLE},
    {"The Inter Project Authors", MC_TEXT},
    {"SIL Open Font License 1.1", MC_TEXT},
    {"https://github.com/rsms/inter-tight", MC_URL},
    {"", MC_TEXT},
    {"VOICE", MC_TITLE},
    {"Dennis H. Klatt (1980)", MC_TEXT},
    {"https://doi.org/10.1121/1.383940", MC_URL},
    {"Hillenbrand, Getty, Clark and Wheeler (1995)", MC_TEXT},
    {"https://doi.org/10.1121/1.411872", MC_URL},
    {"", MC_TEXT},
    {"WAVE USER TABLES", MC_TITLE},                /* DUELL 0.2.14: the editor's WAV converter (web/editor/wavetable.js); ideas, no code */
    {"Cooley and Tukey (1965): the FFT", MC_TEXT},
    {"https://doi.org/10.1090/S0025-5718-1965-0178586-1", MC_URL},
    {"Xfer Serum: wavetable WAV files", MC_TEXT},
    {"of 2048 sample frames (Vital, Surge)", MC_TEXT},
    {"", MC_TEXT},
    {"FM VOICE", MC_TITLE},                        /* DUELL 0.2.17: FM BASS 2 (FM6 default patch F9), a DX7 voice import */
    {"One FM voice: aquanodemusic (Aquanode Soundscapes), CC0 1.0 Universal", MC_TEXT},
    {"https://github.com/aquanodemusic/aquanode-soundscapes", MC_URL},
    {"", MC_TEXT},
    {"FM-1 SCREEN READER", MC_TITLE},              /* DUELL 1.4: announce.c and tools/gen_words.py, MPL-2.0 */
    {"Charles Vestal / MPL-2.0", MC_TEXT},
    {"https://github.com/charlesvestal/fm1-reader", MC_URL},
#if DUELL_VELO
    {"", MC_TEXT},
    {"VELO", MC_TITLE},                            /* KEY VELOCITY and aftertouch (sense.c): the method of Velo, built on Felucca; in builds with KEY SENSE, where the method is */
    {"Charles Vestal: key velocity and aftertouch from the keys (method)", MC_TEXT},
    {"GPL-3.0-only", MC_TEXT},
    {"https://github.com/charlesvestal/fm1-velocity", MC_URL},
#endif
};

static int32_t menu_text(const char *s, int32_t y, uint16_t col, int draw)
{
    while (*s) {
        char line[64];
        uint32_t n = 0, space = 0, take, prev = 0;
        int32_t pen = 0;                                 /* 1/16 px, as text_w adds it up */
        while (s[n] && n < sizeof line - 1u) {
            uint32_t c = (uint8_t)s[n];
            line[n] = s[n];
            line[n + 1u] = 0;
            pen += (prev ? kern(&AF_S, prev, c) : 0) + AF_S.g[glyph(&AF_S, c)].adv;
            prev = c;
            if ((pen + 8) >> 4 > 216)
                break;
            if (s[n] == ' ')
                space = n;
            n++;
        }
        take = s[n] && space ? space : n;
        if (!take) take = 1;                         /* progress even for an unusually wide glyph */
        line[take] = 0;
        if (draw && y + AF_S.h > 0 && y < MENU_DOC_H)
            cv_text(6, y, &AF_S, line, col);
        y += 18;
        s += take;
        while (*s == ' ') s++;
    }
    return y;
}

/* ABOUT's USB line (what INFO's USB row showed: the old SYSTEM page's MIDI card; OFF no USB, WAIT no bus yet, BUS frames seen, ENUM being set
 * up, MIDI in use). The CPU line is the meter above */
static uint32_t info_usb(void)                         /* 0 OFF, 1 WAIT, 2 BUS, 3 ENUM, 4 MIDI */
{
    return !usb.up ? 0u : usb.config ? 4u : usb.setups ? 3u : usb.sof_seen ? 2u : 1u;
}
static int32_t about_sec[2];                           /* ABOUT's CREDITS and LICENSES headings, from the document's top (menu_document) */
#define ABOUT_AIR 18                                   /* the air above and below the logo word */
#define ABOUT_GAP 24                                   /* the gap under the logo word: more than a text line */
#define ABOUT_SH 50                                    /* the lines below shift down: 17 + 28 + 17 + 20 + 20 + 24 against the old 78 */
/* the DUELL word of the logo (tools/gen_splash_logo.py SPL_WORD, 80 % of the splash's size), coverage blended onto the canvas in the text colour; (x, y) its top left */
static void about_word_draw(int32_t x, int32_t y)
{
    uint32_t i, p = 0;
    for (i = 0; i < (uint32_t)sizeof SPL_WORD; i++) {
        uint32_t v = SPL_WORD[i] >> 4, n = (SPL_WORD[i] & 15u) + 1u, e = p + n;
        for (; v && p < e; p++) {
            int32_t px = x + (int32_t)(p % SPL_WORD_W), py = y + CV_OY + (int32_t)(p / SPL_WORD_W);
            if (px < 0 || py < 0 || px >= (int32_t)cv_w || py >= (int32_t)cv_h)
                continue;
            cv_px[(uint32_t)py * cv_w + (uint32_t)px] = swap16(ux_mix(swap16(cv_px[(uint32_t)py * cv_w + (uint32_t)px]), T_TEXT, (int32_t)(v * 100u / 15u)));
        }
        p = e;
    }
}
static const char *about_cores(const char **l2)         /* the CORES line (owner, test3): two cores playing, or one (the second core off: it did not start, a fault, or the jobs paused: the automatic fallback);
                                                        * item 119: the long form is 234 px, the card holds 220: two lines, "CORES: 1 RUNNING" and "(SECOND CORE OFF)", every word whole */
{
    *l2 = 0;
#if DUELL_TWOCORE
    if (tc.up && !tc.failed && !tcr.paused)
        return "CORES: 2 RUNNING";
    *l2 = "(SECOND CORE OFF)";
#endif
    return "CORES: 1 RUNNING";
}
static int32_t about_cores_lines(void) { const char *l2; (void)about_cores(&l2); return l2 ? 2 : 1; }
static int32_t menu_document(int32_t y, int draw)
{
    uint32_t i;
    int32_t y0 = y;
    y += ABOUT_SH;                                      /* (DUELL 1.1: the logo word and its air push every line below down) */
    if (draw) {
        char b[16];
        uint16_t col = vt(T_THEME, T_BG);                /* (owner V7: one accent for every number here, no red) */
        const char *ver = FELUCCA_VERSION;
        if (ver[0] == 'D' && ver[1] == 'U' && ver[2] == 'E' && ver[3] == 'L' && ver[4] == 'L' && ver[5] == ' ')
            ver += 6;                                   /* the number only (owner item 69: no second DUELL) */
        {   /* a release shows its number alone (1.1.0); a test build keeps its tag (1.1.0-test3) */
            static char vb[16];
            uint32_t vi = 0;
            while (ver[vi] && vi < 15u && (DUELL_TEST_MODE || ver[vi] != '-'))
                vb[vi] = ver[vi], vi++;
            vb[vi] = 0;
            ver = vb;
        }
        about_word_draw(6, y0 + ABOUT_AIR);             /* the DUELL word of the logo at 80 %, air above and below it (LOGO_SCREENS_V1.png) */
        cv_text(6, y0 + ABOUT_AIR + 28 + ABOUT_GAP, &AF_M, "MultiMorphing Bitimbral Synthesizer", T_TEXT);
        cv_text(6, y0 + ABOUT_AIR + 28 + ABOUT_GAP + 20, &AF_M, "by OSCILL/R", T_TEXT);
        cv_text_grad(6, y0 + ABOUT_AIR + 28 + ABOUT_GAP + 44, &AF_M, ver, 6);
        cv_text_r(222, y0 + ABOUT_AIR + 28 + ABOUT_GAP + 47, &AF_S, __DATE__, T_MID, T_BG);
        cv_text(6, y + 96, &AF_S, "CPU", T_MID);                 /* the meter: the 1 s average, the held peak, the misses */
        cpu_pct(b, cpum.avg);
        cv_text(34, y + 96, &AF_S, b, col);
        cv_text(84, y + 96, &AF_S, "PEAK", T_MID);
        cpu_pct(b, cpum.hold);
        cv_text(118, y + 96, &AF_S, b, col);
        if (cpum.miss) {
            fmt_int(b, (int32_t)(cpum.miss > 9999u ? 9999u : cpum.miss));
            str_cpy(b + str_len(b), " MISSED", 8);
            cv_text_r(222, y + 96, &AF_S, b, col, T_BG);
        }
        cv_text(6, y + 112, &AF_S, "USB", T_MID);                /* the link (INFO's USB row): OFF, WAIT, BUS, ENUM or MIDI */
        cv_text(34, y + 112, &AF_S, (const char *const[5]){"OFF", "WAIT", "BUS", "ENUM", "MIDI"}[info_usb()], vt(T_THEME, T_BG));
        if (ovl_lite)                                   /* 0.2.25: the overload guard is engaged (fx.c ovl_step: RANDOM / OCT UP as the plain delay) */
            cv_text_r(222, y + 112, &AF_S, "LIGHT FX", col, T_BG);
        {   /* DUELL 1.1 (owner, test3): which core is working, in full words (item 119: two lines when it is one core with the second off) */
            const char *l2, *l1 = about_cores(&l2);
            cv_text(6, y + 128, &AF_S, l1, T_TEXT);
            if (l2)
                cv_text(6, y + 146, &AF_S, l2, T_TEXT);
        }
        y += 18 * about_cores_lines();                  /* (the lines below: one row down for each line of it) */
#if DUELL_RAMPLACE
        {   /* two-core stage 1a: part 2's voice code in RAM (ramplace.c): OK and its size, or FAIL and the range that differs from the
             * flash image (checked once a second here, about_sig); BOOT COPY n: the start needed n more copies */
            cv_text(6, y + 136, &AF_S, "RAM CODE", T_MID);
            if (!rp_state) {
                fmt_int(b, (int32_t)((ramplace_bytes() + 512u) / 1024u));
                str_cpy(b + str_len(b), " KB", 4);
                cv_text(78, y + 136, &AF_S, "OK", vt(T_THEME, T_BG));
                cv_text(104, y + 136, &AF_S, b, T_TEXT);
            } else
                cv_text(78, y + 136, &AF_S, rp_state == 1u ? "FAIL X" : rp_state == 2u ? "FAIL Z" : "FAIL X Z", T_ACCENT);   /* (owner V7: no red in ABOUT) */
            if (rp_boot_copies) {
                str_cpy(b, "BOOT COPY ", 11);
                fmt_int(b + str_len(b), rp_boot_copies);
                cv_text_r(232, y + 136, &AF_S, b, T_ACCENT, T_BG);
            }
            y += 18;                                    /* (the lines below one row down; with draw 0 too: below) */
        }
#endif
        cv_text(6, y + 142, &AF_S, "based on Felucca (GPL-3.0)", T_TEXT);
        cv_text(6, y + 160, &AF_S, "(C) 2026 Leo Kuroshita", T_TEXT);
        cv_text(6, y + 178, &AF_S, "H\xFCgelton Instruments", T_TEXT);
        cv_text(6, y + 202, &AF_S, "hugelton.github.io", T_MID);
        cv_text(6, y + 220, &AF_S, "/Felucca", T_MID);
        cv_text(6, y + 244, &AF_S, "hugelton.com", T_MID);
        draw_about_qr(158, y + 186);
    }
    if (!draw)
        y += 18 * about_cores_lines();                  /* (the CORES line's rows, as drawn) */
#if DUELL_RAMPLACE
    if (!draw)
        y += 18;                                        /* (the RAM CODE line's row, as drawn) */
#endif
    about_sec[0] = y + 280 - y0;
    y = menu_text("CREDITS", y + 280, T_THEME, draw) + 8;
    for (i = 0; i < NELEM(MENU_CREDITS); i++) {
        const menu_credit_t *c = &MENU_CREDITS[i];
        const char *text = c->text;
        /* Display host/path once; the full source URL stays in the flash table. */
        if (c->kind == MC_URL && str_len(text) >= 8u && !memcmp(text, "https://", 8))
            text += 8;
        if (!text[0]) y += 8;
        else y = menu_text(text, y, c->kind == MC_TITLE ? T_THEME : c->kind == MC_URL ? T_MID : T_TEXT, draw);
    }
    about_sec[1] = y + 12 - y0;
    y = menu_text("LICENSES + SOURCE", y + 12, T_THEME, draw);
    y = menu_text("Fonts and icons: their licences travel with the source and the release files.", y, T_TEXT, draw);
    y = menu_text("NO WARRANTY", y, T_TEXT, draw);
    y = menu_text("Full notices in source:", y + 8, T_TEXT, draw);
    y = menu_text("github.com/hugelton/Felucca", y, T_MID, draw);
    return y + 4;
}
static int32_t menu_scroll_max(void)
{
    int32_t h = menu_document(0, 0);
    return h > MENU_DOC_H ? h - MENU_DOC_H : 0;
}
/* SELECT in ABOUT (0.2.9): the next (s > 0) or the previous section's start: the animation (0), the information (1: the document's top),
 * CREDITS, LICENSES + SOURCE (each at most the end of the scroll); stops at the first and the last, no wrap */
static int32_t about_section(int32_t cur, int32_t s)
{
    int32_t max = menu_scroll_max(), t[4], k, n = 4;
    t[0] = 0, t[1] = 1, t[2] = about_sec[0] < max ? about_sec[0] : max, t[3] = about_sec[1] < max ? about_sec[1] : max;
    if (s > 0) {
        for (k = 0; k < n; k++)
            if (t[k] > cur)
                return t[k];
        return cur;
    }
    for (k = n - 1; k >= 0; k--)
        if (t[k] < cur)
            return t[k];
    return cur;
}

/* the menu's header (0..24): the page title, the same face as every page's (ui_draw.c head_title_draw: Bold 15, white, centred, no colour, no line; item 119).
 * DUELL 1.3 (owner 2026-11-13): inside a section "MENU > MIDI", the arrow the rows' chevron (the title's face has no such sign), white as the words */
#define MENU_WORD "SETTINGS"                            /* DUELL 1.3 (owner 2026-11-15: "Yes, SETTINGS"; was MENU, the editor's word already): the title, "SETTINGS > MIDI" */
static uint32_t menu_tab(void) { return MI_TAB[ui.menu_sel % MI_COUNT]; }
static uint32_t menu_page(void);
static void menu_head(void)
{
    const char *w[3] = {MENU_WORD, 0, 0};              /* owner 2026-11-15 (one rule): every page titled with its whole path, SETTINGS > MIDI > SIDECHAIN, SETTINGS > SYSTEM > ABOUT */
    cv_begin(240, H_HEAD, T_BG);
    if (ui.guide && ui.guide_menu) {                    /* (SETTINGS > SYSTEM > GUIDE, its pages drawn by ui_guide.c; the list under it is still open) */
        w[1] = MTAB_NAME[MTAB_SYSTEM];
        w[2] = "GUIDE";
    } else if (ui.menu == 1 && menu_tab() < MTAB_COUNT) {
        w[1] = menu_tab() == MTAB_SCHAIN ? MTAB_NAME[MTAB_MIDI] : MTAB_NAME[menu_tab()];
        w[2] = menu_tab() == MTAB_SCHAIN ? MTAB_NAME[MTAB_SCHAIN] : 0;
    } else if (ui.menu == 2) {
        w[1] = MTAB_NAME[MTAB_SYSTEM];
        w[2] = "ABOUT";
    } else if (ui.menu == 4) {
        w[1] = MTAB_NAME[MTAB_MIDI];
        w[2] = "MIDI LEARN";
    }
    if (ui.msg_t && ui.msg[0]) {                       /* a message (PRESETS / ALGORITHM turned: HOME CLOSES SETTINGS) where the title stands */
        head_title_draw(ui.msg, 1);
    } else if (w[1]) {
        uint32_t i, n = w[2] ? 3u : 2u;
        int32_t tw = 0, x, y = UT_TITLE_BASE - AF_T_CAP_Y - AF_T_CAP_H + 1 - Y_HEAD;
        for (i = 0; i < n; i++)
            tw += text_w(&AF_T, w[i]) + (i ? 22 : 0);
        x = HALF_UP(240 - tw);
        GFX_HOOK_ALIGN(0, 0, 0, H_HEAD, AL_V, "header text on its middle");
        for (i = 0; i < n; i++) {
            if (i) {
                cv_icon_in(x + 6, y + AF_T_CAP_Y, 0, AF_T_CAP_H, 12, ICON_X_RIGHT, T_TEXT, T_BG);   /* (its ink 9 px from each word) */
                x += 22;
            }
            x = cv_text_on(x, y, &AF_T, w[i], T_TEXT, T_BG);
        }
        if (ui.menu == 1 && !ui.guide && mtab_pages(menu_tab()) > 1u) {                /* (1.3: the page counter on the title row, right; the footer holds SELECT, KNOB 1 and OCT- BACK) */
            char pc[8] = "1/2";
            pc[0] = (char)('0' + menu_page() + 1u);
            pc[2] = (char)('0' + mtab_pages(menu_tab()));
            cv_text_r(232, y + AF_T_CAP_Y + AF_T_CAP_H - AF_S_CAP_Y - AF_S_CAP_H, &AF_S, pc, T_MID, T_BG);   /* (its capitals on the title's baseline) */
        }
    } else
        head_title_draw(MENU_WORD, 1);
    cv_blit(0, Y_HEAD);
}

/* The page (1.0.5; DUELL 1.3 sections, owner 2026-11-13): the list of the seven sections (ui.menu 6) or one section's rows (ui.menu 1) under the title, the key hints at the bottom.
 *   header   0..24  MENU, or MENU > <SECTION>
 *   rows    32..    a row a label and its value (the list: the section's name and a chevron), no rules; the selected row the background mixed 27 % toward
 *                   part 1's colour with a 2 px edge of that colour at its left (M_SEL, menu_hl). A value (M) at the right,
 *                   ON / OFF as a switch, COLOR its palette's five colours, the rows that open something (SIDECHAIN, MIDI LEARN, TEST, GUIDE,
 *                   ABOUT, ERASE DATA) a chevron in part 1's colour. Rows of one or two units (a two-line label), at most MPAGE_UNITS a page; a
 *                   section with more has pages ("1/2" at the footer's right)
 *   keys   224      the list: SELECT SECTION, OCT+ OPEN; a section: SELECT ROW and, on a row with a value, KNOB 1 VALUE (OCT- goes back
 *                   to the list, HOME closes, unadvertised as before)
 * Drawn in two bands (the canvas holds 124 rows) split in a gap between two rows */
#define MP_Y 29                                        /* the rows' panel (DUELL 1.3: right under the title, the tab bar is gone) */
#define MP_PAD 3
#define MR_X 8                                         /* a row */
#define MR_W 224
#define MR_LX 16                                       /* its label */
#define MR_VR 224                                      /* its value's right edge */
#define MK_Y 224                                       /* the key hints: the footer's row 2 band (its keycaps centred on its names) */
/* DUELL 0.2.14: the rows in units (menu_items.c menu_units, menu_place): a unit is 21 px and a 1 px gap, a two-line
 * row two units (43 px); MPAGE_UNITS units a page. The page shown is the selected row's (SELECT walks every row, so it turns the pages too) */
#define MU_H 21                                        /* a unit's height */
#define MU_P 22                                        /* .. and its pitch (the rule between two rows is the gap row) */
static int32_t mu_y(uint32_t u) { return MP_Y + MP_PAD + (int32_t)u * MU_P; }
static uint32_t menu_page(void) { return menu_place(ui.menu_sel % MI_COUNT, 0); }   /* the page shown (0 ..) */
static uint32_t menu_sec(void) { return menu_tab() == MTAB_SCHAIN ? MTAB_MIDI : menu_tab(); }   /* the section of the list the selected row is in */
#define M_SEL ux_mix(T_BG, T_PTHEME(0), 27)            /* DUELL 1.3 (owner 2026-11-13): the picked row, the background 27 % toward part 1's colour */
static void menu_hl(int32_t y, int32_t h)              /* the picked row's fill (square at its left) and its 2 px edge in part 1's colour */
{
    CV_HL(MR_X, y, MR_W, h);
    cv_rrect(MR_X, y, MR_W, h, 6, M_SEL, T_BG);
    cv_rect(MR_X, y, 8, h, M_SEL);
    cv_rect(MR_X, y, 2, h, T_PTHEME(0));
}
/* a two-valued row whose values are ON and OFF: a switch (a 26 x 14 cushion, its knob at the right when ON) */
static void menu_switch(int32_t xr, int32_t y, int32_t h, int on, int sel)
{
    int32_t x = xr - 26, ty = y + HALF_UP(h - 14);
    uint16_t under = sel ? M_SEL : T_BG;
    uint16_t track = on ? T_THEME : T_DIM;
    uint16_t knob = on ? T_INK : T_TEXT;
    cv_rrect(x, ty, 26, 14, -7, track, under);
    cv_rrect(on ? x + 14 : x + 2, ty + 2, 10, 10, -5, knob, track);
}
/* a row (menu_items.c row `row`) of the page shown: its units' place, the label at the left (a two-line label: its first line in M,
 * the second small (S, MID), the pair centred in the row), the value at the right centred on the whole row */
/* DUELL 1.3 (owner 2026-11-13): the line under a row that says what its chosen value does (rows whose MI_LABEL ends in a bare '\n') */
static const char *menu_help(uint32_t row)
{
    uint32_t v = menu_get(row);
    if (row == MI_MODERECALL)
        return v ? "Load a multi: its mode is set" : "Load a multi: your mode stays";
    if (row == MI_RESTORE)
        return v ? "Power-on: a fresh start" : "Power-on: your last music";
    return "";
}
static void menu_row(uint32_t row)
{
    uint32_t u;
    int32_t y, h, vy;
    int sel = row == ui.menu_sel;
    uint16_t bg = sel ? M_SEL : T_BG, fg = T_TEXT, val = T_TEXT;   /* (DUELL 1.1, PAGES_V2_menu.png: the picked row a neutral fill, the values white, no rules) */
    const char *v = menu_valued(row) ? menu_vname(row, menu_get(row)) : "", *l = menu_label(row);
    char l1[24];
    uint32_t n = 0;
    menu_place(row, &u);
    y = mu_y(u);
    h = (int32_t)menu_units(row) * MU_P - 1;
    vy = y + CAP_IN(M, h);                             /* the label and its value: M (a list's rows) */
    if (sel)
        menu_hl(y, h);
    while (l[n] && l[n] != '\n' && n + 1u < sizeof l1) {
        l1[n] = l[n];
        n++;
    }
    l1[n] = 0;
#if SMK_SCREEN
    if (smk_pk_long(row)) {                            /* SMK-37 PERFORM KNOB n with a choice too wide beside it: the name, then the choice on its own line (full size,
                                                        * right), then KNOB 1's hint; a unit each (menu_items.c menu_units) */
        int32_t t = y + HALF_UP(MU_P - 1 - AF_M_CAP_H);
        cv_text_on(MR_LX, t - AF_M_CAP_Y, &AF_M, l1, fg, bg);
        cv_text_r(MR_VR, t + MU_P - AF_M_CAP_Y, &AF_M, v, val, bg);
        if (l[n] == '\n')
            cv_text_on(MR_LX, y + 2 * MU_P + HALF_UP(MU_P - 1 - AF_S_CAP_H) - AF_S_CAP_Y, &AF_S, l + n + 1, T_MID, bg);
        return;
    }
#endif
    if (l[n] == '\n') {                                /* two lines: M 11 px caps, 6 px, S 9 px caps, centred in h */
        int32_t top = y + HALF_UP(h - (AF_M_CAP_H + 6 + AF_S_CAP_H));
        GFX_HOOK_ALIGN(0, top, 0, top + AF_M_CAP_H, AL_V, "menu row name's first line");
        cv_text_on(MR_LX, top - AF_M_CAP_Y, &AF_M, l1, fg, bg);
        vy = top - AF_M_CAP_Y;                         /* DUELL 1.3 (the approved drawing): a text value on the first line's baseline */
        top += AF_M_CAP_H + 6;
        GFX_HOOK_ALIGN(0, top, 0, top + AF_S_CAP_H, AL_V, "menu row name's second line");
        cv_text_on(MR_LX, top - AF_S_CAP_Y, &AF_S, l[n + 1] ? l + n + 1 : menu_help(row), T_MID, bg);
    } else {
        GFX_HOOK_ALIGN(0, y, 0, y + h, AL_V, "menu row name centred up/down");
        cv_text_on(MR_LX, vy, &AF_M, l1, fg, bg);
    }
    if (!menu_valued(row)) {                           /* SIDECHAIN, MIDI LEARN, TEST, GUIDE, ABOUT, ERASE DATA: OCT+ opens them (DUELL 1.3: the chevron in part 1's colour) */
        GFX_HOOK_ALIGN(0, y, 0, y + h, AL_V, "menu row chevron centred up/down");
        cv_icon_in(MR_VR - 12, y, 0, h, 12, ICON_X_RIGHT, T_PTHEME(0), bg);
        return;
    }
    if (row == MI_HOLD || row == MI_TUNE) {            /* "0.4" s, "440.0" Hz: the value and its unit */
        char b[8] = "0.4";
        b[2] = (char)('0' + HOLD_MS[settings_hold % 4u] / 100u);
        GFX_HOOK_ALIGN(0, y, 0, y + h, AL_V, "menu row value centred up/down");
        GFX_HOOK_ALIGN(0, 0, 0, vy + AF_M.asc, AL_B, "menu row unit on its value's baseline");
        cv_text_r(cv_text_r(MR_VR, vy + AF_M.asc - AF_S.asc, &AF_S, row == MI_TUNE ? "Hz" : "s", T_MID, bg) - 3,
                  vy, &AF_M, row == MI_TUNE ? v : b, val, bg);
        return;
    }
    if (menu_n(row) == 2u && (str_eq(v, "ON") || str_eq(v, "OFF"))) {
        menu_switch(MR_VR, y, h, str_eq(v, "ON"), sel);
        return;
    }
    GFX_HOOK_ALIGN(0, vy + AF_M_CAP_Y, 0, vy + AF_M_CAP_Y + AF_M_CAP_H, AL_V, "menu row value on its line");
    if (row != MI_COLOR) {
        cv_text_r(MR_VR, vy, &AF_M, v, val, bg);
        return;
    }
    {   /* COLOR: the palette's name and its five colours (BG SURF TEXT, part 1's and part 2's colour), live */
        uint32_t c;
        const uint16_t tok[5] = {T_BG, T_BG, T_TEXT, T_PTHEME(0), T_PTHEME(1)};   /* BG SURF TEXT and each part's colour */
        int32_t x0 = MR_VR - 74, sy = y + HALF_UP(h - 12);
        cv_text_r(x0 - 6, vy, &AF_M, v, val, bg);
        for (c = 0; c < 5u; c++) {
            cv_rrect(x0 + (int32_t)c * 15, sy, 12, 12, -3, T_RAISE, bg);       /* a rim for the dark ones */
            cv_rrect(x0 + 1 + (int32_t)c * 15, sy + 1, 10, 10, -2, tok[c], T_RAISE);
        }
    }
}
#if DUELL_TWOCORE
#define CORES_SIG ((uint32_t)(tc.up && !tc.failed && !tcr.paused) * 4099u)    /* (the CORES line: the state it shows) */
#else
#define CORES_SIG 0u
#endif
static uint32_t about_sig(void)
{
    cpu_meter_poll();
#if DUELL_RAMPLACE
    {   /* the RAM code compared with its flash image once a second while ABOUT is up (ramplace.c; about 1 ms) */
        if (!rp_about_t || fm1_ms - rp_about_t >= 1000u) {
            rp_about_t = fm1_ms | 1u;
            rp_state = (uint8_t)ramplace_check();
        }
    }
    return cpu_sig() + info_usb() * 131u + ovl_lite * 977u + rp_state * 7919u + CORES_SIG;
#endif
    return cpu_sig() + info_usb() * 131u + ovl_lite * 977u + CORES_SIG;
}
#if DUELL_TEST_MODE                                    /* the CPU test screen is a developer build (DUELL_TEST_MODE); the release leaves it out down to #endif (TEST screen) */
/* MENU > SYSTEM > TEST (the CPU test screen, beta; ui.menu 3, drawn as the page TEST_PAGE, params.c): what is loaded and how hard the audio works. The multi (slot + name), per part the ENGINE
 * and the PATCH (the stored patch's name or the default sound's), then the CPU meter: the 1 s AVERAGE with a bar (a mark at 80 %,
 * a tick at the held peak), PEAK HOLD, MISSED blocks, and a word for the state (OK, NEAR THE LIMIT, AT THE LIMIT, BLOCKS MISSED
 * JUST NOW; the same flat colours as before: cpu_col). Drawn on the graph panel (cv_oy 0, panel rows). The meter reads the
 * audio's counters only while this page is up: a gap of more than 0.5 s between two looks (another page, the screen dark) opens a
 * fresh window. K4 RESET: cpu_meter_open and the missed count from zero (test_reset); ABOUT keeps its power-on count */
static uint32_t test_t;                                /* the page's last look (fm1_ms; 0: none yet) */
static void test_sync(void)
{
    if (!test_t || fm1_ms - test_t > 500u)
        cpu_meter_open();
    test_t = fm1_ms ? fm1_ms : 1u;
    cpu_meter_poll();
}
static void test_reset(void)                           /* K4: peak hold, missed blocks and the average window from zero */
{
    cpu_meter_open();
    cpum.base = cpu_miss;
    test_t = fm1_ms ? fm1_ms : 1u;
}
static uint8_t test_pick = 0xFFu;                      /* K3's multi (0..15): the last one stepped to or loaded */
static uint32_t test_slot(void)                        /* the multi K3 shows: the pick, else the one the music came from, else the first used */
{
    uint32_t k;
    if (test_pick < MU_SLOTS && project_used(test_pick))
        return test_pick;
    k = project_cur_slot();
    if (k < MU_SLOTS && project_used(k))
        return k;
    for (k = 0; k < MU_SLOTS; k++)
        if (project_used(k))
            return k;
    return MU_SLOTS;                                   /* no multi at all */
}
static uint32_t test_missed(void) { return cpum.miss - cpum.base; }
static void test_multi_name(char *b)                   /* "M05 NAME", or "NO MULTI" when the music did not come from one */
{
    uint32_t k = project_cur_slot();
    if (k >= MU_SLOTS) {
        str_cpy(b, "NO MULTI", 24);
        return;
    }
    mu_label(b, k);
    str_cpy(b + str_len(b), " ", 2);
    project_cur_name(b + str_len(b));
}
static uint32_t test_sig(void)                         /* what the panel shows */
{
    char b[24];
    uint32_t h = 2166136261u, k;
    test_sync();
    h = (h ^ cpu_sig()) * 16777619u;
    h = (h ^ felucca_dbg.erase_max_us / 1000u) * 16777619u;
    test_multi_name(b);
    h = str_hash(h, b);
    for (k = 0; k < 2u; k++) {
        sound_name(&trk[k], b);
        h = str_hash(h + trk[k].eng_req * 31u, b);
    }
    return h;
}
static void test_pct(char *d, uint32_t v) { cpu_pct(d, v); }
static void graph_test(void)
{
    char b[24], v[16];
    uint32_t lvl = cpu_level(), plv = cpum.hold >= 100u ? 2u : cpum.hold >= CPU_WARN ? 1u : 0u, k;
    uint16_t col = cpu_col(lvl, T_BG);
    int32_t fill = (int32_t)(cpum.avg > 100u ? 100u : cpum.avg) * 224 / 100, tick = (int32_t)(cpum.hold > 100u ? 100u : cpum.hold) * 224 / 100, x;
    cv_text_on(10, 3, &AF_S, "MULTI", T_MID, T_BG);
    test_multi_name(b);
    cv_text_r(230, 3, &AF_S, b, project_cur_slot() < MU_SLOTS ? T_TEXT : T_DIM, T_BG);
    for (k = 0; k < 2u; k++) {                         /* the parts: engine at the left, the patch at the right */
        int32_t y = 17 + 13 * (int32_t)k;
        v[0] = (char)('1' + k);
        v[1] = 0;
        cv_text_on(10, y, &AF_S, v, song.sel == k ? T_ACCENT : T_DIM, T_BG);
        cv_text_on(22, y, &AF_S, eng_shown(ENGINES[trk[k].eng_req % NENGINES]->name), T_MID, T_BG);
        sound_name(&trk[k], b);
        cv_text_r(230, y, &AF_S, b, T_TEXT, T_BG);
    }
    cv_text_on(10, 47, &AF_S, "AVERAGE 1 S", T_MID, T_BG);
    test_pct(v, cpum.avg);
    cv_text_r(230, 44, &AF_M, v, col, T_BG);
    cv_rect(8, 64, 224, 8, T_RAISE);                   /* the track, the fill, the 80 % mark, the peak tick */
    cv_rect(8, 64, fill, 8, col);
    cv_rect(8 + 224 * (int32_t)CPU_WARN / 100, 72, 1, 3, T_MID);
    cv_rect(8 + (tick > 222 ? 222 : tick), 61, 2, 14, T_TEXT);
    x = cv_text_on(10, 79, &AF_S, "PEAK HOLD", T_MID, T_BG);
    test_pct(v, cpum.hold);
    cv_text_on(x + 6, 79, &AF_S, v, cpu_col(plv, T_BG), T_BG);
    fmt_int(v, (int32_t)(test_missed() > 9999u ? 9999u : test_missed()));
    x = cv_text_r(230, 79, &AF_S, v, cpu_recent() ? cpu_col(2u, T_BG) : T_TEXT, T_BG);
    cv_text_r(x - 6, 79, &AF_S, "MISSED", T_MID, T_BG);
    cv_text_on(10, 93, &AF_S, cpu_word(), lvl ? cpu_col(lvl, T_BG) : T_MID, T_BG);
#ifdef FELUCCA_METER_EST
    cv_text_r(230, 93, &AF_S, "EMULATOR ESTIMATE", T_DIM, T_BG);
#endif
    x = cv_text_on(10, 107, &AF_S, "ERASE", T_MID, T_BG);   /* DUELL 0.2.11: the longest flash erase since boot (storage_hw.c: the driver's own time) */
    if (felucca_dbg.erase_max_us) {
        fmt_int(v, (int32_t)((felucca_dbg.erase_max_us + 500u) / 1000u));
        str_cpy(v + str_len(v), "MS", 3);
    } else
        str_cpy(v, "--", 3);
    cv_text_on(x + 6, 107, &AF_S, v, T_TEXT, T_BG);
}                                                /* (voice pool, 2026-11-06: the VOICE CAP line is gone; no note-on reads that table any more) */
#endif                                                 /* (TEST screen) */
static void edit_param(uint32_t slot, int32_t steps);   /* ui_input.c: the TEST and MIDI LEARN screens' knobs */
/* A page shown as a MENU screen (ui.menu 3 TEST, 4 MIDI LEARN): the page p drawn by the page code (header with its name in the top middle, the K1..K4 cards, the
 * panel, the footer), page_over making it the current page; the LAYER state is put aside while it draws */
static void draw_page_screen(const page_t *p)
{
    uint8_t layer = ui.layer;
    ui.layer = 0;
    page_over = p;
    if (ui.force)
        draw_frame();
    draw_head();
    draw_columns();
    draw_graph();
    if (ui.msg_t && !--ui.msg_t && ui.msg2[0]) {
        str_cpy(ui.msg, ui.msg2, sizeof ui.msg);
        ui.msg2[0] = 0;
        ui.msg_t = 60;
    }
    if (ui.hot_t)
        ui.hot_t--;
    draw_foot();
    page_over = 0;
    ui.layer = layer;
}

/* the rows' two bands meet at `split`: in the gap above a row of the page (or below its last, at unit `end`), each band at most 124 rows */
static uint32_t menu_split(uint32_t first, uint32_t last, uint32_t pg, uint32_t end)
{
    int32_t s = mu_y(end) - 1, y;
    uint32_t k, u;
    for (k = first; k < last; k++)                     /* (the lowest row top that keeps the upper band within 124) */
        if (menu_shown(k) && menu_place(k, &u) == pg && (y = mu_y(u) - 1) <= H_HEAD + 124 && (s > H_HEAD + 124 || y > s))
            s = y;
    return (uint32_t)(s < 240 - 124 ? 240 - 124 : s);
}
#if DUELL_VELO
#define SENSE_SIG ((uint32_t)ui_sense_type * 2654435761u)
#else
#define SENSE_SIG 0u
#endif
/* DUELL 1.3: the list's row k (a section): its name and the chevron in part 1's colour */
static void menu_sec_row(uint32_t k)
{
    int32_t y = mu_y(k);
    uint16_t bg = k == menu_sec() ? M_SEL : T_BG;
    if (k == menu_sec())
        menu_hl(y, MU_H);
    GFX_HOOK_ALIGN(0, y, 0, y + MU_H, AL_V, "menu row name centred up/down");
    cv_text_on(MR_LX, y + CAP_IN(M, MU_H), &AF_M, MTAB_NAME[k], T_TEXT, bg);
    cv_icon_in(MR_VR - 12, y, 0, MU_H, 12, ICON_X_RIGHT, T_PTHEME(0), bg);
}
static void draw_menu(void)
{
    /* SPEC 1.1a: SELECT picks the row, KNOB 1 the value (an action row has none: SELECT alone; no OCT+ OPEN / CLEAR hint);
     * DUELL 1.3: the list SELECT SECTION, OCT+ OPEN */
    static const khint_t KEYS[6] = {{KC_SELECT, "ROW"}, {KC_K1, "VALUE"}, {KC_OCTUP, "OPEN"}, {KC_SELECT, "SECTION"}, {KC_OCTDN, "BACK"}, {KC_OCTDN, "BACK"}};   /* (1.3, owner: inside a section OCT- BACK is shown;
                                                         * owner 2026-11-15, one rule: every row the same three places, SELECT left, the knob in the middle, OCT- right; the list: KNOB 1 OPEN, OCT- CLOSE) */
    uint32_t pass, k, first, last, split, sig, pg, end, u, list = ui.menu == 6;
#if DUELL_TEST_MODE
    if (ui.menu == 3) {                                /* TEST: the page code draws it, whole each frame (it checks its own signatures) */
        draw_page_screen(&TEST_PAGE);
        return;
    }
#endif
    if (ui.menu == 4) {                                /* MIDI LEARN (DUELL 1.3: was GLO's page): the same */
        draw_page_screen(&MLEARN_PAGE);
        if (!ui.msg_t)                                  /* (owner 2026-11-15: titled SETTINGS > MIDI > MIDI LEARN, over the page's own title; a message stays the page header's) */
            menu_head();
        return;
    }
#if DUELL_BENCH
    if (ui.menu == 5) {                                /* BENCH (bench builds): src/bench.c draws it */
        bench_draw();
        return;
    }
#endif
    {   /* DUELL 1.1 general rule: every row's value, whatever variable it lives in */
        uint32_t r;
        sig = 2166136261u;
        for (r = 0; r < MI_COUNT; r++)
            sig = (sig ^ menu_get(r)) * 16777619u;
    }
    sig += ui.menu * 7u + ui.menu_sel * 131u + settings.palette * 1009u + settings_hold * 3511u +
          settings_leds * 6151u + ui_prefs * 4099u + song.rec * 65537u + song.sel * 13u +
          ui_rec_prefs * 92821u + ui_scr * 131071u +          /* (#157: SCREEN OFF's value redraws its row) */
          ui_prefs2 * 524287u + ui_idle * 1048573u +      /* (1.2: ANIM IDLE's value redraws its row) */
          SENSE_SIG + (uint32_t)ui_notes_off * 40503u +   /* (DUELL 1.1: KEY VELOCITY and AFTERTOUCH keep their curve here, NOTES LEFT its bit: the card was stale until the page was left, test3) */
          (uint32_t)(song.g[G_TUNE] + 64) * 8191u + ui_home_pg * 27449u +   /* (1.2: the project's row; DUELL: HOME OPENS) */
          (ui.menu == 2 ? ui.menu_scroll * 48611u + about_sig() * 40507u + about_step() * 6007u : 0u);
    if (ui.msg_t && !--ui.msg_t && ui.msg2[0]) {       /* (owner 2026-11-15: a message shows in the title row here too, as on every page) */
        str_cpy(ui.msg, ui.msg2, sizeof ui.msg);
        ui.msg2[0] = 0;
        ui.msg_t = 60;
    }
    sig += ui.msg_t ? 0x9E3779B9u + (uint32_t)ui.msg[0] * 977u : 0u;
    if (!ui.force && sig == ui.menu_sig)
        return;
    ui.menu_sig = sig;
    if (ui.menu == 2 && !ui.menu_scroll) {             /* ABOUT's first view: the splash drawing, endless (the footer hint on it) */
        splash_frame(about_step(), ABOUT_KY);
        return;
    }
    menu_head();
    if (ui.menu == 2) {
        int32_t scroll = ui.menu_scroll, max = menu_scroll_max();
        int32_t thumb = MENU_DOC_H * MENU_DOC_H / (max + MENU_DOC_H);
        if (thumb < 12) thumb = 12;
        for (pass = 0; pass < 2u; pass++) {
            CV_BANDS(240, pass ? MENU_DOC_H - 124u : 124u, T_BG) {                 /* (in bands: gfx.c CV_BANDS) */
                cv_bg = T_BG;
                cv_oy = pass ? -124 : 0;
                cv_scroll = 1;
                menu_document(-scroll, 1);
                cv_scroll = 0;
                cv_rrect(229, 4, 3, MENU_DOC_H - 8, 1, T_LINE, T_BG);           /* the scroll bar */
                cv_rrect(229, 4 + (max ? scroll * (MENU_DOC_H - 8 - thumb) / max : 0), 3, thumb, 1, T_MID, T_LINE);
                cv_oy = 0;
                cv_blit(0, H_HEAD + pass * 124u + (uint32_t)cv_by);
            }
        }
        cv_begin(240, 240 - (H_HEAD + MENU_DOC_H), T_BG);
        about_keys(ABOUT_KY - (H_HEAD + MENU_DOC_H));
        cv_blit(0, H_HEAD + MENU_DOC_H);
        return;
    }
    first = mtab_first(menu_tab());
    last = mtab_end(menu_tab());
    pg = menu_page();
    end = list ? MTAB_LIST : 0u;
    for (k = first; !list && k < last; k++)            /* (the page's last unit: the panel's end) */
        if (menu_shown(k) && menu_place(k, &u) == pg && u + menu_units(k) > end)
            end = u + menu_units(k);
    split = list ? (uint32_t)mu_y(4) - 1u : menu_split(first, last, pg, end);
    for (pass = 0; pass < 2u; pass++) {
        int32_t top_y = pass ? (int32_t)split : H_HEAD;
        CV_BANDS(240, pass ? 240u - split : split - H_HEAD, T_BG) {                 /* (in bands: gfx.c CV_BANDS) */
            cv_oy = -top_y;                               /* drawn in screen rows */
            if (list) {
                for (k = pass ? 4u : 0u; k < (pass ? MTAB_LIST : 4u); k++)
                    menu_sec_row(k);
            } else
                for (k = first; k < last; k++)
                    if (menu_shown(k) && menu_place(k, &u) == pg && mu_y(u) + (int32_t)menu_units(k) * MU_P - 1 > top_y && mu_y(u) - 1 < top_y + (int32_t)CV_FULL_H)
                        menu_row(k);
            if (pass && list)
                cv_key_row(8, 232, MK_Y, (const khint_t[3]){KEYS[4], KEYS[0], KEYS[2]}, 3u, 7u, T_BG);   /* (owner 2026-11-15: SELECT ROW on the list too, so OPEN fits; was SELECT SECTION) */   /* (owner 2026-11-15: OCT- BACK at the left, the way back; forward to the right) */
            else if (pass) {
                int32_t xe = 232;                             /* (1.3: the page counter is in the title row now, menu_head: the footer has room for OCT- BACK) */
                if (MI_READONLY(ui.menu_sel) || MI_OPENS(ui.menu_sel) || ui.menu_sel == MI_ERASE)   /* TEST, ABOUT, SIDECHAIN, MIDI LEARN, ERASE DATA: SELECT picks the row, OCT+ opens it (owner 2026-11-15: OCT+ is the open, as everywhere; was KNOB 1 OPEN) */
                    cv_key_row(8, xe, MK_Y, (const khint_t[3]){KEYS[5], KEYS[0], KEYS[2]}, 3u, 7u, T_BG);
                else if (menu_valued(ui.menu_sel))
                    cv_key_row(8, xe, MK_Y, (const khint_t[3]){KEYS[5], KEYS[0], KEYS[1]}, 3u, 7u, T_BG);
                else
                    cv_key_row(8, xe, MK_Y, (const khint_t[2]){KEYS[5], KEYS[0]}, 2u, 3u, T_BG);
            }
            cv_oy = 0;
            cv_blit(0, (uint32_t)top_y + (uint32_t)cv_by);
        }
    }
}
static void enc_drop(void)                             /* knob turns nobody takes */
{
    uint32_t k;
    for (k = 0; k < NE; k++)
        panel_enc(k);
}

static void menu_close(void)
{
    if (ui.confirm == CF_ERASE_ALL)                    /* (HOME in the ERASE DATA dialog: cancelled, nothing erased) */
        ui.confirm = 0;
    settings_save();                                   /* palette / panel table, if changed */
    ui.menu = 0;
    ui.force = 1;
    go_main();
}
/* DUELL 1.3: open section t of the list (or MIDI's SIDECHAIN) at the row last picked there */
static void menu_open_sec(uint32_t t)
{
    uint32_t r = mtab_first(t) + ui.menu_row[t];
    if (r >= mtab_end(t) || !menu_shown(r))
        for (r = mtab_first(t); r + 1u < mtab_end(t) && !menu_shown(r); r++)
            ;
    ui.menu_sel = (uint8_t)r;
    ui.menu = 1;
    ui.force = 1;
}

/* menu (SPEC 1.1a; DUELL 1.3 sections): in the list SELECT picks a section and OCT+ opens it; in a section SELECT walks its rows (stopping at its first and
 * last row, no wrap), in ABOUT it jumps between sections (KNOB 1 scrolls there); KNOB 1..4 (any of them) change the selected row's value (menu_items.c menu_step), OCT+
 * opens the rows that open something (a knob right too: TEST, GUIDE, ABOUT, SIDECHAIN, MIDI LEARN); OCT- goes back: from a section to the list, from SIDECHAIN to MIDI,
 * from TEST, ABOUT and MIDI LEARN to their section. ALGORITHM and PRESETS do nothing here. HOME closes it, from them too (ui_input.c) */
static void menu_move(int32_t s)                       /* SELECT: the next / previous row of the section, clamped; a row without a place is passed by */
{
    int32_t dir = s < 0 ? -1 : 1, r = (int32_t)ui.menu_sel, n = s < 0 ? -s : s;
    uint32_t t = menu_tab(), f = mtab_first(t), e = mtab_end(t);
    for (; n > 0; n--) {
        int32_t q = r + dir;
        while (q >= (int32_t)f && q < (int32_t)e && !menu_shown((uint32_t)q))
            q += dir;
        if (q < (int32_t)f || q >= (int32_t)e)
            break;
        r = q;
    }
    ui.menu_sel = (uint8_t)r;
    ui.menu_row[t] = (uint8_t)(ui.menu_sel - f);
}
static int32_t accel(uint32_t role, int32_t s, int32_t range);   /* (ui_input.c, KNOB ACCEL) */
static int32_t kr_pass(uint32_t k, int32_t s);         /* (ui_input.c: a jump's twist swallowed) */
static void menu_input(uint32_t oct)                  /* oct: ui_input.c oct_taps */
{
    int32_t s;
    uint32_t k, up = (oct >> 1) & 1u, dn = oct & 1u;
    if (panel_enc(EN_PRESET) | panel_enc(EN_ALGO))     /* PRESETS, ALGORITHM: nothing here (SPEC 1.1a); owner 2026-11-15 (one rule for SETTINGS): the title says why, as the GUIDE does */
        ui_message("HOME CLOSES SETTINGS");
    if (ui.menu == 6) {                                /* DUELL 1.3: the list of the sections */
        if ((s = panel_enc(EN_SELECT)) != 0) {
            k = (uint32_t)clamp((int32_t)menu_sec() + clamp(s, -8, 8), 0, MTAB_LIST - 1);
            ui.menu_sel = (uint8_t)(mtab_first(k) + ui.menu_row[k]);
        }
        for (k = 0; k < 4u; k++)                        /* (owner 2026-11-16: the knobs only change values, never open or turn pages: nothing here) */
            kr_pass(k, panel_enc(EN_K1 + k));
        if (up)
            menu_open_sec(menu_sec());
        else if (dn)                                    /* (one rule: OCT- one level back; from the list that is out of SETTINGS) */
            menu_close();
        enc_drop();
        return;
    }
    if (ui.menu == 3 || ui.menu == 4) {                /* TEST, MIDI LEARN: KNOB 1..4 are its own (TEST: K1 MORPH both ways: not a way back); OCT- goes back to the
                                                        * section, HOME and a page button close the menu; SELECT and OCT+ do nothing here */
        uint8_t layer = ui.layer;
        if (ui.menu == 4 && up) {                       /* owner 2026-11-15 (as TOOLS): OCT+ does the picked card: LEARN starts, learning: DONE ends it; CLEAR ALL asks */
            if (ui.ml.on)
                ml_oct(2u);
            else if (ml_act == 1u)
                ml_toggle();
            else if (ml_act == 2u) {
                if (ml_count()) {
                    ui.confirm = CF_ML_CLEAR;
                    ui.confirm_trk = 0;
                } else
                    ui_message("NOTHING LEARNED");
            }
            if (ui.confirm != CF_ML_CLEAR)
                ml_act = 0;
            ui.force = 1;
            enc_drop();
            return;
        }
        if (dn) {                                       /* OCT- back: a picked card dropped first (as TOOLS), else back to the section */
            if (ui.menu == 4 && ml_act)
                ml_act = 0;
            else
                ui.menu = 1;
            ui.force = 1;
            enc_drop();
            return;
        }
        ui.layer = 0;
#if DUELL_TEST_MODE
        page_over = ui.menu == 3 ? &TEST_PAGE : &MLEARN_PAGE;
#else
        page_over = &MLEARN_PAGE;
#endif
        for (k = 0; k < 4u; k++)
            if ((s = panel_enc(EN_K1 + k)) != 0) {
                ui.hot_col = (uint8_t)k;
                ui.hot_t = 40;
                edit_param(k, s);
            }
        page_over = 0;
        ui.layer = layer;
        enc_drop();
        return;
    }
    if (ui.menu == 2) {                                /* ABOUT (0.2.9, the owner): KNOB 1 scrolls (right down, left up; bounded), SELECT
                                                        * jumps to the next / previous section (about_section); OCT- back to SYSTEM,
                                                        * HOME closes; KNOB 2..4, PRESETS, ALGORITHM nothing */
        if (dn) {
            ui.menu = 1, ui.force = 1;
            enc_drop();
            return;
        }
        if ((s = panel_enc(EN_K1)) != 0)
            ui.menu_scroll = (uint16_t)clamp((int32_t)ui.menu_scroll + clamp(s, -128, 128) * 18, 0, menu_scroll_max());
        for (s = clamp(panel_enc(EN_SELECT), -4, 4); s; s -= s > 0 ? 1 : -1)   /* (a section a detent) */
            ui.menu_scroll = (uint16_t)about_section(ui.menu_scroll, s);
        enc_drop();
        return;
    }
    if (dn) {                                          /* DUELL 1.3: OCT- back: SIDECHAIN to MIDI's row, a section to the list */
        if (menu_tab() == MTAB_SCHAIN)
            ui.menu_sel = MI_SCHAIN;
        else
            ui.menu = 6;
        ui.force = 1;
        enc_drop();
        return;
    }
    if ((s = panel_enc(EN_SELECT)) != 0)
        menu_move(s);
    for (s = 0, k = 0; k < 4u; k++) {                  /* KNOB 1..4, any of them */
        int32_t e = kr_pass(k, panel_enc(EN_K1 + k));
        s += ui.menu_sel == MI_TUNE ? accel(EN_K1 + k, e, (int32_t)TUNE_N) :   /* (0.2.22: TUNE has 510 steps: with KNOB ACCEL ON a fast turn goes x2 .. x8, ui_input.c accel; the other rows as ever) */
             ui.menu_sel == MI_SC1NT || ui.menu_sel == MI_SC2NT || ui.menu_sel == MI_SPLIT ? accel(EN_K1 + k, e, 127) :   /* (SIDECHAIN's notes: as GLO > SIDECHAIN's knob; SPLIT as the MODE page's) */
             ui.menu_sel == MI_XFADE ? accel(EN_K1 + k, e, 100) : e;
    }
    if (menu_valued(ui.menu_sel)) {
        if (s) {                                       /* a step; COLOR previews the palette */
            uint32_t was = menu_get(ui.menu_sel);
            menu_put(ui.menu_sel, menu_step(ui.menu_sel, s));
            if (menu_get(ui.menu_sel) != was && !MI_PROJECT(ui.menu_sel)) {   /* DUELL 0.2.2: a changed setting is saved now, not when the */
                if (menu_n(ui.menu_sel) == 2u)                                /* menu is left: a two-value switch at once, any other once the */
                    settings_save();                                          /* knob has rested ~2 s (the AMOUNT knob's debounce, ui_input.c */
                else {                                                        /* morph_settings); while playing the write waits (settings_poll) */
                    ui.mset_dirty = 1;
                    ui.mset_t = fm1_ms;
                }
            }
        }
    } else if (up) {                                   /* OCT+ opens ERASE DATA (its dialog asks), TEST, GUIDE, ABOUT, SIDECHAIN, MIDI LEARN; owner 2026-11-16: the knobs only change values, never open */
        if (ui.menu_sel == MI_SCHAIN) {                 /* DUELL 1.3: its four values */
            menu_open_sec(MTAB_SCHAIN);
        } else if (ui.menu_sel == MI_MLEARN) {          /* DUELL 1.3: the MIDI LEARN screen, as GLO's page was */
            ui.menu = 4;
            ml_act = 0;                                 /* (nothing picked on opening) */
            ui.force = 1;
        } else if (ui.menu_sel == MI_ERASE) {           /* DUELL 0.2.2: the dialog over the menu (ui_input.c: OCT+ YES, OCT- NO) */
            ui.confirm = CF_ERASE_ALL;
            ui.confirm_trk = 0;
            ui.force = 1;
#if DUELL_TEST_MODE
        } else if (ui.menu_sel == MI_TEST) {
            ui.menu = 3;
            cpu_meter_open();                           /* (the CPU meter's window begins) */
            ui.force = 1;
#endif
        } else if (ui.menu_sel == MI_GUIDE) {           /* DUELL 0.2.11: the first-start GUIDE's pages, over the menu (ui_guide.c); the bit untouched */
            guide_open(1);
        } else if (ui.menu_sel == MI_ABOUT) {
            ui.menu = 2;
            about_t0 = fm1_ms;
            cpu_meter_open();
            ui.menu_scroll = 0;
            ui.force = 1;
        }
    }
    enc_drop();                                        /* swallow the rest while the menu is up */
}
