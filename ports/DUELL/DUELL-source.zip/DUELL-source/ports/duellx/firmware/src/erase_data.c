/* SPDX-License-Identifier: GPL-3.0-only */
/* DUELL 0.2.2: ERASE DATA, start from scratch. MENU > SYSTEM > ERASE DATA (after its dialog, ui_input.c) and the editor's
 * ERASE_ALL (cmd 80, editor_erase.c, with its token) run the same erase_data_run(); included by project.c.
 *
 * What goes (flash objects, storage.c; a stored object is the A/B pair of sectors, both erased by st_wipe):
 *   the autosave (OBJ_AUTOSAVE), the pattern slots (OBJ_PATSLOT0..2), the multis (OBJ_MULTI0..7: M01..M16 are
 *   the default ones again, ROM), the patch store (OBJ_PATCH0..5 and, DUELL 0.2.15, OBJ_PATCHX0..9, the cloud plan's job A: OBJ_PATCHX0..15 (chunks 6..21): every stored patch and every default sound's shadow copy),
 *   the user wavetables (OBJ_WTAB0..2, DUELL 0.2.14: USR1..USR3 are EMPTY again), DUELL 1.1 (item 91, owner: erase EVERYTHING the user stored) the FM6
 *   voice bank (0xE7000), and the settings (OBJ_SETTINGS: theme, scale, MIDI channels and MIDI MAP / LEARN, the favourites, the preferences). The theme's RAM
 *   copy (`settings`, .noinit, survives the restart) is reset by persist_boot when no record is found (project.c).
 * The velocity calibration (OBJ_VELO, 0xC6000..0xC7FFF, sense.c) STAYS (owner, item 103: it belongs to this unit's key sensors, not to the user's data; it is not in the erase list). The button / knob map (`panel`, .noinit and the settings record) is the built-in one again (project.c persist_boot).
 * What stays: the RAM safety records (crash, boot guard, second core, diagnostics: never user data, gone at power-off) and the firmware itself (DUELL 0.2.9: the user sample slots are gone with the SAMPLE engine; the rest of
 * their flash (0xA6000..0xC5FFF is the patch store's chunks 6..21 and 0xC6000..0xC7FFF OBJ_VELO, above), is not touched; 0xA0000..0xA5FFF is the user wavetables, above).
 *
 * Order and power cuts: the objects in that order, the SETTINGS LAST. Every object is erased copy by copy (st_wipe: the
 * copy that is not the current one first), so a cut at any point leaves each object either whole as it was or empty; nothing
 * older comes back. The settings being last matters at boot: the unit starts as a NEW unit (VIOLET, LAYER, M01: persist_boot
 * finds no valid settings, ui_input.c first_boot_poll) only once everything else is gone. A cut before that boots as the
 * unit was left, with less of its data (the autosave, patterns, multis or patches already erased, the default ones in
 * their place), and ERASE DATA can simply be run again; a cut after the settings' first sector leaves the other, whole copy
 * of them and is the same case. Nothing is half-valid: a commit record is valid or the object is empty.
 *
 * After it the unit restarts (erase_restart_due, main.c: the chip reset; the browser build reloads the page) so every
 * RAM copy (patch store, multis, pattern slots, settings) is read from the now empty flash: the first-start path. Until
 * then nothing may write the old state back: erase_busy blocks the settings / pattern slot / autosave writers. */
#if FELUCCA_FLASH
#ifndef ERASE_FEED
#define ERASE_FEED() ((void)0)                    /* (felucca.c: fm1_wdt_feed(); the host tests have none) */
#endif
#define ERASE_RESTART_MS 700u                    /* the message is seen / the editor's reply leaves before the restart */
static uint32_t erase_at;                        /* fm1_ms | 1 when the restart is due (0: none) */

static int erase_busy(void) { return erase_at != 0u; }
static int erase_restart_due(void) { return erase_at && (int32_t)(fm1_ms - (erase_at & ~1u)) >= 0; }

/* 0 done (the restart follows), 3 stop playback first, 4 the flash failed (some objects may be gone already: run it again;
 * the settings were not touched, so the unit is not a new unit) */
static int erase_data_run(void)
{
    static const uint8_t ORDER[] = {OBJ_AUTOSAVE, OBJ_PATSLOT0, OBJ_PATSLOT0 + 1, OBJ_PATSLOT0 + 2,
                                    OBJ_MULTI0, OBJ_MULTI0 + 1, OBJ_MULTI0 + 2, OBJ_MULTI0 + 3,
                                    OBJ_MULTI0 + 4, OBJ_MULTI0 + 5, OBJ_MULTI0 + 6, OBJ_MULTI0 + 7,
                                    OBJ_PATCH0, OBJ_PATCH0 + 1, OBJ_PATCH0 + 2, OBJ_PATCH0 + 3, OBJ_PATCH0 + 4, OBJ_PATCH0 + 5,
                                    OBJ_PATCHX0, OBJ_PATCHX0 + 1, OBJ_PATCHX0 + 2, OBJ_PATCHX0 + 3, OBJ_PATCHX0 + 4,
                                    OBJ_PATCHX0 + 5, OBJ_PATCHX0 + 6, OBJ_PATCHX0 + 7, OBJ_PATCHX0 + 8, OBJ_PATCHX0 + 9,
                                    OBJ_PATCHX0 + 10, OBJ_PATCHX0 + 11, OBJ_PATCHX0 + 12, OBJ_PATCHX0 + 13, OBJ_PATCHX0 + 14,
                                    OBJ_PATCHX0 + 15,   /* (item 103, owner: OBJ_VELO, the key velocity calibration, is the unit's, not user data: KEPT) */
                                    OBJ_WTAB0, OBJ_WTAB0 + 1, OBJ_WTAB0 + 2,
                                    OBJ_SETTINGS};
    uint32_t i, failed = 0;
    if (transport_busy())
        return 3;
    if (!flash_ok || erase_at)
        return 4;
    persist_pending = 0;                         /* nothing queued is written over the empty flash */
    ps_dirty = 0;
    as.wrote = 1;                                /* and no autosave for the next 60 s (autosave_poll's gap) */
    as.last = fm1_ms;
    as.err = 0;
    for (i = 0; i < sizeof ORDER; i++) {           /* DUELL 1.1 (owner, test3: the settings and multis stayed): an object that cannot be wiped no longer stops the erase before the rest and the settings: every object is tried, the */
        if (ORDER[i] == OBJ_SETTINGS && !st_blank(FVB_HOME) && st_erase(FVB_HOME))   /* DUELL 1.1 (item 91): the FM6 voice bank the editor loaded (0xE7000, fm6_vbank.c; */
            failed = 1;                             /* its staged copy lives in the autosave's sectors, wiped above) goes too, just before the settings */
        if (st_wipe(ORDER[i]))                      /* settings last as ever, and the failure is told after all of it (rc 4); the unit restarts when the settings went, so it never comes up half old */
            failed = 1;
        ERASE_FEED();
    }
    if (failed) {
        persist_t pr;
        if (st_load(OBJ_SETTINGS, &pr, sizeof pr) != (int)sizeof pr)
            failed = 2;                             /* (the settings are gone: the next start is a new unit; the object that failed is told with rc 4 and can be erased again from the menu) */
    }
    erase_at = (fm1_ms + ERASE_RESTART_MS) | 1u;
    return failed ? 4 : 0;   /* (the unit restarts either way: erase_at is set) */
}
#else
static int erase_busy(void) { return 0; }
static int erase_restart_due(void) { return 0; }
static int erase_data_run(void) { return 4; }
#endif
