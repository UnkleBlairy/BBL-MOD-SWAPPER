/* SPDX-License-Identifier: GPL-3.0-only */
/* DUELL 0.2.11: the first-start GUIDE (SPEC "First-start guide"; docs/GUIDE_PLAN.md, the owner's pages). Included at the end of ui_layer.c.
 *   WHEN       once, after the power-on splash, while the settings bit "guide seen" (ui.c PREF_GUIDE_SEEN, bit 5 of [15][24]) is clear: a
 *              new unit, a flash erase, and any settings record of an older build (the bit was never written before), so an update
 *              shows it once too. The splash then stays GUIDE_SPLASH_MS longer (ui_draw.c splash_draw). Leaving it, or finishing it,
 *              sets the bit and writes the settings once (settings_save: the write waits for silence, as every settings write since 0.2.11: project.c settings_poll).
 *              Power off with the guide up: the bit stays clear, so the next start shows it again.
 *              MENU > SYSTEM > GUIDE opens the same pages at any time; that never touches the bit.
 *   PAGES      GUIDE_N full-screen pages over whatever page is under them: the header (item 118: its title SETUP or GUIDE, no counter in it), the text, the legend row
 *              (rows 197 .. 209: OCT + NEXT, OCT - BACK, HOME SKIP) and the SHARED footer (engine, patch, the counter 1/5, battery: ui_draw.c draw_foot). A page's text: "#" a heading (L, the theme colour), "~" a
 *              small gap, "*" a line whose words up to its first ':' are in the theme colour (what it is, then how), else a line
 *              (M, the text colour); each line at most GD_W px (the layout lint, tests/ui_render.c, checks
 *              every page in every palette).
 *   KEYS       SELECT right / OCT+ the next page, SELECT left / OCT- the previous one (SELECT stops at both ends, OCT+ on the last
 *              page finishes); HOME leaves at once (from the MENU it closes the menu, as HOME does there); EDIT FX ENV LFO ARP
 *              SCL GLO SEQ SAVE leave at once and go on to their own job, in the same press (as they leave the MENU); PLAY/STOP and
 *              REC (the HOLD switch) work as on HOME; the keys and MIDI play as ever. KNOB 1-4, PRESETS and ALGORITHM do nothing (the header
 *              says "[HOME] CLOSES GUIDE" for a moment, so no turn is silently ignored). */
#define GD_X UT_T6_X                                    /* the text's left edge (item 118: x 9, as the picture; was 12) */
#define GD_W (240 - 2 * UT_T6_X)                        /* the text's room: x 9 .. 230 */
#define GD_HINT_Y UT_T6_END                             /* the body's end (item 118): the legend row is drawn in the last strip, the shared footer (draw_foot) owns rows 217 .. 239 */
static uint8_t guide_pick[2];                           /* DUELL 1.3 (owner 2026-11-15): the option picked on SETUP 1/5 (0 KEYS, 1 CIRCUIT TRACKS, 2 MPC/FORCE: the MIDI PRESET) and on SETUP 2/5 (0 LAYER, 1 STEREO, 2 DUEL) */
#define GUIDE_KNOB_MSG "HOME CLOSES GUIDE"              /* (owner 2026-11-15: one wording with SETTINGS' "HOME CLOSES SETTINGS"; was HOME ENDS THE GUIDE) */            /* a knob turned while it is up (it does nothing there) */
static const khint_t *guide_kh;                       /* the key hints drawn last (the host test reads them) */
static uint32_t guide_sig;                              /* the page drawn last (+ 1; 0: draw it) */
static char sp_guide[241];                              /* DUELL 1.4: the page's words as drawn last, for the screen reader (ui_speak.c) */
static char sp_guide_keys[72];                          /* .. and its legend row (said after the words) */
#if SMK_SCREEN
static uint32_t guide_lo(void) { return ui.guide_menu ? 3u : 2u; }          /* (the SMK-37: no device page, it is its own keyboard) */
#else
static uint32_t guide_lo(void) { return ui.guide_menu ? 3u : 1u; }
#endif          /* the first and the last page shown (the menu's: the GUIDE pages only) */
static uint32_t guide_hi(void) { return GUIDE_N; }
static int guide_ask(uint32_t pg) { return pg == 1u || pg == 2u; }          /* SETUP pages ask (DUELL 1.3: the device, then the mode), GUIDE pages tell */
/* SETUP 2/5's recommended mode for the device picked on SETUP 1/5 (owner 2026-11-15): KEYS LAYER, CIRCUIT TRACKS DUEL, MPC/FORCE STEREO */
static uint32_t guide_rec_mode(void) { return guide_pick[0] == 1u ? 2u : guide_pick[0] == 2u ? 1u : 0u; }

#if DUELL_BENCH
/* (DUELL_BENCH developer builds, HANDOFF_V2 item 107: the first-start guide is not built in, so XIP holds the CPU suite and the velocity capture together:
 * it counts as seen, so no start shows it and the splash is not stretched; the pages' text and the H / G heading faces (about 19 KB) are left out.
 * The GUIDE row is the BENCH row there; nothing of the audio side is touched.) */
static int guide_seen(void) { return 1; }
#else
static int guide_seen(void) { return (ui_prefs2 & (PREF_GUIDE_SEEN >> 16)) != 0u; }
#endif
/* opened: by the splash's end (from_menu 0: the first start, all five pages) or MENU > SYSTEM > GUIDE (1: the three GUIDE pages) */
static void guide_open(uint32_t from_menu)
{
#if DUELL_BENCH
    if (from_menu) {                                    /* (bench builds: the GUIDE row is the BENCH row, menu_items.c: it opens the BENCH screen, src/bench.c;
                                                         * the first start's guide opens as ever) */
        ui.menu = 5;
        bench_open();
        ui.force = 1;
        return;
    }
#endif
    ui.guide_menu = (uint8_t)(from_menu != 0u);
    ui.guide = (uint8_t)guide_lo();
    guide_pick[0] = 0;
    guide_pick[1] = 0;
    guide_sig = 0;
    ui.force = 1;
    if (!from_menu) {                                   /* (a fresh unit's "LOADED" of M01, made under the splash: not over the first page) */
        ui.msg_t = 0;
        ui.msg2[0] = 0;
    }
}
/* left or finished: the first start's guide sets the bit and writes the settings once; the MENU's never touches it (and goes
 * back to the MENU, which is still open under it) */
static void guide_close(void)
{
    uint32_t first = !ui.guide_menu;
    ui.guide = 0;
    ui.guide_menu = 0;
    ui.force = 1;
    if (first && !guide_seen()) {
        ui_prefs2 |= (uint8_t)(PREF_GUIDE_SEEN >> 16);
        settings_save();
    }
}
static void guide_page(int32_t d)                      /* the next / previous page, stopping at both ends */
{
    ui.guide = (uint8_t)clamp((int32_t)ui.guide + d, (int32_t)guide_lo(), (int32_t)guide_hi());
}
/* the choice of the page just left: SETUP 1/5 sets the MIDI PRESET (KEYS: STANDARD) and ticks its recommended mode on SETUP 2/5; SETUP 2/5 sets the mode (the audio takes it at its next block, seq.c mode_apply) */
static void guide_apply(uint32_t pg)
{
    if (ui.guide_menu)
        return;
    if (pg == 1u) {
        mac_preset_put(guide_pick[0] == 1u ? MPRE_CIRCUIT : guide_pick[0] == 2u ? MPRE_MPC : MPRE_STANDARD);
        guide_pick[1] = (uint8_t)guide_rec_mode();
    } else if (pg == 2u)
        duell_mode_req = (uint8_t)(guide_pick[1] == 0u ? DM_LAYER : guide_pick[1] == 1u ? DM_STEREO : DM_SPLIT);
}

/* ui_input, while it is up (after the HOME and REC button timers). 1: it took this frame's input; 0: it closed for a page button or
 * SAVE, whose press goes on through ui_input to its job */
static void play_press(uint32_t now);                   /* (ui_input.c: PLAY/STOP pressed) */
static int guide_input(uint32_t pressed, uint32_t rec, uint32_t now)
{
    int32_t s;
    if ((pressed >> panel.btn[B_HOME]) & 1u) {          /* HOME: leave at once (used up: no tap, no menu) */
        guide_close();
        ui.home_t0 |= 2u;
        if (ui.menu)
            menu_close();                               /* (as HOME closes the MENU) */
        enc_drop();
        return 1;
    }
    if (leave_pressed(pressed) || ((pressed >> panel.btn[B_SAVE]) & 1u)) {
        guide_close();
        return 0;
    }
    if ((pressed >> panel.btn[B_PLAY]) & 1u)            /* PLAY/STOP as on HOME (twice: STOP ALL); its hold: play_hold */
        play_press(now);
    if (rec == BT_TAP) {                                /* REC: the HOLD switch (rec_tap: rec_is_hold on HOME; owner 2026-11-15: from SETTINGS too, as SETTINGS does) */
        if (ui.menu)
            rec_hold_tap();
        else
            rec_tap();
    }
    song.grid = (uint8_t)keys_mode();                   /* (the keys play) */
    if ((pressed >> panel.btn[B_OCTUP]) & 1u) {
        guide_apply(ui.guide);
        if (ui.guide >= guide_hi()) {                   /* OCT+ on the last page: done */
            guide_close();
            enc_drop();
            return 1;
        }
        guide_page(1);
    }
    if ((pressed >> panel.btn[B_OCTDN]) & 1u)
        guide_page(-1);
    s = panel_enc(EN_SELECT);
    if (guide_ask(ui.guide) && !ui.guide_menu) {      /* SETUP 1/5 and 2/5: KNOB 1 (shown), 2, 3 and 4 (silently) turn through the options (owner 2026-11-16: the knobs never turn pages) */
        uint32_t k;
        for (k = EN_K1; k <= EN_K4; k++) {
            int32_t d = panel_enc(k);
            if (d)
                s = d;
        }
    }
    if (s != 0) {
        if (guide_ask(ui.guide) && !ui.guide_menu) {    /* a question: SELECT picks the option */
            uint32_t pk = ui.guide == 1u ? 0u : 1u, n = 3u;
            guide_pick[pk] = (uint8_t)clamp((int32_t)guide_pick[pk] + (s > 0 ? 1 : -1), 0, (int32_t)n - 1);
        } else
            guide_page(s > 0 ? 1 : -1);
    }
    {   /* KNOB 1-4, PRESETS, ALGORITHM: nothing changes, and the header says why (no silently ignored control) */
        uint32_t k, any = 0;
        for (k = 0; k < NE; k++)
            any |= k != EN_SELECT && !(guide_ask(ui.guide) && !ui.guide_menu) && panel_enc(k) != 0;   /* (a SETUP question: no message at all) */
        if (any)
            ui_message(GUIDE_KNOB_MSG);
    }
    return 1;
}

static int32_t guide_last_x;                           /* the right end of the last line guide_wrap drew */
/* a text wrapped at spaces into lines of at most w px at pitch p from (x, y); the y after it */
static int32_t guide_wrap(int32_t x, int32_t y, int32_t w, const aafont_t *f, const char *s, uint16_t fg, int32_t p)
{
    char ln[64];
    uint32_t n, last;
    const char *q = s;
    char *said = gfx_said;                              /* (DUELL 1.4: the screen reader takes the text whole, not its lines) */
    if (said)
        gfx_said_add(s);
    gfx_said = 0;
    while (*q) {
        last = 0;
        for (n = 0; q[n] && n + 1u < sizeof ln; n++) {
            ln[n] = q[n];
            ln[n + 1u] = 0;
            if (q[n] == ' ')
                last = n;
            if (text_w(f, ln) > w && last) {
                n = last;
                break;
            }
        }
        ln[n] = 0;
        guide_last_x = cv_text(x, y, f, ln, fg);
        y += p;
        q += n;
        while (*q == ' ')
            q++;
    }
    gfx_said = said;
    return y;
}
#if !DUELL_BENCH                                       /* (the guide's page drawing: not in a DUELL_BENCH developer build, see guide_seen) */
/* DUELL 1.1 (FIRST_RUN_SETUP_V2_A.png): a sentence (M) wrapped at spaces to w px, a word "[SAVE]" drawn as its keycap (kc_tag) in the line, centred on the line's capitals; the first line's capitals end on row `base`,
 * the next ones UT_T6_G_LINE under it; -> the last line's baseline */
#if SMK_SCREEN
/* the SMK-37's printed buttons as pills of the keycaps' look (it has none of its own): the label in S on the key colour, 13 px tall */
static int32_t smk_pill_w(const char *lb) { return text_w(&AF_S, lb) + 8; }
static int32_t smk_pill(int32_t x, int32_t y, const char *lb)
{
    int32_t pw = smk_pill_w(lb);
    cv_rrect(x, y, pw, KC_H + 1, 4, T_KEY, T_BG);         /* (one row taller than a keycap: the Q of SEQ keeps its tail inside) */
    cv_text_in(x, y + HALF_UP(KC_H - AF_S_CAP_H) - AF_S_CAP_Y, pw, &AF_S, lb, T_KINK, T_KEY);
    return x + pw;
}
static const char *smk_kc_name(uint32_t id) { return id == KC_OCTDN ? "OCT-" : id == KC_OCTUP ? "OCT+" : id == KC_HOME ? "PATCH" : 0; }   /* (the guide's legend: the SMK's buttons; OCT- / OCT+ short, owner 2026-11-20) */
static int32_t guide_kw(uint32_t id) { return smk_kc_name(id) ? smk_pill_w(smk_kc_name(id)) : kc_w(id); }
static int32_t guide_kcap(int32_t x, int32_t y, uint32_t id) { return smk_kc_name(id) ? smk_pill(x, y, smk_kc_name(id)) : cv_keycap(x, y, id, T_KEY, T_KINK, T_BG); }
#else
#define guide_kw(id) kc_w(id)
#define guide_kcap(x, y, id) cv_keycap((x), (y), (id), T_KEY, T_KINK, T_BG)
#endif
static int32_t guide_rich(int32_t x, int32_t base, int32_t w, const char *s)
{
    int32_t cx = x;
    char *said = gfx_said;                              /* (DUELL 1.4: the screen reader takes the sentence whole, its keycaps' brackets left out by ui_speak.c) */
    if (said)
        gfx_said_add(s);
    gfx_said = 0;
    while (*s) {
        char wd[24];
        uint32_t n = 0, tl = 0;
        int32_t id, wpx;
        while (*s == ' ')
            s++;
        while (s[n] && s[n] != ' ' && n + 1u < sizeof wd) {
            wd[n] = s[n];
            n++;
        }
        wd[n] = 0;
        id = kc_tag(wd, &tl);
        wpx = id >= 0 ? kc_w((uint32_t)id) : text_w(&AF_M, wd);
#if SMK_SCREEN
        if (wd[0] == '[') {                             /* the SMK-37's printed buttons, every one as a pill (also ARP, SEQ: one look) (no keycap of the FM-1's: [GLOBE], [KNOB_BANK], [NOTE_REPEAT] ..): a pill of the same look,
                                                         * its label in S, '_' a space, a mark after it (",") as the keycaps' */
            char lb[16];
            uint32_t a = 1u, b = 0, e;
            for (e = 1u; wd[e] && wd[e] != ']'; e++)
                ;
            while (a < e && b + 1u < sizeof lb)
                lb[b++] = wd[a] == '_' ? ' ' : wd[a], a++;
            lb[b] = 0;
            wpx = smk_pill_w(lb) + (wd[e] && wd[e + 1u] ? text_w(&AF_M, wd + e + 1u) : 0);
            if (cx > x && cx + wpx > x + w) {
                cx = x;
                base += UT_T6_G_LINE;
            }
            cx = smk_pill(cx, base - AF_M_CAP_H + 1 - (KC_H - AF_M_CAP_H) / 2, lb);
            if (wd[e] && wd[e + 1u])
                cx = cv_text_on(cx, UT_TY(M, base), &AF_M, wd + e + 1u, T_TEXT, T_BG);
            cx += 5;
            s += n;
            continue;
        }
#endif
        if (id >= 0 && wd[tl])                          /* (a mark after the keycap: "[OCT+]," ) */
            wpx += text_w(&AF_M, wd + tl);
        if (cx > x && cx + wpx > x + w) {
            cx = x;
            base += UT_T6_G_LINE;
        }
        if (id >= 0) {
            cx = cv_keycap(cx, base - AF_M_CAP_H + 1 - (KC_H - AF_M_CAP_H) / 2, (uint32_t)id, T_KEY, T_KINK, T_BG);
            if (wd[tl])
                cx = cv_text_on(cx, UT_TY(M, base), &AF_M, wd + tl, T_TEXT, T_BG);
        } else
            cx = cv_text_on(cx, UT_TY(M, base), &AF_M, wd, T_TEXT, T_BG);
        cx += 5;
        s += n;
    }
    gfx_said = said;
    return base;
}
/* TEMPLATE 6 (item 118; ui_tokens.h): the rows of one option block */
typedef struct { int16_t top, h, nbase, dbase; } t6_opt_t;
/* a question's option: the picked one on a box of the selected part's colour (hard corners), its name (L, white) on baseline nbase, up to three explanation lines (S; grey, lilac on the box) from dbase, 15 px apart, a pill (RECOMMENDED,
 * DEFAULT) after the name in the part's colour, as tall as the name's capitals */
static void guide_option(const t6_opt_t *g, const char *name, const char *d1, const char *d2, const char *d3, const char *tag, uint32_t picked)
{
    const char *d[3];
    uint32_t i;
    uint16_t pc = T_PTHEME(song.sel), sel = ux_mix(T_BG, pc, UT_T6_SEL_PCT), fill = picked ? sel : T_BG;
    uint16_t grey = ux_mix(T_BG, T_TEXT, UT_GREY_PCT), lilac = ux_mix(sel, T_TEXT, UT_T6_DESC_SEL_PCT);
    int32_t nx;
    d[0] = d1;
    d[1] = d2;
    d[2] = d3;
    if (picked)
        { CV_HL(UT_T6_BOX_X, g->top, UT_T6_BOX_W, g->h); cv_card(UT_T6_BOX_X, g->top, UT_T6_BOX_W, g->h, sel, T_BG); }
    nx = cv_text_on(GD_X, UT_TY(L, g->nbase), &AF_L, name, T_TEXT, fill);
    if (tag[0]) {
        int32_t pw = text_w(&AF_S, tag) + 2 * UT_T6_PILL_PAD, ph = AF_L_CAP_H, px = nx + UT_T6_PILL_GAP, py = g->nbase - ph + 1;
        uint16_t ink = ux_cr(T_TEXT, pc) >= 300u ? T_TEXT : ux_cr(T_BG, pc) >= ux_cr(T_TEXT, pc) ? T_BG : T_TEXT;
        cv_rrect(px, py, pw, ph, UT_T6_PILL_R, pc, fill);
        cv_text_in(px, py + HALF_UP(ph - AF_S_CAP_H) - AF_S_CAP_Y, pw, &AF_S, tag, ink, pc);
    }
    for (i = 0; i < 3u; i++)
        if (d[i][0])
            cv_text_on(GD_X, UT_TY(S, g->dbase + (int32_t)i * UT_T6_LINE), &AF_S, d[i], picked ? lilac : grey, fill);
}
/* a thin line from (x, y0) down to y and right to x1 (the AVAILABLE VOICES notes' leaders) */
static void guide_leader(int32_t x, int32_t y0, int32_t y, int32_t x1)
{
    cv_rect(x, y0, 1, y - y0 + 1, T_MID);
    if (x1 < x)
        cv_rect(x1, y, x - x1 + 1, 1, T_MID);
    else
        cv_rect(x, y, x1 - x, 1, T_MID);
}
/* from (x, y) right to xc, then up to y1 (the leader of a note to its item in the capsule) */
#if SMK_SCREEN
#define GD_CAP_END (50 + CAP_Y + CAP_H + 2)             /* (the SMK-37, owner 2026-11-20: the pointers stop under the capsule, they never enter it) */
#else
#define GD_CAP_END 65
#endif
static void guide_leader2(int32_t x, int32_t y, int32_t xc, int32_t y1)   /* (owner 2026-11-15: in the selected part's colour, as the GUIDE pages' headings) */
{
    cv_rect(x, y, xc - x + 1, 1, T_PTHEME(song.sel));
    cv_rect(xc, y1, 1, y - y1 + 1, T_PTHEME(song.sel));
}
/* one page's content into the current canvas (the caller sets cv_oy for the strip; everything is drawn at its SCREEN row) */
#if SMK_SCREEN
/* the SMK-37's guide (owner 2026-11-20: everything DUELL's guide says, in the SMK's buttons, and what the SMK does its own way): SETUP 2 the mode (the keys split at F#4 in
 * STEREO and DUEL), GUIDE 3 the capsule (as the FM-1), 4 .. 8 three topics each. The printed buttons in brackets (guide_rich: a pill; '_' a space) */
/* (owner 2026-11-20: rows, not sentences; what is printed on the unit in a pill, a knob as the screen's knob dot, the parts and GLOBAL in their colours) a body line's
 * tokens, space apart: [NAME] a pill (printed on the unit; '_' a space), #n knob n's dot, {1} {2} {G} the words PART 1, PART 2, GLOBAL in their colours, else a word */
static int32_t guide_tok_w(const char *w, uint32_t n)
{
    char b[24];
    uint32_t i;
    for (i = 0; i < n && i + 1u < sizeof b; i++)
        b[i] = w[i] == '_' ? ' ' : w[i];
    b[i] = 0;
    if (b[0] == '[' && i > 2u) {
        b[i - 1u] = 0;
        return smk_pill_w(b + 1);
    }
    if (b[0] == '#' && i == 2u)
        return AF_S_CAP_H;
    if (b[0] == '{' && i == 3u)
        return text_w(&AF_M, b[1] == 'G' ? "GLOBAL" : b[1] == '1' ? "PART 1" : "PART 2");
    return text_w(&AF_M, b);
}
static void guide_tok(int32_t x, int32_t base, const char *w, uint32_t n)
{
    char b[24];
    uint32_t i;
    for (i = 0; i < n && i + 1u < sizeof b; i++)
        b[i] = w[i] == '_' ? ' ' : w[i];
    b[i] = 0;
    if (b[0] == '[' && i > 2u) {
        b[i - 1u] = 0;
        (void)smk_pill(x, base - AF_M_CAP_H + 1 - (KC_H - AF_M_CAP_H) / 2, b + 1);
    } else if (b[0] == '#' && i == 2u)
        smk_dot(x, base - AF_M_CAP_H + 1, (uint32_t)(b[1] - '1'), T_TEXT);
    else if (b[0] == '{' && i == 3u)
        cv_text_on(x, UT_TY(M, base), &AF_M, b[1] == 'G' ? "GLOBAL" : b[1] == '1' ? "PART 1" : "PART 2",
                   b[1] == 'G' ? smk_gcol() : vt(T_PTHEME(b[1] == '2'), T_BG), T_BG);
    else
        cv_text_on(x, UT_TY(M, base), &AF_M, b, T_TEXT, T_BG);
}
static int32_t guide_rows(int32_t y, const char *s)     /* the body: its lines ('\n'), each from the left edge; -> the last line's baseline */
{
    char *said = gfx_said;
    if (said)
        gfx_said_add(s);
    gfx_said = 0;
    while (*s) {
        int32_t x = GD_X;
        while (*s && *s != '\n') {
            uint32_t n = 0;
            while (*s == ' ')
                s++;
            while (s[n] && s[n] != ' ' && s[n] != '\n')
                n++;
            if (n) {
                guide_tok(x, y, s, n);
                x += guide_tok_w(s, n) + 4;
            }
            s += n;
        }
        if (*s == '\n') {
            s++;
            y += UT_T6_G_LINE;
        }
    }
    gfx_said = said;
    return y;
}
static void guide_topics(const char *const *t)          /* up to three headings, each with its rows */
{
    int32_t y = UT_T6_G_HEAD0;
    uint32_t i;
    for (i = 0; i < 3u && t[2u * i]; i++) {
        if (i) {                                       /* (owner 2026-11-20: a line and some room between two topics) */
            cv_rect(GD_X, y - UT_T6_G_TH + 8, GD_W, 1, ux_mix(T_BG, T_TEXT, 22));
            y += 8;
        }
        cv_text_on(GD_X, UT_TY(L, y), &AF_L, t[2u * i], T_PTHEME(song.sel), T_BG);
        y = guide_rows(y + UT_T6_G_HT, t[2u * i + 1u]) + UT_T6_G_TH;
    }
}
static void guide_capsule_page(void);
static void guide_content(uint32_t pg)
{
    static const t6_opt_t O2[3] = {{45, 55, 64, 79}, {102, 37, 120, 134}, {141, 37, 159, 173}};
    static const char *const T[6][6] = {             /* (owner 2026-11-20: what first, then how; rows, short; one name once; LFO, ENVELOPE singular) */
        {"TWO PARTS", "KNOBS #1 - #4 = {1}\nKNOBS #5 - #8 = {2}",
         "THREE COLOURS", "{1} {2} = the two parts\n{G} = the whole unit", 0, 0},
        {"SWITCH PARTS", "{1} only = [GLOBE] + [CHN_1] C3\n{2} only = [GLOBE] + [CHN_2] C#3\nBoth = [GLOBE] + [CHN_1] [CHN_2]",
         "KEY SPLIT", "In STEREO and DUEL:\n{1} = low keys\n{2} = high keys\nMove = [BT] MENU > PLAYING > SPLIT", 0, 0},
        {"CONTROLS", "{1} LEVEL = [FADER_1]\n{2} LEVEL = [FADER_2]\n{1} MORPH = [FADER_3]\n{2} MORPH = [FADER_4]\nLFO = [KNOB_BANK]\nENVELOPE = [FADER_BANK]\nMOD MATRIX =\n[KNOB_BANK] + [FADER_BANK]\nMENU = [BT]", 0, 0, 0, 0},
        {"PADS", "An effect = hold a pad\nMore of it = press harder",
         "PERFORM", "Your eight knobs = [NOTE_REPEAT]\nPut a control there: on its page,\nhold [NOTE_REPEAT] + turn its knob", 0, 0},
        {"QUICK EDIT", "Main knobs over the page = hold\n[PARA] [SCALE] [GLOBE] [ARP]\n[SEQ] or [SEQ_REC]",
         "PRINTED KEYS", "ARP RATE = [ARP] + [1/4] .. [1/32T]\nSCALE ROOT =\n[GLOBE] + [SC_C] .. [SC_B]", 0, 0},
        {"RESET A KNOB", "[OCT-] + turn the knob",
         "PARAMETER LOCK", "A step's own value =\nhold its key + [OCT+] + turn a knob",
         "STOP ALL", "[SEQ_PLAY] twice"}};
    if (pg == 2u) {
        cv_text_on(GD_X, UT_TY(M, UT_T6_Q_BASE), &AF_M, "How do you want to start?", T_TEXT, T_BG);
        guide_option(&O2[0], "LAYER", "Both parts combined:", "velocity crossfade, key split", "", "RECOMMENDED", guide_pick[1] == 0u);
        guide_option(&O2[1], "STEREO", "Both parts in one stereo field", "", "", "", guide_pick[1] == 1u);
        guide_option(&O2[2], "DUEL", "Dual mono, for external effects", "", "", "", guide_pick[1] == 2u);
    } else if (pg == 3u)
        guide_capsule_page();
    else if (pg >= 4u && pg <= 9u)
        guide_topics(T[pg - 4u]);
}
#define guide_content guide_content_fm1                 /* (the FM-1's pages below: their page 3 is the SMK's too) */
#endif
static void guide_content(uint32_t pg)
{
    static const t6_opt_t O1[3] = {{50, 25, 69, 0}, {77, 39, 96, 111}, {118, 39, 137, 152}};       /* DUELL 1.3 SETUP 1/5 (owner 2026-11-15): KEYS OR OTHER MIDI (the name alone), CIRCUIT TRACKS, MPC/FORCE (a line: what it sets) */
    static const t6_opt_t O2[3] = {{45, 55, 64, 79}, {102, 37, 120, 134}, {141, 37, 159, 173}};   /* SETUP 2/5: LAYER, STEREO, DUEL (FINAL_V1_08_setup; was SETUP 1/5; 2026-11-16: up, the legend's KNOB 2 CHOOSE line under them) */
    int32_t y;
    if (pg == 1u) {                                     /* DUELL 1.3 (owner 2026-11-15): the device first, its MIDI PRESET at once; replaces SETUP 5/5's "Set up MIDI now?" */
        cv_text_on(GD_X, UT_TY(M, UT_T6_Q_BASE), &AF_M, "What do you play DUELL with?", T_TEXT, T_BG);
        guide_option(&O1[0], "KEYS OR OTHER MIDI", "", "", "", "", guide_pick[0] == 0u);
        guide_option(&O1[1], "CIRCUIT TRACKS", "Its knobs 1 to 8 turn the macros", "", "", "", guide_pick[0] == 1u);
        guide_option(&O1[2], "MPC/FORCE", "Its Q-Links turn the macros", "", "", "", guide_pick[0] == 2u);
    } else if (pg == 2u) {                              /* the mode: all three always, RECOMMENDED on the one that fits SETUP 1/5's device */
        uint32_t r = guide_rec_mode();
        cv_text_on(GD_X, UT_TY(M, UT_T6_Q_BASE), &AF_M, "How do you want to start?", T_TEXT, T_BG);
        guide_option(&O2[0], "LAYER", "Both parts combined:", "velocity crossfade, key split", "", r == 0u ? "RECOMMENDED" : "", guide_pick[1] == 0u);
        guide_option(&O2[1], "STEREO", "Both parts in one stereo field", "", "", r == 1u ? "RECOMMENDED" : "", guide_pick[1] == 1u);
        guide_option(&O2[2], "DUEL", "Dual mono, for external effects", "", "", r == 2u ? "RECOMMENDED" : "", guide_pick[1] == 2u);
    } else if (pg == 3u) {                              /* FIRST_RUN_SETUP_V2_A.png: PART MARKER, the capsule at the right, three short notes (part number, morph end, voices), each joined to its cell by a thin line */
        const int32_t cx = 240 - 12 - CAP_W, tw = 172, my = AF_M_CAP_Y + AF_M_CAP_H / 2;
        static const char *const NOTE[3] = {"Part 1 or 2", "The morph end that you edit", "POLY: remaining voices with the current settings, or MONO, LEGATO, UNISON"};   /* (owner 2026-11-06: short notes, no full sentences) */
        static const int32_t NY[3] = {72, 108, 142};
        uint32_t i;
        /* (owner 2026-11-06: no title on this page, the header GUIDE is enough) */
        char *said = gfx_said;                          /* (DUELL 1.4: the capsule's marks are not read; the notes say what they are) */
        gfx_said = 0;
        cv_oy += 50;                                    /* (head_capsule draws at the header's rows) */
        head_capsule(cx, 0, 1u, 0u, 8, 0u);
        cv_oy -= 50;
        gfx_said = said;
        for (i = 0; i < 3u; i++) {                      /* each leader starts 3 px after the end of its own text's last line, runs right, then up to its item in the capsule */
            int32_t xc = cx + (int32_t)i * CAP_NUM_W + (i == 0u ? CAP_NUM_W : i == 1u ? CAP_LET_W : CAP_VOI_W) / 2;
            y = guide_wrap(GD_X, NY[i], i == 2u ? tw + 24 : tw, &AF_M, NOTE[i], T_TEXT, UT_T6_G_LINE + 1);
            guide_leader2(guide_last_x + 3, y - (UT_T6_G_LINE + 1) + my, xc, GD_CAP_END);
        }
    } else if (pg == 4u) {                              /* (owner 2026-11-15: the headings in the selected part's colour, T_PTHEME, as SETUP's boxes) outcome as a heading (L), the how-sentence under it with its keycaps in the sentence */
        y = UT_T6_G_HEAD0;
        cv_text_on(GD_X, UT_TY(L, y), &AF_L, "PERFORM MODE", T_PTHEME(song.sel), T_BG);
        y = guide_rich(GD_X, y + UT_T6_G_HT, GD_W, "Hold [FX] and the white keys turn into effects.") + UT_T6_G_TH;
        cv_text_on(GD_X, UT_TY(L, y), &AF_L, "QUICK EDIT", T_PTHEME(song.sel), T_BG);
        y = guide_rich(GD_X, y + UT_T6_G_HT, GD_W, "Keep [SEL] [ENV] [LFO] [EDIT] [GLO] [ARP] [SEQ] or [REC] pressed to show its main knobs over the page.") + UT_T6_G_TH;
        cv_text_on(GD_X, UT_TY(L, y), &AF_L, "STOP ALL", T_PTHEME(song.sel), T_BG);
        guide_rich(GD_X, y + UT_T6_G_HT, GD_W, "Tap [PLAY] twice.");
    } else {                                            /* 5: the last GUIDE page */
        y = UT_T6_G_HEAD0;
        cv_text_on(GD_X, UT_TY(L, y), &AF_L, "RESET A KNOB", T_PTHEME(song.sel), T_BG);
        y = guide_rich(GD_X, y + UT_T6_G_HT, GD_W, "Hold [OCT-] and turn the knob.") + UT_T6_G_TH;
        cv_text_on(GD_X, UT_TY(L, y), &AF_L, "SAVE OVER A PATCH", T_PTHEME(song.sel), T_BG);
        y = guide_rich(GD_X, y + UT_T6_G_HT, GD_W, "Keep [SAVE] pressed.") + UT_T6_G_TH;
        cv_text_on(GD_X, UT_TY(L, y), &AF_L, "PARAMETER LOCK", T_PTHEME(song.sel), T_BG);
        guide_rich(GD_X, y + UT_T6_G_HT, GD_W, "One step gets its own value for the knob you turn. With a note key down, press [OCT+] and turn a knob.");
    }
}
#if SMK_SCREEN
static void guide_capsule_page(void) { guide_content_fm1(3u); }   /* (the SMK-37's GUIDE 3: the FM-1's capsule page) */
#undef guide_content
#endif
/* the legend row (item 118, FINAL_V1_08_setup): each key's cap (the firmware's own) and its word (S, grey) on the capitals' last row UT_T6_LEG_BASE; two items: at x UT_T6_LEG_X1 and UT_T6_LEG_X2 as the picture,
 * three: the first at X1, the last ending at UT_T6_LEG_R, the middle one between them. Three items whose words do not leave UT_T6_LEG_MIN px between them (the MENU copy's OCT+ NEXT / OCT- BACK / HOME CLOSE and
 * OCT+ FINISH: 219 / 229 px of 222) lose the LAST item's word, as cv_key_row always did; no other word is touched (HANDOFF_V2 item 118 lists it) */
static void guide_legend(const khint_t *h, uint32_t n)   /* owner 2026-11-15: three FIXED places, OCT- BACK at the left (the way back), HOME in the middle, OCT+ at the right (forward);
                                                         * h[0..2] left, middle, right; an entry with no word (act 0) is a key that does nothing on this page: its place stays empty */
{
    uint32_t i;
    int32_t x[3], w[3];
    int word1 = 1;
    uint16_t grey = ux_mix(T_BG, T_TEXT, UT_GREY_PCT);
    (void)n;
    for (;;) {
        for (i = 0; i < 3u; i++)
            w[i] = h[i].act ? guide_kw(h[i].key) + (h[i].act[0] && (i != 1u || word1) ? UT_T6_LEG_GAP + text_w(&AF_S, h[i].act) : 0) : 0;
        x[0] = UT_T6_LEG_X1;
        x[2] = UT_T6_LEG_R - w[2];
        x[1] = 120 - w[1] / 2;
        if (!word1 || !h[1].act || ((!h[0].act || x[1] - x[0] - w[0] >= UT_T6_LEG_MIN) && (!h[2].act || x[2] - x[1] - w[1] >= UT_T6_LEG_MIN)))
            break;
        word1 = 0;                                      /* (too tight: the middle item loses its word, its keycap stays) */
    }
    for (i = 0; i < 3u; i++) {
        int32_t e;
        if (!h[i].act)
            continue;
        e = guide_kcap(x[i], UT_T6_LEG_Y, h[i].key);
        if (h[i].act[0] && (i != 1u || word1))
            cv_text_on(e + UT_T6_LEG_GAP, UT_TY(S, UT_T6_LEG_BASE), &AF_S, h[i].act, grey, T_BG);
    }
    if (guide_ask((ui.guide - 1u) % GUIDE_N + 1u) && !ui.guide_menu) {   /* owner 2026-11-16: KNOB 1 CHOOSE (every knob chooses, KNOB 1 is shown) with the other keys, at the first place's x: in the legend row when that place is
                                                                          * empty (no BACK: SETUP 1/5), else a second legend line right above it */
        int32_t up = h[0].act ? UT_T6_LEG_LINE : 0;
        int32_t e = cv_keycap(UT_T6_LEG_X1, UT_T6_LEG_Y - up, KC_K1, T_KEY, T_KINK, T_BG);
        cv_text_on(e + UT_T6_LEG_GAP, UT_TY(S, UT_T6_LEG_BASE - up), &AF_S, "CHOOSE", grey, T_BG);
    }
}
#else
static void guide_content(uint32_t pg) { (void)pg; }
static void guide_legend(const khint_t *h, uint32_t n) { (void)h; (void)n; }
#endif
/* the page (ui_draw_page): the content when the page or a pick changes (or ui.force), the header every frame (its own signature: a message) */
static void guide_draw(void)
{
    /* left OCT- BACK, middle HOME, right OCT+ (owner 2026-11-15); {key, 0}: nothing there on that page (no BACK on the first page, no HOME on the last) */
    static const khint_t H1[3] = {{KC_OCTDN, 0}, {KC_HOME, "SKIP"}, {KC_OCTUP, "NEXT"}};            /* the first start's first page */
    static const khint_t HN[3] = {{KC_OCTDN, "BACK"}, {KC_HOME, "SKIP"}, {KC_OCTUP, "NEXT"}};
    static const khint_t HL[3] = {{KC_OCTDN, "BACK"}, {KC_HOME, 0}, {KC_OCTUP, "FINISH"}};         /* the last page: FINISH does what HOME would */
    static const khint_t HM1[3] = {{KC_OCTDN, 0}, {KC_HOME, "CLOSE"}, {KC_OCTUP, "NEXT"}};         /* SETTINGS' copy */
    static const khint_t HM[3] = {{KC_OCTDN, "BACK"}, {KC_HOME, "CLOSE"}, {KC_OCTUP, "NEXT"}};
    static const khint_t HMF[3] = {{KC_OCTDN, "BACK"}, {KC_HOME, 0}, {KC_OCTUP, "FINISH"}};
    uint32_t pg = (ui.guide - 1u) % GUIDE_N + 1u, sig = pg * 64u + ui.guide_menu * 32u + guide_pick[0] * 4u + guide_pick[1];
    if (ui.force || guide_sig != sig + 1u) {
        static const int32_t EDGE[3] = {H_HEAD, H_HEAD + 124, GD_HINT_Y};
        uint32_t band;
        const khint_t *kh = ui.guide_menu ? (pg == GUIDE_N ? HMF : pg == guide_lo() ? HM1 : HM) : pg == 1u ? H1 : pg == GUIDE_N ? HL : HN;
        guide_sig = sig + 1u;
        guide_kh = kh;
        sp_guide[0] = sp_guide_keys[0] = 0;             /* DUELL 1.4: the page's words for the screen reader (ui_speak.c), taken from the first pass of each strip */
        for (band = 0; band < 2u; band++) {             /* two strips: the canvas holds 124 rows (the legend row is in the last one) */
            int32_t y0 = EDGE[band];
            int first = 1;
            CV_BANDS(240, (uint32_t)(EDGE[band + 1] - y0), T_BG) {                 /* (in bands: gfx.c CV_BANDS) */
                cv_oy = -y0;
                gfx_said = first && band == 0u && ann_on() ? sp_guide : 0;   /* (the content: once; the legend: once) */
                gfx_said_max = sizeof sp_guide;
                guide_content(pg);
                gfx_said = first && band == 1u && ann_on() ? sp_guide_keys : 0;
                gfx_said_max = sizeof sp_guide_keys;
                if (band == 1u)
                    guide_legend(kh, 3u);
                gfx_said = 0;
                first = 0;
                cv_oy = 0;
                cv_blit(0, (uint32_t)y0 + (uint32_t)cv_by);
            }
        }
    }
    if (ui.guide_menu && !ui.msg_t)                     /* (owner 2026-11-15: opened from SETTINGS, titled SETTINGS > SYSTEM > GUIDE, as SETTINGS' pages) */
        menu_head();
    else
        draw_head();                                    /* SETUP or GUIDE (ui_draw.c head_page_title), or a message (STOP ALL) */
    draw_foot();                                        /* item 118: the shared footer, the counter 1/5 (MENU's copy 1/3) in it */
    if (ui.msg_t && !--ui.msg_t && ui.msg2[0]) {
        str_cpy(ui.msg, ui.msg2, sizeof ui.msg);
        ui.msg2[0] = 0;
        ui.msg_t = 60;
    }
    ui.force = 0;
}
