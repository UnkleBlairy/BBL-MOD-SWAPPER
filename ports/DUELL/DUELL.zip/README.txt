Duell 1.3.7 for the BBL Mod Swapper

Original by oscillr: https://github.com/oscillr/DUELL
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: DUELL-source.zip on the ports page.
