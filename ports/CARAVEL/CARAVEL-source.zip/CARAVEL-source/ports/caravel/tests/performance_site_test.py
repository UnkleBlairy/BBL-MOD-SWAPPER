#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Website-content checks with disposable HTML fixtures, no device or deployment."""
import hashlib
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "web"))
import make_site
import performance_pages as performance
import stasis_pages


class PerformanceSiteTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.site = Path(self.temp.name) / "site"
        self.site.mkdir()
        template = (ROOT / "web/index_pkg.html").read_text()
        look = make_site.look_css(template)
        pages = {
            "index.html": make_site.landing(look, "0.6.0", True, "firmware/caravel-0.6.0-source.tar.gz"),
            "webapp/installer/index.html": '<style>/*LOOK-BEGIN*/\n' + look + '\n/*LOOK-END*/</style><script type="application/json">{"release_verified": true}</script>',
            "webapp/editor/index.html": "<p>TEST ONLY unchanged editor fixture</p>",
            "emulator/index.html": "<p>TEST ONLY unchanged emulator fixture</p>",
        }
        for name in ("tutorials", "sounds", "changelog"):
            pages[name + "/index.html"] = stasis_pages.page("TEST ONLY " + name, "<p>Fixture</p>", look, make_site.SHIP_PATH)
        for name, text in pages.items():
            path = self.site / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text)
        for name in ("LICENSING.md", "NOTICE", "CREDITS.md", "LICENSE", "caravel-0.6.0-source.tar.gz", "caravel-0.6.0.fwsc"):
            path = self.site / "firmware" / name
            path.parent.mkdir(exist_ok=True)
            path.write_bytes(b"TEST ONLY unchanged release inventory fixture: " + name.encode())

    def protected(self):
        paths = list((self.site / "firmware").iterdir())
        paths += [self.site / name for name in ("webapp/installer/index.html", "webapp/editor/index.html", "emulator/index.html")]
        return {p.relative_to(self.site).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}

    def test_landing_pill_of_every_supported_release_is_accepted(self):
        # Unknown releases stop at the performance overlay; 0.13.0 is accepted only after exact published-release verification. (0.10.1 initially failed here.)
        look = make_site.look_css((ROOT / "web/index_pkg.html").read_text())
        for version in ("0.6.0", "0.7.0", "0.7.1", "0.7.2", "0.8.0", "0.9.0", "0.10.0", "0.10.1", "0.11.0", "0.12.0", "0.13.0"):
            with self.subTest(version=version):
                for name in ("caravel-%s-source.tar.gz" % version, "caravel-%s.fwsc" % version):
                    (self.site / "firmware" / name).write_bytes(b"TEST ONLY unchanged release inventory fixture: " + name.encode())
                (self.site / "index.html").write_text(make_site.landing(look, version, True, "firmware/caravel-%s-source.tar.gz" % version))
                performance.build(self.site)
        (self.site / "index.html").write_text(make_site.landing(look, "0.14.0", True, "firmware/caravel-0.6.0-source.tar.gz"))
        with self.assertRaisesRegex(ValueError, "requires a verified"):
            performance.build(self.site)

    def test_downloads_match_and_all_release_assets_are_preserved(self):
        before = self.protected()
        performance.build(self.site)
        self.assertEqual(before, self.protected())
        self.assertEqual((self.site / "performance" / performance.PROJECT).read_bytes(),
                         (performance.ASSETS / performance.PROJECT).read_bytes())
        self.assertEqual((self.site / "performance" / performance.PACKAGE).read_bytes(),
                         (performance.ASSETS / performance.PACKAGE).read_bytes())
        self.assertIn('href="performance/"', (self.site / "index.html").read_text())
        for name in ("tutorials/stasis", "sounds"):
            self.assertIn("Download the performance setup", (self.site / name / "index.html").read_text())
        self.assertIn('href="../performance/"', (self.site / "tutorials/index.html").read_text())
        initial = {p.relative_to(self.site): p.read_bytes() for p in self.site.rglob("*") if p.is_file()}
        performance.build(self.site)
        self.assertEqual(initial, {p.relative_to(self.site): p.read_bytes() for p in self.site.rglob("*") if p.is_file()})

    def test_changed_download_is_rejected_before_site_write(self):
        source = Path(self.temp.name) / "assets"
        shutil.copytree(performance.ASSETS, source)
        (source / performance.PROJECT).write_bytes(b"TEST ONLY corrupt project")
        before = {p.relative_to(self.site): p.read_bytes() for p in self.site.rglob("*") if p.is_file()}
        with self.assertRaisesRegex(ValueError, "checksum mismatch"):
            performance.build(self.site, source)
        self.assertEqual(before, {p.relative_to(self.site): p.read_bytes() for p in self.site.rglob("*") if p.is_file()})

    def test_070_preserves_historical_downloads_links_and_selected_release(self):
        landing = self.site / 'index.html'
        landing.write_text(landing.read_text().replace('v0.6.0', 'v0.7.0').replace(
            'firmware/caravel-0.6.0-source.tar.gz', 'firmware/caravel-0.7.0-source.tar.gz'))
        for path in (self.site / 'firmware').glob('caravel-0.6.0*'):
            path.rename(path.with_name(path.name.replace('0.6.0', '0.7.0')))
        for name in ('tutorials', 'sounds', 'changelog'):
            shutil.rmtree(self.site / name)
        before = self.protected()
        performance.build(self.site)
        self.assertEqual(before, self.protected())
        stasis_pages.check_site(self.site)
        self.assertIn('v0.7.0', landing.read_text())
        self.assertIn('href="performance/"', landing.read_text())
        self.assertIn('href="tutorials/"', landing.read_text())
        self.assertIn('href="tutorials/random-morph-journey/"', landing.read_text())
        morph = (self.site / 'tutorials/random-morph-journey/index.html').read_text()
        self.assertIn('https://github.com/bonszaimusic/caravel/releases/download/v0.6.0/caravel-0.6.0-source.tar.gz', morph)
        self.assertIn('href="../tutorials/random-morph-journey/"', (self.site / 'tutorials/index.html').read_text())
        self.assertIn('href="../tutorials/stasis/"', (self.site / 'tutorials/index.html').read_text())
        for name in ('performance', 'tutorials/stasis', 'sounds', 'changelog'):
            text = (self.site / name / 'index.html').read_text()
            self.assertIn('v0.6.0', text)
            self.assertIn('https://github.com/bonszaimusic/caravel/releases/download/v0.6.0/caravel-0.6.0-source.tar.gz', text)
        self.assertEqual((self.site / 'performance' / performance.PROJECT).read_bytes(),
                         (performance.ASSETS / performance.PROJECT).read_bytes())
        # the header of every generated page names the version of the site, not the 0.6.0 the lessons are about
        for name in ('performance', 'tutorials', 'tutorials/start-here', 'tutorials/stasis', 'tutorials/random-morph-journey', 'sounds', 'changelog'):
            self.assertIn('<span class="pill">v0.7.0</span>', (self.site / name / 'index.html').read_text(), name)
        initial = {p.relative_to(self.site): p.read_bytes() for p in self.site.rglob('*') if p.is_file()}
        performance.build(self.site)
        self.assertEqual(initial, {p.relative_to(self.site): p.read_bytes() for p in self.site.rglob('*') if p.is_file()})

    def test_preview_and_other_version_do_not_get_release_downloads(self):
        path = self.site / "webapp/installer/index.html"
        path.write_text(path.read_text().replace('"release_verified": true', '"release_verified": false'))
        with self.assertRaisesRegex(ValueError, "verified Caravel"):
            performance.build(self.site)
        self.assertFalse((self.site / "performance").exists())
        path.write_text(path.read_text().replace('"release_verified": false', '"release_verified": true'))
        landing = self.site / "index.html"
        landing.write_text(landing.read_text().replace("v0.6.0", "v0.5.0"))
        with self.assertRaisesRegex(ValueError, "verified Caravel"):
            performance.build(self.site)
        self.assertFalse((self.site / "performance").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
