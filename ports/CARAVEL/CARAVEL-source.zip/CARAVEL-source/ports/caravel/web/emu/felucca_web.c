/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
 * The design (the device clock driven by the audio the worklet asks for, the exports below, the saved
 * flash handed back before boot) follows X0X's browser build, web/emu/x0x_web.c of charlesvestal/fm1-x0x
 * (GPL-3.0), a Felucca fork. */
/* Felucca in the browser: the firmware's sources, as the host tests build them (tests/hostsim.c: libc,
 * engines, voices, FX, sequencer; then the UI, main.c, storage and projects, in src/felucca.c's order),
 * compiled to WebAssembly and run in an AudioWorklet against a simulated FM-1:
 *   - the device clock: TIMER4 ticks (24 MHz) and fm1_ms advance with the audio the worklet asks for; the
 *     audio ISR (audio.c fm1_alnk0_irq, the real one) renders each I2S half (HALF_FRAMES) as the DMA would
 *     ask for it, and the main loop (main.c's, below in web_frame) runs every 15 ms, with ui_input on every
 *     millisecond in between as main.c's wait loop calls it;
 *   - the panel: buttons and encoders by their printed labels (panel.c's table maps them to the matrix),
 *     the keys as fm1_in.notes, the LEDs read back from fm1_led / fm1_led_dim through the key matrix;
 *   - the screen: lcd_fill / lcd_blit into a 240 x 240 RGB565 frame (the panel's byte order);
 *   - the flash: a 1 MiB NOR image behind storage.c's hooks (settings, projects, user presets, the user
 *     sample slots read through it as XIP); the page keeps its storage sectors and gives them back at boot.
 * Not here: USB (MIDI, audio, the editor, updates), TRS MIDI, the serial console, the battery (full), the
 * crash / UBOOT paths. Nothing of the firmware changes for this file.
 *   web/emu/build.sh  ->  build/emu/{felucca.wasm, worklet.js, index.html} */
#include <stdint.h>

#define FELUCCA_WEB 1
#ifndef FELUCCA_CDC
#define FELUCCA_CDC 1                    /* as src/felucca.c: MENU > USB SERIAL is there (nothing behind it) */
#endif
#define FELUCCA_FLASH 1
#define FELUCCA_OTA 0
#define FELUCCA_UAC 0
#define FELUCCA_UART 0
#ifndef FELUCCA_VERSION
#define FELUCCA_VERSION "WEB"
#endif

static uint8_t nor[
#if FELUCCA_HOME_PERF && !FELUCCA_PERF_HW
0x140000
#else
0x100000
#endif
];            /* the SPI NOR (erased: 0xFF) */
#define SMP_USER_XIP(k) ((const uint8_t *)nor + SMP_USER_BASE + (k) * SMP_USER_SIZE)   /* eng_sample.c */
#define main hostsim_main
#include "../../tests/hostsim.c"
#undef main

/* ------------------------------------------------------------ the clock --- */
#define FM1_TICKS_PER_US 24u             /* TIMER4: 24 MHz */
static uint32_t web_ticks;
static uint32_t fm1_ticks(void) { return web_ticks; }

/* ------------------------------------------------------ audio (ALNK0) --- */
static uint32_t web_half;                /* the half the next render fills */
#define FM1_AUDIO_HALF 1u
static uint8_t fm1_audio_pending(void) { return FM1_AUDIO_HALF; }
static void fm1_audio_ack_aux(uint8_t p) { (void)p; }
static uint32_t fm1_audio_free_half(void) { return web_half; }
static void fm1_audio_ack_half(void) {}
static void fm1_audio_init(int32_t *buf, uint32_t words, void (*isr)(void), uint32_t prio)
{ (void)buf; (void)words; (void)isr; (void)prio; }
static void fm1_audio_stop(void) {}
void isr_alnk0(void) {}
#include "../../firmware/src/audio.c"

/* ------------------------------------------------------------ the panel --- */
#define FM1_NCOL 11u
static const int8_t FM1_KEYMAP[6][FM1_NCOL] = {      /* as hal/fm1_input.h: key id at (column, row bit) */
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
    { 5, 11,  4, 10,  3,  9,  2,  8, -1, -1, -1},
    {34, 35, 36, 37, 38, 40, 39, 13,  7,  6, 12},
    {23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33},
    { 0,  1, 15, 14, 17, 16, 19, 18, 20, 21, 22},
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
};
static uint8_t fm1_led[FM1_NCOL], fm1_led_dim[FM1_NCOL], fm1_led_breath[FM1_NCOL], fm1_led_mid[FM1_NCOL];
static uint32_t web_dim_lo;
static void fm1_led_dim_level(uint32_t lo) { web_dim_lo = lo; }
/* the power-on LED sweep (hal/fm1_input.h fm1_led_anim_start, the picture hal/fm1_led_anim.h): its frame from the
 * clock (a scan frame 1.1 ms), the page draws each LED's level (web_anim_levels); at its end, or on a key or a button
 * down, the last picture (the glow everywhere, or dark) and the UI's LEDs from the next frame, as the scan does */
#include "../../firmware/hal/fm1_led_anim.h"
static uint32_t web_anim_t0, web_anim_glow, web_anim_run, web_anim_idle;   /* (idle: 1.2's idle animation, MENU >
                                                                              * ANIM IDLE: fm1_idle_level, endless) */
static uint32_t web_anim_frame(void) { return (web_ticks - web_anim_t0) / (1100u * FM1_TICKS_PER_US); }
static void fm1_led_anim_start(uint32_t glow)
{
    web_anim_idle = 0;
    memset(fm1_led, 0, sizeof fm1_led);
    memset(fm1_led_dim, 0, sizeof fm1_led_dim);
    memset(fm1_led_breath, 0, sizeof fm1_led_breath);
    memset(fm1_led_mid, 0, sizeof fm1_led_mid);
    web_anim_t0 = web_ticks;
    web_anim_glow = glow != 0u;
    web_anim_run = 1;
}
static int fm1_led_anim_on(void)
{
    if (web_anim_run && web_anim_idle && (fm1_in.notes || fm1_in.buttons))
        web_anim_run = 0;                       /* (the idle animation: ended, the UI's LEDs from now) */
    if (web_anim_run && !web_anim_idle && (web_anim_frame() >= FM1_ANIM_FRAMES || fm1_in.notes || fm1_in.buttons)) {
        uint32_t c, r;
        web_anim_run = 0;
        for (c = 0; c < FM1_NCOL; c++)
            for (r = 1; r < 5u; r++)
                if (web_anim_glow && FM1_KEYMAP[r][c] >= 0)
                    fm1_led_dim[c] |= (uint8_t)(1u << r);
    }
    return (int)web_anim_run;
}
static void fm1_led_idle_start(uint32_t glow)
{
    fm1_led_anim_start(glow);
    web_anim_idle = 1;
}
static int fm1_led_idle_on(void) { return fm1_led_anim_on() && web_anim_idle; }
static void fm1_led_anim_stop(void) { web_anim_run = 0; }
static uint32_t web_pressed, web_released, web_notes_pressed;
static int32_t web_enc_steps[7];
static uint32_t fm1_input_edges(uint32_t *released)
{
    uint32_t p = web_pressed;
    if (released)
        *released = web_released;
    web_pressed = web_released = 0;
    return p;
}
static uint32_t fm1_input_note_edges(void) { uint32_t n = web_notes_pressed; web_notes_pressed = 0; return n; }
static int32_t fm1_enc_take(uint32_t e) { int32_t s = web_enc_steps[e % 7u]; web_enc_steps[e % 7u] = 0; return s; }
static void fm1_input_init(void) {}
static void fm1_input_tick(void) {}
static void fm1_wdt_feed(void) {}
static void fm1_irq_off(void) {}
static void fm1_irq_on(void) {}

/* ----------------------------------------------------------- the screen --- */
static uint16_t web_fb[240 * 240];       /* RGB565 as the panel gets it (high byte first) */
static uint32_t web_draws;
#ifdef WEB_LCD_TRACE
/* (tests, -DWEB_LCD_TRACE=1: every lcd_fill / lcd_blit as x y w h colour kind, and after it the panel's pixels at four probes on the
 * outer frame: what a real panel shows between two draw calls of one frame) */
static uint16_t web_trace[4096][6], web_probe[4096][6];
static uint32_t web_trace_n;
static void web_tr(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint32_t c, uint32_t k) { if (web_trace_n < 4096u) { uint16_t *t = web_trace[web_trace_n++]; t[0]=(uint16_t)x; t[1]=(uint16_t)y; t[2]=(uint16_t)w; t[3]=(uint16_t)h; t[4]=(uint16_t)c; t[5]=(uint16_t)k; } }
static void web_tr_after(void) { if (web_trace_n && web_trace_n <= 4096u) { uint16_t *p = web_probe[web_trace_n - 1u]; p[0] = web_fb[0]; p[1] = web_fb[120 * 240]; p[2] = web_fb[120 * 240 + 239]; p[3] = web_fb[239 * 240 + 120]; p[4] = web_fb[25 * 240 + 3]; p[5] = web_fb[26 * 240 + 130]; } }   /* (4, 5: two amber pixels of the hazard strip under the header) */
#else
#define web_tr(x,y,w,h,c,k) ((void)0)
#define web_tr_after() ((void)0)
#endif
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    uint16_t sw = (uint16_t)((c >> 8) | (c << 8));
    web_tr(x, y, w, h, c, 0);
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            web_fb[(y + j) * 240u + x + i] = sw;
    web_tr_after();
    web_draws++;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *p)
{
    uint32_t i, j;
    web_tr(x, y, w, h, 0, 1);
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            web_fb[(y + j) * 240u + x + i] = p[j * w + i];
    web_tr_after();
    web_draws++;
}
static void lcd_sync(void) {}
#if CARAVEL_STASIS2 && defined(CARAVEL_STASIS_SCOPE_V6) && CARAVEL_STASIS_SCOPE_V6
/* The WebAssembly framebuffer blits are synchronous. */
static uint8_t lcd_scope_ready(void) { return 1u; }
#endif
static void lcd_power(uint32_t s)              /* MENU > SCREEN OFF (lcd.c): off, the page dark; on: redrawn before */
{
    if (!s) {
        memset(web_fb, 0, sizeof web_fb);
        web_draws++;
    }
}
static void lcd_wake_now(void) {}
static void lcd_init(void) {}

#include "../../firmware/src/gfx.c"
#include "../../firmware/src/panel.c"
#include "../../firmware/src/ui.c"
#include "../../firmware/src/menu_items.c"
#include "../../firmware/src/icons.c"
#include "../../firmware/src/ui_graph.c"
#include "../../firmware/src/ui_draw.c"
#include "../../firmware/src/ui_menu.c"
#include "../../experiments/action-banks/action_control.c"
#include "../../firmware/src/ui_input.c"
#include "../../firmware/src/ui_layer.c"

/* ------------------------------------------------------------ the flash --- */
static uint32_t web_flash_writes;
static uint8_t flash_ok;
static int st_read(uint32_t off, void *dst, uint32_t n)
{
    if (off >= sizeof nor || n > sizeof nor - off)
        return -1;
    memcpy(dst, nor + off, n);
    return 0;
}
#if defined(WEB_FLASH_TEST)
static int web_flash_fail_after=-1;
static int web_flash_fault(void){if(web_flash_fail_after<0)return 0;if(!web_flash_fail_after)return 1;web_flash_fail_after--;return 0;}
#endif
static int st_erase(uint32_t off)
{
#if defined(WEB_FLASH_TEST)
    if(web_flash_fault())return -8;
#endif
    if (off >= sizeof nor || 4096u > sizeof nor - off)
        return -8;
    memset(nor + (off & ~4095u), 0xFF, 4096);
    web_flash_writes++;
    return 0;
}
static int st_prog(uint32_t off, const void *src, uint32_t n)       /* NOR: a write only clears bits */
{
#if defined(WEB_FLASH_TEST)
    if(web_flash_fault())return -8;
#endif
    const uint8_t *s = src;
    uint32_t i;
    if (off >= sizeof nor || n > sizeof nor - off)
        return -8;
    for (i = 0; i < n; i++)
        nor[off + i] &= s[i];
    web_flash_writes++;
    return 0;
}
static uint32_t irq_save(void) { return 0; }
static void irq_restore(uint32_t f) { (void)f; }
static uint32_t fl_jedec_ram(void) { return 0x856014u; }             /* the FM-1's part (project.c) */
static void fl_plain_window_init(void) {}
#define FL_FAR(fn) (fn)
#include "../../firmware/src/storage.c"
#include "../../firmware/src/upreset.c"
#include "../../firmware/src/project.c"
#if FELUCCA_HOME_PERF
#if FELUCCA_PERF_HW
#include "../../experiments/home-perf/home_store_hw.c"
#else
#include "../../experiments/home-perf/home_store.c"
#endif
#endif
#include "../../firmware/src/ui_f2.c"


/* ------------------------------------------------- main.c and its HAL --- */
#if FELUCCA_CPU2
typedef struct { uint32_t magic, count, vec, pc, emu, dbg, rets, core; } fm1_crash_t;
#else
typedef struct { uint32_t magic, count, vec, pc, emu, dbg, rets; } fm1_crash_t;
#endif
#define FM1_CRASH_MAGIC 0x43525348u
static fm1_crash_t fm1_crash;                     /* (none: main.c boot_leds runs the sweep) */
static struct { uint8_t p3_rst, wdt_con; uint32_t rst_src; } fm1_boot;
uint32_t _data_start[1], _data_end[1], _data_load[1], _bss_start[1], _bss_end[1];
uint32_t _pool_start[1], _pool_end[1], _rt_start[1], _rt_end[1], _rt_load[1];
static uint32_t web_master_adc = 700;   /* MASTER, 0..1023 as the ADC reads it */
enum { FM1_ADC_BATT = 3, FM1_ADC_MASTER = 4 };
static int32_t fm1_adc_read(uint32_t ch) { return ch == FM1_ADC_MASTER ? (int32_t)web_master_adc : 620; }
static void fm1_adc_init(void) {}
static void fm1_timer5_ack(void) {}
static void fm1_timer5_start(void (*isr)(void), uint32_t prio) { (void)isr; (void)prio; }
void isr_timer5(void) {}
static void fm1_reboot(void) {}
static void fm1_enter_uboot(void) {}
static void fm1_guard_lock_top(void) {}
static void fm1_irq_enable_all(void) {}
static void fm1_irq_init(void) {}
static void fm1_time_init(void) {}
static void fm1_reset_reason(void) {}
static void fm1_wdt_arm(uint32_t v) { (void)v; }
static void fm1_mailbox_clear(void) {}
static void fm1_guard_enable(uint32_t m) { (void)m; }
enum { FM1_GUARD_STACK = 1, FM1_GUARD_WRITE = 2, FM1_GUARD_BUS = 4, FM1_GUARD_PC = 8 };
#if FELUCCA_CPU2
/* the second core (hal/fm1_cpu1.h): none here, one core whatever MENU > 2ND CORE says (fx.c mix_block's C1_ON() is 0
 * without felucca.c's macros) */
uint32_t _c1_start[1], _c1_end[1], _c1_load[1];
static uint8_t fm1_c1_on, fm1_c1_gave_up;
static void fm1_cpu1_halt(void) {}
static int fm1_cpu1_start(void) { return -1; }
static void fm1_guard_pc_open(void) {}
#endif
#if FELUCCA_CDC
static void cdc_task(void) {}
#endif
/* main.c's calls into the USB driver (registers): nothing here (usb.c's own functions stay as they are) */
#define usb_poll() ((void)0)
#define usb_start() ((void)0)
#define usb_retry(ms) ((void)(ms))
#define usb_detach() ((void)0)
#include "../../firmware/src/master.c"
#include "../../firmware/src/main.c"
#undef usb_poll
#undef usb_start
#undef usb_retry
#undef usb_detach

/* --------------------------------------------------------- the device --- */
static uint32_t web_booted, web_boot_ms, web_last_frame;

/* main.c fm1_main's boot, up to the main loop (no USB, no UART, no panel setup) */
static void web_power_on(void)
{
    memset(harmony_follow, 1, sizeof harmony_follow);   /* as main.c fm1_main: a cold boot has every track following the bus */
    persist_boot();
    settings_init();
    usb_serial_apply();
    lcd_init();
    draw_splash();                        /* main.c: the splash (ui_draw.c) */
    memset(&felucca_dbg, 0, sizeof felucca_dbg);
    felucca_dbg.magic = DBG_MAGIC;
    fm1_input_init();
    fm1_adc_init();
    panel_init();
    felucca_init();
    master_boot();                        /* main.c (#137): the pot's level from the first block */
    kb_boot_hold = 1;                     /* main.c (#137): the keys silent under the splash */
    audio_init();
    boot_leds();                          /* main.c: the power-on LED sweep, from the scan's start */

#if FELUCCA_HOME_PERF
    hp_init();
#endif
    autosave_boot(boot_clean);            /* main.c: the last session's music (1.2, project.c) */
#if CARAVEL_UX_LAYERS
    uxl_boot();                           /* main.c: PLAY at power-on */
#endif
    web_boot_ms = fm1_ms + 430u;         /* main.c: 30 + 400 ms before the first frame */
    web_booted = 1;
}

/* one pass of main.c fm1_main's loop (what the browser has: no USB, editor, UBOOT, console) */
static void web_frame(void)
{
    int32_t b = fm1_adc_read(FM1_ADC_BATT);
    if (b > 0)
        song.batt_raw = song.batt_raw ? song.batt_raw + (b - song.batt_raw) / 32 : b;
    master_poll();
    felucca_dbg.ui_frames++;
    ui_input();
    settings_poll();
    autosave_poll();
    ui_leds();
    ui_draw();
}

/* output ring, stereo float, filled by web_ms, drained by web_render */
#define RING 4096u
static float ring[RING * 2];
static uint32_t ring_w, ring_r, web_samples_due;

/* one millisecond of the device: the clock, the audio halves due by now, the main loop */
static void web_ms(void)
{
    fm1_ms++;
    web_ticks += 1000u * FM1_TICKS_PER_US;
    web_samples_due += FS;
    while (web_samples_due >= 1000u * HALF_FRAMES) {      /* an I2S half: the audio ISR renders it */
        uint32_t k;
        const int32_t *o = &abuf[web_half * HALF_WORDS];
        web_samples_due -= 1000u * HALF_FRAMES;
        fm1_alnk0_irq();
        for (k = 0; k < HALF_FRAMES; k++) {
            uint32_t i = (ring_w++ % RING) * 2u;
            ring[i] = (float)o[2u * k] / 8388608.0f;
            ring[i + 1] = (float)o[2u * k + 1u] / 8388608.0f;
        }
        web_half ^= 1u;
    }
    if (!web_booted || (int32_t)(fm1_ms - web_boot_ms) < 0)
        return;
    if (web_boot_ms) {                                    /* main.c: the splash goes, the loop starts */
        web_boot_ms = 0;
        kb_boot_hold = 0;
        lcd_fill(0, 0, 240, 240, T_BG);
        web_last_frame = fm1_ms - 15u;
    }
    if (fm1_ms - web_last_frame >= 15u) {                /* main.c: a frame, then ui_input until 15 ms are over */
        web_last_frame = fm1_ms;
        web_frame();
    } else {
        ui_input();                                       /* main.c's wait loop */
    }
}

#define EXPORT __attribute__((used, visibility("default")))
#undef __attribute__

static float out_l[1024], out_r[1024];
EXPORT float *web_out_l(void) { return out_l; }
EXPORT float *web_out_r(void) { return out_r; }
/* n frames (<= 1024) into out_l / out_r: the device runs until they exist */
EXPORT void web_render(uint32_t n)
{
    uint32_t k;
    if (n > 1024u)
        n = 1024u;
    while (ring_w - ring_r < n)
        web_ms();
    for (k = 0; k < n; k++) {
        uint32_t i = (ring_r++ % RING) * 2u;
        out_l[k] = ring[i];
        out_r[k] = ring[i + 1];
    }
}

/* the flash: erased, then the page's saved sectors (web_nor), then boot */
EXPORT uint8_t *web_nor(void) { return nor; }
EXPORT uint32_t web_nor_size(void) { return sizeof nor; }
EXPORT void web_nor_erase(void) { memset(nor, 0xFF, sizeof nor); }
EXPORT uint32_t web_flash_writes_count(void) { return web_flash_writes; }
#if CARAVEL_UX_LAYERS
EXPORT void web_test_build(void) { uxl.play = 0; uxl.lvl = 0; uxl.hint_until = 0; ui.force = 1; }   /* (tests: the emulator started in PLAY; the tests that were written for BUILD go back) */
EXPORT uint32_t web_test_seen(void) { return (favorites.factory[15][31] >> 7) & 1u; }   /* (tests: the LEVELS screen has been shown) */
EXPORT uint32_t web_test_lvl(void) { return uxl.lvl; }
#endif
EXPORT void web_boot(void)
{
    if (!web_booted)
        web_power_on();
}

/* input, by the printed labels: buttons bit b = B_FX .. B_OCTUP (panel.c), keys bit k = key k (F3 .. G5),
 * encoders by role (EN_SELECT .. EN_K4), MASTER 0..1023 */
static uint32_t web_btn_labels, web_key_mask;
EXPORT void web_buttons(uint32_t labels)
{
    uint32_t m = 0, b, old = fm1_in.buttons;
    web_btn_labels = labels;
    for (b = 0; b < NB; b++)
        if ((labels >> b) & 1u)
            m |= 1u << panel.btn[b];
    web_pressed |= m & ~old;
    web_released |= old & ~m;
    fm1_in.buttons = m;
}
EXPORT void web_keys(uint32_t mask)
{
    uint32_t old = fm1_in.notes;
    mask &= (1u << 27) - 1u;
    web_key_mask = mask;
    web_notes_pressed |= mask & ~old;
    fm1_in.notes = mask;
}
EXPORT void web_enc(uint32_t role, int32_t n)
{
    if (role < NE)
        web_enc_steps[panel.enc[role] % 7u] += n * panel.dir[role];
}
EXPORT void web_master(uint32_t v) { web_master_adc = v > 1023u ? 1023u : v; }
/* a channel message from Web MIDI, as a USB-MIDI packet arrives (usb.c midi_enqueue): 0 = the ring was full */
EXPORT uint32_t web_midi(uint32_t status, uint32_t d1, uint32_t d2)
{
    if (status < 0x80u || status >= 0xF0u)
        return 1;
    return (uint32_t)midi_enqueue((status >> 4) | status << 8 | (d1 & 127u) << 16 | (d2 & 127u) << 24, 1);
}

/* the LEDs: bit b = the button labelled b lit (bit 14: PLAY's green), keys bit k; the dim glow and the breath alike */
static uint32_t led_on(const uint8_t *l, uint32_t id)
{
    uint32_t c, r;
    for (c = 0; c < FM1_NCOL; c++)
        for (r = 1; r < 5u; r++)
            if (FM1_KEYMAP[r][c] == (int8_t)id)
                return (l[c] >> r) & 1u;
    return 0;
}
static uint32_t led_buttons(const uint8_t *l)
{
    uint32_t b, m = 0;
    for (b = 0; b < NB; b++)
        m |= led_on(l, panel.btn[b]) << b;
    return m;
}
static uint32_t led_keys(const uint8_t *l)
{
    uint32_t k, m = 0;
    for (k = 0; k < 27u; k++)
        m |= led_on(l, 14u + k) << k;
    return m;
}
EXPORT uint32_t web_lit_buttons(void)
{
    return led_buttons(fm1_led) | ((fm1_led[LED_PLAY_GREEN >> 3] >> (LED_PLAY_GREEN & 7u)) & 1u) << 14;
}
EXPORT uint32_t web_lit_keys(void) { return led_keys(fm1_led); }
EXPORT uint32_t web_dim_buttons(void) { return led_buttons(fm1_led_dim); }
EXPORT uint32_t web_dim_keys(void) { return led_keys(fm1_led_dim); }
EXPORT uint32_t web_dim_level(void) { return web_dim_lo; }
EXPORT uint32_t web_breath_buttons(void) { return led_buttons(fm1_led_breath); }   /* #119: dark .. ~60 % of lit */
EXPORT uint32_t web_breath_keys(void) { return led_keys(fm1_led_breath); }
EXPORT uint32_t web_mid_keys(void) { return led_keys(fm1_led_mid); }   /* the DRUM grid's beats: a steady mid level */
/* the power-on sweep (or 1.2's idle animation) running: each LED's level now (hal/fm1_led_anim.h: 0..64 /64 of lit, | 0x80 the glow under
 * it), 0..13 the buttons by label, 14..40 the keys F3..G5; 0 when it is not */
EXPORT uint8_t *web_anim_levels(void)
{
    static uint8_t lv[FM1_ANIM_NBTN + FM1_ANIM_NKEY];
    uint32_t f = web_anim_frame(), i;
    if (!fm1_led_anim_on())
        return 0;
    for (i = 0; i < FM1_ANIM_NBTN + FM1_ANIM_NKEY; i++)
        lv[i] = (uint8_t)(web_anim_idle ? fm1_idle_level : fm1_anim_level)(f, i < FM1_ANIM_NBTN ? (i < NB ? panel.btn[i] : i) : i,
                                                                          web_anim_glow);
    return lv;
}

/* for the test and the bench (web/emu/emu_test.mjs), a heavy song straight into the tracks (as hostsim's
 * renders set them): T1 FM6 PAD, T2 PHYS DRONE STRING (SYMP), T3 GRAIN CLOUD PAD, 4-note chords on all 16
 * steps, held; T4 DRUM, kick snare and hats. PLAY is the page's (or the test's) to press */
EXPORT void web_test_heavy(void)
{
    static const uint8_t ENG[3][2] = {{ENGI_ENSEMBLE,4},{ENGI_PHYS,7},{ENGI_DRONE,5}};
    static const uint8_t CH[4][4] = {{48, 55, 60, 64}, {45, 52, 57, 60}, {41, 48, 53, 57}, {43, 50, 55, 59}};
    uint32_t p, i;
    for (p = 0; p < 3u; p++) {
        track_t *t = &trk[p];
        host_preset(t, ENG[p][0], ENG[p][1]);
        t->p[P_VOICE] = V_POLY;
        t->p[P_SUS] = 127;
        for (i = 0; i < 16u; i++) {
            uint8_t n[4], k;
            for (k = 0; k < 4u; k++)
                n[k] = (uint8_t)(CH[i / 4u][k] + 12u * p);
            put_step(t, i, 4, n, ST_NOTE, 0);
        }
    }
    host_percussive_track(&trk[3]);
    for (i = 0; i < 16u; i++) {
        uint8_t n[4];
        uint32_t k = 0;
        if (i % 4u == 0u)
            n[k++] = 36;
        if (i == 4u || i == 12u)
            n[k++] = 38;
        n[k++] = i % 2u ? 42 : 46;
        put_step(&trk[3], i, k, n, ST_NOTE, 0);
    }
    ui.force = 1;
}

#if CARAVEL_UX_CAPTURE
EXPORT uint32_t web_test_cap_open(uint32_t i)   /* (tests: note-ons in the live ring without an end) */
{
    uint32_t k, j, n = 0;
    if (i >= NTRK) return 0;
    for (k = 0; k < cap_rn[i]; k++) {
        const cap_ev_t *e = cap_ring_at(i, k);
        if (!e->vel) continue;
        for (j = k + 1u; j < cap_rn[i]; j++) { const cap_ev_t *o = cap_ring_at(i, j); if (!o->vel && o->note == e->note) break; }
        if (j == cap_rn[i]) n++;
    }
    return n;
}
#if CARAVEL_UX_EVOLVE
EXPORT uint32_t web_test_ev(uint32_t what)   /* (tests: EVOLVE state) */
{
    switch (what) {
    case 0: return hp_rm.state;
    case 1: return hp_j.on;
    case 2: return hp_el1.on;
    case 3: return action_snap_slot;
    case 4: return hp_rm.count;
    case 5: return hp_rm_snapshot_count(song.sel, 0);
    case 6: return hp_rm_snapshot_count(song.sel, 1);
    case 7: return hp_j.cur;
    case 8: return hp_j.paused;
    case 9: return hp_j.wait;
    case 10: return uxl.grp[UXL_MOVE];
    case 11: return uxl.area;
#if CARAVEL_ELASTIC_P1
    case 13: return hp_er_count(&hp_er);
    case 14: return hp_er.spring[0].active | hp_er.spring[1].active << 1 | hp_er.spring[2].active << 2 | hp_er.spring[3].active << 3;
    case 15: return hp_el_scope;
    case 16: return hp_el_pick;
    case 17: return hp_er.valid;
    case 18: return hp_er.row * 100u + hp.track[song.sel].active;
    case 19: return hp_el1.row;
    case 20: case 21: case 22: case 23: return ENGINES[trk[song.sel].eng_req % NENGINES]->knob[what - 20u];
    case 25: return P_E0;
    case 50: return (uint32_t)(int32_t)perf_k[0];
    case 51: return (uint32_t)(int32_t)trk[song.sel].p[P_DLY];
    case 52: return (uint32_t)(int32_t)trk[song.sel].p[P_REV];
    case 53: return (uint32_t)(int32_t)song.g[G_DMIX];
    case 1000: return ui.page;
    case 49: return song.playing;
    case 48: return ui.home ? 100u : cur_page()->fam;
#if CARAVEL_ELASTIC_P1
    case 47: return hp_er.last;
#endif
    case 46: { uint32_t c, m = 0; hp_ref_t r; for (c = 0; c < 4u; c++) { if (uxl_inter_ref(c, &r)) { m |= 1u << c; if (uxl_morph_has(r)) m |= 16u << c; } } return m; }
    case 40: return cur_page()->graph == GR_EVOLVE ? 1u + uxl_evp_idx() : 0u;
    case 41: return hp_rm.scope;
    case 42: return hp_rm.bars;
#if CARAVEL_ELASTIC_P1
    case 44: return hp_el_times_track[song.sel].pull;
    case 45: return hp_el_times_track[song.sel].couple;
#endif
#if CARAVEL_ELASTIC_P1
    case 31: case 32: case 33: case 34: return hp_el_stimes[song.sel][what - 31u].pull;
    case 35: case 36: case 37: case 38: return hp_el_scfg[song.sel][what - 35u].range;
#endif
#if CARAVEL_ELASTIC_P1
    case 30: return (hp_er_audio[song.sel][0] | hp_er_audio[song.sel][1] | hp_er_audio[song.sel][2] | hp_er_audio[song.sel][3]) >> 31;
#endif
    case 27: return uxl.inter;
    case 28: return uxl.uset;
    case 29: return uxl_set_count(song.sel);
    case 26: { hp_ref_t r = hp_current(0); return r.kind * 100000u + r.id * 100u + r.aux * 10u + (r.track == 255u) + 1000u * hp_elastic_p1_ref_target(r, song.sel); }
    case 24: return trk[song.sel].engine * 100u + trk[song.sel].eng_req;
#endif
    case 12: { uint32_t i, sum = 0; for (i = 0; i < P_COUNT; i++) sum = sum * 31u + (uint32_t)(int32_t)trk[song.sel].p[i]; return sum; }
    default: return 0;
    }
}
#endif

#if CARAVEL_UX_EVOLVE
/* (tests: the widest label (M) and value (S) of every parameter of every engine and of the globals: do they fit a BUILD card?) */
static char meas_buf[1024];
EXPORT const char *web_test_measure(void)
{
    track_t tmp = trk[0];
    uint32_t e, id, n = 0;
    int32_t wl = 0, wv = 0, wt = 0, wlg = 0, wvg = 0, wtg = 0, w, v, step;
    char ll[24] = "", lv[24] = "", lt[32] = "", lgl[24] = "", lgv[24] = "", lgt[32] = "", b[24];
    const char *u;
    const param_desc_t *d;
    for (e = 0; e < NENGINES + 1u; e++) {
        for (id = 0; id < P_COUNT + (e == 0u ? G_COUNT : 0u); id++) {
            int glob = id >= P_COUNT;
            if (e > 0u && glob)
                break;
            if (!glob) { tmp.eng_req = (uint8_t)(e ? e - 1u : tmp.eng_req); d = track_desc(&tmp, id); }
            else d = &GP[id - P_COUNT];
            if (!d || !d->label || !d->label[0] || (d->label[0] == '-' && !d->label[1]))
                continue;
            w = text_w(&AF_M, d->label);
            if (!glob && w > wl) { wl = w; str_cpy(ll, d->label, sizeof ll); }
            if (glob && w > wlg) { wlg = w; str_cpy(lgl, d->label, sizeof lgl); }
            if (d->max < d->min || d->max - d->min > 20000)
                continue;
            step = (d->max - d->min) / 80;
            if (step < 1) step = 1;
            for (v = d->min; v <= d->max; v += step) {
                param_format(d, v, b, &u);
                w = text_w(&AF_S, b);
                if (!glob && w > wv) { wv = w; str_cpy(lv, b, sizeof lv); }
                if (glob && w > wvg) { wvg = w; str_cpy(lgv, b, sizeof lgv); }
                w += (u && u[0] ? 3 + text_w(&AF_S, u) : 0);
                if (!glob && w > wt) { wt = w; str_cpy(lt, b, sizeof lt); str_cpy(lt + str_len(lt), u, sizeof lt - str_len(lt)); }
                if (glob && w > wtg) { wtg = w; str_cpy(lgt, b, sizeof lgt); str_cpy(lgt + str_len(lgt), u, sizeof lgt - str_len(lgt)); }
                n++;
            }
        }
    }
    perf_format(meas_buf, sizeof meas_buf, "track label M max %d (%s); value S max %d (%s); value+unit max %d (%s) | global label %d (%s); value %d (%s); value+unit %d (%s) | %u samples",
                (int)wl, ll, (int)wv, lv, (int)wt, lt, (int)wlg, lgl, (int)wvg, lgv, (int)wtg, lgt, n);
    return meas_buf;
}
#endif

#if CARAVEL_SLIM
/* (tests: every entry of the PRESETS list: bit e of the result is set when engine e has one; and the engines of the four tracks) */
EXPORT uint32_t web_test_preset_engines(void)
{
    uint32_t total, i, m = 0, pk;
    (void)preset_pos(&total);
    for (i = 0; i < total; i++) {
        uint32_t e = preset_at(i, &pk);
        if (e < 32u)
            m |= 1u << e;
        else
            m |= 0x80000000u;                           /* a user preset */
    }
    return m;
}
EXPORT uint32_t web_test_track_engines(void) { return (uint32_t)trk[0].eng_req | (uint32_t)trk[1].eng_req << 8 | (uint32_t)trk[2].eng_req << 16 | (uint32_t)trk[3].eng_req << 24; }
#endif
EXPORT void web_test_engine(uint32_t e, uint32_t preset) { host_preset(&trk[0], e, preset); ui.force = 1; }   /* (tests, shots: track 1's engine) */
EXPORT uint32_t web_test_page(void) { return (uint32_t)ui.page | (uint32_t)ui.home << 8 | (uint32_t)ui.layer << 9; }   /* (tests: the page shown) */
#if CARAVEL_AFTERBURNER
/* Read-only probes: tests edit AFTER through the real panel input path. */
EXPORT int32_t web_test_afterburner(uint32_t field)
{
    switch (field) {
    case 0: return afterburner.on;
    case 1: return afterburner.time;
    case 2: return afterburner.amt;
    case 3: return afterburner.damp;
    case 4: return !ui.home && str_eq(cur_page()->title, "AFTER");
    case 5: return afb.active;
    case 6: return afb.clearing;
    default: return 0;
    }
}
EXPORT double web_test_afterburner_energy(void)
{
    double energy = 0;
    for (uint32_t i = 0; i < AFB_N; i++) {
        double sample = (double)afb_line[i] / AFB_Q;
        energy += sample * sample;
    }
    return energy / AFB_N;
}
#endif
EXPORT int32_t web_test_p(uint32_t i) { return i < P_COUNT ? TSEL->p[i] : 0; }   /* (tests: a parameter of the selected track) */
#if CARAVEL_UX_LAYERS && CARAVEL_UX_EVOLVE
/* Read the actual FX card model; test setup changes only the stored track filter. */
EXPORT void web_test_filter_own(int32_t v) { TSEL->p[P_FILT] = (int16_t)clamp(v, -64, 63); ui.force = 1; }
EXPORT int32_t web_test_filter_view(uint32_t what) {
    uly_t m; uly_model(LAYER_FX, &m);
    if (!what) return tf_eff(TSEL);
    if (what == 1u) return m.dim[0];
    if (what == 2u) return perf_k[0];
    if (what == 3u) return TSEL->p[P_FILT];
    if (what == 24u) return T_DIM;
    if (what == 25u) return T_TEXT;
    return what - 4u < sizeof m.cv[0] ? (uint8_t)m.cv[0][what - 4u] : 0;
}
#endif

EXPORT void web_test_select(uint32_t t) { if (t < NTRK) { song.sel = (uint8_t)t; ui.force = 1; } }   /* (tests: select a track) */
/* (tests, shots: HARM routing UI) the roles as the HARM page's own chooser sets them, the bus switch, the KEY mode and a KEY link */
EXPORT void web_test_harm_role(uint32_t t, uint32_t mode) { if (t < NTRK && mode <= 4u) { harm_choose_role(&trk[t], mode); ui.force = 1; } }
EXPORT void web_test_harm_on(uint32_t on) { harmony_on = on ? 1u : 0u; ui.force = 1; }
EXPORT void web_test_harm_key_mode(uint32_t on) { harmony_key_mode = on ? 1u : 0u; ui.force = 1; }
EXPORT void web_test_harm_link(uint32_t t, uint32_t src) { if (t < NTRK && src <= NTRK) { link_src[t] = (uint8_t)src; ui.force = 1; } }
EXPORT void web_test_harm_csrc(uint32_t t, uint32_t src) { if (t < NTRK && src <= 5u) { trk[t].p[P_CSRC] = (int16_t)src; ui.force = 1; } }
EXPORT void web_test_harm_bus(uint32_t t) { if (t < NTRK) { trk[t].p[P_CSRC] = 0; trk[t].p[P_CHRD] = CH_BUS; harmony_follow[t] = 1u; ui.force = 1; } }
EXPORT uint32_t web_test_harm_key(uint32_t what) { return what == 0u ? harmony_key_root_eff() : what == 1u ? harmony_key_scale_eff() : what == 2u ? harmony_key_mode : harmony_chord_at(harmony_bar); }
EXPORT void web_test_harm_prog(uint32_t i, uint32_t root, uint32_t dur) { if (i < 4u) { hroot_set(i, (uint8_t)root); hdur_set(i, (uint8_t)dur); ui.force = 1; } }
EXPORT uint32_t web_test_harm_linkget(uint32_t t) { return t < NTRK ? link_src[t] : 0u; }
#if CARAVEL_UX_EVOLVE && CARAVEL_ELASTIC_P1
EXPORT void web_test_el_arm(void) { uxl_el_arm_toggle(); }   /* (shots) PLAY's ELASTIC A1: arm / disarm the selected track */
#endif
EXPORT uint32_t web_test_harm_hc(uint32_t f) { uxl_hc_t h; uxl_hc_get(&h); return !h.ok ? 255u : f == 0u ? h.cur : f == 1u ? h.nxt : f == 2u ? h.left : f == 3u ? h.extra : f == 4u ? h.hold : f == 6u ? h.len : f == 7u ? h.elapsed : h.prog; }   /* (tests) the harmony readout */
EXPORT int32_t web_test_fxk(uint32_t i) { return i == 0u ? TSEL->p[P_FILT] : perf_k[i & 3u]; }   /* (tests) the PLAY FX macros' raw values: FILTER, CRUSH, THROW, DEPTH */
EXPORT uint32_t web_test_mom(void) { return uxl.mom; }
EXPORT void web_test_set_latch(uint32_t t, uint32_t v) { if (t < NTRK) trk[t].p[P_LATCH] = (int16_t)v; }
EXPORT uint32_t web_test_latch(uint32_t t) { return t < NTRK ? (uint32_t)trk[t].p[P_LATCH] : 0u; }
EXPORT void web_test_harm_chrd(uint32_t t, uint32_t v) { if (t < NTRK) { trk[t].p[P_CHRD] = (int16_t)v; ui.force = 1; } }   /* (tests) a local chord shape */
EXPORT void web_test_harm_reset(void) { uint32_t i; harmony_on = 0; harmony_key_mode = 0; for (i = 0; i < NTRK; i++) { link_src[i] = 0; harmony_follow[i] = 0; trk[i].p[P_CSRC] = 0; trk[i].p[P_CHRD] = CH_OFF; } ui.force = 1; }
EXPORT uint32_t web_test_cap_events(uint32_t i) { return i < NTRK ? cap_ln[i] : 0u; }   /* (tests: the events of a track's loop) */
EXPORT uint32_t web_test_cap_post(uint32_t op, uint32_t i, uint32_t nb) { return cap_post(op, i, nb); }   /* (tests: a command as the UI posts it, none run until the next block) */
EXPORT uint32_t web_test_cap_pending(void) { return (uint8_t)(cap_cq_w - cap_cq_r); }   /* (tests: commands not yet taken by the audio context) */
EXPORT uint32_t web_test_cap_loop_abs(uint32_t i, uint32_t k) { return i < NTRK && k < cap_ln[i] && cap_len[i] ? (cap_o[i] + ((uint32_t)cap_loop[i][k].t << 4)) % cap_len[i] : 0xFFFFFFFFu; }   /* (tests: where a loop event falls on the bar clock, Q16 within the loop) */
EXPORT uint32_t web_test_cap_len(uint32_t i) { return i < NTRK ? cap_len[i] : 0u; }   /* (tests: the loop's length, Q16 bars) */
EXPORT uint32_t web_test_cap_prof(uint32_t what) { return what == 0u ? cap_p_blocks : what == 1u ? cap_p_fired_max : what == 2u ? cap_p_takes : cap_p_all; }   /* (tests: the block counter: blocks, most events fired in a block, takes, all four loops running) */
EXPORT uint32_t web_test_cap_state(uint32_t i) { return i < NTRK ? cap_st[i] : 0u; }   /* (tests: 0 no loop, 1 running, 2 paused) */
#endif
EXPORT void web_test_stasis(uint32_t on) { song.g[G_RTYPE] = on ? 3 : 2; }   /* (tests: the reverb TYPE STASIS or HALL) */
EXPORT int32_t web_test_dr_level(void) { return song.g[G_DRLVL]; }   /* (tests: STASIS HOLD) */
EXPORT uint32_t web_test_user_preset(uint32_t i) { return (uint32_t)up_used(i); }
EXPORT void web_test_hades(uint32_t preset)
{
    host_preset(&trk[0], ENGI_HADES, preset);
    ui.force = 1;
}
EXPORT void web_test_drone(uint32_t preset)
{
    host_preset(&trk[0], ENGI_DRONE, preset);
    ui.force = 1;
}
/* Local preview helper: prepare any track for the playable-row experiment. */
EXPORT void web_p12_demo_track(uint32_t t)
{
    if (t >= NTRK) return;
    host_preset(&trk[t], ENGI_DRONE, 0);
#if FELUCCA_HOME_PERF
    hp_apply(t, 1);
    hp.track[t].active = 0;
    hp.track[t].count = 1;
#endif
    ui.force = 1;
}
#if CARAVEL_FORMAT2
EXPORT uint32_t web_test_f2(uint32_t what)       /* (tests: FORMAT 2) 0 notice stage, 1 old mask, 2 acknowledged */
{
    return what == 0u ? f2.stage : what == 1u ? f2_old : (ui_prefs3 & (PREF_F2_ACK >> 24)) != 0u;
}
#endif
EXPORT uint32_t web_test_project_save(uint32_t slot) { return (uint32_t)project_save_as(slot & 3u, "TEST"); }
EXPORT uint32_t web_test_project_load(uint32_t slot) { project_load(slot & 3u); return 0u; }
EXPORT uint32_t web_test_project_used(uint32_t i) { return i < 4u && project_used(i); }
EXPORT uint32_t web_test_project_ram_mask(void) { return project_ram_mask(); }
EXPORT void web_test_live_load_mode(uint32_t full) { menu_put(MI_LIVELOAD, !!full); }
EXPORT void web_test_scene_fx(uint32_t value) { trk[0].p[P_REV] = song.g[G_RSIZE] = (int16_t)(value & 127u); }
EXPORT uint32_t web_test_scene_fx_value(void) { return (uint32_t)trk[0].p[P_REV] | (uint32_t)song.g[G_RSIZE] << 8; }
EXPORT uint32_t web_test_step_record_mask(void) { return step_record_mask; }
EXPORT uint32_t web_test_cursor(void) { return ui.cursor; }
EXPORT uint32_t web_test_step_note(uint32_t i, uint32_t k) { return i < NSTEP && k < TSEL->step[i].n ? TSEL->step[i].note[k] : 255u; }
EXPORT uint32_t web_test_step_count(uint32_t i) { return i < NSTEP ? TSEL->step[i].n : 0; }
EXPORT uint32_t web_test_seq_idx(void) { return TSEL->seq_idx; }
EXPORT uint32_t web_test_fx_events(void)
{
    uint32_t n = 0;
    for (uint32_t i = 0; i < motion.count; i++) n += MOTION_IS_FX(&motion.event[i]);
    return n;
}
EXPORT uint32_t web_test_fx_replay(void) { return perf_motion[0] | perf_motion[1] | perf_motion[2] | perf_motion[3]; }
EXPORT uint32_t web_test_fx_live(void) { return perf_held | perf_latched; }
EXPORT uint32_t web_test_fx_edge(uint32_t on)
{
    for (uint32_t i = 0; i < motion.count; i++) {
        const motion_event_t *e = &motion.event[i];
        if (MOTION_IS_FX(e) && (e->place >> 6) == song.sel && !(e->param & MOTION_LOCK) == !!on)
            return (e->place & 63u) << 8 | (uint8_t)e->value;
    }
    return 0xFFFFFFFFu;
}

EXPORT uint16_t *web_screen(void) { return web_fb; }
EXPORT uint32_t web_screen_draws(void) { return web_draws; }
#ifdef WEB_LCD_TRACE
EXPORT uint32_t web_trace_count(void) { return web_trace_n; }
EXPORT void web_trace_reset(void) { web_trace_n = 0; }
EXPORT const uint16_t *web_trace_ptr(void) { return &web_trace[0][0]; }
EXPORT const uint16_t *web_probe_ptr(void) { return &web_probe[0][0]; }
#endif
#if CARAVEL_ELASTIC_P1 && CARAVEL_ELASTIC_PLAYABLE
/* Read-only emulator diagnostics: validate actual firmware ELASTIC ownership
 * and fractional spring travel, not merely "some pixels changed". */
EXPORT uint32_t web_p12_armed_mask(void)
{
    return hp_elastic_p1_armed_mask();
}
/* Debug-only queries and track selection for exact compiled WASM testing.
 * Real HOME/SETUP knob callbacks still perform every configuration edit. */
EXPORT void web_p12_test_select_track(uint32_t t)
{
    if(t<NTRK){song.sel=t;ui.force=1;}
}
/* 1 when this build has the opt-in STASIS Scope V6 (live audio scope), so whole-screen comparisons can skip its disc. */
#if defined(CARAVEL_STASIS_SCOPE_V6) && CARAVEL_STASIS_SCOPE_V6
/* Test-only: one of the 32 source peaks (|PCM16| >> 8, 0..127) the scope draws. */
EXPORT uint32_t web_stasis_scope_peak(uint32_t i) { return i < 32u ? (uint32_t)st_scope_peak[i] : 0u; }
#endif
EXPORT uint32_t web_stasis_scope_v6(void)
{
#if defined(CARAVEL_STASIS_SCOPE_V6) && CARAVEL_STASIS_SCOPE_V6
    return 1u;
#else
    return 0u;
#endif
}
EXPORT uint32_t web_p12_scope_track(uint32_t t)
{ return t<NTRK?hp_el_scope_track[t]:0xFFFFFFFFu; }
EXPORT uint32_t web_p12_pull_track_ms(uint32_t t)
{ return t<NTRK?hp_et_ms(hp_el_times_track[t].pull):0xFFFFFFFFu; }
EXPORT uint32_t web_p12_return_track_ms(uint32_t t)
{ return t<NTRK?hp_et_return_ms(hp_el_times_track[t].back):0xFFFFFFFFu; }
EXPORT uint32_t web_p12_range_track(uint32_t t)
{ return t<NTRK?hp_el_cfg_track[t].range:0xFFFFFFFFu; }
/* P1.3 debug-only readbacks: UI uses the real SETUP page callbacks. */
EXPORT uint32_t web_p13_bounce_track(uint32_t t)
{ return t<NTRK?hp_el_times_track[t].bounce:0xFFFFFFFFu; }
EXPORT uint32_t web_p13_effective_bounce_track(uint32_t t)
{ return t<NTRK?hp_ec_cycles(hp_el_times_track[t].bounce,
          hp_et_return_ms(hp_el_times_track[t].back)):0xFFFFFFFFu; }
EXPORT uint32_t web_p13_reflect_track(uint32_t t)
{ return t<NTRK?hp_el_times_track[t].reflect:0xFFFFFFFFu; }
EXPORT uint32_t web_p13_couple_track(uint32_t t)
{ return t<NTRK?hp_el_times_track[t].couple:0xFFFFFFFFu; }
EXPORT uint32_t web_p13_seed_track(uint32_t t)
{ return t<NTRK?hp_el_times_track[t].seed:0xFFFFFFFFu; }
EXPORT uint32_t web_p13_setup_page(void)
{ return hp_el_setup_page; }
EXPORT void web_p13_test_reset_settings(void) { hp_elastic_p1_init(); }
EXPORT uint32_t web_p13_test_project_save(void) { return (uint32_t)hp_project_save(0u,0); }
EXPORT uint32_t web_p13_test_project_load(void) { return (uint32_t)hp_project_load(0u); }
/* WASM test proves the exact compiled control-time maps, independent of
 * cached screenshots or test-only native model assumptions. */
EXPORT uint32_t web_p12_pull_ms(uint32_t knob){return hp_et_ms(knob);}
EXPORT uint32_t web_p12_return_ms(uint32_t knob){return hp_et_return_ms(knob);}
EXPORT int32_t web_p12_coil_shift(uint32_t track,uint32_t slot)
{
    if(track>=NTRK||slot>=HP_ER_MAX || !hp_el1_track[track].on)
        return 0;
    const hp_elastic_t *e=0;
    if(hp_el_scope_track[track] && (hp_er_track[track].valid&(1u<<slot)))
        e=&hp_er_track[track].spring[slot];
    else if(!hp_el_scope_track[track] && !hp_el_pick_track[track] &&
            hp_el1_track[track].slot==slot)
        e=&hp_el1_track[track].spring;
    if(!e)return 0;
    return hp_evis_shift(e->x,hp_elastic_limit(e,hp_el_cfg_track[track])*256);
}
#endif
#if CARAVEL_ACTION_BANKS
/* Test-only visibility for real WASM keyboard, project and display integration. */
EXPORT uint32_t web_action_state(void) {
 return action_enabled | (action_setup?1u<<1:0u) | ((uint32_t)action_bank<<8) | (action_capture_mask?1u<<16:0u);
}
/* Read/write through the same firmware controls the physical encoders use. */
EXPORT int32_t web_action_setup_value(uint32_t slot) {return action_setup_value(slot);}
EXPORT void web_action_setup_knob(uint32_t slot,int32_t steps)
{if(action_enabled && action_setup && slot<4u)action_setup_turn(slot,steps);}
EXPORT void web_action_setup_toggle(void)
{if(action_enabled){action_setup=!action_setup;ui.force=1;}}
EXPORT uint32_t web_action_key_note(uint32_t k) { return k<27u?kb_note[k]:0; }
EXPORT uint32_t web_action_stasis_capt(void) { return (uint32_t)song.g[G_DRLVL]; }
#if CARAVEL_STASIS2 && CARAVEL_UX_LAYERS
/* Test-only physical effect-map/legend inspection; invokes the same refresh
 * as the firmware UI. These symbols exist only in the private WASM probe. */
EXPORT uint32_t web_stasis2_fx_key_map(uint32_t p)
{
    if(p>=PF_KEYS)return PF_N;
    fx_map_sync();
    return perf_map[p];
}
EXPORT uint32_t web_stasis2_fx_cell_state(uint32_t p)
{ return p<PF_KEYS ? uxl_stasis_cell_state(p) : 0u; }
/* Only the WASM test wrapper may select a temporary screenshot palette. */
EXPORT void web_stasis2_test_palette(uint32_t palette, uint32_t line)
{
    ux.style=line?ST_LINE:ST_FLAT;
    palette_set(palette);
    ui.force=1u;
}
/* Inspect the same five-group PLAY SPACE map the actual knob/UI uses.
 * Read-only; no synthetic UI inputs, no hardcoded parallel model. */
EXPORT uint32_t web_stasis2_space_groups(void) { return uxl_area_ng(UXL_SPACE); }
EXPORT uint32_t web_stasis2_space_target(uint32_t group,uint32_t knob)
{
    if(group>=uxl_area_ng(UXL_SPACE)||knob>=4u) return 0u;
    uxl_tg_t t[4];
    uxl_group(UXL_SPACE,group,t);
    return (uint32_t)t[knob].kind<<16u | t[knob].id;
}
#endif
#if CARAVEL_STASIS_EXPAND
/* Read-only C/WASM hardware regressions. The browser UI itself always
 * uses the actual physical HOME/SELECT/K1..K4 and ACTION note gestures. */
/* Deterministic per-sample test of the ACTUAL DSP anti-alias filter and
 * cubic overlap. These test-only globals are never used by hardware or the
 * live emulator audio path. */
static int32_t stasis_probe_filter[3],stasis_probe_sum;
static uint32_t stasis_probe_count;
EXPORT void web_stasis_probe_reset(void)
{
 memset(stasis_probe_filter,0,sizeof stasis_probe_filter);
 stasis_probe_sum=0;stasis_probe_count=0;
}
EXPORT int32_t web_stasis_probe_capture(int32_t value,uint32_t quality)
{
 quality=quality>2u?2u:quality;
 value=clamp(value,-32768,32767);
 stasis_probe_sum+=stasis_record_prefilter(value,stasis_probe_filter,quality);
 if(++stasis_probe_count==(1u<<quality)){
  int32_t result=stasis_probe_sum>>(quality);
  stasis_probe_sum=0;stasis_probe_count=0;
  return result;
 }
 return 0x10000; /* no decimated sample yet */
}
EXPORT uint32_t web_stasis_grain_envelope(uint32_t triangle,uint32_t grain)
{
 grain=grain>2u?2u:grain;
 uint32_t half=2048u<<grain;
 return stasis_grain_weight(triangle>half?half:triangle,grain);
}
/* Native FX > GRAIN page verification; values are the same C fields as
 * ACTION > STASIS > GRAIN (not mirrored emulator settings). */
EXPORT uint32_t web_stasis_grain_page(void)
{
 for(uint32_t i=0;i<NPAGES;i++)
  if(PAGES[i].graph==GR_STGRAIN)return i;
 return 0xFFFFFFFFu;
}
EXPORT uint32_t web_stasis_grain_visible(void)
{
 uint32_t page=web_stasis_grain_page();
 return page<NPAGES && page_visible(page);
}
EXPORT void web_stasis_grain_open(void)
{
 uint32_t p=web_stasis_grain_page();
 if(p<NPAGES&&page_visible(p)){ui.home=0;ui.page=p;ui.force=1;page_entered();}
}
/* Read-only capacity for V5 source regression and browser QA. */
EXPORT uint32_t web_stasis_ring_capacity(void) { return ST_RING_LEN; }
EXPORT uint32_t web_stasis_granular_get(uint32_t field)
{
 switch(field){
 case 0:return st_expand.grain;
 case 1:return st_expand.scan;
 case 2:return st_expand.quality;
 case 3:return st_expand.reverse;
 case 4:return st.valid;
 case 5:return st.w;
#if CARAVEL_STASIS2
 case 6:return 0;  /* second capture bank retired */
 case 7:return 0;
#else
 case 6:return st_layer.valid;
 case 7:return st_layer.phase;
#endif
 case 8:return st.active_quality;
 case 9:return st.active_grain;
 case 10:return st.gr_ready;
 case 11:return st.auto_hold;
 case 12:return stasis_min_history();
 case 13:return mod_stasis.scan;
 case 14:return action_stasis_grain_page;
#if CARAVEL_STASIS2
 case 15:return st_expand.length;
 case 16:return st.region_status;
 case 17:return st.region_length;
 case 18:return st.new_source;
 case 19:return ST_RING_LEN;
#endif
 default:return 0;
 }
}
EXPORT void web_stasis_test_type(uint32_t type)
{song.g[G_RTYPE]=(int16_t)clamp(type,0,3);ui.force=1;}
EXPORT void web_stasis_test_hold(uint32_t hold)
{song.g[G_DRLVL]=(int16_t)!!hold;ui.force=1;}
EXPORT uint32_t web_stasis_scan_mod(uint32_t source,int32_t amount)
{
 if(source==0u){trk[0].p[P_M1SRC]=0;trk[0].p[P_M1DST]=0;trk[0].p[P_M1AMT]=0;}
 else {
  trk[0].p[P_M1SRC]=(int16_t)clamp(source,1,MS_N-1);
  trk[0].p[P_M1DST]=MD_STSCAN;
  trk[0].p[P_M1AMT]=(int16_t)clamp(amount,-64,63);
 }
 return MD_STSCAN;
}
#endif
EXPORT uint32_t web_action_mute(uint32_t t) { return t<NTRK?(uint32_t)trk[t].p[P_MUTE]:0; }
#if FELUCCA_RANDOM_MORPH
EXPORT uint32_t web_action_random_state(void) { return hp_rm.state; }
EXPORT uint32_t web_action_random_count(void) { return hp_rm.count; }
EXPORT uint32_t web_action_random_cell(uint32_t index,uint32_t field)
{
 if(index>=hp_rm.count)return 0xFFFFFFFFu;
 const hp_rm_cell_t*c=&hp_rm.cell[index];
 switch(field){
 case 0:return c->ref.kind;
 case 1:return c->ref.id;
 case 2:return c->ref.track;
 case 3:return (uint32_t)(int32_t)c->from;
 case 4:return (uint32_t)(int32_t)c->to;
 case 5:return c->released;
 case 6:return c->ref.aux;
 default:return 0;
 }
}
/* Diagnostics expose actual descriptors/table, not hardcoded cutoff limits. */
EXPORT int32_t web_action_find_cutoff(uint32_t track)
{
 if(track>=NTRK)return -1;
 for(uint32_t id=P_E0;id<P_E0+8u;id++)
  if(track_desc(&trk[track],id)->fmt==F_CUTOFF)return (int32_t)id;
 return -1;
}
EXPORT uint32_t web_action_cutoff_hz(uint32_t index)
{ return CUTOFF_HZ[index&127u]; }
EXPORT uint32_t web_action_engine_base(void){return P_E0;}

/* Read-only snapshot diagnostics; all writes still use the real physical
 * A4 tap/hold and A3 recall pathways in action_control.c. */
EXPORT uint32_t web_action_snapshot_slot(void) { return action_snap_slot; }
EXPORT uint32_t web_action_snapshot_count(uint32_t slot)
{ return hp_rm_snapshot_count(song.sel,slot); }
EXPORT int32_t web_action_snapshot_value(uint32_t slot,uint32_t index)
{ return slot<HP_RM_SNAP_SLOTS && index<hp_rm_snap[song.sel][slot].count
  ? hp_rm_snap[song.sel][slot].values[index] : -32768; }
#endif
#endif
EXPORT uint32_t web_now_ms(void) { return fm1_ms; }
EXPORT uint32_t web_playing(void) { return song.playing; }
/* Read-only guided-tour state from the actual emulator firmware UI, not pixels.
 * Bits: 0 PLAY (0 BUILD); 1..2 selected track T1..T4; 8 help; 9..13 active engine.
 * Only added to the browser wrapper. No embedded firmware or DSP change. */
EXPORT uint32_t web_tour_state(void)
{
#if CARAVEL_UX_LAYERS
    uint32_t help = (uxl.lvl || (uxl.hint_until && fm1_ms < uxl.hint_until)) ? 1u : 0u;
    return (uint32_t)(uxl.play ? 1u : 0u) | (((uint32_t)song.sel & 3u) << 1) |
           (help << 8) | (((uint32_t)TSEL->eng_req & 31u) << 9);
#else
    return 0xFFFFFFFFu;
#endif
}

/* Explicit opt-in start palette for a deep-linked browser lesson. In-memory ONLY:
 * user must first confirm overwriting unsaved track sounds in the web UI.
 * The source starter uses factory presets only; the browser requests user consent. Does not rewrite a PROJECT, create a SEQ/HARMONY fixture,
 * persist flash, replace firmware or restore prerequisites invisibly. */
/* Read-only source starter inspection. Changes ONLY missing source presets and
 * exact factory-default T1 values after separately confirmed browser action.
 * Bits: 1 T1 preset, 2 TONE factory 127, 4 FILT OFF, 8 ATK factory 85,
 * 16 T2 source preset, 32 T3 source preset. Custom non-default values survive.
 * No sequencer, HARMONY, FLASH, PROJECT or unsaved content is restored here. */
EXPORT uint32_t web_tour_starter_missing(uint32_t stage)
{
    uint32_t missing = 0;
    if (stage >= 10u) return 0;
    if (trk[0].engine != ENGI_ENSEMBLE || trk[0].preset != 5u) {
        missing |= 1u;
    } else {
        if (trk[0].p[P_E2] == 127) missing |= 2u;
        if (trk[0].p[P_FILT] == 0) missing |= 4u;
        if (trk[0].p[P_ATK] == 85) missing |= 8u;
    }
    if (stage >= 1u && (trk[1].engine != ENGI_DRONE || trk[1].preset != 5u))
        missing |= 16u;
    if (stage >= 7u && (trk[2].engine != ENGI_HADES || trk[2].preset != 0u))
        missing |= 32u;
    return missing;
}
EXPORT void web_tour_starter(uint32_t stage)
{
    uint32_t missing = web_tour_starter_missing(stage);
    if (stage >= 10u || !missing) return;
    if (missing & 1u) host_preset(&trk[0], ENGI_ENSEMBLE, 5u);
    /* A new source preset gets its three warm targets; existing ENSEMBLE 6
     * presets have only EXACT factory-default values changed. Custom settings,
     * including a deliberately chosen cutoff, are never overwritten. */
    if (missing & (1u | 2u)) trk[0].p[P_E2] = 84;
    if (missing & (1u | 4u)) trk[0].p[P_FILT] = -32;
    if (missing & (1u | 8u)) trk[0].p[P_ATK] = 109;
    if (missing & 16u) host_preset(&trk[1], ENGI_DRONE, 5u);
    if (missing & 32u) host_preset(&trk[2], ENGI_HADES, 0u);
    /* Preserve the user's selected track and current pages; stage guidance
     * uses actual read-only firmware track/engine/page checks. */
    ui.force = 1u;
}
/* BUILD page title, read-only. The actual PLAY view is drawn separately from cur_page,
 * so return an empty title there. This is a page label, NOT OCR of the LCD. */
EXPORT const char *web_tour_page_title(void)
{
#if CARAVEL_UX_LAYERS
    return uxl.play ? "" : cur_page()->title;
#else
    return "";
#endif
}
EXPORT uint32_t web_sample_rate(void) { return FS; }


#if FELUCCA_PAIR_MORPH
#include "../../experiments/engine-pair-morph/pair_web.c"
#if FELUCCA_HOME_PERF
#include "../../experiments/home-perf/home_web.c"
#endif

#endif
