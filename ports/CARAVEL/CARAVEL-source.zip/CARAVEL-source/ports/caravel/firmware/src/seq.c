/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Keyboard, scale, arpeggiator, sequencer and transport.
 * Everything here runs in the audio ISR, once per CTL-sample block, and
 * ends in trk_note_on / trk_note_off: engines never see where a note came from.
 * Four tracks, one transport: every track's pattern loops on its own LEN / DIV /
 * SWING / GATE (polymeter). The keys play the selected track; MIDI IN by MENU > MIDI > MIDI IN (G_ROUTE):
 * CH1-4 (0) channels 1..4 play parts 1..4, channels 5..16 are ignored (midi_control.c midi_event); SEL (1)
 * every channel the selected track; 1.2: CH5-8, CH9-12, CH13-16 as CH1-4 on those four channels (midi_base). Their CC1 (mod wheel), CC11 (expression) and channel aftertouch go to
 * the same track's modulation matrix (mod.c; the selected track: the one selected then).
 * A note into an armed track (song.rec) while
 * the transport runs is recorded into its pattern, quantised to its (swung) steps, with its
 * held length as TIE steps (rec_note, rec_hold, rec_release). With the ARP on, the notes the arp
 * plays are recorded, not the keys held (what plays back is what was heard). A key or MIDI note plays a
 * chord when the track's CHRD is on (chord.c): its notes go through the same input as so many keys. */
static const uint16_t SCALE_MASK[] = {
    0xFFF,                                   /* CHR */
    (1 << 0) | (1 << 2) | (1 << 4) | (1 << 5) | (1 << 7) | (1 << 9) | (1 << 11),   /* MAJ */
    (1 << 0) | (1 << 2) | (1 << 3) | (1 << 5) | (1 << 7) | (1 << 8) | (1 << 10),   /* MIN */
    (1 << 0) | (1 << 2) | (1 << 3) | (1 << 5) | (1 << 7) | (1 << 9) | (1 << 10),   /* DOR */
    (1 << 0) | (1 << 2) | (1 << 4) | (1 << 5) | (1 << 7) | (1 << 9) | (1 << 10),   /* MIX */
    (1 << 0) | (1 << 2) | (1 << 4) | (1 << 7) | (1 << 9),                          /* PEN */
    (1 << 0) | (1 << 3) | (1 << 5) | (1 << 7) | (1 << 10),                         /* MPEN */
    (1 << 0) | (1 << 2) | (1 << 3) | (1 << 5) | (1 << 7) | (1 << 8) | (1 << 11),   /* HARM */
    (1 << 0) | (1 << 1) | (1 << 3) | (1 << 5) | (1 << 7) | (1 << 8) | (1 << 10),   /* PHRY */
    (1 << 0) | (1 << 2) | (1 << 4) | (1 << 6) | (1 << 7) | (1 << 9) | (1 << 11),   /* LYD */
    (1 << 0) | (1 << 1) | (1 << 3) | (1 << 5) | (1 << 6) | (1 << 8) | (1 << 10),   /* LOC */
    (1 << 0) | (1 << 2) | (1 << 3) | (1 << 5) | (1 << 7) | (1 << 9) | (1 << 11),   /* MEL (ascending) */
    (1 << 0) | (1 << 3) | (1 << 5) | (1 << 6) | (1 << 7) | (1 << 10),              /* BLUES (minor) */
    (1 << 0) | (1 << 2) | (1 << 4) | (1 << 6) | (1 << 8) | (1 << 10),              /* WHOLE */
    (1 << 0) | (1 << 1) | (1 << 3) | (1 << 4) | (1 << 6) | (1 << 7) | (1 << 9) | (1 << 10), /* DIMHW */
    (1 << 0) | (1 << 2) | (1 << 3) | (1 << 5) | (1 << 6) | (1 << 8) | (1 << 9) | (1 << 11), /* DIMWH */
};

#include "../../experiments/action-banks/action_state.h"
#define KB_SILENT 255u
static uint32_t kb_prev;
static volatile uint8_t kb_boot_hold;    /* #137: set from power-on to the end of the splash (main.c): the keys sound nothing,
                                          * and one held across its end stays silent until it is let go and pressed again */
static uint8_t kb_note[27], kb_trk[27];  /* per key: the note it started and on which track */
static uint8_t ret_harm;                  /* 1 while link_retrigger runs for a HARMONY bar change (not for a LINK key change) */
static uint8_t kb_src[27];                /* per key: the note the key mapped to before HARMONY snapped it (RETRIG HARM re-snaps from it) */
static uint8_t in_key;                   /* the key (+ 1) whose notes go into input_on now (key_on), 0: none (MIDI IN) */
static uint8_t ext_from_midi;            /* do not teach source from MIDI's already mapped/sounding chord */
static uint8_t kb_vel = 100;             /* 1.5.6 (#84): the keys' velocity (MENU > SELECT VEL, ui_input.c sel_play) */
/* #191: where each track's held[i] came from, so the arp maps it again as it plays (arp_list: TRN, ROOT, SCALE, QNT as
 * they are now). held_key: the key + 1 (bits 0..4) and the octave buttons then + 3 (bits 5..7); 0: not a key's own
 * mapping (MIDI IN, the DRUM grid, an engine's own key map), held[i] plays as it is. held_dt: held[i] above the key's
 * note (a CHRD chord's other notes). Out of track_t: its size stays as the audio ISR's trk[] indexing wants it */
static uint8_t held_key[NTRK][16];
static int8_t held_dt[NTRK][16];
static volatile uint8_t kb_asleep;       /* MENU > SCREEN OFF (ui.c): the screen dark or waking, a key pressed now only
                                          * wakes it (silent, no layer, its release nothing) */
static uint8_t last_note = 60;
static volatile uint8_t transport_req;   /* 1 start, 2 stop, 3 INT restart, 4 bar resync, 5 pulse resync, 6 cancel */
static volatile uint8_t bar_reset_req;    /* GLO + OCT+: every track to its step 0 at the next bar (seq_resync) */
static uint32_t scale_mask(const track_t *t);
static uint32_t trk_index(const track_t *t);
static void link_retrigger(uint32_t i);
/* HARMONIC BUS (FUN11): four chords, each held for 1/2/4/8 bars; the on/off and the per-track LINK source and
 * RETRIG live in the project's FUN11 block (project.c). The chord is a diatonic triad in T1's scale; the note sources
 * that use the bus (sequencer strong steps, ARP strong steps, the G5 generator, CHRD BUS) take chord tones there. */
static uint8_t harmony_on;
static volatile uint32_t harmony_bar;
static uint32_t harmony_base_bar;                 /* HARM_BAR() at Start / bar reset */
static uint16_t harmony_phase;                    /* perf_bars_q16's fraction at the last Start / bar reset: HARMONY (and the ARP's bar sync) count bars from there,
                                                   * so a start is a bar line for them; perf_bars_q16 itself (JOURNEY's clock) is never moved (round 7) */
#define HARM_BAR() ((perf_bars_q16 - harmony_phase) >> 16)
static uint8_t harmony_root[4], harmony_dur[4];
/* Independent global key, legacy old projects still follow T1 until converted. */
static uint8_t harmony_key_mode, harmony_key_root, harmony_key_scale;
static uint8_t harmony_local_shape[NTRK];  /* last KEY chord shape per track */
static uint32_t harmony_key_root_eff(void)
{
    return harmony_key_mode ? harmony_key_root : (uint32_t)trk[0].p[P_ROOT];
}
static uint32_t harmony_key_scale_eff(void)
{
    return harmony_key_mode ? harmony_key_scale : (uint32_t)trk[0].p[P_SCALE];
}

static uint8_t harmony_edit_dur;                 /* HARMONY: K1..K4 edit the DUR row instead of the roots */
static uint8_t link_src[NTRK];                   /* 0 OFF, 1..4 = T1..T4 */
static uint8_t link_retrig[NTRK];                /* 0 OFF, 1 HARM (was CHORD), 2 SCALE (was LINK), 3 BOTH */
static uint8_t harmony_follow[NTRK];             /* per track: follow the HARMONY bus (1: yes); felucca_init sets it on, as INIT and every load do (round 7: an initializer would cost 64 B of RAM against the guard) */
#if CARAVEL_ACTION_BANKS
/* Transient performance overlay. Only events_block moves the musical playhead. */
enum {H_NONE,H_HOLD,H_PREV,H_NEXT,H_RESET,H_RESUME,H_J0,H_J1,H_J2,H_J3,H_LONG,H_SHORT};   /* H_J0..3: to chord n at the next bar line, keeping the progress in the chord; H_LONG / H_SHORT: the chord's remaining bars +1 / -1 */
static volatile uint8_t harmony_command, harmony_pending, harmony_hold;
static uint8_t harmony_rep;                      /* bars of the current chord already repeated (LEFT turned up): its elapsed bars for the display */
static uint8_t harmony_extra;                    /* bars the current chord is held beyond its length (0..16; past that: HOLD); audio context only, never saved */
static volatile int8_t harmony_shift_want;
static int8_t harmony_shift;
static volatile uint8_t harmony_shift_pending, harmony_shift_dirty;
static uint8_t harmony_cc_hi[4];
static void harmony_perf_clear(void)
{
 harmony_command=harmony_pending=harmony_hold=harmony_shift_pending=harmony_shift_dirty=0;harmony_extra=0;harmony_rep=0;
 harmony_shift=harmony_shift_want=0;
 memset(harmony_cc_hi,0,sizeof harmony_cc_hi);
}
#else
static void harmony_perf_clear(void) {}
#endif
static uint8_t hroot_get(uint32_t i) { return harmony_root[i & 3u] % 12u; }
static void hroot_set(uint32_t i, uint8_t r) { harmony_root[i & 3u] = (uint8_t)(r % 12u); }
static uint8_t hdur_get(uint32_t i) { return harmony_dur[i & 3u] & 3u; }
static void hdur_set(uint32_t i, uint8_t d) { harmony_dur[i & 3u] = (uint8_t)(d & 3u); }
static uint32_t harmony_chord_at(uint32_t bar)
{
    uint32_t total = 0, i;
    for (i = 0; i < 4u; i++)
        total += 1u << hdur_get(i);
    bar %= total ? total : 4u;
    for (i = 0; i < 4u; i++) {
        uint32_t d = 1u << hdur_get(i);
        if (bar < d)
            return i;
        bar -= d;
    }
    return 3u;
}
/* All global progression consumers resolve to the global key; old unmarked
 * projects retain their original dynamic T1 mapping. */
static uint32_t harmony_scale_abs(void)
{
    uint32_t sm = SCALE_MASK[clamp((int32_t)harmony_key_scale_eff(), 0,
        (int32_t)(sizeof SCALE_MASK / sizeof SCALE_MASK[0]) - 1)];
    uint32_t abs = 0, i, root = harmony_key_root_eff();
    if (sm == 0xFFFu)
        sm = SCALE_MASK[1]; /* CHR: retain former MAJOR fallback */
    for (i = 0; i < 12u; i++)
        if ((sm >> i) & 1u)
            abs |= 1u << ((root + i) % 12u);
    return abs;
}
/* The one effective root of a bus chord, for tone generation, the editor and the display: a root inside T1's scale is
 * itself; a stored root outside it (a project from before roots were limited to the scale, or a scale changed after the
 * roots were set) is the scale note below it, wrapping to the highest one. The stored value is never rewritten. */
static uint32_t harmony_root_eff(uint32_t root)
{
    uint32_t abs = harmony_scale_abs(), d;
    root %= 12u;
    for (d = 0; abs && d < 12u; d++)
        if ((abs >> ((root + 12u - d) % 12u)) & 1u)
            return (root + 12u - d) % 12u;
    return root;
}
/* The next root from `root` along T1's scale, `steps` scale degrees (+ up, - down, wrapping at the octave); a chromatic
 * scale (or one with fewer than three notes) steps by semitones. The start is the effective root: what the card shows. */
static uint32_t harmony_root_step(uint32_t root, int32_t steps)
{
    uint32_t abs = harmony_scale_abs(), notes[12], n = 0, i, at = 0;
    root = harmony_root_eff(root);
    if (__builtin_popcount(abs) < 3)
        abs = 0xFFFu;
    for (i = 0; i < 12u; i++)
        if ((abs >> i) & 1u) {
            if (i == root)
                at = n;
            notes[n++] = i;
        }
    {
        int32_t pos = ((int32_t)at + steps) % (int32_t)n;
        if (pos < 0)
            pos += (int32_t)n;
        return notes[pos];
    }
}
/* Root edits/store remain the prepared progression; SHIFT moves its scale degree. */
static uint8_t hroot_live(uint32_t idx)
{
 uint8_t root=hroot_get(idx);
#if CARAVEL_ACTION_BANKS
 if(harmony_shift){
  uint32_t abs=harmony_scale_abs(),n=0,at=0;uint8_t notes[12];
  for(uint32_t i=0;i<12u;i++)if(abs&(1u<<i))notes[n++]=(uint8_t)i;
  if(n){at=n-1u;for(uint32_t i=0;i<n;i++)if(notes[i]<=root)at=i;
   int32_t pos=((int32_t)at+harmony_shift)%(int32_t)n;if(pos<0)pos+=(int32_t)n;root=notes[pos];}
 }
#endif
 return (uint8_t)harmony_root_eff(root);
}
static uint16_t harmony_mask_pitch(uint32_t root)
{
    uint32_t abs = harmony_scale_abs(), notes[12], n = 0, i, at = 0;
    uint16_t out;
    for (i = 0; i < 12u; i++)
        if ((abs >> i) & 1u)
            notes[n++] = i;
    if (n < 3u)
        return 0;
    root = harmony_root_eff(root);
    for (i = 0; i < n; i++)
        if (notes[i] == root) {
            at = i;
            break;
        }
    out = (uint16_t)(1u << notes[at]);              /* a third and a fifth, not "every other scale note":
                                                     * a pentatonic scale would otherwise give no third */
    {
        static const int8_t third[] = {3, 4, 2, 5};
        static const int8_t fifth[] = {7, 6, 8};
        uint32_t want = notes[at];
        for (i = 0; i < sizeof third; i++)
            if ((abs >> ((want + (uint32_t)third[i]) % 12)) & 1u) {
                out |= (uint16_t)(1u << ((want + (uint32_t)third[i]) % 12));
                break;
            }
        for (i = 0; i < sizeof fifth; i++)
            if (!((out >> ((want + (uint32_t)fifth[i]) % 12)) & 1u) &&
                ((abs >> ((want + (uint32_t)fifth[i]) % 12)) & 1u)) {
                out |= (uint16_t)(1u << ((want + (uint32_t)fifth[i]) % 12));
                break;
            }
    }
    return out;
}
/* One description of a bus chord for tone generation (chord.c), the editor and the live display: its effective root (a
 * pitch class) and its tones relative to that root (bit i: i semitones above it, the form chord_name() takes; 0: the
 * scale has no triad). The editor names the PREPARED chord of a slot, the sounding one is the LIVE chord. */
static uint32_t harmony_chord_desc(uint32_t root, uint16_t *rel)
{
    uint32_t r = harmony_root_eff(root), i;
    uint16_t abs = harmony_mask_pitch(r), m = 0;
    for (i = 0; i < 12u; i++)
        if ((abs >> ((r + i) % 12u)) & 1u)
            m |= (uint16_t)(1u << i);
    *rel = m;
    return r;
}
static uint32_t harmony_prepared_desc(uint32_t idx, uint16_t *rel) { return harmony_chord_desc(hroot_get(idx), rel); }
static uint32_t harmony_live_desc(uint32_t idx, uint16_t *rel) { return harmony_chord_desc(hroot_live(idx), rel); }
static uint16_t harmony_mask_root(uint32_t idx) { return harmony_mask_pitch(hroot_live(idx)); }
static uint16_t harmony_mask_bar(uint32_t bar) { return harmony_mask_root(harmony_chord_at(bar)); }
static uint16_t harmony_mask(const track_t *t)
{
    uint32_t k = trk_index(t);
    if (!harmony_on || k >= NTRK || !harmony_follow[k])
        return 0;
    return harmony_mask_bar(harmony_bar);
}
static int chord_kit(const track_t *t);                /* chord.c: the track's keys are a kit / slices / hits */
/* CHORD EXT (chord.c): EXT_G the cheap guard (CHORD SOURCE HARM; 2..5, T1..T4, are not live yet: OFF), EXT_ON the answer: EXT
 * governs the track's notes (its pool, or silence), so no HARMONY snap, no CHRD, no FOLLOW. Not for FELUCCA_FM4 (the ids are
 * operator values there) */
#if !FELUCCA_FM4
/* The audio side reads CHORD SOURCE / EXT / OCT ONCE per event (ext_cfg), whatever the UI thread turns meanwhile: the pool build, the
 * decision EXT_ON and the placement of one event all use that one copy (chord.c ext_*). */
typedef struct { int16_t src, ext, oct; } ext_cfg_t;
static inline ext_cfg_t ext_cfg(const track_t *t) { ext_cfg_t c; c.src = t->p[P_CSRC]; c.ext = t->p[P_CEXT]; c.oct = t->p[P_COCT]; return c; }
static int ext_on(const track_t *t, int src);
static inline int ext_is_on(const track_t *t, const ext_cfg_t *c) { return c->src >= 1 && c->src <= 5 && ext_on(t, c->src); }
static inline int ext_now(const track_t *t) { int16_t s = t->p[P_CSRC]; return s >= 1 && s <= 5 && ext_on(t, s); }
#define EXT_ON(t) ext_now(t)
#else
typedef struct { int16_t src, ext, oct; } ext_cfg_t;
static inline ext_cfg_t ext_cfg(const track_t *t) { ext_cfg_t c = {0, 0, 0}; (void)t; return c; }
static inline int ext_is_on(const track_t *t, const ext_cfg_t *c) { (void)t; (void)c; return 0; }
#define EXT_ON(t) 0
#endif
static uint32_t harmony_snap(const track_t *t, uint32_t n)
{
    uint16_t mask = harmony_mask(t);
    uint32_t d;
    if (!mask || chord_kit(t) || EXT_ON(t))         /* a note that picks a drum / slice is not a pitch to move; an EXT track takes its pool instead */
        return n;
    for (d = 0; d <= 6u; d++) {
        if ((mask >> ((n + d) % 12u)) & 1u)
            return (uint32_t)clamp((int32_t)(n + d), 0, 127);
        if (d && ((mask >> ((n - d + 12u) % 12u)) & 1u))
            return (uint32_t)clamp((int32_t)n - (int32_t)d, 0, 127);
    }
    return n;
}
#if CARAVEL_ACTION_BANKS
static uint32_t harmony_chord_start(uint32_t idx)
{
 uint32_t bar=0;for(uint32_t i=0;i<idx;i++)bar+=1u<<hdur_get(i);return bar;
}
/* Called at the audio control boundary, stopped immediately or playing at a bar line. */
static void harmony_perf_apply(uint32_t bar)
{
 uint32_t idx=harmony_chord_at(harmony_bar),cmd=harmony_pending,off=0;
 if(cmd){
  if(cmd==H_PREV)idx=(idx+3u)&3u;
  else if(cmd==H_NEXT||cmd==H_RESUME)idx=(idx+1u)&3u;
  else if(cmd==H_RESET){idx=0;harmony_hold=0;harmony_shift=harmony_shift_want=0;harmony_shift_pending=0;}
  else if(cmd>=H_J0&&cmd<=H_J3){   /* to chord j at this bar line, as far into it as we were into the old one (whole bars) */
   uint32_t total=0,i,d=1u<<hdur_get(idx),pos,e,j=cmd-H_J0,dj=1u<<hdur_get(j),e2;
   for(i=0;i<4u;i++)total+=1u<<hdur_get(i);
   pos=harmony_bar%total;e=pos-harmony_chord_start(idx)+(song.playing?1u:0u);   /* (playing: the bar that begins now) */
   if(e>d-1u)e=d-1u;
   e2=e*dj/d;if(e2>dj-1u)e2=dj-1u;
   idx=j;off=e2;
  }
  if(cmd==H_RESUME)harmony_hold=0;
  harmony_extra=0;harmony_rep=0;
  harmony_bar=harmony_chord_start(idx)+off;harmony_base_bar=(bar-harmony_bar)&0xFFFFu;
  harmony_pending=H_NONE;
 }
 if(harmony_shift_pending){harmony_shift=harmony_shift_want;harmony_shift_pending=0;}
}
#endif
static void midi_resync_cancel(void);
static volatile uint8_t step_record_mask; /* transient per-track STEP REC; never live-write at the playhead */
static volatile uint8_t panic_req;       /* bit per track: release every sounding note (preset / engine change) */
static volatile uint8_t midi_hint;       /* MIDI IN played track n - 1, which is not the selected one (the UI says so) */
static volatile uint8_t midi_seen;       /* 1.5.5 (#208): bit per track, a MIDI IN note-on played it since the UI last
                                          * looked (ui_input.c midi_follow: the track's light, AUTO SELECT;
                                          * ui.c scr_input: MENU > MIDI > SCREEN WAKE +MIDI) */

static uint32_t trk_index(const track_t *t) { return (uint32_t)(t - trk); }

/* MENU > MIDI > MIDI IN (G_ROUTE, up to 1.1.5 GLO > SYSTEM ROUT): the first channel (0..15) of the block of four that
 * plays tracks 1..4, -1 with SEL, -2 with TRACK (each track its own: song.mch). Stored
 * 0 CH1-4, 1 SEL, then (1.2, Discussion #143) 2 CH5-8, 3 CH9-12, 4 CH13-16, (1.5.5, #202) 5 TRACK */
static int32_t midi_base(void)
{
    uint32_t r = (uint32_t)song.g[G_ROUTE];
    return r == ROUTE_SEL ? -1 : r == ROUTE_TRACK ? -2 : r ? (int32_t)(r - 1u) * 4 : 0;
}
/* MIDI channel 0..15 of track i (keys -> MIDI out): its channel in ROUT's block (SEL, CH1-4: 1..4); TRACK its own (OMNI,
 * OFF: as CH1-4) */
static uint32_t trk_midi_ch(uint32_t i)
{
    int32_t b = midi_base();
    if (b == -2)
        return mch_get(i) < 16u ? mch_get(i) : i % NTRK;
    return (b > 0 ? (uint32_t)b : 0u) + i % NTRK;
}

static int drum_track(const track_t *t) { (void)t;return 0; }

/* the 27 keys from F: black or white, and the key's place among the keys of its colour (white 0..15, black
 * 0..10). The DRUM grid: white keys are steps, black keys 1..8 lanes, 9 ACC, 10 / 11 the page */
static int key_black(uint32_t k) { return (int)((0x54Au >> ((k + 5u) % 12u)) & 1u); }
static uint32_t key_place(uint32_t k)
{
    uint32_t i, n = 0;
    for (i = 0; i < k; i++)
        n += (uint32_t)(key_black(i) == key_black(k));
    return n;
}
enum { GK_ACC = NLANE, GK_PGDN, GK_PGUP };       /* black keys 9..11 on the grid */
/* the DRUM grid: key k's lane note (black keys 1..8), KB_SILENT for the rest. Out of line (1.5): called from the audio
 * ISR's key loop only on a key change; inlined there, its % 12 and key_place's loop sat in the ISR's static cost
 * (tests/target_budget.py) for a path that runs once per key press */
static __attribute__((noinline)) uint8_t grid_key_note(uint32_t k)
{
    return key_black(k) && key_place(k) < NLANE ? DRUM_LANE_NOTE[key_place(k)] : KB_SILENT;
}
/* GLO > SONG (song.grid 3): key k's slot, the white keys A3 B3 C4 D4 (white places 2..5: keys 4 6 7 9 from F) A..D; -1 = a
 * key that plays. A table, not key_place (a loop); the audio ISR's key loop reads SONG_KEYS, the same keys */
#define SONG_KEYS (1u << 4 | 1u << 6 | 1u << 7 | 1u << 9)
static int32_t song_key(uint32_t k)
{
    static const int8_t S[10] = {-1, -1, -1, -1, 0, -1, 1, 2, -1, 3};
    return k < 10u ? S[k] : -1;
}

static uint32_t scale_mask(const track_t *t)
{
    return SCALE_MASK[clamp(t->p[P_SCALE], 0, sizeof SCALE_MASK / sizeof SCALE_MASK[0] - 1)];
}

/* note n moved down onto the track's scale (ROOT, SCALE): QNT SNAP's keys and QNT SEQ's sequenced notes */
static int32_t scale_snap(const track_t *t, int32_t n)
{
    uint32_t mask = scale_mask(t), guard = 12;
    while (guard-- && !((mask >> (uint32_t)((n - t->p[P_ROOT] + 120) % 12)) & 1u))
        n--;
    return n;
}

enum { QN_OFF, QN_SNAP, QN_WHITE, QN_SEQ, QN_SEQT };   /* P_QUANT (SEQ+T, 1.5.6 #218: appended; older firmware loads SEQ) */

/* the engine's own key map (DRUM's GM map, slices) for key k, -1 none */
static int32_t kb_engine(const track_t *t, uint32_t k)
{
    const engine_t *e = ENGINES[eng_idx(t->eng_req)];   /* (the engine it switches to) */
    return e->keys ? e->keys(t, k) : -1;
}

/* key k's note with the octave buttons at oct: QNT, ROOT, SCALE, TRN (KB_SILENT: a black key under WHITE). The keys
 * (kb_map) and the arp's latched keys (arp_list, #191: as the keys play now, the octave they were pressed in) */
static uint32_t kb_pitch(const track_t *t, uint32_t k, int32_t oct)
{
    static const int8_t DEGREE[12] = {0, -1, 1, -1, 2, 3, -1, 4, -1, 5, -1, 6};
    int32_t n = 53 + (int32_t)k;
    if (t->p[P_QUANT] == QN_SNAP || t->p[P_QUANT] >= QN_SEQ)   /* SNAP (and SEQ, SEQ+T): every key, rounded down */
        return (uint32_t)clamp(scale_snap(t, n + 12 * oct + t->p[P_TRANS]), 0, 127);
    if (t->p[P_QUANT] == QN_WHITE) {                    /* WHITE: white keys walk the scale, black keys are silent */
        uint32_t mask = scale_mask(t), i;
        int32_t count = 0, degree = DEGREE[n % 12], wo;
        if (degree < 0)
            return KB_SILENT;
        /* C4 is the root. Walk scale degrees on successive white keys, including
         * below C4; scales with 5, 6, 8 or 12 notes still have no duplicated degrees. */
        degree += (n / 12 - 5) * 7;
        for (i = 0; i < 12u; i++)
            count += (mask >> i) & 1u;
        wo = degree / count;
        degree %= count;
        if (degree < 0) {
            degree += count;
            wo--;
        }
        for (i = 0; i < 12u; i++)
            if ((mask >> i) & 1u) {
                if (!degree)
                    break;
                degree--;
            }
        n = 60 + t->p[P_ROOT] + 12 * wo + (int32_t)i;
    }
    return (uint32_t)clamp(n + 12 * oct + t->p[P_TRANS], 0, 127);
}

static uint32_t kb_map(const track_t *t, uint32_t k)
{
    int32_t n = kb_engine(t, k);
    return n >= 0 ? (uint32_t)n : kb_pitch(t, k, song.octave);
}

#include "chord.c"
/* A bus chord's name for the editor and the display: "C", "Am", "F", "G" ... from the shared description (an
 * effective root with root-relative tones); the bare note when the scale has no triad. live: the chord as it sounds now
 * (SHIFT applied), else the one the slot prepares. b: 12 bytes. */
static void harmony_card_name(uint32_t slot, char *b, int live)
{
    uint16_t rel;
    uint32_t r = live ? harmony_live_desc(slot, &rel) : harmony_prepared_desc(slot, &rel);
    if (rel)
        chord_name(b, r, rel);
    else
        str_cpy(b, N_NOTE[r % 12u], 12);
}

/* ----------------------------------------------------------- latch --- */
/* LATCH (P_LATCH, CHORD page; Caravel): the notes the keys and MIDI IN play go on sounding after their release, per track.
 * OFF; NEW: a press with nothing held ends the latched notes and starts a new set (as ARP HOLD does for the arp);
 * STACK: new notes join the latched ones, and a press whose notes all sound latched ends them (the key or chord again).
 * Without ARP the released notes are kept in lat_stay (the note-off is not given); with ARP the held list the arp plays is
 * kept (arp_hold). The recording sees the key down and up as ever (rec_release), MIDI OUT too. Ends: LATCH OFF, ARP turned
 * on, a panic (preset / engine / voice mode change, CC120 / 123), STOP, OCT- + OCT+ together (latch_req). A kit (DRUM, slices)
 * takes no latch. Runtime state, never stored; the audio ISR only */
enum { LT_OFF, LT_NEW, LT_STACK };
static uint32_t lat_stay[NTRK][4];       /* bit n: note n was let go and sounds on */
static uint32_t lat_eat[NTRK][4];        /* bit n: the press of note n ended it (STACK): its release does nothing */
/* Older STACK voicings keep their pitches when the newest BUS chord moves. One bit per
 * pitch is sufficient: only chord_last follows Harmony; earlier voicings stay in place. */
static uint32_t lat_bus_other[NTRK][4];
static uint8_t lat_bus_last[NTRK];
static uint8_t lat_vel[NTRK][128];       /* the input velocity of a latched note (retrigger keeps the dynamics) */
/* EXT/HARMONY: unlike physical keys, a released LATCH pitch no longer has
 * kb_src/mchord.src. Save a *fixed* pitch anchor per sounding latch note.
 * Never remap from the last harmonised output; that drifts by up to six
 * semitones per bar on a repeating progression. 512 B RAM for 4 tracks. */
static uint8_t lat_src[NTRK][128];
static volatile uint8_t link_retrig_req;  /* bit per track: a LINK key change asks the audio side to retrigger that track's held bus chord (round 7: the UI no longer touches voices) */
static volatile uint8_t latch_req;       /* bit per track: the UI asks for the release gesture (OCT- + OCT+) */

/* A track whose chords come from the HARMONY bus (CHRD BUS) or from CHORD EXT has no STACK: every held key is already a chord (about 3 voices), so
 * stacked latches would use up the voices. It latches as NEW (a new set replaces the old one). A local chord shape keeps STACK. (chord.c) */
static int latch_chords(const track_t *t);
static uint32_t latch_mode(const track_t *t)
{
    uint32_t v = (uint32_t)t->p[P_LATCH];
    if (v == LT_STACK && latch_chords(t)) v = LT_NEW;
    return (v == LT_NEW || v == LT_STACK) && !chord_kit(t) ? v : LT_OFF;
}
static int lat_get(const uint32_t *a, uint32_t n) { return (int)((a[n >> 5] >> (n & 31u)) & 1u); }
static void lat_put(uint32_t *a, uint32_t n, uint32_t on)
{
    a[n >> 5] = on ? a[n >> 5] | 1u << (n & 31u) : a[n >> 5] & ~(1u << (n & 31u));
}
static int lat_any(const uint32_t *a) { return (a[0] | a[1] | a[2] | a[3]) != 0u; }

/* the keys' and MIDI IN's holding of the ARP's chord: ARP HOLD, or any LATCH */
static int arp_hold(const track_t *t) { return t->p[P_AHOLD] || latch_mode(t) != LT_OFF; }
/* a press with no key down starts a new chord (HOLD, NEW); STACK adds to it */
static int arp_replace(const track_t *t)
{
    uint32_t m = latch_mode(t);
    return m == LT_NEW || (t->p[P_AHOLD] && m != LT_STACK);
}

#if CARAVEL_UX_CAPTURE
static int cap_note_held(const track_t *t,uint32_t note);
#endif
static int midi_note_held(const track_t *t, uint32_t note);
static int midi_local_held(const track_t *t, uint32_t note);
/* Before a fresh input replaces chord_last, its released pitches become older owners. */
static void latch_bus_capture(track_t *t)
{
    uint32_t k = trk_index(t), j;
    if (t->p[P_CHRD] == CH_BUS && !t->p[P_AMODE] && latch_mode(t) != LT_OFF && !EXT_ON(t))   /* (an EXT track has no CHRD BUS chord) */
        for (j = 0; j < 4u; j++)
            lat_bus_other[k][j] |= lat_stay[k][j];
    lat_bus_last[k] = 0;
}
/* A released BUS input remains an owner even when another held chord shares a pitch
 * (input_off is deliberately skipped for those shared pitches). Inspect the whole list
 * before input_off consumes STACK's lat_eat bits. Sustain reaches this on pedal-up. */
static void latch_bus_release(track_t *t, const uint8_t *notes, uint32_t n)
{
    uint32_t k = trk_index(t), j;
    int matches = n == chord_last[k].n;
    if (t->p[P_CHRD] != CH_BUS || t->p[P_AMODE] || latch_mode(t) == LT_OFF || !n || EXT_ON(t))
        return;
    for (j = 0; j < n; j++) {
        if (lat_get(lat_eat[k], notes[j])) return;
        if (j >= chord_last[k].n || notes[j] != chord_last[k].note[j]) matches = 0;
    }
    if (matches)
        lat_bus_last[k] = 1;
    else
        for (j = 0; j < n; j++)
            lat_put(lat_bus_other[k], notes[j], 1);
}

static void chord_live_sync(uint32_t i);
/* the latched notes end (LATCH off, ARP on, a new set, the release gesture; the notes a key holds are not among them) */
static __attribute__((noinline)) void latch_free(track_t *t)
{
    uint32_t k = trk_index(t), n;
    for (n = 0; n < 128u; n++)
        if (lat_get(lat_stay[k], n) || lat_get(lat_bus_other[k], n)) {
            if (!midi_local_held(t, n) && !midi_note_held(t, n)
#if CARAVEL_UX_CAPTURE
                && !cap_note_held(t,n)
#endif
            ) trk_note_off(t, n);
            lat_vel[k][n] = 0;
            lat_src[k][n] = 0;
        }
    memset(lat_bus_other[k], 0, sizeof lat_bus_other[k]);
    lat_bus_last[k] = 0;
    memset(lat_stay[k], 0, sizeof lat_stay[k]);
    chord_live_sync(k);
}
/* the track's latch state is gone (a panic ended every note; trk_all_off) */
static void latch_forget(uint32_t k)
{
    memset(lat_bus_other[k], 0, sizeof lat_bus_other[k]);
    lat_bus_last[k] = 0;
    memset(lat_stay[k], 0, sizeof lat_stay[k]);
    memset(lat_eat[k], 0, sizeof lat_eat[k]);
    memset(lat_vel[k], 0, sizeof lat_vel[k]);
    memset(lat_src[k], 0, sizeof lat_src[k]);
    chord_live_sync(k);
}
/* A rebuilt CHRD BUS chord must stay eligible only while some owner still holds it. */
static void chord_live_sync(uint32_t i)
{
    uint32_t k, m;
    for (k = 0; k < 27u; k++)
        if (kb_chn[k] && kb_live[k] && kb_trk[k] == i) {
            chord_live[i] = 1;
            return;
        }
    for (m = 0; m < MCHORD_N; m++)
        if (mchord[m].id == i + 1u) {
            chord_live[i] = 1;
            return;
        }
    if (lat_any(lat_stay[i]) || lat_any(lat_bus_other[i]) || lat_bus_last[i])
        chord_live[i] = 1;
    else
        chord_live[i] = 0;
}

/* Panic/CC120: no held panel key may re-arm the cached bus chord until a fresh press. The key's outgoing
 * NoteOff list stays intact; only its retrigger eligibility is gone. */
static void chord_panic(uint32_t i)
{
    uint32_t k;
    ext_window_clear(i);
    for (k = 0; k < 27u; k++)
        if (kb_trk[k] == i)
            kb_live[k] = 0;
    chord_live[i] = 0;
}

/* Is there a real owner whose note list is exactly the cached chord? An unrelated remaining key (different
 * octave/voicing) must not resurrect chord_last. */
static int chord_owner_matches(uint32_t i, const uint8_t *old, uint32_t oldn)
{
    uint32_t k, m, j;
    for (k = 0; k < 27u; k++) {
        if (!kb_chn[k] || !kb_live[k] || kb_trk[k] != i || kb_chn[k] != oldn)
            continue;
        for (j = 0; j < oldn && kb_chord[k][j] == old[j]; j++)
            ;
        if (j == oldn)
            return 1;
    }
    for (m = 0; m < MCHORD_N; m++) {
        mchord_t *c = &mchord[m];
        if (c->id != i + 1u || c->n != oldn)
            continue;
        for (j = 0; j < oldn && c->note[j] == old[j]; j++)
            ;
        if (j == oldn)
            return 1;
    }
    return oldn && lat_bus_last[i];
}

/* The cached chord no longer belongs to any owner: select a surviving live owner and rebuild from its own input
 * key. This keeps a held low chord following HARMONY after the newest owner was released. */
static int chord_owner_fallback(uint32_t i, uint32_t *src, uint8_t *old, uint32_t *oldn)
{
    uint32_t k, m, j;
    for (k = 0; k < 27u; k++) {
        if (!kb_chn[k] || !kb_live[k] || kb_trk[k] != i)
            continue;
        *src = kb_note[k];
        *oldn = kb_chn[k];
        for (j = 0; j < *oldn; j++)
            old[j] = kb_chord[k][j];
        return 1;
    }
    for (m = 0; m < MCHORD_N; m++) {
        mchord_t *c = &mchord[m];
        if (c->id != i + 1u)
            continue;
        *src = c->src;
        *oldn = c->n;
        for (j = 0; j < *oldn; j++)
            old[j] = c->note[j];
        return 1;
    }
    return 0;
}

/* HARMONY/LINK RETRIG for a LATCH-held chord that is not CHRD BUS: retrigger every latched note.
 * MONO/LEGATO/UNISON keep the full logical stack (a physically held newer note must stay newer) and every note
 * keeps the velocity it was played with. */
static void retrigger_latched(uint32_t i)
{
    track_t *t = &trk[i];
    uint32_t k = trk_index(t), n, j, nl = 0, nf = 0;
    uint8_t full[8], vel[8], order[8];
    if (trk_vmode(t) != V_POLY) {
        for (j = 0; j < t->nmono && nf < 8u; j++)
            full[nf++] = t->mono_stack[j];
        for (j = 0; j < nf; j++)
            if (lat_get(lat_stay[k], full[j])) {
                order[nl] = full[j];
                vel[nl] = lat_vel[k][order[nl]] ? lat_vel[k][order[nl]] : 100u;
                nl++;
            }
        for (j = 0; j < nl; j++)
            trk_note_off(t, order[j]);
        for (j = 0; j < nl; j++)
            trk_note_on(t, order[j], vel[j]);
        for (j = 0; j < nf; j++)                        /* restore the complete stack order, held notes included */
            t->mono_stack[j] = full[j];
        t->nmono = (uint8_t)nf;
        {
            uint32_t want = mono_pick(t), v = t->v[0].vel ? t->v[0].vel : 100u;
            if (want && want != t->mono_note)
                mono_play(t, want, v, 0, 0);
        }
        return;
    }
    for (n = 0; n < 128u; n++) {
        if (!lat_get(lat_stay[k], n))
            continue;
        uint8_t v = lat_vel[k][n] ? lat_vel[k][n] : 100u;
        trk_note_off(t, n);
        trk_note_on(t, n, v);
    }
}

/* A CHRD BUS retrigger replaces the notes in chord_last. The physical key and MIDI mchord still own the old
 * notes, so move those owners to the new list; a LATCH bit moves too. Without this a key-up would release only
 * the old chord and the new notes would hang. */
static void retrigger_owners(uint32_t i, const uint8_t *old, uint32_t oldn, const uint8_t *new, uint32_t newn)
{
    uint32_t k, j, m;
    int was_latched = lat_bus_last[i];
    uint8_t lv = 100u;
    for (j = 0; j < oldn; j++)
        if (lat_get(lat_stay[i], old[j])) {
            lv = lat_vel[i][old[j]] ? lat_vel[i][old[j]] : 100u;
            break;
        }
    for (k = 0; k < 27u; k++) {
        if (!kb_chn[k] || !kb_live[k] || kb_trk[k] != i || kb_chn[k] != oldn)
            continue;
        for (j = 0; j < oldn && kb_chord[k][j] == old[j]; j++)
            ;
        if (j != oldn)
            continue;
        for (j = 0; j < newn; j++)
            kb_chord[k][j] = new[j];
        kb_chn[k] = (uint8_t)newn;
    }
    for (m = 0; m < MCHORD_N; m++) {
        mchord_t *c = &mchord[m];
        if (c->id != i + 1u || c->n != oldn)
            continue;
        for (j = 0; j < oldn && c->note[j] == old[j]; j++)
            ;
        if (j != oldn)
            continue;
        for (j = 0; j < newn; j++)
            c->note[j] = new[j];
        c->n = (uint8_t)newn;
    }
    if (was_latched) {
        for (j = 0; j < oldn; j++) {
            if (!lat_get(lat_bus_other[i], old[j])) {
                lat_put(lat_stay[i], old[j], 0);
                lat_vel[i][old[j]] = 0;
                lat_src[i][old[j]] = 0;
            }
            lat_put(lat_eat[i], old[j], 0);
        }
        for (j = 0; j < newn; j++) {
            lat_put(lat_stay[i], new[j], 1);
            lat_put(lat_eat[i], new[j], 0);
            lat_vel[i][new[j]] = lv;
            lat_src[i][new[j]] = new[j]; /* BUS uses a separate stored chord owner */
        }
    }
    for (j = 0; j < oldn; j++)                        /* round 7: a moved chord's stale 'this press ended it' marks go with it, or its release would swallow a later NoteOff */
        lat_put(lat_eat[i], old[j], 0);
    for (j = 0; j < newn; j++)
        lat_put(lat_eat[i], new[j], 0);
}

static int midi_note_held(const track_t *t, uint32_t note);
static int midi_local_held(const track_t *t, uint32_t note);
static int chord_note_held(uint32_t i, uint32_t note)
{
    return midi_local_held(&trk[i], note) || midi_note_held(&trk[i], note) || lat_get(lat_stay[i], note) || lat_get(lat_bus_other[i], note);
}

static int midi_any_held(const track_t *t);
static void arp_drop(track_t *t, uint32_t note);
/* a note of track t sounds now because LATCH keeps it (without ARP: a voice or the mono stack plays it) */
static int lat_sounds(const track_t *t, uint32_t n)
{
    uint32_t i;
#if FELUCCA_PAIR_MORPH
    if (ep.cells && pair_member(t)) {
        /* One CELL host pitch represents many physical keys. LATCH belongs to
         * the shared gesture, regardless of which member owns the input. */
        for (i = 0; i < ep.key_count; i++)
            if (ep.keys[i] == n) return 1;
        return 0;
    }
#endif
    if (trk_vmode(t) == V_POLY) {
        for (i = 0; i < NVOICE; i++)
            if (t->v[i].active && t->v[i].gate && t->v[i].note == n)
                return 1;
        return 0;
    }
    for (i = 0; i < t->nmono; i++)
        if (t->mono_stack[i] == n)
            return 1;
    return 0;
}

/* A pitch a STACK press may end: latched itself, or kept by an older latched BUS chord while a held key now plays it (input_on takes it out
 * of lat_stay then), and sounding. */
static int lat_ends(const track_t *t, uint32_t n)
{
    uint32_t k = trk_index(t);
    return (lat_get(lat_stay[k], n) || lat_get(lat_bus_other[k], n)) && lat_sounds(t, n);
}
/* Would latch_press end these notes (STACK, no ARP, every one latched and sounding)? chord_build asks this before it replaces chord_last:
 * a press that only ends latched notes starts no new chord and must not take over the newest chord's identity. */
static int latch_would_toggle(const track_t *t, const uint8_t *nn, uint32_t n)
{
    uint32_t i;
    if (latch_mode(t) != LT_STACK || t->p[P_AMODE] || !n)
        return 0;
    for (i = 0; i < n; i++)
        if (!lat_ends(t, nn[i]))
            return 0;
    return 1;
}

/* a press (key, chord, MIDI note) of the n notes nn on track t, before they start: STACK and every one of them latched
 * (the ARP's list: held) ends them, and the press starts nothing (1; the release of each is eaten); NEW without ARP and no
 * key or note held ends the latched set. 0: the press goes on as always.
 * CHRD BUS: the pressed chord is the newest one (chord_last, latched) or an older one. Its tones end unless another latched chord
 * still holds them: an older chord's by the newest chord, the newest one's by the older ones (lat_bus_other, one bit per pitch: with
 * three or more overlapping chords an older chord's toggle cannot tell a shared tone of two older ones apart and ends it). The newest
 * chord stays the one that follows HARMONY when an older chord is pressed again. */
static __attribute__((noinline)) int latch_press(track_t *t, const uint8_t *nn, uint32_t n)
{
    uint32_t k = trk_index(t), mode = latch_mode(t), i, j;
    if (mode == LT_OFF || !n)
        return 0;
    if (mode == LT_NEW) {
        if (!t->p[P_AMODE] && !midi_any_held(t))
            latch_free(t);
        return 0;
    }
    for (i = 0; i < n; i++) {
        if (t->p[P_AMODE]) {
            for (j = 0; j < t->nheld && t->held[j] != nn[i]; j++)
                ;
            if (j == t->nheld)
                return 0;
        } else if (!lat_ends(t, nn[i])) {
            return 0;
        }
    }
    {
        int bus = !t->p[P_AMODE] && t->p[P_CHRD] == CH_BUS && !EXT_ON(t), newest = 0;
        if (bus && lat_bus_last[k] && n == chord_last[k].n) {
            newest = 1;
            for (i = 0; i < n; i++)
                newest &= nn[i] == chord_last[k].note[i];
        }
        for (i = 0; i < n; i++) {
            if (t->p[P_AMODE]) {
                arp_drop(t, nn[i]);
                lat_put(lat_eat[k], nn[i], 1);
            } else {
                int keep = 0;
                if (bus) {
                    if (newest) {
                        keep = lat_get(lat_bus_other[k], nn[i]);    /* the newest chord ends: an older one may hold the tone */
                    } else {
                        lat_put(lat_bus_other[k], nn[i], 0);        /* an older chord ends: the newest one may hold the tone */
                        for (j = 0; lat_bus_last[k] && j < chord_last[k].n; j++)
                            keep |= chord_last[k].note[j] == nn[i];
                    }
                    keep |= midi_local_held(t, nn[i]) || midi_note_held(t, nn[i]);   /* a key / MIDI note / the sustain still plays it */
                }
                if (!keep) {
                    lat_put(lat_stay[k], nn[i], 0);
                    lat_src[k][nn[i]] = 0;
                    trk_note_off(t, nn[i]);
                    lat_put(lat_eat[k], nn[i], 1);                  /* its release does nothing; a kept tone's release goes on as ever */
                }
            }
        }
        if (!bus || newest)
            lat_bus_last[k] = 0;
        if (bus)
            chord_live_sync(k);
    }
    return 1;
}

/* ------------------------------------------------------------- arp --- */
static void arp_add(track_t *t, uint32_t note)
{
    uint32_t i, k = in_key - 1u;
    if (arp_replace(t) && t->arp_phys == 0u)
        t->nheld = 0;                               /* new chord replaces the latched one */
    t->arp_phys++;                                  /* every key-down: arp_remove counts every key-up */
    for (i = 0; i < t->nheld; i++)
        if (t->held[i] == note)
            return;                                 /* repeated note-on: not a new note */
    if (t->nheld < 16u) {
        /* #191: a key the track's scale keyboard maps (not the DRUM grid, not an engine's own map) is kept as that
         * key, so TRN, ROOT, SCALE and QNT reach the notes the arp holds (arp_list); the octave stays the one it was
         * pressed in. Anything else (MIDI IN) plays as it came, as before */
        uint8_t *hk = held_key[trk_index(t)];
        hk[t->nheld] = in_key && song.grid != 1u && kb_engine(t, k) < 0
                           ? (uint8_t)(in_key | (uint32_t)(song.octave + 3) << 5) : 0u;
        held_dt[trk_index(t)][t->nheld] = (int8_t)(hk[t->nheld] ? (int32_t)note - kb_note[k] : 0);
        t->held[t->nheld++] = (uint8_t)note;
    }
    if (t->nheld == 1u) {
        t->arp_pos = 0xFFFFFFF;                     /* fire on this block */
        t->arp_idx = 0xFFFFFFFFu;
    }
}

/* the note leaves the held list */
static void arp_drop(track_t *t, uint32_t note)
{
    uint32_t i, k = 0;
    uint8_t *hk = held_key[trk_index(t)];
    int8_t *dt = held_dt[trk_index(t)];
    for (i = 0; i < t->nheld; i++)
        if (t->held[i] != note) {
            hk[k] = hk[i];
            dt[k] = dt[i];
            t->held[k++] = t->held[i];
        }
    t->nheld = (uint8_t)k;
}

static void arp_remove(track_t *t, uint32_t note)
{
    if (t->arp_phys)
        t->arp_phys--;
    if (arp_hold(t))
        return;
    arp_drop(t, note);
}

#define ND_NONE 0u                      /* track_t nd_late / nd_early: nothing latched (seq_tick; else its seq_pos + 1) */
static void rec_note(track_t *t, uint32_t note, uint32_t vel);
static void rec_release(track_t *t, uint32_t note);
static int rec_on(const track_t *t) {
#if FELUCCA_PAIR_MORPH
    if (pair_member(t)) return (song.rec & ~step_record_mask & ((1u << ep.a) | (1u << ep.b))) && song.playing && !0u;
#endif
    return (((song.rec & ~step_record_mask) >> trk_index(t)) & 1u) && song.playing && !0u;
}

#include "motion.c"

/* the ARP's modes (P_AMODE). Append-only: a stored value keeps its meaning. ORD (1.2, it played as UP before) plays
 * the held notes in the order they were pressed, whatever ARP 2's ORD switch says (that switch orders the list of the
 * other modes). 1.2 (Discussion #95), over the note list (the held notes low to high, or as played,
 * across OCT octaves), C E G held: DNUP G E C E; UP+8 C E G C' (the first note again an octave above the top);
 * CONV C G E (outside in); DIVG E G C (inside out); PINKY C G E G (the top note between the others); THUMB
 * C E C G (the bottom one); WALK a random step up or down the list (bouncing off its ends); CHORD all the held
 * notes together (the first 4), an octave higher each step through OCT */
enum { AM_OFF, AM_UP, AM_DN, AM_UPDN, AM_RND, AM_ORD, AM_REPEAT, AM_DNUP, AM_UP8, AM_CONV, AM_DIVG, AM_PINKY,
       AM_THUMB, AM_WALK, AM_CHORD, AM_TURING };

/* External clock advances exact quarter notes; sequencer/ARP periods are whole
 * samples. Carry the fractional difference instead of accumulating floor()
 * error each step. Separate carries retain polymeter and each ARP rate. */
#define MIDI_CLOCK_GRID 24000u                    /* fixed units per quarter, divisible by every DIV denominator */
typedef struct { uint32_t remainder; } midi_grid_t;
static midi_grid_t midi_seq_grid[NTRK], midi_arp_grid[NPART], midi_click_grid, midi_beat_grid;
static __attribute__((noinline)) void midi_grid_reset(void)
{
    memset(midi_seq_grid, 0, sizeof midi_seq_grid);
    memset(midi_arp_grid, 0, sizeof midi_arp_grid);
    memset(&midi_click_grid, 0, sizeof midi_click_grid);
    memset(&midi_beat_grid, 0, sizeof midi_beat_grid);
}
static __attribute__((noinline)) uint32_t midi_grid_advance(midi_grid_t *g, uint32_t n, uint32_t div)
{
    uint32_t quarter = beat_samples();
    if (div < 6u) quarter = (quarter / DIV_DEN[div]) * DIV_DEN[div];
    /* n <= GRID/2 and quarter <= 66150: numerator fits uint32_t. */
    uint32_t numerator = n * quarter + g->remainder;
    uint32_t samples = numerator / MIDI_CLOCK_GRID;
    g->remainder = numerator % MIDI_CLOCK_GRID;
    return samples;
}
static __attribute__((noinline)) uint32_t midi_seq_preview(const track_t *t, uint32_t n)
{
    midi_grid_t copy = midi_seq_grid[trk_index(t)];
    return midi_grid_advance(&copy, n, (uint32_t)t->p[P_SDIV]);
}

static void arp_forget(track_t *t)               /* (its notes ended otherwise: trk_all_off) */
{
    t->arp_note = t->arp_ch[0] = t->arp_ch[1] = t->arp_ch[2] = 0;
    t->arp_gate = 0;
}

/* CHORD's notes. Not inlined: they run once an arp step, and kept out of the audio ISR's loop over the tracks
 * (tests/target_budget.py) */
static __attribute__((noinline)) void arp_chord_off(track_t *t, int rec)   /* the other notes end */
{
    uint32_t i;
    for (i = 0; i < 3u; i++)
        if (t->arp_gate & (2u << i)) {
            if (rec)
                rec_release(t, t->arp_ch[i]);
            trk_note_off(t, t->arp_ch[i]);
            t->arp_ch[i] = 0;
            t->arp_gate &= (uint8_t)~(2u << i);
        }
}

static __attribute__((noinline)) void arp_chord(track_t *t, const uint32_t *list, uint32_t n)
{
    uint32_t i, j, nt, o = t->arp_idx % (uint32_t)(t->p[P_AOCT] > 0 ? t->p[P_AOCT] : 1);
    uint8_t used[CHORD_MAX], nu = 0;
    uint32_t lim = EXT_ON(t) ? 3u : 4u;             /* (CHORD EXT: the pool's three at most) */
    if (n > lim)
        n = lim;
    for (i = 0; i < n; i++) {
        nt = (uint32_t)clamp((int32_t)list[i] + 12 * (int32_t)o, 0, 127);
        nt = harmony_snap(t, nt);                   /* AM_CHORD follows HARMONY like every other ARP mode */
        for (j = 0; j < nu && used[j] != nt; j++)
            ;
        if (j == nu && nu < CHORD_MAX)
            used[nu++] = (uint8_t)nt;
    }
    for (i = 0; i < nu; i++) {
        nt = used[i];
        if (!i)
            t->arp_note = (uint8_t)nt;
        else
            t->arp_ch[i - 1u] = (uint8_t)nt;
        t->arp_gate |= (uint8_t)(1u << i);
        if (rec_on(t))
            rec_note(t, nt, 100);
        trk_note_on(t, nt, 100);
    }
}

static void arp_silence(track_t *t)              /* the sounding arp note(s) end */
{
    if (t->arp_gate & 14u)
        arp_chord_off(t, 0);
    if (t->arp_gate & 1u)
        trk_note_off(t, t->arp_note);
    t->arp_note = 0;
    t->arp_gate = 0;
}

static void arp_off(track_t *t)                  /* the sounding arp note(s) end (a recorded one too) */
{
    if (t->arp_gate & 14u)
        arp_chord_off(t, rec_on(t));
    if (t->arp_gate & 1u) {
        trk_note_off(t, t->arp_note);
        if (rec_on(t))
            rec_release(t, t->arp_note);
    }
    t->arp_note = 0;
    t->arp_gate = 0;
}

/* TURING: a 16-bit feedback register per track picks the note list's index. The taps 0,2,3,5 are the usual
 * maximal-length polynomial; one random bit flips now and then so the loop does not lock. No new parameter: the
 * register is the mode's own state, and a mode change leaves it where it is. */
static uint16_t arp_turing[NTRK];
static uint32_t arp_bar_last;                   /* the transport bar the ARP was last aligned to */

/* the place in the note list (len notes) the step arp_idx plays (not inlined, as arp_chord); UP+8 adds its note */
static __attribute__((noinline)) uint32_t arp_pick(track_t *t, uint32_t *list, uint32_t len)
{
    uint32_t i = t->arp_idx, m = (uint32_t)t->p[P_AMODE], cyc, k, w;
    if (m == AM_UP8 && len < 64u)                   /* UP+8: the first note again over the top */
        list[len++] = (uint32_t)clamp((int32_t)list[0] + 12 * t->p[P_AOCT], 0, 127);
    cyc = len > 1u ? 2u * len - 2u : 1u;
    k = i % cyc;
    switch (m) {
    case AM_DN:
        return len - 1u - i % len;
    case AM_UPDN:
        return k < len ? k : cyc - k;
    case AM_DNUP:
        return k < len ? len - 1u - k : k - (len - 1u);
    case AM_RND:
        return rng() % len;
    case AM_CONV:
    case AM_DIVG:
        k = i % len;
        if (m == AM_DIVG)
            k = len - 1u - k;
        return (k & 1u) ? len - 1u - k / 2u : k / 2u;
    case AM_PINKY:
        return len < 2u ? 0u : (k & 1u) ? len - 1u : k / 2u;
    case AM_THUMB:
        return len < 2u ? 0u : (k & 1u) ? 1u + k / 2u : 0u;
    case AM_TURING: {
        uint32_t k = trk_index(t);
        uint16_t r = arp_turing[k];
        uint16_t fb;
        if (!r)
            r = (uint16_t)(0xACE1u ^ (k * 0x9E37u));
        fb = (uint16_t)(((r >> 0) ^ (r >> 2) ^ (r >> 3) ^ (r >> 5)) & 1u);
        r = (uint16_t)((r >> 1) | (fb << 15));
        if ((rng() & 7u) == 0u)
            r ^= (uint16_t)(1u << (rng() & 15u));
        arp_turing[k] = r;
        return r % len;
    }
    case AM_WALK:
        w = t->arp_walk;
        if (!i)
            w = 0;                                  /* (from the bottom) */
        else if (w >= len)
            w = len - 1u;                           /* (notes let go) */
        else if (len > 1u)
            w = !w ? 1u : w == len - 1u ? w - 1u : (rng() >> 7) & 1u ? w + 1u : w - 1u;
        t->arp_walk = (uint8_t)w;
        return w;
    default:
        return i % len;
    }
}

/* n: samples the arp advances by (the external clock's while it runs, 0 stopped); gate_n: samples its
 * gate counts down by (real time when the external transport stops: a tapped or latched note still ends) */
/* The transport's musical time: bars (Q16) the sequencer clock has advanced while it plays, on the internal or the
 * external clock alike (a tempo change moves it at the new tempo; a Stop freezes it), and a count of Starts. Audio
 * side writes, the UI thread reads. HARMONY's bar counter and the MORPH JOURNEY's CONTINUE / START use this one clock. */
static volatile uint32_t perf_bars_q16, perf_starts;
static uint32_t perf_bars_rem;
static volatile uint32_t beat_pos, beat_n;      /* samples into the beat, the beat of the bar (0..3) */

/* the metronome (click.c) and the count-in (1.1, Discussion #131). The click follows the song tempo's quarter notes
 * (BPM, or the external clock's 24 pulses), 4 to the bar, the first accented, whatever a track's DIV or SWING: a beat is
 * four 1/16 steps as the sequencer counts them (click_beat_len: 4 x div_samples(1/16), which may be a few samples
 * shorter than beat_samples, so the click never drifts from the 1/16 tracks it is recorded against). clk_pos and
 * clk_step count the 1/16 steps as seq_tick counts a 1/16 track's (and midi_clock_pulse rescales clk_pos with them when
 * an external clock's tempo moves): CLK_START at seq_start clicks the first beat in the block step 0 starts in, and
 * beat k in the block a 1/16 track's step 4k starts in (every 4th step; step 0 of 16, the bar's first, accented).
 * The count-in: with MENU > COUNT-IN on, PLAY from stop with a track armed (REC while stopped starts PLAY too) on
 * the internal clock counts cin_total beats first (1 or 2 bars, clicked whatever CLICK is), then
 * starts the sequencer at step 1 exactly that many beats later (song.playing stays 0 until then: nothing plays or
 * records; the keys sound). A note into an armed track in the count-in's last eighth (the second half of its last
 * beat) is recorded onto step 1 when it starts (cin_keep, cin_flush), held on or let go as it was. An external clock
 * never counts in (its Start starts). STOP (seq_stop) cancels it. */
#define CLK_START 0xFFFFFFFFu
static uint32_t clk_pos = CLK_START, clk_step;  /* samples into the 1/16 step, the step of the bar (0..15) */
static volatile uint8_t cin_left, cin_total;    /* the count-in's beats still to come (0: none), of how many */
static volatile uint32_t cin_pos;               /* samples into its beat playing */
static uint8_t cin_flush;                       /* the count-in ended in this block: record what was kept */
static uint8_t cin_note[NTRK][4], cin_vel[NTRK][4], cin_n[NTRK], cin_up[NTRK];   /* kept notes; cin_up bit k: let go */
static int seq_counting(void) { return cin_left != 0u; }
static uint32_t click_beat_len(void) { return 4u * div_samples(2); }   /* DIV 2: 1/16 */
static int click_wanted(void)                  /* CLICK REC: while a track is armed (not in a song: no recording) */
{
    return click_mode == CLICK_ON || (click_mode == CLICK_REC && song.rec && !0u);
}
/* the arp's note list (list, its length returned; 0: nothing to play): the held notes (sorted or as played) over OCT
 * octaves, *cnt of them. #191: the notes as they play now, a key's mapped again through kb_pitch (TRN, ROOT, SCALE,
 * QNT now, the octave it was pressed in; a chord's note as far above it), the rest (MIDI IN) as they came; each once
 * (two keys may meet on one note now), a key silent now (a black key, QNT WHITE since) left out. With nothing changed
 * since the keys were pressed, exactly the list of held[] as before */
static uint32_t arp_list(const track_t *t, uint32_t *list, uint32_t *cnt)
{
    uint32_t i, j, n = 0, x, s, last = 0, len = 0, o;
    const uint8_t *hk = held_key[trk_index(t)];
    const int8_t *dt = held_dt[trk_index(t)];
    for (i = 0; i < t->nheld; i++) {
        x = t->held[i];
        if ((s = hk[i]) != 0u) {
            x = kb_pitch(t, (s & 31u) - 1u, (int32_t)(s >> 5) - 3);
            if (x == KB_SILENT)
                continue;
            x = (uint32_t)clamp((int32_t)x + dt[i], 0, 127);
        }
        last = x;
        for (j = 0; j < n && list[j] != x; j++)
            ;
        if (j == n)
            list[n++] = x;
    }
    {
        ext_cfg_t ec = ext_cfg(t);
        if (ext_is_on(t, &ec))                      /* CHORD EXT: each anchor becomes the pool's tones near it (none: silence) */
            n = ext_arp(t, &ec, list, n, &last);
    }
    *cnt = n;
    if (!t->p[P_AORDER] && t->p[P_AMODE] != AM_ORD)   /* (ORD: as pressed, held[] keeps that order) */
        for (i = 1; i < n; i++)
            for (j = i; j > 0 && list[j - 1] > list[j]; j--) {
                x = list[j];
                list[j] = list[j - 1];
                list[j - 1] = x;
            }
    for (o = 0; o < (uint32_t)t->p[P_AOCT]; o++)
        for (i = 0; i < n && len < 64u; i++)
            list[len++] = clamp((int32_t)list[i] + 12 * (int32_t)o, 0, 127);
    if (n && t->p[P_AMODE] == AM_REPEAT) { list[0] = last; len = 1; } /* REPEAT: last played note, no octave traversal */
    return len;
}

/* an arp step starts (period: its length): the next note of the list. Not inlined: once a step, kept out of the audio
 * ISR's loop over the tracks (tests/target_budget.py) */
static __attribute__((noinline)) void arp_fire(track_t *t, uint32_t period)
{
    uint32_t cnt, list[64], len, j;
    if (!(len = arp_list(t, list, &cnt))) {        /* (every key silent now: QNT WHITE's black keys) */
        if (t->arp_gate)
            arp_off(t);
        return;
    }
    t->arp_idx++;
    j = t->p[P_AMODE] == AM_CHORD ? 0u : arp_pick(t, list, len);
    if (t->arp_gate)
        arp_off(t);
    if ((uint32_t)(rng() & 127u) <= (uint32_t)t->p[P_APROB]) {
        t->arp_off = period * (uint32_t)t->p[P_AGATE] / 128u;
        if (t->p[P_AMODE] == AM_CHORD) {            /* CHORD: the first 4 notes, an octave up each step */
            arp_chord(t, list, cnt);
            return;
        }
        t->arp_note = (uint8_t)harmony_snap(t, list[j]);   /* every ARP step, TURING included */
        t->arp_gate = 1;
        if (rec_on(t))
            rec_note(t, t->arp_note, 100);           /* recording: what the arp plays */
        trk_note_on(t, t->arp_note, 100);
    }
}

/* External clock may deliver a fractional step, or several queued clocks at
 * once. Retain its remainder rather than losing it on every ARP trigger. */
static __attribute__((noinline)) void arp_external_due(track_t *t, uint32_t period, int32_t sw)
{
    uint32_t duration = period + (uint32_t)((t->arp_idx & 1u) ? sw : -sw);
    while (t->arp_pos >= duration) {
        t->arp_pos -= duration;
        arp_fire(t, period);
        duration = period + (uint32_t)((t->arp_idx & 1u) ? sw : -sw);
    }
    if (t->arp_gate) {
        if (t->arp_off <= t->arp_pos) arp_off(t);
        else t->arp_off -= t->arp_pos;
    }
}

static void arp_step(track_t *t, uint32_t n, uint32_t gate_n)
{
    uint32_t period;
    int32_t sw;
#if FELUCCA_PAIR_MORPH
    if (pair_follower(t)) return;
#endif
    if (t->arp_gate) {
        if (t->arp_off <= gate_n)
            arp_off(t);
        else
            t->arp_off -= gate_n;
    }
    if (!t->p[P_AMODE] || !t->nheld) {
        if (!t->nheld && t->arp_gate)
            arp_off(t);
        return;
    }
    period = div_samples((uint32_t)t->p[P_ARATE]);
    sw = t->p[P_ASWING] * (int32_t)period / 250;
    t->arp_pos += n;
    if (t->arp_pos < period + (uint32_t)((t->arp_idx & 1u) ? sw : -sw) && t->arp_pos != 0xFFFFFFF + n)
        return;
    if (song.g[G_CLOCK] && t->arp_pos != 0xFFFFFFFu + n) {
        arp_external_due(t, period, sw);
        return;
    }
    if (song.g[G_CLOCK]) midi_arp_grid[trk_index(t)].remainder = 0;
    t->arp_pos = 0;
    arp_fire(t, period);
}

static void arp_tick(track_t *t, uint32_t n) { arp_step(t, n, n); }
/* ARP SYNC: realign the free-running arp phase at every transport bar. RATE 2BAR/4BAR are longer than the bar
 * and would be cut, so they keep their own cycle. */
static void arp_bar_sync(void)
{
    uint32_t now = HARM_BAR(), i;
    if (now == arp_bar_last)
        return;
    arp_bar_last = now;
    for (i = 0; i < NTRK; i++) {
        if ((uint32_t)trk[i].p[P_ARATE] >= 8u)          /* 2BAR / 4BAR: not reset by a one-bar boundary */
            continue;
        trk[i].arp_pos = 0xFFFFFFF;
        trk[i].arp_idx = 0xFFFFFFFFu;
    }
}

/* -------------------------------------------------------- note input --- */
/* the length of step idx in samples: SWING (the track's + the global, at most 100) makes the even steps longer
 * and the odd ones shorter, so every odd step starts late */
static uint32_t step_samples(const track_t *t, uint32_t period, uint32_t idx)
{
    return swing_step_len(t, period, idx);   /* core.h: own + global, at most 100 */
}

/* NUDGE (1.2, #162): a note `off` samples from the start of the step it goes into, in 1/NUDGE_DIV of the step (period),
 * rounded (step_set_nudge keeps -8..+7): the first note of a fresh step sets it; QUANTIZE (P_SQNT) decides whether it
 * plays (not inlined: its divide stays out of the audio ISR's loops) */
static __attribute__((noinline)) int32_t rec_nudge(int32_t off, uint32_t period)
{
    return (off * NUDGE_DIV + (off < 0 ? -(int32_t)period / 2 : (int32_t)period / 2)) / (int32_t)(period ? period : 1u);
}

/* live recording: the note goes into the nearest step, as swung (the one playing, or
 * the next one when it is past the middle of the playing one). Overdub: a step that
 * holds notes gets this one added (a chord of up to 4; when full, the last note is
 * replaced); MONO / LEGATO / UNISON parts keep one note per step, as step entry does.
 * Held on (synth parts): each further step the sequencer enters while the note is
 * held becomes a TIE (rec_hold), up to the pattern length; a release before the middle
 * of the last one puts that step back (rec_release), so a short note stays one step.
 * A note recorded into another step ends the hold before (the step model ties the
 * notes of one step only). */
static void rec_note(track_t *t, uint32_t note, uint32_t vel)
{
    uint32_t len = t->p[P_SLEN] > 0 ? (uint32_t)t->p[P_SLEN] : 1u, idx = t->seq_idx % len, k;
    uint32_t period = div_samples((uint32_t)t->p[P_SDIV]), cur = step_samples(t, period, t->seq_idx);
    uint32_t next = t->seq_pos > cur / 2u, sounds;
    int32_t off = rec_nudge(t->seq_pos >= cur ? 0 : next ? -(int32_t)(cur - t->seq_pos) : (int32_t)t->seq_pos, period);
    step_t *s;
    if (next)
        idx = (idx + 1u) % len;
    s = &t->step[idx];
    /* the step's notes play later in this pass (it is the next one, not played early yet, or the one playing whose
     * nudge has not come yet): what sounds now must not play again there (rskip) */
    sounds = next ? t->nd_fired != idx + 1u : t->nd_late != ND_NONE;
    if (drum_track(t)) {                            /* DRUM: into the grid, no holds (hits) */
        uint32_t l = drum_lane(note);
        if (s->time != ST_NOTE || (!s->n && !s->hit)) {
            s->n = s->hit = s->acc = 0;
            s->flags = 0;
            s->vel = 0;
            step_set_nudge(s, off);
        }
        s->time = ST_NOTE;
        if (note == DRUM_LANE_NOTE[l]) {            /* a lane's note: its hit */
            s->hit |= (uint8_t)(1u << l);
            if (vel > 110)
                s->acc |= (uint8_t)(1u << l);
        } else {                                    /* another GM drum (a low tom, a crash): a note */
            for (k = 0; k < s->n && s->note[k] != note; k++)
                ;
            if (k == s->n) {
                if (s->n < 4u)
                    s->n++;
                s->note[s->n - 1u] = (uint8_t)note;
            }
            if (vel > 110)
                s->flags |= SF_ACCENT;
        }
        if (vel > s->vel)
            s->vel = (uint8_t)vel;
        t->seq_active = 1;
        if (sounds) {
            if (t->rskip_idx != idx)
                t->rskip_n = 0;
            t->rskip_idx = (uint8_t)idx;
            if (t->rskip_n < NLANE)
                t->rskip[t->rskip_n++] = (uint8_t)note;
        }
        return;
    }
    if (s->time != ST_NOTE || !s->n || trk_vmode(t) != V_POLY) {
        s->n = 0;                                   /* a fresh step */
        s->flags = 0;
        s->vel = 0;
        step_set_nudge(s, off);
    }
    for (k = 0; k < s->n && s->note[k] != note; k++)
        ;
    if (k == s->n) {
        if (s->n < 4u)
            s->n++;
        s->note[s->n - 1u] = (uint8_t)note;
    }
    s->time = ST_NOTE;
    if (vel > 110)
        s->flags |= SF_ACCENT;
    if (vel > s->vel)
        s->vel = (uint8_t)vel;
    t->seq_active = 1;
    if (sounds) {                                   /* it sounds now: the step must not trigger it again */
        if (t->rskip_idx != idx)
            t->rskip_n = 0;
        t->rskip_idx = (uint8_t)idx;
        if (t->rskip_n < 4u)
            t->rskip[t->rskip_n++] = (uint8_t)note;
    }
    if (!t->rh_n || t->rh_start != idx) {           /* a new hold (one in another step ends) */
        t->rh_n = 0;
        t->rh_start = (uint8_t)idx;
        t->rh_ties = 0;
    }
    for (k = 0; k < t->rh_n && t->rh_note[k] != note; k++)
        ;
    if (k == t->rh_n && t->rh_n < 4u)
        t->rh_note[t->rh_n++] = (uint8_t)note;      /* a chord: held until its last key is up */
}

/* the sequencer enters step idx (before playing it): a recorded note still held ties into it */
static void rec_hold(track_t *t, uint32_t idx, uint32_t len)
{
    step_t *s;
    uint32_t k;
    if (!t->rh_n)
        return;
    if (!(((song.rec & ~step_record_mask) >> trk_index(t)) & 1u) || t->rh_ties + 1u >= len) {
        t->rh_n = 0;                                /* disarmed, or the whole pattern is this note */
        return;
    }
    if (idx == t->rh_start)
        return;                                     /* (recorded ahead into the step now starting) */
    s = &t->step[idx];
    t->rh_bak = *s;
    t->rh_last = (uint8_t)idx;
    t->rh_ties++;
    for (k = 0; k < 4u; k++)
        s->note[k] = 0;
    s->n = 0;
    s->time = ST_TIE;
    s->flags = 0;
    s->vel = 0;
    s->hit = s->acc = 0;
}

/* a key of a recorded note is up: the hold ends with the last one */
static void rec_release(track_t *t, uint32_t note)
{
    uint32_t i, k = 0;
    for (i = 0; i < t->rh_n; i++)
        if (t->rh_note[i] != note)
            t->rh_note[k++] = t->rh_note[i];
    if (k == t->rh_n || (t->rh_n = (uint8_t)k))
        return;                                     /* not one of them, or others still held */
    if (t->rh_ties && t->seq_idx == t->rh_last &&
        t->seq_pos < step_samples(t, div_samples((uint32_t)t->p[P_SDIV]), t->seq_idx) / 2u)
        t->step[t->rh_last] = t->rh_bak;            /* released early in it: not held into this step */
}

/* a note into armed track t in the count-in's last eighth: kept for step 1 (cin_flush); once each, 4 per track */
static __attribute__((noinline)) void cin_keep(track_t *t, uint32_t note, uint32_t vel)
{
    uint32_t i = trk_index(t), k;
    if (cin_left != 1u || cin_pos < click_beat_len() / 2u || !(((song.rec & ~step_record_mask) >> i) & 1u) || t->p[P_AMODE])
        return;
    for (k = 0; k < cin_n[i] && cin_note[i][k] != note; k++)
        ;
    if (k == cin_n[i]) {
        if (k == 4u)
            return;
        cin_n[i]++;
    }
    cin_note[i][k] = (uint8_t)note;
    cin_vel[i][k] = (uint8_t)vel;
    cin_up[i] &= (uint8_t)~(1u << k);
}

#include "capture.c"
#if !FELUCCA_FM4
static int ext_real_input(void) {
#if CARAVEL_UX_CAPTURE
    return !cap_replay;
#else
    return 1;
#endif
}
#endif
static void input_on(track_t *t, uint32_t note, uint32_t vel)
{
#if CARAVEL_UX_CAPTURE
    if(!cap_replay) {
        cap_latched[trk_index(t)][note>>5]&=~(1u<<(note&31u));
        if(cap_note_held(t,note))return; /* the shared input is already down */
    }
#endif
    last_note = (uint8_t)note;
    lat_vel[trk_index(t)][note & 127u] = (uint8_t)clamp((int32_t)vel, 1, 127);
    lat_src[trk_index(t)][note & 127u] = (uint8_t)note; /* immutable latch anchor */
    lat_put(lat_stay[trk_index(t)], note, 0);       /* (LATCH: a latched note pressed again is held by the key again) */
    lat_put(lat_eat[trk_index(t)], note, 0);
    if (cin_left)
        cin_keep(t, note, vel);
    if (rec_on(t) && !t->p[P_AMODE])               /* (ARP on: arp_tick records its notes) */
        rec_note(t, note, vel);
    if (t->p[P_AMODE])
        arp_add(t, note);
    else
        trk_note_on(t, note, vel);
}

static int midi_note_held(const track_t *t, uint32_t note);
static int midi_local_held(const track_t *t, uint32_t note);
static void input_off(track_t *t, uint32_t note)
{
#if CARAVEL_UX_CAPTURE
    if((!cap_replay && cap_note_held(t,note)) || midi_local_held(t,note))return;
#endif
    if (midi_note_held(t, note))
        return;
    if (lat_get(lat_eat[trk_index(t)], note)) {    /* (LATCH STACK: this press ended the note, nothing began) */
        lat_put(lat_eat[trk_index(t)], note, 0);
        return;
    }
    if (cin_left) {                                 /* a kept note let go before step 1: recorded, then let go */
        uint32_t i = trk_index(t), k;
        for (k = 0; k < cin_n[i]; k++)
            if (cin_note[i][k] == note)
                cin_up[i] |= (uint8_t)(1u << k);
    }
    rec_release(t, note);
    arp_remove(t, note);                            /* both: the note may have started in the */
    if (!t->p[P_AMODE] && latch_mode(t) != LT_OFF) {
        lat_put(lat_stay[trk_index(t)], note, 1);   /* LATCH: the note sounds on, let go of by latch_free */
        return;
    }
    trk_note_off(t, note);                          /* other mode (ARP switched while held) */
}

/* the effect of key k in the FX layer (PF_N none): the white keys F3 .. G5 the map's (perf_map: the settings,
 * ui_layer.c; by default 1.1.5's ten, FLANGER, PHASER, REV / ECHO THROW), black keys 1..4 the track mutes */
static uint32_t perf_key(uint32_t k)
{
    uint32_t p = key_place(k);
    return !key_black(k) ? (p < PF_KEYS ? perf_map[p] : PF_N) : p < NTRK ? PF_M1 + p : PF_N;
}

/* a key of the FX layer down (FX held) / up: the effect it holds. kb_fx: the one it took (+ 1, 0 none), so a key
 * remapped while held lets go of what it holds; an effect two keys hold ends with the last of them. noinline: out
 * of keyboard_block's loop (the audio ISR) */
static uint8_t kb_fx[27];
static __attribute__((noinline)) void perf_key_press(uint32_t k, int down)
{
    uint32_t e, j;
    if (down) {
        e = perf_key(k);
        kb_fx[k] = (uint8_t)(e + 1u);
        perf_press(e, 1);
        return;
    }
    if (!kb_fx[k])
        return;
    e = kb_fx[k] - 1u;
    kb_fx[k] = 0;
    for (j = 0; j < 27u; j++)
        if (kb_fx[j] == e + 1u)
            return;
    perf_press(e, 0);
}

/* the map changed (ui_layer.c: PRESETS with a key held, EDIT, a settings load): a white key held takes its new
 * effect at once (the old one let go); FX LATCH: a latched effect of the key's becomes the new one */
static __attribute__((noinline)) void perf_key_remap(void)
{
    uint32_t k, e, o;
    perf_remap = 0;
    for (k = 0; k < 27u; k++) {
        if (!kb_fx[k] || key_black(k) || (o = kb_fx[k] - 1u) == (e = perf_key(k)))
            continue;
        if (!perf_latch_on) {
            perf_key_press(k, 0);
            perf_key_press(k, 1);
            continue;
        }
        kb_fx[k] = (uint8_t)(e + 1u);
        if (o < PF_N && ((perf_latched >> o) & 1u)) {
            perf_latched &= ~PF_BIT(o);
            motion_fx_capture(o, 0);
            if (e < PF_N) {
                perf_latched |= PF_BIT(e);
                perf_ord[e] = ++perf_seq;
                motion_fx_capture(e, 1);
            }
        }
    }
}

/* outgoing MIDI ownership: a NoteOff may only be sent when no other key on this track still owns the note */
static int midi_out_held(uint32_t ignore, uint32_t trk, uint32_t note)
{
    uint32_t j, i;
    for (j = 0; j < 27u; j++) {
        if (j == ignore || !kb_midin[j] || kb_trk[j] != trk)
            continue;
        for (i = 0; i < kb_midin[j]; i++)
            if (kb_midi[j][i] == note)
                return 1;
    }
    return 0;
}

/* key k plays kb_note[k] on track t: its chord (chord.c; the note alone with CHRD OFF). A note another key
 * holds already sounds: it is not started again (nor sent to MIDI OUT); the key keeps its notes */
static void key_on(uint32_t k, track_t *t)
{
    cap_key_on(k, t);                                   /* capture the input before harmonic mapping */
    kb_src[k] = kb_note[k];
    if (harmony_on && harmony_follow[trk_index(t)] && t->p[P_CHRD] != CH_BUS && !chord_kit(t))
        kb_note[k] = (uint8_t)harmony_snap(t, kb_note[k]);   /* live single notes follow HARMONY */
    ext_cfg_t ec = ext_cfg(t);
    uint32_t n = chord_build_c(t, &ec, kb_note[k], kb_chord[k]), i, mc = trk_midi_ch(trk_index(t)), vel = kb_vel, eat;
    kb_chn[k] = 0;
    kb_live[k] = 1;                                 /* a fresh press is eligible for retrigger */
    kb_midin[k] = (uint8_t)n;
    for (i = 0; i < n; i++)
        kb_midi[k][i] = kb_chord[k][i];
    eat = (uint32_t)latch_press(t, kb_chord[k], n);   /* LATCH STACK: the key again ends its latched notes */
    in_key = (uint8_t)(k + 1u);                     /* (the arp keeps the key: arp_add) */
    for (i = 0; i < n; i++) {
        uint32_t x = kb_chord[k][i];
        if (!midi_local_held(t, x)) {
            if (!eat)
                input_on(t, x, vel);
        }
        if (!midi_out_held(k, (uint32_t)kb_trk[k], x))
            midi_out_event(0x09u | (0x90u | mc) << 8 | x << 16 | vel << 24);
    }
    in_key = 0;
    kb_chn[k] = (uint8_t)n;
    last_note = kb_note[k];                         /* (step entry, the SAMPLE zone: the key's note) */
}

/* key k is up: the notes it started end, but those another key still holds */
static void key_off(uint32_t k, track_t *t)
{
    cap_key_off(k, t);
    uint32_t n = kb_chn[k], mn = kb_midin[k], live = kb_live[k], i, mc = trk_midi_ch(trk_index(t));
    kb_chn[k] = 0;
    kb_live[k] = 0;
    kb_midin[k] = 0;
    if (live) latch_bus_release(t, kb_chord[k], n);
    for (i = 0; i < n; i++) {
        uint32_t x = kb_chord[k][i];
        if (!midi_local_held(t, x)) {
            if (live)
                input_off(t, x);
            else {
                arp_remove(t, x);                /* round 7: a key let go after STOP/panic leaves the ARP's list too */
                if (!chord_note_held(trk_index(t), x))
                    trk_note_off(t, x);          /* STOP/panic: release any old gate without creating a fresh LATCH */
            }
        }
    }
    for (i = 0; i < mn; i++) {
        uint32_t x = kb_midi[k][i];
        if (!midi_out_held(k, (uint32_t)kb_trk[k] % NTRK, x))
            midi_out_event(0x08u | (0x80u | mc) << 8 | x << 16);
    }
    chord_live_sync(trk_index(t));
    cap_key_done();
}

#ifdef FM1_INPUT_LAT
/* the press latency stats (hal/fm1_input.h fm1_in_stat, console `inp`): from the first scan that saw
 * key k closed to its note-on here, and to the note's first sample leaving the DMA (kb_out_tick:
 * audio.c, the TIMER4 tick at which the block being rendered starts to play) */
static uint32_t kb_out_tick;
static __attribute__((noinline)) void kb_lat(uint32_t k)
{
    uint32_t t0 = fm1_in.note_t0[k], d = fm1_ticks() - t0, o = kb_out_tick - t0;
    fm1_in_stat.kb_n++;
    fm1_in_stat.kb_sum += d;
    fm1_in_stat.dac_sum += o;
    if (d > fm1_in_stat.kb_max)
        fm1_in_stat.kb_max = d;
    if (o > fm1_in_stat.dac_max)
        fm1_in_stat.dac_max = o;
}
#endif

#ifndef CARAVEL_UX_EVOLVE
#define CARAVEL_UX_EVOLVE 0
#endif
#if CARAVEL_UX_EVOLVE
static int uxl_swallow(uint32_t k);
#endif
static void keyboard_block(void)
{
    uint32_t cur = fm1_in.notes, ch, k;
    uint32_t lay, fx, mute;
#if CARAVEL_ACTION_BANKS
    /* A key held before ACTION activation remains a note until released. */
    action_preheld &= cur;
#endif
    ch = cur ^ kb_prev;                          /* keys also sound while entering steps */
    if (perf_remap)
        perf_key_remap();
    if (!ch)
        return;
    if (kb_boot_hold) {                           /* #137: under the splash; their release is silent too */
        for (k = 0; k < 27u; k++)
            if ((ch & cur) >> k & 1u)
                kb_note[k] = KB_SILENT;
        kb_prev = cur;
        return;
    }
    lay = (fm1_in.buttons & kb_mask) || kb_lock;  /* (#83: kb_lock, a layer locked open with no button held) */
    fx = (fm1_in.buttons & perf_mask) || (kb_lock & 2u);
    mute = song.grid == 2u ? ~0u : song.grid == 3u ? SONG_KEYS : 0u;   /* the keys that never sound here */
    for (k = 0; k < 27u; k++) {
        if (!((ch >> k) & 1u))
            continue;
        if ((cur >> k) & 1u) {                    /* the selected track; the key-up goes to the same one */
            kb_trk[k] = song.sel;
#if FELUCCA_PAIR_MORPH
            kb_trk[k] = (uint8_t)(pair_owner(&trk[kb_trk[k]]) - trk);
#endif

            if (kb_asleep) {                      /* (SCREEN OFF: the wake press is swallowed) */
                kb_note[k] = KB_SILENT;
                continue;
            }
            if (lay) {                            /* a layer's button held (or locked): the key is the layer's */
                kb_note[k] = KB_SILENT;           /* (ui_layer.c), with FX an effect (perform.c) */
                kb_layer |= 1u << k;
                if (fx)
                    perf_key_press(k, 1);
                continue;
            }
#if CARAVEL_UX_EVOLVE
            if (uxl_swallow(k)) {                 /* PLAY, LFO held: D5 E5 F5 G5 are the EVOLVE verbs (ui_uxl.c) */
                kb_note[k] = KB_SILENT;
                continue;
            }
#endif
#if CARAVEL_ACTION_BANKS
            if ((action_capture_mask & (1u << k)) && !(action_preheld & (1u << k))) {
                kb_note[k] = KB_SILENT;  /* no note-on, recording or MIDI */
                continue;
            }
#endif
            if ((mute >> k) & 1u)                 /* NAME (ui_name.c): every key types, none sounds; SONG: A..D */
                kb_note[k] = KB_SILENT;
            else if (song.grid == 1u)             /* the DRUM grid: a lane key plays its lane, the rest are the UI's */
                kb_note[k] = grid_key_note(k);
            else
                kb_note[k] = (uint8_t)kb_map(&trk[kb_trk[k]], k);
            if (kb_note[k] == KB_SILENT)
                continue;
            key_on(k, &trk[kb_trk[k]]);
#ifdef FM1_INPUT_LAT
            kb_lat(k);
#endif
        } else {
            if ((kb_layer >> k) & 1u) {
                kb_layer &= ~(1u << k);
                perf_key_press(k, 0);
                continue;
            }
            if (kb_note[k] == KB_SILENT)
                continue;
            key_off(k, &trk[kb_trk[k] % NTRK]);
        }
    }
    kb_prev = cur;
}

/* -------------------------------------------------------- sequencer --- */
/* DUP x2 publishes the editable/savable pattern immediately, but the current
 * pass finishes at its old end. No step/clock restart; only eight runtime bytes,
 * never part of a saved project. A manual LEN edit cancels the temporary end. */
static uint8_t seq_extend_end[NTRK], seq_extend_target[NTRK];
static uint32_t seq_loop_len(const track_t *t)
{
    uint32_t k = trk_index(t), len = t->p[P_SLEN] > 0 ? (uint32_t)t->p[P_SLEN] : 1u;
    if (!seq_extend_end[k]) return len;
    if (seq_extend_target[k] != len)
        seq_extend_end[k] = seq_extend_target[k] = 0;
    return seq_extend_end[k] ? seq_extend_end[k] : len;
}
static void seq_start(void)
{
#if CARAVEL_REVERB_MINIMAL
    stasis_transport_start();      /* PLAY starts fresh recording after STOP's tail */
#endif
    uint32_t i;
    midi_grid_reset();
    bar_reset_req = 0;                             /* PLAY starts at the top; nothing left to reset */
    memset(seq_extend_end, 0, sizeof seq_extend_end);
    memset(seq_extend_target, 0, sizeof seq_extend_target);
    motion_fx_close();
    motion_begin();
    ((void)0);
    for (i = 0; i < NTRK; i++) {                   /* every track from its step 0, together */
        track_t *t = &trk[i];
        t->seq_idx = (uint16_t)(t->p[P_SLEN] - 1);
        t->seq_pos = 0x7FFFFFFF;                   /* step 0 fires on the first block */
        t->rskip_n = 0;
        t->rh_n = 0;
        t->rat_left = 0;
        t->nd_late = t->nd_early = ND_NONE;
        t->nd_fired = 0;
        t->arp_pos = 0xFFFFFFF;                    /* ARP phrase starts with the sequencer */
        t->arp_idx = 0xFFFFFFFFu;
        if (t->p[P_LTRIG] && t->p[P_LSYNC])        /* LFO 2 FREE + SYNC: in time with the bars from PLAY */
            t->lfo_ph = (uint32_t)t->p[P_LPHASE] << 25;
        lfo2_trigger(t, 1);
    }
    song.tick = 0;
    harmony_perf_clear();
    harmony_phase = (uint16_t)perf_bars_q16;       /* round 7: a start is a bar line for HARMONY (the clock kept the phase of the last stop) */
    harmony_base_bar = HARM_BAR();                 /* HARMONY BAR 1 with the transport, on either clock */
    harmony_bar = 0;
    beat_pos = 0; beat_n = 0;                      /* the ARP LED's beat from the top too */
    clk_pos = CLK_START;                           /* the metronome's first beat with step 0 */
    song.playing = 1;
    arp_bar_last = HARM_BAR();
#if FELUCCA_PERF_HW
    perf_starts++;
#endif
    slicer_start();                                /* slicer.c: its step 0 with the sequencer's */
    perf_start();                                  /* perform.c: its 1/16 grid too */
}

static void seq_release(track_t *t)
{
    uint32_t i;
    for (i = 0; i < t->seq_n; i++)
        trk_note_off(t, t->seq_notes[i]);
    t->seq_n = 0;
    t->seq_hold = 0;
    t->slide_glide = 0;                             /* live MONO / LEG keys must not glide after it */
}

static __attribute__((noinline)) void seq_stop(void)
{
    uint32_t i;
    ext_sources_stop();                           /* discard a partial gesture, retain remembered harmony */
#if CARAVEL_REVERB_MINIMAL
    stasis_transport_stop();       /* STOP must release held STASIS independently of transport */
#endif
    midi_resync_cancel();
    memset(seq_extend_end, 0, sizeof seq_extend_end);
    memset(seq_extend_target, 0, sizeof seq_extend_target);
    motion_fx_close();
    song.playing = 0;
    LAUNCH_STATE.live_pending = LAUNCH_STATE.live_applied = 0;
    cin_left = 0;                                  /* (a count-in: cancelled, nothing recorded) */
    bar_reset_req = 0;                             /* a reset armed before the stop does not fire after it */
    cin_flush = 0;
    memset(cin_n, 0, sizeof cin_n);
    if (song.g[G_CLOCK])                           /* external clock: the arp stops with the transport, */
        for (i = 0; i < NPART; i++)                /* its sounding note too (HOLD keeps the latched chord) */
            if (trk[i].arp_gate)
                arp_off(&trk[i]);
    for (i = 0; i < NTRK; i++) {
        if (latch_mode(&trk[i]) != LT_OFF) {       /* STOP ends the latch: the latched notes and the arp's chord */
            latch_free(&trk[i]);
            if (trk[i].nheld && !trk[i].arp_phys) {
                trk[i].nheld = 0;
                if (trk[i].arp_gate)
                    arp_silence(&trk[i]);
            }
        }
        seq_release(&trk[i]);
        trk[i].rh_n = 0;                           /* a recorded note held over the stop: as far as it got */
        trk[i].rat_left = 0;
        trk[i].nd_late = trk[i].nd_early = ND_NONE;   /* (a nudged step not played yet: not after the stop) */
        trk[i].nd_fired = 0;
    }
    chord_stop_all();                              /* a retriggered bus chord is not in any holder list */
    ((void)0);
    motion_end();
}

/* play one step: TIE extends, REST releases, NOTE (re)triggers its notes, then its lane hits (their GM
 * notes, DRUM_LANE_NOTE; an accented hit at 127); a SLIDE on the previous step makes this one legato with a
 * glide (acid style). skip: bit k = note k, bit 8 + l = the hit of lane l already sounds from live
 * recording (not triggered, not released here); SEQ_REP: a RATCH repeat (seq_ratchet).
 * RATCH x2..x4 (core.h step_ratchet): a NOTE step plays all of it again in equal parts of its swung length, each
 * part retriggered with GATE of the part; the chance is rolled once for the whole step (a failed roll: no part),
 * a slide into it glides into the first part only, and it never slides or ties out (its last part ends at its
 * gate). x1, what every older pattern holds, is the step exactly as before. */
/* 1.5.5 (#209): a step's CONDITION (core.h step_cond). a:b plays on loop a of every b of its track: cond_loop counts the
 * passes through the track's LEN, 0 the first (seq_tick: each wrap to step 1 adds one, modulo COND_LOOPS, a multiple
 * of 2, 3 and 4). It starts at 0 on PLAY (and RESTART) and on every SONG section (each section's pattern from its
 * first loop: 4:4 plays on a section's 4th repeat); a pattern loaded or LEN changed while playing keeps counting. Each
 * track counts its own LEN. A step played early by its NUDGE (step 1 at the end of the loop before) is the next
 * loop's. FILL / !FILL: seq_fill, set by the UI while GLO + E4 is held (ui_layer.c). Read where the chance is rolled
 * (seq_play): a step whose condition fails plays as a failed roll (nothing, none of its locks). Every step with no
 * condition (every older pattern) plays as before, its roll untouched */
#define COND_LOOPS 12u
static volatile uint8_t seq_fill;
static const uint8_t COND_A[9] = {1, 2, 1, 2, 3, 1, 2, 3, 4}, COND_B[9] = {2, 2, 3, 3, 3, 4, 4, 4, 4};
static __attribute__((noinline)) int seq_cond_miss(const track_t *t, const step_t *s, uint32_t idx)
{
    uint32_t c = step_cond(s), loop;
    if (c >= COND_FILL)
        return (c == COND_FILL) != (seq_fill != 0u);
    if (!c)
        return 0;
    loop = t->cond_loop + (idx < t->seq_idx);       /* (an early play of step 1: the next loop's) */
    return loop % COND_B[c - 1u] != COND_A[c - 1u] - 1u;
}
/* the step does not play: its condition fails, or its chance's roll */
static int seq_miss(const track_t *t, const step_t *s, uint32_t idx)
{
    if (s->probability >= COND_FIRST)
        return seq_cond_miss(t, s, idx);
    return step_chance(s) < 100u && rng() % 100u >= step_chance(s);
}
#define SEQ_REP (1u << 16)
#define SEQ_ROLLED (1u << 17)   /* seq_tick rolled the chance already (before the step's parameter locks): it passed */
#define SEQ_MISS (1u << 18)     /* .. it failed: nothing plays */
static __attribute__((noinline)) void seq_step(track_t *t, const step_t *s, uint32_t idx, uint32_t period, uint32_t skip)
{
    uint32_t i, j, gate = period * (uint32_t)t->p[P_SGATE] / 128u;
    uint32_t vel = (s->flags & SF_ACCENT) ? 127u : (s->vel ? s->vel : 96u);
    uint32_t slide_in = t->seq_hold && t->seq_n && !(skip & SEQ_REP);
    uint32_t len = t->p[P_SLEN] ? (uint32_t)t->p[P_SLEN] : 1u;
    uint32_t next_tie = seq_steps(t)[(idx + 1u) % len].time == ST_TIE;
    uint32_t hits = step_ratchet(s);
    uint8_t nn[4 + NLANE], vv[4 + NLANE];           /* the notes it plays: its notes, then its hits */
    uint32_t m = 0, sk = 0;
    /* QNT SEQ: the step's notes (not the lane hits) snap to the scale as they play; never on a drum kit, the slices
     * or another engine that maps the keys itself. SEQ+T (#218): moved by TRN first, as the keys are. seq_notes keeps
     * the notes that sound: their note-offs match */
    const engine_t *e = ENGINES[eng_idx(t->eng_req)];
    uint32_t qseq = t->p[P_QUANT] >= QN_SEQ && !(e->keys && e->keys(t, 0) >= 0);
    int32_t qtrn = qseq && t->p[P_QUANT] == QN_SEQT ? t->p[P_TRANS] : 0;
    if (!(skip & SEQ_REP)) {
        t->rat_left = 0;
        if ((skip & SEQ_MISS) || (!(skip & SEQ_ROLLED) && seq_miss(t, s, idx))) {
            seq_release(t);
            return;
        }
    }
    if (s->time == ST_TIE) {
        if (t->seq_n) {
            t->seq_off = gate + period / 2u;
            t->seq_hold = (s->flags & SF_SLIDE) != 0 || next_tie;   /* chains hold at any GATE / swing */
        }
        return;
    }
    if (s->time == ST_REST || (!s->n && !s->hit)) {
        seq_release(t);
        return;
    }
    if (hits > 1u) {                                /* RATCH: the gate of a part, no slide or tie out */
        gate = step_samples(t, period, idx) / hits * (uint32_t)t->p[P_SGATE] / 128u;
        if (!(skip & SEQ_REP))
            t->rat_left = (uint8_t)(hits - 1u);
    }
    ext_cfg_t ec = ext_cfg(t);
    uint32_t ex = ext_is_on(t, &ec);                /* CHORD EXT: every note of every step takes the pool's nearest tone */
    for (i = 0; i < s->n && i < 4u; i++) {
        uint32_t x = s->note[i];
        if (ex) {                                   /* (SEQ+T's transposition stays; no scale snap, no HARMONY snap) */
            int32_t y = ext_map(t, &ec, clamp((int32_t)x + qtrn, 0, 127));
            if (y < 0)
                continue;                           /* no pool (WAIT / empty): the note is not played */
            x = (uint32_t)y;
            for (j = 0; j < m && nn[j] != x; j++)
                ;
            if (j < m)                              /* two notes on one pool tone play once */
                continue;
        } else {
            if (qseq) {                             /* QNT SEQ: onto the scale now; two notes snapping */
                x = (uint32_t)clamp(scale_snap(t, (int32_t)x + qtrn), 0, 127);   /* together play once */
                for (j = 0; j < m && nn[j] != x; j++)
                    ;
                if (j < m)
                    continue;
            }
            if (harmony_on && (idx & 3u) == 0u)
                x = harmony_snap(t, x);              /* HARMONIC BUS: a strong step takes a chord tone */
        }
        nn[m] = (uint8_t)x;
        vv[m] = (uint8_t)vel;
        sk |= ((skip >> i) & 1u) << m;
        m++;
    }
    for (i = 0; i < NLANE; i++)
        if ((s->hit >> i) & 1u) {
            nn[m] = DRUM_LANE_NOTE[i];
            vv[m] = (uint8_t)((s->acc >> i) & 1u ? 127u : vel);
            sk |= ((skip >> (8u + i)) & 1u) << m;
            m++;
        }
    t->slide_glide = (uint8_t)slide_in;
    if (!slide_in)
        seq_release(t);
    for (i = 0; i < m; i++)
        if (!((sk >> i) & 1u))
            trk_note_on(t, nn[i], vv[i]);
    if (slide_in)                                   /* release what is not held over */
        for (i = 0; i < t->seq_n; i++) {
            for (j = 0; j < m && nn[j] != t->seq_notes[i]; j++)
                ;
            if (j == m)
                trk_note_off(t, t->seq_notes[i]);
        }
    t->seq_n = 0;
    for (i = 0; i < m; i++)
        if (!((sk >> i) & 1u))
            t->seq_notes[t->seq_n++] = nn[i];
    t->seq_off = gate;
    t->seq_hold = hits == 1u && ((s->flags & SF_SLIDE) != 0 || next_tie);   /* next step a TIE: keep the notes to it */
}

/* MENU > CONTROL > STEP PREVIEW (1.2, Discussion #169): the UI asks for a step of a track to sound once (aud_req: step
 * << 8 | track + 1; ui_input.c cursor_move); with the transport stopped it plays here as the sequencer would play it,
 * through the track's sound: its notes or hits, accent, QNT SEQ (not its chance, ratchet repeats or locks), for a 1/16
 * at the track's GATE (seq_tick lets it go, stopped too). A SLIDE or TIE after it does not hold it. Nothing is recorded:
 * the step is only read */
static volatile uint16_t aud_req;
static __attribute__((noinline)) void seq_audition(void)
{
    uint32_t r = aud_req, i = (r & 0xFFu) - 1u, idx = r >> 8;
    track_t *t;
    uint16_t at;
    aud_req = 0;
    if (song.playing || cin_left || i >= NTRK || idx >= NSTEP)
        return;
    t = &trk[i];
    at = t->seq_idx;
    t->seq_idx = (uint16_t)idx;
    seq_step(t, &t->step[idx], idx, div_samples(2), SEQ_ROLLED);
    t->seq_idx = at;
    t->seq_hold = 0;
    t->rat_left = 0;
}

/* RATCH: the next part of the playing step once the sequencer is that far into it (seq_step played the first).
 * The step is read again: an edit to fewer parts (or another source in a song) ends the repeats */
static __attribute__((noinline)) void seq_ratchet(track_t *t, uint32_t period)
{
    const step_t *s = &seq_steps(t)[t->seq_idx];
    uint32_t hits = step_ratchet(s);
    if (t->rat_left >= hits) {
        t->rat_left = 0;
        return;
    }
    if (t->seq_pos < (hits - t->rat_left) * (step_samples(t, period, t->seq_idx) / hits))
        return;
    t->rat_left--;
    seq_step(t, s, t->seq_idx, period, SEQ_REP);
}

/* the nudge of step s in 1/NUDGE_DIV of the step (NUDGE, core.h) when it plays off its start: the track's QUANTIZE OFF,
 * a NOTE step that plays something, x1 (a ratcheted step's parts divide the step: on its start); else 0 */
static int32_t seq_nudge(const track_t *t, const step_t *s)
{
    if (t->p[P_SQNT] || s->time != ST_NOTE || (!s->n && !s->hit) || step_ratchet(s) != 1u)
        return 0;
    return step_nudge(s);
}

/* 1.5.6 (#213): the matrix's TIME on step idx: how late it plays (samples, 0: on time). A NOTE step that plays
 * something, x1 (a ratcheted step's parts divide the step, as NUDGE); its VEL and first note are the sources' VEL
 * and KEY (mod.c mod_time). Not inlined: once a step, off the audio ISR's loop */
static __attribute__((noinline)) uint32_t seq_time(track_t *t, uint32_t idx, uint32_t period)
{
    const step_t *s = &seq_steps(t)[idx];
    uint32_t vel = (s->flags & SF_ACCENT) ? 127u : (s->vel ? s->vel : 96u);
    if (s->time != ST_NOTE || (!s->n && !s->hit) || step_ratchet(s) != 1u)
        return 0;
    return mod_time(t, s->n ? s->note[0] : DRUM_LANE_NOTE[__builtin_ctz(s->hit) & (NLANE - 1u)], vel, period);
}

/* the automation a track plays: its slot's while a song plays (song_chain.c lanes; 0: a silent lane, none) */
#define seq_motion_source(t) (&motion)

/* step idx plays: its chance (the one roll, as seq_step made it: a step that does not play applies no lock), the
 * automation and the locks before the notes (so a note-on reads them: eng_drum's KIT, ..), the notes live recording
 * already sounds left out (rskip), then its notes. On its start, or (NUDGE) at its start + its nudge */
static __attribute__((noinline)) void seq_play(track_t *t, uint32_t idx, uint32_t period)
{
    const step_t *s = &seq_steps(t)[idx];
    const motion_store_t *m = seq_motion_source(t);
    uint32_t skip = SEQ_ROLLED, i, k;
    if (seq_miss(t, s, idx))
        skip = SEQ_MISS;
    if (m)
        motion_step(t, idx, m, skip == SEQ_ROLLED);
    if (t->rskip_n && t->rskip_idx == idx) {
        ext_cfg_t ec = ext_cfg(t);
        uint32_t ex = ext_is_on(t, &ec);            /* CHORD EXT: the note that would sound is the pool tone, not the stored one (seq_step) */
        int32_t qtrn = ex && t->p[P_QUANT] == QN_SEQT ? t->p[P_TRANS] : 0;
        for (k = 0; k < t->rskip_n; k++) {
            for (i = 0; i < s->n; i++) {
                int32_t y = ex ? ext_map(t, &ec, clamp((int32_t)s->note[i] + qtrn, 0, 127)) : (int32_t)s->note[i];
                if (y == (int32_t)t->rskip[k])
                    skip |= 1u << i;
            }
            for (i = 0; i < NLANE; i++)
                if (((s->hit >> i) & 1u) && DRUM_LANE_NOTE[i] == t->rskip[k])
                    skip |= 1u << (8u + i);
        }
        t->rskip_n = 0;
    }
    seq_step(t, s, idx, period, skip);
}

/* QUANTIZE ON: step seq_idx plays on its start, or (1.5.6, #213) late by the matrix's TIME (not inlined, as seq_play) */
static __attribute__((noinline)) void seq_play_on(track_t *t, uint32_t period)
{
    uint32_t h = seq_time(t, t->seq_idx, period);
    if (h)
        t->nd_late = h + 1u;
    else
        seq_play(t, t->seq_idx, period);
}

/* NUDGE (1.2, #162; QUANTIZE OFF): a step plays at its start + nudge x DIV / 16. When a step starts its own late play
 * (nd_late) and the next step's early one (nd_early: that much before the end of this one) are latched; an early
 * play marks the step (nd_fired), whose start then plays nothing. A late play falls before the next start (at most
 * 7/16 of the step, the shortest swung step is 0.6 of it); an early one never before the late one of the step before.
 * Not across the end of a song row's pattern (the next row's pattern is not there yet): such a step plays on its
 * start. QUANTIZE ON (the default), or every nudge 0 (every older pattern): each step plays on its start, as before.
 * seq_nd_due: before step seq_idx's end is checked, the latched plays due by now (seq_pos): this step's late one, then
 * the next step's early one (not inlined: off the audio ISR's loop, and only called with one latched) */
static __attribute__((noinline)) void seq_nd_due(track_t *t, uint32_t period, uint32_t len, uint32_t cur_len, uint32_t n)
{
    if (t->nd_late != ND_NONE && (t->seq_pos >= t->nd_late - 1u || t->seq_pos >= cur_len)) {
        t->nd_late = ND_NONE;                       /* (also when a shorter DIV / LEN left it past the end) */
        seq_play(t, t->seq_idx, period);
    }
    if (t->nd_early != ND_NONE && t->seq_pos >= t->nd_early - 1u && t->seq_pos != 0x7FFFFFFFu + n) {
        uint32_t nx = (t->seq_idx + 1u) % len;
        t->nd_early = ND_NONE;
        t->nd_fired = (uint8_t)(nx + 1u);
        seq_play(t, nx, period);
    }
}

/* NUDGE: step seq_idx has started: it plays now (or played early: nd_fired), or its late play is latched; and the
 * next step's early play (not inlined, as seq_nd_due) */
static __attribute__((noinline)) void seq_nd_start(track_t *t, uint32_t period, uint32_t len)
{
    uint32_t nx = (t->seq_idx + 1u) % len;
    int32_t d;
    t->nd_early = ND_NONE;
    if (t->nd_fired == t->seq_idx + 1u) {
        ;                                           /* (it played early) */
    } else {                                        /* late by its NUDGE and (1.5.6) the matrix's TIME */
        uint32_t h = seq_time(t, t->seq_idx, period);
        d = seq_nudge(t, &seq_steps(t)[t->seq_idx]);
        if (d > 0 || h)
            t->nd_late = (uint32_t)(d > 0 ? d : 0) * period / NUDGE_DIV + h + 1u;
        else
            seq_play(t, t->seq_idx, period);
    }
    t->nd_fired = 0;
    if ((!0u || nx) && (d = seq_nudge(t, &seq_steps(t)[nx])) < 0) {
        uint32_t at = step_samples(t, period, t->seq_idx), back = (uint32_t)-d * period / NUDGE_DIV;
        at = (at > back ? at - back : 0u) + 1u;
        t->nd_early = at < t->nd_late ? t->nd_late : at;   /* (never before this step's own late play) */
    }
}

/* step seq_idx starts (seq_tick; top: PLAY's or a SONG section's first): a loop's first counts it (seq_cond_miss), a
 * recorded note held ties into it (not inlined: once a step, off the audio ISR's loop) */
static __attribute__((noinline)) void seq_enter(track_t *t, uint32_t top, uint32_t len)
{
    if (!t->seq_idx)
        t->cond_loop = (uint8_t)(top || t->cond_loop + 1u >= COND_LOOPS ? 0u : t->cond_loop + 1u);
    rec_hold(t, t->seq_idx, len);
}

static void seq_tick(track_t *t, uint32_t n)
{
    uint32_t period, len, top;
#if FELUCCA_PAIR_MORPH
    if (pair_follower(t)) return;
#endif

    if (song.g[G_CLOCK])
        n = midi_grid_advance(&midi_seq_grid[trk_index(t)], n, (uint32_t)t->p[P_SDIV]);
    if (t->seq_n && !t->seq_hold) {
        if (t->seq_off <= n)
            seq_release(t);
        else
            t->seq_off -= n;
    }
    if (!song.playing)
        return;
    period = div_samples((uint32_t)t->p[P_SDIV]);
    len = seq_loop_len(t);
    t->seq_pos += n;
    for (;;) {
        uint32_t cur_len = step_samples(t, period, t->seq_idx);
        if (t->nd_late | t->nd_early)
            seq_nd_due(t, period, len, cur_len, n);
        if (t->seq_pos < cur_len && t->seq_pos != 0x7FFFFFFFu + n)
            break;
        if (t->seq_pos < 0x7FFFFFFFu)
            motion_fx_tick(t, seq_motion_source(t), cur_len); /* include the old step's tail before wrapping */
        top = t->seq_pos >= 0x7FFFFFFFu;
        t->seq_pos = t->seq_pos >= 0x7FFFFFFFu ? ((0u | LAUNCH_STATE.live_applied) ? LAUNCH_STATE.carry : 0u) : t->seq_pos - cur_len;
        t->seq_idx = (uint16_t)((t->seq_idx + 1u) % len);
        if (!t->seq_idx && seq_extend_end[trk_index(t)]) {
            seq_extend_end[trk_index(t)] = seq_extend_target[trk_index(t)] = 0;
            len = seq_loop_len(t);
        }
        seq_enter(t, top, len);
        if (t->p[P_SQNT] && !t->nd_fired)
            seq_play_on(t, period);                 /* QUANTIZE ON: every step on its start, as before 1.2 */
        else
            seq_nd_start(t, period, len);
        motion_fx_step(t, seq_motion_source(t));
    }
    motion_fx_tick(t, seq_motion_source(t), step_samples(t, period, t->seq_idx));
    if (t->rat_left)
        seq_ratchet(t, period);
}

/* MIDI in: the track a channel plays (0..15): G_ROUTE CH1-4 (0) channels 1..4 their parts (5..16 never get
 * here: midi_event drops them), SEL (1) every channel the selected track; CH5-8 .. CH13-16 (2..4) as CH1-4 on
 * their four channels (midi_base); TRACK (5, 1.5.5) the first track set to the channel, else the first set to OMNI, else
 * none (dropped as a channel outside a block) */
static uint8_t midi_route;                 /* the G_ROUTE events_block last saw (a change to a block: midi_route_block;
                                            * MIDI_ROUTE_AGAIN: TRACK's channels changed, the same again) */
#define MIDI_ROUTE_AGAIN 0xFFu
static int32_t midi_slot(uint32_t ch)      /* the track channel ch plays, -1 none (and with SEL) */
{
    int32_t b = midi_base(), omni = -1;
    uint32_t i;
    if (b != -2)
        return b >= 0 && ch - (uint32_t)b < NPART ? (int32_t)(ch - (uint32_t)b) : -1;
    for (i = 0; i < NPART; i++) {
        uint32_t c = mch_get(i);
        if (c == ch)
            return (int32_t)i;
        if (c == MCH_OMNI && omni < 0)
            omni = (int32_t)i;
    }
    return omni;
}
static int midi_in_block(uint32_t ch) { return midi_slot(ch) >= 0; }   /* ch is heard by a track (never with SEL) */
static track_t *midi_track(uint32_t ch)
{
    int32_t k = midi_slot(ch);
#if FELUCCA_PAIR_MORPH
    return pair_owner(k >= 0 ? &trk[k] : TSEL);
#endif
#if !FELUCCA_PAIR_MORPH
    return k >= 0 ? &trk[k] : TSEL;
#endif
}

#include "midi_control.c"

/* RETRIG = HARM / BOTH, for what a track holds besides a CHRD BUS chord: its held notes follow the bar's chord and are sounded again.
 *   an EXT track: each owner's voicing is rebuilt from the pool of the new bar (ext_build, the key / MIDI source note as anchor);
 *   CHRD OFF with FOLLOW: the held single note is snapped again (harmony_snap) from its key;
 *   LATCH: a latched pitch no key holds moves the same way (its lat_stay bit goes old -> new, as retrigger_owners moves a BUS chord's).
 * Per owner (a key, a MIDI chord), from kb_src[k] / mchord.src, not through chord_last. An owner whose list does not change is left alone
 * (an unchanged pool is no retrigger); at most 8 owners, 12 latched pitches per trigger. The owner lists are the release identity: they
 * are rewritten, so a key-up / note-off still ends exactly what sounds. The ARP is off here (link_retrigger returns first). */
static uint32_t ret_new(track_t *t, const ext_cfg_t *ec, uint32_t ex, uint32_t src, uint8_t *out)
{
    if (ex)
        return ext_build(t, ec, src, out);
    out[0] = (uint8_t)harmony_snap(t, src);
    return 1;
}
static int ret_same(const uint8_t *a, uint32_t na, const uint8_t *b, uint32_t nb)
{
    uint32_t i;
    if (na != nb)
        return 0;
    for (i = 0; i < na; i++)
        if (a[i] != b[i])
            return 0;
    return 1;
}
#if !FELUCCA_FM4
#define RET_N 48u
_Static_assert(8u * CHORD_MAX + 12u <= RET_N, "retrigger owner note capacity");
static __attribute__((noinline)) void retrigger_follow(uint32_t i)
{
    track_t *t = &trk[i];
    struct { uint8_t kind, idx, no, nn, vel, old[CHORD_MAX], nw[CHORD_MAX]; } ow[8];
    uint8_t lp[12], ln[12], lv[12], ls[12], on[RET_N], offs[RET_N];                     /* (8 owners x CHORD_MAX + 12 latched pitches at most) */
    ext_cfg_t ec = ext_cfg(t);                                /* SOURCE / EXT / OCT once for the whole bar line */
    uint32_t ex = ext_is_on(t, &ec), no = 0, nl = 0, k, m, j, n, ch, note, non = 0, noff = 0;
    int32_t oct = clamp((int32_t)ec.oct, -2, 2);
    for (k = 0; k < 27u && no < 8u; k++) {                    /* keys */
        uint8_t nw[CHORD_MAX];
        if (!kb_chn[k] || !kb_live[k] || kb_trk[k] != i)
            continue;
        if (lat_get(lat_eat[i], kb_chord[k][0]))             /* a LATCH STACK toggle press: it ended the latched notes and sounds nothing */
            continue;
        n = ret_new(t, &ec, ex, kb_src[k], nw);
        if (ret_same(kb_chord[k], kb_chn[k], nw, n))
            continue;
        ow[no].kind = 0; ow[no].idx = (uint8_t)k; ow[no].no = kb_chn[k]; ow[no].nn = (uint8_t)n; ow[no].vel = lat_vel[i][kb_chord[k][0] & 127u];
        memcpy(ow[no].old, kb_chord[k], CHORD_MAX); memcpy(ow[no].nw, nw, CHORD_MAX);
        no++;
    }
    for (m = 0; m < MCHORD_N && no < 8u; m++) {               /* MIDI notes that play a chord / a mapped note */
        mchord_t *c = &mchord[m];
        uint8_t nw[CHORD_MAX];
        if (c->id != i + 1u || !c->n)
            continue;
        if (lat_get(lat_eat[i], c->note[0]))
            continue;
        n = ret_new(t, &ec, ex, c->src, nw);
        if (ret_same(c->note, c->n, nw, n))
            continue;
        ow[no].kind = 1; ow[no].idx = (uint8_t)m; ow[no].no = c->n; ow[no].nn = (uint8_t)n; ow[no].vel = lat_vel[i][c->note[0] & 127u];
        memcpy(ow[no].old, c->note, CHORD_MAX); memcpy(ow[no].nw, nw, CHORD_MAX);
        no++;
    }
    for (ch = 0; midi_owners[i] && ch < 16u && no < 8u; ch++) {   /* MIDI notes played as they came (no mchord entry): one now, if there is room (no MIDI owner: no scan) */
        if (!midi_ch[ch].owned[i])
            continue;
        for (note = 0; note < 128u && no < 8u; note++) {
            uint8_t nw[CHORD_MAX];
            if ((midi_note_get(ch, note) & 0x7Fu) != i + 1u || mchord_of(ch, note, i + 1u))
                continue;
            if (lat_get(lat_eat[i], note))                    /* a LATCH STACK toggle press: it ended the latched notes and sounds nothing (as the key and mchord loops) */
                continue;
            n = ret_new(t, &ec, ex, note, nw);
            if (n == 1u && nw[0] == note)
                continue;
            for (m = 0; m < MCHORD_N && mchord[m].id; m++)
                ;
            if (m == MCHORD_N)
                continue;
            mchord[m].id = (uint8_t)(i + 1u); mchord[m].ch = (uint8_t)ch; mchord[m].src = (uint8_t)note;
            mchord[m].n = 1; mchord[m].note[0] = (uint8_t)note;
            ow[no].kind = 1; ow[no].idx = (uint8_t)m; ow[no].no = 1; ow[no].nn = (uint8_t)n; ow[no].vel = lat_vel[i][note];
            memset(ow[no].old, 0, CHORD_MAX); ow[no].old[0] = (uint8_t)note; memcpy(ow[no].nw, nw, CHORD_MAX);
            no++;
        }
    }
    for (j = 0; (lat_stay[i][0] | lat_stay[i][1] | lat_stay[i][2] | lat_stay[i][3]) && j < 128u && nl < 12u; j++) {   /* latched pitches no key / note holds (nothing latched: no scan) */
        int32_t y;
        if (!lat_get(lat_stay[i], j) || midi_local_held(t, j) || midi_note_held(t, j) || mchord_held(i + 1u, j))
            continue;
        /* For LATCH EXT, always map the FIRST pitch the user latched,
         * not the previous bar's already-reharmonised output. This is
         * the missing fixed source identity that causes downward drift. */
        uint32_t anchor = lat_src[i][j];
        y = ex ? ext_map(t, &ec, clamp((int32_t)anchor - 12 * oct, 0, 127)) :
                 (int32_t)harmony_snap(t, anchor);
        if (y < 0 || y == (int32_t)j)
            continue;
        lp[nl] = (uint8_t)j; ln[nl] = (uint8_t)y; lv[nl] = lat_vel[i][j] ? lat_vel[i][j] : 100u;
        ls[nl] = (uint8_t)anchor;
        nl++;
    }
    for (k = 0; k < no; k++) {                                /* rewrite the owners first: they are the release identity */
        for (j = 0; j < CHORD_MAX; j++) {
            if (ow[k].kind == 0) kb_chord[ow[k].idx][j] = ow[k].nw[j]; else mchord[ow[k].idx].note[j] = ow[k].nw[j];
        }
        if (ow[k].kind == 0) kb_chn[ow[k].idx] = ow[k].nn; else mchord[ow[k].idx].n = ow[k].nn;
    }
    for (k = 0; k < nl; k++) {
        lat_put(lat_stay[i], lp[k], 0);
        lat_vel[i][lp[k]] = 0;
        lat_src[i][lp[k]] = 0;
        lat_put(lat_eat[i], lp[k], 0);
    }
    for (k = 0; k < nl; k++) {
        lat_put(lat_stay[i], ln[k], 1);
        lat_put(lat_eat[i], ln[k], 0);
        lat_vel[i][ln[k]] = lv[k];
        lat_src[i][ln[k]] = ls[k]; /* carry original pitch, never relatch the output */
    }
    for (k = 0; k < no; k++) {
        for (j = 0; j < ow[k].no && noff < RET_N; j++)
            offs[noff++] = ow[k].old[j];
        for (j = 0; j < ow[k].nn; j++) {
            lat_put(lat_eat[i], ow[k].nw[j], 0);              /* (a stale 'this press ended it' mark would swallow a later NoteOff) */
            lat_vel[i][ow[k].nw[j] & 127u] = ow[k].vel;       /* the voicing keeps the dynamics it was pressed with (0: sounded as 100) */
            if (non < RET_N)
                on[non++] = ow[k].nw[j];
        }
        for (j = 0; j < ow[k].no; j++)
            lat_put(lat_eat[i], ow[k].old[j], 0);
    }
    for (k = 0; k < nl; k++) {
        if (noff < RET_N) offs[noff++] = lp[k];
        if (non < RET_N) on[non++] = ln[k];
    }
    for (k = 0; k < noff; k++)                                /* what no owner, key, note or latch holds any more ends */
        if (!chord_note_held(i, offs[k])
#if CARAVEL_UX_CAPTURE
            && !cap_note_held(t, offs[k])                    /* a loop keeps its mapped pitch until its recorded note-off */
#endif
        )
            trk_note_off(t, offs[k]);
    for (k = 0; k < non; k++) {
        uint32_t vel = lat_vel[i][on[k]] ? lat_vel[i][on[k]] : 100u;
        for (j = 0; j < k && on[j] != on[k]; j++)
            ;
        if (j == k)
            trk_note_on(t, on[k], vel);
    }
}
#else
static void retrigger_follow(uint32_t i) { (void)i; }   /* (FM4: the ids are operator values: no CHORD EXT) */
#endif
/* Resync is a phase change, not a new transport: preserve SONG, live launches,
 * held chords, live FX and the sound/automation data. Live recording and SONG
 * are refused by the caller, including if either starts after the request. */
static __attribute__((noinline)) void seq_resync(void)
{
    midi_grid_reset();
    memset(seq_extend_end, 0, sizeof seq_extend_end);
    memset(seq_extend_target, 0, sizeof seq_extend_target);
    motion_begin();
    for (uint32_t i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        seq_release(t);
        if (t->arp_gate) arp_silence(t);
        t->arp_pos = 0xFFFFFFFu;
        t->arp_idx = 0xFFFFFFFFu;
        t->arp_off = t->arp_walk = 0;
        t->seq_idx = (uint16_t)(t->p[P_SLEN] - 1);
        t->seq_pos = 0x7FFFFFFFu;
        t->rskip_n = t->rh_n = t->rat_left = 0;
        t->nd_late = t->nd_early = ND_NONE;
        t->nd_fired = 0;
        if (t->p[P_LTRIG] && t->p[P_LSYNC])
            t->lfo_ph = (uint32_t)t->p[P_LPHASE] << 25;
        lfo2_trigger(t, 1);
        /* Enter step zero now: subsequent queued clocks must advance the new
         * pass rather than be discarded by the sequencer's start sentinel. */
        seq_tick(t, 0);
        arp_step(t, 0, 0);
    }
    song.tick = 0;
    arp_bar_last = HARM_BAR();
    beat_pos = beat_n = clk_step = 0;
    clk_pos = 0;
    if (click_wanted()) click_req = 2;              /* retain queued-clock progress after the downbeat */
    slicer_start();
    perf_start();
}

#include "midi_clock.c"

/* the count-in: its first beat now (accented) */
static __attribute__((noinline)) void cin_begin(void)
{
    cin_total = cin_left = (uint8_t)(4u * cin_bars);
    cin_pos = 0;
    memset(cin_n, 0, sizeof cin_n);
    click_req = 2;
}
/* n samples on: a beat ends; the last one starts the sequencer (in this block, before seq_tick: step 0 with it) */
static __attribute__((noinline)) void cin_block(uint32_t n)
{
    uint32_t b = click_beat_len();
    cin_pos += n;
    if (cin_pos < b)
        return;
    cin_pos -= b;
    cin_pos = cin_pos < b ? cin_pos : 0u;
    if (--cin_left) {
        click_req = (uint8_t)((cin_total - cin_left) % 4u ? 1u : 2u);
        return;
    }
    seq_start();
    cin_flush = 1;
}
/* the count-in's kept notes onto step 1, which has just started (events_block, after seq_tick): as if played now */
static __attribute__((noinline)) void cin_record(void)
{
    uint32_t i, k;
    cin_flush = 0;
    for (i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        for (k = 0; k < cin_n[i]; k++)
            if (rec_on(t)) {
                rec_note(t, cin_note[i][k], cin_vel[i][k]);
                if ((cin_up[i] >> k) & 1u)
                    rec_release(t, cin_note[i][k]);
            }
        cin_n[i] = 0;
    }
}
/* the metronome's beat: adv samples on while the transport runs (click.c sounds it in this block) */
static void click_tick(uint32_t adv)
{
    if (song.g[G_CLOCK]) adv = midi_grid_advance(&midi_click_grid, adv, 2u);
    uint32_t p = div_samples(2), beat = 0;
    if (clk_pos == CLK_START) {
        clk_pos = 0;
        clk_step = 0;
        beat = 2;
    } else {
        clk_pos += adv;
        while (clk_pos >= p) {                      /* (as seq_tick: the remainder kept) */
            clk_pos -= p;
            clk_step = (clk_step + 1u) & 15u;
            if (!(clk_step & 3u))
                beat = clk_step ? 1u : 2u;
        }
    }
    if (beat && click_wanted())
        click_req = (uint8_t)beat;
}
/* the beat of the bar the click is on (0..3: 0 the accented first), -1 stopped: the count-in's, else the playing
 * transport's (clk_step, internal or external clock). It moves in the block a beat clicks in (the header's metronome,
 * ui_draw.c, swings on it; CLICK OFF it moves all the same) */
static int32_t click_beat_now(void)
{
    if (cin_left)
        return (int32_t)((uint32_t)(cin_total - cin_left) % 4u);
    if (!song.playing)
        return -1;
    return clk_pos == CLK_START ? 0 : (int32_t)(clk_step >> 2);
}

/* Rare FULL launch only. Sound decoding and validation ran in the main loop.
 * Let old voices fade using the existing engine-switch path; new step notes
 * wait in xp_note until that short fade finishes. No second synth runs. */
static __attribute__((noinline)) void project_sound_apply(void)
{
    for (uint32_t k = 0; k < NTRK; k++) {
        track_t *t = &trk[k];
        uint32_t active = 0;
        seq_release(t);
        midi_forget_track(k);
        arp_silence(t);
        trk_all_off(t);
        latch_forget(k);
        chord_panic(k);
        chord_live_sync(k);
        for (uint32_t i = 0; i < NVOICE; i++) active |= t->v[i].active;
        t->nheld = t->arp_phys = 0;
        arp_forget(t);
        t->user = 0;
        t->preset = live_sound.preset[k];
        t->eng_req = LAUNCH_STATE.live_engine[k];
        memcpy(t->p, live_sound.p[k], sizeof t->p);
        lfo2_load(k, &live_sound.lfo2[k]);
        if (active) { t->xf_on = 1; t->xf = XF_BLOCKS; }
    }
    /* A live part does not replace the master clock or the MIDI setup. */
    for (uint32_t i = G_DTIME; i <= G_CDEPTH; i++) song.g[i] = live_sound.g[i];
    song.g[G_TUNE] = live_sound.g[G_TUNE];
    song.g[G_RTYPE] = live_sound.g[G_RTYPE];
    chordext_reset_runtime();                           /* (CHORD SOURCE / EXT follow the slot; the remembered chord does not: slice 1b) */
}
static __attribute__((noinline)) int project_pattern_engines_ok(void)
{
    if (LAUNCH_STATE.live_full) return 1;
    for (uint32_t k = 0; k < NTRK; k++)
        if (LAUNCH_STATE.live_engine[k] != trk[k].eng_req) return 0;
    return 1;
}

/* everything that happens between two rendered blocks */
/* Pattern launch uses the same overshoot handling as SONG, but copies into
 * the editable working tracks. All four restart together at track 1's end.
 * Audio ISR only: no flash access, allocation, decoding or factory-patch search. */
static __attribute__((noinline)) void project_pattern_tick(uint32_t n)
{
    track_t *clock = &trk[0];
    uint32_t length, k, slot = LAUNCH_STATE.live_pending;
    if (!slot || !n || !song.playing || 0u || 0u ||
        clock->seq_pos >= 0x7FFFFFFFu || clock->seq_idx + 1u != seq_loop_len(clock)) return;
    length = step_samples(clock, div_samples((uint32_t)clock->p[P_SDIV]), clock->seq_idx);
    if (clock->seq_pos + n < length) return;
    if (!project_pattern_engines_ok()) {
        LAUNCH_STATE.live_pending = 0;
        LAUNCH_STATE.live_notice = 5;          /* engine changed after queuing: refuse unsafe automation */
        return;
    }
    LAUNCH_STATE.carry = clock->seq_pos + n - length; /* SONG is idle; reuse its boundary overshoot */
    motion_fx_close();
    motion_end();
    if (LAUNCH_STATE.live_full) project_sound_apply();
    song.rec = 0;                       /* a queued launch must not record into the new pattern */
    step_record_mask = 0;
    for (k = 0; k < NTRK; k++) {
        track_t *t = &trk[k];
        seq_extend_end[k] = seq_extend_target[k] = 0;
        seq_release(t);                 /* releases old tied notes, including MIDI note-offs */
        memcpy(t->step, LAUNCH_PATTERN.step[k], sizeof t->step);
        memcpy(&t->p[P_SLEN], LAUNCH_PATTERN.timing[k], sizeof LAUNCH_PATTERN.timing[k]);
        t->p[P_SQNT] = LAUNCH_PATTERN.qnt[k];
        t->seq_idx = (uint16_t)(t->p[P_SLEN] - 1);
        t->seq_pos = 0x7FFFFFFFu;
        t->rh_n = t->rskip_n = t->rat_left = 0;
        t->nd_late = t->nd_early = ND_NONE;
        t->nd_fired = 0;
    }
    motion = LAUNCH_PATTERN.motion;
    motion_begin();
    LAUNCH_STATE.live_applied = 1;
    LAUNCH_STATE.live_notice = (uint8_t)slot;
    LAUNCH_STATE.live_pending = 0;
}

static void events_block(uint32_t n)
{
    uint32_t i, pr, lr, lq, seq_n = n;
    voice_policy_sync();
#if FELUCCA_PAIR_MORPH
    pair_validate();
    panic_req |= pair_cleanup_pending; pair_cleanup_pending = 0;
#endif
    uint32_t clock_mode = (uint32_t)song.g[G_CLOCK];
    if (midi_clock.mode != clock_mode) {
        seq_stop();
        memset(&midi_clock, 0, sizeof midi_clock);
        midi_clock.mode = (uint8_t)clock_mode;
        midi_beat_samples = 0;
    }
    if (cin_left && !clock_mode)
        cin_block(n);
    if (transport_req == 1u) {
        if (clock_mode) {
            uint8_t valid = midi_clock.bar_valid && midi_clock.tempo_valid && fm1_ms - midi_clock.last_ms <= 500u;
            uint8_t tick = midi_clock.bar_tick;
            midi_clock_transport(0xFAu, fm1_ms);
            midi_clock.bar_valid = valid;            /* local PLAY cannot establish a master downbeat */
            midi_clock.bar_tick = tick;
        } else if (cin_left)
            ;                                       /* counting in already (the UI's PLAY stops it: seq_counting) */
        else if (cin_bars && (song.rec & ~step_record_mask) && !song.playing && !0u)
            cin_begin();                            /* recording from stop: the count-in first */
        else
            seq_start();
        transport_req = 0;
    } else if (transport_req == 2u) {
        seq_stop();
        transport_req = 0;
    } else if (transport_req == 3u) {                 /* GLO + PLAY: from the top without stopping (INT clock) */
        if (!clock_mode) {
            seq_stop();
            seq_start();
        }
        transport_req = 0;
    }
    if (transport_req >= 4u || midi_clock.resync)
        midi_resync_poll();
    if (midi_route != (uint8_t)song.g[G_ROUTE]) {     /* ROUT changed: a block lets go of the other channels */
        ext_midi_clear_all();
        midi_route = (uint8_t)song.g[G_ROUTE];
        if (midi_route != ROUTE_SEL)
            midi_route_block();
    }
    pr = panic_req;
#if FELUCCA_PAIR_MORPH
    if (ep.on && (pr & ((1u << ep.a) | (1u << ep.b)))) pr |= (1u << ep.a) | (1u << ep.b);
#endif

    panic_req = 0;
    lr = latch_req;
#if FELUCCA_PAIR_MORPH
    if (ep.on && (lr & ((1u << ep.a) | (1u << ep.b)))) lr |= 1u << ep.a;
#endif

    latch_req = 0;
    lq = link_retrig_req;
    link_retrig_req = 0;
    if (midi_in_overflow) {                            /* a lost note-off must never leave a held note */
        midi_resync_cancel();
        midi_clock.bar_valid = 0;                    /* lost clocks also lose the counted bar */
        mi_r = mi_w;
        memset(midi_sel_on, 0, sizeof midi_sel_on);
        memset(midi_ch, 0, sizeof midi_ch);
        memset(midi_owners, 0, sizeof midi_owners);
        ext_midi_clear_all();
        memset(mchord, 0, sizeof mchord);
        midi_hint = 0;
        for (i = 0; i < NTRK; i++) {
            trk[i].rh_n = trk[i].rskip_n = 0;
            trk[i].seq_n = trk[i].seq_hold = trk[i].slide_glide = trk[i].rat_left = 0;
        }
        pr |= (1u << NTRK) - 1u;
        RING_PUBLISH();
        midi_in_overflow = 0;
    }
    for (i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        if ((pr >> i) & 1u) {
            midi_forget_track(i);
            trk_all_off(t);
            t->nheld = 0;
            t->arp_phys = 0;
            arp_forget(t);
            latch_forget(i);
            chord_panic(i);
            chord_live_sync(i);
        }
        engine_block(t);                              /* engine switch: fade, then switch (voice.c) */
        if ((lq >> i) & 1u)
            link_retrigger(i);                        /* LINK RETRIG after a key change (asked by key_link_sync in the UI) */
        if ((lr >> i) & 1u) {                         /* OCT- + OCT+: let go of everything latched */
            latch_free(t);
            if (arp_hold(t) && t->nheld) {
                t->nheld = 0;
                if (t->arp_gate)
                    arp_silence(t);
            }
        }
        /* ARP turned off, or HOLD / LATCH released with no key down: drop the latched chord */
        if ((t->armp && !t->p[P_AMODE]) || (t->aholdp && !arp_hold(t) && !t->arp_phys)) {
            t->nheld = 0;
            if (!t->p[P_AMODE])
                t->arp_phys = 0;
            if (t->arp_gate)
                arp_silence(t);
        }
        if ((lat_any(lat_stay[i]) || lat_any(lat_bus_other[i]) || lat_bus_last[i]) &&
            (t->p[P_AMODE] || latch_mode(t) == LT_OFF))
            latch_free(t);                            /* LATCH turned off, or ARP on: the latched notes end */
        t->armp = t->p[P_AMODE];
        t->aholdp = arp_hold(t);
    }
    ext_source_tick();
    keyboard_block();
    motion_fx_sync();
    while (mi_r != mi_w) {                            /* USB-MIDI (and TRS) in */
        uint32_t at = mi_r % MQ, pkt = midi_in_q[at], status = (pkt >> 8) & 0xFFu;
        uint32_t st = status & 0xF0u, ch = status & 0x0Fu;
        uint32_t d1 = (pkt >> 16) & 0x7Fu, d2 = (pkt >> 24) & 0x7Fu;
        uint32_t source = midi_in_source[at] ? midi_in_source[at] : 1u, ms = midi_in_ms[at];
        mi_r++;
        if (status >= 0xF8u) {
            if (clock_mode == source) {
                if (status == 0xF8u)
                    midi_clock_pulse(ms);
                else
                    midi_clock_transport(status, ms);
            }
        } else
            midi_event_source(st, ch, d1, d2, source);
    }
    if (clock_mode) {
        seq_n = 0;
        if (song.playing) {
            uint32_t last = midi_clock.have_pulse ? midi_clock.last_ms : midi_clock.start_ms;
            if (fm1_ms - last > 500u) {
                seq_stop();                         /* cable loss must not leave a running held note */
                midi_clock.bar_valid = 0;
                midi_clock.tempo_valid = 0;
            } else
                seq_n = midi_clock_advance(fm1_ms);
        }
    }
    cap_idle();                       /* transport pause/resume in the note-owning audio context */
    /* The beat's share of this block, advanced once (the ARP LED and the bar reset below use it). */
    uint32_t beat_n_samples = clock_mode ? midi_grid_advance(&midi_beat_grid, seq_n, 0u) : n;
#if CARAVEL_ACTION_BANKS
    if(!harmony_on){
        if(harmony_command||harmony_pending||harmony_hold||harmony_shift||harmony_shift_pending||harmony_shift_dirty)harmony_perf_clear();
    }
    else {
        uint8_t cmd=harmony_command,shift_dirty=harmony_shift_dirty;
        harmony_command=H_NONE;harmony_shift_dirty=0;
        if(shift_dirty)harmony_shift_pending=1;
        if(cmd==H_HOLD){
            if(harmony_hold){harmony_pending=harmony_pending==H_RESUME?H_NONE:H_RESUME;}
            else {harmony_hold=1;harmony_pending=H_NONE;}
        }else if(cmd==H_LONG){                                   /* the countdown up: one more bar; past 16: HOLD (infinity) */
            if(!harmony_hold){if(harmony_extra<16u)harmony_extra++;else harmony_hold=1;}
            cmd=H_NONE;
        }else if(cmd==H_SHORT){                                  /* down: from HOLD to 16, then the extra bars, then the chord's own bars (at least 1 stays) */
            if(harmony_hold){harmony_hold=0;harmony_extra=16;}
            else if(harmony_extra)harmony_extra--;
            else if(song.playing){
                uint32_t total=0,i,idx=harmony_chord_at(harmony_bar),left;
                for(i=0;i<4u;i++)total+=1u<<hdur_get(i);
                left=harmony_chord_start(idx)+(1u<<hdur_get(idx))-harmony_bar%total;
                if(left>=2u)harmony_base_bar=(harmony_base_bar-1u)&0xFFFFu;
            }
            cmd=H_NONE;
        }else if(cmd)harmony_pending=cmd;
        if(!song.playing && (cmd||shift_dirty)){uint8_t keep=cmd?H_NONE:harmony_pending;harmony_pending=cmd?harmony_pending:H_NONE;harmony_perf_apply(HARM_BAR());if(keep)harmony_pending=keep;}   /* a SHIFT edit while stopped leaves a queued PREV / NEXT / RESET queued */
    }
#endif
    if (bar_reset_req) {
        /* Stopped: reset at once. Playing: at the first bar line that falls in this block. A whole-block
         * quantisation, as the external resync is; seq_resync enters step 0 before the ordinary step clocks. */
        if (!song.playing) {
            /* Stopped: PLAY starts every track at step 0 anyway. Only put the beat display back; no seq_resync,
             * whose arp step could sound a held chord while the transport is stopped. */
            bar_reset_req = 0;
            harmony_perf_clear();
            harmony_base_bar = HARM_BAR();
            harmony_bar = 0;
            beat_pos = beat_n = 0;
        } else if (beat_n == 3u && beat_pos + beat_n_samples >= beat_samples()) {
            bar_reset_req = 0;
            harmony_perf_clear();
            harmony_phase = (uint16_t)perf_bars_q16;   /* round 7: this bar line IS a bar line for HARMONY */
            harmony_base_bar = HARM_BAR();
            harmony_bar = 0;
            seq_resync();
        }
    }
    if (song.playing && seq_n) {
        uint32_t bar = 4u * (clock_mode ? MIDI_CLOCK_GRID : beat_samples()), num = (seq_n << 16) + perf_bars_rem;
        uint32_t hb = harmony_bar, old_chord = harmony_chord_at(hb), prev_bar=HARM_BAR();
        perf_bars_q16 += num / bar;
        perf_bars_rem = num % bar;
        uint32_t boundary=HARM_BAR()!=prev_bar;
        uint16_t old_mask=boundary&&harmony_on?harmony_mask_bar(hb):0;
#if CARAVEL_ACTION_BANKS
        if(harmony_hold)harmony_base_bar=(harmony_base_bar+HARM_BAR()-prev_bar)&0xFFFFu;
#endif
        harmony_bar = (HARM_BAR() - harmony_base_bar) & 0xFFFFu;   /* (the bar count is 16 bits: the difference wraps with it) */
#if CARAVEL_ACTION_BANKS
        if(boundary&&harmony_extra&&!harmony_hold&&!harmony_pending&&harmony_chord_at(harmony_bar)!=old_chord){
            harmony_base_bar=(harmony_base_bar+1u)&0xFFFFu;harmony_bar=hb;harmony_extra--;harmony_rep++;   /* the chord would end: one more bar of it */
        }else if(boundary&&harmony_chord_at(harmony_bar)!=old_chord)harmony_rep=0;
        if(boundary){
            if(harmony_pending)harmony_bar=hb; /* a queued NEXT advances once, not once plus the natural change */
            harmony_perf_apply(HARM_BAR());
        }
#endif
        arp_bar_sync();
        if (boundary && harmony_on && (old_chord != harmony_chord_at(harmony_bar) || old_mask != harmony_mask_bar(harmony_bar)))
            for (i = 0; i < NTRK; i++)
                if ((link_retrig[i] & 1u) && (harmony_follow[i] || EXT_ON(&trk[i]))) {   /* (CHORD EXT overrides FOLLOW) */
                    ret_harm = 1;                     /* (the bar line asks: link_retrigger may rebuild an EXT voicing / a single note) */
                    link_retrigger(i);
                    ret_harm = 0;
                }
        cap_tick();                   /* notes on a bar line use the newly effective chord */
    }
    if (aud_req)
        seq_audition();                               /* (STEP PREVIEW: a step sounds, stopped) */
    project_pattern_tick(clock_mode ? midi_seq_preview(&trk[0], seq_n) : seq_n);
    for (i = 0; i < NTRK; i++)
        seq_tick(&trk[i], seq_n);
    LAUNCH_STATE.live_applied = 0;
    if (cin_flush)
        cin_record();
    if (song.playing)
        click_tick(seq_n);
    for (i = 0; i < NPART; i++) {
        uint32_t arp_n = clock_mode ? midi_grid_advance(&midi_arp_grid[i], seq_n, (uint32_t)trk[i].p[P_ARATE]) : n;
        arp_step(&trk[i], arp_n, clock_mode && song.playing ? arp_n : n);
    }
    beat_pos += beat_n_samples;                        /* ARP LED beat */
    slicer_follow(seq_n, n, clock_mode && song.playing);
    if (beat_pos >= beat_samples()) {
        beat_pos -= beat_samples();
        beat_pos = beat_pos < beat_samples() ? beat_pos : 0u;
        beat_n = (beat_n + 1u) & 3u;                  /* ARP LED beat only: HARMONY uses perf_bars_q16 */
    }
    if (song.playing)
        song.tick++;
}



