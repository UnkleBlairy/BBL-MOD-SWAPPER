/* SPDX-License-Identifier: GPL-3.0-only */
/* Shared HPM1 validation, capture and restore. Backends provide hp_io. */
static uint32_t hp_hash(const void*p,uint32_t n){const uint8_t*b=p;uint32_t h=2166136261u;while(n--){h^=*b++;h*=16777619u;}return h;}
static void hp_pair_capture(hp_pair_store_t*p)
{
 memset(p,0,sizeof*p);p->on=ep.on;p->a=ep.a;p->b=ep.b;p->motion=ep.motion;p->base=ep.base;
 for(uint32_t i=0;i<hp.events;i++)if(hp.event[i].control>=6&&ep.on&&hp.pair_valid){p->base=hp.pair_base;p->motion=hp.pair_motion;break;}
 memcpy(p->lane,ep.lane,sizeof p->lane);
 for(uint32_t t=0;t<NTRK;t++)for(uint32_t k=0;k<NMSLOT;k++)p->mod[t][k]=trk[t].p[P_M1DST+3*k]==MD_PAIR;
}
static int hp_ref_valid(hp_ref_t r)
{
#if CARAVEL_FORMAT2
 if(r.kind==HP_DX||r.kind==HP_FM6||(r.engine!=255u&&!eng_ok(r.engine)))return 0;
#endif
 if(!r.kind)return 1;if(r.track>=NTRK&&r.track!=255)return 0;
 if(r.kind==HP_TRACK)return r.aux<=1&&(r.aux?r.id<8&&r.engine<NENGINES:r.id<P_E0&&(r.engine==255||r.engine<NENGINES));
 if(r.kind==HP_GLOBAL)return r.id<=G_CDEPTH||r.id==G_RTYPE;
 if(r.kind==HP_PAIR||r.kind==HP_MACRO)return r.id<4;
 if(r.kind==HP_LFO2)return lfo2_target(r.id);

 return 0;
}
static int hp_model_valid(const hp_model_t*m)
{
 if(m->events>HP_EVENTS)return 0;
 for(uint32_t t=0;t<NTRK;t++){
  const hp_track_t*h=&m->track[t];if(h->pad[0]>UP_SLOTS)return 0;if(!h->count||h->count>HP_ROWS||h->active>=h->count)return 0;
  for(uint32_t row=0;row<HP_ROWS;row++)for(uint32_t k=0;k<4;k++)if(!hp_ref_valid(h->cell[row][k]))return 0;
  for(uint32_t c=0;c<4;c++){const hp_macro_t*a=&m->macro[t][c];if(a->base<0||a->base>127)return 0;for(uint32_t j=0;j<4;j++)if(!hp_ref_valid(a->route[j].ref)||a->route[j].amount< -64||a->route[j].amount>63)return 0;}
 }
 for(uint32_t i=0;i<m->events;i++){const hp_event_t*e=&m->event[i];if(e->track>=NTRK||e->step>=NSTEP||e->control>7||e->control==4||e->control==5||e->lock>1||e->value<0||e->value>127)return 0;}
 return 1;
}
#include "home_store_snapshots.h"
static int hp_capsule_ok(const hp_store_t*p)
{
 if(CARAVEL_FORMAT2 && p->version!=6u)return 0;
 if(p->magic!=HP_MAGIC||p->reserved[0]!=hp_hash(p,20))return 0;
#if HP_SNAPSHOT_STORE
 if(p->version==2||p->version==3||(CARAVEL_FORMAT2&&p->version==6)
#if HP_EL_PROJECT
 ||p->version==4||p->version==5
#endif
 ){
  uint8_t raw[HP_RAW_META] __attribute__((aligned(4)));
  return p->size==HP_V2_SIZE&&p->crc==hp_hash((const uint8_t*)p+32,HP_V2_SIZE-32)&&hp_v2_decode(p,raw);
 }
#endif
 if(p->version!=1||p->size!=sizeof*p||p->crc!=hp_hash((const uint8_t*)p+32,sizeof*p-32)||!hp_model_valid(&p->model))return 0;
 const hp_pair_store_t*q=&p->pair;if(q->on>1||q->motion>1||q->base<0)return 0;
 if(q->on&&(q->a>=NTRK||q->b>=NTRK||q->a==q->b))return 0;
 for(uint32_t i=0;i<NSTEP;i++)if(q->lane[i]<-1)return 0;
 return 1;
}
static int hp_capture(hp_store_t*p)
{
 memset(p,0,HP_CAPTURE_BYTES);p->magic=HP_MAGIC;p->version=1;p->size=sizeof*p;
 project_capture(&proj_scratch);
#if CARAVEL_FORMAT2
 if(!proj_pack(&p->native,&proj_scratch))return 0;
#else
 proj_pack(&p->native,&proj_scratch);
#endif
#if HP_SNAPSHOT_STORE
 p->reserved[1]=hp_v2_encode((uint8_t*)&p->model,&hp,0,hp_rm_snap);
 if(!p->reserved[1]){p->magic=0;return 0;}
 p->version=
#if CARAVEL_FORMAT2
 6;
#elif HP_EL_PROJECT
 5;
#else
 3;
#endif
 p->size=HP_V2_SIZE;p->reserved[2]=HP_RAW_META;
#else
 uint32_t irq=perf_irq_save();p->model=hp;for(uint32_t t=0;t<NTRK;t++)p->model.track[t].pad[0]=trk[t].user;hp_pair_capture(&p->pair);perf_irq_restore(irq);
#endif
 return 1;
}
static int hp_restore(const hp_store_t*p)
{
 if(!hp_capsule_ok(p))return 0;
#if HP_SNAPSHOT_STORE
 uint8_t raw[HP_RAW_META] __attribute__((aligned(4)));
 int v2=p->version==2||p->version==3||(CARAVEL_FORMAT2&&p->version==6)
#if HP_EL_PROJECT
 ||p->version==4||p->version==5
#endif
 ;if(v2&&!hp_v2_decode(p,raw))return 0;
#endif
 if(p!=&hp_io)memcpy(&hp_io,p,p->size);
#if HP_SNAPSHOT_STORE
 if(v2)hp_meta_unpack(&hp_io.model,&hp_io.pair,raw);
#endif
 if(!proj_import(&proj_scratch,&hp_io.native,sizeof hp_io.native))return 0;
 hp_pair_store_t*pair=&hp_io.pair;
 if(pair->on)for(uint32_t m=0;m<2;m++){proj_trk_t*t=&proj_scratch.t[m?pair->b:pair->a];if(!pair_engine_ok(t->engine)||(uint32_t)t->p[P_VOICE]>V_UNISON)return 0;}
 if(project_restore_runtime(&proj_scratch))return 0;
 /* Pair mode has no SPREAD. A project saved with SPREAD set on a pair track loads with it at 0, instead of being rejected. */
 if(pair->on)for(uint32_t m=0;m<2;m++)trk[m?pair->b:pair->a].p[P_SPRD]=0;
 uint32_t irq=perf_irq_save();
 hp=hp_io.model;for(uint32_t t=0;t<NTRK;t++){uint32_t u=hp.track[t].pad[0];if(u&&(!up_used(u-1)||up_engine(u-1)==trk[t].eng_req))trk[t].user=u;}hp_last_valid=0;hp_backup_track=255;hp_motion_stop();
 if(pair->on){
  for(uint32_t t=0;t<NTRK;t++){memset(trk[t].v,0,sizeof trk[t].v);engine_block(&trk[t]);}
  voice_policy=0;voice_policy_sync();pair_cleanup_pending=0;panic_req=0;
  if(!pair_enable(pair->a,pair->b)){perf_irq_restore(irq);return 0;}
  ep.base=ep.effective=pair->base;ep.motion=pair->motion;hp.pair_base=pair->base;hp.pair_motion=pair->motion;hp.pair_valid=1;memcpy(ep.lane,pair->lane,sizeof ep.lane);
  for(uint32_t t=0;t<NTRK;t++)for(uint32_t k=0;k<NMSLOT;k++)if(pair->mod[t][k])trk[t].p[P_M1DST+3*k]=MD_PAIR;
 }
#if HP_SNAPSHOT_STORE
 hp_rm_reset_all();hp_rm_snapshot_clear();action_snap_slot=0;
 uint32_t dropped=0;
 if(p->version==3||(CARAVEL_FORMAT2&&p->version==6)
#if HP_EL_PROJECT
    ||p->version==4||p->version==5
#endif
 )memcpy(hp_rm_snap,raw+HP_HW_META,sizeof hp_rm_snap); /* v4 retains ALL v3 snapshot slots/settings */
 else if(p->version==2)dropped=hp_snapshots_migrate((const void*)(raw+HP_HW_META));   /* the old four slots, sorted into the tracks' own sets */
#if CARAVEL_FORMAT2
 for(uint32_t t=0;t<NTRK;t++)for(uint32_t k=0;k<HP_RM_SNAP_SLOTS;k++) {
  hp_rm_snap_t *q=&hp_rm_snap[t][k];
  for(uint32_t i=0;i<q->count;i++) {
   uint32_t v=hp_take(q->refs[i],3),e=(v>>14)&31u;
   if(e!=31u)hp_put(q->refs[i],(v&~(31u<<14))|(eng_unstore(e)<<14),3);
  }
 }
 uxl.uset=raw[HP_RAW_META-HP_F2_SET_BYTES+5u];
#endif
 hp_ps_apply(v2?hp_rm_snap:0);                  /* stored settings, or the defaults of a project made before them; a journey starts stopped */
#if HP_EL_PROJECT
 /* project_restore_runtime calls hp_init() (defaults + no active arms).
  * v4 restores legacy BOUNCE counts; v5 uses tagged tempo subdivisions.
  * Historical untagged values remain valid and keep their original sound.
  * v1/v2/v3 load safe new defaults rather than guessing missing bytes. */
 if(p->version==4u||p->version==5u||(CARAVEL_FORMAT2&&p->version==6u))hp_el_persist_apply(raw+HP_RAW_META_V3);
 else{uint8_t defaults[HP_EL_PERSIST_BYTES];hp_el_persist_pack(defaults,0u);hp_el_persist_apply(defaults);}
#endif
#endif
 perf_irq_restore(irq);hp_dirty=0;ui.force=1;
#if HP_SNAPSHOT_STORE
 if(dropped){char m[32];perf_format(m,sizeof m,"%u TARGETS DROPPED",dropped);ui_message(m);}   /* an old project's slot held more than a track's slot can */
#endif
 return 1;
}
static uint32_t hp_signature(void)
{
 hp_pair_store_t p;hp_pair_capture(&p);
#if HP_SNAPSHOT_STORE
 uint32_t ps=0;                      /* each track's BARS DEPTH SCOPE SHAPE WAIT DIR: a change is an autosave (RESTORE LAST) */
 for(uint32_t t=0;t<NTRK;t++){hp_eng_ovr=(uint8_t)t;ps=ps*31u+hp_ps_word();}
 hp_eng_ovr=255u;
#endif
 return autosave_sig()
#if CARAVEL_FORMAT2
 ^((uint32_t)uxl.uset<<24)
#endif
#if HP_SNAPSHOT_STORE
 ^hp_hash(hp_rm_snap,sizeof hp_rm_snap)^hp_hash(&ps,sizeof ps)
#endif
 ^hp_hash(&hp,sizeof hp)^hp_hash(&p,sizeof p)^((uint32_t)trk[0].user|(uint32_t)trk[1].user<<8|(uint32_t)trk[2].user<<16|(uint32_t)trk[3].user<<24)
#if HP_EL_PROJECT
 /* Settings changes also trigger the existing quiet 10s RESTORE LAST
  * autosave; never include live coil positions or continuous phase ticks. */
 ^hp_el_persist_sig()
#endif
 ;
}

/* Canonical sound comparison; no flags, snapshots, flash writes or DSP changes. */
static int hp_sound_changed(const track_t *t)
{
 uint32_t k=trk_index(t),u=user_of(t),e=t->eng_req%NENGINES;
 int16_t p[P_COUNT];lfo2_config_t l2={{0}};uint8_t patch[128],actual[128];
 const engine_t*engine=ENGINES[e];
 if(u<UP_SLOTS){
  const up_rec_t*r=up_rec(u);if(r->engine!=e)return 0;
  up_values(r,p);if(r->ver>=8u)memcpy(l2.p,r->packed+UP_L2_AT,L2_N);
 }else{
  if(!engine->npresets)return 0;
  preset_sound_values(e,t->preset,p,&l2);
 }
 for(uint32_t i=0;i<P_COUNT;i++)if(!param_kept(i)&&motion_base_value(t,i)!=p[i])return 1;
 if(memcmp(&l2,&lfo2_config[k],sizeof l2))return 1;


 return 0;
}
