/* SPDX-License-Identifier: GPL-3.0-only */
/* Experimental HOME model. Never consumes a native P_* or motion ID. */
#if !defined(FELUCCA_WEB) && !defined(PAIR_TEST) && !FELUCCA_PERF_HW
#error HOME performance prototype is emulator only
#endif
#define HP_ROWS 32u
#define HP_EVENTS 128u
#define HP_VFIRST 2048u
enum {HP_NONE, HP_TRACK, HP_GLOBAL, HP_LFO2, HP_DX, HP_PAIR, HP_MACRO, HP_FM6};
typedef struct { uint16_t id, page; uint8_t kind, track, engine, aux; } hp_ref_t;
typedef struct { hp_ref_t ref; int16_t amount; uint16_t pad; } hp_route_t;
typedef struct { int16_t base; uint16_t pad; hp_route_t route[4]; } hp_macro_t;
typedef struct { uint8_t count, active, pad[2]; /* pad[0]: optional user-preset origin, 0 unknown; codec high bits. */ hp_ref_t cell[HP_ROWS][4]; } hp_track_t;
typedef struct { uint8_t track, step, control, lock; int16_t value; uint16_t pad; } hp_event_t;
typedef struct { hp_track_t track[NTRK]; hp_macro_t macro[NTRK][4]; uint16_t events, pad; hp_event_t event[HP_EVENTS]; int16_t pair_base; uint8_t pair_motion,pair_valid; } hp_model_t;
static hp_model_t hp;
static hp_ref_t hp_last;
static uint8_t hp_last_valid, hp_last_track, hp_default=1, hp_macro_sel, hp_route_sel;
static uint8_t hp_edit_row, hp_edit_col, hp_edit_action, hp_apply_armed;
static uint8_t hp_edit_track=255, hp_backup_track=255;
/* Reuse the existing HOME undo allocation for one performance edit. */
static union {
 hp_track_t home;
 struct {uint16_t count,pad;hp_event_t event[HP_EVENTS];} automation;
} hp_edit_history;
#define hp_edit_backup hp_edit_history.home
static uint8_t hp_backup_automation;
_Static_assert(sizeof(hp_edit_history)==sizeof(hp_track_t),"shared HOME/automation undo must not grow");
/* Four macros with four routes each touch at most sixteen parameters. */
#define HP_MACRO_TARGETS 16u
_Static_assert(P_COUNT <= 256, "Macro IDs require more than one byte");
static int16_t hp_macro_live[NTRK][4], hp_macro_keep[NTRK][HP_MACRO_TARGETS];
static uint8_t hp_macro_ids[NTRK][HP_MACRO_TARGETS], hp_macro_count[NTRK];
static uint8_t hp_dirty,hp_combo_pending;
/* MORPH JOURNEY (pilot) MIDI Learn targets follow the 4 macros and 4 pair controls: PLAY DIR NEXT WAIT BARS DEPTH SCOPE SHAPE */
#if CARAVEL_ACTION_BANKS && FELUCCA_RANDOM_MORPH
#define HP_JVN 8u
#else
#define HP_JVN 0u
#endif
#define HP_HFIRST (HP_VFIRST+16u)
#if CARAVEL_ACTION_BANKS
#define HP_HVN 5u
#else
#define HP_HVN 0u
#endif
static int hp_harmony_target(uint32_t id) {return HP_HVN && id>=HP_HFIRST && id<HP_HFIRST+HP_HVN;}
static int hp_virtual(uint32_t id) { return (id >= HP_VFIRST && id < HP_VFIRST+8u+HP_JVN)||hp_harmony_target(id); }
static int hp_journey_target(uint32_t id) { return HP_JVN && id >= HP_VFIRST+8u && id < HP_VFIRST+8u+HP_JVN; }
static void hp_journey_cc(uint32_t id, uint32_t value);
static void hp_begin(track_t *t);
static void hp_end(track_t *t);
static void hp_motion_step(track_t *t, uint32_t step, uint32_t play);
static void hp_motion_pause(track_t *t);
static uint32_t hp_auto_count(const track_t *t, int locks);
static uint32_t hp_pair_auto_count(void);
static uint32_t hp_auto_sig(const track_t *t);
static int hp_auto_find(uint32_t track,uint32_t step,uint32_t control);
static void hp_auto_edit(uint32_t index,uint32_t step,int32_t value,uint32_t lock);
static void hp_auto_delete(uint32_t index);
static void hp_auto_undo_take(const track_t *t);
static int hp_auto_undo_ready(const track_t *t);
static int hp_auto_undo_swap(track_t *t);
static void hp_motion_stop(void);
static void hp_midi(track_t *t, uint32_t id, uint32_t value);
static void hp_midi_touch(uint32_t kind, uint32_t track, uint32_t id);
#if CARAVEL_ELASTIC_P1
static void hp_elastic_p1_init(void);
static void hp_elastic_p1_clear(void);
#if CARAVEL_ELASTIC_PLAYABLE
static void hp_elastic_p1_clear_track(uint32_t track);
static void hp_elastic_p1_clear_current(void);
#endif
static void hp_elastic_p1_manual(uint32_t track,uint32_t id);
static void hp_elastic_p1_poll(uint32_t now);
/* ui.c is compiled before home_ui.c (which includes the controller header):
 * keep its one load-time query behind this accessor. */
static int hp_elastic_p1_targets_track(uint32_t track);
#endif
static const param_desc_t *hp_vdesc(uint32_t id);
static int hp_project_save(uint32_t slot, const char *name);
static int hp_project_load(uint32_t slot);
#if FELUCCA_PERF_HW
static int hp_project_rename(uint32_t slot,const char*name);
#endif
static void hp_autosave_poll(void);
static int hp_autosave_boot(int allowed);
static void hp_init(void);
static void hp_apply(uint32_t track, uint32_t set);
static void hp_apply_template(uint32_t track, uint32_t set);
static void hp_open_editor(void);
static void hp_add_last(void);
static void hp_touch(uint32_t slot);
static void hp_draw_home(void);
static void hp_page_cards(void);
static void hp_page_knob(uint32_t slot, int32_t steps);
static void hp_turn(uint32_t slot, int32_t steps, int momentary);
static void hp_row_turn(int32_t steps);
static uint32_t hp_lock_id(uint32_t slot);
static void hp_lock_turn(uint32_t slot, int32_t steps, uint64_t held);
static void hp_editor_apply(void);
static void hp_source(void);
static void hp_page_graph(void);
static void hp_editor_sync(void);
static int hp_oct_button(uint32_t button);

static int hp_forget(uint32_t slot);

static void hp_motion_clear(track_t*t);

static int hp_sound_changed(const track_t *t);

#if FELUCCA_RANDOM_MORPH
/* Volatile HOME Random Morph state shared by the menu and performance UI. */
#define HP_RM_V2_MAX 128u  /* a project format 2 slot: 128 targets */
#define HP_RM_MAX 32u   /* cells of ONE track's morph: its own HOME controls (32 = the snapshot limit), plus its parked RETURN origins */
#define HP_RM_IDLE 0u
#define HP_RM_RANDOM 1u
#define HP_RM_FROZEN 2u
#define HP_RM_RETURN 3u
#define HP_RM_DONE 4u
#define HP_RM_RECALL 5u
#define HP_RM_ROW 0u
#define HP_RM_TRACK 1u
#define HP_RM_ALL 2u
#define HP_RM_LINEAR 0u
#define HP_RM_SMOOTH 1u
#define HP_RM_DRIFT 2u

typedef struct {
 hp_ref_t ref;
 int16_t original,from,to,last;
 uint8_t released; /* manual edit takes permanent priority for this morph */
 uint8_t context; /* uses cell padding: TRACK/ROW owner of the RETURN origin */
} hp_rm_cell_t;
typedef struct {
 hp_rm_cell_t cell[HP_RM_MAX];
 uint32_t count,phase,stamp,seed;
 uint8_t state,bars,depth,scope,shape,origin_track,origin_row,frozen_from;
 uint8_t beat; /* a journey leg on the transport's musical time (CONTINUE / START): stamp is then the leg's start in bars (Q16), not milliseconds */
 uint16_t used; /* shared 128-target arena: active prefix plus parked origins */
 uint8_t context;
} hp_rm_state_t;
#define HP_RM_INIT {.bars=8,.depth=35,.scope=HP_RM_TRACK,.shape=HP_RM_SMOOTH,.seed=0x8C89D39Bu}
/* One morph engine per track, each with its own cells, phase, state and settings. `hp_rm` is the SELECTED track's engine for everything the
 * panel and the tests do; the polls and the claim / release scans address the engines by index (hp_eng_ovr). */
static hp_rm_state_t hp_eng[NTRK]={HP_RM_INIT,HP_RM_INIT,HP_RM_INIT,HP_RM_INIT};
static uint8_t hp_eng_ovr=255u;                        /* 255: follow the selected track; 0..3: the engine a poll or a fan-out works on */
#define hp_et() (hp_eng_ovr<NTRK?(uint32_t)hp_eng_ovr:(uint32_t)(song.sel&3u))
#define hp_rm (hp_eng[hp_et()])
static const uint8_t hp_rm_times[]={1,2,4,8,16,32,64};
static const uint8_t hp_rm_depths[]={10,25,35,50,75,100};
#if CARAVEL_ACTION_BANKS
/* Volatile snapshot memory: four slots per track (a track's own set; nothing is shared between tracks). A slot stores refs and values only:
 * no sound, project, FX audio or duplicate synth parameter stores. No heap use. A track's set holds that track's own controls (and the
 * global / Pair morph controls pinned on its HOME), at most 32 targets per slot; the few spare bytes of the first slot carry the track's
 * RANDOM / JOURNEY settings in a saved project (home_store_snapshots.h). */
#define HP_RM_SNAP_SLOTS 4u
#define HP_RM_SNAP_MAX 32u
typedef struct {
 uint8_t count,scope,pad[2];                   /* count 0 = empty; scope HP_RM_ROW or HP_RM_TRACK: what was captured */
 /* Snapshot recall never uses source-page metadata. Three bytes losslessly
  * encode every supported pinned target; separate values avoid struct padding. */
 uint8_t refs[HP_RM_SNAP_MAX][3];
 int16_t values[HP_RM_SNAP_MAX];
} hp_rm_snap_t;
static hp_rm_snap_t hp_rm_snap[NTRK][HP_RM_SNAP_SLOTS];
#endif


static void hp_rm_reset(void);
static void hp_rm_reset_all(void);
static void hp_rm_freeze(void);

#endif /* FELUCCA_RANDOM_MORPH */
