/* SPDX-License-Identifier: GPL-3.0-only */
/* One engine per track: morphs and journeys of different tracks run at the same time, a control two tracks move belongs to the one that
 * started last, the settings are per track and saved with the project. The firmware is booted in the host harness. */
#define FELUCCA_HOME_PERF 1
#define PAIR_TEST_MAIN journey_tracks_baseline_main
#include "../engine-pair-morph/pair_test.c"
static void tap(uint32_t k){key(1u<<(k?action_keys[k-1u]:ACT_BANK_NEXT));key(0);}   /* 0 = BANK, 1..4 = A1..A4 */
static void sel(uint32_t t){song.sel=t;go_home();action_refresh();run_ms(60);}
static void seal(hp_store_t*p){p->crc=hp_hash((uint8_t*)p+32,p->size-32);p->reserved[0]=hp_hash(p,20);}
static int cell_of(uint32_t u,uint32_t track,uint32_t id)         /* the index of engine u's cell for a track's control, -1 none */
{
 for(uint32_t i=0;i<hp_eng[u].used;i++)if(hp_eng[u].cell[i].ref.kind==HP_TRACK&&hp_eng[u].cell[i].ref.track==track&&hp_tid(hp_eng[u].cell[i].ref)==id)return (int)i;
 return -1;
}
int main(void){
 web_nor_erase();web_boot();run_ms(1400);normal_off();pair_disable();
 for(uint32_t t=0;t<NTRK;t++)hp_apply(t,0);
 /* T1's HOME pins T1's REV and T2's PAN; T2's HOME pins T2's PAN and REV */
 CHECK(web_home_assign(0,0,0,HP_TRACK,0,P_REV));CHECK(web_home_assign(0,0,1,HP_TRACK,1,P_PAN));
 CHECK(web_home_assign(1,0,0,HP_TRACK,1,P_PAN));CHECK(web_home_assign(1,0,1,HP_TRACK,1,P_REV));
 song.sel=0;go_home();action_enabled=1;action_bank=0;action_refresh();
 for(uint32_t t=0;t<NTRK;t++){hp_eng[t].scope=HP_RM_TRACK;hp_eng[t].bars=2;hp_eng[t].depth=100;hp_eng[t].shape=HP_RM_LINEAR;}
 hp_rm_reset_all();
 trk[0].p[P_REV]=10;trk[1].p[P_PAN]=-30;trk[1].p[P_REV]=20;

 /* 1. last started wins: T1 starts, then T2 starts a morph that moves the same control (T2's PAN) */
 tap(1);run_ms(200);
 CHECK(hp_eng[0].state==HP_RM_RANDOM&&cell_of(0,1,P_PAN)>=0&&!hp_eng[0].cell[cell_of(0,1,P_PAN)].released);
 sel(1);tap(1);run_ms(100);
 CHECK(hp_eng[1].state==HP_RM_RANDOM);
 {int a=cell_of(0,1,P_PAN),b=cell_of(1,1,P_PAN),r0=cell_of(0,0,P_REV);
  CHECK(a>=0&&b>=0&&r0>=0);
  CHECK(hp_eng[0].cell[a].released&&!hp_eng[1].cell[b].released&&!hp_eng[0].cell[r0].released);   /* T1 gave the control up, kept its own REV */
  for(uint32_t i=0;i<20u;i++){run_ms(40);CHECK(trk[1].p[P_PAN]==hp_eng[1].cell[b].last);}}          /* only T2's morph writes it now */
 sel(0);tap(1);run_ms(100);                                                                          /* T1 starts again: it takes the control back */
 {int a=cell_of(0,1,P_PAN),b=cell_of(1,1,P_PAN);
  CHECK(!hp_eng[0].cell[a].released&&hp_eng[1].cell[b].released);}
 for(uint32_t t=0;t<NTRK;t++){hp_eng_ovr=(uint8_t)t;hp_rm_reset();}hp_eng_ovr=255u;

 /* 2. the settings are per track and survive a project round trip */
 hp_eng[0].bars=4;hp_eng[0].depth=25;hp_eng[0].shape=HP_RM_DRIFT;hp_jn[0].wait=3;hp_jn[0].rev=1;hp_jn[0].scope=1;hp_jn[0].tp=2;
 hp_eng[1].bars=16;hp_eng[1].depth=75;hp_eng[1].scope=HP_RM_ALL;hp_eng[1].shape=HP_RM_LINEAR;hp_jn[1].wait=0;hp_jn[1].rev=0;hp_jn[1].scope=0;hp_jn[1].tp=1;
 hp_eng[2].bars=1;hp_eng[2].depth=10;hp_eng[2].scope=HP_RM_ROW;hp_eng[2].shape=HP_RM_SMOOTH;hp_jn[2].wait=5;hp_jn[2].rev=1;hp_jn[2].scope=1;hp_jn[2].tp=0;
 hp_eng[3].bars=64;hp_eng[3].depth=100;hp_eng[3].shape=HP_RM_SMOOTH;hp_jn[3].wait=1;hp_jn[3].rev=0;hp_jn[3].scope=0;hp_jn[3].tp=2;
 {uint8_t bars[NTRK],depth[NTRK],scope[NTRK],shape[NTRK],wait[NTRK],rev[NTRK],js[NTRK],tp[NTRK];
  for(uint32_t t=0;t<NTRK;t++){bars[t]=hp_eng[t].bars;depth[t]=hp_eng[t].depth;scope[t]=hp_eng[t].scope;shape[t]=hp_eng[t].shape;wait[t]=hp_jn[t].wait;rev[t]=hp_jn[t].rev;js[t]=hp_jn[t].scope;tp[t]=hp_jn[t].tp;}
  CHECK(hp_capture(&hp_io));seal(&hp_io);
  for(uint32_t t=0;t<NTRK;t++){hp_eng[t].bars=8;hp_eng[t].depth=35;hp_eng[t].scope=HP_RM_TRACK;hp_eng[t].shape=HP_RM_SMOOTH;hp_jn[t].wait=0;hp_jn[t].rev=0;hp_jn[t].scope=0;hp_jn[t].tp=0;}
  CHECK(hp_restore(&hp_io));
  for(uint32_t t=0;t<NTRK;t++)CHECK(hp_eng[t].bars==bars[t]&&hp_eng[t].depth==depth[t]&&hp_eng[t].scope==scope[t]&&hp_eng[t].shape==shape[t]&&hp_jn[t].wait==wait[t]&&hp_jn[t].rev==rev[t]&&hp_jn[t].scope==js[t]&&hp_jn[t].tp==tp[t]);}

 /* 3. SCOPE ALL fans a RANDOM key out to every track, each with its own BARS */
 for(uint32_t t=0;t<NTRK;t++){hp_eng[t].scope=HP_RM_TRACK;hp_eng[t].bars=1;}
 hp_rm_reset_all();
 CHECK(web_home_assign(2,0,0,HP_TRACK,2,P_REV));CHECK(web_home_assign(3,0,0,HP_TRACK,3,P_REV));
 sel(0);hp_rm.scope=HP_RM_ALL;hp_eng[2].bars=4;tap(1);run_ms(100);
 for(uint32_t t=0;t<NTRK;t++)CHECK(hp_eng[t].state==HP_RM_RANDOM&&hp_eng[t].count>=1u&&hp_eng[t].origin_track==t);
 CHECK(strstr(ui.msg,"4 TRACKS")!=NULL);
 run_ms(2500);
 CHECK(hp_eng[0].state==HP_RM_DONE&&hp_eng[2].state==HP_RM_RANDOM);                                 /* T3's longer BARS are its own */
 tap(3);run_ms(100);                                                                                  /* A3 with no slot: RETURN on every track */
 for(uint32_t t=0;t<NTRK;t++)CHECK(hp_eng[t].state==HP_RM_RETURN);

 /* 4. JOURNEY scope ALL: PLAY / PAUSE / NEXT act on every track's journey, DIR and WAIT are set on every track */
 for(uint32_t t=0;t<NTRK;t++){hp_jn[t].on=hp_jn[t].paused=hp_jn[t].held=0;hp_jn[t].phase=0;hp_jn[t].scope=0;hp_jn[t].tp=0;hp_jn[t].rev=0;hp_jn[t].wait=1;hp_eng[t].bars=1;hp_eng[t].scope=HP_RM_TRACK;}
 hp_rm_reset_all();hp_rm_snapshot_clear();
 for(uint32_t t=0;t<2u;t++){
  sel(t);trk[0].p[P_REV]=10;trk[1].p[P_PAN]=-30;trk[1].p[P_REV]=20;
  action_snap_slot=0;CHECK(hp_rm_snapshot_store(0));
  trk[0].p[P_REV]=80;trk[1].p[P_PAN]=40;trk[1].p[P_REV]=70;action_snap_slot=1;CHECK(hp_rm_snapshot_store(1));
  trk[0].p[P_REV]=50;trk[1].p[P_PAN]=0;trk[1].p[P_REV]=50;
 }
 sel(0);while(action_bank!=ACT_BANK_JOURNEY)tap(0);
 hp_j.scope=1;action_snap_slot=0;tap(1);run_ms(200);
 CHECK(hp_jn[0].on&&hp_jn[1].on&&!hp_jn[2].on&&!hp_jn[3].on&&strstr(ui.msg,"PLAY: 2 TRACKS")!=NULL);
 tap(1);run_ms(60);CHECK(hp_jn[0].paused&&hp_jn[1].paused&&strstr(ui.msg,"PAUSE: 2 TRACKS")!=NULL);
 tap(1);run_ms(60);CHECK(!hp_jn[0].paused&&!hp_jn[1].paused);
 tap(2);run_ms(60);CHECK(hp_jn[0].rev==1u&&hp_jn[1].rev==1u&&hp_jn[2].rev==1u);                        /* DIR on every track */
 tap(4);run_ms(60);CHECK(hp_jn[0].wait==2u&&hp_jn[1].wait==2u&&hp_jn[3].wait==2u);                       /* WAIT on every track */
 tap(3);run_ms(60);CHECK(strstr(ui.msg,"NEXT: 2 TRACKS")!=NULL);
 {uint32_t g=0;while(!(hp_jn[0].phase==1u&&hp_jn[1].phase==1u)&&g++<8000u)run_ms(10);CHECK(hp_jn[0].phase==1u&&hp_jn[1].phase==1u);}
 /* scope THIS: PLAY touches only the selected track */
 for(uint32_t t=0;t<NTRK;t++){hp_jn[t].on=hp_jn[t].paused=hp_jn[t].held=0;hp_jn[t].phase=0;}hp_rm_reset_all();
 hp_j.scope=0;action_snap_slot=0;tap(1);run_ms(100);CHECK(hp_jn[0].on&&!hp_jn[1].on);
 /* 5. a dialog open over a running morph or journey is drawn once, not on every poll (it flickered on a project SAVE over a used slot) */
 for(uint32_t t=0;t<NTRK;t++){hp_jn[t].on=hp_jn[t].paused=hp_jn[t].held=0;hp_jn[t].phase=0;}hp_rm_reset_all();
 sel(0);{uint32_t g=0;while(action_bank!=0u&&g++<8u)tap(0);}CHECK(action_bank==0u);hp_rm.scope=HP_RM_TRACK;hp_rm.bars=8;hp_rm.depth=100;
 hp_rm_start(fm1_ms);run_ms(200);CHECK(hp_rm.state==HP_RM_RANDOM);ui.home=0;
 {uint32_t forced=0,i;confirm_open(CF_OVR_PROJ,0);
  for(i=0;i<60u;i++){run_ms(20);forced+=ui.force!=0;}
  CHECK(ui.confirm==CF_OVR_PROJ&&forced<=1u&&hp_rm.state==HP_RM_RANDOM);
  ui.confirm=0;ui.force=0;run_ms(100);forced=0;                                   /* ... and the page is redrawn again once it is closed */
  for(i=0;i<20u;i++){run_ms(20);forced+=ui.force!=0;}
  CHECK(forced>0u);}

 /* 6. the FX filter (FILT, HP / LP) swings only between -70 and +70 in a RANDOM morph, whatever it was set to */
 hp_rm_reset_all();ui.home=1;
 CHECK(web_home_assign(3,1,0,HP_TRACK,3,P_FILT));
 sel(3);hp_rm.scope=HP_RM_ROW;hp_rm.depth=100;hp.track[3].active=1;
 {int lo=99,hi=-99;
  for(uint32_t n=0;n<90u;n++){
   trk[3].p[P_FILT]=(int16_t)(n%3u==0?-64:n%3u==1?0:63);
   hp_rm_reset();hp_rm_start(fm1_ms+n);
   int c=cell_of(3,3,P_FILT);CHECK(c>=0);
   int t=hp_eng[3].cell[c].to;if(t<lo)lo=t;if(t>hi)hi=t;
   CHECK(t>=-45&&t<=44);
  }
  CHECK(lo<-30&&hi>30);                                                               /* it does use most of the allowed swing */
  char v[24];const char*u;param_format(hp_desc(hp_track_ref(3,P_FILT,0xFFFF)),-45,v,&u);CHECK(!strcmp(v,"70"));
  param_format(hp_desc(hp_track_ref(3,P_FILT,0xFFFF)),44,v,&u);CHECK(!strcmp(v,"69"));}
 printf("JOURNEY TRACKS PASS: %u checks.\n",checks);
 return 0;
}
