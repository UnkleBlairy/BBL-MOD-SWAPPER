Caravel 1.2.0 for the BBL Mod Swapper

Original by bonszaimusic: https://github.com/bonszaimusic/caravel
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: CARAVEL-source.zip on the ports page.
