/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: Ravel 1.46.0 (https://github.com/De-Pattern/Ravel_FM1) on the Teensy 4.1: its own browser build (web/emu/ravel_web.c) inside ports/common's shell */
#include "../../../common/shell_pre.h"
#include <stdlib.h>
#include <time.h>
#ifndef CLOCK_MONOTONIC
#define CLOCK_MONOTONIC 1
static int clock_gettime(int c, struct timespec *t) { (void)c; t->tv_sec = 0; t->tv_nsec = 0; return 0; }
#endif
#define getenv(n) ((char *)0)
#define memset rv_memset
#define memcpy rv_memcpy
#define memmove rv_memmove
#define memcmp rv_memcmp
#define web_boot o_web_boot
#define web_out_l o_web_out_l
#define web_out_r o_web_out_r
#define web_render o_web_render
#define web_buttons o_web_buttons
#define web_keys o_web_keys
#define web_enc o_web_enc
#define web_master o_web_master
#define web_nor_erase o_web_nor_erase
#define web_ms o_web_ms
#define web_frame o_web_frame
#include "../../web/emu/ravel_web.c"
#undef __attribute__
#undef EXPORT
#undef memset
#undef memcpy
#undef memcmp
#undef memmove
#undef web_boot
#undef web_out_l
#undef web_out_r
#undef web_render
#undef web_buttons
#undef web_keys
#undef web_enc
#undef web_master
#undef web_nor_erase
#undef web_ms
#undef web_frame
#define SH_FLOAT
#define SH_OUT_L sh_lp
#define SH_OUT_R sh_rp
#define SH_RENDERF(n) sh_rv(n)
#define SH_ADC(m) rv_set_master((m * m) >> 8)
static void SH_BOOT(void) { rv_boot(); ui_intro(); }
static void SH_FRAME(uint32_t ms)
{ (void)ms; }
static float sh_l[1024], sh_r[1024];
static uint32_t sh_rn, sh_ra;
static void sh_rv(uint32_t n)
{
    uint32_t i;
    for (i = 0; i < n; i++) {
        while (sh_ra >= sh_rn) { sh_rn = rv_run(1); sh_ra = 0; }
        sh_l[i] = audio[2u * sh_ra]; sh_r[i] = audio[2u * sh_ra + 1u]; sh_ra++;
    }
}
static float *sh_lp(void) { return sh_l; }
static float *sh_rp(void) { return sh_r; }
static uint32_t sh_b, sh_k;
#define SH_BTN(i, d) (sh_b = (sh_b & ~(1u << (i))) | (uint32_t)(d) << (i), rv_set_buttons(sh_b))
#define SH_KEY(k, d) (sh_k = (sh_k & ~(1u << (k))) | (uint32_t)(d) << (k), rv_set_keys(sh_k))
#define SH_ENC(e, n) rv_enc((int)(e), (n))
#define SH_KEY_LED(k) (rv_leds_keys() >> (k) & 1u ? 2 : 0)
#define SH_BTN_LED(i) (rv_leds_buttons() >> (i) & 1u ? 2 : 0)
#include "../../../common/shell_post.h"
