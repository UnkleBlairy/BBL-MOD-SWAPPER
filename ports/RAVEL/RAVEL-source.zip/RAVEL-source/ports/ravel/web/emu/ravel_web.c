/* SPDX-License-Identifier: GPL-3.0-only */
/* Ravel in a browser: the same instrument and simulated FM-1 as the desktop simulator
 * (host/host_core.c), built freestanding for WebAssembly (web/emu/build.sh) and driven by
 * the page (index.html). */
#include <stdint.h>

#define EXPORT __attribute__((used))

/* the C library the instrument needs: the compiler's built-ins call these */
void *memset(void *d, int c, unsigned long n)
{
    uint8_t *p = d;
    while (n--)
        *p++ = (uint8_t)c;
    return d;
}
void *memcpy(void *d, const void *s, unsigned long n)
{
    uint8_t *p = d;
    const uint8_t *q = s;
    while (n--)
        *p++ = *q++;
    return d;
}
void *memmove(void *d, const void *s, unsigned long n)
{
    uint8_t *p = d;
    const uint8_t *q = s;
    if (p < q) {
        while (n--)
            *p++ = *q++;
    } else {
        p += n;
        q += n;
        while (n--)
            *--p = *--q;
    }
    return d;
}
int memcmp(const void *a, const void *b, unsigned long n)
{
    const uint8_t *p = a, *q = b;
    for (; n; n--, p++, q++)
        if (*p != *q)
            return *p - *q;
    return 0;
}

#include "../../host/host_core.c"
#include "../../firmware/app/rv.h"

int ui_section(void);
int ui_track(void);
const char *ui_page_title(void);
void ui_goto(int sec, int page);
void ui_set_track(int t);
int ui_octave(void);
int ui_armed(void);
int rv_preset_count(void);
const char *rv_preset_name(int i);
int rv_preset_kind(int i);
void rv_preset_apply(int t, int i);

/* ------------------------------------------------------------- audio --- */
#define AUDIO_MAX 1024u
static float audio[AUDIO_MAX * 2u];
static uint32_t audio_n;

static void host_audio(const int32_t *blk, uint32_t n)
{
    uint32_t i;
    for (i = 0; i < n && audio_n < AUDIO_MAX; i++, audio_n++) {
        audio[2u * audio_n] = (float)blk[2u * i] * (1.0f / 8388608.0f);
        audio[2u * audio_n + 1u] = (float)blk[2u * i + 1u] * (1.0f / 8388608.0f);
    }
}

/* audio coming in: the page writes a file's samples into this ring */
#define IN_RING 1024u
static float in_ring[IN_RING * 2u];
static uint32_t in_w, in_r;
static int host_audio_in(float *lr, int frames)
{
    int i;
    for (i = 0; i < frames && in_r != in_w; i++, in_r++) {
        lr[2 * i] = in_ring[2u * (in_r % IN_RING)];
        lr[2 * i + 1] = in_ring[2u * (in_r % IN_RING) + 1u];
    }
    return i;
}
void ui_intro(void);
EXPORT void web_intro(void) { ui_intro(); }   /* the start screen, as the FM-1 plays it at power-on */
EXPORT float *web_in_ptr(void) { return in_ring; }
EXPORT uint32_t web_in_write_pos(void) { return in_w % IN_RING; }
EXPORT uint32_t web_in_space(void) { return IN_RING - 1u - (in_w - in_r); }
EXPORT void web_in_commit(uint32_t n) { in_w += n; }
EXPORT uint32_t web_in_ring(void) { return IN_RING; }
EXPORT void web_in_clear(void) { in_r = in_w; }

/* ---------------------------------------------------------- running --- */
EXPORT void rv_boot(void)
{
    held_btn = held_keys = 0;
    boot();
}
EXPORT uint32_t rv_run(uint32_t ms)
{
    audio_n = 0;
    if (ms > 250u)
        ms = 250u;
    run_ms(ms);
    return audio_n;
}
EXPORT float *rv_audio(void) { return audio; }
EXPORT uint16_t *rv_fb(void) { return fb; }
EXPORT void rv_set_buttons(uint32_t m) { held_btn = m; }
EXPORT void rv_set_keys(uint32_t m) { held_keys = m; }
EXPORT void rv_enc(int role, int32_t d)
{
    if (role >= 0 && role < NE)
        enc_acc[role] += d;
}
EXPORT void rv_set_master(uint32_t v) { master = v > 4096u ? 4096u : v; }
EXPORT uint32_t rv_leds_buttons(void) { return lit_btn; }
EXPORT uint32_t rv_leds_keys(void) { return lit_keys; }
EXPORT uint32_t rv_leds_dim(void) { return lit_dim; }
EXPORT uint32_t rv_sample_rate(void) { return 44100u; }

/* flash slots, so the page can keep them between visits */
EXPORT uint8_t *rv_store(uint32_t s) { return s < RV_KEEP ? store[s] : 0; }
EXPORT int rv_store_len(uint32_t s) { return s < PLAT_STORES ? store_len[s] : -1; }
EXPORT void rv_store_set_len(uint32_t s, int n)
{
    if (s < PLAT_STORES && n <= (int)PLAT_SLOT_MAX)
        store_len[s] = n;
}
EXPORT uint32_t rv_store_writes(void) { return store_writes; }
EXPORT uint32_t rv_store_slots(void) { return PLAT_STORES; }   /* the projects and the sound banks */
EXPORT uint32_t rv_store_max(void) { return PLAT_SLOT_MAX; }

/* ------------------------------------------------------ the instrument --- */
EXPORT int web_track(void) { return ui_track(); }
EXPORT void web_set_track(int t) { ui_set_track(t); }
EXPORT int web_section(void) { return ui_section(); }
EXPORT void web_goto(int sec, int page) { ui_goto(sec, page); }
EXPORT const char *web_page_title(void) { return ui_page_title(); }
EXPORT int web_kind(int t) { return rv.tp[t & 7][TP_KIND]; }
EXPORT int web_engine(int t) { return rv.tp[t & 7][TP_ENGINE]; }
EXPORT int web_src0(int t) { return rv.tp[t & 7][TP_S0]; }
void ui_weft_touch(int t, int pre);
EXPORT void web_set_kind(int t, int kind, int engine)   /* (COMP: T8 only; one GLITCH LOOPER at a time) */
{
    int i;
    if (kind == KIND_TAPE || kind < 0 || kind >= KIND_N || (kind == KIND_COMP && (t & 7) != 7))
        return;
    if (kind == KIND_LOOP)
        for (i = 0; i < RV_TRACKS; i++)
            if (i != (t & 7) && rv.tp[i][TP_KIND] == KIND_LOOP)
                return;
    if (kind == KIND_PERC || kind == KIND_LOOP || kind == KIND_WEFT || rv.tp[t & 7][TP_KIND] == KIND_LOOP)
        rv_track_set_kind(t & 7, kind);               /* (a kit's lanes, a looper's trigs: the steps start clean; WEFT: its first patch) */
    else
        rv_track_defaults(t & 7, kind, engine);
    if (kind == KIND_WEFT)
        ui_weft_touch(t, 0);
}
EXPORT float web_comp_gr(void) { return rv_live.comp_gr; }
void host_midi_push(int a, int b, int c);
EXPORT void web_midi(int a, int b, int c) { host_midi_push(a, b, c); }   /* MIDI in, from the page's Web MIDI */
EXPORT int web_arp_n(int t) { return rv_live.arp_n[t & 7]; }
EXPORT int web_arp_hits(int t) { return rv_live.arp_hit[t & 7]; }
EXPORT float web_meter(int t) { return rv_live.meter[t & 7]; }
EXPORT float web_fenv(int t) { return rv_live.fenv[t & 7]; }   /* the FILTER ENV of the newest voice */
float rv_senv_level(int t, int *env);
void rv_senv_start(int t, int e);
EXPORT float web_senv(int t) { return rv_senv_level(t & 7, 0); }   /* STEP ENV: its level now */
EXPORT int web_senv_env(int t) { int e = -1; rv_senv_level(t & 7, &e); return e; }   /* the envelope playing (0-31), or -1 */
EXPORT void web_senv_start(int t, int e) { rv_senv_start(t & 7, e); }   /* (tests) */
EXPORT void web_step_set(int t, int s, int on, int env) { rv_step *p = &rv.pat[t & 7][rv.pat_cur[t & 7] % RV_PATTERNS].s[s & 63]; p->flags = on ? (uint8_t)(p->flags | ST_ON) : (uint8_t)(p->flags & ~ST_ON); p->env = (uint8_t)env; if (on && !p->vel) { p->vel = 100; p->len = 4; p->note = 60; p->chance = 100; } }
EXPORT float web_master_l(void) { return rv_live.master_l; }
EXPORT float web_master_r(void) { return rv_live.master_r; }
EXPORT int web_playing(void) { return rv_live.playing; }
EXPORT int web_armed(void) { return ui_armed(); }
EXPORT void web_transport(int run) { rv_transport(run); }
EXPORT void web_all_off(void) { rv_all_off(); }
int rv_save(int slot);
int rv_load(int slot);
EXPORT int web_save(int slot) { return rv_save(slot); }   /* (tests) */
EXPORT int web_load(int slot)
{
    int rc = rv_load(slot);
    if (rc == -2)
        rv_demo(2);                                    /* (a damaged save, part of it read: a new project, not half of it) */
    return rc;
}
EXPORT void web_demo(int which)
{
    rv_transport(0);
    rv_demo(which);
}
EXPORT const char *web_project_name(void) { return rv.name; }
EXPORT int web_tempo(void) { return rv.gp[GP_TEMPO]; }
EXPORT int web_bar(void) { return rv_live.bar; }
EXPORT int web_beat(void) { return rv_live.beat; }
EXPORT int web_step(int t) { return rv_live.step[t & 7][0]; }
EXPORT int web_mute(void) { return rv.mute; }
EXPORT void web_set_mute(int m) { rv.mute = (uint8_t)m; }
EXPORT const char *web_kind_name(int k) { return rv_kind_names[k % KIND_N]; }
EXPORT const char *web_engine_name(int e) { return rv_engine_names[e % ENG_N]; }
const char *ui_sound_name(int t);
EXPORT const char *web_sound_name(int t)
{
    const rv_pinfo *pi = rv_pinfo_track(t & 7, TP_S0);
    int k = rv.tp[t & 7][TP_KIND];
    if (k == KIND_WEFT)
        return ui_sound_name(t);
    if (k == KIND_SYNTH)
        return rv_engine_names[rv.tp[t & 7][TP_ENGINE] % ENG_N];
    return pi->names ? pi->names[rv.tp[t & 7][TP_S0] - pi->min] : "";
}
EXPORT int web_preset_count(void) { return rv_preset_count(); }
EXPORT const char *web_preset_name(int i) { return rv_preset_name(i); }
EXPORT int web_preset_kind(int i) { return rv_preset_kind(i); }
EXPORT void web_preset_apply(int t, int i) { rv_preset_apply(t & 7, i); }

/* the sound bank (SAVE > SOUNDS): list, load into a track, keep a track's sound under a name */
int rv_bank_used(int i);
const char *rv_bank_name(int i);
const char *rv_bank_kind_label(int i);
int rv_bank_store(int t, int i, const char *name);
int rv_bank_apply(int t, int i);
int rv_bank_clear(int i);
static char bank_name_buf[16];
void rv_bank_select(int b);
int rv_bank_current(void);
EXPORT int web_bank_n(void) { return 32; }
EXPORT int web_bank_banks(void) { return PLAT_BANKS; }
EXPORT void web_bank_select(int b) { rv_bank_select(b); }   /* banks A..D: one in RAM at a time */
EXPORT int web_bank_current(void) { return rv_bank_current(); }
EXPORT int web_bank_used(int i) { return rv_bank_used(i); }
EXPORT const char *web_bank_name(int i) { return rv_bank_name(i); }
EXPORT const char *web_bank_kind_label(int i) { return rv_bank_kind_label(i); }
EXPORT int web_bank_load(int t, int i) { return rv_bank_apply(t & 7, i); }
EXPORT char *web_bank_name_buf(void) { return bank_name_buf; }   /* the page writes a name here, */
EXPORT int web_bank_store(int t, int i) { bank_name_buf[11] = 0; return rv_bank_store(t & 7, i, bank_name_buf); }   /* then stores */
EXPORT int web_bank_clear(int i) { return rv_bank_clear(i); }
extern int rv_fault_count, rv_fault_where, rv_fault_track;
EXPORT int web_fault_track(void) { return rv_fault_track; }
EXPORT int web_fault_count(void) { return rv_fault_count; }
EXPORT int web_fault_where(void) { return rv_fault_where; }
EXPORT uint32_t web_cpu(void) { return rv_live.voices_synth + rv_live.voices_strike; }
EXPORT int web_tp(int t, int p) { return p >= 0 && p < TP_N ? rv.tp[t & 7][p] : 0; }
EXPORT void web_tp_set(int t, int p, int v) { if (p >= 0 && p < TP_N) rv_pid_set(PID_T(t & 7, p), v); }
EXPORT int web_head_step(int t, int h) { return rv_live.step[t & 7][h & 1]; }
EXPORT float web_fg_rate(int t, int h) { return rv_live.fg_rate[t & 7][h & 1]; }
EXPORT int web_gp(int g) { return g >= 0 && g < GP_N ? rv.gp[g] : 0; }
EXPORT void web_gp_set(int g, int v) { rv_pid_set(PID_G(g), v); }
EXPORT int web_gp_tempo(void) { return GP_TEMPO; }

EXPORT void web_mat_set(int i, int src, int dst, int amt) { rv_mslot *m = &rv.mat[i & 7]; m->src = (uint8_t)src; m->dst = (uint16_t)dst; m->amt = (int8_t)amt; }   /* (tests) */
EXPORT int web_mat_amt(int i) { return rv_live.mat_amt[i & 7]; }   /* a row's AMOUNT as other rows move it */
EXPORT int web_pid_mat(int k) { return PID_MAT(k); }
EXPORT int web_pid_t(int t, int p) { return PID_T(t, p); }
EXPORT int web_pid_g(int g) { return PID_G(g); }

/* projects and sounds to and from a computer: SysEx in (whole messages, F0..F7), replies out */
static uint8_t sx_in[1024];
EXPORT uint8_t *web_sysex_in_buf(void) { return sx_in; }
EXPORT int web_sysex_in(uint32_t n)       /* sx_in holds F0 .. F7 */
{
    if (n < 2 || n > sizeof sx_in || sx_in[0] != 0xF0 || sx_in[n - 1] != 0xF7)
        return 0;
    return rv_xfer_wire(sx_in + 1, n - 2);
}
EXPORT uint8_t *web_sysex_out(void) { return sx_out; }
EXPORT uint32_t web_sysex_out_len(void) { return sx_out_n; }
EXPORT void web_sysex_out_clear(void) { sx_out_n = 0; }
EXPORT void web_storage_changed(int slot) { ui_storage_changed(slot); }   /* (an imported file, written straight in) */
EXPORT int web_mat_dst(int i) { return rv.mat[i & 7].dst; }   /* (tests) */
EXPORT float web_eff(int t, int p) { return rv_param_eff(t & 7, p); }   /* a track parameter as modulation has it now (tests) */
EXPORT void web_kit_rate(int t, int l, int v) { rv.kit_rate[t & 7][l % RV_LANES] = (uint8_t)RV_LRATE_STORE(v); }   /* (tests) v: 0..8, 4 = the track's */
EXPORT void web_kit_hit(int t, int s, int l) { rv_step *p = &rv.pat[t & 7][rv.pat_cur[t & 7] % RV_PATTERNS].s[s & 63]; p->flags |= ST_ON; p->note |= (uint8_t)(1u << l); p->vel = 100; p->chance = 100; }
EXPORT void web_step_byte(int t, int s, int field, int v)   /* (tests) 0: ratchet, 1: cut, 2: note, 3: vel, 4: len (a kit: which lanes roll) */
{
    rv_step *p = &rv.pat[t & 7][rv.pat_cur[t & 7] % RV_PATTERNS].s[s & 63];
    if (field == 0) p->ratchet = (uint8_t)v;
    else if (field == 1) p->cut = (uint8_t)v;
    else if (field == 2) p->note = (uint8_t)v;
    else if (field == 4) p->len = (uint8_t)v;
    else p->vel = (uint8_t)v;
}
EXPORT void web_punch(int fx, int on) { rv_punch(fx, on); }
EXPORT void web_route_set(int a, int b, int type, int amt) { rv.infl[a & 7][b & 7].type = (uint8_t)type; rv.infl[a & 7][b & 7].amt = (int8_t)amt; }
EXPORT void web_scene_store(int s) { rv_scene_store(s); }
EXPORT void web_scene_launch(int s) { rv_scene_launch(s); }
EXPORT float web_live_glide(void) { return rv_live.glide; }
EXPORT float web_live_bed(void) { return rv_live.bed_env; }
EXPORT int web_lane_step(int t, int l) { return rv_live.lane_step[t & 7][l % RV_LANES]; }
EXPORT int web_step_info(int t, int st, int what)   /* (tests) 0: on, 1: note, 2: notes in its chord (1-4) */
{
    const rv_step *p = &rv.pat[t & 7][rv.pat_cur[t & 7] % RV_PATTERNS].s[st & 63];
    return what == 0 ? (p->flags & ST_ON) != 0 : what == 1 ? p->note : 1 + (p->chord[0] != 0) + (p->chord[1] != 0) + (p->chord[2] != 0);
}

/* ------------------------------------------------------------- WEFT: the patcher on the page --- */
#include "../../firmware/app/rv_weftdef.h"
void ui_weft_select(int b);
int ui_weft_selected(void);
void ui_weft_touch(int t, int pre);
void rv_weft_preset(int t, int k);
void rv_weft_block_defaults(int t, int i);
int rv_weft_presets(void);
const char *rv_weft_preset_name(int k);
/* a field of track t's patch: 0 type, 1 input A, 2 input B, 3 amount A, 4 amount B (block i, 0-11); 5 the output;
 * 6 KNOB i's setting (1 + 0-23, 0 none); 7 setting i (0-23); 8 voices (0: one, 1: two); 9 block i's B moves its
 * second setting (1) or does its own job (0) */
EXPORT int web_wf_get(int t, int f, int i)
{
    const rv_weft *w = &rv.weft[t & 7];
    int b = (unsigned)i % WF_BLOCKS;
    switch (f) {
    case 0: return w->type[b];
    case 1: return w->a[b];
    case 2: return w->b[b];
    case 3: return w->amta[b];
    case 4: return w->amtb[b];
    case 5: return w->out;
    case 6: return w->map[i & 3];
    case 7: return rv.tp[t & 7][wf_sp(i)];
    case 8: return rv.tp[t & 7][TP_POLY] > 0;
    case 9: return (w->bmove >> b) & 1;
    case 10: return w->run & 1;
    case 11: return (w->run >> 1) & 1;                   /* RATE: 0 FULL, 1 HALF */
    default: return 0;
    }
}
EXPORT void web_wf_set(int t, int f, int i, int v)
{
    rv_weft *w = &rv.weft[t & 7];
    int b = (unsigned)i % WF_BLOCKS;
    switch (f) {
    case 0:
        v = v < 0 || v >= WO_N ? 0 : v;
        if (w->type[b] != v) {
            w->type[b] = (uint8_t)v;
            w->bmove &= (uint16_t)~(1u << b);
            rv_weft_block_defaults(t, b);
            if (v && !w->out)
                w->out = WF_OUT_AUTO;
        }
        break;
    case 1: w->a[b] = (uint8_t)(v < 0 || v >= WS_N ? 0 : v); break;
    case 2: w->b[b] = (uint8_t)(v < 0 || v >= WS_N ? 0 : v); break;
    case 3: w->amta[b] = (int8_t)(v < -100 ? -100 : v > 100 ? 100 : v); break;
    case 4: w->amtb[b] = (int8_t)(v < -100 ? -100 : v > 100 ? 100 : v); break;
    case 5: w->out = (uint8_t)(v < 0 || v > WF_OUT_AUTO ? 0 : v); break;
    case 6: w->map[i & 3] = (uint8_t)(v < 0 || v > WF_SETS ? 0 : v); break;
    case 7: rv.tp[t & 7][wf_sp(i)] = (int16_t)(v < 0 ? 0 : v > 127 ? 127 : v); break;
    case 8: rv.tp[t & 7][TP_POLY] = (int16_t)(v ? 1 : 0); break;
    case 9: w->bmove = (uint16_t)(v ? w->bmove | (1u << b) : w->bmove & ~(1u << b)); break;
    case 10: w->run = (uint8_t)((w->run & ~1u) | (v ? 1u : 0u)); break;
    case 11: w->run = (uint8_t)((w->run & ~2u) | (v ? 2u : 0u)); break;
    default: return;
    }
    ui_weft_touch(t, -1);
}
EXPORT int web_wf_scope(int b, int k) { return rv_live.wscope[(unsigned)b % WF_BLOCKS][k & 31]; }
EXPORT void web_wf_watch(void) { rv_live.wf_view = 60; }   /* (the patcher shows the scopes) */
EXPORT int web_wf_voices(void) { return rv_live.wvoices; }
EXPORT int web_wf_ntypes(void) { return WO_N; }
EXPORT int web_wf_nsrc(void) { return WS_MENU; }
EXPORT int web_wf_nblocks(void) { return WF_BLOCKS; }
int rv_weft_outb(int t);
EXPORT int web_wf_outb(int t) { return rv_weft_outb(t); }   /* the block heard (OUT, or AUTO's), -1 none */
EXPORT const char *web_wf_type_name(int k) { return wf_types[(unsigned)k % WO_N].name; }
EXPORT const char *web_wf_desc(int k) { return wf_desc[(unsigned)k % WO_N]; }
/* what a type calls its settings (s 0, 1) and inputs (s 2: A, 3: B) */
EXPORT const char *web_wf_label(int k, int s)
{
    const wf_type_t *ty = &wf_types[(unsigned)k % WO_N];
    return s == 0 ? ty->p1 : s == 1 ? ty->p2 : s == 2 ? ty->a : ty->b;
}
/* a type's setting s (0, 1) as a list: how many names (0: a number 0-127), and name v */
EXPORT int web_wf_list_n(int k, int s) { return s ? wf_types[(unsigned)k % WO_N].m2 : wf_types[(unsigned)k % WO_N].m1; }
EXPORT const char *web_wf_list_name(int k, int s, int v)
{
    const wf_type_t *ty = &wf_types[(unsigned)k % WO_N];
    int m = s ? ty->m2 : ty->m1;
    return m ? (s ? ty->n2 : ty->n1)[(unsigned)v % (unsigned)m] : "";
}
EXPORT const char *web_wf_src_name(int s) { return wf_src_names[(unsigned)s % WS_N]; }
EXPORT int web_wf_npresets(void) { return rv_weft_presets(); }
EXPORT const char *web_wf_preset_name(int k) { return rv_weft_preset_name(k); }
EXPORT void web_wf_preset(int t, int k) { rv_weft_preset(t, k); ui_weft_touch(t, k); }
EXPORT void web_wf_select(int b) { ui_weft_select(b); }
EXPORT int web_wf_selected(void) { return ui_weft_selected(); }
