/* SPDX-License-Identifier: GPL-3.0-only */
/* Ravel: the sound bank. 32 of your own sounds, any kind (synth of any engine, strike, perc single
 * or a kit), each with a name, kept in their own flash slot beside the projects and shared by every
 * project. A sound is a track's voice: its kind and engine and all its sound settings, the CZ patch,
 * the kit's lanes; not its steps, sequencer settings or pan. Loading one into a track of another
 * kind turns the track into that kind. Kept in RAM outside the pool (RV_RAMBSS). */

#define RV_BANK_N 32                               /* sounds in a bank */
#define RV_BANKS PLAT_BANKS                        /* banks A..D */
#define RV_BANK_MAGIC 0x4B4E4252u                  /* "RBNK" */
#define RV_BANK_NAME 12

/* a sound: a CZ patch or a kit's lanes, never both (the one its kind and engine use) */
typedef struct {
    char name[RV_BANK_NAME];
    uint8_t used, kind, engine, rsv;
    int16_t tp[RV_TP];
    union { rv_cz cz; rv_kit kit; struct { rv_kit kit; uint8_t rate[RV_LANES]; } kr; rv_weft weft; } x;   /* kr: a kit with its lanes' rates (version 7); weft: a WEFT patch (its settings in tp) */
} rv_sound;
typedef struct {
    uint32_t magic, version;                       /* 10: HYBRID FM's pages; 9: WEFT's twelve blocks; 8: the SQ engine and SQ-80 filter gone; 7: kit lanes' rates; 6: 112 track parameters; 5: DRIVE's old default gone; 4: with STEP ENV; 3: with the FILTER ENV; 2: a bank of four; 1: the single first bank */
    rv_sound s[RV_BANK_N];
} rv_bank_t;
/* the first bank's old shape (version 1), read once to move it to bank A; and versions 2-5, with 96
 * track parameters a sound */
#define BANK_TP96 96
typedef struct {
    char name[RV_BANK_NAME];
    uint8_t used, kind, engine, rsv;
    int16_t tp[BANK_TP96];
    rv_cz cz;
    rv_kit kit;
} rv_sound_v1;
typedef struct { uint32_t magic, version; rv_sound_v1 s[RV_BANK_N]; } rv_bank_v1;
typedef struct {
    char name[RV_BANK_NAME];
    uint8_t used, kind, engine, rsv;
    int16_t tp[BANK_TP96];
    union { rv_cz cz; rv_kit kit; } x;
} rv_sound_96;
typedef struct { uint32_t magic, version; rv_sound_96 s[RV_BANK_N]; } rv_bank_96;
/* one bank in RAM at a time (outside the pool), with room to read the old ones */
static union { rv_bank_t b; rv_bank_v1 old; rv_bank_96 b96; } bankmem RV_RAMBSS;
#define bank bankmem.b
static uint8_t bank_cur, bank_dirty;               /* the bank in RAM; a name edited and not yet kept */
static uint8_t bank_bad;                           /* the bank in RAM could not be read (damaged, or from a newer
                                                     * firmware): shown empty, and never written, so it is not lost */

typedef char rv_weft_fits[sizeof(rv_weft) <= sizeof(rv_cz) ? 1 : -1];   /* (a WEFT patch shares the CZ's room in a sound) */
static int bank_is_kit(int kind, int engine) { return kind == KIND_PERC && engine == 1; }
static int bank_is_cz(int kind, int engine) { return kind == KIND_SYNTH && engine == ENG_CZ; }

/* the settings that make a sound (the rest belong to the track's place in the song) */
static int bank_sound_param(int p)
{
    switch (p) {
    case TP_PAN:
    case TP_LEN: case TP_RATE: case TP_DIR: case TP_INTERVAL: case TP_CLKSRC: case TP_BRANCH:
    case TP_H2ROLE: case TP_H2RATE: case TP_H2START: case TP_SEQMODE:
        return 0;
    default:                                       /* (the arpeggiator is the track's, as its steps are) */
        return !(p >= TP_H1ROLE && p <= TP_H2TRANS) && !(p >= TP_ARPMODE && p <= TP_ARPCHNC);
    }
}

static void bank_blank(void)
{
    __builtin_memset(&bankmem, 0, sizeof bankmem);
    bank.magic = RV_BANK_MAGIC;
    bank.version = 11;
}

/* a sound's track parameters past the 96 it was kept with: their defaults */
static void bank_tp_fill(int16_t *tp)
{
    int p;
    for (p = BANK_TP96; p < RV_TP; p++)
        tp[p] = (int16_t)(p < TP_N && TRACK[p].name ? TRACK[p].def : 0);
}

/* versions 2-5 (96 track parameters), in RAM as read: each sound spread out to today's size, from the
 * last so none is overwritten before it moves (a sound only grows) */
static void bank_from_96(void)
{
    int i;
    for (i = RV_BANK_N - 1; i >= 0; i--) {
        uint8_t *src = (uint8_t *)&bankmem.b96.s[i], *dst = (uint8_t *)&bank.s[i];
        int head = (int)((uint8_t *)&bankmem.b96.s[0].tp[0] - (uint8_t *)&bankmem.b96.s[0]);
        __builtin_memmove(dst + ((uint8_t *)&bank.s[0].x - (uint8_t *)&bank.s[0]), src + ((uint8_t *)&bankmem.b96.s[0].x - (uint8_t *)&bankmem.b96.s[0]), sizeof bankmem.b96.s[0].x);
        __builtin_memmove(dst, src, (unsigned)(head + BANK_TP96 * 2));
        bank_tp_fill(bank.s[i].tp);
    }
}

/* sounds kept before the FILTER ENV (version 2): theirs as their one envelope was; and before STEP
 * ENV (2, 3): it off */
static void bank_upgrade(void)
{
    int i;
    for (i = 0; i < RV_BANK_N; i++)
        if (bank.s[i].used) {
            if (bank.version < 3)
                rv_fenv_from_env(bank.s[i].tp);
            if (bank.version < 4) {
                bank.s[i].tp[TP_SEDST] = TP_CUT;
                bank.s[i].tp[TP_SEAMT] = 0;
                bank.s[i].tp[TP_SEDEF] = 0;
            }
            if (bank.version < 5 && bank.s[i].tp[TP_DRIVE] == 10)   /* the old default DRIVE: clean */
                bank.s[i].tp[TP_DRIVE] = 0;
            if (bank.version < 7 && bank_is_kit(bank.s[i].kind, bank.s[i].engine))   /* lanes at the track's rate */
                __builtin_memset(bank.s[i].x.kr.rate, 0, RV_LANES);
            if (bank.version < 8) {                  /* the SQ engine and the SQ-80 filter gone (format 21) */
                if (bank.s[i].kind == KIND_SYNTH) {
                    bank.s[i].engine = (uint8_t)rv_up21_engine(bank.s[i].engine);
                    bank.s[i].tp[TP_ENGINE] = (int16_t)rv_up21_engine(bank.s[i].tp[TP_ENGINE]);
                }
                bank.s[i].tp[TP_FTYPE] = (int16_t)rv_up21_ftype(bank.s[i].tp[TP_FTYPE]);
            }
            if (bank.version < 9 && bank.s[i].kind == KIND_WEFT) {   /* WEFT's twelve blocks (format 25) */
                uint8_t o[48];
                int p;
                __builtin_memcpy(o, &bank.s[i].x, sizeof o);
                rv_weft_from24(&bank.s[i].x.weft, o);
                for (p = TP_WX0; p <= TP_WX5; p++)
                    bank.s[i].tp[p] = 0;
            }
            if (bank.version < 11 && bank.s[i].kind == KIND_SYNTH && bank.s[i].tp[TP_ENGINE] == ENG_PIANO)
                rv_piano_from_fm(bank.s[i].tp);   /* (HYBRID FM gone: the PIANO in its place, format 28) */
        }
    bank.version = 11;
}

/* the old single bank, in RAM as version 1: reshaped in place into version 2 (each sound is
 * smaller and starts no later, so walking up never overwrites one not yet moved) */
static void bank_from_v1(void)
{
    int i;
    for (i = 0; i < RV_BANK_N; i++) {
        rv_sound_v1 o = bankmem.old.s[i];
        rv_sound *n = &bank.s[i];
        __builtin_memset(n, 0, sizeof *n);
        __builtin_memcpy(n->name, o.name, RV_BANK_NAME);
        n->used = o.used, n->kind = o.kind, n->engine = o.engine;
        __builtin_memcpy(n->tp, o.tp, sizeof o.tp);
        bank_tp_fill(n->tp);
        if (bank_is_kit(o.kind, o.engine))
            n->x.kit = o.kit;
        else
            n->x.cz = o.cz;
    }
    __builtin_memset((uint8_t *)&bankmem + sizeof bank, 0, sizeof bankmem - sizeof bank);
    bank.magic = RV_BANK_MAGIC;
    bank.version = 2;
    bank_upgrade();
}

static int bank_read(int b)                            /* 1 read; 0 not (bank_bad set if something was there) */
{
    int n = plat_load(PLAT_BANK0 + b, &bankmem, sizeof bankmem);
    bank_bad = 0;
    if (n < 0 && n != -3)
        return 0;                                      /* (nothing there: an empty bank, free to write) */
    bank_bad = 1;
    if (n < 0 || bank.magic != RV_BANK_MAGIC || bank.version < 2 || bank.version > 11)
        return 0;
    if (bank.version < 6) {                            /* 96 track parameters a sound: spread out */
        if (n != (int)sizeof(rv_bank_96))
            return 0;
        bank_from_96();
    } else if (n != (int)sizeof bank)
        return 0;
    bank_bad = 0;
    __builtin_memset((uint8_t *)&bankmem + sizeof bank, 0, sizeof bankmem - sizeof bank);
    if (bank.version < 11)                             /* (kept as version 11 the next time it is written) */
        bank_upgrade();
    return 1;
}

int rv_bank_flush(void)
{
    bank_dirty = 0;
    if (bank_bad)
        return -1;                                     /* (never over a bank that couldn't be read) */
    return plat_save(PLAT_BANK0 + bank_cur, &bank, sizeof bank);
}
int rv_bank_bad(void) { return bank_bad; }

/* bring bank b (0..3 = A..D) into RAM (a name edited in the one leaving is kept first) */
void rv_bank_select(int b)
{
    b = clampi(b, 0, RV_BANKS - 1);
    if (b == bank_cur)
        return;
    if (bank_dirty)
        rv_bank_flush();
    bank_cur = (uint8_t)b;
    if (!bank_read(b))
        bank_blank();
}
int rv_bank_current(void) { return bank_cur; }
void rv_bank_settle(void)                              /* a name being edited: kept now */
{
    if (bank_dirty)
        rv_bank_flush();
}
void rv_bank_reload(int slot)                          /* a bank written from outside: read again if it is the one in RAM */
{
    if (slot != PLAT_BANK0 + bank_cur)
        return;
    bank_dirty = 0;
    if (!bank_read(bank_cur))
        bank_blank();
}

void rv_bank_init(void)
{
    bank_cur = 0;
    if (bank_read(0))
        return;
    if (bank_bad) {                                    /* (A is there but unreadable: kept, not replaced) */
        bank_blank();
        return;
    }
    if (plat_load(PLAT_BANK_OLD, &bankmem.old, sizeof bankmem.old) == (int)sizeof bankmem.old &&
        bankmem.old.magic == RV_BANK_MAGIC && bankmem.old.version == 1) {
        bank_from_v1();                                /* the first bank moves to A */
        rv_bank_flush();
        return;
    }
    bank_blank();
}

int rv_bank_used(int i) { return i >= 0 && i < RV_BANK_N && bank.s[i].used; }
const char *rv_bank_name(int i) { return i >= 0 && i < RV_BANK_N ? bank.s[i].name : ""; }
int rv_bank_kind(int i) { return i >= 0 && i < RV_BANK_N ? bank.s[i].kind : 0; }
int rv_bank_engine(int i) { return i >= 0 && i < RV_BANK_N ? bank.s[i].engine : 0; }
int rv_bank_is_kit(int i) { return rv_bank_used(i) && bank_is_kit(bank.s[i].kind, bank.s[i].engine); }

/* a sound's kind, for lists: SYNTH, STRIKE, TAPE, PERC or KIT */
const char *rv_bank_kind_label(int i)
{
    static const char *const k[KIND_N] = {"SYNTH", "STRIKE", "TAPE", "PERC", "COMP", "GLITCH", "WEFT"};
    if (!rv_bank_used(i))
        return "";
    if (rv_bank_is_kit(i))
        return "KIT";
    return k[bank.s[i].kind % KIND_N];
}

/* keep track t's sound in slot i, named name (0: a name from the track's sound) */
int rv_bank_store(int t, int i, const char *name)
{
    rv_sound *s;
    int k;
    if (i < 0 || i >= RV_BANK_N || bank_bad)
        return -1;
    s = &bank.s[i];
    __builtin_memcpy(s->tp, rv.tp[t & 7], sizeof s->tp);
    if (bank_is_kit(rv.tp[t & 7][TP_KIND], rv.tp[t & 7][TP_ENGINE])) {
        s->x.kr.kit = rv.kit[t & 7];
        __builtin_memcpy(s->x.kr.rate, rv.kit_rate[t & 7], RV_LANES);
    } else if (rv.tp[t & 7][TP_KIND] == KIND_WEFT)
        s->x.weft = rv.weft[t & 7];
    else
        s->x.cz = rv.cz[t & 7];
    s->kind = (uint8_t)rv.tp[t & 7][TP_KIND];
    s->engine = (uint8_t)rv.tp[t & 7][TP_ENGINE];
    s->used = 1;
    if (name) {
        for (k = 0; k < RV_BANK_NAME - 1 && name[k]; k++)
            s->name[k] = name[k];
        for (; k < RV_BANK_NAME; k++)
            s->name[k] = 0;
    }
    return rv_bank_flush();
}

/* put slot i's sound on track t (its kind with it); the caller has dealt with steps that a change
 * between a kit and notes would make meaningless */
int rv_bank_apply(int t, int i)
{
    const rv_sound *s;
    int p, was_kit = bank_is_kit(rv.tp[t & 7][TP_KIND], rv.tp[t & 7][TP_ENGINE]);
    if (!rv_bank_used(i))
        return -1;
    s = &bank.s[i];
    if (s->kind == KIND_TAPE || s->kind >= KIND_N)   /* (a tape sound, saved before the tape left, or a kind from a
                                                      * newer build: nothing to load) */
        return -1;
    if (s->kind == KIND_COMP && (t & 7) != 7)        /* the compressor lives on T8 */
        return -1;
    rv_all_off();
    for (p = 0; p < TP_N; p++)
        if (bank_sound_param(p))
            rv.tp[t & 7][p] = s->tp[p];
    if (bank_is_kit(s->kind, s->engine)) {
        rv.kit[t & 7] = s->x.kr.kit;
        __builtin_memcpy(rv.kit_rate[t & 7], s->x.kr.rate, RV_LANES);
    } else if (bank_is_cz(s->kind, s->engine))
        rv.cz[t & 7] = s->x.cz;
    else if (s->kind == KIND_WEFT)
        rv.weft[t & 7] = s->x.weft;
    if (was_kit != bank_is_kit(s->kind, s->engine)) {  /* lanes and notes don't read each other's steps */
        int pt = rv.pat_cur[t & 7];
        for (rv.pat_cur[t & 7] = 0; rv.pat_cur[t & 7] < RV_PATTERNS; rv.pat_cur[t & 7]++)
            rv_pattern_clear(t);
        rv.pat_cur[t & 7] = (uint8_t)pt;
    }
    return 0;
}

int rv_bank_clear(int i)
{
    if (i < 0 || i >= RV_BANK_N || bank_bad)
        return -1;
    __builtin_memset(&bank.s[i], 0, sizeof bank.s[i]);
    return rv_bank_flush();
}

/* naming: the characters a name can use, and one character set in place (no flash write: the
 * caller flushes when the naming pauses) */
static const char bank_chars[] = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-+#&'.";
int rv_bank_char_index(char c)
{
    int k;
    for (k = 0; bank_chars[k]; k++)
        if (bank_chars[k] == c)
            return k;
    return 0;
}
int rv_bank_nchars(void) { return (int)sizeof bank_chars - 1; }
void rv_bank_set_char(int i, int pos, int ci)
{
    int k;
    if (!rv_bank_used(i) || pos < 0 || pos >= RV_BANK_NAME - 1)
        return;
    for (k = 0; k < pos; k++)                          /* (no holes before the cursor) */
        if (!bank.s[i].name[k])
            bank.s[i].name[k] = ' ';
    bank.s[i].name[pos] = bank_chars[clampi(ci, 0, rv_bank_nchars() - 1)];
    bank_dirty = 1;
    for (k = RV_BANK_NAME - 2; k >= 0 && (bank.s[i].name[k] == ' ' || !bank.s[i].name[k]); k--)
        bank.s[i].name[k] = 0;                         /* trailing spaces go */
}
