/* SPDX-License-Identifier: GPL-3.0-only */
/* Ravel: the whole instrument as one unit (the modules share their statics). The platform
 * (plat.h) and the Beads port (core/beads) are built beside it. */
#include "rv_params.c"
#include "rv_synth.c"
#include "rv_strike.c"
#include "rv_perc.c"
#include "rv_mod.c"
#include "rv_bus.c"
#include "rv_seq.c"
#include "rv_loop.c"
#include "rv_weft.c"
#include "rv_engine.c"
#include "rv_presets.c"
#include "rv_project.c"
#include "rv_bank.c"
#include "rv_xfer.c"
#include "rv_stress.c"
/* the interface and the start screen run beside the sound, not in it: on the FM-1 they are meant to be built for
 * size (the flash is nearly full), the drawing primitives (rv_gfx.c) excepted. (The FM-1's clang 4 ignores this
 * pragma; its largest functions are marked RV_SMALL by hand: draw_picture, ui_frame, ui_input_only, knob_turn) */
#if defined(RV_FM1) && defined(__clang__)
#pragma clang attribute push(__attribute__((minsize)), apply_to = function)
#define RV_UI_MINSIZE 1
#endif
#include "rv_ui.c"
#include "rv_intro.c"
#ifdef RV_UI_MINSIZE
#pragma clang attribute pop
#endif

/* start: a blank project, then the last one saved or loaded (SONG > PANEL: START WITH) */
void ravel_start(void)
{
    rv_demo(2);                     /* a blank project; saved ones stay in their slots (SAVE > LOAD) */
    rv_engine_init();
    rv_bank_init();                 /* your sounds (SAVE > SOUNDS) */
    ui_init();
    ui_open_last();                 /* the last project, if PANEL > START WITH is LAST (not after a reset) */
}
