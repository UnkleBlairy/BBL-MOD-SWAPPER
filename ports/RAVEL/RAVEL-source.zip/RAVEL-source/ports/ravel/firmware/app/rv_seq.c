/* SPDX-License-Identifier: GPL-3.0-only */
/* Ravel: the sequencer. Every track has its own pattern, length, rate, direction (forward,
 * reverse, ping-pong, snake, or Silt's graph: cords say where the playhead goes next) and clock
 * (the master, an LFO, dust, or another track through an influence CLOCK route: René-style).
 * Steps carry note, velocity, length, chance, microtiming, ratchets, a condition, two parameter
 * locks, a library articulation, a microcut and graph cords. Scenes and the arrangement switch
 * patterns on the bar; drawn density arcs thin a part out without new patterns.
 * Part of the engine unit (ravel_app.c). */
#include "rv_int.h"

static event_t evq[RV_EVQ] RV_RAMBSS;            /* (in plain RAM: the pool keeps room for the render's code) */
static int evn;
static uint32_t now_s;                              /* the sample clock: samples since boot */
static void loop_fire(int t, int si);               /* (rv_loop.c: a LOOP track's step) */
static seqtrk_t sq[RV_TRACKS];
static uint8_t playing;
static uint32_t mpulse;                             /* master pulses since start */
static float mpulse_f;
static int8_t pend_scene = -1, pend_pat[RV_TRACKS];
static uint8_t song_ended;
static void seq_stop(void);
static uint8_t arr_row, arr_bar_left;
static uint32_t song_bar;
static uint8_t fill_on;
static uint32_t seq_rng = 0x5EED5EEDu;
static uint64_t turn_bits[RV_TRACKS];
/* the metronome's click: when, how loud, a downbeat or not (rv_engine.c plays it) */
static uint32_t click_when;
static float click_amp;
static uint8_t click_down, click_armed;
static int countin_left;                             /* pulses of count-in still to come */

static void click_at(uint32_t when, int down, int countin)
{
    int m = rv.gp[GP_METRO];
    if (!m && !countin)
        return;
    click_when = when;
    click_amp = m == 2 ? 0.32f : 0.14f;
    click_down = (uint8_t)down;
    click_armed = 1;
}


/* ------------------------------------------------- graph mode and heads --- */
static int is_kit(int t) { return rv.tp[t][TP_KIND] == KIND_PERC && rv.tp[t][TP_ENGINE] == 1; }   /* a PERC kit */
static int is_graph(int t) { return !is_kit(t) && (rv.tp[t][TP_SEQMODE] == SEQ_GRAPH || rv.tp[t][TP_DIR] == DIR_GRAPH); }
/* the matrix in the sequence: LENGTH as modulation moves it (the knob's until the first block is worked out),
 * and HITS and ROTATE (sq_mod), which change what the steps play, never the steps */
static int seq_len(int t)
{
    float e = trk[t].eff[TP_LEN];
    return e >= 0.5f ? clampi((int)(e + 0.5f), 1, RV_STEPS) : clampi(rv.tp[t][TP_LEN], 1, RV_STEPS);
}
static int sqm_int(float x) { return (int)(x < 0.0f ? x - 0.5f : x + 0.5f); }
static int sqm_on(int t) { return sqm_int(sq_mod[t][SQM_HITS]) != 0 || sqm_int(sq_mod[t][SQM_ROT]) != 0; }
static rv_step sqm_dflt;                          /* a hit where the pattern has no note to lend it */
/* the step that plays at place si of len (lane: a kit's lane, -1: a track's): ROTATE turns the pattern; HITS
 * makes it a euclidean pattern of as many more or fewer hits as it has (the first on place 1, turned with it),
 * each hit playing its own step, or the last one before it that plays (a kit: each lane its own, a lane with
 * none left silent). 0: nothing plays here */
static RV_SMALL rv_step *sqm_step(int t, int si, int len, int lane, int *at)
{
    rv_pattern *pt = &rv.pat[t][rv.pat_cur[t] % RV_PATTERNS];
    int rot = sqm_int(sq_mod[t][SQM_ROT]), dh = sqm_int(sq_mod[t][SQM_HITS]), j, i, n = 0, h;
    uint8_t bit = (uint8_t)(lane >= 0 ? 1u << lane : 0u);
#define SQM_PLAYS(q) (((q)->flags & ST_ON) && (lane < 0 || ((q)->note & bit)))
    rot = ((rot % len) + len) % len;
    j = ((si % len) - rot + len) % len;
    *at = j;
    if (!dh)
        return &pt->s[j];
    for (i = 0; i < len; i++)
        n += SQM_PLAYS(&pt->s[i]) ? 1 : 0;
    if (lane >= 0 && n == 0)                          /* (a kit's silent lane stays silent) */
        return 0;
    h = clampi(n + dh, 0, len);
    if (h <= 0 || (j * h) % len >= h)
        return 0;
    for (i = 0; i < len; i++) {
        rv_step *q = &pt->s[(j - i + len) % len];
        if (SQM_PLAYS(q)) {
            *at = (j - i + len) % len;
            return q;
        }
    }
#undef SQM_PLAYS
    __builtin_memset(&sqm_dflt, 0, sizeof sqm_dflt);
    sqm_dflt.flags = ST_ON;
    sqm_dflt.note = (uint8_t)(lane >= 0 ? 63 : 60);
    sqm_dflt.vel = 100;
    sqm_dflt.chance = 100;
    sqm_dflt.len = 8;
    return &sqm_dflt;
}
/* HEAD 2 picks the pair: OFF or NOTES (head 1 plays notes too), MELODY (head 2 sets the pitch,
 * head 1 plays it: ROLE_PITCH) or RHYTHM (head 2 plays head 1's pitches: ROLE_GATE). Head 1's role
 * follows, so no setting leaves the track silent. */
static int head_role(int t, int h)
{
    int r2 = is_graph(t) ? clampi(rv.tp[t][TP_H2ROLE], 0, 3) : ROLE_OFF;
    if (h == 1)
        return r2;
    return r2 == ROLE_PITCH ? ROLE_GATE : r2 == ROLE_GATE ? ROLE_PITCH : ROLE_NOTES;
}
static const float head_rates[9] = {0.25f, 0.3333f, 0.5f, 0.6667f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f};

/* a head's function generator (Silt's traversal shape): 0..1 over CYCLE steps travelled, or a
 * modulator's level */
static float fg_value(int t, int h, float *pos)
{
    int shape = clampi(rv.tp[t][h ? TP_H2SHAPE : TP_H1SHAPE], 0, FG_N - 1);
    int cyc = clampi(rv.tp[t][h ? TP_H2CYCLE : TP_H1CYCLE], 2, 64);
    float u = (float)(sq[t].travelled[h] % (uint32_t)cyc) / (float)cyc;
    *pos = u;
    switch (shape) {
    case FG_RISE: return u;
    case FG_FALL: return 1.0f - u;
    case FG_ARCH: return sin_lut(u * 0.5f);
    case FG_DECAY: return fm_expf(-8.0f * u);
    case FG_SWELL: return 0.5f - 0.5f * sin_lut(u + 0.25f);
    case FG_LFO1: return 0.5f + 0.5f * lfo[0].value;
    case FG_LFO2: return 0.5f + 0.5f * lfo[1].value;
    case FG_DUST: return clampf(dust_v, 0.0f, 1.0f);
    default: return 0.0f;
    }
}

/* a head's rate now, in steps per master clock pulse: its RATE, moved by its function generator,
 * either times the clock (x CLOCK: up to two octaves faster or slower) or plus it (+ CLOCK) */
static float head_rate(int t, int h)
{
    float r = head_rates[clampi(rv.tp[t][h ? TP_H2RATE : TP_RATE], 0, 8)], pos, v, d;
    int shape = rv.tp[t][h ? TP_H2SHAPE : TP_H1SHAPE];
    if (!is_graph(t) || shape == FG_OFF) {
        rv_live.fg[t][h] = 0.0f;
        rv_live.fg_rate[t][h] = r;
        return r;
    }
    v = fg_value(t, h, &pos);
    d = rv.tp[t][h ? TP_H2DEPTH : TP_H1DEPTH] * (1.0f / 64.0f);
    if (rv.tp[t][h ? TP_H2COMB : TP_H1COMB] == COMB_ADD)
        r = r + d * v * 2.0f;
    else
        r = r * fm_exp2f(d * v * 2.0f);
    r = clampf(r, 0.03f, 8.0f);
    rv_live.fg[t][h] = v;
    rv_live.fg_pos[t][h] = pos;
    rv_live.fg_rate[t][h] = r;
    return r;
}
#define LATENCY_TICKS 6                             /* sequenced notes sound 6/24 step late: room for early micro */

static void infl_fire(int a, int note, int vel, uint16_t chain, uint32_t when);
static void note_on_internal(int t, int note, int vel, int env, uint16_t chain);
static void note_off_internal(int t, int note);
static void all_off_now(void);
static void hs_move(int rmv, int kit);              /* (rv_engine.c) a ratchet repeat's R MOVE, for the next note */
static uint8_t spark_pend;

#ifndef RV_FM1
uint32_t rv_dbg_ons[RV_TRACKS];                    /* (the desktop builds: notes the sequencer started, for the tests) */
#endif
static void ev_push(const event_t *e)               /* (the last 16 places: note-offs only, so a queue
                                                     * that fills up never keeps a note that has sounded) */
{
#ifndef RV_FM1
    if (e->type == EV_ON)
        rv_dbg_ons[e->track & 7]++;
#endif
    if (evn < (e->type == EV_OFF || e->type == EV_AOFF ? RV_EVQ : RV_EVQ - 16))
        evq[evn++] = *e;
}

static float step_seconds(int t)
{
    static const float rates[9] = {0.25f, 0.3333f, 0.5f, 0.6667f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f};
    return clk_period / rates[clampi(rv.tp[t][TP_RATE], 0, 8)];
}

static int pattern_empty(int t)
{
    int i;
    const rv_pattern *p = &rv.pat[t][rv.pat_cur[t] % RV_PATTERNS];
    for (i = 0; i < RV_STEPS; i++)
        if (p->s[i].flags & ST_ON)
            return 0;
    return 1;
}

/* a step's rank in its bar, downbeats first: what density arcs thin out last */
static int step_rank(int si)
{
    int r = si & 15;
    return ((r & 1) << 3) | ((r & 2) << 1) | ((r & 4) >> 1) | ((r & 8) >> 3);
}

static const uint16_t scale_masks[12] = {0xFFF, 0xAB5, 0x5AD, 0x6AD, 0x5AB, 0xAD5, 0x6B5, 0x295, 0x4A9, 0x555, 0x18D, 0x463};

static int in_scale(int n)
{
    int sc = clampi(rv.gp[GP_SCALE], 0, 11), root = clampi(rv.gp[GP_ROOT], 0, 11);
    int k = ((n - root) % 12 + 12) % 12;
    return (scale_masks[sc] >> k) & 1u;              /* the masks hold C in bit 0 */
}

/* the nearest note of the scale (a tie goes down) */
int rv_quantize_note(int n)
{
    int d;
    if (clampi(rv.gp[GP_SCALE], 0, 11) == 0)
        return n;
    for (d = 0; d < 7; d++) {
        if (in_scale(n - d))
            return n - d;
        if (in_scale(n + d + 1) && !in_scale(n - d - 1))
            return n + d + 1;
    }
    return n;
}

/* the keys, folded (as Elektron's fold): with a scale set, key k plays the k-th scale note from
 * the first one at or above the keyboard's lowest key, so every key plays and none is out */
int rv_fold_key(int base, int k)
{
    int n = base, i;
    if (clampi(rv.gp[GP_SCALE], 0, 11) == 0)
        return base + k;
    while (!in_scale(n))
        n++;
    for (i = 0; i < k; i++)
        do
            n++;
        while (!in_scale(n));
    return n;
}

/* ------------------------------------------------------------- CHANCE --- */
/* A track's phrase, generated (after Mutable Instruments' Marbles: the rhythm and the notes decided by chance, and
 * remembered, so that what happened by accident can come round again). Up to 16 steps, each with a rhythm (a note
 * or a rest, its accent, ratchet and timing) and a note (a degree of the song's scale, from CENTER). Each time
 * the playhead comes to a step it plays what it remembers, or, as MEMORY allows, decides again: DRIFT says how
 * far (a small change, or a new choice); LOCK holds the notes, the rhythm or both. A new note walks from the last
 * one (mostly near it, now and then a leap, pulled back toward CENTER over RANGE); a step's chance of a note is
 * DENS, weighted by FEEL. The notes are degrees, so a change of key or scale keeps the phrase's shape. The memory
 * is in RAM, not the project (REC + SAVE writes the phrase into the track's steps); the settings are the track's */
#define CH_N 16
typedef struct {
    int8_t deg[CH_N], mic[CH_N];              /* each step: its degree (from CENTER), its timing (ticks) */
    uint8_t on[CH_N], vel[CH_N], rat[CH_N];   /* a note or a rest, its velocity, its ratchet (count - 1) */
    uint8_t got[CH_N];                        /* decided yet: bit 0 the rhythm, bit 1 the note */
    int8_t last, pos;                         /* the degree last played; the step now */
    uint32_t rng;
} chance_t;
#ifdef RV_FM1
static chance_t chs[RV_TRACKS] ;   /* (outside the RAM the sound needs; ch_ok says if it holds anything) */
#else
static chance_t chs[RV_TRACKS];
#endif
static uint8_t ch_ok[RV_TRACKS];
static rv_step ch_step;                           /* the step CHANCE plays now, as an ordinary step */
static const uint8_t ch_feel[4][CH_N] = {         /* FEEL: how likely a note is at each place in the bar (tenths) */
    {14, 7, 10, 7, 14, 7, 10, 7, 14, 7, 10, 7, 14, 7, 10, 7},          /* EVEN: on the beats */
    {8, 6, 14, 6, 8, 6, 14, 6, 8, 6, 14, 6, 8, 6, 14, 6},             /* OFFBEAT: between them */
    {15, 6, 8, 14, 6, 8, 14, 6, 12, 6, 8, 14, 6, 8, 12, 7},           /* SYNCOP: 3 + 3 + 2 */
    {10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10}};  /* FREE */

static int is_chance(int t)
{
    return !is_kit(t) && rv.tp[t][TP_KIND] != KIND_LOOP && rv.tp[t][TP_SEQMODE] == SEQ_CHANCE && rv.tp[t][TP_DIR] != DIR_GRAPH;
}
static int ch_set(int t, int k) { float e = trk[t].eff[TP_H1ROLE + k]; return k == CH_FEEL || k == CH_LOCK ? rv.tp[t][TP_H1ROLE + k] : sqm_int(e); }   /* (as modulation moves them) */
static float ch_u(chance_t *c) { return xs_uni(&c->rng); }

/* a degree of the song's scale from the root at middle C (signed: down as well as up) */
static RV_SMALL int ch_note(int d)
{
    int n = 60 + clampi(rv.gp[GP_ROOT], 0, 11), i;
    d = clampi(d, -36, 36);
    if (clampi(rv.gp[GP_SCALE], 0, 11) == 0)
        return clampi(n + d, 0, 127);
    for (i = 0; i < d; i++)
        do
            n++;
        while (!in_scale(n));
    for (i = 0; i > d; i--)
        do
            n--;
        while (!in_scale(n));
    return clampi(n, 0, 127);
}

static RV_SMALL chance_t *ch_get(int t)
{
    chance_t *c = &chs[t & 7];
    if (!ch_ok[t & 7]) {                              /* (a new phrase: nothing decided) */
        __builtin_memset(c, 0, sizeof *c);
        c->pos = -1;
        c->rng = 0x9E3779B9u ^ ((uint32_t)(t + 1) * 0x85EBCA6Bu) ^ xs32(&seq_rng);
        ch_ok[t & 7] = 1;
    }
    return c;
}

/* step i's rhythm: fresh, a note or a rest by DENS and FEEL; either way its accent, ratchet and timing again */
static RV_SMALL void ch_rhythm(chance_t *c, int t, int i, int fresh)
{
    float w = (float)ch_feel[clampi(ch_set(t, CH_FEEL), 0, 3)][i] * 0.1f, dens = (float)ch_set(t, CH_DENS) * (1.0f / 127.0f);
    if (fresh)
        c->on[i] = (uint8_t)(dens >= 0.999f || ch_u(c) < dens * w);
    c->vel[i] = (uint8_t)(w >= 1.2f && ch_u(c) * 127.0f < (float)ch_set(t, CH_ACCENT) ? 124 : 78 + (int)(ch_u(c) * 30.0f));
    c->rat[i] = (uint8_t)(ch_u(c) * 254.0f < (float)ch_set(t, CH_RATCHET) ? (ch_u(c) < 0.7f ? 1 : 2) : 0);
    c->mic[i] = (int8_t)((ch_u(c) * 2.0f - 1.0f) * (float)ch_set(t, CH_JITTER) * (8.0f / 127.0f));
}

/* step i's note: fresh, a step of the walk from the last note (a repeat, a step, two, now and then a leap; RANGE
 * wider, pulled toward CENTER); or a nudge, a degree up or down from what it was */
static RV_SMALL void ch_pitch(chance_t *c, int t, int i, int fresh)
{
    float rg = (float)ch_set(t, CH_RANGE) * (1.0f / 127.0f), r, pull;
    int span = 1 + (int)(rg * 13.0f + 0.5f), from = fresh ? c->last : c->deg[i], mag = 1, d;
    if (fresh) {
        r = ch_u(c);
        mag = r < 0.25f ? 0 : r < 0.65f ? 1 : r < 0.87f ? 2 : 3 + (int)(ch_u(c) * 3.0f);
        mag = (int)((float)mag * (0.4f + 1.6f * rg) + 0.5f);
    }
    pull = clampf((float)-from / (float)span, -1.0f, 1.0f);
    d = from + (ch_u(c) < 0.5f + 0.45f * pull ? mag : -mag);
    if (d > span)                                     /* (off the edge of RANGE: back in) */
        d = 2 * span - d;
    if (d < -span)
        d = -2 * span - d;
    c->deg[i] = (int8_t)clampi(d, -span, span);
}

/* the playhead moves on: decide what it must, and set ch_step to play */
static RV_SMALL int chance_advance(int t)
{
    chance_t *c = ch_get(t);
    int len = clampi(ch_set(t, CH_LENGTH), 1, CH_N), lock = clampi(ch_set(t, CH_LOCK), 0, 3), i;
    float mem = (float)ch_set(t, CH_MEMORY) * (1.0f / 127.0f), drift = (float)ch_set(t, CH_DRIFT) * (1.0f / 127.0f);
    i = c->pos + 1 >= len ? 0 : c->pos + 1;
    c->pos = (int8_t)i;
    if (!(c->got[i] & 1))
        ch_rhythm(c, t, i, 1);
    else if (!(lock & 2) && ch_u(c) >= mem)
        ch_rhythm(c, t, i, ch_u(c) < drift);
    if (!(c->got[i] & 2))
        ch_pitch(c, t, i, 1);
    else if (!(lock & 1) && ch_u(c) >= mem)
        ch_pitch(c, t, i, ch_u(c) < drift);
    c->got[i] = 3;
    __builtin_memset(&ch_step, 0, sizeof ch_step);
    ch_step.flags = c->on[i] ? ST_ON : 0;
    ch_step.note = (uint8_t)ch_note(c->deg[i] + clampi(ch_set(t, CH_CENTER), -14, 14));
    ch_step.vel = c->vel[i];
    ch_step.len = (uint8_t)(1 + ch_set(t, CH_GATE) * 23 / 127);   /* (eighths of a step: to three steps) */
    ch_step.chance = 100;
    ch_step.micro = c->mic[i];
    ch_step.ratchet = c->rat[i];
    if (c->on[i])
        c->last = c->deg[i];
    return i;
}

/* for the page and REC: a new phrase, a few steps decided again, what step i holds */
void rv_chance_new(int t) { ch_ok[t & 7] = 0; }
RV_SMALL void rv_chance_mutate(int t)
{
    chance_t *c = ch_get(t);
    int k, len = clampi(ch_set(t, CH_LENGTH), 1, CH_N);
    for (k = 0; k < 3; k++) {
        int i = (int)(ch_u(c) * (float)len) % len;
        ch_rhythm(c, t, i, 1);
        ch_pitch(c, t, i, 1);
        c->got[i] = 3;
    }
}
int rv_chance_pos(int t) { return ch_ok[t & 7] && is_chance(t) ? chs[t & 7].pos : -1; }
/* -1: not decided yet; 0: a rest; 1: a note (*note its MIDI note before the song's transposition, *deg its degree) */
RV_SMALL int rv_chance_peek(int t, int i, int *note, int *deg, int *vel)
{
    chance_t *c = &chs[t & 7];
    if (!ch_ok[t & 7] || i < 0 || i >= CH_N || !(c->got[i] & 3))
        return -1;
    *deg = c->deg[i];
    *note = ch_note(c->deg[i] + clampi(ch_set(t, CH_CENTER), -14, 14));
    *vel = c->vel[i];
    return c->on[i];
}
RV_SMALL int rv_chance_step(int t, int i, rv_step *o)   /* step i as an ordinary step (REC + SAVE); 0: not decided */
{
    chance_t *c = &chs[t & 7];
    if (!ch_ok[t & 7] || i < 0 || i >= CH_N || !(c->got[i] & 3))
        return 0;
    __builtin_memset(o, 0, sizeof *o);
    o->flags = c->on[i] ? ST_ON : 0;
    o->note = (uint8_t)ch_note(c->deg[i] + clampi(ch_set(t, CH_CENTER), -14, 14));
    o->vel = c->on[i] ? c->vel[i] : 100;
    o->len = (uint8_t)(1 + ch_set(t, CH_GATE) * 23 / 127);
    o->chance = 100;
    o->micro = c->mic[i];
    o->ratchet = c->rat[i];
    return 1;
}

static int cond_pass(const rv_step *s, int t)
{
    uint32_t p = sq[t].passes;
    switch (s->cond) {
    case 0: return 1;
    case 1: return p == 0;
    case 2: return p != 0;
    case 3: return p % 2 == 0;
    case 4: return p % 2 == 1;
    case 5: return p % 3 == 0;
    case 6: return p % 3 == 1;
    case 7: return p % 3 == 2;
    case 8: return p % 4 == 0;
    case 9: return p % 4 == 1;
    case 10: return p % 4 == 2;
    case 11: return p % 4 == 3;
    case 12: return fill_on;
    case 13: return !fill_on;
    default: return 1;
    }
}

/* the step a head goes to next */
static int next_step(int t, int h, int cur)
{
    int len = is_graph(t) ? clampi(rv.tp[t][TP_LEN], 1, RV_STEPS) : seq_len(t), dir = is_graph(t) ? DIR_GRAPH : clampi(rv.tp[t][TP_DIR], 0, DIR_N - 1), n;
    seqtrk_t *s = &sq[t];
    if (cur < 0) {                                  /* the first step */
        if (h == 1)
            return clampi(rv.tp[t][TP_H2START] - 1, 0, len - 1);
        return dir == DIR_REV ? len - 1 : 0;
    }
    switch (dir) {
    case DIR_REV:
        n = cur - 1;
        if (n < 0) {
            n = len - 1;
            if (h == 0)
                s->passes++;
        }
        return n;
    case DIR_PING:
        if (s->dir[h] == 0)
            s->dir[h] = 1;
        n = cur + s->dir[h];
        if (n >= len || n < 0) {
            s->dir[h] = (int8_t)-s->dir[h];
            n = cur + s->dir[h];
            if (n < 0)
                n = 0;
            if (n >= len)
                n = len - 1;
            if (h == 0 && s->dir[h] > 0)
                s->passes++;
        }
        return n;
    case DIR_SNAKE: {
        /* steps as rows of four, walked like a snake: the playhead position k maps to a step */
        int k = 0, r, c;
        for (k = 0; k < len; k++) {
            r = k / 4;
            c = k % 4;
            if (r * 4 + ((r & 1) ? 3 - c : c) == cur)
                break;
        }
        k++;
        if (k >= len) {
            k = 0;
            if (h == 0)
                s->passes++;
        }
        r = k / 4;
        c = k % 4;
        n = r * 4 + ((r & 1) ? 3 - c : c);
        return n < len ? n : k;
    }
    case DIR_GRAPH: {
        const rv_step *st = &rv.pat[t][rv.pat_cur[t] % RV_PATTERNS].s[cur];
        int a = st->to[0] && st->to[0] <= len ? st->to[0] - 1 : (cur + 1) % len;   /* past LENGTH: NEXT */
        n = a;
        if (st->to[1] && st->to[1] <= len) {
            int take2 = 0, br = clampi(rv.tp[t][TP_BRANCH], 0, 4);
            if (br == 0)
                take2 = xs_uni(&seq_rng) < 0.5f;
            else if (br == 1) {
                turn_bits[t] ^= (uint64_t)1 << cur;
                take2 = (int)((turn_bits[t] >> cur) & 1u);
            } else if (br <= 3)
                take2 = lfo[br - 2].value > 0.0f;
            else {                                   /* MOTION: the head's function generator */
                float pos;
                take2 = fg_value(t, h, &pos) > 0.5f;
            }
            if (take2)
                n = st->to[1] - 1;
        }
        n = clampi(n, 0, len - 1);
        if (n <= cur && h == 0 && n == 0)
            s->passes++;
        return n;
    }
    default:
        n = cur + 1;
        if (n >= len) {
            n = 0;
            if (h == 0)
                s->passes++;
        }
        return n;
    }
}

/* where in its step a ratchet's repeat k of cnt falls (0..1): EVEN, FASTER, SLOWER, or BOUNCE, the
 * gaps shrinking like a dropped ball's */
static float rat_pos(int curve, int k, int cnt)
{
    float u = (float)k / (float)cnt;
    if (curve == 1)
        return fm_powf(u, 0.6f);
    if (curve == 2)
        return fm_powf(u, 1.6f);
    if (curve == 3)
        return (1.0f - fm_powf(0.72f, (float)k)) / (1.0f - fm_powf(0.72f, (float)cnt));
    return u;
}
/* a repeat's loudness: the fade (bit 5) or a bounce dies away */
static float rat_vel(const rv_step *s, int k, int cnt)
{
    if (((s->ratchet >> 3) & 3) == 3)
        return fm_powf(0.8f, (float)k);
    return (s->ratchet & 32) && cnt > 1 ? 1.0f - 0.6f * (float)k / (float)cnt : 1.0f;
}
/* a note k steps of the scale up (or down), for R MOVE */
static int scale_walk(int note, int k)
{
    int j, d = k > 0 ? 1 : -1;
    for (j = 0; j != k; j += d) {
        int m = note + d, guard = 0;
        while (rv_quantize_note(m) == note && guard++ < 12)
            m += d;
        note = clampi(rv_quantize_note(m), 0, 127);
    }
    return note;
}

/* a step plays: locks, then notes (with ratchets), jumps and cuts, all scheduled */
/* a KIT's step: each lane reads its own step (a lane with its own LENGTH runs against the others),
 * a step holds which lanes play (note: a bit per lane), which are accented (env) and which ratchet
 * (len); velocity, chance, timing and conditions belong to the step, and each lane adds its chance */
static void kit_fire(int t, int si, uint32_t when)
{
    const rv_kit *k = &rv.kit[t];
    rv_pattern *pt = &rv.pat[t][rv.pat_cur[t] % RV_PATTERNS];
    int tlen = seq_len(t), l, r, sqm = sqm_on(t);
    float sd = step_seconds(t), tick = sd * (1.0f / 24.0f), quant;
    float density = rv.arcs[t][(song_bar >> clampi(rv.gp[GP_ARCSPAN], 0, 2)) & 15];
    for (l = 0; l < RV_LANES; l++) {
        /* the lane's QUANTZE, or the song's */
        int lq = rv.kit_quant[t][l];
        quant = (float)(lq ? clampi(lq - 1, 0, 100) : rv.gp[GP_QUANT]) * 0.01f;
        /* the lane's rate against the track's (num / den): in this track step it plays the lane steps
         * that fall in it, each at its own time; at the track's rate, just this step */
        static const uint8_t num[9] = {1, 1, 1, 2, 1, 3, 2, 3, 4}, den[9] = {4, 3, 2, 3, 1, 2, 1, 1, 1};
        int ri = RV_LRATE_KNOB(rv.kit_rate[t][l] % 9), len = k->len[l] ? clampi(k->len[l], 1, RV_STEPS) : tlen;
        uint32_t n = sq[t].travelled[0] - 1u, k0, k1, kk;
        if (ri == 4) {
            k0 = n;
            k1 = n + 1u;
        } else {
            k0 = (n * num[ri] + den[ri] - 1u) / den[ri];
            k1 = ((n + 1u) * num[ri] + den[ri] - 1u) / den[ri];
        }
        for (kk = k0; kk < k1; kk++) {
        int li, cnt, curve, sw;
        const rv_step *s;
        float chance, lofs = ri == 4 ? 0.0f : ((float)(kk * den[ri]) / (float)num[ri] - (float)n) * sd;
        event_t e;
        li = ri == 4 && len == tlen ? si : (int)(kk % (uint32_t)len);
        rv_live.lane_step[t][l] = (int8_t)li;
        s = &pt->s[li];
        if (sqm) {                                    /* the matrix's HITS or ROTATE: what plays here */
            s = sqm_step(t, li, len, l, &li);
            if (!s)
                continue;
        }
        if (!(s->flags & ST_ON) || !((s->note >> l) & 1))
            continue;
        if (!cond_pass(s, t))
            continue;
        chance = (float)s->chance * (float)k->chance[l] * 0.01f;
        if (chance < 100.0f && xs_uni(&seq_rng) * 100.0f >= chance)
            continue;
        if (density < 100 && (float)step_rank(li) >= density * 0.16f)
            continue;
        sw = (kk & 1u) ? rv.gp[GP_SWING] - 50 : 0;    /* the offbeat in time, not the step's number */
        e.when = when + (uint32_t)(int32_t)((lofs + ((float)LATENCY_TICKS + (float)s->micro * (1.0f - quant)) * tick) * RV_FS + (float)sw * 0.02f * sd * RV_FS);   /* (through int32: early micro can be before when) */
        e.track = (uint8_t)t;
        e.chain = (uint16_t)(1u << t);
        e.env = (uint8_t)(rv.pat_cur[t] % RV_PATTERNS);   /* the pattern and step its locks are found under */
        e.step = (uint8_t)li;
        e.head = 0x40;                                /* a kit hit: look up its locks */
        e.rmv = 0;
        e.type = EV_ON;
        e.note = (uint8_t)(60 + l);
        e.len_s = 0.0f;
        cnt = ((s->len >> l) & 1) ? (s->ratchet & 7) + 1 : 1;
        curve = (s->ratchet >> 3) & 3;
        for (r = 0; r < cnt; r++) {
            float u = rat_pos(curve, r, cnt);
            event_t on = e;
            on.vel = (uint8_t)(((s->env >> l) & 1) ? 127 : clampi(s->vel ? s->vel : 100, 1, 110));   /* accent */
            if (cnt > 1)
                on.vel = (uint8_t)clampi((int)((float)on.vel * rat_vel(s, r, cnt) + 0.5f), 1, 127);
            on.rmv = (uint8_t)(((s->ratchet >> 6) & 3) | (r << 2) | ((cnt - 1) << 5));
            on.when = e.when + (uint32_t)(u * sd * RV_FS * (ri == 4 ? 1.0f : (float)den[ri] / (float)num[ri]));
            ev_push(&on);
        }
        }
    }
}

/* ---- CHAIN: a kit's lanes setting each other off ---- */
int rv_chain_get(int t, int off, int n)
{
    int v = 0, i;
    for (i = 0; i < n; i++) {
        int b = off + i;
        v |= (((uint16_t)rv.tp[t & 7][TP_H1ROLE + (b >> 4)] >> (b & 15)) & 1) << i;
    }
    return v;
}
void rv_chain_set(int t, int off, int n, int v)
{
    int i;
    for (i = 0; i < n; i++) {
        int b = off + i;
        uint16_t w = (uint16_t)rv.tp[t & 7][TP_H1ROLE + (b >> 4)];
        w = (uint16_t)((w & ~(1u << (b & 15))) | (((unsigned)v >> i & 1u) << (b & 15)));
        rv.tp[t & 7][TP_H1ROLE + (b >> 4)] = (int16_t)w;
    }
}
/* a chain to start from, for the factory kit (KICK, SNARE, CH HAT, OH HAT, CLAP, RIM): the kick sets off
 * hats and the snare, hats run on, the snare now and then rolls */
RV_SMALL void rv_chain_defaults(int t)
{
    static const uint8_t d[RV_LANES][CHN_CORDS][2] = {
        {{3, 85}, {2, 45}, {6, 20}},                  /* KICK: hat, snare, rim */
        {{3, 60}, {5, 25}, {2, 15}},                  /* SNARE: hat, clap, itself (a roll) */
        {{3, 80}, {4, 10}, {1, 12}},                  /* CH HAT: itself, open, kick */
        {{3, 50}, {6, 20}, {0, 0}},                   /* OH HAT: hat, rim */
        {{2, 35}, {3, 30}, {0, 0}},                   /* CLAP: snare, hat */
        {{1, 30}, {6, 25}, {0, 0}}};                  /* RIM: kick, itself */
    int l, c, i;
    for (i = TP_H1ROLE; i < TP_H1ROLE + 12; i++)
        rv.tp[t & 7][i] = 0;
    for (l = 0; l < RV_LANES; l++)
        for (c = 0; c < CHN_CORDS; c++) {
            rv_chain_set(t, CHN_TO(l, c), 3, d[l][c][0]);
            rv_chain_set(t, CHN_PCT(l, c), 7, d[l][c][1]);
        }
}
static uint8_t chn_next[RV_TRACKS], chn_lit[RV_TRACKS], chn_go[RV_TRACKS];
int rv_chain_lit(int t) { return chn_lit[t & 7]; }
static int is_chain(int t) { return is_kit(t) && rv.tp[t][TP_SEQMODE] == SEQ_CHAIN; }
/* a step of the chain: the lanes set off last step fire (and the start lane at the loop's top, as RESTART
 * says), and each one's cords roll for the next */
static RV_SMALL void chain_fire(int t, int si, uint32_t when)
{
    int live = chn_next[t], l, c, nx = 0, start = rv_chain_get(t, CHN_START, 3) % RV_LANES;
    int restart = rv_chain_get(t, CHN_RESTART, 2), startbit = 0;
    float sd = step_seconds(t);
    int sw = (sq[t].travelled[0] & 1u) ? 0 : rv.gp[GP_SWING] - 50;   /* (travelled counts this step: odd is the downbeat) */
    if (chn_go[t] || (si == 0 && (restart == CHR_LOOP || (restart == CHR_QUIET && !live)))) {
        live |= 1 << start;
        startbit = 1 << start;
        chn_go[t] = 0;
    }
    chn_lit[t] = (uint8_t)live;
    for (l = 0; l < RV_LANES; l++) {
        event_t e;
        if (!(live >> l & 1))
            continue;
        {
            e.when = when + (uint32_t)(int32_t)(((float)LATENCY_TICKS * sd * (1.0f / 24.0f)) * RV_FS + (float)sw * 0.02f * sd * RV_FS);
            e.track = (uint8_t)t;
            e.chain = (uint16_t)(1u << t);
            e.env = (uint8_t)(rv.pat_cur[t] % RV_PATTERNS);
            e.step = (uint8_t)si;
            e.head = 0x40;                            /* a kit hit (the step's locks for the lane, if it has any) */
            e.rmv = 0;
            e.type = EV_ON;
            e.note = (uint8_t)(60 + l);
            e.len_s = 0.0f;
            e.vel = (uint8_t)((startbit >> l & 1) ? 110 : 90);   /* the start a little stronger */
            ev_push(&e);
        }
        for (c = 0; c < CHN_CORDS; c++) {
            int to = rv_chain_get(t, CHN_TO(l, c), 3), pc = rv_chain_get(t, CHN_PCT(l, c), 7);
            if (to >= 1 && to <= RV_LANES && pc > 0 && xs_uni(&seq_rng) * 100.0f < (float)pc)
                nx |= 1 << (to - 1);
        }
    }
    chn_next[t] = (uint8_t)nx;
}

static int rec_key_down(int t, int si);
static void step_fire(int t, int h, int si, uint32_t when)
{
    rv_step *s = is_chance(t) ? &ch_step : &rv.pat[t][rv.pat_cur[t] % RV_PATTERNS].s[si];   /* (CHANCE: the step it decided) */
    static rv_step sqm_rest;                          /* (nothing plays: HITS left none here) */
    if (!is_chance(t) && !is_graph(t) && !is_kit(t) && sqm_on(t)) {   /* the matrix's HITS or ROTATE: what plays here */
        int at;
        s = sqm_step(t, si, seq_len(t), -1, &at);
        if (!s)
            s = &sqm_rest;
    }
    float sd = step_seconds(t), tick = sd * (1.0f / 24.0f);
    int k, note, cnt, curve, sw;
    int role = head_role(t, h), tt = t;               /* head 2 may play another track */
    if (h == 1 && rv.tp[t][TP_H2TARGET] > 0)
        tt = clampi(rv.tp[t][TP_H2TARGET] - 1, 0, RV_TRACKS - 1);
    float quant = rv.gp[GP_QUANT] * 0.01f, micro, density;
    event_t e;
    if (h == 0) {                                   /* the locks hold for this step */
        for (k = 0; k < TP_N; k++)
            trk[t].lockon[k] = 0;
        trk[t].lockany = 0;
        for (k = 0; k < 2; k++)
            if (s->lp[k] && s->lp[k] - 1 < TP_N) {
                int p = s->lp[k] - 1;
                const rv_pinfo *pi = rv_pinfo_track(t, p);
                trk[t].lockon[p] = 1;
                trk[t].lockany = 1;
                trk[t].lockv[p] = (int16_t)(pi->min + s->lv[k]);
            }
        rv_live.step[t][0] = (int16_t)si;
    } else {
        rv_live.step[t][1] = (int16_t)si;
    }
    if (is_kit(t)) {
        if (h == 0) {
            if (is_chain(t))
                chain_fire(t, si, when);
            else
                kit_fire(t, si, when);
        }
        return;
    }
    if (!(s->flags & ST_ON))
        return;
    if (h == 0 && rec_key_down(t, si))
        return;                                       /* being recorded, its key still down: the key is playing it (the step's own
                                                       * note-off would cut the held note short) */
    if (!cond_pass(s, t))
        return;
    if (rv.tp[t][TP_KIND] == KIND_LOOP) {             /* a LOOP track: its record and play trigs (chance and conditions apply) */
        if (h == 0 && (s->chance >= 100 || xs_uni(&seq_rng) * 100.0f < (float)s->chance))
            loop_fire(t, si);
        return;
    }
    if (s->chance < 100 && xs_uni(&seq_rng) * 100.0f >= (float)s->chance)
        return;
    density = rv.arcs[t][(song_bar >> clampi(rv.gp[GP_ARCSPAN], 0, 2)) & 15];
    if (density < 100 && (float)step_rank(si) >= density * 0.16f)
        return;
    micro = (float)s->micro * (1.0f - quant);
    sw = ((sq[t].travelled[h] - 1u) & 1u) ? rv.gp[GP_SWING] - 50 : 0;   /* SWING: every second step in time sits at SWING% of the pair
                                                                        (50 even, 66 a triplet feel), whatever the direction or LENGTH */
    e.when = when + (uint32_t)(int32_t)(((float)LATENCY_TICKS + micro) * tick * RV_FS + (float)sw * 0.02f * sd * RV_FS);   /* (the same) */
    e.track = (uint8_t)tt;
    e.chain = (uint16_t)(1u << tt);
    e.env = s->env;
    e.step = (uint8_t)si;
    e.head = (uint8_t)h;
    e.rmv = 0;
    if ((s->cut & 3) && role != ROLE_PITCH) {
        e.type = EV_CUT;
        e.note = s->cut;
        ev_push(&e);
    }
    if (s->flags & ST_JUMP)                          /* (a tape jump, from before the tape left: nothing now) */
        return;
    {   /* the step's note, then its chord's (each through the transposition and the scale) */
    int ci, nch = 1 + (s->chord[0] != 0) + (s->chord[1] != 0) + (s->chord[2] != 0);
    for (ci = 0; ci < 4; ci++) {
    if (ci && !s->chord[ci - 1])
        continue;
    note = s->note + (ci ? s->chord[ci - 1] : 0);
    {
        int ivl = clampi(rv.tp[t][TP_INTERVAL], 1, 12);
        if (is_graph(t))
            note += rv.tp[t][h ? TP_H2TRANS : TP_H1TRANS];
        note += rv.gp[GP_TRANSPOSE];
        note = rv_quantize_note(note);
        if (role == ROLE_PITCH) {                    /* a PITCH head only sets the pitch (the step's own note) */
            sq[t].pitch_reg = (int16_t)note;
            sq[t].pitch_set = 1;
            return;
        }
        if (role == ROLE_GATE && sq[t].pitch_set) {  /* a GATE head plays the PITCH head's note (and its chord's intervals) */
            note = sq[t].pitch_reg + (ci ? s->chord[ci - 1] : 0);
        } else if (ivl > 1 && ((note - rv.gp[GP_ROOT]) % ivl + ivl) % ivl)
            continue;                               /* INTERVAL: only notes a multiple of N semitones from the root */
    }
    (void)nch;
    cnt = (s->ratchet & 7) + 1;
    curve = (s->ratchet >> 3) & 3;
    for (k = 0; k < cnt; k++) {
        float u = rat_pos(curve, k, cnt), len_s;
        int mv = cnt > 1 ? (s->ratchet >> 6) & 3 : 0;
        e.type = EV_ON;
        e.note = (uint8_t)clampi(mv == 1 || mv == 2 ? scale_walk(note, mv == 1 ? k : -k) : note, 0, 127);   /* R MOVE: up or down the scale */
        e.vel = (uint8_t)clampi((int)((float)s->vel * rat_vel(s, k, cnt) + 0.5f), 1, 127);
        len_s = cnt > 1 ? sd / (float)cnt * 0.7f : sd * rv_len_steps(s->len);
        if (cnt > 1 && curve == 3)                   /* a bounce: each note as long as its gap allows */
            len_s = fm_maxf(0.004f, ((k + 1 < cnt ? rat_pos(3, k + 1, cnt) : 1.0f) - u) * sd * 0.8f);
        if (mv == 3)                                 /* DARK: and shorter as they go */
            len_s *= 1.0f - 0.6f * (float)k / (float)cnt;
        e.len_s = len_s;
        e.rmv = (uint8_t)(mv | (k << 2) | ((cnt - 1) << 5));
        {
            event_t on = e, off = e;
            on.when = e.when + (uint32_t)(u * sd * (float)(cnt > 1 ? 1 : 0) * RV_FS);
            if (s->flags & ST_TIE)
                on.head |= 0x80u;                   /* tied: no note-off; the track's next note ends it */
            ev_push(&on);
            if (!(s->flags & ST_TIE)) {
                off.type = EV_OFF;
                off.when = on.when + (uint32_t)(len_s * RV_FS);
                ev_push(&off);
            }
        }
    }
    }
    }
}

static int track_clocked_by_route(int t)
{
    int a;
    for (a = 0; a < RV_TRACKS; a++)
        if (rv.infl[a][t].type == RT_CLOCK)
            return 1;
    return 0;
}

/* one head moves one step and plays it */
static RV_SMALL void head_advance(int t, int h, uint32_t when)
{
    seqtrk_t *s = &sq[t];
    if (h == 0 && pend_pat[t] >= 0 && !is_graph(t)
        && (s->step[0] < 0 || s->travelled[0] % (uint32_t)seq_len(t) == 0)) {
        rv.pat_cur[t] = (uint8_t)(pend_pat[t] % RV_PATTERNS);   /* a launched pattern waits for this one's end, then starts at its top */
        pend_pat[t] = -1;
        s->passes = 0;
        s->step[0] = s->step[1] = -1;
    }
    s->step[h] = (int16_t)(is_chance(t) ? chance_advance(t) : next_step(t, h, s->step[h]));
    s->travelled[h]++;
    if (h == 0) {
        s->step_time = when;
        s->step_dur = step_seconds(t);
        if (s->first_take)
            s->take_steps++;
    }
    step_fire(t, h, s->step[h], when);
}

static int master_clocked(int t) { return rv.tp[t][TP_CLKSRC] == 0 && !track_clocked_by_route(t) && !((weft_own >> t) & 1u); }   /* (a SEQ OUT stepping it: not) */

/* a track's step from another clock (an LFO, dust, a route): head 1 moves, and head 2 follows at
 * its rate relative to head 1. On the master clock each head is scheduled on its own. */
static void track_advance(int t, uint32_t when)
{
    seqtrk_t *s = &sq[t];
    head_advance(t, 0, when);
    if (head_role(t, 1) != ROLE_OFF && !master_clocked(t)) {
        s->next_at[1] += head_rate(t, 1) / head_rate(t, 0);
        while (s->next_at[1] >= 1.0f) {
            s->next_at[1] -= 1.0f;
            head_advance(t, 1, when);
        }
    }
}

/* a scene waiting to be applied, and the graph tracks' launched patterns (step tracks switch at their own end) */
/* a scene GLIDE: patterns, mutes and the routes' kinds change at once; the levels, the macros and
 * the routes' amounts move there over GLIDE bars (a route on its way out fades, then goes) */
static struct {
    uint8_t on;
    float u, du;
    uint8_t lv0[RV_TRACKS], lv1[RV_TRACKS];
    int8_t m0[RV_MACROS], m1[RV_MACROS];
    int8_t a0[RV_TRACKS][RV_TRACKS], a1[RV_TRACKS][RV_TRACKS];
    rv_route fin[RV_TRACKS][RV_TRACKS];
} gl;

static void glide_set(float u)
{
    int t, a, b;
    float w = u * u * (3.0f - 2.0f * u);
    for (t = 0; t < RV_TRACKS; t++)
        rv.tp[t][TP_LEVEL] = (int16_t)((float)gl.lv0[t] + (float)(gl.lv1[t] - gl.lv0[t]) * w + 0.5f);
    for (t = 0; t < RV_MACROS; t++)
        rv.gp[GP_MACRO1 + t] = (int16_t)((float)gl.m0[t] + (float)(gl.m1[t] - gl.m0[t]) * w + (gl.m1[t] >= gl.m0[t] ? 0.5f : -0.5f));
    for (a = 0; a < RV_TRACKS; a++)
        for (b = 0; b < RV_TRACKS; b++)
            rv.infl[a][b].amt = (int8_t)((float)gl.a0[a][b] + (float)(gl.a1[a][b] - gl.a0[a][b]) * w);
}

static void glide_tick(int n)
{
    if (!gl.on)
        return;
    gl.u += gl.du * (float)n;
    if (gl.u >= 1.0f) {                               /* there: the scene as it was stored */
        int a, b;
        glide_set(1.0f);
        for (a = 0; a < RV_TRACKS; a++)
            for (b = 0; b < RV_TRACKS; b++)
                rv.infl[a][b] = gl.fin[a][b];
        gl.on = 0;
        rv_live.glide = 1.0f;
        return;
    }
    glide_set(gl.u);
    rv_live.glide = gl.u;
}

static void apply_pending(void)
{
    int t;
    if (pend_scene >= 0) {
        const rv_scene *sc = &rv.scene[pend_scene & 15];
        if (sc->used) {
            int bars = clampi(rv.gp[GP_SCNGLIDE], 0, 8);
            if (rv.scene_tempo[pend_scene & 15])          /* a scene with its own tempo */
                rv.gp[GP_TEMPO] = rv.scene_tempo[pend_scene & 15];
            if (bars > 0 && playing) {
                int a, b;
                for (t = 0; t < RV_TRACKS; t++) {
                    gl.lv0[t] = (uint8_t)clampi(rv.tp[t][TP_LEVEL], 0, 127);
                    gl.lv1[t] = sc->level[t];
                }
                for (t = 0; t < RV_MACROS; t++) {
                    gl.m0[t] = (int8_t)clampi(rv.gp[GP_MACRO1 + t], -128, 127);
                    gl.m1[t] = sc->macro[t];
                }
                for (a = 0; a < RV_TRACKS; a++)
                    for (b = 0; b < RV_TRACKS; b++) {
                        rv_route *cur = &rv.infl[a][b];
                        const rv_route *to = &sc->infl[a][b];
                        gl.fin[a][b] = *to;
                        if (to->type == RT_OFF && cur->type != RT_OFF) {   /* going: it fades */
                            gl.a0[a][b] = cur->amt;
                            gl.a1[a][b] = 0;
                        } else if (to->type == cur->type) {
                            gl.a0[a][b] = cur->amt;
                            gl.a1[a][b] = to->amt;
                            *cur = *to;
                            cur->amt = gl.a0[a][b];
                        } else {                                           /* coming: it grows */
                            *cur = *to;
                            gl.a0[a][b] = 0;
                            gl.a1[a][b] = to->amt;
                            cur->amt = 0;
                        }
                    }
                gl.u = 0.0f;
                gl.du = 1.0f / ((float)bars * 4.0f * 60.0f / (float)clampi(rv.gp[GP_TEMPO], 20, 300) * RV_FS);
                gl.on = 1;
                rv_live.glide = 0.0f;
            } else {
                gl.on = 0;
                rv_live.glide = 1.0f;
            }
            for (t = 0; t < RV_TRACKS; t++) {
                rv.pat_cur[t] = sc->pattern[t] % RV_PATTERNS;
                if (!gl.on)
                    rv.tp[t][TP_LEVEL] = sc->level[t];
                sq[t].passes = 0;
            }
            rv.mute = sc->mute;
            if (!gl.on) {
                int a, b;
                for (t = 0; t < RV_MACROS; t++)
                    rv.gp[GP_MACRO1 + t] = sc->macro[t];
                for (a = 0; a < RV_TRACKS; a++)
                    for (b = 0; b < RV_TRACKS; b++)
                        rv.infl[a][b] = sc->infl[a][b];
            }
        }
        rv.scene_cur = (uint8_t)(pend_scene & 15);
        pend_scene = -1;
    }
    for (t = 0; t < RV_TRACKS; t++)
        if (pend_pat[t] >= 0 && is_graph(t)) {
            rv.pat_cur[t] = (uint8_t)(pend_pat[t] % RV_PATTERNS);
            pend_pat[t] = -1;
            sq[t].passes = 0;
        }
}

/* the bar: scenes, graph patterns and the arrangement switch here */
static void bar_boundary(void)
{
    song_bar++;
    if (rv.gp[GP_SONGMODE] == 1 && rv.arr_len) {
        if (arr_bar_left > 0)
            arr_bar_left--;
        if (arr_bar_left == 0) {
            arr_row = (uint8_t)((arr_row + 1) % rv.arr_len);
            arr_bar_left = rv.arr[arr_row].bars ? rv.arr[arr_row].bars : 1;
            if (rv.arr[arr_row].scene >= RV_ARR_END) {   /* an END row: the song stops here */
                song_ended = 1;
                return;
            }
            pend_scene = (int8_t)rv.arr[arr_row].scene;
        }
    }
    apply_pending();
}

/* ------------------------------------------------------- the arpeggiator --- */
/* ARP: a note track's notes, from the keys, its own steps or an influence, are held instead of
 * played, and the arpeggiator plays them one at a time on the master clock (whether the transport
 * runs or not), in the order its MODE gives, over OCTAVES, each for GATE of its step. LATCH keeps
 * them after the keys let go, until a new chord comes. */
typedef struct {
    uint8_t n, note[RV_ARP_HELD], vel[RV_ARP_HELD], live[RV_ARP_HELD];
    uint8_t down;                                   /* of them, held now */
    uint8_t rep;                                    /* REPEAT: times the step has played its note */
    int16_t sounding;                               /* the note it plays now, -1: none */
    uint16_t serial;                                /* its notes, counted: a note's end ends only its own */
    uint16_t gen;                                   /* its starts: a step queued before it stopped is dropped */
    uint32_t pos;                                   /* steps since it started */
    float next;                                     /* its next step, in master pulses */
} arp_t;
static arp_t arp[RV_TRACKS];
/* HOLD with the arp off: the keys' notes sound on after they let go, until the next chord (the first
 * key down after all were up) lets them go, or HOLD goes off */
typedef struct { uint8_t n, note[RV_ARP_HELD], down; } hold_t;
static hold_t hold[RV_TRACKS];
/* the keys (and MIDI notes) down on each track now, whatever its mode: HOLD switched on takes these, so
 * a chord you're already holding stays when you let go */
static hold_t keys_down[RV_TRACKS];
static uint8_t hold_was[RV_TRACKS], latch_was[RV_TRACKS];
static void keys_down_on(int t, int note)
{
    hold_t *k = &keys_down[t];
    int i;
    for (i = 0; i < k->n; i++)
        if (k->note[i] == note)
            return;
    if (k->n < RV_ARP_HELD)
        k->note[k->n++] = (uint8_t)note;
}
static void keys_down_off(int t, int note)
{
    hold_t *k = &keys_down[t];
    int i;
    for (i = 0; i < k->n; i++)
        if (k->note[i] == note) {
            k->note[i] = k->note[--k->n];
            return;
        }
}
static float arp_pf;                                /* master pulses so far (counted when stopped too) */
static uint8_t arp_out, arp_live_in;                /* the arpeggiator itself is playing; the note is a key's */
static uint32_t arp_rng = 0xA5A5F00Du;
static const float arp_rates[6] = {4.0f, 2.0f, 1.3333333f, 1.0f, 0.6666667f, 0.5f};   /* in steps: 1/4 .. 1/32 */

static int arp_on(int t)
{
    int k = rv.tp[t][TP_KIND];
    return rv.tp[t][TP_ARPMODE] != ARP_OFF && (k == KIND_SYNTH || k == KIND_STRIKE || (k == KIND_PERC && rv.tp[t][TP_ENGINE] != 1));
}
static float arp_rate(int t) { return arp_rates[clampi(rv.tp[t][TP_ARPRATE], 0, 5)]; }
static void arp_silence(int t)
{
    arp_t *a = &arp[t];
    if (a->sounding >= 0) {
        arp_out = 1;
        note_off_internal(t, a->sounding);
        arp_out = 0;
        a->sounding = -1;
    }
}
static int arp_find(const arp_t *a, int note)
{
    int i;
    for (i = 0; i < a->n; i++)
        if (a->note[i] == note)
            return i;
    return -1;
}
static void arp_drop(arp_t *a, int i)
{
    for (; i + 1 < a->n; i++) {
        a->note[i] = a->note[i + 1];
        a->vel[i] = a->vel[i + 1];
        a->live[i] = a->live[i + 1];
    }
    a->n--;
}

/* a step: the last note ends, the next begins */
static void arp_step(int t, uint32_t when)
{
    arp_t *a = &arp[t];
    int mode = rv.tp[t][TP_ARPMODE], oct = clampi(rv.tp[t][TP_ARPOCT], 1, 4), reps = clampi(rv.tp[t][TP_ARPREP], 1, 4);
    int chance = clampi(rv.tp[t][TP_ARPCHNC], 0, 100), note, i, vel = 100;
    uint32_t k = a->pos;
    arp_silence(t);
    if (!a->n || !arp_on(t))
        return;
    if (mode == ARP_RANDOM) {
        int r = (int)(xs32(&arp_rng) % (uint32_t)(a->n * oct));
        note = a->note[r % a->n] + 12 * (r / a->n);
    } else {
        note = rv_arp_note(a->note, a->n, mode, oct, (int)(k % (uint32_t)rv_arp_len(a->n, mode, oct)));
    }
    if (++a->rep >= reps) {
        a->rep = 0;
        a->pos++;
    }
    rv_live.arp_pos[t] = (uint8_t)k;
    if (chance < 100 && xs_uni(&arp_rng) * 100.0f >= (float)chance)
        return;                                     /* a rest */
    for (i = 0; i < a->n; i++)                      /* the velocity its key came with */
        if ((note - a->note[i]) % 12 == 0 && note >= a->note[i])
            vel = a->vel[i];
    if (note > 127)
        return;
    arp_out = 1;
    note_on_internal(t, note, vel, 0, (uint16_t)(1u << t));
    arp_out = 0;
    a->sounding = (int16_t)note;
    a->serial++;
    rv_live.arp_hit[t]++;
    if (rv.tp[t][TP_ARPGATE] < 100) {               /* (at 100 each note runs into the next) */
        event_t e;
        __builtin_memset(&e, 0, sizeof e);
        e.type = EV_AOFF;
        e.track = (uint8_t)t;
        e.note = (uint8_t)note;
        e.chain = a->serial;
        e.when = when + (uint32_t)(arp_rate(t) * clk_period * (float)rv.tp[t][TP_ARPGATE] * 0.01f * RV_FS);
        ev_push(&e);
    }
}

/* a note comes to (on) or leaves (off) a track whose arpeggiator is on */
static void arp_key(int t, int note, int vel, int on)
{
    arp_t *a = &arp[t];
    int i = arp_find(a, note), latch = rv.tp[t][TP_ARPLATCH] != 0;
    if (on) {
        int was;
        if (latch && !a->down)                      /* LATCH: a new chord replaces the last */
            a->n = 0;
        was = a->n;
        i = arp_find(a, note);
        if (i < 0 && a->n < RV_ARP_HELD) {
            i = a->n++;
            a->note[i] = (uint8_t)note;
            a->live[i] = 0;
        }
        if (i >= 0) {
            a->vel[i] = (uint8_t)vel;
            a->live[i] |= arp_live_in;
        }
        if (a->down < 255)
            a->down++;
        if (!was && a->n) {                         /* the first note: it starts now, then on its grid */
            float r = arp_rate(t);
            a->pos = 0;
            a->rep = 0;
            a->gen++;
            a->next = (float)(int)(arp_pf / r + 0.999f) * r;
            if (a->next < arp_pf)
                a->next += r;
            arp_step(t, now_s);
        }
    } else {
        if (a->down)
            a->down--;
        if (!latch && i >= 0)
            arp_drop(a, i);
        if (!a->n)
            arp_silence(t);
    }
}
static int hold_on(int t)
{
    int k = rv.tp[t][TP_KIND];
    return rv.tp[t][TP_ARPLATCH] && !arp_on(t) && (k == KIND_SYNTH || k == KIND_STRIKE || (k == KIND_PERC && rv.tp[t][TP_ENGINE] != 1));
}
static void hold_release(int t)
{
    hold_t *h = &hold[t];
    int i;
    arp_out = 1;
    for (i = 0; i < h->n; i++)
        note_off_internal(t, h->note[i]);
    arp_out = 0;
    h->n = 0;
}
static int hold_has(int t, int note)
{
    int i;
    for (i = 0; i < hold[t].n; i++)
        if (hold[t].note[i] == note)
            return 1;
    return 0;
}
/* a key goes down on a HOLD track (it plays as ever) */
static void hold_key_on(int t, int note)
{
    hold_t *h = &hold[t];
    if (!h->down)
        hold_release(t);                            /* a new chord: the last one goes */
    if (!hold_has(t, note) && h->n < RV_ARP_HELD)
        h->note[h->n++] = (uint8_t)note;
    if (h->down < 255)
        h->down++;
}

/* does the arpeggiator take this note's end (it holds the note)? */
static int arp_holds(int t, int note) { return arp_find(&arp[t], note) >= 0; }

/* each master pulse: the steps that fall before the next */
static void arp_pulse(int off)
{
    int t;
    uint32_t base = now_s + (uint32_t)off;
    for (t = 0; t < RV_TRACKS; t++) {
        arp_t *a = &arp[t];
        float r;
        int guard = 8;
        if (!a->n || !arp_on(t))
            continue;
        r = arp_rate(t);
        while (a->next < arp_pf + 1.0f && guard--) {
            event_t e;
            float d = (a->next - arp_pf) * clk_period;
            __builtin_memset(&e, 0, sizeof e);
            e.type = EV_ARP;
            e.track = (uint8_t)t;
            e.chain = a->gen;
            e.when = base + (uint32_t)(d > 0.0f ? d * RV_FS : 0.0f);
            ev_push(&e);
            a->next += r;
        }
        if (a->next < arp_pf)
            a->next = arp_pf + r;
    }
    arp_pf += 1.0f;
}

/* each control step: an arpeggiator switched off (or its track changed kind) lets its notes go;
 * the screen's copy of what each holds */
static void arp_control(void)
{
    int t, i;
    for (t = 0; t < RV_TRACKS; t++) {
        arp_t *a = &arp[t];
        if (a->n && !arp_on(t)) {
            arp_silence(t);
            a->n = 0;
            a->down = 0;
        }
        if (latch_was[t] && !rv.tp[t][TP_ARPLATCH] && a->n) {   /* the arp's HOLD switched off: the notes no key holds go */
            for (i = a->n - 1; i >= 0; i--) {
                int k, held = 0;
                for (k = 0; k < keys_down[t].n; k++)
                    held |= keys_down[t].note[k] == a->note[i];
                if (!held && (!a->down || a->live[i]))
                    arp_drop(a, i);
            }
            if (!a->n) {
                arp_silence(t);
                a->down = 0;
            }
        }
        latch_was[t] = (uint8_t)(rv.tp[t][TP_ARPLATCH] != 0);
        if (hold[t].n && !hold_on(t))              /* HOLD off (or the arp on): what it held goes */
            hold_release(t);
        if (!hold_on(t))
            hold[t].down = 0;
        else if (!hold_was[t] && keys_down[t].n) { /* HOLD just on, keys already down: it holds those */
            hold[t] = keys_down[t];
            hold[t].down = keys_down[t].n;
        }
        hold_was[t] = (uint8_t)hold_on(t);
        rv_live.arp_n[t] = a->n ? a->n : hold[t].n;
        for (i = 0; i < rv_live.arp_n[t]; i++)
            rv_live.arp_note[t][i] = a->n ? a->note[i] : hold[t].note[i];
    }
}

/* the transport stopped: the steps' notes go (the keys' stay) */
static void arp_stop(void)
{
    int t, i;
    for (t = 0; t < RV_TRACKS; t++) {
        arp_t *a = &arp[t];
        a->sounding = -1;                           /* (all_off_now let it go) */
        for (i = a->n - 1; i >= 0; i--)
            if (!a->live[i])
                arp_drop(a, i);
        if (a->down > a->n)
            a->down = a->n;
        hold[t].n = 0;                              /* (all_off_now let them go) */
    }
}
static void arp_reset(void)
{
    int t;
    for (t = 0; t < RV_TRACKS; t++) {
        arp[t].n = arp[t].down = 0;
        arp[t].sounding = -1;
        hold[t].n = hold[t].down = 0;
    }
}


/* a master pulse at sample offset off in this control step */
static void seq_pulse(int off)
{
    int t;
    uint32_t base = now_s + (uint32_t)off, lat = (uint32_t)((float)LATENCY_TICKS / 24.0f * clk_period * RV_FS);   /* the click lands with the notes */
    if (!playing)
        return;
    if (countin_left > 0) {                           /* the count-in: clicks on the beats, nothing plays */
        if ((countin_left & 3) == 0)
            click_at(base + lat, (countin_left & 15) == 0, 1);
        countin_left--;
        rv_live.countin = (uint8_t)((countin_left + 3) / 4);
        return;
    }
    if ((mpulse & 3) == 0)
        click_at(base + lat, (mpulse & 15) == 0, 0);
    if ((mpulse & 15) == 0 && mpulse) {
        bar_boundary();
        if (song_ended) {                             /* the arrangement's END: stop as the transport does */
            song_ended = 0;
            seq_stop();
            rv_live.playing = 0;
            return;
        }
    }
    rv_live.beat = (uint8_t)((mpulse >> 2) & 3);
    rv_live.bar = (uint8_t)(song_bar & 255);
    for (t = 0; t < RV_TRACKS; t++) {
        seqtrk_t *s = &sq[t];
        static const float rates[9] = {0.25f, 0.3333f, 0.5f, 0.6667f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f};
        float r = rates[clampi(rv.tp[t][TP_RATE], 0, 8)];
        if (!master_clocked(t))
            continue;
        {
            int h, heads = head_role(t, 1) != ROLE_OFF ? 2 : 1;
            for (h = 0; h < heads; h++) {
                int guard = 16;
                while (s->next_at[h] < mpulse_f + 1.0f && guard--) {
                    event_t e;
                    float d = (s->next_at[h] - mpulse_f) * clk_period;
                    e.type = EV_ADV;
                    e.track = (uint8_t)t;
                    e.head = (uint8_t)h;
                    e.when = base + (uint32_t)(d > 0.0f ? d * RV_FS : 0.0f);
                    ev_push(&e);
                    s->next_at[h] += 1.0f / (h == 0 && !is_graph(t) ? r : head_rate(t, h));
                }
                if (s->next_at[h] < mpulse_f)           /* (a guard tripped: catch up, don't burst) */
                    s->next_at[h] = mpulse_f + 1.0f;
            }
        }
    }
    mpulse++;
    mpulse_f += 1.0f;
}

/* other clocks: LFO wraps and dust fire the tracks that follow them */
static void seq_other_clocks(void)
{
    int t, wf = weft_clk_fired, wr = weft_clk_reset;
    weft_clk_fired = weft_clk_reset = 0;              /* (WEFT's clock: from the last step's sound) */
    if (!playing) {                                   /* (stopped: a pattern still changes; the rest is let go) */
        for (t = 0; t < RV_TRACKS; t++) {
            if (wsq_pat[t] >= 0)
                rv.pat_cur[t] = (uint8_t)(wsq_pat[t] == 2 ? !rv.pat_cur[t] : wsq_pat[t]);
            wsq_pat[t] = -1;
            wsq_steps_c[0][t] = wsq_steps_c[1][t] = wsq_jump[t] = 0;
        }
        wsq_restart_c[0] = wsq_restart_c[1] = 0;
        return;
    }
    for (t = 0; t < RV_TRACKS; t++) {               /* WEFT's SEQ OUTs: a pattern, back to step 1, a jump, steps */
        int len = clampi(rv.tp[t][TP_LEN], 1, RV_STEPS), k;
        if (wsq_pat[t] >= 0) {
            rv.pat_cur[t] = (uint8_t)(wsq_pat[t] == 2 ? !rv.pat_cur[t] : wsq_pat[t]);
            wsq_pat[t] = -1;
        }
        if (((wsq_restart_c[0] | wsq_restart_c[1]) >> t) & 1u) {
            sq[t].step[0] = sq[t].step[1] = -1;
            sq[t].dir[0] = sq[t].dir[1] = 1;
        }
        if (wsq_jump[t]) {                            /* (the next step it plays is that one) */
            sq[t].step[0] = (int16_t)((wsq_jump[t] - 1) * len / 255 - 1);
            sq[t].dir[0] = 1;
        }
        wsq_jump[t] = 0;
        for (k = 0; k < wsq_steps_c[0][t] + wsq_steps_c[1][t] && k < 4; k++)
            track_advance(t, now_s);
        wsq_steps_c[0][t] = wsq_steps_c[1][t] = 0;
    }
    wsq_restart_c[0] = wsq_restart_c[1] = 0;
    for (t = 0; t < RV_TRACKS; t++) {
        int src = rv.tp[t][TP_CLKSRC];
        if ((weft_own >> t) & 1u)
            continue;                                 /* (a SEQ OUT steps it, not its CLOCK) */
        if (src == 4 && wr) {                         /* WEFT asks for step 1 */
            sq[t].step[0] = sq[t].step[1] = -1;
            sq[t].dir[0] = sq[t].dir[1] = 1;
        }
        if ((src == 1 && lfo_wrapped[0]) || (src == 2 && lfo_wrapped[1]) || (src == 3 && dust_fired) || (src == 4 && wf))
            track_advance(t, now_s);
    }
}

static void seq_start(void)
{
    int t;
    clock_reset();
    weft_pos16 = 0.0f;                                /* (WEFT's TICKs on the transport's grid) */
    mpulse = 0;
    mpulse_f = 0.0f;
    song_bar = 0;
    arr_row = 0;
    arr_bar_left = rv.arr_len ? (rv.arr[0].bars ? rv.arr[0].bars : 1) : 0;
    if (rv.gp[GP_SONGMODE] == 1 && rv.arr_len && rv.arr[0].scene < RV_ARR_END)
        pend_scene = (int8_t)rv.arr[0].scene;
    for (t = 0; t < RV_TRACKS; t++) {
        sq[t].tied = 0;
        sq[t].step[0] = sq[t].step[1] = -1;
        sq[t].dir[0] = sq[t].dir[1] = 1;
        sq[t].next_at[0] = 0.0f;
        sq[t].next_at[1] = 0.0f;
        sq[t].passes = 0;
        sq[t].travelled[0] = sq[t].travelled[1] = 0;
        sq[t].pitch_set = 0;
        turn_bits[t] = 0;
        chs[t].pos = -1;                              /* (CHANCE starts its phrase from the top; ch_get sets it up if new) */
        chn_next[t] = 0;                              /* (CHAIN starts from its start lane) */
        chn_go[t] = 1;
        chn_lit[t] = 0;
    }
    if (pend_scene >= 0)                              /* row 1's scene now, without counting a bar */
        apply_pending();
    arp_pf = 0.0f;                                    /* the arpeggiators on the bar's grid */
    for (t = 0; t < RV_TRACKS; t++)
        arp[t].next = 0.0f;
    countin_left = rv_live.recording && rv.gp[GP_COUNTIN] > 0 ? 16 * rv.gp[GP_COUNTIN] : 0;   /* recording: count in first */
    rv_live.countin = (uint8_t)((countin_left + 3) / 4);
    playing = 1;
}

static void seq_stop(void)
{
    if (gl.on)                                        /* stopped mid-glide: straight there */
        gl.u = 1.0f, glide_tick(0);
    countin_left = 0;
    rv_live.countin = 0;
    int t, k;
    playing = 0;
    evn = 0;
    for (t = 0; t < RV_TRACKS; t++) {
        for (k = 0; k < TP_N; k++)
            trk[t].lockon[k] = 0;
        trk[t].lockany = 0;
        rv_live.step[t][0] = rv_live.step[t][1] = -1;
        sq[t].tied = 0;
    }
    all_off_now();
    arp_stop();
}


/* events due in this control step */
/* in the order they fall (a note-off before a note-on at the same moment): a step is long enough
 * (128 frames) for a ratchet's off and its next hit to share one */
static void seq_events(int n)
{
    uint32_t end = now_s + (uint32_t)n;
    for (;;) {
        event_t e;
        int j, best = -1;
        for (j = 0; j < evn; j++) {
            int32_t d;
            if ((int32_t)(evq[j].when - end) >= 0)
                continue;
            d = best < 0 ? -1 : (int32_t)(evq[j].when - evq[best].when);
            if (best < 0 || d < 0 || (d == 0 && evq[j].type == EV_OFF && evq[best].type != EV_OFF))
                best = j;
        }
        if (best < 0)
            break;
        e = evq[best];
        evq[best] = evq[--evn];
        switch (e.type) {
        case EV_ADV:
            if (playing)
                head_advance(e.track, e.head & 1, e.when);
            break;
        case EV_ON: {
            seqtrk_t *q = &sq[e.track];
            if (q->tied && q->tied - 1 == e.note) {
                /* a tie into the same note carries on: no new attack */
            } else if (e.head & 0x40) {               /* a kit lane's hit: with its step's locks */
                perc_lock_prepare(e.track, e.note - 60, e.env, e.step);
                hs_move(e.rmv, 1);
                note_on_internal(e.track, e.note, e.vel, 0, e.chain);
            } else {
                hs_move(e.rmv, 0);
                note_on_internal(e.track, e.note, e.vel, e.env, e.chain);
                if (q->tied)
                    note_off_internal(e.track, q->tied - 1);   /* the tied note ends as the next begins */
            }
            q->tied = (uint8_t)((e.head & 0x80u) ? e.note + 1 : 0);
            break;
        }
        case EV_OFF:
            note_off_internal(e.track, e.note);
            break;
        case EV_ARP:
            if (e.chain == arp[e.track & 7].gen)
                arp_step(e.track & 7, e.when);
            break;
        case EV_AOFF:
            if (e.chain == arp[e.track & 7].serial)
                arp_silence(e.track & 7);
            break;
        case EV_CUT:
            cut_now(e.note, step_seconds(e.track));
            break;
        case EV_SPARK:                                /* a tap on a strike track's body, at its last note */
            if (rv.tp[e.track][TP_KIND] == KIND_STRIKE) {
                event_t off = e;
                spark_pend = 1;
                note_on_internal(e.track, e.note, e.vel, 0, e.chain);
                off.type = EV_OFF;
                off.when = e.when + (uint32_t)(step_seconds(e.track) * 0.5f * RV_FS);
                ev_push(&off);
            }
            break;
        case EV_TRIG:
            note_on_internal(e.track, e.note, e.vel, 0, e.chain);
            {
                event_t off = e;
                off.type = EV_OFF;
                off.when = e.when + (uint32_t)(step_seconds(e.track) * 0.5f * RV_FS);
                ev_push(&off);
            }
            break;
        default:
            break;
        }
    }
}

/* ------------------------------------------------------------- influence --- */
static void infl_fire(int a, int note, int vel, uint16_t chain, uint32_t when)
{
    int b;
    for (b = 0; b < RV_TRACKS; b++) {
        const rv_route *r = &rv.infl[a][b];
        event_t e;
        if (r->type == RT_OFF)
            continue;
        switch (r->type) {
        case RT_TRIG:
            /* a chain never re-enters a track it has already played this time round */
            if (chain & (1u << b))
                break;
            if (r->chance && r->chance < 100 && xs_uni(&seq_rng) * 100.0f >= (float)r->chance)
                break;
            e.type = EV_TRIG;
            e.track = (uint8_t)b;
            e.note = (uint8_t)clampi(note + (r->amt > 0 ? 0 : 0), 0, 127);
            e.vel = (uint8_t)clampi(vel * (64 + (r->amt < 0 ? r->amt : 0)) / 64, 1, 127);
            e.chain = (uint16_t)(chain | (1u << b));
            e.when = when + (uint32_t)((float)r->arg * step_seconds(a) * RV_FS);
            ev_push(&e);
            rv_live.route_fire[a][b] = 255;
            break;
        case RT_CLOCK:
            if (playing && !(chain & (1u << b) && a != b))
                track_advance(b, when);
            rv_live.route_fire[a][b] = 255;
            break;
        case RT_SPARK:                                /* the hit taps b's body: it rings, no note of its own */
            if (a != b && rv.tp[b][TP_KIND] == KIND_STRIKE && r->amt > 0) {
                e.type = EV_SPARK;
                e.track = (uint8_t)b;
                e.note = (uint8_t)clampi(60 + (int)trk[b].lead_key, 0, 127);
                e.vel = (uint8_t)clampi(vel * r->amt / 63, 1, 127);
                e.chain = (uint16_t)(chain | (1u << b));
                e.head = 0;
                e.rmv = 0;
                e.env = 0;
                e.step = 0;
                e.len_s = 0.0f;
                e.when = when;
                ev_push(&e);
                rv_live.route_fire[a][b] = 255;
            }
            break;
        default:
            break;
        }
    }
}

/* ------------------------------------------------------- the API side --- */
static void seq_transport_now(int run)
{
    if (run && !playing)
        seq_start();
    else if (!run && playing)
        seq_stop();
    rv_live.playing = playing;
}

static void scene_launch_now(int s)
{
    if (!playing) {
        pend_scene = (int8_t)(s & 15);
        apply_pending();
        return;
    }
    pend_scene = (int8_t)(s & 15);
}

void rv_scene_store(int s)
{
    rv_scene *sc = &rv.scene[s & 15];
    int t, b;
    sc->used = 1;
    for (t = 0; t < RV_TRACKS; t++) {
        sc->pattern[t] = rv.pat_cur[t];
        sc->level[t] = (uint8_t)rv.tp[t][TP_LEVEL];
        for (b = 0; b < RV_TRACKS; b++)
            sc->infl[t][b] = rv.infl[t][b];
    }
    sc->mute = rv.mute;
    for (t = 0; t < RV_MACROS; t++)
        sc->macro[t] = (int8_t)rv.gp[GP_MACRO1 + t];
}

static void pattern_launch_now(int t, int p)
{
    if (!playing) {
        rv.pat_cur[t & 7] = (uint8_t)(p % RV_PATTERNS);
        return;
    }
    pend_pat[t & 7] = (int8_t)(p % RV_PATTERNS);
}

/* ---------------------------------------------------------- kit locks --- */
int rv_kitlock_find(int t, int pat, int step, int lane, int field)
{
    const rv_kitlock *k = rv.kitlk[t & 7];
    uint8_t st = (uint8_t)((step & 63) | ((pat & 1) << 6)), w = (uint8_t)(lane << 4 | field);
    int i;
    for (i = 0; i < RV_KITLOCKS; i++)
        if (k[i].what == w && k[i].step == st)
            return i;
    return -1;
}

int rv_kitlock_set(int t, int pat, int step, int lane, int field, int v)
{
    rv_kitlock *k = rv.kitlk[t & 7];
    int i = rv_kitlock_find(t, pat, step, lane, field);
    if (i < 0)
        for (i = 0; i < RV_KITLOCKS && k[i].what != 0xFF; i++)
            ;
    if (i >= RV_KITLOCKS)
        return 0;
    k[i].step = (uint8_t)((step & 63) | ((pat & 1) << 6));
    k[i].what = (uint8_t)(lane << 4 | field);
    k[i].val = (uint8_t)clampi(v, 0, 127);
    return 1;
}

void rv_kitlock_clear(int t, int pat, int step, int lane)
{
    rv_kitlock *k = rv.kitlk[t & 7];
    int i;
    for (i = 0; i < RV_KITLOCKS; i++)
        if (k[i].what != 0xFF && (step < 0 || (k[i].step & 63) == (step & 63)) && ((k[i].step >> 6) & 1) == (pat & 1) &&
            (lane < 0 || (k[i].what >> 4) == lane))
            k[i].what = 0xFF;
}

/* a step moved (hold a step and tap another, or turn PRESETS): the step, its locks and a kit's (kept apart) go to
 * the other place; what was there goes, and where it came from is left empty */
RV_SMALL void rv_step_move(int t, int from, int to)
{
    int pat = rv.pat_cur[t & 7] % RV_PATTERNS, i;
    rv_step *p = rv.pat[t & 7][pat].s;
    from &= 63;
    to &= 63;
    if (from == to)
        return;
    p[to] = p[from];
    __builtin_memset(&p[from], 0, sizeof p[from]);
    if (is_kit(t & 7)) {
        rv_kitlock *k = rv.kitlk[t & 7];
        rv_kitlock_clear(t, pat, to, -1);
        for (i = 0; i < RV_KITLOCKS; i++)
            if (k[i].what != 0xFF && (k[i].step & 63) == from && ((k[i].step >> 6) & 1) == (pat & 1))
                k[i].step = (uint8_t)((k[i].step & 64) | to);
    }
}

/* COPY marks a pattern; PASTE copies it from where it is (no buffer: RAM is tight), with a kit's locks */
static int8_t clip_t = -1, clip_p;

void rv_pattern_copy(int t)
{
    clip_t = (int8_t)(t & 7);
    clip_p = (int8_t)(rv.pat_cur[t & 7] % RV_PATTERNS);
}

/* 0 pasted; -1 nothing copied; -2 notes into a kit or lanes into notes */
int rv_pattern_paste(int t)
{
    int pat = rv.pat_cur[t & 7] % RV_PATTERNS, i;
    if (clip_t < 0)
        return -1;
    if (is_kit(clip_t) != is_kit(t & 7))
        return -2;
    if (clip_t == (t & 7) && clip_p == pat)
        return 0;
    rv.pat[t & 7][pat] = rv.pat[clip_t][clip_p];
    rv_kitlock_clear(t, pat, -1, -1);
    for (i = 0; i < RV_KITLOCKS; i++) {
        rv_kitlock k = rv.kitlk[clip_t][i];       /* (a copy: the table may be the same one) */
        if (k.what != 0xFF && ((k.step >> 6) & 1) == (clip_p & 1))
            rv_kitlock_set(t, pat, k.step & 63, k.what >> 4, k.what & 15, k.val);
    }
    return 0;
}

void rv_pattern_clear(int t)
{
    int i;
    rv_pattern *p = &rv.pat[t & 7][rv.pat_cur[t & 7] % RV_PATTERNS];
    rv_kitlock_clear(t, rv.pat_cur[t & 7] % RV_PATTERNS, -1, -1);   /* a kit's locks go with its steps */
    for (i = 0; i < RV_STEPS; i++) {
        rv_step *s = &p->s[i];
        uint8_t *b = (uint8_t *)s;
        int k;
        for (k = 0; k < (int)sizeof(*s); k++)
            b[k] = 0;
        s->note = 60;
        s->vel = 100;
        s->len = 4;
        s->chance = 100;
    }
}

static uint32_t tap_last, tap_n;
static float tap_avg;
static void tap_tempo_now(void)
{
    uint32_t t = now_s;
    float d = (float)(t - tap_last) * RV_DT;
    tap_last = t;
    if (d > 0.2f && d < 2.0f) {
        tap_avg = tap_n ? tap_avg * 0.6f + d * 0.4f : d;
        tap_n++;
        if (tap_n >= 2)
            rv.gp[GP_TEMPO] = (int16_t)clampi((int)(60.0f / tap_avg + 0.5f), 30, 240);
    } else {
        tap_n = 0;
    }
}

static void record_arm_now(int t, int on)
{
    seqtrk_t *s = &sq[t & 7];
    if (on) {
        rv_live.recording = 1;
        rv_live.rec_track = (uint8_t)(t & 7);
        s->first_take = 0;                          /* (a first take on an empty pattern used to set LENGTH to the
                                                     * steps it ran: a long take, or one left armed, made it 64.
                                                     * LENGTH is only ever what you set) */
        s->take_steps = 0;
    } else {
        s->first_take = 0;
        rv_live.recording = 0;
    }
}

/* step recording: stopped, armed, on a SEQ page (the interface turns it on). The keys (or MIDI notes) held
 * together are written on the cursor's step as one note or a chord of up to four, replacing what it held
 * (its locks and tricks stay); when the last of them is let go, the cursor moves to the next step. A rest
 * empties the cursor's step and moves on; back moves the cursor back a step. */
static int8_t srec_t = -1;
static uint8_t srec_cur, srec_n;
static uint8_t srec_elen = 4;                         /* the entry length (code, as a step's LENGTH): the knob sets it */
static uint8_t srec_stay;                             /* STAY: letting go leaves the cursor where it is (note input) */
static uint8_t srec_down[8];                          /* the notes down now */
static int srec_len(int t) { return clampi(rv.tp[t][TP_LEN], 1, RV_STEPS); }
static void srec_cmd(int op, int t, int step)
{
    if (op == SREC_ON && srec_t != t) {
        const rv_pattern *p = &rv.pat[t][rv.pat_cur[t] % RV_PATTERNS];
        int i, len = srec_len(t), last = -1;
        for (i = 0; i < len; i++)                     /* the cursor starts after the last note */
            if (p->s[i].flags & ST_ON)
                last = i;
        srec_t = (int8_t)t;
        srec_cur = (uint8_t)((last + 1) % len);
        srec_n = 0;
    } else if (op == SREC_OFF) {
        srec_t = -1;
        srec_n = 0;
    } else if (srec_t >= 0 && srec_n == 0 && op != SREC_LEN && op != SREC_STAY) {
        int len = srec_len(srec_t);
        rv_step *s = &rv.pat[srec_t][rv.pat_cur[srec_t] % RV_PATTERNS].s[srec_cur % len];
        if (op == SREC_REST) {
            s->flags &= (uint8_t)~ST_ON;
            srec_cur = (uint8_t)((srec_cur + 1) % len);
        } else if (op == SREC_BACK)
            srec_cur = (uint8_t)((srec_cur + len - 1) % len);
        else if (op == SREC_TO)
            srec_cur = (uint8_t)(((step % len) + len) % len);
    }
    if (op == SREC_LEN)                               /* (any time: the notes to come take it) */
        srec_elen = (uint8_t)clampi(step, 1, RV_LEN_MAX);
    if (op == SREC_STAY)
        srec_stay = (uint8_t)(step != 0);
    rv_live.srec_step = (int8_t)(srec_t < 0 ? -1 : srec_cur);
}
static int srec_note(int t, int note, int vel)       /* 1: step recording took it */
{
    int len, k, c;
    rv_step *s;
    if (srec_t != t || playing)
        return 0;
    len = srec_len(t);
    srec_cur = (uint8_t)(srec_cur % len);
    s = &rv.pat[t][rv.pat_cur[t] % RV_PATTERNS].s[srec_cur];
    if (vel > 0) {
        for (k = 0; k < srec_n; k++)
            if (srec_down[k] == note)
                return 1;
        if (srec_n == 0) {                            /* the first key: the step's note, the chord cleared */
            s->flags = ST_ON;
            s->note = (uint8_t)note;
            s->vel = (uint8_t)vel;
            s->micro = 0;
            s->len = srec_elen;
            s->chord[0] = s->chord[1] = s->chord[2] = 0;
        } else if (note - s->note >= -64 && note - s->note <= 63) {   /* the next ones: its chord */
            for (c = 0; c < 3; c++)
                if (!s->chord[c]) {
                    s->chord[c] = (int8_t)(note - s->note);
                    break;
                }
        }
        if (srec_n < sizeof srec_down)
            srec_down[srec_n++] = (uint8_t)note;
    } else {
        for (k = 0; k < srec_n; k++)
            if (srec_down[k] == note) {
                srec_down[k] = srec_down[--srec_n];
                if (srec_n == 0 && !srec_stay) {      /* all let go: past the note (a step, or its length) */
                    int adv = (int)(rv_len_steps(s->len) + 0.999f);
                    srec_cur = (uint8_t)((srec_cur + (adv > 1 ? adv : 1)) % len);
                }
                break;
            }
    }
    rv_live.srec_step = (int8_t)srec_cur;
    return 1;
}

/* where a live event lands: the step and its micro offset */
static int live_step_pos(int t, int *micro)
{
    seqtrk_t *s = &sq[t];
    float sd = s->step_dur > 0.0f ? s->step_dur : step_seconds(t);
    float frac = (float)(now_s - s->step_time) * RV_DT / sd - (float)LATENCY_TICKS / 24.0f;
    int si = s->step[0] < 0 ? 0 : s->step[0], len = clampi(rv.tp[t][TP_LEN], 1, RV_STEPS);
    if (frac > 0.5f) {
        si = (si + 1) % len;
        frac -= 1.0f;
    }
    *micro = clampi((int)(frac * 24.0f + (frac >= 0.0f ? 0.5f : -0.5f)), -6, 12);
    return si;
}

/* TAKE: while it plays and you're not recording, what you play on the track in view is written, as
 * recording would write it, into a pattern of its own, each step stamped with when; TAKE (REC + SAVE)
 * copies the steps played in the last loop into the track's pattern (rv_take). A new track in view
 * starts it afresh */
static rv_pattern take_pat RV_RAMBSS;
static uint32_t take_when[RV_STEPS];                  /* the step's playhead count when written + 1 (0: nothing) */
static int8_t take_owner = -1;
static void take_now(void)
{
    int t = take_owner, len, si, n = 0, c;
    uint32_t cur;
    if (t < 0) {
        rv_live.take_res = 1;
        return;
    }
    len = clampi(rv.tp[t][TP_LEN], 1, RV_STEPS);
    cur = sq[t].travelled[0] + 1u;
    for (si = 0; si < len; si++) {
        const rv_step *a = &take_pat.s[si];
        rv_step *d = &rv.pat[t][rv.pat_cur[t] % RV_PATTERNS].s[si];
        if (!take_when[si] || cur - take_when[si] >= (uint32_t)len || !(a->flags & ST_ON))
            continue;                                 /* (nothing, or from an earlier loop) */
        if (is_kit(t)) {
            if (!(d->flags & ST_ON)) {
                d->note = d->env = d->len = 0;
                d->vel = 100;
                d->chance = 100;
                d->micro = a->micro;
            }
            d->flags |= ST_ON;
            d->note |= a->note;
        } else {
            d->flags = ST_ON;
            d->note = a->note;
            d->vel = a->vel;
            d->micro = a->micro;
            d->len = a->len;
            for (c = 0; c < 3; c++)
                d->chord[c] = a->chord[c];
        }
        n++;
    }
    __builtin_memset(&take_pat, 0, sizeof take_pat);
    __builtin_memset(take_when, 0, sizeof take_when);
    rv_live.take_res = (uint8_t)(n + 1 > 255 ? 255 : n + 1);
}

/* a step written by recording whose key is still held (while recording that track) */
static int rec_key_down(int t, int si)
{
    int k;
    if (!rv_live.recording || rv_live.rec_track != t)
        return 0;
    for (k = 0; k < 16; k++)
        if (sq[t].held_note[k] == si)
            return 1;
    return 0;
}

static RV_SMALL void record_note(int t, int note, int vel)
{
    int micro, si, k, shadow = 0;
    rv_step *s, *base;
    if (srec_note(t, note, vel))
        return;
    if (!playing || rv.tp[t][TP_KIND] == KIND_LOOP)   /* (a LOOP track records sound, not notes) */
        return;
    if (rv_live.recording && rv_live.rec_track == t)
        base = rv.pat[t][rv.pat_cur[t] % RV_PATTERNS].s;
    else if (t == (rv_live.ui_track & 7)) {           /* not recording: for TAKE */
        if (take_owner != t) {
            __builtin_memset(&take_pat, 0, sizeof take_pat);
            __builtin_memset(take_when, 0, sizeof take_when);
            take_owner = (int8_t)t;
        }
        base = take_pat.s;
        shadow = 1;
    } else
        return;
    if (countin_left > 0 && !shadow) {                           /* the count-in: only a note just before the top counts, on step 1 */
        if (countin_left > 1 || vel == 0)
            return;
        si = 0;
        micro = 0;
    } else
        si = live_step_pos(t, &micro);
    s = &base[si];
    if (is_kit(t)) {                                  /* a kit: the key's lane plays on this step */
        int lane = perc_lane_of(note), tlen = clampi(rv.tp[t][TP_LEN], 1, RV_STEPS);
        int llen = rv.kit[t].len[lane] ? clampi(rv.kit[t].len[lane], 1, RV_STEPS) : tlen;
        if (llen != tlen && countin_left == 0 && sq[t].step[0] >= 0) {   /* a lane with its own LENGTH: its own step */
            uint32_t ahead = si != sq[t].step[0] ? 1u : 0u;
            si = (int)((sq[t].travelled[0] - 1u + ahead) % (uint32_t)llen);
            s = &base[si];
        }
        if (vel > 0) {
            if (!(s->flags & ST_ON)) {
                s->note = 0;
                s->env = 0;
                s->len = 0;
                s->vel = 100;
                s->chance = 100;
                s->micro = (int8_t)micro;
            }
            s->flags |= ST_ON;
            s->note |= (uint8_t)(1u << perc_lane_of(note));
            if (shadow)
                take_when[si] = sq[t].travelled[0] + 1u;
        }
        return;
    }
    if (vel > 0) {
        int held_here = 0, c;
        for (k = 0; k < 16; k++)                      /* a key recorded on this step still down: this one joins its chord */
            if (sq[t].held_note[k] == si && (s->flags & ST_ON))
                held_here = 1;
        if (held_here && note != s->note && note - s->note >= -64 && note - s->note <= 63) {
            for (c = 0; c < 3; c++)
                if (s->chord[c] == note - s->note)
                    break;                            /* (already in it) */
            if (c == 3)
                for (c = 0; c < 3; c++)
                    if (!s->chord[c]) {
                        s->chord[c] = (int8_t)(note - s->note);
                        break;
                    }
        } else {
            s->flags = ST_ON;
            s->note = (uint8_t)note;
            s->vel = (uint8_t)vel;
            s->micro = (int8_t)micro;
            s->len = 4;
            s->chord[0] = s->chord[1] = s->chord[2] = 0;
        }
        if (shadow)
            take_when[si] = sq[t].travelled[0] + 1u;
        for (k = 0; k < 16; k++)
            if (sq[t].held_note[k] < 0 || k == 15) {
                sq[t].held_note[k] = (int8_t)si;
                sq[t].held_key[k] = (int8_t)note;
                sq[t].held_on[k] = now_s;
                break;
            }
        (void)note;
    } else {
        for (k = 0; k < 16; k++)
            if (sq[t].held_note[k] >= 0 && sq[t].held_key[k] == note) {   /* (a chord's notes share the step's length) */
                rv_step *st = &base[sq[t].held_note[k]];
                float steps = (float)(now_s - sq[t].held_on[k]) * RV_DT / (sq[t].step_dur > 0.0f ? sq[t].step_dur : 0.125f);
                st->len = (uint8_t)rv_len_code(steps);   /* (the last key let go sets it) */
                sq[t].held_note[k] = -1;
                break;
            }
    }
}

/* a knob moved while recording: write it into the playing step as a lock */
static void motion_now(int pid, int v)
{
    int t, p, k, slot = -1;
    rv_step *s;
    const rv_pinfo *pi;
    if (!playing || !rv_live.recording || pid >= RV_GPID)
        return;
    t = pid / RV_TP;
    p = pid % RV_TP;
    if (sq[t].step[0] < 0)
        return;
    s = &rv.pat[t][rv.pat_cur[t] % RV_PATTERNS].s[sq[t].step[0]];
    for (k = 0; k < 2; k++)
        if (s->lp[k] == p + 1)
            slot = k;
    if (slot < 0)
        slot = !s->lp[0] ? 0 : !s->lp[1] ? 1 : 1;
    pi = rv_pinfo_track(t, p);
    s->lp[slot] = (uint8_t)(p + 1);
    s->lv[slot] = (uint8_t)clampi(v - pi->min, 0, 255);
}

static void seq_init(void)
{
    int t, k;
    rv_live.srec_step = -1;
    for (t = 0; t < RV_TRACKS; t++) {
        pend_pat[t] = -1;
        sq[t].step[0] = sq[t].step[1] = -1;
        for (k = 0; k < 16; k++)
            sq[t].held_note[k] = -1;
        rv_live.step[t][0] = rv_live.step[t][1] = -1;
    }
    clock_reset();
}
