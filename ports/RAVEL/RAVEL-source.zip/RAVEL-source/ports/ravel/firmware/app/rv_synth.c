/* SPDX-License-Identifier: GPL-3.0-only */
/* Ravel: articulation and the six synth engines (VA, PD, FM, PHYS, FORMANT, PARTICLE).
 * Part of the engine unit (ravel_app.c). */
#include "rv_int.h"

/* ----------------------------------------------------------- articulation --- */
static __attribute__((noinline)) void artic_cfg_track(artic_cfg_t *c, const float *eff)   /* (once a voice a step: in the flash since v1.20, for SPACE's room in RAM) */
{
    c->atk = rv_time_f(eff[TP_ATK]);
    c->dec = rv_time_f(eff[TP_DEC]);
    c->sus = clampf(eff[TP_SUS] * (1.0f / 127.0f), 0.0f, 1.0f);
    c->rel = rv_time_f(eff[TP_REL]);
    c->curve = clampf(eff[TP_ACURVE] * (1.0f / 64.0f), -1.0f, 1.0f);
    c->over = clampf(eff[TP_OVER] * (1.0f / 127.0f), 0.0f, 1.0f);
    c->loop = eff[TP_LOOP] < 0.5f ? 0.0f : 4.0f * fm_exp2f(-eff[TP_LOOP] * (13.0f / 127.0f));   /* 4 s .. 0.5 ms */
    c->give = clampf(eff[TP_GIVE] * (1.0f / 127.0f), 0.0f, 1.0f);
    c->tail = clampf(eff[TP_TAIL] * (1.0f / 127.0f), 0.0f, 1.0f);
}

/* the shapes (rv_shapes.h, after the XAOC Zadar's library): the WAVE engine's ENV reads them, a shape
 * at u (0..1), WARP bending time and MORPH crossfading toward the next */
#define SHP_DATA
#include "rv_shapes.h"
static float shp_eval(int shape, float morph, float warp, float u)
{
    float x, fr, a, b;
    int i, s0 = (shape - 1) % SHP_N, s1 = shape % SHP_N;
    u = clampf(u, 0.0f, 1.0f);
    if (warp > 0.01f || warp < -0.01f)             /* > 0: lingers early, < 0: rushes early */
        u = fm_powf(u, fm_exp2f(warp));
    x = u * (float)(SHP_LEN - 1);
    i = (int)x;
    if (i >= SHP_LEN - 1)
        i = SHP_LEN - 2;
    fr = x - (float)i;
    a = shp_tab[s0][i] + (shp_tab[s0][i + 1] - shp_tab[s0][i]) * fr;
    if (morph < 0.004f)
        return a * (1.0f / 255.0f);
    b = shp_tab[s1][i] + (shp_tab[s1][i + 1] - shp_tab[s1][i]) * fr;
    return (a + (b - a) * morph) * (1.0f / 255.0f);
}
/* the FILTER ENV ----------------------------------------------------------------------------- */
static void fenv_start(fenv_t *e)
{
    e->stage = FE_DLY;
    e->u = 0.0f;
    e->from = e->lvl;                            /* a new note rises from wherever it is */
}
static void fenv_release(fenv_t *e)
{
    if (e->stage == FE_OFF || e->stage == FE_REL)
        return;
    e->stage = FE_REL;
    e->u = 0.0f;
    e->from = e->lvl;
}
/* a bend: k = 0 straight, k > 0 exponential (slow, then a rush), k < 0 logarithmic (a rush, then slow) */
static float fe_bend(float u, float k)
{
    if (k > -0.05f && k < 0.05f)
        return u;
    return (fm_expf(k * u) - 1.0f) / (fm_expf(k) - 1.0f);
}
/* dt seconds on (a block); returns the level 0..1 */
RV_INL float fenv_tick(fenv_t *e, const float *eff, float dt)
{
    float sc = fm_exp2f(-eff[TP_FRATE] * (1.0f / 16.0f)), sus = clampf(eff[TP_FSUS] * (1.0f / 127.0f), 0.0f, 1.0f), t;
    float ka = eff[TP_FACRV] * (6.0f / 64.0f), kd = -eff[TP_FDCRV] * (6.0f / 64.0f);
    switch (e->stage) {
    case FE_DLY:
        t = rv_time_f(eff[TP_FDLY]) * sc;
        e->u += t > 0.0005f ? dt / t : 1.0f;
        if (e->u >= 1.0f) {
            e->stage = FE_ATK;
            e->u = 0.0f;
        }
        e->lvl = e->from;
        break;
    case FE_ATK:
        t = rv_time_f(eff[TP_FATK]) * sc;
        e->u += dt / (t > 0.0002f ? t : 0.0002f);
        if (e->u >= 1.0f) {
            e->stage = FE_HOLD;
            e->u = 0.0f;
            e->lvl = 1.0f;
        } else
            e->lvl = e->from + (1.0f - e->from) * fe_bend(e->u, ka);
        break;
    case FE_HOLD:
        t = rv_time_f(eff[TP_FHOLD]) * sc;
        e->u += t > 0.0005f ? dt / t : 1.0f;
        if (e->u >= 1.0f) {
            e->stage = FE_DEC;
            e->u = 0.0f;
            e->from = 1.0f;
        }
        e->lvl = 1.0f;
        break;
    case FE_DEC:
        t = rv_time_f(eff[TP_FDEC]) * sc;
        e->u += dt / (t > 0.0005f ? t : 0.0005f);
        if (e->u >= 1.0f) {
            e->lvl = sus;
            e->u = 0.0f;
            e->from = sus;
            e->stage = eff[TP_FLOOP] >= 0.5f ? FE_DLY : FE_SUS;   /* LOOP: round again from the delay, while held */
        } else
            e->lvl = e->from + (sus - e->from) * fe_bend(e->u, kd);
        break;
    case FE_SUS:
        e->lvl = sus;                            /* (follows the knob) */
        break;
    case FE_REL:
        t = rv_time_f(eff[TP_FREL]) * sc;
        e->u += dt / (t > 0.0005f ? t : 0.0005f);
        if (e->u >= 1.0f) {
            e->stage = FE_OFF;
            e->lvl = 0.0f;
        } else
            e->lvl = e->from * (1.0f - fe_bend(e->u, kd));
        break;
    default:
        e->lvl = 0.0f;
        break;
    }
    return e->lvl;
}

static inline float shape_up(float u, float c) { return u + c * u * (1.0f - u); }     /* c > 0: fast start */
static inline float shape_down(float u) { float r = 1.0f - u; return 1.0f - r * r * r; }  /* fast then slow */

static void artic_start(artic_t *a, const artic_cfg_t *c)
{
    a->stage = AS_ONSET;
    a->gate = 1;
    a->looping = 0;
    a->from = a->p;                              /* legato: from wherever it is */
    a->to = 1.0f + c->over * 0.6f;
    a->u = 0.0f;
    a->du = RV_DT / (c->atk > 0.0002f ? c->atk : 0.0002f);
    a->tailv = 0.0f;
}

static void artic_release(artic_t *a, const artic_cfg_t *c)
{
    if (a->stage == AS_OFF || a->stage == AS_TERM)
        return;
    a->gate = 0;
    a->stage = AS_TERM;
    a->from = a->p;
    a->to = 0.0f;
    a->u = 0.0f;
    a->du = RV_DT / (c->rel > 0.0005f ? c->rel : 0.0005f);
    a->tailv = c->tail;
}

/* one sample; returns the level */
RV_INL float artic_tick(artic_t *a, const artic_cfg_t *c)
{
    float o;
    switch (a->stage) {
    case AS_ONSET:
        a->u += a->du;
        if (a->u >= 1.0f) {
            a->p = a->to;
            a->stage = AS_CONT;
            a->from = a->p;
            a->to = c->sus;
            a->u = 0.0f;
            a->du = RV_DT / ((a->looping ? c->loop * 0.5f : c->dec) + 0.0002f);
        } else {
            a->p = a->from + (a->to - a->from) * shape_up(a->u, c->curve);
        }
        break;
    case AS_CONT:
        if (a->u < 1.0f) {
            a->u += a->du;
            a->p = a->from + (a->to - a->from) * shape_down(a->u > 1.0f ? 1.0f : a->u);
        } else if (c->loop > 0.0f && a->gate) {      /* loop back to the onset while held */
            a->stage = AS_ONSET;
            a->looping = 1;
            a->from = a->p;
            a->to = 1.0f + c->over * 0.6f;
            a->u = 0.0f;
            a->du = RV_DT / (c->loop * 0.5f + 0.0002f);
        } else {
            a->p += (c->sus - a->p) * 0.002f;          /* follows the sustain knob */
        }
        break;
    case AS_TERM:
        a->u += a->du;
        if (a->u >= 1.0f) {
            a->p = 0.0f;
            a->stage = AS_OFF;
        } else {
            float r = 1.0f - a->u;
            a->p = a->from * r * r * r;
        }
        a->tailv *= 0.9993f;
        break;
    default:
        a->p = 0.0f;
        a->tailv *= 0.9993f;
        break;
    }
    if (c->give > 0.001f) {                         /* the spring: 9 Hz, lightly damped */
        const float k = 3197.0f, damp = 2.0f * 0.16f * 56.5f;
        a->v += (k * (a->p - a->s) - damp * a->v) * RV_DT;
        a->s += a->v * RV_DT;
        o = a->p + c->give * 1.6f * (a->s - a->p);
    } else {
        a->s = a->p;
        a->v = 0.0f;
        o = a->p;
    }
    a->out = o < 0.0f ? 0.0f : o;
    return a->out;
}

/* ------------------------------------------------------------- tables --- */
#define WT_LEN 256
static int16_t wt[8][WT_LEN + 1];                  /* particle tables, Q14 */
static float sine_tab[1025];

static void synth_tables(void)
{
    int i, t;
    uint32_t ns = 0x1234567u;
    for (i = 0; i <= 1024; i++)
        sine_tab[i] = fm_sin_turns((float)i / 1024.0f);
    for (i = 0; i < WT_LEN; i++) {
        float x = (float)i / WT_LEN, v, w[8];
        w[0] = fm_sin_turns(x);
        w[1] = (fm_sin_turns(x) + 0.5f * fm_sin_turns(7 * x) + 0.33f * fm_sin_turns(13 * x) + 0.25f * fm_sin_turns(19 * x)) * 0.5f;
        v = 0.0f;
        for (t = 1; t < 12; t += 2)
            v += fm_sin_turns(t * x) / (float)t * (1.0f + 2.0f * fm_expf(-(t - 5) * (t - 5) * 0.2f));
        w[2] = v * 0.45f;
        v = 0.0f;
        for (t = 1; t < 16; t++) {
            float f = 130.0f * t, e = 1.0f / (1.0f + (f - 730.0f) * (f - 730.0f) / 4900.0f) + 0.5f / (1.0f + (f - 1090.0f) * (f - 1090.0f) / 8100.0f) +
                                      0.25f / (1.0f + (f - 2440.0f) * (f - 2440.0f) / 14400.0f);
            v += e * fm_sin_turns(t * x + 0.18f * t * t);
        }
        w[3] = v * 0.6f;
        w[4] = (fm_sin_turns(x) + 0.5f * fm_sin_turns(2.756f * x) + 0.3f * fm_sin_turns(5.404f * x)) * 0.6f;
        {
            int k = (int)(x * 256.0f);
            w[5] = (float)(((k & (k >> 3)) & 31)) / 15.5f - 1.0f;
        }
        w[6] = xs_bi(&ns) * 0.7f;
        w[7] = fm_sin_turns(x * (1.0f + 6.0f * x)) * (1.0f - x);
        for (t = 0; t < 8; t++)
            wt[t][i] = (int16_t)clampf(w[t] * 16384.0f, -32767.0f, 32767.0f);
    }
    for (t = 0; t < 8; t++)
        wt[t][WT_LEN] = wt[t][0];
}

RV_INL float sin_lut(float ph)              /* ph in turns, any range */
{
    float x = ph - fm_floorf(ph), f;
    int i;
    x *= 1024.0f;
    i = (int)x;
    f = x - (float)i;
    i &= 1023;                                  /* (a phase a hair below a whole turn: x - floor(x) rounds to 1) */
    return sine_tab[i] + (sine_tab[i + 1] - sine_tab[i]) * f;
}

static inline float wt_read(const int16_t *w, float ph)
{
    float x = ph - fm_floorf(ph), f;
    int i;
    x *= WT_LEN;
    i = (int)x;
    f = x - (float)i;
    i &= WT_LEN - 1;                            /* (the same) */
    return ((float)w[i] + (float)(w[i + 1] - w[i]) * f) * (1.0f / 16384.0f);
}

/* ---------------------------------------------------------------- VA --- */
static const float va_ratios[8] = {0.5f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f, 5.0f, 7.0f};

RV_HOT static void va_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    va_t *s = &v->e.va;
    float dt = f * RV_DT, wave = eff[TP_S0] * (1.0f / 127.0f), pw = 0.5f + (eff[TP_S1] - 64.0f) * (0.45f / 64.0f);
    int nsup = clampi((int)(eff[TP_S2] + 0.5f), 1, 7), i, k;
    float det = eff[TP_S3] * (1.0f / 127.0f), sub = eff[TP_S4] * (1.0f / 127.0f), noise = eff[TP_S5] * (1.0f / 127.0f);
    float osc1 = eff[TP_OSC1] * (1.0f / 127.0f);
    float tz = eff[TP_S6] * (1.0f / 127.0f), fmr = va_ratios[clampi((int)(eff[TP_S7] + 0.5f), 0, 7)];
    float sync = eff[TP_S8] * (1.0f / 127.0f);
    float norm = 1.0f / fm_sqrtf((float)nsup);
    static const float spread[7] = {0.0f, -0.11f, 0.11f, -0.37f, 0.37f, -0.71f, 0.71f};
    for (i = 0; i < n; i++) {
        float x = 0.0f, ph, sl_dt;
        if (tz > 0.001f) {                            /* through-zero FM: a sine modulator, naive carrier */
            float m = sin_lut(s->ph2);
            float inc = dt * (1.0f + tz * 6.0f * m);
            s->ph2 += dt * fmr;
            s->ph2 -= fm_floorf(s->ph2);
            s->ph += inc;
            s->ph -= fm_floorf(s->ph);
            ph = s->ph;
            x = (1.0f - wave) * (2.0f * ph - 1.0f) + wave * (ph < pw ? 1.0f : -1.0f);
            x = lerpf(x, sin_lut(ph), 0.5f);
        } else if (sync > 0.001f) {                   /* hard sync: a slave saw reset by the master */
            sl_dt = dt * (1.0f + sync * 3.0f);
            s->ph += dt;
            s->ph2 += sl_dt;
            if (s->ph >= 1.0f) {
                s->ph -= fm_floorf(s->ph);
                s->ph2 = s->ph * (sl_dt / dt);
            }
            s->ph2 -= fm_floorf(s->ph2);
            x = 2.0f * s->ph2 - 1.0f - blep(s->ph2, sl_dt);
            x = lerpf(x, s->ph2 < pw ? 1.0f : -1.0f, wave);
        } else {
            for (k = 0; k < nsup; k++) {               /* one saw, or a supersaw of up to seven */
                float d = dt * (1.0f + spread[k] * det * 0.06f);
                float p = k == 0 ? s->ph : s->sph[k];
                float saw, pul, p2;
                p += d;
                p -= fm_floorf(p);
                saw = 2.0f * p - 1.0f - blep(p, d);
                p2 = p + (1.0f - pw);
                p2 -= fm_floorf(p2);
                pul = (p < pw ? 1.0f : -1.0f) + blep(p, d) - blep(p2, d);
                x += lerpf(saw, pul, wave);
                if (k == 0)
                    s->ph = p;
                else
                    s->sph[k] = p;
            }
            x *= norm;
        }
        x *= osc1;                                     /* OSC LVL: the oscillator against SUB and NOISE */
        if (sub > 0.001f) {                            /* a square an octave down */
            s->sub += dt * 0.5f;
            s->sub -= fm_floorf(s->sub);
            x += sub * (s->sub < 0.5f ? 0.7f : -0.7f);
        }
        if (noise > 0.001f)
            x += noise * xs_bi(&s->ns) * 0.6f;
        out[i] = x * 0.5f;
    }
}

/* ---------------------------------------------------------------- CZ --- */
/* The Casio CZ (CZ-101/1000/3000/5000/CZ-1): what its NEC uPD933 chip does, as worked out in
 * MAME's uPD933 device (BSD-3-Clause, Devin Acker), driven the way the CZ's firmware drives it,
 * with the panel-to-chip conversions from the CZ's MIDI tone format.
 *
 * A line is one chip voice: a cosine read through a phase transfer that DCW bends (eight waves,
 * the resonant three a sine at 1 + DCW/64 times the pitch, hard-synced, under a saw, triangle or
 * trapezoid window). Two waves alternate cycle by cycle (the CZ's octave-down cascade). Each
 * line has three 8-step envelopes in the chip's units: DCO adds pitch (6.25-cent steps up to
 * level 63, then 2-semitone steps), DCW sets the bend (0..1016), DCA the level on the chip's
 * logarithmic curve (78 dB). A step's rate code (8 | r & 7) << (r >> 3) is how far it moves
 * each 40 kHz chip sample. Line 2 can be ring-modulated by line 1 or have its pitch kicked by
 * noise (0 or +32 semitones every 8 chip samples), as the chip does. */
static const uint16_t cz_vib_delay[100] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63, 67, 71, 75, 79, 83, 87, 91, 95, 99, 103, 107, 111, 115, 119, 123, 127, 135, 143, 151, 159, 167, 175, 183, 191, 199, 207, 215, 223, 231, 239, 247, 255, 271, 287, 303, 319, 335, 351, 367, 383, 399, 415, 431, 447, 463, 479, 495, 511, 543, 575, 607, 639};
static const uint16_t cz_vib_rate[100] = {32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, 480, 512, 544, 576, 608, 640, 672, 704, 736, 768, 800, 832, 864, 896, 928, 960, 992, 1024, 1120, 1184, 1248, 1312, 1376, 1440, 1504, 1568, 1632, 1696, 1760, 1824, 1888, 1952, 2016, 2080, 2272, 2400, 2528, 2656, 2784, 2912, 3040, 3168, 3296, 3424, 3552, 3680, 3808, 3936, 4064, 4192, 4576, 4832, 5088, 5344, 5600, 5856, 6112, 6368, 6624, 6880, 7136, 7392, 7648, 7904, 8160, 8416, 9184, 9696, 10208, 10720, 11232, 11744, 12256, 12768, 13280, 13792, 14304, 14816, 15328, 15840, 16352, 16864, 18400, 19424, 20448, 21472};
static const uint16_t cz_vib_depth[100] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63, 65, 71, 75, 79, 83, 87, 91, 95, 99, 103, 107, 111, 115, 119, 123, 127, 131, 143, 151, 159, 167, 175, 183, 191, 199, 207, 215, 223, 231, 239, 247, 255, 263, 287, 303, 319, 335, 351, 367, 383, 399, 415, 431, 447, 463, 479, 495, 511, 527, 575, 607, 639, 768};

static const uint8_t cz_kf_dca[10] = {0x00, 0x08, 0x11, 0x1A, 0x24, 0x2F, 0x3A, 0x45, 0x52, 0x5F};
static const uint8_t cz_kf_dcw[10] = {0x00, 0x1F, 0x2C, 0x39, 0x46, 0x53, 0x60, 0x6E, 0x92, 0xFF};
#define CZ_CHIP_STEP (40000.0f / RV_FS)                 /* chip samples per Ravel sample */

static float cz_rate_units(int which, int r)
{
    int c;
    r = clampi(r, 0, 99);
    c = which == CZE_DCO ? 127 * r / 99 : which == CZE_DCW ? 119 * r / 99 + 8 : 119 * r / 99;
    return (float)((8 | (c & 7)) << (c >> 3));
}

static float cz_level_units(int which, int l)
{
    l = clampi(l, 0, 99);
    if (which == CZE_DCO)                             /* 0..63: 6.25 cents; 64..99: 2 semitones from 8 */
        return l <= 63 ? (float)(l << 16) : (float)((l - 60) << 21);
    return (float)((127 * l / 99) << (which == CZE_DCW ? 19 : 18));
}

static void cz_env_aim(czenv_t *e, const rv_czenv *p, int which, float kf)
{
    int s = clampi(e->step, 0, 7);
    e->target = cz_level_units(which, p->level[s]);
    e->rate = cz_rate_units(which, p->rate[s]) * kf;
    e->run = 1;
}

static void cz_env_start(czenv_t *e, const rv_czenv *p, int which, float kf)
{
    e->cur = 0.0f;
    e->step = 0;
    cz_env_aim(e, p, which, kf);
}

/* the key went up: on to the step after the sustain point (if it was not passed yet) */
static void cz_env_release(czenv_t *e, const rv_czenv *p, int which, float kf)
{
    int sus = clampi(p->sus, 0, 8), end = clampi(p->end, 1, 8);
    if (sus && e->step < sus && sus < end) {
        e->step = (int8_t)sus;
        cz_env_aim(e, p, which, kf);
    } else if (e->run == 2) {
        e->run = e->step + 1 < end ? 1 : 0;
        if (e->run) {
            e->step++;
            cz_env_aim(e, p, which, kf);
        }
    }
}

/* n Ravel samples: towards the step's level, then the next step, the sustain point or the end */
static void cz_env_tick(czenv_t *e, const rv_czenv *p, int which, float kf, int gate, int n)
{
    int sus = clampi(p->sus, 0, 8), end = clampi(p->end, 1, 8);
    float mv;
    if (e->run != 1)
        return;
    mv = e->rate * (float)n * CZ_CHIP_STEP;
    if (fm_fabsf(e->target - e->cur) <= mv) {
        e->cur = e->target;
        if (sus && e->step == sus - 1 && gate)
            e->run = 2;
        else if (e->step >= end - 1)
            e->run = 0;
        else {
            e->step++;
            cz_env_aim(e, p, which, kf);
        }
    } else {
        e->cur += e->target > e->cur ? mv : -mv;
    }
}

static int cz_chip_wave(int w) { static const uint8_t m[9] = {0, 0, 1, 2, 4, 5, 6, 6, 6}; return m[clampi(w, 0, 8)]; }

/* one line's sample: pos 0..4096 (two cycles), dcw 0..1023, window 0..3; 0..1 before the DCA */
RV_INL float cz_line_sample(int w0, int w1, int win, float pos, float dcw)
{
    float p = pos >= 2048.0f ? pos - 2048.0f : pos, ph = 0.0f, pv = 1024.0f - dcw, wv = 0.0f, s;
    int w = pos >= 2048.0f ? w1 : w0;
    if (pv < 1.0f)
        pv = 1.0f;
    switch (w) {
    case 0: ph = p < pv ? p * 1024.0f / pv : 1024.0f + (p - pv) * 1024.0f / (2048.0f - pv); break;   /* saw */
    case 1: {                                                                                       /* square */
        float q = p >= 1024.0f ? p - 1024.0f : p;
        ph = (q < pv ? q * 1024.0f / pv : 1023.0f) + (p >= 1024.0f ? 1024.0f : 0.0f);
        break;
    }
    case 2: ph = p < pv * 2.0f ? p * 2048.0f / (pv * 2.0f) : 2047.0f; break;                          /* pulse */
    case 4: ph = p < pv ? p * 2048.0f / pv : (p - pv) * 2048.0f / (2048.0f - pv); break;               /* double sine */
    case 5: ph = p < 1024.0f ? p : p < pv + 1024.0f ? 1024.0f + (p - 1024.0f) * 1024.0f / pv : 2047.0f; break;   /* saw pulse */
    case 6: ph = p + p * dcw * (1.0f / 64.0f); ph -= 2048.0f * fm_floorf(ph * (1.0f / 2048.0f)); break;    /* resonance */
    default: break;
    }
    switch (win) {                                    /* the resonant waves' windows */
    case 1: wv = p; break;                                                    /* saw: falls over the cycle */
    case 2: wv = p < 1024.0f ? 2048.0f - p * 2.0f : (p - 1024.0f) * 2.0f; break; /* triangle */
    case 3: wv = p >= 1024.0f ? (p - 1024.0f) * 2.0f : 0.0f; break;           /* trapezoid: falls in the second half */
    default: break;
    }
    s = 0.5f - 0.5f * sin_lut(ph * (1.0f / 2048.0f) + 0.25f);   /* the chip's 0..1 cosine */
    return s * (1.0f - wv * (1.0f / 2048.0f));
}

static void cz_note(voice_t *v, const float *eff, int t)
{
    cz_t *c = &v->e.cz;
    int l, k, note = v->note, mode = clampi((int)(eff[TP_S0] + 0.5f), 0, 3);
    for (l = 0; l < 2; l++) {
        const rv_czline *pl = &rv.cz[t & 7].line[mode == 1 ? 1 : mode == 3 ? l : 0];
        float kfa = fm_exp2f((float)cz_kf_dca[clampi(pl->kf_dca, 0, 9)] * (1.0f / 95.0f) * (float)(note - 60) * (1.0f / 12.0f));
        c->l[l].pos = 0.0f;                           /* the CZ restarts the oscillator on each note */
        for (k = 0; k < 3; k++)
            cz_env_start(&c->l[l].env[k], &pl->env[k], k, k == CZE_DCA ? kfa : 1.0f);
    }
    c->vib_t = 0.0f;
    c->gate = 1;
    c->done = 0;
    if (!c->ns)
        c->ns = v->rng | 1u;
}

RV_INL void cz_render(voice_t *v, const float *eff, float f, float *out, int n, int t)
{
    cz_t *c = &v->e.cz;
    const rv_cz *pz = &rv.cz[t & 7];
    int mode = clampi((int)(eff[TP_S0] + 0.5f), 0, 3), oct = clampi((int)(eff[TP_S1] + 0.5f), 0, 2) - 1;
    int mod = clampi((int)(eff[TP_S2] + 0.5f), 0, 2), lines = mode >= 2 ? 2 : 1, i, l, k;
    int gate = v->a.gate, note = v->note;
    float det = ((float)clampi((int)(eff[TP_S5] + 0.5f), 0, 3) * 12.0f + (float)clampi((int)(eff[TP_S6] + 0.5f), 0, 11)
                 + eff[TP_S7] * (1.0f / 60.0f)) * (eff[TP_S4] > 0.5f ? -1.0f : 1.0f);
    float vib = 0.0f, foam = eff[TP_S13] * (1.0f / 127.0f), dcwoff = eff[TP_S12] * 8.0f;
    float veld = (float)clampi((int)(eff[TP_S14] + 0.5f), 0, 9) * (1.0f / 9.0f), lev = 0.0f;
    float dt[2], dcw[2], a0[2], a1[2];
    int w0[2], w1[2], win[2];
    /* the key went up */
    if (c->gate && !gate) {
        for (l = 0; l < 2; l++) {
            const rv_czline *pl = &pz->line[mode == 1 ? 1 : mode == 3 ? l : 0];
            float kfa = fm_exp2f((float)cz_kf_dca[clampi(pl->kf_dca, 0, 9)] * (1.0f / 95.0f) * (float)(note - 60) * (1.0f / 12.0f));
            for (k = 0; k < 3; k++)
                cz_env_release(&c->l[l].env[k], &pl->env[k], k, k == CZE_DCA ? kfa : 1.0f);
        }
    }
    c->gate = (uint8_t)gate;
    /* vibrato: after its delay, at its rate and depth, in one of four shapes */
    c->vib_t += (float)n * RV_DT;
    if (eff[TP_S11] > 0.5f && c->vib_t >= (float)cz_vib_delay[clampi((int)(eff[TP_S9] + 0.5f), 0, 99)] * 0.01f) {
        float x;
        int vw = clampi((int)(eff[TP_S8] + 0.5f), 0, 3);
        c->vib_ph += (float)cz_vib_rate[clampi((int)(eff[TP_S10] + 0.5f), 0, 99)] * 0.00085f * (float)n * RV_DT;
        c->vib_ph -= fm_floorf(c->vib_ph);
        x = vw == 0 ? (c->vib_ph < 0.5f ? 4.0f * c->vib_ph - 1.0f : 3.0f - 4.0f * c->vib_ph)
          : vw == 1 ? (c->vib_ph < 0.5f ? 1.0f : -1.0f) : vw == 2 ? 2.0f * c->vib_ph - 1.0f : 1.0f - 2.0f * c->vib_ph;
        vib = x * (float)cz_vib_depth[clampi((int)(eff[TP_S11] + 0.5f), 0, 99)] * (12.0f / 768.0f);
    }
    /* each line's settings and envelopes for this block */
    for (l = 0; l < lines; l++) {
        int src = mode == 1 ? 1 : mode == 3 ? l : 0;   /* 1, 2, 1+1' (line 1 twice), 1+2' */
        const rv_czline *pl = &pz->line[src];
        czline_t *ln = &c->l[l];
        float kfa = fm_exp2f((float)cz_kf_dca[clampi(pl->kf_dca, 0, 9)] * (1.0f / 95.0f) * (float)(note - 60) * (1.0f / 12.0f));
        float kfw = (float)cz_kf_dcw[clampi(pl->kf_dcw, 0, 9)] * (1.0f / 255.0f), semi, fl, lim, d;
        int wa = clampi(pl->wave1, 1, 8), wb = clampi(pl->wave2, 0, 8);
        if (wa >= 6 && wb >= 6)                        /* the CZ cannot cascade two resonant waves */
            wb = 0;
        w0[l] = cz_chip_wave(wa);
        w1[l] = wb ? cz_chip_wave(wb) : w0[l];
        win[l] = wa >= 6 ? wa - 5 : wb >= 6 ? wb - 5 : 0;
        a0[l] = ln->env[CZE_DCA].cur;
        for (k = 0; k < 3; k++)
            cz_env_tick(&ln->env[k], &pl->env[k], k, k == CZE_DCA ? kfa : 1.0f, gate, n);
        a1[l] = ln->env[CZE_DCA].cur;
        semi = ln->env[CZE_DCO].cur * (1.0f / 1048576.0f) + (float)oct * 12.0f + vib + (l == 1 ? det : 0.0f);
        fl = f * fm_exp2f(semi * (1.0f / 12.0f));
        dt[l] = clampf(fl * 4096.0f * 0.5f * RV_DT, 0.0f, 1900.0f);   /* 2048 units a cycle */
        d = ln->env[CZE_DCW].cur * (1.0f / 65536.0f);
        d *= clampf(1.0f - kfw * (float)(note - 36) * (1.0f / 48.0f), 0.0f, 1.0f);   /* DCW key follow: duller up high */
        d *= 1.0f - veld * (1.0f - v->vel) * 0.9f;                                      /* VEL DCW (CZ-1 style) */
        d += dcwoff;                                                                    /* DCW +- (modulatable) */
        lim = 1024.0f - clampf(fl * (8192.0f / 40000.0f), 0.0f, 1024.0f);              /* the chip's high-note limit */
        dcw[l] = clampf(d, 0.0f, lim > 0.0f ? lim : 0.0f);
        for (k = 0; k < 3; k++)
            rv_live.cz_step[t & 7][l * 3 + k] = (int8_t)(ln->env[k].run ? ln->env[k].step : -1);
    }
    /* the DCA as amplitude, on the chip's log curve (index 0..508 of 511 over 13 bits) */
    for (l = 0; l < lines; l++) {
        float i0 = a0[l] * (1.0f / 65536.0f), i1 = a1[l] * (1.0f / 65536.0f);
        a0[l] = i0 < 1.0f ? 0.0f : fm_exp2f(i0 * (13.0f / 511.0f) - 13.0f);
        a1[l] = i1 < 1.0f ? 0.0f : fm_exp2f(i1 * (13.0f / 511.0f) - 13.0f);
    }
    for (i = 0; i < n; i++) {
        float u = (float)i / (float)n, y = 0.0f, sa = 0.0f;
        for (l = 0; l < lines; l++) {
            czline_t *ln = &c->l[l];
            float amp = a0[l] + (a1[l] - a0[l]) * u, s, step = dt[l];
            if (l == 1 && mod == 2) {                  /* noise: line 2's pitch kicked every 8 chip samples */
                if (++c->pm_n >= 9) {
                    c->pm_n = 0;
                    c->pm = (xs_uni(&c->ns) < 0.5f) ? 0.0f : 1.0f;
                }
                if (c->pm > 0.5f)
                    step *= 6.3496f;                   /* +32 semitones */
            }
            s = (cz_line_sample(w0[l], w1[l], win[l], ln->pos, dcw[l]) - 0.5f) * 2.0f * amp;
            if (l == 1 && mod == 1)                     /* ring: line 2 times line 1, as the chip multiplies */
                s *= sa;
            ln->pos += step;
            if (ln->pos >= 4096.0f)
                ln->pos -= 4096.0f;
            if (l == 0) {
                sa = s;
                if (foam > 0.0f) {                      /* FOAM: the fundamental taken out, the sidebands left */
                    float p = ln->pos >= 2048.0f ? ln->pos - 2048.0f : ln->pos;
                    s -= foam * 0.8f * amp * -sin_lut(p * (1.0f / 2048.0f) + 0.25f);
                }
            }
            y += s;
        }
        out[i] = y * (lines == 2 ? 0.4f : 0.5f);
    }
    /* the level the rest of Ravel sees (the filter's envelope, influence, the matrix's ENV) */
    for (l = 0; l < lines; l++)
        if (a1[l] > lev)
            lev = a1[l];
    c->level = fm_sqrtf(lev);
    /* done: every line's DCA has stopped at nothing, or the key is up and it has nowhere to go */
    {
        int alive = 0;
        for (l = 0; l < lines; l++) {
            czenv_t *e = &c->l[l].env[CZE_DCA];
            if (e->run == 0 && !gate && e->cur > 0.0f) {   /* ended above zero with the key up: fade out */
                e->target = 0.0f;
                e->rate = cz_rate_units(CZE_DCA, 70);
                e->run = 1;
                e->step = 7;
            }
            if (e->run || e->cur >= 65536.0f)
                alive = 1;
        }
        c->done = (uint8_t)!alive;
    }
}

/* -------------------------------------------------------------- PIANO --- */
/* A grand piano, felted or not, by waveguides rather than samples: each note's strings (one in the low
 * bass, a detuned pair above, UNISON apart, so they beat and the tone blooms) are loops of delay. A felt
 * hammer's stroke goes into them: a smooth pulse, longer for a soft hammer, a gentle blow or the FELT
 * between hammer and strings (which reaches fewer partials, so the note is darker and rounder), struck
 * STRIKE along the string (the partials it misses). Each loop is read back through two allpasses that
 * stretch its upper partials sharp as a stiff steel string's are (STRETCH, more in the treble and the low
 * bass, as on a grand), and loses its highs faster than its fundamental (TONE). DECAY is how long a held
 * note rings (about 12 s at middle C, far longer in the bass, short at the top); when the key is let go
 * the damper stops it, unless PEDAL holds them off (half way: a half pedal), and the top octave and a
 * half has no dampers. THUMP is the key and hammer's knock at the start (louder with FELT, as on a felt
 * piano), KEY OFF the damper's soft noise as it lands, BODY the soundboard's warmth, DYNAMC how much
 * harder playing brightens the tone as well as its level. ATTACK lays a recording of a real grand's hammer strike
 * (25 ms of its bite and knock, above the strings' low partials) over the start of each note: the modelled
 * strings and a sampled attack, as hybrid pianos do. */
static float pn_atan(float x)                         /* (within about 1e-5) */
{
    float a = fm_fabsf(x), z, r;
    int inv = a > 1.0f;
    if (inv)
        a = 1.0f / a;
    z = a * a;
    r = a * (0.99997726f + z * (-0.33262347f + z * (0.19354346f + z * (-0.11643287f + z * (0.05265332f - z * 0.01172120f)))));
    if (inv)
        r = 1.57079633f - r;
    return x < 0.0f ? -r : r;
}
/* a first-order allpass's delay at w radians a sample, in samples (sw, cw: w's sine and cosine) */
static float pn_apd(float a, float w, float sw, float cw) { return 1.0f - 2.0f * pn_atan(a * sw / (1.0f + a * cw)) / w; }
#define PN_DAMPED 89
#include "rv_pnatk.h"                                 /* (ATTACK: a real grand's hammer strike, 25 ms, tools/make_piano_attack.py) */
#define PN_ECHO 0.45f                                 /* (how much of the stroke comes back from the near end: the partials it misses, not quite gone) */
static float pn_comb(float wd)                        /* that echo's effect on a partial wd radians out of step: |1 - k e^-jwd| */
{
    return fm_sqrtf(1.0f + PN_ECHO * PN_ECHO - 2.0f * PN_ECHO * fm_cosf(wd));
}
/* a raised-cosine pulse's spectrum, F cycles across it (its area 1/2 at F = 0) */
static float pn_hann(float F)
{
    float d = 1.0f - F * F, x = 3.14159265f * F;
    if (F < 1e-4f)
        return 0.5f;
    if (fm_fabsf(d) < 1e-3f)
        return 0.25f;
    return 0.5f * fm_sinf(x) / (x * d);
}                                  /* (F6: the first note with no damper) */

static RV_SMALL void piano_note(voice_t *v, const float *eff)
{
    piano_t *s = &v->e.pn;
    float f = note_hz((float)v->note + eff[TP_PITCH]), per = 44100.0f / f, vel = v->vel;
    float felt = eff[TP_S0] * (1.0f / 127.0f), hard = eff[TP_S1] * (1.0f / 127.0f), dyn = eff[TP_S11] * (1.0f / 127.0f);
    float uni = eff[TP_S6] * (1.0f / 127.0f), vt, t;
    int k, sz;
    if (!s->ns)
        s->ns = v->rng | 1u;
    s->nstr = per * 1.25f + 8.0f <= (float)(PN_BUF / 2) ? 2 : 1;
    sz = s->nstr == 2 ? PN_BUF / 2 : PN_BUF;
    __builtin_memset(s->buf, 0, sizeof s->buf);
    for (k = 0; k < 2; k++) {
        s->base[k] = (int16_t)(k * sz);
        s->size[k] = (int16_t)sz;
        s->w[k] = 0;
        s->ap[k][0] = s->ap[k][1] = s->fr[k] = s->lp[k] = 0.0f;
    }
    s->det[0] = s->nstr == 2 ? -uni * (0.6f + 0.6f * xs_uni(&s->ns)) : 0.0f;   /* cents */
    s->det[1] = uni * (0.6f + 0.6f * xs_uni(&s->ns));
    vt = 1.0f - dyn + dyn * vel;                      /* how hard it was played, as the tone hears it */
    t = 0.0010f * fm_powf(261.6f / f, 0.6f);          /* the hammer on the string: longer in the bass */
    t *= (1.0f + felt * 1.5f) * (1.4f - 0.8f * hard) * (1.6f - 0.95f * vt);
    s->exc_len = clampf(t * 44100.0f, 4.0f, fm_maxf(per * 0.9f, 4.0f));   /* (never longer than the string's period) */
    s->exc_pos = per * (0.055f + eff[TP_S7] * (0.12f / 127.0f));
    s->exc_t = 0.0f;
    s->hard = vt * vt * hard * (1.0f - felt) * 1.2f;  /* a hard hammer's edge: a shorter stroke on top */
    {                                                 /* its level: the same loudness whatever the note and the hammer */
        float e2 = 0.0f, w0 = 6.28318531f / per;
        int h, nh = (int)(per * 0.45f);
        if (nh > 48)
            nh = 48;
        for (h = 1; h <= nh; h++) {
            float F = (float)h * s->exc_len / per, G = F * (1.0f / 0.33f), x, cb;
            x = pn_hann(F) * s->exc_len + s->hard * pn_hann(G) * s->exc_len * 0.33f;
            cb = pn_comb((float)h * w0 * s->exc_pos);
            x *= cb * 2.0f / per;
            e2 += x * x * 0.5f;
        }
        s->exc_amp = 0.16f * (1.0f - 0.3f * felt) * (f > 261.6f ? fm_powf(f * (1.0f / 261.6f), 0.3f) : 1.0f) / fm_sqrtf(fm_maxf(e2, 1e-9f));
        if (s->exc_amp > 1.6f)
            s->exc_amp = 1.6f;
    }
    s->thump = eff[TP_S8] * (1.0f / 127.0f) * (0.3f + 0.7f * vel) * (0.5f + felt) * 1.6f;
    s->offn = s->nlp = s->dc = s->held = 0.0f;
    s->atk_pos = 0.0f;                                /* the recorded strike: followed half way to the note, darker for FELT */
    s->atk_rate = 0.5f * fm_exp2f((float)(v->note - 66) * (1.0f / 24.0f));
    s->atk_amp = eff[TP_S12] * (1.0f / 127.0f) * vel * fm_sqrtf(vel) * (1.0f - 0.85f * felt) * 0.22f * (1.0f / 127.0f);
    s->nz.ic1 = s->nz.ic2 = s->bd.ic1 = s->bd.ic2 = 0.0f;
    s->gate_was = 1;
}

/* the hammer: a smooth stroke, less its echo from the agraffe's end; a sample of it (out of the render: the pool is short) */
static __attribute__((noinline)) float pn_stroke(piano_t *s)
{
    float t = s->exc_t, L = s->exc_len, h = s->exc_len * 0.33f, e = 0.0f;
    if (t < L)
        e += 0.5f - 0.5f * fm_cosf(6.28318531f * t / L);
    if (t < h)
        e += s->hard * (0.5f - 0.5f * fm_cosf(6.28318531f * t / h));
    t -= s->exc_pos;
    if (t >= 0.0f && t < L)
        e -= PN_ECHO * (0.5f - 0.5f * fm_cosf(6.28318531f * t / L));
    if (t >= 0.0f && t < h)
        e -= PN_ECHO * s->hard * (0.5f - 0.5f * fm_cosf(6.28318531f * t / h));
    s->exc_t += 1.0f;
    return e * s->exc_amp;
}

/* the recorded strike's next sample (out of the render: the pool is short) */
static __attribute__((noinline)) RV_SMALL float pn_attack(piano_t *s)
{
    int i = (int)s->atk_pos;
    float f = s->atk_pos - (float)i, y;
    if (i >= PN_ATK_N - 1) {
        s->atk_pos = (float)PN_ATK_N;
        return 0.0f;
    }
    y = (float)pn_atk[i] + ((float)pn_atk[i + 1] - (float)pn_atk[i]) * f;
    s->atk_pos += s->atk_rate;
    return y * s->atk_amp;
}

/* a block's settings, worked out once a block (out of the render, in flash: the pool is short) */
typedef struct { float a, c, eta[2], g[2], gain, body, thd, ofd; int dly[2]; } pn_blk_t;
static __attribute__((noinline)) RV_SMALL int piano_block(voice_t *v, const float *eff, float f, int n, pn_blk_t *b)
{
    piano_t *s = &v->e.pn;
    int k, nst = s->nstr == 2 ? 2 : 1;
    float dt = (float)n * RV_DT, vel = v->vel;
    float felt = eff[TP_S0] * (1.0f / 127.0f), decay = eff[TP_S2] * (1.0f / 127.0f), pedal = eff[TP_S3] * (1.0f / 127.0f);
    float tone = eff[TP_S4] * (1.0f / 127.0f), body = eff[TP_S10] * (1.0f / 127.0f);
    float a, c, t60, lf;
    int damped = !v->a.gate && v->note < PN_DAMPED && pedal < 0.99f;
    if (!s->ns)
        s->ns = v->rng | 1u;
    if (!s->nstr)
        return 0;
    for (k = 0; k < nst; k++) {
        if (s->base[k] < 0 || s->size[k] < 16 || s->base[k] + s->size[k] > PN_BUF || (uint16_t)s->w[k] >= (uint16_t)s->size[k]) {
            s->nstr = 0;                              /* (another engine's bytes: silent until the next note) */
            return 0;
        }
        if (!(s->lp[k] == s->lp[k]) || !(s->fr[k] == s->fr[k]) || !(s->ap[k][0] == s->ap[k][0]) || !(s->ap[k][1] == s->ap[k][1]))
            s->lp[k] = s->fr[k] = s->ap[k][0] = s->ap[k][1] = 0.0f;
    }
    s->held += dt;
    if (!v->a.gate && s->gate_was) {                  /* let go: the damper lands, with its own soft noise */
        s->gate_was = 0;
        if (damped)
            s->offn = eff[TP_S9] * (1.0f / 127.0f) * (0.4f + 0.6f * vel) * 0.25f;
    }
    /* the strings' stiffness: their partials stretched sharp, most in the treble and the low bass */
    lf = fm_log2f(f * (1.0f / 55.0f));
    a = -fm_minf(clampf(0.9f - 0.125f * lf, 0.08f, 0.93f) * clampf(eff[TP_S5] * (1.0f / 64.0f), 0.0f, 1.25f), 0.93f);
    /* how long it rings, held; then what the damper leaves (or the pedal, half way: a half pedal) */
    t60 = (1.2f + decay * decay * 24.0f) * fm_minf(3.0f, fm_powf(261.6f / f, 0.55f));
    c = (0.01f + (1.0f - tone) * 0.16f + felt * 0.08f) * fm_powf(261.6f / f, 1.4f);   /* the loss: the highs die sooner (as fast, */
    c = clampf(c, 0.0f, 0.85f);                       /* a second, in the treble as in the bass: less a pass in a short loop) */
    if (damped) {
        float td = 0.1f + pedal * pedal * t60;
        t60 = fm_minf(t60, td);
        c += (1.0f - c) * 0.35f * (1.0f - pedal);
    }
    for (k = 0; k < nst; k++) {
        float fk = f * fm_exp2f(s->det[k] * (1.0f / 1200.0f)), per, w, sw, cw, rem, d, hl;
        int N;
        if (fk > 15000.0f)
            fk = 15000.0f;
        per = 44100.0f / fk;
        w = 6.28318531f * fk * RV_DT;
        sw = fm_sinf(w);
        cw = fm_cosf(w);
        rem = per - 2.0f * pn_apd(a, w, sw, cw) - pn_atan(c * sw / (1.0f - c * cw)) / w;
        N = (int)(rem - 0.5f);
        if (N < 1)
            N = 1;
        if (N > s->size[k] - 2)
            N = s->size[k] - 2;
        d = clampf(rem - (float)N, 0.1f, 2.5f);
        b->eta[k] = (1.0f - d) / (1.0f + d);
        d -= pn_apd(b->eta[k], w, sw, cw) - d;           /* (once more, where the fraction's own delay is off at this pitch) */
        d = clampf(d, 0.1f, 2.5f);
        b->eta[k] = (1.0f - d) / (1.0f + d);
        b->dly[k] = N;
        hl = (1.0f - c) / fm_sqrtf(1.0f - 2.0f * c * cw + c * c);   /* the loss filter's gain at the note */
        b->g[k] = fm_exp2f(-9.966f * per / (44100.0f * t60 * (nst == 2 && !damped ? (k ? 1.3f : 0.35f) : 1.0f))) / hl;   /* the pair: */
        /* one string gives its energy to the bridge fast, the other slowly: the piano's two-stage decay, a loud start
         * that drops away to a long, quieter singing */
        if (b->g[k] > 0.99998f)                          /* (never above 1 at any pitch: the loss passes DC whole) */
            b->g[k] = 0.99998f;
    }
    svf_set(&s->nz, 180.0f + 420.0f * (1.0f - felt), 1.1f);   /* the knock: wood and felt */
    svf_set(&s->bd, 190.0f, 0.8f);                    /* the soundboard's warmth */
    b->thd = fm_expf(-RV_DT / 0.025f);
    b->ofd = fm_expf(-RV_DT / 0.04f);
    b->gain = 1.4f / (float)nst;
    b->body = body;
    b->a = a;
    b->c = c;
    return nst;
}

RV_INL void piano_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    piano_t *s = &v->e.pn;
    pn_blk_t bk;
    int i, k, nst = RV_FAR(piano_block)(v, eff, f, n, &bk), wi[2], sz[2], bs[2];
    float a = bk.a, c = bk.c;
    if (!nst)
        return;
    for (k = 0; k < nst; k++) {
        wi[k] = s->w[k];
        sz[k] = s->size[k];
        bs[k] = s->base[k];
    }
    for (i = 0; i < n; i++) {
        float e = 0.0f, y = 0.0f, nzv, bp;
        if (s->exc_t < s->exc_len + s->exc_pos)       /* the hammer (a few milliseconds a note) */
            e = RV_FAR(pn_stroke)(s);
        for (k = 0; k < nst; k++) {
            int r = wi[k] - bk.dly[k];
            float x, t1, t2, t3, *ap = s->ap[k];
            if (r < 0)
                r += sz[k];
            x = (float)s->buf[bs[k] + r] * (1.0f / 16384.0f);
            y += x;
            t1 = bk.eta[k] * x + s->fr[k];               /* the fraction */
            s->fr[k] = x - bk.eta[k] * t1;
            t2 = a * t1 + ap[0];                      /* the stiffness */
            ap[0] = t1 - a * t2;
            t3 = a * t2 + ap[1];
            ap[1] = t2 - a * t3;
            s->lp[k] += (t3 - s->lp[k]) * (1.0f - c); /* the loss */
            x = clampf((s->lp[k] * bk.g[k] + e) * 16384.0f, -32700.0f, 32700.0f);
            s->buf[bs[k] + wi[k]] = (int16_t)(x + (x < 0.0f ? -0.5f : 0.5f));   /* (rounded: cut toward 0, a high note would die) */
            if (++wi[k] >= sz[k])
                wi[k] = 0;
        }
        y *= bk.gain;
        if (s->atk_pos < (float)PN_ATK_N)             /* ATTACK: the recorded hammer strike, over the strings' start */
            y += RV_FAR(pn_attack)(s);
        if (s->thump + s->offn > 1e-5f) {             /* the knock and the damper: noise through the wood (only then) */
            nzv = xs_bi(&s->ns) * (s->thump + s->offn);
            s->thump *= bk.thd;
            s->offn *= bk.ofd;
            y += svf_tick(&s->nz, nzv, &bp, 0) * 0.7f + bp * 0.5f;   /* (mostly the low thud, a little wood) */
        }
        if (bk.body > 0.0f) {                         /* the soundboard */
            svf_tick(&s->bd, y, &bp, 0);
            y += bp * bk.body * 0.8f;
        }
        s->dc += (y - s->dc) * 0.0015f;
        out[i] = y - s->dc;
    }
    for (k = 0; k < nst; k++)
        s->w[k] = (int16_t)wi[k];
    s->held = fm_minf(s->held, 1000.0f);
}

/* -------------------------------------------------------------- PHYS --- */
static const float membrane_ratio[6] = {1.0f, 1.59f, 2.14f, 2.30f, 2.65f, 2.92f};

static void phys_strike(voice_t *v, const float *eff)
{
    phys_t *s = &v->e.ph;
    int model = clampi((int)(eff[TP_S0] + 0.5f), 0, 3), i;
    float exc = eff[TP_S4] * (1.0f / 127.0f), bright = eff[TP_S1] * (1.0f / 127.0f);
    float pos = 0.05f + eff[TP_S3] * (0.45f / 127.0f), lp = 0.0f;
    float per = 44100.0f / note_hz((float)v->note + eff[TP_PITCH]);
    int len = clampi((int)per, 4, RV_KS_LEN - 2), pdel = clampi((int)(len * pos), 1, len - 1);
    if (model == 3) {                                 /* membrane: a modal bank kicked once */
        for (i = 0; i < 6; i++)
            s->mode_s[i][0] = s->mode_s[i][1] = 0.0f;
        s->exc = exc * v->vel;
        return;
    }
    if (model != 0)
        return;                                       /* bowed and blown are excited continuously */
    for (i = 0; i < len; i++) {                        /* a burst: noise, coloured by brightness */
        float x = xs_bi(&s->ns);
        lp += (x - lp) * (0.08f + bright * 0.9f);
        s->line[i] = (int16_t)clampf(lp * exc * v->vel * 16000.0f, -32000.0f, 32000.0f);
    }
    for (i = len - 1; i >= pdel; i--)                  /* the pluck position: a comb on the burst */
        s->line[i] = (int16_t)clampi(s->line[i] - s->line[i - pdel], -32000, 32000);
    for (i = len; i < RV_KS_LEN; i++)
        s->line[i] = 0;
    s->w = len;                                       /* the read point (w - len) lands on the burst */
}

RV_INL void phys_render(voice_t *v, const float *eff, float f, const float *exc_in, float *out, int n)
{
    phys_t *s = &v->e.ph;
    int model = clampi((int)(eff[TP_S0] + 0.5f), 0, 3), i, k;
    float bright = eff[TP_S1] * (1.0f / 127.0f), damp = eff[TP_S2] * (1.0f / 127.0f);
    float exc = eff[TP_S4] * (1.0f / 127.0f), inh = eff[TP_S5] * (1.0f / 127.0f);
    float body = eff[TP_S6] * (1.0f / 127.0f), decay = eff[TP_S7] * (1.0f / 127.0f);
    float per = 44100.0f / f, lpc = 0.15f + bright * 0.84f - damp * 0.3f;
    float t60 = 0.05f + decay * decay * 12.0f;
    float g = fm_exp2f(-per / (t60 * 44100.0f) * 9.97f);   /* loop gain for that T60 */
    float apc = inh * 0.7f, lpd;
    if ((uint32_t)s->w >= RV_KS_LEN)                  /* the voice's memory is shared by every engine: */
        s->w = 0;                                     /* after a switch these may hold another's bytes */
    if ((uint32_t)s->wn >= RV_KS_LEN)
        s->wn = 0;
    if (!(s->bow == s->bow) || fm_fabsf(s->bow) > 4.0f)
        s->bow = 0.0f;
    if (model == 3) {
        float b1[6], b2[6], gn[6];
        for (k = 0; k < 6; k++) {
            float fr = f * (membrane_ratio[k] + inh * k * 0.11f);
            float r = fm_exp2f(-1.0f / ((0.03f + decay * 2.5f) / (1.0f + k * (0.5f + damp * 2.0f)) * 44100.0f) * 1.44f);
            if (fr > 18000.0f)
                fr = 18000.0f;
            /* a decaying rotation (coupled form): its energy cannot grow when the pitch moves */
            b1[k] = r * fm_cosf(6.2831853f * fr * RV_DT);
            b2[k] = r * fm_sinf(6.2831853f * fr * RV_DT);
            gn[k] = (k == 0 ? 1.0f : 0.25f + bright * 0.75f) * 0.6f;
        }
        for (i = 0; i < n; i++) {
            float x = s->exc + exc_in[i] * 0.5f, y = 0.0f;
            s->exc = 0.0f;
            for (k = 0; k < 6; k++) {
                float re = b1[k] * s->mode_s[k][0] - b2[k] * s->mode_s[k][1] + gn[k] * x;
                float im = b2[k] * s->mode_s[k][0] + b1[k] * s->mode_s[k][1];
                s->mode_s[k][0] = re;
                s->mode_s[k][1] = im;
                y += im;
            }
            out[i] = y * 0.5f;
        }
        return;
    }
    lpc = clampf(lpc, 0.05f, 0.99f);
    lpd = (1.0f - lpc) / lpc;                         /* the loss filter's delay: tuned out */
    if (model == 1) {
        /* bowed (STK's bowed string): two segments of string meet at the bow, POSITN from the
         * bridge. Each sample the bow grips or slips by the friction curve and sends the same
         * velocity both ways; the bridge end is lossy (BRIGHT, DAMP, DECAY), the nut end rigid. */
        float beta = 0.05f + eff[TP_S3] * (0.4f / 127.0f), tot = per - lpd, db, dn;
        if (tot > 2.0f * (RV_KS_LEN - 3))
            tot = 2.0f * (RV_KS_LEN - 3);
        db = clampf(tot * beta, 1.5f, RV_KS_LEN - 3.0f);
        dn = clampf(tot - db, 1.5f, RV_KS_LEN - 3.0f);
        for (i = 0; i < n; i++) {
            float br, nr, sv, dv, bt, nv, a0, a1, fr;
            int di, r0, r1;
            di = (int)db; fr = db - (float)di;            /* the bridge segment's far end */
            r0 = s->w - di; if (r0 < 0) r0 += RV_KS_LEN;
            r1 = r0 - 1; if (r1 < 0) r1 += RV_KS_LEN;
            a0 = (s->line[r0] + (s->line[r1] - s->line[r0]) * fr) * (1.0f / 16000.0f);
            di = (int)dn; fr = dn - (float)di;            /* the neck segment's far end */
            r0 = s->wn - di; if (r0 < 0) r0 += RV_KS_LEN;
            r1 = r0 - 1; if (r1 < 0) r1 += RV_KS_LEN;
            a1 = (s->neck[r0] + (s->neck[r1] - s->neck[r0]) * fr) * (1.0f / 16000.0f);
            s->lp += (a0 - s->lp) * lpc;
            br = -s->lp * g;                              /* the bridge reflects, with loss */
            nr = -a1;                                     /* the nut reflects */
            sv = br + nr;                                 /* the string's speed under the bow */
            s->bow += ((v->a.gate ? (0.03f + exc * 0.22f) * v->vel : 0.0f) - s->bow) * 0.003f;
            dv = s->bow - sv;
            bt = fm_fabsf(dv * (5.0f - inh * 3.0f) + 0.001f) + 0.75f;   /* INHARM: lighter bow pressure */
            bt = 1.0f / (bt * bt * bt * bt);
            nv = dv * (bt > 1.0f ? 1.0f : bt) + exc_in[i] * 0.3f;
            s->neck[s->wn] = (int16_t)clampf((br + nv) * 16000.0f, -32760.0f, 32760.0f);
            s->line[s->w] = (int16_t)clampf((nr + nv) * 16000.0f, -32760.0f, 32760.0f);
            s->w = (s->w + 1) % RV_KS_LEN;
            s->wn = (s->wn + 1) % RV_KS_LEN;
            s->dly += (a0 - s->dly) * 0.02f;
            out[i] = (a0 + body * s->dly * 3.0f) * 1.6f;
        }
        return;
    }
    for (i = 0; i < n; i++) {
        /* blown: a clarinet's bore inverts at the reed, so the loop is half the period */
        float d = (model == 2 ? per * 0.5f : per) - lpd - (apc > 0.0f ? 1.0f : 0.0f), y, rd, frac, x;
        int di, r0, r1;
        if (d < 2.0f)
            d = 2.0f;
        if (d > RV_KS_LEN - 3)
            d = RV_KS_LEN - 3;
        di = (int)d;
        frac = d - (float)di;
        r0 = s->w - di;
        if (r0 < 0)
            r0 += RV_KS_LEN;
        r1 = r0 - 1;
        if (r1 < 0)
            r1 += RV_KS_LEN;
        rd = (s->line[r0] + (s->line[r1] - s->line[r0]) * frac) * (1.0f / 16000.0f);
        s->lp += (rd - s->lp) * lpc;                  /* loss: brightness, damping */
        y = s->lp * g;
        if (apc > 0.0f) {                             /* stiffness: an allpass in the loop */
            float a = apc * (y - s->ap) + s->prev;
            s->prev = y;
            s->ap = a;
            y = a;
        }
        x = exc_in[i] * 0.3f;
        if (model == 2) {                      /* blown: a reed (STK's clarinet) */
            float br, pd, r;
            s->bow += ((v->a.gate ? (0.62f + exc * 0.45f) * (0.75f + 0.25f * v->vel) : 0.0f) - s->bow) * 0.001f;   /* above the reed's threshold */
            br = s->bow * (1.0f + xs_bi(&s->ns) * 0.04f);   /* breath, with a little turbulence */
            pd = -0.95f * y - br;                     /* the bore reflects inverted */
            r = clampf(0.7f - 0.3f * pd, -1.0f, 1.0f);    /* the reed opens and closes */
            x += br + pd * r - y;                     /* the reed sets what goes back in */
        }
        y += x;
        s->line[s->w] = (int16_t)clampf(y * 16000.0f, -32760.0f, 32760.0f);
        s->w = (s->w + 1) % RV_KS_LEN;
        /* body: a little low resonance mixed in */
        s->dly += (y - s->dly) * 0.02f;
        out[i] = (y + body * s->dly * 3.0f) * 0.8f;
    }
}

/* ----------------------------------------------------------- FORMANT --- */
static const float vowels[5][3] = {{730, 1090, 2440}, {530, 1840, 2480}, {270, 2290, 3010}, {570, 840, 2410}, {300, 870, 2240}};
static const float vowel_gain[3] = {1.0f, 0.55f, 0.3f};

RV_INL void form_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    form_t *s = &v->e.fo;
    float vw = eff[TP_S0] * (4.0f / 127.0f), sh = fm_exp2f(eff[TP_S1] * (1.0f / 64.0f));
    float bw = 0.4f + eff[TP_S2] * (8.0f / 127.0f);
    int fof = eff[TP_S3] > 0.5f, vi = clampi((int)vw, 0, 3), i, k;
    float vf = vw - (float)vi, breath = eff[TP_S4] * (1.0f / 127.0f), glot = eff[TP_S5] * (1.0f / 127.0f);
    float spread = eff[TP_S6] * (1.0f / 127.0f), vib = eff[TP_S7] * (1.0f / 127.0f);
    float F[3], dt;
    for (k = 0; k < 3; k++)
        F[k] = lerpf(vowels[vi][k], vowels[vi + 1][k], vf) * sh;
    s->vib += 5.5f * RV_DT * n;
    s->vib -= fm_floorf(s->vib);
    f *= 1.0f + vib * 0.012f * sin_lut(s->vib) * clampf(v->a.out * 2.0f, 0.0f, 1.0f);
    dt = f * RV_DT;
    if (!fof)
        for (k = 0; k < 3; k++)
            svf_set(&s->f[k], F[k], F[k] / (60.0f * bw + 30.0f));
    for (i = 0; i < n; i++) {
        float y = 0.0f, src;
        s->ph += dt;
        if (s->ph >= 1.0f) {
            s->ph -= 1.0f;
            if (fof)
                for (k = 0; k < 3; k++) {
                    s->fof_ph[k] = 0.0f;
                    s->fof_env[k] = 1.0f;
                    s->fof_t[k] = 0.0f;
                }
        }
        if (fof) {
            for (k = 0; k < 3; k++) {
                if (s->fof_env[k] < 0.0005f)
                    continue;
                {
                    float att = s->fof_t[k] < 0.002f ? 0.5f - 0.5f * sin_lut(s->fof_t[k] * 250.0f + 0.25f) : 1.0f;
                    y += sin_lut(s->fof_ph[k]) * s->fof_env[k] * att * vowel_gain[k];
                    s->fof_ph[k] += F[k] * (1.0f + spread * 0.02f * (k - 1)) * RV_DT;
                    s->fof_env[k] *= 1.0f - (0.0015f + bw * 0.0012f) * (1.0f + k * 0.4f);
                    s->fof_t[k] += RV_DT;
                }
            }
            y += breath * xs_bi(&s->ns) * 0.2f;
            out[i] = y * 0.45f;
        } else {
            /* a glottal pulse: raised cosine open phase, sharper with GLOTTAL */
            float op = 0.4f + (1.0f - glot) * 0.5f;
            src = s->ph < op ? (1.0f - sin_lut(s->ph / op * 0.5f + 0.25f)) : 0.0f;
            src = (src - 0.4f) * (0.5f + glot);
            src += breath * xs_bi(&s->ns) * 0.6f;
            for (k = 0; k < 3; k++) {
                float bp;
                svf_tick(&s->f[k], src, &bp, 0);
                y += bp * vowel_gain[k];
            }
            out[i] = y * 0.6f;
        }
    }
}

/* ---------------------------------------------------------- PARTICLE --- */
/* Silt's pulsar emitters: each emitter fires a short wavelet (a pulsaret) once per period;
 * coupling pulls the emitters' phases together (Kuramoto), mask leaves pulses out by a fixed
 * rule, scatter (optional) jitters them. */
RV_INL void part_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    part_t *s = &v->e.pa;
    const int16_t *tab = wt[clampi((int)(eff[TP_S0] + 0.5f), 0, 7)];
    float duty = 0.04f + eff[TP_S1] * (0.92f / 127.0f);
    int ne = clampi((int)(eff[TP_S2] + 0.5f), 1, 3), i, e;
    float ratio = eff[TP_S3] * (1.0f / 127.0f), couple = eff[TP_S4] * (1.0f / 127.0f);
    float mask = eff[TP_S5] * (1.0f / 127.0f), form = fm_exp2f((eff[TP_S6] - 64.0f) * (3.0f / 64.0f));
    float scat = eff[TP_S7] * (1.0f / 127.0f);
    float inc[3], keep = 1.0f - mask * 0.85f;
    inc[0] = f * RV_DT;
    inc[1] = inc[0] * (1.0f + ratio * 0.5f);
    inc[2] = inc[0] * (1.0f + ratio * 1.25f);
    for (i = 0; i < n; i++) {
        float y = 0.0f, cx = 0.0f, sy = 0.0f, psi = 0.0f, R = 0.0f;
        if (ne > 1 && couple > 0.001f) {
            for (e = 0; e < ne; e++) {
                cx += sin_lut(s->th[e] + 0.25f);
                sy += sin_lut(s->th[e]);
            }
            R = fm_sqrtf(cx * cx + sy * sy) / (float)ne;
            /* mean phase in turns, from atan2 by a cheap octant fit */
            {
                float ax = fm_fabsf(cx), ay = fm_fabsf(sy), mn = fm_minf(ax, ay), mx = fm_maxf(ax, ay) + 1e-9f, a = mn / mx;
                float r = a * (0.15915f - 0.0466f * a);     /* atan(a)/2pi, to 0.3 degrees */
                if (ay > ax)
                    r = 0.25f - r;
                if (cx < 0.0f)
                    r = 0.5f - r;
                if (sy < 0.0f)
                    r = -r;
                psi = r;
            }
        }
        for (e = 0; e < ne; e++) {
            float ie = inc[e];
            if (ne > 1 && couple > 0.001f)
                ie += couple * R * 0.02f * inc[0] * 30.0f * sin_lut(psi - s->th[e]);
            s->th[e] += ie;
            if (s->th[e] >= 1.0f) {
                s->th[e] -= fm_floorf(s->th[e]);
                s->count++;
                /* deterministic mask: keep a pulse when the running count crosses an integer */
                if ((int)((float)(s->count + 1) * keep) != (int)((float)s->count * keep) || mask < 0.01f) {
                    s->on[e] = 1;
                    s->rd[e] = 0.0f;
                    if (scat > 0.001f)
                        s->th[e] -= scat * xs_uni(&s->ns) * 0.4f;
                }
            }
            if (s->on[e]) {
                float u = s->rd[e];                     /* through the pulsaret, 0..1 */
                float w = 0.5f - 0.5f * sin_lut(u + 0.25f);
                y += wt_read(tab, u * duty * form * 4.0f + 0.0f) * w * (e == 0 ? 1.0f : 0.7f);
                s->rd[e] += ie / duty;
                if (s->rd[e] >= 1.0f)
                    s->on[e] = 0;
            }
        }
        out[i] = y * 0.55f;
    }
}

/* -------------------------------------------------------------- CHIP --- */
/* After the Syntakt's SY CHIP: a SID-style oscillator (triangle, saw, pulse, the noise shift
 * register, the combined saw&pulse wave, ring, animated PWM and two drum tables) that steps
 * through the played note and up to three offsets (OF2-OF4) at RATE, so one voice plays a
 * chord. A square sub oscillator holds the played note (octaves -3..+1), and the main oscillator
 * can restart with it (SYNC: the arp's notes then sweep a synced timbre). OVER drives it all.
 * Then a decompose stage:
 * sample-rate reduction, bit crushing, and fragments of the voice's own last moments repeated,
 * reversed, dropped, bit-flipped or doubled. */
static void chip_note(voice_t *v, const float *eff)
{
    chip_t *c = &v->e.ch;
    (void)eff;
    c->step = 0;
    c->dir = 1;
    c->acc = 0.0f;
    c->sweep = 1.0f;
    c->vib_t = 0.0f;
    if (!c->lfso)
        c->lfso = 0x7FFFF8u;                          /* the SID's noise register starts all ones */
    if (!c->ns)
        c->ns = v->rng | 1u;
    c->frag_left = 0;
    c->frag_mode = 0;
}

static inline float chip_wave(chip_t *c, int w, float ph, float pw)
{
    switch (w) {
    case CW_TRI: return ph < 0.5f ? 4.0f * ph - 1.0f : 3.0f - 4.0f * ph;
    case CW_SAW: return 2.0f * ph - 1.0f;
    case CW_PULSE: case CW_PWM: return ph < pw ? 1.0f : -1.0f;
    case CW_NOISE: return c->noise;
    case CW_SAWPUL: {                                 /* the SID ANDs the two waves' bits */
        int a = (int)(ph * 4095.0f), b = ph < pw ? 4095 : 0;
        return (float)(a & b) * (2.0f / 4095.0f) - 1.0f;
    }
    default: return 0.0f;
    }
}

RV_INL void chip_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    chip_t *c = &v->e.ch;
    int w = clampi((int)(eff[TP_S0] + 0.5f), 0, CW_N - 1), mode = clampi((int)(eff[TP_S3] + 0.5f), 0, 4);
    int steps = clampi((int)(eff[TP_S7] + 0.5f), 1, 4), i;
    float pw = 0.05f + eff[TP_S1] * (0.9f / 127.0f), spd = 2.0f * fm_exp2f(eff[TP_S2] * (6.0f / 127.0f));
    float ofs[4] = {0.0f, eff[TP_S4], eff[TP_S5], eff[TP_S6]};
    float sub = eff[TP_S8] * (1.0f / 127.0f), over = eff[TP_S11] * (1.0f / 127.0f), osc1 = eff[TP_OSC1] * (1.0f / 127.0f);
    int sync = eff[TP_S10] > 0.5f;
    float sdt = clampf(f * fm_exp2f((float)(clampi((int)(eff[TP_S9] + 0.5f), 0, 4) - 3)) * RV_DT, 0.0f, 0.45f);
    float srr = eff[TP_S12] * (1.0f / 127.0f), hold_n = 1.0f + srr * srr * 63.0f;
    float q = (float)(1 << (clampi((int)(eff[TP_S13] + 0.5f), 1, 16) - 1));
    float dec = eff[TP_S14] * (1.0f / 127.0f);
    int flen = 64 + (int)(eff[TP_S15] * ((RV_CHIP_BUF - 80) / 127.0f));
    float semi, dt, dt2, nclk, drum = 0.0f;
    if ((uint32_t)c->w >= RV_CHIP_BUF)                /* shared memory: never trust a stale index */
        c->w = 0;
    /* the arpeggio: advance once per block (a step every 1/SPEED s) */
    if (steps > 1) {
        c->acc += spd * (float)n * RV_DT;
        while (c->acc >= 1.0f) {
            c->acc -= 1.0f;
            switch (mode) {
            case 0: c->step = (int8_t)((c->step + 1) % steps); break;
            case 1: c->step = (int8_t)((c->step + steps - 1) % steps); break;
            case 2:
                if (c->step + c->dir >= steps || c->step + c->dir < 0)
                    c->dir = (int8_t)-c->dir;
                c->step = (int8_t)(c->step + c->dir);
                break;
            case 3: c->step = (int8_t)(xs_uni(&c->ns) * (float)steps * 0.9999f); break;
            default: if (c->step < steps - 1) c->step++; break;   /* ONCE: up, then stays */
            }
        }
        c->step = (int8_t)clampi(c->step, 0, steps - 1);
    } else {
        c->step = 0;
    }
    /* pitch: the arp's offset, and KICK's own fast drop */
    c->sweep *= fm_expf(-(float)n * RV_DT / (w == CW_KICK ? 0.035f : 0.06f));
    c->vib_t += (float)n * RV_DT;
    semi = ofs[c->step] + (w == CW_KICK ? 36.0f * c->sweep : 0.0f);
    dt = clampf(f * fm_exp2f(semi * (1.0f / 12.0f)) * RV_DT, 0.0f, 0.45f);
    dt2 = dt * (1.0f + eff[TP_S1] * (3.0f / 127.0f));   /* RING: PW is the partner's ratio */
    nclk = dt * 16.0f;                                /* the noise register clocks 16 times a cycle */
    for (i = 0; i < n; i++) {
        float x, y, sq;
        c->ph += dt;
        if (c->ph >= 1.0f)
            c->ph -= 1.0f;
        c->pwm2 += sdt;                               /* the sub: a square on the played note */
        if (c->pwm2 >= 1.0f) {
            c->pwm2 -= 1.0f;
            if (sync)                                 /* SYNC: the main oscillator restarts with it */
                c->ph = c->pwm2 * (dt / sdt);
        }
        sq = c->pwm2 < 0.5f ? 1.0f : -1.0f;
        c->drift += nclk;
        while (c->drift >= 1.0f) {                    /* the SID's 23-bit noise register */
            uint32_t b = ((c->lfso >> 22) ^ (c->lfso >> 17)) & 1u;
            c->drift -= 1.0f;
            c->lfso = ((c->lfso << 1) | b) & 0x7FFFFFu;
            c->noise = (float)(((c->lfso >> 15) & 0xFFu)) * (2.0f / 255.0f) - 1.0f;
        }
        switch (w) {
        case CW_RING: {                               /* triangle, its sign flipped by a partner */
            c->ph2 += dt2;
            if (c->ph2 >= 1.0f)
                c->ph2 -= 1.0f;
            x = chip_wave(c, CW_TRI, c->ph, pw) * (c->ph2 < 0.5f ? 1.0f : -1.0f);
            break;
        }
        case CW_PWM:
            c->pwm += 2.2f * RV_DT;
            if (c->pwm >= 1.0f)
                c->pwm -= 1.0f;
            x = chip_wave(c, CW_PULSE, c->ph, 0.5f + (pw - 0.05f) * 0.5f * sin_lut(c->pwm));
            break;
        case CW_KICK:                                 /* a noise click, then a falling triangle */
            drum = c->sweep;
            x = c->vib_t < 0.004f ? c->noise : chip_wave(c, CW_TRI, c->ph, pw);
            break;
        case CW_SNARE:                                /* a triangle body under noise that outlasts it */
            drum = c->sweep;
            x = chip_wave(c, CW_TRI, c->ph, pw) * drum + c->noise * 0.7f;
            break;
        default: x = chip_wave(c, w, c->ph, pw); break;
        }
        x = (x * osc1 + sq * sub * 0.8f) * (0.5f / (1.0f + sub * 0.4f));   /* OSC LVL against SUB */
        if (over > 0.0f)                              /* OVER: driven into a soft wall */
            x = sat(x * (1.0f + over * 7.0f)) * (0.5f + 0.2f * over) / (0.5f + over * 0.3f);
        /* SRR: hold each sample HOLD times (fractional, so the aliasing moves with it) */
        c->hold_n += 1.0f;
        if (c->hold_n >= hold_n) {
            c->hold_n -= hold_n;
            c->hold = x;
        }
        x = hold_n > 1.01f ? c->hold : x;
        if (q < 32768.0f)                             /* CRUSH: down to so many bits */
            x = fm_floorf(x * q + 0.5f) / q;
        /* DECOMP: the voice remembers its last 46 ms; at each fragment's end the dice may
         * replay the last fragment, reverse it, drop it, flip its bits or play it twice as fast */
        c->buf[c->w] = (int16_t)clampf(x * 16000.0f, -32000.0f, 32000.0f);
        y = x;
        if (dec > 0.0f) {
            if (--c->frag_left <= 0) {
                float r = xs_uni(&c->ns);
                c->frag_len = flen;
                c->frag_left = flen;
                c->frag_pos = 0;
                c->frag_mode = r < dec ? (uint8_t)(1 + (int)(xs_uni(&c->ns) * 4.999f)) : 0;
                c->flip = (uint16_t)(xs_uni(&c->ns) * 65535.0f) | 0x2000u;
            }
            if (c->frag_mode) {
                int32_t k = c->frag_pos++, r0;
                switch (c->frag_mode) {
                case 1: r0 = c->w - c->frag_len + (k % c->frag_len); break;            /* repeat */
                case 2: r0 = c->w - 2 * k - 1; break;                                     /* reverse */
                case 3: r0 = -1; break;                                                   /* drop */
                case 4: r0 = c->w; break;                                                 /* bit flip */
                default: r0 = c->w - c->frag_len + ((2 * k) % c->frag_len); break;       /* twice as fast */
                }
                if (r0 < 0 && c->frag_mode != 3)
                    r0 += RV_CHIP_BUF * 2;
                if (c->frag_mode == 3)
                    y = 0.0f;
                else if (c->frag_mode == 4)
                    y = (float)((int16_t)(c->buf[c->w] ^ (int16_t)(c->flip & 0x3FF0u))) * (1.0f / 16000.0f);
                else
                    y = (float)c->buf[r0 % RV_CHIP_BUF] * (1.0f / 16000.0f);
            }
        }
        c->w = (c->w + 1) % RV_CHIP_BUF;
        out[i] = y;
    }
    (void)drum;
}

/* --------------------------------------------------- the synth voice --- */
/* clear a voice's engine state for eng. The engines share one block of memory (a union), so only
 * eng's own fields are seeded: writing another engine's fields would land on eng's phases and
 * filter states as garbage numbers. */
/* --------------------------------------------------------------- WAVE --- */
/* After the PPG Wave and the Waldorf Microwave. Two oscillators read wavetables: each table is
 * 8 key waves and POS (0-63) moves between them. Osc 1 can hard-sync osc 2, ring-modulate it or
 * frequency-modulate it (XMOD, by XM AMT). Both read through a phase WARP (after Serum's: SYNC,
 * BEND, PWM, MIRROR, REMAP 2/4, SQUEEZE, FLIP, QUANT). MIX balances them into a mixer that
 * saturates prettily as SAT rises. The WAVE ENV is a shape from the shape library that sweeps both
 * positions (by WE AMT), looping while the key is held, as the Microwave's wave envelope loops.
 * ASIC: at 0 the positions glide and the waves are band-limited; up to 63 the positions step
 * through 64 waves as the PPG and Microwave did; above, the samples are read raw and unsmoothed,
 * the phase is truncated and the output coarsens: the early Microwave's digital sizzle. */
#define WT_DATA
#include "rv_wavetables.h"

static void wave_note(voice_t *v, const float *eff)
{
    wave_t *w = &v->e.wv;
    w->wu = 0.0f;
    w->wdone = 0;
    if (((int)(eff[TP_S8] + 0.5f) == WX_SYNC) || ((int)(eff[TP_S8] + 0.5f) == WX_SYNCFM))
        w->ph[0] = w->ph[1] = 0.0f;
}

/* one osc's sample: table t, key position kp (0..7), phase p (0..1); lvl 0 full, 1 limited, or a mix */
RV_INL float wtab_read(int t, float kp, float p, float lim, int raw)
{
    int k0 = (int)kp, k1, i0, i1;
    float kf = kp - (float)k0, x = p * (float)WT_N, fr, a, b;
    const int8_t *f0, *f1;
    if (k0 >= WT_KEYS - 1) {
        k0 = WT_KEYS - 1;
        kf = 0.0f;
    }
    k1 = k0 + (k0 < WT_KEYS - 1);
    i0 = (int)x & (WT_N - 1);
    i1 = (i0 + 1) & (WT_N - 1);
    fr = raw ? 0.0f : x - fm_floorf(x);
    f0 = wt_tab[t][k0];
    f1 = wt_tab[t][k1];
    a = f0[i0] + (f0[i1] - f0[i0]) * fr;
    b = f1[i0] + (f1[i1] - f1[i0]) * fr;
    a += (b - a) * kf;
    if (lim > 0.001f) {                               /* high notes: toward the 10-harmonic copy (64 samples a cycle) */
        float c, d, xl = p * (float)WT_NL, fl = raw ? 0.0f : xl - fm_floorf(xl);
        int j0 = (int)xl & (WT_NL - 1), j1 = (j0 + 1) & (WT_NL - 1);
        f0 = wt_lim[t][k0];
        f1 = wt_lim[t][k1];
        c = f0[j0] + (f0[j1] - f0[j0]) * fl;
        d = f1[j0] + (f1[j1] - f1[j0]) * fl;
        c += (d - c) * kf;
        a += (c - a) * lim;
    }
    return a * (1.0f / 127.0f);
}

static inline float wtab_warp(int warp, float a, float p)
{
    switch (warp) {
    case WW_SYNC: { float q = p * (1.0f + a * 7.0f); return q - fm_floorf(q); }
    case WW_BEND: return fm_powf(p > 1e-6f ? p : 1e-6f, fm_exp2f((0.5f - a) * 4.0f));   /* bipolar around the middle */
    case WW_PWM: { float wd = 0.5f - a * 0.48f; return p < wd ? p * 0.5f / wd : 0.5f + (p - wd) * 0.5f / (1.0f - wd); }
    case WW_MIRROR: { float m = p < 0.5f ? p * 2.0f : 2.0f - p * 2.0f; return p + (m - p) * a; }
    case WW_SQUEEZE: {
        float e = 1.0f + a * 3.0f;
        return p < 0.5f ? 0.5f * fm_powf(p * 2.0f, e) : 1.0f - 0.5f * fm_powf(2.0f - p * 2.0f, e);
    }
    case WW_QUANT: { float st = fm_exp2f(7.0f - a * 5.5f); return fm_floorf(p * st) / st; }
    default: return p;
    }
}

/* one oscillator through its warp: REMAP and FLIP work on the output */
RV_INL float wtab_osc(int t, float kp, float p, int warp, float wa, float lim, int raw)
{
    float y;
    if (warp == WW_REMAP2 || warp == WW_REMAP4) {      /* the cycle read 2 or 4 times a period, blended in */
        float m = warp == WW_REMAP2 ? 2.0f : 4.0f, q = p * m;
        y = wtab_read(t, kp, p, lim, raw);
        return y + (wtab_read(t, kp, q - fm_floorf(q), lim, raw) - y) * wa;
    }
    y = wtab_read(t, kp, wtab_warp(warp, wa, p), lim, raw);
    if (warp == WW_FLIP && p > 1.0f - wa * 0.5f)       /* FLIP: the end of the cycle upside down */
        y = -y;
    return y;
}

RV_INL void wave_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    wave_t *w = &v->e.wv;
    int t1 = clampi((int)(eff[TP_S0] + 0.5f), 0, WT_TABLES - 1), t2 = clampi((int)(eff[TP_S2] + 0.5f), 0, WT_TABLES - 1);
    int xm = clampi((int)(eff[TP_S8] + 0.5f), 0, 4), warp = clampi((int)(eff[TP_S10] + 0.5f), 0, WW_N - 1);
    int wenv = clampi((int)(eff[TP_S12] + 0.5f), 0, SHP_N), i, raw;
    float asic = clampf(eff[TP_S15], 0.0f, 127.0f), mix = eff[TP_S6] * (1.0f / 127.0f), satv = eff[TP_S7] * (1.0f / 127.0f), olv1 = eff[TP_OSC1] * (1.0f / 127.0f);
    float xa = eff[TP_S9] * (1.0f / 127.0f), wa = eff[TP_S11] * (1.0f / 127.0f), det = eff[TP_S5] * (0.3f / 127.0f);
    float f2 = f * fm_exp2f((eff[TP_S4] + det) * (1.0f / 12.0f)), d1, d2, p1, p2, kp1, kp2, l1, l2, g1, g2, drive, q;
    /* the wave envelope: a shape that loops while held, then finishes its cycle */
    if (wenv > 0 && !w->wdone) {
        w->wu += (float)n * RV_DT / rv_time_f(eff[TP_S14]);
        if (w->wu >= 1.0f) {
            if (v->a.gate)
                w->wu -= fm_floorf(w->wu);
            else {
                w->wu = 1.0f;
                w->wdone = 1;
            }
        }
        w->wv = shp_eval(wenv, 0.0f, 0.0f, w->wu);
    } else if (!wenv) {
        w->wv = 0.0f;
    }
    p1 = clampf(eff[TP_S1] + eff[TP_S13] * (63.0f / 64.0f) * w->wv, 0.0f, 63.0f);
    p2 = clampf(eff[TP_S3] + eff[TP_S13] * (63.0f / 64.0f) * w->wv, 0.0f, 63.0f);
    if (asic >= 1.0f) {                                /* the PPG's stepping: 64 whole waves */
        p1 = fm_floorf(p1 + 0.5f);
        p2 = fm_floorf(p2 + 0.5f);
    }
    kp1 = p1 * (7.0f / 63.0f);
    kp2 = p2 * (7.0f / 63.0f);
    raw = asic >= 64.0f;
    /* band limit (smooth only): the share of the 10-harmonic copy each osc needs */
    l1 = raw ? 0.0f : clampf((63.0f - 0.45f * (float)RV_FS / (f > 1.0f ? f : 1.0f)) / 53.0f, 0.0f, 1.0f);
    l2 = raw ? 0.0f : clampf((63.0f - 0.45f * (float)RV_FS / (f2 > 1.0f ? f2 : 1.0f)) / 53.0f, 0.0f, 1.0f);
    d1 = clampf(f * RV_DT, 0.0f, 0.45f);
    d2 = clampf(f2 * RV_DT, 0.0f, 0.45f);
    g1 = fm_cosf(mix * 1.5707963f);                  /* equal-power MIX */
    g2 = fm_sinf(mix * 1.5707963f);
    if (xm == WX_OFF && mix < 0.002f)
        g2 = 0.0f;
    drive = 1.0f + satv * 5.0f;
    q = raw ? fm_exp2f(12.0f - (asic - 64.0f) * (4.0f / 63.0f)) : 0.0f;   /* the output: 12 bits down to 8 */
    for (i = 0; i < n; i++) {
        float y1, y2, ph1 = w->ph[0], ph2, y;
        if (raw) {                                     /* the phase truncated: a jitter that sizzles */
            float tr = fm_exp2f(9.0f + (127.0f - asic) * (4.0f / 63.0f));
            ph1 = fm_floorf(ph1 * tr) / tr;
        }
        y1 = wtab_osc(t1, kp1, ph1, warp, wa, l1, raw);
        ph2 = w->ph[1];
        if (xm == WX_FM || xm == WX_SYNCFM) {          /* osc 1 bends osc 2's phase */
            ph2 += xa * 1.5f * y1;
            ph2 -= fm_floorf(ph2);
        }
        y2 = g2 > 0.0f || xm == WX_RING ? wtab_osc(t2, kp2, ph2, warp, wa, l2, raw) : 0.0f;
        if (xm == WX_RING)
            y2 += (y1 * y2 - y2) * xa;
        y = y1 * g1 * olv1 + y2 * (g2 > 0.0f ? g2 : (xm == WX_RING ? 0.7f : 0.0f));   /* LEVEL 1 on osc 1 */
        y = sat(y * drive) * (1.0f / sat(drive));       /* the mixer: rounds off as it is pushed */
        if (q > 0.0f)
            y = fm_floorf(y * q + 0.5f) / q;
        out[i] = y * 0.5f;
        w->ph[0] += d1;
        if (w->ph[0] >= 1.0f) {
            w->ph[0] -= 1.0f;
            if (xm == WX_SYNC || xm == WX_SYNCFM)       /* hard sync: osc 2 restarts with osc 1 */
                w->ph[1] = w->ph[0] * (d2 / (d1 > 1e-7f ? d1 : 1e-7f));
        }
        w->ph[1] += d2;
        w->ph[1] -= fm_floorf(w->ph[1]);
    }
}

/* -------------------------------------------------------------- LOGIC --- */
/* Oscillators from function blocks, after Kurzweil's VAST (whose FUNs compute a function of two
 * inputs) and E-mu's patch-cord functions. Three sources: A on the note, B and C at a ratio of it
 * (B DRIFT pulls B off the ratio, so the pattern slowly turns). OP 1 combines A and B, OP 2 that
 * result with C (OP 2 AMT blends it in): arithmetic (A+B, A*B, MIN, MAX, DIFF), bit logic on BITS-
 * bit words (AND, OR, XOR, NAND), a comparator (A>B), GATE (A where B is high), QUANT (A in steps B
 * sets), MOD (A wrapped by B), SIN(A+B), and A(B) (A's wave read at B). Run at twice the rate and
 * smoothed (SMOOTH) to tame the edges. Then GRAIN: pitch-synchronous grains of the voice's own last
 * moments, GRAIN long (short: pulsar-like gaps; long: overlapping clouds), sprayed and transposed. */
static inline float lg_src(int wv, float ph, float pw, uint32_t *ns)
{
    switch (wv) {
    case LW_TRI: return ph < 0.5f ? 4.0f * ph - 1.0f : 3.0f - 4.0f * ph;
    case LW_SQR: return ph < 0.5f ? 1.0f : -1.0f;
    case LW_SINE: return fm_sin_turns(ph);
    case LW_PULSE: return ph < pw ? 1.0f : -1.0f;
    case LW_NOISE: return xs_bi(ns);
    default: return 2.0f * ph - 1.0f;
    }
}

RV_INL float lg_op(int op, float x, float y, int bits, int wa, float pw, uint32_t *ns)
{
    float top = (float)((1 << bits) - 1);
    int ux, uy;
    switch (op) {
    case LO_ADD: return (x + y) * 0.5f;
    case LO_MULT: return x * y;
    case LO_MIN: return x < y ? x : y;
    case LO_MAX: return x > y ? x : y;
    case LO_AND: case LO_OR: case LO_XOR: case LO_NAND: {
        int r;
        ux = (int)((x * 0.5f + 0.5f) * top + 0.5f);
        uy = (int)((y * 0.5f + 0.5f) * top + 0.5f);
        r = op == LO_AND ? (ux & uy) : op == LO_OR ? (ux | uy) : op == LO_XOR ? (ux ^ uy) : ~(ux & uy) & ((1 << bits) - 1);
        return (float)r * (2.0f / top) - 1.0f;
    }
    case LO_COMP: return x > y ? 1.0f : -1.0f;
    case LO_GATE: return y > 0.0f ? x : 0.0f;
    case LO_DIFF: return fm_fabsf(x - y) - 1.0f;
    case LO_QUANT: {
        float st = 1.0f + (y * 0.5f + 0.5f) * top;
        return fm_floorf(x * st + 0.5f) / st;
    }
    case LO_MOD: {
        float m = 0.1f + (y * 0.5f + 0.5f) * 1.9f, u = x + 1.0f;
        return (u - fm_floorf(u / m) * m) * (2.0f / m) - 1.0f;
    }
    case LO_SINE: return fm_sin_turns((x + y) * 0.5f);
    default: return lg_src(wa, y * 0.5f + 0.5f, pw, ns);   /* A(B): A's wave at B */
    }
}

static const float lg_ratio[20] = {0.25f, 0.3333333f, 0.5f, 0.6666667f, 0.75f, 1.0f, 1.25f, 1.3333333f, 1.5f, 1.6666667f,
                                   2.0f, 2.5f, 3.0f, 4.0f, 5.0f, 6.0f, 7.0f, 8.0f, 11.0f, 16.0f};

static void logic_note(voice_t *v, const float *eff)
{
    logic_t *l = &v->e.lg;
    (void)eff;
    l->ph[0] = l->ph[1] = l->ph[2] = 0.0f;           /* the pattern starts the same each note */
    if (!l->ns)
        l->ns = v->rng | 1u;
}

RV_INL void logic_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    logic_t *l = &v->e.lg;
    int wa = clampi((int)(eff[TP_S0] + 0.5f), 0, LW_N - 1), wb = clampi((int)(eff[TP_S2] + 0.5f), 0, LW_N - 1);
    int wc = clampi((int)(eff[TP_S4] + 0.5f), 0, LW_N - 1), op1 = clampi((int)(eff[TP_S5] + 0.5f), 0, LO_N - 1);
    int op2 = clampi((int)(eff[TP_S6] + 0.5f), 0, LO_N - 1), bits = clampi((int)(eff[TP_S8] + 0.5f), 1, 12), i, s, k;
    float rb = lg_ratio[clampi((int)(eff[TP_S1] + 0.5f), 0, 19)] * fm_exp2f(eff[TP_S10] * (30.0f / 127.0f / 1200.0f));   /* B DRIFT: up to 30 cents off */
    float rc = lg_ratio[clampi((int)(eff[TP_S3] + 0.5f), 0, 19)], amt2 = eff[TP_S7] * (1.0f / 127.0f);
    float pw = 0.05f + eff[TP_S9] * (0.9f / 127.0f), dry = eff[TP_S11] * (1.0f / 127.0f);
    float sm = 1.0f - 0.97f * eff[TP_S12] * (1.0f / 127.0f), grain = eff[TP_S13] * (1.0f / 127.0f);
    float spray = eff[TP_S14] * (1.0f / 127.0f), gp = fm_exp2f(eff[TP_S15] * (1.0f / 12.0f));
    float dt = clampf(f * RV_DT * 0.5f, 0.0f, 0.24f);   /* half a sample's step: twice the rate */
    for (i = 0; i < n; i++) {
        float acc = 0.0f, y;
        int wrapped = 0;
        for (s = 0; s < 2; s++) {
            float a, b, c, r;
            l->ph[0] += dt;
            if (l->ph[0] >= 1.0f) {
                l->ph[0] -= 1.0f;
                wrapped = 1;
            }
            l->ph[1] += dt * rb;
            l->ph[1] -= fm_floorf(l->ph[1]);
            l->ph[2] += dt * rc;
            l->ph[2] -= fm_floorf(l->ph[2]);
            a = lg_src(wa, l->ph[0], pw, &l->ns);
            b = lg_src(wb, l->ph[1], pw, &l->ns);
            r = lg_op(op1, a, b, bits, wa, pw, &l->ns);
            if (amt2 > 0.001f) {
                c = lg_src(wc, l->ph[2], pw, &l->ns);
                r += (lg_op(op2, r, c, bits, wa, pw, &l->ns) - r) * amt2;
            }
            acc += r + (a - r) * dry;
        }
        l->lp += (acc * 0.5f - l->lp) * sm;
        y = l->lp;
        /* the grains: the voice's last moments, one grain a period */
        l->buf[l->w] = (int16_t)clampf(y * 16000.0f, -32000.0f, 32000.0f);
        l->w = (l->w + 1) & (RV_LOGIC_BUF - 1);
        if (grain > 0.001f) {
            float gsum = 0.0f;
            if (wrapped) {
                for (k = 0; k < 4 && l->gon[k]; k++)
                    ;
                if (k < 4) {
                    float per = 1.0f / (f > 20.0f ? f : 20.0f), len = per * (0.15f + grain * 3.85f);
                    float room = (float)(RV_LOGIC_BUF - 8) - len * gp * (float)RV_FS, back = per * (float)RV_FS;
                    if (back > room)
                        back = room;
                    back += spray * (xs_bi(&l->ns) * 0.5f + 0.5f) * (room - back);   /* SPRAY: within the room the buffer has, at any pitch */
                    l->gpos[k] = (float)l->w - clampf(back, 4.0f, (float)(RV_LOGIC_BUF - 8));
                    l->gt[k] = 0.0f;
                    l->gdt[k] = RV_DT / clampf(len, 0.0005f, 0.02f);
                    l->ginc[k] = gp;
                    l->gon[k] = 1;
                }
            }
            for (k = 0; k < 4; k++) {
                float p, wdw, fr;
                int32_t i0;
                if (!l->gon[k])
                    continue;
                p = l->gpos[k];
                while (p < 0.0f)
                    p += (float)RV_LOGIC_BUF;
                i0 = (int32_t)p;
                fr = p - (float)i0;
                wdw = 4.0f * l->gt[k] * (1.0f - l->gt[k]);
                gsum += (l->buf[i0 & (RV_LOGIC_BUF - 1)] + (l->buf[(i0 + 1) & (RV_LOGIC_BUF - 1)] - l->buf[i0 & (RV_LOGIC_BUF - 1)]) * fr) * (1.0f / 16000.0f) * wdw;
                l->gpos[k] += l->ginc[k];
                if (l->gpos[k] >= (float)RV_LOGIC_BUF)
                    l->gpos[k] -= (float)RV_LOGIC_BUF;
                l->gt[k] += l->gdt[k];
                if (l->gt[k] >= 1.0f)
                    l->gon[k] = 0;
            }
            y += (gsum * 1.2f - y) * clampf(grain * 3.0f, 0.0f, 1.0f);
        }
        out[i] = y * 0.5f;
    }
}

/* -------------------------------------------------------------- ORGAN --- */
/* A pipe organ played like a synthesizer, after the organ records of Maxime Denuc (Nachthorn). Seven
 * ranks by footage (16' to 1') over one stop family, each pipe a cycle with that family's spectrum
 * (rv_organ.h). Pipes don't start together or cleanly: each rank speaks after its own small delay
 * (SPREAD), rises over SPEECH (the higher ranks a little quicker) and comes in slightly flat, with a
 * CHIFF of air at the onset. AIR keeps a breath under the tone, WIND makes the supply waver (pitch
 * and level), the TREMULANT throbs, and CELESTE adds a second 8' rank tuned sharp so it beats. The
 * church is the SPACE bus: CLOUDS, with a long DECAY. */
#define ORG_DATA
#include "rv_organ.h"
static const float org_gain[5] = {1.0f, 1.05f, 1.5f, 2.4f, 2.4f};
static const float org_ratio[8] = {0.5f, 1.0f, 2.0f, 3.0f, 4.0f, 5.0f, 8.0f, 1.0f};

static void organ_note(voice_t *v, const float *eff)
{
    organ_t *o = &v->e.og;
    int k;
    float spread = eff[TP_S10] * (0.035f / 127.0f), wind = eff[TP_S12] * (4.0f / 127.0f);
    if (!o->ns)
        o->ns = v->rng | 1u;
    o->t = 0.0f;
    o->chiff = 1.0f;
    for (k = 0; k < 8; k++) {
        o->dly[k] = spread * (xs_bi(&o->ns) * 0.5f + 0.5f);   /* each pipe speaks in its own time */
        o->cents[k] = wind * 0.5f * xs_bi(&o->ns);           /* and is a touch out with its neighbours */
        o->ph[k] = xs_bi(&o->ns) * 0.5f + 0.5f;
    }
}

RV_INL void organ_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    organ_t *o = &v->e.og;
    int stop = clampi((int)(eff[TP_S0] + 0.5f), 0, ORG_STOPS - 1), i, k, nr = 0;
    float speech = 0.01f * fm_exp2f(eff[TP_S9] * (3.9f / 127.0f)), dt = (float)n * RV_DT;
    float chiff = eff[TP_S8] * (1.0f / 127.0f), air = eff[TP_S11] * (0.06f / 127.0f), wind = eff[TP_S12] * (1.0f / 127.0f);
    float trem = eff[TP_S13] * (1.0f / 127.0f), trem_hz = 3.0f * fm_exp2f(eff[TP_S14] * (1.6f / 127.0f));
    float celeste = eff[TP_S15] * (14.0f / 127.0f), lvl[8], inc[8], share[8], tot = 0.0f, onset = 0.0f, tr, wob;
    int idx[8];
    /* the wind: a slow wander in pitch and level; the tremulant */
    o->wind_v += (xs_bi(&o->ns) - o->wind_v) * dt * 3.0f;
    o->wind += (o->wind_v - o->wind) * dt * 1.5f;
    o->trem_ph += trem_hz * dt;
    o->trem_ph -= fm_floorf(o->trem_ph);
    tr = trem * fm_sin_turns(o->trem_ph);
    wob = o->wind * wind;
    for (k = 0; k < 8; k++) {
        float lv = k < 7 ? eff[TP_S1 + k] * (1.0f / 127.0f) : (celeste > 0.01f ? eff[TP_S2] * (0.8f / 127.0f) : 0.0f);
        float age = o->t - o->dly[k], sp = speech * (1.0f - (float)(k < 7 ? k : 1) * 0.07f), g, fr, cents;
        if (lv < 0.002f)
            continue;
        g = age <= 0.0f ? 0.0f : 1.0f - fm_expf(-age / sp);
        cents = o->cents[k] - (1.0f - g) * 18.0f + wob * 3.0f + tr * 6.0f + (k == 7 ? celeste : 0.0f);   /* pipes come in flat */
        fr = f * org_ratio[k] * fm_exp2f(cents * (1.0f / 1200.0f));
        if (fr > 0.45f * (float)RV_FS)                 /* above what a pipe could sound */
            continue;
        idx[nr] = k;
        lvl[nr] = lv * g * (1.0f + tr * 0.22f + wob * 0.03f);
        inc[nr] = fr * RV_DT * (float)ORG_N;
        {                                              /* the harmonics that fit: full (24), plain (4) or pure (1) */
            float room = 0.45f * (float)RV_FS / fr;
            share[nr] = room >= 24.0f ? 0.0f : room >= 4.0f ? (24.0f - room) / 20.0f : 1.0f + clampf((4.0f - room) / 3.0f, 0.0f, 1.0f);
        }
        nr++;
        tot += lv;
        onset += g;
    }
    tot = 0.55f / (tot > 1.0f ? fm_sqrtf(tot) : 1.0f) * org_gain[stop];   /* the bright stops' peaks sit higher: level them */
    svf_set(&o->ch, f * 3.0f < 9000.0f ? f * 3.0f : 9000.0f, 5.0f);
    {   /* each rank over the whole step (its phase in a register, its tables chosen once), summed in
         * rank order as ever; then the air, a sample at a time */
        float yb[RV_SUB];
        for (i = 0; i < n; i++)
            yb[i] = 0.0f;
        for (k = 0; k < nr; k++) {
            int r = idx[k], lo = share[k] < 1.0f ? 0 : 1;   /* share 0..1: full to plain, 1..2: plain to pure */
            float sh = share[k] - (float)lo, ph = o->ph[r], dp = inc[k], lv = lvl[k];
            const int8_t *ta = org_tab[stop][lo], *tb = org_tab[stop][lo + 1];
            if (sh > 0.001f) {
                for (i = 0; i < n; i++) {
                    int i0, i1;
                    float fr, a, b;
                    ph += dp;
                    if (ph >= (float)ORG_N)
                        ph -= (float)ORG_N;
                    i0 = (int)ph;
                    fr = ph - (float)i0;
                    i1 = (i0 + 1) & (ORG_N - 1);
                    a = ta[i0] + (ta[i1] - ta[i0]) * fr;
                    b = tb[i0] + (tb[i1] - tb[i0]) * fr;
                    a += (b - a) * sh;
                    yb[i] += a * lv;
                }
            } else {
                for (i = 0; i < n; i++) {
                    int i0, i1;
                    float fr;
                    ph += dp;
                    if (ph >= (float)ORG_N)
                        ph -= (float)ORG_N;
                    i0 = (int)ph;
                    fr = ph - (float)i0;
                    i1 = (i0 + 1) & (ORG_N - 1);
                    yb[i] += (ta[i0] + (ta[i1] - ta[i0]) * fr) * lv;
                }
            }
            o->ph[r] = ph;
        }
        for (i = 0; i < n; i++) {
            float y = yb[i], ns = xs_bi(&o->ns), bp;
            y *= (1.0f / 127.0f);
            svf_tick(&o->ch, ns, &bp, 0);              /* the chiff: air through the pipe's mouth */
            o->air_lp += (ns - o->air_lp) * 0.08f;
            y += bp * chiff * o->chiff * 0.5f + o->air_lp * air * (0.3f + 0.7f * (nr ? onset / (float)nr : 0.0f));
            out[i] = y * tot;
            o->chiff *= 0.9992f;
        }
    }
    o->t += dt;
}

/* --------------------------------------------------------------- MONO --- */
/* After the SH-101 as Dorian Concept plays it, like a wind or bowed instrument. One oscillator
 * (the 101's way: saw, pulse and a sub all from one source, so nothing detunes), mixed as on its
 * panel; the track filter defaults to SH-101 and follows the keys. Notes played legato keep the
 * envelope going and glide (RETRIG ALWAYS starts each one again); a detached note SCOOPs up into
 * pitch; the vibrato fades in after VIB DLY; DRIFT lets the pitch breathe; VEL>CUT opens the
 * filter with velocity; DRIVE pushes into the filter. */
static void mono_note(voice_t *v, const float *eff, int legato)
{
    mono_t *m = &v->e.mo;
    (void)eff;
    if (!m->ns)
        m->ns = v->rng | 1u;
    if (!legato) {
        m->scoop = 1.0f;
        m->vib_t = 0.0f;
    }
}

RV_INL void mono_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    mono_t *m = &v->e.mo;
    int sub_mode = clampi((int)(eff[TP_S3] + 0.5f), 0, 2), i;
    float saw = eff[TP_S0] * (1.0f / 127.0f), pul = eff[TP_S1] * (1.0f / 127.0f), sub = eff[TP_S2] * (1.0f / 127.0f);
    float noise = eff[TP_S4] * (1.0f / 127.0f), pwm = eff[TP_S6] * (1.0f / 127.0f), dt = (float)n * RV_DT;
    float scoop = eff[TP_S7] * (3.0f / 127.0f), stime = 0.005f * fm_exp2f(eff[TP_S8] * (5.3f / 127.0f));
    float vib = eff[TP_S9] * (50.0f / 127.0f), vrate = fm_exp2f(eff[TP_S10] * (3.17f / 127.0f));
    float vdly = eff[TP_S11] * (1.5f / 127.0f), drift = eff[TP_S13] * (3.0f / 127.0f), drive = 1.0f + eff[TP_S15] * (2.0f / 127.0f);
    float lfo, cents, d, pw, mixn, sd;
    m->vib_t += dt;
    m->vib_ph += vrate * dt;
    m->vib_ph -= fm_floorf(m->vib_ph);
    lfo = fm_sin_turns(m->vib_ph);
    m->drift_v += (xs_bi(&m->ns) - m->drift_v) * dt * 2.0f;
    m->drift += (m->drift_v - m->drift) * dt * 0.8f;
    cents = vib * lfo * clampf(vdly > 0.01f ? m->vib_t / vdly : 1.0f, 0.0f, 1.0f) + drift * m->drift * 2.0f - scoop * 100.0f * m->scoop;
    m->scoop *= fm_expf(-dt / stime);
    d = clampf(f * fm_exp2f(cents * (1.0f / 1200.0f)) * RV_DT, 0.0f, 0.45f);
    pw = clampf(0.5f - eff[TP_S5] * (0.42f / 127.0f) + pwm * 0.4f * lfo, 0.05f, 0.95f);
    mixn = saw + pul + sub + noise;
    mixn = drive * 0.5f / (mixn > 1.0f ? mixn : 1.0f);
    sd = d * (sub_mode == 0 ? 0.5f : 0.25f);
    for (i = 0; i < n; i++) {
        float y = 0.0f, p2;
        m->ph += d;
        if (m->ph >= 1.0f)
            m->ph -= 1.0f;
        m->sub += sd;
        if (m->sub >= 1.0f)
            m->sub -= 1.0f;
        if (saw > 0.0f)
            y += saw * (2.0f * m->ph - 1.0f - blep(m->ph, d));
        if (pul > 0.0f) {
            p2 = m->ph + (1.0f - pw);
            p2 -= fm_floorf(p2);
            y += pul * ((m->ph < pw ? 1.0f : -1.0f) + blep(m->ph, d) - blep(p2, d));
        }
        if (sub > 0.0f) {
            float spw = sub_mode == 2 ? 0.25f : 0.5f, s2 = m->sub + (1.0f - spw);
            s2 -= fm_floorf(s2);
            y += sub * ((m->sub < spw ? 1.0f : -1.0f) + blep(m->sub, sd) - blep(s2, sd));
        }
        if (noise > 0.0f)
            y += noise * xs_bi(&m->ns);
        out[i] = y * mixn;
    }
}

RV_INL void voice_engine_reset(voice_t *v, int eng)
{
    __builtin_memset(&v->e, 0, sizeof(v->e));
    switch (eng) {
    case ENG_VA: v->e.va.ns = v->rng | 1u; break;
    case ENG_PIANO: v->e.pn.ns = v->rng | 1u; break;
    case ENG_PHYS: v->e.ph.ns = v->rng | 1u; break;
    case ENG_FORMANT: v->e.fo.ns = v->rng | 1u; break;
    case ENG_PARTICLE: v->e.pa.ns = v->rng | 1u; break;
    case ENG_RESIN: v->e.rs.ns = v->rng | 1u; break;
    case ENG_TINE: v->e.tn.ns = v->rng | 1u; break;
    case ENG_GUITAR: v->e.gt.ns = v->rng | 1u; break;
    case ENG_HARM: v->e.hm.ns = v->rng | 1u; v->e.hm.key[0] = -1.0f; break;
    default: break;
    }
    v->e_eng = (uint8_t)(eng + 1);
}

/* eng: the engine that will render the voice (a stolen voice may hold another engine's state) */
static void synth_voice_note_on(voice_t *v, int note, float vel, int legato, int eng)
{
    v->note = (int8_t)note;
    v->vel = vel;
    v->target = (float)note;
    if (!legato)
        v->pitch = (float)note;
    if (!v->on || v->e_eng != eng + 1) {
        voice_engine_reset(v, eng);
        v->a.p = v->a.s = v->a.v = v->a.out = 0.0f;
        v->lad.s[0] = v->lad.s[1] = v->lad.s[2] = v->lad.s[3] = 0.0f;
        __builtin_memset(v->zp.s, 0, sizeof(v->zp.s));
        v->svf2.ic1 = v->svf2.ic2 = 0.0f;
        v->xs_y = v->xs_acc = 0.0f;
        v->svf.ic1 = v->svf.ic2 = 0.0f;
        v->lpg = 0.0f;
    }
    v->on = 1;
}

/* -------------------------------------------------------------- RESIN --- */
/* Two acoustic instruments pushed toward breaking down. BOW is a bowed string: two segments of
 * waveguide meet at the bow, which grips and slips by a friction curve; PRESS and ROSIN shape the
 * curve, SPEED is the bow's, SCRAPE puts noise into the slips (so it follows the bow, not the
 * output), HARMON leans toward the octave's flageolet, BODY rings three modes scaled by SIZE
 * (violin to cello). HORN is a reed and a bore (after STK's saxophone): breath against a reed
 * table, the bore in two segments (BORE sets where), GROWL a sung tone fed into the breath so it
 * meets the reed, MULTI a second, inharmonic reflection that pushes it into multiphonics, THROAT a
 * resonance, KEYS a click at each note, AIR the breath's noise. Both carry their own vibrato (RATE,
 * DEPTH, an ONSET it grows in over), a slow DRIFT, and QUAKE: the instability inside the sound,
 * pressure that wavers, pitch that quivers, grit, squeals, breakup. */
#define RS_BOW_GAIN 0.5f

static void resin_note(voice_t *v, const float *eff, int legato)
{
    resin_t *s = &v->e.rs;
    if (!s->ns)
        s->ns = v->rng | 1u;
    if (!legato) {
        s->vib_env = 0.0f;
        s->held = 0.0f;
    }
    if ((int)(eff[TP_S0] + 0.5f) == 1)                /* HORN: the keys clack */
        s->click = eff[TP_S14] * (1.0f / 127.0f) * (0.4f + 0.6f * v->vel);
}

/* a wandering value: noise leaking toward 0 at rate k (per second), about +-1 */
static inline void rs_wander(float *x, float *xv, uint32_t *ns, float k, float dt)
{
    *xv += (xs_bi(ns) * 1.7f - *xv) * fm_minf(1.0f, k * dt * 2.0f);
    *x += (*xv - *x) * fm_minf(1.0f, k * dt);
}

static inline float rs_read(const int16_t *b, int len, int w, float d)
{
    int di = (int)d, r0 = w - di, r1;
    float fr = d - (float)di;
    if (r0 < 0)
        r0 += len;
    r1 = r0 - 1;
    if (r1 < 0)
        r1 += len;
    return (b[r0] + (b[r1] - b[r0]) * fr) * (1.0f / 16000.0f);
}

RV_INL void resin_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    resin_t *s = &v->e.rs;
    int horn = (int)(eff[TP_S0] + 0.5f) == 1, i, k;
    float dt = (float)n * RV_DT, q = eff[TP_S12] * (1.0f / 127.0f), cents, per, tot, lpc, lpd, db, dn, atk, att, rel;
    float vrate = 3.0f + eff[TP_S8] * (6.0f / 127.0f), vdep = eff[TP_S9] * (60.0f / 127.0f);
    float onset = 0.02f + eff[TP_S10] * eff[TP_S10] * (2.5f / 16129.0f), size = eff[TP_S7] * (1.0f / 127.0f);
    if ((uint32_t)s->wb >= RS_BR || (uint32_t)s->wk >= RS_NK)   /* (after another engine had the voice) */
        s->wb = s->wk = 0;
    if (!(s->bow == s->bow) || fm_fabsf(s->bow) > 4.0f || !(s->lp == s->lp))
        s->bow = s->lp = s->dly = 0.0f;
    if (!s->ns)
        s->ns = v->rng | 1u;
    /* the movers, once a block */
    if (v->a.gate) {
        s->held += dt;
        s->vib_env = fm_minf(1.0f, s->vib_env + dt / onset);
    }
    s->vib_ph += vrate * dt * (1.0f + 0.06f * s->drift);
    s->vib_ph -= fm_floorf(s->vib_ph);
    rs_wander(&s->drift, &s->drift_v, &s->ns, 0.6f, dt);
    rs_wander(&s->quiv, &s->quiv_v, &s->ns, 11.0f, dt);
    rs_wander(&s->jit, &s->jit_v, &s->ns, 7.0f, dt);
    cents = vdep * s->vib_env * sin_lut(s->vib_ph) + eff[TP_S11] * (25.0f / 127.0f) * s->drift + q * q * 22.0f * s->quiv;
    f *= fm_exp2f(cents * (1.0f / 1200.0f));
    s->sq *= fm_expf(-dt / 0.08f);                    /* QUAKE's squeals: now and then the string jumps up */
    if (!horn && q > 0.3f && v->a.gate && (xs32(&s->ns) & 0xFFFF) < (uint32_t)(q * q * q * dt * 4.0f * 65536.0f))
        s->sq = 0.6f + 0.4f * q;
    per = 44100.0f / (f > 20.0f ? f : 20.0f);
    atk = 0.004f + eff[TP_S13] * eff[TP_S13] * (1.5f / 16129.0f);   /* BOW ATK / ATTACK: how fast the bow (breath) builds */
    att = 1.0f - fm_expf(-1.0f / (atk * 44100.0f));
    rel = 1.0f - fm_expf(-1.0f / (0.03f * 44100.0f));
    if (!horn) {
        float press = clampf(eff[TP_S1] * (1.0f / 127.0f) + q * 0.25f + q * 0.35f * s->jit, 0.0f, 1.0f);   /* QUAKE leans on the bow too */
        float speed = (0.04f + eff[TP_S2] * (0.28f / 127.0f)) * (0.6f + 0.4f * v->vel) * (1.0f + q * 0.3f * s->quiv);
        float slope = 5.5f - press * 4.2f, offset = 0.9f - eff[TP_S14] * (0.35f / 127.0f);
        float scrape = clampf(eff[TP_S4] * (1.0f / 127.0f) + q * 0.5f, 0.0f, 1.0f), hiss = eff[TP_S15] * (1.0f / 127.0f);
        float harm = clampf(eff[TP_S5] * (1.0f / 127.0f) + s->sq, 0.0f, 1.0f), body = eff[TP_S6] * (1.0f / 127.0f);
        float beta = 0.04f + eff[TP_S3] * (0.4f / 127.0f), breakup = press > 0.7f ? (press - 0.7f) * 3.3f : 0.0f;
        float fs = fm_exp2f(-size * 1.7f), b1[3], b2[3], half;
        static const float bf[3] = {290.0f, 470.0f, 1150.0f}, bg[3] = {1.0f, 0.7f, 0.45f};
        for (k = 0; k < 3; k++) {                     /* the body's three modes, scaled by SIZE */
            float r = fm_exp2f(-1.0f / (0.035f * 44100.0f) * 1.44f), fr = bf[k] * fs;
            b1[k] = r * fm_cosf(6.2831853f * fr * RV_DT);
            b2[k] = r * fm_sinf(6.2831853f * fr * RV_DT);
        }
        lpc = 0.62f + 0.3f * (1.0f - size);
        lpd = (1.0f - lpc) / lpc;
        tot = per - lpd;
        if (tot > (float)(RS_NK - 3))
            tot = (float)(RS_NK - 3);
        db = clampf(tot * beta, 1.5f, (float)(RS_BR - 3));
        dn = clampf(tot - db, 1.5f, (float)(RS_NK - 3));
        half = clampf(db + per * 0.5f, 2.0f, (float)(RS_BR - 3));
        for (i = 0; i < n; i++) {
            float a0, a1, brr, nr, sv, dv, bt, nv, slip, y, nz = xs_bi(&s->ns), bo = 0.0f;
            a0 = rs_read(s->br, RS_BR, s->wb, db);
            a1 = rs_read(s->nk, RS_NK, s->wk, dn);
            s->lp += (a0 - s->lp) * lpc;
            brr = -s->lp * 0.995f;                    /* the bridge reflects, with loss */
            nr = -a1;                                 /* the nut */
            sv = brr + nr;
            s->bow += ((v->a.gate ? speed : 0.0f) - s->bow) * (v->a.gate ? att : rel);
            dv = s->bow - sv;
            bt = fm_fabsf(dv * slope) + offset;
            bt = 1.0f / (bt * bt * bt * bt);
            if (bt > 1.0f)
                bt = 1.0f;
            if (breakup > 0.0f)                       /* past a point the grip turns erratic */
                bt *= 1.0f + breakup * 0.6f * nz;
            slip = 1.0f - bt;
            nv = dv * bt + nz * scrape * slip * 0.12f * (0.4f + press);   /* SCRAPE: noise in the slips */
            s->nk[s->wk] = (int16_t)clampf((brr + nv) * 16000.0f, -32760.0f, 32760.0f);
            s->br[s->wb] = (int16_t)clampf((nr + nv) * 16000.0f, -32760.0f, 32760.0f);
            s->wb = s->wb + 1 >= RS_BR ? 0 : s->wb + 1;
            s->wk = s->wk + 1 >= RS_NK ? 0 : s->wk + 1;
            y = a0;
            if (harm > 0.01f)                         /* HARMON: the octave's flageolet, the odd partials thinned */
                y = (a0 * (1.0f - harm) + harm * 0.5f * (a0 + rs_read(s->br, RS_BR, s->wb, half))) * (1.0f + 1.6f * harm);
            for (k = 0; k < 3; k++) {                 /* the body */
                float re = b1[k] * s->body[k][0] - b2[k] * s->body[k][1] + y * bg[k] * 0.012f;
                float im = b2[k] * s->body[k][0] + b1[k] * s->body[k][1];
                s->body[k][0] = re;
                s->body[k][1] = im;
                bo += im;
            }
            {
                float hn = nz - s->hp;                /* HISS: the hair on the string */
                s->hp += (nz - s->hp) * 0.25f;
                y += hn * hiss * s->bow * 0.9f;
            }
            out[i] = (y + body * bo) * RS_BOW_GAIN;
        }
        return;
    }
    {   /* HORN */
        float breath = (0.3f + eff[TP_S1] * (0.8f / 127.0f)) * (0.7f + 0.3f * v->vel) * (1.0f + q * 0.3f * s->jit);
        float rs = eff[TP_S2] * (1.0f / 127.0f), slope = 0.18f + rs * 0.3f + q * 0.08f * s->quiv, offset = 0.62f + rs * 0.2f;
        float pos = 0.12f + eff[TP_S3] * (0.35f / 127.0f), growl = clampf(eff[TP_S4] * (1.0f / 127.0f) + q * 0.25f, 0.0f, 1.0f);
        float multi = clampf(eff[TP_S5] * (1.0f / 127.0f) + q * 0.4f, 0.0f, 1.0f), air = eff[TP_S15] * (1.0f / 127.0f);
        float gf = f * (0.5f + 0.012f * s->drift + 0.02f * q * s->quiv), drive = 1.0f + q * 2.5f + breath;
        float dm;
        svf_set(&s->thr, 250.0f * fm_exp2f(eff[TP_S6] * (3.0f / 127.0f)), 2.5f);   /* THROAT: 250 Hz to 2 kHz */
        lpc = 0.85f - size * 0.5f;
        lpd = (1.0f - lpc) / lpc;
        tot = per - lpd;
        if (tot > (float)(RS_NK - 3))
            tot = (float)(RS_NK - 3);
        db = clampf(tot * pos, 1.5f, (float)(RS_BR - 3));
        dn = clampf(tot - db, 1.5f, (float)(RS_NK - 3));
        dm = clampf(dn * 0.62f, 1.5f, (float)(RS_NK - 3));
        for (i = 0; i < n; i++) {
            float a0, a1, tmp, last, pd, rt, br, nz = xs_bi(&s->ns), bp, y;
            s->bow += ((v->a.gate ? breath : 0.0f) - s->bow) * (v->a.gate ? att : rel);
            s->gph += gf * RV_DT;
            s->gph -= fm_floorf(s->gph);
            br = s->bow * (1.0f + growl * 0.7f * sin_lut(s->gph)) * (1.0f + air * 0.2f * nz);   /* GROWL meets the reed */
            a1 = rs_read(s->nk, RS_NK, s->wk, dn);
            a0 = rs_read(s->br, RS_BR, s->wb, db);
            s->lp += (a1 - s->lp) * lpc;
            tmp = -0.95f * s->lp;
            if (multi > 0.01f)                        /* MULTI: a second, inharmonic reflection */
                tmp += multi * 0.32f * rs_read(s->nk, RS_NK, s->wk, dm);
            last = tmp - a0;
            pd = br - last;
            rt = clampf(offset + slope * pd, -1.0f, 1.0f);   /* the reed opens and closes */
            s->br[s->wb] = (int16_t)clampf(tmp * 16000.0f, -32760.0f, 32760.0f);
            s->nk[s->wk] = (int16_t)clampf((br - pd * rt - tmp) * 16000.0f, -32760.0f, 32760.0f);
            s->wb = s->wb + 1 >= RS_BR ? 0 : s->wb + 1;
            s->wk = s->wk + 1 >= RS_NK ? 0 : s->wk + 1;
            svf_tick(&s->thr, last, &bp, 0);
            y = last + bp * 0.6f + air * 0.05f * nz * s->bow;
            y *= drive;                               /* pressure and QUAKE push it into saturation */
            y = y / (1.0f + fm_fabsf(y));
            if (s->click > 0.0005f) {                 /* KEYS */
                y += s->click * (nz * 0.6f + 0.4f);
                s->click *= 0.994f;
            }
            out[i] = y * 0.6f;
        }
    }
}


/* --------------------------------------------------------------- TINE --- */
/* Struck and plucked metal and wood as a bank of up to eight modes, each a decaying rotation
 * (re, im) that a short half-sine pulse sets ringing; a harder PLUCK, MALLET or HAMMER is a
 * shorter pulse, which reaches the higher modes. KALIMBA: a thick tine's clamped-bar modes,
 * a second, slightly detuned fundamental (the tine also swings sideways) and RUST's stray,
 * quickly dying partials; the rings on the tines (BUZZ) rattle when the tine swings past
 * RATTLE's reach; a box with a hole (HOLE, WAH as a hand opening and closing it). MARIMBA: bars
 * tuned 1 : 4 : 10, struck at POSITN, a tube under each (TUBE) that carries the fundamental,
 * ROLL for held notes, BUZZ for a balafon's gourds. EPIANO: a tine and its tonebar before a
 * pickup (after the Rhodes): BELL the tine's high partial, PICKUP how far off centre the tine
 * swings (the second harmonic), BARK how hard a hard note drives it, TREM, DRIVE, THUMP and
 * the dampers' KEY OFF. All: DECAY, TONE (how much faster the high modes die), DETUNE (each
 * note a little out, as tines are), DAMP (how fast a released note stops), DRIFT. */
#define TN_KAL 0
#define TN_MAR 1
#define TN_EP 2

static void tine_add(tine_t *s, float rat, float w, float dk)
{
    if (s->nm >= TN_M)
        return;
    s->rat[s->nm] = rat;
    s->lr[s->nm] = fm_log2f(rat > 1.0f ? rat : 1.0f);
    s->w[s->nm] = w;
    s->dk[s->nm] = dk;                                /* this mode's decay, as a share of its natural one */
    s->nm++;
}

static void tine_strike(tine_t *s, const float *eff, float vel, float amp)
{
    int model = clampi((int)(eff[TP_S0] + 0.5f), 0, 2);
    float hard = eff[TP_S1] * (1.0f / 127.0f), sc = model == TN_KAL ? 0.3f : model == TN_EP ? 0.55f : 1.0f;   /* a thumb lets go sharply; felt is softer */
    s->exc_len = (0.00012f + (1.0f - hard) * (1.0f - hard) * 0.0032f) * (1.25f - 0.5f * vel) * sc * 44100.0f;
    if (s->exc_len < 3.0f)
        s->exc_len = 3.0f;
    s->exc_amp = amp * 3.14159265f / (2.0f * s->exc_len);   /* a pulse of area amp */
    s->exc_n = 0.0f;
}

static void tine_note(voice_t *v, const float *eff)
{
    tine_t *s = &v->e.tn;
    int model = clampi((int)(eff[TP_S0] + 0.5f), 0, 2), k;
    float vel = v->vel, r1 = xs_bi(&s->ns), r2 = xs_bi(&s->ns);
    if (!s->ns)
        s->ns = v->rng | 1u;
    s->nm = 0;
    if (model == TN_KAL) {
        float rust = eff[TP_S4] * (1.0f / 127.0f), thick = eff[TP_S7] * (1.0f / 127.0f), sh = 1.0f - 0.16f * thick;
        tine_add(s, 1.0f, 1.0f, 1.0f);
        tine_add(s, 1.0f + 0.0025f + rust * 0.007f * (1.0f + 0.5f * r1), 0.25f + 0.35f * rust, 0.8f);
        tine_add(s, 6.267f * sh * (1.0f + rust * 0.03f * r2), 0.55f - 0.2f * thick, 1.0f);
        tine_add(s, 17.55f * sh * (1.0f + rust * 0.04f * xs_bi(&s->ns)), 0.3f - 0.1f * thick, 1.0f);
        tine_add(s, 34.39f * sh, 0.12f, 1.0f);
        if (rust > 0.05f) {                           /* rust: stray partials that die fast */
            tine_add(s, 2.71f * (1.0f + 0.1f * xs_bi(&s->ns)), rust * 0.3f, 0.12f);
            tine_add(s, 11.3f * (1.0f + 0.1f * xs_bi(&s->ns)), rust * 0.25f, 0.08f);
        }
        s->click = eff[TP_S11] * (1.0f / 127.0f) * (0.3f + 0.7f * vel) * 0.5f;
        s->bend = eff[TP_S13] * (1.0f / 127.0f) * (0.3f + 0.7f * vel) * 0.045f;
    } else if (model == TN_MAR) {
        float pos = eff[TP_S4] * (1.0f / 127.0f), wood = eff[TP_S6] * (1.0f / 127.0f);
        tine_add(s, 1.0f, 1.0f - 0.35f * pos, 1.0f + eff[TP_S5] * (1.6f / 127.0f));   /* the tube carries it */
        tine_add(s, 3.99f, 0.15f + 0.85f * pos, 1.0f);
        tine_add(s, 9.8f + 0.6f * wood, 0.55f + 0.25f * (1.0f - pos), 1.0f);
        tine_add(s, 17.6f, 0.25f * pos + 0.1f, 0.7f);
        tine_add(s, 27.0f, 0.12f, 0.5f);
        s->click = eff[TP_S7] * (1.0f / 127.0f) * (0.3f + 0.7f * vel) * 0.35f;
        s->bend = 0.0f;
        s->roll_t = 0.0f;
    } else {
        float bell = eff[TP_S4] * (1.0f / 127.0f), bar = eff[TP_S7] * (1.0f / 127.0f);
        tine_add(s, 1.0f, 1.0f, 1.0f + bar * 1.2f);
        tine_add(s, 1.0f + 0.0006f + 0.0016f * bar, 0.2f + 0.5f * bar, 1.2f);       /* the tonebar beside it */
        tine_add(s, 2.0f, 0.04f, 0.6f);
        tine_add(s, 7.1f, bell * (0.25f + 0.55f * vel), 0.1f);                     /* the bell: bright, quick */
        tine_add(s, 17.4f, bell * 0.18f * vel, 0.04f);
        s->thump = eff[TP_S11] * (1.0f / 127.0f) * (0.3f + 0.7f * vel) * 0.6f;
        s->bend = 0.0f;
        s->click = 0.0f;
    }
    s->detune = eff[TP_S12] * (40.0f / 127.0f) * xs_bi(&s->ns);   /* cents, this note */
    s->offn = 0.0f;
    s->held = 0.0f;
    s->gate_was = 1;
    for (k = s->nm; k < TN_M; k++)
        s->re[k] = s->im[k] = 0.0f;
    tine_strike(s, eff, vel, 1.0f);
}

RV_INL void tine_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    tine_t *s = &v->e.tn;
    int model = clampi((int)(eff[TP_S0] + 0.5f), 0, 2), i, k, nm = s->nm > TN_M ? TN_M : s->nm;
    float dt = (float)n * RV_DT, vel = v->vel, cs[TN_M], sn[TN_M], rr[TN_M];
    float decay = eff[TP_S2] * (1.0f / 127.0f), tone = eff[TP_S3] * (1.0f / 127.0f), t60, texp, damp;
    float buzz = 0.0f, th = 1.0f, bha = 0.25f, boxa = 0.0f, trem = 0.0f, drive = 0.0f, bias = 0.0f, pk = 1.0f, gain;
    if (!s->ns)
        s->ns = v->rng | 1u;
    if (!nm)
        return;
    for (k = 0; k < nm; k++)
        if (!(s->re[k] == s->re[k]) || fm_fabsf(s->re[k]) > 50.0f)
            s->re[k] = s->im[k] = 0.0f;
    rs_wander(&s->drift, &s->drift_v, &s->ns, 0.5f, dt);
    s->held += dt;
    if (!v->a.gate && s->gate_was) {                  /* released: the dampers, and their noise */
        s->gate_was = 0;
        if (model == TN_EP)
            s->offn = eff[TP_S13] * (1.0f / 127.0f) * 0.12f;
    }
    /* pitch: DETUNE, DRIFT, the tine's bend as it settles */
    s->bend *= fm_expf(-dt / 0.04f);
    f *= fm_exp2f((s->detune + eff[TP_S15] * (14.0f / 127.0f) * s->drift) * (1.0f / 1200.0f)) * (1.0f + s->bend);
    /* how long it rings */
    if (model == TN_KAL) {
        t60 = 0.3f + decay * decay * 9.0f;
        texp = 1.6f - tone * 1.2f + eff[TP_S4] * (0.5f / 127.0f);
    } else if (model == TN_MAR) {
        t60 = 0.15f + decay * decay * 4.5f;
        texp = 1.5f - tone * 1.0f + eff[TP_S6] * (0.4f / 127.0f);
    } else {
        t60 = 0.6f + decay * decay * 14.0f;
        texp = 1.3f - tone * 0.9f;
    }
    t60 *= fm_minf(2.0f, fm_powf(261.6f / (f > 20.0f ? f : 20.0f), 0.45f));   /* high notes die sooner */
    damp = eff[TP_S14] * (1.0f / 127.0f);
    if (!v->a.gate && damp > 0.0f)
        t60 = fm_minf(t60, 0.03f + (1.0f - damp) * (1.0f - damp) * 3.0f);
    for (k = 0; k < nm; k++) {
        float fk = f * s->rat[k], w, g, tk, r;
        if (fk > 18000.0f) {
            cs[k] = 1.0f;
            sn[k] = 0.0f;
            rr[k] = 0.0f;
            continue;
        }
        w = 6.28318531f * fk * RV_DT;
        cs[k] = fm_cosf(w);
        sn[k] = fm_sinf(w);
        g = 1.0f / fm_sqrtf(cs[k] * cs[k] + sn[k] * sn[k]);
        cs[k] *= g;
        sn[k] *= g;
        tk = t60 * s->dk[k] * fm_exp2f(-texp * s->lr[k]);
        if (tk < 0.004f)
            tk = 0.004f;
        r = fm_expf(-6.9078f * RV_DT / tk);
        rr[k] = r;
    }
    /* the model's surroundings */
    if (model == TN_KAL) {
        float hole = eff[TP_S9] * (1.0f / 127.0f), wah = eff[TP_S10] * (1.0f / 127.0f);
        buzz = eff[TP_S5] * (1.0f / 127.0f);
        th = 0.35f + (1.0f - eff[TP_S6] * (1.0f / 127.0f)) * 1.1f;
        bha = 0.35f;
        boxa = eff[TP_S8] * (1.0f / 127.0f);
        if (wah > 0.0f) {                             /* WAH: a hand over the hole, at 1 to 8 Hz */
            s->wah_ph += (1.0f + wah * 7.0f) * dt;
            s->wah_ph -= fm_floorf(s->wah_ph);
            hole *= 0.5f + 0.5f * sin_lut(s->wah_ph);
        }
        svf_set(&s->box[0], 110.0f + hole * 300.0f, 3.0f + hole * 2.0f);   /* the hole: Helmholtz, lower when covered */
        svf_set(&s->box[1], 820.0f, 2.0f);
        gain = 0.3f;
    } else if (model == TN_MAR) {
        float roll = eff[TP_S8] * (1.0f / 127.0f);
        buzz = eff[TP_S10] * (1.0f / 127.0f);
        th = 0.3f + (1.0f - eff[TP_S11] * (1.0f / 127.0f)) * 1.0f;
        bha = 0.06f;                                  /* the gourds: lower, more nasal */
        if (roll > 0.0f && v->a.gate) {               /* ROLL: held notes struck again and again */
            float rate = 5.0f + eff[TP_S9] * (19.0f / 127.0f), hum = eff[TP_S13] * (1.0f / 127.0f);
            s->roll_t += dt;
            if (s->roll_t >= 1.0f / rate) {
                s->roll_t -= (1.0f / rate) * (1.0f + hum * 0.25f * xs_bi(&s->ns));
                tine_strike(s, eff, vel * (1.0f - hum * 0.3f * xs_uni(&s->ns)), roll * (0.4f + 0.25f * xs_uni(&s->ns)));
            }
        }
        gain = 0.5f;
    } else {
        float tr = eff[TP_S8] * (1.0f / 127.0f), pick = eff[TP_S6] * (1.0f / 127.0f), bark = eff[TP_S5] * (1.0f / 127.0f);
        if (tr > 0.0f) {
            s->trem_ph += (1.5f + eff[TP_S9] * (7.5f / 127.0f)) * dt;
            s->trem_ph -= fm_floorf(s->trem_ph);
            trem = tr * 0.5f;
        }
        bias = pick * 0.9f;
        pk = 0.7f + bark * 3.5f * vel * vel + tone * 0.4f;
        drive = eff[TP_S10] * (1.0f / 127.0f);
        gain = 0.65f / pk;
    }
    for (i = 0; i < n; i++) {
        float x = 0.0f, y = 0.0f, nz = xs_bi(&s->ns);
        if (s->exc_n < s->exc_len) {
            x = s->exc_amp * sin_lut(0.5f * s->exc_n / s->exc_len);
            s->exc_n += 1.0f;
            if (model == TN_KAL)                      /* rust grinds in the pluck */
                x *= 1.0f + eff[TP_S4] * (0.6f / 127.0f) * nz;
        }
        for (k = 0; k < nm; k++) {
            float re = s->re[k], im = s->im[k];
            s->re[k] = rr[k] * (cs[k] * re - sn[k] * im) + x * s->w[k];
            s->im[k] = rr[k] * (sn[k] * re + cs[k] * im);
            y += s->im[k];
        }
        if (model == TN_EP) {                         /* the pickup: off centre, so it bends the wave */
            float z = y * pk + bias, b0 = bias / (1.0f + fm_fabsf(bias)), d0 = 1.0f / ((1.0f + fm_fabsf(bias)) * (1.0f + fm_fabsf(bias)));
            y = (z / (1.0f + fm_fabsf(z)) - b0) / d0;
            if (drive > 0.0f) {
                float dz = y * (1.0f + drive * 4.0f);
                y = dz / (1.0f + fm_fabsf(dz)) * (1.0f + drive);
            }
            if (s->thump > 0.0005f) {                 /* the hammer's thud */
                s->thlp += (nz - s->thlp) * 0.02f;
                y += s->thump * s->thlp * 6.0f;
                s->thump *= 0.9985f;
            }
            if (trem > 0.0f)
                y *= 1.0f - trem * (1.0f + sin_lut(s->trem_ph));
        } else {
            if (buzz > 0.0f) {                        /* the rings (or gourds) rattle past their reach */
                float a = fm_fabsf(y) - th, b = a > 0.0f ? a * (0.8f + 0.2f * nz) * (y > 0.0f ? 1.0f : -1.0f) : 0.0f;
                s->blp += (b - s->blp) * bha;
                y += buzz * (b - s->blp) * 2.5f;
            }
            if (boxa > 0.0f) {
                float b0, b1;
                svf_tick(&s->box[0], y, &b0, 0);
                svf_tick(&s->box[1], y, &b1, 0);
                y += boxa * (b0 * 0.9f + b1 * 0.35f);
            }
            if (s->click > 0.0005f) {                 /* thumbnail or stick on the attack */
                y += s->click * nz;
                s->click *= 0.982f;
            }
        }
        if (s->offn > 0.0005f) {
            y += s->offn * nz;
            s->offn *= 0.996f;
        }
        out[i] = y * gain;
    }
}

/* ------------------------------------------------------------ GUITAR --- */
/* A plucked string (an extended Karplus-Strong): a burst into a delay tuned to the note, a low pass in its loop.
 * PICK is the burst's brightness, POSITN where it is plucked (a comb on the burst), DECAY how long it rings, MUTE a
 * palm on the bridge (darker, shorter), PICKUP where it is heard (another comb, bridge to neck), STRUM how far
 * apart the notes of a chord start. The pedal, amp and cabinet are the track's (rv_engine.c gtr_amp). */
static __attribute__((noinline)) RV_SMALL void gtr_pluck(gtr_t *s, const float *eff, float per, float vel)
{
    float pick = eff[TP_S0] * (1.0f / 127.0f), mute = eff[TP_S3] * (1.0f / 127.0f), lp = 0.0f, lp2 = 0.0f;
    float c = clampf((0.08f + 0.9f * pick) * (0.6f + 0.4f * vel) * (1.0f - 0.5f * mute), 0.02f, 0.99f), scr = pick * pick * 0.25f;
    float pos = 0.04f + eff[TP_S1] * (0.42f / 127.0f), amp = vel * 22000.0f, ip, ip2;
    int len = clampi((int)per, 4, GT_LEN - 2), i, k, r0 = s->w - len;
    if (r0 < 0)
        r0 += GT_LEN;
    ip = 1.0f / ((float)len * pos);
    ip2 = 1.0f / ((float)len * (1.0f - pos));
    for (i = 0; i < len; i++) {                       /* the string's shape as the pick lets go: a triangle with its
                                                     * corner at POSITN (its harmonics fall as 1/n^2, those at the
                                                     * position missing), rounded by the pick (PICK: soft to hard),
                                                     * a little scrape with a hard one; laid on what still rings */
        float x = (float)i < (float)len * pos ? (float)i * ip : (float)(len - i) * ip2;
        x = x - 0.5f + scr * xs_bi(&s->ns);
        lp += (x - lp) * c;
        lp2 += (lp - lp2) * c;
        k = r0 + i < GT_LEN ? r0 + i : r0 + i - GT_LEN;
        s->line[k] = (int16_t)clampf((float)s->line[k] * 0.25f + lp2 * amp, -32000.0f, 32000.0f);
    }
    s->plucked = 1;
}

/* (in the flash: the voices' code in RAM has no room for it; the loop is short and stays in the cache) */
static __attribute__((noinline)) void gtr_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    gtr_t *s = &v->e.gt;
    float decay = eff[TP_S2] * (1.0f / 127.0f), mute = eff[TP_S3] * (1.0f / 127.0f), pkup = eff[TP_S4] * (1.0f / 127.0f);
    float per = 44100.0f / (f > 25.0f ? f : 25.0f), t60, g, lpc, lpd, d, pud, puc, tm;
    int i, len;
    if ((uint32_t)s->w >= GT_LEN)                     /* (the voice's memory may hold another engine's bytes) */
        s->w = 0;
    if (!(s->lp == s->lp) || fm_fabsf(s->lp) > 4.0f || !(s->dcy == s->dcy) || !(s->pu == s->pu))
        s->lp = s->dcx = s->dcy = s->pu = 0.0f;
    if (!s->ns)
        s->ns = v->rng | 1u;
    s->held += (float)n * RV_DT;
    if (!s->plucked) {
        if (s->wait > (float)n)
            s->wait -= (float)n;
        else
            gtr_pluck(s, eff, per, v->vel);
    }
    t60 = 0.35f + decay * decay * 13.0f;
    t60 *= clampf(fm_sqrtf(196.0f / (f > 20.0f ? f : 20.0f)), 0.35f, 1.6f);   /* the low strings ring longer */
    tm = 0.05f + 0.3f * (1.0f - mute);                /* MUTE: the palm shortens it, */
    t60 += (tm - t60) * fm_minf(1.0f, mute * 1.6f);
    if (!v->a.gate)                                   /* the fretting hand lets go */
        t60 = fm_minf(t60, 0.09f);
    lpc = clampf(0.5f + 0.47f * (1.0f - mute) - 0.3f * mute, 0.12f, 0.97f);   /* and darkens it */
    g = fm_exp2f(-per / (t60 * 44100.0f) * 9.97f);
    lpd = (1.0f - lpc) / lpc;                         /* the loss filter's delay, tuned out */
    d = clampf(per - lpd, 2.0f, (float)(GT_LEN - 3));
    len = (int)d;
    pud = clampf((float)len * (0.05f + 0.22f * (1.0f - pkup)), 1.0f, (float)(GT_LEN - 3));   /* PICKUP: bridge (bright) to neck */
    puc = 0.3f + 0.65f * pkup;
    for (i = 0; i < n; i++) {
        float fr = d - (float)len, a0, a1, y, pu;
        int r0 = s->w - len, r1, rp;
        if (r0 < 0)
            r0 += GT_LEN;
        r1 = r0 - 1;
        if (r1 < 0)
            r1 += GT_LEN;
        a0 = ((float)s->line[r0] + (float)(s->line[r1] - s->line[r0]) * fr) * (1.0f / 16000.0f);
        s->lp += (a0 - s->lp) * lpc;
        y = s->lp * g;
        s->line[s->w] = (int16_t)clampf(y * 16000.0f, -32000.0f, 32000.0f);
        rp = s->w - (int)pud;
        if (rp < 0)
            rp += GT_LEN;
        if (++s->w >= GT_LEN)
            s->w = 0;
        a1 = (float)s->line[rp] * (1.0f / 16000.0f);
        pu = y - a1 * 0.6f;                           /* the pickup hears the string less where it sits */
        s->pu += (pu - s->pu) * puc;
        pu = s->pu - s->dcx + 0.995f * s->dcy;        /* (no DC) */
        s->dcx = s->pu;
        s->dcy = pu;
        out[i] = pu * 0.9f;
    }
}

/* ---------------------------------------------------------- HARMONIC --- */
/* After Make Noise's Telharmonic. H: 24 harmonics, the loudest at CENTROID, its neighbours falling away the more
 * FLUX, LOCK one held at full, EVEN the odd ones against the even; worked into a one-cycle table only when that
 * changes (or the top voice's pitch drops harmonics past the top), so it costs a table read a voice. P: a carrier
 * phase-modulated by two sines locked to it, at the two harmonics either side of CENTROID (1 to 8), FLUX taking
 * the modulation away (a sine at full). N: noise, FLUX wide, in two sidebands around the note. Up to three voices
 * an INTERVAL apart (a chord), DETUNE between them */
static const int8_t harm_iv[8][2] = {{0, 0}, {12, -12}, {7, 12}, {5, 12}, {4, 7}, {3, 7}, {5, 7}, {4, 10}};
static __attribute__((noinline)) RV_SMALL void harm_table(harm_t *s, float c, float fl, int lock, float ev, int top)
{
    float a[24], sum = 0.0f;
    int k, i;
    for (k = 0; k < 24; k++) {
        float d = fm_fabsf((float)(k + 1) - c);
        a[k] = k < top ? fm_exp2f(-d * fl * fl * 2.5f) * ((k & 1) ? ev : 2.0f - ev) : 0.0f;
        if (k + 1 == lock && k < top)
            a[k] = 1.0f;
        sum += a[k];
    }
    sum = 0.9f / fm_maxf(sum, 1.0f) * fm_minf(4.0f, 1.0f + sum * 0.15f);   /* (about as loud, few harmonics or many) */
    for (i = 0; i < HM_TAB; i++) {
        float y = 0.0f;
        for (k = 0; k < 24; k++)
            if (a[k] > 0.0f)
                y += a[k] * sine_tab[((k + 1) * i * (1024 / HM_TAB)) & 1023];
        s->tab[i] = y * sum;
    }
    s->tab[HM_TAB] = s->tab[0];
}
static __attribute__((noinline)) void harm_render(voice_t *v, const float *eff, float f, float *out, int n)
{
    harm_t *s = &v->e.hm;
    int iv = clampi((int)(eff[TP_S2] + 0.5f), 0, 7), nv = clampi((int)(eff[TP_S3] + 0.5f), 0, 2) + 1, lock = (int)(eff[TP_S7] + 0.5f), i, j, top;
    float c = 1.0f + eff[TP_S0] * (23.0f / 127.0f), fl = eff[TP_S1] * (1.0f / 127.0f), ev = eff[TP_S8] * (1.0f / 64.0f);
    float lh = eff[TP_S4] * (1.0f / 127.0f), lp = eff[TP_S5] * (1.0f / 127.0f), ln = eff[TP_S6] * (1.0f / 127.0f);
    float inc[3], hi = f, pr = 1.0f + eff[TP_S0] * (7.0f / 127.0f), pf = pr - fm_floorf(pr), idx = (1.0f - fl) * 0.7f;
    float nc = op_coef(10.0f * fm_exp2f(fl * 11.0f)), ng = 1.6f / fm_sqrtf(fm_maxf(fl, 0.02f)), g = 1.0f / fm_sqrtf((float)nv);
    int pk = (int)pr;
    if (!s->ns)
        s->ns = v->rng | 1u;
    for (j = 0; j < 3; j++) {
        float fj = f * (j ? fm_exp2f(((float)harm_iv[iv][j - 1] + (j == 1 ? 1.0f : -1.0f) * eff[TP_S9] * (0.3f / 127.0f)) * (1.0f / 12.0f)) : 1.0f);
        inc[j] = fj * RV_DT;
        if (j < nv && fj > hi)
            hi = fj;
        if (!(s->ph[j] == s->ph[j]) || fm_fabsf(s->ph[j]) > 2.0f)
            s->ph[j] = 0.0f;
    }
    top = clampi((int)(18000.0f / fm_maxf(hi, 20.0f)), 1, 24);
    if (lh > 0.0f && (s->key[0] != c || s->key[1] != fl || s->key[2] != (float)lock || s->key[3] != ev + (float)top * 4.0f)) {
        harm_table(s, c, fl, lock, ev, top);
        s->key[0] = c, s->key[1] = fl, s->key[2] = (float)lock, s->key[3] = ev + (float)top * 4.0f;
    }
    for (i = 0; i < n; i++) {
        float y = 0.0f;
        for (j = 0; j < nv; j++) {
            float ph = s->ph[j] + inc[j];
            ph -= fm_floorf(ph);
            s->ph[j] = ph;
            if (lh > 0.0f) {
                float x = ph * (float)HM_TAB, fr;
                int q = (int)x;
                fr = x - (float)q;
                y += lh * (s->tab[q] + (s->tab[q + 1] - s->tab[q]) * fr);
            }
            if (lp > 0.0f) {                          /* the two modulators, locked to the carrier: harmonics pk, pk + 1 */
                float m = sin_lut(ph * (float)pk) * (1.0f - pf) + sin_lut(ph * (float)(pk + 1)) * pf;
                y += lp * 0.8f * sin_lut(ph + idx * m);
            }
            if (ln > 0.0f) {                          /* low-passed noise times the note: two sidebands, FLUX wide */
                s->nz[j][0] += (xs_bi(&s->ns) - s->nz[j][0]) * nc;
                s->nz[j][1] += (s->nz[j][0] - s->nz[j][1]) * nc;
                y += ln * ng * s->nz[j][1] * sin_lut(ph);
            }
        }
        out[i] = y * g;
    }
}

#include "rv_zplane.h"

/* each engine's output trim, so a default patch of any engine plays at about the same loudness
 * (measured: the loudest 50 ms of a held C3 at default settings) */
static const float eng_trim[ENG_N] = {1.000f, 2.018f, 0.822f, 2.042f, 0.620f, 1.380f, 0.617f, 1.000f, 1.000f, 0.519f, 0.646f, 1.000f, 1.000f, 1.000f, 1.000f};

/* renders n samples of a synth voice, filtered and enveloped, added to out; returns its level */
/* the voice after its source, a sample at a time: the envelope, the filter, the level (RAM code on the
 * FM-1: every synth voice runs it) */
RV_HOT static float voice_post(voice_t *v, const float *exc, const float *buf, float *out, int n, int eng, int ft,
                               float res, float cut, float velamt, float sem_m, int sem_bp)
{
    int i;
    float lvl, vf = 1.0f - velamt + velamt * v->vel, trim = eng_trim[eng];   /* (once a step) */
    float sem_g = ft == FT_SEM && sem_bp ? fm_sqrtf(v->svf.k) : 0.0f;         /* (the SEM's BP gain, once: k holds through the step) */
    lvl = 0.0f;
    if (eng == ENG_PHYS)                              /* (PHYS takes the excitation itself) */
        exc = 0;
    for (i = 0; i < n; i++) {
        float a = eng == ENG_CZ ? 1.0f : artic_tick(&v->a, &v->cfg), x = buf[i], bp, hp, y;   /* CZ: its DCA is the envelope */
        if (exc)
            x += exc[i] * 0.5f;
        if (v->a.tailv > 0.0005f)
            x += xs_bi(&v->rng) * v->a.tailv * 0.35f;
        switch (ft) {
        case FT_LADDER: y = ladder_tick(&v->lad, x); break;
        case FT_MS20: y = ms20_tick(&v->lad, x); break;
        case FT_SH101: y = sh101_tick(&v->lad, x); break;
        case FT_ZVOWEL: case FT_ZTALK: case FT_ZPHASER: case FT_ZPEAKS: case FT_ZSWEEP: case FT_ZMETAL:
            y = zp_tick(&v->zp, x);
            break;
        case FT_XLP24:                                /* two clean stages, the resonance in the first */
            y = svf_tick(&v->svf2, svf_tick(&v->svf, x, 0, 0), 0, 0);
            break;
        case FT_XBP24:
            svf_tick(&v->svf, x, &bp, 0);
            svf_tick(&v->svf2, bp * v->svf.k, &hp, 0);
            y = hp * v->svf2.k * (1.0f + res * 2.0f);
            break;
        case FT_XNOTCH:
            svf_tick(&v->svf, x, &bp, 0);
            y = x - v->svf.k * bp * (1.0f + res * 0.8f);
            break;
        case FT_XSH:                                  /* sample and hold: CUTOFF is the clock, RESO smooths less */
            v->xs_acc += rv_cut_hz_i(cut) * 2.0f * RV_DT;
            if (v->xs_acc >= 1.0f) {
                v->xs_acc -= fm_floorf(v->xs_acc);
                v->xs_y = x;
            }
            y = svf_tick(&v->svf2, v->xs_y, 0, 0) * (1.0f - res) + v->xs_y * res;
            break;
        case FT_XSHAPE: {                             /* a wave shaper: CUTOFF drives it, RESO folds it */
            float g = 1.0f + cut * (6.0f / 127.0f);
            y = fm_sinf(x * g * (1.0f + res * 2.0f)) * (0.7f + 0.3f / g);
            break;
        }
        case FT_SEM: {                                /* Oberheim SEM: one state variable, LP to notch to HP, or BP */
            float lp = svf_tick(&v->svf, x, &bp, &hp);
            v->svf.ic1 = 2.0f * sat(v->svf.ic1 * 0.5f);   /* the OTA integrators round off when it rings */
            y = sem_bp ? bp * sem_g : lp + (hp - lp) * sem_m;   /* BP rises with RESO, as the SEM's does */
            break;
        }
        case FT_LP: y = svf_tick(&v->svf, x, 0, 0); break;
        case FT_BP: svf_tick(&v->svf, x, &bp, 0); y = bp * (1.0f + res); break;
        case FT_HP: svf_tick(&v->svf, x, 0, &hp); y = hp; break;
        default: y = svf_tick(&v->svf, x, 0, 0) * v->lpg; break;
        }
        y *= a * vf;
        y = 2.0f * sat(y * 0.5f);                     /* a resonant filter or body driven hard: rounded, not runaway */
        out[i] += y * trim;
        v->last = y;
        lvl = a;
    }
    return lvl;
}

RV_HOT2 static float synth_voice_render(voice_t *v, track_t *tr, float *out, int n, float bend)
{
    const float *eff = tr->eff;
    float buf[RV_SUB], f, lvl0, fl, cut, res, ktrk, env_amt, lvl;
    int eng = clampi((int)(eff[TP_ENGINE] + 0.5f), 0, ENG_N - 1), ft = clampi((int)(eff[TP_FTYPE] + 0.5f), 0, FT_N - 1);
    float glide = eff[TP_GLIDE] < 0.5f ? 1.0f : 1.0f - fm_expf(-(float)n * RV_DT / (0.002f + eff[TP_GLIDE] * eff[TP_GLIDE] * 0.00012f));
    float velamt = eff[TP_VELO] * (1.0f / 127.0f);
    v->pitch += (v->target - v->pitch) * glide;
    f = note_hz(v->pitch + eff[TP_PITCH] + eff[TP_FINE] * 0.01f + bend);
    if (f > 16000.0f)
        f = 16000.0f;
    if (v->e_eng != eng + 1)                          /* the engine changed under a sounding voice */
        voice_engine_reset(v, eng);
    switch (eng) {
    case ENG_VA: RV_FAR(va_render)(v, eff, f, buf, n); break;
    case ENG_CZ: cz_render(v, eff, f, buf, n, v->track); break;
    case ENG_PIANO: piano_render(v, eff, f, buf, n); break;
    case ENG_PHYS: phys_render(v, eff, f, tr->exc, buf, n); break;
    case ENG_FORMANT: form_render(v, eff, f, buf, n); break;
    case ENG_CHIP: chip_render(v, eff, f, buf, n); break;
    case ENG_WAVE: wave_render(v, eff, f, buf, n); break;
    case ENG_LOGIC: logic_render(v, eff, f, buf, n); break;
    case ENG_ORGAN: organ_render(v, eff, f, buf, n); break;
    case ENG_MONO: mono_render(v, eff, f, buf, n); break;
    case ENG_RESIN: resin_render(v, eff, f, buf, n); break;
    case ENG_TINE: tine_render(v, eff, f, buf, n); break;
    case ENG_GUITAR: RV_FAR(gtr_render)(v, eff, f, buf, n); break;
    case ENG_HARM: RV_FAR(harm_render)(v, eff, f, buf, n); break;
    default: part_render(v, eff, f, buf, n); break;
    }
    /* the filter: cutoff from its knob, the FILTER ENV, the key */
    lvl0 = eng == ENG_CZ ? v->e.cz.level : v->a.out;  /* the level's envelope (CZ: its DCA): the LPG follows it */
    fl = fenv_tick(&v->fe, eff, (float)n * RV_DT);
    ktrk = eff[TP_KTRK] * (1.0f / 127.0f);
    env_amt = eff[TP_EFILT] * (1.0f / 64.0f);
    cut = eff[TP_CUT] + env_amt * 64.0f * fl + ktrk * ((float)v->note - 60.0f) * (127.0f / 120.0f);
    res = eff[TP_RES] * (1.0f / 127.0f);
    if (eng == ENG_MONO)                              /* VEL>CUT: a harder note is brighter */
        cut += eff[TP_S12] * (70.0f / 127.0f) * (v->vel - 0.5f);
    if (ft == FT_LPG) {
        float target = clampf(lvl0, 0.0f, 1.0f);
        v->lpg += (target - v->lpg) * (1.0f - fm_expf(-0.4308f * (float)n * (1.0f / 32.0f)));   /* a vactrol lags a little (35 % a 32-frame step, whatever the step) */
        cut = eff[TP_CUT] * v->lpg + 6.0f;
    }
    cut = clampf(cut, 0.0f, 135.0f);
    if (FT_IS_XT(ft)) {                               /* the XT filters */
        float q = 0.5f + res * res * 24.0f;
        svf_set(&v->svf, rv_cut_hz(cut), ft == FT_XNOTCH ? 0.5f + res * 6.0f : q);
        svf_set(&v->svf2, rv_cut_hz(cut), ft == FT_XLP24 || ft == FT_XBP24 ? 0.55f : q);
    } else if (FT_IS_Z(ft))                           /* MORPH and XFORM */
        RV_FAR(zp_design)(ft - FT_ZVOWEL, cut * (1.0f / 127.0f), res, v->zp.c, &v->zp.g);
    else if (ft == FT_LADDER || ft == FT_MS20 || ft == FT_SH101)
        ladder_set(&v->lad, rv_cut_hz(cut), res);
    else if (ft == FT_SEM)                            /* 12 dB, its resonance stops short of oscillating */
        svf_set(&v->svf, rv_cut_hz(cut), 0.55f + res * res * 11.0f);
    else
        svf_set(&v->svf, rv_cut_hz(cut), 0.5f + res * res * 18.0f);
    const float sem_m = clampf(eff[TP_FMODE] * (1.0f / 127.0f), 0.0f, 1.0f);   /* (locals: two cores may render voices at once) */
    const int sem_bp = eff[TP_FBP] > 0.5f;
    lvl = RV_FAR(voice_post)(v, tr->exc_on ? tr->exc : 0, buf, out, n, eng, ft, res, cut, velamt, sem_m, sem_bp);
    if (eng == ENG_CZ) {
        if (v->e.cz.done)
            v->on = 0;
        return v->e.cz.level;
    }
    if (v->a.stage == AS_OFF && v->a.tailv < 0.0005f)
        v->on = 0;
    return lvl;
}
