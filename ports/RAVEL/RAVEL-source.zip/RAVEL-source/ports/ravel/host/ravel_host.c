/* SPDX-License-Identifier: GPL-3.0-only */
/* Ravel on the desktop: the app on a simulated FM-1 (host_core.c), driven by a script.
 * Audio goes to a WAV, the screen to PNGs. The PNG writer is X0X's (stored deflate, no zlib).
 *
 *   ravel_host SCRIPT [OUTDIR]
 *
 * Script, one command per line (# comments):
 *   wait MS                       run the device for MS milliseconds
 *   press BTN | release BTN | tap BTN
 *                                 (BTN: OCT- OCT+ FX SCL ENV LFO EDIT GLO HOME SAVE ARP SEQ PLAY REC)
 *   key K down|up | tapkey K      (K: 0..26 = F3..G5)
 *   turn ENC N                    (ENC: SELECT ALGO K1 K2 K3 K4 PRESET; N detents, one a frame)
 *   input FILE.wav                play a 16-bit stereo WAV into the audio input (USB in on the FM-1)
 *   master N                      MASTER pot 0..4096
 *   cpu N                         the audio load the platform reports, % (only the FM-1 measures it)
 *   wav FILE | wavstop            record the output
 *   shot FILE.png                 save the screen
 *   demo N                        load demo N (1 Ravel, 2 Dust, 3 Graph), as SAVE > DEMO N does
 *   intro                         the start screen (the FM-1 plays it at power-on)
 *   reboot                        switch off and on again (a blank project; SAVE's slots are kept)
 *   preset T I                    sound preset I (0: the first) onto track T
 *   settp T NAME VALUE            set track T's (1..8) parameter (its screen name, no spaces)
 *   expect tp T NAME VALUE        track T's (1..8) parameter, by its screen name
 *   expect mutes M | solos S       the muted / soloed tracks as a bitmask (T1 = 1)
 *   expect held T N               track T's synth voices held now
 *   expect wtype T B N | wsrc T B S | wsrcb T B S   WEFT: track T's block B's type / input A's / input B's source
 *   expect wvoices N              WEFT voices sounding
 *   expect wbmove T B 0|1         WEFT: track T's block B's input B moves its second setting
 *   expect playstep T S           track T's playhead is on step S (1..64; 0: none)
 *   expect playstep_in T LO HI    track T's playhead is on a step from LO to HI
 *   wpreset T K                   WEFT: factory patch K (0..) onto track T
 *   wset T F I V                  WEFT: a field of track T's patch, as the emulator's patcher sets it (F: 0 type,
 *                                 1 input A, 2 input B, 3 amount A, 4 amount B (block I, 1..12), 5 the output,
 *                                 7 setting I (1..24), 9 B moves (block I))
 *   setgp G V                     global G (GP_ number) to V
 *   setmatg K S G A               matrix row K from source S (MS_ number) into global G (GP_ number), amount A
 *   setmat K T N | setlock T S N  matrix row K (1..8) into, or step S of track T locking, track T's WEFT setting N (1..24)
 *   expect wsetting T N V | matset K N | lockset T S N   a WEFT setting's value; which setting a matrix row / lock names
 *   expect soundused N K          the bank's slot N holds a sound of kind K (-1: empty)
 *   expect gp NAME VALUE          a global parameter
 *   expect page TITLE             the page on screen
 *   expect store SLOT FILE        the storage slot holds just that file
 *   expect msg TEXT               the message on the top line now ("" when none)
 *   expect name NAME [SLOT]       the project's name (no spaces), or the one saved in SLOT (1..7)
 *   expect slotused N 0|1         project slot N (1..32) is empty or saved
 *   expect steps T N              track T (1..8) has N steps on in its current pattern
 *   expect stepnote T S NOTE      track T's step S (1..64) plays NOTE (-1: the step is off)
 *   expect stepvel T S V          track T's step S has velocity V (on or off)
 *   expect stepchord T S N        track T's step S has N notes (1..4)
 *   expect matdst K NAME          matrix row K (1..8) moves NAME ("T1 HITS")
 *   expect ons T LO HI            the sequencer started from LO to HI notes on track T since "ons 0"
 *   chainclear T                  track T's (1..8) CHAIN with no cords
 *   reset                         as reboot, but a reset while it ran (a crash): what survives a reset kept
 *   clear T                       track T's (1..8) current pattern: every step off
 *   ons 0                         count track notes from now
 *   setmatp K S T NAME A          matrix row K (1..8) from source S into track T's parameter NAME, amount A
 *   setmatq K S T Q A             matrix row K (1..8) from source S (MS_ number) into track T's LENGTH (Q 0), HITS (1) or ROTATE (2), amount A
 *   expect kitq T L N             kit track T's lane L (1..6): its QUANTZE as stored (0 SONG, 1..101 = 0..100 %)
 *   expect msrc NAME LO HI        the matrix source NAME (WHEEL, TOUCH, BEND...) is between LO and HI now
 *   expect stepcur S              the step the knobs edit is S (1..64)
 *   expect steplen T S CODE       track T's step S has LENGTH CODE (8 a step)
 *   expect recording 0|1          REC armed
 *   expect sreccur S              step recording's cursor is on step S (0: off)
 *   expect meter_max T X          track T's output level is at most X (0..1)
 *   expect peak_db_min DB         the output's peak since the last wav reached DB at least
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "host_core.c"
#include "../firmware/app/rv.h"
const char *ui_page_title(void);
const char *ui_msg_text(void);
int ui_step_cur(void);
void ui_intro(void);
int rv_bank_used(int i);
int rv_bank_kind(int i);
int rv_save(int slot);
int rv_load(int slot);
int rv_bank_store(int t, int i, const char *name);
int rv_bank_apply(int t, int i);
int rv_bank_flush(void);
extern uint32_t rv_dbg_ons[RV_TRACKS];
void rv_bank_reload(int slot);
void rv_weft_preset(int t, int k);
void rv_weft_block_defaults(int t, int i);

/* ----------------------------------------------------------- input --- */
static int16_t *in_pcm;
static uint32_t in_frames, in_pos;
static int host_audio_in(float *lr, int frames)
{
    int i;
    if (!in_pcm || in_pos >= in_frames)
        return 0;
    for (i = 0; i < frames && in_pos < in_frames; i++, in_pos++) {
        lr[2 * i] = in_pcm[2 * in_pos] / 32768.0f;
        lr[2 * i + 1] = in_pcm[2 * in_pos + 1] / 32768.0f;
    }
    return i;
}
static void input_open(const char *path)
{
    FILE *f = fopen(path, "rb");
    long n;
    if (!f) {
        fprintf(stderr, "cannot read %s\n", path);
        return;
    }
    fseek(f, 0, SEEK_END);
    n = ftell(f) - 44;
    fseek(f, 44, SEEK_SET);
    free(in_pcm);
    in_pcm = malloc((size_t)(n > 0 ? n : 4));
    in_frames = (uint32_t)(n > 0 ? n / 4 : 0);
    if (fread(in_pcm, 1, (size_t)(n > 0 ? n : 0), f) != (size_t)(n > 0 ? n : 0))
        in_frames = 0;
    in_pos = 0;
    fclose(f);
}

/* ---------------------------------------------------------- outputs --- */
static FILE *wav;
static uint32_t wav_frames;
#ifdef RV_WEFT_HASH
uint32_t rv_weft_hash = 2166136261u, rv_weft_frames;
uint64_t rv_weft_ns;
#endif
static float peak_out;

static void host_audio(const int32_t *blk, uint32_t n)
{
    uint32_t i;
    for (i = 0; i < 2u * n; i++) {
        float v = fabsf((float)blk[i] / 8388608.0f);
        if (v > peak_out)
            peak_out = v;
    }
    if (!wav)
        return;
    for (i = 0; i < n; i++) {
        int16_t s[2] = {(int16_t)(blk[2 * i] >> 8), (int16_t)(blk[2 * i + 1] >> 8)};
        fwrite(s, 2, 2, wav);
    }
    wav_frames += n;
}

static void wav_open(const char *path)
{
    static const uint8_t h[44] = {0};
    wav = fopen(path, "wb");
    if (wav)
        fwrite(h, 1, 44, wav);
    wav_frames = 0;
    peak_out = 0;
}

static void wav_close(void)
{
    uint32_t bytes = wav_frames * 4, v;
    if (!wav)
        return;
    fseek(wav, 0, SEEK_SET);
    fwrite("RIFF", 1, 4, wav);
    v = 36 + bytes;
    fwrite(&v, 4, 1, wav);
    fwrite("WAVEfmt ", 1, 8, wav);
    v = 16;
    fwrite(&v, 4, 1, wav);
    {
        uint16_t fmt[2] = {1, 2};
        uint32_t r[2] = {44100u, 44100u * 4u};
        uint16_t al[2] = {4, 16};
        fwrite(fmt, 2, 2, wav);
        fwrite(r, 4, 2, wav);
        fwrite(al, 2, 2, wav);
    }
    fwrite("data", 1, 4, wav);
    fwrite(&bytes, 4, 1, wav);
    fclose(wav);
    wav = 0;
}

static void png_write(const char *path)
{
    /* RGB PNG with stored (uncompressed) deflate blocks: no zlib needed */
    static uint8_t raw[240 * (1 + 240 * 3)];
    FILE *f = fopen(path, "wb");
    uint32_t crc_t[256], i, j, k, n = 0, a = 1, b = 0, pos, len = sizeof raw;
    uint8_t hdr[8] = {137, 80, 78, 71, 13, 10, 26, 10};
    if (!f) {
        fprintf(stderr, "cannot write %s\n", path);
        return;
    }
    for (i = 0; i < 256; i++) {
        uint32_t c = i;
        for (k = 0; k < 8; k++)
            c = c & 1 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
        crc_t[i] = c;
    }
    for (j = 0; j < 240; j++) {
        raw[n++] = 0;
        for (i = 0; i < 240; i++) {
            uint16_t p = fb[j * 240 + i];
            raw[n++] = (uint8_t)(((p >> 11) & 31) * 255 / 31);
            raw[n++] = (uint8_t)(((p >> 5) & 63) * 255 / 63);
            raw[n++] = (uint8_t)((p & 31) * 255 / 31);
        }
    }
    for (i = 0; i < len; i++) {
        a = (a + raw[i]) % 65521;
        b = (b + a) % 65521;
    }
#define PUT32(v) do { uint8_t q_[4] = {(uint8_t)((v) >> 24), (uint8_t)((v) >> 16), (uint8_t)((v) >> 8), (uint8_t)(v)}; fwrite(q_, 1, 4, f); } while (0)
    fwrite(hdr, 1, 8, f);
    {
        uint8_t ih[17] = {'I', 'H', 'D', 'R', 0, 0, 0, 240, 0, 0, 0, 240, 8, 2, 0, 0, 0};
        uint32_t c = 0xFFFFFFFFu;
        PUT32(13u);
        fwrite(ih, 1, 17, f);
        for (i = 0; i < 17; i++)
            c = crc_t[(c ^ ih[i]) & 255] ^ (c >> 8);
        PUT32(~c);
    }
    {
        uint32_t nblk = (len + 65534) / 65535, zlen = 2 + len + nblk * 5 + 4, c = 0xFFFFFFFFu;
        uint8_t *z = malloc(zlen + 4), *q = z;
        memcpy(q, "IDAT", 4);
        q += 4;
        *q++ = 0x78;
        *q++ = 0x01;
        for (pos = 0; pos < len;) {
            uint32_t m = len - pos > 65535 ? 65535 : len - pos;
            *q++ = pos + m >= len ? 1 : 0;
            *q++ = (uint8_t)m;
            *q++ = (uint8_t)(m >> 8);
            *q++ = (uint8_t)~m;
            *q++ = (uint8_t)(~m >> 8);
            memcpy(q, raw + pos, m);
            q += m;
            pos += m;
        }
        *q++ = (uint8_t)(b >> 8);
        *q++ = (uint8_t)b;
        *q++ = (uint8_t)(a >> 8);
        *q++ = (uint8_t)a;
        PUT32(zlen);
        fwrite(z, 1, zlen + 4, f);
        for (i = 0; i < zlen + 4; i++)
            c = crc_t[(c ^ z[i]) & 255] ^ (c >> 8);
        PUT32(~c);
        free(z);
    }
    {
        uint8_t ie[4] = {'I', 'E', 'N', 'D'};
        uint32_t c = 0xFFFFFFFFu;
        PUT32(0u);
        fwrite(ie, 1, 4, f);
        for (i = 0; i < 4; i++)
            c = crc_t[(c ^ ie[i]) & 255] ^ (c >> 8);
        PUT32(~c);
    }
    fclose(f);
}

/* ------------------------------------------------------------ script --- */
static const char *const BTN_NAMES[NB] = {"OCT-", "OCT+", "FX", "SCL", "ENV", "LFO", "EDIT", "GLO",
                                          "HOME", "SAVE", "ARP", "SEQ", "PLAY", "REC"};
static const char *const ENC_NAMES[NE] = {"SELECT", "ALGO", "K1", "K2", "K3", "K4", "PRESET"};

static int find_name(const char *const *t, int n, const char *s)
{
    int i;
    for (i = 0; i < n; i++)
        if (!strcmp(t[i], s))
            return i;
    return -1;
}

static int find_tp(int t, const char *s)
{
    int p;
    if (!strcmp(s, "SEQMODE"))                         /* (the sequencer's MODE: other knobs are called MODE too) */
        return TP_SEQMODE;
    for (p = 0; p < TP_N; p++) {
        const rv_pinfo *pi = rv_pinfo_track(t, p);
        int k;
        if (!pi->name)
            continue;
        for (k = 0; pi->name[k] && (pi->name[k] == s[k] || (pi->name[k] == ' ' && s[k] == '_')); k++)
            ;
        if (!pi->name[k] && !s[k])                    /* (a space in a name: _ in the script) */
            return p;
    }
    return -1;
}

static int find_gp(const char *s)
{
    int g;
    for (g = 0; g < GP_N; g++) {
        const rv_pinfo *pi = rv_pinfo_global(g);
        if (pi->name && !strcmp(pi->name, s))
            return g;
    }
    return -1;
}

int main(int argc, char **argv)
{
    FILE *f;
    char line[256], outdir[200] = ".", path[512];
    int lineno = 0, fails = 0;
    if (argc < 2) {
        fprintf(stderr, "usage: ravel_host SCRIPT [OUTDIR]\n");
        return 2;
    }
    if (argc > 2)
        snprintf(outdir, sizeof outdir, "%s", argv[2]);
    if (!(f = fopen(argv[1], "r"))) {
        perror(argv[1]);
        return 2;
    }
    boot();
    while (fgets(line, sizeof line, f)) {
        char a[64] = "", b[128] = "", c[64] = "";
        int n;
        lineno++;
        if (line[0] == '#' || (n = sscanf(line, "%63s %127s %63s", a, b, c)) < 1)
            continue;
        if (!strcmp(a, "wait")) {
            run_ms((uint32_t)atoi(b));
        } else if (!strcmp(a, "press") || !strcmp(a, "release") || !strcmp(a, "tap")) {
            int i = find_name(BTN_NAMES, NB, b);
            if (i < 0) {
                fprintf(stderr, "line %d: no button %s\n", lineno, b);
                return 2;
            }
            if (a[0] == 'p' || a[0] == 't')
                held_btn |= 1u << i;
            if (a[0] == 't')
                run_ms(40);
            if (a[0] == 'r' || a[0] == 't')
                held_btn &= ~(1u << i);
            run_ms(20);
        } else if (!strcmp(a, "key") || !strcmp(a, "tapkey")) {
            int k = atoi(b);
            if (k < 0 || k >= NKEYS)
                return 2;
            if (!strcmp(a, "tapkey") || !strcmp(c, "down"))
                held_keys |= 1u << k;
            if (!strcmp(a, "tapkey"))
                run_ms(120);
            if (!strcmp(a, "tapkey") || !strcmp(c, "up"))
                held_keys &= ~(1u << k);
            run_ms(2);
        } else if (!strcmp(a, "turn")) {
            int e = find_name(ENC_NAMES, NE, b), d = atoi(c), s = d < 0 ? -1 : 1;
            if (e < 0)
                return 2;
            while (d) {
                enc_acc[e] += s;
                d -= s;
                run_ms(17);
            }
        } else if (!strcmp(a, "intro")) {     /* the start screen, as the FM-1 plays it at power-on */
            ui_intro();
        } else if (!strcmp(a, "cpu")) {
            cpu_pct = (uint32_t)atoi(b);
        } else if (!strcmp(a, "master")) {
            master = (uint32_t)atoi(b);
        } else if (!strcmp(a, "wav")) {
            snprintf(path, sizeof path, "%s/%s", outdir, b);
            wav_open(path);
        } else if (!strcmp(a, "wavstop")) {
            wav_close();
        } else if (!strcmp(a, "shot")) {
            snprintf(path, sizeof path, "%s/%s", outdir, b);
            png_write(path);
        } else if (!strcmp(a, "peakreset")) {
            peak_out = 0;
        } else if (!strcmp(a, "kind")) {      /* kind T K: track T (1..8) becomes kind K (as the KIND knob does) */
            int tt = 0, kk = 0;
            sscanf(line, "%*s %d %d", &tt, &kk);
            rv_track_set_kind((tt - 1) & 7, kk);
        } else if (!strcmp(a, "preset")) {    /* preset T I: sound preset I (0..) onto track T */
            void rv_preset_apply(int t, int i);
            rv_preset_apply(atoi(b) - 1, atoi(c));
        } else if (!strcmp(a, "wpreset")) {   /* wpreset T K: WEFT factory patch K onto track T */
            int tt = 0, kk = 0;
            sscanf(line, "%*s %d %d", &tt, &kk);
            rv_weft_preset((tt - 1) & 7, kk);
        } else if (!strcmp(a, "setgp")) {     /* setgp G V: global G (GP_ number) to V */
            int x = 0, y = 0;
            sscanf(line, "%*s %d %d", &x, &y);
            if (x >= 0 && x < GP_N)
                rv.gp[x] = (int16_t)y;
        } else if (!strcmp(a, "clear")) {    /* clear T: track T's current pattern, no steps */
            rv_pattern_clear((atoi(b) - 1) & 7);
        } else if (!strcmp(a, "chainclear")) {   /* chainclear T: track T's CHAIN with no cords (START the first lane, RESTART LOOP) */
            int p;
            for (p = TP_H1ROLE; p < TP_H1ROLE + 12; p++)
                rv.tp[(atoi(b) - 1) & 7][p] = 0;
        } else if (!strcmp(a, "ons")) {
            __builtin_memset(rv_dbg_ons, 0, sizeof rv_dbg_ons);
        } else if (!strcmp(a, "setmatq")) {
            int x = 0, y = 0, z = 0, q = 0, w = 0;
            sscanf(line, "%*s %d %d %d %d %d", &x, &y, &z, &q, &w);
            rv.mat[(x - 1) & 7].src = (uint8_t)y;
            rv.mat[(x - 1) & 7].amt = (int8_t)w;
            rv.mat[(x - 1) & 7].dst = (uint16_t)(q == 0 ? PID_T((z - 1) & 7, TP_LEN) : PID_SQ((z - 1) & 7, q - 1));
        } else if (!strcmp(a, "setmatp")) {   /* setmatp K S T NAME A: matrix row K from source S into track T's parameter NAME */
            char nm[64] = "";
            int x = 0, y = 0, tt = 0, w = 0, pp;
            sscanf(line, "%*s %d %d %d %63s %d", &x, &y, &tt, nm, &w);
            pp = find_tp((tt - 1) & 7, nm);
            if (pp < 0) {
                fprintf(stderr, "line %d: no parameter %s\n", lineno, nm);
                return 2;
            }
            rv.mat[(x - 1) & 7].src = (uint8_t)y;
            rv.mat[(x - 1) & 7].amt = (int8_t)w;
            rv.mat[(x - 1) & 7].dst = (uint16_t)PID_T((tt - 1) & 7, pp);
        } else if (!strcmp(a, "setmatg")) {   /* setmatg K S G A: matrix row K (1..8) from source S (MS_ number) into global G (GP_ number), amount A */
            int x = 0, y = 0, z = 0, w = 0;
            sscanf(line, "%*s %d %d %d %d", &x, &y, &z, &w);
            rv.mat[(x - 1) & 7].src = (uint8_t)y;
            rv.mat[(x - 1) & 7].amt = (int8_t)w;
            rv.mat[(x - 1) & 7].dst = (uint16_t)PID_G(z);
        } else if (!strcmp(a, "setmat") || !strcmp(a, "setlock")) {   /* setmat K T N: matrix row K (1..8) into track T's
                                                 * WEFT setting N (1..24); setlock T S N: step S (1..64) locks it */
            int x = 0, y = 0, z = 0;
            sscanf(line, "%*s %d %d %d", &x, &y, &z);
            if (a[3] == 'm') {
                rv.mat[(x - 1) & 7].src = MS_LFO1;
                rv.mat[(x - 1) & 7].amt = 10;
                rv.mat[(x - 1) & 7].dst = (uint16_t)PID_T((y - 1) & 7, wf_sp(z - 1));
            } else {
                rv_step *st = &rv.pat[(x - 1) & 7][rv.pat_cur[(x - 1) & 7] % RV_PATTERNS].s[(y - 1) % RV_STEPS];
                st->lp[0] = (uint8_t)(wf_sp(z - 1) + 1);
                st->lv[0] = 10;
            }
        } else if (!strcmp(a, "wset")) {      /* wset T F I V: a field of track T's WEFT patch */
            int tt = 0, ff = 0, ii = 0, vv = 0, bb;
            rv_weft *w;
            sscanf(line, "%*s %d %d %d %d", &tt, &ff, &ii, &vv);
            w = &rv.weft[(tt - 1) & 7];
            bb = (ii - 1 + WF_BLOCKS) % WF_BLOCKS;
            switch (ff) {
            case 0: w->type[bb] = (uint8_t)vv; rv_weft_block_defaults((tt - 1) & 7, bb); break;
            case 1: w->a[bb] = (uint8_t)vv; break;
            case 2: w->b[bb] = (uint8_t)vv; break;
            case 3: w->amta[bb] = (int8_t)vv; break;
            case 4: w->amtb[bb] = (int8_t)vv; break;
            case 5: w->out = (uint8_t)vv; break;
            case 7: rv.tp[(tt - 1) & 7][wf_sp(ii - 1)] = (int16_t)vv; break;
            case 9: w->bmove = (uint16_t)(vv ? w->bmove | (1u << bb) : w->bmove & ~(1u << bb)); break;
            case 10: w->run = (uint8_t)((w->run & ~1u) | (vv ? 1u : 0u)); break;   /* RUN: 0 KEYS, 1 ALWAYS */
            case 11: w->run = (uint8_t)((w->run & ~2u) | (vv ? 2u : 0u)); break;   /* RATE: 0 FULL, 1 HALF */
            default: break;
            }
        } else if (!strcmp(a, "storedump") || !strcmp(a, "storeput")) {   /* storedump|storeput SLOT FILE: a storage slot to or from a file */
            int sl = 0;
            char fn[256] = "";
            FILE *fp;
            sscanf(line, "%*s %d %255s", &sl, fn);
            fp = fopen(fn, a[5] == 'd' ? "wb" : "rb");
            if (!fp || sl < 0 || sl >= PLAT_STORES) {
                fprintf(stderr, "line %d: %s\n", lineno, fn);
                return 2;
            }
            if (a[5] == 'd')
                fwrite(store[sl], 1, (size_t)(store_len[sl] > 0 ? store_len[sl] : 0), fp);
            else
                store_len[sl] = (int32_t)fread(store[sl], 1, PLAT_SLOT_MAX, fp);
            fclose(fp);
        } else if (!strcmp(a, "rvsave")) {    /* rvsave SLOT | rvload SLOT: the project, straight */
            rv_save(atoi(b));
        } else if (!strcmp(a, "rvload")) {
            if (rv_load(atoi(b)) != 0)
                fprintf(stderr, "line %d: load failed\n", lineno);
        } else if (!strcmp(a, "bankstore")) { /* bankstore T I NAME: track T's sound into the bank's slot I (1..32), kept */
            int tt = 0, ii = 0;
            char nm[32] = "";
            sscanf(line, "%*s %d %d %31s", &tt, &ii, nm);
            rv_bank_store((tt - 1) & 7, ii - 1, nm);
            rv_bank_flush();
        } else if (!strcmp(a, "bankapply")) { /* bankapply T I: the bank's slot I onto track T */
            int tt = 0, ii = 0;
            sscanf(line, "%*s %d %d", &tt, &ii);
            rv_bank_apply((tt - 1) & 7, ii - 1);
        } else if (!strcmp(a, "bankreload")) {
            rv_bank_reload(PLAT_BANK0);
        } else if (!strcmp(a, "settp")) {     /* settp T NAME VALUE: track T's (1..8) parameter, straight */
            char nm[64] = "";
            int tt = 0, vv = 0, pp;
            sscanf(line, "%*s %d %63s %d", &tt, nm, &vv);
            pp = find_tp((tt - 1) & 7, nm);
            if (pp < 0) {
                fprintf(stderr, "line %d: no parameter %s\n", lineno, nm);
                return 2;
            }
            rv.tp[(tt - 1) & 7][pp] = (int16_t)vv;
        } else if (!strcmp(a, "demo")) {      /* demo 1|2|3, as SAVE > DEMO 1-3 */
            int d = atoi(b);
            rv_transport(0);
            rv_demo(d == 3 ? 3 : d == 2 ? 1 : 0);
        } else if (!strcmp(a, "midi")) {      /* midi b0 b1 b2 (hex): a message in, as from USB or the jack */
            void host_midi_push(int x, int y, int z);
            unsigned x = 0, y = 0, z = 0;
            sscanf(line, "%*s %x %x %x", &x, &y, &z);
            host_midi_push((int)x, (int)y, (int)z);
            run_ms(1);
        } else if (!strcmp(a, "reboot") || !strcmp(a, "reset")) {   /* reboot: off and on; reset: a reset while it ran (memory kept) */
            held_btn = held_keys = 0;
            if (!strcmp(a, "reboot"))
                ui_boot_power();
            boot();
        } else if (!strcmp(a, "input")) {
            snprintf(path, sizeof path, "%s", b);
            input_open(path);
        } else if (!strcmp(a, "expect")) {
            char w1[64] = "", w2[64] = "", w3[64] = "";
            int got = -99999, want = 0;
            sscanf(line, "%*s %*s %63s %63s %63s", w1, w2, w3);
            if (!strcmp(b, "tp")) {
                int t = atoi(w1) - 1, p = t >= 0 && t < 8 ? find_tp(t, w2) : -1;
                if (p < 0) {
                    fprintf(stderr, "line %d: no parameter %s\n", lineno, w2);
                    return 2;
                }
                got = rv.tp[t][p];
                want = atoi(w3);
            } else if (!strcmp(b, "keylit")) {           /* expect keylit KEY N: the key's LED, 0 off, 1 lit, 2 dim */
                int k = atoi(w1) & 31;
                got = (lit_keys >> k) & 1u ? 1 : (lit_dim >> k) & 1u ? 2 : 0;
                want = atoi(w2);
            } else if (!strcmp(b, "gp")) {
                int g = find_gp(w1);
                if (g < 0) {
                    fprintf(stderr, "line %d: no global %s\n", lineno, w1);
                    return 2;
                }
                got = rv.gp[g];
                want = atoi(w2);
            } else if (!strcmp(b, "store")) {                /* expect store SLOT FILE: the slot holds just that file */
                int sl = -1;
                long n;
                char fn[256] = "";
                static uint8_t fb[PLAT_SLOT_MAX];
                FILE *fp;
                sscanf(line, "%*s %*s %d %255s", &sl, fn);
                fp = fopen(fn, "rb");
                n = fp ? (long)fread(fb, 1, sizeof fb, fp) : -1;
                if (fp)
                    fclose(fp);
                if (sl < 0 || sl >= PLAT_STORES || n != store_len[sl] || memcmp(fb, store[sl], (size_t)n)) {
                    printf("FAIL line %d: slot %d doesn't hold %s\n", lineno, sl, fn);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "msg")) {                  /* the message on the top line now */
                char want[64];
                sscanf(line, "%*s %*s %63[^\n]", want);
                if (strcmp(ui_msg_text(), want)) {
                    printf("FAIL line %d: message is \"%s\", expected \"%s\"\n", lineno, ui_msg_text(), want);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "matdst")) {               /* matrix row K's destination, as named ("T1 HITS") */
                char want_s[64] = "", lb[24];
                int kk = (atoi(w1) - 1) & 7;
                sscanf(line, "%*s %*s %*s %63[^\n]", want_s);
                rv_pid_label(rv.mat[kk].dst, lb, 24);
                if (strcmp(lb, want_s)) {
                    printf("FAIL line %d: row %d moves %s, expected %s\n", lineno, kk + 1, lb, want_s);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "page")) {
                char title[64];
                sscanf(line, "%*s %*s %63[^\n]", title);
                if (strcmp(ui_page_title(), title)) {
                    printf("FAIL line %d: page is %s, expected %s\n", lineno, ui_page_title(), title);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "peak_db_max")) {          /* since the last peakreset: quiet enough */
                float db = 20.0f * log10f(peak_out + 1e-9f);
                if (db > atof(c)) {
                    printf("FAIL line %d: peak %.1f dB, expected at most %s dB\n", lineno, db, c);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "name")) {                 /* the project's name, or slot N's (1..7) */
                char nm[13];
                const char *have = rv.name;
                if (w2[0]) {
                    rv_slot_used(PLAT_PROJ(atoi(w2) - 1), nm);
                    have = nm;
                }
                if (strcmp(have, w1)) {
                    printf("FAIL line %d: name is \"%s\", expected \"%s\"\n", lineno, have, w1);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "slotused")) {             /* project slot N (1..32): 1 saved, 0 empty */
                char nm[13];
                got = rv_slot_used(PLAT_PROJ(atoi(w1) - 1), nm) ? 1 : 0;
                want = atoi(w2);
            } else if (!strcmp(b, "steps")) {                /* steps on in track T's (1..8) current pattern */
                int tt = atoi(w1) - 1, i2;
                const rv_pattern *pp = &rv.pat[tt & 7][rv.pat_cur[tt & 7] % RV_PATTERNS];
                got = 0;
                for (i2 = 0; i2 < RV_STEPS; i2++)
                    got += (pp->s[i2].flags & ST_ON) != 0;
                want = atoi(w2);
            } else if (!strcmp(b, "stepnote")) {             /* track T's step S: its note (-1: off) */
                int tt = atoi(w1) - 1;
                const rv_step *ss = &rv.pat[tt & 7][rv.pat_cur[tt & 7] % RV_PATTERNS].s[(atoi(w2) - 1) & (RV_STEPS - 1)];
                got = (ss->flags & ST_ON) ? ss->note : -1;
                want = atoi(w3);
            } else if (!strcmp(b, "stepvel")) {              /* track T's step S: its velocity (on or off) */
                int tt = atoi(w1) - 1;
                got = rv.pat[tt & 7][rv.pat_cur[tt & 7] % RV_PATTERNS].s[(atoi(w2) - 1) & (RV_STEPS - 1)].vel;
                want = atoi(w3);
            } else if (!strcmp(b, "ons")) {                  /* notes started on track T: from LO to HI */
                int lo = atoi(w2), hi = atoi(w3), n = (int)rv_dbg_ons[(atoi(w1) - 1) & 7];
                got = n >= lo && n <= hi ? lo : n;
                want = lo;
            } else if (!strcmp(b, "kitq")) {                 /* kit track T's lane L: its stored QUANTZE */
                got = rv.kit_quant[(atoi(w1) - 1) & 7][(atoi(w2) - 1) % RV_LANES];
                want = atoi(w3);
            } else if (!strcmp(b, "stepchord")) {            /* track T's step S: how many notes */
                int tt = atoi(w1) - 1;
                const rv_step *ss = &rv.pat[tt & 7][rv.pat_cur[tt & 7] % RV_PATTERNS].s[(atoi(w2) - 1) & (RV_STEPS - 1)];
                got = 1 + (ss->chord[0] != 0) + (ss->chord[1] != 0) + (ss->chord[2] != 0);
                want = atoi(w3);
            } else if (!strcmp(b, "dustn")) {                /* DUST grains since the last dustn: between two counts */
                static unsigned last_n;
                unsigned n2 = (unsigned)rv_live.dust_n - last_n;
                last_n = rv_live.dust_n;
                if ((int)n2 < atoi(w1) || (int)n2 > atoi(w2)) {
                    printf("FAIL line %d: %u DUST grains, expected %s to %s\n", lineno, n2, w1, w2);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "msrc")) {                 /* a matrix source's value now: between two numbers */
                int ms2;
                for (ms2 = 0; ms2 < MS_N && strcmp(rv_msrc_names[ms2], w1); ms2++)
                    ;
                if (ms2 == MS_N || rv_live.msrc[ms2] < atof(w2) || rv_live.msrc[ms2] > atof(w3)) {
                    printf("FAIL line %d: source %s is %.3f, expected %s to %s\n", lineno, w1,
                           ms2 < MS_N ? rv_live.msrc[ms2] : -99.0f, w2, w3);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "meter_min")) {            /* track T's output level is at least X (0..1) */
                float mv = rv_live.meter[(atoi(w1) - 1) & 7];
                if (mv < atof(w2)) {
                    printf("FAIL line %d: track %s's meter %.4f, expected at least %s\n", lineno, w1, mv, w2);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "meter_max")) {            /* track T's output level is at most X (0..1) */
                float mv = rv_live.meter[(atoi(w1) - 1) & 7];
                if (mv > atof(w2)) {
                    printf("FAIL line %d: track %s's meter %.4f, expected at most %s\n", lineno, w1, mv, w2);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "loopfill")) {             /* LOOP lane L (1..4): how many of its samples are not silent, at least N */
                uint32_t q, nn = rv_loop_lane_len(), cnt = 0;
                for (q = 0; q < nn; q++)
                    cnt += rv_loop_peek(atoi(w1) - 1, q) != 0;
                got = (int)cnt;
                if (got < atoi(w2)) {
                    printf("FAIL line %d: lane %s has %d sounding samples, expected at least %s\n", lineno, w1, got, w2);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "loopst")) {               /* LOOP lane L's state bits (1 play, 2 rec, 4 wait, 8 slice) */
                got = rv_live.loop_st[(atoi(w1) - 1) & 3];
                want = atoi(w2);
            } else if (!strcmp(b, "lprange")) {              /* track T's step S: lane L's RANGE */
                const rv_step *ss = &rv.pat[(atoi(w1) - 1) & 7][rv.pat_cur[(atoi(w1) - 1) & 7] % RV_PATTERNS].s[(atoi(w2) - 1) & (RV_STEPS - 1)];
                int ll = (atoi(w3) - 1) & 3;
                char w4[16] = "";
                sscanf(line, "%*s %*s %*s %*s %*s %15s", w4);
                got = ll == 0 ? (uint8_t)ss->chord[0] : ll == 1 ? (uint8_t)ss->chord[1] : ll == 2 ? (uint8_t)ss->chord[2] : ss->vel;
                want = atoi(w4);
            } else if (!strcmp(b, "stepbits")) {             /* track T's step S: its note byte (LOOP: the trigs) */
                got = rv.pat[(atoi(w1) - 1) & 7][rv.pat_cur[(atoi(w1) - 1) & 7] % RV_PATTERNS].s[(atoi(w2) - 1) & (RV_STEPS - 1)].note;
                want = atoi(w3);
            } else if (!strcmp(b, "stepcur")) {              /* the step the knobs edit (1..64) */
                got = ui_step_cur() + 1;
                want = atoi(w1);
            } else if (!strcmp(b, "steplen")) {              /* track T's step S: its LENGTH (code: 8 a step) */
                int tt = atoi(w1) - 1;
                got = rv.pat[tt & 7][rv.pat_cur[tt & 7] % RV_PATTERNS].s[(atoi(w2) - 1) & (RV_STEPS - 1)].len;
                want = atoi(w3);
            } else if (!strcmp(b, "skipped")) {              /* SKIP SILENT: the tracks whose voices are skipped, a bit a track */
                got = rv_live.skipped;
                want = atoi(w1);
            } else if (!strcmp(b, "mutes")) {                /* the muted tracks, a bit a track (T1: 1) */
                got = rv.mute;
                want = atoi(w1);
            } else if (!strcmp(b, "solos")) {                /* the soloed tracks, likewise */
                got = rv.solo;
                want = atoi(w1);
            } else if (!strcmp(b, "recording")) {            /* REC armed: 1 */
                got = rv_live.recording;
                want = atoi(w1);
            } else if (!strcmp(b, "sreccur")) {              /* step recording's cursor (1..64, 0: off) */
                got = rv_live.srec_step + 1;
                want = atoi(w1);
            } else if (!strcmp(b, "soundused")) {            /* slot N (1..32) of the bank in memory holds a sound of kind K (-1: empty) */
                int sl = atoi(w1) - 1;
                got = rv_bank_used(sl) ? rv_bank_kind(sl) : -1;
                want = atoi(w2);
            } else if (!strcmp(b, "wtype")) {                /* WEFT: track T's block B (1..8) is of type N */
                got = rv.weft[(atoi(w1) - 1) & 7].type[(unsigned)(atoi(w2) - 1) % WF_BLOCKS];
                want = atoi(w3);
            } else if (!strcmp(b, "wsrc")) {                 /* WEFT: track T's block B's input A comes from S */
                got = rv.weft[(atoi(w1) - 1) & 7].a[(unsigned)(atoi(w2) - 1) % WF_BLOCKS];
                want = atoi(w3);
            } else if (!strcmp(b, "wsrcb")) {                /* WEFT: track T's block B's input B comes from S */
                got = rv.weft[(atoi(w1) - 1) & 7].b[(unsigned)(atoi(w2) - 1) % WF_BLOCKS];
                want = atoi(w3);
            } else if (!strcmp(b, "wsetting")) {             /* WEFT: track T's setting N (1..24) is V */
                got = rv.tp[(atoi(w1) - 1) & 7][wf_sp(atoi(w2) - 1)];
                want = atoi(w3);
            } else if (!strcmp(b, "matset")) {               /* matrix row K's destination is WEFT setting N (1..24; 0 other) */
                got = wf_spi(rv.mat[(atoi(w1) - 1) & 7].dst % RV_TP) + 1;
                want = atoi(w2);
            } else if (!strcmp(b, "lockset")) {              /* track T's step S's first lock is WEFT setting N (1..24) */
                rv_step *st = &rv.pat[(atoi(w1) - 1) & 7][rv.pat_cur[(atoi(w1) - 1) & 7] % RV_PATTERNS].s[(atoi(w2) - 1) % RV_STEPS];
                got = st->lp[0] ? wf_spi(st->lp[0] - 1) + 1 : 0;
                want = atoi(w3);
            } else if (!strcmp(b, "wbmove")) {               /* WEFT: track T's block B's input B moves its second setting */
                got = (rv.weft[(atoi(w1) - 1) & 7].bmove >> ((unsigned)(atoi(w2) - 1) % WF_BLOCKS)) & 1;
                want = atoi(w3);
            } else if (!strcmp(b, "playstep_in")) {          /* track T's playhead is between LO and HI (1..64) */
                int ps = rv_live.step[(atoi(w1) - 1) & 7][0] + 1;
                if (ps < atoi(w2) || ps > atoi(w3)) {
                    printf("FAIL line %d: track %s's playhead on %d, expected %s to %s\n", lineno, w1, ps, w2, w3);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "playstep")) {             /* track T's playhead (1..64; 0 none) */
                got = rv_live.step[(atoi(w1) - 1) & 7][0] + 1;
                want = atoi(w2);
            } else if (!strcmp(b, "wvoices")) {              /* WEFT: voices sounding */
                got = rv_live.wvoices;
                want = atoi(w1);
            } else if (!strcmp(b, "held")) {                 /* track T's synth voices held now */
                got = rv_track_held(atoi(w1) - 1);
                want = atoi(w2);
            } else if (!strcmp(b, "voices")) {               /* synth and strike voices sounding */
                got = rv_live.voices_synth + rv_live.voices_strike;
                want = atoi(w1);
            } else if (!strcmp(b, "playing")) {              /* the transport: 1 running */
                got = rv_live.playing;
                want = atoi(w1);
            } else if (!strcmp(b, "midibpm")) {              /* MIDI clock's tempo, measured: between two values */
                if (rv_live.midi_bpm < atof(w1) || rv_live.midi_bpm > atof(w2)) {
                    printf("FAIL line %d: MIDI tempo %.1f, expected %s to %s\n", lineno, rv_live.midi_bpm, w1, w2);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "arpn")) {                 /* notes track T's (1..8) arpeggiator holds */
                got = rv_live.arp_n[(atoi(w1) - 1) & 7];
                want = atoi(w2);
            } else if (!strcmp(b, "arphits_min")) {          /* notes it has played (mod 256), at least */
                if (rv_live.arp_hit[(atoi(w1) - 1) & 7] < atoi(w2)) {
                    printf("FAIL line %d: arp played %d, expected at least %s\n", lineno, rv_live.arp_hit[(atoi(w1) - 1) & 7], w2);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "comp_gr_min")) {          /* COMP: reduction now, dB, at least */
                if (rv_live.comp_gr < atof(c)) {
                    printf("FAIL line %d: COMP reduces %.1f dB, expected at least %s\n", lineno, rv_live.comp_gr, c);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "comp_gr_max")) {
                if (rv_live.comp_gr > atof(c)) {
                    printf("FAIL line %d: COMP reduces %.1f dB, expected at most %s\n", lineno, rv_live.comp_gr, c);
                    fails++;
                }
                continue;
            } else if (!strcmp(b, "peak_db_min")) {
                float db = 20.0f * log10f(peak_out + 1e-9f);
                if (db < atof(c)) {
                    printf("FAIL line %d: peak %.1f dB, expected at least %s dB\n", lineno, db, c);
                    fails++;
                }
                continue;
            } else {
                fprintf(stderr, "line %d: unknown expect %s\n", lineno, b);
                return 2;
            }
            if (got != want) {
                printf("FAIL line %d: %s is %d, expected %d\n", lineno, line, got, want);
                fails++;
            }
        } else {
            fprintf(stderr, "line %d: unknown command %s\n", lineno, a);
            return 2;
        }
    }
    wav_close();
    fclose(f);
#ifdef RV_WEFT_HASH
    {
        extern uint32_t rv_weft_hash, rv_weft_frames;
        extern uint64_t rv_weft_ns;
        printf("wefthash %08x frames %u\n", rv_weft_hash, rv_weft_frames);
        printf("weftns %llu\n", (unsigned long long)rv_weft_ns);
    }
#endif
    printf("%s: %s\n", argv[1], fails ? "FAILED" : "ok");
    return fails ? 1 : 0;
}
