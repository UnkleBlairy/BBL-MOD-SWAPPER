Nano Freak 3.0.1 for the BBL Mod Swapper

Original by Virusiinstaller: https://github.com/Virusiinstaller/nano-freak-fm1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: NANOFREA-source.zip on the ports page.
