/* SPDX-License-Identifier: GPL-3.0-only
 * NANO (Nano Freak, src/eng_nano.c), BASIC WAVES, on the host through hostsim.c.
 *   build/host/nano_test
 * 1. pitch: a saw is at the key's pitch (within 6 cents) over four octaves, SYNC off and at 50 %.
 * 2. SYM: at MORPH 0 a centred pulse has almost no even harmonics, a narrow one has them.
 * 3. SUB adds a partial an octave below; with SUB 0 there is none.
 * 4. SYNC: the output repeats at the master's period (correlation over 0.97 one period on) and is brighter than without it.
 * 5. no overflow, no DC, no click: every key, MORPH, SYM, SUB, SYNC and cutoff in a sweep stays bounded, the largest step
 *    between two samples is limited, and a note-off falls silent.
 * 4b. TWO OP FM: pitch, INDEX, RATIO, FEEDBACK sweeps.
 * 4c. WAVESHAPER: period, FOLD, WAVE, bounded sweep.
 * 4d. FORMANT: period, the spectral peak follows FORMANT, bounded sweep.
 * 4e. NOISE: MODE low-pass to high-pass, the filter follows the key, bounded sweep.
 * 4f. CHORDS: the chord notes, CHORD changes the third, bounded sweep.
 * 4g. MODAL: rings at the key, DAMP narrows it, bounded sweep.
 * 4h. SWARM: the centre saw, DETUNE, bounded sweep.
 * 4i. HARMONIC: period, PEAK, STRETCH, bounded sweep.
 * 4k. BASS: pitch of both waves, SUB puts a line one or two octaves down, WIDTH, bounded sweep.
 * 4l. SAW: sync repeats at the master period, comb feedback sign, CS80, bounded sweep.
 * 4m. WAVETABLE: every table repeats at the key's period, POSITION, CHORUS, MORPH into the next table, bounded sweep.
 * 4n. V.ANALOG: the saw repeats at the key's period, DETUNE puts it a fifth / two octaves away, SYNC changes the square, bounded sweep.
 * 4o. RINGS (modal model): pitch, DAMPING, STRUCTURE, POSITION, four voices, bounded sweep.
 * 4j. PLUCK: the string's pitch, DECAY, POSITION, voices past the fourth silent, bounded sweep.
 * 6. the preset table plays: every NANO preset makes sound. */
#define main hostsim_main
#include "hostsim.c"
#undef main

static int bad;
static void check(const char *what, int ok)
{
    printf("nano: %-104s %s\n", what, ok ? "ok" : "FAIL");
    bad += !ok;
}

/* track 0 = NANO: MORPH, SYM, SUB, SYNC, CUT 127 (open), RES 0, a held loudness contour */
#include "nano_arp_table.h"
static void setup(uint32_t morph, uint32_t sym, uint32_t sub, uint32_t sync, uint32_t cut)
{
    memset(trk, 0, sizeof trk);
    memset(eng_mem, 0, sizeof eng_mem);
    host_tracks_init();
    host_preset(&trk[0], ENGI_NANO, 0);
    trk[0].p[P_E0] = 0;
    trk[0].p[P_E1] = (int16_t)morph;
    trk[0].p[P_E2] = (int16_t)sym;
    trk[0].p[P_E3] = (int16_t)sub;
    trk[0].p[P_E4] = (int16_t)sync;
    trk[0].p[P_E5] = (int16_t)cut;
    trk[0].p[P_E6] = 0;
    trk[0].p[P_E7] = 64;
    trk[0].p[P_ATK] = 0;
    trk[0].p[P_DEC] = 0;
    trk[0].p[P_SUS] = 127;
    trk[0].p[P_REL] = 0;
    trk[0].p[P_VOICE] = V_POLY;
    trk[0].p[P_CHOR] = trk[0].p[P_DLY] = trk[0].p[P_REV] = trk[0].p[P_DIST] = 0;
}

/* TWO OP FM: RATIO INDEX FEEDBACK on E1..E3, the filter open */
static void setup_fm(uint32_t ratio, uint32_t index, uint32_t fb)
{
    setup(ratio, index, fb, 0, 127);
    trk[0].p[P_E0] = 1;
}

/* WAVESHAPER: WAVE FOLD SLOPE on E1..E3, the filter open */
static void setup_ws(uint32_t wave, uint32_t fold, uint32_t slope)
{
    setup(wave, fold, slope, 0, 127);
    trk[0].p[P_E0] = 2;
}

/* FORMANT: RATIO FORMANT SHAPE on E1..E3, the filter open */
static void setup_fo(uint32_t ratio, uint32_t formant, uint32_t shape)
{
    setup(ratio, formant, shape, 0, 127);
    trk[0].p[P_E0] = 3;
}

/* NOISE: MODE CLOCK RES on E1..E3, the filter open */
static void setup_no(uint32_t mode, uint32_t clock, uint32_t res)
{
    setup(mode, clock, res, 0, 127);
    trk[0].p[P_E0] = 4;
}

/* CHORDS: CHORD INVERSION WAVE on E1..E3, the filter open */
static void setup_ch(uint32_t chord, uint32_t inversion, uint32_t wave)
{
    setup(chord, inversion, wave, 0, 127);
    trk[0].p[P_E0] = 5;
}

/* MODAL: STRUCTURE BRIGHT DAMP on E1..E3, the filter open */
static void setup_mo(uint32_t structure, uint32_t bright, uint32_t damp)
{
    setup(structure, bright, damp, 0, 127);
    trk[0].p[P_E0] = 6;
}

/* SWARM: WAVE DETUNE MIX on E1..E3, the filter open */
static void setup_sw(uint32_t wave, uint32_t detune, uint32_t mix)
{
    setup(wave, detune, mix, 0, 127);
    trk[0].p[P_E0] = 7;
}

/* HARMONIC: PEAK WIDTH CHORUS on E1..E3 and STRETCH on E4, the filter open */
static void setup_hm(uint32_t peak, uint32_t width, uint32_t chorus, uint32_t stretch)
{
    setup(peak, width, chorus, stretch, 127);
    trk[0].p[P_E0] = 8;
}

/* PLUCK: BOW POSITION DECAY on E1..E3, the filter open */
static void setup_pl(uint32_t bow, uint32_t position, uint32_t decay)
{
    setup(bow, position, decay, 0, 127);
    trk[0].p[P_E0] = 9;
}

/* BASS: WAVE WIDTH SUB on E1..E3, the filter open */
static void setup_bs(uint32_t wave, uint32_t width, uint32_t sub)
{
    setup(wave, width, sub, 0, 127);
    trk[0].p[P_E0] = 10;
}

/* SAW: WAVE (0 sync, 64 comb, 127 CS80) E2 E3 on E1..E3, the filter open */
static void setup_sa(uint32_t wave, uint32_t e2, uint32_t e3)
{
    setup(wave, e2, e3, 0, 127);
    trk[0].p[P_E0] = 11;
}

/* WAVETABLE: TABLE POSITION CHORUS MORPH on E1..E4, the filter open (TABLE n is knob 8 n + 1) */
static void setup_wt(uint32_t table, uint32_t pos, uint32_t chorus, uint32_t morph)
{
    setup(table * 8 + 1, pos, chorus, morph, 127);
    trk[0].p[P_E0] = 12;
}

/* V.ANALOG: DETUNE SYNC SHAPE on E1..E3, the filter open */
static void setup_va(uint32_t detune, uint32_t sync, uint32_t shape)
{
    setup(detune, sync, shape, 0, 127);
    trk[0].p[P_E0] = 13;
}

/* RINGS: MODEL STRUCTURE BRIGHTNESS DAMPING on E1..E4, POSITION on E7, the filter open */
static void setup_ri(uint32_t model, uint32_t st, uint32_t br, uint32_t dm, uint32_t ps)
{
    setup(model, st, br, dm, 127);
    trk[0].p[P_E0] = 14;
    trk[0].p[P_E7] = (int16_t)ps;
}

static void play(uint32_t note, double *y, uint32_t n)
{
    static int32_t b[CTL];
    uint32_t i, k;
    trk_note_on(&trk[0], note, 100);
    for (i = 0; i < n; i += CTL) {
        track_render(&trk[0], b, CTL);
        for (k = 0; k < CTL && i + k < n; k++)
            y[i + k] = b[k];
    }
    trk_note_off(&trk[0], note);
}

static double hz(uint32_t note) { return 440.0 * pow(2.0, ((double)note - 69.0) / 12.0); }

/* the amplitude of frequency f in y[a .. b) (a Goertzel-style correlation) */
static double tone_at(const double *y, uint32_t a, uint32_t b, double f)
{
    double sr = 0, si = 0, w = 2 * M_PI * f / FS;
    uint32_t i;
    for (i = a; i < b; i++) {
        sr += y[i] * cos(w * (double)i);
        si += y[i] * sin(w * (double)i);
    }
    return 2 * sqrt(sr * sr + si * si) / (b - a);
}

/* the power in the band f1 .. f2 of y[a .. b): 40 tones across it */
static double band_power(const double *y, uint32_t a, uint32_t b, double f1, double f2)
{
    double pw = 0;
    int k;
    for (k = 0; k < 40; k++) {
        double x = tone_at(y, a, b, f1 + (f2 - f1) * k / 39.0);
        pw += x * x;
    }
    return pw / 40.0 * (f2 - f1);
}

/* the pitch: rising zero crossings of the mean-free signal */
static double pitch(const double *y, uint32_t a, uint32_t b)
{
    uint32_t i, nz = 0;
    double first = 0, last = 0, mean = 0;
    for (i = a; i < b; i++)
        mean += y[i];
    mean /= b - a;
    for (i = a + 1; i < b; i++) {
        double p = y[i - 1] - mean, q = y[i] - mean;
        if (p < 0 && q >= 0) {
            double pos = (double)i - 1 + (-p) / (q - p);
            if (!nz++)
                first = pos;
            last = pos;
        }
    }
    return nz > 2 ? (double)FS * (nz - 1) / (last - first) : 0;
}

static double y[FS];

int main(void)
{
    uint32_t n = FS / 2, a = FS / 8, note, i, ok;
    double worst = 0;

    /* 1. pitch */
    for (note = 36; note <= 84; note += 12) {
        setup(127, 0, 0, 0, 127);
        play(note, y, n);
        double c = 1200 * log2(pitch(y, a, n) / hz(note));
        if (fabs(c) > worst)
            worst = fabs(c);
    }
    printf("   saw pitch, worst of 4 octaves: %.2f cents\n", worst);
    check("a saw is at the key's pitch (6 cents), SYNC off", worst < 6.0);
    worst = 0;
    for (note = 36; note <= 72; note += 12) {
        setup(127, 0, 0, 64, 127);
        play(note, y, n);
        double c = 1200 * log2(pitch(y, a, n) / hz(note));
        double r = fabs(c) > 1200 ? 1 : 0;
        (void)r;
        /* the synced saw's zero crossings are not one a cycle: check the period through the correlation instead */
        double per = (double)FS / hz(note), best = 0;
        uint32_t lag = (uint32_t)(per + 0.5), j;
        double e = 0, cc = 0;
        for (j = a; j + lag < n; j++) {
            e += y[j] * y[j];
            cc += y[j] * y[j + lag];
        }
        best = e > 0 ? cc / e : 0;
        if (1.0 - best > worst)
            worst = 1.0 - best;
    }
    printf("   synced, worst 1 - correlation at the master period: %.4f\n", worst);
    check("SYNC 50 %: the output repeats at the master's period (correlation over 0.97)", worst < 0.03);

    /* 2. SYM at MORPH 0 */
    {
        double f = hz(57), h1, h2, h3, e1, e2;
        setup(0, 64, 0, 0, 127);
        play(57, y, n);
        h1 = tone_at(y, a, n, f);
        h2 = tone_at(y, a, n, 2 * f);
        h3 = tone_at(y, a, n, 3 * f);
        e1 = h2 / h1;
        setup(0, 0, 0, 0, 127);
        play(57, y, n);
        e2 = tone_at(y, a, n, 2 * f) / tone_at(y, a, n, f);
        printf("   pulse: 2nd / 1st %.4f centred, %.4f narrow (3rd / 1st %.3f)\n", e1, e2, h3 / h1);
        check("MORPH 0 SYM centre: a square (2nd harmonic under 3 % of the 1st, the 3rd about a third)", e1 < 0.03 && h3 / h1 > 0.25 && h3 / h1 < 0.42);
        check("MORPH 0 SYM low: a narrow pulse has the even harmonics (2nd over 40 % of the 1st)", e2 > 0.4);
    }

    /* 3. SUB */
    {
        double f = hz(57), s0, s1;
        setup(127, 0, 0, 0, 127);
        play(57, y, n);
        s0 = tone_at(y, a, n, f / 2);
        setup(127, 0, 127, 0, 127);
        play(57, y, n);
        s1 = tone_at(y, a, n, f / 2);
        printf("   sub partial: %.1f off, %.1f at 127\n", s0, s1);
        check("SUB 127 adds a partial an octave below (over 3000, and 20x the one with SUB 0)", s1 > 3000 && s1 > 20 * s0);
    }

    /* 4. SYNC makes it brighter: more energy in the top of the spectrum than the unsynced saw */
    {
        double lo = 0, hi0, hi1, f = hz(48);
        uint32_t h;
        setup(127, 0, 0, 0, 127);
        play(48, y, n);
        for (h = 20; h < 40; h++)
            lo += tone_at(y, a, n, f * h) * tone_at(y, a, n, f * h);
        hi0 = lo;
        setup(127, 0, 0, 64, 127);
        play(48, y, n);
        lo = 0;
        for (h = 20; h < 40; h++)
            lo += tone_at(y, a, n, f * h) * tone_at(y, a, n, f * h);
        hi1 = lo;
        printf("   harmonics 20..39: %.0f unsynced, %.0f synced\n", hi0, hi1);
        check("SYNC makes the sound brighter (the upper harmonics carry more)", hi1 > hi0 * 1.5);
    }

    /* 4b. TWO OP FM (TYPE 1): RATIO 30 is 1:1; INDEX 0 is a sine at the key's pitch; INDEX brightens; RATIO changes the spectrum;
     *     FEEDBACK both ways stays bounded */
    {
        double w = 0, h2, e_lo = 0, e_hi = 0, r1 = 0, r2 = 0, f = hz(57), peak = 0, dc = 0;
        uint32_t idx, k, fb;
        for (note = 36; note <= 84; note += 12) {
            setup_fm(30, 0, 64);
            play(note, y, n);
            double c = 1200 * log2(pitch(y, a, n) / hz(note));
            if (fabs(c) > w)
                w = fabs(c);
        }
        setup_fm(30, 0, 64);
        play(57, y, n);
        h2 = tone_at(y, a, n, 2 * f) / tone_at(y, a, n, f);
        printf("   FM INDEX 0: pitch worst %.2f cents, 2nd / 1st %.4f\n", w, h2);
        check("FM INDEX 0 is a sine at the key's pitch (6 cents, 2nd harmonic under 2 %)", w < 6.0 && h2 < 0.02);
        setup_fm(30, 20, 64);
        play(57, y, n);
        for (k = 2; k <= 8; k++)
            e_lo += tone_at(y, a, n, f * k);
        setup_fm(30, 90, 64);
        play(57, y, n);
        for (k = 2; k <= 8; k++)
            e_hi += tone_at(y, a, n, f * k);
        printf("   FM harmonics 2..8: %.0f at INDEX 20, %.0f at 90\n", e_lo, e_hi);
        check("FM INDEX brightens (harmonics 2..8 carry over 5x more at 90 than at 20)", e_hi > 5 * e_lo);
        {
            double ha[9];
            setup_fm(30, 70, 64);
            play(57, y, n);
            for (k = 2; k <= 8; k++) {
                ha[k] = tone_at(y, a, n, f * k);
                r1 += ha[k];
            }
            setup_fm(60, 70, 64);
            play(57, y, n);
            for (k = 2; k <= 8; k++)
                r2 += fabs(tone_at(y, a, n, f * k) - ha[k]);
            printf("   FM harmonics 2..8: %.0f in all at 1:1, they move by %.0f at the octave up\n", r1, r2);
            check("FM RATIO changes the spectrum (the harmonics move by over 20 %)", r2 > 0.2 * r1);
        }
        for (fb = 0; fb <= 127; fb += 127)
            for (idx = 0; idx <= 127; idx += 63)
                for (k = 0; k < 4; k++) {
                    static const uint8_t keys[] = {57, 69, 84, 108};
                    uint32_t j;
                    setup_fm(30 + 30 * (k & 1u), idx, fb);
                    play(keys[k], y, 8192);
                    for (j = 2048; j < 8192; j++) {
                        if (fabs(y[j]) > peak)
                            peak = fabs(y[j]);
                        dc += y[j];
                    }
                }
        printf("   FM sweep: peak %.0f, mean %.1f\n", peak, dc / (6144.0 * 24));
        check("FM sweep (INDEX, FEEDBACK both ways, ratio, keys): bounded (peak under 65536) and no DC (under 5 % of the peak)", peak < 65536 && fabs(dc / (6144.0 * 24)) < 0.05 * peak);
    }

    /* 4c. WAVESHAPER (TYPE 2): the period, FOLD brightens, WAVE changes the spectrum, bounded sweeps with no DC */
    {
        double worstc = 0, lo = 0, hi = 0, f = hz(57), peak = 0, dc = 0, ha[9], moved = 0, tot = 0;
        uint32_t k, w, fo, sl;
        for (note = 36; note <= 84; note += 12) {
            double per0 = (double)FS / hz(note), per = per0, e = 0, cc = 0, be = 1;
            uint32_t lag, j, kk;
            for (kk = 1; kk <= 64; kk++) {                                /* a number of periods that is a whole number of samples to 0.05 */
                double d = fabs(kk * per0 - floor(kk * per0 + 0.5));
                if (d < be) {
                    be = d;
                    per = kk * per0;
                }
                if (d < 0.05)
                    break;
            }
            lag = (uint32_t)(per + 0.5);
            setup_ws(64, 60, 64);
            play(note, y, n);
            for (j = a; j + lag < n; j++) {
                e += y[j] * y[j];
                cc += y[j] * y[j + lag];
            }
            if (e > 0 && 1.0 - cc / e > worstc)
                worstc = 1.0 - cc / e;
        }
        printf("   WS: worst 1 - correlation at the period: %.4f\n", worstc);
        check("WS repeats at the key's period (correlation over 0.97) over four octaves", worstc < 0.03);
        setup_ws(64, 10, 64);
        play(57, y, n);
        for (k = 2; k <= 8; k++)
            lo += tone_at(y, a, n, f * k);
        setup_ws(64, 110, 64);
        play(57, y, n);
        for (k = 2; k <= 8; k++)
            hi += tone_at(y, a, n, f * k);
        printf("   WS harmonics 2..8: %.0f at FOLD 10, %.0f at 110\n", lo, hi);
        check("WS FOLD changes the sound (harmonics 2..8 differ by over 30 %)", fabs(hi - lo) > 0.3 * (hi > lo ? hi : lo));
        setup_ws(0, 80, 64);
        play(57, y, n);
        for (k = 2; k <= 8; k++) {
            ha[k] = tone_at(y, a, n, f * k);
            tot += ha[k];
        }
        setup_ws(127, 80, 64);
        play(57, y, n);
        for (k = 2; k <= 8; k++)
            moved += fabs(tone_at(y, a, n, f * k) - ha[k]);
        printf("   WS harmonics 2..8: %.0f in all at WAVE 0, they move by %.0f at WAVE 127\n", tot, moved);
        check("WS WAVE changes the spectrum (the harmonics move by over 20 %)", moved > 0.2 * tot);
        for (w = 0; w <= 127; w += 32)
            for (fo = 0; fo <= 127; fo += 63)
                for (sl = 0; sl <= 127; sl += 127)
                    for (k = 0; k < 4; k++) {
                        static const uint8_t keys[] = {57, 69, 84, 108};
                        uint32_t j;
                        setup_ws(w, fo, sl);
                        play(keys[k], y, 8192);
                        for (j = 2048; j < 8192; j++) {
                            if (fabs(y[j]) > peak)
                                peak = fabs(y[j]);
                            dc += y[j];
                        }
                    }
        printf("   WS sweep: peak %.0f, mean %.1f\n", peak, dc / (6144.0 * 120));
        check("WS sweep (WAVE, FOLD, SLOPE, keys): bounded (peak under 65536) and no DC (under 5 % of the peak)", peak < 65536 && fabs(dc / (6144.0 * 120)) < 0.05 * peak);
    }

    /* 4d. FORMANT (TYPE 3): the period, FORMANT moves the spectral peak, bounded sweeps with no DC */
    {
        double worstc = 0, peak = 0, dc = 0, f = hz(45);
        uint32_t k, fo, w, sh, pk[3], ti;
        static const uint32_t ts[3] = {20, 60, 100};
        for (note = 36; note <= 84; note += 12) {
            double per0 = (double)FS / hz(note), per = per0, e = 0, cc = 0, be = 1;
            uint32_t lag, j, kk;
            for (kk = 1; kk <= 64; kk++) {
                double d = fabs(kk * per0 - floor(kk * per0 + 0.5));
                if (d < be) {
                    be = d;
                    per = kk * per0;
                }
                if (d < 0.05)
                    break;
            }
            lag = (uint32_t)(per + 0.5);
            setup_fo(64, 60, 64);
            play(note, y, n);
            for (j = a; j + lag < n; j++) {
                e += y[j] * y[j];
                cc += y[j] * y[j + lag];
            }
            if (e > 0 && 1.0 - cc / e > worstc)
                worstc = 1.0 - cc / e;
        }
        printf("   FORMANT: worst 1 - correlation at the period: %.4f\n", worstc);
        check("FORMANT repeats at the key's period (correlation over 0.97) over four octaves", worstc < 0.03);
        for (ti = 0; ti < 3; ti++) {
            double best = 0;
            setup_fo(64, ts[ti], 64);
            play(45, y, n);
            pk[ti] = 1;
            for (k = 1; k <= 60; k++) {
                double h = tone_at(y, a, n, f * k);
                if (h > best) {
                    best = h;
                    pk[ti] = k;
                }
            }
        }
        printf("   FORMANT peak harmonic of key 45: %u at FORMANT 20, %u at 60, %u at 100\n", pk[0], pk[1], pk[2]);
        check("FORMANT moves the spectral peak up (FORMANT 20 < 60 < 100)", pk[0] < pk[1] && pk[1] < pk[2]);
        for (fo = 0; fo <= 127; fo += 32)
            for (w = 0; w <= 127; w += 63)
                for (sh = 0; sh <= 127; sh += 32)
                    for (k = 0; k < 4; k++) {
                        static const uint8_t keys[] = {45, 60, 84, 108};
                        uint32_t j;
                        setup_fo(w, fo, sh);
                        play(keys[k], y, 8192);
                        for (j = 2048; j < 8192; j++) {
                            if (fabs(y[j]) > peak)
                                peak = fabs(y[j]);
                            dc += y[j];
                        }
                    }
        printf("   FORMANT sweep: peak %.0f, mean %.1f\n", peak, dc / (6144.0 * 300));
        check("FORMANT sweep (RATIO, FORMANT, SHAPE, keys): bounded (peak under 65536) and no DC (under 5 % of the peak)", peak < 65536 && fabs(dc / (6144.0 * 300)) < 0.05 * peak);
    }

    /* 4e. NOISE (TYPE 4): MODE moves it from low-pass to high-pass, the filter follows the key, bounded sweeps with no DC */
    {
        double lo_a, hi_a, lo_b, hi_b, p57, p69, peak = 0, dc = 0, cnt = 0;
        uint32_t k, md, ck, rs, j;
        setup_no(0, 120, 30);
        play(57, y, n);
        lo_a = band_power(y, a, n, 100, 800);
        hi_a = band_power(y, a, n, 4000, 9000);
        setup_no(127, 120, 30);
        play(57, y, n);
        lo_b = band_power(y, a, n, 100, 800);
        hi_b = band_power(y, a, n, 4000, 9000);
        printf("   NOISE band power low / high: %.3g / %.3g at MODE 0, %.3g / %.3g at MODE 127\n", lo_a, hi_a, lo_b, hi_b);
        check("NOISE MODE 0 is a low-pass (the lows over 1000x the highs), MODE 127 a high-pass (the highs not rolled off: over 0.1x the lows)", lo_a > 1000 * hi_a && hi_b > 0.1 * lo_b);
        setup_no(64, 120, 100);
        play(57, y, n);
        p57 = band_power(y, a, n, hz(57) * 0.94, hz(57) * 1.06) / band_power(y, a, n, hz(69) * 0.94, hz(69) * 1.06);
        setup_no(64, 120, 100);
        play(69, y, n);
        p69 = band_power(y, a, n, hz(69) * 0.94, hz(69) * 1.06) / band_power(y, a, n, hz(57) * 0.94, hz(57) * 1.06);
        printf("   NOISE resonance: key 57 band over key 69's band %.2f, key 69 over 57 %.2f\n", p57, p69);
        check("NOISE filter follows the key (a resonant band-pass peaks at the key's pitch, over 3x its neighbour octave)", p57 > 3 && p69 > 3);
        for (md = 0; md <= 127; md += 32)
            for (ck = 0; ck <= 127; ck += 32)
                for (rs = 0; rs <= 127; rs += 63)
                    for (k = 0; k < 3; k++) {
                        static const uint8_t keys[] = {36, 69, 105};
                        setup_no(md, ck, rs);
                        play(keys[k], y, 8192);
                        for (j = 2048; j < 8192; j++) {
                            if (fabs(y[j]) > peak)
                                peak = fabs(y[j]);
                            dc += y[j];
                        }
                        cnt += 6144;
                    }
        printf("   NOISE sweep: peak %.0f, mean %.1f\n", peak, dc / cnt);
        check("NOISE sweep (MODE, CLOCK, RES, keys): bounded (peak under 65536) and no DC (under 5 % of the peak)", peak < 65536 && fabs(dc / cnt) < 0.05 * peak);
    }

    /* 4f. CHORDS (TYPE 5): the chord's notes are there and the notes between them are not (string machine and wavetable), a
     *     different CHORD changes them, bounded sweeps with no DC */
    {
        double peak = 0, dc = 0, cnt = 0;
        uint32_t wv, k, ch, iv, wave, j;
        for (wv = 0; wv < 2; wv++) {
            double on, off;
            setup_ch(127, 0, wv ? 127 : 0);                               /* the major chord, root position */
            play(60, y, n);
            on = tone_at(y, a, n, hz(36)) + tone_at(y, a, n, hz(40)) + tone_at(y, a, n, hz(43));
            off = tone_at(y, a, n, hz(37)) + tone_at(y, a, n, hz(39)) + tone_at(y, a, n, hz(42));
            printf("   CHORDS %s: chord notes %.0f, notes between %.0f\n", wv ? "wavetable" : "string machine", on, off);
            check(wv ? "CHORDS wavetable: the chord's notes (root, major third, fifth) are over 4x the notes between" : "CHORDS string machine: the chord's notes (root, major third, fifth) are over 4x the notes between", on > 4 * off);
        }
        {
            double minor, major;
            setup_ch(127, 0, 0);
            play(60, y, n);
            major = tone_at(y, a, n, hz(40)) - tone_at(y, a, n, hz(39));
            setup_ch(52, 0, 0);                                           /* a minor chord: the third is a semitone lower */
            play(60, y, n);
            minor = tone_at(y, a, n, hz(40)) - tone_at(y, a, n, hz(39));
            printf("   CHORDS third minus the minor third: %.0f in the major chord, %.0f in the minor\n", major, minor);
            check("CHORDS CHORD changes the third (major above, minor below)", major > 0 && minor < 0);
        }
        for (ch = 0; ch <= 127; ch += 25)
            for (iv = 0; iv <= 127; iv += 21)
                for (wave = 0; wave <= 127; wave += 21)
                    for (k = 0; k < 3; k++) {
                        static const uint8_t keys[] = {36, 60, 96};
                        setup_ch(ch, iv, wave);
                        play(keys[k], y, 8192);
                        for (j = 2048; j < 8192; j++) {
                            if (fabs(y[j]) > peak)
                                peak = fabs(y[j]);
                            dc += y[j];
                        }
                        cnt += 6144;
                    }
        printf("   CHORDS sweep: peak %.0f, mean %.1f\n", peak, dc / cnt);
        check("CHORDS sweep (CHORD, INVERSION, WAVE, keys): bounded (peak under 65536) and no DC (under 5 % of the peak)", peak < 65536 && fabs(dc / cnt) < 0.05 * peak);
    }

    /* 4g. MODAL (TYPE 6): the resonators ring at the key's harmonics, DAMP narrows them, only four voices sound, bounded sweeps */
    {
        double peak = 0, dc = 0, cnt = 0, rl, rh;
        uint32_t k, st, br, dp, j;
        setup_mo(32, 90, 20);                                             /* STRUCTURE 32 is harmonic (no stiffness) */
        play(45, y, n);
        rl = band_power(y, a, n, hz(45) * 1.94, hz(45) * 2.06) / band_power(y, a, n, hz(45) * 1.44, hz(45) * 1.56);
        setup_mo(32, 90, 100);
        play(45, y, n);
        rh = band_power(y, a, n, hz(45) * 1.94, hz(45) * 2.06) / band_power(y, a, n, hz(45) * 1.44, hz(45) * 1.56);
        printf("   MODAL: the 2nd mode over the gap below it: %.1f at DAMP 20, %.1f at DAMP 100\n", rl, rh);
        check("MODAL rings at the key's harmonics (the 2nd mode over 10x the gap below it at DAMP 100) and DAMP narrows the peaks (5x more than at 20)", rh > 10 && rh > 5 * rl);
        for (st = 0; st <= 127; st += 63)
            for (br = 20; br <= 120; br += 50)
                for (dp = 20; dp <= 120; dp += 50)
                    for (k = 0; k < 3; k++) {
                        static const uint8_t keys[] = {45, 60, 84};
                        setup_mo(st, br, dp);
                        play(keys[k], y, 16384);
                        for (j = 4096; j < 16384; j++) {
                            if (fabs(y[j]) > peak)
                                peak = fabs(y[j]);
                            dc += y[j];
                        }
                        cnt += 12288;
                    }
        printf("   MODAL sweep: peak %.0f, mean %.1f\n", peak, dc / cnt);
        check("MODAL sweep (STRUCTURE, BRIGHT, DAMP, keys): bounded (peak under 65536) and no DC (under 5 % of the peak)", peak < 65536 && fabs(dc / cnt) < 0.05 * peak);
    }

    /* 4h. SWARM (TYPE 7): MIX 0 is the centre oscillator alone (a saw at the key's pitch), DETUNE spreads the swarm, bounded sweeps */
    {
        double peak = 0, dc = 0, cnt = 0, f = hz(57), c0, c1, ratio;
        uint32_t wv, de, mx, k, j;
        setup_sw(0, 0, 0);
        play(57, y, n);
        c0 = tone_at(y, a, n, f);
        ratio = tone_at(y, a, n, 2 * f) / c0;
        printf("   SWARM centre alone: 2nd / 1st %.2f (a saw: 0.5)\n", ratio);
        check("SWARM MIX 0 is a single saw at the key's pitch (2nd harmonic near half the first)", ratio > 0.4 && ratio < 0.6);
        setup_sw(0, 0, 127);
        play(57, y, n);
        c1 = tone_at(y, a, n, f);
        setup_sw(0, 100, 127);
        play(57, y, n);
        printf("   SWARM fundamental: %.0f undetuned, %.0f at DETUNE 100\n", c1, tone_at(y, a, n, f));
        check("SWARM DETUNE spreads the swarm (the fundamental's line weakens by over 30 %)", tone_at(y, a, n, f) < 0.7 * c1);
        for (wv = 0; wv <= 127; wv += 32)
            for (de = 0; de <= 127; de += 63)
                for (mx = 0; mx <= 127; mx += 63)
                    for (k = 0; k < 3; k++) {
                        static const uint8_t keys[] = {36, 60, 96};
                        setup_sw(wv, de, mx);
                        play(keys[k], y, 8192);
                        for (j = 2048; j < 8192; j++) {
                            if (fabs(y[j]) > peak)
                                peak = fabs(y[j]);
                            dc += y[j];
                        }
                        cnt += 6144;
                    }
        printf("   SWARM sweep: peak %.0f, mean %.1f\n", peak, dc / cnt);
        check("SWARM sweep (WAVE, DETUNE, MIX, keys): bounded (peak under 65536) and no DC (under 5 % of the peak)", peak < 65536 && fabs(dc / cnt) < 0.05 * peak);
    }

    /* 4i. HARMONIC (TYPE 8): the period, PEAK moves the strongest harmonic up, STRETCH moves the partials off the harmonics, bounded sweeps */
    {
        double peak = 0, dc = 0, cnt = 0, f = hz(45), per0 = (double)FS / hz(57), per = per0, e = 0, cc = 0, be = 1, on, off;
        uint32_t pe, wd, ch, k, j, kk, lag, pk[3], ti;
        static const uint32_t ps[3] = {10, 50, 100};
        for (kk = 1; kk <= 64; kk++) {
            double d = fabs(kk * per0 - floor(kk * per0 + 0.5));
            if (d < be) {
                be = d;
                per = kk * per0;
            }
            if (d < 0.05)
                break;
        }
        lag = (uint32_t)(per + 0.5);
        setup_hm(60, 60, 0, 0);
        play(57, y, n);
        for (j = a; j + lag < n; j++) {
            e += y[j] * y[j];
            cc += y[j] * y[j + lag];
        }
        printf("   HARMONIC: 1 - correlation at the period %.4f\n", 1.0 - cc / e);
        check("HARMONIC repeats at the key's period (correlation over 0.97)", 1.0 - cc / e < 0.03);
        for (ti = 0; ti < 3; ti++) {
            double best = 0;
            setup_hm(ps[ti], 40, 0, 0);
            play(45, y, n);
            pk[ti] = 1;
            for (k = 1; k <= 12; k++) {
                double h = tone_at(y, a, n, f * k);
                if (h > best) {
                    best = h;
                    pk[ti] = k;
                }
            }
        }
        printf("   HARMONIC strongest harmonic: %u at PEAK 10, %u at 50, %u at 100\n", pk[0], pk[1], pk[2]);
        check("HARMONIC PEAK moves the strongest harmonic up (PEAK 10 < 50 < 100)", pk[0] < pk[1] && pk[1] < pk[2]);
        setup_hm(50, 40, 0, 0);
        play(45, y, n);
        on = tone_at(y, a, n, 4 * f);
        setup_hm(50, 40, 0, 100);
        play(45, y, n);
        off = tone_at(y, a, n, 4 * f);
        printf("   HARMONIC 4th harmonic: %.0f harmonic, %.0f at STRETCH 100\n", on, off);
        check("HARMONIC STRETCH moves the 4th partial off the 4th harmonic (the line falls by over 3x)", off < on / 3);
        for (pe = 0; pe <= 127; pe += 32)
            for (wd = 0; wd <= 127; wd += 63)
                for (ch = 0; ch <= 127; ch += 127)
                    for (k = 0; k < 3; k++) {
                        static const uint8_t keys[] = {36, 60, 96};
                        setup_hm(pe, wd, ch, (k & 1u) * 90);
                        play(keys[k], y, 8192);
                        for (j = 2048; j < 8192; j++) {
                            if (fabs(y[j]) > peak)
                                peak = fabs(y[j]);
                            dc += y[j];
                        }
                        cnt += 6144;
                    }
        printf("   HARMONIC sweep: peak %.0f, mean %.1f\n", peak, dc / cnt);
        check("HARMONIC sweep (PEAK, WIDTH, CHORUS, STRETCH, keys): bounded (peak under 65536) and no DC (under 5 % of the peak)", peak < 65536 && fabs(dc / cnt) < 0.05 * peak);
    }

    /* 4j. PLUCK (TYPE 9): the string's pitch, DECAY lengthens the ring, voices past the fourth are silent, bounded sweeps */
    {
        double worstc = 0, peak = 0, dc = 0, cnt = 0, short_t, long_t, e5 = 0;
        uint32_t k, j, de, po, bo;
        static const uint8_t pkeys[] = {45, 57, 69, 81};
        for (k = 0; k < 4; k++) {
            double best = 0, bc = 0, c;
            setup_pl(0, 40, 100);
            play(pkeys[k], y, n);
            for (c = -60; c <= 60; c += 2) {
                double h = tone_at(y, a, n, hz(pkeys[k]) * pow(2.0, c / 1200.0));
                if (h > best) {
                    best = h;
                    bc = c;
                }
            }
            printf("   PLUCK key %u: strongest line %+.0f cents from the key\n", pkeys[k], bc);
            if (fabs(bc) > worstc)
                worstc = fabs(bc);
        }
        check("PLUCK sounds at the key's pitch (within 20 cents), four octaves", worstc <= 20);
        {
            double acc[2];
            uint32_t w;
            for (w = 0; w < 2; w++) {
                double early, late;
                setup_pl(0, 40, w ? 120 : 10);
                play(57, y, FS);
                early = late = 0;
                for (j = FS / 8; j < FS / 8 + 4096; j++)
                    early += y[j] * y[j];
                for (j = FS - 4096; j < FS; j++)
                    late += y[j] * y[j];
                acc[w] = late / (early > 0 ? early : 1);
            }
            short_t = acc[0];
            long_t = acc[1];
            printf("   PLUCK late/early energy: %.4f at DECAY 10, %.4f at DECAY 120\n", short_t, long_t);
            check("PLUCK DECAY lengthens the ring (DECAY 120 keeps over 3x the energy of DECAY 10 at one second)", long_t > 3 * short_t);
        }
        setup_pl(0, 40, 100);
        trk_note_on(&trk[0], 60, 100);
        for (k = 0; k < 5; k++)
            trk_note_on(&trk[0], 60 + (int)k, 100);
        {
            static int32_t b[CTL];
            uint32_t blk;
            for (blk = 0; blk < 64; blk++) {
                track_render(&trk[0], b, CTL);
                for (j = 0; j < CTL; j++)
                    e5 += fabs((double)b[j]);
            }
            printf("   PLUCK six held notes: summed magnitude %.0f\n", e5);
            check("PLUCK six notes at once stay bounded (voices past the fourth are silent, no crash)", e5 < 64.0 * CTL * 65536);
        }
        for (de = 0; de <= 127; de += 40)
            for (po = 0; po <= 127; po += 63)
                for (bo = 0; bo <= 127; bo += 127)
                    for (k = 0; k < 3; k++) {
                        static const uint8_t keys[] = {28, 60, 100};
                        setup_pl(bo, po, de);
                        play(keys[k], y, 8192);
                        for (j = 2048; j < 8192; j++) {
                            if (fabs(y[j]) > peak)
                                peak = fabs(y[j]);
                            dc += y[j];
                        }
                        cnt += 6144;
                    }
        printf("   PLUCK sweep: peak %.0f, mean %.1f\n", peak, dc / cnt);
        check("PLUCK sweep (BOW, POSITION, DECAY, keys): bounded (peak under 65536) and no DC (under 5 % of the peak)", peak < 65536 && fabs(dc / cnt) < 0.05 * peak);
    }

    /* 4k. BASS (TYPE 10): pitch of both waves, SUB adds a line one or two octaves down, WIDTH moves the even harmonics, bounded sweeps */
    {
        double worstc = 0, peak = 0, f = hz(57), lo_a, hi_a, lo_b, hi_b, mid, sq1, sq2;
        uint32_t w, k, j, wd, su;
        for (w = 0; w < 2; w++)
            for (k = 0; k < 4; k++) {
                static const uint8_t bkeys[] = {36, 48, 60, 72};
                double c;
                setup_bs(w * 127, 0, 64);
                play(bkeys[k], y, n);
                if (!w) {
                    c = 1200 * log2(pitch(y, a, n) / hz(bkeys[k]));
                    if (!(fabs(c) < 1e9))
                        c = 1e9;
                } else {                                         /* the saw crosses zero twice a cycle at some widths: find the strongest line */
                    double best = 0;
                    c = 0;
                    for (j = 0; j <= 40; j++) {
                        double cc = -20 + j, h = tone_at(y, a, n, hz(bkeys[k]) * pow(2.0, cc / 1200.0));
                        if (h > best) {
                            best = h;
                            c = cc;
                        }
                    }
                    if (tone_at(y, a, n, hz(bkeys[k]) / 2) > 0.3 * best || tone_at(y, a, n, 2 * hz(bkeys[k])) > best)
                        c = 1200;
                }
                if (fabs(c) > worstc)
                    worstc = fabs(c);
            }
        printf("   BASS pitch, worst of 2 waves x 4 octaves: %.2f cents\n", worstc);
        check("BASS at the key's pitch (6 cents for the square, 20 for the saw's spectral line), SUB in the middle", worstc < 20.0);
        setup_bs(0, 64, 0);
        play(57, y, n);
        lo_a = tone_at(y, a, n, f / 4);
        hi_a = tone_at(y, a, n, f / 2);
        setup_bs(0, 64, 127);
        play(57, y, n);
        lo_b = tone_at(y, a, n, f / 4);
        hi_b = tone_at(y, a, n, f / 2);
        setup_bs(0, 64, 64);
        play(57, y, n);
        mid = tone_at(y, a, n, f / 4) + tone_at(y, a, n, f / 2);
        printf("   BASS SUB 0: -2 oct %.0f, -1 oct %.0f; SUB 127: -2 oct %.0f, -1 oct %.0f; SUB 64: %.0f\n", lo_a, hi_a, lo_b, hi_b, mid);
        check("BASS SUB below the middle puts the line two octaves down, above it one octave down", lo_a > 3 * hi_a && hi_b > 3 * lo_b);
        check("BASS SUB in the middle is off (both sub lines under a fifth of the ends')", mid < 0.2 * (lo_a > hi_b ? lo_a : hi_b));
        setup_bs(0, 0, 64);
        play(57, y, n);
        sq1 = tone_at(y, a, n, 2 * f);
        setup_bs(0, 100, 64);
        play(57, y, n);
        sq2 = tone_at(y, a, n, 2 * f);
        printf("   BASS 2nd harmonic: %.0f at WIDTH 0, %.0f at WIDTH 100\n", sq1, sq2);
        check("BASS WIDTH away from the middle brings in the even harmonics (over 5x)", sq2 > 5 * sq1);
        for (w = 0; w < 2; w++)
            for (wd = 0; wd <= 127; wd += 32)
                for (su = 0; su <= 127; su += 32)
                    for (k = 0; k < 3; k++) {
                        static const uint8_t keys[] = {24, 60, 108};
                        setup_bs(w * 127, wd, su);
                        play(keys[k], y, 8192);
                        for (j = 2048; j < 8192; j++)
                            if (fabs(y[j]) > peak)
                                peak = fabs(y[j]);
                    }
        printf("   BASS sweep: peak %.0f\n", peak);
        check("BASS sweep (WAVE, WIDTH, SUB, keys): bounded (peak under 65536)", peak < 65536);
    }

    /* 4l. SAW (TYPE 11): the synced saws repeat at the master period, the comb's feedback sign moves the peaks half a period, CS80 pitch, bounded sweeps */
    {
        double peak = 0, f = hz(57), rp_a, rp_b, rn_a, rn_b, e, cc, worst_c = 0;
        uint32_t w, k, j, lag, e2, e3, kk;
        for (w = 0; w < 3; w++) {
            static const uint8_t wv[3] = {0, 64, 127};
            static const uint8_t skeys[] = {45, 57, 69};
            for (k = 0; k < 3; k++) {
                double per0 = (double)FS / hz(skeys[k]), per = per0, be = 1;
                for (kk = 1; kk <= 64; kk++) {
                    double d = fabs(kk * per0 - floor(kk * per0 + 0.5));
                    if (d < be) {
                        be = d;
                        per = kk * per0;
                    }
                    if (d < 0.05)
                        break;
                }
                lag = (uint32_t)(per + 0.5);
                setup_sa(wv[w], w == 1 ? 63 : 70, 100);
                play(skeys[k], y, n);
                e = cc = 0;
                for (j = a; j + lag < n; j++) {
                    e += y[j] * y[j];
                    cc += y[j] * y[j + lag];
                }
                if (1.0 - cc / e > worst_c)
                    worst_c = 1.0 - cc / e;
            }
        }
        printf("   SAW worst 1 - correlation at the key's period, three waves: %.4f\n", worst_c);
        check("SAW (sync, comb, CS80) repeats at the key's period (correlation over 0.95)", worst_c < 0.05);
        setup_sa(64, 63, 127);
        play(57, y, n);
        rp_a = tone_at(y, a, n, f);
        rp_b = tone_at(y, a, n, 1.5 * f);
        setup_sa(64, 63, 0);
        play(57, y, n);
        rn_a = tone_at(y, a, n, f);
        rn_b = tone_at(y, a, n, 1.5 * f);
        printf("   SAW comb: f %.0f (1.5 f %.0f) at feedback up, f %.0f (1.5 f %.0f) at feedback down\n", rp_a, rp_b, rn_a, rn_b);
        check("SAW comb tuned to the key: feedback up reinforces the harmonics, feedback down notches them (f line over 1.8x)", rp_a > 1.8 * rn_a);
        for (w = 0; w < 3; w++)
            for (e2 = 0; e2 <= 127; e2 += 32)
                for (e3 = 0; e3 <= 127; e3 += 32)
                    for (k = 0; k < 3; k++) {
                        static const uint8_t keys[] = {28, 60, 108};
                        static const uint8_t wv[3] = {0, 64, 127};
                        setup_sa(wv[w], e2, e3);
                        play(keys[k], y, 8192);
                        for (j = 2048; j < 8192; j++)
                            if (fabs(y[j]) > peak)
                                peak = fabs(y[j]);
                    }
        printf("   SAW sweep: peak %.0f\n", peak);
        check("SAW sweep (WAVE, E2, E3, keys): bounded (peak under 65536)", peak < 65536);
    }

    /* 4m. WAVETABLE (TYPE 12): every table repeats at the key's period, POSITION changes the wave, CHORUS adds a sharp second reader, MORPH reaches the next table, bounded sweeps */
    {
        double worst_c = 0, peak = 0, e, cc, d0 = 0, d1 = 0, n0 = 0, n1 = 0, sh0, sh1, lo;
        static double y2[FS];
        uint32_t tb, k, j, lag, pe, ch, mo;
        lag = (uint32_t)((double)FS / hz(57) * 1 + 0.5);
        {   /* the period of key 57 is 200.45 samples: use the multiple with a whole-sample lag */
            double per0 = (double)FS / hz(57), per = per0, be = 1;
            uint32_t kk;
            for (kk = 1; kk <= 64; kk++) {
                double d = fabs(kk * per0 - floor(kk * per0 + 0.5));
                if (d < be) {
                    be = d;
                    per = kk * per0;
                }
                if (d < 0.05)
                    break;
            }
            lag = (uint32_t)(per + 0.5);
        }
        for (tb = 0; tb < 16; tb++) {
            setup_wt(tb, 50, 0, 0);
            play(57, y, n);
            e = cc = 0;
            for (j = a; j + lag < n; j++) {
                e += y[j] * y[j];
                cc += y[j] * y[j + lag];
            }
            if (1.0 - cc / e > worst_c)
                worst_c = 1.0 - cc / e;
        }
        printf("   WAVETABLE worst 1 - correlation at the key's period over 16 tables: %.4f\n", worst_c);
        check("WAVETABLE every table repeats at the key's period (correlation over 0.95)", worst_c < 0.05);
        setup_wt(0, 0, 0, 0);
        play(57, y, n);
        setup_wt(0, 127, 0, 0);
        play(57, y2, n);
        for (j = a; j < n; j++) {
            d0 += (y[j] - y2[j]) * (y[j] - y2[j]);
            n0 += y[j] * y[j];
        }
        printf("   WAVETABLE POSITION 0 vs 127: relative difference %.3f\n", sqrt(d0 / n0));
        check("WAVETABLE POSITION changes the wave (the two renders differ by over 10 %)", sqrt(d0 / n0) > 0.1);
        setup_wt(0, 40, 0, 0);
        play(93, y, n);
        sh0 = tone_at(y, a, n, hz(93) * 1.006);
        lo = tone_at(y, a, n, hz(93) * 0.994);
        setup_wt(0, 40, 127, 0);
        play(93, y, n);
        sh1 = tone_at(y, a, n, hz(93) * 1.006);
        printf("   WAVETABLE sharp line: %.0f at CHORUS 0 (flat side %.0f), %.0f at CHORUS 127\n", sh0, lo, sh1);
        check("WAVETABLE CHORUS brings a second reader 10 cents sharp (the line above the key more than doubles)", sh1 > 2 * sh0);
        setup_wt(1, 60, 0, 127);
        play(57, y, n);
        setup_wt(2, 60, 0, 0);
        play(57, y2, n);
        d1 = n1 = 0;
        for (j = a; j < n; j++) {
            d1 += (y[j] - y2[j]) * (y[j] - y2[j]);
            n1 += y2[j] * y2[j];
        }
        printf("   WAVETABLE table 1 with MORPH 127 vs table 2: relative difference %.4f\n", sqrt(d1 / n1));
        check("WAVETABLE MORPH 127 is the next table at the same position (under 3 % apart)", sqrt(d1 / n1) < 0.03);
        for (tb = 0; tb < 16; tb += 5)
            for (pe = 0; pe <= 127; pe += 42)
                for (ch = 0; ch <= 127; ch += 127)
                    for (mo = 0; mo <= 127; mo += 127)
                        for (k = 0; k < 3; k++) {
                            static const uint8_t keys[] = {28, 60, 108};
                            setup_wt(tb, pe, ch, mo);
                            play(keys[k], y, 8192);
                            for (j = 2048; j < 8192; j++)
                                if (fabs(y[j]) > peak)
                                    peak = fabs(y[j]);
                        }
        printf("   WAVETABLE sweep: peak %.0f\n", peak);
        check("WAVETABLE sweep (TABLE, POSITION, CHORUS, MORPH, keys): bounded (peak under 65536)", peak < 65536);
    }

    /* 4n. V.ANALOG (TYPE 13): the saw repeats at the key's period, DETUNE puts it a fifth or two octaves away, SYNC changes the square, bounded sweeps */
    {
        double f = hz(57), e, cc, peak = 0, d0 = 0, n0 = 0, l0, l1, l2, fifth, root;
        static double y2[FS];
        uint32_t k, j, lag, kk, sy, sh, de;
        double per0 = (double)FS / f, per = per0, be = 1;
        for (kk = 1; kk <= 64; kk++) {
            double d = fabs(kk * per0 - floor(kk * per0 + 0.5));
            if (d < be) {
                be = d;
                per = kk * per0;
            }
            if (d < 0.05)
                break;
        }
        lag = (uint32_t)(per + 0.5);
        setup_va(64, 0, 64);
        play(57, y, n);
        e = cc = 0;
        for (j = a; j + lag < n; j++) {
            e += y[j] * y[j];
            cc += y[j] * y[j + lag];
        }
        printf("   V.ANALOG saw alone: 1 - correlation at the key's period %.4f\n", 1.0 - cc / e);
        check("V.ANALOG the saw alone repeats at the key's period (correlation over 0.97)", 1.0 - cc / e < 0.03);
        setup_va(127, 0, 64);
        play(57, y, n);
        l0 = tone_at(y, a, n, 4 * f);
        l1 = tone_at(y, a, n, f);
        setup_va(0, 0, 64);
        play(57, y, n);
        l2 = tone_at(y, a, n, f / 4);
        printf("   V.ANALOG DETUNE 127: 4 f line %.0f (f line %.0f); DETUNE 0: f/4 line %.0f\n", l0, l1, l2);
        check("V.ANALOG DETUNE at the ends is two octaves up or down (the line there over 3x the key's)", l0 > 3 * l1 && l2 > 3 * tone_at(y, a, n, f));
        setup_va(80, 0, 64);
        play(57, y, n);
        fifth = tone_at(y, a, n, f * 1.4983);
        root = tone_at(y, a, n, f);
        printf("   V.ANALOG DETUNE 80: fifth line %.0f, key line %.0f\n", fifth, root);
        check("V.ANALOG DETUNE 80 puts the saw a fifth up (the fifth over 3x the key's line)", fifth > 3 * root);
        setup_va(64, 20, 127);
        play(57, y, n);
        setup_va(64, 127, 127);
        play(57, y2, n);
        for (j = a; j < n; j++) {
            d0 += (y[j] - y2[j]) * (y[j] - y2[j]);
            n0 += y[j] * y[j];
        }
        printf("   V.ANALOG SYNC 20 vs 127 (square dominant): relative difference %.3f\n", sqrt(d0 / n0));
        check("V.ANALOG SYNC changes the square (the renders differ by over 20 %)", sqrt(d0 / n0) > 0.2);
        for (de = 0; de <= 127; de += 32)
            for (sy = 0; sy <= 127; sy += 32)
                for (sh = 0; sh <= 127; sh += 32)
                    for (k = 0; k < 3; k++) {
                        static const uint8_t keys[] = {24, 60, 108};
                        setup_va(de, sy, sh);
                        play(keys[k], y, 8192);
                        for (j = 2048; j < 8192; j++)
                            if (fabs(y[j]) > peak)
                                peak = fabs(y[j]);
                    }
        printf("   V.ANALOG sweep: peak %.0f\n", peak);
        check("V.ANALOG sweep (DETUNE, SYNC, SHAPE, keys): bounded (peak under 65536)", peak < 65536);
    }

    /* 4o. RINGS (TYPE 14), the modal model: the struck bank's pitch, DAMPING, STRUCTURE, POSITION, voices past the fourth, bounded sweeps */
    {
        double f = hz(57), early, late, e2a, e2b, l0, l1, peak = 0, e5 = 0, rp0, rp1;
        uint32_t k, j, st, br, dm, ps, w;
        for (k = 0; k < 4; k++) {
            static const uint8_t rk[] = {45, 57, 69, 81};
            double best = 0, bc = 0, c;
            setup_ri(0, 32, 64, 64, 64);
            play(rk[k], y, n);
            for (c = -40; c <= 40; c += 2) {
                double h = tone_at(y, a, n, hz(rk[k]) * pow(2.0, c / 1200.0));
                if (h > best) {
                    best = h;
                    bc = c;
                }
            }
            printf("   RINGS key %u: strongest line %+.0f cents from the key\n", rk[k], bc);
            check("RINGS modal rings at the key's pitch (within 10 cents) with STRUCTURE at harmonic", fabs(bc) <= 10);
        }
        for (w = 0; w < 2; w++) {
            double a1 = 0, a2 = 0;
            setup_ri(0, 32, 64, w ? 120 : 40, 64);
            play(57, y, FS);
            for (j = FS / 8; j < FS / 8 + 4096; j++)
                a1 += y[j] * y[j];
            for (j = FS / 2; j < FS / 2 + 4096; j++)
                a2 += y[j] * y[j];
            if (w)
                late = a2 / (a1 > 0 ? a1 : 1);
            else
                early = a2 / (a1 > 0 ? a1 : 1);
            if (w)
                e2b = late;
            else
                e2a = early;
        }
        printf("   RINGS energy after half a second over that at an eighth: %.5f at DAMPING 40, %.5f at DAMPING 120\n", e2a, e2b);
        check("RINGS DAMPING lengthens the ring (the tail at 120 holds over 10x the energy of 40)", e2b > 10 * e2a);
        setup_ri(0, 32, 64, 80, 64);
        play(57, y, n);
        l0 = tone_at(y, a, n, 3 * f) / (tone_at(y, a, n, f) + 1);
        setup_ri(0, 100, 64, 80, 64);
        play(57, y, n);
        l1 = tone_at(y, a, n, 3 * f) / (tone_at(y, a, n, f) + 1);
        printf("   RINGS 3rd harmonic over the fundamental: %.3f at STRUCTURE 32, %.3f at STRUCTURE 100\n", l0, l1);
        check("RINGS STRUCTURE away from harmonic detunes the partials (the 3rd harmonic line drops below a third)", l1 < l0 / 3);
        setup_ri(0, 32, 64, 80, 64);
        play(57, y, n);
        rp0 = tone_at(y, a, n, 2 * f) / (tone_at(y, a, n, f) + 1);
        setup_ri(0, 32, 64, 80, 20);
        play(57, y, n);
        rp1 = tone_at(y, a, n, 2 * f) / (tone_at(y, a, n, f) + 1);
        printf("   RINGS 2nd harmonic over the fundamental: %.3f at POSITION 64, %.3f at POSITION 20\n", rp0, rp1);
        check("RINGS POSITION in the middle cancels the even modes (the 2nd harmonic under a tenth, and over 3x that elsewhere)", rp0 < 0.1 && rp1 > 3 * rp0);
        setup_ri(0, 32, 64, 80, 64);
        for (k = 0; k < 6; k++)
            trk_note_on(&trk[0], 60 + (int)k, 100);
        {
            static int32_t b[CTL];
            uint32_t blk;
            for (blk = 0; blk < 64; blk++) {
                track_render(&trk[0], b, CTL);
                for (j = 0; j < CTL; j++)
                    e5 += fabs((double)b[j]);
            }
            printf("   RINGS six held notes: summed magnitude %.0f\n", e5);
            check("RINGS six notes at once stay bounded (voices past the fourth are silent, no crash)", e5 < 64.0 * CTL * 65536);
        }
        for (st = 0; st <= 127; st += 32)
            for (br = 0; br <= 127; br += 64)
                for (dm = 0; dm <= 127; dm += 63)
                    for (ps = 0; ps <= 127; ps += 63)
                        for (k = 0; k < 3; k++) {
                            static const uint8_t keys[] = {24, 60, 108};
                            setup_ri(0, st, br, dm, ps);
                            play(keys[k], y, 8192);
                            for (j = 0; j < 8192; j++)
                                if (fabs(y[j]) > peak)
                                    peak = fabs(y[j]);
                        }
        printf("   RINGS sweep: peak %.0f\n", peak);
        check("RINGS sweep (STRUCTURE, BRIGHTNESS, DAMPING, POSITION, keys): bounded (peak under 65536)", peak < 65536);
    }

    /* 4p. RINGS (TYPE 14), the FM model (E1 77): a sine at zero BRIGHTNESS, sidebands with it, DAMPING lengthens the strike's decay, bounded sweeps */
    {
        double f = hz(57), c0, c1, e_a, e_b, a1, a2, peak = 0, h0, h1, h3, h5;
        uint32_t k, j, st, br, dm, ps, w;
        setup_ri(77, 64, 0, 64, 64);
        play(57, y, n);
        c0 = tone_at(y, a, n, f);
        h0 = tone_at(y, a, n, 2 * f) + tone_at(y, a, n, 3 * f);
        printf("   RINGS FM at BRIGHTNESS 0: key line %.0f, 2f + 3f lines %.0f\n", c0, h0);
        check("RINGS FM at BRIGHTNESS 0 is a sine at the key (the 2nd and 3rd lines under 5 % of it)", c0 > 0 && h0 < 0.05 * c0);
        setup_ri(77, 64, 127, 64, 64);
        play(57, y, n);
        c1 = tone_at(y, a, n, f);
        h1 = tone_at(y, a, n, 3 * f) + tone_at(y, a, n, 5 * f);
        h3 = tone_at(y, a, n, 2 * f);
        h5 = h1;
        printf("   RINGS FM at BRIGHTNESS 127 (ratio 12): key line %.0f, 3f + 5f lines %.0f, 2f %.0f\n", c1, h1, h3);
        check("RINGS FM BRIGHTNESS brings in sidebands (the 3f + 5f lines over 30 % of the key's)", h5 > 0.3 * c1);
        for (w = 0; w < 2; w++) {
            a1 = a2 = 0;
            setup_ri(77, 64, 64, w ? 120 : 40, 64);
            play(57, y, FS);
            for (j = FS / 8; j < FS / 8 + 4096; j++)
                a1 += y[j] * y[j];
            for (j = FS / 2; j < FS / 2 + 4096; j++)
                a2 += y[j] * y[j];
            if (w)
                e_b = a2 / (a1 > 0 ? a1 : 1);
            else
                e_a = a2 / (a1 > 0 ? a1 : 1);
        }
        printf("   RINGS FM energy after half a second over that at an eighth: %.5f at DAMPING 40, %.5f at DAMPING 120\n", e_a, e_b);
        check("RINGS FM DAMPING lengthens the decay (the tail at 120 holds over 10x the energy of 40)", e_b > 10 * e_a);
        for (st = 0; st <= 127; st += 32)
            for (br = 0; br <= 127; br += 64)
                for (dm = 0; dm <= 127; dm += 63)
                    for (ps = 0; ps <= 127; ps += 32)
                        for (k = 0; k < 3; k++) {
                            static const uint8_t keys[] = {24, 60, 108};
                            setup_ri(77, st, br, dm, ps);
                            play(keys[k], y, 8192);
                            for (j = 0; j < 8192; j++)
                                if (fabs(y[j]) > peak)
                                    peak = fabs(y[j]);
                        }
        printf("   RINGS FM sweep: peak %.0f\n", peak);
        check("RINGS FM sweep (STRUCTURE, BRIGHTNESS, DAMPING, POSITION, keys): bounded (peak under 65536)", peak < 65536);
    }

    /* 4q. RINGS (TYPE 14), the STRING model (E1 64): the key's pitch, DAMPING lengthens the ring, POSITION is a comb, bounded sweeps */
    {
        static const uint8_t keys[] = {33, 45, 57, 69, 81};
        double peak = 0, e_a, e_b, a1, a2, p_mid, p_q, f1;
        uint32_t k, j, st, br, dm, ps, w, lag, best;
        int ok = 1;
        for (k = 0; k < 5; k++) {
            double f = hz(keys[k]), bc = -2, T = FS / f, cents;
            setup_ri(64, 32, 100, 80, 20);
            play(keys[k], y, 16384);
            best = 0;
            for (lag = (uint32_t)(T * 0.8); lag < (uint32_t)(T * 1.25); lag++) {
                double c = 0;
                for (j = 3000; j < 9000; j++)
                    c += y[j] * y[j + lag];
                if (c > bc) {
                    bc = c;
                    best = lag;
                }
            }
            cents = 1200 * log2(T / best);
            printf("   RINGS STRING key %u: period %.1f, found %u, %.1f cents\n", keys[k], T, best, cents);
            if (fabs(cents) > 40 && !(best > T * 0.99 && best < T * 1.01))
                ok = 0;
        }
        check("RINGS STRING plays the key (the period within 40 cents, or a sample, from key 33 to 81)", ok);
        for (w = 0; w < 2; w++) {
            a1 = a2 = 0;
            setup_ri(64, 32, 100, w ? 110 : 40, 20);
            play(57, y, FS);
            for (j = FS / 16; j < FS / 16 + 4096; j++)
                a1 += y[j] * y[j];
            for (j = FS / 2; j < FS / 2 + 4096; j++)
                a2 += y[j] * y[j];
            if (w)
                e_b = a2 / (a1 > 0 ? a1 : 1);
            else
                e_a = a2 / (a1 > 0 ? a1 : 1);
        }
        printf("   RINGS STRING energy at half a second over that at a sixteenth: %.5f at DAMPING 40, %.5f at DAMPING 110\n", e_a, e_b);
        check("RINGS STRING DAMPING lengthens the ring (the tail at 110 holds over 10x the energy of 40)", e_b > 10 * e_a && e_b > 0);
        f1 = hz(57);
        setup_ri(64, 32, 100, 100, 64);
        play(57, y, n);
        p_mid = tone_at(y, a, n, 2 * f1) / (tone_at(y, a, n, f1) + 1);
        setup_ri(64, 32, 100, 100, 32);
        play(57, y, n);
        p_q = tone_at(y, a, n, 4 * f1) / (tone_at(y, a, n, f1) + 1);
        w = (uint32_t)(tone_at(y, a, n, 2 * f1) / (tone_at(y, a, n, f1) + 1) * 1000);
        printf("   RINGS STRING 2f/f at POSITION 64: %.3f; at POSITION 32: 2f/f %.3f, 4f/f %.3f\n", p_mid, w / 1000.0, p_q);
        check("RINGS STRING POSITION is a comb (2f nearly gone in the middle, 4f at a quarter, 2f there is not)", p_mid < 0.15 && p_q < 0.15 && w > 4 * p_mid * 1000);
        for (st = 0; st <= 127; st += 32)
            for (br = 0; br <= 127; br += 64)
                for (dm = 0; dm <= 127; dm += 63)
                    for (ps = 0; ps <= 127; ps += 32)
                        for (k = 0; k < 3; k++) {
                            static const uint8_t kk[] = {24, 60, 108};
                            setup_ri(64, st, br, dm, ps);
                            play(kk[k], y, 8192);
                            for (j = 0; j < 8192; j++)
                                if (fabs(y[j]) > peak) {
                                    peak = fabs(y[j]);
                                    if (peak > 60000)
                                        printf("      peak %.0f at st %u br %u dm %u ps %u key %u\n", peak, st, br, dm, ps, kk[k]);
                                }
                        }
        printf("   RINGS STRING sweep: peak %.0f\n", peak);
        check("RINGS STRING sweep (STRUCTURE, BRIGHTNESS, DAMPING, POSITION, keys): bounded (peak under 65536)", peak < 65536);
    }

    /* 4r. RINGS (TYPE 14), SYMPA (E1 38) and QUANT (E1 114): the key's pitch, the second string's tuning is heard, bounded sweeps */
    {
        static const uint8_t keys[] = {45, 57, 69};
        static const uint8_t mdl[] = {38, 114};
        double peak = 0, r_oct, r_ref;
        uint32_t k, j, st, br, dm, ps, w, lag, best;
        int ok = 1;
        for (w = 0; w < 2; w++)
            for (k = 0; k < 3; k++) {
                double f = hz(keys[k]), bc = -2, T = FS / f, cents;
                setup_ri(mdl[w], 5, 100, 80, 20);
                play(keys[k], y, 16384);
                best = 0;
                for (lag = (uint32_t)(T * 0.8); lag < (uint32_t)(T * 1.25); lag++) {
                    double c = 0;
                    for (j = 3000; j < 9000; j++)
                        c += y[j] * y[j + lag];
                    if (c > bc) {
                        bc = c;
                        best = lag;
                    }
                }
                cents = 1200 * log2(T / best);
                printf("   RINGS %s key %u: period %.1f, found %u, %.1f cents\n", w ? "QUANT" : "SYMPA", keys[k], T, best, cents);
                if (fabs(cents) > 40)
                    ok = 0;
            }
        check("RINGS SYMPA and QUANT play the key (the period within 40 cents, keys 45 to 69)", ok);
        {
            double f1 = hz(57);
            setup_ri(114, 105, 100, 110, 64);                            /* chord 9: an octave up */
            play(57, y, FS);
            r_oct = tone_at(y + FS / 4, a, 16384, 2 * f1) / (tone_at(y + FS / 4, a, 16384, f1) + 1);
            setup_ri(114, 15, 100, 110, 64);                             /* chord 1: a second (2 st) */
            play(57, y, FS);
            r_ref = tone_at(y + FS / 4, a, 16384, 2 * f1) / (tone_at(y + FS / 4, a, 16384, f1) + 1);
            printf("   RINGS QUANT 2f/f in the tail: %.3f with the octave string, %.3f with a second\n", r_oct, r_ref);
            check("RINGS QUANT tunes the second string (the octave strengthens 2f in the tail)", r_oct > 1.2 * r_ref);
        }
        for (w = 0; w < 2; w++)
            for (st = 0; st <= 127; st += 21)
                for (br = 0; br <= 127; br += 63)
                    for (dm = 0; dm <= 127; dm += 63)
                        for (ps = 0; ps <= 127; ps += 32)
                            for (k = 0; k < 3; k++) {
                                static const uint8_t kk[] = {24, 60, 108};
                                setup_ri(mdl[w], st, br, dm, ps);
                                play(kk[k], y, 8192);
                                for (j = 0; j < 8192; j++)
                                    if (fabs(y[j]) > peak)
                                        peak = fabs(y[j]);
                            }
        printf("   RINGS SYMPA and QUANT sweep: peak %.0f\n", peak);
        check("RINGS SYMPA and QUANT sweep (STRUCTURE, BRIGHTNESS, DAMPING, POSITION, keys): bounded (peak under 65536)", peak < 65536);
    }

    /* 4s. FOLD on the fourth knob (the types that have no use of it): a sine gets its harmonics, 0 changes nothing, every such type stays bounded */
    {
        static const uint8_t types[] = {1, 2, 3, 4, 5, 6, 7, 9, 10, 11, 13};
        double f = hz(57), h0, h1, c1, peak = 0;
        uint32_t k, j, ty;
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_E0] = 1;
        play(57, y, n);
        h0 = tone_at(y, a, n, 3 * f);
        c1 = tone_at(y, a, n, f);
        setup(0, 0, 0, 127, 127);
        trk[0].p[P_E0] = 1;
        play(57, y, n);
        h1 = tone_at(y, a, n, 3 * f) + tone_at(y, a, n, 5 * f);
        printf("   FOLD on TWO OP FM (a sine at the key): 3f line %.0f without, 3f + 5f %.0f at 127 (key line %.0f)\n", h0, h1, c1);
        check("FOLD at 127 brings in odd harmonics a sine does not have (3f + 5f over 10 % of the key line)", h1 > 0.1 * c1 && h1 > 5 * h0);
        for (ty = 0; ty < sizeof types; ty++)
            for (k = 1; k <= 127; k += 63) {
                setup(64, 64, 64, k, 127);
                trk[0].p[P_E0] = types[ty];
                play(57, y, 8192);
                for (j = 0; j < 8192; j++)
                    if (fabs(y[j]) > peak)
                        peak = fabs(y[j]);
            }
        printf("   FOLD sweep over the 11 types: peak %.0f\n", peak);
        check("FOLD sweep (11 types, knob 1, 64, 127): bounded (peak under 65536)", peak < 65536);
    }

    /* 4t. THE NANO FREAK FILTER: CUT 20 Hz * 2^(10 cut / 127), TYPE, SLOPE, DRIVE, CLIP */
    {
        double f1 = hz(57), r_lo, r_hi, r12, r24, hp1, lp1, bp1, bp7, lp7, rs, rp, rr, sp, sq;
        uint32_t j, ty;
        double pk, ms;
#define SAWF(cut, res, type, slope, drive, clip) do { setup(0, 0, 0, 0, cut); trk[0].p[P_E6] = res; trk[0].p[P_FTYPE] = type; trk[0].p[P_ED_FX] = (int16_t)((slope) | (drive) << 1 | (clip) << 4); play(57, y, n); } while (0)
        SAWF(64, 0, 0, 0, 0, 0);
        r_lo = tone_at(y, a, n, 7 * f1) / (tone_at(y, a, n, f1) + 1);
        lp1 = tone_at(y, a, n, f1);
        SAWF(110, 0, 0, 0, 0, 0);
        r_hi = tone_at(y, a, n, 7 * f1) / (tone_at(y, a, n, f1) + 1);
        printf("   FILTER LP 12 dB: 7f / f %.3f at CUT 64 (659 Hz), %.3f at CUT 110 (4.6 kHz)\n", r_lo, r_hi);
        check("FILTER CUT follows 20 Hz * 2^(10 cut / 127): the 7th harmonic (1.5 kHz) falls at CUT 64 and stays at CUT 110", r_lo < 0.4 * r_hi);
        r12 = r_lo;
        SAWF(64, 0, 0, 1, 0, 0);
        r24 = tone_at(y, a, n, 7 * f1) / (tone_at(y, a, n, f1) + 1);
        printf("   FILTER LP 24 dB: 7f / f %.3f (12 dB: %.3f)\n", r24, r12);
        check("FILTER SLOPE 24 dB falls twice as fast (the 7th harmonic under 60 % of the 12 dB one)", r24 < 0.6 * r12);
        SAWF(64, 0, 2, 0, 0, 0);
        hp1 = tone_at(y, a, n, f1);
        SAWF(64, 0, 1, 0, 0, 0);
        bp1 = tone_at(y, a, n, f1);
        bp7 = tone_at(y, a, n, 7 * f1);
        printf("   FILTER at CUT 64: key line %.0f LP, %.0f HP, %.0f BP; 7f %.0f BP\n", lp1, hp1, bp1, bp7);
        check("FILTER TYPE: HP takes the key's low harmonic away (under 40 % of LP's) and BP is under LP's at both ends", hp1 < 0.4 * lp1 && bp1 < lp1 && bp7 < tone_at(y, a, n, 7 * f1) * 10);
        lp7 = tone_at(y, a, n, 7 * f1);
        SAWF(64, 120, 0, 0, 0, 0);
        rp = 0;
        for (j = 0; j < n; j++)
            if (fabs(y[j]) > rp)
                rp = fabs(y[j]);
        printf("   FILTER RES 120: peak %.0f\n", rp);
        check("FILTER RES 120 stays bounded", rp < 65536);
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_E0] = 1;
        trk[0].p[P_E5] = 127;
        play(57, y, n);
        rs = tone_at(y, a, n, 3 * f1) / (tone_at(y, a, n, f1) + 1);
        trk[0].p[P_ED_FX] = 7 << 1;
        play(57, y, n);
        rr = tone_at(y, a, n, 3 * f1) / (tone_at(y, a, n, f1) + 1);
        printf("   FILTER DRIVE on a sine: 3f / f %.4f off, %.4f at 127\n", rs, rr);
        check("FILTER DRIVE 127 saturates a sine into odd harmonics (3f over 5 % of the key line, 10x the dry)", rr > 0.05 && rr > 10 * rs);
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_E0] = 1;
        trk[0].p[P_E5] = 127;
        play(57, y, n);
        pk = ms = 0;
        for (j = 4096; j < n; j++) {
            ms += y[j] * y[j];
            if (fabs(y[j]) > pk)
                pk = fabs(y[j]);
        }
        sp = sqrt(ms / (n - 4096)) / (pk + 1);
        trk[0].p[P_ED_FX] = 7 << 4;
        play(57, y, n);
        pk = ms = 0;
        for (j = 4096; j < n; j++) {
            ms += y[j] * y[j];
            if (fabs(y[j]) > pk)
                pk = fabs(y[j]);
        }
        sq = sqrt(ms / (n - 4096)) / (pk + 1);
        printf("   FILTER CLIP on a sine: rms / peak %.3f off, %.3f at 127\n", sp, sq);
        check("FILTER CLIP 127 squares a sine (rms / peak from 0.7 up over 0.85)", sp < 0.75 && sq > 0.85);
        (void)ty;
        (void)lp7;
#undef SAWF
    }

    /* 4u. THE ENVELOPE: the test bed's laws: ATK linear 1 ms * 2^(v 12.3/127); DEC (and the release) 5 ms * 2^(v 11/127), 98 % of the way */
    {
        static double e[1 << 16];
        static int32_t b[CTL];
        uint32_t i, k, nb = (1u << 16) / CTL, pk = 0, t90 = 0, td = 0, tr = 0;
        double top = 0, ta, tdec, trel, wa, wd;
        /* attack 40: 14.7 ms: 90 % of the top at 0.9 of that */
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_E0] = 1;
        trk[0].p[P_ATK] = 40;
        trk[0].p[P_SUS] = 127;
        trk_note_on(&trk[0], 57, 127);
        for (i = 0; i < nb; i++) {
            double m = 0;
            track_render(&trk[0], b, CTL);
            for (k = 0; k < CTL; k++)
                if (fabs((double)b[k]) > m)
                    m = fabs((double)b[k]);
            e[i] = m;
            if (m > top)
                top = m;
        }
        for (i = 0; i < nb && e[i] < 0.9 * top; i++)
            ;
        t90 = i * CTL;
        wa = 0.9 * 0.001 * pow(2.0, 40 * 12.3 / 127) * FS;
        ta = (double)t90;
        /* decay 40 to sustain 0: 55 ms to 2 % */
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_E0] = 1;
        trk[0].p[P_DEC] = 40;
        trk[0].p[P_SUS] = 0;
        trk_note_on(&trk[0], 57, 127);
        top = 0;
        for (i = 0; i < nb; i++) {
            double m = 0;
            track_render(&trk[0], b, CTL);
            for (k = 0; k < CTL; k++)
                if (fabs((double)b[k]) > m)
                    m = fabs((double)b[k]);
            e[i] = m;
            if (m > top) {
                top = m;
                pk = i;
            }
        }
        for (i = pk; i < nb && e[i] > 0.02 * top; i++)
            ;
        td = (i - pk) * CTL;
        wd = 0.005 * pow(2.0, 40 * 11.0 / 127) * FS;
        tdec = (double)td;
        /* the release takes the DECAY's time too (REL is not used): note off at the sustain */
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_E0] = 1;
        trk[0].p[P_DEC] = 40;
        trk[0].p[P_REL] = 120;
        trk[0].p[P_SUS] = 127;
        trk_note_on(&trk[0], 57, 127);
        for (i = 0; i < 32; i++)
            track_render(&trk[0], b, CTL);
        trk_note_off(&trk[0], 57);
        top = 0;
        for (i = 0; i < nb; i++) {
            double m = 0;
            track_render(&trk[0], b, CTL);
            for (k = 0; k < CTL; k++)
                if (fabs((double)b[k]) > m)
                    m = fabs((double)b[k]);
            e[i] = m;
            if (i == 0)
                top = m;
        }
        for (i = 0; i < nb && e[i] > 0.02 * top; i++)
            ;
        tr = i * CTL;
        trel = (double)tr;
        printf("   ENVELOPE: ATK 40 90 %% at %.0f (want %.0f), DEC 40 to 2 %% at %.0f (want %.0f), release at %.0f\n", ta, wa, tdec, wd, trel);
        check("ENVELOPE ATK is linear and takes the test bed's time (90 % of the top within 10 % of 0.9 T)", fabs(ta - wa) < 0.1 * wa + CTL);
        check("ENVELOPE DEC falls to 2 % in the test bed's time (within 15 %)", fabs(tdec - wd) < 0.15 * wd + CTL);
        check("ENVELOPE release follows the DECAY knob (REL is not used): the time of DEC 40 within 15 %", fabs(trel - wd) < 0.15 * wd + CTL);
    }

    /* 4v. THE FILTER ENVELOPE: FLT (P_ED_FLT) is the test bed's FAMT: +-7 octaves, FLT 63 = 6.9 octaves of the cutoff at full level */
    {
        double f1 = hz(57), ra, rb, rn;
        setup(0, 0, 0, 0, 40);
        trk[0].p[P_ED_FLT] = 32;
        play(57, y, n);
        ra = tone_at(y, a, n, 7 * f1) / (tone_at(y, a, n, f1) + 1);
        setup(0, 0, 0, 0, 84);
        play(57, y, n);
        rb = tone_at(y, a, n, 7 * f1) / (tone_at(y, a, n, f1) + 1);
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_ED_FLT] = -64;
        play(57, y, n);
        rn = tone_at(y, a, n, 7 * f1) / (tone_at(y, a, n, f1) + 1);
        printf("   FILTER ENV: 7f / f %.3f at CUT 40 + FLT 32, %.3f at CUT 84; %.3f at CUT 127 with FLT -64\n", ra, rb, rn);
        check("FILTER ENV FLT 32 opens the cutoff by 32 * 89 / 64 = 44.5 dial units (the 7th harmonic as CUT 84, within 15 %)", fabs(ra - rb) < 0.15 * rb);
        check("FILTER ENV FLT -64 closes it by 5 octaves (the 7th harmonic under 40 % of the open one)", rn < 0.4 * rb);
    }

    /* 4w. THE CYCLING ENVELOPE (the matrix source CYC): RISE / FALL n^2.2 * 10 s, RUN loops, ENV follows the gate and holds HOLD's level */
    {
        static int32_t b[CTL];
        uint32_t i, up = 0, first = 0, t1 = 0, t2 = 0, nblk = 3 * FS / CTL;
        int32_t lv, top = 0;
        double want_rise = pow(20 / 127.0, 2.2) * 10.0, want_per = 2 * want_rise + pow(10 / 127.0, 2.2) * 10.0, got_rise, got_per, held, rel;
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_FM1_ATK] = 20;
        trk[0].p[P_FM1_DEC] = 20;
        trk[0].p[P_FM1_SUS] = 10;
        trk[0].p[P_FM1_REL] = 127;
        trk[0].p[P_FM1_LEVEL] = 1;
        for (i = 0; i < nblk; i++) {
            track_render(&trk[0], b, CTL);
            lv = mod_tsrc(&trk[0], MS_CYC, 0);
            if (lv > top)
                top = lv;
            if (!first && lv >= 32767 * 99 / 100)
                first = i;
            if (up == 0 && lv > 16384) {
                up = 1;
                if (!t1)
                    t1 = i;
                else if (!t2)
                    t2 = i;
            } else if (lv < 16384)
                up = 0;
        }
        got_rise = (double)first * CTL / FS;
        got_per = (double)(t2 - t1) * CTL / FS;
        printf("   CYC RUN: peak %d, rise %.3f s (want %.3f), period %.3f s (want %.3f)\n", (int)top, got_rise, want_rise, got_per, want_per);
        check("CYC RUN rises to AMOUNT in the test bed's RISE time (within 10 %)", top > 32000 && fabs(got_rise - want_rise) < 0.1 * want_rise + 0.003);
        check("CYC RUN loops with period RISE + HOLD + FALL (within 10 %)", t2 && fabs(got_per - want_per) < 0.1 * want_per + 0.003);
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_FM1_ATK] = 10;
        trk[0].p[P_FM1_DEC] = 10;
        trk[0].p[P_FM1_SUS] = 64;
        trk[0].p[P_FM1_REL] = 127;
        trk[0].p[P_FM1_LEVEL] = 0;
        for (i = 0; i < 200; i++)
            track_render(&trk[0], b, CTL);
        lv = mod_tsrc(&trk[0], MS_CYC, 0);
        check("CYC ENV is idle (0) with no note", lv == 0);
        trk_note_on(&trk[0], 57, 100);
        for (i = 0; i < 2000; i++)
            track_render(&trk[0], b, CTL);
        held = mod_tsrc(&trk[0], MS_CYC, 0) / 32767.0;
        trk_note_off(&trk[0], 57);
        for (i = 0; i < 2000; i++)
            track_render(&trk[0], b, CTL);
        rel = mod_tsrc(&trk[0], MS_CYC, 0) / 32767.0;
        printf("   CYC ENV: held %.3f (want %.3f), after the note %.3f\n", held, 64 / 127.0, rel);
        check("CYC ENV settles at HOLD's level while the note is held, and falls to 0 after it", fabs(held - 64 / 127.0) < 0.02 && rel < 0.01);
    }

    /* 4x. THE LFO: RATE 0.005 Hz * 2^(14.3 n), TRI from 0, GLD (a random glide), MORPH into the next shape */
    {
#if FELUCCA_CPU2
#define LFO_END(t) track_lfo_end(t)
#else
#define LFO_END(t) ((void)0)
#endif
        static int32_t b[CTL];
        uint32_t i, last = 0, nc = 0, first = 0, rate = 90;
        int32_t prev = 0, big = 0, v0, v1;
        double want = 1.0 / (0.005 * pow(2.0, rate / 127.0 * 14.3)), per;
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_LRATE] = rate;
        trk[0].p[P_LWAVE] = 0;
        trk[0].p[P_LFADE] = 0;
        for (i = 0; i < 3 * FS / CTL; i++) {
            track_render(&trk[0], b, CTL);
            LFO_END(&trk[0]);
            if (prev < 0 && trk[0].lfo_val >= 0 && i > 4) {
                if (!first)
                    first = i;
                last = i;
                nc++;
            }
            prev = trk[0].lfo_val;
        }
        per = nc > 1 ? (double)(last - first) * CTL / FS / (nc - 1) : 0;
        printf("   LFO RATE %u: period %.4f s (want %.4f)\n", rate, per, want);
        check("LFO RATE follows the test bed's 0.005 Hz * 2^(14.3 n) (the period within 3 %)", fabs(per - want) < 0.03 * want);
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_LRATE] = 0;
        trk[0].p[P_LWAVE] = 1;
        trk[0].lfo_ph = 0;
        track_render(&trk[0], b, CTL);
            LFO_END(&trk[0]);
        v0 = trk[0].lfo_val;
        trk[0].p[P_LWAVE] = 0;
        trk[0].p[P_FM2_ATK] = 127;                     /* SIN morphed all the way into TRI */
        trk[0].lfo_ph = 0x30000000u;
        track_render(&trk[0], b, CTL);
            LFO_END(&trk[0]);
        v1 = trk[0].lfo_val;
        trk[0].p[P_FM2_ATK] = 0;
        trk[0].p[P_LWAVE] = 1;
        trk[0].lfo_ph = 0x30000000u;
        track_render(&trk[0], b, CTL);
            LFO_END(&trk[0]);
        printf("   LFO TRI at phase 0: %d; SIN + MORPH 127 at 0.19: %d, TRI there: %d\n", (int)v0, (int)v1, (int)trk[0].lfo_val);
        check("LFO TRI starts at 0 (|v| under 5 % of full), and MORPH 127 turns SIN into TRI (within 3 %)", abs(v0) < 1700 && abs(v1 - trk[0].lfo_val) < 1000);
        setup(0, 0, 0, 0, 127);
        trk[0].p[P_LRATE] = 100;
        trk[0].p[P_LWAVE] = 5;
        for (i = 0; i < 2 * FS / CTL; i++) {
            track_render(&trk[0], b, CTL);
            LFO_END(&trk[0]);
            if (i > 100 && abs(trk[0].lfo_val - prev) > big)
                big = abs(trk[0].lfo_val - prev);
            prev = trk[0].lfo_val;
        }
        printf("   LFO GLD: largest step in a block %d\n", (int)big);
        check("LFO GLD glides (no step over 3000 in a block while S&H would jump)", big > 0 && big < 3000);
    }

    /* 4y. THE ARP, IMPRESS / CHANCE, THE CC MAP, MIDI OUT (nano_ctl.c): the arp's note sequences are the test bed's (nano_arp_table.h) */
    {
        static const uint8_t KEYS[3] = {64, 60, 67};
        static const uint8_t PAT_FW[14] = {1, 2, 3, 5, 4, 15, 16, 9, 10, 17, 18, 14, 19, 20};
        uint32_t r, bad = 0, ntest = 0, s2, i, k;
        char want[256];
        track_t *t = &trk[0];
        for (r = 0; r < NELEM(ARP_REF); r++) {
            uint32_t period, L = ARP_REF[r].len, v, got_ok = 1;
            char got[256] = "";
            setup(0, 0, 0, 0, 127);
            host_preset(t, ENGI_NANO, 0);
            for (v = 0; v < 128 && 1u + v * 15u / 127u != L; v++)
                ;
            t->p[P_AMODE] = PAT_FW[ARP_REF[r].pat];
            t->p[P_AOCT] = ARP_REF[r].range;
            t->p[P_ASWING] = 0;
            t->p[P_AHOLD] = 0;
            t->p[P_LN0] = (int16_t)v;
            t->p[P_LN1] = ARP_REF[r].rc;
            t->p[P_LN2] = ARP_REF[r].type;
            t->nheld = 0;
            t->arp_phys = 0;
            for (i = 0; i < (uint32_t)ARP_REF[r].nk; i++)
                arp_add(t, KEYS[i]);
            period = div_samples((uint32_t)t->p[P_ARATE]);
            for (s2 = 0; s2 < 24; s2++) {
                char b[8];
                arp_tick(t, period);
                snprintf(b, sizeof b, "%s%d", s2 ? " " : "", (int)t->arp_note);
                strcat(got, b);
            }
            snprintf(want, sizeof want, "%s", ARP_REF[r].seq);
            ntest++;
            if (strcmp(got, want)) {
                if (bad++ < 4)
                    printf("   ARP MISMATCH pat %d range %d len %d keys %d rc %d: got %s\n      want %s\n", ARP_REF[r].pat, ARP_REF[r].range, ARP_REF[r].len, ARP_REF[r].nk, ARP_REF[r].rc, got, want);
            }
            (void)got_ok;
        }
        printf("   ARP: %u of %u sequences differ from the test bed's\n", bad, ntest);
        check("ARP: UP DOWN UPDOWN ORDER ASPLAYED CONVERGE DIVERGE HOLLOW JEOPARDY BROKEN ALTERNATING, ranges 1-2, LENGTH, ARP CHORD match the test bed note for note", bad == 0);
        /* PATTERN: eight steps of dice repeating, rests and notes from the keys; RANDOM stays in the keys */
        {
            int seq[24], rests = 0, in_set = 1;
            setup(0, 0, 0, 0, 127);
            host_preset(t, ENGI_NANO, 0);
            t->p[P_LN1] = 0;                                  /* ARP CHORD off: the keys themselves are the list */
            t->p[P_AMODE] = 15;
            t->p[P_AOCT] = 1;
            t->p[P_ASWING] = 0;
            t->nheld = 0;
            t->arp_phys = 0;
            for (i = 0; i < 3; i++)
                arp_add(t, KEYS[i]);
            for (s2 = 0; s2 < 24; s2++) {
                arp_tick(t, div_samples((uint32_t)t->p[P_ARATE]));
                seq[s2] = t->arp_note;
                rests += !seq[s2];
                if (seq[s2] && seq[s2] != 60 && seq[s2] != 64 && seq[s2] != 67)
                    in_set = 0;
            }
            for (s2 = 0; s2 < 16; s2++)
                if (seq[s2] != seq[s2 + 8])
                    in_set = 0;
            printf("   ARP PATTERN: %d rests in 24 steps, repeats every 8: %d\n", rests, in_set);
            check("ARP PATTERN plays keys and rests, the same eight steps over and over", in_set && rests < 24);
        }
        /* ARP CHORD pattern: the keys together, an octave up per step; TYPE chord: each step's note is a chord's root */
        {
            uint32_t cnt1, cnt2, ok = 1;
            setup(0, 0, 0, 0, 127);
            host_preset(t, ENGI_NANO, 0);
            t->p[P_LN1] = 0;                                  /* ARP CHORD off: the keys themselves are the list */
            t->p[P_AMODE] = 14;
            t->p[P_AOCT] = 2;
            t->p[P_ASWING] = 0;
            t->nheld = 0;
            t->arp_phys = 0;
            for (i = 0; i < 3; i++)
                arp_add(t, KEYS[i]);
            arp_tick(t, div_samples((uint32_t)t->p[P_ARATE]));
            cnt1 = 1 + (t->arp_ch[0] != 0) + (t->arp_ch[1] != 0) + (t->arp_ch[2] != 0);
            arp_tick(t, div_samples((uint32_t)t->p[P_ARATE]));
            cnt2 = t->arp_note;
            printf("   ARP CHORD pattern: %u notes, then lowest %u\n", cnt1, cnt2);
            check("ARP CHORD pattern plays the held notes together and an octave up the next step", cnt1 == 3 && cnt2 == 72);
            setup(0, 0, 0, 0, 127);
            host_preset(t, ENGI_NANO, 0);
            t->p[P_AMODE] = 1;
            t->p[P_AOCT] = 1;
            t->p[P_ASWING] = 0;
            t->p[P_LN1] = 1;
            t->p[P_LN2] = 1;
            t->nheld = 0;
            t->arp_phys = 0;
            arp_add(t, 60);
            arp_tick(t, div_samples((uint32_t)t->p[P_ARATE]));
            ok = t->arp_note == 60 && t->arp_ch[0] == 64 && t->arp_ch[1] == 67 && t->arp_ch[2] == 72;
            check("ARP TYPE chord: each step plays the chord (Maj) on the pattern's note", ok);
        }
        /* IMPRESS / CHANCE: Impress 0 leaves the pattern as the test bed has it, even after a roll; Impress shortens and varies */
        {
            int left = 0, same = 1, shifted = 0;
            char a0[256] = "", a1[256] = "";
            for (k = 0; k < 2; k++) {
                setup(0, 0, 0, 0, 127);
                host_preset(t, ENGI_NANO, 0);
                t->p[P_AMODE] = 1;
                t->p[P_AOCT] = 1;
                t->p[P_ASWING] = 0;
                t->p[P_LN4] = 127;
                nano_poll(t);                          /* CHANCE 127: the dice roll */
                t->p[P_LN3] = k ? 127 : 0;
                t->nheld = 0;
                t->arp_phys = 0;
                for (i = 0; i < 3; i++)
                    arp_add(t, KEYS[i]);
                for (s2 = 0; s2 < 48; s2++) {
                    char b[8];
                    arp_tick(t, div_samples((uint32_t)t->p[P_ARATE]));
                    snprintf(b, sizeof b, "%d ", (int)t->arp_note);
                    strcat(k ? a1 : a0, b);
                }
            }
            for (i = 0; a0[i] && a1[i]; i++)
                (void)0;
            {
                int n0 = 0, n1 = 0, c0 = 0, c1 = 0;
                for (i = 0; a0[i]; i++)
                    n0 += a0[i] == '0' && (i == 0 || a0[i - 1] == ' ');
                for (i = 0; a1[i]; i++)
                    n1 += a1[i] == '0' && (i == 0 || a1[i - 1] == ' ');
                c0 = (int)strlen(a0);
                c1 = (int)strlen(a1);
                left = n1 - n0;
                same = strstr(a0, " 0 ") == 0 && n0 == 0;
                shifted = strchr(a1, '7') != 0 && c1 > 0 && c0 > 0 && strcmp(a0, a1) != 0;
            }
            printf("   IMPRESS: Impress 0 has no gaps: %d; Impress 127 leaves %d steps out of 48 out and changes the pattern: %d\n", same, left, shifted);
            check("IMPRESS 0 keeps every step; Impress 127 after a roll leaves some out and changes the sequence", same && left > 0 && shifted);
        }
        {
            int32_t some_gate = 0, some_oct = 0, vel_moved = 0;
            setup(0, 0, 0, 0, 127);
            host_preset(t, ENGI_NANO, 0);
            t->p[P_LN3] = 127;
            for (i = 0; i < 64; i++) {
                some_gate |= nv_gate(t, i, 64) < 5;
                some_oct |= nv_oct(t, i) != 0;
                vel_moved |= nv_vel(t, i, 100) != 100;
            }
            t->p[P_LN3] = 0;
            check("IMPRESS 127: some step's gate drops out, some octave moves, some velocity changes", some_gate && some_oct && vel_moved);
            check("IMPRESS 0: gate, velocity and octave are the written ones", nv_gate(t, 3, 64) == 64 && nv_vel(t, 3, 100) == 100 && nv_oct(t, 3) == 0);
        }
        /* the CC map: each CC the table has takes a value in and gives it back */
        {
            uint32_t n = 0, ok = 0;
            static const uint8_t VALS[3] = {0, 64, 127};
            setup(0, 0, 0, 0, 127);
            host_preset(t, ENGI_NANO, 0);
            for (k = 0; k < NELEM(nano_cc); k++) {
                uint32_t vi;
                int good = 1;
                if (nano_cc[k].kind == NC_TRANSP || nano_cc[k].kind == NC_BPM)
                    continue;
                for (vi = 0; vi < 3; vi++) {
                    int32_t back;
                    int16_t before[P_COUNT];
                    memcpy(before, t->p, sizeof before);
                    nano_cc_in(t, nano_cc[k].cc, VALS[vi]);
                    back = nano_ctl_get(t, k);
                    {
                        int16_t keep[P_COUNT];
                        memcpy(keep, t->p, sizeof keep);
                        nano_cc_in(t, nano_cc[k].cc, (uint32_t)back);
                        if (memcmp(keep, t->p, sizeof keep))
                            good = 0;
                    }
                }
                n++;
                ok += good;
            }
            printf("   CC MAP: %u of %u controls give back what they were set to\n", ok, n);
            check("CC MAP: every control's value, read back as a CC and applied again, leaves the parameter as it was", ok == n);
            nano_cc_in(t, 23, 127);
            check("CC 23 is the cutoff (E5) to its full value", t->p[P_E5] == 127);
            nano_cc_in(t, 26, 0);
            check("CC 26 is the filter envelope amount: 0 is -64, 127 is +63", t->p[P_ED_FLT] == -64);
            nano_cc_in(t, 26, 127);
            check("CC 26 at 127 is +63", t->p[P_ED_FLT] == 63);
            nano_cc_in(t, 19, 127);
            nano_cc_in(t, 18, 127);
            nano_cc_in(t, 20, 127);
            check("CC 18 19 20: SLOPE, DRIVE and CLIP are the bits of the FX parameter (127 -> 0x7F)", (t->p[P_ED_FX] & 0x7F) == 0x7F);
            nano_cc_in(t, 17, 127);
            check("CC 17 at 127: the filter is HP", t->p[P_FTYPE] == 2);
            nano_cc_in(t, 73, 127);
            check("CC 73 at 127: the last arp pattern, ALTERNATING", t->p[P_AMODE] == 20);
            nano_cc_in(t, 3, 100);
            nano_poll(t);
            check("CC 3 is CHANCE", t->p[P_LN4] == 100 && t->nano_ch == 100);
            check("a CC that is not in the map is not taken", nano_cc_in(t, 1, 5) == 0);
        }
        /* CC out: a change of a control queues its CC; MIDI out: the arp's notes go out, and MIDI only keeps them quiet here */
        {
            uint32_t w0, packet, n_on = 0, q0;
            setup(0, 0, 0, 0, 127);
            host_preset(t, ENGI_NANO, 0);
            t->p[P_E5] = 127;
            fm_cc_out = 0;
            w0 = nco_w;
            nano_cc_out(t, P_E5);
            check("CC out: nothing queued while it is off", nco_w == w0);
            fm_cc_out = 1;
            nano_cc_out(t, P_E5);
            packet = nco_q[w0 % NCO_Q];
            printf("   CC OUT packet %08X\n", packet);
            check("CC out: a cutoff change queues CC 23 with its value 127 on the part's channel", nco_w == w0 + 1 && ((packet >> 16) & 0xFF) == 23 && (packet >> 24) == 127 && (packet & 0xFF) == 0x0B);
            usb.config = 1;
            q0 = mo_w - mo_r;
            nano_cc_flush();
            check("CC out: the audio side sends what was queued", nco_r == nco_w && mo_w - mo_r == q0 + 1);
            fm_cc_out = 0;
            t->p[P_AMODE] = 1;
            t->p[P_ASWING] = 0;
            t->nheld = 0;
            t->arp_phys = 0;
            fm_seq_out = 1;
            arp_add(t, 60);
            q0 = mo_w - mo_r;
            arp_tick(t, div_samples((uint32_t)t->p[P_ARATE]));
            for (i = 0; i < NVOICE; i++)
                n_on += t->v[i].active;
            check("MIDI out BOTH: the arp's note goes out and sounds here", mo_w - mo_r == q0 + 1 && n_on > 0);
            fm_seq_out = 2;
            setup(0, 0, 0, 0, 127);
            host_preset(t, ENGI_NANO, 0);
            t->p[P_AMODE] = 1;
            t->p[P_ASWING] = 0;
            t->nheld = 0;
            t->arp_phys = 0;
            arp_add(t, 62);
            q0 = mo_w - mo_r;
            arp_tick(t, div_samples((uint32_t)t->p[P_ARATE]));
            n_on = 0;
            for (i = 0; i < NVOICE; i++)
                n_on += t->v[i].active;
            check("MIDI out MIDI only: the note goes out and is silent here", mo_w - mo_r == q0 + 1 && n_on == 0);
            fm_seq_out = 0;
            usb.config = 0;
        }
    }

    /* 4z. THE SEQUENCER with IMPRESS: Impress 0 plays every step as written; Impress 127 after a roll leaves steps out and moves some */
    {
        uint32_t run, n[2] = {0, 0}, moved = 0, shifted_notes = 0, i, b, blocks;
        track_t *t = &trk[0];
        for (run = 0; run < 2; run++) {
            setup(0, 0, 0, 0, 127);
            host_preset(t, ENGI_NANO, 0);
            t->p[P_SLEN] = 16;
            t->p[P_SDIV] = 2;
            t->p[P_SGATE] = 64;
            for (i = 0; i < 16u; i++)
                t->step[i] = (step_t){{(uint8_t)(60 + i % 5)}, 1, ST_NOTE, 0, 100};
            t->p[P_LN4] = 127;
            nano_poll(t);
            t->p[P_LN3] = run ? 127 : 0;
            blocks = 4u * 16u * div_samples(2) / CTL;
            seq_start();
            for (b = 0; b < blocks; b++) {
                uint32_t v0 = vage;
                seq_tick(t, CTL);
                for (; v0 < vage; v0++) {
                    n[run]++;
                    for (i = 0; i < NVOICE; i++)
                        if (t->v[i].age == v0 + 1u) {
                            if (t->v[i].note < 60 || t->v[i].note > 64)
                                shifted_notes++;
                        }
                }
            }
            seq_stop();
        }
        (void)moved;
        printf("   SEQ IMPRESS: %u note-ons in 4 bars at Impress 0, %u at Impress 127 (%u of them off the written notes)\n", n[0], n[1], shifted_notes);
        check("SEQ: Impress 0 plays all 64 steps as written", n[0] == 64);
        check("SEQ: Impress 127 after a roll leaves steps out and moves notes by octaves", n[1] < 64 && n[1] > 20 && shifted_notes > 0);
    {
        track_t *t = &trk[0];
        uint32_t s2, i;
        /* ONE KEY, as a sound loads: the key is the root and the arp plays four different pitches over it (UP, DOWN, UPDOWN; 1 octave) */
        {
            static const uint8_t PM[3] = {1, 2, 3};          /* UP, DOWN, UPDOWN (the framework's numbers, as PAT_FW) */
            uint32_t pi, root, ok = 1;
            for (pi = 0; pi < 3; pi++) for (root = 48; root <= 72; root += 12) {
                int seen[8], nseen = 0, st;
                setup(0, 0, 0, 0, 127);
                host_preset(t, ENGI_NANO, 0);
                if (t->p[P_LN1] != 1) ok = 0;
                t->p[P_AMODE] = PM[pi]; t->p[P_AOCT] = 1; t->p[P_ASWING] = 0; t->p[P_AHOLD] = 0; t->p[P_LN0] = 127 * 3 / 15 + 1;   /* 4 steps */
                t->nheld = 0; t->arp_phys = 0;
                arp_add(t, root);
                for (s2 = 0; s2 < 8; s2++) {
                    arp_tick(t, div_samples((uint32_t)t->p[P_ARATE]));
                    for (st = 0, i = 0; i < (uint32_t)nseen; i++) st |= seen[i] == t->arp_note;
                    if (!st && nseen < 8) seen[nseen++] = t->arp_note;
                }
                if (nseen < 4 || (pi == 0 && (seen[0] != (int)root))) ok = 0;
            }
            check("ARP ONE KEY: UP / DOWN / UPDOWN, 1 octave, 4 steps play four different pitches built on the key (ARP CHORD MAJ on a load)", ok);

        /* a second key moves the whole pattern to it (the newest key is the root); ORDER and AS PLAYED play the keys themselves */
        {
            static const uint8_t MODES[4] = {AM_UP, AM_ORD, AM_RND, AM_ASPL};
            uint32_t mi, ok2 = 1;
            for (mi = 0; mi < 4; mi++) {
                uint32_t bad_old = 0, bad_new = 0, only_keys = 1, got67 = 0;
                setup(0, 0, 0, 0, 127);
                host_preset(t, ENGI_NANO, 0);
                t->p[P_AMODE] = MODES[mi]; t->p[P_AOCT] = 1; t->p[P_ASWING] = 0; t->p[P_AHOLD] = 0; t->p[P_LN0] = 127;   /* 16 steps */
                t->nheld = 0; t->arp_phys = 0;
                arp_add(t, 60);
                arp_add(t, 67);
                for (s2 = 0; s2 < 24; s2++) {
                    arp_tick(t, div_samples((uint32_t)t->p[P_ARATE]));
                    if (!t->arp_note) continue;
                    if (t->arp_note != 60 && t->arp_note != 67) only_keys = 0;
                    if (t->arp_note == 71 || t->arp_note == 74 || t->arp_note == 79) got67 = 1;
                    if (t->arp_note == 64 || t->arp_note == 72) bad_old = 1;   /* the MAJ chord on 60 (E, C+1) */
                    if (t->arp_note < 67 && t->arp_note != 60) bad_new = 1;
                }
                if (MODES[mi] == AM_ORD || MODES[mi] == AM_ASPL) { if (!only_keys || got67) ok2 = 0; }
                else if (bad_old || !got67 || bad_new) ok2 = 0;
                if (!ok2) printf("   mode %u: only_keys %u got67 %u bad_old %u bad_new %u\n", MODES[mi], only_keys, got67, bad_old, bad_new);
            }
            check("ARP ROOT: a second key moves the whole pattern to it (UP, RANDOM); ORDER and AS PLAYED play the keys as pressed", ok2);
        }
        }
    }
    }

    /* 5. a sweep: bounded, no DC, no click; a note-off falls silent */
    {
        double peak = 0, step = 0, dc = 0, tail = 0;
        uint32_t morph, sym, sub, sync, cut, cnt = 0;
        for (morph = 0; morph <= 127; morph += 31)
            for (sym = 0; sym <= 127; sym += 43)
                for (sub = 0; sub <= 127; sub += 127)
                    for (sync = 0; sync <= 127; sync += 21)
                        for (cut = 40; cut <= 127; cut += 43) {
                            static const uint8_t keys[] = {24, 48, 69, 96, 108};
                            uint32_t kk = (cnt++) % 5u, j;
                            setup(morph, sym, sub, sync, cut);
                            play(keys[kk], y, 8192);
                            for (j = 2048; j < 8192; j++) {
                                double ay = fabs(y[j]);
                                if (ay > peak)
                                    peak = ay;
                                if (fabs(y[j] - y[j - 1]) > step)
                                    step = fabs(y[j] - y[j - 1]);
                                dc += y[j];
                            }
                        }
        dc /= (double)cnt * 6144;
        {
            static int32_t b[CTL];
            setup(127, 0, 127, 64, 127);
            trk_note_on(&trk[0], 60, 100);
            for (i = 0; i < 20; i++)
                track_render(&trk[0], b, CTL);
            trk_note_off(&trk[0], 60);
            for (i = 0; i < 400; i++)
                track_render(&trk[0], b, CTL);
            for (i = 0; i < CTL; i++)
                tail += fabs((double)b[i]);
        }
        printf("   sweep of %u settings: peak %.0f, largest step %.0f, mean %.1f, tail after note-off %.1f\n", cnt, peak, step, dc, tail);
        check("the sweep stays bounded (a narrow pulse peaks high, as in the test bed, but stays under twice full scale)", peak < 65536.0);
        check("no DC (the mean is under 2 % of the peak)", fabs(dc) < 0.02 * peak);
        check("no click: the largest step between two samples is under 80 % of the peak", step < 0.8 * peak);
        check("a note-off falls silent", tail < 1.0);
    }

    /* 6. every preset sounds */
    for (i = 0, ok = 1; i < NELEM(NANO_PRESETS); i++) {
        double e = 0;
        uint32_t j;
        memset(trk, 0, sizeof trk);
        memset(eng_mem, 0, sizeof eng_mem);
        host_tracks_init();
        host_preset(&trk[0], ENGI_NANO, i);
        play(48, y, 8192);
        for (j = 2048; j < 8192; j++)
            e += y[j] * y[j];
        printf("   preset %u %-10s rms %.0f\n", i, NANO_PRESETS[i].name, sqrt(e / 6144));
        if (sqrt(e / 6144) < 1000)
            ok = 0;
    }
    check("every preset makes sound", ok);
    return bad;
}
