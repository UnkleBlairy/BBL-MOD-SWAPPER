#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Strokes synthesised, for the instruments the kit has no recording of: the djembe's and the udu's (a few decaying
partials, as a drum head or a clay pot rings, over a short noise of the hand), the berimbau's and its caxixi's. For the strokes the kit has no recording of: writes 16-bit mono WAVs at 44100 Hz into
the kit's folder (tools/kit.py makes the firmware's samples from them).

  synth.py [NAME ...] [--out app/kit]     the strokes named, or else those the kit's folder has no WAV for

  djembe_bass   the shell's air (Helmholtz, ~75 Hz) and the head's low mode: the palm flat in the centre
  djembe_tone   the head's modes from ~370 Hz: fingers together at the edge
  djembe_slap   the high modes and a crack of noise: fingers loose at the edge
  udu_bass      the pot's air through the side hole, its pitch rising as the palm leaves the hole
  udu_tone      the clay's modes: fingers on the belly
  udu_slap      a short pop on the top opening
  berimbau_dom  the steel wire struck open (solto), the gourd's air under it
  berimbau_dim  the stone pressed on the wire (preso): a tone higher, shorter
  berimbau_tsch the stone resting lightly on it (chiado): a short buzz
  caxixi_shake_1, caxixi_shake_2   the basket rattle, forward and back
  agogo_high, agogo_low   the two iron bells struck by the stick: a cone's inharmonic partials, the strike's click
  pandeiro_tum  the thumb at the head's edge: its low boom, the jingles (platinelas) a little
  pandeiro_pa   the open hand's slap: the head's high modes, a crack, the jingles loud
  pandeiro_chia the jingles alone, the frame shaken
  atabaque_tum  the tall drum's bass: its long body's air, deep and long
  atabaque_pa   its open tone: the head's modes from ~250 Hz, ringing longer than the djembe's
  reco_scrape   the stick along the reco-reco's notches: a quick train of clicks through its resonance
Needs numpy."""
import argparse
import wave
from pathlib import Path

import numpy as np

SR = 44100
rng = np.random.default_rng(1)            # the same strokes at every run


def t_of(dur):
    return np.arange(int(dur * SR)) / SR


def partial(dur, f0, f1, glide, amp, tau, t0=0.0):
    """a decaying sine whose frequency goes from f0 to f1 (exponentially, time constant glide), from t0"""
    t = t_of(dur)
    f = f1 + (f0 - f1) * np.exp(-t / glide) if glide > 0 else np.full_like(t, f0)
    ph = 2 * np.pi * np.cumsum(f) / SR
    y = amp * np.sin(ph) * np.exp(-t / tau)
    if t0:
        y = np.concatenate([np.zeros(int(t0 * SR)), y])[:len(t)]
    return y


def noise(dur, lo, hi, amp, tau):
    """noise between lo and hi Hz (FFT band-pass), decaying"""
    n = int(dur * SR)
    sp = np.fft.rfft(rng.standard_normal(n))
    f = np.fft.rfftfreq(n, 1 / SR)
    sp[(f < lo) | (f > hi)] = 0
    y = np.fft.irfft(sp, n)
    y /= np.abs(y).max() + 1e-12
    return amp * y * np.exp(-t_of(dur) / tau)


def attack(y, ms):
    """a soft start (a half cosine over ms): no click"""
    n = int(ms * SR / 1000)
    y[:n] *= 0.5 - 0.5 * np.cos(np.linspace(0, np.pi, n))
    return y


def mix(*parts):
    n = max(len(p) for p in parts)
    y = np.zeros(n)
    for p in parts:
        y[:len(p)] += p
    return y


def djembe_bass():
    d = 0.6
    return attack(mix(partial(d, 92, 74, 0.05, 1.0, 0.17),          # the shell's air
                      partial(d, 230, 205, 0.03, 0.35, 0.05),       # the head's lowest mode
                      partial(d, 148, 140, 0.03, 0.2, 0.08),
                      noise(d, 60, 900, 0.25, 0.012)), 1.5)        # the palm


def djembe_tone():
    d = 0.45
    f = 372
    modes = [(1.0, 1.0, 0.13), (1.59, 0.45, 0.08), (2.14, 0.32, 0.06), (2.30, 0.22, 0.05), (2.65, 0.14, 0.04),
             (2.92, 0.08, 0.03)]                                    # a circular head's modes: ratio, level, decay
    return attack(mix(*[partial(d, f * r * 1.025, f * r, 0.03, a, tau) for r, a, tau in modes],
                      partial(d, 80, 76, 0.05, 0.12, 0.1),          # a little of the shell's air
                      noise(d, 1500, 6000, 0.12, 0.006)), 0.8)


def djembe_slap():
    d = 0.32
    f = 390
    modes = [(1.0, 0.45, 0.06), (2.30, 0.5, 0.045), (3.5, 0.5, 0.035), (4.6, 0.4, 0.03), (6.1, 0.3, 0.025),
             (7.4, 0.22, 0.02)]
    return attack(mix(*[partial(d, f * r * 1.03, f * r, 0.015, a, tau) for r, a, tau in modes],
                      noise(d, 1200, 9000, 0.9, 0.018),             # the crack of the fingers
                      noise(d, 3000, 12000, 0.35, 0.006)), 0.3)


def udu_bass():
    d = 0.9
    return attack(mix(partial(d, 68, 112, 0.09, 1.0, 0.28),         # the air in the pot, the hole opening
                      partial(d, 136, 224, 0.09, 0.14, 0.18),
                      noise(d, 40, 400, 0.18, 0.03)), 6.0)          # the puff through the hole


def udu_tone():
    d = 0.45
    modes = [(430, 1.0, 0.09), (775, 0.55, 0.06), (1160, 0.35, 0.045), (1690, 0.22, 0.03), (2380, 0.12, 0.02)]
    return attack(mix(*[partial(d, f * 1.01, f, 0.02, a, tau) for f, a, tau in modes],
                      partial(d, 108, 108, 0, 0.25, 0.12),          # the air answers a little
                      noise(d, 800, 5000, 0.18, 0.005)), 0.6)


def udu_slap():
    d = 0.35
    return attack(mix(partial(d, 165, 230, 0.03, 1.0, 0.07),        # the top opening's air, short
                      partial(d, 520, 500, 0.02, 0.35, 0.03),
                      noise(d, 300, 4000, 0.45, 0.008)), 0.5)


def bandpass(y, f, q):
    """a resonance: a biquad band-pass (constant peak gain), as the gourd is"""
    w = 2 * np.pi * f / SR
    al = np.sin(w) / (2 * q)
    b0, b2, a0, a1, a2 = al, -al, 1 + al, -2 * np.cos(w), 1 - al
    out = np.zeros_like(y)
    x1 = x2 = y1 = y2 = 0.0
    for i, x in enumerate(y):
        v = (b0 * x + b2 * x2 - a1 * y1 - a2 * y2) / a0
        x2, x1, y2, y1 = x1, x, y1, v
        out[i] = v
    return out


def wire(d, f0, ring, damp, bright):
    """the steel wire struck near its end by the stick: its partials a little stretched (stiffness), the higher ones
    dying sooner, the gourd's resonance under them, the stick's click on top"""
    t = t_of(d)
    y = np.zeros_like(t)
    for k in range(1, 48):
        fk = k * f0 * np.sqrt(1 + 0.00012 * k * k)
        if fk > SR * 0.45:
            break
        a = k ** -0.7 * (1.0 + bright * (k >= 5))
        y += a * np.sin(2 * np.pi * fk * t + rng.uniform(0, 6.28)) * np.exp(-t / (ring / (1 + damp * (k - 1))))
    y = 0.55 * y + 1.6 * bandpass(y, 380.0, 3.0)
    return attack(mix(y / np.abs(y).max(), noise(d, 1800, 7000, 0.35, 0.003)), 0.4)


def berimbau_dom():
    return wire(0.8, 110.0, 0.9, 0.05, 0.3)


def berimbau_dim():
    return wire(0.5, 110.0 * 2 ** (2 / 12), 0.42, 0.11, 0.6)


def berimbau_tsch():
    d = 0.15
    t = t_of(d)
    buzz = noise(d, 1500, 6500, 1.0, 0.035) * (0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 110.0 * t)))   # the coin rattling
    return attack(mix(0.5 * wire(d, 110.0, 0.05, 0.3, 0.8), buzz), 0.3)


def shake(d, grains, amp, tau):
    """the seeds hitting the basket: short grains of bright noise, close together"""
    n = int(d * SR)
    y = np.zeros(n)
    for _ in range(grains):
        at = int(abs(rng.normal(0.010, 0.008)) * SR)
        g = noise(0.02, 3000, 11000, amp * rng.uniform(0.4, 1.0), 0.004)
        y[at:at + len(g)] += g[:max(0, n - at)]
    return attack(y * np.exp(-t_of(d) / tau), 0.3)


def caxixi_shake_1():
    return shake(0.12, 26, 1.0, 0.045)


def caxixi_shake_2():
    return shake(0.10, 16, 0.6, 0.035)


def bell(f, d):
    """an agogo's iron cone struck: its inharmonic partials (the higher ones dying sooner), the stick's click"""
    parts = [(1.0, 1.0, 0.42), (2.71, 0.45, 0.15), (4.65, 0.25, 0.08), (6.3, 0.12, 0.05), (8.1, 0.06, 0.03)]
    return attack(mix(*[partial(d, f * r, f * r, 0, a, tau) for r, a, tau in parts],
                      noise(d, 2000, 9000, 0.25, 0.003)), 0.2)


def agogo_high():
    return bell(1060.0, 0.6)


def agogo_low():
    return bell(760.0, 0.7)


def jingles(d, n, amp):
    """the pandeiro's platinelas: pairs of small cymbals, each a few high inharmonic partials, struck a little apart"""
    y = np.zeros(int(d * SR))
    for _ in range(n):
        at = int(abs(rng.normal(0.004, 0.006)) * SR)
        f = rng.uniform(3200, 5200)
        j = mix(*[partial(d, f * r, f * r, 0, amp * rng.uniform(0.4, 1.0) * a, rng.uniform(0.03, 0.07))
                  for r, a in ((1.0, 1.0), (1.47, 0.6), (2.09, 0.4))],
                noise(d, 5000, 12000, amp * 0.5, 0.004))
        y[at:] += j[:len(y) - at]
    return y


def pandeiro_tum():
    d = 0.45
    return attack(mix(partial(d, 132, 112, 0.04, 1.0, 0.16),        # the head's low mode, the thumb leaving it
                      partial(d, 270, 250, 0.03, 0.25, 0.06),
                      noise(d, 80, 1200, 0.2, 0.01),
                      jingles(d, 6, 0.12)), 1.0)


def pandeiro_pa():
    d = 0.35
    modes = [(1.0, 0.5, 0.05), (1.59, 0.45, 0.04), (2.14, 0.4, 0.03), (2.65, 0.3, 0.025), (3.5, 0.2, 0.02)]
    return attack(mix(*[partial(d, 420 * r * 1.03, 420 * r, 0.01, a, tau) for r, a, tau in modes],
                      noise(d, 1200, 8000, 0.7, 0.012),             # the slap's crack
                      jingles(d, 10, 0.35)), 0.3)


def pandeiro_chia():
    return attack(jingles(0.2, 12, 0.4), 1.5)


def atabaque_tum():
    d = 0.75
    return attack(mix(partial(d, 82, 64, 0.06, 1.0, 0.26),          # the long body's air
                      partial(d, 175, 158, 0.04, 0.35, 0.09),       # the head's lowest mode
                      partial(d, 120, 116, 0.04, 0.2, 0.12),
                      noise(d, 50, 700, 0.22, 0.014)), 2.0)        # the palm


def atabaque_pa():
    d = 0.55
    f = 252
    modes = [(1.0, 1.0, 0.2), (1.59, 0.45, 0.12), (2.14, 0.3, 0.08), (2.30, 0.2, 0.07), (2.65, 0.12, 0.05)]
    return attack(mix(*[partial(d, f * r * 1.02, f * r, 0.03, a, tau) for r, a, tau in modes],
                      partial(d, 66, 64, 0.05, 0.12, 0.15),
                      noise(d, 1200, 5000, 0.12, 0.006)), 0.8)


def reco_scrape():
    """the stick along the notches: about forty a second, a little faster as the stroke goes, each a click that sets
    the body ringing"""
    d = 0.28
    y = np.zeros(int(d * SR))
    t, k = 0.0, 0
    while t < 0.22:
        c = noise(0.02, 1500, 9000, rng.uniform(0.6, 1.0), 0.0025)
        at = int(t * SR)
        y[at:at + len(c)] += c[:len(y) - at]
        t += 1 / (34 + 1.2 * k)
        k += 1
    y = 0.5 * y + 1.2 * bandpass(y, 1350.0, 4.0) + 0.6 * bandpass(y, 3100.0, 5.0)
    return attack(y * np.exp(-t_of(d) / 0.2), 0.3)


STROKES = {"djembe_bass": djembe_bass, "djembe_tone": djembe_tone, "djembe_slap": djembe_slap,
           "udu_bass": udu_bass, "udu_tone": udu_tone, "udu_slap": udu_slap,
           "berimbau_dom": berimbau_dom, "berimbau_dim": berimbau_dim, "berimbau_tsch": berimbau_tsch,
           "caxixi_shake_1": caxixi_shake_1, "caxixi_shake_2": caxixi_shake_2,
           "agogo_high": agogo_high, "agogo_low": agogo_low, "pandeiro_tum": pandeiro_tum, "pandeiro_pa": pandeiro_pa,
           "pandeiro_chia": pandeiro_chia, "atabaque_tum": atabaque_tum, "atabaque_pa": atabaque_pa,
           "reco_scrape": reco_scrape}


def write(path, y):
    y = y / (np.abs(y).max() + 1e-12) * 0.89                       # -1 dBFS
    fade = int(0.03 * SR)
    y[-fade:] *= np.linspace(1, 0, fade)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((y * 32767).astype("<i2").tobytes())


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("names", nargs="*", choices=[[]] + list(STROKES), metavar="NAME")
    ap.add_argument("--out", type=Path, default=Path(__file__).resolve().parent.parent / "kit")
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    for name in a.names or [n for n in STROKES if not (a.out / f"{n}.wav").exists()]:
        write(a.out / f"{name}.wav", STROKES[name]())
        print(f"{a.out / name}.wav")


if __name__ == "__main__":
    main()
