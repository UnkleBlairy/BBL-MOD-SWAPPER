ARTIHIVE 2.0.6 for the BBL Mod Swapper

Original by KHAVld: https://github.com/KHAVld/ARTIHIVE
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: ARTIHIVE-source.zip on the ports page.
