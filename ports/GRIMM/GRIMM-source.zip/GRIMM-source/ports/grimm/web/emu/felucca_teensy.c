/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: GR!MM 2.0 (https://github.com/GRiMMBIENT/grimm) on the Teensy 4.1: its own browser build (firmware/src/grimm.c) inside ports/common's shell */
#ifdef __arm__                          /* (the FM-1's clang: uint32_t is unsigned int; newlib's is unsigned long) */
#undef __UINT32_TYPE__
#undef __INT32_TYPE__
#define __UINT32_TYPE__ unsigned int
#define __INT32_TYPE__ int
#endif
#include "../../../common/shell_pre.h"
#include <stdlib.h>
#include <time.h>
#ifndef CLOCK_MONOTONIC
#define CLOCK_MONOTONIC 1
static int clock_gettime(int c, struct timespec *t) { (void)c; t->tv_sec = 0; t->tv_nsec = 0; return 0; }
#endif
#define getenv(n) ((char *)0)
#define import_module(a) used
#define import_name(a) used
#include "../../../common/coro.h"
static void web_yield_(void) { co_yield(); }
#define web_yield web_yield_
#define web_boot o_web_boot
#define web_out_l o_web_out_l
#define web_out_r o_web_out_r
#define web_render o_web_render
#define web_buttons o_web_buttons
#define web_keys o_web_keys
#define web_enc o_web_enc
#define web_master o_web_master
#define web_nor_erase o_web_nor_erase
#define web_ms o_web_ms
#define web_frame o_web_frame
#include "../../firmware/src/grimm.c"
#undef __attribute__
#undef EXPORT
#undef memset
#undef memcpy
#undef memcmp
#undef memmove
#undef web_boot
#undef web_out_l
#undef web_out_r
#undef web_render
#undef web_buttons
#undef web_keys
#undef web_enc
#undef web_master
#undef web_nor_erase
#undef web_ms
#undef web_frame
#define SH_FLOAT
#define SH_OUT_L o_web_out_l
#define SH_OUT_R o_web_out_r
#define SH_RENDERF(n) sh_gr(n)
#define SH_ADC(m) o_web_master(m)
static void SH_BOOT(void) { co_start(web_run); }
static void SH_FRAME(uint32_t ms)
{ (void)ms; }
static uint32_t sh_raw_m;
#define SH_BTN(i, d) (sh_raw_m = (sh_raw_m & ~(1u << (i))) | (uint32_t)(d) << (i), o_web_buttons(sh_raw_m))
#define SH_ENC(e, n) o_web_enc((e), (n))
static uint32_t sh_keys_m;
#define SH_KEY(k, d) (sh_keys_m = (sh_keys_m & ~(1u << (k))) | (uint32_t)(d) << (k), o_web_keys(sh_keys_m))
#define SH_KEY_LED(k) (web_lit_keys() >> (k) & 1u ? 2 : 0)
#define SH_BTN_LED(i) (web_lit_buttons() >> (i) & 1u ? 2 : 0)
static void sh_gr(uint32_t n)
{
    web_want_frames(n);
    while (!web_ready()) co_resume();
    web_take();
}
#include "../../../common/shell_post.h"
