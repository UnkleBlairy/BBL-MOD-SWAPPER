# FMav-1

**A semi-modular monophonic synthesizer for the M-VAVE FM-1.** One VCO (saw > pulse, pulse width, PWM), a four-pole
transistor ladder filter that self-oscillates, an LFO (0.165 .. 550 Hz, triangle > square, or locked to the MIDI clock),
an ADSR, a VCA with its MODE switch (EG / ON), a keyboard with low-note priority, legato triggering, glide and KB SCALE,
a wave folder, a sample & hold (on the VCO), a two-channel mixer, an attenuator, a white-noise source, and a
patchbay of 12 inputs with their normals,
every cable running a sample at a time (the LFO, the S+H and the VCO patch into the pitch, the pulse width, the cutoff
and the folder at audio rate).

- **Knobs modelled on a reference panel**: drawn and turning as its knobs do (7 to 5 o'clock), their ranges tuned on
  recordings of a real unit; the tuning is still going on.
- **Four monophonic tracks**, each its own sound, on MIDI channels N .. N+3 (fixed; ALGORITHM picks the panel's).
- **The MIDI clock** (HOME > GLOBAL > CLOCK: INTERNAL, USB or TRS, the other port ignored): the LFO's SYNC (a note value,
  phase-locked, START realigns it), the arpeggiator on the clock's ticks, a tempo-synced delay. INTERNAL: TEMPO.
- **DUMMY cables**: a plug on its own breaks an input's normal (0 V), as on a real patchbay.
- **Chorus, delay and plate reverb**, shared as sends; **REC switches all of them off and on**, as they were;
  **held, REC shows each on-screen parameter's MIDI CC**.
- **90 factory programs** (91-99 INIT): basses, leads, patchbay tricks, rhythmic sounds, pads, keys, drums and drones,
  each INIT plus only the knobs it needs and only what the reference panel has (the effects aside), so each can be
  set up on the real instrument too.
- **Screen reader support**: with the FM-1 on USB, [FM-1 Screen Reader](https://charlesvestal.github.io/fm1-reader/)
  (Chrome or Edge) says the program, the page and its knobs, every knob as it turns and every message, with its own
  voice or the computer's screen reader. **Or with no computer**: PLAY held 2 s turns on the FM-1's own voice, the
  same words on the outputs and in USB audio, or on just one of them (HOME > READER > OUTPUT).
- Played from outside (TRS MIDI IN or USB-MIDI: notes, bend, aftertouch, mod wheel, sustain, program change, clock, a CC
  for every parameter, the cables included, and NRPN) or from the keys. No sequencer: sequence it from a Digitakt or
  anything that sends MIDI.

The panel: a button opens a section at its first page (pressed again: its next page, the first after the last: pressed
N times = page N, whatever was open before), SELECT turned runs through its pages and stops at the first and the last
(the same keys always reach the same page: it can be played by heart, without looking), the four knobs are the page's, SELECT pressed opens UTL (folder, mixer, attenuator, noise), then KEYBOARD. Every knob has one place. HOME: the mixer (levels, pans), VOICE,
GLOBAL; EDIT: the VCO; GLO: the VCF. An input jack is a knob that picks the output its cable comes from: SEQ shows the whole
patchbay with its cables, then every input on the knobs. The screen is our own drawing (white print on black,
vertical module tabs, a 13-button keyboard), animated (the LFO LED, the tracks' lamps, the cables' swing, the boot: a
cable plugged into VCA OUT).

Identity `FM-1_3628`. The full guide (Italian) is [LEGGIMI.md](LEGGIMI.md), the MIDI chart [CC-NRPN.md](CC-NRPN.md),
the changes [CHANGELOG.md](CHANGELOG.md).

> **Use at your own risk.** FMav-1 is free software with **no warranty**: the authors are not liable for a bricked FM-1,
> lost data or anything else. See [DISCLAIMER.md](DISCLAIMER.md) and [LICENSE](LICENSE).

## Install

From The Firmware Hub (one click, Chrome / Edge), or with the installer from a release:

```sh
python3 tools/fm1_install.py fmav1-0.5.1.fwsc --yes    # FM-1 on USB, switched on
```

It installs over most FM-1 firmwares (Felucca, SLOOP, OberVave and their forks) and keeps their stored programs
(FMav-1 stores its own at 0xD8000). If the FM-1 does not start: hold OCT- while switching it on (update mode) and run
the installer again.

## Build

```sh
sh build.sh --release 0.5.1                            # build/fmav1-0.5.1.fwsc
OBV_DEFS=-DMFM_NTRK=1u sh build.sh                     # the one-track build
sh tests/run_host.sh tests/mfm_programs.txt programs   # on a computer: build/host/programs.wav and the screens
sh tests/run_tests.sh                                  # every host test, sanitizers and a parameter fuzz (~3 min, 8 cores)
QUICK=1 sh tests/run_tests.sh                          # the same, the 90 programs not under the sanitizers (~5 min)
```

The JieLi toolchain (`tools/get_toolchain.sh`) and the AC79 SDK are needed for the device build; the host tests need
only a C compiler and Python with Pillow. Integers only (the chip has no FPU); see `docs/RULES.md` and `docs/API.md` for
the platform.

## Credits and licence

GPL-3.0-only, see [LICENSE](LICENSE) and [LICENSING.md](LICENSING.md). FMav-1 is built on
[OberVave](https://github.com/zvenson/obervave) 3.3.2 (zvenson) with its saves-in-silence
fixes and fixed MIDI channels, which stands on [Dinghy](https://github.com/zvenson/dinghy) and the FM-1 platform of
[Felucca](https://github.com/hugelton/Felucca) by Leo Kuroshita (Hügelton Instruments) with the changes of
[SLOOP](https://github.com/isod89/sloop-fm1) (isod89). The ladder filter and the fast-knob decoder follow
[FMini-1](https://github.com/ruppert/fmini-1) (Ruppert); the ladder's stages saturate as in the published equations of
A. Huovilainen (DAFx 2004) and S. D'Angelo and V. Välimäki (ICASSP 2013).

FMav-1 is an independent work, not made, endorsed or supported by M-VAVE or by any synthesizer maker. "M-VAVE" and
"FM-1" belong to their owners.
