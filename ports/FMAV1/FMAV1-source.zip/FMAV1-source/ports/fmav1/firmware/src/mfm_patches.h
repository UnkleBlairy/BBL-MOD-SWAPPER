/* SPDX-License-Identifier: GPL-3.0-only */
/* The factory programs (90; 91-99 are INIT): each a name and the knobs that differ from INIT (mfm_params.h), ended
 * by X. Our own sounds in the spirit of a small semi-modular (nobody's patches copied): basses, leads, the patchbay's
 * sounds, drums and effects; the drones (VCA ON: they sound without a note, as the hardware does) last.
 * 0.5 (the user): rebuilt from INIT, so each can be set up on the reference by turning only the knobs listed, in the
 * panel's order: only what the reference has (the effects aside: no white noise, no VELO / MODWHL / AFTERTC / GATE cable, no
 * FINE, ANALOG, arp or LFO SYNC), and only the knobs each sound needs (every other one back at INIT's where the
 * simulator heard no difference). The sounds are 0.4.1's, each knob at the value of the same Hz, time or level on
 * the curves fitted to the reference (CLASSIC BASS: the reference's own, from a photo); the noise programs remade with
 * the VCO and the LFO modulating each other at audio rate (CLOCK HATS: the VCO modulating itself through the mixer),
 * WHISTLE on the filter singing alone; the synced LFOs free at their rate at 120 bpm. VOLUME levels them as 0.4.1. */
#define X 255
#define J(i) PJ(i)

/* ---- basses */
/* (0.5) CLASSIC BASS on the reference's knobs as the user set them to sound like it (a photo; the laws fitted to
 * that recording): CUTOFF 10:28, RESONANCE 7, VCF MOD AMT 2:48, DECAY 12:35, SUSTAIN and RELEASE 9; 0.5.2: DECAY and
 * RELEASE on their new laws for the same times, the user: the sound as it was) */
static const uint8_t PF_CLASSIC_BASS[] = {P_PITCH, 48, P_CUTOFF, 44, P_VCF_AMT, 99, P_DECAY, 55, P_SUSTAIN, 25,
    P_RELEASE, 23, P_VOLUME, 95, X};
static const uint8_t PF_SQUARE_BASS[] = {P_PITCH, 48, P_WAVE, 127, P_CUTOFF, 56, P_VCF_AMT, 94, P_DECAY, 22,
    P_SUSTAIN, 54, P_RELEASE, 12, P_VOLUME, 97, X};
static const uint8_t PF_ACID_LINE[] = {P_PITCH, 48, P_CUTOFF, 50, P_RES, 106, P_VCF_AMT, 103, P_DECAY, 19, P_SUSTAIN, 0,
    P_GLIDE, 45, P_VOLUME, 122, X};
static const uint8_t PF_RUBBER_BASS[] = {P_PITCH, 48, P_WAVE, 90, P_PW, 90, P_CUTOFF, 48, P_RES, 96, P_VCF_AMT, 108,
    P_DECAY, 17, P_SUSTAIN, 0, J(I_CUTOFF), J_KBCV, P_VOLUME, 127, X};
static const uint8_t PF_FOLD_BASS[] = {P_PITCH, 48, P_CUTOFF, 59, P_RES, 35, P_VCF_AMT, 94, P_DECAY, 21, P_SUSTAIN, 45,
    P_RELEASE, 12, P_FOLD, 45, J(I_FOLD), J_VCO, P_VOLUME, 125, X};
static const uint8_t PF_PWM_BASS[] = {P_PITCH, 48, P_WAVE, 127, P_PW, 70, P_VCO_MIX, 127, P_PWM_AMT, 70, P_CUTOFF, 58,
    P_VCF_AMT, 90, P_LFO_RATE, 42, P_DECAY, 24, P_SUSTAIN, 73, P_RELEASE, 15, P_VOLUME, 90, X};
static const uint8_t PF_DIRTY_BASS[] = {P_PITCH, 48, P_CUTOFF, 57, P_RES, 52, P_VCF_AMT, 94, P_DECAY, 21, P_SUSTAIN, 37,
    P_RELEASE, 12, P_ONE_LVL, 127, J(I_FOLD), J_ONETWO, J(I_ONE), J_VCO, J(I_TWO), J_ONE, P_VOLUME, 127, X};
static const uint8_t PF_FM_BASS[] = {P_PITCH, 48, P_VCO_MIX, 127, P_PITCH_AMT, 30, P_CUTOFF, 62, P_VCF_AMT, 90,
    P_LFO_RATE, 117, P_DECAY, 21, P_SUSTAIN, 45, P_RELEASE, 12, J(I_LFORATE), J_KBCV, P_VOLUME, 109, X};
static const uint8_t PF_SUB_PLUCK[] = {P_PITCH, 36, P_WAVE, 127, P_CUTOFF, 54, P_VCF_AMT, 90, P_DECAY, 18, P_SUSTAIN, 0,
    P_RELEASE, 14, P_VOLUME, 107, X};
static const uint8_t PF_WOW_BASS[] = {P_PITCH, 48, P_CUTOFF, 48, P_RES, 84, P_VCF_AMT, 108, P_ATTACK, 20, P_DECAY, 25,
    P_SUSTAIN, 28, P_RELEASE, 14, P_VOLUME, 126, X};

/* ---- leads */
static const uint8_t PF_CLASSIC_LEAD[] = {P_VCO_MIX, 127, P_PITCH_AMT, 8, P_CUTOFF, 72, P_RES, 46, P_VCF_AMT, 90,
    P_DECAY, 25, P_SUSTAIN, 73, P_RELEASE, 17, P_GLIDE, 35, P_DL_ON, 1, P_RV_ON, 1, P_RV_SEND, 18, P_VOLUME, 106, X};
static const uint8_t PF_SQUARE_LEAD[] = {P_PITCH, 72, P_WAVE, 127, P_PW, 110, P_VCO_MIX, 127, P_PITCH_AMT, 7,
    P_CUTOFF, 75, P_RES, 35, P_VCF_AMT, 83, P_LFO_RATE, 65, P_DECAY, 25, P_SUSTAIN, 92, P_RELEASE, 17, P_RV_ON, 1,
    P_RV_SEND, 16, P_CH_ON, 1, P_VOLUME, 77, X};
static const uint8_t PF_FOLD_LEAD[] = {P_CUTOFF, 79, P_VCF_AMT, 83, P_DECAY, 37, P_SUSTAIN, 82, P_RELEASE, 17,
    P_FOLD, 80, P_GLIDE, 30, J(I_FOLD), J_VCO, P_VOLUME, 113, X};
static const uint8_t PF_RESO_LEAD[] = {P_CUTOFF, 65, P_RES, 110, P_VCF_AMT, 88, P_DECAY, 24, P_SUSTAIN, 54,
    P_RELEASE, 17, J(I_CUTOFF), J_KBCV, P_VOLUME, 126, X};
static const uint8_t PF_GLIDE_LEAD[] = {P_PITCH, 72, P_WAVE, 64, P_VCO_MIX, 127, P_PITCH_AMT, 7, P_CUTOFF, 77,
    P_RES, 41, P_VCF_AMT, 78, P_LFO_RATE, 63, P_SUSTAIN, 101, P_RELEASE, 19, P_GLIDE, 75, P_DL_ON, 1, P_DL_TIMEL, 7,
    P_DL_TIMER, 8, P_DL_FB, 55, P_VOLUME, 127, X};
static const uint8_t PF_DUO_LEAD[] = {P_CUTOFF, 73, P_RES, 29, P_VCF_AMT, 85, P_LFO_RATE, 117, P_LFO_WAVE, 127,
    P_DECAY, 25, P_SUSTAIN, 82, P_RELEASE, 17, P_ONE_LVL, 90, J(I_LFORATE), J_KBCV, J(I_FOLD), J_ONETWO,
    J(I_ONE), J_LFO, J(I_TWO), J_VCO, P_RV_ON, 1, P_RV_SEND, 20, P_VOLUME, 87, X};
static const uint8_t PF_PWM_LEAD[] = {P_PITCH, 72, P_WAVE, 127, P_PW, 80, P_VCO_MIX, 127, P_PWM_AMT, 90, P_CUTOFF, 80,
    P_VCF_AMT, 74, P_LFO_RATE, 53, P_SUSTAIN, 101, P_RELEASE, 19, P_RV_ON, 1, P_RV_SEND, 24, P_CH_ON, 1, P_VOLUME, 63,
    X};
static const uint8_t PF_FM_LEAD[] = {P_CUTOFF, 82, P_VCF_AMT, 78, P_DECAY, 51, P_SUSTAIN, 63, P_RELEASE, 19, P_DL_ON, 1,
    P_DL_SEND, 22, P_DL_TIMEL, 10, P_DL_TIMER, 8, P_DL_FB, 40, P_VOLUME, 103, X};
static const uint8_t PF_WAH_LEAD[] = {P_PITCH, 72, P_CUTOFF, 65, P_RES, 76, P_VCF_MIX, 127, P_VCF_AMT, 94,
    P_LFO_RATE, 58, P_SUSTAIN, 101, P_RELEASE, 17, P_VOLUME, 127, X};
static const uint8_t PF_SCREAM_LEAD[] = {P_VCO_MIX, 127, P_PITCH_AMT, 9, P_CUTOFF, 66, P_RES, 92, P_VCF_AMT, 83,
    P_LFO_RATE, 65, P_DECAY, 29, P_SUSTAIN, 73, P_RELEASE, 17, P_FOLD, 30, P_ONE_LVL, 110, P_GLIDE, 30,
    J(I_CUTOFF), J_KBCV, J(I_FOLD), J_ONETWO, J(I_ONE), J_VCO, J(I_TWO), J_ONE, P_VOLUME, 127, X};

/* ---- the patchbay at work */
static const uint8_t PF_SH_FILTER[] = {P_CUTOFF, 62, P_RES, 100, P_LFO_RATE, 67, P_RELEASE, 21, J(I_CUTOFF), J_SH,
    P_DL_ON, 1, P_DL_TIMEL, 7, P_DL_TIMER, 5, P_VOLUME, 124, X};
static const uint8_t PF_SH_MELODY[] = {P_WAVE, 127, P_PW, 110, P_CUTOFF, 72, P_RES, 58, P_VCF_AMT, 79, P_LFO_RATE, 62,
    P_DECAY, 18, P_SUSTAIN, 45, P_RELEASE, 15, P_ATTN, 25, J(I_1VOCT), J_ATTN, J(I_GATE), J_LFO, J(I_ATTN), J_SH,
    P_DL_ON, 1, P_RV_ON, 1, P_RV_DECAY, 92, P_VOLUME, 103, X};
static const uint8_t PF_WOBBLE[] = {P_PITCH, 48, P_CUTOFF, 51, P_RES, 68, P_VCF_MIX, 127, P_VCF_AMT, 105,
    P_LFO_RATE, 53, P_RELEASE, 14, P_VOLUME, 126, X};
static const uint8_t PF_TREMOLO[] = {P_WAVE, 127, P_CUTOFF, 73, P_LFO_RATE, 63, P_SUSTAIN, 73, P_RELEASE, 24,
    J(I_VCACV), J_LFO, P_RV_ON, 1, P_VOLUME, 69, X};
static const uint8_t PF_RING_TONE[] = {P_PITCH, 67, P_CUTOFF, 85, P_LFO_RATE, 117, P_SUSTAIN, 67, P_RELEASE, 21,
    J(I_VCACV), J_LFO, J(I_LFORATE), J_KBCV, P_RV_ON, 1, P_RV_SEND, 40, P_RV_DECAY, 96, P_VOLUME, 75, X};
static const uint8_t PF_FOLD_SWEEP[] = {P_WAVE, 127, P_PW, 60, P_VCO_MIX, 127, P_PWM_AMT, 110, P_CUTOFF, 85,
    P_LFO_RATE, 29, P_ATTACK, 34, P_SUSTAIN, 111, P_RELEASE, 39, P_FOLD, 90, J(I_FOLD), J_VCO, P_RV_ON, 1, P_CH_ON, 1,
    P_CH_DEPTH, 13, P_VOLUME, 73, X};
static const uint8_t PF_AUTO_REPEAT[] = {P_CUTOFF, 54, P_RES, 88, P_VCF_AMT, 94, P_LFO_RATE, 58, P_DECAY, 16,
    P_SUSTAIN, 0, P_RELEASE, 14, J(I_GATE), J_LFO, P_VOLUME, 127, X};
static const uint8_t PF_SLOW_SWELL[] = {P_WAVE, 127, P_PW, 80, P_VCO_MIX, 127, P_PWM_AMT, 70, P_CUTOFF, 62,
    P_VCF_AMT, 90, P_LFO_RATE, 36, P_ATTACK, 92, P_DECAY, 80, P_SUSTAIN, 101, P_RELEASE, 86, P_RV_ON, 1, P_RV_SEND, 46,
    P_RV_DECAY, 104, P_CH_ON, 1, P_CH_RATE, 61, P_VOLUME, 49, X};
static const uint8_t PF_CROSS_MOD[] = {P_PITCH, 84, P_WAVE, 127, P_PW, 64, P_CUTOFF, 82, P_RES, 35, P_VCF_AMT, 83,
    P_LFO_RATE, 112, P_DECAY, 25, P_SUSTAIN, 54, P_RELEASE, 21, J(I_1VOCT), J_LFO, J(I_PWM), J_LFO, J(I_LFORATE), J_VCO,
    P_VOLUME, 102, X};
static const uint8_t PF_KB_SCALE[] = {P_WAVE, 100, P_PW, 100, P_CUTOFF, 75, P_RES, 52, P_VCF_AMT, 81, P_DECAY, 23,
    P_SUSTAIN, 63, P_RELEASE, 19, P_GLIDE, 55, P_KB_SCALE, 32, P_VOLUME, 127, X};

/* ---- drums and effects; the drones last */
static const uint8_t PF_KICK[] = {P_PITCH, 36, P_PITCH_AMT, 60, P_CUTOFF, 56, P_VCF_AMT, 94, P_DECAY, 21, P_SUSTAIN, 0,
    P_RELEASE, 19, P_VOLUME, 112, X};
static const uint8_t PF_TOM[] = {P_PITCH, 48, P_PITCH_AMT, 45, P_CUTOFF, 59, P_RES, 68, P_VCF_AMT, 90, P_DECAY, 22,
    P_SUSTAIN, 0, P_RELEASE, 21, P_VOLUME, 127, X};
static const uint8_t PF_METAL[] = {P_PITCH, 90, P_WAVE, 127, P_PW, 64, P_CUTOFF, 92, P_RES, 35, P_LFO_RATE, 112,
    P_DECAY, 18, P_SUSTAIN, 0, J(I_1VOCT), J_LFO, J(I_PWM), J_LFO, J(I_LFORATE), J_VCO, P_RV_ON, 1, P_RV_SEND, 26,
    P_VOLUME, 127, X};
static const uint8_t PF_NOISE_HIT[] = {P_PITCH, 120, P_VCO_MIX, 127, P_PITCH_AMT, 80, P_RES, 76, P_LFO_RATE, 127,
    P_LFO_WAVE, 127, P_DECAY, 17, P_SUSTAIN, 0, J(I_LFORATE), J_VCO, P_RV_ON, 1, P_RV_SEND, 20, P_VOLUME, 127, X};
static const uint8_t PF_ZAP[] = {P_PITCH_AMT, 90, P_CUTOFF, 85, P_RES, 68, P_DECAY, 16, P_SUSTAIN, 0, P_VOLUME, 127, X};
static const uint8_t PF_LASER[] = {P_CUTOFF, 48, P_RES, 121, P_VCF_AMT, 118, P_DECAY, 20, P_SUSTAIN, 0, P_RELEASE, 17,
    J(I_CUTOFF), J_KBCV, P_DL_ON, 1, P_DL_SEND, 26, P_DL_TIMEL, 7, P_VOLUME, 121, X};
static const uint8_t PF_SIREN[] = {P_VCO_MIX, 127, P_PITCH_AMT, 50, P_CUTOFF, 85, P_LFO_RATE, 29, P_RELEASE, 21,
    P_VOLUME, 107, X};
static const uint8_t PF_BLIPS[] = {P_PITCH, 72, P_CUTOFF, 82, P_RES, 46, P_LFO_RATE, 69, P_DECAY, 13, P_SUSTAIN, 0,
    P_RELEASE, 12, J(I_1VOCT), J_SH, J(I_GATE), J_LFO, P_DL_ON, 1, P_DL_FB, 58, P_VOLUME, 125, X};
static const uint8_t PF_ARP_PLUCK[] = {P_WAVE, 127, P_PW, 100, P_CUTOFF, 62, P_RES, 68, P_VCF_AMT, 94, P_DECAY, 18,
    P_SUSTAIN, 0, P_DL_ON, 1, P_DL_TIMEL, 5, P_DL_TIMER, 8, P_DL_FB, 42, P_RV_ON, 1, P_RV_SEND, 16, P_VOLUME, 127, X};
static const uint8_t PF_DRONE[] = {P_PITCH, 36, P_WAVE, 64, P_PW, 64, P_VCO_MIX, 127, P_PWM_AMT, 60, P_CUTOFF, 59,
    P_RES, 84, P_VCF_MIX, 127, P_VCF_AMT, 83, P_LFO_RATE, 16, P_VCA_MODE, VCA_ON, P_RV_ON, 1, P_RV_SEND, 50,
    P_RV_DECAY, 110, P_CH_ON, 1, P_VOLUME, 111, X};

/* ---- 0.3: more basses */
static const uint8_t PF_DEEP_SUB[] = {P_PITCH, 36, P_WAVE, 127, P_CUTOFF, 50, P_VCF_AMT, 83, P_DECAY, 24, P_SUSTAIN, 82,
    P_RELEASE, 14, P_VOLUME, 93, X};
static const uint8_t PF_PICK_BASS[] = {P_PITCH, 48, P_CUTOFF, 57, P_VCF_AMT, 103, P_DECAY, 17, P_SUSTAIN, 15,
    P_RELEASE, 13, P_VOLUME, 109, X};
static const uint8_t PF_GROWL_BASS[] = {P_PITCH, 48, P_WAVE, 127, P_PW, 90, P_VCO_MIX, 127, P_PWM_AMT, 40, P_CUTOFF, 65,
    P_VCF_AMT, 98, P_LFO_RATE, 49, P_DECAY, 23, P_SUSTAIN, 63, P_RELEASE, 14, J(I_FOLD), J_VCO, P_VOLUME, 96, X};
static const uint8_t PF_OCTAVE_BASS[] = {P_PITCH, 48, P_CUTOFF, 55, P_VCF_AMT, 94, P_LFO_RATE, 117, P_LFO_WAVE, 127,
    P_DECAY, 22, P_SUSTAIN, 45, P_RELEASE, 13, P_ONE_LVL, 70, J(I_LFORATE), J_KBCV, J(I_FOLD), J_ONETWO,
    J(I_ONE), J_LFO, J(I_TWO), J_VCO, P_VOLUME, 120, X};
static const uint8_t PF_BLIP_BASS[] = {P_PITCH, 48, P_WAVE, 127, P_PW, 100, P_PITCH_AMT, 18, P_CUTOFF, 51, P_RES, 76,
    P_VCF_AMT, 113, P_DECAY, 16, P_SUSTAIN, 0, P_VOLUME, 125, X};
static const uint8_t PF_SQUARE_ACID[] = {P_PITCH, 48, P_WAVE, 127, P_CUTOFF, 53, P_RES, 96, P_VCF_AMT, 98, P_DECAY, 21,
    P_SUSTAIN, 28, P_RELEASE, 10, P_GLIDE, 55, P_VOLUME, 124, X};
static const uint8_t PF_BOOM_BASS[] = {P_PITCH, 36, P_PITCH_AMT, 30, P_CUTOFF, 59, P_VCF_AMT, 90, P_DECAY, 24,
    P_SUSTAIN, 37, P_RELEASE, 15, P_VOLUME, 104, X};
static const uint8_t PF_HOT_BASS[] = {P_PITCH, 48, P_CUTOFF, 60, P_RES, 52, P_VCF_AMT, 94, P_DECAY, 21, P_SUSTAIN, 45,
    P_RELEASE, 12, P_ONE_LVL, 127, J(I_FOLD), J_ONETWO, J(I_ONE), J_VCO, J(I_TWO), J_VCO, P_VOLUME, 127, X};
static const uint8_t PF_SEQ_BASS[] = {P_PITCH, 48, P_CUTOFF, 55, P_RES, 52, P_VCF_AMT, 98, P_DECAY, 19, P_SUSTAIN, 0,
    P_RELEASE, 12, P_VOLUME, 126, X};
static const uint8_t PF_SOFT_BASS[] = {P_PITCH, 48, P_CUTOFF, 49, P_VCF_AMT, 74, P_ATTACK, 13, P_SUSTAIN, 101,
    P_RELEASE, 17, P_VOLUME, 127, X};

/* ---- more leads (the LFO a second oscillator: KB CV on LFO RATE, 116 = the VCO's C at C4, 122 a fifth up) */
/* (0.5, the user, on the FM-1: ATTACK 104 ms, DECAY 487 ms, SUSTAIN 6.2, RELEASE 466 ms, LFO RATE 3.26 Hz; 0.5.2:
 * the ATTACK, DECAY and RELEASE knobs for the same 104, 487 and 466 ms on their new laws) */
static const uint8_t PF_BRASS_LEAD[] = {P_VCO_MIX, 127, P_PITCH_AMT, 7, P_CUTOFF, 62, P_VCF_AMT, 94, P_LFO_RATE, 57,
    P_ATTACK, 34, P_DECAY, 29, P_SUSTAIN, 82, P_RELEASE, 27, P_RV_ON, 1, P_RV_SEND, 14, P_VOLUME, 93, X};
static const uint8_t PF_WHISTLE[] = {P_CUTOFF, 69, P_RES, 127, P_VCF_MIX, 127, P_VCF_AMT, 65, P_LFO_RATE, 65,
    P_ATTACK, 17, P_RELEASE, 21, J(I_CUTOFF), J_KBCV, J(I_FOLD), J_DUMMY, P_RV_ON, 1, P_VOLUME, 110, X};
static const uint8_t PF_HOLLOW_LEAD[] = {P_PITCH, 72, P_WAVE, 127, P_PW, 30, P_VCO_MIX, 127, P_PWM_AMT, 30,
    P_CUTOFF, 76, P_RES, 46, P_VCF_AMT, 81, P_LFO_RATE, 47, P_DECAY, 37, P_SUSTAIN, 82, P_RELEASE, 19, P_DL_ON, 1,
    P_DL_SEND, 24, P_DL_FB, 45, P_VOLUME, 95, X};
static const uint8_t PF_SOFT_LEAD[] = {P_VCO_MIX, 127, P_PITCH_AMT, 6, P_CUTOFF, 66, P_VCF_AMT, 81, P_LFO_RATE, 63,
    P_ATTACK, 24, P_DECAY, 51, P_SUSTAIN, 92, P_RELEASE, 21, P_RV_ON, 1, P_RV_SEND, 26, P_VOLUME, 79, X};
static const uint8_t PF_BITE_LEAD[] = {P_CUTOFF, 62, P_RES, 84, P_VCF_AMT, 105, P_DECAY, 20, P_SUSTAIN, 45,
    P_RELEASE, 15, J(I_CUTOFF), J_KBCV, P_VOLUME, 127, X};
static const uint8_t PF_FIFTH_LEAD[] = {P_CUTOFF, 74, P_VCF_AMT, 83, P_LFO_RATE, 123, P_LFO_WAVE, 127, P_DECAY, 37,
    P_SUSTAIN, 82, P_RELEASE, 17, P_ONE_LVL, 80, J(I_LFORATE), J_KBCV, J(I_FOLD), J_ONETWO, J(I_ONE), J_LFO,
    J(I_TWO), J_VCO, P_DL_ON, 1, P_DL_SEND, 20, P_VOLUME, 108, X};
static const uint8_t PF_WHEEL_LEAD[] = {P_CUTOFF, 59, P_RES, 58, P_VCF_AMT, 78, P_DECAY, 37, P_SUSTAIN, 92,
    P_RELEASE, 17, P_GLIDE, 30, P_VOLUME, 127, X};
static const uint8_t PF_FOLDED_TRI[] = {P_CUTOFF, 92, P_VCF_AMT, 74, P_LFO_RATE, 117, P_SUSTAIN, 101, P_RELEASE, 19,
    P_FOLD, 50, J(I_LFORATE), J_KBCV, J(I_FOLD), J_LFO, P_RV_ON, 1, P_RV_SEND, 20, P_VOLUME, 94, X};
static const uint8_t PF_CHIP_LEAD[] = {P_PITCH, 72, P_WAVE, 127, P_PW, 30, P_SUSTAIN, 82, P_RELEASE, 10, P_DL_ON, 1,
    P_DL_FB, 40, P_VOLUME, 78, X};
static const uint8_t PF_SUB_LEAD[] = {P_PITCH, 72, P_CUTOFF, 77, P_RES, 29, P_VCF_AMT, 83, P_LFO_RATE, 117,
    P_LFO_WAVE, 127, P_DECAY, 29, P_SUSTAIN, 87, P_RELEASE, 17, P_ONE_LVL, 90, J(I_LFORATE), J_KBCV,
    J(I_FOLD), J_ONETWO, J(I_ONE), J_LFO, J(I_TWO), J_VCO, P_VOLUME, 118, X};

/* ---- rhythmic: made on the clock in 0.3 (a synced LFO, the CLOCK output); 0.5: their LFO free at the rate it
 * had at 120 bpm (the reference has no clock). CLOCK MELODY and CLOCK HATS play by themselves (the LFO in GATE) */
static const uint8_t PF_SYNC_WOBBLE[] = {P_PITCH, 48, P_CUTOFF, 51, P_RES, 76, P_VCF_MIX, 127, P_VCF_AMT, 105,
    P_LFO_RATE, 61, P_RELEASE, 14, P_VOLUME, 127, X};
static const uint8_t PF_TRANCE_GATE[] = {P_WAVE, 127, P_PW, 100, P_CUTOFF, 62, P_RES, 35, P_VCF_MIX, 127,
    P_VCF_AMT, 104, P_LFO_RATE, 71, P_LFO_WAVE, 127, P_RELEASE, 19, P_RV_ON, 1, P_VOLUME, 62, X};
static const uint8_t PF_CLOCK_SH[] = {P_CUTOFF, 62, P_RES, 96, P_LFO_RATE, 71, P_LFO_WAVE, 127, P_RELEASE, 17,
    J(I_CUTOFF), J_SH, P_DL_ON, 1, P_DL_FB, 45, P_VOLUME, 126, X};
static const uint8_t PF_CLOCK_MELODY[] = {P_WAVE, 127, P_PW, 100, P_CUTOFF, 72, P_RES, 58, P_VCF_AMT, 83,
    P_LFO_RATE, 71, P_LFO_WAVE, 127, P_DECAY, 17, P_SUSTAIN, 0, P_ATTN, 25, J(I_1VOCT), J_ATTN, J(I_GATE), J_LFO,
    J(I_ATTN), J_SH, P_RV_ON, 1, P_VOLUME, 107, X};
static const uint8_t PF_SYNC_PWM[] = {P_WAVE, 127, P_PW, 70, P_VCO_MIX, 127, P_PWM_AMT, 100, P_CUTOFF, 72,
    P_VCF_AMT, 74, P_LFO_RATE, 34, P_ATTACK, 27, P_SUSTAIN, 111, P_RELEASE, 24, P_RV_ON, 1, P_RV_SEND, 36, P_CH_ON, 1,
    P_VOLUME, 59, X};
static const uint8_t PF_DOTTED_LEAD[] = {P_PITCH, 72, P_CUTOFF, 73, P_RES, 35, P_VCF_AMT, 83, P_DECAY, 25,
    P_SUSTAIN, 73, P_RELEASE, 15, P_DL_ON, 1, P_DL_SEND, 44, P_DL_FB, 64, P_VOLUME, 109, X};
static const uint8_t PF_CHOPPER[] = {P_WAVE, 64, P_PW, 64, P_CUTOFF, 51, P_RES, 52, P_VCF_MIX, 127, P_VCF_AMT, 98,
    P_LFO_RATE, 71, P_LFO_WAVE, 127, P_RELEASE, 15, P_RV_ON, 1, P_RV_SEND, 20, P_VOLUME, 127, X};
static const uint8_t PF_TRIPLET_WOB[] = {P_PITCH, 48, P_WAVE, 127, P_PW, 110, P_CUTOFF, 50, P_RES, 84, P_VCF_MIX, 127,
    P_VCF_AMT, 103, P_LFO_RATE, 67, P_RELEASE, 14, P_VOLUME, 120, X};
static const uint8_t PF_CLOCK_HATS[] = {P_PITCH, 120, P_WAVE, 127, P_PW, 64, P_LFO_RATE, 71, P_LFO_WAVE, 127,
    P_DECAY, 13, P_SUSTAIN, 0, P_ONE_LVL, 64, J(I_1VOCT), J_ONETWO, J(I_GATE), J_LFO, J(I_ONE), J_VCO, P_VOLUME, 79, X};
static const uint8_t PF_SYNC_ARP[] = {P_WAVE, 127, P_PW, 90, P_CUTOFF, 65, P_RES, 64, P_VCF_AMT, 94, P_DECAY, 19,
    P_SUSTAIN, 0, P_DL_ON, 1, P_RV_ON, 1, P_RV_SEND, 20, P_VOLUME, 127, X};

/* ---- pads, keys, textures */
static const uint8_t PF_STRINGS[] = {P_VCO_MIX, 127, P_PITCH_AMT, 5, P_CUTOFF, 72, P_VCF_AMT, 68, P_LFO_RATE, 62,
    P_ATTACK, 58, P_SUSTAIN, 111, P_RELEASE, 73, P_RV_ON, 1, P_RV_SEND, 50, P_RV_DECAY, 105, P_CH_ON, 1, P_CH_RATE, 61,
    P_VOLUME, 63, X};
static const uint8_t PF_BRASS_PAD[] = {P_CUTOFF, 59, P_VCF_AMT, 90, P_ATTACK, 34, P_DECAY, 63, P_SUSTAIN, 92,
    P_RELEASE, 24, P_RV_ON, 1, P_RV_SEND, 40, P_CH_ON, 1, P_VOLUME, 69, X};
static const uint8_t PF_GLASS_KEYS[] = {P_WAVE, 127, P_PW, 30, P_CUTOFF, 75, P_RES, 108, P_VCF_AMT, 83, P_DECAY, 25,
    P_SUSTAIN, 28, P_RELEASE, 24, P_RV_ON, 1, P_RV_SEND, 40, P_VOLUME, 113, X};
static const uint8_t PF_ORGAN[] = {P_WAVE, 127, P_CUTOFF, 85, P_RELEASE, 14, P_CH_ON, 1, P_CH_RATE, 100, P_CH_DEPTH, 13,
    P_VOLUME, 83, X};
static const uint8_t PF_MALLET[] = {P_PITCH, 72, P_CUTOFF, 65, P_RES, 68, P_VCF_AMT, 94, P_DECAY, 22, P_SUSTAIN, 0,
    P_RV_ON, 1, P_VOLUME, 126, X};
static const uint8_t PF_BELL[] = {P_VCO_MIX, 127, P_PITCH_AMT, 40, P_CUTOFF, 92, P_LFO_RATE, 125, P_DECAY, 63,
    P_SUSTAIN, 0, P_RELEASE, 73, J(I_LFORATE), J_KBCV, P_RV_ON, 1, P_RV_SEND, 50, P_VOLUME, 75, X};
static const uint8_t PF_PAD_SWEEP[] = {P_WAVE, 127, P_PW, 90, P_CUTOFF, 59, P_RES, 58, P_VCF_MIX, 127, P_VCF_AMT, 83,
    P_LFO_RATE, 27, P_ATTACK, 70, P_RELEASE, 79, P_RV_ON, 1, P_RV_SEND, 50, P_CH_ON, 1, P_CH_RATE, 61, P_VOLUME, 66, X};
static const uint8_t PF_VOX[] = {P_VCO_MIX, 127, P_PITCH_AMT, 6, P_CUTOFF, 66, P_RES, 88, P_VCF_MIX, 127, P_VCF_AMT, 71,
    P_LFO_RATE, 42, P_ATTACK, 20, P_SUSTAIN, 111, P_RELEASE, 21, P_RV_ON, 1, P_VOLUME, 111, X};
static const uint8_t PF_WIND[] = {P_PITCH, 84, P_WAVE, 127, P_PW, 64, P_VCO_MIX, 127, P_PITCH_AMT, 104, P_CUTOFF, 62,
    P_RES, 108, P_VCF_MIX, 110, P_VCF_AMT, 90, P_LFO_RATE, 100, P_ATTACK, 70, P_DECAY, 80, P_SUSTAIN, 101,
    P_RELEASE, 86, J(I_LFORATE), J_VCO, P_RV_ON, 1, P_RV_SEND, 50, P_VOLUME, 92, X};
static const uint8_t PF_AMBIENT_KEYS[] = {P_CUTOFF, 68, P_VCF_AMT, 78, P_ATTACK, 17, P_DECAY, 63, P_SUSTAIN, 54,
    P_RELEASE, 73, P_RV_ON, 1, P_RV_SEND, 70, P_RV_DECAY, 115, P_VOLUME, 58, X};

/* ---- drums and effects; two drones last (VCA ON: they sound without a note) */
static const uint8_t PF_SNARE[] = {P_PITCH, 120, P_WAVE, 127, P_PW, 64, P_VCO_MIX, 127, P_PITCH_AMT, 104, P_CUTOFF, 80,
    P_VCF_AMT, 83, P_LFO_RATE, 100, P_DECAY, 17, P_SUSTAIN, 0, P_RELEASE, 15, J(I_LFORATE), J_VCO, P_VOLUME, 127, X};
static const uint8_t PF_HIHAT[] = {P_PITCH, 120, P_VCO_MIX, 127, P_PITCH_AMT, 127, P_CUTOFF, 117, P_LFO_RATE, 127,
    P_LFO_WAVE, 127, P_DECAY, 13, P_SUSTAIN, 0, J(I_LFORATE), J_VCO, P_VOLUME, 127, X};
static const uint8_t PF_CLAP[] = {P_PITCH, 108, P_WAVE, 127, P_PW, 64, P_VCO_MIX, 127, P_PITCH_AMT, 104, P_CUTOFF, 107,
    P_LFO_RATE, 112, P_DECAY, 17, P_SUSTAIN, 0, J(I_LFORATE), J_VCO, P_RV_ON, 1, P_RV_SEND, 40, P_RV_DECAY, 60,
    P_VOLUME, 85, X};
static const uint8_t PF_BELL_HIT[] = {P_PITCH, 66, P_WAVE, 127, P_CUTOFF, 85, P_RES, 46, P_LFO_RATE, 127,
    P_LFO_WAVE, 127, P_DECAY, 18, P_SUSTAIN, 0, P_ONE_LVL, 64, P_ATTN, 64, J(I_LFORATE), J_KBCV, J(I_FOLD), J_ONETWO,
    J(I_ONE), J_LFO, J(I_TWO), J_ATTN, J(I_ATTN), J_VCO, P_VOLUME, 125, X};
static const uint8_t PF_BLIP_PERC[] = {P_PITCH, 84, P_WAVE, 127, P_PW, 64, P_PITCH_AMT, 40, P_CUTOFF, 92, P_DECAY, 15,
    P_SUSTAIN, 0, P_VOLUME, 113, X};
static const uint8_t PF_DROP[] = {P_PITCH_AMT, 80, P_CUTOFF, 79, P_RES, 46, P_DECAY, 80, P_SUSTAIN, 0, P_RELEASE, 79,
    P_RV_ON, 1, P_VOLUME, 110, X};
static const uint8_t PF_RISER[] = {P_PITCH_AMT, 50, P_CUTOFF, 48, P_RES, 68, P_VCF_AMT, 105, P_ATTACK, 114,
    P_RELEASE, 67, P_RV_ON, 1, P_RV_SEND, 50, P_VOLUME, 91, X};
static const uint8_t PF_UFO[] = {P_VCO_MIX, 127, P_PITCH_AMT, 40, P_CUTOFF, 75, P_RES, 84, P_LFO_RATE, 76,
    P_RELEASE, 24, P_DL_ON, 1, P_RV_ON, 1, P_RV_SEND, 40, P_VOLUME, 97, X};
static const uint8_t PF_DRONE_5TH[] = {P_PITCH, 48, P_CUTOFF, 65, P_RES, 76, P_LFO_RATE, 114, P_VCA_MODE, VCA_ON,
    P_ONE_LVL, 90, J(I_LFORATE), J_KBCV, J(I_FOLD), J_ONETWO, J(I_ONE), J_LFO, J(I_TWO), J_VCO, P_RV_ON, 1,
    P_RV_SEND, 50, P_RV_DECAY, 110, P_CH_ON, 1, P_VOLUME, 76, X};
static const uint8_t PF_DARK_DRONE[] = {P_PITCH, 36, P_WAVE, 127, P_PW, 80, P_VCO_MIX, 127, P_PWM_AMT, 60, P_CUTOFF, 58,
    P_RES, 92, P_VCF_MIX, 127, P_VCF_AMT, 78, P_LFO_RATE, 16, P_VCA_MODE, VCA_ON, P_FOLD, 40, J(I_FOLD), J_VCO,
    P_RV_ON, 1, P_RV_SEND, 70, P_RV_DECAY, 115, P_VOLUME, 76, X};

static const factory_t FACTORY[] = {   /* (0.5, the user: BRASS LEAD, CLASSIC LEAD, CLASSIC BASS, PWM LEAD, FOLDED
                                           * TRI, DOTTED LEAD first; the others in their old order) */
    {"BRASS LEAD", PF_BRASS_LEAD}, {"CLASSIC LEAD", PF_CLASSIC_LEAD}, {"CLASSIC BASS", PF_CLASSIC_BASS},
    {"PWM LEAD", PF_PWM_LEAD}, {"FOLDED TRI", PF_FOLDED_TRI}, {"DOTTED LEAD", PF_DOTTED_LEAD},
    {"SQUARE BASS", PF_SQUARE_BASS}, {"ACID LINE", PF_ACID_LINE}, {"RUBBER BASS", PF_RUBBER_BASS},
    {"FOLD BASS", PF_FOLD_BASS}, {"PWM BASS", PF_PWM_BASS}, {"DIRTY BASS", PF_DIRTY_BASS}, {"FM BASS", PF_FM_BASS},
    {"SUB PLUCK", PF_SUB_PLUCK}, {"WOW BASS", PF_WOW_BASS}, {"SQUARE LEAD", PF_SQUARE_LEAD},
    {"FOLD LEAD", PF_FOLD_LEAD}, {"RESO LEAD", PF_RESO_LEAD}, {"GLIDE LEAD", PF_GLIDE_LEAD}, {"DUO LEAD", PF_DUO_LEAD},
    {"FM LEAD", PF_FM_LEAD}, {"WAH LEAD", PF_WAH_LEAD}, {"SCREAM LEAD", PF_SCREAM_LEAD}, {"S+H FILTER", PF_SH_FILTER},
    {"S+H MELODY", PF_SH_MELODY}, {"WOBBLE", PF_WOBBLE}, {"TREMOLO", PF_TREMOLO}, {"RING TONE", PF_RING_TONE},
    {"FOLD SWEEP", PF_FOLD_SWEEP}, {"AUTO REPEAT", PF_AUTO_REPEAT}, {"SLOW SWELL", PF_SLOW_SWELL},
    {"CROSS MOD", PF_CROSS_MOD}, {"KB SCALE 2X", PF_KB_SCALE}, {"KICK", PF_KICK}, {"TOM", PF_TOM}, {"METAL", PF_METAL},
    {"NOISE HIT", PF_NOISE_HIT}, {"ZAP", PF_ZAP}, {"LASER", PF_LASER}, {"SIREN", PF_SIREN}, {"BLIPS", PF_BLIPS},
    {"ARP PLUCK", PF_ARP_PLUCK}, {"DRONE", PF_DRONE}, {"DEEP SUB", PF_DEEP_SUB}, {"PICK BASS", PF_PICK_BASS},
    {"GROWL BASS", PF_GROWL_BASS}, {"OCTAVE BASS", PF_OCTAVE_BASS}, {"BLIP BASS", PF_BLIP_BASS},
    {"SQUARE ACID", PF_SQUARE_ACID}, {"BOOM BASS", PF_BOOM_BASS}, {"HOT BASS", PF_HOT_BASS}, {"SEQ BASS", PF_SEQ_BASS},
    {"SOFT BASS", PF_SOFT_BASS}, {"WHISTLE", PF_WHISTLE}, {"HOLLOW LEAD", PF_HOLLOW_LEAD}, {"SOFT LEAD", PF_SOFT_LEAD},
    {"BITE LEAD", PF_BITE_LEAD}, {"FIFTH LEAD", PF_FIFTH_LEAD}, {"WHEEL LEAD", PF_WHEEL_LEAD},
    {"CHIP LEAD", PF_CHIP_LEAD}, {"SUB LEAD", PF_SUB_LEAD}, {"SYNC WOBBLE", PF_SYNC_WOBBLE},
    {"TRANCE GATE", PF_TRANCE_GATE}, {"CLOCK S+H", PF_CLOCK_SH}, {"CLOCK MELODY", PF_CLOCK_MELODY},
    {"SYNC PWM", PF_SYNC_PWM}, {"CHOPPER", PF_CHOPPER}, {"TRIPLET WOB", PF_TRIPLET_WOB}, {"CLOCK HATS", PF_CLOCK_HATS},
    {"SYNC ARP", PF_SYNC_ARP}, {"STRINGS", PF_STRINGS}, {"BRASS PAD", PF_BRASS_PAD}, {"GLASS KEYS", PF_GLASS_KEYS},
    {"ORGAN", PF_ORGAN}, {"MALLET", PF_MALLET}, {"BELL", PF_BELL}, {"PAD SWEEP", PF_PAD_SWEEP}, {"VOX", PF_VOX},
    {"WIND", PF_WIND}, {"AMBIENT KEYS", PF_AMBIENT_KEYS}, {"SNARE", PF_SNARE}, {"HI-HAT", PF_HIHAT}, {"CLAP", PF_CLAP},
    {"BELL HIT", PF_BELL_HIT}, {"BLIP PERC", PF_BLIP_PERC}, {"DROP", PF_DROP}, {"RISER", PF_RISER}, {"UFO", PF_UFO},
    {"DRONE 5TH", PF_DRONE_5TH}, {"DARK DRONE", PF_DARK_DRONE},
};
_Static_assert(sizeof FACTORY / sizeof FACTORY[0] == 90, "90 factory programs, 91-99 INIT");
#define NFACT (sizeof FACTORY / sizeof FACTORY[0])
#undef X
#undef J
