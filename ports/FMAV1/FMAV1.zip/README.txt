FMav-1 0.6.4 for the BBL Mod Swapper

Original by wootr0p: https://github.com/wootr0p/fmav1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: FMAV1-source.zip on the ports page.
