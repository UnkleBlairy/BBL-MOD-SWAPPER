HERA 1.1 for the BBL Mod Swapper

Original by benbadio: https://github.com/benbadio/hera-fm1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: HERA-source.zip on the ports page.
