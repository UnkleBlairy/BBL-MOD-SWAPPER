Elixir 1.5.4 for the BBL Mod Swapper

Original by dmajka: https://github.com/dmajka/elixir
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: ELIXIR-source.zip on the ports page.
