/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: Elixir 1.5.4 (https://github.com/dmajka/elixir) on the Teensy 4.1: its own browser build (web/emu/elixir_web.c) inside ports/common's shell */
#include "../../../common/shell_pre.h"
#include <stdlib.h>
#include <time.h>
#ifndef CLOCK_MONOTONIC
#define CLOCK_MONOTONIC 1
static int clock_gettime(int c, struct timespec *t) { (void)c; t->tv_sec = 0; t->tv_nsec = 0; return 0; }
#endif
#define getenv(n) ((char *)0)
#define web_boot o_web_boot
#define web_out_l o_web_out_l
#define web_out_r o_web_out_r
#define web_render o_web_render
#define web_buttons o_web_buttons
#define web_keys o_web_keys
#define web_enc o_web_enc
#define web_master o_web_master
#define web_nor_erase o_web_nor_erase
#define web_ms o_web_ms
#define web_frame o_web_frame
#include "../../web/emu/elixir_web.c"
#undef __attribute__
#undef EXPORT
#undef memset
#undef memcpy
#undef memcmp
#undef memmove
#undef web_boot
#undef web_out_l
#undef web_out_r
#undef web_render
#undef web_buttons
#undef web_keys
#undef web_enc
#undef web_master
#undef web_nor_erase
#undef web_ms
#undef web_frame
#define SH_FLOAT
#define SH_OUT_L o_web_out_l
#define SH_OUT_R o_web_out_r
#define SH_RENDERF(n) o_web_render(n)
#define SH_ADC(m) o_web_master(m)
static void SH_BOOT(void) { o_web_boot(); }
static void SH_FRAME(uint32_t ms)
{ (void)ms; }
static int sh_role(uint32_t hw) { static const uint8_t R[7] = {0, 1, 3, 4, 5, 6, 2}; return R[hw]; }
#define SH_ENC(e, n) o_web_enc(sh_role(e), (n))
static uint32_t sh_labels;
static uint32_t sh_label(uint32_t raw) { return raw < 2u ? raw + 12u : raw - 2u; }
#define SH_BTN(i, d) (sh_labels = (sh_labels & ~(1u << sh_label(i))) | (uint32_t)(d) << sh_label(i), o_web_buttons(sh_labels))
static uint32_t sh_keys_m;
#define SH_KEY(k, d) (sh_keys_m = (sh_keys_m & ~(1u << (k))) | (uint32_t)(d) << (k), o_web_keys(sh_keys_m))
#define SH_KEY_LED(k) (web_lit_keys() >> (k) & 1u ? 2 : web_dim_keys() >> (k) & 1u ? 1 : 0)
#define SH_BTN_LED(i) (web_lit_buttons() >> sh_label(i) & 1u ? 2 : web_dim_buttons() >> sh_label(i) & 1u ? 1 : 0)
#include "../../../common/shell_post.h"

/* ---------------------------------------------------------------- MIDI (teensy-fm1) --- */
/* The runtime (src/main.rs) hands in whole messages from the FM-1's TRS jack and the Teensy's USB MIDI port, and takes
 * the firmware's MIDI out for USB. usb.config stands in for "a USB MIDI host is there", as on the FM-1 itself.
 * (added by tools_night/addmidi.py, docs/MIDI.md) */
EXPORT void teensy_midi_in(uint32_t st, uint32_t d1, uint32_t d2, uint32_t source)
{
    if (st >= 0xF8u) {
        if (st == 0xF8u || st == 0xFAu || st == 0xFBu || st == 0xFCu)
            (void)midi_enqueue(0xFu | st << 8, source);
        return;
    }
    if (st < 0x80u || st >= 0xF0u)
        return;
    (void)midi_enqueue((st >> 4) | st << 8 | (d1 & 127u) << 16 | (d2 & 127u) << 24, source);
}
EXPORT void teensy_midi_link(uint32_t on) { usb.config = on ? 1u : 0u; }
EXPORT uint32_t teensy_midi_out(uint32_t *out, uint32_t cap)
{
    uint32_t n = 0;
    while (n < cap && mo_r != mo_w) {
        out[n++] = midi_out_q[mo_r % MQ];
        mo_r++;
    }
    return n;
}
