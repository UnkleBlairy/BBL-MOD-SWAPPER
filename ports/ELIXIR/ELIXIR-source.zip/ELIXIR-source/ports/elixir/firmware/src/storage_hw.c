/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* The firmware side of storage.c (FELUCCA_FLASH): flash reads in short IRQ-off windows so the
 * audio keeps up, erases and writes only inside the storage areas, the audio buffer silenced
 * first. The host tests (storage_test.c) provide their own st_* on a simulated NOR. */
static uint8_t flash_ok;                 /* JEDEC id matched at boot (persist_boot) */
static int st_read(uint32_t off, void *dst, uint32_t n)   /* 256-byte IRQ-off windows: audio keeps up */
{
    uint8_t *d = dst;
    while (n) {
        uint32_t k = n > 256u ? 256u : n, f = irq_save();
        int rc = FL_FAR(fl_read_ram)(off, d, k);
        irq_restore(f);
        if (rc)
            return rc;
        off += k;
        d += k;
        n -= k;
    }
    return 0;
}
static void audio_silence(void)                 /* IRQs off: the DMA would loop stale audio (buzz) */
{
    uint32_t i;
    for (i = 0; i < sizeof abuf / sizeof abuf[0]; i++)
        abuf[i] = 0;
}
/* Elixir 0.5.1: a save's erases and writes behind the output's hush (engine.c): faded out first (the audio ISR's ramp,
 * ~6 ms; 30 ms at most, as when the audio is stopped), faded back in after (storage.c st_save_to,
 * project.c proj_save) */
static void flash_hush(void)
{
    uint32_t t0 = fm1_ms;
    out_hush = 1;
    while (out_gain && fm1_ms - t0 < 30u)
        fm1_wdt_feed();
}
static void flash_unhush(void) { out_hush = 0; }
static int st_erase_dev(uint32_t off)
{
    uint32_t took, f;
    int rc;
    if (!FL_STORE_OK(off, 0x1000u))
        return -8;
    f = irq_save();
    audio_silence();
    fm1__led_lines(0);                          /* (#236) the erase stops the LED scan for ~17 ms (the IRQs are off and its code */
    rc = FL_FAR(fl_erase4k_ram)(off, &took);    /* is in the flash): one column would stay lit at full duty and the rest dark, a */
    irq_restore(f);                             /* flash of the whole panel. Dark rows: the panel just drops out; the tick lights */
    return rc;                                  /* the rows again at its next pass */
}
static int st_prog_dev(uint32_t off, const void *src, uint32_t n)
{
    if (!FL_STORE_OK(off, n))                   /* only inside the storage areas */
        return -8;
    return fl_write(off, src, n);
}
