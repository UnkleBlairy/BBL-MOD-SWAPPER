#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
# Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments (Felucca's build; Elixir: its sources, two cores,
# its generated headers, no engines)
"""Build Elixir: the app, the update loader and an installable .fwsc package.

  tools/build.py [--release X.Y[-suffix]]

Outputs in build/: elixir.bin (app), loader/ota.bin (update loader),
elixir.fwsc (package). A release build (--release X.Y) writes elixir-X.Y.fwsc and a folder
release-X.Y/ with the package, the app, SHA256SUMS and the licence files.
See README.md for the toolchain and the SDK.

The JieLi toolchain is Linux x86-64 only. JIELI_TOOLCHAIN points at it; on
macOS (or with JIELI_DOCKER=1) each tool runs in a linux/amd64 container.
"""
import argparse
import hashlib
import os
import platform
import re
import shutil
import struct
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
FW = SRC / "firmware"
OUT = SRC / "build"
GEN = OUT / "gen"
LDR = OUT / "loader"
sys.path.insert(0, str(SRC / "tools"))
import fm1pkg_make  # noqa: E402
import lz4blk  # noqa: E402

APP_XIP = 0x02000120                # app.bin offset 0 in the XIP map; the SPL jumps here
APP_SLOT = fm1pkg_make.APP_SLOT
LOADER_LOAD = 0x01C0A800
LOADER_NAME = b"usb_hid_ota.bin"    # the file name the SPL looks for
DOCKER_IMAGE = os.environ.get("JIELI_DOCKER_IMAGE", "debian:bookworm-slim")
CFLAGS = ["-Os", "-ffunction-sections", "-fno-builtin", "-Wall", "-Wno-unused-function"]
LINE = re.compile(r"^\s*([0-9a-f]+):\s+((?:[0-9a-f]{2} )+)\s*\t(.*)$")

# SDK files of AC79NN_SDK_V1.2.1_2023-12-13 (the tested version)
SDK_SHA256 = {
    "uboot.boot": "4e3b4c220dc96641cb5a723f41e68ce41d5261ae9434bb33fbd7f2c59976ded4",
    "cfg_tool.bin": "276579954f076886a6a7694f65dc71c034a63a2c204b76749065c0ac7b010d1b",
    "cfg/eq_cfg_hw.bin": "41167491bffed4651750719c973d2758adeb9021a5670d02d6a53c85ed80ea7d",
}

PRODUCT = None                      # package identity: FM-1_359XXYYZZ (product_for); Felucca's FM-1_900 until 0.21
ID_PREFIX = "359"                   # (0.22) "ELX" on a phone keypad: free on The Firmware Hub, nine digits so no
                                    # firmware claiming FM-1_ + 3 to 8 digits matches it
VERSION = None                      # ELIXIR_VERSION for release builds (default: firmware/src/elixir.c)
CPU2 = True                         # 0.15 (Phase 17): the second core is built in (firmware/src/elixir.c FELUCCA_CPU2 1)


def product_for(version):
    """the package identity for a version string: v0.22 -> FM-1_359002200 (X, Y, Z two digits each; a -testN or
    -rcN build shares its release's)"""
    m = re.fullmatch(r"v?(\d+)\.(\d+)(?:\.(\d+))?(?:\.\d+)?(?:-[A-Za-z0-9]+)?", version)
    if not m or max(int(m[1]), int(m[2]), int(m[3] or 0)) > 99:
        raise SystemExit(f"version {version!r}: no identity for it (X.Y or X.Y.Z, up to 99 each)")
    return f"FM-1_{ID_PREFIX}{int(m[1]):02d}{int(m[2]):02d}{int(m[3] or 0):02d}"


def source_version():
    m = re.search(r'^#define ELIXIR_VERSION "([^"]+)"', (FW / "src" / "elixir.c").read_text(), re.M)
    return m[1]


def toolchain():
    tc = os.environ.get("JIELI_TOOLCHAIN")
    if not tc or not (Path(tc) / "pi32v2" / "bin" / "clang").exists():
        raise SystemExit("JIELI_TOOLCHAIN must point at the JieLi Linux toolchain "
                         "(the directory with pi32v2/ and common/; see tools/get_toolchain.sh)")
    return Path(tc).resolve()


def use_docker():
    native = platform.system() == "Linux" and platform.machine() in ("x86_64", "AMD64")
    return os.environ.get("JIELI_DOCKER", "0" if native else "1") == "1"


def tc(tool, *args):
    """run a toolchain binary (pi32v2/bin/..., common/bin/...) with cwd SRC; paths relative to SRC"""
    rel = [str(Path(a).resolve().relative_to(SRC)) if isinstance(a, Path) else a for a in args]
    if tool == "cc":                # the toolchain's cc wrapper needs python3; call clang directly
        tool, rel = "pi32v2/bin/clang", ["-target", "pi32v2", *rel]
    if use_docker():
        cmd = ["docker", "run", "--rm", "--platform", "linux/amd64", "-v", f"{SRC}:/work",
               "-v", f"{toolchain()}:/opt/jieli:ro", "-w", "/work", DOCKER_IMAGE, f"/opt/jieli/{tool}", *rel]
    else:
        cmd = [str(toolchain() / tool), *rel]
    r = subprocess.run(cmd, cwd=SRC, capture_output=True, text=True)
    if r.returncode:
        sys.stderr.write(r.stdout + r.stderr)
        raise SystemExit(f"build: {tool} failed")
    if r.stderr.strip():
        sys.stderr.write(r.stderr)
    return r.stdout


def tc_all(*cmds):
    with ThreadPoolExecutor(len(cmds)) as ex:
        return list(ex.map(lambda c: tc(*c), cmds))


def generate():
    """generated headers (UI fonts, icons, keycaps, palettes, tables, samples)"""
    GEN.mkdir(parents=True, exist_ok=True)
    tools = SRC / "tools"
    cmds = [[tools / "gen_aa_font.py", GEN / "ui_fonts.h", "--preset", "inter-tight"],
            [tools / "gen_aa_keycaps.py", GEN / "ui_keycaps.h"],
            [tools / "gen_ui_palettes.py", GEN / "ui_palettes.h"],
            [tools / "gen_tables.py", GEN / "elixir_tables.h"],
            [tools / "gen_factory_kits.py", GEN / "factory_kits.h", SRC / "assets" / "kits" / "factory"]]
    procs = [subprocess.Popen([sys.executable, *map(str, c)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              text=True) for c in cmds]
    failed = []
    for c, p in zip(cmds, procs):
        sys.stdout.write(p.communicate()[0])
        if p.returncode:
            failed.append(c[0].name)
    if failed:
        raise SystemExit(f"build: {', '.join(failed)} failed")
    subprocess.run([sys.executable, str(tools / "tblpack.py"), str(GEN / "tblpack_data.h"), str(GEN / "elixir_tables.h"),
                    str(FW / "src" / "rings_tables.h"), str(FW / "src" / "plaits_tables.h")], check=True)   # (22)


# ---- update loader

def crc16(d, c=0):
    for b in d:
        c ^= b << 8
        for _ in range(8):
            c = ((c << 1) ^ 0x1021) if c & 0x8000 else c << 1
        c &= 0xFFFF
    return c


def ldr_head(dcrc, a, b, attr, name):
    body = struct.pack("<HIIBBH16s", dcrc, a, b, attr, 0, 0, name)
    return struct.pack("<H", crc16(body)) + body


def ldr_wrap(image):
    """ota.bin = outer JLFS head (32 B) + inner head (32 B, load address) +
    blocks [clen u32][dlen u32][LZ4 block], dlen 4096 except the last"""
    blocks = bytearray()
    for i in range(0, len(image), 4096):
        raw = image[i:i + 4096]
        c = lz4blk.compress(raw)
        if len(c) > 4096 or lz4blk.decompress(c) != raw:
            raise SystemExit(f"loader: block {i // 4096} does not compress below 4096 B")
        blocks += struct.pack("<II", len(c), len(raw)) + c
    inner = ldr_head(crc16(image), len(image), LOADER_LOAD, 0, LOADER_NAME)
    body = inner + bytes(blocks)
    return ldr_head(crc16(body), 0x20, len(body), 0x41, LOADER_NAME) + body


def build_loader():
    LDR.mkdir(parents=True, exist_ok=True)
    src = FW / "loader"
    flags = [*CFLAGS, "-Ifirmware/hal", "-Ifirmware/src"]
    tc_all(("cc", "-c", src / "crt0_ldr.S", "-o", LDR / "crt0_ldr.o"),
           ("cc", *flags, "-c", src / "loader.c", "-o", LDR / "loader.o"))
    elf = LDR / "loader.elf"
    tc("pi32v2/bin/ld", "--gc-sections", "-e", "_start", "-T", src / "loader.ld",
       LDR / "crt0_ldr.o", LDR / "loader.o", "-o", elf)
    _, dis, hdr, syms = tc_all(("common/bin/objcopy", "-O", "binary", "-j", ".text", elf, LDR / "loader.bin"),
                               ("common/bin/objdump", "-d", elf),
                               ("common/bin/objdump", "-h", elf),
                               ("common/bin/objdump", "-t", elf))
    (LDR / "loader.dis").write_text(dis)
    for ln in hdr.splitlines():     # the loader rewrites the flash: nothing may run from XIP
        p = ln.split()
        if len(p) > 4 and p[1].startswith(".") and int(p[3], 16) >= 0x02000000 and int(p[2], 16):
            raise SystemExit(f"loader: section {p[1]} at {p[3]} is outside RAM")
    image = (LDR / "loader.bin").read_bytes()
    if not image or len(image) > 0x14000:
        raise SystemExit("loader: image empty or too big")
    ota = ldr_wrap(image)
    (LDR / "ota.bin").write_bytes(ota)
    bss = [int(ln.split()[0], 16) for ln in syms.splitlines() if ln.rstrip().endswith("_bss_end")]
    print(f"loader: image {len(image)} B at {LOADER_LOAD:#x}" + (f", bss end {bss[0]:#x}" if bss else ""))
    print(f"loader: ota.bin {len(ota)} B")
    return ota


# ---- app

def ld_regions():
    """firmware/app.ld's MEMORY regions: name -> (origin, length)"""
    regs = {}
    for m in re.finditer(r"^\s*(\w+)\s*\([rwx]+\)\s*:\s*ORIGIN\s*=\s*(\w+),\s*LENGTH\s*=\s*(\w+)",
                         (FW / "app.ld").read_text(), re.M):
        n = m.group(3)
        regs[m.group(1)] = (int(m.group(2), 0), int(n[:-1], 0) * 1024 if n.endswith("K") else int(n, 0))
    return regs


def ramhot(obj):
    """2026-11-21 Phase 1: the functions marked RAMHOT in firmware/src run from RAM (app.ld HOTCODE); on by default
    since Phase 1d, ELIXIR_RAMHOT=0 keeps them in flash (an A/B build, v<version>-cold), ELIXIR_RAMHOT_FLASH=a,b..
    keeps those in flash (an A/B of a subset, v<version>-split). A partial link renames each one's .text.<name> to
    .ram_hot.<name>, keeping its code and relocations: a
    section attribute would change the code (the JieLi clang never inlines into a function of another section), and
    this objcopy (LLVM 4) can't rename. Returns the object to link"""
    (OUT / "elixir_hot.o").unlink(missing_ok=True)
    if os.environ.get("ELIXIR_RAMHOT") == "0":
        return obj
    names = []
    for f in sorted((FW / "src").glob("*.c")):
        names += re.findall(r"^static\s+RAMHOT\s+[\w\s*]*?\b(\w+)\s*\(", f.read_text(), re.M)
    if not names:
        raise SystemExit("RAMHOT: no function is marked RAMHOT")
    keep = [n for n in os.environ.get("ELIXIR_RAMHOT_FLASH", "").split(",") if n]
    if set(keep) - set(names):
        raise SystemExit(f"ELIXIR_RAMHOT_FLASH: not marked RAMHOT: {', '.join(sorted(set(keep) - set(names)))}")
    names = [n for n in names if n not in keep]
    sects = set(re.findall(r"^\s*\d+ (\.text\.\w+) ", tc("common/bin/objdump", "-h", obj), re.M))
    lost = [n for n in names if f".text.{n}" not in sects]
    if lost:                                      # inlined into its callers: nothing of its own to move
        raise SystemExit(f"RAMHOT: no section of its own (inlined?): {', '.join(lost)}")
    script = OUT / "ramhot.ld"
    script.write_text("SECTIONS\n{\n" + "".join(f"    .ram_hot.{n} : {{ *(.text.{n}) }}\n" for n in names) + "}\n")
    out = OUT / "elixir_hot.o"
    tc("pi32v2/bin/ld", "-r", "-T", script, obj, "-o", out)
    print(f"RAMHOT: {len(names)} functions to .ram_hot" + (f" ({len(keep)} left in flash)" if keep else ""))
    return out


def build_app():
    flags = [*CFLAGS, "-Ifirmware/hal", "-Ifirmware/src", "-Ibuild/gen"]
    flags.append(f'-DFELUCCA_ID="{PRODUCT}"')
    version = VERSION
    if os.environ.get("ELIXIR_RAMHOT") == "0":    # (the A/B build with no RAM code says so on the about screen)
        version = (version or source_version()) + "-cold"
    if os.environ.get("ELIXIR_LDDIAG") in ("1", "2"):    # (a diagnostic build says so on the about screen)
        version = (version or source_version()) + "-diag" + os.environ["ELIXIR_LDDIAG"]
    if os.environ.get("ELIXIR_RAMHOT_FLASH"):   # (an A/B with some RAMHOT functions left in flash)
        version = (version or source_version()) + "-split"
    if version:
        flags.append(f'-DELIXIR_VERSION="{version}"')
    if os.environ.get("ELIXIR_WTABLE") == "1":       # (0.24: P WTABLE, parked; ~48 KB: docs/parked/README.md)
        flags.append("-DELIXIR_WTABLE=1")
    if os.environ.get("ELIXIR_LDDIAG") in ("1", "2"):    # (1.0: SEQ, MOD split on the LOAD page: a test build;
        flags.append(f"-DELIXIR_LDDIAG={os.environ['ELIXIR_LDDIAG']}")   # 2026-11-21 Phase 2: 2, MIXER's parts)
    if os.environ.get("ELIXIR_PH_MONO") in ("0", "1"):     # (1.0 Phase 10: 0, the phaser's two chains, to A/B)
        flags.append(f'-DPH_MONO={os.environ["ELIXIR_PH_MONO"]}')
    if os.environ.get("ELIXIR_FX_CHORUS") == "1":          # (1.0: the FX bus's CHORUS, set aside: built back in)
        flags.append('-DFX_CHORUS_ON=1')
    if os.environ.get("ELIXIR_FX_DRIVE") == "1":           # (1.0 Phase 10f: the FX bus's DRIVE, set aside: built back in)
        flags.append('-DFX_DRIVE_ON=1')
    if os.environ.get("ELIXIR_USB_AUDIO") in ("0", "8"):   # (1.0: 8, the default, the mix and six stems; 0 MIDI only)
        flags.append(f'-DELIXIR_USB_AUDIO={os.environ["ELIXIR_USB_AUDIO"]}')
    cmain = ("cc", *flags, "-c", FW / "src" / "elixir.c", "-o", OUT / "elixir.o")
    (OUT / "fm1_cpu1.o").unlink(missing_ok=True)
    tc_all(("cc", "-c", FW / "crt0.S", "-o", OUT / "crt0.o"),
           ("cc", "-c", FW / "hal" / "fm1_vec.S", "-o", OUT / "fm1_vec.o"),
           ("cc", "-c", FW / "hal" / "fm1_isr.S", "-o", OUT / "fm1_isr.o"),
           *([("cc", "-c", FW / "hal" / "fm1_cpu1.S", "-o", OUT / "fm1_cpu1.o")] if CPU2 else []),
           cmain)
    main_o = ramhot(OUT / "elixir.o")
    elf = OUT / "elixir.elf"
    tc("pi32v2/bin/ld", "-T", FW / "app.ld", OUT / "crt0.o", OUT / "fm1_vec.o", OUT / "fm1_isr.o",
       *([OUT / "fm1_cpu1.o"] if CPU2 else []), main_o, "-o", elf)
    for sect in ("text.bin", "data.bin", "ramtext.bin", "c1text.bin", "ramhot.bin"):
        (OUT / sect).unlink(missing_ok=True)
    *_, syms, dis, rt = tc_all(("common/bin/objcopy", "-O", "binary", "-j", ".text", elf, OUT / "text.bin"),
                               ("common/bin/objcopy", "-O", "binary", "-j", ".data", elf, OUT / "data.bin"),
                               ("common/bin/objcopy", "-O", "binary", "-j", ".ram_text", elf, OUT / "ramtext.bin"),
                               *([("common/bin/objcopy", "-O", "binary", "-j", ".c1_text", elf, OUT / "c1text.bin")]
                                 if CPU2 else []),
                               ("common/bin/objcopy", "-O", "binary", "-j", ".ram_hot", elf, OUT / "ramhot.bin"),
                               ("common/bin/objdump", "-t", elf),
                               ("common/bin/objdump", "-d", elf),
                               ("common/bin/objdump", "-d", "-j", ".ram_text", *(("-j", ".c1_text") if CPU2 else ()),
                                elf))
    (OUT / "elixir.dis").write_text(dis)

    def symv(name):
        return int(re.search(r"^([0-9a-f]+) .*\s" + name + r"$", syms, re.M).group(1), 16)
    img = bytearray((OUT / "text.bin").read_bytes())
    # .ram_text, .c1_text and .data follow .text at their load addresses; crt0 / main copy them by words
    for sect, lname in (("ramtext.bin", "_rt_load"), ("c1text.bin", "_c1_load"), ("ramhot.bin", "_rh_load"),
                        ("data.bin", "_data_load")):
        load = symv(lname)
        if load % 4:
            raise SystemExit(f"{lname} {load:#x} is not word aligned")
        blob = (OUT / sect).read_bytes() if (OUT / sect).exists() else b""
        if blob:
            if load - APP_XIP < len(img):
                raise SystemExit(f"{lname} overlaps the image")
            img += b"\xff" * (load - APP_XIP - len(img))
            img += blob
    img += b"\xff" * (-len(img) % 4)
    (OUT / "elixir.bin").write_bytes(img)
    return bytes(img), syms, dis, rt


def check(img, syms, dis, rt):
    errors, notes = [], []
    m = re.search(r"^([0-9a-f]+) .*\s_start$", syms, re.M)
    if not m or int(m.group(1), 16) != APP_XIP:
        errors.append(f"_start is not at {APP_XIP:#x}")
    if img[:4] != bytes.fromhex("04818000"):
        errors.append(f"image starts with {img[:4].hex()}, not the entry stub")
    # RAM code runs with the flash off: no calls into XIP. The second core's waiting loop (.c1_text) calls only its
    # job, through the pointer core 0 handed it (a register: "call rN")
    sect, rt_calls, c1_calls, c1_insns, rt_insns = None, [], [], 0, 0
    for ln in rt.splitlines():
        mm = re.match(r"^Disassembly of section (\S+):", ln)
        if mm:
            sect = mm.group(1)
            continue
        if not LINE.match(ln):
            continue
        if sect == ".c1_text":
            c1_insns += 1
            if re.search(r"\bcall\b", ln) and not re.search(r"\bcall\s+r\d+\b", ln):
                c1_calls.append(ln.strip())
        else:
            rt_insns += 1
            if re.search(r"\bcall\b", ln):
                rt_calls.append(ln.strip())
    if rt_calls:
        errors.append(f".ram_text contains calls: {rt_calls[:3]}")
    else:
        notes.append(f".ram_text: {rt_insns} insns, no calls")
    c1_syms = re.findall(r"\s(fm1_c1_\w+|_c1_ustack\w*|_c1_sstack\w*)$", syms, re.M)
    if not CPU2:                    # FELUCCA_CPU2=0: nothing of the second core (no stack, waiting loop, mailbox)
        if c1_insns or c1_syms:
            errors.append(f"FELUCCA_CPU2=0 build holds second-core code or data: {sorted(set(c1_syms))[:4]}")
        else:
            notes.append("one core: no second-core code, stack or mailbox")
    elif c1_calls:
        errors.append(f".c1_text calls other than its job: {c1_calls[:3]}")
    elif not c1_insns:
        errors.append(".c1_text: the second core's waiting loop is missing (firmware/hal/fm1_cpu1.h fm1_c1_main)")
    else:
        notes.append(f".c1_text: {c1_insns} insns, only its job called")
    for ln in dis.splitlines():     # nothing may call or load an address in the chip ROM
        mm = LINE.match(ln)
        if not mm:
            continue
        for v in re.findall(r"= (-?\d+) <|call -?\d+ <[^:>]*: ([0-9a-f]+) >", mm.group(3)):
            val = (int(v[0]) & 0xFFFFFFFF) if v[0] else int(v[1], 16) & 0xFFFFFFFF
            if 0xFFC00000 <= val < 0xFFD00000:
                errors.append(f"reference to ROM address {val:#010x}")
    if len(img) > APP_SLOT:
        errors.append(f"image {len(img)} B exceeds the app slot")

    def sym(name):
        mm = re.search(r"^([0-9a-f]+) .*\s" + name + r"$", syms, re.M)
        return int(mm.group(1), 16) if mm else 0
    region = ld_regions()
    ram_org, ram_len = region["RAM"]
    pool_len = region["POOL"][1]
    bss = sym("_bss_end") - ram_org
    pool = sym("_pool_end") - sym("_pool_start")
    notes.append(f"image {len(img)} B; RAM .data+.bss {bss} B of {ram_len}; pool {pool} B of {pool_len}")
    rt_org, rt_len = region["RAMTEXT"]
    rb_end = sym("_rb_end")
    if sym("_rb_start") != rt_org:
        errors.append("app.ld: RAMTEXT holds something before .ram_buf (the RAM code belongs in HOTCODE)")
    if rb_end:                                    # 18a: .ram_buf, buffers only (Phase 1 2026-11-21: code to HOTCODE)
        notes.append(f"RAMTEXT: .ram_buf {rb_end - sym('_rb_start')} B, {rt_org + rt_len - rb_end} B free of {rt_len}")
    # 2026-11-21 Phase 1: all the RAM code at the top of the SRAM, under the stacks (in call range of XIP's code)
    hc_org, hc_len = region["HOTCODE"]
    hot = sym("_rh_end") - sym("_rh_start")
    notes.append(f"HOTCODE: .ram_text {sym('_rt_end') - sym('_rt_start')} B, .c1_text {sym('_c1_end') - sym('_c1_start')}"
                 f" B, .ram_hot {hot} B{'' if hot else ' (ELIXIR_RAMHOT=0)'}, "
                 f"{hc_org + hc_len - sym('_rh_end')} B free of {hc_len}")
    if sym("_rt_start") != hc_org or not sym("_rt_start") < sym("_c1_start") <= sym("_rh_start"):
        errors.append("app.ld: HOTCODE is not .ram_text, .c1_text, .ram_hot in order (the guard's one RAM PC window)")
    if hc_org + hc_len != sym("_guard0"):
        errors.append("app.ld: HOTCODE does not end at the stacks' guard band")
    if region["RAM"][0] + ram_len != region["POOL"][0]:
        errors.append("app.ld: POOL does not start where RAM ends")
    if region["POOL"][0] + pool_len != hc_org:
        errors.append("app.ld: HOTCODE does not start where POOL ends")
    # 34: RAM and POOL are one SRAM split by app.ld (no heap; the stacks have their own guarded regions), so the
    # spare is one reserve: >= 8 KiB across both (was 4 KiB of .bss and 8 KiB of pool apart). The linker still
    # stops either side at its length; move the split in app.ld when one side fills
    spare = (ram_len - bss) + (pool_len - pool)
    notes.append(f"SRAM spare {spare} B (RAM {ram_len - bss} + pool {pool_len - pool}), {spare - 8192} B above the "
                 f"8 KiB reserve")
    if spare < 8192:
        errors.append(f"SRAM spare {spare} B < 8192 B (RAM {ram_len - bss} + pool {pool_len - pool})")
    return errors, notes


# Every hardware register access lives in hal/. In src/, engines/src/ and loader/ (comments stripped):
#  - no volatile pointer cast, except of a C object's address (`*(volatile T *)&x`: a read-once
#    of a RAM flag shared with an ISR, e.g. usb.c ota_wire_send);
#  - no literal in a register or reserved window (core SFRs 0x10000-0x13FFF, SFC 0x40000-0x43FFF,
#    GPIO/IOMAP 0x50000-0x51FFF, CPU 0x1EE0000-0x1EEFFFF, RAM top 0x01C7F000- (boot info,
#    mailbox, vectors), XIP 0x02000000-0x020FFFFF);
#  - no inline asm, except the empty compiler barrier RING_PUBLISH() (emits no instruction);
#  - no HAL register macro (a hal/ #define that is, or expands to, a volatile access).
# Linker symbols (_bss_start[], _rt_load[], ...) are plain C objects and pass.
MMIO_LIT = re.compile(r"\b0x0*(1[0-3][0-9a-f]{3}|4[0-3][0-9a-f]{3}|5[01][0-9a-f]{3}|1ee[0-9a-f]{4}|"
                      r"1c7f[0-9a-f]{3}|20[0-9a-f]{5})u?l?\b", re.I)
MMIO_CAST = re.compile(r"\(\s*(?:const\s+)?volatile\b[^()]*\*\s*\)(?!\s*&)")
MMIO_ASM = re.compile(r"\b(?:__asm__|asm)\b(?!\s+volatile\s*\(\s*\"\"\s*:::\s*\"memory\"\s*\))")


def mmio_check():
    def strip(s):
        s = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), s, flags=re.S)
        return re.sub(r"//[^\n]*", "", s)
    defs = {}
    for h in sorted((FW / "hal").glob("*.h")):
        for m in re.finditer(r"^#define\s+(\w+)(?:\([^)]*\))?\s+(.*)$", strip(h.read_text()), re.M):
            defs[m.group(1)] = m.group(2)
    regs = {n for n, b in defs.items() if re.search(r"\bvolatile\b", b)}
    while True:                                   # macros built on register macros (FM1_WR_LIMIT_H -> FM1_X2)
        more = {n for n, b in defs.items() if n not in regs and set(re.findall(r"\w+", b)) & regs}
        if not more:
            break
        regs |= more
    errors = []
    for f in sorted([*(FW / "src").glob("*.[ch]"), *(FW / "loader").glob("*.c")]):
        for no, ln in enumerate(strip(f.read_text()).splitlines(), 1):
            where = f"{f.relative_to(FW)}:{no}"
            for rx, what in ((MMIO_LIT, "register/window address"), (MMIO_CAST, "volatile pointer cast"),
                             (MMIO_ASM, "inline asm")):
                m = rx.search(ln)
                if m:
                    errors.append(f"{where}: {what} outside hal/ ({m.group(0).strip()}); add a hal/ helper")
            used = set(re.findall(r"\b[A-Z_][A-Z0-9_]*\b", ln)) & regs
            if used:
                errors.append(f"{where}: HAL register macro {sorted(used)[0]} outside hal/; use a hal/ helper")
    return errors


def main():
    global PRODUCT, VERSION
    ap = argparse.ArgumentParser()
    ap.add_argument("--release", metavar="X.Y", help="release build: version string vX.Y (and its identity)")
    ap.add_argument("--sdk", type=Path, help="JieLi AC79 SDK checkout (default: $AC79_SDK)")
    a = ap.parse_args()
    name = "elixir.fwsc"
    if a.release:
        VERSION = "v" + a.release.lower()      # e.g. v1.0, v1.1-rc1
        name = f"elixir-{a.release}.fwsc"
    PRODUCT = product_for(VERSION or source_version())
    fm1pkg_make.SDK = a.sdk
    for rel, sha in SDK_SHA256.items():          # fail early without the SDK
        if hashlib.sha256(fm1pkg_make.sdk_file(rel)).hexdigest() != sha:
            print(f"warning: SDK {rel} differs from AC79NN_SDK_V1.2.1; the package will not match the reference")
    OUT.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(2) as ex:
        gen, ldr = ex.submit(generate), ex.submit(build_loader)
        gen.result()
        ota = ldr.result()
    img, syms, dis, rt = build_app()
    errors, notes = check(img, syms, dis, rt)
    hal_err = mmio_check()
    errors += hal_err
    if not hal_err:
        notes.append("register access: hal/ only (src/, engines/src/, loader/ clean)")
    for n in notes:
        print("  ok   ", n)
    for e in errors:
        print("  FAIL ", e)
    if errors:
        raise SystemExit("build: checks failed")
    pkg = fm1pkg_make.ufw(fm1pkg_make.flash_image(img, fm1pkg_make.KEY), ota, PRODUCT)
    (OUT / name).write_bytes(pkg)
    print(f"app      {OUT / 'elixir.bin'}  {len(img)} B")
    print(f"loader   {LDR / 'ota.bin'}  {len(ota)} B")
    print(f"package  {OUT / name}  {len(pkg)} B, identity {PRODUCT}")
    if a.release:                   # what a release carries: the package, the app and every licence they need
        rel = OUT / f"release-{a.release}"
        shutil.rmtree(rel, ignore_errors=True)
        (rel / "LICENSES").mkdir(parents=True)
        app = f"elixir-{a.release}-app.bin"
        (rel / name).write_bytes(pkg)
        (rel / app).write_bytes(img)
        (rel / "SHA256SUMS").write_text("".join(f"{hashlib.sha256(b).hexdigest()}  {n}\n"
                                                for n, b in ((name, pkg), (app, bytes(img)))))
        for f in sorted((SRC / "LICENSES").glob("*.txt")):
            shutil.copy(f, rel / "LICENSES" / f.name)
        for doc in ("LICENSE", "README.md", "NOTICE.md"):
            if (SRC / doc).exists():
                shutil.copy(SRC / doc, rel / doc)
        print(f"release  {rel}/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
