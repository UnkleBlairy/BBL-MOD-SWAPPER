Golana 1.3 for the BBL Mod Swapper

Original by Gadlele: https://github.com/Gadlele/Golana
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: GOLANA-source.zip on the ports page.
