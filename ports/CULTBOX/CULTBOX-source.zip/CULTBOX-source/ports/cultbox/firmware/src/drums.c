/* SPDX-License-Identifier: GPL-3.0-only */
/* Sample drums (drums.h). One voice per pad: a hit restarts it. No libm: the pitch ratio comes from a semitone table. */
#include "drums.h"
#include "drums_data.h"

#define KIT DRUM_ELKA
#define HAT_CLOSED 8
#define HAT_OPEN 9
const char *const *const drums_names = DRUM_ELKA_NAMES;
/* General MIDI drum notes of the pads: kick, snare 1, snare 2, tom 1, tom 2, conga, claves, cowbell, hats */
static const uint8_t PAD_NOTE[DRUMS_NPAD] = {36, 38, 40, 50, 45, 63, 75, 56, 42, 46};
static const float SEMI[50] = {0.250000f, 0.264866f, 0.280616f, 0.297302f, 0.314980f, 0.333710f, 0.353553f, 0.374577f, 0.396850f, 0.420448f, 0.445449f, 0.471937f, 0.500000f, 0.529732f, 0.561231f, 0.594604f, 0.629961f, 0.667420f, 0.707107f, 0.749154f, 0.793701f, 0.840896f, 0.890899f, 0.943874f, 1.000000f, 1.059463f, 1.122462f, 1.189207f, 1.259921f, 1.334840f, 1.414214f, 1.498307f, 1.587401f, 1.681793f, 1.781797f, 1.887749f, 2.000000f, 2.118926f, 2.244924f, 2.378414f, 2.519842f, 2.669680f, 2.828427f, 2.996614f, 3.174802f, 3.363586f, 3.563595f, 3.775497f, 4.000000f, 4.237852f};   /* 2^(n/12), n = -24 .. 25 */

typedef struct { float pos, inc, env, envm, gain; uint32_t active, delay; } drum_voice_t;
struct drums_bank {
    drum_voice_t v[DRUMS_NPAD];
    uint8_t pv[DRUMS_PADVALS];
    uint8_t level, crush, tone, choke;
    uint8_t sub_level, sub_tune, sub_decay, sub_drop;
    float lp, held, vint;
    uint32_t hold_n, rng;
    float sx, sy, se, sf, sa, sk, sg, sp, spk; /* the sub: the circle's two states, its step now and at rest, its level, the decay and the drop's per sample, the gain, the drop now, its rate */
    uint32_t sub_on, sub_delay;
};
typedef char drums_bank_fits[sizeof(struct drums_bank) <= DRUMS_BANK_BYTES ? 1 : -1];

int drums_pad_of_note(unsigned note)
{
    unsigned i;
    for (i = 0; i < DRUMS_NPAD; i++) if (PAD_NOTE[i] == note) return (int)i;
    return -1;
}
unsigned drums_note_of_pad(unsigned pad) { return PAD_NOTE[pad % DRUMS_NPAD]; }

void drums_panic(drums_bank_t *b)
{
    unsigned i;
    for (i = 0; i < DRUMS_NPAD; i++) b->v[i].active = 0;
    b->sub_on = 0;
}
/* the sub's settings: its pitch (a step of the circle is 2 pi f / rate: exact enough below a few hundred Hz), its decay, its drop */
static float sub_exp2(float x)                  /* 2^x, x within +-20 (the decay and the pitch only) */
{
    int n = (int)(x + (x < 0 ? -0.5f : 0.5f));
    float a = (x - (float)n) * 0.6931471805599453f;
    float p = 1.0f + a * (1.0f + a * (0.5f + a * (1.0f / 6.0f + a * (1.0f / 24.0f + a * (1.0f / 120.0f)))));
    union { uint32_t u; float f; } s;
    s.u = (uint32_t)(n + 127) << 23;
    return p * s.f;
}
static void sub_derive(drums_bank_t *b)
{
    float f = 30.0f * sub_exp2((float)b->sub_tune * (2.0f / 127.0f));                       /* 30 .. 120 Hz */
    float T = 0.04f + 0.96f * ((float)b->sub_decay * (1.0f / 127.0f)) * ((float)b->sub_decay * (1.0f / 127.0f));   /* seconds to -60 dB */
    b->sf = 6.2831853f * f * (1.0f / 44100.0f);
    b->sk = 1.0f - 6.9f / (T * 44100.0f);
    b->sg = (float)b->sub_level * (1.0f / 127.0f) * 0.7f * 32768.0f;
    b->spk = 1.0f - 1.0f / (0.025f * 44100.0f);                                             /* the drop settles in about 25 ms */
}

void drums_init(drums_bank_t *b)
{
    unsigned i;
    for (i = 0; i < DRUMS_NPAD; i++) {
        b->v[i].pos = b->v[i].inc = b->v[i].env = b->v[i].envm = b->v[i].gain = 0.0f;
        b->v[i].active = 0; b->v[i].delay = 0;
        b->pv[i * 3u + DRUM_TUNE] = 64; b->pv[i * 3u + DRUM_DECAY] = 127; b->pv[i * 3u + DRUM_LEVEL] = 100;
    }
    b->level = 100; b->crush = 0; b->tone = 127; b->choke = 1;
    b->lp = b->held = b->vint = 0.0f; b->hold_n = 0; b->rng = 0x2F6E2B1u;
    b->sub_level = 0; b->sub_tune = 43; b->sub_decay = 60; b->sub_drop = 40;
    b->sx = b->sy = b->se = b->sf = b->sa = b->sk = b->sg = b->sp = b->spk = 0.0f; b->sub_on = 0; b->sub_delay = 0;
    sub_derive(b);
}
void drums_vintage(drums_bank_t *b, unsigned v) { b->vint = (float)(v > 127u ? 127u : v) * (1.0f / 127.0f); }
void drums_set(drums_bank_t *b, unsigned p, unsigned v)
{
    if (p < DRUMS_PADVALS) b->pv[p] = (uint8_t)v;
    else if (p == DRUMS_LEVEL) b->level = (uint8_t)v;
    else if (p == DRUMS_CRUSH) b->crush = (uint8_t)v;
    else if (p == DRUMS_TONE) b->tone = (uint8_t)v;
    else if (p == DRUMS_CHOKE) b->choke = (uint8_t)v;
    else if (p >= DRUMS_SUBLEVEL && p <= DRUMS_SUBDROP) {
        if (p == DRUMS_SUBLEVEL) b->sub_level = (uint8_t)v; else if (p == DRUMS_SUBTUNE) b->sub_tune = (uint8_t)v;
        else if (p == DRUMS_SUBDECAY) b->sub_decay = (uint8_t)v; else b->sub_drop = (uint8_t)v;
        sub_derive(b);
    }
}

void drums_note(drums_bank_t *b, unsigned note, unsigned vel) { drums_note_at(b, note, vel, 0); }
void drums_note_at(drums_bank_t *b, unsigned note, unsigned vel, uint32_t delay) { drums_note_ex(b, note, vel, delay, 0); }
void drums_note_ex(drums_bank_t *b, unsigned note, unsigned vel, uint32_t delay, int tune_half)
{
    int pad = drums_pad_of_note(note);
    drum_voice_t *v;
    float st, f, r0, r1, vg = 1.0f;
    int i;
    unsigned tune, decay;
    if (pad < 0 || !vel) return;
    v = &b->v[pad];
    tune = b->pv[pad * 3 + DRUM_TUNE]; decay = b->pv[pad * 3 + DRUM_DECAY];
    st = ((float)tune - 64.0f) * (12.0f / 64.0f) + (float)tune_half * 0.5f;     /* the pad's tune, +-12 semitones, and the step's, +-12 */
    if (b->vint > 0.0f) {                                    /* vintage: no two hits alike: a little off pitch and level */
        uint32_t n = b->rng; n ^= n << 13; n ^= n >> 17; n ^= n << 5; b->rng = n;
        st += ((float)(n >> 8) * (1.0f / 8388608.0f) - 1.0f) * 0.4f * b->vint;                  /* +-40 cents at most */
        vg = 1.0f - 0.18f * b->vint * (float)((n >> 3) & 255u) * (1.0f / 255.0f);
    }
    i = (int)st;
    if ((float)i > st) i--;
    f = st - (float)i;
    if (i < -24) { i = -24; f = 0.0f; }
    if (i > 24) { i = 24; f = 0.0f; }
    r0 = SEMI[i + 24]; r1 = SEMI[i + 25];
    v->inc = (float)KIT[pad].rate * (1.0f / 44100.0f) * (r0 + (r1 - r0) * f);
    v->pos = 0.0f;
    v->env = 1.0f;
    if (decay >= 127u) v->envm = 1.0f;                       /* the whole sample */
    else {                                                   /* a fade out, 10 ms .. 0.9 s to -60 dB */
        float x = (float)decay * (1.0f / 127.0f), T = 0.01f + 0.9f * x * x;
        v->envm = 1.0f - 6.9f / (T * 44100.0f);
    }
    v->gain = ((float)vel * (1.0f / 127.0f)) * ((float)b->pv[pad * 3 + DRUM_LEVEL] * 0.01f) * vg;
    v->active = 1;
    v->delay = delay;
    if (pad == HAT_CLOSED && b->choke) b->v[HAT_OPEN].active = 0;
    if (pad == 0 && b->sub_level) {                          /* the kick: its sub starts with it, from the circle's zero crossing */
        float d = (float)b->sub_drop * (1.0f / 127.0f) * 2.0f;   /* the start is up to three times the pitch */
        b->sx = 0.0f; b->sy = 1.0f; b->sa = 1.0f * ((float)vel * (1.0f / 127.0f)) * ((float)b->pv[DRUM_LEVEL] * 0.01f) * vg;
        b->sp = d; b->se = b->sf * (1.0f + d);
        b->sub_on = 1; b->sub_delay = delay;
    }
}

unsigned drums_render(drums_bank_t *b, int32_t *out)
{
    float mix[DRUMS_FRAMES], master = (float)b->level * 0.01f, a, step;
    unsigned p, i, any = 0, rate_n = 1u + b->crush / 32u, sstart;
    for (p = 0; p < DRUMS_NPAD && !b->v[p].active; p++) { }
    if (p == DRUMS_NPAD && !b->sub_on) return 0;                     /* nothing sounds: nothing to do */
    for (i = 0; i < DRUMS_FRAMES; i++) mix[i] = 0.0f;
    for (p = 0; p < DRUMS_NPAD; p++) {
        drum_voice_t *v = &b->v[p];
        const int16_t *d = KIT[p].data;
        uint32_t last = KIT[p].len - 1u;
        float pos, inc, env, envm, g;
        if (!v->active) continue;
        pos = v->pos; inc = v->inc; env = v->env; envm = v->envm; g = v->gain;
        i = v->delay < DRUMS_FRAMES ? v->delay : DRUMS_FRAMES;       /* a delayed hit starts part way into the block */
        v->delay -= i;
        for (; i < DRUMS_FRAMES; i++) {
            uint32_t ip = (uint32_t)pos;
            float f, s;
            if (ip >= last || env < 0.0005f) { v->active = 0; break; }
            f = pos - (float)ip;
            s = (float)d[ip] + ((float)d[ip + 1u] - (float)d[ip]) * f;
            mix[i] += s * (g * env);
            env *= envm;
            pos += inc;
        }
        v->pos = pos; v->env = env;
        if (v->active) any = 1;
    }
    sstart = b->sub_delay < DRUMS_FRAMES ? b->sub_delay : DRUMS_FRAMES; b->sub_delay -= sstart;   /* a delayed kick: its sub starts with it */
    a = b->tone >= 127u ? 1.0f : 0.02f + 0.98f * ((float)b->tone * (1.0f / 127.0f)) * ((float)b->tone * (1.0f / 127.0f));
    step = 1.0f + ((float)b->crush * (1.0f / 127.0f)) * ((float)b->crush * (1.0f / 127.0f)) * 4096.0f;
    for (i = 0; i < DRUMS_FRAMES; i++) {
        float y = mix[i] * master;
        int32_t q;
        if (b->crush) {                                      /* fewer bits and a lower rate */
            if (b->hold_n == 0) {
                q = (int32_t)(y / step);
                b->held = (float)q * step;
            }
            b->hold_n = (b->hold_n + 1u) % rate_n;
            y = b->held;
        }
        b->lp += a * (y - b->lp);
        y = b->lp;
        if (b->sub_on && i >= sstart) {                      /* the sub: the magic circle, after crush and tone */
            b->sx += b->se * b->sy;
            b->sy -= b->se * b->sx;
            y += b->sx * b->sa * b->sg * master;
            b->sa *= b->sk; b->sp *= b->spk; b->se = b->sf * (1.0f + b->sp);
            if (b->sa < 0.002f) b->sub_on = 0;
        }
        y *= 256.0f;                                         /* Q15 -> Q23 */
        q = y > 8388607.0f ? 8388607 : y < -8388607.0f ? -8388607 : (int32_t)y;
        out[i] += q;
    }
    return any || b->sub_on || b->lp > 1.0f || b->lp < -1.0f;
}
