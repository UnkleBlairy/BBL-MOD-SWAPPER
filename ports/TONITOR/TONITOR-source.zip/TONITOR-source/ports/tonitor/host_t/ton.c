/* SPDX-License-Identifier: GPL-3.0-only
 * TONITOR host harness: the firmware's own DSP, sounds, layers and screen, compiled for the computer.
 *
 *   host render DIR [SEEDS]   every FM family and ANIMA kind, SEEDS sounds each (default 3): a note held
 *                             8 s and released, a WAV each, and a line of figures (levels, clipping, cost)
 *   host mix DIR              the six layers entering one after another through the real mixer (mix.wav)
 *   host screens DIR          the screen in several states, as PPM images (tools/ppm2png.py makes PNGs)
 *   host flows                the panel's flows: held notes through changes, two layers at once, no stuck note
 *   host check                every sound of 40 seeds per family / kind: none silent, none clipping hard,
 *                             none running away; exits 1 on a failure (tests/run_tests.sh)
 *
 * Build: tests/run_tests.sh (or see the clang line there). */
#define HOST 1
#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "tonitor_tables.h"

#define NELEM(a) (sizeof(a) / sizeof((a)[0]))
#define RING_PUBLISH() __asm__ volatile("" ::: "memory")
static volatile uint32_t fm1_ms;
static uint32_t host_ticks;
static uint32_t fm1_ticks(void) { return host_ticks += 24000u; }
static void host_pump(void);

static int str_eq(const char *a, const char *b) { while (*a && *a == *b) a++, b++; return *a == *b; }
static int str_cmp(const char *a, const char *b) { while (*a && *a == *b) a++, b++; return (int)(uint8_t)*a - (int)(uint8_t)*b; }   /* (libc.c's: byte order) */
static unsigned str_len(const char *s) { return (unsigned)strlen(s); }
static void str_cpy(char *d, const char *s, unsigned max)
{
    unsigned i = 0;
    while (s[i] && i + 1 < max) {
        d[i] = s[i];
        i++;
    }
    d[i] = 0;
}

static void fmt_fix(char *b, int32_t v, int decimals)   /* (libc.c's) */
{
    char t[12];
    int n = 0, neg = v < 0, i;
    uint32_t u = (uint32_t)(neg ? -v : v);
    do {
        t[n++] = (char)('0' + u % 10u);
        u /= 10u;
        if (n == decimals)
            t[n++] = '.';
    } while (u || n <= decimals);
    if (neg)
        t[n++] = '-';
    for (i = 0; i < n; i++)
        b[i] = t[n - 1 - i];
    b[n] = 0;
}
static void fmt_int(char *b, int32_t v) { fmt_fix(b, v, 0); }

/* the screen: a framebuffer instead of the panel */
#define fb shl_fb   /* teensy-fm1 */
static void lcd_sync(void) {}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h; j++)
        for (i = 0; i < w; i++)
            if (x + i < 240u && y + j < 240u) {
                uint16_t c = px[j * w + i];
                sh_put((y + j) * 240u + x + i, sh_be16((uint16_t)((c >> 8) | (c << 8))));
            }
}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = 0; j < h; j++)
        for (i = 0; i < w; i++)
            if (x + i < 240u && y + j < 240u)
                sh_put((y + j) * 240u + x + i, sh_be16(c));
}

#include "dsp.h"
#include "voice.c"
#include "gfx.c"
#include "logo.c"
#include "fm.c"
#include "anima.c"
#include "cal.c"
#include "russolo.c"
#include "druid.c"
#include "bayarea.c"
#include "hive.c"
#include "obrador.c"
#include "reverb.c"
/* CPU1's mailbox (src/audio_worker.h), as one core sees it: a job posted runs at the join -- the units of work are
 * apart, so the sound is the same as with the two cores at once. host_cores 1: CPU1 off (the one-core path) */
static int audio_worker_online;            /* (0: one core, as the host times it -- the sum of both; cores sets it) */
static void (*host_job)(void *);
static int host_jobs_n;
static void *host_job_ctx;
static int audio_worker_submit(void (*fn)(void *), void *ctx)
{
    if (!audio_worker_online)
        return 0;
    host_job = fn;
    host_job_ctx = ctx;
    return 1;
}
static int audio_worker_join(void)
{
    if (host_job) {
        host_job(host_job_ctx);
        host_jobs_n++;
    }
    host_job = 0;
    return 1;
}
static void audio_worker_check(void) {}
/* usb.c's side, as the tests see it: no host attached; what would be sent out kept, for the MIDI tests */
static struct { uint8_t config, suspended; } usb;
static uint32_t host_mout[256], host_mout_n;
static void midi_out_event(uint32_t pkt)
{
    if (host_mout_n < 256u)
        host_mout[host_mout_n] = pkt;
    host_mout_n++;
}
#define MQ 64u
static uint32_t midi_in_q[MQ];
static volatile uint32_t mi_w, mi_r;
#include "layers.c"

/* the panel */
#define FM1_NCOL 11u
static const int8_t FM1_KEYMAP[6][FM1_NCOL] = {
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}, {5, 11, 4, 10, 3, 9, 2, 8, -1, -1, -1},
    {34, 35, 36, 37, 38, 40, 39, 13, 7, 6, 12}, {23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33},
    {0, 1, 15, 14, 17, 16, 19, 18, 20, 21, 22}, {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}};
static struct { uint32_t notes, buttons; } fm1_in;
static uint32_t host_press, host_rel;
static int32_t host_enc[7];
static uint8_t fm1_led_dim[FM1_NCOL];
static uint32_t fm1_input_edges(uint32_t *rel)
{
    uint32_t p = host_press;
    host_press = 0;
    if (rel)
        *rel = host_rel, host_rel = 0;
    return p;
}
static int32_t fm1_enc_take(uint32_t e)
{
    int32_t s = host_enc[e];
    host_enc[e] = 0;
    return s;
}
static uint8_t host_led[64];
static void fm1_led_key(uint32_t id, int on) { if (id < 64u) host_led[id] = (uint8_t)!!on; }
#include "ui.c"
#include "snaps.c"
#include "sessions.c"
#include "setup.c"
#include "backup.c"

/* the flash, emulated: NOR (erased to 0xFF, programming only clears bits); erases counted */
#ifdef TEENSY_NOR_ADDR                  /* teensy-fm1: real flash, in this ROM's slot */
extern int32_t teensy_nor_erase(uint32_t off);
extern int32_t teensy_nor_prog(uint32_t off, const uint8_t *src, uint32_t n);
#define host_flash ((uint8_t *)TEENSY_NOR_ADDR - SES_LO)
#else
static uint8_t host_flash_[SES_HI - SES_LO];
#define host_flash (host_flash_ - SES_LO)
#endif
static uint32_t host_erases;
static int ses_flash_read(uint32_t off, void *p, uint32_t n)
{
    memcpy(p, host_flash + off, n);
    return 0;
}
static int ses_flash_erase(uint32_t off)
{
    if (off < SES_LO || off + 4096u > SES_HI || (off & 4095u))
        return -8;
#ifdef TEENSY_NOR_ADDR
    if (teensy_nor_erase(off - SES_LO)) return -8;
#else
    memset(host_flash + off, 0xFF, 4096u);
#endif
    host_erases++;
    return 0;
}
static int ses_flash_prog(uint32_t off, const void *p, uint32_t n)
{
    uint32_t i;
    if (off < SES_LO || off + n > SES_HI)
        return -8;
#ifdef TEENSY_NOR_ADDR
    (void)i; if (teensy_nor_prog(off - SES_LO, p, n)) return -8;
#else
    for (i = 0; i < n; i++)
        host_flash[off + i] &= ((const uint8_t *)p)[i];
#endif
    return 0;
}


static int32_t mix_out[2 * CTL];
static uint32_t ms_frac;
static void host_pump(void)
{
    mix_block(mix_out);
    ms_frac += CTL * 1000u;
    fm1_ms += ms_frac / 44100u;
    ms_frac %= 44100u;
}
static float ton_l[1024], ton_r[1024];
static float *ton_lp(void) { return ton_l; }
static float *ton_rp(void) { return ton_r; }
static void ton_render(uint32_t n)
{
    static uint32_t at = CTL;
    uint32_t i;
    for (i = 0; i < n; i++) {
        if (at >= CTL) { host_pump(); at = 0; }
        ton_l[i] = (float)clampi(mix_out[2u * at], -32768, 32767) / 32768.0f;
        ton_r[i] = (float)clampi(mix_out[2u * at + 1u], -32768, 32767) / 32768.0f;
        at++;
    }
}
static void ton_boot(void)
{
#ifndef TEENSY_NOR_ADDR
    memset(host_flash_, 0xFF, sizeof host_flash_);
#endif
    ses_scan(1);
    vo_init();
    setup_load();
    layers_init();
    ui_init();
    sounds_init();
    scale_draw();
    lx_post();
    lcd_fill(0, 0, 240, 240, 0);
    ui.force = 1;
}
static void ton_frame(void) { ui_input(); setup_poll(); midi_poll(); ui_leds(); ui_draw(); reader_tick(); }
