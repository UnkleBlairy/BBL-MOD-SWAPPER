/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: TONITOR 2026.11.10 (https://github.com/nzimas/tonitor) on the Teensy 4.1: its own browser build (host_t/ton.c) inside ports/common's shell */
#include "../../../common/shell_pre.h"
#include <stdlib.h>
#include <time.h>
#ifndef CLOCK_MONOTONIC
#define CLOCK_MONOTONIC 1
static int clock_gettime(int c, struct timespec *t) { (void)c; t->tv_sec = 0; t->tv_nsec = 0; return 0; }
#endif
#define getenv(n) ((char *)0)
#define web_boot o_web_boot
#define web_out_l o_web_out_l
#define web_out_r o_web_out_r
#define web_render o_web_render
#define web_buttons o_web_buttons
#define web_keys o_web_keys
#define web_enc o_web_enc
#define web_master o_web_master
#define web_nor_erase o_web_nor_erase
#define web_ms o_web_ms
#define web_frame o_web_frame
#include "../../host_t/ton.c"
#undef __attribute__
#undef EXPORT
#undef memset
#undef memcpy
#undef memcmp
#undef memmove
#undef web_boot
#undef web_out_l
#undef web_out_r
#undef web_render
#undef web_buttons
#undef web_keys
#undef web_enc
#undef web_master
#undef web_nor_erase
#undef web_ms
#undef web_frame
#define SH_FLOAT
#define SH_OUT_L ton_lp
#define SH_OUT_R ton_rp
#define SH_RENDERF(n) ton_render(n)
#define SH_ADC(m) (master_q12 = (int32_t)((m * m) >> 8))
static void SH_BOOT(void) { ton_boot(); }
static void SH_FRAME(uint32_t ms)
{ (void)ms; ton_frame(); }
#define SH_ENC(e, n) (host_enc[e] += (n))
#define SH_BTN(i, d) do { if (d) { fm1_in.buttons |= 1u << (i); host_press |= 1u << (i); } else { fm1_in.buttons &= ~(1u << (i)); host_rel |= 1u << (i); } } while (0)
#define SH_KEY(k, d) (fm1_in.notes = (fm1_in.notes & ~(1u << (k))) | (uint32_t)(d) << (k))
#define SH_KEY_LED(k) (host_led[14u + (k)] ? 2 : 0)
#define SH_BTN_LED(i) (host_led[i] ? 2 : 0)
#include "../../../common/shell_post.h"
