TONITOR 2026.11.10 for the BBL Mod Swapper

Original by nzimas: https://github.com/nzimas/tonitor
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: TONITOR-source.zip on the ports page.
