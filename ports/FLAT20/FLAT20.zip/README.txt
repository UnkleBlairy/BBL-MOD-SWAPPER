FLAT-20 0.3.2 for the BBL Mod Swapper

Original by thenewwazoo: https://github.com/thenewwazoo/FLAT-20
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: FLAT20-source.zip on the ports page.
