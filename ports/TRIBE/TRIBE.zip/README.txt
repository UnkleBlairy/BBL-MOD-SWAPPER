TRIBE 0.3 for the BBL Mod Swapper

Original by apiel: https://github.com/apiel/fm1-tribe
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: TRIBE-source.zip on the ports page.
