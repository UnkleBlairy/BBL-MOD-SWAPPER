/* SPDX-License-Identifier: GPL-3.0-only */
/* DUB-1 UI: the panel and the screen. Part of the unity build (after gfx.c and project.c); the host
 * simulator includes it too.
 *
 *   keys           the scale: each key adds or removes its note from the pool (the root stays)
 *   PLAY           plays / rests                   EDIT  tapped: the CHORDS page (eight slots: KNOB 1 the slot, the
 *                  keys its root, KNOB 2 its kind, KNOB 3 its type, KNOB 4 Play: Endless or Loop); held: the next chord
 *   REC            tapped: DUB HOLD (the echo repeats what it holds, the chord holds); held: the EFFECTS grid, played
 *                  on the white keys while they're held
 *   OCT- / OCT+    on the Sequence's, the Lead's and Sequence 2's pages: its octave, a step a press (both held 5 s:
 *                  the update mode)
 *   SEL            PERFORM: the keys mute (white 1-5) and solo (black 1-5) the layers and, held, make the dub moves
 *                  (white 7-11); the knobs the master actions (Filter, Dub, Energy, Space), with white 6 held the mix
 *   SELECT         a layer's pages: its level (elsewhere nothing)   ALGORITHM the voice, the walk
 *                  (Chords), the noise's character                    PRESETS the piece
 *   FX ENV LFO GLO / HOME SAVE ARP SEQ   the pages: SPACE, CHORD, BASS, SETUP / DUB, NOISE, PINGS, DRUMS
 *   KNOB 1-4       the page's four values
 *   GLO held       saves (it also saves by itself a few seconds after a change, while resting);
 *                  held on 1.5 s: the piece back to its recipe */
#include "../dsp/fastmath.h"

/* the pages, one a layer (a button each, NPAGES; the Noise page, V_NSND, SAVE's); the header's dots show them in the
 * panel's order, PAGE_ORDER below (the view numbers stay as they were: the tests use them) */
/* (past NPAGES, on no button of their own: V_MIX, PERFORM's knobs, the four layers' levels; the layers' sound
 * pages, the layer's button pressed again) */
enum { V_DUB, V_CHORD, V_TEXTURE, V_BASS, V_DRUMS, V_SPACE, V_SETUP, NPAGES, V_MIX = NPAGES, V_CSND, V_PSND, V_BSND,
       V_DSND, V_CFM, V_PFM, V_BFM, V_CHORDS, V_PAT, V_PERF, V_KEY, V_NSND, V_ESND, V_NSND2, V_ARC, V_SMOVE, V_S2MOVE, V_AMOVE,
       V_LSTYLE, V_SET, NVIEWS };            /* (1.4) V_SET: the journey's set list, GLO a third time */
/* (V_PERF: PERFORM's knobs, the master actions; V_MIX while white 6 is held. V_KEY: HOME again, the key and the
 * tempo, the Dub page's second) */
static const char *const VIEW_NAME[NVIEWS] = {"Aisling", "Drone", "Sequence", "Lead", "Sequence 2", "Space", "Setup",
                                              "Mix", "Drone sound", "Seq sound", "Lead sound", "Seq2 sound",
                                              "Drone move", "Repeats", "Lead move", "Chords", "Pattern", "Perform", "Key",
                                              "Atmosphere", "Echo", "Atmos sound", "Arc", "Seq move", "Seq2 move",
                                              "Atmos move", "Lead style", "Journey"};
#define B_NONE 0xFFu
static const uint8_t VIEW_BTN[NVIEWS] = {B_HOME, B_ENV, B_ARP, B_LFO, B_SEQ, B_FX, B_GLO, B_NONE, B_NONE, B_NONE, B_NONE,
                                         B_NONE, B_NONE, B_NONE, B_NONE, B_NONE, B_NONE, B_NONE, B_NONE, B_SAVE, B_NONE, B_NONE,
                                         B_NONE, B_NONE, B_NONE, B_NONE, B_NONE, B_NONE};
static int sound_of(int v) { return v == V_CHORD ? V_CSND : v == V_TEXTURE ? V_PSND : v == V_BASS ? V_BSND : v == V_DRUMS ? V_DSND : -1; }
static int fm_of(int v) { return v == V_TEXTURE ? V_PFM : -1; }   /* (BERLIN: no FM pages; the Sequence's third, its
                                                                   * Repeats, in the Ping FM page's place) */
static int parent_of(int v)
{
    return v == V_CSND || v == V_CFM ? V_CHORD : v == V_PSND || v == V_PFM || v == V_SMOVE ? V_TEXTURE
         : v == V_BSND || v == V_LSTYLE || v == V_BFM ? V_BASS : v == V_DSND || v == V_PAT || v == V_S2MOVE ? V_DRUMS : -1;
}
static int next_page(int v)                      /* (BERLIN) a layer's button again: its next page, the last back to the
                                                  * first (the Move page, the filter motion's, last) */
{
    switch (v) {
    case V_CSND: return V_CFM;
    case V_PSND: return V_PFM;
    case V_PFM: return V_SMOVE;
    case V_BSND: return V_LSTYLE;                /* (AISLING: how it plays, Ornament's page, before its Move) */
    case V_LSTYLE: return V_BFM;
    case V_DSND: return V_PAT;
    case V_PAT: return V_S2MOVE;
    default: return parent_of(v);
    }
}
static int atm_view(int v) { return v == V_NSND || v == V_NSND2 || v == V_AMOVE; }   /* (the Atmosphere's pages) */
static int page_of(int v)                        /* a sound page: its layer's; the Echo page: Space's */
{
    return v == V_KEY ? V_DUB : v == V_ESND ? V_SPACE : v == V_NSND2 || v == V_AMOVE ? V_NSND : v == V_ARC || v == V_SET ? V_SETUP
         : parent_of(v) >= 0 ? parent_of(v) : v;
}
/* the header's dots, as the buttons sit on the panel: FX ENV LFO GLO, then HOME SAVE ARP SEQ (SELECT's round once) */
#define NROUND 8
static const uint8_t PAGE_ORDER[NROUND] = {V_SPACE, V_CHORD, V_BASS, V_SETUP, V_DUB, V_NSND, V_TEXTURE, V_DRUMS};
/* (0.5) each round stop's pages, in the order its button steps through them: the dots at the knob rule's right end */
#define NO_PAGE 0xFFu
static const uint8_t PAGE_RUN[NROUND][4] = {
    {V_SPACE, V_ESND, NO_PAGE, NO_PAGE},   {V_CHORD, V_CSND, V_CFM, NO_PAGE},
    {V_BASS, V_BSND, V_LSTYLE, V_BFM},     {V_SETUP, V_ARC, V_SET, NO_PAGE},
    {V_DUB, V_KEY, NO_PAGE, NO_PAGE},      {V_NSND, V_NSND2, V_AMOVE, NO_PAGE},
    {V_TEXTURE, V_PSND, V_PFM, V_SMOVE},   {V_DRUMS, V_DSND, V_PAT, V_S2MOVE},
};
static int page_dots(int v, int *at)             /* how many pages v's button has (0: v is on none), and which is v */
{
    int r, j, n;
    for (r = 0; r < NROUND; r++)
        if (PAGE_ORDER[r] == page_of(v))
            break;
    if (r == NROUND || page_of(v) == V_MIX || page_of(v) == V_PERF)
        return 0;
    for (j = n = 0; j < 4; j++)
        if (PAGE_RUN[r][j] != NO_PAGE) {
            if (PAGE_RUN[r][j] == v)
                *at = j;
            n++;
        }
    return n;
}
/* the layer a page is (SELECT: its level; OCT- / OCT+: its octave): the Chord, Pings, Bass, Drums and Noise pages
 * and their sound, FM and Pattern pages; -1 elsewhere (the Chords page too) */
#define NLAYER 5
static int oct_layer(int v)
{
    v = parent_of(v) >= 0 ? parent_of(v) : v;
    return v == V_CHORD ? 0 : v == V_TEXTURE ? 1 : v == V_BASS ? 2 : v == V_DRUMS ? 3 : atm_view(v) ? 4 : -1;
}
/* the four knobs of each page: a parameter, or one of these; and what the knob is called there */
enum { K_LEDS = 200, K_CPU, K_NONE, K_SLOT, K_CQ, K_CX,    /* (the Chords page: the slot, and its kind and type) */
       K_LANE, K_LCH,                                        /* (the Pattern page: the lane, and its chance) */
       K_FILTER, K_DUB, K_ENERGY, K_SPACE,                   /* the master actions (EN_MAC_*), in that order */
       K_MODE,                                               /* (the Key page: the mode, as ALGORITHM sets it) */
       K_PLAY,                                               /* (the Chords page: Endless or Loop, P_PMODE's bit 2) */
       K_SAVE,                                               /* (Setup: a turn saves; it shows whether it's saved) */
       K_CHORUS,
       K_JRP, K_JRIN, K_DAY,
       K_SCR };                                              /* (1.4.1) the screen, dark or light: saved, as Lights */
#define NDAY 4                                   /* (1.4) the day: off, or a whole day in 20 minutes, 1 hour, 3 hours */
static const char *const DAY_NAME[NDAY] = {"Off", "20 min", "1 hour", "3 hours"};
static void dy_set(int v);
enum { DUMMY_K_END = 0 };                                      /* (1.4, the Set list page: the piece, and whether it's in) */                                           /* (1.3, PERFORM: the output's chorus, never saved) */
static const char *const LANE_NAME[EN_NDRUM] = {"Steps", "Steps 2", "Octaves", "Octaves 2", "Skips"};   /* (BERLIN:
                                                  * the Sequence's and Sequence 2's) */
static int lane_seq(int d) { return d == 1 || d == 3; }   /* (a lane's sequence: its accents, its chance) */
_Static_assert(P_NPARAMS <= K_LEDS, "the knobs' own codes must come after the parameters");
static const uint16_t VIEW_KNOB[NVIEWS][4] = {
    {K_FILTER, P_EVOLVE, P_MOTION, P_DRIFT},
    {P_PEDAL, P_CRES, P_PHASER, P_CATT},          /* (BERLIN) the Drone */
    {P_DENSITY, P_SEQOCT, P_SEQLEN, P_SEQGRID},  /* the Sequence */
    {P_LDENS, P_LOCT, P_ORN, P_VIB},             /* (the Lead; AISLING: Ornament for Glide, on Lead style) */
    {P_SCH1, P_SEQ2OCT, P_SEQ2LEN, P_SEQ2},      /* (Sequence 2) */
    {P_ECHO, P_ETIME, P_FEEDBACK, P_REVERB},
    {P_TUNE, P_MIDI, K_LEDS, K_SAVE},
    {P_CHORD, P_SEQ, P_LEAD, P_SEQ2},
    {P_CCOL, P_DREL, P_DRREV, P_DRECHO},        /* the Drone's sound */
    {P_CUTOFF, P_DECAY, P_SQREV, P_SQECHO},      /* the Sequence's sound */
    {P_LTONE, P_LATT, P_LDREV, P_LDECHO},        /* the Lead's sound */
    {P_S2CUT, P_S2DEC, P_S2REV, P_S2ECHO},       /* Sequence 2's sound */
    {P_MW0, P_MT0, P_MR0, P_MI0},                /* the Drone's Move (ENV, a third time) */
    {P_TAPA, P_TAPAT, P_TAPB, P_TAPBT},          /* the Sequence's repeats (its third page) */
    {P_MW2, P_MT2, P_MR2, P_MI2},                /* the Lead's Move (LFO, a third time) */
    {K_SLOT, K_CQ, K_CX, K_PLAY},
    {K_LANE, P_SACCENT, K_LCH, P_SMODE},
    {K_FILTER, K_DUB, K_ENERGY, K_CHORUS},        /* (Wet, Energy: offsets for playing; (1.3) Chorus the same. Sweep,
                                                   * here till 1.3, is the Sequence's Move page's Width) */
    {P_TEMPO, P_ROOT, K_MODE, P_TRANS},
    {P_NGRAIN, P_NWIDTH, P_NDRIFT, P_NROOM},       /* the Atmosphere */
    {P_EBLUR, P_ETONE, P_EWIDTH, P_SIZE},
    {P_NCOL, P_NTUNE, P_NPLATE, P_NECHO},      /* its space */
    {P_LDIN, P_BRIDGE, P_ARC, P_LMEM},         /* the Arc (GLO again): how the piece builds (the intros are each
                                                  * layer's, on its Move page), and how much the Lead keeps its ideas */
    {P_MW1, P_MT1, P_MR1, P_MI1},                /* the Sequence's Move (ARP, a fourth time; its Width is Sweep) */
    {P_MW3, P_MT3, P_MR3, P_MI3},                /* Sequence 2's Move (SEQ, a fourth time) */
    {P_MW4, P_MT4, P_MR4, P_MI4},                /* the Atmosphere's Move (SAVE, a third time) */
    {P_ORN, P_GLIDE, P_VIB, P_LMEM},             /* (AISLING) Lead style (LFO, a third time): how it plays; Memory
                                                  * as on the Arc page */
    {K_JRP, K_JRIN, K_SCR, K_DAY},              /* (1.4) the Journey (GLO, a third time): its pieces; the day */
};
static const char *const KNOB_LABEL[NVIEWS][4] = {
    {"Filter", "Evolve", "Motion", "Drift"},
    {"Pedal", "Reso", "Phaser", "Attack"},
    {"Density", "Octave", "Length", "Grid"},
    {"Phrases", "Octave", "Ornament", "Vibrato"},
    {"Chance", "Octave", "Length", "Level"},
    {"Echo", "Echo time", "Feedback", "Reverb"},
    {"Tune", "MIDI out", "Lights", "Save"},
    {"Drone", "Seq", "Lead", "Seq 2"},
    {"Colour", "Release", "Reverb", "Echo"},
    {"Cutoff", "Decay", "Reverb", "Echo"},
    {"Tone", "Attack", "Reverb", "Echo"},
    {"Cutoff", "Decay", "Reverb", "Echo"},
    {"Width", "Time", "Rate", "Intro"},
    {"Repeat A", "A time", "Repeat B", "B time"},
    {"Width", "Time", "Rate", "Intro"},
    {"Slot", "Chord", "Type", "Play"},
    {"Lane", "Accent", "Chance", "Play"},
    {"Filter", "Wet", "Energy", "Chorus"},
    {"Tempo", "Root", "Mode", "Transpose"},
    {"Density", "Width", "Drift", "Air"},
    {"Blur", "Tone", "Width", "Size"},
    {"Colour", "Ring", "Reverb", "Echo"},
    {"Lead in", "Bridge", "Arc", "Memory"},
    {"Width", "Time", "Rate", "Intro"},
    {"Width", "Time", "Rate", "Intro"},
    {"Width", "Time", "Rate", "Intro"},
    {"Ornament", "Glide", "Vibrato", "Memory"},
    {"Piece", "In set", "Screen", "Day"},
};
/* what each knob does, a line: on the rule above the knobs while it's being turned (in capitals; each fits the
 * rule's 228 px, and every view has its row: the host's expect helpfit) */
_Static_assert(NVIEWS == 28, "a view added: its KNOB_HELP row too");
static const char *const KNOB_HELP[NVIEWS][4] = {   /* (BERLIN's, a row a view, V_DUB .. V_ARC) */
    {"Down shuts, up opens; Off mid", "How often a step changes", "How much, and the sections' pace", "Bars before the chord moves on"},
    {"The root an octave under", "The filter's resonance", "The slow phaser's depth", "How slowly the chord swells in"},
    {"How many of the steps sound", "Two octaves down to two up", "Steps before it returns", "Eighths, or sixteenths"},
    {"How often it plays a phrase", "Two octaves down to one up", "Cuts, rolls, slides: how often", "How deep the late vibrato"},
    {"How likely each note plays", "Its octave (Motion moves it a while)", "Steps: a step short, it drifts", "Its level"},
    {"How much goes into the echo", "The echo's time: 1/8 to a bar", "How long the repeats go on", "How much goes into the plate"},
    {"Fine tuning, in cents", "Notes and clock out over MIDI", "The keys' and buttons' lights", "A turn saves all eight pieces"},
    {"The Drone's level", "The Sequence's level", "The Lead's level", "Sequence 2's level"},
    {"Darker, or brighter and wider", "How long it fades at a change", "How much goes into the plate", "How much goes into the echo"},
    {"The filter: dark to bright", "How long each note rings", "How much goes into the plate", "How much goes into the echo"},
    {"Dark and soft, or bright", "How slowly a note swells in", "How much goes into the plate", "How much goes into the echo"},
    {"The filter: dark to bright", "How long each note rings", "How much goes into the plate", "How much goes into the echo"},
    {"How far its filter wanders", "How long one move takes", "How often a new move starts", "Bars its filter takes to open"},
    {"Each note again, as loud: 100", "When: a dotted eighth, classic", "A second repeat, into rests", "When the second comes"},
    {"How far its tone wanders: gently", "How long one move takes", "How often a new move starts", "Bars its tone takes to open"},
    {"The slot you're writing", "Its kind (Empty: a gap)", "Triad, 6, 7, Maj7, 9, 11, Add9", "Endless, or the slots in a loop"},
    {"The lane you're writing", "How much quieter off the root", "How likely the lane's steps play", "Auto patterns, or your own"},
    {"Down shuts, up opens; Off mid", "The whole music dry, or drowned", "Sparser, or busier", "The whole music, thickened"},
    {"Beats a minute", "The key's root note", "The scale: Minor, Major, ...", "How the steps follow the chord"},
    {"How busy it is", "Mono, to wide", "How quickly it changes", "The air under it"},
    {"Clean repeats, to a dissolving wash", "The repeats darker, or brighter", "The echo mono, to wide", "How long the plate rings"},
    {"Darker, or brighter", "How much it rings", "How much goes into the plate", "How much goes into the echo"},
    {"Bars before the Lead may start", "How far the bridge moves filters", "The Sequence's long rise: 0 none", "How much the Lead keeps its ideas"},
    {"How far its filter wanders", "How long one move takes", "How often a new move starts", "Bars its filter takes to open"},
    {"How far its filter wanders", "How long one move takes", "How often a new move starts", "Bars its filter takes to open"},
    {"How far its filter wanders", "How long one move takes", "How often a new move starts", "Bars its filter takes to open"},
    {"Cuts, rolls, slides: how often", "How long it slides, note to note", "How deep the late vibrato", "How much the Lead keeps its ideas"},
    {"Which piece: the journey's list", "The journey plays it, or passes", "Dark, on black; or light, on white", "Dawn to night: light and weather"},
};

/* (BERLIN) the screen's colours: Cosmic, on black (spec 15): lavender text, a cyan accent; the layers in their own
 * colours, the Drone violet, the Sequence pink, the Lead gold, Sequence 2 cyan, the Atmosphere dim lavender; each with a
 * dark tint for the shapes at rest. (The names stay DUB-1's: K_PAD the Drone, K_BELL the Sequence, K_BASS the Lead,
 * K_PULSE Sequence 2, K_NOISE the Atmosphere.) */
/* (1.4.1) the colours by night (as they were, on black) and by day (on bainin white: the same hues, darker, so
 * each reads on it; a tint is pale, not dark). the Journey page's Screen sets which; proj.light keeps it. */
enum { KC_BG, KC_PANEL, KC_LINE, KC_DIM, KC_TEXT, KC_ACC, KC_BELL, KC_BELL_T, KC_PAD, KC_PAD_T, KC_PULSE, KC_PULSE_T, KC_BASS, KC_BASS_T, KC_FROST, KC_FROST_T, KC_RIM, KC_RIM_T, KC_CLAP, KC_CLAP_T, KC_EIRE, KC_EIRE_O, KC_NOISE, KC_SEA, KC_HEATHER, KC_GORSE, KC_BAININ, KC_N };
static const uint16_t KPAL[2][KC_N] = {
    {RGB(0, 0, 0), RGB(26, 23, 38), RGB(46, 41, 66), RGB(141, 127, 184), RGB(239, 231, 255), RGB(127, 216, 255), RGB(255, 106, 213), RGB(96, 36, 82), RGB(180, 140, 255), RGB(58, 44, 96), RGB(127, 216, 255), RGB(36, 66, 84), RGB(255, 210, 127), RGB(98, 80, 44), RGB(232, 92, 84), RGB(128, 56, 52), RGB(214, 124, 176), RGB(108, 58, 86), RGB(232, 206, 98), RGB(108, 98, 48), RGB(52, 196, 116), RGB(255, 146, 72), RGB(186, 174, 156), RGB(72, 188, 176), RGB(198, 150, 210), RGB(244, 200, 56), RGB(246, 238, 214)},
    {RGB(250, 247, 240), RGB(232, 226, 240), RGB(206, 198, 224), RGB(108, 94, 150), RGB(24, 18, 40), RGB(0, 118, 170), RGB(204, 40, 150), RGB(242, 204, 230), RGB(120, 80, 210), RGB(222, 210, 246), RGB(0, 128, 180), RGB(198, 228, 240), RGB(176, 118, 0), RGB(240, 224, 190), RGB(200, 50, 44), RGB(246, 208, 204), RGB(170, 70, 130), RGB(240, 208, 226), RGB(150, 124, 0), RGB(238, 230, 190), RGB(20, 140, 80), RGB(200, 90, 10), RGB(120, 110, 96), RGB(0, 128, 118), RGB(140, 80, 160), RGB(166, 118, 0), RGB(40, 34, 30)},
};
static const uint16_t *kpal = KPAL[0];
static void pal_sync(void);                      /* kpal as proj.light says, and all drawn again when it changed */
#define K_BG kpal[KC_BG]
#define K_PANEL kpal[KC_PANEL]
#define K_LINE kpal[KC_LINE]
#define K_DIM kpal[KC_DIM]
#define K_TEXT kpal[KC_TEXT]
#define K_ACC kpal[KC_ACC]         /* the accent: the page, the knob being turned, a message's word */
#define K_BELL kpal[KC_BELL]
#define K_BELL_T kpal[KC_BELL_T]
#define K_PAD kpal[KC_PAD]
#define K_PAD_T kpal[KC_PAD_T]
#define K_PULSE kpal[KC_PULSE]
#define K_PULSE_T kpal[KC_PULSE_T]
#define K_BASS kpal[KC_BASS]
#define K_BASS_T kpal[KC_BASS_T]
#define K_FROST kpal[KC_FROST]         /* dub hold */
#define K_FROST_T kpal[KC_FROST_T]
#define K_RIM kpal[KC_RIM]         /* the rim */
#define K_RIM_T kpal[KC_RIM_T]
#define K_CLAP kpal[KC_CLAP]         /* the clap */
#define K_CLAP_T kpal[KC_CLAP_T]
#define K_EIRE kpal[KC_EIRE]         /* (AISLING) the triskele's green */
#define K_EIRE_O kpal[KC_EIRE_O]       /* (AISLING) and the flag's orange: the launch screen's "by" */
#define K_NOISE kpal[KC_NOISE]       /* the noise (its level ring) */

static struct {
    uint8_t view;
    uint8_t perf, perf_from;           /* PERFORM (SEL): the keys play the mutes and the moves, the knobs
                                        * the mix; the page it was started from */
    uint32_t mutes, moves;             /* the layers muted (EN_M_*), the moves held (EN_PF_*) */
    uint32_t solo;                     /* the layers soloed (EN_M_*): the others muted while any is */
    uint8_t chorus;                    /* (1.3) PERFORM's Chorus, 0..100, never saved */
    int8_t mac[EN_NMAC];               /* the master actions (HOME's Filter, PERFORM's knobs): -50..50, never saved */
    uint32_t pheld, platch;            /* (1.3) PERFORM's keys held, and latched (a bit a key, PKEY's) */
    uint32_t pcc;                      /* (1.3) the effects a CC holds, on any page (a bit a key, PKEY's) */
    uint8_t pamt[32], psent[34];       /* (1.4) each key's amount as its CC last had it (64..127), and what the
                                        * engine was last sent (by the engine's numbers; 0: nothing yet, full) */
    uint32_t pnow, pout;               /* every effect sounding (the link's STATE); those by hand, as last sent out */
    uint32_t fx;                       /* the effects held (EN_FX_*), REC's grid */
    uint32_t bfx;                      /* (BERLIN) the grid's effects held on the black keys (EN_FX_*) */
    uint8_t mv;                        /* (BERLIN) the black keys' moves held (EN_MV_*) */
    uint8_t day, shower;               /* (1.4) the day (DAY_NAME's); its shower falling (Fras, lightly) */
    uint8_t jr_out, jr_cur;            /* (1.4) the Set list: the pieces left out (a bit each), the one looked at */
    uint8_t slot, chords_from;         /* the Chords page: the slot edited; the page it was opened from */
    uint8_t noise_from;                /* the Noise page (SAVE): the page it was opened from */
    int8_t oct_home[NLAYER];           /* each layer's octave as its piece was loaded (OCT- / OCT+ lit away from it) */
    uint8_t oct_ring;                  /* the level ring in the middle (SELECT): its layer + 1 (0: none) */
    uint8_t s2_hand;                   /* Sequence 2's Octave set by hand while Motion had it shifted: the shift not
                                        * shown till the engine has dropped it (a block later) */
    uint32_t card_until, card_t0;      /* a nudge's card in the middle: up until, then fading; when it came */
    uint32_t flash_until;              /* (0.5) a button's new page: its name large, up until, then fading */
    uint8_t card_shake;                /* the card a big move's (red: a shake, new chords, a reset) or not */
    uint16_t card_col;                 /* its colour */
    uint8_t lock;                      /* Lock (SEL held): each phrase keeps what it has */
    char card_head[16], card_text[24];
    uint32_t oct_until, oct_pulse;     /* the ring: up until, then fading; its last step (a pulse) */
    uint32_t sel_until;                /* (HOME) SELECT's Energy on the knobs' rule, up until */
    float oct_v;                       /* the ring's arc, gliding to the level */
    uint32_t prog_gen;                 /* the engine's slots, as last taken (en_prog_gen) */
    uint8_t lane;                      /* the Pattern page: the lane edited */
    uint8_t grid_said;
    uint32_t btn, keys, btn_used;
    uint32_t enc_t[NE];
    uint8_t enc_run[NE];               /* detents in the current quick run, per knob (accel) */
    uint32_t down_t[NB];               /* when each button went down */
    uint32_t turn_t;                   /* the last knob turn */
    uint8_t reset_done;                /* SAVE held: the piece went back to its recipe this hold */
    uint8_t dirty;                     /* the project changed since the last save */
    uint32_t act_t, saved_t;
    char msg[2][24];
    uint32_t msg_until;
    int8_t touched;                    /* the knob turned last (0..3), shown bright for a moment */
    uint32_t touch_until;
    uint32_t frame;
    uint32_t sig[3];                   /* what each band shows: redrawn when it changes */
} ui;

/* the screen reader (announce.c; speak() below): a message went to it this frame, so speak() leaves what it
 * changed be; and the transport as last said (PLAY says its own: the engine takes it a block later) */
static uint8_t sp_said;
static char sp_buf[ANN_MAX + 1];                 /* (the screen reader's text, built below) */
static uint32_t sp_n;
static void sp_cat(const char *s);
static struct {
    uint8_t playing;
    uint32_t play_t;                   /* when PLAY (or the start) set it: the engine catches up within ms */
} sp_tp;
static void sp_piece(void);
static void msg_text(const char *a, const char *b, char *t)   /* the message as a reader gets it: "a b" */
{
    uint32_t i, k = 0;
    for (i = 0; i < 23u && a && a[i]; i++)
        t[k++] = a[i];
    if (b && b[0])
        t[k++] = ' ';
    for (i = 0; i < 23u && b && b[i]; i++)
        t[k++] = b[i];
    while (k && t[k - 1] == '.')               /* "UPDATE MODE IN 3..": the dots are for the eye */
        k--;
    t[k] = 0;
}
/* a message for a moment in the header; flags: how a screen reader gets it (0: the caller tells it) */
static void say_as(const char *a, const char *b, uint32_t flags)
{
    uint32_t i;
    char t[48];
    for (i = 0; i < 23u && a && a[i]; i++)
        ui.msg[0][i] = a[i];
    ui.msg[0][i] = 0;
    for (i = 0; i < 23u && b && b[i]; i++)
        ui.msg[1][i] = b[i];
    ui.msg[1][i] = 0;
    ui.msg_until = plat_ms() + 1300u;
    if (flags && ann_on()) {
        msg_text(a, b, t);
        ann_say(t, 0, flags);
        sp_said = 1;
    }
}
static void say(const char *a, const char *b) { say_as(a, b, ANN_NOW); }
/* a long press's card in the middle (a nudge, a shake, the next chord, new chords, saved, a reset): what it did, in
 * big, outlined in its colour; it fades out CARD_SHOW after (draw_card) */
#define CARD_SHOW 1500u
#define CARD_FADE 300u
static int str_begins(const char *s, const char *p)   /* (the firmware's libc has no strcmp, strncmp) */
{
    while (*p && *s == *p)
        s++, p++;
    return !*p;
}
static int card_on(uint32_t now) { return ui.card_until && now < ui.card_until + CARD_FADE; }
#define FLASH_SHOW 700u
#define FLASH_FADE 200u
static int flash_on(uint32_t now) { return ui.flash_until && now < ui.flash_until + FLASH_FADE; }
static void card_show(const char *head, const char *text, uint16_t col, int big)
{
    int i;
    for (i = 0; head && head[i] && i < (int)sizeof ui.card_head - 1; i++)
        ui.card_head[i] = head[i];
    ui.card_head[i] = 0;
    for (i = 0; text && text[i] && i < (int)sizeof ui.card_text - 1; i++)
        ui.card_text[i] = text[i];
    ui.card_text[i] = 0;
    ui.card_col = col;
    ui.card_shake = (uint8_t)big;
    ui.card_t0 = plat_ms();
    ui.card_until = ui.card_t0 + CARD_SHOW;
}
/* something did not happen: a screen reader says it whole (what follows does not cut it off) */
static void warn(const char *a, const char *b) { say_as(a, b, ANN_NOW | ANN_KEEP); }
void ui_say(const char *a, const char *b) { say(a, b); }

static void itoa_u(uint32_t v, char *b)
{
    char t[12];
    int n = 0;
    do {
        t[n++] = (char)('0' + v % 10u);
        v /= 10u;
    } while (v);
    while (n)
        *b++ = t[--n];
    *b = 0;
}

/* (0.5) undo: the piece's settings as they were before an edit, UNDO_N times back, in RAM only, and gone with a
 * change of piece. Every edit ends in mark_dirty, when the piece has already changed, so the state before it is
 * kept all the time (shadow, each frame while nothing is under way) and the first edit after UNDO_GAP of quiet
 * pushes it. What was undone sits at the top of the same array, growing down, as the redo (un + rn <= UNDO_N).
 * Evolve's own moves aren't edits. The sequences' patterns aren't in it: taking them back restarts them. */
/* the USB link (link.c): buttons and keys held from the other end, what's lit, and a count that moves when the pieces
 * themselves change */
static uint32_t link_v_btn, link_v_keys, link_lit_b, link_lit_k;
static uint8_t link_gen;

#define UNDO_N 16
#define UNDO_GAP 800u
typedef struct {
    int16_t par[P_NPARAMS];
    uint16_t pool;
} undo_t;
static struct {
    undo_t hist[UNDO_N], shadow;
    uint8_t un, rn;
    uint8_t open;                                /* an edit under way: the state before it is pushed */
    uint8_t evolve;                              /* (Evolve moving: not an edit) */
    uint32_t t;                                  /* the last edit */
} ud;
static void undo_capture(undo_t *s)
{
    int p;
    for (p = 0; p < P_NPARAMS; p++)
        s->par[p] = proj.par[p];
    s->pool = proj.pool;
}
static int undo_skip(int p, int endless)         /* Tune and MIDI out aren't the piece's; Endless moves the chords itself */
{
    return global_par(p) || (endless && p >= P_CR0 && p <= P_CX7);
}
static int undo_same(const undo_t *s)            /* the piece as s has it? */
{
    const int endless = !(proj.par[P_PMODE] & EN_PLOOP);
    int p;
    for (p = 0; p < P_NPARAMS; p++)
        if (!undo_skip(p, endless) && s->par[p] != proj.par[p])
            return 0;
    return s->pool == proj.pool;
}
static void undo_close(void)                     /* the edit under way is over; up and back again leaves no entry */
{
    if (!ud.open)
        return;
    ud.open = 0;
    if (ud.un && undo_same(&ud.hist[ud.un - 1]))
        ud.un--;
    undo_capture(&ud.shadow);
}
static void undo_push(void)
{
    int i;
    if (ud.un == UNDO_N) {                       /* (full: the oldest goes) */
        for (i = 1; i < UNDO_N; i++)
            ud.hist[i - 1] = ud.hist[i];
        ud.un--;
    }
    ud.hist[ud.un++] = ud.shadow;
    ud.rn = 0;
    ud.open = 1;
    ud.t = plat_ms();
}
static void undo_clear(void)
{
    ud.un = ud.rn = ud.open = 0;
    undo_capture(&ud.shadow);
}
static void undo_tick(void)
{
    if (!ud.open)
        undo_capture(&ud.shadow);
    else if (plat_ms() - ud.t >= UNDO_GAP)
        undo_close();
}
static void mark_dirty(void)
{
    ui.dirty = 1;
    if (ud.evolve)
        return;
    if (ud.open)
        ud.t = plat_ms();
    else if (!undo_same(&ud.shadow))             /* (Lights, Tune, MIDI out, the screen's view: no entry) */
        undo_push();
}
int ui_dirty(void) { return ui.dirty != 0; }

static uint32_t pool_abs(void)                 /* the pool as absolute pitch classes */
{
    uint32_t p = proj.pool, r = (uint32_t)proj.par[P_ROOT];
    return ((p << r) | (p >> (12u - r))) & 0xFFFu;
}
static const char *mode_name(void)
{
    return proj.pool == EN_MODE_POOL[proj.par[P_MODE]] ? EN_MODE_NAME[proj.par[P_MODE]] : "Custom";
}

/* ------------------------------------------------------------ values --- */
/* the modes as they're stepped through (ALGORITHM, the Key page's Mode): the most common first; AISLING's two
 * hexatonics last, so the eight keep their places. (The values kept are the engine's, MODE_*) */
static const uint8_t MODE_ORDER[EN_NMODES] = {MODE_AEOLIAN, MODE_IONIAN, MODE_DORIAN, MODE_MIXOLYDIAN, MODE_PENT_MIN,
                                              MODE_PENT_MAJ, MODE_PHRYGIAN, MODE_LYDIAN, MODE_HEX_MAJ, MODE_HEX_MIN,
                                              MODE_BLUES};
static int mode_pos(int m)
{
    int i;
    for (i = 0; i < EN_NMODES && MODE_ORDER[i] != m; i++)
        ;
    return i < EN_NMODES ? i : 0;
}
/* the Chords page's slots (amb.h): written (a kind), the walk's (no kind, a degree + 1 as the root) or a gap */
static int slot_is_walk(int i) { return !proj.par[P_CQ0 + i] && proj.par[P_CR0 + i]; }
static int slot_is_gap(int i) { return !proj.par[P_CQ0 + i] && !proj.par[P_CR0 + i]; }
static int scale_steps(void)
{
    int n = 0, i;
    for (i = 0; i < 12; i++)
        n += (int)(proj.pool >> i & 1u);
    return n ? n : 1;
}
static void walk_written(int i, int *r, int *q, int *x)   /* a walk slot's chord, as it would be written */
{
    en_walk_chord(proj.pool, proj.par[P_ROOT], (proj.par[P_CR0 + i] - 1) % scale_steps(), r, q, x);
}
static void knob_set(int k, int v);
static void oct_home_take(void);
static void slot_write(int i)                    /* a walk slot about to be edited: written as it sounds */
{
    int r, q, x;
    if (!slot_is_walk(i))
        return;
    walk_written(i, &r, &q, &x);
    knob_set(P_CR0 + i, r);
    knob_set(P_CX0 + i, x);
    knob_set(P_CQ0 + i, q);
}
static int s2_shift(void) { return ui.s2_hand ? 0 : en_s2oct_shift; }   /* (Motion's move of Sequence 2's octave) */
static int knob_get(int k)
{
    if (k < P_NPARAMS)                           /* (Sequence 2's Octave: its home and Motion's shift, as it plays;
                                                  * the project keeps home) */
        return proj.par[k] + (k == P_SEQ2OCT ? s2_shift() : 0);
    if (k == K_LEDS)
        return proj.leds;
    if (k == K_SCR)                              /* (packs) the knob: Auto, Dark, Light; kept: 2, 0, 1 */
        return (proj.light + 1) % 3;
    if (k == K_CPU)
        return (int)plat_cpu_pct();
    if (k == K_SLOT)
        return ui.slot;
    if (k == K_CQ || k == K_CX) {
        if (slot_is_walk(ui.slot)) {             /* the walk's: its chord as it would be written */
            int r, q, x;
            walk_written(ui.slot, &r, &q, &x);
            return k == K_CQ ? q : x;
        }
        return proj.par[(k == K_CQ ? P_CQ0 : P_CX0) + ui.slot];
    }
    if (k == K_LANE)
        return ui.lane;
    if (k == K_LCH)
        return proj.par[P_SCH0 + lane_seq(ui.lane)];
    if (k >= K_FILTER && k <= K_SPACE)
        return ui.mac[k - K_FILTER];
    if (k == K_MODE)
        return mode_pos(proj.par[P_MODE]);
    if (k == K_PLAY)
        return proj.par[P_PMODE] & EN_PLOOP ? 1 : 0;
    if (k == K_SAVE)
        return ui.dirty ? 1 : 0;
    if (k == K_CHORUS)
        return ui.chorus;
    if (k == K_DAY)
        return ui.day;
    if (k == K_JRP)
        return ui.jr_cur;
    if (k == K_JRIN)
        return !(ui.jr_out >> ui.jr_cur & 1u);
    return 0;
}
static void knob_range(int k, int *lo, int *hi)
{
    if (k < P_NPARAMS) {
        *lo = en_param_info(k)->lo;
        *hi = en_param_info(k)->hi;
    } else if (k >= K_FILTER && k <= K_SPACE) {
        *lo = -50;
        *hi = 50;
    } else {
        *lo = 0;
        *hi = k == K_SCR ? 2 : k == K_DAY ? NDAY - 1 : k == K_JRP ? NPIECES - 1 : k == K_JRIN ? 1 : k == K_CHORUS ? 100 : k == K_PLAY ? 1 : k == K_MODE ? EN_NMODES - 1 : k == K_LEDS ? 2 : k == K_CPU ? 100 : k == K_SLOT ? EN_NPROG - 1 : k == K_CQ ? EN_NCQ - 1 : k == K_CX ? EN_NCX - 1
            : k == K_LANE ? EN_NDRUM - 1 : k == K_LCH ? 100 : 0;
    }
}
static const char *knob_name(int k)
{
    if (k < P_NPARAMS)
        return en_param_info(k)->name;
    return k == K_LEDS ? "Lights" : k == K_CPU ? "CPU" : k == K_SLOT ? "Slot" : k == K_CQ ? "Chord" : k == K_CX ? "Type"
         : k == K_LANE ? "Lane" : k == K_LCH ? "Chance" : k == K_FILTER ? "Filter" : k == K_DUB ? "Wet"
         : k == K_ENERGY ? "Energy" : k == K_SPACE ? "Duck" : k == K_MODE ? "Mode" : k == K_PLAY ? "Play" : k == K_SAVE ? "Save" : k == K_CHORUS ? "Chorus" : k == K_DAY ? "Day" : k == K_SCR ? "Screen" : k == K_JRP ? "Piece" : k == K_JRIN ? "In set" : "";
}
static void knob_text(int k, char *b)
{
    int v = knob_get(k);
    if (k < P_NPARAMS) {
        en_param_text(k, v, b);
    } else if (k == K_LEDS) {                    /* On: the keys, and the unlit buttons glow; Keys: no glow */
        const char *n = v == 2 ? "Keys" : v ? "On" : "Off";
        while ((*b++ = *n++))
            ;
    } else if (k == K_CPU) {
        itoa_u((uint32_t)v, b);
        while (*b)
            b++;
        *b++ = '%';
        *b = 0;
    } else if (k == K_JRP || k == K_JRIN || k == K_DAY || k == K_SCR) {
        const char *n = k == K_SCR ? (v == 2 ? "Light" : v ? "Dark" : "Auto") : k == K_DAY ? DAY_NAME[v] : k == K_JRP ? piece_name(v) : v ? "In" : "Out";
        while ((*b++ = *n++))
            ;
    } else if (k == K_SLOT) {
        itoa_u((uint32_t)v + 1u, b);
    } else if (k == K_CQ || k == K_CX) {
        en_param_text((k == K_CQ ? P_CQ0 : P_CX0) + ui.slot, v, b);
    } else if (k == K_LANE) {
        const char *n = LANE_NAME[(unsigned)v < EN_NDRUM ? v : 0];
        while ((*b++ = *n++))
            ;
    } else if (k == K_LCH) {
        itoa_u((uint32_t)v, b);
        while (*b)
            b++;
        *b++ = '%';
        *b = 0;
    } else if (k == K_FILTER) {                  /* Off in the middle; Shut (the low-pass) down, Open up, 0..100 */
        const char *n = v < 0 ? "Shut " : "Open ";
        if (!v) {
            n = "Off";
            while ((*b++ = *n++))
                ;
            return;
        }
        while (*n)
            *b++ = *n++;
        itoa_u((uint32_t)(v < 0 ? -v : v) * 2u, b);
    } else if (k >= K_DUB && k <= K_SPACE) {     /* 0: the piece as it is; more or less of it, -100..+100 */
        if (v)
            *b++ = v < 0 ? '-' : '+';
        itoa_u((uint32_t)(v < 0 ? -v : v) * 2u, b);
    } else if (k == K_MODE) {
        const char *n = mode_name();
        while ((*b++ = *n++))
            ;
    } else if (k == K_PLAY) {
        const char *n = v ? "Loop" : "Endless";
        while ((*b++ = *n++))
            ;
    } else if (k == K_CHORUS) {
        if (v)
            itoa_u((uint32_t)v, b);
        else
            b[0] = 'O', b[1] = 'f', b[2] = 'f', b[3] = 0;
    } else if (k == K_SAVE) {                    /* changed since the last save: "Save" (turn it); else "Saved" */
        const char *n = v ? "Save" : "Saved";
        while ((*b++ = *n++))
            ;
    } else {
        b[0] = 0;
    }
}

static void set_mode(int m);
static void do_save(void)                       /* SAVE or GLO held, or Setup's KNOB 4 turned */
{
    if (project_save() == 0) {
        ui.dirty = 0;
        say("SAVED", 0);
    } else {
        warn("NOT SAVED", "FLASH ERROR");
    }
}
static void knob_set(int k, int v)
{
    int lo, hi;
    if (k == K_CPU || k == K_NONE)
        return;
    knob_range(k, &lo, &hi);
    v = v < lo ? lo : v > hi ? hi : v;
    if (v == knob_get(k) && !(k == P_SEQ2OCT && s2_shift()))   /* (Sequence 2's Octave, shifted: the hand makes what
                                                               * it shows home, even unchanged) */
        return;
    if (k < P_NPARAMS) {
        int was = proj.par[k];
        if (k == P_SEQ2OCT && en_s2oct_shift)
            ui.s2_hand = 1;
        proj.par[k] = (int16_t)v;
        en_set(k, v);
        if (k == P_PMODE && (was & EN_PLOOP) && !(v & EN_PLOOP))
            en_prog_rotate();                    /* (from Loop, by hand: the slot playing up to slot 1) */
    } else if (k == K_LEDS) {
        proj.leds = (uint8_t)v;
    } else if (k == K_SCR) {                     /* (kpal follows it at the next frame: pal_sync) */
        proj.light = (uint8_t)(((v < 0 ? 0 : v > 2 ? 2 : v) + 2) % 3);   /* (packs: 2, as the piece is) */
    } else if (k == K_SLOT) {
        ui.slot = (uint8_t)v;
        return;                                  /* (only where the page looks: nothing saved) */
    } else if (k == K_DAY) {                     /* (not saved: off at every start) */
        dy_set(v);
        return;
    } else if (k == K_JRP) {
        ui.jr_cur = (uint8_t)v;
        return;
    } else if (k == K_JRIN) {                    /* (not saved, as the stay. The last one in stays in) */
        const uint8_t o = v ? ui.jr_out & (uint8_t)~(1u << ui.jr_cur) : ui.jr_out | (uint8_t)(1u << ui.jr_cur);
        if (o != (uint8_t)((1u << NPIECES) - 1u))
            ui.jr_out = o;
        return;
    } else if (k == K_CQ || k == K_CX) {
        slot_write(ui.slot);
        knob_set((k == K_CQ ? P_CQ0 : P_CX0) + ui.slot, v);
        if (k == K_CQ && !v) {                   /* Empty: a gap (the chord before it held) */
            knob_set(P_CR0 + ui.slot, 0);
            knob_set(P_CX0 + ui.slot, 0);
        }
        return;
    } else if (k == K_LANE) {
        ui.lane = (uint8_t)v;
        return;
    } else if (k == K_LCH) {
        knob_set(P_SCH0 + lane_seq(ui.lane), v);
        return;
    } else if (k >= K_FILTER && k <= K_SPACE) {
        ui.mac[k - K_FILTER] = (int8_t)v;
        en_macro(k - K_FILTER, v);
        return;                                  /* (for playing: nothing saved) */
    } else if (k == K_CHORUS) {
        ui.chorus = (uint8_t)v;
        en_chorus(v);
        return;                                  /* (for playing: nothing saved) */
    } else if (k == K_MODE) {                    /* (the knob: the place in MODE_ORDER) */
        set_mode(MODE_ORDER[v]);
        return;
    } else if (k == K_PLAY) {                    /* (the walk's character kept) */
        knob_set(P_PMODE, (proj.par[P_PMODE] & 3) | (v ? EN_PLOOP : 0));
        return;
    }
    mark_dirty();
}

/* knob acceleration by speed (X0X's): a few clicks are one step each however quick, so small
 * corrections stay exact; a longer quick turn speeds up to 8 a detent, so half a turn sweeps 0-100.
 * Small ranges never accelerate. */
static uint8_t accel_off;              /* the host simulator's "spin": exact steps */
static int32_t accel(int role, int32_t s, int range)
{
    uint32_t now = plat_ms(), dt = now - ui.enc_t[role], a = (uint32_t)(s < 0 ? -s : s), m;
    ui.enc_t[role] = now;
    if (!a)
        return s;
    if (a > 1)
        dt /= a;                                      /* per detent */
    ui.enc_run[role] = (uint8_t)(dt < 60u ? (ui.enc_run[role] + a > 255u ? 255u : ui.enc_run[role] + a) : a);
    if (range <= 24 || accel_off || ui.enc_run[role] < 4u)
        return s;
    m = dt < 12u ? 8u : dt < 25u ? 5u : dt < 45u ? 3u : 1u;
    if (range < 100 && m > 3u)
        m = 3u;
    return s * (int32_t)m;
}

static void turn(int role, int k, int32_t e)
{
    int lo, hi;
    if (!e || k == K_NONE || k == K_CPU)
        return;
    if (k == K_SAVE) {                           /* a turn, either way: saved */
        do_save();
        return;
    }
    knob_range(k, &lo, &hi);
    if (lo < 0 && hi > 0 && hi - lo >= 10) {     /* (1.3.0) a centred knob: a notch at 0, three clicks to leave it */
#define NOTCH 2                                  /* (the clicks out of 0 held back) */
        static int8_t held[16];
        static uint32_t held_t[16];
        int v = knob_get(k), n, r = role & 15;
        if (v == 0) {                            /* (clicks out of 0 held back, NOTCH of them, one way, close together) */
            int32_t a = e > 0 ? e : -e, dir = e > 0 ? 1 : -1;
            if (plat_ms() - held_t[r] > 700u || (held[r] > 0) != (dir > 0))
                held[r] = 0;
            held_t[r] = plat_ms();
            while (a > 0 && (held[r] > 0 ? held[r] : -held[r]) < NOTCH)
                held[r] = (int8_t)(held[r] + dir), a--;
            if (!a)
                return;
            e = dir * a;
            held[r] = 0;
        }
        n = v + accel(role, e, hi - lo);
        knob_set(k, (v > 0 && n < 0) || (v < 0 && n > 0) ? 0 : n);   /* (and it stops at 0 on the way through) */
        return;
    }
    knob_set(k, knob_get(k) + accel(role, e, hi - lo));
}

/* ------------------------------------------------------------- the pool --- */
static void set_mode(int m)
{
    m = (m % EN_NMODES + EN_NMODES) % EN_NMODES;
    proj.par[P_MODE] = (int16_t)m;
    proj.pool = EN_MODE_POOL[m];
    en_set(P_MODE, m);
    en_pool(proj.pool);
    say("MODE", EN_MODE_NAME[m]);
    mark_dirty();
}

/* the voices: ALGORITHM on a layer's page steps through that layer's (round: after the last, the first) */
/* (BERLIN) the page's brightness knob (the filter motion's): its knob index, its layer, its units an octave; -1: none */
static int bright_of(int v, int *layer, float *per_oct)
{
    switch (v) {
    case V_CSND: *layer = 0, *per_oct = 25.0f; return 0;   /* the Drone's Colour (2 octaves a 50) */
    case V_PSND: *layer = 1, *per_oct = 18.18f; return 0;  /* the Sequence's Cutoff (0.055 an octave a unit) */
    case V_BSND: *layer = 2, *per_oct = 25.0f; return 0;   /* the Lead's Tone */
    case V_DSND: *layer = 3, *per_oct = 18.18f; return 0;  /* Sequence 2's Cutoff */
    case V_NSND2: *layer = 4, *per_oct = 50.0f; return 0;  /* the Atmosphere's Colour */
    default: return -1;
    }
}
static int knob_dot(int v)                       /* the knob's value where its filter is now (-999: no such knob) */
{
    int layer, p, lo, hi;
    float per;
    const int k = bright_of(v, &layer, &per);
    if (k < 0)
        return -999;
    p = VIEW_KNOB[v][k];
    lo = en_param_info(p)->lo, hi = en_param_info(p)->hi;
    {
        const float x = (float)proj.par[p] + en_fo[layer] * per;
        return x < (float)lo ? lo : x > (float)hi ? hi : (int)(x + (x >= 0.0f ? 0.5f : -0.5f));
    }
}

static int view_voice(int v)
{
    v = page_of(v);
    return v == V_CHORD ? P_CVOICE : v == V_TEXTURE ? P_SVOICE : v == V_BASS ? P_LVOICE : v == V_DRUMS ? P_S2VOICE : -1;
}
static void set_voice(int p, int v)
{
    const en_param_t *pi = en_param_info(p);
    char t[12];
    int n = pi->hi - pi->lo + 1;
    v = ((v - pi->lo) % n + n) % n + pi->lo;
    proj.par[p] = (int16_t)v;
    en_set(p, v);
    en_param_text(p, v, t);
    say("VOICE", t);
    mark_dirty();
}

static void mac_home(void)                       /* (the user, 2026-10-28) a piece from the master actions at 0 (the
                                                  * engine's own, at its regrow) */
{
    int i;
    for (i = 0; i < EN_NMAC; i++)
        ui.mac[i] = 0;
    if (ui.chorus) {                             /* ((1.3) and the Chorus) */
        ui.chorus = 0;
        en_chorus(0);
    }
}

static void set_piece(int i)                    /* the piece playing kept as it is; piece i as it was left */
{
    mac_home();
    project_piece(i);                            /* (after a change of bank: nothing kept, project.c's bank_stale) */
    project_apply();
    oct_home_take();
    en_seed(plat_ms());
    en_regrow();
    say_as("PIECE", piece_name(proj.piece), 0);
    sp_piece();                                  /* a screen reader: the piece with its key and tempo */
    mark_dirty();
    undo_clear();                                /* (0.5) another piece: nothing to go back to */
}
static void set_piece_bank(int b, int i)        /* (packs) piece i of bank b (0 the eight, 1 the pack's) */
{
    if (project_bank(b))
        memset(ui.sig, 0, sizeof ui.sig);        /* (other names, perhaps another screen: all drawn again) */
    set_piece(i);
}
static void set_piece_ring(int e)               /* PRESET's turn by e: past the eighth, the pack's first, and round.
                                                  * (1.6) A place the pack left empty is passed over. */
{
    const int all = NPIECES * (pack_have() ? 2 : 1), d = e < 0 ? -1 : 1, was = proj.piece + NPIECES * bank;
    int n = was, k;
    for (e = e < 0 ? -e : e; e > 0; e--)
        for (k = 0; k < all; k++) {              /* (the eight are never empty: it ends) */
            n = (n + d + all) % all;
            if (!piece_empty(n / NPIECES, n % NPIECES))
                break;
        }
    if (n != was)
        set_piece_bank(n / NPIECES, n % NPIECES);
}

/* ----------------------------------------------------------- PERFORM --- */
/* (1.3, the Performance release; the user: "stay on perform and manipulate the track while it generates melody ...
 * I don't really care about the mutings. I'd prefer lots of effects") SEL's mode: every key from F3 up an effect,
 * as long as the key is held, several together; no REC to hold, no layer's mute. The white keys four groups of four
 * (rhythm, echo, space, colour), the black keys a fifth in the keyboard's own groups (3 2 3 2 1). REC tapped with
 * keys held: those stay on (latched; all of them latched already: let go); REC alone: every latch let go.
 * A key that does something is lit, dark while held, blinking while latched.
 * What a key does (d): under 100 one of the grid's effects (EN_FX_*), 100 + a move (EN_MV_*), 200 + one of the old
 * PERFORM's moves (EN_PF_*), PK_SOON: an effect 1.3 has yet to build (the key dark, nothing said) */
#define PERF_N 27
#define PK_SOON 255
enum { PG_RHYTHM, PG_ECHO, PG_SPACE, PG_COLOUR, PG_BLACK, PG_N };
static const struct {
    const char *name;
    uint8_t d, g;
} PKEY[PERF_N] = {
    {"Stutter", EN_FX_STUTTER, PG_RHYTHM},                 {"Ceo", EN_FX_TAKEOFF, PG_BLACK},
    {"Half time", EN_FX_HALF, PG_RHYTHM},            {"Fras", EN_FX_TWITTER, PG_BLACK},
    {"Gate", EN_FX_GATE, PG_RHYTHM},                 {"Sweep", EN_FX_SWEEP, PG_BLACK},
    {"Roll", EN_FX_ROLL, PG_RHYTHM},
    {"Repeat", EN_FX_REPEAT, PG_ECHO},               {"Rise", 100 + EN_MV_RISE, PG_BLACK},
    {"Macalla", EN_FX_SUPERNOVA, PG_ECHO},           {"Close", 100 + EN_MV_CLOSE, PG_BLACK},
    {"Tape stop", EN_FX_TAPESTOP, PG_ECHO},
    {"Reverse", EN_FX_REVERSE, PG_ECHO},                   {"Octave", EN_FX_OCTAVE, PG_BLACK},
    {"Reverb", EN_FX_REVERB, PG_SPACE},              {"Dive", EN_FX_DIVE, PG_BLACK},
    {"Shimmer", EN_FX_SHIMMER, PG_SPACE},            {"Ring", EN_FX_RING, PG_BLACK},
    {"Freeze", EN_FX_FREEZE, PG_SPACE},
    {"Wash", EN_FX_WASH, PG_SPACE},                  {"Vinyl", EN_FX_VINYL, PG_BLACK},
    {"Flange", EN_FX_FLANGE, PG_COLOUR},                  {"Comb", EN_FX_COMB, PG_BLACK},
    {"Phaser", EN_FX_PHASER, PG_COLOUR},
    {"Drive", EN_FX_DRIVE, PG_COLOUR},               {"Drop", 200 + EN_PF_DROP, PG_BLACK},
    {"Crush", EN_FX_CRUSH, PG_COLOUR},
};
/* (1.3) an effect's CC: the low octave's twelve keys 20-31, the fifteen above 102-116 (both runs undefined in MIDI,
 * so no keyboard's own pedal or wheel lands on one). 64 and over: held; under: let go */
static int pkey_cc(int k) { return k < 12 ? 20 + k : 102 + k - 12; }
static int cc_pkey(int n) { return n >= 20 && n < 32 ? n - 20 : n >= 102 && n < 102 + PERF_N - 12 ? n - 102 + 12 : -1; }
/* (1.2's PERFORM, kept for the USB link alone: LK_PERF's fifteen, the layers muted (0-4), the moves held (5-9), the
 * layers soloed (10-14), and LK_FORGET. No key reaches them now) */
#define LPERF_N 15
static const char *const LPERF_NAME[LPERF_N] = {"DRONE", "SEQ", "LEAD", "SEQ 2", "ATMOS", "SWEEP", "OPEN", "SHUT",
                                                "DROP", "ECHO", "DRONE", "SEQ", "LEAD", "SEQ 2", "ATMOS"};
/* each layer's mute (EN_M_*), in the meters' order: Sequence 2 is two of the engine's bits (DUB-1's kick and hats) */
static const uint32_t LAYER_MUTE[NLAYER] = {EN_M_CHORD, EN_M_PINGS, EN_M_BASS, EN_M_KICK | EN_M_HATS, EN_M_NOISE};
#define DAY_SHOWER 84                            /* (the shower's amount, as a CC) */
#define ALL_MUTE (EN_M_CHORD | EN_M_PINGS | EN_M_BASS | EN_M_KICK | EN_M_HATS | EN_M_NOISE)
static void fx_send(void)                        /* all that is held, to the engine: the grid's (ui.fx), the black
                                                  * keys' (ui.bfx, ui.mv), the link's moves, and PERFORM's keys,
                                                  * held or latched */
{
    uint32_t on = (ui.perf ? ui.pheld | ui.platch : 0u) | ui.pcc, fx = 0, mv = 0, pf = 0, hand;
    int i;
    /* (1.3) by hand (PERFORM's keys, the grid's that PERFORM has too): each change a CC out, on channel 16, with
     * MIDI out on. A CC's own are not sent back */
    hand = ui.perf ? ui.pheld | ui.platch : 0u;
    for (i = 0; i < PERF_N; i++)
        if (PKEY[i].d < 100 && ((ui.fx | ui.bfx) >> PKEY[i].d & 1u))
            hand |= 1u << i;
    if (proj.par[P_MIDI])
        for (i = 0; i < PERF_N; i++)
            if ((hand ^ ui.pout) >> i & 1u)
                plat_midi_out(0x0Bu | 0xBFu << 8 | (uint32_t)pkey_cc(i) << 16 | (hand >> i & 1u ? 127u : 0u) << 24);
    ui.pout = hand;
    ui.pnow = hand | ui.pcc;
    for (i = 0; i < PERF_N; i++)
        if (on >> i & 1u) {
            const int d = PKEY[i].d;
            /* (1.4) its amount, sent before it is held: full by hand (a key, the grid, a black key), a CC's by its
             * value. Half time, Freeze and Octave are switches: the engine makes nothing of theirs; Drop has none */
            const int e = d < 100 ? d : d == 100 + EN_MV_RISE ? 32 : d == 100 + EN_MV_CLOSE ? 33 : -1;
            const int byhand = (hand >> i & 1u) || (e == 32 && ui.mv & EN_MV_RISE) || (e == 33 && ui.mv & EN_MV_CLOSE);
            const int want = byhand || ui.pamt[i] < 64 ? 127 : ui.pamt[i];
            if (d == PK_SOON)
                continue;
            if (e >= 0 && want != (ui.psent[e] ? ui.psent[e] : 127)) {
                ui.psent[e] = (uint8_t)want;
                en_amt(e, want);
            }
            if (d < 100)
                fx |= 1u << d;
            else if (d < 200)
                mv |= (uint32_t)(d - 100);
            else
                pf |= (uint32_t)(d - 200);
        }
    if (ui.shower && !((ui.fx | ui.bfx | fx) >> EN_FX_TWITTER & 1u)) {   /* (1.4) the day's shower: Fras, lightly,
                                                  * unless a hand or a CC has it */
        if (ui.psent[EN_FX_TWITTER] != DAY_SHOWER)
            ui.psent[EN_FX_TWITTER] = DAY_SHOWER, en_amt(EN_FX_TWITTER, DAY_SHOWER);
        fx |= 1u << EN_FX_TWITTER;
    }
    en_fx(ui.fx | ui.bfx | fx);
    en_move(ui.mv | mv);
    en_perf(ui.moves | pf);
}
/* (1.4) THE JOURNEY's glide: one piece into the next without two playing at once (there isn't the load for a
 * crossfade). Over 16 bars the layers thin out into the echo and the plate (the Lead, Sequence 2, Sequence 1, then the
 * Drone and the Atmosphere eased), the tempo eases across under the tail, the piece changes with nothing sounding but
 * that tail, and the new piece's layers come in: the Drone and the Atmosphere, Sequence 1, Sequence 2, the Lead. The
 * layers held out are laid over the hand's mutes, never stored in them. A touch ends it: before the change, the piece
 * stays; after, the new one whole at once. The change is set_piece's without its save: nothing is marked to be
 * saved, so a journey never writes the flash */
#define JR_THIN (EN_M_CHORD | EN_M_NOISE)        /* (eased by the engine: en_thin; the rest stop sounding new notes) */
static struct {
    uint8_t on, to, changed, n;                  /* gliding; the piece it goes to; changed yet; bars into it */
    int16_t tempo;                               /* the tempo sent last, easing */
    uint32_t mask;                               /* the layers held out now (EN_M_*) */
    uint32_t bar, six;                           /* the engine's bar last seen; the sixteenth the tempo's ease began */
    uint32_t act;                                /* the last touch when it began (another ends it) */
    uint8_t stay, piece, pb;                     /* the stay (JR_MIN's); the piece it is on; the phrase's bar last
                                                  * seen (the set list: ui.jr_out) */
    uint32_t since;                              /* the stay's start: the piece's arrival, or the last touch */
} jr;
static void perf_mutes(void)                     /* to the engine: the mutes, and with a solo, all but it */
{
    en_mute(ui.mutes | (ui.solo ? ALL_MUTE & ~ui.solo : 0u) | (jr.mask & ~JR_THIN));
}
static int perf_sounds(int i)                    /* layer i (0..4) heard: not muted, not soloed out */
{
    if (ui.solo && !(ui.solo & LAYER_MUTE[i]))
        return 0;
    return (ui.mutes & LAYER_MUTE[i]) != LAYER_MUTE[i];
}
static void set_view(int v);
static void lock_toggle(void)                    /* SEL held: Lock, on or off: the phrases keep their kick, groove and plan,
                                                  * Evolve's own moves rest (not saved; off at boot) */
{
    ui.lock = (uint8_t)!ui.lock;
    en_lock(ui.lock);
    say("LOCK", ui.lock ? "ON" : "OFF");
    card_show("LOCK", ui.lock ? "the sequences kept" : "the sequences free", K_ACC, 0);
}
static void lead_forget(void)                    /* (PERFORM's SAVE, the link's LK_FORGET) the Lead forgets its ideas and its theme */
{
    en_lead_forget();
    say("LEAD", "FORGOTTEN");
    card_show("LEAD FORGOTTEN", "new ideas", K_BASS, 0);
}
static void link_perf(int i, int down)           /* (the link's LK_PERF, 1.2's fifteen) */
{
    if (i < 0 || i >= LPERF_N)
        return;
    if (i >= 10) {                               /* a solo: on or off, a press each */
        uint32_t m = LAYER_MUTE[i - 10];
        if (!down)
            return;
        ui.solo ^= m;
        perf_mutes();
        if (ui.solo & m)
            say("SOLO", LPERF_NAME[i]);
        else if (ui.solo)                        /* (one let go, others still soloed) */
            say(LPERF_NAME[i], "SOLO OFF");
        else
            say("SOLO", "OFF");
        return;
    }
    if (i < 5) {                                 /* the chord, pings, bass, kick, hats: a mute (the levels kept) */
        if (!down)
            return;
        if ((ui.mutes & LAYER_MUTE[i]) == LAYER_MUTE[i])   /* (Sequence 2: both its bits out, back) */
            ui.mutes &= ~LAYER_MUTE[i];
        else
            ui.mutes |= LAYER_MUTE[i];
        perf_mutes();
        say(LPERF_NAME[i], (ui.mutes & LAYER_MUTE[i]) == LAYER_MUTE[i] ? "OFF" : "ON");
        return;
    }
    if (down)
        ui.moves |= 1u << (i - 5);
    else
        ui.moves &= ~(1u << (i - 5));
    fx_send();
    if (down)
        say(LPERF_NAME[i], 0);
}
static void perf_key(uint32_t key, int down)     /* PERFORM: a key, its effect while held */
{
    if (key >= PERF_N || PKEY[key].d == PK_SOON)
        return;
    if (down)
        ui.pheld |= 1u << key;
    else
        ui.pheld &= ~(1u << key);
    fx_send();
    if (down)
        say(PKEY[key].name, 0);
}
static void set_view(int v);
static void perf_set(int on)                     /* on: the mixer on the knobs; off: back to the page */
{
    ui.perf = (uint8_t)on;
    if (on) {
        if (ui.view != V_MIX && ui.view != V_PERF)
            ui.perf_from = ui.view;
        set_view(V_PERF);
    } else {
        ui.moves = 0;                            /* every key and latch let go (and the link's moves) */
        ui.pheld = ui.platch = ui.pcc = 0;
        fx_send();
        if (ui.view == V_MIX || ui.view == V_PERF)
            set_view(ui.perf_from);
    }
    say("PERFORM", on ? "ON" : "OFF");
}

/* ------------------------------------------------------- the effects grid --- */
/* REC held: the white keys from F3 up are the sixteen effects (four groups of four: the echo, the filter,
 * the space, rhythm and noise), each as long as its key is held, even once REC is let go. A tap on REC alone
 * is still dub hold (REC's release does nothing once a key played) */
static const uint8_t FX_KEY[EN_NFX] = {0, 2, 4, 6, 7, 9, 11, 12, 14, 16, 18, 19, 21, 23, 24, 26};
#define GRID_HOLD 300u                   /* ms of REC held before the grid shows */
static int grid_up(void) { return ui.fx || ((ui.btn >> B_REC & 1u) && plat_ms() - ui.down_t[B_REC] >= GRID_HOLD); }
static int fx_key(uint32_t key, int down)        /* 1: the key was an effect's */
{
    int e;
    for (e = 0; e < EN_NFX && FX_KEY[e] != key; e++)
        ;
    if (e >= EN_NFX)
        return 0;
    if (down) {
        ui.fx |= 1u << e;
        ui.btn_used |= 1u << B_REC;              /* (REC's release: no dub hold now) */
        say(EN_FX_NAME[e], 0);
    } else {
        if (!(ui.fx >> e & 1u))                  /* (1.3) not one held on the grid: the key is someone else's */
            return 0;
        ui.fx &= ~(1u << e);
    }
    fx_send();
    return 1;
}

/* ----------------------------------------------------------- the chords --- */
/* EDIT tapped: the Chords page, the eight coming: the walk's (teal: degrees, they follow the key), yours (white)
 * and gaps (the chord before held). KNOB 1 the slot, the keys its root (a walk's chord becomes yours, its kind and
 * type kept; a gap becomes a minor chord), KNOB 2 its kind (Empty: a gap), KNOB 3 its type, KNOB 4 Play:
 * Endless (slot 1 playing; on, all move up and the walk writes slot 8) or Loop (the slots in turn, to the last
 * that isn't a gap). The engine holds them (it writes the walk's): prog_take mirrors them into the project.
 * EDIT again, or any page's button: back. EDIT held: the next chord */
#define NEXT_HOLD 500u
static int prog_count(void)                      /* how far the slots run (Loop): to the last that isn't a gap */
{
    int i, n = 0;
    for (i = 0; i < EN_NPROG; i++)
        if (!slot_is_gap(i))
            n = i + 1;
    return n;
}
static const char *slot_label(int i, char *nm)   /* written: its name; the walk's: the chord the scale gives it */
{
    if (slot_is_walk(i)) {
        int pcs[EN_NPAD + 1], iv[4], t[4], d = (proj.par[P_CR0 + i] - 1) % scale_steps(), k;
        en_chord_tones(proj.pool, proj.par[P_ROOT], d, t);
        en_voicing(proj.pool, d, proj.par[P_CX0 + i] & 1, iv);
        pcs[0] = t[0];
        for (k = 0; k < EN_NPAD; k++)
            pcs[k + 1] = (t[0] + iv[k]) % 12;
        return en_chord_name(pcs, EN_NPAD + 1, nm);
    }
    return en_chord_label(proj.par[P_CR0 + i], proj.par[P_CQ0 + i], proj.par[P_CX0 + i], nm);
}
static void prog_take(void)                      /* the engine's slots (the walk writes them, Endless moves them) */
{
    int i;
    if (en_prog_gen == ui.prog_gen)
        return;
    ui.prog_gen = en_prog_gen;
    for (i = 0; i < EN_NPROG; i++) {
        proj.par[P_CR0 + i] = en_prog_slot[i][0];
        proj.par[P_CQ0 + i] = en_prog_slot[i][1];
        proj.par[P_CX0 + i] = en_prog_slot[i][2];
    }
}
static void set_view(int v);
static void slot_key(uint32_t key)               /* the Chords page: a key, the slot's root */
{
    char nm[16];
    slot_write(ui.slot);                         /* (the walk's: its kind and type kept, the root yours) */
    knob_set(P_CR0 + ui.slot, (int)((5u + key) % 12u));
    if (!proj.par[P_CQ0 + ui.slot])
        knob_set(K_CQ, EN_CQ_MINOR);
    say(slot_label(ui.slot, nm), 0);
}
static uint8_t edit_new;                         /* EDIT held on: the new progression made this hold */
static void edit_released(uint32_t held)
{
    if (edit_new) {                              /* (held on: done already) */
        edit_new = 0;
    } else if (held >= NEXT_HOLD) {              /* held: the next chord */
        en_next();
        say("NEXT CHORD", en_playing ? "ON THE BAR" : 0);
        card_show("NEXT CHORD", en_playing ? "on the bar" : "", K_PULSE, 0);
    } else if (ui.view == V_CHORDS) {            /* tapped: the Chords page (one page: again stays) */
        ;
    } else {
        if (ui.perf) {                           /* (a page's button leaves PERFORM: the keys the scale again) */
            perf_set(0);
            set_view(V_DUB);
        }
        ui.chords_from = (uint8_t)ui.view;
        set_view(V_CHORDS);
    }
}

/* ---------------------------------------------------------- the pattern --- */
/* the Drums button a third time: the Pattern page. KNOB 1 the lane (kick, shaker, open hat, rim), the white keys
 * its sixteen steps (a key, a step: on or off), a black key held with a white one: that step accented; KNOB 2
 * the accents' strength, KNOB 3 the lane's chance, KNOB 4 Play: Auto (generated, as ever) or Pattern. The first
 * edit takes the pattern over from what Auto plays. The arrangement still takes lanes out (a Break, a fill) */
static const uint8_t STEP_KEY[16] = {0, 2, 4, 6, 7, 9, 11, 12, 14, 16, 18, 19, 21, 23, 24, 26};   /* the white keys */
/* (BERLIN, spec 13) the black keys in normal playing: an effect each while held, eight of the grid's and three moves
 * (EN_MV_*, coded 100 + the move) */
#define NBLACK 11
static const uint8_t BLACK_KEY[NBLACK] = {1, 3, 5, 8, 10, 13, 15, 17, 20, 22, 25};
static const uint8_t BLACK_DO[NBLACK] = {EN_FX_TAKEOFF, EN_FX_SUPERNOVA, EN_FX_TWITTER, EN_FX_REPEAT, EN_FX_SHIMMER,
                                         EN_FX_FREEZE, EN_FX_OCTAVE, EN_FX_RETURN, 100 + EN_MV_RISE, 100 + EN_MV_CLOSE,
                                         100 + EN_MV_TRANSPOSE};
/* (AISLING) the first three black keys (the user's OP1, OP2, OP3) named as the user asked: Ceo, Macalla, Fras */
static const char *const BLACK_NAME[NBLACK] = {"Ceo", "Macalla", "Fras", "Repeat", "Shimmer", "Freeze",
                                               "Octave", "Return", "Rise", "Close", "Transpose"};
static int black_of(uint32_t key)                /* the black key's index (0..10), or -1 */
{
    int b;
    for (b = 0; b < NBLACK && BLACK_KEY[b] != key; b++)
        ;
    return b < NBLACK ? b : -1;
}
static void black_set(int b, int on)             /* a black key's effect on or off, to the engine */
{
    const int d = BLACK_DO[b];
    if (d >= 100)
        ui.mv = (uint8_t)(on ? ui.mv | (d - 100) : ui.mv & ~(d - 100));
    else
        ui.bfx = on ? ui.bfx | 1u << d : ui.bfx & ~(1u << d);
    fx_send();
}
static uint32_t lane_steps(int d) { return proj.par[P_SMODE] ? (uint32_t)(uint16_t)proj.par[P_SGATE0 + d] : en_seq_lane[d]; }
static void pattern_key(uint32_t key, uint32_t keys)
{
    int st, d = ui.lane, acc;
    uint32_t m, black = 0;
    char t[24];
    for (st = 0; st < 16 && STEP_KEY[st] != key; st++)
        ;
    if (st >= 16)
        return;                                  /* (a black key: an accent's, with a white one) */
    for (m = 0; m < 16; m++)
        keys &= ~(1u << STEP_KEY[m]);
    black = keys;
    if (!proj.par[P_SMODE]) {                    /* the first edit: Auto's pattern, taken over */
        int k;
        for (k = 0; k < EN_NDRUM; k++)
            knob_set(P_SGATE0 + k, (int)(int16_t)(uint16_t)en_seq_lane[k]);
        knob_set(P_SACC0, (int)(int16_t)en_seq_acc[0]);
        knob_set(P_SACC1, (int)(int16_t)en_seq_acc[1]);
        knob_set(P_SMODE, 1);
    }
    m = (uint32_t)(uint16_t)proj.par[P_SGATE0 + d];
    acc = (int)((uint32_t)(uint16_t)proj.par[P_SACC0 + lane_seq(d)] >> st & 1u);
    if (black) {                                 /* accent it (on, too), or not: the lane's sequence's accents */
        knob_set(P_SACC0 + lane_seq(d), (int)(int16_t)(uint16_t)((uint32_t)(uint16_t)proj.par[P_SACC0 + lane_seq(d)] ^ (1u << st)));
        knob_set(P_SGATE0 + d, (int)(int16_t)(uint16_t)(m | 1u << st));
        acc = !acc;
    } else {
        knob_set(P_SGATE0 + d, (int)(int16_t)(uint16_t)(m ^ 1u << st));
    }
    t[0] = 0;
    itoa_u((uint32_t)st + 1u, t);
    say_as(LANE_NAME[d], 0, 0);
    if (ann_on()) {
        sp_n = 0;
        sp_buf[0] = 0;
        sp_cat("Step ");
        sp_cat(t);
        sp_cat(black ? (acc ? " accented" : " not accented") : (proj.par[P_SGATE0 + d] >> st & 1 ? " on" : " off"));
        ann_say(sp_buf, 0, ANN_NOW);
        sp_said = 1;
    }
}

/* ------------------------------------------------------------ buttons --- */
static void set_view(int v)
{
    ui.view = (uint8_t)v;
    ui.touched = -1;
}

static void button(int b)
{
    int v;
    if (ui.perf && b == B_SAVE) {                /* (1.3) SAVE tapped in PERFORM: the Lead's FORGET, PERFORM kept
                                                  * (held, it still saves; the Noise page: from any other page) */
        lead_forget();
        return;
    }
    if (ui.perf && (b == B_HOME || b == B_ENV || b == B_ARP || b == B_LFO || b == B_SEQ || b == B_FX || b == B_GLO ||
                    b == B_SAVE || b == B_EDIT)) {   /* (1.3.0) a page's button leaves PERFORM: the keys the scale
                                                      * again, the page its first (SEL brings PERFORM back) */
        perf_set(0);
        set_view(V_DUB);
        if (b == B_HOME)
            return;
    }
    if (sound_of(ui.view) >= 0 && b == VIEW_BTN[ui.view]) {   /* the layer's button again: its sound page */
        set_view(sound_of(ui.view));
        return;
    }
    if (parent_of(ui.view) >= 0 && b == VIEW_BTN[parent_of(ui.view)]) {   /* again: the layer's next page; the last,
                                                                           * back to its first */
        set_view(next_page(ui.view));
        return;
    }
    if (b == B_FX && (ui.view == V_SPACE || ui.view == V_ESND)) {   /* FX again: the Echo page; again: back */
        set_view(ui.view == V_SPACE ? V_ESND : V_SPACE);
        return;
    }
    if (b == B_GLO && (ui.view == V_SETUP || ui.view == V_ARC || ui.view == V_SET)) {   /* GLO again: the Arc (how
                                                  * the piece builds); again: (1.4) the journey's Set list; again: back */
        if (ui.view == V_ARC)
            ui.jr_cur = (uint8_t)proj.piece;     /* (it opens on the piece playing) */
        set_view(ui.view == V_SETUP ? V_ARC : ui.view == V_ARC ? V_SET : V_SETUP);
        return;
    }
    if (b == B_HOME && ui.view == V_DUB) {       /* HOME again: the Key page (the key and the tempo); again: back */
        set_view(V_KEY);
        return;
    }
    for (v = 0; v < NPAGES; v++)                 /* a page's button: its page */
        if (VIEW_BTN[v] == b) {
            set_view(v);
            return;
        }
    switch (b) {
    case B_SEL:                                  /* PERFORM; again: back to the page it came from (0.5; a page's
                                                  * button leaves it too, for that page). Off the Mix page (D4
                                                  * held), back to PERFORM's */
        if (!ui.perf)
            perf_set(1);
        else if (ui.view == V_MIX)
            set_view(V_PERF);
        else
            perf_set(0);
        break;
    case B_EDIT:                                 /* (its release: edit_released, in input) */
        break;
    case B_PLAY:
        sp_tp.playing = !en_playing;
        sp_tp.play_t = plat_ms();
        if (en_playing) {
            en_play(0);
            say("RESTING", 0);
        } else {
            en_seed(plat_ms());
            en_play(1);
            say("PLAYING", 0);
        }
        break;
    case B_REC:
        if (plat_ms() - ui.down_t[B_REC] >= GRID_HOLD)
            break;                               /* held long enough for the grid: only a tap is dub hold */
        say("HOLD", en_frozen ? "OFF" : "ON");
        en_freeze(!en_frozen);                   /* the engine takes it at its next block */
        break;
    case B_SAVE:                                 /* the Noise page (saving: held, as GLO; or Setup's KNOB 4) */
        if (atm_view(ui.view)) {                 /* (SAVE again steps through: its sound, its Move page, back) */
            set_view(ui.view == V_NSND ? V_NSND2 : ui.view == V_NSND2 ? V_AMOVE : V_NSND);
        } else {
            ui.noise_from = (uint8_t)ui.view;
            set_view(V_NSND);
        }
        break;
    default: break;
    }
}

/* ---------------------------------------------------------- OCT- / OCT+ --- */
/* (the user, 2026-10-28) on the Sequence's, the Lead's and Sequence 2's pages (oct_layer): its octave, a step a tap
 * (on its release; none held on, none when both are down: so the update mode, both held 5 s, main_fm1.c, moves
 * nothing), said; lit while that octave is above (OCT+) or below (OCT-) its home, where the piece was loaded (oct_home).
 * The Drone's and the Atmosphere's pages, and pages of no layer: nothing. (The levels are SELECT's now, with the ring;
 * the mutes PERFORM's) */
#define OCT_SHOW 1200u                           /* the ring up after the last turn, then OCT_FADE fading */
#define OCT_FADE 250u
#define NO_OCT 0xFFu
static const uint8_t LAYER_LEVEL[NLAYER] = {P_CHORD, P_SEQ, P_LEAD, P_SEQ2, P_CRACKLE};
static const uint8_t LAYER_OCT[NLAYER] = {NO_OCT, P_SEQOCT, P_LOCT, P_SEQ2OCT, NO_OCT};
static const char *const LAYER_NAME[NLAYER] = {"DRONE", "SEQ", "LEAD", "SEQ 2", "ATMOS"};
static const char *const OCT_NAME[NLAYER] = {"", "SEQ OCTAVE", "LEAD OCTAVE", "SEQ 2 OCTAVE", ""};
static void oct_home_take(void)                  /* a piece loaded (or reset): its octaves, the lights' home */
{
    int l;
    for (l = 0; l < NLAYER; l++)
        if (LAYER_OCT[l] != NO_OCT)
            ui.oct_home[l] = (int8_t)proj.par[LAYER_OCT[l]];
}
static void oct_show(int l)                      /* the ring up (from where it was, if it was: it glides) */
{
    uint32_t now = plat_ms();
    if (ui.oct_ring != l + 1 || now >= ui.oct_until + OCT_FADE)
        ui.oct_v = (float)proj.par[LAYER_LEVEL[l]] * 0.01f;
    ui.oct_ring = (uint8_t)(l + 1);
    ui.oct_until = now + OCT_SHOW;
    ui.oct_pulse = now;
}
static int oct_ring_on(uint32_t now)             /* the ring's layer + 1, while it shows on this page (else 0) */
{
    if (!ui.oct_ring || now >= ui.oct_until + OCT_FADE || oct_layer(ui.view) != ui.oct_ring - 1)
        return 0;
    return ui.oct_ring;
}
static void level_turn(int l, int32_t e)         /* SELECT on a layer's page: its level, 1 a detent */
{
    char t[8];
    knob_set(LAYER_LEVEL[l], proj.par[LAYER_LEVEL[l]] + (int)e);
    itoa_u((uint32_t)proj.par[LAYER_LEVEL[l]], t);
    say(LAYER_NAME[l], t);
    oct_show(l);
}
static void energy_turn(int32_t e)               /* (the user, 2026-10-28) SELECT on HOME: Energy, PERFORM's, 1 a
                                                  * detent (the keys still the Lead's); held as a turn of its knob */
{
    char t[8];
    knob_set(K_ENERGY, knob_get(K_ENERGY) + (int)e);
    knob_text(K_ENERGY, t);
    say("ENERGY", t);
    ui.sel_until = plat_ms() + 1200u;
}
static void oct_step(int b)
{
    int l = oct_layer(ui.view), k;
    char t[12];
    if (l < 0 || LAYER_OCT[l] == NO_OCT)
        return;
    k = LAYER_OCT[l];
    knob_set(k, knob_get(k) + (b == B_OCTUP ? 1 : -1));
    en_param_text(k, knob_get(k), t);
    say(OCT_NAME[l], t + (t[0] == '+'));         /* (as the knob shows it: "1", not "+1") */
    if (VIEW_KNOB[ui.view][1] == k) {            /* (the page's Octave knob, lit a moment) */
        ui.touched = 1;
        ui.touch_until = plat_ms() + 1200u;
    }
}
static int undo_restore(const undo_t *s, char *what, int cap)   /* only what differs: the rest doesn't hear it */
{
    const int endless = !(proj.par[P_PMODE] & EN_PLOOP);
    int p, n = 0, last = 0, i, k = 0;
    char v[12];
    for (p = 0; p < P_NPARAMS; p++)
        if (!undo_skip(p, endless) && proj.par[p] != s->par[p]) {
            proj.par[p] = s->par[p];
            en_set(p, proj.par[p]);
            last = p;
            n++;
        }
    if (proj.pool != s->pool) {
        proj.pool = s->pool;
        en_pool(proj.pool);
        last = P_MODE;
        n += n ? 0 : 1;                          /* (a mode: its pool and its number, one change) */
    }
    if (n == 1) {                                /* the one setting, and where it is now */
        const char *nm = en_param_info(last)->name;
        while (*nm && k < 14 && k < cap - 1)
            what[k++] = *nm++;
        en_param_text(last, proj.par[last], v);
        if (k < cap - 1)
            what[k++] = ' ';
        for (i = 0; v[i] && k < cap - 1; i++)
            what[k++] = v[i];
        what[k] = 0;
    } else {
        static const char SET[] = " settings";
        itoa_u((uint32_t)n, what);
        while (what[k])
            k++;
        for (i = 0; SET[i] && k < cap - 1; i++)
            what[k++] = SET[i];
        what[k] = 0;
    }
    return n;
}
static void undo_step(int redo)                  /* HOME held, OCT- or OCT+ */
{
    const char *head = redo ? "REDO" : "UNDO";
    char t[24];
    undo_close();
    if (!(redo ? ud.rn : ud.un)) {
        say(head, "NOTHING");
        card_show(redo ? "NOTHING TO REDO" : "NOTHING TO UNDO", 0, K_DIM, 0);
        return;
    }
    undo_capture(&ud.shadow);                    /* (as it is now: the other way back. Restored first, because
                                                  * with the array full the two share a place) */
    if (redo) {
        undo_restore(&ud.hist[UNDO_N - ud.rn], t, (int)sizeof t);
        ud.hist[ud.un] = ud.shadow;
        ud.rn--, ud.un++;
    } else {
        undo_restore(&ud.hist[ud.un - 1], t, (int)sizeof t);
        ud.hist[UNDO_N - 1 - ud.rn] = ud.shadow;
        ud.un--, ud.rn++;
    }
    undo_capture(&ud.shadow);
    ui.dirty = 1;                                /* (saved at rest, as any edit: the stack itself never is) */
    say(head, t);
    card_show(head, t, K_ACC, 0);
}
static void oct_press(int b)
{
    const int other = b == B_OCTUP ? B_OCTDN : B_OCTUP;
    if (ui.btn >> B_HOME & 1u) {                 /* (0.5) HOME held: OCT- undoes, OCT+ redoes. HOME's tap and shake
                                                  * and this button's step are off */
        ui.btn_used |= 1u << B_HOME | 1u << b;
        undo_step(b == B_OCTUP);
        return;
    }
    if (ui.btn >> other & 1u)                    /* both down: neither steps */
        ui.btn_used |= 1u << B_OCTDN | 1u << B_OCTUP;
}
static void oct_release(int b)
{
    if (!(ui.btn_used >> b & 1u))
        oct_step(b);                             /* a tap */
}

/* (1.1) SLEEP, Setup's ALGORITHM (ZEN-1's and Penumbra's idea): off, or 15 or 30 minutes, 1, 2, 4 or 8 hours from the
 * last touch (a button, a key, a knob, a note from outside). The sound fades out over the last SLEEP_FADE (a touch
 * then: it comes back up, and the time starts again); then the music stops and the screen and the lights go dark. A
 * new press, key or turn wakes it (MIDI does not: a sequencer left running would): the screen back, the music again if
 * it was playing, faded in; that touch only wakes (sleep_input). Not saved: off at every start. The fade is a gain after MASTER (ui_gain_q12: main_fm1.c), so the USB audio input,
 * taken before MASTER, is not faded; it stops with the music */
#define NSLEEP 7
static const uint16_t SLEEP_MIN[NSLEEP] = {0, 15, 30, 60, 120, 240, 480};
static const char *const SLEEP_NAME[NSLEEP] = {"OFF", "15 MIN", "30 MIN", "1 HOUR", "2 HOURS", "4 HOURS", "8 HOURS"};
static const char *const SLEEP_SAID[NSLEEP] = {"sleep off", "sleep in 15 minutes", "sleep in 30 minutes",
                                               "sleep in 1 hour", "sleep in 2 hours", "sleep in 4 hours",
                                               "sleep in 8 hours"};
#define SLEEP_FADE 30000u                        /* the fade out, ms: by the gain's square, so it sounds even */
#define WAKE_FADE 1000u                          /* back up: the whole way in this at most */
#define WAKE_QUIET 300u                          /* woken: touches still only wake till none for this long */
volatile uint32_t ui_gain_q12 = 4096u;           /* the gain after MASTER, Q12 (the audio's: main_fm1.c, amb_host.c) */
static struct {
    uint8_t set;                                 /* SLEEP_MIN's index */
    uint8_t asleep, was_playing;
    uint8_t waking;                              /* woken: the touch that woke it not let through yet */
    uint32_t gain_t, quiet_t;                    /* the gain's last step; woken, the last touch */
} sl;
static void sleep_turn(int e)                    /* (a step a detent; off at the left, 8 hours at the right) */
{
    int v = (int)sl.set + e;
    sl.set = (uint8_t)(v < 0 ? 0 : v >= NSLEEP ? NSLEEP - 1 : v);
    say_as("SLEEP", SLEEP_NAME[sl.set], 0);
    if (ann_on()) {                              /* (in words: "sleep in 30 minutes") */
        ann_say(SLEEP_SAID[sl.set], 0, ANN_NOW);
        sp_said = 1;
    }
}

/* (1.2; the idea is Unholy Union's, Bunker's and Tessera's, the code ours) Evolve's timing, HOME's ALGORITHM: its
 * nudges now and then on a phrase's start, as before, or on every 4th, 8th, 16th or 32nd bar line from the top, every
 * time (Evolve above 40, as ever; at 40 and under, none). Saved, for every piece (proj.evbars); the patterns' own small
 * changes (seq_vary) keep their times */
#define NEVB 5
static const uint8_t EVB_BARS[NEVB] = {0, 4, 8, 16, 32};
static const char *const EVB_NAME[NEVB] = {"NOW AND THEN", "EVERY 4 BARS", "EVERY 8 BARS", "EVERY 16 BARS",
                                           "EVERY 32 BARS"};
static const char *const EVB_SAID[NEVB] = {"evolve now and then", "evolve every 4 bars", "evolve every 8 bars",
                                           "evolve every 16 bars", "evolve every 32 bars"};
static int evb(void) { return proj.evbars < NEVB ? proj.evbars : 0; }
static void evolve_turn(int e)                   /* (a step a detent; now and then at the left, 32 bars at the right) */
{
    int v = evb() + e;
    v = v < 0 ? 0 : v >= NEVB ? NEVB - 1 : v;
    if (v != evb()) {
        proj.evbars = (uint8_t)v;
        mark_dirty();
    }
    say_as("EVOLVE", EVB_NAME[v], 0);
    if (ann_on()) {
        ann_say(EVB_SAID[v], 0, ANN_NOW);
        sp_said = 1;
    }
}

/* (1.2; the idea is Penumbra's, the code ours) MIDI CCs, any channel, USB and the TRS jack: 16-19 (General Purpose 1-4)
 * the four knobs of the page on screen, as KNOB 1-4; 74-79 HOME's four and PERFORM's two, whatever the page: Filter,
 * Evolve, Motion, Drift, Wet, Energy. A CC sets the value outright, 0..127 across the knob's range (the centred ones:
 * 64 is 0), and is a touch, as a note. (1.3) 20-31 and 102-116: PERFORM's 27 effects, a CC a key (pkey_cc). Never SAVE (a DAW's stream would wear the flash); Setup's Lights, Tune and MIDI
 * out are left alone too */
#define CC_PAGE 16
#define CC_FIXED 74
static const uint16_t CC_FIXED_K[7] = {K_FILTER, P_EVOLVE, P_MOTION, P_DRIFT, K_DUB, K_ENERGY, K_CHORUS};
static void cc_in(int n, int v)
{
    int k = K_NONE, j = -1, lo, hi;
    if ((k = cc_pkey(n)) >= 0) {                 /* (1.3) an effect, held while its CC is 64 or over: on any page */
        const uint32_t b = 1u << k;
        if (v >= 64) {                           /* (1.4) 64..127 its amount too: 127 full, as 1.3 */
            const int was = ui.pamt[k];
            ui.pamt[k] = (uint8_t)(v > 127 ? 127 : v);
            if (!(ui.pcc & b)) {
                ui.pcc |= b;
                fx_send();
                say(PKEY[k].name, 0);
            } else if (was != ui.pamt[k])
                fx_send();
        } else if (v < 64 && (ui.pcc & b)) {
            ui.pcc &= ~b;
            fx_send();
        }
        ui.act_t = plat_ms();
        return;
    }
    k = K_NONE;
    if (n >= CC_PAGE && n < CC_PAGE + 4) {
        if (grid_up())
            return;                              /* (the grid on the screen: the knobs rest, as by hand) */
        j = n - CC_PAGE;
        k = VIEW_KNOB[ui.view][j];
    } else if (n >= CC_FIXED && n < CC_FIXED + 7) {
        k = CC_FIXED_K[n - CC_FIXED];
    }
    if (k == K_NONE || k == K_CPU || k == K_SAVE || k == K_LEDS || k == K_SCR || k == P_TUNE || k == P_MIDI)
        return;
    knob_range(k, &lo, &hi);
    knob_set(k, lo + (v * (hi - lo) + 63) / 127);
    if (j >= 0) {                                /* (the page's knob: lit, its help, as a turn by hand) */
        ui.touched = (int8_t)j;
        ui.touch_until = plat_ms() + 1200u;
    }
    ui.act_t = plat_ms();                        /* (a touch, as a note: the sleep timer waits) */
}

/* MIDI in (USB and the TRS jack): notes on any channel play the Lead (they added or removed their note from the scale up
 * to 0.3: the scale is the Key page's now); clock and start / stop drive the grid */
static void midi_in(void)
{
    uint32_t pkt;
    while (plat_midi_in(&pkt)) {
        uint32_t st = (pkt >> 8) & 0xFFu, n = (pkt >> 16) & 0x7Fu, v = pkt >> 24;
        if (st == 0xF8u || st == 0xFAu || st == 0xFBu || st == 0xFCu)
            en_clock(st == 0xF8u ? EN_CLK_TICK : st == 0xFAu ? EN_CLK_START : st == 0xFBu ? EN_CLK_CONTINUE : EN_CLK_STOP);
        else if ((st & 0xF0u) == 0x90u || (st & 0xF0u) == 0x80u) {
            en_lead_midi((int)n, (st & 0xF0u) == 0x90u && v);
            if ((st & 0xF0u) == 0x90u && v)      /* (1.1) a note played from outside is a touch: the sleep timer waits
                                                  * (asleep, MIDI never reaches here: sleep_input) */
                ui.act_t = plat_ms();
        }
        else if ((st & 0xF0u) == 0xB0u && (n == 120u || n == 123u)) {
            en_lead_midi(-1, 0);                 /* (all sound off, all notes off: a DAW's stop, say) */
            if (ui.pcc) {                        /* (1.3: and the effects a CC held) */
                ui.pcc = 0;
                fx_send();
            }
        }
        else if ((st & 0xF0u) == 0xB0u)
            cc_in((int)n, (int)v);               /* (1.2) */
        else if ((st & 0xF0u) == 0xC0u && n < NPIECES * (pack_have() ? 2u : 1u)) {   /* (packs: 8-15 the pack's) */   /* (1.1, Penumbra's idea) program change 0-7, any
                                                  * channel: that piece, as PRESET turned to it. The one playing:
                                                  * nothing (a DAW sends it at every clip's start; not grown again) */
            if ((int)n != proj.piece + NPIECES * bank)
                set_piece_bank((int)n / NPIECES, (int)n % NPIECES);
            ui.act_t = plat_ms();                /* (a touch, as a note: the sleep timer waits) */
        }
    }
}


#define RESET_HOLD 1500u                 /* GLO held on: the piece back to its recipe */

/* NUDGE: a layer's button held (ENV the Drone, ARP the Sequence, LFO the Lead, SEQ Sequence 2): its sound a small step
 * further, a few of its values each a few units, a walk pulled back to the piece's recipe (the further a value has
 * gone, the likelier it steps back), so nudges explore round the piece's sound and never wander off. The biggest
 * change said, and the layer's sound page shown, that knob lit. Evolve nudges by itself: now and then on a phrase's
 * first bar, one layer, a smaller step (nudge_tick) */
#define NUDGE_HOLD 500u
#define SHAKE_HOLD 1500u                  /* held on: a shake (a new voice, every value a big step) */
#define NNUDGE 6
#define NHAND 5                                  /* (0.5) those a held button nudges: SAVE held saves now, so the Atmosphere
                                                  * moves by Evolve and HOME's shake only */
static const uint8_t NUDGE_BTN[NNUDGE] = {B_ENV, B_ARP, B_LFO, B_SEQ, B_FX, B_SAVE};
static const char *const NUDGE_NAME[NNUDGE] = {"DRONE", "SEQ", "LEAD", "SEQ 2", "SPACE", "ATMOS"};
static const uint8_t NUDGE_PAR[NNUDGE][6] = {   /* (BERLIN) each layer its own sound, never its sends, octave or the
                                                  * piece's frame (the Lead's reverb and echo stay where set: the user) */
    {P_CATT, P_CCOL, P_CRES, P_DREL, P_PHASER, P_PEDAL},   /* the Drone */
    {P_CUTOFF, P_DECAY, P_SACCENT, P_CUTOFF, P_DECAY, P_SACCENT},   /* the Sequence */
    {P_LTONE, P_LATT, P_VIB, P_GLIDE, P_LTONE, P_VIB},   /* the Lead */
    {P_S2CUT, P_S2DEC, P_S2CUT, P_S2DEC, P_S2CUT, P_S2DEC},   /* Sequence 2 */
    {P_ECHO, P_FEEDBACK, P_REVERB, P_SIZE, P_CLOUD, P_ECHO},   /* (the space: FX; its shake, a new echo time) */
    {P_NCOL, P_NGRAIN, P_NTUNE, P_NROOM, P_NCOL, P_NGRAIN},   /* (the noise: SAVE; its shake, a new character) */
};
static uint32_t nudge_seed = 0x9E3779B9u;
static int nrand(int n)
{
    nudge_seed = nudge_seed * 1664525u + 1013904223u;
    return n > 0 ? (int)((nudge_seed >> 8) % (uint32_t)n) : 0;
}
enum { NUDGE_EVOLVE, NUDGE_HAND, NUDGE_SHAKE };
/* how a nudge goes: EVOLVE (Evolve's, 1-2 values, half steps, nothing said), HAND (the button held: 3-4 values, steps
 * up to an eighth of the range), SHAKE (held on: a new voice or kit, and every value a big step). Each value walks
 * from where it is, pulled back to the recipe: back as likely as it is far from it, always back from a quarter of
 * the range away */
static uint8_t nudge_quiet;                      /* (HOME held on: the shakes all at once, said once, the page kept) */
static void nudge(int layer, int how)
{
    static const uint8_t SND[NNUDGE] = {V_CSND, V_PSND, V_BSND, V_DSND, V_SPACE, V_NSND};
    static const uint8_t VOICE[NNUDGE] = {P_CVOICE, P_SVOICE, P_LVOICE, P_S2VOICE, P_ETIME, P_NCHAR};
    int16_t rec[P_NPARAMS];
    uint16_t pool;
    int j, best = -1, bd = 0, n, np = 0;
    uint8_t pick[8];
    char vn[24] = "";
    if (how != NUDGE_EVOLVE && !nudge_quiet)     /* (a nudge is its own step back, however soon after an edit) */
        undo_close();
    if (how == NUDGE_SHAKE && layer == 4) {      /* the space's: another echo time */
        int nt = en_param_info(P_ETIME)->hi + 1, cur = proj.par[P_ETIME], v = (cur + 1 + nrand(nt - 1)) % nt;
        knob_set(P_ETIME, v);
        en_param_text(P_ETIME, v, vn);
    } else if (how == NUDGE_SHAKE) {             /* a new voice (another than this), first: the values then fit it */
        const en_param_t *pi = en_param_info(VOICE[layer]);
        int nv = pi->hi - pi->lo + 1 - (layer == 0), cur = proj.par[VOICE[layer]], v;
        v = (cur + 1 + nrand(nv > 1 ? nv - 1 : 1)) % nv;   /* (the chord's: not Noise, the last, an effect more
                                                             * than a colour; ALGORITHM still has it) */
        if (v == cur)
            v = (v + 1) % nv;
        set_voice(VOICE[layer], v);
        en_param_text(VOICE[layer], proj.par[VOICE[layer]], vn);
    }
    piece_recipe(proj.piece, rec, &pool);
    for (j = 0; j < 6; j++) {                    /* (the values to choose from, each once) */
        int q, dup = 0;
        for (q = 0; q < np; q++)
            dup |= pick[q] == NUDGE_PAR[layer][j];
        if (!dup)
            pick[np++] = NUDGE_PAR[layer][j];
    }
    n = how == NUDGE_SHAKE ? np : how == NUDGE_HAND ? 3 + nrand(2) : 1 + nrand(2);
    for (j = 0; j < n && np; j++) {
        int w = nrand(np), p = pick[w], lo = en_param_info(p)->lo, hi = en_param_info(p)->hi;
        int st = (hi - lo) / (p == P_DECAY || p == P_CUTOFF || p == P_FEEDBACK ? 16 : 8), v = proj.par[p], d;
        pick[w] = pick[--np];                    /* (not twice in one nudge) */
        if (how == NUDGE_EVOLVE)
            st = (st + 1) / 2;
        else if (how == NUDGE_SHAKE)
            st = st * 3 / 2;
        if (st < 1)
            st = 1;
        d = 1 + nrand(st);                       /* a step of 1..st; back towards the recipe as likely as it is far
                                                  * from it (a quarter of the range away: always back), else either way */
        if (v != rec[p] && nrand(hi - lo) < 4 * (v > rec[p] ? v - rec[p] : rec[p] - v))
            d = v > rec[p] ? -d : d;
        else if (nrand(2))
            d = -d;
        v += d;
        v = v < lo ? lo : v > hi ? hi : v;
        d = v - proj.par[p];
        if (!d)
            continue;
        knob_set(p, v);
        if (d * d > bd * bd)
            best = p, bd = d;
    }
    if (how == NUDGE_EVOLVE)
        return;
    {   /* said: "CHORD NUDGE  Colour +9", "CHORD SHAKE  Keys" */
        char t[24], head[16], v[8];
        const char *nm = how == NUDGE_SHAKE ? vn : best >= 0 ? en_param_info(best)->name : "";
        int k = 0, i;
        while (*nm && k < (how == NUDGE_SHAKE ? 23 : 14))
            t[k++] = *nm++;
        if (how == NUDGE_HAND && best >= 0) {
            t[k++] = ' ';
            t[k++] = bd > 0 ? '+' : '-';
            itoa_u((uint32_t)(bd > 0 ? bd : -bd), v);
            for (i = 0; v[i] && k < 23; i++)
                t[k++] = v[i];
        }
        t[k] = 0;
        for (i = 0; NUDGE_NAME[layer][i]; i++)
            head[i] = NUDGE_NAME[layer][i];
        for (k = 0; (how == NUDGE_SHAKE ? " SHAKE" : " NUDGE")[k] && i < 15; k++)
            head[i++] = (how == NUDGE_SHAKE ? " SHAKE" : " NUDGE")[k];
        head[i] = 0;
        if (!nudge_quiet)
            say(head, t);
        if (how != NUDGE_EVOLVE && !nudge_quiet) /* (yours, not Evolve's: a card in the middle too) */
            card_show(head, t, how == NUDGE_SHAKE ? K_FROST : K_PULSE, how == NUDGE_SHAKE);
    }
    if (!ui.perf && !nudge_quiet) {
        if (SND[layer] == V_NSND && ui.view != V_NSND) {
            ui.noise_from = (uint8_t)ui.view;   /* (SAVE again goes back there) */
        }
        set_view(SND[layer]);
        for (j = 0; j < 4; j++)
            if (VIEW_KNOB[ui.view][j] == best && how == NUDGE_HAND) {
                ui.touched = (int8_t)j;
                ui.touch_until = plat_ms() + 1500u;
            }
    }
}
#ifdef EN_HOST
static uint32_t ui_evolve_n, ui_evolve_bar;      /* Evolve's nudges so far, and the bar of the last */
#endif
/* (1.4) the journey: a stay on each piece (Setup's SELECT: off, 5, 10, 20 or 40 minutes), then the glide to the next
 * of the set list, on a phrase's start. A touch, or a piece picked, and the stay starts again. Not saved: off at
 * every start, as Sleep; nor is anything it does (the pieces are left as they were saved) */
#define NJR 5
static const uint8_t JR_MIN[NJR] = {0, 5, 10, 20, 40};
static const char *const JR_NAME[NJR] = {"OFF", "5 MIN", "10 MIN", "20 MIN", "40 MIN"};
static const char *const JR_SAID[NJR] = {"journey off", "journey, 5 minutes a piece", "journey, 10 minutes a piece",
                                         "journey, 20 minutes a piece", "journey, 40 minutes a piece"};
static uint32_t jr_touch(void) { return (int32_t)(ui.act_t - ui.turn_t) > 0 ? ui.act_t : ui.turn_t; }
static int jr_next(void)                         /* the set list's next piece after this one: -1, there's no other */
{
    int i;
    for (i = 1; i < NPIECES; i++)
        if (!(ui.jr_out >> (proj.piece + i) % NPIECES & 1u) && !piece_empty(bank, (proj.piece + i) % NPIECES))
            return (proj.piece + i) % NPIECES;
    return -1;
}
/* (1.4) the day and the weather: a slow round laid over whatever plays. The light: the plucks' filter, the pings'
 * tone and the plate's size, open by day, darker and closer at night; the pace: Density a few points; the weather:
 * the Atmosphere's level, three fronts a day, and at the heaviest a shower (Fras, lightly, 40 s at most). All as
 * offsets in the engine (en_day), so the piece's own values never move and nothing is marked to save. The time
 * runs while it plays; it begins at dawn. Off: every offset 0, and the sound as it was to the bit */
#define DAY_NP 5
static const uint8_t DAY_MIN[NDAY] = {0, 20, 60, 180};
static const struct { uint8_t p; int8_t day, night; } DAY_P[DAY_NP - 1] = {
    {P_CUTOFF, 8, -12}, {P_SWEEP, 6, -10}, {P_SIZE, 8, -10}, {P_DENSITY, 4, -6}};
static struct {
    uint32_t t, span, last, calc, sh_t;          /* ms into the day; a day; the tick before; the last sum; the shower's start */
    int8_t sent[DAY_NP];
    uint8_t wet;
} dy;
static float dy_frac(float x) { return x - (float)(int32_t)x; }
static float dy_ph(void) { return dy.span ? (float)dy.t / (float)dy.span : 0.0f; }   /* 0 dawn, .25 noon, .5 dusk */
static float dy_light(float ph) { return fm_sinf(FM_TWO_PI * dy_frac(ph)); }   /* -1 midnight .. 1 noon */
static float dy_weather(float ph)                /* 0 fair .. 1 the worst of it */
{
    const float f = fm_sinf(FM_TWO_PI * dy_frac(3.0f * ph + 0.15f));
    return f <= 0.0f ? 0.0f : f * (0.55f + 0.45f * fm_sinf(FM_TWO_PI * dy_frac(ph + 0.45f)));
}
static void dy_send(float l, float w, int on)
{
    int i;
    for (i = 0; i < DAY_NP; i++) {
        const float v = !on ? 0.0f : i == DAY_NP - 1 ? -6.0f + 26.0f * w
                      : l > 0.0f ? l * (float)DAY_P[i].day : -l * (float)DAY_P[i].night;
        const int o = (int)(v + (v < 0.0f ? -0.5f : 0.5f));
        if (o != dy.sent[i])
            dy.sent[i] = (int8_t)o, en_day(i == DAY_NP - 1 ? P_CRACKLE : DAY_P[i].p, o);
    }
}
static void fx_send(void);
static void cv_disc(int32_t cx, int32_t cy, int32_t r, uint16_t c);
static void dy_set(int v)
{
    v = v < 0 ? 0 : v >= NDAY ? NDAY - 1 : v;
    if (v == ui.day)
        return;
    if (!ui.day)
        dy.t = 0;                                /* (from off: dawn) */
    else if (v)
        dy.t = (uint32_t)((float)dy.t * (float)DAY_MIN[v] / (float)DAY_MIN[ui.day]);   /* (the same hour) */
    ui.day = (uint8_t)v;
    dy.span = DAY_MIN[v] * 60000u;
    dy.last = plat_ms(), dy.calc = 0;
    if (!v) {
        dy_send(0.0f, 0.0f, 0);
        dy.wet = 0;
        if (ui.shower)
            ui.shower = 0, fx_send();
    }
}
static void dy_tick(void)
{
    const uint32_t now = plat_ms(), dt = now - dy.last;
    float ph, w;
    int wet, sh;
    dy.last = now;
    if (!ui.day)
        return;
    if (en_playing && (dy.t += dt) >= dy.span)
        dy.t -= dy.span;
    if (dy.calc && now - dy.calc < 250u)
        return;
    dy.calc = now | 1u;
    ph = dy_ph(), w = dy_weather(ph);
    dy_send(dy_light(ph), w, 1);
    wet = en_playing && w > 0.8f;
    if (wet && !dy.wet)
        dy.sh_t = now;
    dy.wet = (uint8_t)wet;
    sh = wet && now - dy.sh_t < 40000u;
    if (sh != ui.shower)
        ui.shower = (uint8_t)sh, fx_send();
}
/* the sun by day, the moon by night, on its arc at the top of the main page */
static void draw_sun(void)
{
    const float ph = dy_ph(), f = ph < 0.5f ? 2.0f * ph : 2.0f * ph - 1.0f;
    const int32_t x = 98 + (int32_t)(44.0f * f + 0.5f), y = 14 - (int32_t)(9.0f * fm_sinf(3.14159265f * f) + 0.5f);
    if (ph < 0.5f)
        cv_disc(x, y, 4, K_CLAP);
    else {
        cv_disc(x, y, 4, K_TEXT);
        cv_disc(x + 3, y - 1, 4, K_BG);
    }
}
static void jr_send(void)
{
    perf_mutes();
    en_thin(jr.mask & JR_THIN);
}
static void jr_end(void)
{
    if (!jr.changed)                             /* (it stays: its own tempo back) */
        en_set(P_TEMPO, proj.par[P_TEMPO]);
    jr.on = 0;
    jr.mask = 0;
    jr.since = plat_ms();                        /* (the stay, from here) */
    jr.piece = (uint8_t)proj.piece;
    jr_send();
}
static int jr_go(int to)                         /* the glide to piece `to` begun: 0 if it can't be */
{
    to = (to % NPIECES + NPIECES) % NPIECES;
    if (jr.on || !en_playing || en_frozen || to == proj.piece)
        return 0;
    jr.on = 1, jr.to = (uint8_t)to, jr.changed = 0, jr.n = 0;
    jr.piece = (uint8_t)proj.piece;
    jr.bar = en_bar_no;
    jr.act = jr_touch();
    jr.tempo = proj.par[P_TEMPO];
    jr.mask = EN_M_BASS;                         /* the Lead first */
    jr_send();
    return 1;
}
static void jr_turn(int e)                       /* (a step a detent; off at the left) */
{
    int v = (int)jr.stay + e;
    jr.stay = (uint8_t)(v < 0 ? 0 : v >= NJR ? NJR - 1 : v);
    jr.since = plat_ms();
    jr.piece = (uint8_t)proj.piece;
    say_as("JOURNEY", JR_NAME[jr.stay], 0);
    if (ann_on()) {
        ann_say(JR_SAID[jr.stay], 0, ANN_NOW);
        sp_said = 1;
    }
}
static void jr_tick(void)
{
    const uint32_t b = en_bar_no;
    if (!jr.on) {
        const uint32_t now = plat_ms(), t = jr_touch();
        const uint8_t pb = en_phrase_bar;
        const int top = pb == 0 && jr.pb != 0;   /* a phrase's first bar, just begun */
        int to;
        jr.pb = pb;
        if (!jr.stay)
            return;
        if (!en_playing || proj.piece != jr.piece)   /* (stopped: the time waits; a piece picked: from now) */
            jr.since = now, jr.piece = (uint8_t)proj.piece;
        if ((int32_t)(t - jr.since) > 0)         /* a touch: the whole stay again */
            jr.since = t;
        if (top && now - jr.since >= JR_MIN[jr.stay] * 60000u && (to = jr_next()) >= 0)
            jr_go(to);
        return;
    }
    if (!en_playing || jr_touch() != jr.act || proj.piece != (jr.changed ? jr.to : jr.piece)) {
        /* stopped, a touch, or a piece picked (a program change) */
        jr_end();
        return;
    }
    if (!jr.changed && jr.n >= 4) {              /* the tempo across, bars 4 to 8: only the Drone and the tail sound */
        const int t0 = proj.par[P_TEMPO], t1 = proj.slot[jr.to].par[P_TEMPO];
        uint32_t d = en_bars - jr.six;
        int v;
        d = d > 64u ? 64u : d;
        v = t0 + (t1 - t0) * (int)d / 64;
        if (v != jr.tempo)
            en_set(P_TEMPO, jr.tempo = (int16_t)v);
    }
    if (b == jr.bar)
        return;
    jr.bar = b;
    switch (++jr.n) {
    case 2: jr.mask |= EN_M_KICK | EN_M_HATS; break;
    case 4: jr.mask |= EN_M_PINGS, jr.six = en_bars; break;
    case 6: jr.mask |= JR_THIN; break;
    case 8:                                      /* the piece: set_piece's change, never its save */
        mac_home();
        project_piece(jr.to);
        project_apply();
        oct_home_take();
        en_seed(plat_ms());
        en_regrow();
        say_as("PIECE", piece_name(proj.piece), 0);
        sp_piece();
        undo_clear();
        jr.changed = 1;
        jr.act = jr_touch();
        jr.bar = en_bar_no;
        jr.mask &= ~(uint32_t)JR_THIN;
        break;
    case 10: jr.mask &= ~(uint32_t)EN_M_PINGS; break;
    case 12: jr.mask &= ~(uint32_t)(EN_M_KICK | EN_M_HATS); break;
    case 14: jr.mask &= ~(uint32_t)EN_M_BASS; break;
    case 16: jr_end(); return;
    default: return;
    }
    jr_send();
}

static void nudge_tick(void)                     /* Evolve's nudges: on a phrase's first bar, now and then, one layer;
                                                  * (1.2) or every N bars, every time (evolve_turn) */
{
    static uint8_t last_pb = 0xFF;
    static uint32_t last_bar = 0xFFFFFFFFu;
    const uint8_t pb = en_phrase_bar;
    const uint32_t b = en_bar_no, nb = EVB_BARS[evb()];
    const int ev = proj.par[P_EVOLVE], new_pb = pb != last_pb, new_bar = b != last_bar;
    last_pb = pb;
    last_bar = b;
    if (!(nb ? new_bar : new_pb))
        return;
    if (nb ? b == 0 || b % nb : pb != 0)         /* (every N bars: from bar N on, not the top) */
        return;
    if (!en_playing || en_frozen || ev <= 40 || ui.lock)   /* (Lock: they rest) */
        return;
    ud.evolve = 1;
    if (nb || nrand(100) < (ev - 40) * 2 / 3) {  /* (Evolve 100: 40% of the phrases; 70: 20%; 40 and under: none) */
        nudge(nrand(NNUDGE), NUDGE_EVOLVE);
#ifdef EN_HOST
        ui_evolve_n++, ui_evolve_bar = b;        /* (for the tests: `expect evolves`, `expect evolvebar`) */
#endif
    }
    ud.evolve = 0;
}
static void input(void)
{
    uint32_t btn = plat_buttons() | link_v_btn, keys = plat_keys() | link_v_keys, ch, i;
    int32_t e;
    const int view_was = ui.view;
    ch = btn ^ ui.btn;
    ui.btn = btn;
    for (i = 0; i < NB; i++) {
        uint32_t m = 1u << i;
        if (!(ch & m))
            continue;
        if (btn & m) {
            ui.btn_used &= ~m;
            ui.down_t[i] = plat_ms();
            if (i == B_GLO)
                ui.reset_done = 0;
            if (i == B_PLAY)                   /* transport on the press */
                button((int)i);
            if (i == B_OCTDN || i == B_OCTUP)
                oct_press((int)i);
        } else if (i == B_OCTDN || i == B_OCTUP) {
            oct_release((int)i);
        } else if (i == B_EDIT) {               /* EDIT: the Chords page (a tap), the next chord (held) */
            edit_released(plat_ms() - ui.down_t[B_EDIT]);
        } else if ((i == B_GLO || i == B_SAVE) && !(ui.btn_used & m) && plat_ms() - ui.down_t[i] >= NUDGE_HOLD) {
            do_save();                           /* SAVE or GLO held and let go: saved (GLO held on: the reset, below,
                                                  * unsaved) */
            if (!ui.dirty)
                card_show("SAVED", "all eight pieces", K_ACC, 0);
        } else if (i == B_SEL && !(ui.btn_used & m) && plat_ms() - ui.down_t[B_SEL] >= NUDGE_HOLD) {
            lock_toggle();                       /* (SEL held: Lock; a tap, PERFORM) */
        } else if (!(ui.btn_used & m) && i != B_PLAY) {
            button((int)i);
        }
    }
    if (ui.view != view_was)                     /* (0.5) a button brought a new page: its name, large, for a moment */
        ui.flash_until = plat_ms() + FLASH_SHOW;
    for (i = 0; i < NHAND; i++) {                /* a layer's button held: a nudge; held on: a shake (its release
                                                  * then does nothing) */
        static uint8_t shaken;
        uint32_t m = 1u << NUDGE_BTN[i], held = plat_ms() - ui.down_t[NUDGE_BTN[i]];
        if (!(btn & m)) {
            shaken &= (uint8_t)~(1u << i);
        } else if (!(ui.btn_used & m) && held >= NUDGE_HOLD) {
            ui.btn_used |= m;
            nudge((int)i, NUDGE_HAND);
        } else if ((ui.btn_used & m) && held >= SHAKE_HOLD && !(shaken >> i & 1u) &&
                   (int32_t)(ui.turn_t - ui.down_t[NUDGE_BTN[i]]) <= 0) {
            shaken |= (uint8_t)(1u << i);
            nudge((int)i, NUDGE_SHAKE);
        }
    }
    {   /* (1.3.0) HOME held on (1.5 s, nothing turned meanwhile): a shake of everything that shakes,
         * the chord, the pings, the bass, the drums and the noise, at once; again and again, till something sounds */
        static uint8_t home_shaken;
        const uint32_t m = 1u << B_HOME;
        if (!(btn & m)) {
            home_shaken = 0;
        } else if (!home_shaken && !(ui.btn_used & m) && plat_ms() - ui.down_t[B_HOME] >= SHAKE_HOLD &&
                   (int32_t)(ui.turn_t - ui.down_t[B_HOME]) <= 0) {
            static const uint8_t ALL[5] = {0, 1, 2, 3, 5};
            int j;
            home_shaken = 1;
            ui.btn_used |= m;
            undo_close();                        /* (all of them one step back) */
            nudge_quiet = 1;
            for (j = 0; j < 5; j++)
                nudge(ALL[j], NUDGE_SHAKE);
            nudge_quiet = 0;
            say("SHAKE", "EVERYTHING");
            card_show("SHAKE ALL", "every layer, and the space", K_FROST, 1);
        }
    }
    if ((btn >> B_EDIT & 1u) && !edit_new && plat_ms() - ui.down_t[B_EDIT] >= SHAKE_HOLD &&
        (int32_t)(ui.turn_t - ui.down_t[B_EDIT]) <= 0) {   /* EDIT held on: a new progression, the walk's chords
                                                  * all walked again (yours, the gaps and the one playing kept) */
        edit_new = 1;
        undo_close();
        undo_push();                             /* (the walk writes them, not an edit's knob: undo has them too) */
        en_prog_rewalk();
        say("NEW CHORDS", EN_WALK_NAME[(proj.par[P_PMODE] & 3) % EN_NWALK]);
        card_show("NEW CHORDS", EN_WALK_NAME[(proj.par[P_PMODE] & 3) % EN_NWALK], K_FROST, 1);
    }
    ch = keys ^ ui.keys;
    ui.keys = keys;
    for (i = 0; i < NKEYS; i++)
        if (ch >> i & 1u) {
            int down = (int)(keys >> i & 1u);
            if (!down && black_of(i) >= 0)       /* (BERLIN) a black key let go: its effect ends, whatever took it */
                black_set(black_of(i), 0);
            if (!down) {                         /* (BERLIN) a white key let go: the Lead let go of it first, whatever
                                                  * takes the key now (REC, an effect, PERFORM, a page); the engine
                                                  * ignores a release that isn't its key */
                int st;
                for (st = 0; st < 16 && STEP_KEY[st] != i; st++)
                    ;
                if (st < 16)
                    en_lead_key(st, 0);
            }
            if (((btn >> B_REC & 1u) && down) || (!down && ui.fx))
                if (fx_key(i, down))
                    continue;                    /* REC held: the effects (and their keys let go) */
            if (btn >> B_REC & 1u)
                continue;                        /* (REC held: the other keys do nothing) */
            if (ui.view == V_PAT && !ui.perf) {  /* the Pattern page: the white keys, the lane's steps */
                if (down)
                    pattern_key(i, keys);
                continue;
            }
            if (ui.view == V_CHORDS && !ui.perf) {   /* the Chords page: the keys, the slot's root */
                if (down)
                    slot_key(i);
                continue;
            }
            if (ui.perf)
                perf_key(i, (int)(keys >> i & 1u));
            else {                               /* (BERLIN) the white keys: the Lead, in the scale; the black: nothing */
                int st;
                for (st = 0; st < 16 && STEP_KEY[st] != i; st++)
                    ;
                if (st < 16 && down)
                    en_lead_key(st, 1);          /* (its release sent above) */
                else if (down && black_of(i) >= 0) {   /* the black keys: their effects (spec 13) */
                    black_set(black_of(i), 1);
                    say(BLACK_NAME[black_of(i)], 0);
                }
            }
        }
    if (btn || keys || ch)
        ui.act_t = plat_ms();
    midi_in();
    if ((e = plat_enc(EN_SELECT)) != 0) {        /* (the user, 2026-10-28) a layer's pages: its level; HOME: Energy;
                                                  * elsewhere nothing (no pages, no tempo: one knob, one job) */
        if (oct_layer(ui.view) >= 0)
            level_turn(oct_layer(ui.view), e);
        else if (ui.view == V_DUB)               /* (HOME: Energy, the user's: to play the keys and push it at once) */
            energy_turn(e);
        else if (ui.view == V_SETUP || ui.view == V_SET)   /* (1.4) Setup and the Set list: the journey's stay */
            jr_turn((int)e);
        ui.turn_t = plat_ms();
    }
    if ((e = plat_enc(EN_ALGO)) != 0) {         /* a layer's page: its voice; the Chords page: the walk */
        int vp = view_voice(ui.view);
        if (atm_view(ui.view)) {   /* the Noise pages: its character */
            int c = ((proj.par[P_NCHAR] + (int)(e % EN_NNCHAR)) % EN_NNCHAR + EN_NNCHAR) % EN_NNCHAR;
            knob_set(P_NCHAR, c);
            say("NOISE", EN_NCHAR_NAME[c]);
        } else if (ui.view == V_CHORDS) {        /* the walk's character: its chords walked again, at once */
            int w = (((proj.par[P_PMODE] & 3) + (int)(e % EN_NWALK)) % EN_NWALK + EN_NWALK) % EN_NWALK;
            knob_set(P_PMODE, (proj.par[P_PMODE] & EN_PLOOP) | w);
            en_prog_rewalk();
            {   /* the character, and what it does */
                static const char *const WHAT[EN_NWALK] = {"Home: stays near home", "Wander: roams wider",
                                                         "Free: goes anywhere"};
                say("WALK", WHAT[w]);
            }
        } else if (ui.view == V_SETUP) {         /* (1.1) Setup: the sleep timer */
            sleep_turn((int)e);
        } else if (ui.view == V_DUB) {           /* (1.2) HOME: Evolve's timing */
            evolve_turn((int)e);
        } else if (vp >= 0) {
            set_voice(vp, proj.par[vp] + (int)e);   /* (every detent: a quick turn comes as several at once) */
        }                                        /* (elsewhere: nothing; the scope and the spectrum are gone) */
        ui.turn_t = plat_ms();
    }
    if ((e = plat_enc(EN_PRESET)) != 0) {
        set_piece_ring((int)e);
        ui.turn_t = plat_ms();
    }
    if ((btn >> B_GLO & 1u) && !ui.reset_done && plat_ms() - ui.down_t[B_GLO] > RESET_HOLD) {
        ui.reset_done = 1;                     /* held on: the piece back to its recipe (not saved) */
        ui.btn_used |= 1u << B_GLO;
        undo_close();                          /* (and undo brings its settings back) */
        project_piece_reset();
        link_gen++;
        project_apply();
        oct_home_take();
        mac_home();
        en_regrow();
        say("RESET", piece_name(proj.piece));
        card_show("RESET", piece_name(proj.piece), K_FROST, 1);
        mark_dirty();
    }
    for (i = 0; i < 4; i++)
        if ((e = plat_enc(EN_K1 + (int)i)) != 0) {
            if (grid_up())
                continue;                        /* (the grid on the screen: the knobs rest) */
            turn(EN_K1 + (int)i, VIEW_KNOB[ui.view][i], e);
            ui.touched = (int8_t)i;
            ui.touch_until = plat_ms() + 1200u;
            ui.act_t = ui.turn_t = plat_ms();
        }
}

/* ------------------------------------------------------------- screen --- */
/* three bands: the header (28 px), the main screen (144), the knobs (68) */
#define HDR_H 28
#define MAIN_Y 28
#define MAIN_H 144
#define KNB_Y 172
#define KNB_H 68

static uint32_t hash(uint32_t h, uint32_t v) { return (h ^ v) * 16777619u; }

/* a rectangle with rounded corners (radius r, up to 6) */
static void cv_round(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c)
{
    static const uint8_t IN[7][6] = {{0}, {1}, {1, 0}, {2, 1, 0}, {2, 1, 0, 0}, {3, 2, 1, 0, 0}, {4, 2, 1, 1, 0, 0}};
    int32_t j;
    if (r > 6)
        r = 6;
    if (r > h / 2)
        r = h / 2;
    cv_rect(x, y + r, w, h - 2 * r, c);
    for (j = 0; j < r; j++) {
        int32_t d = IN[r][j];
        cv_rect(x + d, y + j, w - 2 * d, 1, c);
        cv_rect(x + d, y + h - 1 - j, w - 2 * d, 1, c);
    }
}

/* a filled circle of radius r (0..6) centred on (cx, cy): HW[r][d] is the half width d rows from the middle */
static void cv_disc(int32_t cx, int32_t cy, int32_t r, uint16_t c)
{
    static const uint8_t HW[7][7] = {{0}, {1, 0}, {2, 1, 0}, {3, 2, 2, 0}, {4, 4, 3, 2, 0}, {5, 5, 4, 4, 3, 0},
                                     {6, 6, 5, 5, 4, 3, 0}};
    int32_t j;
    if (r <= 0) {
        cv_rect(cx, cy, 1, 1, c);
        return;
    }
    if (r > 6)
        r = 6;
    for (j = -r + 1; j < r; j++) {
        int32_t w = HW[r][j < 0 ? -j : j];
        cv_rect(cx - w, cy + j, 2 * w + 1, 1, c);
    }
}

static void text_c(int32_t cx, int32_t y, const felucca_font_t *f, const char *s, uint16_t c)
{
    cv_text(cx - text_w(f, s) / 2, y, f, s, c);
}

/* anti-aliased drawing (X0X's): a pixel blended over the canvas, a disc, and a knob's ring */
static void px_blend(int32_t x, int32_t y, uint16_t c, uint32_t a)
{
    uint16_t *q;
    uint32_t bg;
    y += cv_oy;
    if ((uint32_t)x >= cv_w || y < cv_y0 || y >= cv_y1 || !a)
        return;
    q = &cv_px[(uint32_t)y * cv_w + (uint32_t)x];
    if (a >= 16u) {
        *q = swap16(c);
        return;
    }
    bg = swap16(*q);
    *q = swap16((uint32_t)(((((c >> 11) * a + (bg >> 11) * (16u - a)) >> 4) << 11) |
                           (((((c >> 5) & 63u) * a + ((bg >> 5) & 63u) * (16u - a)) >> 4) << 5) |
                           (((c & 31u) * a + (bg & 31u) * (16u - a)) >> 4)));
}

static void disc(float cx, float cy, float r, uint16_t c)
{
    int32_t x0 = (int32_t)fm_floorf(cx - r - 1.0f), x1 = (int32_t)(cx + r + 1.0f);
    int32_t y0 = (int32_t)fm_floorf(cy - r - 1.0f), y1 = (int32_t)(cy + r + 1.0f), x, y;
    for (y = y0; y <= y1; y++)
        for (x = x0; x <= x1; x++) {
            float dx = (float)x + 0.5f - cx, dy = (float)y + 0.5f - cy, d = fm_sqrtf(dx * dx + dy * dy);
            px_blend(x, y, c, (uint32_t)(fm_clampf(r - d + 0.5f, 0.0f, 1.0f) * 16.0f + 0.5f));
        }
}

/* (AISLING) the triskele, Newgrange's triple spiral: three spirals, their centres R from (cx, cy), each winding `turns`
 * from its centre out to (cx, cy), where the three meet; a line th wide, each arm drawn to the fraction g (0..1) of
 * its length from its own centre (the launch screen grows it) */
static void triskele_at(float cx, float cy, float R, float turns, float th, float g, float rot, uint16_t c)
{
    const float T = turns * FM_TWO_PI, end = T * fm_clampf(g, 0.0f, 1.0f);
    int k;
    for (k = 0; k < 3; k++) {
        const float phi = FM_TWO_PI * ((float)k / 3.0f - 0.25f) + rot, sx = cx + R * fm_cosf(phi), sy = cy + R * fm_sinf(phi);
        float t;
        for (t = 0.0f; t <= end; t += 0.6f / fm_maxf(R * t / T, 0.6f)) {   /* (a step of ~0.6 px along the arm) */
            const float r = R * t / T, a = phi + FM_PI - (T - t);
            disc(sx + r * fm_cosf(a), sy + r * fm_sinf(a), th * 0.5f, c);
        }
    }
}
static void triskele(float cx, float cy, float R, float turns, float th, float g, uint16_t c)
{
    triskele_at(cx, cy, R, turns, th, g, 0.0f, c);
}

/* (1.3, the user: "more Celtic") a rule as a plait: two strands crossing every PLAIT_P/2 pixels, each passing over
 * the other in turn (the one under broken either side of the crossing), from x0 to x1 about the row y. Under 2
 * crossings' room, a plain line, as before */
#define PLAIT_P 12
static void plait(int32_t x0, int32_t x1, int32_t y, uint16_t c)
{
    int32_t i, n = (x1 - x0) * 2;
    if (x1 - x0 < PLAIT_P) {
        if (x1 > x0)
            cv_rect(x0, y, x1 - x0, 1, c);
        return;
    }
    x1 = x0 + (x1 - x0) / (PLAIT_P / 2) * (PLAIT_P / 2);   /* (it ends on a crossing, the strands together) */
    n = (x1 - x0) * 2;
    for (i = 0; i <= n; i++) {
        const float x = (float)x0 + (float)i * 0.5f, ph = (float)i * (0.5f * FM_TWO_PI / (float)PLAIT_P),
                    d = 2.0f * fm_sinf(ph);
        const int32_t q = i % PLAIT_P, cross = (i + PLAIT_P / 2) / PLAIT_P;   /* (q: half pixels past a crossing, 0..11) */
        const int near = (q <= 2 || q >= PLAIT_P - 2) && i > 2 && i < n - 2;
        if (!(near && (cross & 1)))
            disc(x, (float)y + 0.5f + d, 0.62f, c);
        if (!(near && !(cross & 1)))
            disc(x, (float)y + 0.5f - d, 0.62f, c);
    }
}

/* atan2 in turns, 0..1 from +x going clockwise on screen (y down) */
static float turns(float y, float x)
{
    float ax = fm_fabsf(x), ay = fm_fabsf(y), a = ax < ay ? ax / (ay + 1e-9f) : ay / (ax + 1e-9f), s = a * a, r;
    r = ((-0.0464964749f * s + 0.15931422f) * s - 0.327622764f) * s * a + a;   /* atan on [0, 1] */
    if (ay > ax)
        r = 1.57079637f - r;
    if (x < 0.0f)
        r = FM_PI - r;
    if (y < 0.0f)
        r = FM_TWO_PI - r;
    return r * (1.0f / FM_TWO_PI);
}

/* a knob: a 270-degree track from 7:30 to 4:30, anti-aliased, round ends; the value filled from
 * the start (or from the top, for a centred value) and a round handle */
static void arc_th(int32_t cx, int32_t cy, int32_t r, float th, float v, uint16_t track, uint16_t fill, uint16_t bg,
                   int bipolar)
{
    const float a0 = 0.375f, sweep = 0.75f;
    float ro = (float)r, ri = ro - th, rm = ro - th * 0.5f, fx = (float)cx + 0.5f, fy = (float)cy + 0.5f, lo, hi;
    int32_t x, y;
    v = fm_clampf(v, 0.0f, 1.0f);
    lo = bipolar ? (v < 0.5f ? v : 0.5f) : 0.0f;
    hi = bipolar ? (v < 0.5f ? 0.5f : v) : v;
    for (y = -r - 1; y <= r + 1; y++)
        for (x = -r - 1; x <= r + 1; x++) {
            float dx = (float)x, dy = (float)y, d = fm_sqrtf(dx * dx + dy * dy), t, a;
            a = fm_clampf(ro + 0.5f - d, 0.0f, 1.0f) * fm_clampf(d - ri + 0.5f, 0.0f, 1.0f);
            if (a <= 0.0f)
                continue;
            t = turns(dy, dx) - a0;
            if (t < 0.0f)
                t += 1.0f;
            t /= sweep;
            if (t > 1.0f)
                continue;
            px_blend(cx + x, cy + y, (t >= lo && t <= hi) ? fill : track, (uint32_t)(a * 16.0f + 0.5f));
        }
    {
        float e0 = a0 * FM_TWO_PI, e1 = (a0 + sweep) * FM_TWO_PI, ev = (a0 + sweep * v) * FM_TWO_PI;
        float el = (a0 + sweep * lo) * FM_TWO_PI;
        disc(fx + fm_cosf(e0) * rm - 0.5f, fy + fm_sinf(e0) * rm - 0.5f, th * 0.5f, lo <= 0.0f && hi > 0.0f ? fill : track);
        disc(fx + fm_cosf(e1) * rm - 0.5f, fy + fm_sinf(e1) * rm - 0.5f, th * 0.5f, hi >= 1.0f ? fill : track);
        if (hi > lo)
            disc(fx + fm_cosf(el) * rm - 0.5f, fy + fm_sinf(el) * rm - 0.5f, th * 0.5f, fill);
        disc(fx + fm_cosf(ev) * rm - 0.5f, fy + fm_sinf(ev) * rm - 0.5f, th * 0.5f + 1.3f, bg);
        disc(fx + fm_cosf(ev) * rm - 0.5f, fy + fm_sinf(ev) * rm - 0.5f, th * 0.5f + 0.6f, fill);
    }
}

static void arc(int32_t cx, int32_t cy, int32_t r, float v, uint16_t track, uint16_t fill, uint16_t bg, int bipolar)
{
    arc_th(cx, cy, r, 3.4f, v, track, fill, bg, bipolar);
}
/* a mark across a knob's ring at v (0..1 of its sweep), a little past both its edges: where a knob's behaviour changes
 * (Motion's regions, 40 and 70) */
static void arc_mark(int32_t cx, int32_t cy, int32_t r, float v, uint16_t col)
{
    const float a = (0.375f + 0.75f * v) * FM_TWO_PI, c = fm_cosf(a), sn = fm_sinf(a);
    float d;
    for (d = (float)r - 5.2f; d <= (float)r + 1.6f; d += 0.4f)
        px_blend(cx + (int32_t)(c * d + 0.5f), cy + (int32_t)(sn * d + 0.5f), col, 16u);
}

static void caps(char *d, const char *s, int n)  /* s in capitals, at most n - 1 characters */
{
    int i;
    for (i = 0; i < n - 1 && s[i]; i++)
        d[i] = (char)(s[i] >= 'a' && s[i] <= 'z' ? s[i] - 32 : s[i]);
    d[i] = 0;
}

static uint16_t mix(uint16_t a, uint16_t b, int t)   /* t 0..16: a -> b */
{
    int r, g, bl;
    if (t <= 0)
        return a;
    if (t >= 16)
        return b;
    r = ((a >> 11) * (16 - t) + (b >> 11) * t) / 16;
    g = (((a >> 5) & 63) * (16 - t) + ((b >> 5) & 63) * t) / 16;
    bl = ((a & 31) * (16 - t) + (b & 31) * t) / 16;
    return (uint16_t)(r << 11 | g << 5 | bl);
}
static int q16(float x) { return x <= 0.0f ? 0 : x >= 1.0f ? 16 : (int)(x * 16.0f + 0.5f); }

static void tag(int32_t *x, const char *s, uint16_t bg, uint16_t fg)
{
    int32_t w = text_w(&FONT_XS, s) + 10;
    cv_round(*x, 6, w, 16, 6, bg);
    cv_text(*x + 5, 7, &FONT_XS, s, fg);
    *x += w + 4;
}

/* the battery (dxsloop's thresholds on the divider's raw reading): three bars, 591 up, 561, 531; on USB
 * (powering and charging it: there is no charger line) the bars fill one, two, three in turn */
static int batt_bars(void)
{
    int32_t b = plat_battery();
    return b >= 591 ? 3 : b >= 561 ? 2 : b >= 531 ? 1 : 0;
}
static int batt_pct(void)                        /* a rough charge, 521 .. 601 */
{
    int32_t p = (plat_battery() - 521) * 100 / 80;
    return p < 0 ? 0 : p > 100 ? 100 : (int)p;
}
static void draw_battery(int32_t bx)
{
    int lvl = plat_usb_power() ? 1 + (int)((plat_ms() / 600u) % 3u) : batt_bars(), k;
    uint16_t c = !plat_usb_power() && lvl <= 1 ? K_FROST : K_DIM, o = !plat_usb_power() && !lvl ? K_FROST : K_DIM;
    cv_rect(bx, 9, 15, 1, o);                    /* (empty: the outline red) */
    cv_rect(bx, 17, 15, 1, o);
    cv_rect(bx, 9, 1, 9, o);
    cv_rect(bx + 14, 9, 1, 9, o);
    cv_rect(bx + 15, 11, 2, 5, o);
    for (k = 0; k < lvl; k++)
        cv_rect(bx + 2 + k * 4, 11, 3, 5, c);
}

/* the header: the piece in a tag, its root and mode; on the right, the tempo with a slow beat light
 * (a play triangle while resting) and a dot while there is something unsaved. Messages take its place
 * for a moment. */
static void draw_header(void)
{
    char t[24];
    int msg = plat_ms() < ui.msg_until;
    uint32_t h = hash(hash(hash(2166136261u, proj.piece | (uint32_t)proj.par[P_ROOT] << 8 | (uint32_t)proj.pool << 12),
                           en_playing | ui.dirty << 4 | (uint32_t)msg << 5 | (uint32_t)en_ext << 6 | (uint32_t)proj.par[P_MODE] << 8),
                      (uint32_t)proj.par[P_TEMPO] | (uint32_t)(ui.view == V_SETUP ? batt_pct() : 0) << 22 | (uint32_t)batt_bars() << 29 | (uint32_t)plat_usb_power() << 31 |
                      (plat_usb_power() ? (plat_ms() / 600u) % 3u << 7 : 0u) | (ui.view == V_SETUP ? plat_cpu_pct() << 8 | plat_cpu_peak() << 15 |
                                                                           (plat_xruns() & 0x1FFu) << 22 : 0u));
    if (msg)
        h = hash(hash(h, (uint32_t)ui.msg[0][0] << 8 | ui.msg[0][1]), ui.msg_until);
    if (en_playing)
        h = hash(h, (en_bars / 4u) & 1u);
    if (h == ui.sig[0])
        return;
    ui.sig[0] = h;
    cv_begin(240, HDR_H, K_BG);
    if (msg) {
        /* (1.3) in the flash's uncial hand, in capitals, where it has the letters and the room; else as before */
        char u[2][24];
        int i, j, ok = 1;
        for (i = 0; i < 2; i++) {
            caps(u[i], ui.msg[i], sizeof u[i]);
            for (j = 0; u[i][j]; j++)
                ok &= u[i][j] >= 32 && u[i][j] <= 95;
        }
        if (ok && text_w(&FONT_US, u[0]) + 8 + text_w(&FONT_US, u[1]) <= 222) {
            int32_t x = cv_text(10, 4, &FONT_US, u[0], K_TEXT);
            cv_text(x + 8, 4, &FONT_US, u[1], K_ACC);
        } else {
            int32_t x = cv_text(10, 6, &FONT_B, ui.msg[0], K_TEXT);
            cv_text(x + 8, 6, &FONT_B, ui.msg[1], K_ACC);
        }
    } else {
        int32_t x = 232, w;
        if (plat_battery() >= 0 || plat_usb_power()) {   /* the battery, at the right edge */
            draw_battery(219);
            x = 213;
        }
        if (ui.view == V_SETUP && (plat_battery() >= 0 || plat_usb_power())) {   /* Setup: the charge, by the icon */
            char c[8];
            if (plat_usb_power()) {
                c[0] = 'U', c[1] = 'S', c[2] = 'B', c[3] = 0;
            } else {
                uint32_t k;
                itoa_u((uint32_t)batt_pct(), c);
                for (k = 0; c[k]; k++)
                    ;
                c[k++] = '%', c[k] = 0;
            }
            x -= text_w(&FONT_XS, c);
            cv_text(x, 8, &FONT_XS, c, K_TEXT);
            x -= 8;
        }
        if (ui.dirty) {                            /* unsaved */
            cv_round(x - 5, 12, 5, 5, 2, K_DIM);
            x -= 11;
        }
        if (en_ext) {
            t[0] = 'E';
            t[1] = 'X';
            t[2] = 'T';
            t[3] = 0;
        } else {
            itoa_u((uint32_t)proj.par[P_TEMPO], t);
        }
        if (ui.view == V_SETUP) {                 /* Setup: the audio load (now/peak), and any dropouts ("!n") */
            char c[24] = "CPU ";
            uint32_t k;
            itoa_u(plat_cpu_pct(), c + 4);
            for (k = 0; c[k]; k++)
                ;
            c[k++] = '/';
            itoa_u(plat_cpu_peak(), c + k);
            if (plat_xruns()) {
                for (; c[k]; k++)
                    ;
                c[k++] = ' ', c[k++] = '!';
                itoa_u(plat_xruns() > 999u ? 999u : plat_xruns(), c + k);
            }
            x -= text_w(&FONT_XS, c);
            cv_text(x, 8, &FONT_XS, c, K_DIM);   /* (the leftmost on the right: its changing width moves nothing) */
        } else {                                 /* elsewhere: the tempo and the beat light */
        x -= text_w(&FONT_S, t);
        cv_text(x, 6, &FONT_S, t, en_playing ? K_TEXT : K_DIM);
        x -= 16;
        if (en_playing) {                         /* a slow beat light */
            int on = ((en_bars / 4u) & 1u) == 0u;
            cv_round(x, 9, 10, 10, 5, on ? K_PAD : K_PAD_T);
        } else {
            int32_t j;                            /* resting: a play triangle */
            for (j = 0; j < 5; j++)
                cv_rect(x + 2 + j, 9 + j, 1, 11 - 2 * j, K_DIM);
        }
        }
        w = text_w(&FONT_B, piece_name(proj.piece)) + 12;   /* the piece, in a coral tag */
        cv_round(4, 4, w, 20, 6, K_TEXT);
        cv_text(10, 6, &FONT_B, piece_name(proj.piece), K_BG);
        if (ui.view != V_SETUP) {                /* (Setup: the room is the CPU's; the root is its first knob) */
            w = cv_text(w + 10, 8, &FONT_XS, EN_NOTE_NAME[proj.par[P_ROOT]], K_TEXT);
            cv_text(w + 3, 8, &FONT_XS, mode_name(), K_DIM);
        }
    }
    cv_blit(0, 0);
}

/* (BERLIN) the main screen, Cosmic: a slow starfield; the chord a glowing body in the middle; each sequence note a
 * particle orbiting it (the Sequence inner and pink, Sequence 2 outer and cyan), a repeat a smaller one, each with a
 * fading trail. Around it: the section and its bars (top left), the page (top right), the five layers' meters (left),
 * the echo's level (right), and the two sequences' lanes (below), each with its own step */
#define CX 120
#define CY 67                                    /* (the user, 2026-10-28: down from 48, the chord, its orbits and
                                                  * its ring clear of the top bar, the page's name and the user's name, the
                                                  * meters, ECHO and the lanes: the layout scenario checks it) */
#define ORB_RX0 28.0f                            /* the orbits: the Sequence's across, Sequence 2's (31, 44 before the
                                                  * ring); their height */
#define ORB_RX1 40.0f
#define ORB_RY 0.68f
#define RING_RX 50.0f                            /* the chord's ring (its progress), outside them */
#define RING_RY 34.0f
/* the echo's output, as measured: its peak each frame, the last few frames (a repeat's level is the peak around
 * when it's due) */
#define EPK_N 16
static struct {
    uint32_t t;
    float pk;
} epk[EPK_N];
static uint8_t epk_w;
static int scr_layer(int v)                      /* a layer's own page (and the Noise page): the screen that layer's */
{
    return v == V_CHORD || v == V_TEXTURE || v == V_BASS || v == V_DRUMS || atm_view(v) || (v >= V_CSND && v <= V_DSND) || v == V_CFM || v == V_BFM || v == V_LSTYLE || v == V_SMOVE || v == V_S2MOVE
         ? oct_layer(v) : -1;                    /* (1.3.0: the sound pages too, live, not the envelope) */
}

static const char *chord_now(char *nm)          /* the chord's name, as the screen shows it ("Em7") */
{
    int pcs[EN_NPAD + 1], k;
    if (en_chord_slot >= 0 && proj.par[P_CQ0 + en_chord_slot])   /* a slot's: its own name */
        return slot_label(en_chord_slot, nm);
    pcs[0] = en_chord_root;
    for (k = 0; k < EN_NPAD; k++)
        pcs[k + 1] = en_chord[k] % 12;
    return en_chord_name(pcs, EN_NPAD + 1, nm);
}

/* the echo's level this frame (its peak since the last): the ECHO meter */
static void echo_take(uint32_t now)
{
    epk[epk_w].t = now;
    epk[epk_w].pk = en_echo_pk;
    en_echo_pk = 0.0f;
    epk_w = (uint8_t)((epk_w + 1u) % EPK_N);
}

static void line(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c);

/* (BERLIN) the stars: a sparse field, dim, drifting left a pixel every few frames while it plays */
#define STAR_N 36
static uint8_t star_x[STAR_N], star_y[STAR_N], star_b[STAR_N];
static uint8_t star_init, star_t;
static void draw_stars(void)
{
    int i;
    if (!star_init) {                            /* (the same sky every start) */
        uint32_t r = 0x2545F491u;
        for (i = 0; i < STAR_N; i++) {
            r = r * 1664525u + 1013904223u, star_x[i] = (uint8_t)(r >> 24);
            r = r * 1664525u + 1013904223u, star_y[i] = (uint8_t)((r >> 24) % 92u);
            r = r * 1664525u + 1013904223u, star_b[i] = (uint8_t)(2u + (r >> 24) % 5u);
        }
        star_init = 1;
    }
    if (en_playing && ++star_t >= 4u) {
        star_t = 0;
        for (i = 0; i < STAR_N; i++)
            star_x[i]--;                         /* (past the left edge: back in at the right, 16 px later) */
    }
    for (i = 0; i < STAR_N; i++)
        if (star_x[i] < 240)
            cv_rect(star_x[i], star_y[i], 1, 1, mix(K_BG, K_DIM, star_b[i]));
}

/* (BERLIN) the orbits: each note a particle round the chord, fading; its trail the last few places it was */
#define ORB_N 24
static struct {
    float a, life;
    uint8_t on, layer, rep;
} orb[ORB_N];
static uint32_t orb_hits[2], orb_reps[2];
static void orb_add(int layer, int rep)
{
    int i, k = 0;
    for (i = 0; i < ORB_N; i++) {
        if (!orb[i].on) {
            k = i;
            break;
        }
        if (orb[i].life < orb[k].life)
            k = i;
    }
    orb[k].on = 1;
    orb[k].layer = (uint8_t)layer;
    orb[k].rep = (uint8_t)rep;
    orb[k].life = rep ? 0.55f : 1.0f;
    orb[k].a = 0.39f * (float)(orb_hits[layer] + orb_reps[layer]) + (layer ? 3.0f : 0.0f);
}
static void orbits_take(void)                    /* the sequences' new notes and repeats, a particle each (3 at most) */
{
    int l, k;
    for (l = 0; l < 2; l++) {
        const uint32_t h = en_seq_hits[l], r = en_seq_reps[l];
        const int muted = (ui.mutes & LAYER_MUTE[l ? 3 : 1]) == LAYER_MUTE[l ? 3 : 1];
        for (k = 0; orb_hits[l] != h; k++)
            if (orb_hits[l]++, k < 3 && !muted)
                orb_add(l, 0);
        for (k = 0; orb_reps[l] != r; k++)
            if (orb_reps[l]++, k < 2 && !muted)
                orb_add(l, 1);
    }
}
static int draw_orbits(void)                     /* 1: one still moves */
{
    int i, k, any = 0;
    for (i = 0; i < ORB_N; i++) {
        const float rx = orb[i].layer ? ORB_RX1 : ORB_RX0, ry = rx * ORB_RY;
        const uint16_t c = en_frozen ? K_FROST : orb[i].layer ? K_PULSE : K_BELL;
        if (!orb[i].on)
            continue;
        for (k = 3; k >= 0; k--) {               /* the trail first, the particle on top */
            const float a = orb[i].a - 0.09f * (float)k, f = orb[i].life * (1.0f - 0.22f * (float)k);
            const int32_t x = CX + (int32_t)(rx * fm_cosf(a)), y = CY + (int32_t)(ry * fm_sinf(a)),
                          d = orb[i].rep || k ? 2 : 3;
            if (f > 0.03f)
                cv_round(x - d / 2, y - d / 2, d, d, 1, mix(K_BG, c, (int)(f * 16.0f)));
        }
        orb[i].a += orb[i].layer ? 0.045f : 0.06f;
        orb[i].life -= 0.016f;
        if (orb[i].life <= 0.0f)
            orb[i].on = 0;
        any = 1;
    }
    return any;
}

/* (the user, 2026-10-28) the chord's progress: a ring of dots round it, in the orbits' style (their size, a glow on its
 * head), growing clockwise from 12 o'clock as the chord goes on (Drift's bars and the bar's sixteenths), full as it
 * changes, then from 12 again; it doesn't spin. Brighter in the chord's last bar (to play into the change); as it was
 * while held (REC: in the hold's red); none at Drift Hold */
#define RING_N 32
static int ring_dots(int *last)                  /* the dots lit, 0..RING_N (-1: no ring); *last: the chord's last bar */
{
    static int keep = -1, keep_last;
    const int db = en_drift_bars(proj.par[P_DRIFT]);
    int k;
    float p;
    *last = 0;
    if (!db)
        return -1;
    if (en_frozen && keep >= 0) {                /* (held: the engine counts on, the ring stays) */
        *last = keep_last;
        return keep;
    }
    k = (int)(en_drift * (float)db + 0.5f);      /* (the bars of this chord gone, the one playing not) */
    p = ((float)k + (float)(en_drum_pos[0] + 1u) * (1.0f / 16.0f)) / (float)db;
    keep = (int)(fm_clampf(p, 0.0f, 1.0f) * (float)RING_N);
    keep_last = *last = k >= db - 1;
    return keep;
}
static void draw_ring(void)
{
    static int8_t rx[RING_N], ry[RING_N];
    static uint8_t init;
    const uint16_t c = en_frozen ? K_FROST : K_PAD;
    int last, n = ring_dots(&last), k;
    if (!init) {                                 /* (the places once: from 12 o'clock, clockwise) */
        for (k = 0; k < RING_N; k++) {
            const float a = (float)k * (FM_TWO_PI / (float)RING_N) - 0.25f * FM_TWO_PI,
                        x = RING_RX * fm_cosf(a), y = RING_RY * fm_sinf(a);
            rx[k] = (int8_t)(int)(x + (x < 0.0f ? -0.5f : 0.5f));
            ry[k] = (int8_t)(int)(y + (y < 0.0f ? -0.5f : 0.5f));
        }
        init = 1;
    }
    for (k = 0; k < n; k++) {                    /* (each an orbit's particle, 3 px; the head brightest, the three
                                                  * before it a glow) */
        const int back = n - 1 - k, f = back > 3 ? (last ? 12 : 7) : 16 - 2 * back;
        cv_round(CX + rx[k] - 1, CY + ry[k] - 1, 3, 3, 1, last && !back ? mix(c, K_TEXT, 8) : mix(K_BG, c, f));
    }
}

static void line(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c)   /* Bresenham */
{
    int32_t dx = x1 > x0 ? x1 - x0 : x0 - x1, dy = y1 > y0 ? y0 - y1 : y1 - y0, sx = x0 < x1 ? 1 : -1,
            sy = y0 < y1 ? 1 : -1, e = dx + dy;
    for (;;) {
        int32_t e2 = 2 * e;                      /* (taken before either step: else a short slope can overshoot) */
        cv_pset(x0, y0, c);
        if (x0 == x1 && y0 == y1)
            break;
        if (e2 >= dy) {
            e += dy;
            x0 += sx;
        }
        if (e2 <= dx) {
            e += dx;
            y0 += sy;
        }
    }
}

static void draw_meters(void)                    /* (BERLIN) left: the five layers, each its own activity at its level */
{
    const uint16_t C[5] = {K_PAD, K_BELL, K_BASS, K_PULSE, K_NOISE},
                          T[5] = {K_PAD_T, K_BELL_T, K_BASS_T, K_PULSE_T, K_PANEL};
    static const char *const NAME[5] = {"D", "1", "L", "2", "A"};
    int i;
    for (i = 0; i < 5; i++) {
        int32_t x = 8 + i * 9, h = (int32_t)(fm_clampf(en_layer_act[i], 0.0f, 1.0f) * 52.0f + 0.5f);
        cv_round(x, 32, 6, 56, 2, T[i]);
        if (h > 0)
            cv_round(x, 32 + 56 - h - 2, 6, h + 2, 2, C[i]);
        {   /* the filter: a tick, 6 px an octave from the middle (up: brighter) */
            const int32_t o = (int32_t)(fm_clampf(en_fo[i], -4.5f, 4.5f) * 6.0f);
            cv_rect(x - 1, 59 - o, 8, 1, K_TEXT);
        }
        text_c(x + 3, 89, &FONT_XS, NAME[i], mix(K_BG, C[i], 11));   /* (1.4.1) whose it is: Drone, Sequence, Lead,
                                                  * Sequence 2, Atmosphere, as the lanes' own 1 and 2 */
    }
}

static void draw_duck(void)                      /* (BERLIN) right: the echo's level, rising from the bottom (eased: up
                                                  * at once, down over ~half a second) */
{
    static float lv;
    const float pk = epk[(epk_w + EPK_N - 1u) % EPK_N].pk;
    int32_t h;
    lv = fm_maxf(fm_clampf(pk * 3.0f, 0.0f, 1.0f), lv * 0.93f);
    h = (int32_t)(lv * 52.0f + 0.5f);
    cv_round(220, 32, 8, 56, 3, K_PULSE_T);
    if (h > 0)
        cv_round(220, 32 + 54 - h, 8, h + 2, 3, K_PULSE);
    cv_text(216 - text_w(&FONT_XS, "ECHO"), 76, &FONT_XS, "ECHO", K_DIM);
}

/* (BERLIN) below: the two sequences, a lane each, as long as it is, each with its own step (white): the steps that
 * play in its colour, the rests a dot; on a layer's page the other lane greyed */
static void draw_lanes(void)
{
    const uint16_t C[2] = {K_BELL, K_PULSE}, T[2] = {K_BELL_T, K_PULSE_T};
    const int lay = oct_layer(ui.view);
    int l, i;
    for (l = 0; l < 2; l++) {
        const uint32_t p = lane_steps(l);
        const int len = proj.par[l ? P_SEQ2LEN : P_SEQLEN], pos = en_loop_pos[l],
                  lit = lay < 0 || lay == (l ? 3 : 1);
        const int32_t y = 108 + l * 16;
        text_c(14, y - 8, &FONT_XS, l ? "2" : "1", lit ? mix(K_BG, C[l], 11) : T[l]);   /* (1.4.1) which sequence */
        for (i = 0; i < len && i < 16; i++) {
            const int32_t x = 32 + i * 12;
            if (en_playing && i == pos)
                cv_round(x - 3, y - 3, 7, 7, 3, lit ? K_TEXT : K_DIM);
            else if (p >> i & 1u)
                cv_round(x - 2, y - 2, 5, 5, 2, lit ? C[l] : T[l]);
            else
                cv_rect(x, y, 1, 1, lit ? K_LINE : K_PANEL);
        }
    }
}

/* the grid's cells, in its order (the host's gridfit checks each fits its 55 px) */
static const char *const GRID_CELL[EN_NFX] = {"Repeat", "Time", "Stop", "Shimmer", "Low", "High", "Sweep", "Phaser",
                                              "Reverb", "Ceo", "Freeze", "Wash", "Octave", "Return", "Fras",
                                              "Macalla"};
/* (the user, 2026-11-10: "more Irish") the flag's orange, the sea, heather, gorse, shamrock; shaded towards bainin */
#define K_SEA kpal[KC_SEA]
#define K_HEATHER kpal[KC_HEATHER]
#define K_GORSE kpal[KC_GORSE]
#define K_BAININ kpal[KC_BAININ]
/* (1.3.1; the user, 2026-11-11: "more of how it is shown now") the grid in PERFORM's look: its name in the uncial hand,
 * a colour a group (Echo the sea and Space heather, as PERFORM's; Filter gorse, Moves the flag's orange), a shade a
 * cell, a plaited rule after each group's name; a held cell its colour full, the lettering black, as the flash */
static void grid_band(int32_t oy)                 /* the whole screen, in two bands of 240 x 120 */
{
    static const char *const GROUP[4] = {"ECHO", "FILTER", "SPACE", "MOVES"};   /* (BERLIN's) */
    const uint16_t GCOL[4] = {K_SEA, K_GORSE, K_HEATHER, K_EIRE_O};
    int r, c;
    cv_begin(240, 120, K_BG);
    text_c(120, 0 - oy, &FONT_US, "EFFECTS", K_ACC);
    text_c(120, 22 - oy, &FONT_XS, "HOLD A WHITE KEY    TAP REC: HOLD", K_DIM);
    for (r = 0; r < 4; r++) {
        int32_t yr = 38 + r * 50;
        int32_t gx = cv_text(6, yr - oy, &FONT_XS, GROUP[r], mix(K_BG, GCOL[r], 11));
        plait(gx + 6, 234, yr + 5 - oy, mix(K_BG, GCOL[r], 6));
        for (c = 0; c < 4; c++) {
            int e = r * 4 + c, on = (int)(ui.fx >> e & 1u);
            int32_t x = 4 + c * 59, y = yr + 13 - oy;
            const uint16_t col = mix(GCOL[r], K_BAININ, c * 3);
            char t[12];
            cv_round(x, y, 55, 33, 5, on ? col : mix(K_BG, col, 5));
            if (c == 0 && !on)                   /* (the first of a group: its key is lit) */
                cv_rect(x + 4, y + 29, 47, 2, col);
            caps(t, GRID_CELL[e], sizeof t);
            text_c(x + 28, y + 8, &FONT_S, t, on ? K_BG : col);
        }
    }
    cv_blit(0, (uint32_t)oy);
}

static void draw_grid(void)                      /* REC held: the effects, the whole screen */
{
    uint32_t h = hash(0x47524944u, ui.fx);
    if (h == ui.sig[1] && ui.sig[0] == 0x47524944u)
        return;
    ui.sig[0] = ui.sig[2] = 0x47524944u;         /* (the header and the knobs drawn again after) */
    ui.sig[1] = h;
    grid_band(0);
    grid_band(120);
}

/* (1.3) PERFORM at rest: its keys' effects in the main area, as the grid shows its own. Four rows of white keys from
 * F3 up, a group a row, then the eleven black keys; a colour a group; an effect not built yet dim */
static uint16_t pkey_col(int k);
/* (1.3 step 5) the map's spare cell, after the eleventh black key's: the triskele, green, turning with the music (a
 * sixteenth, a forty-eighth of a turn: once round in three bars), still at rest. Lines, no picture; on its own
 * (own = 1) only its cell is drawn and sent, and only when its angle has moved */
#define PTR_X 179
#define PTR_Y 124
#define PTR_W 57
#define PTR_H 18
static uint8_t ptr_at;
static void ptrisk(int own)
{
    const uint8_t at = (uint8_t)(en_bars % 48u);
    const int32_t ox = own ? 0 : PTR_X, oy = own ? 0 : PTR_Y;
    if (own) {
        if (at == ptr_at)
            return;
        cv_begin(PTR_W, PTR_H, K_BG);
    }
    ptr_at = at;
    plait(ox + 2, ox + 18, oy + 8, mix(K_BG, K_EIRE, 7));
    plait(ox + 40, ox + 56, oy + 8, mix(K_BG, K_EIRE, 7));
    triskele_at((float)(ox + 29), (float)(oy + 9), 4.5f, 1.5f, 1.6f, 1.0f, (float)at * (FM_TWO_PI / 48.0f), K_EIRE);
    if (own)
        cv_blit(PTR_X, MAIN_Y + PTR_Y);
}
static void draw_pmap(void)
{
    int k, w = 0, b = 0;
    if (ui.sig[1] == 0x504D4150u) {
        ptrisk(1);
        return;
    }
    ui.sig[1] = 0x504D4150u;
    cv_begin(240, MAIN_H, K_BG);
    for (k = 0; k < PERF_N; k++) {
        const int blk = PKEY[k].g == PG_BLACK, n = blk ? b++ : w++, soon = PKEY[k].d == PK_SOON;
        const int32_t x = 2 + (n & 3) * 59, y = (blk ? 84 : 0) + (n >> 2) * 20;
        const uint16_t col = pkey_col(k);
        char t[16];
        cv_round(x, y, 57, 18, 4, soon ? mix(K_BG, K_PANEL, 8) : mix(K_BG, col, 5));
        caps(t, PKEY[k].name, sizeof t);
        text_c(x + 28, y + 1, &FONT_XS, t, soon ? K_LINE : col);
    }
    ptrisk(0);
    cv_blit(0, MAIN_Y);
}

/* (1.3) PERFORM's flash: an effect held, and the header and the main area are its colour, its name large, a line
 * saying what it does; two held, two bands; more, more bands (eight at most, the rest counted). A steady colour,
 * never a strobe; the knobs stay, for the hand that turns one while a key is held. A colour a group, a shade a key;
 * the lettering black on all of them (the host's pfcontrast: 4.5:1 or better). Latched keys aren't flashed once let
 * go: their keys blink, REC is lit. */
#define PF_H (HDR_H + MAIN_H)
#define PF_MAX 8
static const uint8_t PG_COL_I[PG_N] = {KC_EIRE_O, KC_SEA, KC_HEATHER, KC_GORSE, KC_EIRE};
#define PG_COL(g) kpal[PG_COL_I[g]]
static const char *const PLINE[PERF_N] = {
    "a slice, over and over", "fog rolling into the echo", "half the speed", "a burst of rain",
    "chopped to the beat", "the Sequence's filter swept", "a beat rolled faster", "the Sequence into the echo",
    "every filter opens", "the echo rings on and builds", "every filter closes", "the tape slowing down",
    "backwards", "the Sequence an octave up", "into the plate", "falling away", "the plate climbing an octave",
    "bells in it", "the cloud holds what it has", "everything into the echo", "dust and wobble", "a jet passing",
    "a ringing pipe", "a deep phaser", "warm overdrive", "both sequences out", "fewer bits",
};
static uint16_t pkey_col(int k)
{
    int i, n = 0;
    for (i = 0; i < k; i++)
        n += PKEY[i].g == PKEY[k].g;
    return mix(PG_COL(PKEY[k].g), K_BAININ, PKEY[k].g == PG_BLACK ? n : n * 3);
}
/* (1.4.1) the held effect's band: the key's colour; on the light screen a shade deeper, so the white lettering on
 * it reads (4.5:1, the host's expect pfcontrast) */
static uint16_t pflash_col(int k) { return screen_light() ? mix(pkey_col(k), K_BAININ, 4) : pkey_col(k); }
static int pflash_up(void) { return ui.perf && (ui.pheld | ui.pcc); }
/* (1.4) a key's amount under full, in 63rds (1..63), or 0: full, or not sounding. Only a CC makes less than full */
static int pk_under(int k)
{
    const uint32_t b = 1u << k;
    const int d = PKEY[k].d;
    if (!(ui.pcc & b) || (ui.pnow & ~ui.pcc & b) || (ui.perf && (ui.pheld | ui.platch) & b))
        return 0;
    if (d >= 200 || d == EN_FX_HALF || d == EN_FX_OCTAVE || d == EN_FX_FREEZE)   /* (the switches: on is on) */
        return 0;
    return ui.pamt[k] >= 64 && ui.pamt[k] < 127 ? ui.pamt[k] - 63 : 0;
}
static void pflash_band(uint32_t m, int32_t oy, int32_t hh, int fade)
{
    int n = 0, k, j = 0, more;
    for (k = 0; k < PERF_N; k++)
        n += (int)(m >> k & 1u);
    more = n > PF_MAX ? n - (PF_MAX - 1) : 0;
    if (more)
        n = PF_MAX;
    cv_begin(240, (uint32_t)hh, K_BG);
    for (k = 0; k < PERF_N && j < n; k++) {
        int32_t y0, bh;
        uint16_t col, ink = mix(K_BG, K_PANEL, fade);
        char t[16];
        if (!(m >> k & 1u))
            continue;
        y0 = j * PF_H / n;
        bh = (j + 1) * PF_H / n - y0 - (j + 1 < n ? 2 : 0);   /* (a black rule between two) */
        if (more && j == n - 1) {                /* the last band: the rest, counted */
            cv_rect(0, y0 - oy, 240, bh, mix(K_DIM, K_BG, fade));
            t[0] = '+', t[1] = (char)('0' + more / 10), t[2] = (char)('0' + more % 10), t[3] = 0;
            text_c(120, y0 + (bh - 19) / 2 - oy, &FONT_US, more < 10 ? (t[1] = t[2], t[2] = 0, t) : t, ink);
            break;
        }
        col = mix(pflash_col(k), K_BG, fade);
        cv_rect(0, y0 - oy, 240, bh, col);
        if (pk_under(k)) {                       /* (1.4) under full: a bar up the band's left edge, as tall as its
                                                  * amount, clear of the lettering (at full there is none, and the
                                                  * flash is 1.3's) */
            const int32_t h = bh * pk_under(k) / 64 > 2 ? bh * pk_under(k) / 64 : 2;
            cv_rect(0, y0 + bh - h - oy, 6, h, ink);
        }
        caps(t, PKEY[k].name, sizeof t);
        if (n <= 2) {
            int32_t ty = y0 + (bh - 58) / 2;
            text_c(120, ty - oy, &FONT_UL, t, ink);          /* (an uncial hand for the name; the line stays plain) */
            text_c(120, ty + 42 - oy, &FONT_XS, PLINE[k], ink);
            if (ui.platch >> k & 1u)
                text_c(120, y0 + 4 - oy, &FONT_XS, "LATCHED", ink);
        } else if (n <= 4) {
            int32_t ty = y0 + (bh - 40) / 2;
            text_c(120, ty - oy, &FONT_UM, t, ink);
            text_c(120, ty + 25 - oy, &FONT_XS, PLINE[k], ink);
        } else {
            text_c(120, y0 + (bh - 19) / 2 - oy, &FONT_US, t, ink);
        }
        j++;
    }
    cv_blit(0, (uint32_t)oy);
}
static void draw_pflash(void)                    /* (each third frame, as the main area) */
{
    static uint32_t last;                        /* what was held, for the two frames it takes to go */
    static uint8_t fade;
    uint32_t m = pflash_up() ? ui.pheld | ui.pcc : 0, h;
    if (m) {
        last = m;
        fade = 0;
    } else if (!last) {
        return;
    } else if ((fade = (uint8_t)(fade + 6)) > 12) {   /* gone: the header and the main area drawn again */
        last = 0;
        ui.sig[0] = ui.sig[1] = 0;
        return;
    }
    h = hash(hash(0x50464C41u, last), ui.platch | (uint32_t)fade << 27);
    {
        int k;
        for (k = 0; k < PERF_N; k++)             /* (1.4: and each amount under full) */
            if (pk_under(k))
                h = hash(h, (uint32_t)(k << 8 | pk_under(k)));
    }
    if (h == ui.sig[1] && ui.sig[0] == 0x50464C41u)
        return;
    ui.sig[0] = 0x50464C41u;
    ui.sig[1] = h;
    pflash_band(last, 0, PF_H / 2, fade);
    pflash_band(last, PF_H / 2, PF_H - PF_H / 2, fade);
}
static int pflash_showing(void) { return ui.sig[0] == 0x50464C41u; }

/* the Pattern page: the four lanes, sixteen steps each, the lane edited lit, the accents taller, the step
 * playing a column */
static void draw_pattern(void)
{
    const uint16_t C[EN_NDRUM] = {K_PULSE, K_TEXT, K_DIM, K_RIM, K_CLAP};
    static const char *const SH[EN_NDRUM] = {"SEQ", "SEQ2", "OCT", "OCT2", "SKIP"};   /* (BERLIN's lanes, LANE_NAME) */
    int l, i, pos = en_loop_pos[0];              /* (the Sequence's step, not the bar's sixteenth) */
    text_c(120, -1, &FONT_XS, proj.par[P_SMODE] ? "PLAY: THE PATTERN" : "PLAY: AUTO (A KEY TAKES IT OVER)",
           proj.par[P_SMODE] ? K_ACC : K_DIM);
    if (en_playing)
        cv_round(37 + pos * 12, 15, 11, 86, 2, K_PANEL);   /* (five lanes, 17 px apart) */
    for (l = 0; l < EN_NDRUM; l++) {
        uint32_t p = lane_steps(l), a = proj.par[P_SMODE] ? (uint32_t)(uint16_t)proj.par[P_SACC0 + lane_seq(l)] : 0u;
        int32_t y = 17 + l * 17, sel = l == ui.lane;
        int maybe = proj.par[P_SMODE] && proj.par[P_SCH0 + lane_seq(l)] < 50;   /* (a chance under half: rings) */
        if (sel)
            cv_round(2, y - 2, 236, 17, 4, mix(K_BG, K_PANEL, 10));
        cv_text(5, y + 1, &FONT_XS, SH[l], sel ? K_TEXT : K_DIM);
        for (i = 0; i < 16; i++) {
            int32_t x = 38 + i * 12;
            if (p >> i & 1u) {
                int ac = (int)(a >> i & 1u);
                uint16_t c = en_playing && i == pos ? K_TEXT : sel ? C[l] : mix(K_BG, C[l], 9);
                int32_t yy = ac ? y : y + 3, hh = ac ? 13 : 7;
                if (maybe) {                     /* a step that only sometimes plays: a ring */
                    cv_rect(x + 1, yy, 7, 1, c), cv_rect(x + 1, yy + hh - 1, 7, 1, c);
                    cv_rect(x, yy + 1, 1, hh - 2, c), cv_rect(x + 8, yy + 1, 1, hh - 2, c);
                } else {
                    cv_round(x, yy, 9, hh, 2, c);
                }
            } else {
                cv_rect(x + 4, y + 6, 2, 2, (i & 3) ? K_LINE : K_DIM);
            }
        }
    }
    text_c(120, 104, &FONT_XS, "WHITE: STEPS   BLACK + WHITE: ACCENT", K_DIM);
}

/* the Chords page: the eight slots, the one edited outlined, the one playing lit; an empty slot inside the
 * progression shows that the chord before it goes on */
static void draw_slots(void)
{
    static const char *const HEAD[4] = {"HOME: THE WALK WRITES SLOT 8", "WANDER: THE WALK WRITES SLOT 8",
                                        "FREE: THE WALK WRITES SLOT 8", "LOOP: THE SLOTS IN TURN"};
    int i, loop = (proj.par[P_PMODE] & EN_PLOOP) != 0, n = loop ? prog_count() : EN_NPROG;
    char nm[16];
    text_c(120, -1, &FONT_XS, HEAD[loop ? 3 : (proj.par[P_PMODE] & 3) % EN_NWALK], K_ACC);
    for (i = 0; i < EN_NPROG; i++) {
        int32_t x = 12 + (i & 3) * 55, y = 30 + (i >> 2) * 46;   /* (the two rows in the middle) */
        int filled = !slot_is_gap(i), now = en_playing && i == en_prog_pos && n, sel = i == ui.slot;
        if (sel)
            cv_round(x - 2, y - 2, 54, 38, 5, K_ACC);
        cv_round(x, y, 50, 34, 4, now ? K_PAD : filled ? K_PANEL : mix(K_BG, K_PANEL, 6));
        {
            char d[2];
            d[0] = (char)('1' + i), d[1] = 0;
            cv_text(x + 3, y + 1, &FONT_XS, d, now ? K_BG : K_DIM);
        }
        if (filled) {                            /* (yours in white; the walk's in the scale's teal) */
            const char *t = slot_label(i, nm);
            text_c(x + 25, y + 11, text_w(&FONT_B, t) <= 46 ? &FONT_B : &FONT_XS, t,
                   now ? K_BG : slot_is_walk(i) ? K_PAD : K_TEXT);
        } else if (i < n) {
            text_c(x + 25, y + 13, &FONT_XS, "(HOLDS)", now ? K_BG : K_DIM);
        }
    }
}
/* (1.4) the Set list page: the eight pieces, two across. In: lit; out: dim, and marked OUT; the one playing in the
 * Drone's colour; the one the knobs are on ringed. The head: the stay (SELECT's, here as on Setup) */
static void draw_setlist(void)
{
    int i;
    char t[40], *q = t;
    const char *a = jr.stay ? "JOURNEY " : "JOURNEY OFF: SELECT SETS THE STAY", *b = jr.stay ? JR_NAME[jr.stay] : "",
               *c = jr.stay ? " A PIECE" : "";
    while (*a) *q++ = *a++;
    while (*b) *q++ = *b++;
    while (*c) *q++ = *c++;
    *q = 0;
    text_c(120, -1, &FONT_XS, t, jr.stay ? K_ACC : K_DIM);
    for (i = 0; i < NPIECES; i++) {
        const int32_t x = 6 + (i & 1) * 116, y = 16 + (i >> 1) * 24;
        const int out = ui.jr_out >> i & 1, now = i == proj.piece, sel = i == ui.jr_cur;
        char d[2], nm[20];
        if (sel)
            cv_round(x - 2, y - 2, 116, 25, 5, K_ACC);
        cv_round(x, y, 112, 21, 4, now ? K_PAD : out ? mix(K_BG, K_PANEL, 6) : K_PANEL);
        d[0] = (char)('1' + i), d[1] = 0;
        cv_text(x + 4, y + 5, &FONT_XS, d, now ? K_BG : K_DIM);
        caps(nm, piece_name(i), sizeof nm);
        cv_text(x + 16, y + 5, &FONT_XS, nm, now ? K_BG : out ? K_DIM : K_TEXT);
        if (out)
            cv_text(x + 108 - text_w(&FONT_XS, "OUT"), y + 5, &FONT_XS, "OUT", now ? K_BG : K_DIM);
    }
}

/* the level ring (SELECT on a layer's page): over the middle, the layer's level as a big knob in its colour, the
 * number inside, its name under; the arc glides to the level, a step a brief brightening; muted, grey; it fades out
 * OCT_SHOW after the last turn */
static void draw_oct(uint32_t now)
{
    const uint16_t C[NLAYER] = {K_PAD, K_BELL, K_BASS, K_PULSE, K_NOISE};
    const int32_t r = 30, cy = 66;
    int l = oct_ring_on(now) - 1, f;
    int32_t f2;
    uint16_t c, tr, tx;
    float v;
    char t[8];
    if (l < 0)
        return;
    v = (float)proj.par[LAYER_LEVEL[l]] * 0.01f;
    ui.oct_v += (v - ui.oct_v) * 0.55f;          /* (20 frames a second: there in ~100 ms) */
    if (fm_fabsf(v - ui.oct_v) < 0.004f)
        ui.oct_v = v;
    f = now < ui.oct_until ? 16 : 16 - (int)((now - ui.oct_until) * 16u / OCT_FADE);   /* the fade, 16 .. 0 */
    c = (ui.mutes & LAYER_MUTE[l]) == LAYER_MUTE[l] ? K_DIM : C[l];
    if (now - ui.oct_pulse < 160u)               /* a step: brighter for a moment */
        c = mix(c, K_TEXT, 7 - (int)((now - ui.oct_pulse) * 7u / 160u));
    tr = mix(K_BG, K_LINE, f);
    tx = mix(K_BG, K_TEXT, f);
    c = mix(K_BG, c, f);
    for (f2 = -(r + 6); f2 <= r + 6; f2++) {     /* (a disc behind it, the middle hidden) */
        int32_t w = (int32_t)fm_sqrtf((float)((r + 6) * (r + 6) - f2 * f2));
        cv_rect(CX - w, cy + f2, 2 * w + 1, 1, K_BG);
    }
    arc_th(CX, cy, r, 5.0f, ui.oct_v, tr, c, K_BG, 0);
    if ((ui.mutes & LAYER_MUTE[l]) == LAYER_MUTE[l]) {
        text_c(CX, cy - 6, &FONT_XS, "MUTED", tx);
    } else {
        itoa_u((uint32_t)proj.par[LAYER_LEVEL[l]], t);
        text_c(CX, cy - 11, &FONT_C, t, tx);
    }
    {
        int32_t w = text_w(&FONT_XS, LAYER_NAME[l]);
        cv_round(CX - w / 2 - 4, cy + r - 2, w + 8, 14, 4, K_BG);
        text_c(CX, cy + r - 2, &FONT_XS, LAYER_NAME[l], c);
    }
}

/* a nudge's card: a rounded panel in the middle, outlined amber (a nudge) or red (a shake), the layer and its move
 * and what changed; it fades out CARD_SHOW after */
static void draw_card(uint32_t now)
{
    const int32_t w = 196, h = 50, x = CX - w / 2, y = CY - 25;   /* (on the chord) */
    int f;
    uint16_t edge, hc, tc;
    if (!card_on(now))
        return;
    f = now < ui.card_until ? 16 : 16 - (int)((now - ui.card_until) * 16u / CARD_FADE);
    if (now - ui.card_t0 < 120u)                 /* (it comes in brighter, for a moment) */
        f = 16;
    edge = mix(K_BG, ui.card_col, f);
    hc = mix(K_BG, ui.card_col, f);
    tc = mix(K_BG, K_TEXT, f);
    cv_round(x - 2, y - 2, w + 4, h + 4, 6, edge);
    cv_round(x, y, w, h, 5, mix(K_BG, K_PANEL, f / 2));
    text_c(CX, y + 4, &FONT_B, ui.card_head, hc);
    text_c(CX, y + 28, &FONT_XS, ui.card_text, tc);
}

/* (0.5) a button's new page: its name, large, and its button's pages as dots, on the chord, for a moment (a card, which
 * says more, goes first) */
static void draw_flash(uint32_t now)
{
    const int32_t w = 212, h = 50, x = CX - w / 2, y = CY - 25;
    char t[16];
    int f, at = 0, n, j;
    uint16_t on;
    if (!flash_on(now) || card_on(now))
        return;
    f = now < ui.flash_until ? 16 : 16 - (int)((now - ui.flash_until) * 16u / FLASH_FADE);
    on = mix(K_BG, K_ACC, f);
    caps(t, VIEW_NAME[ui.view], sizeof t);
    cv_round(x, y, w, h, 5, mix(K_BG, K_PANEL, f));
    n = page_dots(ui.view, &at);
    if (text_w(&FONT_UL, t) <= w - 8)            /* (1.3: the uncial hand, as PERFORM's flash; all capitals, so it has them) */
        text_c(CX, y + (n ? -1 : 6), &FONT_UL, t, on);
    else if (text_w(&FONT_UM, t) <= w - 8)
        text_c(CX, y + (n ? 6 : 12), &FONT_UM, t, on);
    else if (text_w(&FONT_L, t) <= w - 8)
        text_c(CX, y + (n ? 0 : 8), &FONT_L, t, on);
    else
        text_c(CX, y + (n ? 6 : 13), &FONT_C, t, on);
    for (j = 0; j < n; j++)
        cv_round(CX - (n * 10 - 4) / 2 + j * 10, y + 38, 6, 6, 3, j == at ? on : mix(K_BG, K_DIM, f / 2));
}

#define AISLING_BY "CU_STE"                      /* (the user's name, as signed (2026-10-30): on the main screen and the launch screen) */
#define AISLING_AT "www.stephen8n.com"           /* (and the user's site, under it on the launch screen) */
static void draw_main(void)
{
    uint32_t now = plat_ms(), h = hash(2166136261u, (uint32_t)en_frozen << 16 | proj.piece << 24 | (uint32_t)en_playing << 17), i;
    static uint8_t moving;
    echo_take(now);                              /* (the ECHO meter: each frame) */
    orbits_take();
    if (ui.frame % 3u)                           /* 20 frames a second is plenty */
        return;
    if (grid_up()) {                             /* REC held: the effects grid (ui_frame draws it, whole;
                                                  * before the Chords and Pattern pages, which would draw over it) */
        if (!ui.grid_said && ann_on()) {         /* the grid in words: the white keys' effects, a group at a time */
            int e;
            sp_n = 0;
            sp_buf[0] = 0;
            sp_cat("EFFECTS GRID. White keys");
            for (e = 0; e < EN_NFX; e++) {
                sp_cat(e == 0 ? ": " : (e & 3) ? ", " : "; ");
                sp_cat(EN_FX_NAME[e]);
            }
            ann_say(sp_buf, 0, ANN_NOW);
            ui.grid_said = 1;
        }
        return;
    }
    ui.grid_said = 0;
    if (ui.perf && ui.view == V_PERF) {          /* (1.3) PERFORM at rest: its keys' effects */
        draw_pmap();
        return;
    }
    if (ui.view == V_PAT) {                      /* the Pattern page: the steps */
        h = hash(hash(0x50415454u, ui.lane | (uint32_t)proj.par[P_SMODE] << 4 | (uint32_t)en_drum_pos[0] << 8), en_playing);
        for (i = 0; i < EN_NDRUM; i++)
            h = hash(hash(h, lane_steps((int)i)), (uint32_t)(uint16_t)proj.par[P_SACC0 + lane_seq((int)i)]);
        h = hash(h, (uint32_t)oct_ring_on(now) | (uint32_t)flash_on(now) << 1);
        if (h != ui.sig[1] || oct_ring_on(now) || flash_on(now)) {
            ui.sig[1] = h;
            cv_begin(240, MAIN_H, K_BG);
            draw_pattern();
            draw_oct(now);
            draw_flash(now);
            cv_blit(0, MAIN_Y);
        }
        return;
    }
    if (ui.view == V_CHORDS) {                   /* the Chords page: the slots */
        h = hash(hash(0x43484F52u, ui.slot | (uint32_t)proj.par[P_PMODE] << 4), (uint32_t)en_prog_pos + 1u);
        for (i = 0; i < EN_NPROG; i++)
            h = hash(h, (uint32_t)proj.par[P_CR0 + i] | (uint32_t)proj.par[P_CQ0 + i] << 4 | (uint32_t)proj.par[P_CX0 + i] << 8);
        h = hash(h, (uint32_t)flash_on(now));
        if (h != ui.sig[1] || flash_on(now)) {
            ui.sig[1] = h;
            cv_begin(240, MAIN_H, K_BG);
            draw_slots();
            draw_flash(now);
            cv_blit(0, MAIN_Y);
        }
        return;
    }
    if (ui.view == V_SET) {                      /* (1.4) the Set list page */
        h = hash(hash(0x5345544Cu, ui.jr_out | (uint32_t)ui.jr_cur << 8 | (uint32_t)jr.stay << 12 | (uint32_t)proj.piece << 16),
                 (uint32_t)flash_on(now));
        if (h != ui.sig[1] || flash_on(now)) {
            ui.sig[1] = h;
            cv_begin(240, MAIN_H, K_BG);
            draw_setlist();
            draw_flash(now);
            cv_blit(0, MAIN_Y);
        }
        return;
    }
    for (i = 0; i < EN_NPAD; i++)
        h = hash(h, en_chord[i]);
    for (i = 0; i < 6; i++)
        h = hash(h, en_lane[i] | (uint32_t)proj.par[i < 4 ? i : 0] << 16);
    h = hash(h, en_drum_pos[0] | (uint32_t)q16(en_duck) << 4 | (uint32_t)q16(en_pad_level) << 9 | (uint32_t)q16(en_bass_level) << 14);
    h = hash(h, (uint32_t)(en_prog_pos + 1) << 12);
    {
        int rl, rn = ring_dots(&rl);
        h = hash(h, (uint32_t)(rn + 1) | (uint32_t)rl << 7);
    }
    h = hash(h, (uint32_t)(en_drift * 40.0f) | en_section << 8 | (uint32_t)en_phrase_bar << 12 | (uint32_t)ui.perf << 16 | ui.solo << 20 |
                (uint32_t)ui.lock << 28);
    for (i = 0; i < EN_NLOOP; i++)
        h = hash(h, (uint32_t)q16(en_loop_glow[i]) | (uint32_t)en_loop_pos[i] << 8);
    for (i = 0; i < EN_NDRUM; i++)
        h = hash(h, (uint32_t)q16(en_drum_glow[i]));
    h = hash(h, ui.view | (uint32_t)oct_ring_on(now) << 8);
    if (parent_of(ui.view) >= 0) {               /* a sound or FM page: redrawn as its values move */
        for (i = 0; i < 4; i++)
            h = hash(h, (uint32_t)(proj.par[VIEW_KNOB[ui.view][i]] + 64));
        h = hash(h, (uint32_t)proj.par[view_voice(ui.view)] | (uint32_t)proj.par[P_DECAY] << 8 | (uint32_t)proj.par[P_SEQGRID] << 16);
    }
    h = hash(h, (uint32_t)card_on(now) | (uint32_t)flash_on(now) << 1);
    if (h == ui.sig[1] && !moving && !oct_ring_on(now) && !card_on(now) && !flash_on(now))
        return;
    ui.sig[1] = h;
    cv_begin(240, MAIN_H, K_BG);
    draw_stars();
    moving = (uint8_t)(draw_orbits() | en_playing);
    draw_ring();                                 /* (the chord's progress, round it: over the orbits, under its name) */
    const int named = parent_of(ui.view) < 0 || scr_layer(ui.view) >= 0;   /* (a sound page: as its layer's) */
    static char ch_last[16];
    static uint32_t ch_t;
    char nm[16];
    uint32_t ch_age;
    uint16_t ch_c;
    chord_now(nm);
    if (!str_begins(nm, ch_last) || !str_begins(ch_last, nm)) {                   /* (1.3.0) a new chord: it comes in big and teal, then settles */
        if (ch_last[0])
            ch_t = now | 1u;
        if (card_on(now) && str_begins(ui.card_head, "NEXT CHORD") && now < ui.card_until)
            ui.card_until = now - CARD_FADE;     /* (the next chord's card gone at once, for it) */
        memcpy(ch_last, nm, sizeof ch_last);
    }
    ch_age = ch_t ? now - ch_t : 1000u;
    ch_c = en_frozen ? K_FROST : ch_age < 900u ? mix(K_ACC, K_TEXT, (int)(ch_age * 16u / 900u)) : K_TEXT;   /* (white over
                                                  * the orbits, the user; a new chord: cyan, settling) */
    if (ch_age < 900u)
        moving = 1;
    if (named) {                                 /* the chord, in the middle */
        if ((ch_age < 200u || (ch_age >= 400u && ch_age < 600u)) && text_w(&FONT_L, nm) <= 96) {   /* (big, small, big,
                                                                                         * small: a ping-pong) */
            text_c(CX, CY - 16, &FONT_L, nm, ch_c);
        } else if (text_w(&FONT_C, nm) <= 66) {  /* (the bigger face, the rings behind it; a long name, smaller) */
            text_c(CX, CY - 11, &FONT_C, nm, ch_c);
        } else if (text_w(&FONT_B, nm) <= 72) {
            text_c(CX, CY - 8, &FONT_B, nm, ch_c);
        }
        else
            text_c(CX, CY - 6, &FONT_XS, nm, ch_c);
        if ((proj.par[P_PMODE] & EN_PLOOP) && en_prog_pos >= 0 && prog_count()) {   /* Loop: where it is ("2/4") */
            char t[8];
            t[0] = (char)('1' + en_prog_pos), t[1] = '/', t[2] = (char)('0' + prog_count()), t[3] = 0;
            cv_round(CX - 12, CY + 14, 24, 11, 3, K_BG);     /* (1.4.1) clear of the orbits' dots: it is small */
            text_c(CX, CY + 11, &FONT_XS, t, K_DIM);
        }
    }
    {   /* top left: the phrase's section and its eight bars; under it, the mode the keys are in */
        char t[12];
        int b;
        caps(t, EN_SEC_NAME[en_section], sizeof t);
        cv_text(8, 2, &FONT_XS, t, en_section == EN_SEC_FLOW ? K_DIM : K_ACC);
        for (b = 0; b < 8; b++) {                /* (1.3.0: bars 4 and 8, the B bars, whiter) */
            const int bb = (b == 3 || b == 7) && !ui.lock, lit = en_playing && b <= en_phrase_bar;   /* (Lock: all alike) */
            uint16_t c = lit ? (bb ? K_TEXT : K_DIM) : (bb ? K_DIM : K_LINE);   /* (B bars: ahead, as bright as one played) */
            cv_round(9 + b * 5, 22, 3, 3, 1, c);
        }
    }
    {   /* (1.3.0) top right: the page's name (PERFORM's too); to its left, LOCK and SOLO while on */
        char pn[16];
        int32_t x;
        int k;
        caps(pn, VIEW_NAME[ui.view], sizeof pn);
        x = 232 - text_w(&FONT_US, pn);          /* (1.3: the uncial hand) */
        cv_text(x, 10, &FONT_US, pn, K_ACC);
        if (ui.view == V_DUB) {                  /* (AISLING) the main page: a small green triskele before its name */
            triskele((float)x - 11.0f, 20.0f, 4.0f, 1.5f, 1.6f, 1.0f, K_EIRE);
            x -= 20;
            if (ui.day)                          /* (1.4) the day on: its sun or moon */
                draw_sun();
        }
        for (k = 0; k < NROUND; k++)             /* (under it, the round's dots, in the panel's order: FX ENV LFO GLO
                                                  * HOME SAVE ARP SEQ) */
            cv_round(212 - NROUND * 6 + 2 + k * 6, 31, 4, 4, 2, PAGE_ORDER[k] == page_of(ui.view) ? K_ACC : K_LINE);
        if (ui.solo) {                           /* (a solo on, in PERFORM or kept after it) */
            x -= 6 + text_w(&FONT_XS, "SOLO");
            cv_text(x, 14, &FONT_XS, "SOLO", K_CLAP);
        }
    }
    cv_text(232 - text_w(&FONT_XS, AISLING_BY), -2, &FONT_XS, AISLING_BY, K_DIM);   /* (the user's: over the page) */
    {   /* hold and Lock, in red, after the section's name (top left) */
        char t[12];
        int32_t x;
        caps(t, EN_SEC_NAME[en_section], sizeof t);
        x = 8 + text_w(&FONT_XS, t) + 6;
        if (en_frozen) {
            cv_text(x, 2, &FONT_XS, "hold", K_FROST);
            x += text_w(&FONT_XS, "hold") + 6;
        }
        if (ui.lock)
            cv_text(x, 2, &FONT_XS, "lock", K_FROST);
    }
    draw_meters();
    draw_duck();
    draw_lanes();
    {   /* (BERLIN) a sound page: its brightness knob's filter, moved by the filter motion, said under the lanes */
        int layer;
        float per;
        if (bright_of(ui.view, &layer, &per) >= 0 && fm_fabsf(en_fo[layer]) >= 0.1f) {
            char t[32], *q = t;
            const char *w = en_fo[layer] < 0.0f ? "MOVING DARKER, -" : "MOVING BRIGHTER, +";
            const int tenths = (int)(fm_fabsf(en_fo[layer]) * 10.0f + 0.5f);
            while (*w)
                *q++ = *w++;
            *q++ = (char)('0' + tenths / 10 % 10), *q++ = '.', *q++ = (char)('0' + tenths % 10);
            w = " OCT";
            while (*w)
                *q++ = *w++;
            *q = 0;
            text_c(120, 130, &FONT_XS, t, K_ACC);
        }
    }
    draw_oct(now);
    draw_card(now);
    draw_flash(now);
    cv_blit(0, MAIN_Y);
}

/* the knob strip (X0X's): a rule with the page's name and five page dots at its right end; under
 * it a cell a knob: its name, a ring (or pips, for a switch of a few positions), the value. The
 * knob being turned is drawn on a tint. Only redrawn when what it shows changes (the rings cost a
 * square root and an arctangent per pixel). */
static void draw_knobs(void)
{
    uint32_t h = hash(2166136261u, ui.view | (uint32_t)ui.touched << 8), i;
    if (view_voice(ui.view) >= 0)
        h = hash(h, (uint32_t)proj.par[view_voice(ui.view)]);
    if (ui.view == V_CHORDS)
        h = hash(h, (uint32_t)proj.par[P_PMODE]);
    if (atm_view(ui.view))
        h = hash(h, (uint32_t)proj.par[P_NCHAR]);
    if (ui.view == V_MIX)
        h = hash(h, ui.mutes);
    if (ui.view == V_SETUP)
        h = hash(h, 0x534C50u ^ sl.set ^ (uint32_t)jr.stay << 8);
    if (ui.view == V_DUB)                        /* (1.2) Evolve's timing, lit while Evolve is above 40 */
        h = hash(h, 0x455642u ^ (uint32_t)evb() << 1 ^ (uint32_t)(proj.par[P_EVOLVE] > 40));
    int now_touch = plat_ms() < ui.touch_until, sel_on = ui.view == V_DUB && plat_ms() < ui.sel_until;
    for (i = 0; i < 4; i++)
        h = hash(h, (uint32_t)knob_get(VIEW_KNOB[ui.view][i]));
    if (sel_on)
        h = hash(h, 0x53454Cu ^ (uint32_t)(knob_get(K_ENERGY) + 64) << 24);
    h = hash(h, (uint32_t)now_touch | (uint32_t)(knob_dot(ui.view) + 1000) << 1);   /* (the filter's dot moving) */
    if (h == ui.sig[2])
        return;
    ui.sig[2] = h;
    cv_begin(240, KNB_H, K_BG);
    {   /* the rule; at its right end, where you are: the page, then the dots */
        char t[12];
        int k;
        int32_t xd = 237 - NROUND * 6, xt;
        int32_t x0 = 4;
        if (view_voice(ui.view) >= 0 || ui.view == V_CHORDS || atm_view(ui.view)) {   /* a layer's page: its voice, at the rule's start;
                                                                   * the Chords page: the walk's; Noise: its character */
            char vn[12];
            if (ui.view == V_CHORDS || atm_view(ui.view)) {
                const char *w = ui.view != V_CHORDS ? EN_NCHAR_NAME[proj.par[P_NCHAR] % EN_NNCHAR]
                                                  : EN_WALK_NAME[(proj.par[P_PMODE] & 3) % EN_NWALK];
                int j;
                for (j = 0; j < 11 && w[j]; j++)
                    vn[j] = w[j];
                vn[j] = 0;
            } else {
                en_param_text(view_voice(ui.view), proj.par[view_voice(ui.view)], vn);
            }
            caps(t, vn, sizeof t);
            x0 = cv_text(6, -1, &FONT_XS, t, K_DIM) + 5;
        } else if (ui.view == V_SETUP) {         /* (1.1) Setup: the sleep timer (ALGORITHM's), at the rule's start */
            x0 = cv_text(6, -1, &FONT_XS, "SLEEP", K_DIM) + 4;
            x0 = cv_text(x0, -1, &FONT_XS, SLEEP_NAME[sl.set], sl.set ? K_ACC : K_DIM) + 7;
            x0 = cv_text(x0, -1, &FONT_XS, "JOURNEY", K_DIM) + 4;   /* (1.4) and the journey's stay (SELECT's) */
            x0 = cv_text(x0, -1, &FONT_XS, JR_NAME[jr.stay], jr.stay ? K_ACC : K_DIM) + 5;
        } else if (ui.view == V_DUB && evb()) {  /* (1.2) HOME: Evolve's timing, when it's set (ALGORITHM's); dim while
                                                  * Evolve is 40 or under, so nothing moves */
            x0 = cv_text(6, -1, &FONT_XS, "EVOLVE", K_DIM) + 4;
            x0 = cv_text(x0, -1, &FONT_XS, EVB_NAME[evb()], proj.par[P_EVOLVE] > 40 ? K_ACC : K_DIM) + 5;
        }
        if (sel_on) {                            /* (HOME) SELECT turning: Energy, its value and a bar from the
                                                  * middle (as PERFORM's knob, -50..50), the rule's whole width */
            char v[8];
            const int en = knob_get(K_ENERGY);
            knob_text(K_ENERGY, v);
            cv_rect(0, 0, 240, 12, K_BG);
            xt = cv_text(6, -1, &FONT_XS, "ENERGY", K_TEXT) + 5;
            xt = cv_text(xt, -1, &FONT_XS, v + (v[0] == '+'), K_ACC) + 6;
            cv_round(xt, 3, 50, 5, 2, K_LINE);
            if (en)
                cv_round(en > 0 ? xt + 25 : xt + 25 + en / 2, 3, (en > 0 ? en : -en) / 2 + 1, 5, 2, K_ACC);
            cv_rect(xt + 25, 2, 1, 7, K_TEXT);
            xt += 56;
            if (xt < 234)
                plait(xt, 234, 5, K_LINE);
        } else if (now_touch && ui.touched >= 0 && ui.touched < 4) {   /* a knob turning: what it does, the rule's
                                                                          * whole width */
            char hp[48];
            caps(hp, KNOB_HELP[ui.view][ui.touched], sizeof hp);
            cv_rect(0, 0, 240, 12, K_BG);
            xt = cv_text(6, -1, &FONT_XS, hp, K_TEXT) + 5;
            if (xt < 234)
                plait(xt, 234, 5, K_LINE);
        } else {
            int at = 0, n = page_dots(ui.view, &at);
            xt = 234 - n * 8;                    /* (1.3.0: the page's name and the round's dots top right; here the rule,
                                                  * and at its end (0.5) a dot for each page of this button) */
            plait(x0, xt, 5, K_LINE);
            for (k = 0; k < n; k++)
                cv_round(xt + 3 + k * 8, 3, 5, 5, 2, k == at ? K_ACC : K_LINE);
            (void)xd;
        }
    }
    for (i = 0; i < 4; i++) {
        const int moff = ui.view == V_MIX && (ui.mutes & LAYER_MUTE[i]) == LAYER_MUTE[i];   /* (the mix: a muted
                                                                                       * layer grey, its level kept) */
        int k = VIEW_KNOB[ui.view][i], lo, hi, v, hot = now_touch && ui.touched == (int)i;
        int32_t x = (int32_t)i * 60, cx = x + 30;
        char t[16];
        const uint16_t MIXC[4] = {K_PAD, K_BELL, K_BASS, K_PULSE};   /* (the Mix page: the layers' colours) */
        uint16_t bg = hot ? K_PANEL : K_BG, fill = moff ? K_LINE : ui.view == V_MIX ? MIXC[i] : hot ? K_ACC : K_PAD;
        if (k == K_NONE)
            continue;
        if (i)
            cv_rect(x, 26, 1, 36, K_LINE);       /* (1.4.1) from under the names: TRANSPOSE (57 px of its 60)
                                                  * ran into it (the host's knobfit) */
        if (hot)
            cv_round(x + 3, 11, 54, 57, 6, K_PANEL);
        knob_range(k, &lo, &hi);
        v = knob_get(k);
        caps(t, KNOB_LABEL[ui.view][i], sizeof t);
        text_c(cx, 12, &FONT_XS, t, hot ? K_TEXT : K_DIM);
        if (k == K_SAVE) {                       /* (Save: a dot, lit while there's something to save) */
            cv_disc(cx, 37, 5, v ? K_ACC : K_LINE);
        } else if (k != K_CPU && hi - lo < 10) { /* a switch: its positions as pips (up to ten) */
            int n = hi - lo + 1, j, pw = n > 6 ? 3 : n > 4 ? 6 : 9, gap = n > 6 ? 2 : 3, w0 = n * (pw + gap) - gap;
            for (j = 0; j < n; j++)
                cv_round(cx - w0 / 2 + j * (pw + gap), 33, pw, 8, 2, j == v - lo ? fill : K_LINE);
        } else if (k != K_CPU) {
            arc(cx, 37, 12, hi > lo ? (float)(v - lo) / (float)(hi - lo) : 0.0f, K_LINE, fill, bg, lo < 0);
            if (knob_dot(ui.view) > -999 && (int)i == bright_of(ui.view, &(int){0}, &(float){0.0f}) && hi > lo) {
                /* (BERLIN) the filter motion: where the filter is now, a cyan dot on the ring */
                const float a = (0.375f + 0.75f * (float)(knob_dot(ui.view) - lo) / (float)(hi - lo)) * FM_TWO_PI;
                cv_disc(cx + (int32_t)(fm_cosf(a) * 12.0f + 0.5f), 37 + (int32_t)(fm_sinf(a) * 12.0f + 0.5f), 2, K_ACC);
            }
            if (k == P_MOTION) {                 /* (Motion's three regions: the loop held, variations, Breaks) */
                arc_mark(cx, 37, 12, 0.4f, K_TEXT);
                arc_mark(cx, 37, 12, 0.7f, K_TEXT);
            }
        }
        knob_text(k, t);
        text_c(cx, 50, &FONT_B, t + (t[0] == '+'), moff ? K_DIM : hot ? K_ACC : K_TEXT);   /* (the user: no plus, "1";
                                                  * the font's thin plus read as a minus; the reader still says it) */
    }
    cv_blit(0, KNB_Y);
}

static void leds(void)
{
    uint32_t b = 0, k = 0, i, ap = pool_abs();
    if (VIEW_BTN[page_of(ui.view)] != B_NONE && ((parent_of(ui.view) < 0 && ui.view != V_KEY && ui.view != V_ESND && ui.view != V_NSND2 && ui.view != V_AMOVE) || (plat_ms() / 300u) & 1u))
        b |= 1u << VIEW_BTN[page_of(ui.view)];   /* (a sound page, or Key: its button blinks) */
    if (en_playing)
        b |= 1u << B_PLAY;
    if (en_frozen)
        b |= 1u << B_REC;
    if (ui.view == V_PAT && !ui.perf && !grid_up()) {   /* the Pattern page: the lane's steps on the white keys */
        uint32_t p = lane_steps(ui.lane);
        for (i = 0; i < 16; i++)
            if (p >> i & 1u)
                k |= 1u << STEP_KEY[i];
    } else if (ui.view == V_CHORDS && !ui.perf && !grid_up()) {   /* the Chords page: the slot's root (if it has one) */
        if (!slot_is_gap(ui.slot)) {
            int r = proj.par[P_CR0 + ui.slot], q, x;
            if (slot_is_walk(ui.slot))
                walk_written(ui.slot, &r, &q, &x);
            for (i = 0; i < NKEYS; i++)
                if ((5u + i) % 12u == (uint32_t)r)
                    k |= 1u << i;
        }
    } else if (grid_up()) {                      /* the grid: each group's first key, and the effects held */
        for (i = 0; i < EN_NFX; i++)
            if (!(i & 3) || (ui.fx >> i & 1u))
                k |= 1u << FX_KEY[i];
    } else if (ui.perf) {                        /* PERFORM: each effect's key lit, dark while held, blinking latched */
        const int blink = (plat_ms() / 250u) & 1u;
        b |= 1u << B_SEL;
        for (i = 0; i < PERF_N; i++) {
            if (PKEY[i].d == PK_SOON || ((ui.pheld | ui.pcc) >> i & 1u))
                continue;
            if (!(ui.platch >> i & 1u) || blink)
                k |= 1u << i;
        }
    } else if (proj.leds) {                      /* (BERLIN) the white key of the note the Lead sounds */
        const int d = en_lead_deg;
        (void)ap;
        int bk;
        if (d >= 0 && d < 16)
            k |= 1u << STEP_KEY[d];
        for (bk = 0; bk < NBLACK; bk++)          /* (the user: the black keys lit, the effects apart from the Lead's
                                                  * white keys; one dark while its effect is held, as PERFORM's moves) */
            if (!(BLACK_DO[bk] >= 100 ? ui.mv & (BLACK_DO[bk] - 100) : ui.bfx >> BLACK_DO[bk] & 1u))
                k |= 1u << BLACK_KEY[bk];
    }
    if (ui.btn >> B_HOME & 1u) {                 /* (0.5) HOME held: what OCT- and OCT+ can do now */
        if (ud.un)
            b |= 1u << B_OCTDN;
        if (ud.rn)
            b |= 1u << B_OCTUP;
    } else {   /* (the user, 2026-10-28) a layer's page: OCT+ lit while its octave is above its home (oct_home), OCT- below */
        const int l = oct_layer(ui.view);
        if (l >= 0 && LAYER_OCT[l] != NO_OCT) {
            const int v = knob_get(LAYER_OCT[l]);
            if (v != ui.oct_home[l])
                b |= 1u << (v > ui.oct_home[l] ? B_OCTUP : B_OCTDN);
        }
    }
    plat_glow(proj.leds == 1);
    link_lit_b = b, link_lit_k = k;
    plat_leds(b, k);
}

/* AUTOSAVE: a few seconds after a change, while resting and quiet, nothing touched (a flash erase
 * silences the audio for a moment: never while the garden grows; SAVE saves then) */
#define AUTOSAVE_QUIET 4000u
static void autosave(void)
{
    uint32_t now = plat_ms();
    if (!ui.dirty || en_playing || ui.btn || ui.keys || now - ui.act_t < AUTOSAVE_QUIET || en_pad_level > 0.01f)
        return;
    if (project_save() == 0) {
        ui.dirty = 0;
        ui.saved_t = now;
    }
}

/* ------------------------------------------------------ screen reader --- */
/* The screen as text for a screen reader on the computer (announce.c; fm1-reader): a page once it settles,
 * with its knobs; a knob's value as it turns; the chord as it moves (queued: the
 * garden moves it by itself, every 20 s at the quickest); growing and resting from MIDI, and a MIDI clock
 * arriving or going; what a button did (say). WHERE (the reader asks, or it has just started listening) is
 * the whole screen in two: the page, its knobs and the header, then the garden (the chord, the scale).
 * Nothing is built while no reader listens. */
static struct {
    uint8_t view, ext, started;
    int16_t val[4];
    uint32_t chord;                            /* the chord's name, hashed */
} sp;
static char sp_buf[ANN_MAX + 1];
static uint32_t sp_n;
/* (the user, 2026-10-28) Filter, Wet and Energy as the engine moves them (Motion's, or back to 0 for a new piece),
 * into their knobs once it has taken every turn sent (a turn in flight never undone): shown, not said (the reader's
 * copy moved with them) */
static void mac_take(void)
{
    int i, j, v;
    for (i = 0; i < EN_MAC_SPACE; i++)
        if ((v = en_macro_now(i)) != EN_MAC_BUSY && v != ui.mac[i]) {
            ui.mac[i] = (int8_t)v;
            for (j = 0; j < 4; j++)
                if (VIEW_KNOB[sp.view][j] == K_FILTER + i)
                    sp.val[j] = (int16_t)v;
        }
}
/* the chord names (en_chord_name's, after the root) in words: "m" and "M7" differ only in capitals, which
 * the words file ignores */
static const char *const CHORD_Q[][2] = {
    {"", "major"}, {"m", "minor"}, {"7", "7"}, {"M7", "major 7"}, {"m7", "minor 7"}, {"6", "6"},
    {"m6", "minor 6"}, {"add9", "add 9"}, {"madd9", "minor add 9"}, {"aug", "augmented"}, {"dim", "diminished"},
    {"dim7", "diminished 7"}, {"m7b5", "half diminished"}, {"mM7", "minor major 7"}, {"sus2", "suspended 2"},
    {"sus4", "suspended 4"}, {"7sus4", "7 suspended 4"}, {"5", "5"},
};
#define NCHORD_Q (sizeof CHORD_Q / sizeof CHORD_Q[0])

static void sp_cat(const char *s)
{
    while (*s && sp_n < ANN_MAX)
        sp_buf[sp_n++] = *s++;
    sp_buf[sp_n] = 0;
}
static void sp_int(uint32_t v)
{
    char t[12];
    itoa_u(v, t);
    sp_cat(t);
}
static int sp_same(const char *a, const char *b)
{
    while (*a && *a == *b)
        a++, b++;
    return *a == *b;
}

/* a value as it is said: as shown */
static void sp_value(int k)
{
    char t[16];
    knob_text(k, t);
    sp_cat(t);
}
static void sp_knob(int view, int i)           /* "Stabs 30": the name the page gives it, then its value */
{
    sp_cat(KNOB_LABEL[view][i]);
    sp_cat(" ");
    sp_value(VIEW_KNOB[view][i]);
}

static void sp_chord_q(int root, const char *q)   /* "E minor 7" */
{
    uint32_t i;
    sp_cat(EN_NOTE_NAME[root % 12]);
    sp_cat(" ");
    for (i = 0; i < NCHORD_Q; i++)
        if (sp_same(q, CHORD_Q[i][0])) {
            sp_cat(CHORD_Q[i][1]);
            return;
        }
    sp_cat(q);
}
static void sp_chord(void)                     /* the chord in the middle of the garden */
{
    char nm[16];
    const char *q = chord_now(nm), *r = EN_NOTE_NAME[en_chord_root % 12u];
    while (*r && *q == *r)
        q++, r++;
    sp_chord_q(en_chord_root % 12u, q);
}

/* the page: its name and its knobs; all: the header too (the piece, its key, the tempo, playing or resting) */
static void sp_page(int all)
{
    int i;
    sp_n = 0;
    sp_buf[0] = 0;
    sp_cat(VIEW_NAME[ui.view]);
    sp_cat(" page");
    if (atm_view(ui.view)) {
        sp_cat(", character ");
        sp_cat(EN_NCHAR_NAME[proj.par[P_NCHAR] % EN_NNCHAR]);
    } else if (view_voice(ui.view) >= 0) {
        char vn[12];
        en_param_text(view_voice(ui.view), proj.par[view_voice(ui.view)], vn);
        sp_cat(", voice ");
        sp_cat(vn);
    }
    if (ui.view == V_CHORDS) {
        sp_cat(", walk ");
        sp_cat(EN_WALK_NAME[(proj.par[P_PMODE] & 3) % EN_NWALK]);
    }
    if (ui.view == V_SETUP) {                    /* (1.1) the sleep timer */
        sp_cat(", ");
        sp_cat(SLEEP_SAID[sl.set]);
        sp_cat(", ");
        sp_cat(JR_SAID[jr.stay]);
    }
    if (ui.view == V_DUB && evb()) {             /* (1.2) Evolve's timing */
        sp_cat(", ");
        sp_cat(EVB_SAID[evb()]);
    }
    for (i = 0; i < 4; i++) {
        if (VIEW_KNOB[ui.view][i] == K_NONE)
            continue;
        sp_cat(i ? ", " : ": ");
        sp_knob(ui.view, i);
    }
    if (!all)
        return;
    sp_cat(". Piece ");
    sp_cat(piece_name(proj.piece));
    sp_cat(", ");
    sp_cat(EN_NOTE_NAME[proj.par[P_ROOT]]);
    sp_cat(" ");
    sp_cat(mode_name());
    if (en_ext) {
        sp_cat(", tempo EXT");
    } else if (ui.view != V_KEY) {             /* (the Key page's first knob says it) */
        sp_cat(", tempo ");
        sp_int((uint32_t)proj.par[P_TEMPO]);
    }
    sp_cat(sp_tp.playing ? ", playing" : ", resting");
    if (ui.dirty)
        sp_cat(", not saved yet");
    if (ui.view == V_SETUP) {
        sp_cat(". CPU ");
        sp_int(plat_cpu_pct());
        sp_cat("%, peak ");
        sp_int(plat_cpu_peak());
        sp_cat("%");
        if (plat_usb_power()) {
            sp_cat(", on USB power");
        } else if (plat_battery() >= 0) {
            sp_cat(", battery about ");
            sp_int((uint32_t)batt_pct());
            sp_cat("%");
        }
        if (plat_xruns()) {
            sp_cat(", ");
            sp_int(plat_xruns());
            sp_cat(" dropouts");
        }
    }
}

/* the main screen: the chord and how far to the next, the section, the scale from the root up ("F and F
 * sharp": one letter's two notes joined, so they are heard as two) */
static void sp_garden(void)
{
    uint32_t ap = pool_abs();
    int i, last = -1;
    sp_n = 0;
    sp_buf[0] = 0;
    sp_cat("Chord ");
    sp_chord();
    if (en_frozen) {
        sp_cat(", hold");
    } else if (en_drift_bars(proj.par[P_DRIFT])) {
        sp_cat(", next chord ");
        sp_int((uint32_t)(fm_clampf(en_drift, 0.0f, 1.0f) * 100.0f + 0.5f));
        sp_cat("% of the way");
    } else {
        sp_cat(", held");
    }
    sp_cat(". Section ");
    sp_cat(EN_SEC_NAME[en_section]);
    {   /* (BERLIN) on a sound page: where its brightness knob's filter is moved ("Cutoff moving darker, about -1 octave") */
        int layer;
        float per;
        const int k = bright_of(ui.view, &layer, &per);
        if (k >= 0 && fm_fabsf(en_fo[layer]) >= 0.25f) {
            const int oct = (int)(fm_fabsf(en_fo[layer]) + 0.5f);
            sp_cat(". ");
            sp_cat(KNOB_LABEL[ui.view][k]);
            sp_cat(en_fo[layer] < 0.0f ? " moving darker, about " : " moving brighter, about ");
            if (oct) {
                sp_cat(en_fo[layer] < 0.0f ? "-" : "+");
                sp_int((uint32_t)oct);
                sp_cat(oct == 1 ? " octave" : " octaves");
            } else {
                sp_cat("half an octave");
            }
        }
    }
    sp_cat(". Scale");
    for (i = 0; i < 12; i++) {
        int pc = (proj.par[P_ROOT] + i) % 12;
        if (ap >> pc & 1u) {
            sp_cat(last < 0 ? " " : EN_NOTE_NAME[last][0] == EN_NOTE_NAME[pc][0] ? " and " : ", ");
            sp_cat(EN_NOTE_NAME[pc]);
            last = pc;
        }
    }
}


static void sp_piece_text(void)                /* "PIECE Timewind, D Minor, tempo 96" */
{
    sp_n = 0;
    sp_buf[0] = 0;
    sp_cat("PIECE ");
    sp_cat(piece_name(proj.piece));
    sp_cat(", ");
    sp_cat(EN_NOTE_NAME[proj.par[P_ROOT]]);
    sp_cat(" ");
    sp_cat(mode_name());
    sp_cat(", tempo ");
    sp_int((uint32_t)proj.par[P_TEMPO]);
}
static void sp_piece(void)
{
    if (!ann_on())
        return;
    sp_piece_text();
    ann_say(sp_buf, 0, ANN_NOW);
    sp_said = 1;
}

static uint32_t sp_chord_sig(void)
{
    char nm[16];
    const char *s = chord_now(nm);
    uint32_t h = 2166136261u;
    while (*s)
        h = hash(h, (uint8_t)*s++);
    return h;
}
static void sp_snap(void)
{
    int i;
    for (i = 0; i < 4; i++)
        sp.val[i] = (int16_t)knob_get(VIEW_KNOB[ui.view][i]);
    sp.view = ui.view;
    sp.ext = en_ext;
    sp.chord = sp_chord_sig();
}

static void speak(void)
{
    uint32_t now = plat_ms(), c;
    int where = ann_where(), i, changed = -1;
    if (!ann_on()) {
        sp.started = 0;
        sp_said = 0;
        return;
    }
    if (!sp.started || where) {                       /* everything on the screen, in two */
        sp.started = 1;
        sp_snap();
        sp_page(1);
        ann_say(sp_buf, 0, ANN_NOW);
        sp_garden();
        ann_say(sp_buf, 0, 0);
        sp_said = 0;
        return;
    }
    if (sp_said) {                                    /* a button said what it did (and what it changed) */
        sp_said = 0;
        sp_snap();
        return;
    }
    if (en_playing != sp_tp.playing && now - sp_tp.play_t > 150u) {   /* MIDI start / stop */
        sp_tp.playing = en_playing;
        ann_say(en_playing ? "PLAYING" : "RESTING", 0, 0);
    }
    if (en_ext != sp.ext) {                           /* a MIDI clock arrived, or stopped */
        sp.ext = en_ext;
        sp_n = 0;
        sp_cat("Tempo ");
        if (en_ext)
            sp_cat("EXT");
        else
            sp_int((uint32_t)proj.par[P_TEMPO]);
        ann_say(sp_buf, 0, 0);
    }
    if (ui.view != sp.view) {                         /* a new page: said when it settles */
        sp_snap();
        sp_page(0);
        ann_later(sp_buf, ANN_NOW, 200u, now);
        return;
    }
    for (i = 0; i < 4; i++) {                         /* a knob turning */
        int v = knob_get(VIEW_KNOB[ui.view][i]);
        if (v != sp.val[i]) {
            sp.val[i] = (int16_t)v;
            if (changed < 0)
                changed = i;
        }
    }
    if (changed >= 0) {
        sp_n = 0;
        sp_knob(ui.view, changed);
        ann_later(sp_buf, ANN_NOW, 120u, now);
    }
    c = sp_chord_sig();
    if (c != sp.chord) {                              /* the chord moved: queued, after what is being said */
        sp.chord = c;
        sp_n = 0;
        sp_cat("Chord ");
        sp_chord();
        ann_say(sp_buf, 0, 0);
    }
}

#ifdef EN_HOST
/* every page, knob value, chord and message as a screen reader gets them (the "speakdump"
 * command): KIND <tab> the text sent (fm1-reader/tools/audit.mjs puts it in words with web/words/ and checks it) */
static void sp_print(const char *kind, const char *t) { printf("%s\t%s\n", kind, t); }
static void speak_dump(void)
{
    static const char *const MSG[][2] = {{"UPDATE MODE IN", "3.."}, {"UPDATE MODE", "CANCELLED"},
                                         {"NEXT CHORD", "ON THE BAR"}, {"NEXT CHORD", 0}, {"RESTING", 0},
                                         {"PLAYING", 0}, {"HOLD", "ON"}, {"HOLD", "OFF"}, {"SAVED", 0},
                                         {"PERFORM", "ON"}, {"PERFORM", "OFF"}};
    static const char *const WARN[][2] = {{"NOT SAVED", "FLASH ERROR"}};
    project_t keep = proj;
    uint8_t keep_view = ui.view, keep_dirty = ui.dirty, keep_play = sp_tp.playing;
    uint8_t keep_ext = en_ext, keep_frozen = en_frozen, keep_rest = en_pulse_rest, keep_sec = en_section;
    int v, i, x, lo, hi;
    char t[48];
    for (v = 0; v < NVIEWS; v++) {
        ui.view = (uint8_t)v;
        sp_page(0);
        sp_print("SCREEN", sp_buf);
        for (i = 0; i < 4; i++) {
            int k = VIEW_KNOB[v][i];
            knob_range(k, &lo, &hi);
            for (x = lo; x <= hi; x++) {
                if (k < P_NPARAMS)
                    proj.par[k] = (int16_t)x;
                else if (k == K_SLOT)
                    ui.slot = (uint8_t)x;
                else if (k == K_SCR)
                    proj.light = (uint8_t)((x + 2) % 3);
                else if (k == K_DAY)
                    ui.day = (uint8_t)(x == hi ? 0 : x);   /* (left off) */
                else if (k == K_JRP)
                    ui.jr_cur = (uint8_t)x;
                else if (k == K_JRIN)
                    ui.jr_out = (uint8_t)(x ? 0 : 1u << ui.jr_cur);
                else if (k == K_CQ || k == K_CX)
                    proj.par[(k == K_CQ ? P_CQ0 : P_CX0) + ui.slot] = (int16_t)x;
                else if (k == K_LANE)
                    ui.lane = (uint8_t)x;
                else if (k == K_LCH)
                    proj.par[P_SCH0 + lane_seq(ui.lane)] = (int16_t)x;
                else
                    proj.leds = (uint8_t)x;
                sp_n = 0;
                sp_knob(v, i);
                sp_print("KNOB", sp_buf);
            }
            proj = keep;
        }
    }
    for (x = 0; x < 8; x++) {                         /* WHERE: playing, resting, unsaved, a clock, held, custom */
        ui.view = (uint8_t)(x * 3 % NPAGES);
        sp_tp.playing = (uint8_t)(x & 1);
        ui.dirty = (uint8_t)(x >> 1 & 1);
        en_ext = (uint8_t)(x == 3);
        en_frozen = (uint8_t)(x == 5);
        en_pulse_rest = (uint8_t)(x == 2);
        en_section = (uint8_t)(x % EN_NSEC);
        proj.pool = x == 6 ? 0xFFFu : x == 7 ? 0x91u : keep.pool;
        proj.par[P_ROOT] = (int16_t)(x * 5 % 12);
        sp_page(1);
        sp_print("WHERE", sp_buf);
        sp_garden();
        sp_print("WHERE", sp_buf);
    }
    proj = keep;
    ui.dirty = keep_dirty;
    sp_tp.playing = keep_play;
    en_ext = keep_ext;
    en_frozen = keep_frozen;
    en_pulse_rest = keep_rest;
    en_section = keep_sec;
    ui.view = keep_view;
    for (x = 0; x < 12; x++)
        for (i = 0; i < (int)NCHORD_Q; i++) {
            sp_n = 0;
            sp_cat("Chord ");
            sp_chord_q(x, CHORD_Q[i][0]);
            sp_print("CHORD", sp_buf);
        }
    for (i = 0; i < (int)(sizeof MSG / sizeof MSG[0]); i++) {
        msg_text(MSG[i][0], MSG[i][1], t);
        sp_print("MSG", t);
    }
    for (i = 0; i < (int)(sizeof WARN / sizeof WARN[0]); i++) {
        msg_text(WARN[i][0], WARN[i][1], t);
        sp_print("WARN", t);
    }
    for (x = 10; x < LPERF_N; x++) {
        msg_text("SOLO", LPERF_NAME[x], t);
        sp_print("MSG", t);
        msg_text(LPERF_NAME[x], "SOLO OFF", t);
        sp_print("MSG", t);
    }
    msg_text("SOLO", "OFF", t);
    sp_print("MSG", t);
    for (x = 0; x < 10; x++) {
        msg_text(LPERF_NAME[x], x < 5 ? "OFF" : 0, t);
        sp_print("MSG", t);
        if (x < 5) {
            msg_text(LPERF_NAME[x], "ON", t);
            sp_print("MSG", t);
        }
    }
    for (x = 0; x < PERF_N; x++) {               /* (1.3) PERFORM's keys, the ones to come too */
        msg_text(PKEY[x].name, 0, t);
        sp_print("MSG", t);
    }
    msg_text("LATCH", "ON", t);
    sp_print("MSG", t);
    msg_text("LATCH", "OFF", t);
    sp_print("MSG", t);
    msg_text("LATCH", "CLEAR", t);
    sp_print("MSG", t);
    for (x = 0; x < EN_NMODES; x++) {
        msg_text("MODE", EN_MODE_NAME[MODE_ORDER[x]], t);
        sp_print("MSG", t);
    }
    for (x = 0; x < NSLEEP; x++)                 /* (1.1) the sleep timer: said in words, not the screen's */
        sp_print("MSG", SLEEP_SAID[x]);
    sp_print("MSG", "sleeping");
    sp_print("MSG", "awake");
    for (x = 0; x < NLAYER; x++) {                    /* OCT- / OCT+: a level, a mute */
        msg_text(LAYER_NAME[x], "55", t);
        sp_print("MSG", t);
        msg_text(LAYER_NAME[x], "MUTED", t);
        sp_print("MSG", t);
        msg_text(LAYER_NAME[x], "ON", t);
        sp_print("MSG", t);
    }
    for (x = 90; x <= 140; x += 25) {
        char o[8];
        itoa_u((uint32_t)x, o);
        msg_text("TEMPO", o, t);
        sp_print("MSG", t);
    }
    for (x = 0; x < NPIECES; x++) {
        project_piece(x);
        sp_piece_text();
        sp_print("MSG", sp_buf);
        msg_text("RESET", piece_name(x), t);
        sp_print("MSG", t);
    }
    proj = keep;
    sp_print("MSG", "Tempo EXT");
    sp_print("MSG", "Tempo 122");
}
#endif

void ui_init(void)
{
    memset(&ui, 0, sizeof ui);
    memset(&sl, 0, sizeof sl);                   /* (1.1) the sleep timer: off at every start */
    ui_gain_q12 = 4096u;
    plat_screen(1);
    ui.touched = -1;
    oct_home_take();
    undo_clear();
    lcd_fill(0, 0, 240, 240, K_BG);
    if (!en_playing)
        en_play(1);                              /* it plays from the start */
    sp_tp.playing = 1;
    sp_tp.play_t = plat_ms();
}

#include "link.c"

/* (1.1) the sleep timer (SLEEP, above), each frame */
static uint32_t later(uint32_t a, uint32_t b) { return (int32_t)(a - b) > 0 ? a : b; }
static void sleep_fall(void)                     /* the music stopped as PLAY stops it; dark */
{
    sl.asleep = 1;
    sl.was_playing = (uint8_t)(en_playing != 0);
    if (en_playing) {
        sp_tp.playing = 0;
        sp_tp.play_t = plat_ms();
        en_play(0);
    }
    if (ann_on()) {
        ann_say("sleeping", 0, ANN_NOW);
        sp_said = 1;
    }
    plat_glow(0);
    plat_leds(0, 0);
    link_lit_b = link_lit_k = 0;
    lcd_fill(0, 0, 240, 240, 0);                 /* (black, and black again when it wakes, until the frame draws) */
    plat_screen(0);                              /* (the panel's own sleep: not the backlight, plat_fm1.c) */
}
static void sleep_wake(void)
{
    const uint32_t now = plat_ms();
    sl.asleep = 0;
    sl.waking = 1;
    sl.quiet_t = now;
    ui.act_t = ui.turn_t = now;                  /* (the time starts again) */
    memset(ui.sig, 0, sizeof ui.sig);            /* every band drawn again */
    lcd_fill(0, 0, 240, 240, K_BG);              /* (drawn before the panel wakes: no old picture flashes up) */
    plat_screen(1);
    if (sl.was_playing && !en_playing) {         /* (as PLAY starts it) */
        sp_tp.playing = 1;
        sp_tp.play_t = now;
        en_seed(now);
        en_play(1);
    }
    if (ann_on()) {
        ann_say("awake", 0, ANN_NOW);
        sp_said = 1;
    }
}
/* the gain (the fade out, the fade back in) and falling asleep: 1 while asleep */
static int sleep_tick(void)
{
    const uint32_t now = plat_ms();
    uint32_t want = 4096u, dt = now - sl.gain_t;
    if (!sl.asleep && sl.set) {
        const uint32_t gone = now - later(ui.act_t, ui.turn_t), span = SLEEP_MIN[sl.set] * 60000u;
        if (gone >= span) {
            sleep_fall();
        } else if (span - gone < SLEEP_FADE) {
            const uint32_t r = span - gone;
            want = r * r / SLEEP_FADE * 4096u / SLEEP_FADE;
        }
    }
    if (sl.asleep)
        want = 0;
    if (want <= ui_gain_q12) {                   /* down: at once (the fade is slow already) */
        ui_gain_q12 = want;
    } else {                                     /* up: the whole way in WAKE_FADE at most */
        const uint32_t up = (dt > WAKE_FADE ? WAKE_FADE : dt) * 4096u / WAKE_FADE;
        ui_gain_q12 = ui_gain_q12 + up < want ? ui_gain_q12 + up : want;
    }
    sl.gain_t = now;
    return sl.asleep;
}
/* the touches while asleep, and just woken: 1, input() is not to see them. Asleep: a new press, key or turn wakes it;
 * MIDI is dropped. Woken: the touch that woke it, and any till nothing has been touched for WAKE_QUIET, held back
 * (the panel's state taken as it is, so its release does nothing either) */
static int sleep_input(void)
{
    uint32_t btn, keys, now;
    int k, turned = 0;
    if (!sl.asleep && !sl.waking)
        return 0;
    now = plat_ms();
    btn = plat_buttons() | link_v_btn, keys = plat_keys() | link_v_keys;
    for (k = 0; k < NE; k++)
        turned |= plat_enc(k) != 0;              /* (taken: a turn that wakes it moves nothing) */
    if (sl.asleep) {
        uint32_t pkt;
        while (plat_midi_in(&pkt))
            ;
        if ((btn & ~ui.btn) || (keys & ~ui.keys) || turned)
            sleep_wake();
    } else {
        midi_in();
        if (btn || keys || turned)
            sl.quiet_t = ui.act_t = now;
        else if (now - sl.quiet_t >= WAKE_QUIET)
            sl.waking = 0;
    }
    ui.btn = btn, ui.keys = keys;
    return 1;
}

static void pal_sync(void)
{
    const uint16_t *want = KPAL[screen_light()];
    if (kpal != want) {
        kpal = want;
        memset(ui.sig, 0, sizeof ui.sig);        /* every band drawn again */
    }
}
void ui_frame(void)
{
    pal_sync();
    if (sleep_tick()) {                          /* (1.1) asleep: only waking, saving, the reader and the link */
        sleep_input();
        autosave();
        ann_tick(plat_ms());
        link_tick(plat_ms());
        ui.frame++;
        return;
    }
    if (ui.s2_hand && !en_s2oct_shift)           /* (the engine has the hand's octave: its shifts shown again) */
        ui.s2_hand = 0;
    prog_take();
    nudge_tick();
    jr_tick();
    dy_tick();
    if (!sleep_input())
        input();
    mac_take();
    autosave();
    undo_tick();
    if (grid_up()) {                             /* REC held: the effects, the whole screen */
        if (!(ui.frame % 3u))
            draw_grid();
        draw_main();                             /* (it says the grid to a screen reader) */
    } else if (pflash_up() || pflash_showing()) {   /* (1.3) PERFORM, an effect held: its colour and name; the
                                                  * knobs stay */
        if (!(ui.frame % 3u))
            draw_pflash();
        if (pflash_showing()) {
            echo_take(plat_ms());                /* (what draw_main takes each frame, kept up) */
            orbits_take();
        } else {
            draw_header();
            draw_main();
        }
        draw_knobs();
    } else {
        draw_header();
        draw_main();
        draw_knobs();
    }
    leds();
    speak();
    ann_tick(plat_ms());
    link_tick(plat_ms());
    ui.frame++;
}

void ui_input_only(void)
{
    if (!sleep_input())
        input();
}

/* (AISLING) the launch screen, the user's: a green triskele growing out from its three centres, then AISLING large under
 * it and "by S. CUMMINS" in orange (the flag's three colours, the name between), on black among a few stars, fading in;
 * the version small at the foot. Frame f of UI_SPLASH_N, drawn whole (two bands of 240 x 120) */
static void splash_band(int f, int32_t oy)
{
    static const uint8_t SX[14] = {18, 51, 77, 103, 139, 171, 205, 226, 33, 66, 121, 158, 190, 214},
                         SY[14] = {22, 61, 15, 190, 31, 205, 48, 120, 150, 218, 230, 92, 168, 9};
    int k;
    cv_begin(240, 120, K_BG);
    for (k = 0; k < 14; k++)
        cv_rect(SX[k], SY[k] - oy, 1, 1, mix(K_BG, K_DIM, 3 + (k & 3)));
    if (f >= 1)
        triskele(120.0f, 70.0f - (float)oy, 15.0f, 2.0f, 2.8f, (float)f / 12.0f, K_EIRE);
    if (f >= 6)
        text_c(120, 112 - oy, &FONT_L, "AISLING", mix(K_BG, K_TEXT, f >= 13 ? 16 : 2 * (f - 5)));
    if (f >= 12)
        text_c(120, 152 - oy, &FONT_S, "by " AISLING_BY, mix(K_BG, K_EIRE_O, f >= 19 ? 16 : 2 * (f - 11)));
    if (f >= 16)
        text_c(120, 174 - oy, &FONT_XS, AISLING_AT, mix(K_BG, K_DIM, f >= 23 ? 16 : 2 * (f - 15)));
    if (f >= 20)
        text_c(120, 224 - oy, &FONT_XS, EN_VERSION, K_DIM);
    cv_blit(0, (uint32_t)oy);
}

void ui_splash(int f)
{
    pal_sync();                                  /* (the first frame comes before the project is read: dark) */
    splash_band(f, 0);
    splash_band(f, 120);
}
