Aisling 1.6.1 for the BBL Mod Swapper

Original by stephencummins: https://github.com/stephencummins/fm1-aisling
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: AISLING-source.zip on the ports page.
