SID-1 1.0.1 for the BBL Mod Swapper

Original by putchdev: https://github.com/putchdev/sid-1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: SID1-source.zip on the ports page.
