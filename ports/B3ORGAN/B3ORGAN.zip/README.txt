B3 ORGAN 0.6.1 for the BBL Mod Swapper

Original by R-Jeb: https://github.com/R-Jeb/setBfree-fm1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: B3ORGAN-source.zip on the ports page.
