/* SPDX-License-Identifier: GPL-3.0-only */
/* A fake FM-1 on a computer: the app (firmware/src/dinghy.c) runs unchanged on it. platform.c includes
 * this file instead of the hardware when DINGHY_HOST is set. A script presses keys over time; out come
 * the screen (PPM, at the times SHOT asks) and the sound (WAV, as the FM-1 sends it over USB).
 *
 *   mkdir -p build/host
 *   cc -O2 -Wall -DDINGHY_HOST -Ifirmware/src -Ifirmware/gen -o build/host/dinghy firmware/src/dinghy.c
 *   build/host/dinghy build/host/dinghy        (-> build/host/dinghy.wav, build/host/dinghy-<ms>.ppm)
 *   build/host/dinghy OUT script.txt [FPS]    (your own script; with FPS: OUT-NNNNN.ppm, a frame every 1/FPS s:
 *                                             a film of your firmware, e.g. ffmpeg -r 30 -i OUT-%05d.ppm ...)
 *
 * Change SCRIPT below to try your own app. */
#include <stdint.h>

#ifndef APP_NAME
#define APP_NAME "DINGHY"
#endif
#ifndef APP_VER
#define APP_VER "0.0"
#endif
#define FS 44100u
#define HALF_FRAMES 256u

static volatile uint32_t fm1_ms;
static struct { uint32_t notes, buttons; } fm1_in;
/* teensy-fm1: the panel and the screen are the Teensy's */
static uint32_t din_press, din_rel, din_nedge, din_px;
static int32_t din_enc[8];
static uint8_t din_led[64], din_glow[64];
static uint32_t fm1_input_edges(uint32_t *released) { uint32_t b = din_press; din_press = 0; if (released) *released = din_rel; din_rel = 0; return b; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = din_nedge; din_nedge = 0; return e; }
static int32_t fm1_enc_take(uint32_t e) { int32_t v = din_enc[e & 7u]; din_enc[e & 7u] = 0; return v; }
static void fm1_led_key(uint32_t id, int on) { din_led[id & 63u] = (uint8_t)!!on; }
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            sh_put(j * 240u + i, sh_be16(c));
    din_px += w * h;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            sh_put((y + j) * 240u + x + i, px[j * w + i]);      /* (gfx.c's pixels are high byte first already) */
    din_px += w * h;
}

static uint32_t host_edges;

   /* (the script sets fm1_in.notes) */
static int32_t host_enc[8];                     /* script: "T enc ID DELTA" turns an encoder (ENC_* of platform.c) */



/* the screen: 240 x 240 RGB565, as the ST7789 gets it (gfx.c sends the bytes swapped) */
#define fb shl_fb



#ifndef CV_MAX
#define CV_MAX (240u * 64u)                   /* as the firmware (platform.c): what the canvas holds; more hid a cut band */
#endif
#include "gfx.c"

static uint8_t host_store[256 + 4];
static int settings_load(void *p, uint32_t n)
{
    if (host_store[0] != 1 || n > 256u || host_store[1] != n) return -1;   /* as the flash: only the length it was saved with */
    memcpy(p, host_store + 4, n);
    return 0;
}
static int settings_save(const void *p, uint32_t n)
{
    if (n > sizeof host_store - 4u) return -1;   /* teensy-fm1 */
    host_store[0] = 1; host_store[1] = (uint8_t)n;
    memcpy(host_store + 4, p, n);
    printf("%6u ms  settings saved (%u B)\n", fm1_ms, n);
    return 0;
}

static uint8_t host_data[1024 + 4];
static int data_load(void *p, uint32_t n)
{
    if (host_data[0] != 1 || n > 1024u || (host_data[1] | host_data[2] << 8) != n) return -1;
    memcpy(p, host_data + 4, n);
    return 0;
}
static int data_save(const void *p, uint32_t n)
{
    host_data[0] = 1; host_data[1] = (uint8_t)n; host_data[2] = (uint8_t)(n >> 8);
    memcpy(host_data + 4, p, n);
    printf("%6u ms  data saved (%u B)\n", fm1_ms, n);
    return 0;
}

/* SysEx: the script's "T sysex HEX" (the bytes between F0 and F7, e.g. 7D4233 01) waits here; what the app sends is printed */
static uint8_t host_sx[256];
static uint32_t host_sx_n, host_sx_ready;
static int sysex_get(const uint8_t **p, uint32_t *n) { if (!host_sx_ready) return 0; *p = host_sx; *n = host_sx_n; return 1; }
static void sysex_done(void) { host_sx_ready = 0; }
static int sysex_send(const uint8_t *p, uint32_t n)
{
    uint32_t i;
    printf("%6u ms  SysEx out", fm1_ms);
    for (i = 0; i < n; i++) printf(" %02X", p[i]);
    printf("\n");
    return 0;
}

static uint8_t mq[64][3];
static uint32_t mq_w, mq_r;
static volatile uint8_t midi_in_overflow;       /* the real one is in usb.c */
static int midi_get(uint8_t *st, uint8_t *d1, uint8_t *d2)
{
    if (mq_r == mq_w) return 0;
    *st = mq[mq_r % 64u][0]; *d1 = mq[mq_r % 64u][1]; *d2 = mq[mq_r % 64u][2];
    mq_r++;
    return 1;
}
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2) { printf("%6u ms  MIDI out %02X %u %u\n", fm1_ms, st, d1, d2); }

static void app_audio(int32_t *out, uint32_t n);
static void app_main(void);
static uint32_t battery_state(void) { return 4u; }
