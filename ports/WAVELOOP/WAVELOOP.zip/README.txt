WaveLoop 1.0.5 for the BBL Mod Swapper

Original by ELI7VH: https://github.com/ELI7VH/Felucca
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: WAVELOOP-source.zip on the ports page.
