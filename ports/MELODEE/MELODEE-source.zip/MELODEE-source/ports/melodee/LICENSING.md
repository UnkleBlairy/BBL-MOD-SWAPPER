# Melodee licensing

Melodee is a modified version of Felucca by Leo Kuroshita (@kurogedelic), Hügelton Instruments
(<https://github.com/hugelton/Felucca>), and keeps Felucca's licensing.

Melodee is free software, licensed under the GNU General Public License, version 3 only
(`GPL-3.0-only`, full text in `LICENSE`). That covers the code and its own assets. A few
bundled or ported parts keep their own licences; they are listed below, and their licence
texts are in `LICENSES/`.

Melodee code and modifications: Copyright (C) 2026 Kerem Kilic (Ellic Studio)\
Retained Felucca portions: Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments

Copyright notices follow the code's actual origin. Independently written Melodee files
credit Kerem Kilic; mixed files also identify the retained Felucca portions. Unchanged
upstream files and third-party ports retain their original notices. Sharing Felucca's
GPL licence does not make new Melodee code Hügelton Instruments' work.

## What is GPL-3.0-only

Every file in this tree that carries an `SPDX-License-Identifier: GPL-3.0-only` header:

- the firmware: `firmware/` (app, HAL, update loader)
- the build script and tools: `build.sh`, `tools/`
- the web pages (installer, editor) and their tests: `web/` (apart from the MPL installer ports and Fukiai font below)
- the host tests: `tests/`

Three source files are ports and keep the licence of their originals: `firmware/src/phys_dsp.c`
(DaisySP, MIT), `firmware/src/phys_symp.c` (Rings, MIT), and `firmware/src/cz_native.c`
(MAME uPD933, BSD-3-Clause). `firmware/src/fm6_core.c` and
`firmware/src/eng_fm6.c` restate MSFA (Apache-2.0) and Dexed (GPL-3.0-or-later) in C with native fp32 signal arithmetic (below).
The firmware built with them is GPL-3.0-only as a whole.

You may use, study, change and share Melodee under the GPL. If you distribute Melodee, or
firmware derived from it, you must also give your recipients its complete corresponding
source under the same licence. That includes devices that ship with modified Melodee inside.

## Retained Hügelton Instruments material

The following original material is by Hügelton Instruments (Leo Kuroshita).
Melodee's additions and modifications are credited separately in the source files:

| What | Licence | Where |
| --- | --- | --- |
| Original Felucca portions retained in the firmware, tools, web pages and tests | GPL-3.0-only | Source notices; `LICENSE` |
| The PHASE engine's waveforms: a C port of the oscillator of CrispyZebra (<https://github.com/hugelton/CrispyZebra>) | GPL-3.0 | `firmware/src/eng_phase.c` |
| The panel picture | GPL-3.0-only | `docs/panel.jpg` |
| The Fukiai icon font (<https://github.com/hugelton/Fukiai>): the web editor's icons (the firmware draws its own: `tools/gen_icons.py`, GPL-3.0-only; `tools/gen_aa_icons.py` still rasterises Fukiai for comparison) | MIT | `web/fukiai.ttf`, `LICENSES/MIT-Fukiai.txt`, `web/FUKIAI-LICENSE.txt` |

## Third-party material

| What | Licence | Where |
| --- | --- | --- |
| SLOOP master punch, stereo reverb/freeze and pedal-effect adaptations by isod89, from `isod89/sloop-fm1` at `4ec1ac829fd2bdf2c571ea215fb3d62477d01220`. Retained Felucca filters, input diffusers and insert portions keep Leo Kuroshita / Hügelton Instruments' notices; Melodee's integration retains its own credit. | GPL-3.0-only | `firmware/src/punch.c`, `fx_sloop_reverb.h`, `fx_sloop_insert.h`; source history and attribution in `docs/SLOOP_PUNCH_FX.md` |
| Saadet installer protections and presentation, from `keremimo/saadet` at `f358c01` (introduced in `036b97e`): worker timers, tab/wake locks, timestamped MIDI responses, progress accounting, simulated FM-1 and styles. Original notices identify Kerem Kilic and the retained Charles Vestal / Leo Kuroshita portions. Melodee's session controller and integration are new GPL-3.0-only code. | MPL-2.0 for the ported files | `web/install/keepalive.js`, `transfer.js`, `progress.js`, `fakefm1.js`, `installer.css`, `installer.js`, the MPL portions of `web/index_pkg.html`; `LICENSES/MPL-2.0.txt` |
| m-bootloader v1.2 by Julius Vitkauskas, source `22e2559906f9fc4e077f2d6aee20bf332300439e`: unmodified FM-1 release assets, offered separately and optionally by the web installer. | MIT | `web/m-bootloader/`, `LICENSES/MIT-m-bootloader.txt`; the full notice is published beside the bootloader |
| ChoralRoot FM-1 contributors (<https://github.com/Quixotic7/ChoralRootFM1>, v0.16, commit `9c7445cdd7b767c779741d28654fb59cca3acd97`): boot stub, interrupted-update write ordering, commit-marker/CRC compensation, and recovery tests, adapted for Melodee. The shared `CRSTUB` / `CRBM` format is retained. | GPL-3.0-only | `firmware/stub/`, `firmware/loader/ldr_core.c`, `tools/build.py`, `tools/fm1pkg_make.py`, `tests/boot_stub*`, `tests/loader_powercut_test.c` |
| Rubik font by The Rubik Project Authors (<https://github.com/googlefonts/rubik>): the UI text and the keycap labels, rasterised into the firmware at build time (`tools/gen_aa_font.py`, `tools/gen_aa_keycaps.py`; the generated tables are not offered as a font, and the font declares no Reserved Font Name) | SIL OFL 1.1 | `assets/fonts/Rubik[wght].ttf`, `LICENSES/OFL-Rubik.txt` |
| Inter Tight font by The Inter Project Authors: the panel diagram (`tools/gen_panel_diagram.py`, `docs/panel.jpg`) and the `inter-tight` preset of `tools/gen_aa_font.py` (the firmware's text was Inter Tight up to Melodee 0.13) | SIL OFL 1.1 | `assets/fonts/InterTight[wght].ttf`, `LICENSES/OFL-InterTight.txt` (also `assets/fonts/OFL.txt`) |
| DaisySP by Electrosmith, Corp and Emilie Gillet (<https://github.com/electro-smith/DaisySP>): the PHYS engine's modal and string models and the resonator, ported to fixed point | MIT | `firmware/src/phys_dsp.c`, `LICENSES/MIT-DaisySP.txt` |
| Rings by Emilie Gillet (<https://github.com/pichenettes/eurorack>): the PHYS engine's sympathetic strings, ported to fixed point | MIT | `firmware/src/phys_symp.c`, `LICENSES/MIT-Rings.txt` |
| MSFA (Music Synthesizer for Android, Copyright 2012 Google Inc.) and Dexed (Copyright 2013-2025 Pascal Gauthier, <https://github.com/asb2m10/dexed>; portamento rates by Jean Pierre Cimalando): the FM6 engine restates their synthesis in C with native fp32 signals and discrete DX7 envelopes/ROMs (MSFA's envelopes, pitch envelope, LFO, operator kernels and Dx7Note, Apache-2.0; Dexed's MARK I and OPL engines and its voice handling, GPL-3.0-or-later); their DX7 measurement tables and the tables Dexed computes at start (sine, 2^x, frequency, log-sine / exponent, OPL ROM, detune, LFO, portamento) are used as data. `tests/dexed_ref.cc` builds Dexed's own sources (from a checkout, not in this tree) to compare against. The FM6 factory patches are Felucca's own (F1..F8) and Melodee's own (F9..F24) | Apache-2.0, GPL-3.0-or-later | `firmware/src/fm6_core.c`, `firmware/src/eng_fm6.c`, `tools/gen_tables.py`, `tests/dexed_ref.cc`, `LICENSES/Apache-2.0-msfa.txt` |
| reSID by Dag Lem (<https://github.com/libsidplayfp/resid>): the SID engine restates in C, at the register level, its waveform generator (accumulator, noise register, ring modulation, hard sync), envelope generator (rate and exponential counters, the ADSR delay), its R-2R DAC model (reSID 1.0 `dac.cc`), the 6581 / 8580 filter's resonance laws and output sum and the C64 output stage; its measured 6581 and 8580 cutoff curves and its spline interpolation (reSID 0.16) make the cutoff tables at build time; its samples of a real 6581's and 8580's combined waveforms (`wave*.dat`, unchanged) are packed into the firmware as data. Used under GPL-3.0 | GPL-2.0-or-later | `firmware/src/eng_sid.c`, `firmware/src/drum_sid.c` (its 6581 DC offsets, reSID 0.16), `tools/gen_tables.py`, `assets/resid/` |
| MAME uPD933 device model by Devin Acker: native CZ phase functions, envelope rate law and logarithmic amplitude adapted to C with native fp32 playback | BSD-3-Clause | `firmware/src/cz_native.c`, `LICENSES/BSD-3-Clause-uPD933.txt` |
| Casio CZ-1 preset tones A-1..H-8 (Casio Computer Co., Ltd., 1986): the 64 factory sounds as native tone data, combined from the "64 original CZ-1 patches" SysEx (GeoCities CZ-101 page, archived 2009) and Oli Larkin's VirtualCZ conversions of the same presets (LCD names, line levels, velocity). Included as sound data for CZ-1 compatibility; the rights stay with Casio. See `assets/cz1-factory/README.md` | Casio's (no licence granted) | `assets/cz1-factory/cz1-factory.syx`, `tools/make_cz1_factory.py`, `tools/gen_cz1_factory.py` |
| Sequential Prophet-5/10 factory programs v1.03 (Sequential, 2025; <https://sequential.com/support/download/prophet-5-10-sounds/>): the 200 programs of `P5_Factory_Programs_USER_v1.03.syx`, unchanged native data, as PROPHET's factory presets and its default native user collection. Included as sound data for Prophet-5 compatibility; the rights stay with Sequential. See `assets/prophet5-factory/README.md` | Sequential's (no licence granted) | `assets/prophet5-factory/prophet5-v1.03.syx`, `tools/gen_prophet_factory.py` |
| klattsch by Tony Gies (<https://github.com/tgies/klattsch>): design reference for the VOICE engine; no code copied. Formant data from Klatt (1980) / Hillenbrand et al. (1995) | MIT (klattsch) | credit only |
| JieLi AC79 SDK by JieLi Technology: three external files go into every `.fwsc` package; the optional RAM recovery helper is in `assets/recovery/` | Apache-2.0 | `LICENSES/Apache-2.0.txt` |
| JieLi AC79 SDK's radio calibration (`wl_rf_common.a`, Copyright (c) 2024-2026 Zhuhai Jieli Technology Co., Ltd.), rewritten in C by Charles Vestal for felucca-bsp: the VCO bank scan and the RX filter, TX LO and RX DC trims run when no stored calibration exists; the file's header states the changes (Apache-2.0 section 4(b)) | Apache-2.0 | `firmware/hal/fm1_rf_cal.h`, `LICENSES/Apache-2.0.txt` |

On the device, HOME held > ABOUT opens the information screen; turning PRESETS scrolls on into
CREDITS, a short list of these authors, licences and source URLs.

## JieLi SDK files in the packages (Apache-2.0)

A `.fwsc` package made by `tools/build.py` (with `tools/fm1pkg_make.py`; this is the package the
web installer installs) holds three unmodified files from the JieLi AC79 SDK
(<https://gitee.com/Jieli-Tech/fw-AC79_AIoT_SDK>, `cpu/wl82/tools/`). They are read from your SDK
checkout at build time (see BUILDING.md); those three SDK files are not in this tree.

| File in the package | What it is |
| --- | --- |
| `uboot.boot` | the first-stage boot loader (SPL) |
| `cfg_tool.bin` | the chip configuration block |
| `eq_cfg_hw.bin` | the default hardware EQ table |

They are licensed under the Apache License, Version 2.0 (`LICENSES/Apache-2.0.txt`), not under
the GPL, and their copyright stays with JieLi Technology. The SDK has no NOTICE file. Apache-2.0
files may be distributed together with GPL-3.0 code; Melodee itself stays GPL-3.0-only.

Every distribution of a package carries the licence texts with it: the release folder
(`tools/build.py --release`) and the site (`web/make_site.py`, next to the package in
`firmware/` and linked from the installer page).

## Standalone ROM recovery tool

The optional `fm1-recover` executables include `assets/recovery/wl82loader.bin`,
an unmodified RAM recovery helper from JieLi's AC79 SDK under Apache-2.0. Its
source version and checksum are recorded in `assets/recovery/README.md`; it is
loaded into RAM, not installed in flash. Copyright remains with JieLi Technology.
This SDK file is included in the source tree and the recovery distributions;
the three SDK files in firmware packages are still read from an external checkout.

Recovery archives carry Melodee's GPL-3.0-only licence, the SDK's Apache-2.0 licence,
and the bundled Python/PyUSB/PyInstaller/libusb notices. libusb is dynamically
loaded under LGPL-2.1-or-later; its corresponding source archive is included,
and `--libusb PATH` allows using a replacement library. PyInstaller's bootloader
exception permits distributing the generated executable under Melodee's licence.

## No vendor firmware material

No M-VAVE material is part of Melodee. The firmware links no vendor code and contains no vendor
data, and the packages hold only Melodee and the three SDK files above. The installer's
"Return to official V15" holds only the official file's size and SHA-256: you select the
official firmware file you downloaded yourself, and it is checked and installed in your browser,
never uploaded or redistributed.

## Contributions

Contributions are welcome under GPL-3.0-only.

## Trademarks

"Felucca" and "Hügelton Instruments" are names of Hügelton Instruments.

"M-VAVE" and "FM-1" are trademarks of their respective owners. Melodee is independent
firmware that runs on FM-1 hardware. It is not affiliated with, endorsed by or supported
by those owners, nor by Hügelton Instruments.

## Radio

Bluetooth MIDI uses the pinned Optimist sources and retained notices described
in `docs/BLE_MIDI.md`. When no stored radio calibration exists, the firmware runs
JieLi's AC79 SDK calibration rewritten in C (`firmware/hal/fm1_rf_cal.h`,
Apache-2.0, credited above). The application does not link the SDK RF library.
The SDK-specific proprietary binary from FM1 Open is not included.
