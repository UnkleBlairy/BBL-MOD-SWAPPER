Smileyface 1.3.0-tutorialtime for the BBL Mod Swapper

Original by pbarilla: https://github.com/pbarilla/smileyface
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: SMILEY-source.zip on the ports page.
