#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Summarise a telemetry CSV (tools/fm1log.py): by genre and piece, the load, the xruns, and where the first core's time goes.
    python tools/fm1sum.py telemetry/fm1_....csv"""
import csv
import sys
from collections import defaultdict

GENRES = ["HYPNO", "LOFI", "HOUSE", "DUBSTEP", "DUB", "DNB", "BREAKS", "GARAGE", "ELECTRO", "TRAP", "DISCO", "FUNK", "REGGAE", "SYNTHWAVE", "AMAPIANO", "TRIPHOP", "INDUS", "PSY", "FOREST"]
FIELDS = ["p_clear", "p_bassacid", "p_pluck", "w_pad", "p_merge", "p_drums", "p_echo", "w_rev", "p_master"]
STAGES = ["clear", "bassacid", "pluck", "w_pad", "merge", "drums", "echo", "w_rev", "master"]


def main():
    rows = list(csv.DictReader(open(sys.argv[1])))
    if not rows:
        sys.exit("empty")
    g = defaultdict(list)
    prev = None
    for r in rows:
        r = {k: (int(v) if v.lstrip("-").isdigit() else v) for k, v in r.items()}
        r["dx"] = r["xruns"] - prev["xruns"] if prev else 0
        r["dl"] = r.get("late", 0) - prev.get("late", 0) if prev else 0
        prev = r
        g[(r.get("genre", 0), r.get("piece", 0))].append(r)
    print("xr = halves never rendered (a dropout), late = renders that ran past their half (nothing lost: the next one starts at once)")
    print("%-9s %2s %5s %4s %4s %3s %4s %6s %6s | us per 5.8 ms chunk: %s" % ("genre", "pc", "secs", "cpu", "max", "xr", "late", "peak", "gap", " ".join("%7s" % s for s in STAGES) + "  isr% chor bass"))
    for (ge, pc), s in sorted(g.items()):
        ch = sum(x.get("chunks", 0) for x in s) or 1
        st = ["%7.0f" % (sum(x.get(f, 0) for x in s) / ch) for f in FIELDS]
        print("%-9s %2d %5.0f %3.0f%% %3d%% %3d %4d %5.1fms %5.1fms | %s" % (
            GENRES[ge] if ge < len(GENRES) else ge, pc, len(s) * 0.25, sum(x["cpu"] for x in s) / len(s), max(x["cpu"] for x in s),
            sum(x["dx"] for x in s), sum(x["dl"] for x in s), max(x["max_us"] for x in s) / 1000, max(x["gap_us"] for x in s) / 1000, " ".join(st) + "  %4.1f%% %3d%% %3d%%" % (100.0 * sum(x.get("isr_in", 0) for x in s) / (len(s) * 250000.0), 100.0 * sum(1 for x in s if x.get("chorus", 0)) / len(s), 100.0 * sum(1 for x in s if x.get("bass", 0)) / len(s))))


def peaks(path):
    """the slowest chunks the unit saw (columns pk_*): which stage took the time, at which step, and what had been moved"""
    rows = list(csv.DictReader(open(path)))
    if not rows or "pk_total" not in rows[0]:
        return
    names = ["clear", "bass+acid", "pluck+DX+snips", "wait pad", "merge+sidechain", "drums", "echoes", "wait reverb", "master"]
    ranked = sorted((r for r in rows if int(r["pk_total"])), key=lambda r: -int(r["pk_total"]))[:8]
    print("\nthe slowest chunks (a chunk is at most 256 frames = 5.8 ms; the two of a render must fit 11.6 ms):")
    for r in ranked:
        st = [int(r["pk_" + n]) for n in ("clear", "bassacid", "pluck", "w_pad", "merge", "drums", "echo", "w_rev", "master")]
        info = int(r["pk_info"])
        top = max(range(9), key=lambda i: st[i] if i not in (3, 7) else -1)
        print("  %5.1f s  %s %2d  %5d us (%d frames) step %2d%s  biggest %s %d us  waits %d+%d  %s%s%s" % (
            float(r["t"]), GENRES[int(r["genre"])] if int(r["genre"]) < len(GENRES) else r["genre"], int(r["piece"]), int(r["pk_total"]), (info >> 4) & 255, info & 15,
            " (just after a step)" if info >> 12 & 1 else "", names[top], st[top], st[3], st[7], "drone+acid on core 2 " if info >> 13 & 1 else "",
            "chorus on core 1 " if info >> 14 & 1 else "", "shed %d" % (info >> 15 & 3)))
    hist = [sum(int(r["h_" + k]) for r in rows) for k in ("lt5", "5", "6", "7", "8", "9", "10", "11", "ge12")]
    tot = sum(hist) or 1
    print("renders by time (ms): " + "  ".join("%s %.1f%%" % (lab, 100.0 * h / tot) for lab, h in zip(["<5", "5", "6", "7", "8", "9", "10", "11", ">=12"], hist)))


def halves(path):
    """the slowest halves (columns pkr_*, 0.14.1 on): where a half's time went beyond its chunks' stages (the engine's work between chunks:
    drain, control, the pulse, the swung hits) and the timer interrupt nested in it, with the step and what the main loop was doing"""
    rows = list(csv.DictReader(open(path)))
    if not rows or "pkr_us" not in rows[0]:
        return
    ranked = sorted((r for r in rows if int(r["pkr_us"])), key=lambda r: -int(r["pkr_us"]))[:12]
    if not ranked:
        return
    where = ["between turns", "UI frame", "USB services"]
    print("\nthe slowest halves (budget 11.6 ms): total = its chunks' stages + the timer interrupt inside it + the rest (drain, control, pulse, swung hits):")
    for r in ranked:
        us, st, isr, wt = int(r["pkr_us"]), int(r["pkr_stages"]), int(r["pkr_isr"]), int(r["pkr_waits"])
        wi = int(r["pkr_where"])
        print("  %5.1f s  %s %2d  %5d us = stages %5d (waits %4d) + isr %4d (%2d ticks) + rest %5d  chunks %d  step %2d  half %d  main loop: %s" % (
            float(r["t"]), GENRES[int(r["genre"])] if int(r["genre"]) < len(GENRES) else r["genre"], int(r["piece"]), us, st, wt, isr, int(r["pkr_nested"]),
            us - st - isr, int(r["pkr_chunks"]), wi & 255, wi >> 12 & 1, where[wi >> 8 & 15] if (wi >> 8 & 15) < len(where) else wi >> 8 & 15))


def fixed(path):
    """each stage's fixed cost a chunk (columns sm_*, 0.14.3 on). A stage's time in a chunk is F + n v (F fixed, v a frame); the windows give the
    full chunks' sums (the totals less the short chunks') and the short chunks' sums with their frames: two equations a stage, solved for F and v.
    By genre and piece, where the log holds at least 200 short chunks of it. The short chunks sit at the hits (more voices starting), so their
    v runs a little high and F a little low: the ranking of the stages is the point, not the last microsecond."""
    rows = list(csv.DictReader(open(path)))
    if not rows or "sm_n" not in rows[0]:
        return
    g = defaultdict(list)
    for r in rows:
        g[(int(r["genre"]), int(r["piece"]))].append(r)
    names = ["clear", "bass+acid", "pluck+DX", "wait pad", "merge", "drums", "echoes", "wait rev", "master"]
    keys = ["clear", "bassacid", "pluck", "w_pad", "merge", "drums", "echo", "w_rev", "master"]
    shown = False
    for (ge, pc), s in sorted(g.items()):
        n_sm = sum(int(r["sm_n"]) for r in s)
        fr_sm = sum(int(r["sm_frames"]) for r in s)
        n_all = sum(int(r["chunks"]) for r in s)
        n_full = n_all - n_sm
        if n_sm < 200 or n_full < 200 or fr_sm == 256 * n_sm:
            continue
        if not shown:
            print("\nfixed cost a chunk by stage (us; F + n v solved from the full and the short chunks), and a 256-frame chunk's total:")
            shown = True
        tot_f = tot_full = 0.0
        out = []
        for k, nm in zip(keys, names):
            s_all = sum(int(r["p_" + k if k not in ("w_pad", "w_rev") else k]) for r in s)
            s_sm = sum(int(r["sm_" + k]) for r in s)
            s_full = s_all - s_sm
            v = (s_sm - n_sm * s_full / n_full) / (fr_sm - 256.0 * n_sm)
            f = s_full / n_full - 256.0 * v
            tot_f += f
            tot_full += s_full / n_full
            out.append("%s F %4.0f (of %4.0f)" % (nm, f, s_full / n_full))
        print("  %s %2d  (%d short chunks, mean %.0f frames; %d full):  %s  | fixed %.0f of %.0f us a full chunk" % (
            GENRES[ge] if ge < len(GENRES) else ge, pc, n_sm, fr_sm / n_sm, n_full, "  ".join(out), tot_f, tot_full))


def diag(path):
    """the diagnostic frame (columns d_*, ds_*, hc_*, r_*; 0.14.3 on): the pieces inside the stages, each as us per full chunk and its fixed cost a
    chunk (solved as in fixed()), the sizes of the chunks, and the work between chunks per chunk"""
    rows = list(csv.DictReader(open(path)))
    if not rows or "d_bass" not in rows[0] or "sm_n" not in rows[0]:
        return
    pieces = ["bass", "acid", "cm", "fm", "dj", "noise", "padmix", "side", "drums", "bassmix", "echoes", "fxm", "dyn", "clip"]
    g = defaultdict(list)
    for r in rows:
        g[(int(r["genre"]), int(r["piece"]))].append(r)
    shown = False
    for (ge, pc), s in sorted(g.items()):
        n_sm = sum(int(r["sm_n"]) for r in s)
        fr_sm = sum(int(r["sm_frames"]) for r in s)
        n_all = sum(int(r["chunks"]) for r in s)
        n_full = n_all - n_sm
        if n_all < 400:
            continue
        if not shown:
            print("\nthe pieces inside the stages (us per full chunk; F = the fixed cost a chunk where the log allows it), the chunk sizes, the work between chunks:")
            shown = True
        name = GENRES[ge] if ge < len(GENRES) else str(ge)
        solve = n_sm >= 200 and n_full >= 200 and fr_sm != 256 * n_sm
        out = []
        tot_f = 0.0
        for p in pieces:
            s_all = sum(int(r["d_" + p]) for r in s)
            s_sm = sum(int(r["ds_" + p]) for r in s)
            s_full = s_all - s_sm
            if solve:
                v = (s_sm - n_sm * s_full / n_full) / (fr_sm - 256.0 * n_sm)
                f = s_full / n_full - 256.0 * v
                tot_f += f
                out.append("%s %4.0f F %4.0f" % (p, s_full / n_full, f))
            else:
                out.append("%s %4.0f" % (p, s_all / n_all))
        print("  %s %2d  (%d chunks, %d short):  %s%s" % (name, pc, n_all, n_sm, "  ".join(out), ("  | fixed in these pieces %.0f us" % tot_f) if solve else ""))
        hc = [sum(int(r["hc_" + k]) for r in s) for k in ("lt64", "lt128", "lt256", "256")]
        rr = [sum(int(r["r_" + k]) for r in s) / n_all for k in ("drain", "control", "pulse", "hits")]
        print("           chunks by size: <64 %d  <128 %d  <256 %d  256 %d   | between chunks, us a chunk: drain %.0f control %.0f pulse %.0f hits %.0f" % (
            hc[0], hc[1], hc[2], hc[3], rr[0], rr[1], rr[2], rr[3]))


peaks(sys.argv[1])
halves(sys.argv[1])
fixed(sys.argv[1])
diag(sys.argv[1])
main()
