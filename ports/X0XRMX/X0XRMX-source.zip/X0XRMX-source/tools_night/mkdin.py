"""Dinghy apps (tests/host.c as a fake FM-1): mkdin.py id 'Name' ver STEM app.c HOSTDEF [root] [extra defines...]
The host's script and main are dropped; the app's main loop runs as a coroutine (ports/common/coro.h), a pass a ms, held
back as long as the FM-1's screen would take for what a pass drew."""
import sys,re,os,shutil,subprocess
sys.path.insert(0,'tools_night')
idn,name,ver,stem,app,hd,root=(sys.argv[1:]+[''])[:7]
defs=sys.argv[8:]
src='ports/_dl/'+idn+('/'+root if root and root!='.' else ''); top='ports/_dl/'+idn; dst='ports/'+idn
ig=shutil.ignore_patterns('*.wav','*.png','*.mp4','*.html','*.js','*.mjs','*.fwsc','__pycache__','*.woff*','*.key','*.bin','*.gif','*.jpg','*.a','*.pdf')
for d in os.listdir(src):
    if os.path.isdir(f'{src}/{d}') and d in ('firmware','engine','core','dsp','src','fm1','modules','brothers-link'): shutil.copytree(f'{src}/{d}',f'{dst}/{d}',dirs_exist_ok=True,ignore=ig)
if os.path.isdir(f'{src}/build/gen'): shutil.copytree(f'{src}/build/gen',f'{dst}/build/gen',dirs_exist_ok=True,ignore=ig)
for f in os.listdir(top):
    if os.path.isfile(top+'/'+f) and re.match(r'(LICEN|COPYING|NOTICE|README\.md|THIRD|CREDIT)',f): shutil.copy(top+'/'+f,dst)
if os.path.isdir(top+'/LICENSES'): shutil.copytree(top+'/LICENSES',dst+'/LICENSES',dirs_exist_ok=True)
os.makedirs(dst+'/tests',exist_ok=True); os.makedirs(dst+'/web/emu',exist_ok=True)
for f in os.listdir(src+'/tests'):
    if f.endswith('.h') or f in ('compat.c',): shutil.copy(f'{src}/tests/{f}',dst+'/tests')
open(dst+'/.gitignore','w').write('build/\n__pycache__/\n*.o\n')
g=lambda *a:subprocess.run(['git','-C',top,*a],capture_output=True,text=True).stdout.strip()
url=g('remote','get-url','origin'); open(dst+'/SOURCE_COMMIT.txt','w').write(f'{url} {g("log","-1","--format=%H %ci")} ({ver})\n')
h=open(src+'/'+os.environ.get('HOST','tests/host.c')).read()
# 1. the part before the script
cut=0
for pat in (r'^static void app_main\(void\);',r'^static void app_audio\(int32_t \*out, uint32_t n\);'):
    m=re.search(pat,h,re.M)
    if m: cut=max(cut,m.end())
assert cut
t=h[:cut]
depth=0
for l in t.split('\n'):
    if re.match(r'\s*#\s*if',l): depth+=1
    elif re.match(r'\s*#\s*endif',l): depth-=1
t+='\n'+'#endif\n'*depth
def take(nm,x):
    m=re.search(r'^(?:static|volatile|const)[^\n;={(]*\b'+nm+r'(\[[^\]]*\])*\s*(=[^;]*)?;',x,re.M)
    if m: return m[0]+'\n'
    m=re.search(r'^static[^\n;{]*\b'+nm+r'\([^;{]*\)\s*(?:/\*(?:[^*]|\*(?!/))*\*/\s*)?\{',x,re.M)
    if not m: print('TAIL: no',nm); return ''
    i=m.end()-1; d=0
    while True:
        if x[i]=='{': d+=1
        elif x[i]=='}':
            d-=1
            if d==0: break
        i+=1
    return x[m.start():i+1]+'\n'
for nm in os.environ.get('TAIL','').split(): t+=take(nm,h[cut:])
t=re.sub(r'^#\s*include <(unistd|sys/\w+|linux/\w+|emscripten|time|stdio|stdlib|string)\.h>[^\n]*\n','',t,flags=re.M)
# 2. the panel and the screen: ours
def kill(fn,t):
    m=re.search(r'^(static|void|int)[^\n;{]*\b'+fn+r'\([^;{]*\)\s*(?:/\*(?:[^*]|\*(?!/))*\*/\s*)?\{',t,re.M)
    if not m: return t,False
    i=m.end()-1; d=0
    while True:
        if t[i]=='{': d+=1
        elif t[i]=='}':
            d-=1
            if d==0: break
        i+=1
    return t[:m.start()]+t[i+1:],True
got={}
for fn in ('fm1_input_edges','fm1_input_note_edges','fm1_enc_take','fm1_led_key','fm1_led_key_glow','fm1_led_key_dim','lcd_fill','lcd_blit','lcd_sync','host_leds','platform_poll'):
    got[fn]=False
    while True:
        t,k=kill(fn,t)
        if not k: break
        got[fn]=True
PANEL='''
/* teensy-fm1: the panel and the screen are the Teensy's */
static uint32_t din_press, din_rel, din_nedge, din_px;
static int32_t din_enc[8];
static uint8_t din_led[64], din_glow[64];
static uint32_t fm1_input_edges(uint32_t *released) { uint32_t b = din_press; din_press = 0; if (released) *released = din_rel; din_rel = 0; return b; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = din_nedge; din_nedge = 0; return e; }
static int32_t fm1_enc_take(uint32_t e) { int32_t v = din_enc[e & 7u]; din_enc[e & 7u] = 0; return v; }
static void fm1_led_key(uint32_t id, int on) { din_led[id & 63u] = (uint8_t)!!on; }
'''+('static void fm1_led_key_glow(uint32_t id, int on) { din_glow[id & 63u] = (uint8_t)!!on; }\n' if got['fm1_led_key_glow'] else '')+('static void fm1_led_key_dim(uint32_t id, int on) { din_glow[id & 63u] = (uint8_t)!!on; }\n' if got['fm1_led_key_dim'] else '')+('static void host_leds(const uint8_t *w) { uint32_t i; for (i = 0; i < 41u; i++) { din_led[i] = w[i] > 1u; din_glow[i] = w[i] == 1u; } }\n' if got['host_leds'] else '')+'''static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            sh_put(j * 240u + i, sh_be16(c));
    din_px += w * h;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            sh_put((y + j) * 240u + x + i, px[j * w + i]);      /* (gfx.c's pixels are high byte first already) */
    din_px += w * h;
}
'''
m=re.search(r'^[^\n]*\bfm1_in( = [^;]*)?;',t,re.M); e=m.end()
# after the #else/#endif block the declaration is in
tail=t[e:]
dd=0
for l in t[:e].split('\n'):
    if re.match(r'\s*#\s*if',l): dd+=1
    elif re.match(r'\s*#\s*endif',l): dd-=1
base=0
while dd>0:
    k=re.search(r'^\s*#\s*endif[^\n]*\n',t[e:],re.M); e+=k.end(); dd-=1
t=t[:e]+PANEL+t[e:]
t=t.replace('#include "libc.c"','#define memset din_memset\n#define memcpy din_memcpy\n#define memcmp din_memcmp\n#define memmove din_memmove\n#pragma GCC push_options\n#pragma GCC optimize("no-tree-loop-distribute-patterns")\n#include "libc.c"\n#pragma GCC pop_options\n#undef memset\n#undef memcpy\n#undef memcmp\n#undef memmove')
t=re.sub(r'^static uint16_t fb\[[^;\n]*;','#define fb shl_fb',t,flags=re.M)
t=re.sub(r'(static int settings_save\(const void \*p, uint32_t n\)\s*\{\n)(\s*)(host_store\[0\] = 1;)',r'\1\2if (n > sizeof host_store - 4u) return -1;   /* teensy-fm1 */\n\2\3',t)
exec(os.environ.get('FIX',''))
os.makedirs(os.path.dirname(dst+'/'+os.environ.get('HOST','tests/host.c')),exist_ok=True); open(dst+'/'+os.environ.get('HOST','tests/host.c'),'w').write(t)
open(dst+'/web/emu/felucca_teensy.c','w').write(f'''/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: {name} {ver} ({url}) on the Teensy 4.1: the app on tests/host.c's fake FM-1, inside ports/common's shell */
#ifdef __arm__                          /* (the FM-1's clang: uint32_t is unsigned int; newlib's is unsigned long) */
#undef __UINT32_TYPE__
#undef __INT32_TYPE__
#define __UINT32_TYPE__ unsigned int
#define __INT32_TYPE__ int
#endif
#include "../../../common/shell_pre.h"
#define CO_STACK 16384u
#include "../../../common/coro.h"
#include <stdlib.h>
#define getenv(n) ((char *)0)
#include "../../../common/miniprintf.h"
static int din_noprint(const char *f, ...) {{ (void)f; return 0; }}
static int din_nofile(const void *f, ...) {{ (void)f; return 0; }}
static void *din_nofile0(const void *f, ...) {{ (void)f; return 0; }}
typedef struct {{ int none; }} din_file_t;
#define printf din_noprint
#define fprintf din_nofile
#define fputs(s, f) ((void)(s))
#define fputc(c, f) ((void)(c))
#define SEEK_SET 0
#define SEEK_END 2
#define ftell(f) 0L
#define puts(s) ((void)(s))
#define putchar(c) ((void)(c))
#define sscanf(...) 0
#define FILE din_file_t
#define fopen(...) ((FILE *)din_nofile0(__VA_ARGS__))
#define fread(...) ((unsigned)din_nofile(__VA_ARGS__))
#define fwrite(...) ((unsigned)din_nofile(__VA_ARGS__))
#define fseek(...) din_nofile(__VA_ARGS__)
#define fclose(f) ((void)(f))
#define fflush(f) ((void)(f))
#define stdout ((FILE *)0)
#define stderr ((FILE *)0)
#define perror(s) ((void)(s))
struct din_ts {{ long tv_sec, tv_nsec; }};
#define timespec din_ts
#define CLOCK_MONOTONIC 1
#define clock_gettime(c, t) ((t)->tv_sec = 0, (t)->tv_nsec = 0, 0)
#ifdef __arm__
#define exit(n) do {{ for (;;) ; }} while (0)
#define abort() do {{ for (;;) ; }} while (0)
#endif
#define {hd} 1
static void platform_poll(void);
#include "../../{app}"
#undef __attribute__
#undef memset
#undef memcpy
static void platform_poll(void) {{ co_yield(); }}
{os.environ.get('POST','')}
static int32_t din_master = 4096;
static int32_t din_blk[2u * HALF_FRAMES];
static float din_l[1024], din_r[1024];
static float *din_lp(void) {{ return din_l; }}
static float *din_rp(void) {{ return din_r; }}
static void din_render(uint32_t n)
{{
    static uint32_t at = HALF_FRAMES, ms, busy;
    uint32_t i, j;
    for (i = 0; i < n; i++) {{
        if (at >= HALF_FRAMES) {{
            memset(din_blk, 0, sizeof din_blk);
            app_audio(din_blk, HALF_FRAMES);
            for (j = 0; j < 2u * HALF_FRAMES; j++) {{
                int32_t v = (int32_t)(((int64_t)din_blk[j] * din_master) >> 12);
                din_blk[j] = v > 32767 ? 32767 : v < -32767 ? -32767 : v;
            }}
            at = 0;
        }}
        din_l[i] = (float)din_blk[2u * at] * (1.0f / 32768.0f);
        din_r[i] = (float)din_blk[2u * at + 1u] * (1.0f / 32768.0f);
        at++;
        if ((ms += 1000u) >= 44100u) {{
            ms -= 44100u;
            fm1_ms++;
            if (busy) busy--;
            else {{ din_px = 0; co_resume(); busy = din_px / 750u; }}   /* (the FM-1's screen: ~1.33 us a pixel) */
        }}
    }}
}}
#define SH_FLOAT
#define SH_OUT_L din_lp
#define SH_OUT_R din_rp
#define SH_RENDERF(n) din_render(n)
#define SH_ADC(m) (din_master = (int32_t)((m * m) >> 8))
static void SH_BOOT(void) {{ co_start(app_main); co_resume(); }}
static void SH_FRAME(uint32_t ms) {{ (void)ms; }}
#define SH_ENC(e, n) (din_enc[e] += (n))
#define SH_BTN(i, d) do {{ if (d) {{ fm1_in.buttons |= 1u << (i); din_press |= 1u << (i); }} else {{ fm1_in.buttons &= ~(1u << (i)); din_rel |= 1u << (i); }} }} while (0)
#define SH_KEY(k, d) do {{ if (d) {{ fm1_in.notes |= 1u << (k); din_nedge |= 1u << (k); }} else fm1_in.notes &= ~(1u << (k)); }} while (0)
#define SH_KEY_LED(k) (din_led[14u + (k)] ? 2 : din_glow[14u + (k)] ? 1 : 0)
#define SH_BTN_LED(i) (din_led[i] ? 2 : din_glow[i] ? 1 : 0)
#include "../../../common/shell_post.h"
''')
open(dst+'/PORT.txt','w').write(f'name {name}\nversion {ver}\nstem {stem}\nincludes firmware/src firmware/gen firmware/hal build/gen {os.environ.get('INC','')}\nextra {os.environ.get('EXTRA','')} \ndefines {" ".join(defs)}\nitcm_banks 8\nnor 0\n')
subprocess.run(['tools_night/nosect.sh',idn])
print(idn,got)
