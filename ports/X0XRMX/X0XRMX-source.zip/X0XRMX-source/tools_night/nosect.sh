#!/bin/bash
# the FM-1's own memory sections, unknown to the Teensy's linker script: dropped
cd "$(dirname "$0")/.."
for i in "$@"; do grep -rlE 'section\("\.' ports/$i --include=*.c --include=*.h --include=*.cc | xargs -r sed -i -E 's/section\("\.(pool|noinit|ram_bss|dly_mem|dly|fast_text|c1_text|ramtab|bss|ram_text|app_ram|c1_bss|c1_data|hot)[A-Za-z0-9_.]*"\)/unused/g'; done
