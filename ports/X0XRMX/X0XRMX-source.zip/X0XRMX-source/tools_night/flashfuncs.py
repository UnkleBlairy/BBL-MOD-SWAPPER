#!/usr/bin/env python3
"""flashfuncs.py id [minsize] [file regex] : functions from the screen / menu / storage source files stay in flash"""
import sys,subprocess,re,os
i=sys.argv[1]; mn=int(sys.argv[2]) if len(sys.argv)>2 else 200
rx=re.compile(sys.argv[3] if len(sys.argv)>3 else r'/(ui[a-z0-9_]*|gfx|icons?|panel|storage|project|bank[a-z_]*|editor[a-z_]*|usb[a-z_]*|main|menu[a-z_]*|upreset|splash|kid[a-z_]*|font[a-z0-9_]*|hostsim|settings[a-z_]*|slice_store|song_dice|[a-z0-9_]*_ui|screen[a-z_]*|fmini_app|ghoul[a-z_]*|announce|announce_[a-z]*|setwire|viz|scene[a-z_]*|[a-z]*_host|logo[a-z_]*|art[a-z_]*|ota|backup[a-z_]*|felucca_teensy|felucca_web)\.[ch]$')
no=re.compile(os.environ.get('HOT','') or r'^$')
P='ports/'+i; g=lambda k:next((l[len(k)+1:].strip() for l in open(P+'/PORT.txt') if l.startswith(k+' ')),'')
cc=['arm-none-eabi-gcc','-g','-mcpu=cortex-m7','-mthumb','-mfloat-abi=hard','-mfpu=fpv5-d16','-O2','-w','-std=gnu99','-ffp-contract=off','-ffunction-sections','-fdata-sections']+['-I%s/%s'%(P,x) for x in g('includes').split()]+['-D'+x for x in g('defines').split()]+['-DFELUCCA_VERSION="x"']
out=[];hot=0
for n,c in enumerate(['web/emu/felucca_teensy.c']+g('extra').split()):
    o=f'target/ff{n}.o'; subprocess.check_call((cc if c[-2:]=='.c' else [x for x in cc if x!='-std=gnu99' and x!='-O2']+['-O2','-std=gnu++11','-fno-exceptions','-fno-rtti','-fno-threadsafe-statics','-D__UINT32_TYPE__=unsigned int','-D__INT32_TYPE__=int'])+['-c',f'{P}/{c}','-o',o])
    for l in subprocess.check_output(['arm-none-eabi-nm','-l','-S','--size-sort','-r','-t','d',o],text=True).splitlines():
        m=re.match(r'\d+ (\d+) ([tT]) (\S+)\t?(.*)',l)
        if not m: continue
        sz,nm,fi=int(m[1]),m[3],re.sub(r':\d+$','',m[4])
        if sz>=mn and rx.search(fi) and not re.match('teensy_spans|teensy_put|web_render|web_ms|run_ms|fm1_alnk',nm) and not no.match(nm): out.append((nm,sz))
        else: hot+=sz
open(P+'/teensy_flash_funcs.txt','w').write('# the screen, menus and storage: run from flash (the code is too big for ITCM)\n'+'\n'.join(a for a,b in out)+'\n')
print(i,len(out),'functions,',sum(b for a,b in out)//1024,'KB in flash;',hot//1024,'KB hot')
