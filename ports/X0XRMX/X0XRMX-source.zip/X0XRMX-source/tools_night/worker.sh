#!/bin/bash
# worker.sh W [pid to wait for]: pops ids from target/queue
cd "$(dirname "$0")/.."; export W=$1
[ -n "$2" ] && while kill -0 $2 2>/dev/null; do sleep 5; done
while true; do
 id=$(flock target/queue.lock bash -c 'head -1 target/queue; sed -i 1d target/queue')
 [ -z "$id" ] && { sleep 10; [ -f target/stopq ] && exit; continue; }
 timeout 1800 tools_night/autorom.sh $id > target/work-$W-$id.log 2>&1
done
