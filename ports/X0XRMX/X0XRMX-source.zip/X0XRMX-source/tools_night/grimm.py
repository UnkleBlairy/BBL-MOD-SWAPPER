import sys; sys.path.insert(0,'tools_night')
from mkshell import *
RAWK=RAW+KEYS+'#define SH_KEY_LED(k) (web_lit_keys() >> (k) & 1u ? 2 : 0)\n#define SH_BTN_LED(i) (web_lit_buttons() >> (i) & 1u ? 2 : 0)\n'
mk('grimm','GR!MM','2.0','GRIMM','firmware/src/grimm.c','firmware/src firmware/gen','','GRIMM_WEB=1 APP_VER="2.0"','fb',RAWK+'''static void sh_gr(uint32_t n)
{
    web_want_frames(n);
    while (!web_ready()) co_resume();
    web_take();
}
''',be=1,render='sh_gr',master='o_web_master(m)',boot='co_start(web_run);',pre='#define import_module(a) used\n#define import_name(a) used\n#include "../../../common/coro.h"\nstatic void web_yield_(void) { co_yield(); }\n#define web_yield web_yield_\n',dirs='firmware LICENSES')
p='ports/grimm/firmware/src/fm1_web.c'; s=open(p).read()
s=s.replace('extern void web_yield(void)','/* teensy-fm1: ours (a coroutine) */ extern void web_yield_x(void)').replace('extern uint32_t web_ticks(void)','extern uint32_t web_ticks_x(void)').replace('return web_ticks();','return 0;')
s=s.replace('#define RING 4096u','#define RING 1536u')
s=s.replace('static uint8_t web_async[16384] __attribute__((aligned(8)));','static uint8_t web_async[8];')
s=s.replace('static uint8_t fake_flash[SAMPLE_AREA_LEN];','''#ifdef TEENSY_NOR_ADDR                          /* teensy-fm1: real flash, in this ROM's slot */
extern int32_t teensy_nor_erase(uint32_t off);
extern int32_t teensy_nor_prog(uint32_t off, const uint8_t *src, uint32_t n);
#define fake_flash ((uint8_t *)TEENSY_NOR_ADDR)
#else
static uint8_t fake_flash[SAMPLE_AREA_LEN];
#endif''')
s=s.replace('    for (i = 0; i < 4096u; i++) fake_flash[off + i] = 0xFF;','''#ifdef TEENSY_NOR_ADDR
    (void)i; return teensy_nor_erase(off) ? -8 : 0;
#else
    for (i = 0; i < 4096u; i++) fake_flash[off + i] = 0xFF;
#endif''').replace('    for (i = 0; i < n; i++) fake_flash[off + i] &= s[i];','''#ifdef TEENSY_NOR_ADDR
    (void)i; return teensy_nor_prog(off, s, n) ? -8 : 0;
#else
    for (i = 0; i < n; i++) fake_flash[off + i] &= s[i];
#endif''').replace('    memset(fake_flash, 0xFF, sizeof fake_flash);','#ifndef TEENSY_NOR_ADDR\n    memset(fake_flash, 0xFF, sizeof fake_flash);\n#endif\n   ')
open(p,'w').write(s)
