#!/bin/bash
# rom.sh id... : build all three slots of a port, roms/<STEM>.R1-3 (no copying anywhere else)
exec 9>target/rom-w${W:-0}.lock; flock 9; . ~/.cargo/env; cd "$(dirname "$0")/.."; mkdir -p roms
OBJCOPY=$(find "$(rustc --print sysroot)" -name llvm-objcopy -type f|head -1)
for fw in "$@"; do g(){ sed -n "s/^$1 //p" ports/$fw/PORT.txt; }
rm -f roms/$(g stem).R?
nor=$(( $(g nor | sed 's/^0$/0x0/') ))
for s in 3 1; do
 d=target/rom-w${W:-0}; if ! TFM1_FW=$fw TFM1_SLOT=$s CARGO_TARGET_DIR=$d cargo build --release >target/$fw.log 2>&1; then echo "FAIL $fw slot $s"; grep -E "error: |error\[|overflowed by|undefined symbol|will not fit" target/$fw.log|cut -c1-170|sort -u|head -${ERRS:-14}; break; fi
 "$OBJCOPY" -O ihex $d/thumbv7em-none-eabihf/release/teensy-fm1 target/$fw-s$s.hex
 python3 tools_night/pack.py target/$fw-s$s.hex roms/$(g stem).R$s $s $(g stem) "$(g name)" "$(g version)" $nor || break
 [ $s = 3 ] && { arm-none-eabi-size -A $d/thumbv7em-none-eabihf/release/teensy-fm1 | awk '$2>0&&/text|bss|data|uninit|xip/'; }
done; done
