/* PC test of a port: boots it, plays keys, turns knobs, writes screenshots, reports the sound level and the time it took */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
void web_nor_erase(void);void web_boot(void);void web_render(uint32_t);float*web_out_l(void);float*web_out_r(void);
const uint16_t*teensy_fb(void);uint32_t teensy_spans(uint8_t*,uint32_t);void teensy_redraw(void);void teensy_raw_input(uint32_t,uint32_t);
void teensy_raw_enc(uint32_t,int32_t);void teensy_raw_adc(uint32_t,uint32_t);uint32_t teensy_leds(uint8_t*);uint32_t teensy_ui_frames(void);
static uint8_t sp[8192];static float pk;static double sq;static long ns,nan_;
static void run(int ms){int n=ms*44100/1000;while(n>0){web_render(128);float*l=web_out_l(),*r=web_out_r();for(int i=0;i<128;i++){if(!(fabsf(l[i])<100)||!(fabsf(r[i])<100))nan_++;else{if(fabsf(l[i])>pk)pk=fabsf(l[i]);if(fabsf(r[i])>pk)pk=fabsf(r[i]);sq+=l[i]*l[i];ns++;}}n-=128;teensy_spans(sp,sizeof sp);uint8_t d[64];teensy_leds(d);}}
static void shot(const char*p,const char*n){char f[300];snprintf(f,300,"%s-%s.ppm",p,n);FILE*o=fopen(f,"wb");fprintf(o,"P6 240 240 255\n");const uint16_t*b=teensy_fb();int cols=0;for(int i=0;i<57600;i++){uint16_t v=(b[i]>>8)|(b[i]<<8);uint8_t c[3]={(v>>11)<<3,((v>>5)&63)<<2,(v&31)<<3};if(v)cols++;fwrite(c,1,3,o);}fclose(o);printf(" %s:px=%d",n,cols);}
static void rep(const char*w){printf(" %s:peak=%.3f rms=%.4f nan=%ld\n",w,pk,ns?sqrt(sq/ns):0,nan_);fflush(stdout);pk=0;sq=0;ns=0;nan_=0;}
int main(int c,char**v){web_nor_erase();web_boot();teensy_raw_adc(800,620);teensy_redraw();clock_t t=clock();
run(2500);shot(v[1],"1boot");rep("idle");
for(int k=0;k<5;k++){teensy_raw_input((1u<<(5+k*3))|(1u<<(k*2+4)),0);run(250);}teensy_raw_input(0,0);run(60);shot(v[1],"2keys");rep("keys");
teensy_raw_input(0,1u<<12);run(60);teensy_raw_input(0,0);run(3000);shot(v[1],"3play");rep("play?");
teensy_raw_input(0,1u<<0);run(60);teensy_raw_input(0,0);run(500);shot(v[1],"4btn");
for(int b=0;b<14;b++){teensy_raw_input(0,1u<<b);run(60);teensy_raw_input(0,0);run(150);for(int e=0;e<7;e++){teensy_raw_enc(e,1);run(30);teensy_raw_enc(e,-2);run(30);}}shot(v[1],"5mash");rep("mash");
unsigned s=7;for(int i=0;i<250;i++){s=s*1103515245+12345;unsigned r=s>>8;teensy_raw_input(r%4==0?1u<<(r%27):0,r%3==0?1u<<((r>>6)%14):0);teensy_raw_enc((r>>4)%7,(int)(r%5)-2);run(40);}teensy_raw_input(0,0);run(500);shot(v[1],"6fuzz");rep("fuzz");
printf(" frames=%u cpu=%.2fs\n",teensy_ui_frames(),(double)(clock()-t)/CLOCKS_PER_SEC);return 0;}
