#!/bin/bash
# bulkfel.sh id... : Felucca-family web builds
cd "$(dirname "$0")/.."
for i in "$@"; do
 read V N < <(python3 -c "
import json;f=next((f for f in json.load(open('ports/_dl/cat.json'))['firmwares'] if f['id']=='${i/bgirlx/bgirlfm1}'),{'version':'1','name':'$i'});print(f['version'],f['name'])")
 st=$(echo $i | tr a-z A-Z | tr -cd A-Z0-9 | cut -c1-8)
 echo "=== $i $N $V"
 W=web/emu/felucca_web.c; [ -n "$WEBF" ] && W=$WEBF; [ -f ports/_dl/$i/$W ] || W=$(cd ports/_dl/$i; find . -path "*web/emu/*_web.c" | head -1 | cut -c3-)
 python3 tools_night/mkfel.py $i "$N" "$V" $st $W "build/gen firmware/src firmware/hal" 2>&1 | tail -1 | cut -c1-200
 D=$(grep -v "^#" ports/_dl/$i/web/emu/build.sh 2>/dev/null | grep -oE "\-D[A-Z0-9_]+(=[0-9]+)?( |$)" | sed 's/-D//' | grep -vE 'CAST|SMK37' | sort -u | tr -d '\n')
 sed -i "s/^defines.*/defines $D/" ports/$i/PORT.txt; tools_night/nosect.sh $i
 timeout 100 tools_night/pctest.sh $i 2>&1 | cut -c1-150 | grep -E "err|2keys|3play|fuzz|undef" | head -6
done
