import sys; sys.path.insert(0,'tools_night')
from mkshell import *
B='''static float sh_l[1024];
static float *sh_lp(void) { return sh_l; }
static void sh_gr(uint32_t n)
{
    uint32_t i, k, d = 0;
    while (d < n) {
        k = n - d > 128u ? 128u : n - d;
        { float *s = fw_render((int)k); for (i = 0; i < k; i++) sh_l[d + i] = s ? s[i] : 0.0f; }
        d += k;
    }
}
static int sh_role(uint32_t hw) { static const uint8_t R[7] = {0, 1, 3, 4, 5, 6, 2}; return R[hw]; }
#define SH_ENC(e, n) fw_encoder(sh_role(e), (n))
#define SH_BTN(i, d) fw_button((int)((i) < 2u ? (i) + 12u : (i) - 2u), (d))
static uint32_t sh_keys_m;
#define SH_KEY(k, d) (sh_keys_m = (sh_keys_m & ~(1u << (k))) | (uint32_t)(d) << (k), fw_keys(sh_keys_m))
#define SH_KEY_LED(k) (fw_key_brightness((int)(k)) >= 192 ? 2 : fw_key_brightness((int)(k)) >= 80 ? 1 : 0)
#define SH_BTN_LED(i) (fw_buttons() >> ((i) < 2u ? (i) + 12u : (i) - 2u) & 1u ? 2 : 0)
'''
mk('guitchordi','Guitchordi',sys.argv[1],'GUITCHOR','firmware/app.c','firmware dsp','dsp/engine.c','','fw_frame()',B,be=1,render='sh_gr',out='sh_lp sh_lp',boot='fw_boot();',master='fw_master((int)(m * 100u / 255u))',dirs='firmware dsp')
