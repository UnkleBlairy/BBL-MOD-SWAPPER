"""Ports whose own browser build runs unchanged inside ports/common's shell."""
import os,re,shutil,subprocess,sys
IG=shutil.ignore_patterns('*.wav','*.png','*.mp4','*.html','*.js','*.mjs','*.fwsc','__pycache__','*.woff*','*.mp3','reader','.git')
X0X='''static int sh_role(uint32_t hw) { static const uint8_t R[7] = {0, 1, 3, 4, 5, 6, 2}; return R[hw]; }
#define SH_ENC(e, n) o_web_enc(sh_role(e), (n))
static uint32_t sh_labels;
static uint32_t sh_label(uint32_t raw) { return raw < 2u ? raw + 12u : raw - 2u; }
#define SH_BTN(i, d) (sh_labels = (sh_labels & ~(1u << sh_label(i))) | (uint32_t)(d) << sh_label(i), o_web_buttons(sh_labels))
'''
KEYS='''static uint32_t sh_keys_m;
#define SH_KEY(k, d) (sh_keys_m = (sh_keys_m & ~(1u << (k))) | (uint32_t)(d) << (k), o_web_keys(sh_keys_m))
'''
RAW='''static uint32_t sh_raw_m;
#define SH_BTN(i, d) (sh_raw_m = (sh_raw_m & ~(1u << (i))) | (uint32_t)(d) << (i), o_web_buttons(sh_raw_m))
#define SH_ENC(e, n) o_web_enc((e), (n))
'''
def mk(i,name,ver,stem,web,incs,extra,defs,fb,body,dirs='firmware host tools web/emu build/gen',boot='o_web_boot();',pre='',out='o_web_out_l o_web_out_r',render='o_web_render',master='o_web_master((m * m) >> 8)',be=0,itcm=10):
    s='ports/_dl/'+i; d='ports/'+i
    for k in dirs.split():
        if os.path.isdir(f'{s}/{k}'): shutil.copytree(f'{s}/{k}',f'{d}/{k}',dirs_exist_ok=True,ignore=IG)
    for f in os.listdir(s):
        if os.path.isfile(f'{s}/{f}') and re.match(r'(LICEN[SC]|COPYING|NOTICE|README\.md|THIRD|CREDITS)',f): shutil.copy(f'{s}/{f}',d)
    if os.path.isdir(s+'/LICENSES'): shutil.copytree(s+'/LICENSES',d+'/LICENSES',dirs_exist_ok=True)
    os.makedirs(d+'/web/emu',exist_ok=True); open(d+'/.gitignore','w').write('build/\n__pycache__/\n*.o\n')
    g=lambda *a:subprocess.run(['git','-C',s,*a],capture_output=True,text=True).stdout.strip()
    url=g('remote','get-url','origin'); open(d+'/SOURCE_COMMIT.txt','w').write(f'{url} {g("log","-1","--format=%H %ci")} ({ver})\n')
    names='web_boot web_out_l web_out_r web_render web_buttons web_keys web_enc web_master web_nor_erase web_ms web_frame'.split()
    l,r=out.split()
    t=f'''/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: {name} {ver} ({url}) on the Teensy 4.1: its own browser build ({web}) inside ports/common's shell */
#include "../../../common/shell_pre.h"
#include <stdlib.h>
#include <time.h>
#ifndef CLOCK_MONOTONIC
#define CLOCK_MONOTONIC 1
static int clock_gettime(int c, struct timespec *t) {{ (void)c; t->tv_sec = 0; t->tv_nsec = 0; return 0; }}
#endif
#define getenv(n) ((char *)0)
{pre}'''+''.join(f'#define {n} o_{n}\n' for n in names)+f'#include "../../{web}"\n#undef __attribute__\n#undef EXPORT\n#undef memset\n#undef memcpy\n#undef memcmp\n#undef memmove\n'+''.join(f'#undef {n}\n' for n in names)+f'''#define SH_FLOAT
#define SH_OUT_L {l}
#define SH_OUT_R {r}
#define SH_RENDERF(n) {render}(n)
#define SH_ADC(m) {master}
static void SH_BOOT(void) {{ {boot} }}
static void SH_FRAME(uint32_t ms)
{{
    const uint16_t *p = (const uint16_t *){fb};
    uint32_t i;
    (void)ms;
    for (i = 0; i < 57600u; i++) if (shl_fb[i] != {'sh_be16(p[i])' if be else 'p[i]'}) sh_put(i, {'sh_be16(p[i])' if be else 'p[i]'});
}}
{body}#include "../../../common/shell_post.h"
'''
    open(d+'/web/emu/felucca_teensy.c','w').write(t)
    open(d+'/PORT.txt','w').write(f'name {name}\nversion {ver}\nstem {stem}\nincludes {incs}\nextra {extra}\ndefines {defs}\nitcm_banks {itcm}\nnor 0\n')
