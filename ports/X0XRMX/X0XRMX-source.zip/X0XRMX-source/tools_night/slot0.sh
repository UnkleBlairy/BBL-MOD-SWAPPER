#!/bin/bash
# the test menu (slot 0) + the release's Jam Box and JIANT in slots 1 and 2 -> target/night-menu.hex
set -e; cd "$(dirname "$0")/.."; . ~/.cargo/env
OBJCOPY=$(find "$(rustc --print sysroot)" -name llvm-objcopy -type f|head -1)
TFM1_FW=felucca CARGO_TARGET_DIR=target/slot0 cargo build --release >target/slot0.log 2>&1
"$OBJCOPY" -O ihex target/slot0/thumbv7em-none-eabihf/release/teensy-fm1 target/slot0-felucca.hex
awk '/^python3 - target\/slot0-felucca.hex/{f=1;next} /^PY$/{f=0} f' build.sh > target/mkhex.py
python3 target/mkhex.py target/slot0-felucca.hex /mnt/c/Users/blair/teensy/roms/JAMBOX.R1 /mnt/c/Users/blair/teensy/roms/JIANT.R2 target/night-menu.hex
ls -la target/night-menu.hex
