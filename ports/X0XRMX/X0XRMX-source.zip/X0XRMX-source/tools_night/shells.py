import sys; sys.path.insert(0,'tools_night')
from mkshell import *
LX='#define SH_KEY_LED(k) (o_web_lit_keys() >> (k) & 1u ? 2 : DK >> (k) & 1u ? 1 : 0)\n#define SH_BTN_LED(i) (o_web_lit_buttons() >> sh_label(i) & 1u ? 2 : DB >> sh_label(i) & 1u ? 1 : 0)\n'.replace('o_web','web')
mk('monk','MONK-1','0.10','MONK1','web/emu/monk_web.c','firmware/src firmware/src/dsp build/gen','firmware/src/dsp/monk.c','OM_HOST=1 OM_WEB=1 OM_VERSION="0.10"','web_fb()',X0X+'#define SH_KEY(k, d) web_key((k), (d) ? 100u : 0u, 300u)\n'+LX.replace('DK','0u').replace('DB','0u'),be=0)
mk('tribe','TRIBE','0.3','TRIBE','web/emu/tribe_web.c','firmware/src firmware/src/dsp build/gen','firmware/src/dsp/drum909.c firmware/src/dsp/drum808.c firmware/src/dsp/acid.c firmware/src/dsp/lead.c firmware/src/dsp/fm4.c firmware/src/dsp/noise.c firmware/src/dsp/tribe_syn.c firmware/src/dsp/cycle.c firmware/src/dsp/svf.c firmware/src/dsp/master.c firmware/src/tribe/engine.c firmware/src/tribe/mfx.c firmware/src/tribe/scatter.c firmware/src/tribe/engines.c firmware/src/dsp/kicks.c firmware/src/tribe/project.c firmware/src/tribe/store.c','X0X_HOST=1 TRIBE_WEB=1','web_fb()',X0X+KEYS+LX.replace('DK','web_dim_keys()').replace('DB','web_dim_buttons()'))
mk('elixir','Elixir','1.5.4','ELIXIR','web/emu/elixir_web.c','build/gen firmware/src firmware/hal','','ELIXIR_VERSION="1.5.4"','web_screen()',X0X+KEYS+LX.replace('DK','web_dim_keys()').replace('DB','web_dim_buttons()'),master='o_web_master(m)')
mk('cs1','CS-1','2026.10','CS1','web/emu/cs1_web.c','firmware/src firmware/gen','','APP_VER="2026.10"','web_screen()',RAW+KEYS+'#define SH_KEY_LED(k) (web_leds_keys() >> (k) & 1u ? 2 : 0)\n#define SH_BTN_LED(i) (web_leds_buttons() >> (i) & 1u ? 2 : 0)\n',master='o_web_master(m)',be=1,dirs='firmware tests web/emu')
mk('fmel','FMEL-1','1.3','FMEL1','firmware/src/mel.c','web/emu firmware/src firmware/gen build/gen','','DINGHY_WEB=1 APP_VER="1.3"','web_screen()',RAW.replace('#define SH_BTN(i, d) (sh_raw_m = (sh_raw_m & ~(1u << (i))) | (uint32_t)(d) << (i), o_web_buttons(sh_raw_m))','#define SH_BTN(i, d) web_button((i), (d))')+KEYS+'static uint32_t sh_l(uint32_t i) { return web_leds(i >> 5) >> (i & 31u) & 1u ? 2 : 0; }\n#define SH_KEY_LED(k) sh_l(14u + (k))\n#define SH_BTN_LED(i) sh_l(i)\n',master='o_web_master(m)',be=1,pre='#define memset mel_memset\n#define memcpy mel_memcpy\n#define memcmp mel_memcmp\n')
mk('ravel','Ravel','1.46.0','RAVEL','web/emu/ravel_web.c','firmware/app build/gen','firmware/app/ravel_app.c','','rv_fb()','''static float sh_l[1024], sh_r[1024];
static uint32_t sh_rn, sh_ra;
static void sh_rv(uint32_t n)
{
    uint32_t i;
    for (i = 0; i < n; i++) {
        while (sh_ra >= sh_rn) { sh_rn = rv_run(1); sh_ra = 0; }
        sh_l[i] = audio[2u * sh_ra]; sh_r[i] = audio[2u * sh_ra + 1u]; sh_ra++;
    }
}
static float *sh_lp(void) { return sh_l; }
static float *sh_rp(void) { return sh_r; }
static uint32_t sh_b, sh_k;
#define SH_BTN(i, d) (sh_b = (sh_b & ~(1u << (i))) | (uint32_t)(d) << (i), rv_set_buttons(sh_b))
#define SH_KEY(k, d) (sh_k = (sh_k & ~(1u << (k))) | (uint32_t)(d) << (k), rv_set_keys(sh_k))
#define SH_ENC(e, n) rv_enc((int)(e), (n))
#define SH_KEY_LED(k) (rv_leds_keys() >> (k) & 1u ? 2 : 0)
#define SH_BTN_LED(i) (rv_leds_buttons() >> (i) & 1u ? 2 : 0)
''',render='sh_rv',out='sh_lp sh_rp',boot='rv_boot(); ui_intro();',master='rv_set_master((m * m) >> 8)',pre='#define memset rv_memset\n#define memcpy rv_memcpy\n#define memmove rv_memmove\n#define memcmp rv_memcmp\n',be=1)
