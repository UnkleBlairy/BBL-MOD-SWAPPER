"""fm1-base ports: the simulator's test buffers cut down for the Teensy (a sparse data area of a few sectors)"""
import re,sys
for d in sys.argv[1:]:
    p=f'ports/{d}/base/host/plat_host.c'; s=open(p).read()
    if 'da_at(' in s: continue
    s=re.sub(r'#define HSX_KEEP \w+','#define HSX_KEEP 4096u',s)
    s=s.replace('said_log[16384]','said_log[256]')
    s=s.replace('memset(data_area, 0xFF, DATA_TOP - DATA_BASE);','memset(da_pool, 0xFF, sizeof da_pool);').replace('memset(data_area, 0xFF, sizeof data_area);','memset(da_pool, 0xFF, sizeof da_pool);')
    decl='static uint8_t data_area[DATA_TOP - DATA_BASE];'
    assert decl in s,d
    s=s.replace(decl,'')
    s=re.sub(r'&data_area\[([^\[\]]+)\]',r'da_at(\1)',s); s=re.sub(r'(?<!\w)data_area\[([^\[\]]+)\]',r'(*da_at(\1))',s)
    i=s.index('static uint8_t data_ready')
    s=s[:i]+'''/* teensy-fm1: the data area is sparse, a few 4 KB sectors given out as they are first touched; past those, one scratch sector */
#ifndef DA_SECT
#define DA_SECT 8u
#endif
static uint8_t da_pool[(DA_SECT + 1u) * 4096u];
static uint16_t da_map[(DATA_TOP - DATA_BASE) / 4096u + 1u];
static uint32_t da_n;
static uint8_t *da_at(uint32_t o)
{
    uint32_t k = o >> 12, m = da_map[k];
    if (!m)
        m = da_map[k] = (uint16_t)(da_n < DA_SECT ? ++da_n : DA_SECT + 1u);
    return &da_pool[(m - 1u) * 4096u + (o & 4095u)];
}
'''+s[i:]
    open(p,'w').write(s); print(d,re.findall(r'.*\bdata_area\b.*',s)[:6])
