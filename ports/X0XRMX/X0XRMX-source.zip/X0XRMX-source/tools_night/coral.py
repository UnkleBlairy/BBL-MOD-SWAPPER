import sys; sys.path.insert(0,'tools_night')
from mkshell import *
PRE='''#include <stdio.h>
#ifdef __arm__
#include <pthread.h>
#define pthread_equal(a, b) 1
#define pthread_self() ((pthread_t)1)
#undef PTHREAD_MUTEX_INITIALIZER
#undef PTHREAD_COND_INITIALIZER
#define PTHREAD_MUTEX_INITIALIZER 0
#define PTHREAD_COND_INITIALIZER 0
#define pthread_mutex_lock(m) ((void)(m))
#define pthread_mutex_unlock(m) ((void)(m))
#define pthread_cond_wait(c, m) ((void)(c))
#define pthread_cond_broadcast(c) ((void)(c))
#define pthread_cond_signal(c) ((void)(c))
#define pthread_create(t, a, f, x) ((void)(f), -1)
#define pthread_detach(t) ((void)0)
#define pthread_join(t, r) ((void)0)
static int teensy_noprint(const char *f, ...) { (void)f; return 0; }
#define printf teensy_noprint
#define fprintf(...) ((void)0)
#define puts(s) ((void)(s))
#define putchar(c) ((void)(c))
#define fflush(f) ((void)(f), 0)
#define exit(n) do { for (;;) ; } while (0)
#define atexit(f) ((void)0)
#define fwrite(a, b, c, d) ((size_t)0)
#define fopen(a, b) ((FILE *)0)
#define fread(a, b, c, d) ((size_t)0)
#define fseek(a, b, c) (0)
#define fclose(f) ((void)0)
#endif
#define EMU_WEB 1
'''
BODY=X0X+KEYS+'''static int sh_q(int v) { return !v ? 0 : v == 1 || v == 4 ? 1 : 2; }
#define SH_KEY_LED(k) sh_q(web_leds()[k])
#define SH_BTN_LED(i) sh_q(web_leds()[27u + sh_label(i)])
'''
for i,n,v,st in (('coralflower','CoralFlower','0.7.1','CORALFLW'),('choralroot','ChoralRoot','0.46','CHORALRT'),('purplemonkey','PurpleMonkey','0.12','PURPLEMK')):
    if len(sys.argv)>1 and i not in sys.argv[1:]: continue
    mk(i,n,v,st,'tools/emu/web/emu_web.c','tools/emu/web/compat build/gen firmware/src','','EMU_WEB=1','web_fb()',BODY,dirs='firmware tests tools/emu build/gen',pre=PRE.replace('#define EMU_WEB 1\n',''),master='o_web_master((int32_t)m)')
    b=f'ports/{i}/tools/emu/'
    p=b+'emu_hal_fw.h'; s=open(p).read()
    s=s.replace('static uint8_t emu_flash[EMU_FLASH_SIZE];','''/* teensy-fm1: sparse, a few sectors given out as they are first erased or written; the rest reads erased */
#define EF_SECT 8u
static uint8_t ef_pool[EF_SECT + 1u][4096];
static uint8_t ef_map[256];
static uint32_t ef_n;
static uint8_t *ef_at(uint32_t off)
{
    uint32_t k = off >> 12, m = ef_map[k];
    if (!m) {
        m = ef_n < EF_SECT ? ++ef_n : EF_SECT + 1u;
        if (m <= EF_SECT) ef_map[k] = (uint8_t)m;
        memset(ef_pool[m - 1u], 0xFF, 4096);
    }
    return &ef_pool[m - 1u][off & 4095u];
}
static void ef_read(uint32_t off, void *dst, uint32_t n)
{
    uint8_t *d = dst;
    for (; n; n--, off++) *d++ = ef_map[off >> 12] ? ef_pool[ef_map[off >> 12] - 1u][off & 4095u] : 0xFF;
}''')
    s=s.replace('sizeof emu_flash)','1u)').replace('memset(emu_flash, 0xFF, 1u);','').replace('fread(emu_flash, 1, 1u, emu_flash_f)','0').replace('fwrite(emu_flash, 1, 1u, emu_flash_f)','0').replace('memset(emu_flash + n, 0xFF, sizeof emu_flash - n);','(void)n;').replace('fread(emu_flash, 1, sizeof emu_flash, emu_flash_f)','0').replace('memset(emu_flash + n, 0xFF, sizeof emu_flash - n);','(void)n;').replace('fwrite(emu_flash, 1, sizeof emu_flash, emu_flash_f);','').replace('fwrite(emu_flash + off, 1, n, emu_flash_f);','')
    s=s.replace('memcpy(dst, emu_flash + off, n)','ef_read(off, dst, n)').replace('memset(emu_flash + off, 0xFF, 0x1000u)','memset(ef_at(off), 0xFF, 0x1000u)').replace('emu_flash[off + i] &=','*ef_at(off + i) &=')
    open(p,'w').write(s)
    import re
    for l in s.split('\n'):
        if re.search(r'\bemu_flash\b',l): print(i,l)
    p=b+'web/emu_web.c'; s=open(p).read()
    s=s.replace('#define RING 8192u','#define RING 1024u').replace('web_stage[WEB_FLASH_SIZE]','web_stage[16]').replace('return emu_flash;','return ef_pool[0];')
    open(p,'w').write(s)
