import sys; sys.path.insert(0,'tools_night')
from mkshell import *
BODY='''static float sh_l[1024], sh_r[1024];
static float *sh_lp(void) { return sh_l; }
static float *sh_rp(void) { return sh_r; }
static void sh_hr(uint32_t n)
{
    uint32_t i;
    const float *a = sim_audio();
    sim_render(n);
    for (i = 0; i < n; i++) { sh_l[i] = a[2u * i]; sh_r[i] = a[2u * i + 1u]; }
}
static uint32_t sh_label(uint32_t raw) { return raw < 2u ? raw + 12u : raw - 2u; }
static int sh_role(uint32_t hw) { static const uint8_t R[7] = {0, 1, 3, 4, 5, 6, 2}; return R[hw]; }
#define SH_ENC(e, n) sim_enc(sh_role(e), (n))
#define SH_BTN(i, d) sim_btn(sh_label(i), (d))
#define SH_KEY(k, d) sim_key((k), (d))
#define SH_KEY_LED(k) (sim_key_leds() >> (k) & 1u ? 2 : 0)
#define SH_BTN_LED(i) (sim_leds() >> sh_label(i) & 1u ? 2 : 0)
'''
mk('hortator','Hortator','1.0.1','HORTATOR','tests/sim_core.c','build/gen firmware/src firmware/hal tests','','FELUCCA_VERSION2=1','sim_fb()',BODY,be=1,render='sh_hr',out='sh_lp sh_rp',boot='sim_init(1);',master='sim_master(m)',dirs='firmware tests tools build/gen')
open('ports/hortator/PORT.txt','a').write('')
p='ports/hortator/PORT.txt'; s=open(p).read().replace('nor 0','nor 0x100000').replace('FELUCCA_VERSION2=1',''); open(p,'w').write(s)
src=open('ports/_dl/hortator/firmware/hal/fm1_input.h').read()
i=src.index('static const int8_t FM1_KEYMAP'); open('ports/hortator/build/gen/sim_keymap.h','w').write(src[i:src.index('};',i)+3])
p='ports/hortator/tests/sim_host.h'; s=open(p).read()
s=s.replace('static uint8_t hflash[SIM_FLASH_SIZE];','''#ifdef TEENSY_NOR_ADDR                  /* teensy-fm1: real flash, in this ROM's slot */
extern int32_t teensy_nor_erase(uint32_t off);
extern int32_t teensy_nor_prog(uint32_t off, const uint8_t *src, uint32_t n);
#define hflash ((uint8_t *)TEENSY_NOR_ADDR)
#else
static uint8_t hflash[SIM_FLASH_SIZE];
#endif''')
s=s.replace('    memset(hflash + off, 0xFF, 4096);','''#ifdef TEENSY_NOR_ADDR
    if (teensy_nor_erase(off & ~4095u)) return -8;
#else
    memset(hflash + off, 0xFF, 4096);
#endif''').replace('    for (i = 0; i < n; i++)\n        hflash[off + i] &= s[i];','''#ifdef TEENSY_NOR_ADDR
    (void)i; if (teensy_nor_prog(off, s, n)) return -8;
#else
    for (i = 0; i < n; i++)
        hflash[off + i] &= s[i];
#endif''')
open(p,'w').write(s)
p='ports/hortator/tests/sim_core.c'; s=open(p).read()
s=s.replace('    memset(hflash, 0xFF, sizeof hflash);','#ifndef TEENSY_NOR_ADDR\n    memset(hflash, 0xFF, sizeof hflash);\n#endif').replace('#include "sim_lab.c"','/* teensy-fm1: no lab */')
open(p,'w').write(s)
