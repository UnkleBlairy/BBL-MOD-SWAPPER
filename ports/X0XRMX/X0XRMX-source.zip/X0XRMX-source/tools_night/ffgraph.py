"""ffgraph.py id [roots regex] : functions the sound's code cannot reach (the compiler's call graph) go to flash"""
import sys,os,re,subprocess
i=sys.argv[1]; P='ports/'+i
R=re.compile(sys.argv[2] if len(sys.argv)>2 else r'^(app_audio|mix_block|app_render|audio_render|render_block|din_render|.*_isr|isr_.*)$')
NOT=re.compile(r'draw|page|menu|ui_|_ui|screen|lcd|gfx|text|font|sysex|midi_ui|blit|paint|show|view|init|boot|save|load|main',re.I)
g=lambda k:next((l[len(k)+1:].strip() for l in open(P+'/PORT.txt') if l.startswith(k+' ')),'')
cc=['arm-none-eabi-gcc','-g','-mcpu=cortex-m7','-mthumb','-mfloat-abi=hard','-mfpu=fpv5-d16','-O2','-w','-std=gnu99','-ffp-contract=off','-ffunction-sections','-fdata-sections','-fcallgraph-info']+['-I%s/%s'%(P,x) for x in g('includes').split()]+['-D'+x for x in g('defines').split()]+['-DFELUCCA_VERSION="x"']
size={};edges={};called=set()
for n,c in enumerate(['web/emu/felucca_teensy.c']+g('extra').split()):
    o=f'target/fg{n}.o'
    cmd=cc if c.endswith('.c') else [x for x in cc if x!='-std=gnu99']+['-std=gnu++11','-fno-exceptions','-fno-rtti','-fno-threadsafe-statics','-D__UINT32_TYPE__=unsigned int','-D__INT32_TYPE__=int']
    subprocess.check_call(cmd+['-c',f'{P}/{c}','-o',o])
    for l in subprocess.check_output(['arm-none-eabi-nm','-S','-t','d',o],text=True).splitlines():
        m=re.match(r'\d+ (\d+) [tTwW] (\S+)',l)
        if m: size[m[2]]=max(size.get(m[2],0),int(m[1]))
    for m in re.finditer(r'edge: \{ sourcename: "([^"]+)" targetname: "([^"]+)"',open(f'target/fg{n}.ci').read()):
        a,b=(x.split(':')[-1] for x in m.groups()); edges.setdefault(a,set()).add(b); called.add(b)
base=lambda s:s.split('.')[0]
CO='co_resume' in open(P+'/web/emu/felucca_teensy.c').read()
if CO: R=re.compile(R.pattern[:-2]+'|web_render)$')
keep=set(f for f in size if R.match(base(f)))
roots=set(keep)
# called through pointers only: kept, unless the name says it is the screen's
keep|={f for f in size if f not in called and not NOT.search(f) and f not in ('web_boot','web_buttons') and (CO or f!='web_render')}
todo=list(keep)
while todo:
    f=todo.pop()
    for b in edges.get(f,()):
        if b not in keep: keep.add(b); todo.append(b)
# the coroutine's main loop and the shell's own are not the sound
out=[f for f in size if f not in keep and size[f]>=100]
hot=sum(size[f] for f in size if f not in out)
open(P+'/teensy_flash_funcs.txt','w').write('\n'.join(sorted(out))+'\n')
print(i,'roots',sorted(roots)[:6],len(out),'functions,',sum(size[f] for f in out)//1024,'KB in flash;',hot//1024,'KB hot')
print(sorted(((size[f],f) for f in size if f in keep),reverse=True)[:12])
