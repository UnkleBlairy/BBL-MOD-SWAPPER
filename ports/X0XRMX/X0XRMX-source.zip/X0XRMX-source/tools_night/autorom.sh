#!/bin/bash
# autorom.sh id... : rom.sh, fixing what doesn't fit (menus to flash, more or less ITCM); results in target/rom-results.txt
cd "$(dirname "$0")/.."
for f in "$@"; do ok=
 for try in 1 2 3 4 5 6; do
  out=$(tools_night/rom.sh $f 2>&1); if ! grep -q FAIL <<<"$out" && [ -f roms/$(sed -n 's/^stem //p' ports/$f/PORT.txt).R1 ]; then ok=1; break; fi
  b=$(sed -n 's/^itcm_banks //p' ports/$f/PORT.txt)
  if grep -q "'.text' will not fit" <<<"$out" && [ ! -f ports/$f/teensy_flash_funcs.txt ]; then if grep -q co_resume ports/$f/web/emu/felucca_teensy.c; then python3 tools_night/ffgraph.py $f; else python3 tools_night/flashfuncs.py $f; fi
  elif grep -q "'.text' will not fit" <<<"$out" && ! grep -q "'.bss' will not fit" <<<"$out" && [ $b -lt 12 ]; then sed -i "s/^itcm_banks .*/itcm_banks $((b+1))/" ports/$f/PORT.txt
  elif grep -q "'.bss' will not fit" <<<"$out" && ! grep -q "'.text' will not fit" <<<"$out" && [ ! -f ports/$f/teensy_flash_funcs.txt ]; then if grep -q co_resume ports/$f/web/emu/felucca_teensy.c; then python3 tools_night/ffgraph.py $f; else python3 tools_night/flashfuncs.py $f; fi; sed -i "s/^itcm_banks .*/itcm_banks 8/" ports/$f/PORT.txt
  elif grep -q "'.bss' will not fit" <<<"$out" && ! grep -q "'.text' will not fit" <<<"$out" && [ $b -gt 5 ]; then sed -i "s/^itcm_banks .*/itcm_banks $((b-1))/" ports/$f/PORT.txt
  else break; fi
 done
 if [ $ok ]; then echo "OK $f try$try $(grep R3 <<<"$out")"; else echo "FAIL $f"; echo "$out"|head -6; fi | tee -a target/rom-results.txt
done
