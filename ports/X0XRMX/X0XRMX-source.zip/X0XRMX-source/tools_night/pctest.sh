#!/bin/bash
# pctest.sh id : native build + run of a port, screenshots to target/shots
cd "$(dirname "$0")/.."; id=$1; P=ports/$id; g(){ sed -n "s/^$1 //p" $P/PORT.txt; }
mkdir -p target/shots target/pc
I=""; for i in $(g includes); do I="$I -I$P/$i"; done; D=""; for d in $(g defines); do D="$D -D$d"; done; X=""; for x in $(g extra); do case $x in *.cc|*.cpp) o=target/pc/$id-${x//\//_}.o; g++ -g -O1 -w -std=gnu++11 -ffp-contract=off -fno-exceptions -fno-rtti -fno-threadsafe-statics -fsanitize=${SAN:-address} $I $D -c $P/$x -o $o 2>&1|grep error|head -3; X="$X $o";; *) X="$X $P/$x";; esac; done
gcc -g -O1 -w -std=gnu99 -ffp-contract=off -fsanitize=${SAN:-address} -fno-omit-frame-pointer ${PCFLAGS:-} $I $D "-DFELUCCA_VERSION=\"$(g version)\"" $P/web/emu/felucca_teensy.c $X tools_night/harness.c -lm ${PCLIBS:-} -o target/pc/$id 2>&1 | grep -E "error|undefined|multiple" | head -${ERRS:-15}
[ -x target/pc/$id ] && ASAN_OPTIONS=detect_leaks=0 timeout 400 target/pc/$id target/shots/$id 2>&1 | head -40
