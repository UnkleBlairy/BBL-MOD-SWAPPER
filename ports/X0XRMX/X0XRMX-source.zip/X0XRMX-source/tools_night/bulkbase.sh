#!/bin/bash
# bulkbase.sh id... : fm1-base apps whose base submodule is empty, built on the trusted base copy
cd "$(dirname "$0")/.."
export NOGEN=1
for i in "$@"; do
 read V N < <(python3 -c "
import json;f=next(f for f in json.load(open('ports/_dl/cat.json'))['firmwares'] if f['id']=='$i');print(f['version'].replace(' ','_'),f['name'])")
 st=$(echo $i | tr a-z A-Z | tr -cd A-Z0-9 | cut -c1-8)
 echo "=== $i $N $V"
 [ -f ports/_dl/$i/base/host/plat_host.c ] || cp -r ports/_dl/zenith1/base/. ports/_dl/$i/base/
 timeout 60 python3 tools_night/mkbase.py $i "$N" $V $st 2>&1 | tail -1 | cut -c1-160; tools_night/nosect.sh $i
 timeout 60 env ERRS=4 tools_night/pctest.sh $i 2>&1 | grep -E "err|2keys|3play|fuzz|undef|Sanit" | head -6 | cut -c1-160
done
