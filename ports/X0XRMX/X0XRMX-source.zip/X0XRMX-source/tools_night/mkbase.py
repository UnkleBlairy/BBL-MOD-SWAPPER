#!/usr/bin/env python3
"""Teensy port of an fm1-base app: mkbase.py id 'Menu Name' version STEM [extra defines]"""
import sys,os,re,shutil,subprocess,glob
idn,name,ver,stem=sys.argv[1:5]; xdef=sys.argv[5] if len(sys.argv)>5 else ''
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); root=R+'/ports'; src=f'{root}/_dl/{idn}'; dst=f'{root}/{idn}'
ap=os.environ.get('APP','app'); bs=os.environ.get('BASE','base')
conf={};buf=''
for l in open(f'{src}/{ap}/fm1.toml'):
    l=re.sub(r'(^|\s+)#.*$','',l).strip()
    if buf: l=buf+' '+l; buf=''
    if re.match(r'\w+\s*=\s*\[',l) and ']' not in l: buf=l; continue
    m=re.match(r'(\w+)\s*=\s*(.+)',l)
    if m: conf[m[1]]=re.findall(r'"([^"]*)"',m[2]) if m[2][0]=='[' else m[2].strip('"')
ig=shutil.ignore_patterns('*.wav','*.png','*.mp4','*.html','*.js','*.fwsc','__pycache__','*.woff*','build','.git','tests','docs','*.pdf','*.jpg') if not os.environ.get('ALL') else shutil.ignore_patterns('build','.git','docs','*.mp4')
for d in [ap]+(os.environ.get('MORE') or '').split(): shutil.copytree(f'{src}/{d}',f'{dst}/{d}',dirs_exist_ok=True,ignore=ig)
for d in 'device include lib host assets tools LICENSES'.split():
    if os.path.isdir(f'{src}/{bs}/{d}'): shutil.copytree(f'{src}/{bs}/{d}',f'{dst}/base/{d}',dirs_exist_ok=True,ignore=shutil.ignore_patterns('*.png','__pycache__','*.mp4'))
for f in os.listdir(f'{src}/{bs}'):
    if re.match(r'(LICEN|CREDITS)',f) and os.path.isfile(f'{src}/{bs}/{f}'): shutil.copy(f'{src}/{bs}/{f}',f'{dst}/base/')
for f in os.listdir(src):
    if os.path.isfile(f'{src}/{f}') and re.match(r'(LICEN[SC]|COPYING|NOTICE|README\.md|THIRD|CREDITS)',f): shutil.copy(f'{src}/{f}',dst)
os.makedirs(f'{dst}/build/gen',exist_ok=True); os.makedirs(f'{dst}/web/emu',exist_ok=True)
open(f'{dst}/.gitignore','w').write('build/\n__pycache__/\n*.o\n')
g=lambda *a:subprocess.run(['git','-C',src,*a],capture_output=True,text=True).stdout.strip()
url,sha=g('remote','get-url','origin'),g('log','-1','--format=%H %ci')
open(f'{dst}/SOURCE_COMMIT.txt','w').write(f'{url} {sha} (version {ver}; on fm1-base)\n')
env={**os.environ,'X0X_FONTSET':conf.get('font_set','barlow'),'FM1_FONT_FULL':' '.join(conf.get('font_full',[])),'FM1_FONT_TRIM':'1' if conf.get('font_trim')=='true' else '','FM1_FONT_PACK':'1' if conf.get('font_pack')=='true' else ''}
words=f'{src}/{ap}/{conf.get("words","words.tsv")}'
for c in [[f'{root}/_dl/zenith1/base/tools/gen_font.py',f'{dst}/build/gen/felucca_font.h'],[f'{root}/_dl/zenith1/base/tools/gen_words.py',words,f'{dst}/build/gen/words_web',f'{dst}/build/gen/ann_words.h']]:
    r=subprocess.run(['python3',*c],capture_output=True,text=True,env=env)
    if r.returncode: print('GEN',c[0][-14:],r.stderr.strip()[-200:])
for l in ([] if os.environ.get('NOGEN') else conf.get('gen',[])):
    a=[x.replace('{gen}',f'{dst}/build/gen') for x in l.split()]
    r=subprocess.run(['python3',f'{src}/{ap}/{a[0]}',*a[1:]],cwd=f'{src}/{ap}',capture_output=True,text=True)
    if r.returncode: print('GEN',a,r.stderr.strip()[-200:])
hp=f'{dst}/base/host/plat_host.c'; h=open(hp).read()
h,n=re.subn(r'^(\s+)fb\[(.*?)\] = (.*);$',r'\1X0X_LCD_PUT(\2, \3);',h,flags=re.M)
h=h.replace('#ifdef PLAT_FB\n','/* teensy-fm1: X0X_LCD_PUT(i, v) writes pixel i (the Teensy build marks what changed for its display link) */\n#ifndef X0X_LCD_PUT\n#define X0X_LCD_PUT(i, v) (fb[i] = (v))\n#endif\n#ifdef PLAT_FB\n',1) if '#ifdef PLAT_FB\n' in h else h.replace('static uint16_t fb[','#ifndef X0X_LCD_PUT\n#define X0X_LCD_PUT(i, v) (fb[i] = (v))\n#endif\nstatic uint16_t fb[',1)
open(hp,'w').write(h)
t=open(f'{root}/zen/web/emu/felucca_teensy.c').read()
a=t.index('/* teensy-fm1:'); b=t.index('#include <stdint.h>')
t=t[:a]+f'/* teensy-fm1: {name} {ver} ({url} {sha[:7]}, an fm1-base app) on the Teensy 4.1: fm1-base\'s host simulator\n * (host/plat_host.c, as its browser build runs it), in the shape of the X0X port (ports/x0x). Saves stay in RAM. */\n'+t[b:]
t=re.sub(r'\bring\b','tring',t)
t=re.sub(r'#include "../../host/zen_host.c"','#include "plat_host.c"',t)
if 'web_said' in h and 'static void web_said' not in t: t=t.replace('#include "plat_host.c"','static void web_said(const uint8_t *p, uint32_t n) { (void)p; (void)n; }   /* no screen reader */\n#include "plat_host.c"')
body=re.search(r'EXPORT void teensy_raw_input\(.*?^}',t,re.S|re.M).group(0)
t=t.replace(body,'''static void teensy_keys(uint32_t m)
{
#ifdef APP_KEY_SENSE
    uint32_t k, ch = m ^ held_keys;       /* each key landing at velocity 100 (as the browser build's web_keys) */
    for (k = 0; k < NKEYS; k++)
        if (ch >> k & 1u)
            app_host_key(k, m >> k & 1u ? 100u : 0u, 0);
#endif
    held_keys = m;
}
EXPORT void teensy_raw_input(uint32_t notes, uint32_t buttons)
{
    uint32_t i, b = 0;
    for (i = 0; i < NB; i++)
        if (buttons >> PANEL_BTN[i] & 1u)
            b |= 1u << i;
    held_btn = b;
    teensy_keys(notes & ((1u << NKEYS) - 1u));
}''')
t=re.sub(r'EXPORT void web_keys\(uint32_t m\) \{[^}]*\}','EXPORT void web_keys(uint32_t m) { teensy_keys(m & ((1u << NKEYS) - 1u)); }',t)
t=t.replace('#define atoi teensy_atoi\n','''#define atoi teensy_atoi
#ifdef __arm__
#include <stdarg.h>
static int teensy_noprint(const char *f, ...) { (void)f; return 0; }   /* teensy-fm1: no console */
#define printf teensy_noprint
#define puts(s) ((void)(s), 0)
#define putchar(c) ((void)(c), 0)
#endif
''',1)
open(f'{dst}/web/emu/felucca_teensy.c','w').write(t)
ex=[]
for u in conf.get('o2',[]):
    for f in (sorted(glob.glob(f'{src}/{ap}/{u}')) if re.search(r'[*?]',u) else [f'{src}/{ap}/{u}']): ex.append(os.path.relpath(os.path.normpath(f),src))
incs=['build/gen','base/host','base/device','base/include','base/lib',ap]+[os.path.normpath(f'{ap}/{d}') for d in conf.get('include',[])]
for f in [x for x in ex if not x.endswith(('.cc','.cpp'))]:
    if os.path.dirname(f) not in incs: incs.append(os.path.dirname(f))
defs=['PLAT_HOST','PLAT_WEB',f'APP_VERSION="{ver}"']+[x[2:] for x in conf.get('o2_cflags',[]) if x.startswith('-D')]+xdef.split()
open(f'{dst}/PORT.txt','w').write(f'name {name}\nversion {ver}\nstem {stem}\nincludes {" ".join(incs)}\nextra {" ".join(ex)}\ndefines {" ".join(defs)}\nitcm_banks {os.environ.get("ITCM","10")}\nnor 0\n')
print(idn,'lcd puts',n,'units',len(ex),'conf',{k:conf[k] for k in ('cpu2','resources','mirror','backup') if k in conf})
