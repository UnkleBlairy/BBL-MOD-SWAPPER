#!/bin/bash
# go.sh id name STEM app hostdef root extra : mkdin + PC test
cd "$(dirname "$0")/.."
V=$(python3 -c "
import json,sys;print(next((f['version'] for f in json.load(open('ports/_dl/cat.json'))['firmwares'] if f['id']=='$1'),'?'))")
python3 tools_night/mkdin.py "$1" "$2" "$V" $3 $4 $5 ${6:-.} "APP_VER=\"$V\"" $7 || exit; ERRS=8 tools_night/pctest.sh $1 2>&1| grep -v "ASan doesn" | cut -c1-160 | head -10
