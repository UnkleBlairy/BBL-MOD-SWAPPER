#!/bin/bash
# the screens' code of these ports to flash (their own file names)
cd "$(dirname "$0")/.."
python3 tools_night/flashfuncs.py choralroot 200 '/(ui[a-z0-9_]*|gfx|panel|storage|usb[a-z_]*|main|upreset|cr_(ui|draw|pages|gfx|edit|settings|favs|name|bank|anim|backup|screen|move|layout|ble)|emu_fw|emu_web|hostsim|felucca_teensy|shell_post)\.[ch]$'
for i in coralflower purplemonkey; do python3 tools_night/flashfuncs.py $i 200 '/(ui[a-z0-9_]*|gfx|icons?|panel|storage|project|bank[a-z_]*|editor[a-z_]*|usb[a-z_]*|main|upreset|cf_[a-z_]*(ui|draw|page|screen|gfx|edit|flora|splash|set|bank|name)[a-z_]*|flora[a-z_]*|pm_[a-z]*|cr_[a-z_]*|emu_fw|emu_web|hostsim|felucca_teensy|shell_post)\.[ch]$'; done
