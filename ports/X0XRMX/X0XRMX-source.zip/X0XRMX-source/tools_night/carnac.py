import sys; sys.path.insert(0,'tools_night')
from mkshell import *
NOR='''#ifdef TEENSY_NOR_ADDR                  /* teensy-fm1: real flash, in this ROM's slot (0xA0000 on) */
extern int32_t teensy_nor_erase(uint32_t off);
extern int32_t teensy_nor_prog(uint32_t off, const uint8_t *src, uint32_t n);
#define nor ((uint8_t *)TEENSY_NOR_ADDR - 0xA0000u)
#else
static uint8_t nor_[0x60000];
#define nor (nor_ - 0xA0000u)
#endif
'''
LX='#define SH_KEY_LED(k) (o_lit(0) >> (k) & 1u ? 2 : o_lit(1) >> (k) & 1u ? 1 : 0)\n#define SH_BTN_LED(i) (web_lit_buttons() >> sh_label(i) & 1u ? 2 : 0)\nstatic uint32_t o_lit(int d) { return d ? web_dim_keys() : web_lit_keys(); }\n'
V=sys.argv[1]
src=[f for f in sorted(os.listdir('ports/_dl/carnac/src/dsp')) if f.endswith('.c') and f not in('engine.c','test_wavetables.c')]
mk('carnac','Carnac',V,'CARNAC','src/host/carnac_web.c','src src/dsp src/hardware x0xfw gen',' '.join('src/dsp/'+f for f in src)+' src/host/pcm_images_host.c src/host/wt_areas_host.c','SYNTH_VERSION="'+V+'"','web_fb()',X0X+KEYS+LX,be=1,dirs='src LICENSES')
os.makedirs('ports/carnac/x0xfw',exist_ok=True); os.makedirs('ports/carnac/gen',exist_ok=True)
shutil.copytree('ports/x0x/firmware/src','ports/carnac/x0xfw',dirs_exist_ok=True)
shutil.copy('ports/x0x/build/gen/felucca_font.h','ports/carnac/gen/')
p='ports/carnac/src/host/carnac_web.c'; s=open(p).read()
s=s.replace('static uint8_t nor[NOR_SIZE];',NOR)
s=s.replace('    memcpy(dst, nor + off, n);','    if (off < 0xA0000u) { memset(dst, 0xFF, n); return 0; }\n    memcpy(dst, nor + off, n);')
s=s.replace('    memset(nor + off, 0xFF, 0x1000u);','''    if (off < 0xA0000u) return -8;
#ifdef TEENSY_NOR_ADDR
    if (teensy_nor_erase(off - 0xA0000u)) return -8;
#else
    memset(nor + off, 0xFF, 0x1000u);
#endif''')
s=s.replace('''    for (i = 0; i < n; i++)
        nor[off + i] &= ((const uint8_t *)src)[i];''','''    if (off < 0xA0000u) return -8;
#ifdef TEENSY_NOR_ADDR
    (void)i; if (teensy_nor_prog(off - 0xA0000u, src, n)) return -8;
#else
    for (i = 0; i < n; i++)
        nor[off + i] &= ((const uint8_t *)src)[i];
#endif''')
s=s.replace('{ memset(nor, 0xFF, sizeof nor); }','''{
#ifndef TEENSY_NOR_ADDR
    memset(nor_, 0xFF, sizeof nor_);
#endif
}''')
open(p,'w').write(s)
p='ports/carnac/PORT.txt'; s=open(p).read().replace('nor 0','nor 0x60000'); open(p,'w').write(s)
