cd "$(dirname "$0")/.."; s=$1; nm=$2; mkdir -p ports/_dl/$s; cp -r ports/_dl/hyp1/$s/. ports/_dl/$s/
DIRS="firmware host tools assets web/words web/emu" python3 tools_night/mkhost.py $s $nm 0.1 $3 host/amb_host.c web/emu/amb_web.c firmware/src/dsp/amb.c 'EN_HOST EN_WEB EN_VERSION="1"' "build/gen firmware/src firmware/src/dsp"
echo "https://github.com/RustyPawz/fm1-HYP1 $(git -C ports/_dl/hyp1 log -1 --format='%H %ci') ($s/)" > ports/$s/SOURCE_COMMIT.txt
(cd ports/$s; python3 tools/gen_font.py build/gen/felucca_font.h 2>&1|tail -1; [ -f firmware/words.tsv ] && python3 tools/gen_words.py firmware/words.tsv web/words build/gen/ann_words.h >/dev/null); tools_night/pctest.sh $s
