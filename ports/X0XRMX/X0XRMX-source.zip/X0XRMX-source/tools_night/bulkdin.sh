#!/bin/bash
# bulkdin.sh id... : Dinghy apps, their app file and host define found by themselves
cd "$(dirname "$0")/.."
for i in "$@"; do
 h=$(find ports/_dl/$i -path '*tests/host.c' | head -1); r=${h%/tests/host.c}; root=${r#ports/_dl/$i}; root=${root#/}; root=${root:-.}
 p=$(grep -rlE 'include "(\.\./)+tests/host\.c"' $r/firmware/src --include=*.c --include=*.h | head -1)
 [ -n "$p" ] || { echo "=== $i no platform"; continue; }
 hd=$(grep -B3 -E 'include "(\.\./)+tests/host\.c"' $p | grep -oE '[A-Z0-9_]+_HOST\b' | tail -1)
 app=$(grep -lE '#include "platform\.c"' $r/firmware/src/*.c | head -1); [ -n "$app" ] || app=$p
 st=$(echo $i | tr a-z A-Z | tr -cd A-Z0-9 | cut -c1-8)
 n=$(python3 -c "
import json;print(next((f['name'] for f in json.load(open('ports/_dl/cat.json'))['firmwares'] if f['id']=='$i'),'$i'))")
 echo "=== $i $root app ${app#$r/} $hd"
 timeout 100 tools_night/go.sh $i "$n" $st ${app#$r/} ${hd:-DINGHY_HOST} $root 2>&1 | tail -n +2 | cut -c1-150 | head -${LINES_:-7}
done
