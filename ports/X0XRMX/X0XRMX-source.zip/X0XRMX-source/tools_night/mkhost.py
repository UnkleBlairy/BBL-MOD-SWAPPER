#!/usr/bin/env python3
"""Make a Teensy port of a firmware with X0X's kind of host simulator + browser build.
mkhost.py id 'Menu Name' version STEM hostfile webfile 'extra c' 'defines' 'includes'"""
import sys,os,re,shutil,subprocess
idn,name,ver,stem,host,web,extra,defs,incs=sys.argv[1:10]
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+'/ports'
src=f'{root}/_dl/{idn}'; dst=f'{root}/{idn}'
sub=os.environ.get('SUBDIR','')
if sub: src+='/'+sub
keep_teensy=os.environ.get('KEEP')
for d in (os.environ.get('DIRS') or 'firmware host tools assets/fonts web/words sets web/emu').split():
    if os.path.isdir(f'{src}/{d}'):
        shutil.copytree(f'{src}/{d}',f'{dst}/{d}',dirs_exist_ok=True,ignore=shutil.ignore_patterns('*.wav','*.png','*.mp4','*.html','*.js','*.fwsc','__pycache__','*.woff*','reader'),symlinks=False)
for f in os.listdir(src):
    if os.path.isfile(f'{src}/{f}') and re.match(r'(LICEN[SC]|COPYING|NOTICE|README\.md|THIRD|CREDITS|AUTHORS)',f): shutil.copy(f'{src}/{f}',dst)
os.makedirs(f'{dst}/build/gen',exist_ok=True)
open(f'{dst}/.gitignore','w').write('build/\n__pycache__/\n*.o\n')
sha=subprocess.run(['git','-C',src,'log','-1','--format=%H %ci'],capture_output=True,text=True).stdout.strip()
url=subprocess.run(['git','-C',src,'remote','get-url','origin'],capture_output=True,text=True).stdout.strip()
open(f'{dst}/SOURCE_COMMIT.txt','w').write(f'{url} {sha} (version {ver})\n')
h=open(f'{dst}/{host}').read()
h,n=re.subn(r'^(\s+)fb\[(.*?)\] = (.*);$',r'\1X0X_LCD_PUT(\2, \3);',h,flags=re.M)
h=re.sub(r'#include <libproc.h>\n','',h)
i=h.index('static uint16_t fb[')
h=h[:i]+'''/* teensy-fm1: X0X_LCD_PUT(i, v) writes pixel i (the Teensy build marks what changed for its display link) */
#ifndef X0X_LCD_PUT
#define X0X_LCD_PUT(i, v) (fb[i] = (v))
#endif
'''+h[i:]
open(f'{dst}/{host}','w').write(h)
has_dimk=bool(re.search(r'static uint32_t [^;]*\bdim_keys\b',h))
has_dimb=bool(re.search(r'static uint32_t [^;]*\bdim_btn\b',h))
has_setkeys='static void set_keys(' in h
t=open(f'{root}/x0x/web/emu/felucca_teensy.c').read()
a=t.index('/* teensy-fm1: X0X'); b=t.index('#include <stdint.h>')
t=t[:a]+f'''/* teensy-fm1: {name} {ver} ({url} {sha.split()[0][:7]}) on the Teensy 4.1. Derived from its own browser build, {web}
 * (the host simulator {host}: the whole app against a simulated FM-1), in the shape of the X0X port
 * (ports/x0x). The changes are marked "teensy-fm1:"; the one in the host file is X0X_LCD_PUT (lcd_fill / lcd_blit mark the
 * changed pixels for the display link). Saves stay in RAM (the host's store[]). */
'''+t[b:]
t=t.replace('#define X0X_WEB 1\n#ifndef X0X_VERSION\n#define X0X_VERSION FELUCCA_VERSION\n#endif\n','')
hdr='../../'+host
t=t.replace('#include "../../host/x0x_host.c"',f'#include "{hdr}"')
if 'plat_said' not in h and 'web_said' not in h: t=t.replace('static void web_said(const uint8_t *p, uint32_t n) { (void)p; (void)n; }   /* no screen reader */\n','')
t=t.replace('#define RING 4096u','#define RING 1024u')
t=t.replace('static void web_audio(const int32_t *blk, uint32_t n);',r'''/* teensy-fm1: no environment, no libc atoi */
#include <stdlib.h>
#include <stdio.h>
#define getenv(n) ((char *)0)
static int teensy_atoi(const char *s) { int v = 0, g = *s == '-'; s += g; while (*s >= '0' && *s <= '9') v = v * 10 + *s++ - '0'; return g ? -v : v; }
#define atoi teensy_atoi
static void web_audio(const int32_t *blk, uint32_t n);''',1)
if not has_setkeys: t=re.sub(r'set_keys\((.*)\);',r'held_keys = \1;',t)
if not has_dimk: t=t.replace('(int)(dim_keys >> (i - NB) & 1u)','0')
t=t.replace('int dim = i < NB ? 1 :',f'int dim = i < NB ? {"(int)(dim_btn >> i & 1u)" if has_dimb else "1"} :')
if not keep_teensy: open(f'{dst}/web/emu/felucca_teensy.c','w').write(t)
open(f'{dst}/PORT.txt','w').write(f'name {name}\nversion {ver}\nstem {stem}\nincludes {incs}\nextra {extra}\ndefines {defs}\nitcm_banks {os.environ.get("ITCM","10")}\nnor 0\n')
print(idn,'lcd puts',n,'setkeys',has_setkeys,'dim',has_dimk,has_dimb)
