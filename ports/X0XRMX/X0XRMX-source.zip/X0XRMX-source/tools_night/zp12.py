import sys,re,shutil; sys.path.insert(0,'tools_night')
from mkshell import *
VER=open('ports/_dl/zp12/README.md').read(); m=re.search(r'\*\*Status: ([0-9][0-9.]*)\*\*',VER); V=m[1] if m else '1.0'
B='''#define SH_ENC(e, n) sim_enc((e), (n))
#define SH_BTN(i, d) sim_button((i), (d))
#define SH_KEY(k, d) sim_key((k), (d))
#define SH_KEY_LED(k) (sim_leds_keys() >> (k) & 1u ? 2 : sim_glow_keys() >> (k) & 1u ? 1 : 0)
#define SH_BTN_LED(i) (sim_leds_buttons() >> (i) & 1u ? 2 : 0)
'''
mk('zp12','ZP-12',V,'ZP12','sim/sim.c','sim/hal firmware/src firmware/gen build/gen firmware/hal','','SIM_NATIVE=1','sim_screen()',B,boot='sim_init(44100);',be=1,render='sim_render',out='sim_out_l sim_out_r',master='sim_master(m)',dirs='firmware sim build/gen',pre='#define CO_STACK 24576u\n#include "../../../common/coro.h"\n#define ZP12_VER "%s"\n'%V)
p='ports/zp12/sim/sim.c'; s=open(p).read()
i=s.index('#include <ucontext.h>'); j=s.index('#else',i)
s=s[:i]+'''static void sim_yield(void) { co_yield(); }
static void sim_pass(void) { if (!booted) { booted = 1; co_start(sim_boot); } co_resume(); }
'''+s[j:]
s=s.replace('for (i = 0; i < sizeof sim_flash; i++) sim_flash[i] = 0xFF;','#ifndef TEENSY_NOR_ADDR\n    for (i = 0; i < SIM_FL_N; i++) sim_flash_[i] = 0xFF;\n#endif')
s=s.replace('#include "../firmware/src/zp12.c"','#pragma GCC optimize("no-tree-loop-distribute-patterns")\n#include "../firmware/src/zp12.c"')
open(p,'w').write(s)
NOR='''#define SIM_FL_LO 0x97000u
#define SIM_FL_N 0x69000u
#ifdef TEENSY_NOR_ADDR                  /* teensy-fm1: real flash, in this ROM's slot: from 0x97000 */
extern int32_t teensy_nor_erase(uint32_t off);
extern int32_t teensy_nor_prog(uint32_t off, const uint8_t *src, uint32_t n);
#define sim_flash ((uint8_t *)TEENSY_NOR_ADDR - SIM_FL_LO)
#else
static uint8_t sim_flash_[SIM_FL_N];
#define sim_flash (sim_flash_ - SIM_FL_LO)
#endif
'''
p='ports/zp12/sim/hal/fm1_xip.h'; s=open(p).read().replace('static uint8_t sim_flash[0x100000];\n',NOR); open(p,'w').write(s)
p='ports/zp12/sim/hal/fm1_flash.h'; s=open(p).read()
s=s.replace('    for (i = 0; i < 0x1000u; i++) sim_flash[off + i] = 0xFF;','#ifdef TEENSY_NOR_ADDR\n    (void)i; if (teensy_nor_erase(off - SIM_FL_LO)) return -1;\n#else\n    for (i = 0; i < 0x1000u; i++) sim_flash[off + i] = 0xFF;\n#endif')
s=s.replace('    for (i = 0; i < n; i++) sim_flash[off + i] &= src[i];','#ifdef TEENSY_NOR_ADDR\n    (void)i; if (teensy_nor_prog(off - SIM_FL_LO, src, n)) return -1;\n#else\n    for (i = 0; i < n; i++) sim_flash[off + i] &= src[i];\n#endif')
s=s.replace('dst[i] = sim_flash[(off + i) & 0xFFFFFu]','dst[i] = off + i >= SIM_FL_LO && off + i < 0x100000u ? sim_flash[off + i] : 0xFF'); open(p,'w').write(s)
p='ports/zp12/sim/hal/fm1_lcd_hw.h'; s=open(p).read()
s=s.replace('static uint16_t sim_fb[240 * 240];','#define sim_fb shl_fb').replace('sim_fb[sim_lcd.y * 240u + sim_lcd.x] = (uint16_t)(sim_lcd.hi << 8 | b[i]);','sh_put(sim_lcd.y * 240u + sim_lcd.x, (uint16_t)(b[i] << 8 | sim_lcd.hi));'); open(p,'w').write(s)
p='ports/zp12/web/emu/felucca_teensy.c'; t=open(p).read()
t=re.sub(r'(static void SH_FRAME\(uint32_t ms\)\n\{).*?\n\}',r'\1 (void)ms; }',t,flags=re.S)
t='#ifdef __arm__\n#undef __UINT32_TYPE__\n#undef __INT32_TYPE__\n#define __UINT32_TYPE__ unsigned int\n#define __INT32_TYPE__ int\n#endif\n'+t
open(p,'w').write(t)
p='ports/zp12/PORT.txt'; s=open(p).read().replace('nor 0','nor 0x69000'); open(p,'w').write(s)
