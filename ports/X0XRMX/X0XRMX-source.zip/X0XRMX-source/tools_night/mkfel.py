#!/usr/bin/env python3
"""Teensy port from a Felucca-family browser build: mkfel.py id 'Menu Name' version STEM webfile includes [defines]"""
import sys,os,re,shutil,subprocess
idn,name,ver,stem,web,incs=sys.argv[1:7]; defs=sys.argv[7] if len(sys.argv)>7 else ''
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+'/ports'; src=f'{root}/_dl/{idn}'; dst=f'{root}/{idn}'
for d in ('firmware','tests','tools','web/emu','build/gen','assets'):
    if os.path.isdir(f'{src}/{d}'):
        shutil.copytree(f'{src}/{d}',f'{dst}/{d}',dirs_exist_ok=True,ignore=shutil.ignore_patterns('*.wav','*.png','*.mp4','*.html','*.js','*.mjs','*.fwsc','__pycache__','*.woff*','*.mp3','*.gif','.git','*.golden','vendor','sdk'))
for f in os.listdir(src):
    if os.path.isfile(f'{src}/{f}') and re.match(r'(LICEN[SC]|COPYING|NOTICE|README\.md|THIRD|CREDITS|AUTHORS)',f): shutil.copy(f'{src}/{f}',dst)
open(f'{dst}/.gitignore','w').write('build/\n__pycache__/\n*.o\n')
g=lambda *a:subprocess.run(['git','-C',src,*a],capture_output=True,text=True).stdout.strip()
url,sha=g('remote','get-url','origin'),g('log','-1','--format=%H %ci')
open(f'{dst}/SOURCE_COMMIT.txt','w').write(f'{url} {sha} (version {ver})\n')
t=open(f'{src}/{web}').read(); miss=[]
def sub(p,r,n=1,req=True):
    global t
    t,k=re.subn(p,r,t,count=n,flags=re.M|re.S)
    if req and not k: miss.append(p[:60])
t=t.replace('#include <stdint.h>',f'''/* teensy-fm1: {name} {ver} ({url} {sha[:7]}) on the Teensy 4.1, made from its own browser build ({web}): the changed
 * rows as spans for the display link, the SPI NOR in this ROM's own flash slot, one core. Made by tools_night/mkfel.py. */
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#ifndef CLOCK_MONOTONIC
#define CLOCK_MONOTONIC 1
static int clock_gettime(int c, struct timespec *t) {{ (void)c; t->tv_sec = 0; t->tv_nsec = 0; return 0; }}
#endif
#define getenv(n) ((char *)0)
''',1)
sub(r'^static uint8_t nor\[[^\n]*',r'''#define NOR_SIZE 0x100000u
#ifdef TEENSY_NOR_ADDR
/* teensy-fm1: the 1 MiB NOR is real flash in this ROM's slot (src/nor.rs: mirrored to the card) */
#define NOR_LO 0x90000u   /* below: the FM-1's own firmware image, never written by the store */
#define nor ((uint8_t *)(TEENSY_NOR_ADDR - NOR_LO))
extern int32_t teensy_nor_erase(uint32_t off);
extern int32_t teensy_nor_prog(uint32_t off, const uint8_t *src, uint32_t n);
#else
static uint8_t nor[NOR_SIZE];
#endif''')
t=t.replace('sizeof nor','NOR_SIZE')
sub(r'^(\s+)memset\(nor \+ \(off & ~4095u\), 0xFF, 4096\);',r'''#ifdef TEENSY_NOR_ADDR
\1if (off < NOR_LO || teensy_nor_erase((off & ~4095u) - NOR_LO)) return -8;
#else
\1memset(nor + (off & ~4095u), 0xFF, 4096);
#endif''')
sub(r'^(\s+)for \(i = 0; i < n; i\+\+\)\n\s+nor\[off \+ i\] &= s\[i\];',r'''#ifdef TEENSY_NOR_ADDR
\1(void)i;
\1if (off < NOR_LO || teensy_nor_prog(off - NOR_LO, s, n)) return -8;
#else
\1for (i = 0; i < n; i++)
\1    nor[off + i] &= s[i];
#endif''')
sub(r'\{ memset\(nor, 0xFF, NOR_SIZE\); \}','''{
#ifndef TEENSY_NOR_ADDR
    memset(nor, 0xFF, NOR_SIZE);
#endif
}''')
sub(r'^(static uint32_t web_draws;)',r'''\1
/* teensy-fm1: the FM-1 link sends only what changed: per row, the first and last changed column (lo > hi: clean) */
static uint32_t teensy_px;
static uint8_t dirty_lo[240], dirty_hi[240];
static void teensy_put(uint32_t i, uint16_t v)
{
    uint32_t y, x;
    if (web_fb[i] == v)
        return;
    web_fb[i] = v;
    y = i / 240u; x = i % 240u;
    if (dirty_lo[y] > dirty_hi[y]) { dirty_lo[y] = dirty_hi[y] = (uint8_t)x; return; }
    if (x < dirty_lo[y]) dirty_lo[y] = (uint8_t)x;
    if (x > dirty_hi[y]) dirty_hi[y] = (uint8_t)x;
}
static void teensy_all(void) { uint32_t y; for (y = 0; y < 240u; y++) { dirty_lo[y] = 0; dirty_hi[y] = 239; } }''')
t,k=re.subn(r'web_fb\[([^\]\n]+)\] = ([^;=]+);',lambda m:f'teensy_put({m[1]}, {m[2]});' if m[1]!='i' else m[0],t)
if k<2: miss.append('fb writes %d'%k)
sub(r'(memset\(web_fb, 0, sizeof web_fb\);)',r'\1 teensy_all();',0,False)
sub(r'^static int32_t web_batt_adc = 620;[^\n]*','',1,False)
sub(r'^(static uint32_t web_master_adc = [^\n]*)',r'\1\nstatic int32_t web_batt_adc = 620;   /* teensy-fm1: the FM-1\'s battery over the link */')
t=t.replace('(int32_t)web_master_adc : 620;','(int32_t)web_master_adc : web_batt_adc;')
sub(r'^static uint8_t web_obj\[.*?^EXPORT int32_t web_restore_object.*?^}\n','',1,False)
t=re.sub(r'^EXPORT uint8_t \*web_obj_buf[^\n]*\n','',t,flags=re.M)
t=t.replace('#define RING 4096u','#define RING 1024u')
t,k=re.subn(r'#define FELUCCA_CDC 1\b','#define FELUCCA_CDC 0',t)
sf=open(f'{root}/sloop/web/emu/felucca_teensy.c').read()
a=sf.index('static uint32_t span_row;'); b=sf.index('/* teensy-fm1: the FM-1\'s raw input'); c=sf.index('EXPORT uint32_t teensy_ui_frames'); 
raw=sf[b:sf.index('EXPORT void teensy_raw_adc')]
alt=lambda n,e: f'memcpy(out + {n}, {e}, 11); ' if re.search(r'\b%s\['%e,t) else ''
t+='''
/* ------------------------------------------------ teensy-fm1: what src/main.rs uses --- */
EXPORT const uint16_t *teensy_fb(void) { return web_fb; }
EXPORT uint32_t teensy_draws(void) { return web_draws; }
EXPORT uint32_t teensy_pixels(void) { return teensy_px; }
EXPORT void teensy_redraw(void) { teensy_all(); }
EXPORT uint32_t teensy_ui_frames(void) { return felucca_dbg.ui_frames; }
'''+sf[a:b]+raw+'''EXPORT void teensy_raw_adc(uint32_t master, uint32_t batt) { web_master_adc = master > 1023u ? 1023u : master; web_batt_adc = batt ? (int32_t)(batt > 1023u ? 1023u : batt) : 620; }
EXPORT uint32_t teensy_leds(uint8_t *out)
{
    memset(out, 0, 45);
    memcpy(out, fm1_led, 11); '''+alt(11,'fm1_led_dim')+alt(22,'fm1_led_breath')+alt(33,'fm1_led_mid')+('out[44] = (uint8_t)web_dim_lo;' if 'web_dim_lo' in t else '')+'''
    return 1;
}
'''
open(f'{dst}/web/emu/felucca_teensy.c','w').write(t)
open(f'{dst}/PORT.txt','w').write(f'name {name}\nversion {ver}\nstem {stem}\nincludes {incs}\nextra \ndefines {defs}\nitcm_banks {os.environ.get("ITCM","10")}\nnor 0x70000\n')
print(idn,'missed:',miss)
