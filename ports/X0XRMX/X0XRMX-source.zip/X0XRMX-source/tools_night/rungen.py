import re,sys,subprocess,os
# runs only the generator scripts named in build.py's generate() list that were read beforehand
d=sys.argv[1]; s=open(d+'/tools/build.py').read(); m=re.search(r'^def generate.*?(?=^def )',s,re.S|re.M).group(0)
os.makedirs(d+'/build/gen',exist_ok=True)
for l in re.findall(r'\[\s*tools / "(gen_[a-z0-9_]+\.py)"((?:, [^\[\]]*?)?)\]',m):
    a=[]
    for x in l[1].split(',')[1:]:
        x=x.strip()
        g=re.match(r'GEN / "(.*)"',x); q=re.match(r'"(.*)"$',x); c=re.match(r'(?:SRC|FW) / (.*)$',x)
        a.append('build/gen/'+g[1] if g else q[1] if q else ('/'.join(re.findall(r'"([^"]+)"',x)) if c else x))
    r=subprocess.run(['python3','tools/'+l[0]]+a,cwd=d,capture_output=True,text=True)
    if r.returncode: print(d,l[0],a,'FAILED',r.stderr.strip().split('\n')[-1][:150])
print(d,os.listdir(d+'/build/gen'))
