import sys, zlib, struct
src, out, slot, stem, name, ver, nor = sys.argv[1:8]
slot, nor = int(slot), int(nor)
BASE = [0x60000000, 0x60200000, 0x60400000, 0x60600000]
END = [0x60200000, 0x60400000, 0x60600000, 0x607C0000]
mem = {}; base = 0
for l in open(src).read().split():
    n, ad, t = int(l[1:3], 16), int(l[3:7], 16), int(l[7:9], 16)
    if t == 4: base = int(l[9:13], 16) << 16
    elif t == 0:
        for i, b in enumerate(bytes.fromhex(l[9:9 + 2 * n])): mem[base + ad + i] = b
lo, hi = min(mem), max(mem) + 1
assert lo == BASE[slot], hex(lo)
assert hi <= END[slot] - 0x1000 - nor, 'image runs into the save memory / tag: %x' % hi
img = bytearray(b'\xff' * (hi - lo))
for a, b in mem.items(): img[a - lo] = b
assert struct.unpack_from('<I', img, 0x1000)[0] == 0x402000D1 and struct.unpack_from('<I', img, 0x1014)[0] == lo + 0x1000, 'boot header'
h = bytearray(512)
h[0:8] = b'FM1ROM01'
struct.pack_into('<IIII', h, 8, slot, len(img), zlib.crc32(img), lo)
h[24:24 + len(name)] = name.encode(); h[56:56 + len(ver)] = ver.encode(); h[72:72 + len(stem)] = stem.encode()
struct.pack_into('<I', h, 80, nor)
open(out, 'wb').write(bytes(h) + bytes(img))
print('%s: slot %d, %d KB of %d, crc %08x' % (out, slot, len(img) // 1024, (END[slot] - 0x1000 - lo) // 1024, zlib.crc32(img)))
