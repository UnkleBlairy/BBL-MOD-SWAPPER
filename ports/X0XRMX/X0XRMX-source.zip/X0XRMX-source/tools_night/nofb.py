"""nofb.py id file fbname be-writes...: the shell's frame buffer IS the firmware's (no copy): its pixel writes go through sh_put"""
import re,sys
i,f,fb=sys.argv[1:4]
p=f'ports/{i}/{f}'; s=open(p).read()
s,n=re.subn(r'(?m)^(\s*)'+fb+r'\[([^;\n]*?)\] = ([^;]*);',r'\1sh_put(\2, \3);',s)
s,m=re.subn(r'(?m)^static uint16_t '+fb+r'\[[^;]*;','#define '+fb+' shl_fb   /* teensy-fm1 */',s)
open(p,'w').write(s)
p=f'ports/{i}/web/emu/felucca_teensy.c'; t=open(p).read()
t=re.sub(r'(static void SH_FRAME\(uint32_t ms\)\n\{).*?\n\}',r'\1 (void)ms; }',t,flags=re.S); open(p,'w').write(t)
print(i,'writes',n,'decl',m)
