import sys,re; sys.path.insert(0,'tools_night')
from mkshell import *
B='''static float q_l[1024], q_r[1024];
static float *qq_lp(void) { return q_l; }
static float *qq_rp(void) { return q_r; }
static void q_render(uint32_t n)
{
    static uint32_t at = CTL;
    uint32_t i;
    for (i = 0; i < n; i++) {
        if (at >= CTL) { emu_render(CTL); at = 0; }
        q_l[i] = emu_audio_f[2u * at]; q_r[i] = emu_audio_f[2u * at + 1u]; at++;
    }
}
static void q_boot(void)
{
#ifndef TEENSY_NOR_ADDR
    memset(emu_flash, 0xFF, EMU_FLASH_SIZE);
#endif
    emu_init();
}
static void q_frame(uint32_t ms)
{
    if (!emu_running && ms > 2500u) emu_start();
    emu_frame();
}
static uint32_t q_btn, q_key;
#define SH_ENC(e, n) emu_enc((e), (n))
#define SH_BTN(i, d) (q_btn = (q_btn & ~(1u << (i))) | (uint32_t)(d) << (i), emu_input(q_key, q_btn))
#define SH_KEY(k, d) (q_key = (q_key & ~(1u << (k))) | (uint32_t)(d) << (k), emu_input(q_key, q_btn))
static int q_led(uint32_t id)
{
    uint32_t p, r;
    for (p = 0; p < FM1_NCOL; p++)
        for (r = 1; r < 5u; r++)
            if (FM1_KEYMAP[r][p] == (int8_t)id) return fm1_led[p] >> r & 1u ? 2 : (fm1_led_dim[p] | fm1_led_bg[p]) >> r & 1u ? 1 : 0;
    return 0;
}
#define SH_KEY_LED(k) q_led(14u + (k))
#define SH_BTN_LED(i) q_led(i)
'''
mk('fm1quest','FM1 Quest','43','QUEST','quest/src/fm1quest_wasm.c','build/gen firmware/src firmware/hal quest/src','','','emu_fb',B,boot='q_boot();',render='q_render',out='qq_lp qq_rp',master='emu_adc_set(FM1_ADC_MASTER, (int32_t)m)',dirs='firmware quest/src build/gen')
p='ports/fm1quest/web/emu/felucca_teensy.c'; s=open(p).read()
s=s.replace('static void SH_BOOT','static void q_boot(void);\nstatic void q_frame(uint32_t);\nstatic void SH_BOOT').replace('{\n    const uint16_t *p = (const','{\n    q_frame(ms);\n    const uint16_t *p = (const').replace('    for (i = 0; i < 57600u; i++) if','    if (0) for (i = 0; i < 57600u; i++) if')
open(p,'w').write(s)
p='ports/fm1quest/quest/src/fm1quest_wasm.c'; s=open(p).read()
s=re.sub(r'WASM_EXPORT\("[^"]+"\) ','',s)
s=s.replace('static uint16_t emu_fb[240 * 240];','#define emu_fb shl_fb').replace('emu_fb[st_cy * 240u + st_cx] = (uint16_t)(b[0] << 8 | b[1]);','sh_put(st_cy * 240u + st_cx, (uint16_t)(b[1] << 8 | b[0]));')
s=s.replace('#include "libc.c"','#define memset q_memset\n#define memcpy q_memcpy\n#define memcmp q_memcmp\n#pragma GCC push_options\n#pragma GCC optimize("no-tree-loop-distribute-patterns")\n#include "libc.c"\n#pragma GCC pop_options\n#undef memset\n#undef memcpy\n#undef memcmp')
s=s.replace('static uint8_t emu_flash[EMU_FLASH_SIZE];','''#ifdef TEENSY_NOR_ADDR                  /* teensy-fm1: real flash, in this ROM's slot */
extern int32_t teensy_nor_erase(uint32_t off);
extern int32_t teensy_nor_prog(uint32_t off, const uint8_t *src, uint32_t n);
#define emu_flash ((uint8_t *)TEENSY_NOR_ADDR)
#else
static uint8_t emu_flash[EMU_FLASH_SIZE];
#endif''')
s=s.replace('    memset(emu_flash + (off - EMU_FLASH_BASE), 0xFF, 4096u);','#ifdef TEENSY_NOR_ADDR\n    if (teensy_nor_erase(off - EMU_FLASH_BASE)) return -8;\n#else\n    memset(emu_flash + (off - EMU_FLASH_BASE), 0xFF, 4096u);\n#endif')
s=s.replace('    memcpy(emu_flash + (off - EMU_FLASH_BASE), src, n);','#ifdef TEENSY_NOR_ADDR\n    if (teensy_nor_prog(off - EMU_FLASH_BASE, src, n)) return -8;\n#else\n    memcpy(emu_flash + (off - EMU_FLASH_BASE), src, n);\n#endif')
open(p,'w').write(s)
p='ports/fm1quest/PORT.txt'; s=open(p).read().replace('nor 0','nor 0x70000'); open(p,'w').write(s)
