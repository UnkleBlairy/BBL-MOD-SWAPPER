import sys,re; sys.path.insert(0,'tools_night')
from mkshell import *
NOR='''#ifdef TEENSY_NOR_ADDR                  /* teensy-fm1: real flash, in this ROM's slot */
extern int32_t teensy_nor_erase(uint32_t off);
extern int32_t teensy_nor_prog(uint32_t off, const uint8_t *src, uint32_t n);
'''
LX='#define SH_KEY_LED(k) (web_lit_keys() >> (k) & 1u ? 2 : 0)\n#define SH_BTN_LED(i) (web_lit_buttons() >> sh_label(i) & 1u ? 2 : 0)\n'
mk('fm106','FM-106','1.02','FM106','emu/fm106_web.c','firmware/src firmware/gen firmware/hal','','FM106_WEB=1','web_screen()',X0X+KEYS+LX,boot='o_web_boot(); o_web_enc(2, 1);',master='o_web_master(m)',dirs='firmware emu')
p='ports/fm106/emu/fm106_web.c'; s=open(p).read()
s=s.replace('static uint8_t nor[0x100000];',NOR+'#define nor ((uint8_t *)TEENSY_NOR_ADDR)\n#define NOR_PUT(o, n, src, len) do { uint32_t e_; for (e_ = 0; e_ < (n); e_ += 4096u) teensy_nor_erase((o) + e_); teensy_nor_prog((o), (const uint8_t *)(src), (len)); } while (0)\n#else\nstatic uint8_t nor[0xA000];\n#define NOR_PUT(o, n, src, len) do { memset(nor + (o), 0xFF, (n)); memcpy(nor + (o), (src), (len)); } while (0)\n#endif')
s=s.replace('0xFC000u','0x9000u').replace('0x97000u','0u').replace('0x9C000u','0x8000u').replace('sizeof nor','0xA000u').replace('#define RING 4096u','#define RING 1024u')
s=re.sub(r'memset\(nor \+ (\w+), 0xFF, ([^;]*)\);\n\s*memcpy\(nor \+ \w+, src, n\);',r'NOR_PUT(\1, \2, src, n);',s)
s=s.replace('{ memset(nor, 0xFF, 0xA000u); }','{}')
open(p,'w').write(s)
p='ports/fm106/PORT.txt'; s=open(p).read().replace('nor 0','nor 0xA000'); open(p,'w').write(s)

os.makedirs('ports/_dl/tonitor/host_t',exist_ok=True)
h=open('ports/_dl/tonitor/tests/host/host.c').read()
h=h[:h.index('/* ------------------------------------------------------------- audio --- */')]
h=h.replace('static uint8_t host_flash[0x100000];',NOR+'#define host_flash ((uint8_t *)TEENSY_NOR_ADDR - SES_LO)\n#else\nstatic uint8_t host_flash_[SES_HI - SES_LO];\n#define host_flash (host_flash_ - SES_LO)\n#endif')
h=h.replace('    memset(host_flash + off, 0xFF, 4096u);','#ifdef TEENSY_NOR_ADDR\n    if (teensy_nor_erase(off - SES_LO)) return -8;\n#else\n    memset(host_flash + off, 0xFF, 4096u);\n#endif')
h=h.replace('    for (i = 0; i < n; i++)\n        host_flash[off + i] &=','#ifdef TEENSY_NOR_ADDR\n    (void)i; if (teensy_nor_prog(off - SES_LO, p, n)) return -8;\n#else\n    for (i = 0; i < n; i++)\n        host_flash[off + i] &=').replace('((const uint8_t *)p)[i];\n    return 0;','((const uint8_t *)p)[i];\n#endif\n    return 0;')
h=h.replace('        *rel = 0;','        *rel = host_rel, host_rel = 0;').replace('static uint32_t host_press;','static uint32_t host_press, host_rel;')
h+='''
static int32_t mix_out[2 * CTL];
static uint32_t ms_frac;
static void host_pump(void)
{
    mix_block(mix_out);
    ms_frac += CTL * 1000u;
    fm1_ms += ms_frac / 44100u;
    ms_frac %= 44100u;
}
static float ton_l[1024], ton_r[1024];
static float *ton_lp(void) { return ton_l; }
static float *ton_rp(void) { return ton_r; }
static void ton_render(uint32_t n)
{
    static uint32_t at = CTL;
    uint32_t i;
    for (i = 0; i < n; i++) {
        if (at >= CTL) { host_pump(); at = 0; }
        ton_l[i] = (float)clampi(mix_out[2u * at], -32768, 32767) / 32768.0f;
        ton_r[i] = (float)clampi(mix_out[2u * at + 1u], -32768, 32767) / 32768.0f;
        at++;
    }
}
static void ton_boot(void)
{
#ifndef TEENSY_NOR_ADDR
    memset(host_flash_, 0xFF, sizeof host_flash_);
#endif
    ses_scan(1);
    vo_init();
    setup_load();
    layers_init();
    ui_init();
    sounds_init();
    scale_draw();
    lx_post();
    lcd_fill(0, 0, 240, 240, 0);
    ui.force = 1;
}
static void ton_frame(void) { ui_input(); setup_poll(); midi_poll(); ui_leds(); ui_draw(); reader_tick(); }
'''
open('ports/_dl/tonitor/host_t/ton.c','w').write(h)
B='''#define SH_ENC(e, n) (host_enc[e] += (n))
#define SH_BTN(i, d) do { if (d) { fm1_in.buttons |= 1u << (i); host_press |= 1u << (i); } else { fm1_in.buttons &= ~(1u << (i)); host_rel |= 1u << (i); } } while (0)
#define SH_KEY(k, d) (fm1_in.notes = (fm1_in.notes & ~(1u << (k))) | (uint32_t)(d) << (k))
#define SH_KEY_LED(k) (host_led[14u + (k)] ? 2 : 0)
#define SH_BTN_LED(i) (host_led[i] ? 2 : 0)
'''
mk('tonitor','TONITOR','2026.11.10','TONITOR','host_t/ton.c','firmware/src firmware/hal build/gen','','','fb',B,boot='ton_boot();',be=1,render='ton_render',out='ton_lp ton_rp',master='(master_q12 = (int32_t)((m * m) >> 8))',dirs='firmware host_t build/gen')
p='ports/tonitor/web/emu/felucca_teensy.c'; s=open(p).read()
s=s.replace('{\n    const uint16_t *p = (const','{\n    ton_frame();\n    const uint16_t *p = (const'); open(p,'w').write(s)
p='ports/tonitor/PORT.txt'; s=open(p).read().replace('nor 0','nor 0x49000'); open(p,'w').write(s)
