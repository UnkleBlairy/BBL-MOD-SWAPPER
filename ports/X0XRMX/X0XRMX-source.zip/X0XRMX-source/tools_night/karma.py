import sys,glob,os; sys.path.insert(0,'tools_night')
from mkshell import *
LX='#define SH_KEY_LED(k) (web_lit_keys() >> (k) & 1u ? 2 : web_dim_keys() >> (k) & 1u ? 1 : 0)\n#define SH_BTN_LED(i) (web_lit_buttons() >> sh_label(i) & 1u ? 2 : web_dim_buttons() >> sh_label(i) & 1u ? 1 : 0)\n'
cc=sorted(os.path.relpath(f,'ports/_dl/karma') for f in glob.glob('ports/_dl/karma/firmware/mi/**/*.cc',recursive=True))
mk('karma','KARMA','3.1.6','KARMA','web/emu/sloop_web.c','build/gen firmware/src firmware/hal tests firmware/mi',' '.join(cc),'TEST=1','web_screen()',X0X+KEYS+LX,master='o_web_master(m)',dirs='firmware tests tools web/emu build/gen')
p='ports/karma/web/emu/sloop_web.c'; s=open(p).read().replace('#define RING 4096u','#define RING 1024u').replace('nor[0x100000]','nor[4]'); open(p,'w').write(s)
p='ports/karma/web/emu/felucca_teensy.c'; s=open(p).read()
s=s.replace('#define getenv(n)','#include <stdio.h>\n#ifdef __arm__\nstatic int teensy_noprint(const char *f, ...) { (void)f; return 0; }\n#define printf teensy_noprint\n#define puts(s) ((void)(s))\n#define exit(n) do { for (;;) ; } while (0)\n#endif\n#define getenv(n)',1); open(p,'w').write(s)
