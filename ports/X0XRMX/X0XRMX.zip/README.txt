X0X RMX 1.1.0 for the BBL Mod Swapper

Original by Mr-Roboto: https://github.com/Mr-Roboto/fm1-x0x-rmx
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.
MIDI: yes. The Teensy's USB is a MIDI port (in and out). The FM-1's MIDI jack as MIDI in comes with release 1.2.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: X0XRMX-source.zip on the ports page.
