GammaWave 1.2.1 for the BBL Mod Swapper

Original by fvalente: https://github.com/fvalente/GammaWave-FM1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: GAMMAWAV-source.zip on the ports page.
