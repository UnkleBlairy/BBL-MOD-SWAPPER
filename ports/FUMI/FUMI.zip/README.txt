FuMi-1 1.1.1 for the BBL Mod Swapper

Original by cartesive: https://github.com/cartesive/fumi-1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: FUMI-source.zip on the ports page.
