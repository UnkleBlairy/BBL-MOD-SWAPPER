/* SPDX-License-Identifier: GPL-3.0-only */
/* FuMi-1 UI: the panel and the screen. Part of the unity build (after gfx.c and project.c); the host
 * simulator includes it too. The control map (docs/research/00-START-HERE.md):
 *
 *   white keys     mi fa la ti do x 3 and a top mi (the ST-50's lower row)
 *   black keys     the upper row fa# sol ti-flat do# re, or ornaments (SEQ switches)
 *   SELECT 本数    PRESETS 音色 (voice)    ALGORITHM scale IN / YO / MIN'YO
 *   KNOB 1-4       the page's four values; HOME: 余韻, trill rate, vibrato depth, reverb
 *   LFO ビブラート   ARP トリラー   GLO 単音/和音 (hold: the trill pages)   SEL 調律 (tap: 平均律 / 純正律; hold: the tuning page)
 *   OCT- / OCT+    a note held: pitch bend down / up (sprung); none held: octave down / up
 *   HOME FX EDIT   the pages: HOME, SOUND, BEND.  ENV: the LOOP page.  SAVE saves (and it autosaves when quiet)
 *   REC            the looper (fumi.h): tap: arm (the first key starts the loop) / close / overdub on, off;
 *                  held 1 s: clear.   PLAY  tap: stop / start from the top; held 1 s: undo the top layer
 *   OCT- + OCT+ held 5 s: update mode (main_fm1.c; never reassigned) */

enum { V_HOME, V_SOUND, V_BEND, V_TUNING, V_LOOP, V_TRILL, V_TRILL2, NVIEWS };
static const char *const VIEW_NAME[NVIEWS] = {"Home", "Sound", "Bend", "Tuning", "Loop", "Trill", "Trill 2"};
#define K_NONE 255
static const uint8_t VIEW_KNOB[NVIEWS][4] = {
    {P_YOIN, P_TRILL_RATE, P_VIB_DEPTH, P_REVERB},
    {P_LOWCUT, P_HIGHCUT, P_CHARACTER, P_REV_SIZE},
    {P_BEND_UP, P_BEND_DOWN, P_BEND_TIME, P_SLIDE_TIME},
    {P_TUNING, P_DEPTH, P_FINE, P_A4},
    {P_LOOP_BPM, P_LOOP_BEATS, P_LOOP_CLICK, K_NONE},
    {P_TRILL_VAR, P_TRILL_PAIR, P_TRILL_TA, P_TRILL_OROSHI},   /* GLO held: the trill's feel and defaults (1.0.6) */
    {P_TRILL_FIRST, P_TRILL_JIT, K_NONE, K_NONE},             /* GLO held again: the second page */
};
#define HOLD_MS 1000u                              /* REC / PLAY held this long: clear / undo */

static const uint8_t WHITE_K[FM_NWHITE] = {0, 2, 4, 6, 7, 9, 11, 12, 14, 16, 18, 19, 21, 23, 24, 26};
static const uint8_t BLACK_K[FM_NBLACK] = {1, 3, 5, 8, 10, 13, 15, 17, 20, 22, 25};
/* ornament mode: what each black key does. The four techniques come twice, one set per hand position; the fifth
 * of each set and the eleventh are the koto's left hand (1.0.7): 押し手, 引き色, 後押し */
static const uint8_t BLACK_ORN[FM_NBLACK] = {ORN_VIB, ORN_TRILL, ORN_DAMP, ORN_STRONG, ORN_OSHIDE,
                                             ORN_VIB, ORN_TRILL, ORN_DAMP, ORN_STRONG, ORN_HIKIIRO, ORN_ATOOSHI};
static const char *const NOTE_NAME[12] = {"C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"};

/* the screen's colours: paper, ink, and one warm colour for what sounds */
#define K_BG RGB(250, 246, 236)
#define K_PANEL RGB(236, 229, 214)
#define K_LINE RGB(214, 204, 186)
#define K_DIM RGB(150, 138, 120)
#define K_TEXT RGB(64, 52, 44)
#define K_WHITE RGB(255, 255, 255)
#define K_KOTO RGB(196, 72, 48)
#define K_KOTO_T RGB(240, 200, 184)
#define K_TONIC RGB(120, 100, 80)

static struct {
    uint8_t view;
    uint32_t btn, keys, btn_used;
    uint32_t enc_t[NE];
    uint32_t sel_t;                    /* SEL pressed at (its hold opens the tuning page) */
    uint32_t glo_t;                    /* GLO pressed at (its hold opens the trill pages) */
    uint32_t hold_t[2];                /* REC, PLAY pressed at (held: clear, undo) */
    uint8_t oct_role[2];               /* OCT- / OCT+ while held: 0 up, 1 bend, 2 octave */
    uint8_t tuning_prev;               /* the 純正律 to come back to after a tap to 平均律 */
    uint8_t dirty;
    uint32_t act_t, saved_t;
    uint32_t loop_gen;                 /* the loop's generation last saved (fm_loop_gen) */
    uint32_t loop_retry_t;             /* a loop save failed: not before this (a minute), the setup saved meanwhile */
    char msg[2][24];
    uint32_t msg_until;
    int8_t touched;
    uint32_t touch_until;
    uint32_t frame;
    uint32_t sig[3];
} ui;

static void say(const char *a, const char *b)
{
    uint32_t i;
    for (i = 0; i < 23u && a && a[i]; i++)
        ui.msg[0][i] = a[i];
    ui.msg[0][i] = 0;
    for (i = 0; i < 23u && b && b[i]; i++)
        ui.msg[1][i] = b[i];
    ui.msg[1][i] = 0;
    ui.msg_until = plat_ms() + 1300u;
}
void ui_say(const char *a, const char *b) { say(a, b); }
int ui_dirty(void) { return ui.dirty != 0; }
static void mark_dirty(void) { ui.dirty = 1; }

static void itoa_u(uint32_t v, char *b)
{
    char t[12];
    int n = 0;
    do {
        t[n++] = (char)('0' + v % 10u);
        v /= 10u;
    } while (v);
    while (n)
        *b++ = t[--n];
    *b = 0;
}

/* ------------------------------------------------------------- values --- */
static void knob_set(int p, int v)
{
    const fm_param_t *pi = fm_param_info(p);
    v = v < pi->lo ? pi->lo : v > pi->hi ? pi->hi : v;
    if (v == proj.par[p])
        return;
    proj.par[p] = (int16_t)v;
    fm_set(p, v);
    mark_dirty();
}

/* knob acceleration by speed: a slow turn is one step a detent, a quick one up to 6 */
static uint8_t accel_off;              /* the host simulator's "spin": exact steps */
static int32_t accel(int role, int32_t s, int range)
{
    uint32_t now = plat_ms(), dt = now - ui.enc_t[role], a = (uint32_t)(s < 0 ? -s : s), m;
    ui.enc_t[role] = now;
    if (range <= 24 || !a || accel_off)
        return s;
    if (a > 1)
        dt /= a;
    m = dt < 15u ? 6u : dt < 30u ? 4u : dt < 60u ? 2u : 1u;
    return s * (int32_t)m;
}

static void turn(int role, int p, int32_t e)
{
    const fm_param_t *pi;
    if (!e || p == K_NONE)
        return;
    pi = fm_param_info(p);
    if (p == P_LOOP_BEATS) {                       /* four beats a detent (1.1.0: 4..256), landing on a multiple of four:
                                                    * a value between two (an older setup's) snaps the way the knob turns */
        int32_t v = proj.par[p];
        e = accel(role, e, (pi->hi - pi->lo) / 4);
        knob_set(p, (int)((e > 0 ? v / 4 + e : (v + 3) / 4 + e) * 4));
        return;
    }
    knob_set(p, proj.par[p] + accel(role, e, pi->hi - pi->lo));
}

static void toggle(int p, const char *what)
{
    knob_set(p, !proj.par[p]);
    say(what, proj.par[p] ? "ON" : "OFF");
}

/* ------------------------------------------------------------ buttons --- */
static void set_view(int v)
{
    ui.view = (uint8_t)v;
    ui.touched = -1;
}

static int any_key_held(void) { return (ui.keys & ((1u << NKEYS) - 1u)) != 0; }

static void oct_press(int which)                   /* which: 0 OCT-, 1 OCT+ (bend.h BEND_DOWN / BEND_UP) */
{
    if (ui.oct_role[!which]) {                     /* the other is held: reserved (update mode, main_fm1.c) */
        ui.oct_role[which] = 2;
        fm_bend(which, 1, 0);                      /* the engine lets its bend go */
        return;
    }
    if (any_key_held()) {
        ui.oct_role[which] = 1;
        fm_bend(which, 1, 1);
        return;
    }
    ui.oct_role[which] = 2;
    knob_set(P_OCTAVE, proj.par[P_OCTAVE] + (which ? 1 : -1));
    {
        char t[12];
        fm_param_text(P_OCTAVE, proj.par[P_OCTAVE], t);
        say("OCTAVE", t);
    }
}

static void oct_release(int which)
{
    if (ui.oct_role[which] == 1)
        fm_bend(which, 0, any_key_held());
    ui.oct_role[which] = 0;
}

/* The three selectors move one step at a time, at most one every SEL_STEP_MS: on the FM-1 a single click of
 * PRESETS sometimes arrived as two counts and skipped an instrument (1.0.2). A person clicks a detented
 * encoder at well under 16 a second, so nothing deliberate is lost; a count inside the window is dropped. */
#define SEL_STEP_MS 60u
static int32_t sel_step(int role)
{
    static uint32_t next[NE];                      /* when the next step may be taken (0: at once) */
    int32_t e = plat_enc(role);
    uint32_t now = plat_ms();
    if (e == 0)
        return 0;
    if ((int32_t)(now - next[role]) < 0)
        return 0;
    next[role] = now + SEL_STEP_MS;
    return e > 0 ? 1 : -1;
}

static void sel_tap(void)                          /* 調律: 平均律 <-> 純正律 (whichever was on) */
{
    if (proj.par[P_TUNING] == TN_EQUAL) {
        knob_set(P_TUNING, ui.tuning_prev ? ui.tuning_prev : TN_SUIKO);
    } else {
        ui.tuning_prev = (uint8_t)proj.par[P_TUNING];
        knob_set(P_TUNING, TN_EQUAL);
    }
    say("TUNING", TN_NAME[proj.par[P_TUNING]]);
}

static void loop_rec_tap(void)                     /* what the tap will do, said now; the engine does it */
{
    switch (fm_loop_state) {
    case LP_IDLE: say("LOOP", "ARMED: PLAY"); break;
    case LP_ARMED: say("LOOP", "CANCELLED"); break;
    case LP_REC: say("LOOP", "CLOSED"); break;
    case LP_DUB: say("OVERDUB", "OFF"); break;
    default: say("OVERDUB", "ON"); break;
    }
    fm_loop_rec();
}

static void loop_play_tap(void)
{
    switch (fm_loop_state) {
    case LP_IDLE: say("LOOP", "EMPTY"); return;
    case LP_ARMED: say("LOOP", "CANCELLED"); break;
    case LP_REC: say("LOOP", "CLOSED"); break;
    case LP_STOP: say("LOOP", "PLAYING"); break;
    default: say("LOOP", "STOPPED"); break;
    }
    fm_loop_play();
}

/* REC and PLAY held: the clear and the undo, each announced at 400 ms and done at HOLD_MS (the tap on release
 * is then not taken). Nothing to do: the hold is still used up, so the release does not arm or stop. */
static void loop_hold(int which, uint32_t now)     /* which: 0 REC, 1 PLAY */
{
    uint32_t b = which ? B_PLAY : B_REC, m = 1u << b, dt;
    if (!(ui.btn & m) || (ui.btn_used & m))
        return;
    dt = now - ui.hold_t[which];
    if (dt > HOLD_MS) {
        ui.btn_used |= m;
        if (which) {
            if (fm_loop_state == LP_REC)
                say("TAKE DROPPED", "ARMED");
            else if (fm_loop_layers > 1u)
                say("LOOP", "UNDONE");
            else
                say("LOOP", fm_loop_layers ? "EMPTIED" : "EMPTY");
            fm_loop_undo();
        } else {
            say("LOOP", fm_loop_state == LP_IDLE ? "EMPTY" : "CLEARED");
            fm_loop_clear();
        }
    } else if (dt > 400u && fm_loop_state != LP_IDLE) {
        say(which ? "UNDO?" : "CLEAR LOOP?", "KEEP HOLDING");
    }
}

static void button(int b)                          /* on release, unless the press was used */
{
    switch (b) {
    case B_HOME: set_view(V_HOME); break;
    case B_FX: set_view(V_SOUND); break;
    case B_EDIT: set_view(V_BEND); break;
    case B_ENV: set_view(V_LOOP); break;
    case B_REC: loop_rec_tap(); break;
    case B_PLAY: loop_play_tap(); break;
    case B_SEL: sel_tap(); break;
    case B_LFO: toggle(P_VIB_ON, "VIBRATO"); break;
    case B_ARP: toggle(P_TRILL_ON, "TRILL"); break;
    case B_GLO:
        knob_set(P_MONO, !proj.par[P_MONO]);
        say(proj.par[P_MONO] ? "MONO" : "POLY", proj.par[P_MONO] ? "(TANON)" : "(WAON)");
        break;
    case B_SEQ: {
        int i;
        knob_set(P_BLACK, !proj.par[P_BLACK]);
        for (i = 0; i < ORN_N; i++)                /* nothing stays held across the switch */
            fm_ornament(i, 0);
        for (i = 0; i < FM_NBLACK; i++)
            fm_key(FM_NWHITE + i, 0);
        say("BLACK KEYS", proj.par[P_BLACK] ? "ORNAMENTS" : "UPPER ROW");
        break;
    }
    case B_SAVE:
        if (project_save() == 0) {
            ui.dirty = 0;
            say("SAVED", 0);
        } else {
            say("NOT SAVED", "FLASH ERROR");
        }
        break;
    default: break;
    }
}

/* MIDI in (USB and the TRS jack): notes play the voice, chromatic, with their velocity (1.0.7) */
static void midi_in(void)
{
    uint32_t pkt;
    while (plat_midi_in(&pkt)) {
        uint32_t st = (pkt >> 8) & 0xF0u, n = (pkt >> 16) & 0x7Fu, v = pkt >> 24;
        if (st == 0x90u && v)
            fm_note_vel(FM_NOTE_ID + (int)n, 1, 100.0f * ((float)n - 69.0f), (int)v);
        else if (st == 0x80u || (st == 0x90u && !v))
            fm_note(FM_NOTE_ID + (int)n, 0, 0.0f);
        else if (st == 0xB0u && (n == 123u || n == 120u))
            fm_panic();
    }
}

static void black_key(int b, int on)
{
    if (proj.par[P_BLACK]) {
        if (BLACK_ORN[b] < ORN_N)
            fm_ornament(BLACK_ORN[b], on);
    } else {
        fm_key(FM_NWHITE + b, on);
    }
}

static void input(void)
{
    uint32_t btn = plat_buttons(), keys = plat_keys(), ch, i;
    int32_t e;
    ch = keys ^ ui.keys;
    ui.keys = keys;
    for (i = 0; i < FM_NWHITE; i++)                /* keys first: a glissando is the fastest thing here */
        if (ch >> WHITE_K[i] & 1u)
            fm_key((int)i, (int)(keys >> WHITE_K[i] & 1u));
    for (i = 0; i < FM_NBLACK; i++)
        if (ch >> BLACK_K[i] & 1u)
            black_key((int)i, (int)(keys >> BLACK_K[i] & 1u));
    ch = btn ^ ui.btn;
    ui.btn = btn;
    for (i = 0; i < NB; i++) {
        uint32_t m = 1u << i;
        if (!(ch & m))
            continue;
        if (btn & m) {
            ui.btn_used &= ~m;
            if (i == B_OCTDN || i == B_OCTUP)
                oct_press(i == B_OCTUP);
            else if (i == B_SEL)
                ui.sel_t = plat_ms();
            else if (i == B_GLO)
                ui.glo_t = plat_ms();
            else if (i == B_REC || i == B_PLAY)
                ui.hold_t[i == B_PLAY] = plat_ms();
        } else if (i == B_OCTDN || i == B_OCTUP) {
            oct_release(i == B_OCTUP);
        } else if (!(ui.btn_used & m)) {
            button((int)i);
        }
    }
    if ((btn >> B_SEL & 1u) && !(ui.btn_used >> B_SEL & 1u) && plat_ms() - ui.sel_t > 400u) {
        ui.btn_used |= 1u << B_SEL;                /* SEL held: the tuning page, no toggle on release */
        set_view(V_TUNING);
    }
    if ((btn >> B_GLO & 1u) && !(ui.btn_used >> B_GLO & 1u) && plat_ms() - ui.glo_t > 400u) {
        ui.btn_used |= 1u << B_GLO;                /* GLO held: the trill page; held again: its second page */
        set_view(ui.view == V_TRILL ? V_TRILL2 : V_TRILL);
    }
    loop_hold(0, plat_ms());
    loop_hold(1, plat_ms());
    if (btn || keys || ch)
        ui.act_t = plat_ms();
    midi_in();
    if ((e = sel_step(EN_SELECT)) != 0)            /* a detent is a step: no acceleration on these three */
        knob_set(P_HON, proj.par[P_HON] + e);
    if ((e = sel_step(EN_PRESET)) != 0)          /* PRESETS picks the instrument, as players expect */
        knob_set(P_VOICE, proj.par[P_VOICE] + e);
    if ((e = sel_step(EN_ALGO)) != 0)
        knob_set(P_SCALE, proj.par[P_SCALE] + e);
    for (i = 0; i < 4; i++)
        if ((e = plat_enc(EN_K1 + (int)i)) != 0) {
            turn(EN_K1 + (int)i, VIEW_KNOB[ui.view][i], e);
            ui.touched = (int8_t)i;
            ui.touch_until = plat_ms() + 1200u;
            ui.act_t = plat_ms();
        }
}

/* ------------------------------------------------------------- screen --- */
#define HDR_H 28
#define MAIN_Y 28
#define MAIN_H 144
#define KNB_Y 172
#define KNB_H 68

static uint32_t hash(uint32_t h, uint32_t v) { return (h ^ v) * 16777619u; }

static void cv_round(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c)
{
    static const uint8_t IN[7][6] = {{0}, {1}, {1, 0}, {2, 1, 0}, {2, 1, 0, 0}, {3, 2, 1, 0, 0}, {4, 2, 1, 1, 0, 0}};
    int32_t j;
    if (r > 6)
        r = 6;
    if (r > h / 2)
        r = h / 2;
    cv_rect(x, y + r, w, h - 2 * r, c);
    for (j = 0; j < r; j++) {
        int32_t d = IN[r][j];
        cv_rect(x + d, y + j, w - 2 * d, 1, c);
        cv_rect(x + d, y + h - 1 - j, w - 2 * d, 1, c);
    }
}

static void text_c(int32_t cx, int32_t y, const felucca_font_t *f, const char *s, uint16_t c)
{
    cv_text(cx - text_w(f, s) / 2, y, f, s, c);
}

static uint16_t mix(uint16_t a, uint16_t b, int t)   /* t 0..16: a -> b */
{
    int r = ((a >> 11) * (16 - t) + (b >> 11) * t) / 16, g = (((a >> 5) & 63) * (16 - t) + ((b >> 5) & 63) * t) / 16,
        bl = ((a & 31) * (16 - t) + (b & 31) * t) / 16;
    return (uint16_t)(r << 11 | g << 5 | bl);
}

static void draw_header(void)
{
    int msg = plat_ms() < ui.msg_until;
    int oroshi = proj.par[P_BLACK] && proj.par[P_TRILL_OROSHI];   /* 颪 set: the trill key rolls (shown in ornament mode) */
    uint32_t h = hash(hash(2166136261u, ui.view), (uint32_t)proj.par[P_VIB_ON] | (uint32_t)proj.par[P_TRILL_ON] << 1 |
                                                   (uint32_t)proj.par[P_MONO] << 2 | (uint32_t)proj.par[P_BLACK] << 3 |
                                                   (uint32_t)ui.dirty << 4 | (uint32_t)msg << 5 | (uint32_t)fm_loop_state << 6 |
                                                   (uint32_t)oroshi << 9);
    if (msg)
        h = hash(hash(h, (uint32_t)ui.msg[0][0] << 8 | ui.msg[0][1]), ui.msg_until);
    if (h == ui.sig[0])
        return;
    ui.sig[0] = h;
    cv_begin(240, HDR_H, K_BG);
    if (msg) {
        int32_t x = cv_text(10, 6, &FONT_B, ui.msg[0], K_TEXT);
        cv_text(x + 8, 6, &FONT_B, ui.msg[1], K_KOTO);
    } else {
        static const char *const TAG[4] = {"VIB", "TRILL", "MONO", "ORN"};
        static const char *const LTAG[LP_NSTATE] = {"", "ARM", "REC", "LOOP", "DUB", "STOP"};
        int on[4] = {proj.par[P_VIB_ON], proj.par[P_TRILL_ON], proj.par[P_MONO], proj.par[P_BLACK]}, i;
        const char *title = ui.view == V_HOME ? "FuMi-1" : VIEW_NAME[ui.view];
        int32_t x = 10, left = 10 + text_w(&FONT_B, title) + 8;   /* tags never run into the title: the rest are dropped */
        cv_text(x, 6, &FONT_B, title, K_TEXT);
        x = 232;
        if (fm_loop_state != LP_IDLE) {            /* the looper, rightmost: red while it records */
            int rec = fm_loop_state == LP_REC || fm_loop_state == LP_DUB;
            int32_t w = text_w(&FONT_XS, LTAG[fm_loop_state]) + 10;
            x -= w + 4;
            cv_round(x, 6, w, 16, 6, rec ? K_KOTO : K_KOTO_T);
            cv_text(x + 5, 7, &FONT_XS, LTAG[fm_loop_state], rec ? K_WHITE : K_KOTO);
        }
        if (oroshi) {                              /* 颪 beside the looper's tag: the trill ornament key starts slow */
            int32_t w = text_w(&FONT_JP, FM_KANJI_OROSHI) + 8;
            x -= w + 4;
            cv_round(x, 5, w, 18, 6, K_KOTO_T);
            cv_text(x + 4, 5, &FONT_JP, FM_KANJI_OROSHI, K_KOTO);
        }
        for (i = 3; i >= 0; i--) {
            int32_t w = text_w(&FONT_XS, TAG[i]) + 10;
            if (!on[i])
                continue;
            if (x - w - 4 < left)
                break;
            x -= w + 4;
            cv_round(x, 6, w, 16, 6, K_KOTO_T);
            cv_text(x + 5, 7, &FONT_XS, TAG[i], K_KOTO);
        }
        if (ui.dirty)
            cv_round(x - 10, 12, 5, 5, 2, K_DIM);
    }
    cv_blit(0, 0);
}

#define K_TAN RGB(222, 186, 138)                  /* the panel's tan caps on mi, la and ti of the main register */
static const uint8_t BLACK_GAP[FM_NBLACK] = {0, 1, 2, 4, 5, 7, 8, 9, 11, 12, 14};   /* upper key j sits over the gap after white key BLACK_GAP[j] */
static const uint8_t TAN_CAP[FM_NWHITE] = {0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0};   /* ラ乙 シ一 ミ三 ラ五 シ六 (docs/research/10) */

static void draw_keys(int32_t y_upper, int32_t y_lower)
{   /* the ST-50's two rows of round keys (1.0.8): sixteen below, eleven above sitting between them; a key lights
     * with its voice; the panel's tan caps on the frame notes of the main register */
    int k;
    for (k = 0; k < FM_NBLACK; k++) {
        int t = (int)(fm_key_level[FM_NWHITE + k] * 16.0f + 0.5f), x = 13 + BLACK_GAP[k] * 14;
        cv_round(x - 1, y_upper - 1, 14, 14, 6, K_LINE);
        cv_round(x, y_upper, 12, 12, 6, mix(K_PANEL, K_KOTO, t > 16 ? 16 : t));
    }
    for (k = 0; k < FM_NWHITE; k++) {
        int t = (int)(fm_key_level[k] * 16.0f + 0.5f), x = 6 + k * 14;
        cv_round(x - 1, y_lower - 1, 14, 14, 6, K_LINE);
        cv_round(x, y_lower, 12, 12, 6, mix(TAN_CAP[k] ? K_TAN : K_WHITE, K_KOTO, t > 16 ? 16 : t));
    }
}

static void draw_voice_slider(int32_t y)
{   /* the 音色 strip (1.0.8): a notch per instrument in PRESETS order, a wider gap where the family changes, the one
     * playing filled; the name in large type above says which */
    int n = fm_patch_count(), i;
    int32_t x = 12;
    for (i = 0; i < n; i++) {
        if (i && fm_patch_family(i) != fm_patch_family(i - 1))
            x += 5;
        if (i == proj.par[P_VOICE] && !fm_patch_custom)
            cv_round(x - 1, y - 1, 5, 9, 2, K_KOTO);
        else
            cv_rect(x, y, 3, 7, K_LINE);
        x += 9;
    }
}

static uint32_t loop_max_blocks(void)            /* the ruler: beats x 60 / BPM, in blocks of 32 (as the engine) */
{
    uint32_t b = (uint32_t)(60.0f * 44100.0f / 32.0f * (float)proj.par[P_LOOP_BEATS] / (float)proj.par[P_LOOP_BPM]);
    return b ? b : 1u;
}

static void draw_main(void)
{
    char t[16];
    uint32_t h = hash(2166136261u, ui.view), s;
    int i;
    for (s = 0; s < FM_NKEY; s++)
        h = hash(h, (uint32_t)(fm_key_level[s] * 24.0f));
    uint32_t lp_state = fm_loop_state, lp_len = fm_loop_len, lp_pos = fm_loop_pos, lp_q;   /* one read each */
    lp_q = lp_state == LP_REC || lp_state == LP_ARMED ? lp_pos * 54u / loop_max_blocks() : lp_len ? lp_pos * 54u / lp_len : 0u;
    if (lp_q > 54u)
        lp_q = 54u;
    h = hash(hash(h, (uint32_t)proj.par[P_HON] | (uint32_t)proj.par[P_VOICE] << 8 | (uint32_t)proj.par[P_TUNING] << 16 |
                          (uint32_t)proj.par[P_SCALE] << 20 | (uint32_t)(proj.par[P_OCTAVE] + 1) << 24),
             (uint32_t)(fm_bend_cents * 4.0f + 1000.0f) | (uint32_t)fm_patch_custom << 16 | lp_state << 20 | lp_q << 24);
    for (s = 0; s < 10u && fm_patch_label[s]; s++)   /* the whole name: the render adopts a patch a frame after the
                                                      * slot changes, and Sho and Shakuhachi start alike (1.0.3) */
        h = hash(h, (uint32_t)fm_patch_label[s] | s << 8);
    if (h == ui.sig[1])
        return;
    ui.sig[1] = h;
    cv_begin(240, MAIN_H, K_BG);
    {   /* 本数, big, with the note 三 sounds; the voice; the tuning and the scale */
        int san = 53 + proj.par[P_HON] + 12 * proj.par[P_OCTAVE];
        int32_t x = 12;
        x = cv_text(x, 2, &FONT_L, TN_HON_ASCII[proj.par[P_HON]], K_TEXT);
        cv_text(x + 4, 20, &FONT_XS, "HON", K_DIM);
        t[0] = 0;
        {
            const char *n = NOTE_NAME[((san % 12) + 12) % 12];
            int k = 0;
            while (*n)
                t[k++] = *n++;
            t[k++] = (char)('0' + (san / 12 - 1));
            t[k] = 0;
        }
        cv_text(x + 4, 4, &FONT_S, t, K_DIM);
        if (fm_bend_cents != 0.0f) {           /* the bend: a small dial beside the key number */
            int32_t cx = 110, bw = (int32_t)(fm_bend_cents * 0.16f);
            cv_round(cx - 20, 14, 40, 6, 3, K_LINE);
            cv_round(bw < 0 ? cx + bw : cx, 14, (bw < 0 ? -bw : bw) + 4, 6, 3, K_KOTO);
        }
        {   /* the tuning and the scale, top right */
            char line[40];
            int k = 0;
            const char *a = TN_NAME[proj.par[P_TUNING]], *b = SC_NAME[proj.par[P_SCALE]];
            while (*a)
                line[k++] = *a++;
            line[k++] = ' ';
            line[k++] = '/';
            line[k++] = ' ';
            while (*b)
                line[k++] = *b++;
            line[k] = 0;
            cv_text(240 - 12 - text_w(&FONT_XS, line), 6, &FONT_XS, line, K_DIM);
        }
    }
    {   /* the instrument, large: its name at the left in the biggest face that fits, its kanji at the right
         * (Suiko-style), both centred on the band y 34..82; a name of four characters or more takes the smaller
         * face (1.0.8: クラリネット); a patch sent from outside has no kanji */
        const char *name = (const char *)fm_patch_label, *ja = fm_patch_custom ? "" : FM_PATCH_JA_LCD[proj.par[P_VOICE]];
        const felucca_font_t *jf = ja[0] && ja[1] && ja[2] && ja[3] ? &FONT_JPM : &FONT_JPL;
        int32_t jw = *ja ? text_w(jf, ja) : 0, room = 240 - 24 - (jw ? jw + 10 : 0);
        const felucca_font_t *f = text_w(&FONT_L, name) <= room ? &FONT_L : text_w(&FONT_M, name) <= room ? &FONT_M : &FONT_B;
        cv_text(12, 58 - f->h / 2, f, name, fm_patch_custom ? K_KOTO : K_TEXT);
        if (jw)
            cv_text(240 - 12 - jw, 58 - jf->h / 2, jf, ja, K_TEXT);
    }
    draw_keys(86, 100);
    for (i = 0; i < FM_NWHITE; i++)              /* the panel's names under the lower keys: 水 乙 一 二 三 三′ 五 六 七 八, 三 the reference */
        if (FM_KANJI_KEY_LABEL[i][0])
            text_c(12 + i * 14, 114, &FONT_JPS, FM_KANJI_KEY_LABEL[i], i == 5 ? K_TEXT : K_DIM);
    draw_voice_slider(131);
    if (lp_state != LP_IDLE) {                   /* the loop: where it is in its length (recording: in the ruler's) */
        int rec = lp_state == LP_REC || lp_state == LP_DUB;
        cv_round(12, 141, 216, 3, 1, K_LINE);
        cv_round(12, 141, (int32_t)(lp_q * 4u) + 4, 3, 1, rec ? K_KOTO : lp_state == LP_STOP ? K_DIM : K_TONIC);
    }
    cv_blit(0, MAIN_Y);
}

static void draw_knobs(void)
{
    uint32_t h = hash(2166136261u, ui.view | (uint32_t)ui.touched << 8), i;
    int now_touch = plat_ms() < ui.touch_until;
    for (i = 0; i < 4; i++)
        h = hash(h, (uint32_t)proj.par[VIEW_KNOB[ui.view][i]]);
    h = hash(h, (uint32_t)now_touch);
    if (h == ui.sig[2])
        return;
    ui.sig[2] = h;
    cv_begin(240, KNB_H, K_BG);
    cv_round(4, 2, 232, KNB_H - 6, 6, K_PANEL);
    for (i = 0; i < 4; i++) {
        int p = VIEW_KNOB[ui.view][i], lo, hi, v;
        const fm_param_t *pi;
        int32_t x = (int32_t)i * 60, cx = x + 30, bw;
        int hot = now_touch && ui.touched == (int)i;
        char t[16];
        if (p == K_NONE) {
            if (ui.view == V_LOOP && i == 3) {     /* the ruler's length as a time (1.1.0): 256 beats at 20 read as 12:48 */
                cv_rect(x, 14, 1, KNB_H - 30, K_LINE);
                text_c(cx, 6, &FONT_XS, "Length", K_DIM);
                fm_loop_ruler_text(proj.par[P_LOOP_BPM], proj.par[P_LOOP_BEATS], t);
                text_c(cx, 22, &FONT_M, t, K_TEXT);
            }
            continue;
        }
        pi = fm_param_info(p);
        lo = pi->lo;
        hi = pi->hi;
        v = proj.par[p];
        if (i)
            cv_rect(x, 14, 1, KNB_H - 30, K_LINE);
        text_c(cx, 6, &FONT_XS, pi->name, hot ? K_TEXT : K_DIM);
        fm_param_text(p, v, t);
        {
            const char *q = t;
            int lower = 0;
            for (; *q; q++)
                lower |= *q >= 'a' && *q <= 'z';
            if (lower || text_w(&FONT_M, t) > 56)
                text_c(cx, 26, &FONT_B, t, hot ? K_KOTO : K_TEXT);
            else
                text_c(cx, 22, &FONT_M, t, hot ? K_KOTO : K_TEXT);
        }
        bw = hi > lo ? (int32_t)(44 * (v - lo) / (hi - lo)) : 0;
        cv_round(cx - 22, 50, 44, 6, 3, K_LINE);
        if (lo < 0) {
            int32_t m = cx - 22 + 44 * (0 - lo) / (hi - lo), e = cx - 22 + bw;
            cv_round(e < m ? e : m, 50, (e < m ? m - e : e - m) + 6, 6, 3, hot ? K_KOTO : K_TONIC);
        } else if (bw) {
            cv_round(cx - 22, 50, bw < 6 ? 6 : bw, 6, 3, hot ? K_KOTO : K_TONIC);
        }
    }
    cv_blit(0, KNB_Y);
}

static void leds(void)
{
    uint32_t b = 0, k = 0, i;
    static const uint8_t VIEW_BTN[NVIEWS] = {B_HOME, B_FX, B_EDIT, B_SEL, B_ENV, B_GLO, B_GLO};
    uint32_t lp = fm_loop_state;
    b |= 1u << VIEW_BTN[ui.view];
    if (lp == LP_REC || lp == LP_DUB || (lp == LP_ARMED && (plat_ms() / 250u) & 1u))   /* REC: lit, blinking when armed */
        b |= 1u << B_REC;
    if (lp == LP_PLAY || lp == LP_DUB)
        b |= 1u << B_PLAY;
    plat_play_red(lp == LP_REC || lp == LP_DUB);
    if (proj.par[P_VIB_ON])
        b |= 1u << B_LFO;
    if (proj.par[P_TRILL_ON])
        b |= 1u << B_ARP;
    if (proj.par[P_MONO])
        b |= 1u << B_GLO;
    if (proj.par[P_BLACK])
        b |= 1u << B_SEQ;
    if (proj.leds) {
        for (i = 0; i < FM_NWHITE; i++)
            if (fm_key_level[i] > 0.15f || (i % 5) == 0)   /* the tonics: landmarks, always lit */
                k |= 1u << WHITE_K[i];
        for (i = 0; i < FM_NBLACK; i++)
            if (fm_key_level[FM_NWHITE + i] > 0.15f)
                k |= 1u << BLACK_K[i];
    }
    plat_glow(proj.leds == 1);
    plat_leds(b, k);
}

/* AUTOSAVE: a few seconds after a change, when nothing sounds and nothing is touched (a flash erase
 * silences the audio for a moment) */
#define AUTOSAVE_QUIET 4000u
static void autosave(void)
{
    uint32_t now = plat_ms();
    if (ui.btn || ui.keys || now - ui.act_t < AUTOSAVE_QUIET || fm_nvoices)
        return;
    if (fm_loop_state != LP_IDLE && fm_loop_state != LP_STOP)
        return;                                    /* the loop is running: a flash erase would silence it */
    if (fm_loop_gen != ui.loop_gen && (int32_t)(now - ui.loop_retry_t) >= 0) {   /* the loop, stopped and changed: its own
                                                                                 * object (1.1.0); one erase a pass */
        uint32_t g;
        if (loop_save(&g) == 0) {
            ui.loop_gen = g;                       /* the generation the image was of: a change during the write is not lost */
            return;
        }
        ui.loop_retry_t = now + 60000u;            /* failed: the setup's save goes on; the loop again in a minute */
        say("LOOP", "NOT SAVED");
    }
    if (!ui.dirty)
        return;
    if (project_save() == 0) {
        ui.dirty = 0;
        ui.saved_t = now;
    }
}

void ui_init(void)
{
    memset(&ui, 0, sizeof ui);
    ui.touched = -1;
    ui.tuning_prev = TN_SUIKO;
    ui.loop_gen = fm_loop_gen;                     /* what loop_load brought back is saved already */
    lcd_fill(0, 0, 240, 240, K_BG);
}

void ui_reinit(void)
{
    uint32_t g = ui.loop_gen;
    ui_init();
    ui.loop_gen = g;
}

void ui_frame(void)
{
    input();
    autosave();
    draw_header();
    draw_main();
    draw_knobs();
    leds();
    ui.frame++;
}

void ui_input_only(void) { input(); }
