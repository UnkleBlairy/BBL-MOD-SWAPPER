/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* The few libc routines the compiler may call implicitly (struct copies,
 * zeroing). Freestanding: no other libc. */
typedef unsigned __attribute__((may_alias)) word_t;   /* (a word that may alias anything: no strict-aliasing surprise) */
void *memset(void *d, int c, unsigned n)   /* (a word at a time once aligned: the effects' memories, 150 KB, are emptied in the audio interrupt) */
{
    unsigned char *p = d;
    unsigned w = (unsigned char)c * 0x01010101u;
    while (n && ((unsigned long)p & 3u)) { *p++ = (unsigned char)c; n--; }
    for (; n >= 16u; n -= 16u, p += 16) { ((word_t *)p)[0] = w; ((word_t *)p)[1] = w; ((word_t *)p)[2] = w; ((word_t *)p)[3] = w; }
    for (; n >= 4u; n -= 4u, p += 4) *(word_t *)p = w;
    while (n--) *p++ = (unsigned char)c;
    return d;
}

void *memcpy(void *d, const void *s, unsigned n)
{
    unsigned char *p = d;
    const unsigned char *q = s;
    if (!(((unsigned long)p | (unsigned long)q) & 3u))   /* (both aligned: a word at a time) */
        for (; n >= 4u; n -= 4u, p += 4, q += 4) *(word_t *)p = *(const word_t *)q;
    while (n--)
        *p++ = *q++;
    return d;
}

int memcmp(const void *a, const void *b, unsigned n)
{
    const unsigned char *p = a, *q = b;
    for (; n; n--, p++, q++)
        if (*p != *q)
            return *p - *q;
    return 0;
}

static int str_eq(const char *a, const char *b)
{
    while (*a && *a == *b) {
        a++;
        b++;
    }
    return *a == *b;
}

static unsigned str_len(const char *s)
{
    unsigned n = 0;
    while (s[n])
        n++;
    return n;
}

static void str_cpy(char *d, const char *s, unsigned max)
{
    unsigned i = 0;
    while (s[i] && i + 1 < max) {
        d[i] = s[i];
        i++;
    }
    d[i] = 0;
}

/* decimal with an optional fixed point: fmt_fix(buf, -63, 1) -> "-6.3" */
static void fmt_fix(char *b, int32_t v, int decimals)
{
    char t[12];
    int n = 0, neg = v < 0, i;
    uint32_t u = (uint32_t)(neg ? -v : v);
    do {
        t[n++] = (char)('0' + u % 10u);
        u /= 10u;
        if (n == decimals)
            t[n++] = '.';
    } while (u || n <= decimals);
    if (neg)
        t[n++] = '-';
    for (i = 0; i < n; i++)
        b[i] = t[n - 1 - i];
    b[n] = 0;
}

static void fmt_int(char *b, int32_t v) { fmt_fix(b, v, 0); }

static uint32_t rng_state = 0x1234567u;
static uint32_t rng(void)
{
    rng_state ^= rng_state << 13;
    rng_state ^= rng_state >> 17;
    rng_state ^= rng_state << 5;
    return rng_state;
}
