/* SPDX-License-Identifier: GPL-3.0-only */
/* The FM-1 in a browser: K-WASUB (as KAWA) compiled to WebAssembly (clang --target=wasm32, no libc). platform.c
 * includes this file instead of the hardware when KAWA_WASM is set. The page's audio worklet runs it:
 * ksub_audio() renders 256 frames (the audio interrupt) and moves the clock, ksub_step() is one pass of
 * the main loop; the keys, buttons and knobs come in through ksub_keys / ksub_button / ksub_turn, the
 * screen (240 x 240 RGB565) and the LEDs go out through ksub_screen / ksub_leds. */
#include <stdint.h>
#define WASM_EXPORT(name) __attribute__((export_name(name)))

#ifndef APP_NAME
#define APP_NAME "K-WASUB"
#endif
#ifndef APP_VER
#define APP_VER "0.0"
#endif
#define FS 44100u
#define HALF_FRAMES 256u
#define FM1_TICKS_PER_US 24u
#define RING_PUBLISH() ((void)0)
#define STORE_LO 0x00097000u
#define STORE_HI 0x000E0000u
#define memset din_memset
#define memcpy din_memcpy
#define memcmp din_memcmp
#define memmove din_memmove
#pragma GCC push_options
#pragma GCC optimize("no-tree-loop-distribute-patterns")
#include "libc.c"
#pragma GCC pop_options
#undef memset
#undef memcpy
#undef memcmp
#undef memmove

static volatile uint32_t fm1_ms;
static uint64_t wasm_frames;
static struct { uint32_t notes, buttons; } fm1_in;
/* teensy-fm1: the panel and the screen are the Teensy's */
static uint32_t din_press, din_rel, din_nedge, din_px;
static int32_t din_enc[8];
static uint8_t din_led[64], din_glow[64];
static uint32_t fm1_input_edges(uint32_t *released) { uint32_t b = din_press; din_press = 0; if (released) *released = din_rel; din_rel = 0; return b; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = din_nedge; din_nedge = 0; return e; }
static int32_t fm1_enc_take(uint32_t e) { int32_t v = din_enc[e & 7u]; din_enc[e & 7u] = 0; return v; }
static void fm1_led_key(uint32_t id, int on) { din_led[id & 63u] = (uint8_t)!!on; }
static void host_leds(const uint8_t *w) { uint32_t i; for (i = 0; i < 41u; i++) { din_led[i] = w[i] > 1u; din_glow[i] = w[i] == 1u; } }
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            sh_put(j * 240u + i, sh_be16(c));
    din_px += w * h;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            sh_put((y + j) * 240u + x + i, px[j * w + i]);      /* (gfx.c's pixels are high byte first already) */
    din_px += w * h;
}

static uint32_t w_pressed, w_released, w_note_edges;
static int32_t w_enc[7];
static uint8_t w_leds[41];
static uint32_t w_screen_gen;
static int32_t w_master = 3000;                 /* Q12 */
static uint32_t fm1_ticks(void) { return (uint32_t)(wasm_frames * 544u); }   /* 24 MHz from the frames */





#define fb shl_fb


#define CV_MAX (240u * 64u)
#include "gfx.c"

/* USB-MIDI in from the page (Web MIDI) */
static uint8_t mq[64][3];
static uint32_t mq_w, mq_r;
static int midi_get(uint8_t *st, uint8_t *d1, uint8_t *d2)
{
    if (mq_r == mq_w) return 0;
    *st = mq[mq_r % 64u][0]; *d1 = mq[mq_r % 64u][1]; *d2 = mq[mq_r % 64u][2];
    mq_r++;
    return 1;
}
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2) { (void)st; (void)d1; (void)d2; }
static uint8_t w_settings[260];
static int settings_load(void *p, uint32_t n)   /* (as platform.c: the length saved must be n) */
{
    if (!w_settings[0] || n > 256u || w_settings[1] != n) return -1;
    memcpy(p, w_settings + 4, n);
    return 0;
}
static uint32_t w_settings_gen;
static int settings_save(const void *p, uint32_t n) { w_settings[0] = 1; w_settings[1] = (uint8_t)n; memcpy(w_settings + 4, p, n); w_settings_gen++; return 0; }
static void app_poll(void);


static void app_audio(int32_t *out, uint32_t n);
