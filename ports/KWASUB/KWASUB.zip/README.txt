K-WASUB 1.2.7b for the BBL Mod Swapper

Original by Guizmoh: https://github.com/Guizmoh/K-WASUB_Firmware_for_FM1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: KWASUB-source.zip on the ports page.
