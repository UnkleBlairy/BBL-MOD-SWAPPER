SPAMPY 1.2-r080 for the BBL Mod Swapper

Original by Spampy-Droid: https://github.com/Spampy-Droid/SPAMPY-0.0-r949
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: SPAMPY-source.zip on the ports page.
