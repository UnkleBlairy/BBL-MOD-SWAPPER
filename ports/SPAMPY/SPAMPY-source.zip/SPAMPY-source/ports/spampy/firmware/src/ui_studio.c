/* SPDX-License-Identifier: GPL-3.0-only */
/* LIVE screens, 240 x 240, in a teenage-engineering-like style: black, four colours (one per
 * track and per knob: blue, green, yellow, orange), white for what you touch, red for recording,
 * big numbers, lowercase labels, four dials at the bottom that show what KNOB 1..4 do.
 * Screens: TRACKS (the performance view), DRUMS (GRID / KIT, pads that flash on each hit), the
 * LAYERS (a function button held: what the 16 white keys and the knobs do now), HOLD (a hold to
 * confirm: clear, save), REC (armed / free take). Every band is drawn into the canvas only when its
 * signature changed. */
static uint8_t drum_page, drum_lane, drum_cursor;   /* drum_page: 0 GRID, 1 KIT, 2 SOUND (2.7: a sound's TUNE, DECAY) */
static void trk_short_name(uint32_t c, char *b);
UI_SMALL static int on_drum_page(void) { return !ui.home && cur_page()->scope == SC_DRUM; }

/* ---------------------------------------------------------------- style --- */
/* TE_G1 .. TE_G4: the greys (tiles, empty steps, labels, secondary text), gfx.c (2.7: on a theme's background) */
#define TE_RED RGB(255, 44, 52)          /* recording, erasing */
/* TE_COL, TE_MID, TE_DIM: the tracks' colours, gfx.c (2.7: a theme may set them) */
#define TE_DRUM TE_COL[3]

UI_SMALL static void te_disc(int32_t cx, int32_t cy, int32_t r, uint16_t c)     /* filled circle */
{
    int32_t y, x;
    for (y = -r; y <= r; y++)
        for (x = -r; x <= r; x++)
            if (x * x + y * y <= r * r + r)
                cv_pset(cx + x, cy + y, c);
}
/* a dial: a 270-degree ring (lit up to the value), a pointer; ratio 0..1000, -1 = a plain ring */
UI_SMALL static void te_dial(int32_t cx, int32_t cy, int32_t r, int32_t ratio, uint16_t c, uint16_t dim)
{
    int32_t i, end = ratio < 0 ? 768 : ratio * 768 / 1000;
    for (i = 0; i <= 768; i += 8) {
        uint32_t a = (uint32_t)(384 + i) & 1023u;
        int32_t co = SINE[(a + 256u) & 1023u], si = SINE[a], k;
        uint16_t col = ratio < 0 || i <= end ? c : dim;
        for (k = r - 2; k <= r; k++)
            cv_pset(cx + ((co * k) >> 15), cy + ((si * k) >> 15), col);
    }
    if (ratio >= 0) {
        uint32_t a = (uint32_t)(384 + end) & 1023u;
        int32_t co = SINE[(a + 256u) & 1023u], si = SINE[a];
        cv_line(cx, cy, cx + ((co * (r - 4)) >> 15), cy + ((si * (r - 4)) >> 15), C_WHITE);
        te_disc(cx, cy, 2, C_WHITE);
    }
}
UI_SMALL static void te_play_icon(int32_t x, int32_t y, int playing)
{
    int32_t i;
    if (playing)
        for (i = 0; i < 12; i++)
            cv_rect(x + i, y + i / 2, 1, 14 - i, C_WHITE);   /* a triangle */
    else
        cv_rect(x, y + 1, 12, 12, TE_G3);
}
UI_SMALL static uint32_t studio_hash(uint32_t h, const char *p)
{ while (*p) h = h * 31u + (uint8_t)*p++; return h; }
UI_SMALL static void te_lower(char *d, const char *s, uint32_t n)
{
    uint32_t i;
    for (i = 0; i + 1u < n && s[i]; i++)
        d[i] = s[i] >= 'A' && s[i] <= 'Z' ? (char)(s[i] + 32) : s[i];
    d[i] = 0;
}

/* Copyright (c) 2012 Brian J. Bonislawsky DBA Astigmatic (AOETI).
 * Typeface glyph data under SIL Open Font License 1.1; see LICENSES/OFL-Audiowide.txt.
 * Rasterized from the selected 80s display typeface for the FM-1 LCD. */
static const uint8_t aw_width[46] = {
    5, 13, 5, 11, 10, 11, 11, 10, 9, 10, 10, 12, 11, 10, 12, 11,
    10, 12, 12, 4, 10, 11, 10, 13, 12, 12, 11, 12, 12, 11, 10, 12,
    11, 14, 11, 11, 10, 8, 10, 9, 8, 3, 9, 3, 6, 6,
};
static const uint32_t aw_off[46] = {
    0, 50, 180, 230, 340, 440, 550, 660, 760, 850,
    950, 1050, 1170, 1280, 1380, 1500, 1610, 1710, 1830, 1950,
    1990, 2090, 2200, 2300, 2430, 2550, 2670, 2780, 2900, 3020,
    3130, 3230, 3350, 3460, 3600, 3710, 3820, 3920, 4000, 4100,
    4190, 4270, 4300, 4390, 4420, 4480,
};
static const uint32_t aw_pixels[142] = {
    0u, 2032u, 2143684400u, 4186885574u, 2083750287u, 4164912952u, 3325135971u, 419176384u,
    201428963u, 4234152961u, 4282378225u, 4261511271u, 4194173312u, 1744436288u, 3424224048u, 1744633728u,
    805699776u, 436092870u, 12591041u, 4261462041u, 4282368496u, 4267710471u, 4059979992u, 939327103u,
    2143338688u, 1616916528u, 806881219u, 4169539983u, 3891888992u, 3756259580u, 2140169229u, 4282368048u,
    150880003u, 4043279385u, 2174228865u, 2683961240u, 427925475u, 4267756569u, 3208635910u, 3235904510u,
    1071642113u, 2153781254u, 25198543u, 4159733702u, 207644166u, 1617299040u, 3355213703u, 4244609027u,
    7311345u, 2150631420u, 2141190141u, 2153782246u, 4185939992u, 100728607u, 4185921537u, 3206281601u,
    2551840655u, 4186019865u, 2174228991u, 2683928984u, 427923481u, 2576980377u, 2550268288u, 1612187137u,
    2153782270u, 4279769870u, 1670177208u, 923168967u, 410191712u, 403046784u, 1612187137u, 2155864054u,
    19929536u, 3457054963u, 1721459919u, 644952457u, 2174491105u, 2669263257u, 3649935481u, 2207783038u,
    267485592u, 427857929u, 2174228735u, 132185663u, 3859202264u, 453476301u, 3783274497u, 4164929030u,
    1617298016u, 637952099u, 4263479292u, 2145781344u, 1711697862u, 4167239196u, 1625553151u, 2550333567u,
    2281177856u, 670891839u, 4294717452u, 50380848u, 201523393u, 26745217u, 2551808408u, 427924504u,
    4286837505u, 2959477859u, 207673371u, 29374466u, 67147778u, 1662623334u, 2040215100u, 4041327363u,
    202137806u, 952504192u, 3759933377u, 3698445337u, 18883588u, 2157458430u, 520126480u, 34077182u,
    58835168u, 1880624135u, 4194172928u, 32382u, 0u, 0u, 0u, 0u,
    1054744u, 202116102u, 100795136u, 24673u, 4193804384u, 0u, 19391480u, 100867855u,
    2248278272u, 3221274625u, 588013956u, 274826764u, 817989128u, 562436288u,
};
static uint32_t te_audiowide_index(char ch)
{
    if (ch >= 'a' && ch <= 'z') ch = (char)(ch - 'a' + 'A');
    switch (ch) {
    case ' ': return 0u;
    case '0': return 1u;
    case '1': return 2u;
    case '2': return 3u;
    case '3': return 4u;
    case '4': return 5u;
    case '5': return 6u;
    case '6': return 7u;
    case '7': return 8u;
    case '8': return 9u;
    case '9': return 10u;
    case 'A': return 11u;
    case 'B': return 12u;
    case 'C': return 13u;
    case 'D': return 14u;
    case 'E': return 15u;
    case 'F': return 16u;
    case 'G': return 17u;
    case 'H': return 18u;
    case 'I': return 19u;
    case 'J': return 20u;
    case 'K': return 21u;
    case 'L': return 22u;
    case 'M': return 23u;
    case 'N': return 24u;
    case 'O': return 25u;
    case 'P': return 26u;
    case 'Q': return 27u;
    case 'R': return 28u;
    case 'S': return 29u;
    case 'T': return 30u;
    case 'U': return 31u;
    case 'V': return 32u;
    case 'W': return 33u;
    case 'X': return 34u;
    case 'Y': return 35u;
    case 'Z': return 36u;
    case '-': return 37u;
    case '_': return 38u;
    case '/': return 39u;
    case '+': return 40u;
    case '.': return 41u;
    case '?': return 42u;
    case ':': return 43u;
    case '(': return 44u;
    case ')': return 45u;
    default: return 42u;
    }
}
static int32_t te_audiowide_w(const char *s)
{
    int32_t w = 0;
    for (; *s; s++) w += aw_width[te_audiowide_index(*s)] * 2;
    return w;
}
static int32_t te_arcade_l(int32_t x, int32_t y, const char *s, uint16_t c)
{
    int32_t pen = x;
    for (; *s; s++) {
        uint32_t gi = te_audiowide_index(*s), w = aw_width[gi], row, col;
        for (row = 0; row < 10u; row++)
            for (col = 0; col < w; col++) {
                uint32_t pi = aw_off[gi] + row * w + col;
                uint32_t wi = pi >> 5, shift = 24u - (((pi >> 3) & 3u) * 8u);
                uint8_t v = (uint8_t)(aw_pixels[wi] >> shift);
                if ((v >> (7u - (pi & 7u))) & 1u) cv_rect(pen + (int32_t)col * 2, y + (int32_t)row * 2, 2, 2, c);
            }
        pen += (int32_t)w * 2;
    }
    return pen;
}
static void te_text_c(int32_t cx, int32_t y, const char *s, uint16_t c)   /* centred on cx */
{
    cv_text(cx - text_w(&FONT_TINY, s) / 2, y, &FONT_TINY, s, c);
}
/* the dial strip: KNOB 1..4, label + value under each (a dial with no label: an empty column); a
 * message replaces it */
UI_SMALL static void te_dials(int32_t y0, const char *const lab[4], const char *const val[4], const int32_t ratio[4],
                     uint32_t sig, uint32_t *cache)
{
    uint32_t k;
    sig = studio_hash(sig, ui.msg_t ? ui.msg : "");
    for (k = 0; k < 4u; k++) {
        sig = studio_hash(sig * 7u + (uint32_t)ratio[k] + (ui.hot_t && ui.hot_col == k) * 5003u, lab[k]);
        sig = studio_hash(sig, val[k]);
    }
    if (!ui.force && sig == *cache)
        return;
    *cache = sig;
    cv_begin(240, ui.msg_t ? 240u - (uint32_t)y0 : 40u, C_BLACK);
    if (ui.msg_t) {                                     /* a message: a white bar */
        cv_rect(0, 10, 240, 32, C_WHITE);
        cv_text((240 - text_w(&FONT_TINY, ui.msg)) / 2, 18, &FONT_TINY, ui.msg, C_BLACK);
        cv_blit(0, (uint32_t)y0);
        return;
    }
    for (k = 0; k < 4u; k++) {
        int32_t cx = 30 + 60 * (int32_t)k;
        if (!lab[k][0])
            continue;
        te_dial(cx, 12, 11, ratio[k], TE_COL[k], TE_DIM[k]);
        te_text_c(cx, 24, lab[k], RGB(0, 245, 255));
    }
    cv_blit(0, (uint32_t)y0);
    cv_begin(240, 16, C_BLACK);                         /* the values: white while turned */
    for (k = 0; k < 4u; k++)
        te_text_c(30 + 60 * (int32_t)k, 0, val[k], ui.hot_t && ui.hot_col == k ? C_WHITE : TE_G4);
    cv_blit(0, (uint32_t)y0 + 40u);
}

UI_SMALL static void studio_open(uint32_t scope)
{
    uint32_t i;
    if (scope == SC_SONG && rec_wait)
        rec_wait = 0;                                   /* (an arm does not follow into the song page) */
    for (i = 0; i < NPAGES; i++) if (PAGES[i].scope == scope) {
        ui.page = (uint8_t)i; ui.home = 0; song.seq_mode = 0; ui.force = 1;
        ui.msg_t = 0; ui.entry_open = 0; return;
    }
}
/* LIVE: REC, on any page. One record arm, on the selected track (it follows ALGORITHM). No
 * click (seq.c): playing, recording starts at once; stopped, REC arms and the first note
 * starts the loop (or, in an empty project, a free take that REC closes: seq.c ft_close).
 * REC again stops recording / cancels the arm (playback continues). */
UI_SMALL static void rec_toggle(void)
{
    if (ft_owns_press())
        return;
    if (song.playing && arrangement_enabled) {
        ui_message("STOP THE SONG FIRST");
        return;
    }
    if (song.rec || rec_wait) {
        song.rec = 0;
        rec_wait = 0;
        ui_message("REC OFF");
        return;
    }
    arrangement_enabled = 0;
    if (song.playing)
        rec_begin();                    /* playing: record now */
    else
        rec_wait = 1;                   /* stopped: the first note starts it */
}

/* the loop position of track t: "bar.beat" in its pattern (1.1 .. ) */
UI_SMALL static void loop_pos(const track_t *t, char *b)
{
    uint32_t len = (uint32_t)clamp(t->p[P_SLEN], 1, NSTEP), s = t->seq_idx % len, k;
    fmt_int(b, (int32_t)(s / 16u + 1u));
    k = str_len(b);
    b[k] = '.';
    b[k + 1] = (char)('1' + (s % 16u) / 4u);
    b[k + 2] = 0;
}

/* the header of the live screens: BPM, transport, the loop position, the beat lights, REC */
UI_SMALL 
static void te_header(const char *title, uint16_t tc, uint32_t *cache)
{
    char b[12];
    uint32_t beat = clk_beat, k, playing = song.playing;
    uint32_t sig = studio_hash((uint32_t)song.g[G_BPM] * 7u + playing * 3u + (song.rec != 0) * 1999u +
                               (playing ? beat * 131u + TSEL->seq_idx * 7919u : 0u) + (uint32_t)song.g[G_CLOCK] * 77u +
                               arrangement_enabled * 5u + (ui.bpm_t != 0) * 104729u + song.solo * 37u, title);
    if (str_eq(title, "tracks"))
        sig = sig * 31u + song.sel * 17u + (uint32_t)TSEL->p[P_SDIV] * 131u;
    sig = sig * 31u + tc;
    if (!ui.force && sig == *cache)
        return;
    *cache = sig;
    cv_begin(240, 40, C_BLACK);
    if (str_eq(title, "tracks")) {
        static const char *const divs[NDIV_STEP] = {"4", "8", "16", "32", "8T", "16T", "2", "BAR", "2BAR"};
        fmt_int(b, song.g[G_BPM]);
        cv_text(4, 4, &FONT_L, b, ui.bpm_t ? C_WHITE : TE_G4);
        cv_text(56, 14, &FONT_TINY, "BPM", RGB(255, 238, 0));
        cv_text(120, 4, &FONT_L, playing ? "PLAY" : "STOP", playing ? RGB(0, 220, 232) : RGB(255, 73, 215));
        b[0] = 'T'; b[1] = (char)('1' + song.sel); b[2] = '/';
        str_cpy(b + 3, divs[(uint32_t)clamp(TSEL->p[P_SDIV], 0, NDIV_STEP - 1)], sizeof b - 3u);
        cv_text(240 - text_w(&FONT_TINY, b) - 4, 8, &FONT_TINY, b, C_WHITE);
        cv_rect(0, 39, 240, 1, TE_G1);
        cv_blit(0, 0);
        return;
    }
    fmt_int(b, song.g[G_BPM]);
    cv_text(4, 4, &FONT_L, b, ui.bpm_t ? C_WHITE : TE_G4);
    cv_text(4 + text_w(&FONT_L, b) + 4, 20, &FONT_TINY, "bpm", TE_G3);
    te_play_icon(104, 6, (int)playing);
    if (playing) {                                     /* bar.beat in the selected track's loop */
        loop_pos(TSEL, b);
        cv_text(122, 5, &FONT_TINY, b, C_WHITE);
    } else {
        cv_text(122, 5, &FONT_TINY, arrangement_enabled ? "song" : "loop", TE_G3);
    }
    for (k = 0; k < 4u; k++)                           /* the four beats of the bar */
        cv_rect(104 + (int32_t)k * 9, 26, 7, 7, playing && beat % 4u == k ? (k ? C_WHITE : TE_RED) : TE_G2);
    if (song.rec) {
        te_disc(224, 12, 8, TE_RED);
        cv_text(176, 4, &FONT_TINY, "rec", TE_RED);
        if (song.g[G_CLOCK] != 0)                       /* the click is on */
            cv_text(168, 22, &FONT_TINY, "click", TE_G3);
    } else {
        cv_text(240 - text_w(&FONT_TINY, title) - 4, 5, &FONT_TINY, title, tc);
        if (song.solo)
            cv_text(236 - text_w(&FONT_TINY, "solo"), 22, &FONT_TINY, "solo", C_WHITE);
    }
    cv_rect(0, 39, 240, 1, TE_G1);
    cv_blit(0, 0);
}
/* --------------------------------------------------------------- TRACKS --- */
/* swing, MPC style: "62%" */
UI_SMALL static void swing_str(char *b, int32_t v)            /* 0 straight .. 100 the most (params.c F_SWING) */
{
    fmt_int(b, clamp(v, 0, 100));
}

UI_SMALL 
static void studio_tracks_draw(void)
{
    static uint32_t head, rows[NTRK], footer;
    uint32_t slot, j, first = song.sel & ~1u;
    if (first + 1u >= NTRK)
        first = NTRK - 2u;                       /* track 4 + drums; never read a sixth track */
    te_header("tracks", TE_G3, &head);
    for (slot = 0; slot < 2u; slot++) {
        uint32_t i = first + slot;
        track_t *t = &trk[i];
        char b[24];
        uint32_t selected = song.sel == i, len = (uint32_t)clamp(t->p[P_SLEN], 1, 64);
        uint32_t level = i == TRK_DRUM ? song.g[G_DRLVL] : t->p[P_LEVEL];
        uint32_t silent = trk_silent(t) || !level, pos = t->seq_idx % len, rec = (song.rec >> i) & 1u;
        uint32_t solo = (song.solo >> i) & 1u, bank = song.playing ? pos / 16u : ui.bank, h;
        uint16_t col = TE_COL[i < 4u ? i : 3u];
        if (i == TRK_DRUM) {
            str_cpy(b, DRUM_KIT_NAMES[drum_kit()], sizeof b);
        } else {
            trk_short_name(i, b);
        }
        b[13] = 0;
        if (bank * 16u >= len) bank = (len - 1u) / 16u;
        h = studio_hash(selected + level * 7u + silent * 997u + rec * 1999u + solo * 4999u + len * 37u +
                        song.playing * 7u + pos * 71u + bank * 13u + ui_loud_active(t) * 104729u + (t->user != 0) * 8191u, b);
        for (j = 0; j < 16u; j++) h = h * 31u + (uint32_t)(bank * 16u + j < len && trk_step_on(t, bank * 16u + j));
        if (!ui.force && h == rows[i]) continue;
        rows[i] = h;
        cv_begin(240, 72, C_BLACK);
        if (selected) {
            cv_rect(0, 0, 240, 72, RGB(0, 101, 126));
            cv_rect(0, 0, 4, 72, RGB(0, 220, 232));
        }
        {
            char n[2] = {(char)('1' + i), 0};
            cv_text(7, 0, &FONT_L, n, selected ? RGB(0, 220, 232) : col);
        }
        /* This is the actual HOME/TRACKS screen: reserve room for the saved-copy dot. */
        while (b[0] && te_audiowide_w(b) > (t->user ? 174 : 196)) b[str_len(b) - 1u] = 0;
        {
            int32_t name_end = te_arcade_l(36, 3, b, RGB(0, 245, 255));
            if (t->user)
                te_disc(name_end + 7, 14, 3, RGB(255, 0, 0)); /* same size as the yellow LOUD dot */
        }
        if (ui_loud_active(t)) te_disc(29, 15, 3, RGB(255, 255, 0));
        for (j = 0; j < 16u; j++) {                    /* the 16 steps in view */
            uint32_t p = bank * 16u + j;
            int32_t x = 14 + (int32_t)j * 14;
            te_disc(x, 37, 5, RGB(255, 73, 215));
            if (song.playing && p == pos) {             /* bright moving cursor; red while this track records */
                te_disc(x, 37, 5, rec ? TE_RED : RGB(0, 245, 255));
                te_disc(x, 37, 3, C_WHITE);
            }
        }
        fmt_int(b, (int32_t)(bank * 16u + 1u));
        str_cpy(b + str_len(b), "-", sizeof b - str_len(b));
        fmt_int(b + str_len(b), (int32_t)((bank + 1u) * 16u < len ? (bank + 1u) * 16u : len));
        str_cpy(b + str_len(b), "/", sizeof b - str_len(b));
        fmt_int(b + str_len(b), (int32_t)len);
        cv_text(5, 48, &FONT_S, b, RGB(0, 220, 232));
        if (rec) cv_text(174, 52, &FONT_TINY, "REC", TE_RED);
        else if (solo) cv_text(174, 52, &FONT_TINY, "SOLO", C_WHITE);
        else if (silent) cv_text(174, 52, &FONT_TINY, "MUTE", TE_G3);
        cv_rect(0, 71, 240, 1, RGB(27, 41, 70));
        cv_blit(0, 40 + slot * 72u);
    }
    {   /* KNOB 1 swing (the global groove), 2 level, 3 steps, 4 pan of the selected track */
        track_t *t = TSEL;
        static char v[4][8];
        static const char *const lab[4] = {"SWING", "LEVEL", "STEP", "PAN"};
        const char *val[4] = {v[0], v[1], v[2], v[3]};
        int32_t ratio[4];
        uint32_t lvl = is_drum(t) ? song.g[G_DRLVL] : t->p[P_LEVEL];
        swing_str(v[0], song.g[G_SWING]);
        fmt_int(v[1], t->p[P_MUTE] ? 0 : (int32_t)lvl * 100 / 127);
        fmt_int(v[2], t->p[P_SLEN]);
        fmt_int(v[3], t->p[P_PAN]);
        ratio[0] = song.g[G_SWING] * 10;
        ratio[1] = t->p[P_MUTE] ? 0 : (int32_t)lvl * 1000 / 127;
        ratio[2] = (t->p[P_SLEN] - 1) * 1000 / 63;
        ratio[3] = (t->p[P_PAN] + 64) * 1000 / 127;
        te_dials(184, lab, val, ratio, song.sel, &footer);
    }
}
/* ---------------------------------------------------------------- DRUMS --- */
static const char *const LV_NAME[4] = {"norm", "ghost", "soft", "hard"};
UI_SMALL static uint32_t lvl_rank(uint32_t lvl);                 /* (below) ghost 0, soft 1, norm 2, hard 3 */
UI_SMALL static uint16_t lvl_col(uint32_t lvl)                   /* a hit's colour by its level */
{
    return lvl == LV_GHOST ? TE_DIM[3] : lvl == LV_SOFT ? TE_MID[3] : lvl == LV_HARD ? C_WHITE : TE_DRUM;
}
static uint16_t pad_lit[DRUM_LANES];                   /* pads and key LEDs: frames left lit */
static uint8_t key_lit[27];                             /* menu NOTES, a synth track: frames its key stays lit */
static uint8_t key_lit_trk = 0xFF;                      /* (the track key_lit is for) */
UI_SMALL static void pads_tick(void)                             /* once a frame: the hits since the last one */
{
    uint32_t i, hits, n[NPART][4], k, w;
    fm1_irq_off();
    hits = drums.hits;
    drums.hits = 0;
    for (i = 0; i < NPART; i++)
        for (w = 0; w < 4u; w++) {
            n[i][w] = note_hits[i][w];
            note_hits[i][w] = 0;
        }
    fm1_irq_on();
    for (i = 0; i < DRUM_LANES; i++) {
        if ((hits >> i) & 1u) pad_lit[i] = 6;
        else if (pad_lit[i]) pad_lit[i]--;
    }
    /* a synth track: each note it started lights its key 6 frames (~0.1 s), so a short sequencer note
     * (a 1/16 at GATE 50 %: 60..80 ms) is seen even when it ends between two frames */
    if (song.sel != key_lit_trk) {
        memset(key_lit, 0, sizeof key_lit);
        key_lit_trk = song.sel;
    }
    for (k = 0; k < 27u; k++)
        if (key_lit[k])
            key_lit[k]--;
    if (song.sel < NPART && (n[song.sel][0] | n[song.sel][1] | n[song.sel][2] | n[song.sel][3]))
        for (k = 0; k < 27u; k++) {
            uint32_t note = kb_map(TSEL, k);
            if (note < 128u && (n[song.sel][note >> 5] >> (note & 31u)) & 1u)
                key_lit[k] = 6;
        }
}

UI_SMALL static void drum_screen_draw(void)
{
    static uint32_t head, title_sig, body_sig, footer;
    uint32_t i, j, len = (uint32_t)clamp(TDRUM->p[P_SLEN], 1, 64), kit = drum_kit(), sig, bank;
    if (drum_cursor >= len) drum_cursor = (uint8_t)(len - 1u);
    bank = drum_cursor / 16u;
    {
        char st[16], nm[9];
        const char *style = DRUM_KIT_STYLES[kit];
        if (kit >= DRUM_SYN) {                          /* SYN1..4: the name you gave it (editor DRUM SYNTH) */
            memcpy(nm, dsu_kit(kit - DRUM_SYN)->name, 8);
            nm[8] = 0;
            if (nm[0])
                style = nm;
        }
        te_lower(st, style, sizeof st);
        st[12] = 0;
        te_header(st, TE_DRUM, &head);
    }
    sig = kit * 131u + drum_page * 7u + drum_lane * 977u + bank * 31u + len + (uint32_t)drum_tweaked(kit) * 7919u;   /* title band */
    if (ui.force || sig != title_sig) {
        char b[8];
        title_sig = sig;
        cv_begin(240, 44, C_BLACK);
        cv_rect(2, 4, 34, 34, TE_DRUM);
        fmt_int(b, (int32_t)kit + 1);
        cv_text(19 - text_w(&FONT_TINY, b) / 2, 13, &FONT_TINY, b, C_BLACK);
        cv_text(44, 6, &FONT_L, DRUM_KIT_NAMES[kit], C_WHITE);
        cv_text(194, 1, &FONT_TINY, "grid", drum_page == 0 ? C_WHITE : TE_G3);
        cv_text(194, 15, &FONT_TINY, "kit", drum_page == 1 ? C_WHITE : TE_G3);
        cv_text(194, 29, &FONT_TINY, "sound", drum_page == 2 ? C_WHITE : TE_G3);
        cv_rect(188, 5 + (int32_t)drum_page * 14, 3, 9, TE_DRUM);
        cv_blit(0, 40);
    }
    sig = drum_page + drum_lane * 7u + drum_cursor * 101u + song.playing * 71u + len * 3u;
    for (i = 0; i < DRUM_LANES; i++) sig = sig * 5u + (uint32_t)(drum_tune[i] + 8) * 9u + (uint32_t)(drum_dec[i] + 4) + drum_body[kit][i] * 17u;
    if (song.playing) sig = sig * 31u + TDRUM->seq_idx;
    for (i = 0; i < DRUM_LANES; i++) sig = sig * 3u + (pad_lit[i] != 0);
    for (i = 0; i < len; i++) {
        const dstep_t *s = &TDRUM->dstep[i];
        sig = sig * 31u + dstep_mask(s);
        sig = sig * 31u + s->lvl[0] + s->lvl[1] * 7u + s->lvl[2] * 49u + s->lvl[3] * 343u;
        sig = sig * 31u + s->rat[0] + s->rat[1] * 7u + s->rat[2] * 49u + s->rat[3] * 343u;
    }
    if (ui.force || sig != body_sig) {
        body_sig = sig;
        cv_begin(240, 100, C_BLACK);
        if (!drum_page) {                              /* GRID: the 16 lanes x 16 steps of this bank */
            for (i = 0; i < DRUM_LANES; i++) {
                int32_t y = (int32_t)i * 6 + 2;
                cv_rect(2, y, 6, 5, pad_lit[i] ? C_WHITE : i == drum_lane ? TE_DRUM : TE_G2);
                for (j = 0; j < 16u; j++) {
                    uint32_t p = bank * 16u + j;
                    const dstep_t *s = &TDRUM->dstep[p < NSTEP ? p : 0];
                    uint16_t c;
                    if (p >= len) continue;
                    c = dstep_has(s, i) ? lvl_col(dstep_lvl(s, i)) : i == drum_lane ? TE_G2 : TE_G1;
                    if (song.playing && p == TDRUM->seq_idx && c == TE_G1) c = TE_G2;
                    cv_rect(12 + (int32_t)j * 14, y, 12, 5, c);
                    if (dstep_has(s, i) && dstep_rat(s, i)) {   /* a ratchet: a notch per extra hit */
                        uint32_t r;
                        for (r = 0; r < dstep_rat(s, i); r++)
                            cv_rect(13 + (int32_t)j * 14 + (int32_t)r * 3, y + 2, 2, 1, C_BLACK);
                    }
                    if (p == drum_cursor && i == drum_lane) {
                        cv_rect(11 + (int32_t)j * 14, y - 1, 14, 1, C_WHITE);
                        cv_rect(11 + (int32_t)j * 14, y + 5, 14, 1, C_WHITE);
                    }
                }
            }
        } else {                                       /* KIT: 16 pads, lit on each hit; SOUND (2.7): the one KNOB 1 picks
                                                        * framed, a tuned or shortened / lengthened one marked */
            for (i = 0; i < DRUM_LANES; i++) {
                int32_t x = 2 + (int32_t)(i % 4u) * 60, y = (int32_t)(i / 4u) * 25;
                cv_rect(x, y, 56, 23, pad_lit[i] ? TE_DRUM : TE_G1);
                if (drum_page == 2u && i == drum_lane) {
                    cv_rect(x, y, 56, 1, C_WHITE), cv_rect(x, y + 22, 56, 1, C_WHITE);
                    cv_rect(x, y, 1, 23, C_WHITE), cv_rect(x + 55, y, 1, 23, C_WHITE);
                }
                if (drum_page == 2u && (drum_tune[i] || drum_dec[i] || drum_body[kit][i]))
                    cv_rect(x + 3, y + 3, 4, 4, TE_DRUM);
                te_text_c(x + 28, y + 4, LANE_SHORT[i], pad_lit[i] ? C_BLACK : i == drum_lane ? C_WHITE : TE_G3);
            }
        }
        cv_blit(0, 84);
    }
    {
        static char v[4][12];
        const char *val[4] = {v[0], v[1], v[2], v[3]};
        static const char *const LG[4] = {"sound", "step", "hit", "level"}, *const LK[4] = {"kit", "level", "reverb", "pan"},
                                 *const LS[4] = {"sound", "tune", "decay", "body"};
        int32_t ratio[4];
        if (!drum_page) {
            const dstep_t *s = &TDRUM->dstep[drum_cursor];
            str_cpy(v[0], LANE_SHORT[drum_lane], 8);
            fmt_int(v[1], drum_cursor + 1);
            str_cpy(v[2], dstep_has(s, drum_lane) ? "on" : "--", 4);
            str_cpy(v[3], dstep_has(s, drum_lane) ? LV_NAME[dstep_lvl(s, drum_lane)] : "--", 8);
            ratio[0] = (int32_t)drum_lane * 1000 / (DRUM_LANES - 1);
            ratio[1] = (int32_t)drum_cursor * 1000 / (int32_t)(len > 1u ? len - 1u : 1u);
            ratio[2] = v[2][0] == 'o' ? 1000 : 0;
            ratio[3] = dstep_has(s, drum_lane) ? (int32_t)lvl_rank(dstep_lvl(s, drum_lane)) * 333 : 0;   /* ghost left ..
                                                                     * hard right (2.5: it followed the stored order) */
            te_dials(184, LG, val, ratio, 1u, &footer);
        } else if (drum_page == 2u) {                  /* SOUND (2.7): the sound, its TUNE and DECAY, the drums' level */
            str_cpy(v[0], LANE_SHORT[drum_lane], 8);
            fmt_int(v[1], drum_tune[drum_lane]);
            if (drum_tune[drum_lane] > 0) { v[1][0] = '+'; fmt_int(v[1] + 1, drum_tune[drum_lane]); }
            fmt_int(v[2], drum_dec[drum_lane]);
            if (drum_dec[drum_lane] > 0) { v[2][0] = '+'; fmt_int(v[2] + 1, drum_dec[drum_lane]); }
            fmt_int(v[3], drum_body[kit][drum_lane]);
            ratio[0] = (int32_t)drum_lane * 1000 / (DRUM_LANES - 1);
            ratio[1] = (drum_tune[drum_lane] - DRUM_TUNE_MIN) * 1000 / (DRUM_TUNE_MAX - DRUM_TUNE_MIN);
            ratio[2] = (drum_dec[drum_lane] - DRUM_DEC_MIN) * 1000 / (DRUM_DEC_MAX - DRUM_DEC_MIN);
            ratio[3] = (drum_body[kit][drum_lane] + 4) * 1000 / 8;
            te_dials(184, LS, val, ratio, 3u, &footer);
        } else {
            fmt_int(v[0], (int32_t)kit + 1);
            fmt_int(v[1], song.g[G_DRLVL] * 100 / 127);
            fmt_int(v[2], song.g[G_DRREV] * 100 / 127);
            fmt_int(v[3], TDRUM->p[P_PAN]);
            ratio[0] = (int32_t)kit * 1000 / (int32_t)(DRUM_KITS - 1u);
            ratio[1] = song.g[G_DRLVL] * 1000 / 127;
            ratio[2] = song.g[G_DRREV] * 1000 / 127;
            ratio[3] = (TDRUM->p[P_PAN] + 64) * 1000 / 127;
            te_dials(184, LK, val, ratio, 2u, &footer);
        }
    }
}

/* the level order of the knobs: ghost < soft < norm < hard */
static const uint8_t LV_UP[4] = {LV_GHOST, LV_SOFT, LV_NORM, LV_HARD};
UI_SMALL static uint32_t lvl_rank(uint32_t lvl) { return lvl == LV_GHOST ? 0u : lvl == LV_SOFT ? 1u : lvl == LV_NORM ? 2u : 3u; }

/* the GRID page shown, no layer held: its keys are steps (seq.c kb_grid) */
UI_SMALL static int grid_keys_on(void) { return on_drum_page() && !drum_page && song.sel == TRK_DRUM && !ui.menu; }
/* a key down on the GRID page: the white keys are the 16 steps of this page of steps for the sound of
 * KNOB 1 — an empty one is set (NORM, the sound heard), a set one cleared; the first four black keys
 * pick the page (steps 1-16, 17-32, 33-48, 49-64), as in the SEQ layer. The cursor follows */
UI_SMALL static void grid_key(uint32_t k)
{
    static const int8_t PG[12] = {-1, 0, -1, 1, -1, 2, -1, -1, 3, -1, -1, -1};
    uint32_t len = trk_len(TDRUM), idx;
    int32_t w = punch_key(k);
    dstep_t *st;
    if (w < 0) {
        if (k < 12u && PG[k] >= 0 && (uint32_t)PG[k] * 16u < len) {
            idx = (uint32_t)PG[k] * 16u + drum_cursor % 16u;
            drum_cursor = (uint8_t)(idx < len ? idx : len - 1u);
            ui.force = 1;
        }
        return;
    }
    idx = drum_cursor / 16u * 16u + (uint32_t)w;
    if (idx >= len)
        return;
    drum_cursor = (uint8_t)idx;
    if (song.playing && arrangement_enabled) {
        ui_message("STOP THE SONG FIRST");
        return;
    }
    undo_mark(TDRUM, ui.step_sess ? ui.step_sess : (ui.step_sess = (undo_sess += 4u) | 3u));
    st = &TDRUM->dstep[idx];
    fm1_irq_off();
    if (dstep_has(st, drum_lane)) {
        dstep_clr(st, drum_lane);
        if (!dstep_mask(st)) {                          /* an empty step keeps no lock, no nudge, no condition */
            lock_del(TDRUM, idx, P_COUNT);
            TDRUM->micro[idx] = 0;
            step_fill_set(TDRUM, idx, FC_NORM);
        }
    } else {
        dstep_set(st, drum_lane, LV_NORM, 0);
        TDRUM->seq_active = 1;
    }
    fm1_irq_on();
    if (dstep_has(st, drum_lane))
        audition_lane(drum_lane);
    sync_reload = 1;
}

UI_SMALL static void drum_screen_input(uint32_t pressed, uint32_t home, uint32_t notes)
{
    uint32_t k, b, kit;
    int32_t s;
    if (song.sel != TRK_DRUM || home == 1u) {
        go_home();
        return;
    }
    kit = (uint32_t)TDRUM->p[P_E0];
    for (k = 0; k < NB; k++) if ((pressed >> panel.btn[k]) & 1u) {
        b = k;
        if (b == B_PLAY) {
            if (ft_owns_press()) ;
            else if (!song.playing && arrangement_enabled && !arr_valid(&arrangement, arrangement_ready())) ui_message("EMPTY SECTION: REC");
            else transport_req = song.playing ? 2 : 1;
        } else if (b == B_SEQ || b == B_EDIT) {
            drum_page = (uint8_t)((drum_page + 1u) % 3u);   /* GRID -> KIT -> SOUND (2.7) */
            ui.msg_t = 0;
            ui.force = 1;
        } else if (b == B_SAVE) {
            studio_open(SC_SONG);
            return;
        }
    }
    if ((s = panel_enc(EN_SELECT)) && (uint32_t)clamp((int32_t)drum_page + s, 0, 2) != drum_page) {   /* SELECT: grid <-
                                                                     * kit -> sound (2.7), its pages */
        drum_page = (uint8_t)clamp((int32_t)drum_page + s, 0, 2);
        ui.msg_t = 0;
        ui.force = 1;
    }
    if (drum_page == 2u && notes) {                    /* SOUND (2.7): the key played picks its sound (it is heard
                                                        * as the keys always play it) */
        for (k = 0; k < 32u; k++)
            if ((notes >> k) & 1u) {
                drum_lane = (uint8_t)lane_of_key(k);
                ui.force = 1;
            }
    }
    if ((s = panel_enc(EN_ALGO)) && !ft_on) {
        track_select((uint32_t)clamp((int32_t)song.sel + s, 0, 3));
        if (song.sel != TRK_DRUM) {
            go_home();
            return;
        }
    }
    if ((s = panel_enc(EN_PRESET))) TDRUM->p[P_E0] = (int16_t)clamp(TDRUM->p[P_E0] + s, 0, DRUM_KITS - 1);
    for (k = 0; k < 4u; k++) if ((s = panel_enc(EN_K1 + k))) {
        ui.hot_col = (uint8_t)k;
        ui.hot_t = 40;
        if (!drum_page) {
            dstep_t *st = &TDRUM->dstep[drum_cursor];
            if (k == 0) {                              /* the sound: heard */
                uint8_t l = (uint8_t)clamp(drum_lane + s, 0, DRUM_LANES - 1);
                if (l != drum_lane) audition_lane(l);
                drum_lane = l;
            }
            if (k == 1) {                              /* the step: what it holds, heard */
                uint8_t c = (uint8_t)clamp(drum_cursor + s, 0, TDRUM->p[P_SLEN] - 1);
                if (c != drum_cursor) audition_step(&TDRUM->dstep[c]);
                drum_cursor = c;
            }
            if (k >= 2) {
                if (song.playing && arrangement_enabled) { ui_message("STOP THE SONG FIRST"); continue; }
                undo_mark(TDRUM, ui.step_sess ? ui.step_sess : (ui.step_sess = (undo_sess += 4u) | 3u));
                fm1_irq_off();
                if (k == 2) {
                    if (s > 0) dstep_set(st, drum_lane, LV_NORM, 0);
                    else dstep_clr(st, drum_lane);
                } else if (dstep_has(st, drum_lane)) {
                    uint32_t r = (uint32_t)clamp((int32_t)lvl_rank(dstep_lvl(st, drum_lane)) + (s > 0 ? 1 : -1), 0, 3);
                    dstep_set(st, drum_lane, LV_UP[r], dstep_rat(st, drum_lane));
                }
                fm1_irq_on();
                sync_reload = 1;
            }
        } else if (drum_page == 2u) {                  /* SOUND (2.7) */
            if (k == 0) {
                uint8_t l = (uint8_t)clamp(drum_lane + s, 0, DRUM_LANES - 1);
                if (l != drum_lane) audition_lane(l);
                drum_lane = l;
            }
            if (k == 1 || k == 2) {                    /* TUNE, DECAY: the next hit has them (heard at once) */
                int8_t *p = k == 1 ? &drum_tune[drum_lane] : &drum_dec[drum_lane];
                int32_t lo = k == 1 ? DRUM_TUNE_MIN : DRUM_DEC_MIN, hi = k == 1 ? DRUM_TUNE_MAX : DRUM_DEC_MAX;
                int8_t nv = (int8_t)clamp(*p + s, lo, hi);
                if (nv != *p) {
                    *p = nv;
                    if (!song.playing)
                        audition_lane(drum_lane);
                }
            }
            if (k == 3) drum_body[kit][drum_lane] = (int8_t)clamp((int32_t)drum_body[kit][drum_lane] + s, -4, 4);
        } else {
            if (k == 0) TDRUM->p[P_E0] = (int16_t)clamp(TDRUM->p[P_E0] + s, 0, DRUM_KITS - 1);
            if (k == 1) song.g[G_DRLVL] = (int16_t)clamp(song.g[G_DRLVL] + s, 0, 127);
            if (k == 2) song.g[G_DRREV] = (int16_t)clamp(song.g[G_DRREV] + s, 0, 127);
            if (k == 3) TDRUM->p[P_PAN] = (int16_t)clamp(TDRUM->p[P_PAN] + s, -64, 63);
        }
    }
}

/* ---------------------------------------------------------------- REC --- */
/* a big seven-segment digit, TE style: w x h, segments t thick */
UI_SMALL static void te_digit(int32_t x, int32_t y, int32_t w, int32_t h, int32_t t, uint32_t d, uint16_t c)
{
    static const uint8_t SEG[10] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};   /* gfedcba */
    uint32_t m = SEG[d % 10u];
    int32_t hh = h / 2;
    if (m & 0x01) cv_rect(x + t, y, w - 2 * t, t, c);                       /* a */
    if (m & 0x02) cv_rect(x + w - t, y + t, t, hh - t, c);                  /* b */
    if (m & 0x04) cv_rect(x + w - t, y + hh, t, hh - t, c);                 /* c */
    if (m & 0x08) cv_rect(x + t, y + h - t, w - 2 * t, t, c);               /* d */
    if (m & 0x10) cv_rect(x, y + hh, t, hh - t, c);                         /* e */
    if (m & 0x20) cv_rect(x, y + t, t, hh - t, c);                          /* f */
    if (m & 0x40) cv_rect(x + t, y + hh - t / 2, w - 2 * t, t, c);          /* g */
}

static uint8_t rec_shown;
/* the four tracks, compact, from y0: the one that records is framed in red */
UI_SMALL static void rec_rows(uint32_t rt, uint32_t take, uint32_t y0, uint32_t *cache)
{
    uint32_t sig = rt * 3u + rec_wait + take * 5u + drum_kit() * 977u + y0, i, j;
    for (i = 0; i < NTRK; i++) {
        char b[16];
        if (i == TRK_DRUM) str_cpy(b, DRUM_KIT_NAMES[drum_kit()], sizeof b);
        else trk_short_name(i, b);
        sig = studio_hash(sig, b) + (uint32_t)trk[i].p[P_SLEN] * 31u;
        for (j = 0; j < NSTEP; j++) sig = sig * 3u + (uint32_t)trk_step_on(&trk[i], j);
    }
    if (!ui.force && sig == *cache)
        return;
    *cache = sig;
    cv_begin(240, 76, C_BLACK);
    for (i = 0; i < NTRK; i++) {
        const track_t *t = &trk[i];
        uint32_t len = (uint32_t)clamp(t->p[P_SLEN], 1, 64), armed = i == rt;
        int32_t y = (int32_t)i * 19;
        char b[16];
        uint32_t ci = i < 4u ? i : 3u;
        cv_rect(0, y, 240, 18, armed ? RGB(255, 73, 215) : TE_DIM[ci]);
        cv_rect(1, y + 1, 238, 16, armed ? TE_MID[ci] : C_BLACK);
        cv_rect(4, y + 3, 12, 12, armed ? TE_COL[ci] : TE_DIM[ci]);
        if (i == TRK_DRUM) str_cpy(b, DRUM_KIT_NAMES[drum_kit()], sizeof b);
        else trk_short_name(i, b);
        b[10] = 0;
        cv_text(22, y + 1, &FONT_TINY, b, C_WHITE);
        for (j = 0; j < 16u; j++) {
            uint32_t a = j * len / 16u, z = (j + 1u) * len / 16u, k, on = 0;
            if (z == a) z = a + 1u;
            for (k = a; k < z && k < NSTEP; k++) if (trk_step_on(t, k)) on = 1;
            cv_rect(106 + (int32_t)j * 8, y + 5, 6, 8, on ? (armed ? TE_COL[ci] : TE_DIM[ci]) : TE_G1);
        }
    }
    cv_blit(0, y0);
}

/* REC armed (stopped: waiting for the first note, or PLAY), its count-in, or a free take running
 * (seq.c). Armed, the dials say how it records: KNOB 1 MODE free / tempo (an empty project),
 * KNOB 2 LENGTH (1, 2 or 4 bars), KNOB 3 START note / count, KNOB 4 QUANT on / off (2.7) (ui_input.c rec_knobs). The four tracks
 * stay in view; the REC LED blinks while armed, is lit during the take. */
UI_SMALL static void rec_screen_draw(void)
{
    static uint32_t head, body, rows, foot, dials;
    static uint8_t layout;
    uint32_t sig, take = ft_on, empty = take || project_empty(), rt = take ? ft_trk % NTRK : song.sel;
    uint32_t blink = (fm1_ms / 250u) & 1u, secs = take ? ft_t * CTL / FS : 0u, bars = 0, bpm = 0;
    uint32_t lay = take ? 1u : 2u, free = empty && !rec_tempo && !take, count = ci_on;
    if (take)
        bars = ft_fit(ft_t, &bpm);
    if (!rec_shown || lay != layout) {
        lcd_fill(0, 0, 240, 240, C_BLACK);
        ui.force = 1;
    }
    rec_shown = 1;
    layout = (uint8_t)lay;
    te_header(take ? "free take" : count ? "count-in" : "rec ready", RGB(255, 73, 215), &head);
    if (take) {                                         /* free take: the time, the loop it makes */
        sig = 1000003u + rt * 7919u + blink * 31u + secs * 131u + bars * 17u + bpm * 3u;
        if (ui.force || sig != body) {
            char b[24];
            uint32_t n = secs > 99u ? 99u : secs;
            body = sig;
            cv_begin(240, 106, C_BLACK);
            te_disc(18, 30, 9, RGB(255, 73, 215));
            if (n >= 10u)
                te_digit(36, 4, 32, 56, 7, n / 10u, C_WHITE);
            te_digit(76, 4, 32, 56, 7, n % 10u, C_WHITE);
            cv_text(112, 44, &FONT_TINY, "s", TE_G3);
            cv_rect(132, 6, 1, 54, TE_G1);
            if (bars) {
                fmt_int(b, (int32_t)bars);
                cv_text(146, 4, &FONT_L, b, TE_COL[rt & 3u]);
                cv_text(146 + text_w(&FONT_L, b) + 6, 18, &FONT_TINY, bars == 1u ? "bar" : "bars", TE_G3);
                fmt_int(b, (int32_t)bpm);
                cv_text(146, 38, &FONT_S, b, RGB(0, 245, 255));
                cv_text(146 + text_w(&FONT_S, b) + 4, 46, &FONT_TINY, "bpm", RGB(255, 73, 215));
            } else {
                cv_text(146, 4, &FONT_L, "-", TE_G3);
            }
            te_text_c(120, 80, "press rec on the 1", TE_RED);
            cv_blit(0, 42);
        }
        rec_rows(rt, take, 148u, &rows);
        if (ui.force || foot != 1u) {
            foot = 1u;
            cv_begin(240, 16, C_BLACK);
            cv_text(4, 0, &FONT_TINY, "rec: close", TE_G3);
            cv_text(236 - text_w(&FONT_TINY, "play: drop"), 0, &FONT_TINY, "play: drop", TE_G3);
            cv_blit(0, 224);
        }
        return;
    }
    foot = 0;
    /* armed / counting in: what happens next */
    sig = 2000003u + empty * 7u + free * 11u + rec_count * 13u + count * 17u + ci_beat * 19u + blink * 31u +
          rec_quant_off * 37u;
    if (ui.force || sig != body) {
        static const char *const L1[3] = {"play freely", "play a note", "press play"};
        static const char *const L2[3] = {"then rec on the 1", "it starts the loop", "4 clicks, then rec"};
        static const char *const L3[3] = {"the tempo follows you", "play: go  rec: cancel", "rec: cancel"};
        uint32_t m = free ? 0u : rec_count ? 2u : 1u;
        body = sig;
        cv_begin(240, 64, C_BLACK);
        if (count) {                                    /* the count-in: 4, 3, 2, 1 */
            te_digit(96, 4, 30, 54, 6, 4u - (ci_beat > 3u ? 3u : ci_beat), C_WHITE);
            te_disc(60, 31, 12, RGB(255, 73, 215));
            cv_text(144, 14, &FONT_TINY, "count-in", TE_G4);
            cv_text(144, 34, &FONT_TINY, "rec: cancel", TE_G3);
        } else {
            te_disc(28, 30, 18, RGB(255, 73, 215));
            te_disc(28, 30, 7, C_BLACK);
            cv_text(60, 6, &FONT_TINY, L1[m], C_WHITE);
            cv_text(60, 24, &FONT_TINY, L2[m], TE_G4);
            cv_text(60, 42, &FONT_TINY, L3[m], TE_G3);
        }
        cv_blit(0, 42);
    }
    rec_rows(rt, 0u, 106u, &rows);
    {   /* the dials: how it records */
        static char v[3][10];
        static const char *const LAB_E[4] = {"mode", "length", "start", "quant"};
        static const char *const LAB_F[4] = {"mode", "", "", "quant"};
        static const char *const LAB_N[4] = {"", "length", "start", "quant"};
        static const char *const LAB_0[4] = {"", "", "", ""};
        const char *val[4] = {v[0], v[1], v[2], rec_quant_off ? "off" : "on"};   /* (2.7) QUANT */
        int32_t ratio[4] = {0, 0, 0, 0};
        uint32_t len = (uint32_t)clamp(TSEL->p[P_SLEN], 1, 64);
        str_cpy(v[0], rec_tempo ? "tempo" : "free", sizeof v[0]);
        if (len % 16u == 0u) {
            fmt_int(v[1], (int32_t)(len / 16u));
            str_cpy(v[1] + str_len(v[1]), len == 16u ? " bar" : " bars", 6);
        } else {
            fmt_int(v[1], (int32_t)len);
            str_cpy(v[1] + str_len(v[1]), " st", 4);
        }
        str_cpy(v[2], rec_count ? "count" : "note", sizeof v[2]);
        ratio[0] = rec_tempo ? 1000 : 0;
        ratio[1] = (int32_t)(len - 1u) * 1000 / 63;
        ratio[2] = rec_count ? 1000 : 0;
        ratio[3] = rec_quant_off ? 0 : 1000;
        {
            const char *const *lab = count ? LAB_0 : !empty ? LAB_N : free ? LAB_F : LAB_E;
            uint32_t k;
            for (k = 0; k < 4u; k++)
                if (!lab[k][0])
                    val[k] = "";                        /* (a dial not shown: no value either) */
            te_dials(184, lab, val, ratio, rt * 7u + count * 3u, &dials);
            if (!count && !ui.msg_t) {                  /* the REC choices, including FREE and ON, are neon fuchsia */
                cv_begin(240, 16, C_BLACK);
                for (k = 0; k < 4u; k++)
                    te_text_c(30 + 60 * (int32_t)k, 0, val[k], RGB(255, 73, 215));
                cv_blit(0, 224);
            }
        }
    }
}
