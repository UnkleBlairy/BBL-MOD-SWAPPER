/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Felucca user interface. Four columns map to KNOB 1..4. Rendering is lazy:
 * every element remembers what it last drew and is redrawn only on change. */
#ifndef FELUCCA_VERSION
#define FELUCCA_VERSION "SPAMPY 10.0"  /* the beat machine firmware for the FM-1 (based on Felucca) */
#endif
static void project_save(uint32_t slot);
static void arrangement_save(void);
static void panel_setup(void);
static void settings_save(void);
static void project_load(uint32_t slot);
static void project_erase(uint32_t slot);        /* SAVE > PROJECT > ERASE (2.6) */
static int project_used(uint32_t slot);
static int up_used(uint32_t k);              /* user presets: upreset.c */
static int up_load(uint32_t k);
static int up_load_to(track_t *t, uint32_t k);
static uint32_t up_count(void);
static uint32_t up_nth(uint32_t n);
static uint32_t up_rank(uint32_t slot);
static uint32_t up_engine(uint32_t slot);
static uint32_t up_source_bank(uint32_t slot);
static void up_name(uint32_t k, char *b);
static void up_slot_label(char *b, uint32_t k);
static void up_ui(uint32_t op, uint32_t k);
UI_SMALL static uint32_t user_of(const track_t *t)    /* user preset slot its sound came from, UP_SLOTS = none */
{
    return t->user && up_used(t->user - 1u) ? t->user - 1u : UP_SLOTS;
}
static uint32_t up_gen;                      /* bumped on every user bank change (redraws) */
static uint8_t sync_reload;                  /* engine / preset / project / user preset loaded: editor RELOAD push */
UI_SMALL static void ui_say(const char *a, const char *b);

/* LOUD is a per-sound +9 dB make-up switch. State belongs to each preset or drum kit. */
#define LOUDNESS_TRIM 18                      /* trim is in 0.5 dB steps */
static uint8_t loud_user_bank[UP_SLOTS], loud_factory[NENGINES][128], loud_drum[DRUM_KITS], loud_drum_global, loud_combo_down;
/* Zero means use the saved default.  Any explicit adjustment belongs to this one sound only. */
static uint8_t loud_user_db[UP_SLOTS], loud_factory_db[NENGINES][128], loud_drum_db[DRUM_KITS];
static int8_t loud_default_db = 9;
static int16_t loud_drum_saved_level = -1;
static uint8_t loud_persist_factory[64], loud_persist_drum[4];
static uint8_t loud_dirty;

/* INSERT used to expose one shared A/B/C triplet.  Keep a separate triplet
 * for each effect on each track, and swap it in only when its type is chosen.
 * This is deliberately UI-side state: it does not change the project format. */
#define INSERT_MEMORY_TYPES 9u
static int16_t insert_memory[NTRK][INSERT_MEMORY_TYPES][3];
static uint8_t insert_memory_ready[NTRK], insert_memory_type[NTRK];

UI_SMALL static void insert_memory_sync(track_t *t)
{
    uint32_t tr = trk_index(t), type, old, k;
    if (tr >= NTRK || is_drum(t))
        return;
    type = (uint32_t)clamp(t->p[P_ITYPE], 0, INSERT_MEMORY_TYPES - 1u);
    if (!insert_memory_ready[tr]) {
        for (old = 0; old < INSERT_MEMORY_TYPES; old++)
            for (k = 0; k < 3u; k++)
                insert_memory[tr][old][k] = ins_desc((int32_t)old, k)->def;
        for (k = 0; k < 3u; k++)
            insert_memory[tr][type][k] = t->p[P_IA + k];
        insert_memory_type[tr] = (uint8_t)type;
        insert_memory_ready[tr] = 1;
        return;
    }
    old = insert_memory_type[tr];
    if (type != old) {
        for (k = 0; k < 3u; k++) {
            insert_memory[tr][old][k] = t->p[P_IA + k];
            t->p[P_IA + k] = insert_memory[tr][type][k];
        }
        insert_memory_type[tr] = (uint8_t)type;
    } else {
        for (k = 0; k < 3u; k++)
            insert_memory[tr][type][k] = t->p[P_IA + k];
    }
}

/* REV/CHO has one adjustable reverb control (DAMP).  It too belongs to the
 * selected reverb, so changing the algorithm never copies its damping into
 * another space. */
#define REVERB_MEMORY_TYPES 9u
static int16_t reverb_memory[REVERB_MEMORY_TYPES];
static uint8_t reverb_memory_ready, reverb_memory_type;

UI_SMALL static void reverb_memory_sync(void)
{
    uint32_t type = (uint32_t)clamp(song.g[G_RSIZE], 0, REVERB_MEMORY_TYPES - 1u), k;
    if (!reverb_memory_ready) {
        for (k = 0; k < REVERB_MEMORY_TYPES; k++)
            reverb_memory[k] = GP[G_RDAMP].def;
        reverb_memory[type] = song.g[G_RDAMP];
        reverb_memory_type = (uint8_t)type;
        reverb_memory_ready = 1;
        return;
    }
    if (type != reverb_memory_type) {
        reverb_memory[reverb_memory_type] = song.g[G_RDAMP];
        song.g[G_RDAMP] = reverb_memory[type];
        reverb_memory_type = (uint8_t)type;
    } else {
        reverb_memory[type] = song.g[G_RDAMP];
    }
}
int ui_loud_active(const track_t *t)
{
    uint32_t p = trk_index(t);
    if (is_drum(t)) {
        uint32_t k = (uint32_t)clamp(TDRUM->p[P_E0], 0, DRUM_KITS - 1);
        return loud_drum[k] != 0;
    }
    if (p >= NPART)
        return 0;
    if (user_of(t) < UP_SLOTS)
        return loud_user_bank[user_of(t)] != 0;
    return loud_factory[t->eng_req % NENGINES][t->preset & 127u] != 0;
}
UI_SMALL static uint8_t *loud_db_slot(const track_t *t)
{
    if (is_drum(t)) {
        uint32_t k = (uint32_t)clamp(t->p[P_E0], 0, DRUM_KITS - 1);
        return &loud_drum_db[k];
    }
    if (user_of(t) < UP_SLOTS)
        return &loud_user_db[user_of(t)];
    return &loud_factory_db[t->eng_req % NENGINES][t->preset & 127u];
}
UI_SMALL static int loudness_db(const track_t *t)
{
    uint8_t code = *loud_db_slot(t);
    return code ? (int)code - 11 : loud_default_db;
}
UI_SMALL static void loudness_db_set(const track_t *t, int db)
{
    *loud_db_slot(t) = db == loud_default_db ? 0u : (uint8_t)(db + 11);
}
UI_SMALL static void loudness_loaded(track_t *t)
{
    uint32_t p = trk_index(t);
    if (is_drum(t) || p >= NPART)
        return;
}
int ui_drum_loud(void)
{
    uint32_t k = (uint32_t)clamp(TDRUM->p[P_E0], 0, DRUM_KITS - 1);
    return loud_drum[k] != 0;
}
int ui_loud_q8(const track_t *t)
{
    static const uint16_t q8[21] = {81,91,102,114,128,144,161,181,203,228,256,287,322,362,406,456,512,575,645,724,812};
    return ui_loud_active(t) ? q8[clamp((int32_t)loudness_db(t) + 10, 0, 20)] : 256;
}
void loudness_adjust(int d)
{
    static char v[8];
    if (!ui_loud_active(TSEL)) { ui_say("LOUD ", "ON FIRST"); return; }
    { int db = clamp((int32_t)loudness_db(TSEL) + d, -10, 10);
      loudness_db_set(TSEL, db);
      v[0] = db >= 0 ? '+' : '-'; fmt_int(v + 1, db >= 0 ? db : -db); str_cpy(v + str_len(v), "dB", 3); }
    ui_say("LOUD ", v); loud_dirty = 1; settings_save();
}
UI_SMALL static void loudness_toggle(track_t *t)
{
    uint32_t p = trk_index(t);
    int on;
    if (is_drum(t)) {
        uint32_t k = (uint32_t)clamp(TDRUM->p[P_E0], 0, DRUM_KITS - 1);
        on = ui_drum_loud();
        loud_drum[k] = (uint8_t)!on;
        loud_drum_global = (uint8_t)!on;
        loud_dirty = 1;
        ui_say("LOUD ", on ? "OFF" : "ON");
        settings_save();
        return;
    }
    if (p >= NPART)
        return;
    on = ui_loud_active(t);
    if (user_of(t) < UP_SLOTS) {
        loud_user_bank[user_of(t)] = (uint8_t)!on;
    } else {
        loud_factory[t->eng_req % NENGINES][t->preset & 127u] = (uint8_t)!on;
    }
    ui_say("LOUD ", on ? "OFF" : "ON");
    loud_dirty = 1;
    settings_save();
}

#define ACC C_HI                   /* amber everywhere; white is the only accent */
#define VAL(c) ((c) == ui.hot_col && ui.hot_t ? C_WHITE : TE_COL[(c) & 3u])   /* LIVE: one colour per knob */
#define RATIO(d, v) ((d)->max > (d)->min ? ((int32_t)(v) - (d)->min) * 1000 / ((d)->max - (d)->min) : -1)
/* layout: four 60 px columns, 4 px inset */
/* Terminus 8x16 (S) and 16x32 (L) */
#define Y_HEAD 0
#define H_HEAD 20
#define Y_LABEL 26
#define Y_VALUE 44
#define Y_GAUGE 64
#define Y_SEP_END 98
#define Y_GRAPH 102
#define H_GRAPH 106
#define G_OY 24                       /* graphs draw in the lower 100 px; the focus readout sits on top */
#define Y_FOOT 208
#define H_FOOT 32

static struct {
    uint8_t home;
    uint8_t page;                /* index into PAGES */
    uint8_t fam_last[FAM_COUNT]; /* last page used per family */
    uint8_t bank;                /* SEQ: 16-step bank (follows the cursor) */
    uint8_t cursor;              /* SEQ: step being edited (STEP page KNOB 1 moves it) */
    uint8_t entry_open;          /* SEQ: keys held since the first press of this entry */
    uint8_t hot_col, hot_t;      /* column whose knob was just turned (drawn white) */
    uint8_t menu;                /* 0 off, 1 list, 2 about (HOME held) */
    uint8_t menu_sel;
    uint32_t menu_sig, home_t0;  /* HOME press time (btn_hold) */
    uint8_t force;               /* full redraw pending */
    uint8_t msg_t;               /* transient message frames */
    uint8_t bpm_t;               /* frames the BPM stays highlighted after a SELECT turn */
    uint8_t arm, arm_t;          /* destructive action armed: param id, frames left to confirm */
    uint32_t rec_t0;             /* REC press time (btn_hold) */
    uint8_t confirm;             /* 1 = "clear the sequence?" (REC held on SEQ / ARP), 2 = "clear track n?" (TRACKS) */
    uint8_t confirm_trk;         /* the track the dialog clears */
    uint8_t uslot;               /* SAVE > USER: the selected user preset slot */
    /* layers (ui_layers.c): a function button held, the keys and knobs do something else */
    uint8_t layer;               /* the layer drawn (LY_*), LY_PLAY = none */
    uint8_t layer_btn;           /* its button (B_*), NB = none */
    uint8_t layer_used;          /* a key / knob / OCT was used while it was held: no tap on release */
    uint32_t layer_t0;           /* its press time (ms) */
    uint8_t step_page;           /* SEQ layer: the 16 steps shown (page x 16) */
    uint16_t step_held;          /* SEQ layer: the step keys held (white key index) */
    uint32_t step_sess;          /* SEQ layer: the undo session of this hold */
    uint8_t lock_par;            /* SEQ layer, a step held + KNOB 4: the parameter it locks (the last sound
                                  * parameter a knob changed on a page of the selected track; P_ED_FLT at boot) */
    uint8_t hold_kind;           /* a hold to confirm: 1 = clear the track (REC), 2 = save (SAVE) */
    uint32_t hold_t0;            /* (ms) */
    uint8_t hold_trk;
    uint32_t tap_ms[4];          /* tap tempo: the last taps */
    uint8_t tap_n;
    char msg[24];
    uint32_t enc_t[NE];
    /* drawn-state cache */
    char col[4][32];
    char focus_l[8], focus_v[8], focus_u[8];   /* the touched column, shown large */
    char big_l[4][8], big_v[4][10], big_u[4][8];   /* the four columns, for the big values (2.4: pages without a graph) */
    uint16_t big_c[4];
    uint32_t graph_sig, head_sig, foot_sig, frame;
    uint8_t graph_top;           /* the graph strip's top G_OY rows hold something */
} ui;

UI_SMALL static const page_t *cur_page(void) { return &PAGES[ui.page]; }
static int32_t accel(uint32_t role, int32_t s, int32_t range);   /* ui_input.c */
static void layer_screen_draw(void);                            /* ui_layers.c */
static void hold_screen_draw(void);
static uint8_t layer_shown;

UI_SMALL static uint32_t page_first(uint32_t fam)
{
    uint32_t i;
    for (i = 0; i < NPAGES; i++)
        if (PAGES[i].fam == fam)
            return i;
    return 0;
}

/* transient message in the top bar: a + b */
UI_SMALL static void ui_say(const char *a, const char *b)
{
    uint32_t n;
    str_cpy(ui.msg, a, sizeof ui.msg);
    n = str_len(ui.msg);
    str_cpy(ui.msg + n, b, sizeof ui.msg - n);
    ui.msg_t = 40;
}

UI_SMALL static void ui_message(const char *s) { ui_say(s, ""); }

UI_SMALL static void page_entered(void)
{
    const page_t *pg = cur_page();
    song.seq_mode = !ui.home && pg->fam == FAM_SEQ;
    if (!ui.home && pg->fam == FAM_GLO && pg->id[0] == G_CH1 && song.g[G_ROUTE]) {   /* (2.6) GLO > MIDI while MIDI 2 >
                                                                                   * IN sets the channels aside */
        if (song.g[G_ROUTE] == 1)
            ui_message("IN = CLOCK: NO NOTES");
        else {
            char b[10];
            str_cpy(b, "IN CH ", sizeof b);
            fmt_int(b + 6, song.g[G_ROUTE] - 1);
            ui_say(b, ": SEL TRK ONLY");
        }
    }
    ui.entry_open = 0;
    ui.hot_t = 0;                                /* the white value / focus box was the old page's */
    ui.force = 1;
}

/* (2.6) GLO > MIDI: two tracks never share a channel (it would play the first only, the other silent): a channel
 * turned (a knob, the editor, a backup) onto one another track has goes on to the next free one, the way it was
 * turned, and says whose it was. Every frame (ui_input) */
UI_SMALL static void midi_chan_fix(void)
{
    static const uint8_t ID[4] = {G_CH1, G_CH2, G_CH3, G_DRCH};
    static int16_t was[4] = {-1, -1, -1, -1};
    uint32_t k, j;
    for (k = 0; k < 4u; k++) {
        int32_t v = song.g[ID[k]], dir, owner = -1;
        if (was[k] < 0 || v == was[k] || !v) {
            was[k] = (int16_t)v;
            continue;
        }
        dir = v > was[k] ? 1 : -1;
        for (;;) {
            int32_t o = -1;
            for (j = 0; j < 4u; j++)
                if (j != k && song.g[ID[j]] == v)
                    o = (int32_t)j;
            if (o < 0)
                break;
            if (owner < 0)
                owner = o;
            v += dir;
            if (v < 1) {                                /* (down past 1: OFF, never taken) */
                v = 0;
                break;
            }
            if (v > 16) {                               /* (none free up there: as it was) */
                v = was[k];
                break;
            }
        }
        if (owner >= 0) {
            char b[8];
            str_cpy(b, "CH ", sizeof b);
            fmt_int(b + 3, song.g[ID[k]]);
            ui_say(b, owner == 3 ? " = DRUMS" : owner == 0 ? " = TRACK 1" : owner == 1 ? " = TRACK 2" : " = TRACK 3");
            song.g[ID[k]] = (int16_t)v;
        }
        was[k] = (int16_t)v;
    }
}

UI_SMALL static int step_on(const step_t *st) { return st->time == ST_NOTE && st->n; }
/* LEN (SLOOP 2.6, after Felucca 1.5 by Leo Kuroshita, Discussions #178, #173): a NOTE step's length is the step and
 * the TIE steps after it (inside LEN, no wrap); SEQ > STEP's KNOB 3 on a note sets it (ui_input.c step_edit). Longer:
 * the steps after it become clean TIEs (a REST or an empty step; it stops at the next step holding notes, which stays,
 * and at LEN); shorter: its last TIEs become RESTs (one holding notes keeps them). The steps' locks and nudges stay;
 * the turns on one step are one undo (ui_input.c). Returns the length it got */
UI_SMALL static uint32_t note_len(const track_t *t, uint32_t i)
{
    uint32_t len = (uint32_t)clamp(t->p[P_SLEN], 1, NSTEP), n = 1;
    while (i + n < len && t->step[i + n].time == ST_TIE)
        n++;
    return n;
}
UI_SMALL static uint32_t note_set_len(track_t *t, uint32_t i, uint32_t want)
{
    uint32_t len = (uint32_t)clamp(t->p[P_SLEN], 1, NSTEP), n = note_len(t, i);
    for (; n > want && n > 1u; n--) {
        if (!t->step[i + n - 1u].n)                    /* (a TIE holding notes, from TIME or an older SLOOP, */
            memset(&t->step[i + n - 1u], 0, sizeof(step_t));   /* keeps them, as TIME would) */
        t->step[i + n - 1u].time = ST_REST;
    }
    for (; n < want && i + n < len && !t->step[i + n].n; n++) {
        memset(&t->step[i + n], 0, sizeof(step_t));
        t->step[i + n].time = ST_TIE;
    }
    return n;
}
/* a synth step's velocity as it plays (seq.c step_vel: ACC 127, else its VEL, 96 when 0, through its first note's level) */
UI_SMALL static uint32_t step_vel_shown(const step_t *st)
{
    uint32_t base = (st->flags & SF_ACCENT) ? 127u : (st->vel ? st->vel : 96u);
    return lvl_vel(st->lvl & 3u, base);
}
/* step i of track t has something to play (synth: notes, drums: a lane) */
UI_SMALL static int trk_step_on(const track_t *t, uint32_t i)
{
    return is_drum(t) ? dstep_mask(&t->dstep[i % NSTEP]) != 0u : step_on(&t->step[i % NSTEP]);
}

UI_SMALL static void step_clear(step_t *st)
{
    memset(st, 0, sizeof *st);
    st->time = ST_REST;
}

/* undo / redo (EDIT + OCT- / OCT+): the marked pattern and the one now swap places */
UI_SMALL static int undo_swap(int redo)
{
    track_t *t;
    int16_t len;
    if (!undo.valid || (uint32_t)!!redo != undo.undone)
        return 0;
    t = &trk[undo.trk % NTRK];
    fm1_irq_off();
    {
        uint32_t i;
        for (i = 0; i < NSTEP; i++) {
            step_t x = t->step[i];
            int8_t m = t->micro[i];
            t->step[i] = undo.st[i];
            undo.st[i] = x;
            t->micro[i] = undo.micro[i];                 /* (2.7) and its nudge */
            undo.micro[i] = m;
        }
    }
    len = t->p[P_SLEN];
    t->p[P_SLEN] = undo.len;
    undo.len = len;
    undo.undone = (uint8_t)!redo;
    fm1_irq_on();
    sync_reload = 1;
    ui.force = 1;
    return 1;
}

/* SEQ cursor: wraps inside the pattern length, the bank follows, a step entry ends */
UI_SMALL static void cursor_set(int32_t c)
{
    int32_t len = TSEL->p[P_SLEN] > 0 ? TSEL->p[P_SLEN] : 1;
    ui.cursor = (uint8_t)((c % len + len) % len);
    ui.bank = (uint8_t)(ui.cursor / 16u);
    ui.entry_open = 0;
}

UI_SMALL static void cursor_fix(void)                           /* LEN got shorter: onto the last step */
{
    if (ui.cursor >= (uint32_t)TSEL->p[P_SLEN])
        cursor_set(TSEL->p[P_SLEN] - 1);
}

UI_SMALL static void note_name(char *b, uint32_t n)
{
    str_cpy(b, N_NOTE[n % 12u], 4);
    fmt_int(b + str_len(b), (int32_t)(n / 12u) - 1);
}

UI_SMALL static void open_family(uint32_t fam)
{
    if (!ui.home && cur_page()->fam == fam) {          /* same button again: next page */
        uint32_t i = ui.page + 1u;
        while (i < NPAGES && PAGES[i].fam == fam && !page_shown(&PAGES[i]))
            i++;                                        /* (not a page of another engine: EDIT > FILTER) */
        if (i >= NPAGES || PAGES[i].fam != fam)
            i = page_first(fam);
        ui.page = (uint8_t)i;
    } else {
        ui.page = ui.fam_last[fam] && PAGES[ui.fam_last[fam]].fam == fam && page_shown(&PAGES[ui.fam_last[fam]])
                      ? ui.fam_last[fam] : (uint8_t)page_first(fam);
    }
    ui.fam_last[fam] = ui.page;
    ui.home = 0;
    page_entered();
}

/* SELECT on a page: the previous / next page of its family, as tapping the button again but both ways,
 * stopping at the ends. Not the screens of their own (SONG, DRUMS) nor a family of one page (TRACKS):
 * 0 then, and SELECT is the tempo there */
UI_SMALL static int page_walk(int32_t s)
{
    const page_t *pg = cur_page();
    uint32_t i, fam = pg->fam, n = 0;
    int32_t cur = -1, to;
    uint8_t idx[16];                               /* (2.7: GLO has 9 pages with MIDI 3) */
    if (ui.home || pg->scope == SC_SONG || pg->scope == SC_DRUM)
        return 0;
    for (i = 0; i < NPAGES && n < 16u; i++) {
        if (PAGES[i].fam != fam || PAGES[i].scope == SC_SONG || PAGES[i].scope == SC_DRUM || !page_shown(&PAGES[i]))
            continue;
        if (i == ui.page)
            cur = (int32_t)n;
        idx[n++] = (uint8_t)i;
    }
    if (n < 2u || cur < 0)
        return 0;
    to = clamp(cur + s, 0, (int32_t)n - 1);
    if (to != cur) {
        ui.page = idx[to];
        ui.fam_last[fam] = ui.page;
        page_entered();
    }
    return 1;
}

/* the page shown is one the selected track has (2.6: EDIT > FILTER, ANALOG only): after a track or engine change,
 * from the previous page of the family that it has (a hidden page is never the first one), once a frame */
UI_SMALL static void page_fix(void)
{
    uint32_t i = ui.page, fam = PAGES[i].fam;
    if (ui.home || page_shown(&PAGES[i]))
        return;
    while (i > 0u && PAGES[i - 1u].fam == fam && !page_shown(&PAGES[i - 1u]))
        i--;
    ui.page = (uint8_t)(i > 0u && PAGES[i - 1u].fam == fam ? i - 1u : page_first(fam));
    ui.fam_last[fam] = ui.page;
    page_entered();
}

UI_SMALL static void go_home(void)
{
#if FELUCCA_ARRANGER
    ui.home = 0;
    ui.page = (uint8_t)page_first(FAM_TRK);
#else
    ui.home = 1;
#endif
    ui.entry_open = 0;
    ui.hot_t = 0;
    song.seq_mode = 0;
    ui.force = 1;
}

/* ------------------------------------------------------- track setup --- */
/* LIVE: no factory sequence patterns. Loading a sound (factory or user preset) never
 * writes the sequencer: every pattern is the one the player records or enters. */

/* the parts' sounds at power-on (engine, preset): bass, pad, lead */
static const uint8_t TRK_DEF[NPART][2] = {{0, 2}, {1, 0}, {3, 1}, {6, 0}};   /* four synth defaults for the experiment */
UI_SMALL static uint32_t trk_def_engine(uint32_t i) { return i < NPART ? TRK_DEF[i][0] : 0u; }

UI_SMALL static int seq_is_empty(const track_t *t) { return track_empty(t); }

UI_SMALL static void track_defaults_steps(track_t *t) { steps_clear(t); }

/* what loading a sound (factory or user preset) leaves alone: the mix (LEVEL, PAN, MUTE:
 * the TRACKS faders, and the track FILTER), the pattern parameters (LEN, DIV, SWING, GATE) and the key the part plays
 * in (ROOT, SCALE, QNT, CHORD: the song's; SEL + key sets the root of every part). The SLICER is
 * part of the sound: a factory preset turns it OFF (its defaults), a user preset brings its own */
UI_SMALL static int param_kept(uint32_t i)
{
    return i == P_LEVEL || i == P_PAN || i == P_MUTE || (i >= P_SLEN && i <= P_SGATE) ||
           (i >= P_ROOT && i <= P_QUANT) || i == P_CHORD || i == P_TFLT || i == P_STRUM || i == P_VLEAD;
}

/* preset pi of the engine the track asked for: the whole sound (not the pattern parameters) */
/* Each loaded sound owns its arp settings. The previous arp must not latch into the next preset. */
UI_SMALL static void apply_preset_to(track_t *t, uint32_t pi)
{
    const engine_t *e = ENGINES[t->eng_req % NENGINES];
    uint32_t i;
    const preset_t *pr;
    int kbd_hold = !t->p[P_AMODE] && t->p[P_AHOLD];   /* (2.7: KBD HOLD stays on) */
    if (is_drum(t))
        return;
    arp_keep_req &= (uint8_t)~(1u << trk_index(t)); /* release the previous preset's held arp notes */
    sound_change(t);                                  /* (2.6: what sounds fades out with the old sound, no click) */
    panic_req |= (uint8_t)(1u << trk_index(t));       /* MONO/POLY may change: release what sounds */
    t->user = 0;
    if (t == TSEL)
        sync_reload = 1;
    if (!e->npresets)
        return;
    pi %= preset_logical_limit(t->eng_req); /* Spampy: logical IDs survive compacted preset tables. */
    pr = preset_data(t->eng_req % NENGINES, pi);
    if (!pr) return;
    t->preset = (uint8_t)pi;
    for (i = 0; i < P_E0; i++)                        /* the rest of the sound to its defaults: a preset */
        if (!param_kept(i) && !(kbd_hold && i == P_AHOLD))
            t->p[i] = TP[i].def;                     /* sounds the same after any edit (not the pattern, not the mix) */
    for (i = 0; i < 8u; i++)
        t->p[P_E0 + i] = (int16_t)pr->e[i];
    t->p[P_ATK] = pr->env[0];
    t->p[P_DEC] = pr->env[1];
    t->p[P_SUS] = pr->env[2];
    t->p[P_REL] = pr->env[3];
    t->p[P_ED_FLT] = pr->fenv;
    t->p[P_ED_FX] = preset_trim(t->eng_req % NENGINES, pi);  /* level-matched (tools/level_presets.py) */
    loudness_loaded(t);
    t->p[P_VOICE] = pr->mono ? V_LEGATO : V_POLY;   /* mono presets keep the legato feel */
    {   /* the rest of the patch: sends, arpeggiator (never a pattern: LIVE) */
        static const uint8_t FX_DEF[4] = {0, 24, 28, 36};
        
        for (i = 0; i < 4u; i++) {
            t->p[P_DIST + i] = (int16_t)(pr->fx[i] ? pr->fx[i] - 1 : FX_DEF[i]);
            t->p[P_AMODE + i] = (int16_t)(pr->arp[i] ? pr->arp[i] - 1 : TP[P_AMODE + i].def);
        }
        preset_extras(t->p, pr);                     /* glide, pitch / LFO modulation, voice mode */
    }
    fm6_track_loaded(t);                             /* FM6: the preset's patch (its PTCH) */
}

/* the engine's defaults and its first preset. With the audio IRQ off: the ISR sees the old engine with
 * its values or the new one with its own (voice.c engine_block), never one with the other's */
UI_SMALL static void set_engine_of(track_t *t, uint32_t ei)
{
    const engine_t *e = ENGINES[ei % NENGINES];
    uint32_t i;
    if (is_drum(t))
        return;
    fm1_irq_off();
    locks_restore(t);                                 /* (a lock in force: its base first, then the new sound) */
    sound_change(t);                                  /* (2.6: the sound as it is, before anything new is written) */
    t->eng_req = (uint8_t)(ei % NENGINES);
    for (i = 0; i < 8u; i++)
        t->p[P_E0 + i] = e->edit[i].def;
    apply_preset_to(t, 0);
    fm1_irq_on();
}

UI_SMALL static void apply_preset(uint32_t pi) { apply_preset_to(TSEL, pi); }
UI_SMALL static void set_engine(uint32_t ei) { set_engine_of(TSEL, ei); }

UI_SMALL static void track_defaults(track_t *t)
{
    uint32_t i;
    for (i = 0; i < P_E0; i++)
        t->p[i] = TP[i].def;
    track_defaults_steps(t);
}

/* switch engine (its defaults + first preset) and say so */
UI_SMALL static void select_engine(uint32_t e)
{
    if (is_drum(TSEL))
        return;
    set_engine(e);
    ui_say("ENGINE ", ENGINES[TSEL->eng_req]->name);
    ui.force = 1;
}

/* the factory presets as one list by kind (basses, keys, organs, pads, leads, plucks and bells, stabs,
 * the rest), then the used user presets: the PRESETS knob and the PRESETS page browse it. By name: an
 * engine's preset table may change order; tests/ui_pages_test.c checks every preset is here once */
enum { BK_BASS, BK_KEYS, BK_ORGAN, BK_PAD, BK_LEAD, BK_PLUCK, BK_STAB, BK_FX };
static const char *const BANK_KIND[] = {"BASS", "KEYS", "ORGN", "PAD", "LEAD", "PLCK", "STAB", "FX"};
static const struct { uint8_t kind, e; const char *name; } BANK[] = {
    {BK_BASS, 0, "NIGHT DRIVER"}, {BK_PAD, 0, "VHS PAD"},
    {BK_PAD, 0, "JUNO CHORUS"}, {BK_KEYS, 0, "POLY COMP"},
    {BK_KEYS, 1, "DX MARIMBA"}, {BK_LEAD, 6, "SEQ PULSE"},
    {BK_STAB, 6, "GATE STAB"}, {BK_PLUCK, ENGI_NOISE, "PPG BELL"},
    {BK_PAD, ENGI_NOISE, "WAVE STRINGS"},
    {BK_BASS, 6, "TURBO BASS"},
    {BK_LEAD, 6, "MIDNIGHT ARP"}, {BK_ORGAN, 7, "STREET ORGAN"},
    {BK_PAD, ENGI_NOISE, "CITY LIGHTS"},
    {BK_KEYS, ENGI_NOISE, "RETRO GLASS"},
    {BK_BASS, 0, "SUB BASS"}, {BK_BASS, 0, "PLUGG BASS"},
    {BK_BASS, 0, "FUNK BASS"}, {BK_BASS, 0, "SAW BASS"},
    {BK_BASS, 1, "FM BASS"},
    {BK_PAD, 0, "WARM PAD"},
    {BK_KEYS, 1, "DX RHODES"}, {BK_KEYS, 1, "WURLI"}, {BK_KEYS, 1, "M1 PIANO"},
    {BK_PLUCK, 1, "TRAP BELL"}, {BK_PLUCK, 1, "MUSIC BOX"}, {BK_PLUCK, 1, "PLUGG BELL"},
    {BK_PLUCK, 1, "GLOCKEN"}, {BK_PLUCK, 1, "CELESTA"}, {BK_PLUCK, 1, "HARP"},
    {BK_KEYS, 1, "FM GRAND"},
    {BK_LEAD, 0, "G-FUNK LD"}, {BK_LEAD, 0, "FAT LEAD"}, {BK_LEAD, 0, "PWM LEAD"},
    {BK_BASS, 2, "CZ BASS"}, {BK_STAB, 2, "CZ BRASS"},
    {BK_KEYS, 2, "SOFT KEYS"},
    {BK_LEAD, 3, "GAME LEAD"}, {BK_LEAD, 3, "8BIT ARP"}, {BK_STAB, 3, "CHIP CHORD"},
    {BK_PAD, 5, "SOUL OOH"}, {BK_PAD, 5, "VOX PAD"}, {BK_LEAD, 5, "TALKBOX"},
    {BK_STAB, 6, "MIN STAB"}, {BK_STAB, 6, "RAVE STAB"},
    {BK_PAD, 6, "SAW PAD"}, {BK_PAD, 6, "PULSE PAD"}, {BK_LEAD, 6, "SQR LEAD"},
    {BK_ORGAN, 7, "CHAPEL"},
    {BK_LEAD, ENGI_NOISE, "WAVE RUNNER"}, {BK_BASS, ENGI_NOISE, "CYBER BASS"},
    {BK_KEYS, ENGI_NOISE, "GLASS MOTION"}, {BK_PAD, ENGI_NOISE, "VECTOR PAD"},
    {BK_PLUCK, ENGI_NOISE, "ICE PLUCK"},
    {BK_PAD, ENGI_NOISE, "NEON SWEEP"}, {BK_KEYS, ENGI_NOISE, "POLY PIXEL"},
    {BK_LEAD, ENGI_NOISE, "ORBIT ARP"}, {BK_BASS, ENGI_NOISE, "DEEP VECTOR"},
    {BK_BASS, 0, "REESE"},
    {BK_BASS, 0, "ACID 303"},
    {BK_BASS, 0, "MONO BASS"},
    {BK_KEYS, 1, "RHODES"},
    {BK_KEYS, 1, "DX7 EP"},
    {BK_KEYS, 1, "AFRO KEYS"},
    {BK_KEYS, ENGI_FM6, "TINE EP"},
    {BK_ORGAN, 7, "JAZZ ORGAN"},
    {BK_ORGAN, ENGI_FM6, "DRAWBARS"},
    {BK_ORGAN, 6, "ACCORDION"},
    {BK_PAD, 1, "GLASS PAD"},
    {BK_PAD, 0, "DARK STR"},
    {BK_PAD, 2, "CZ STRING"},
    {BK_PAD, 0, "ATMOS PAD"},
    {BK_PAD, ENGI_FM6, "SOFT PAD"},
    {BK_PAD, 6, "ENSEMBLE"},
    {BK_PAD, 2, "CZ PAD"},
    {BK_PAD, 0, "SINE PAD"},
    {BK_PAD, 1, "JUNO CLOUD"},
    {BK_PAD, 1, "JP8 SLOW"},
    {BK_PAD, 0, "JUNO STRINGS"},
    {BK_PAD, 1, "JP8 STRINGS"},
    {BK_PAD, 1, "DX7 STRINGS"},
    {BK_PAD, 5, "M1 STRINGS"},
    {BK_PAD, 0, "JP8 PAD"},
    {BK_LEAD, 0, "SUPERSAW"},
    {BK_LEAD, 6, "SYNC LEAD"},
    {BK_LEAD, 0, "JUNO LEAD"},
    {BK_LEAD, 3, "WAVE LEAD"},
    {BK_LEAD, 2, "CZ LEAD"},
    {BK_PLUCK, 0, "TRAP PLUCK"},
    {BK_PLUCK, 1, "KALIMBA"},
    {BK_PLUCK, 1, "MARIMBA"},
    {BK_PLUCK, ENGI_FM6, "NYLON PICK"},
    {BK_BASS, ENGI_FM6, "DX BASS 2"}, {BK_BASS, ENGI_FM6, "DX BASS 4"},
    {BK_BASS, ENGI_FM6, "DX BASS 5"}, {BK_BASS, ENGI_FM6, "DX BASS 6"},
    {BK_BASS, ENGI_FM6, "DX BASS 8"}, {BK_KEYS, ENGI_FM6, "TUB BELLS"},
    {BK_KEYS, ENGI_FM6, "FINGERCIM"}, {BK_KEYS, ENGI_FM6, "TIBET"},
    {BK_PAD, ENGI_FM6, "SYN PAD"}, {BK_PAD, ENGI_FM6, "SYN PAD 2"},
    {BK_PAD, ENGI_FM6, "STRING 1"}, {BK_PAD, ENGI_FM6, "STRING 5"},
    {BK_PAD, ENGI_FM6, "STRING 6"}, {BK_PAD, ENGI_FM6, "STRING 7"},
    {BK_STAB, ENGI_FM6, "BRASS 6"}, {BK_STAB, ENGI_FM6, "BRASS 8"},
    {BK_LEAD, ENGI_FM6, "TORIM TORA"},
    {BK_PLUCK, 3, "1BIT BEEP"},
    {BK_PLUCK, 1, "TUBE BELL"},
    {BK_PLUCK, 1, "DX7 BELL"},
    {BK_STAB, 0, "SYN BRASS"},
    {BK_STAB, 6, "80S POLY"},
    {BK_STAB, 6, "POWER STAB"},
    {BK_STAB, 0, "JP8 BRASS"},
    {BK_FX, 4, "GM KIT"},

    {BK_STAB, ENGI_PROPHET, "STABBY BRASS"},
    {BK_KEYS, ENGI_PROPHET, "FANTASTIC FIVE"},
    {BK_PAD, ENGI_PROPHET, "TAARI CHOIR"},
    {BK_PAD, ENGI_PROPHET, "REEDY STRING PA"},
    {BK_STAB, ENGI_PROPHET, "BORN IN THE 80'"},

    {BK_BASS, ENGI_PROPHET, "TUMESCENT BASS"},
    {BK_PAD, ENGI_PROPHET, "INTERNALIZED"},
    {BK_PAD, ENGI_PROPHET, "TANGERINE CHRCH THM"},
    {BK_BASS, ENGI_PROPHET, "FAT POLY BASS"},
    {BK_PAD, ENGI_PROPHET, "CHORAL VOICES"},
    {BK_PAD, ENGI_PROPHET, "MIDNIGHT PWM"},
    {BK_PAD, ENGI_PROPHET, "RIPPLES"},
    {BK_PAD, ENGI_PROPHET, "AGGRO SYNTH"},
    {BK_PAD, ENGI_PROPHET, "80S HORROR STRINGS"},
    {BK_PAD, ENGI_PROPHET, "PULSE PLUCK"},
    {BK_PAD, ENGI_PROPHET, "UNISAWYER"},
    {BK_PAD, ENGI_PROPHET, "GHOSTLY GLOW"},
    {BK_PAD, ENGI_PROPHET, "HOLLOW DREAMS"},
    {BK_STAB, ENGI_PROPHET, "PINK NEON BRASS"},
    {BK_PAD, ENGI_PROPHET, "PLUCK HOLLOW"},
    {BK_STAB, ENGI_PROPHET, "SOFT BRASS"},
    {BK_PAD, ENGI_PROPHET, "REGAL MOVEMENT"},
    {BK_PAD, ENGI_PROPHET, "RUBBER BUMPER"},
    {BK_PAD, ENGI_PROPHET, "SOFT SWELL"},
    {BK_PAD, ENGI_PROPHET, "FULL HEXAGON"},
    {BK_STAB, ENGI_PROPHET, "ICONIC BRASS"},
    {BK_PAD, ENGI_PROPHET, "SYNC SWELLPAD"},
    {BK_BASS, ENGI_PROPHET, "FEATURE MY BASS"},
    {BK_KEYS, ENGI_PROPHET, "NAIVE MELODY"},
    {BK_PAD, ENGI_PROPHET, "SWITCHBACK"},
    {BK_BASS, ENGI_PROPHET, "TIGHT BASS (556?)"},
    {BK_PAD, ENGI_PROPHET, "LOW STRINGS"},
    {BK_PAD, ENGI_PROPHET, "PULSE WIDTH MOD"},
    {BK_PAD, ENGI_PROPHET, "UNISON GLIDE W RES"},
    {BK_KEYS, ENGI_PROPHET, "TOY PIANO"},
    {BK_PAD, ENGI_PROPHET, "INIT PROPHET"},
    {BK_PAD, ENGI_PROPHET, "IT'S A PROPHET 5"},
    {BK_KEYS, ENGI_PROPHET, "FOREVER KEYS"},

    {BK_PAD, ENGI_FM6, "PAD"},
    {BK_STAB, ENGI_CZ, "BRASS 3"},
    {BK_PAD, ENGI_CZ, "STRINGS 2"},
    {BK_PAD, ENGI_CZ, "SYN STRINGS"},
    {BK_PAD, ENGI_CZ, "FAT ENSEMBLE"},
    {BK_PAD, ENGI_SID, "PWM PAD"},
    {BK_PAD, ENGI_SID, "SID STRINGS"},
    {BK_LEAD, ENGI_OBERVAVE, "UNISON LD"},
    {BK_PAD, ENGI_OBERVAVE, "PWM STRING"},
    {BK_PAD, ENGI_OBERVAVE, "SWEEP PAD"},
    {BK_PAD, ENGI_OBERVAVE, "NEON PAD"},
    {BK_PLUCK, ENGI_OBERVAVE, "DREAM ARP"},
    {BK_STAB, ENGI_OBERVAVE, "BIG BRASS"},
    {BK_STAB, ENGI_OBERVAVE, "HORN SECT"},
    {BK_PAD, ENGI_OBERVAVE, "WARM PAD"},
    {BK_PAD, ENGI_OBERVAVE, "DARK PAD"},
    {BK_PAD, ENGI_OBERVAVE, "AIR CHOIR"},
    {BK_PAD, ENGI_OBERVAVE, "SLOW SWEEP"},
    {BK_PAD, ENGI_OBERVAVE, "GHOST PAD"},
    {BK_PAD, ENGI_OBERVAVE, "OB ENSEMBLE"},
    {BK_KEYS, ENGI_OBERVAVE, "TAPE KEYS"},
    {BK_LEAD, ENGI_OBERVAVE, "PWM LEAD"},
    {BK_PAD, ENGI_DRONE, "NIGHT FOG"},
    {BK_PAD, ENGI_DRONE, "DEEP SPACE"},
    {BK_PAD, ENGI_DRONE, "AURORA AIR"},
    {BK_PAD, ENGI_DRONE, "CATHEDRAL HUM"},
    {BK_PAD, ENGI_DRONE, "DARK TIDE"},
    {BK_PAD, ENGI_DRONE, "ABYSS CHOIR"},
    {BK_PAD, ENGI_DRONE, "VIOLET CLOUD"},
    {BK_PAD, ENGI_DRONE, "ECLIPSE"},
#if 0 /* Removed experimental r1038 browser entries. */
    {BK_BASS, 0, "MIAMI BASS"}, {BK_BASS, 0, "NIGHT DRIVE"}, {BK_BASS, 0, "VICE SUB"},
    {BK_LEAD, 0, "NEON PULSE"}, {BK_LEAD, 0, "LASER LEAD"}, {BK_LEAD, 0, "SKYLINE LEAD"}, {BK_LEAD, 0, "CRYSTAL LEAD"},
    {BK_KEYS, 0, "VHS KEYS"}, {BK_KEYS, 0, "CASSETTE KEYS"},
    {BK_PAD, 0, "POLY SUNSET"}, {BK_PAD, 0, "ULTRAVIOLET PAD"}, {BK_PAD, 0, "NOCTURNE PAD"},
    {BK_PAD, 0, "OCEAN PAD"}, {BK_PAD, 0, "PRISM PAD"}, {BK_PAD, 0, "RAINY CITY"}, {BK_PAD, 0, "CELESTIAL STR"},
    {BK_STAB, 0, "TITANIUM BRASS"}, {BK_STAB, 0, "MAGENTA BRASS"},
    {BK_PLUCK, 0, "DIGITAL CRYSTALS"}, {BK_PLUCK, 0, "FM CHIMES"}, {BK_PLUCK, 0, "ARCADE PLUCK"},
#endif
};
#define NBANK (sizeof BANK / sizeof BANK[0])
/* r977 stored loudness and favourites by their BANK position.  These are the
 * surviving r977 positions after the eight requested removals, so an update
 * keeps settings attached to their original sounds. */
static const uint8_t BANK_R977_TO_R978[115] = {
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    0xFF, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 0xFF, 29,
    0xFF, 30, 31, 32, 33, 34, 0xFF, 35, 0xFF, 36, 37, 38, 39, 40, 41, 42,
    43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58,
    59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 0xFF, 71, 0xFF, 72,
    73, 74, 75, 76, 77, 0xFF, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87,
    88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103,
    104, 105, 106,
};
UI_SMALL static uint16_t bank_r977_to_r978(uint16_t n)
{
    if (n & 0x8000u)
        return n;                              /* user preset favourite */
    if (n >= 115u || BANK_R977_TO_R978[n] == 0xFFu)
        return 0xFFFFu;
    return BANK_R977_TO_R978[n];
}
static uint8_t bank_pi[NBANK];                       /* the preset index of each entry in its engine */
static uint8_t bank_ready;
UI_SMALL static void bank_resolve(void)
{
    uint32_t i, k;
    for (i = 0; i < NBANK; i++) {
        bank_pi[i] = 0xFF;
        for (k = 0; k < preset_logical_limit(BANK[i].e); k++) { /* resolve logical IDs, including the added presets */
            const preset_t *pr = preset_data(BANK[i].e % NENGINES, k);
            if (pr && str_eq(pr->name, BANK[i].name)) bank_pi[i] = (uint8_t)k;
        }
    }
    bank_ready = 1;
}

/* The bank's display name is sometimes richer than the engine preset name
 * (for example "80S POLY" instead of "TRIO").  Keep that name on a USER copy. */
UI_SMALL static const char *up_source_name(const track_t *t)
{
    uint32_t i;
    const preset_t *pr;
    if (t->user || is_drum(t))
        return 0;
    if (!bank_ready)
        bank_resolve();
    for (i = 0; i < NBANK; i++)
        if (BANK[i].e == t->eng_req && bank_pi[i] == t->preset)
            return BANK[i].name;
    pr = preset_data(t->eng_req % NENGINES, t->preset % preset_logical_limit(t->eng_req));
    return pr ? pr->name : ENGINES[t->eng_req % NENGINES]->name;
}
/* A USER sound with the same name and engine as a factory sound is its saved
 * edit.  Put it immediately after that factory sound: this keeps the original
 * intact and lets PRESETS move from original to edited copy with one turn. */
UI_SMALL static int up_matches_bank(uint32_t slot, uint32_t bi)
{
    return up_used(slot) && up_source_bank(slot) == bi;
}
UI_SMALL static int up_matches_any_bank(uint32_t slot)
{
    uint32_t i;
    for (i = 0; i < NBANK; i++)
        if (up_matches_bank(slot, i))
            return 1;
    return 0;
}
UI_SMALL static uint32_t base_factory_pos(uint32_t wanted)
{
    uint32_t i, k, n = 0;
    for (i = 0; i < NBANK; i++) {
        if (i == wanted)
            return n;
        n++;
        for (k = 0; k < UP_SLOTS; k++)
            n += (uint32_t)up_matches_bank(k, i);
    }
    return n;
}
UI_SMALL static uint32_t base_user_pos(uint32_t wanted)
{
    uint32_t i, k, n = 0;
    for (i = 0; i < NBANK; i++) {
        n++;
        for (k = 0; k < UP_SLOTS; k++)
            if (up_matches_bank(k, i)) {
                if (k == wanted)
                    return n;
                n++;
            }
    }
    for (k = 0; k < UP_SLOTS; k++)
        if (up_used(k) && !up_matches_any_bank(k)) {
            if (k == wanted)
                return n;
            n++;
        }
    return n;
}
UI_SMALL static uint32_t base_pos(uint32_t *total)            /* list index of the selected track's preset (no favourites) */
{
    uint32_t i, cur = 0;
    if (!bank_ready)
        bank_resolve();
    if (user_of(TSEL) < UP_SLOTS)
        cur = base_user_pos(user_of(TSEL));
    else
        for (i = 0; i < NBANK; i++)
            if (BANK[i].e == TSEL->eng_req && bank_pi[i] == TSEL->preset) {
                cur = base_factory_pos(i);
                break;
            }
    *total = NBANK + up_count();
    return cur;
}

/* list index n (< total) -> engine, *k its preset; NENGINES = user preset, *k its slot (no favourites) */
UI_SMALL static uint32_t base_at(uint32_t n, uint32_t *k)
{
    uint32_t i, s;
    if (!bank_ready)
        bank_resolve();
    for (i = 0; i < NBANK; i++) {
        if (!n--) {
            *k = bank_pi[i] == 0xFF ? 0u : bank_pi[i];
            return BANK[i].e;
        }
        for (s = 0; s < UP_SLOTS; s++)
            if (up_matches_bank(s, i) && !n--) {
                *k = s;
                return NENGINES;
            }
    }
    for (s = 0; s < UP_SLOTS; s++)
        if (up_used(s) && !up_matches_any_bank(s) && !n--) {
            *k = s;
            return NENGINES;
        }
    *k = 0;
    return NENGINES;
}
UI_SMALL static const char *base_kind(uint32_t n)
{
    uint32_t i, s;
    for (i = 0; i < NBANK; i++) {
        if (!n--)
            return BANK_KIND[BANK[i].kind];
        for (s = 0; s < UP_SLOTS; s++)
            if (up_matches_bank(s, i) && !n--)
                return "USER";
    }
    return "USER";
}

/* SLOOP 2.7: favourites (PRESETS page, KNOB 4): up to 16 sounds at the top of the PRESETS list, kept in the FM-1's
 * settings (project.c, the settings' side record). An entry: a factory sound, its BANK index; a user preset, FAV_USER |
 * its slot (an erased one is left out of the list). Program Change keeps the list without them (pc_poll) */
#define FAV_N 16u
#define FAV_NONE 0xFFFFu
#define FAV_USER 0x8000u
static uint16_t fav[FAV_N] = {FAV_NONE, FAV_NONE, FAV_NONE, FAV_NONE, FAV_NONE, FAV_NONE, FAV_NONE, FAV_NONE,
                              FAV_NONE, FAV_NONE, FAV_NONE, FAV_NONE, FAV_NONE, FAV_NONE, FAV_NONE, FAV_NONE};
static uint8_t fav_dirty;                            /* changed since the settings were written */
static int8_t fav_at = -1;                           /* the favourite the selected track's sound was loaded from */
UI_SMALL static uint32_t fav_list(uint32_t *b)                /* the favourites as base list indices, in order */
{
    uint32_t i, n = 0;
    for (i = 0; i < FAV_N; i++) {
        uint32_t f = fav[i];
        if (f == FAV_NONE)
            continue;
        if (f & FAV_USER) {
            if (!up_used(f & 0xFFu))
                continue;
            b[n++] = base_user_pos(f & 0xFFu);
        } else if (f < NBANK) {
            b[n++] = base_factory_pos(f);
        }
    }
    return n;
}
UI_SMALL static uint32_t fav_key(void)                        /* the selected track's sound as a favourite entry */
{
    uint32_t i;
    if (!bank_ready)
        bank_resolve();
    if (user_of(TSEL) < UP_SLOTS)
        return FAV_USER | user_of(TSEL);
    for (i = 0; i < NBANK; i++)
        if (BANK[i].e == TSEL->eng_req && bank_pi[i] == TSEL->preset)
            return i;
    return FAV_NONE;
}
UI_SMALL static int fav_has(uint32_t key)
{
    uint32_t i;
    for (i = 0; i < FAV_N; i++)
        if (key != FAV_NONE && fav[i] == key)
            return 1;
    return 0;
}
UI_SMALL static void fav_toggle(int add)                      /* KNOB 4 on the PRESETS page: right adds, left removes */
{
    uint32_t key = fav_key(), i;
    if (key == FAV_NONE || is_drum(TSEL))
        return;
    if (add) {
        if (fav_has(key)) {
            ui_message("FAV: ALREADY");
            return;
        }
        for (i = 0; i < FAV_N && fav[i] != FAV_NONE; i++)
            ;
        if (i == FAV_N) {
            ui_message("FAVS FULL (16)");
            return;
        }
        fav[i] = (uint16_t)key;
        ui_message("FAV ADDED");
    } else {
        for (i = 0; i < FAV_N && fav[i] != key; i++)
            ;
        if (i == FAV_N)
            return;
        for (; i + 1u < FAV_N; i++)                  /* (the order kept) */
            fav[i] = fav[i + 1u];
        fav[FAV_N - 1u] = FAV_NONE;
        fav_at = -1;
        ui_message("FAV REMOVED");
    }
    fav_dirty = 1;
    ui.force = 1;
}
/* (2.7) the settings' side record: the theme (40 bytes, zero: none), then the favourites (ui.c fav) with a magic and a
 * CRC. A 2.7 beta wrote the theme alone (the rest erased: no favourites); an older SLOOP never reads it */
#define FAVS_MAGIC 0x32564146u                      /* "FAV2" */
#define FAVS_MAGIC_R977 0x31564146u                 /* "FAV1" */
typedef struct {
    theme_t th;
    uint32_t fmagic;
    uint16_t fav[FAV_N];
    uint32_t fcrc;
    uint32_t lmagic;
    uint8_t lfactory[16], ldrum[6], luser[UP_SLOTS]; int8_t ldefault;
    /* Up to 24 individual dB overrides: 5 bits value, 7 bits item, 2 bits class.
     * Defaults need no entry, which leaves room in the fixed 192-byte side record. */
    uint16_t ldb_entry[24];
    uint32_t lcrc;
} side_rec_t;
#define LUD5_MAGIC 0x3544554Cu                         /* "LUD5": independent dB values */
#define LUD_OLD_CRC_LEN (4u + sizeof ((side_rec_t *)0)->lfactory + sizeof ((side_rec_t *)0)->ldrum + sizeof ((side_rec_t *)0)->luser)
#define LUD5_CRC_LEN (__builtin_offsetof(side_rec_t, lcrc) - __builtin_offsetof(side_rec_t, lmagic))
#define LUD_KIND_FACTORY 1u
#define LUD_KIND_DRUM    2u
#define LUD_KIND_USER    3u
UI_SMALL static void side_level_put(side_rec_t *r, uint32_t kind, uint32_t item, uint8_t code)
{
    uint32_t i;
    if (!code || code > 21u || item > 127u || (int)code - 11 == loud_default_db)
        return;
    for (i = 0; i < sizeof r->ldb_entry / sizeof r->ldb_entry[0]; i++)
        if (!r->ldb_entry[i]) { r->ldb_entry[i] = (uint16_t)(code | (item << 5) | (kind << 12)); return; }
}
UI_SMALL static void side_fill(side_rec_t *r)                /* what the settings' side record holds now */
{
    memset(r, 0, sizeof *r);
    if (theme_valid)
        r->th = theme;
    r->fmagic = FAVS_MAGIC;
    memcpy(r->fav, fav, sizeof fav);
    r->fcrc = st_crc32(&r->fmagic, 4u + sizeof r->fav);
    r->lmagic = LUD5_MAGIC;
    memset(r->lfactory, 0, sizeof r->lfactory);
    memset(r->ldrum, 0, sizeof r->ldrum);
    memcpy(r->luser, loud_user_bank, sizeof r->luser);
    r->ldefault = loud_default_db;
    { uint32_t p;
      bank_resolve();
      for (p = 0; p < NBANK; p++) {
          /* The fixed settings side-record has bits for its first 128 factory
           * sounds.  Extra restored originals still browse normally; they
           * simply use the global LOUD level rather than writing past this
           * record and corrupting the preset list. */
          if (p < sizeof r->lfactory * 8u) {
              if (loud_factory[BANK[p].e][bank_pi[p]]) r->lfactory[p >> 3] |= (uint8_t)(1u << (p & 7u));
              side_level_put(r, LUD_KIND_FACTORY, p, loud_factory_db[BANK[p].e][bank_pi[p]]);
          }
      }
      for (p = 0; p < DRUM_KITS; p++) {
          if (loud_drum[p]) r->ldrum[p >> 3] |= (uint8_t)(1u << (p & 7u));
          side_level_put(r, LUD_KIND_DRUM, p, loud_drum_db[p]);
      }
      for (p = 0; p < UP_SLOTS; p++) side_level_put(r, LUD_KIND_USER, p, loud_user_db[p]);
    }
    r->lcrc = st_crc32(&r->lmagic, LUD5_CRC_LEN);
}
UI_SMALL static void side_take(side_rec_t *r)                /* a side record read back: what checks out (theme, favourites) */
{
    if (theme_check(&r->th)) {
        theme = r->th;
        theme_valid = 1;
    }
    if ((r->fmagic == FAVS_MAGIC || r->fmagic == FAVS_MAGIC_R977) &&
        r->fcrc == st_crc32(&r->fmagic, 4u + sizeof r->fav)) {
        uint32_t p;
        memcpy(fav, r->fav, sizeof fav);
        if (r->fmagic == FAVS_MAGIC_R977)
            for (p = 0; p < FAV_N; p++) fav[p] = bank_r977_to_r978(fav[p]);
    }
    if ((r->lmagic == LUD5_MAGIC || r->lmagic == 0x3444554Cu || r->lmagic == 0x3344554Cu || r->lmagic == 0x3244554Cu) &&
        r->lcrc == st_crc32(&r->lmagic, r->lmagic == LUD5_MAGIC ? LUD5_CRC_LEN : LUD_OLD_CRC_LEN)) {
        uint32_t p;
        memcpy(loud_user_bank, r->luser, sizeof loud_user_bank);
        memset(loud_factory, 0, sizeof loud_factory);
        memset(loud_drum, 0, sizeof loud_drum);
        memset(loud_factory_db, 0, sizeof loud_factory_db);
        memset(loud_drum_db, 0, sizeof loud_drum_db);
        memset(loud_user_db, 0, sizeof loud_user_db);
        loud_default_db = (r->lmagic == LUD5_MAGIC || r->lmagic == 0x3444554Cu) ?
            (int8_t)clamp(r->ldefault, -10, 10) : 9;
        bank_resolve();
        if (r->lmagic == 0x3244554Cu) {          /* r977: remap old BANK positions */
            for (p = 0; p < 115u; p++) {
                uint32_t n = BANK_R977_TO_R978[p];
                if (n != 0xFFu && ((r->lfactory[p >> 3] >> (p & 7u)) & 1u))
                    loud_factory[BANK[n].e][bank_pi[n]] = 1;
            }
        } else {
            for (p = 0; p < NBANK && p < sizeof r->lfactory * 8u; p++)
                loud_factory[BANK[p].e][bank_pi[p]] = (uint8_t)((r->lfactory[p >> 3] >> (p & 7u)) & 1u);
        }
        for (p = 0; p < DRUM_KITS; p++) loud_drum[p] = (uint8_t)((r->ldrum[p >> 3] >> (p & 7u)) & 1u);
        if (r->lmagic == LUD5_MAGIC) {
            for (p = 0; p < sizeof r->ldb_entry / sizeof r->ldb_entry[0]; p++) {
                uint16_t e = r->ldb_entry[p]; uint32_t kind = e >> 12, item = (e >> 5) & 127u, code = e & 31u;
                if (!e || code < 1u || code > 21u) continue;
                if (kind == LUD_KIND_FACTORY && item < NBANK) loud_factory_db[BANK[item].e][bank_pi[item]] = (uint8_t)code;
                else if (kind == LUD_KIND_DRUM && item < DRUM_KITS) loud_drum_db[item] = (uint8_t)code;
                else if (kind == LUD_KIND_USER && item < UP_SLOTS) loud_user_db[item] = (uint8_t)code;
            }
        }
    }
}
/* the PRESETS list: the favourites, then every factory sound by kind, then the user presets */
UI_SMALL static uint32_t preset_pos(uint32_t *total)
{
    uint32_t b[FAV_N], nf = fav_list(b), cur = base_pos(total);
    *total += nf;
    if (fav_at >= 0 && (uint32_t)fav_at < nf && b[fav_at] == cur)
        return (uint32_t)fav_at;
    return nf + cur;
}
UI_SMALL static uint32_t preset_at(uint32_t n, uint32_t *k)
{
    uint32_t b[FAV_N], nf = fav_list(b);
    return base_at(n < nf ? b[n] : n - nf, k);
}
UI_SMALL static const char *preset_kind(uint32_t n)
{
    uint32_t b[FAV_N], nf = fav_list(b);
    return n < nf ? "FAV" : base_kind(n - nf);
}

/* list index n into track t (2.6: MIDI Program Change, any track); 0 done, 1 no such sound */
UI_SMALL static int preset_go_to(track_t *t, uint32_t n)
{
    uint32_t k, total, e;
    if (is_drum(t))
        return 1;
    if (!bank_ready)
        bank_resolve();
    total = NBANK + up_count();
    if (n >= total)
        return 1;
    e = base_at(n, &k);                              /* (2.7: the list without the favourites: PC n as before) */
    if (e == NENGINES)
        return up_load_to(t, k);
    if (e != t->eng_req)
        set_engine_of(t, e);
    apply_preset_to(t, k);
    ui.force = 1;
    return 0;
}
/* MIDI Program Change (2.6, after Felucca 1.5.1, PR #179 by @renebohne): seq.c queues it per track (the track its
 * channel plays, GLO > MIDI); here, in the main loop (a flash read, a sound loaded): a synth track takes the n-th sound
 * of the PRESETS list (0 the first factory sound, the user presets after the 153), the drum track kit n. A number past
 * the end does nothing (no wrap) */
UI_SMALL static void pc_poll(void)
{
    uint32_t i;
    for (i = 0; i < NTRK; i++) {
        uint32_t r = pc_req[i], n;
        char b[12];
        if (!r)
            continue;
        pc_req[i] = 0;
        n = r - 1u;
        if (is_drum(&trk[i])) {
            if (n >= DRUM_KITS)
                continue;
            trk[i].p[P_E0] = (int16_t)n;
            if (&trk[i] == TSEL)
                sync_reload = 1;
        } else if (preset_go_to(&trk[i], n)) {
            continue;
        }
        str_cpy(b, "T1 PROG ", sizeof b);
        b[1] = (char)('1' + i);
        fmt_int(b + 8, (int32_t)n);
        ui_message(b);
        ui.force = 1;
    }
}
UI_SMALL static void preset_go(uint32_t n)                    /* load list index n into the selected track */
{
    uint32_t k, e = preset_at(n, &k), b[FAV_N];
    if (is_drum(TSEL))
        return;                                      /* one GM kit: nothing to browse */
    fav_at = (int8_t)(n < fav_list(b) ? (int32_t)n : -1);
    if (e == NENGINES) {
        up_load(k);
        return;
    }
    if (e != TSEL->eng_req)
        select_engine(e);
    apply_preset(k);
    ui.force = 1;
}

/* HOME: what KNOB k edits: the engine's four main parameters; on the drum track
 * LEVEL and REV (GLO > DRUMS), PAN and LEN */
UI_SMALL static const param_desc_t *home_param(uint32_t k, int16_t **vp)
{
    static const uint8_t DRUM_HOME[4][2] = {{1, G_DRLVL}, {1, G_DRREV}, {0, P_PAN}, {0, P_SLEN}};
    uint32_t id;
    if (is_drum(TSEL)) {
        id = DRUM_HOME[k & 3u][1];
        if (DRUM_HOME[k & 3u][0]) {
            *vp = &song.g[id];
            return &GP[id];
        }
        *vp = &TSEL->p[id];
        return &TP[id];
    }
    id = ENGINES[TSEL->eng_req % NENGINES]->macro[k & 3u];
    *vp = &TSEL->p[id];
    return track_desc(TSEL, id);
}

/* select track i (KNOB 1 on TRACKS, the editor): its sound, pages and pattern from now on */
UI_SMALL static void track_select(uint32_t i)
{
    if (i >= NTRK || i == song.sel)
        return;
    song.sel = (uint8_t)i;
    rec_follow(i);                                   /* LIVE: recording follows the selected track */
    ui.entry_open = 0;
    ui.cursor = 0;
    ui.bank = 0;
    sync_reload = 1;
    ui.force = 1;
}

/* ------------------------------------------------------- MIDI LEARN --- */
/* MIDI LEARN (SLOOP 2.6, after Felucca 1.5 by Leo Kuroshita, Discussion #170; the map: seq.c ml_tab). GLO held +
 * the black key F#3 turns it on and off. On: a knob turned on a track's page (the sound's pages, HOME, TRACKS' LEVEL
 * and PAN) picks its parameter on the selected track as it edits it; the next CC that comes (any channel IN hears) is
 * set to it, and stays until something else is learned on it or HOME > SYSTEM > LEARN CLEAR. Then turn the next knob.
 * One CC sets one parameter, a parameter has one CC: learning one again replaces both. The settings keep the map */
static struct { uint8_t on, pick, trk, id; } mlu;
UI_SMALL static uint32_t ml_code(uint32_t id) { return id >= P_E0 ? ML_E0 + id - P_E0 : id + 1u; }
UI_SMALL static void ml_put(uint32_t i, uint32_t e)       /* (the ISR reads the entry: never half of one) */
{
    fm1_irq_off();
    ml_tab[i % ML_N] = (uint16_t)e;
    fm1_irq_on();
}
UI_SMALL static uint32_t ml_count(void)
{
    uint32_t i, n = 0;
    for (i = 0; i < ML_N; i++)
        n += (ml_tab[i] >> 9) != 0u;
    return n;
}
/* cc -> parameter id of track k, in place of what either had; 0 = no room, 2 = a CC that is never learned */
UI_SMALL static uint32_t ml_learn(uint32_t cc, uint32_t k, uint32_t id)
{
    uint32_t i, e;
    if (!ml_free_cc(cc) || k >= NTRK || id >= P_COUNT)
        return 2;
    for (i = 0; i < ML_N; i++)
        if ((e = ml_tab[i]) >> 9 && ((e & 127u) == cc || ((e >> 9) == ml_code(id) && ((e >> 7) & 3u) == k)))
            ml_put(i, 0);
    for (i = 0; i < ML_N; i++)
        if (!(ml_tab[i] >> 9)) {
            ml_put(i, cc | k << 7 | ml_code(id) << 9);
            return 1;
        }
    return 0;
}
UI_SMALL static int ml_clear_all(void)                    /* HOME > SYSTEM > LEARN CLEAR; 1 = there were */
{
    uint32_t i, n = ml_count();
    for (i = 0; i < ML_N; i++)
        ml_put(i, 0);
    if (n)
        settings_later = 1;                      /* (saved when quiet) */
    return n != 0u;
}
UI_SMALL static void ml_toggle(void)                      /* GLO + F#3 */
{
    mlu.on = (uint8_t)!mlu.on;
    mlu.pick = 0;
    ml_arm = 0;
    ml_heard = 0;
    ui_message(mlu.on ? "LEARN: TURN A KNOB" : "LEARN DONE");
    ui.force = 1;
}
/* a knob turned parameter id of track t: picked while learning (ui_input.c) */
UI_SMALL static void ml_knob(const track_t *t, uint32_t id)
{
    char b[16];
    if (!mlu.on || id >= P_COUNT)
        return;
    if (!mlu.pick || mlu.id != id || mlu.trk != (uint8_t)trk_index(t)) {
        mlu.trk = (uint8_t)trk_index(t);
        mlu.id = (uint8_t)id;
        b[0] = 'T';
        b[1] = (char)('1' + mlu.trk);
        b[2] = ' ';
        str_cpy(b + 3, track_desc(t, id)->label, 9);
        ui_say(b, ": SEND A CC");
    }
    mlu.pick = 1;
    ml_heard = 0;
    ml_arm = 1;
}
/* each frame: a CC heard for the picked parameter is learned */
UI_SMALL static void ml_poll(void)
{
    uint32_t cc = ml_heard, r;
    char a[16], b[16];
    if (!cc)
        return;
    ml_heard = 0;
    if (!mlu.on || !mlu.pick)
        return;
    cc--;
    r = ml_learn(cc, mlu.trk, mlu.id);
    if (r != 1u) {
        ui_message(r ? "CC NOT LEARNABLE" : "LEARN FULL");
        return;
    }
    str_cpy(a, "CC", 4);
    fmt_int(a + 2, (int32_t)cc);
    str_cpy(a + str_len(a), " = T", 5);
    b[0] = (char)('1' + mlu.trk);
    b[1] = ' ';
    str_cpy(b + 2, track_desc(&trk[mlu.trk % NTRK], mlu.id)->label, 9);
    ui_say(a, b);
    mlu.pick = 0;
    ml_arm = 0;
    settings_later = 1;                          /* (saved when quiet) */
}
