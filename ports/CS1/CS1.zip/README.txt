CS-1 2026.10 for the BBL Mod Swapper

Original by twochannels: https://github.com/twochannels/CS-1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: CS1-source.zip on the ports page.
