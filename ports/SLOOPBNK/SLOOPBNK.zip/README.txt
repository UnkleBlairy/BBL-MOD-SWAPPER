SLOOP BANKS 2.5-b28-test for the BBL Mod Swapper

Original by majnikool: https://github.com/majnikool/sloop-fm1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: SLOOPBNK-source.zip on the ports page.
