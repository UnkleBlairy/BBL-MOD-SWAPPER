/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Physical panel: which matrix button / encoder carries which printed label.
 * The default table can be overridden by HARDWARE CALIBRATION (hold OCT- and
 * OCT+ while powering on), which asks for each label in turn. The learned
 * table lives in .noinit and, with FELUCCA_FLASH, in flash with the settings
 * (project.c). */
/* (B_SCL: the button printed SEL, the key / scale button between FX and ENV) */
enum { B_FX, B_SCL, B_ENV, B_LFO, B_EDIT, B_GLO, B_HOME, B_SAVE, B_ARP, B_SEQ, B_PLAY, B_REC,
       B_OCTDN, B_OCTUP, NB };
enum { EN_SELECT, EN_ALGO, EN_PRESET, EN_K1, EN_K2, EN_K3, EN_K4, NE };
static const char *const B_NAME[NB] = {"FX", "SEL", "ENV", "LFO", "EDIT", "GLO", "HOME", "SAVE",
                                        "ARP", "SEQ", "PLAY", "REC", "OCT-", "OCT+"};
static const char *const E_NAME[NE] = {"SELECT", "ALGORITHM", "PRESETS", "KNOB 1", "KNOB 2",
                                        "KNOB 3", "KNOB 4"};
#define PANEL_MAGIC 0x50414E35u          /* "PAN5": bump when PANEL_DEFAULT changes */

typedef struct {
    uint32_t magic;
    uint8_t btn[NB];             /* matrix button id (0..13) per label */
    uint8_t enc[NE];             /* matrix encoder (0..6) per role */
    int8_t dir[NE];              /* +1 / -1 so that clockwise is + */
} panel_t;
panel_t panel __attribute__((section(".noinit")));

static const panel_t PANEL_DEFAULT = {
    PANEL_MAGIC,
    {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 1},   /* PLAY = 12, REC = 13 */
    {0, 1, 6, 2, 3, 4, 5},                           /* SELECT = enc 0, ALGORITHM = enc 1, PRESETS = enc 6 */
    {1, 1, 1, 1, 1, 1, 1},
};

static void panel_init(void)                     /* also after a flash load: ids are used as array indexes and shifts */
{
    uint32_t i, ok = panel.magic == PANEL_MAGIC;
    for (i = 0; ok && i < NB; i++)
        ok = panel.btn[i] < 14u;
    for (i = 0; ok && i < NE; i++)
        ok = panel.enc[i] < 7u && (panel.dir[i] == 1 || panel.dir[i] == -1);
    if (!ok)
        panel = PANEL_DEFAULT;
}

static uint32_t panel_btn_of(uint32_t matrix_id)        /* label of a matrix button, NB if none */
{
    uint32_t b;
    for (b = 0; b < NB; b++)
        if (panel.btn[b] == matrix_id)
            return b;
    return NB;
}

static void panel_led(uint32_t label, int on) { fm1_led_key(panel.btn[label], on); }

/* steps of a role, + = clockwise */
static uint32_t ui_input_ms;                    /* the last button, key or knob turn (ui_input.c; autosave) */
/* the knobs (roles, bit per EN_*) not to be read again in this UI pass (ui_input: a layer took them, #102 of
 * Felucca): panel_enc returns 0 and leaves their detents for the next pass */
static uint32_t enc_hold;
static int32_t panel_enc(uint32_t role)
{
    int32_t s;
    if ((enc_hold >> role) & 1u)
        return 0;
    s = fm1_enc_take(panel.enc[role]) * panel.dir[role];
    if (s)
        ui_input_ms = fm1_ms;                      /* a knob turning is not idle either: autosave waits */
    return s;
}

/* user settings that survive a reset */
#define SETTINGS_MAGIC 0x53455433u              /* "SET3" */
struct { uint32_t magic, palette, lowcut, zoom; } settings __attribute__((section(".noinit")));

/* the lights (menu LIGHTS / KEYS / NOTES), for playing in the dark: kept in flash with the settings
 * (project.c persist_t.lights), read at every boot; not in .noinit, so nothing there moves. The same
 * word keeps SYNC and the REC screen's MODE / START (seq.c rec_tempo, rec_count) */
enum { LIGHTS_OFF, LIGHTS_LOW, LIGHTS_MID, LIGHTS_HIGH, LIGHTS_N };
enum { KEYS_OFF, KEYS_C, KEYS_WHITE, KEYS_ALL, KEYS_N };   /* (ALL: SLOOP 2.4; an older SLOOP reads it as OFF) */
static uint8_t lights_lvl, lights_keys;
static uint8_t lights_notes;                   /* 1: on a synth track the sounding notes light their keys */
static uint8_t lights_sync;                    /* GLO > SYSTEM > SYNC (G_SYNC), kept here: 0 INT, 1 USB, 2 TRS */
static uint8_t lights_mout;                    /* GLO > SYSTEM > MIDI (G_MIDI): 1 = the sequencer goes to MIDI OUT too */
static uint8_t lights_min;                     /* GLO > SYSTEM > IN (G_ROUTE): 1 = MIDI in takes the clock only, no notes */
static const uint16_t LIGHTS_NS[LIGHTS_N] = {0u, 500u, 1000u, 2000u};   /* the backlight pulse a frame (ns): a lit
                                                * LED ~95 us, the glow (landmarks) 4 us (fm1_input.h) */
static uint8_t usb_serial;                      /* menu USB SERIAL: 1 = the serial console presented (usb.c) */
static uint8_t vis_style;                       /* the visualiser's style, 0..11 (ui_vis.c) */
static uint8_t dx_layout;                       /* the fork: DX7 bank sectors claimed from USR4, counted DOWN from FL_DX_HI (dx_claim_banks) */
static uint8_t dx_layout_old;                   /* builds 17-18 recorded a bank COUNT here (bits 23..26); read once, never written */
static uint32_t lights_word(void)
{
    return (uint32_t)lights_lvl | (uint32_t)lights_keys << 4 | (uint32_t)(lights_notes != 0u) << 8 |
           (uint32_t)(rec_tempo != 0u) << 9 | (uint32_t)(rec_count != 0u) << 10 | (uint32_t)(usb_full != 0u) << 11 |
           (uint32_t)(lights_sync % 3u) << 12 | (uint32_t)(lights_mout != 0u) << 14 | (uint32_t)(lights_min != 0u) << 15 |
           (uint32_t)(usb_serial != 0u) << 16 | (uint32_t)(vis_style % 12u) << 17 | (uint32_t)(punch_keep & 3u) << 21 |
           (uint32_t)((key_vel_ix + 8u - KEY_VEL_DEF) & 7u) << 23 | (uint32_t)(dx_layout & 31u) << 27;
    /* bits 23..26 held a bank COUNT on builds 17-18; from build 27 bits 23..25 are the key velocity (seq.c KEY_VEL, 0 =
     * the default), read as such only once the bank record (27..31) exists, which every boot writes first (dx_claim_banks) */
}
static void lights_from_word(uint32_t w)
{
    lights_lvl = (uint8_t)((w & 15u) < LIGHTS_N ? (w & 15u) : LIGHTS_OFF);
    lights_keys = (uint8_t)(((w >> 4) & 15u) < KEYS_N ? ((w >> 4) & 15u) : KEYS_OFF);
    lights_notes = (uint8_t)((w >> 8) & 1u);
    rec_tempo = (uint8_t)((w >> 9) & 1u);       /* the REC screen: MODE, START (seq.c) */
    rec_count = (uint8_t)((w >> 10) & 1u);
    usb_full = (uint8_t)((w >> 11) & 1u);       /* menu USB AUDIO (fx.c) */
    lights_sync = (uint8_t)(((w >> 12) & 3u) % 3u);
    lights_mout = (uint8_t)((w >> 14) & 1u);    /* GLO > SYSTEM > MIDI (seq.c) */
    lights_min = (uint8_t)((w >> 15) & 1u);     /* GLO > SYSTEM > IN (seq.c) */
    usb_serial = (uint8_t)((w >> 16) & 1u);
    vis_style = (uint8_t)(((w >> 17) & 15u) % 12u);
    punch_keep = (uint8_t)((w >> 21) & 3u);      /* FX > KEEP (punch.c): a punch-in kept on */
    dx_layout = (uint8_t)((w >> 27) & 31u);      /* the fork: sectors claimed from the top (0 = the first builds' four) */
    if (dx_layout) {                             /* the record exists: bits 23..25 are the key velocity */
        dx_layout_old = 0;
        key_vel_ix = (uint8_t)((((w >> 23) & 7u) + KEY_VEL_DEF) & 7u);
    } else {                                     /* no record yet: builds 17-18's count (8 or 12), honoured once */
        dx_layout_old = (uint8_t)((w >> 23) & 15u);
        key_vel_ix = KEY_VEL_DEF;
    }   /* the visualiser (ui_vis.c); 0 in 2.3 = OSCILLOSCOPE */     /* menu USB SERIAL (usb.c usb_cdc_on, at the next start); 0 in 2.3 = OFF */
}

static void settings_save(void);              /* project.c: flash copy (FELUCCA_FLASH) */

/* The fork: a DX7 bank claimed from USR4 holds whatever an earlier firmware left in that flash — real voices,
 * even: the stock firmware's preset store sits at 0xEE000.., which is why GUITAR 1 / BRASS 1 / BOWOAN appeared as
 * banks 1-4 the day twelve banks shipped — and nothing but a first erase tells a leftover from a loaded one.
 * The banks END at FL_DX_HI and GROW DOWNWARD when a build adds some, so a bank's NUMBER moves with every
 * addition (the first builds' bank 1 at 0xF7000 is bank 9 of twelve): what is claimed must be recorded by
 * place, not by number. dx_layout (settings bits 27..31) is the number of sectors claimed, counted down from
 * FL_DX_HI; at boot every bank below those is erased once, then the count is kept. 0 — a build before this, or
 * a fresh device — counts as the first builds' four at the top. Recorded only when every erase succeeded, so a
 * failed one is retried at the next boot. (Builds 17-18 kept a bank COUNT in bits 23..26, which said "claimed"
 * about banks that had merely been renumbered; those bits are ignored and written back as 0.) */
#ifndef DX_CLAIM_ERASE
static uint32_t dx_bank_write(uint32_t b, uint8_t *data);   /* editor.c: data 0 = erase, then the XIP cache */
#define DX_CLAIM_ERASE(b) dx_bank_write((b), 0)
#endif
static uint32_t dx_claim_banks(void)                          /* -> banks erased */
{
    /* builds 17-18 counted banks instead: 8 on 17 (its eight = the top eight sectors) and 12 on 18 (all twelve, by
     * its own reckoning) — honoured as a count from the top, so a device that loaded its banks on 18 keeps them */
    uint32_t claimed = dx_layout ? dx_layout : dx_layout_old ? dx_layout_old : 4u, below, b, n = 0;
    if (claimed >= DX_USER_BANKS) {
        if (!dx_layout) {                                     /* builds 17-18's twelve: write the record by place now, */
            dx_layout = (uint8_t)DX_USER_BANKS;               /* so bits 23..26 are never read as a count again */
            dx_layout_old = 0;
            settings_save();
        }
        return 0;
    }
    below = DX_USER_BANKS - claimed;                          /* the banks under the claimed top: new to this device */
    for (b = 0; b < below; b++)
        n += DX_CLAIM_ERASE(b) ? 0u : 1u;
    if (n == below) {
        dx_layout = (uint8_t)DX_USER_BANKS;
        settings_save();
    }
    return n;
}
static uint8_t settings_later;                 /* changed while playing: saved once stopped (project.c) */

static void settings_init(void)
{
    if (settings.magic != SETTINGS_MAGIC || settings.palette >= NPALETTES) {
        settings.magic = SETTINGS_MAGIC;
        settings.palette = 4;                  /* MONO (default) */
        settings.lowcut = 0;
        settings.zoom = 0;                     /* large readout of the touched value: off */
    }
    palette_set(settings.palette);
    fx_lowcut = (uint8_t)(settings.lowcut != 0);
}
