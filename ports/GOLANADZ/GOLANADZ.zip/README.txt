Golana DZ Edition 0.1.0-beta for the BBL Mod Swapper

Original by dzwerg: https://github.com/dzwerg/Golana-DZ
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: GOLANADZ-source.zip on the ports page.
