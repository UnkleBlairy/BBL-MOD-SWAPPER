/* SPDX-License-Identifier: GPL-3.0-only */
/* Copyright (C) 2026 GR!MM
 * The design (the wasm in an AudioWorklet, the device clock driven by the audio the worklet asks for, the screen,
 * the lights and the saved bytes read back through exports) follows Felucca's browser build, web/emu/felucca_web.c
 * of hugelton/Felucca (Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments, GPL-3.0), which
 * follows X0X's, web/emu/x0x_web.c of charlesvestal/fm1-x0x (GPL-3.0). */
/* Arctic Scream in a browser: a fake FM-1, as tests/host.c is one for a computer. platform.c includes this file instead of
 * the hardware when ARCTIC_WEB is set; the app (firmware/src/arctic.c) runs unchanged on it.
 *
 *   web/build_web.sh   ->  web/dist/{index.html, panel.js, worklet.js, arctic.wasm}
 *
 * One call of platform_poll() is one millisecond of the device, as in host mode: the audio halves due by then
 * (app_audio, then the MASTER knob as platform.c applies it), into a ring the worklet drains. The app's main loop
 * never returns, so once the worklet has the frames it asked for, platform_poll() calls web_yield(): build_web.sh
 * runs Binaryen's Asyncify over the wasm, and web_yield (worklet.js) unwinds app_main back to the worklet and
 * rewinds into it for the next audio block. fm1_ticks() is the browser's clock (web_ticks): the app's CPU reading
 * is the browser's, not the FM-1's, and in Chromium's AudioWorklet (no performance.now) it is Date.now, in whole
 * milliseconds: a block reads 0 or 1 ms, so NOW comes out right on average but PEAK is one such step (17.2 %).
 * Not here: USB (MIDI out goes nowhere), updates, the rescue, crashes. */
#include <stdint.h>

#ifndef APP_NAME
#define APP_NAME "DINGHY"
#endif
#ifndef APP_VER
#define APP_VER "0.0"
#endif
#define FS 44100u
#define HALF_FRAMES 256u

#define EXPORT __attribute__((used, visibility("default")))
extern void web_yield(void) __attribute__((import_module("env"), import_name("web_yield")));
#define web_ticks() (fm1_ms * 24000u)

static volatile uint32_t fm1_ms;
#define FM1_TICKS_PER_US 24u
static uint32_t fm1_ticks(void) { return web_ticks(); }   /* 24 MHz, as the FM-1's TIMER4: here the browser's clock */

/* ---- the panel: keys (bit k = key k, 0 = F3), buttons (bit = BTN_ id), encoders (ENC_ id), LEDs (fm1_led_key ids:
 * 0..13 the buttons, 14 + k the keys) */
static struct { uint32_t notes, buttons; } fm1_in;
/* teensy-fm1: the panel and the screen are the Teensy's */
static uint32_t din_press, din_rel, din_nedge, din_px;
static int32_t din_enc[8];
static uint8_t din_led[64], din_glow[64];
static uint32_t fm1_input_edges(uint32_t *released) { uint32_t b = din_press; din_press = 0; if (released) *released = din_rel; din_rel = 0; return b; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = din_nedge; din_nedge = 0; return e; }
static int32_t fm1_enc_take(uint32_t e) { int32_t v = din_enc[e & 7u]; din_enc[e & 7u] = 0; return v; }
static void fm1_led_key(uint32_t id, int on) { din_led[id & 63u] = (uint8_t)!!on; }
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            sh_put(j * 240u + i, sh_be16(c));
    din_px += w * h;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            sh_put((y + j) * 240u + x + i, px[j * w + i]);      /* (gfx.c's pixels are high byte first already) */
    din_px += w * h;
}

static uint32_t web_pressed, web_released, web_notes_pressed, web_led_btn, web_led_key;
static uint32_t web_key_mask, web_key_tap;     /* the keys held; pressed and let go since the last poll */
static int32_t web_enc_steps[7];





static void fm1_led_glow(uint32_t id, int on) { (void)id; (void)on; }   /* (the glow: not shown here) */

/* ---- the screen: 240 x 240 RGB565, as host.c keeps it (gfx.c sends blits byte-swapped, as the ST7789 wants) */
#define fb shl_fb
static uint32_t web_draws;

static void lcd_light(int on) { (void)on; }     /* (SCREEN OFF: the page's screen stays lit) */


#define CV_MAX (240u * 64u)
#include "gfx.c"

/* ---- settings: up to 256 bytes, kept by the page (localStorage) and handed back before boot; as platform.c, a
 * load only succeeds with the length that was saved */
static uint8_t web_set[256];
static int32_t web_set_len = -1;
static uint32_t web_set_writes;
static int settings_load(void *p, uint32_t n)
{
    if (web_set_len < 0 || (uint32_t)web_set_len != n || n > sizeof web_set) return -1;
    memcpy(p, web_set, n);
    return 0;
}
static int settings_save(const void *p, uint32_t n)
{
    if (n > sizeof web_set) return -1;
    memcpy(web_set, p, n);
    web_set_len = (int32_t)n;
    web_set_writes++;
    return 0;
}

/* ---- MIDI: in from Web MIDI (web_midi), out nowhere; no MIDI clock here (platform.c's ring stays empty) */
static uint32_t rt_now(void) { return 0; }
static uint8_t mq[64][3];
static uint32_t mq_w, mq_r;
static int midi_get(uint8_t *st, uint8_t *d1, uint8_t *d2)
{
    if (mq_r == mq_w) return 0;
    *st = mq[mq_r % 64u][0]; *d1 = mq[mq_r % 64u][1]; *d2 = mq[mq_r % 64u][2];
    mq_r++;
    return 1;
}
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2) { (void)st; (void)d1; (void)d2; }
static uint32_t midi_room(void) { return 64u; }
static int32_t batt_raw(void) { return -1; }   /* (no battery in a browser: no icon) */
static int usb_powered(void) { return 0; }
static uint32_t usb_drops(void) { return 0u; }   /* (no USB audio here) */
static uint32_t stk_main(void) { return 0u; }   /* (1.5.2: the stacks are measured on the FM-1 only) */
static uint32_t stk_irq(void) { return 0u; }
#define STK_MAIN_SZ 0u
#define STK_IRQ_SZ 0u
static int usb_recording(void) { return 0; }
static int usb_feeding(void) { return 0; }
static void usb_feed(const int32_t *x, uint32_t n) { (void)x; (void)n; }

/* Arctic Scream: the sample area (platform.c's, 288 KiB), here RAM, erased as a new FM-1's: at boot the firmware writes its four
 * factory samples in (samples.c), as on the device. (2.0, Arctic Scream's web extension) The browser's slots are
 * longer than the FM-1's: 1 MiB each, ~95 s (the FM-1: 72 KiB, 6.6 s); INFO says so, and the pages cut to it */
#define SMP_SLOT_SIZE 0x12000u
#define SAMPLE_AREA_LEN (4u * SMP_SLOT_SIZE)
#ifdef TEENSY_NOR_ADDR                  /* teensy-fm1: real flash, in this ROM slot */
extern int32_t teensy_nor_erase(uint32_t off);
extern int32_t teensy_nor_prog(uint32_t off, const uint8_t *src, uint32_t n);
#define fake_flash ((uint8_t *)TEENSY_NOR_ADDR)
#else
static uint8_t fake_flash[SAMPLE_AREA_LEN];
#endif
static const uint8_t *sample_flash(void) { return fake_flash; }
static int sample_flash_erase(uint32_t off)
{
    uint32_t i;
    if ((off & 0xFFFu) || off >= SAMPLE_AREA_LEN) return -8;
#ifdef TEENSY_NOR_ADDR
    (void)i; if (teensy_nor_erase(off)) return -8;
#else
    for (i = 0; i < 4096u; i++) fake_flash[off + i] = 0xFF;
#endif
    return 0;
}
static int sample_flash_write(uint32_t off, const void *p, uint32_t n)   /* NOR: a write only clears bits */
{
    const uint8_t *s = p;
    uint32_t i;
    if (off >= SAMPLE_AREA_LEN || n > SAMPLE_AREA_LEN - off) return -8;
#ifdef TEENSY_NOR_ADDR
    (void)i; if (teensy_nor_prog(off, s, n)) return -8;
#else
    for (i = 0; i < n; i++) fake_flash[off + i] &= s[i];
#endif
    return 0;
}
/* Arctic Scream: the save sectors (store.c), here RAM, erased at the start: nothing saved */
#define SAVE_NSECT 6u
static uint8_t fake_save[SAVE_NSECT][4096];
static const uint8_t *save_flash(uint32_t i)
{
    static int init;
    if (!init) { memset(fake_save, 0xFF, sizeof fake_save); init = 1; }
    return i < SAVE_NSECT ? fake_save[i] : 0;
}
static int save_flash_erase(uint32_t i)
{
    if (i >= SAVE_NSECT) return -8;
    (void)save_flash(0);
    memset(fake_save[i], 0xFF, 4096u);
    return 0;
}
static int save_flash_write(uint32_t i, uint32_t off, const void *p, uint32_t n)   /* NOR: a write only clears bits */
{
    const uint8_t *s = p;
    uint32_t k;
    if (i >= SAVE_NSECT || off >= 4096u || n > 4096u - off) return -8;
    (void)save_flash(0);
    for (k = 0; k < n; k++) fake_save[i][off + k] &= s[k];
    return 0;
}
/* SysEx: the editor page's frames in (as USB would bring them: 7D .. without F0 / F7), the replies out (F0 .. F7) */
static uint8_t web_sx_in[640], web_sx_out[4096];
static uint32_t web_sx_in_n, web_sx_in_ready, web_sx_out_n;
static int sysex_get(const uint8_t **p, uint32_t *n)
{
    if (!web_sx_in_ready) return 0;
    if (!web_sx_in_n || web_sx_in[0] != 0x7Du) { web_sx_in_ready = 0; return 0; }
    *p = web_sx_in, *n = web_sx_in_n;
    return 1;
}
static void sysex_done(void) { web_sx_in_ready = 0; }
static int ann_wire_send(const uint8_t *p, uint32_t n) { (void)p; (void)n; return -1; }   /* (1.5: no reader here yet) */
static int po_wire_send(const uint8_t *p, uint32_t n) { (void)p; (void)n; return -1; }    /* (1.5.2: PANEL OUT, none here) */
static int mr_wire_send(const uint8_t *p, uint32_t n) { (void)p; (void)n; return -1; }    /* (2.1.5: SCREEN MIRROR, none here) */
static int sysex_send(const uint8_t *p, uint32_t n)
{
    if (web_sx_out_n + n > sizeof web_sx_out) return -1;
    memcpy(web_sx_out + web_sx_out_n, p, n);
    web_sx_out_n += n;
    return 0;
}

static void app_audio(int32_t *out, uint32_t n);
static void app_main(void);

static volatile int8_t fm1_jack = -1;
static int32_t arc_master = 4092;
static int32_t fm1_master(void) { return arc_master; }
