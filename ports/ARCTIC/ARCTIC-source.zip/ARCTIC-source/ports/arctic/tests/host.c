/* SPDX-License-Identifier: GPL-3.0-only */
/* GR!MM changes (file names): Copyright (C) 2026 GR!MM */
/* A fake FM-1 on a computer: the app (firmware/src/arctic.c) runs unchanged on it. platform.c includes
 * this file instead of the hardware when DINGHY_HOST is set. A script presses keys over time; out come
 * the screen (PPM, at the times SHOT asks) and the sound (WAV, as the FM-1 sends it over USB). fm1_ticks() is this
 * computer's clock: the longest app_audio() goes out at the end, as a share of its 5.8 ms (the FM-1's is its own).
 *
 *   mkdir -p build/host
 *   cc -O2 -Wall -DDINGHY_HOST -Ifirmware/src -Ifirmware/gen -o build/host/arctic firmware/src/arctic.c
 *   build/host/arctic build/host/arctic        (-> build/host/arctic.wav, build/host/arctic-<ms>.ppm)
 *   build/host/arctic OUT script.txt [FPS]    (your own script; with FPS: OUT-NNNNN.ppm, a frame every 1/FPS s:
 *                                             a film of your firmware, e.g. ffmpeg -r 30 -i OUT-%05d.ppm ...)
 *
 * Change SCRIPT below to try your own app. */
#include <stdint.h>

#ifndef APP_NAME
#define APP_NAME "DINGHY"
#endif
#ifndef APP_VER
#define APP_VER "0.0"
#endif
#define FS 44100u
#define HALF_FRAMES 256u

static volatile uint32_t fm1_ms;
static struct { uint32_t notes, buttons; } fm1_in;
/* teensy-fm1: the panel and the screen are the Teensy's */
static uint32_t din_press, din_rel, din_nedge, din_px;
static int32_t din_enc[8];
static uint8_t din_led[64], din_glow[64];
static uint32_t fm1_input_edges(uint32_t *released) { uint32_t b = din_press; din_press = 0; if (released) *released = din_rel; din_rel = 0; return b; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = din_nedge; din_nedge = 0; return e; }
static int32_t fm1_enc_take(uint32_t e) { int32_t v = din_enc[e & 7u]; din_enc[e & 7u] = 0; return v; }
static void fm1_led_key(uint32_t id, int on) { din_led[id & 63u] = (uint8_t)!!on; }
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            sh_put(j * 240u + i, sh_be16(c));
    din_px += w * h;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            sh_put((y + j) * 240u + x + i, px[j * w + i]);      /* (gfx.c's pixels are high byte first already) */
    din_px += w * h;
}

static uint32_t host_edges, host_rel, host_tap;   /* buttons pressed, let go since the last call; tapped (up next ms) */

   /* (the script sets fm1_in.notes) */
static int32_t host_enc[7];

#define FM1_TICKS_PER_US 24u
static uint32_t fm1_ticks(void)                 /* 24 MHz, as the FM-1's TIMER4: here the computer's clock */
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint32_t)ts.tv_sec * 24000000u + (uint32_t)ts.tv_nsec / 1000u * 24u;
}
static uint32_t host_lit;                       /* (1.4) the 27 keys' lights, as last set (T probe: "lit") */

static void fm1_led_glow(uint32_t id, int on) { (void)id; (void)on; }

/* the screen: 240 x 240 RGB565, as the ST7789 gets it (gfx.c sends the bytes swapped) */
#define fb shl_fb

static uint32_t host_dark;                      /* (SCREEN OFF: the backlight off) */
static void lcd_light(int on) { host_dark = !on; }


#define CV_MAX (240u * 64u)
#include "gfx.c"

static uint8_t host_store[256 + 4];             /* (valid, its size; then the bytes: as the FM-1's sector, a load of
                                                 * another size fails) */
static int settings_load(void *p, uint32_t n)
{
    if (host_store[0] != 1 || n > 256u || n != (host_store[1] | (uint32_t)host_store[2] << 8)) return -1;
    memcpy(p, host_store + 4, n);
    return 0;
}
static int settings_save(const void *p, uint32_t n)
{
    host_store[0] = 1, host_store[1] = (uint8_t)n, host_store[2] = (uint8_t)(n >> 8);
    memcpy(host_store + 4, p, n);
    printf("%6u ms  settings saved (%u B)\n", fm1_ms, n);
    return 0;
}

static uint8_t mq[64][3];
static uint32_t mq_w, mq_r;
static int midi_get(uint8_t *st, uint8_t *d1, uint8_t *d2)
{
    if (mq_r == mq_w) return 0;
    *st = mq[mq_r % 64u][0]; *d1 = mq[mq_r % 64u][1]; *d2 = mq[mq_r % 64u][2];
    mq_r++;
    return 1;
}
#ifdef ARCTIC_STRESS
static void stress_midi_out(uint32_t st, uint32_t d1);   /* (tests/stress_check.c: what is on out there) */
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2) { (void)d2; stress_midi_out(st, d1); }
#else
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2) { printf("%6u ms  MIDI out %02X %u %u\n", fm1_ms, st, d1, d2); }
#endif
static uint32_t midi_room(void) { return 64u; }
#ifdef ARCTIC_STRESS                             /* (the stress test: a battery going round its levels, 4 s a step) */
static int32_t batt_raw(void) { return 500 + (int32_t)((fm1_ms / 4000u * 13u) % 110u); }
static int usb_powered(void) { return (fm1_ms / 60000u) % 3u == 2u; }
#else                                           /* (no battery here: no icon) */
static int32_t batt_raw(void) { return -1; }
static int usb_powered(void) { return 0; }
#endif

/* Arctic Scream: the sample area (platform.c's, 288 KiB), here RAM, erased as a new FM-1's: at boot the firmware writes its four
 * factory samples in (samples.c), as on the device; no USB, so no SysEx (no uploads) */
#define SAMPLE_AREA_LEN 0x48000u
static uint8_t fake_flash[SAMPLE_AREA_LEN];
static const uint8_t *sample_flash(void) { return fake_flash; }
static int sample_flash_erase(uint32_t off)
{
    uint32_t i;
    if ((off & 0xFFFu) || off >= SAMPLE_AREA_LEN) return -8;
    for (i = 0; i < 4096u; i++) fake_flash[off + i] = 0xFF;
    return 0;
}
static int sample_flash_write(uint32_t off, const void *p, uint32_t n)   /* NOR: a write only clears bits */
{
    const uint8_t *s = p;
    uint32_t i;
    if (off >= SAMPLE_AREA_LEN || n > SAMPLE_AREA_LEN - off) return -8;
    for (i = 0; i < n; i++) fake_flash[off + i] &= s[i];
    return 0;
}
/* Arctic Scream: the save sectors (store.c), here RAM, erased at the start: nothing saved */
#define SAVE_NSECT 6u
static uint8_t fake_save[SAVE_NSECT][4096];
static const uint8_t *save_flash(uint32_t i)
{
    static int init;
    if (!init) { memset(fake_save, 0xFF, sizeof fake_save); init = 1; }
    return i < SAVE_NSECT ? fake_save[i] : 0;
}
static int save_flash_erase(uint32_t i)
{
    if (i >= SAVE_NSECT) return -8;
    (void)save_flash(0);
    memset(fake_save[i], 0xFF, 4096u);
    printf("%6u ms  flash sector %u erased (a save)\n", fm1_ms, i);   /* (tests/rc11_test.py: when) */
    return 0;
}
static uint32_t usb_drops(void) { return 0u; }   /* (no USB audio here) */
static uint32_t stk_main(void) { return 0u; }   /* (1.5.2: the stacks are measured on the FM-1 only) */
static uint32_t stk_irq(void) { return 0u; }
#define STK_MAIN_SZ 0u
#define STK_IRQ_SZ 0u
static uint32_t host_rec_from = 1, host_rec_to;   /* (ARCTIC_USB_REC=FROM,TO: a computer reads the USB audio from FROM to TO ms) */
static int usb_recording(void) { return fm1_ms >= host_rec_from && fm1_ms < host_rec_to; }
static uint32_t host_vsteps[2];                 /* (2.2: voices.c, ARCTIC_CPU2: the voices' control steps rendered on
                                                 * this core, on the second: said at the end) */
static uint32_t c1_sim;                         /* (2.2: ARCTIC_CPU2=1: arctic.c's SPACE as on the second core, a block
                                                 * behind) */
static uint32_t cpu_hot_force;                  /* (2.2: ARCTIC_CPU_HOT=1: arctic.c's CPU guard as if the blocks ran hot) */
static uint32_t host_feed;                      /* (2.2: ARCTIC_USB_FEED=1: the computer takes the sound while it records) */
static int32_t host_usb_pk;                     /* (the USB sound's peak since the last probe: "usbpk MS PEAK") */
static int usb_feeding(void) { return host_feed && usb_recording(); }   /* (no USB audio ring here: its peak only) */
static void usb_feed(const int32_t *x, uint32_t n)
{
    uint32_t i;
    for (i = 0; i < 2u * n; i++)
        if ((x[i] < 0 ? -x[i] : x[i]) > host_usb_pk) host_usb_pk = x[i] < 0 ? -x[i] : x[i];
}
static void compat_exit(void);                  /* (tests/compat.c) */
static int save_flash_write(uint32_t i, uint32_t off, const void *p, uint32_t n)   /* NOR: a write only clears bits */
{
    const uint8_t *s = p;
    uint32_t k;
    if (i >= SAVE_NSECT || off >= 4096u || n > 4096u - off) return -8;
    (void)save_flash(0);
    for (k = 0; k < n; k++) fake_save[i][off + k] &= s[k];
    return 0;
}
#ifdef ARCTIC_STRESS                             /* (the stress test: a frame put in host_sx as from USB; the replies) */
static uint8_t host_sx[640];
static uint32_t host_sx_n, host_sx_ready;
static void stress_sysex_out(const uint8_t *p, uint32_t n);
static int sysex_get(const uint8_t **p, uint32_t *n)
{
    if (!host_sx_ready || !host_sx_n || host_sx[0] != 0x7Du) return 0;
    *p = host_sx, *n = host_sx_n;
    return 1;
}
static void sysex_done(void) { host_sx_ready = 0; }
static int sysex_send(const uint8_t *p, uint32_t n) { stress_sysex_out(p, n); return 0; }
#else                                           /* (a script's "sysex": a frame as from the editor, e.g. a sound) */
static const uint8_t *host_sx;
static uint32_t host_sx_n;
static int sysex_get(const uint8_t **p, uint32_t *n)
{
    if (!host_sx_n) return 0;
    *p = host_sx, *n = host_sx_n;
    return 1;
}
static void sysex_done(void) { host_sx_n = 0; }
static int sysex_send(const uint8_t *p, uint32_t n) { (void)p; (void)n; return 0; }
#endif
/* (Arctic Scream 1.5) the screen reader's frames (announce.c): a SAY printed ("said: ..."), and with ARCTIC_SAID_LOG
 * appended to that file as "MSG<tab>text" ("WARN" with ANN_KEEP), for fm1-reader's tools/audit.mjs */
static int ann_wire_send(const uint8_t *p, uint32_t n)
{
    static FILE *log;
    static int opened;
    if (n < 7u) return 0;
    if (p[4] == 16u) {
        printf("%6u ms  said%s: %.*s\n", fm1_ms, p[5] & 2u ? " (keep)" : "", (int)(n - 7u), (const char *)p + 6);
        if (!opened) opened = 1, log = getenv("ARCTIC_SAID_LOG") ? fopen(getenv("ARCTIC_SAID_LOG"), "a") : 0;
        if (log) fprintf(log, "%s\t%.*s\n", p[5] & 2u ? "WARN" : "MSG", (int)(n - 7u), (const char *)p + 6), fflush(log);
    } else if (p[4] == 1u)
        printf("%6u ms  reader HELLO: %.*s\n", fm1_ms, (int)(n - 7u), (const char *)p + 6);
    return 0;
}
/* (1.5.2) PANEL OUT's frames (panel_out.c): printed as "panel: cmd args.." (tests/panel_out_test.py) */
static int po_wire_send(const uint8_t *p, uint32_t n)
{
    uint32_t i;
    if (n < 6u) return 0;
    printf("%6u ms  panel:", fm1_ms);
    for (i = 4; i + 1u < n; i++) printf(" %u", p[i]);
    printf("\n");
    return 0;
}

/* (2.1.5) SCREEN MIRROR's frames (mirror.c), read as an app would: the rows painted into mr_fb, the names printed
 * ("mirror name: .."); ARCTIC_MR_RATE: at most so many messages a millisecond (a slow USB: rows dropped, everything
 * asked for again); at the end "mirror: .." with how many pixels differ from the screen (tests/mirror_test.py) */
static uint16_t mr_fb[240 * 240];
static void mr_tick(uint32_t now);                 /* (mirror.c's: at the end, what waits sent first) */
static int mr_stale(uint32_t y);                   /* (mirror.c's: a row not yet as the screen has it) */
static uint32_t mr_msgs, mr_bytes, mr_bad, mr_rate_t, mr_rate_n, mr_last_ms, mr_flush;
static int mr_wire_send(const uint8_t *p, uint32_t n)
{
    static int rate = -1;
    uint32_t y, x, i;
    if (rate < 0) rate = getenv("ARCTIC_MR_RATE") ? atoi(getenv("ARCTIC_MR_RATE")) : 0;
    if (rate && !mr_flush) {
        if (mr_rate_t != fm1_ms) mr_rate_t = fm1_ms, mr_rate_n = 0;
        if (mr_rate_n >= (uint32_t)rate) return -1;
        mr_rate_n++;
    }
    if (n < 6u || p[0] != 0xF0u || p[1] != 0x7Du || p[2] != 'F' || p[3] != 'S' || p[n - 1u] != 0xF7u || n > 70u) {
        mr_bad++;
        return 0;
    }
    for (i = 1; i + 1u < n; i++)
        if (p[i] & 0x80u) mr_bad++;
    if (p[4] == 2u) {
        printf("%6u ms  mirror name: %.*s\n", fm1_ms, (int)(n - 6u), (const char *)p + 5);
        return 0;
    }
    if (p[4] != 1u || n < 14u || (n - 10u) % 4u) {
        mr_bad++;
        return 0;
    }
    y = p[5] | (uint32_t)p[6] << 7, x = p[7] | (uint32_t)p[8] << 7;
    for (i = 9; i + 4u <= n - 1u; i += 4u) {
        uint32_t k = p[i], c = p[i + 1u] | (uint32_t)p[i + 2u] << 7 | (uint32_t)p[i + 3u] << 14;
        if (!k || y >= 240u || x + k > 240u || c > 0xFFFFu) {
            mr_bad++;
            return 0;
        }
        while (k--) mr_fb[y * 240u + x++] = (uint16_t)c;
    }
    mr_msgs++, mr_bytes += n, mr_last_ms = fm1_ms;
    return 0;
}

static void app_audio(int32_t *out, uint32_t n);
static int32_t host_master = 4092;              /* the MASTER knob as the app reads it (fm1_master, Q12): all
                                                 * the way up, as the USB audio always was here; ARCTIC_MASTER: the knob
                                                 * 0 .. 1023 (squared, as platform.c) */
static int32_t fm1_master(void) { return host_master; }
static uint8_t host_tvel[27], host_tpress[27];  /* (2.1.4) the script's "touch K VEL PRESS": what key K would read with
                                                 * TOUCH on (firmware/src/touch.c); VEL 0: no reading */
static volatile int8_t fm1_jack = -1;           /* the headphone jack (SOUND AUTO): not read (the whole range, as before);
                                                 * the script's "jack 1" headphones in, "jack 0" nothing plugged */
static void app_main(void);
