/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 PolarPatch */
/* Arctic Scream 2.0's JIEHKKI page (LFO, tapped a third time; North Sami: a glacier, sanit.oahpa.no): a piece the
 * FM-1 plays on its own for as long as LENGTH says, moving as slowly as a glacier, then dying out.
 *   LENGTH     5, 10, 15, 25, 30, 60 MIN, (2.1) 2, 4, 8 HOURS (all night, to sleep by), ENDLESS: the piece's time
 *   DRIFT      0 .. 100 %: how much moves while it plays: the tracks' notes (its own; twice as often in its
 *              opening), their presence in the mix (a track rests a while, comes back), their filters (opening over
 *              the first minutes, closing as it dies out). 0: nothing moves, the piece only rises and dies out: a
 *              sleep timer
 *   RUOHCAT    (to creak, crack: sanit.oahpa.no) 0 .. 100 %: the ice around the drone, a crack, a drip, a deep boom now
 *              and then, each its own, from far apart (1 %, a minute or so) to a storm of them (100 %); heard whenever
 *              it is up, the piece playing or not. 0: none
 *   START      OFF, ON, (2.2) ALWAYS: the piece (ALWAYS: ON, and again at every power-on, the project saying so:
 *              Arctic Scream plays as it wakes, a piece of its own each time, after Arcturus S6's drone at power-on). Turned ON with nothing sounding, it plays its own notes, one a track (from the
 *              SCALE: ROOT low on T1, its fifth, a third and a fifth or second over it; SCALE OFF: as NATURAL
 *              MINOR), the tracks coming in one after another as it rises out of silence (10 .. 30 s); with notes
 *              sounding, it takes them as they are (and moves the mix alone). At its end
 *              (LENGTH) all of it has faded out: the notes are let go, the sequencer stops, GENERATE stops, the
 *              screen goes dark, and the FM-1 stays silent until a hand (a key, a button, a knob, a MIDI note) wakes
 *              it. Turned OFF: its notes let go, the mix as set again. ENDLESS: no end; its own notes still move
 * The main loop decides (jk_tick, every JK_TICK ms): the notes go through nq (as a key's, the ids JK_ID ..), the
 * gains and the filters' moves through jk_og, jk_tg, jk_cut; the audio ISR ramps them (jk_out, mix_tracks, trk_filter)
 * and plays RUOHCAT's sounds (ru_render: noise through band-passes, a falling sine, a slow low one; into the mix and
 * the REV bus). LENGTH, DRIFT and RUOHCAT are the project's (store.c, version 9); START is not saved (2.2: ALWAYS is,
 * EXT's byte 23's bit 4).
 *
 * The RUOHCAT page (LFO, tapped a fourth time): the ice's sounds with your own samples among them (a joik heard far off
 * over the drone, the wind, water):
 *   AMOUNT     RUOHCAT's knob, as on JIEHKKI: how often
 *   SAMPLE     OFF, SLOT 1 .. 4, ALL: which sample slots it plays from (ALL: any that holds one)
 *   SHARE      0 .. 100 %: of its sounds, how many are the samples (100 %: the samples alone)
 *   VARY       0 .. 100 %: 0, a sample whole, from its start, as recorded; up, from further in, shorter, now and then a
 *              fourth, a fifth or an octave down or up
 * A sample comes in over 20 ms and goes over its last 100 ms, panned, with a share into SPACE; two at most at once.
 * SAMPLE, SHARE and VARY are the project's too (store.c's EXT).
 * (2.1) The ice answers (after ZEN-1's koi, aceyprime's, who play your note back when they find it; written anew):
 * with RUOHCAT up, a note you play (a key, MIDI; not the sequencer's, not the piece's) comes back a few seconds later
 * from far off in the ice, an octave up, a bell of ice: often or seldom as RUOHCAT is up, one at a time.
 * (2.2) Its dusk (after PaperLagoon's sleep, hacha's, whose last minute is sparser, quieter, slower; written anew): as
 * the piece dies out (jk_fo: its last fifth, 1 .. 8 min) it does not only fade: its notes move half as often, the mix
 * stops changing, and its own tracks go one by one, the highest first (T4 a quarter into it, T3 at half, T2 at three
 * quarters), each let go into SPACE's tail, till T1's low note is alone and fades into silence.
 * (2.2) The ice holds its breath (after Arcturus S6's gated reverb freeze, Zeptosecond DSP's; written anew): with
 * RUOHCAT up, now and then SPACE's tail is held still for 3 .. 10 s (SIZE's INF, hall.c's rv_hold: the knob as it is),
 * the tracks playing on over it, then let go to die away as SIZE says: every ~90 s at 1 %, every ~20 s at 100 %.
 * (2.2) The keys show it (after Arcturus S6's keys as a display, written anew): while nothing is held, the keys light
 * JIEHKKI's own notes (every track's), and RUOHCAT's sounds flash across them: a crack, a few keys side by side; a
 * drip, a high key; a boom, the lowest three; the ice's answer, the key of its note. kl_keys: arctic.c's lights. */

#define JK_TICK 50u                             /* ms between the main loop's looks */
#define JK_ENDLESS 9                            /* (JK_NLEN: arctic.c; 2.0's 6: store.c reads it as this) */
static const uint16_t JK_MIN[JK_NLEN] = {5, 10, 15, 25, 30, 60, 120, 240, 480, 0};   /* LENGTH's minutes (0: ENDLESS) */
static const char *const JK_LEN_NAME[JK_NLEN] = {"5 MIN", "10 MIN", "15 MIN", "25 MIN", "30 MIN", "60 MIN", "2 HOURS",
                                                 "4 HOURS", "8 HOURS", "ENDLESS"};
#define JK_ID 202u                              /* its notes' origin (lat_id): JK_ID + 2 t + (0, 1) */
static const uint8_t JK_LO[NT] = {33, 43, 45, 52}, JK_HI[NT] = {52, 62, 64, 76};   /* a track's notes' range */

static volatile int32_t jk_len = 2, jk_drift = 40, jk_ruo, jk_go;   /* the knobs: 15 MIN, 40 %, 0, OFF */
static volatile int32_t jk_og = 32767, jk_tg[NT] = {32767, 32767, 32767, 32767}, jk_cut[NT];   /* main loop -> audio:
                                                 * the output's gain, a track's (Q15), its filter's move (CUTOFF << 8) */
static volatile uint32_t jk_snap;              /* main loop -> audio: + 1, the output's gain to jk_og at once (a piece
                                                 * of its own begins: no blip of its first notes before the rise) */
static int32_t jk_oga = 32767, jk_tga[NT] = {32767, 32767, 32767, 32767};   /* audio: as ramped */
static struct {
    uint32_t run, own, t0, len, tick, ended, end_t, next_move, next_g[NT], enter[NT];
    uint8_t note[NT], id[NT], want[NT];         /* its own notes now (0: none), their ids; a note to come in (enter) */
    int32_t cut_t[NT], cut[NT];                 /* a filter's move: where it goes, where it is (<< 8) */
    uint32_t rng;
    int32_t go_was;                             /* (2.2) START as last seen; done: the piece over, START left as it was
                                                 * (ALWAYS) till it is turned or the FM-1 wakes again */
    uint32_t done;
} jk = {.rng = 0x2545F491u};
static volatile uint32_t jk_sleep;              /* main loop: the piece is over, the screen to go dark (arctic.c) */

static uint32_t jk_rnd(uint32_t n)
{
    jk.rng ^= jk.rng << 13, jk.rng ^= jk.rng >> 17, jk.rng ^= jk.rng << 5;
    return (uint32_t)(((uint64_t)jk.rng * n) >> 32);
}
static int jk_in(int32_t n)                     /* in the scale (SCALE OFF: NATURAL MINOR on ROOT) */
{
    return sc_scale > 0 ? sc_in(n) : 0x5ADu >> ((uint32_t)(n + 132 - clamp(sc_root, 0, 11)) % 12u) & 1u;
}
static int32_t jk_step(int32_t n, int32_t d)    /* d notes of the scale on from n */
{
    int32_t s = d > 0 ? 1 : -1;
    for (; d; d -= s)
        do n += s; while (n > 0 && n < 127 && !jk_in(n));
    return n;
}
static int32_t jk_fit(uint32_t t, int32_t n)    /* n into track t's range, by octaves, in the scale */
{
    while (n > JK_HI[t]) n -= 12;
    while (n < JK_LO[t]) n += 12;
    while (!jk_in(n) && n > 0) n--;
    return n;
}
static uint32_t jk_len_ms(void)
{
    return (uint32_t)JK_MIN[clamp(jk_len, 0, JK_NLEN - 1)] * 60000u;
}
static uint32_t jk_left(uint32_t now)           /* ms left of the piece (ENDLESS, not playing: 0) */
{
    uint32_t L = jk.len, e = now - jk.t0;
    return jk.run && L && e < L ? L - e : 0;
}

/* (2.2, after HADAL-1's MIDI out, Polystellarflow's: written anew) the piece's own notes out over USB-MIDI too, each
 * track's on its channel (as its keys', MIDI CHANNEL), while SEQ MIDI OUT is on: another synth, a DAW or a MIDI-to-CV
 * box can follow the piece. Kept in echo_on as the echoes are (a channel changed, SEQ MIDI OUT off: let go) */
static void jk_mo(uint32_t on, uint32_t t, uint32_t n)
{
    uint32_t c = (set.mch < MCH_ALL ? set.mch : 0u) + (t & 3u);
    if (c > 15u || n > 127u || !midi_room()) return;
    if (on && mo_seq) midi_send(0x90u | c, n, 100u), echo_on[n] |= (uint16_t)(1u << c);
    else if (!on && (echo_on[n] >> c & 1u)) midi_send(0x80u | c, n, 0u), echo_on[n] &= (uint16_t)~(1u << c);
}
static void jk_play(uint32_t t, int32_t n)      /* track t's own note to n (the new one on, then the old one let go) */
{
    uint32_t id = JK_ID + 2u * t + (jk.id[t] == JK_ID + 2u * t);
    if (n == jk.note[t]) return;
    if (n > 0) nq_note(NQ_ON, t, (uint32_t)n, id), jk_mo(1u, t, (uint32_t)n);
    if (jk.note[t]) nq_note(NQ_OFF, t, jk.note[t], jk.id[t]), jk_mo(0u, t, jk.note[t]);
    jk.note[t] = (uint8_t)(n > 0 ? n : 0), jk.id[t] = (uint8_t)id;
}
/* (2.2, after HADAL-1's motif, Polystellarflow's: written anew) MOTIF: with its own notes, the piece is born with a few
 * notes of its own (3 .. 5, the SCALE's, around two octaves over T1), heard now and then over the drone on T4's sound:
 * the first after its opening, then every ~2 .. 6 minutes (DRIFT up: more often), each time a little changed (a note
 * a step of the scale up or down, now and then one more or one less), slow, each note ~1.2 .. 2.4 s. Never in its
 * dusk. Its notes out over MIDI as T4's (jk_mo) */
static uint32_t jk_open(uint32_t L);           /* (below) */
static uint32_t jk_dusk(uint32_t now);
#define MF_ID 210u                              /* its notes' origin (lat_id): MF_ID, MF_ID + 1 in turn */
#define MF_MAX 5u
static struct { uint8_t n, i, note[MF_MAX], on, id; uint32_t next, t; } mf;
static void mf_born(uint32_t now)               /* a piece of its own begins: its motif */
{
    uint32_t k;
    int32_t b = jk_step(jk.note[0] + 24, 0);
    mf.n = (uint8_t)(3u + jk_rnd(3u)), mf.i = 0, mf.on = 0;
    for (k = 0; k < mf.n; k++) mf.note[k] = (uint8_t)clamp(jk_step(b, (int32_t)jk_rnd(7u) - 2), JK_LO[3], JK_HI[3]);
    mf.next = now + jk_open(jk.len) + 20000u + jk_rnd(40000u);
}
static void mf_off(void)
{
    if (mf.on) nq_note(NQ_OFF, 3, mf.on, mf.id), jk_mo(0u, 3, mf.on), mf.on = 0;
}
static void mf_tick(uint32_t now)               /* (jk_tick) its notes, one after another, then a while till the next */
{
    if (!jk.own || jk_dusk(now)) { mf_off(), mf.i = 0; return; }
    if (!mf.i) {
        if ((int32_t)(now - mf.next) < 0) return;
        mf.i = 1, mf.t = now;
    }
    if ((int32_t)(now - mf.t) < 0) return;
    mf_off();
    if (mf.i > mf.n) {                          /* (played: changed a little for the next time, then a while) */
        uint32_t k = jk_rnd(mf.n), d = (uint32_t)clamp(jk_drift, 0, 100);
        mf.note[k] = (uint8_t)clamp(jk_step(mf.note[k], jk_rnd(2u) ? 1 : -1), JK_LO[3], JK_HI[3]);
        if (!jk_rnd(4u) && mf.n < MF_MAX) mf.note[mf.n] = mf.note[mf.n - 1u], mf.n++;
        else if (!jk_rnd(5u) && mf.n > 3u) mf.n--;
        mf.i = 0, mf.next = now + 360000u - d * 2400u + jk_rnd(60000u);
        return;
    }
    mf.id = (uint8_t)(mf.id == MF_ID ? MF_ID + 1u : MF_ID), mf.on = mf.note[mf.i - 1u];
    nq_note(NQ_ON, 3, mf.on, mf.id), jk_mo(1u, 3, mf.on);
    mf.t = now + 1200u + jk_rnd(1200u), mf.i++;
}
static void jk_notes_off(void)
{
    mf_off(), mf.i = 0;
    uint32_t t;
    for (t = 0; t < NT; t++) jk_play(t, 0), jk.want[t] = 0;
}
static uint32_t jk_open(uint32_t L)            /* its opening (ms): the tracks come in, the filters open, the notes move
                                                 * twice as often: L / 6, 4 min at most (ENDLESS: 4 min) */
{
    return L && L / 6u < 240000u ? L / 6u : 240000u;
}
static uint32_t jk_fo(uint32_t L)              /* its dying out (ms): L / 5, 1 .. 8 min */
{
    uint32_t fo = L / 5u;
    return fo < 60000u ? 60000u : fo > 480000u ? 480000u : fo;
}
static void jk_calm(void)                       /* the mix as set: every gain up, the filters back */
{
    uint32_t t;
    for (t = 0; t < NT; t++) jk_tg[t] = 32767, jk.cut_t[t] = 0;
}

static void jk_always(uint32_t on)              /* (2.2) a project loaded: START ALWAYS in it (or not) */
{
    if (on) jk_go = JK_ALWAYS, jk.done = 0;
    else if (jk_go == JK_ALWAYS) jk_go = 1;    /* (one playing goes on, as any loaded project leaves it) */
    jk.go_was = jk_go;
}
static void jk_start(uint32_t now)
{
    int32_t r = clamp(sc_root, 0, 11), n1 = jk_fit(0, 36 + r);
    uint32_t t, gap;
#ifndef DINGHY_HOST
    jk.rng ^= fm1_ticks() | 1u;                 /* (2.2: each piece its own, from the clock at its start; the host's
                                                 * tests: as before, the same each run) */
    if (!jk.rng) jk.rng = 0x2545F491u;
#endif
    jk.run = 1, jk.t0 = now, jk.len = jk_len_ms(), jk.ended = 0;
    jk.own = !tracks_latched() && !playing;     /* (nothing sounding: its own notes, out of silence) */
    gap = jk.len ? jk.len / 60u : 12000u;       /* (the tracks coming in: 5 .. 12 s apart) */
    gap = gap < 5000u ? 5000u : gap > 12000u ? 12000u : gap;
    jk.next_move = now + 3u * gap + 8000u + jk_rnd(8000u);
    jk_calm();
    if (jk.own) {
        jk_og = 0;                              /* (risen from silence: jk_arc) */
        jk_snap = jk_snap + 1u;
        jk_play(0, n1);
        jk.want[1] = (uint8_t)jk_fit(1, jk_step(n1, 4));   /* (the fifth: four notes of the scale up) */
        jk.want[2] = (uint8_t)jk_fit(2, jk_step(n1 + 12, 2));   /* (a third, an octave up) */
        jk.want[3] = (uint8_t)jk_fit(3, jk_step(n1 + 24, jk_rnd(2) ? 4 : 1));   /* (a fifth or second over it) */
        for (t = 1; t < NT; t++) jk.enter[t] = now + t * gap - gap / 4u + jk_rnd(gap / 2u);
        mf_born(now);                           /* (2.2: its motif) */
    }
}
static void jk_stop(void)                       /* turned OFF: its notes out, the mix as set */
{
    jk_notes_off();
    jk.run = 0;
    jk_calm();
    jk_og = 32767;
}
static void jk_end(uint32_t now)                /* LENGTH played out: silence till a hand wakes it */
{
    uint32_t t;
    jk_notes_off();
    for (t = 0; t < NT; t++) nq_put(NQ_RELEASE, t, 0);   /* (the latched notes, the arps) */
    if (playing) playing = 0, nq_put(NQ_STOP, 0, (uint32_t)slot_cur & 3u);
    gen_on = 0;
    jk.run = 0, jk.ended = 1, jk.end_t = now, jk.done = 1;
    if (jk_go != JK_ALWAYS) jk_go = 0;          /* (2.2: ALWAYS stays, for the next power-on) */
    jk.go_was = jk_go;
    jk_og = 0;
    jk_sleep = 1;
}

static int32_t jk_arc_at(uint32_t e, uint32_t L, uint32_t own)   /* the output's gain (Q15) e ms into a piece L long
                                                 * (0: ENDLESS): risen out of silence (its own notes: over L / 16,
                                                 * 10 .. 30 s, quick at first, heard from its first seconds), dying out
                                                 * (jk_fo) */
{
    uint32_t fi = L ? L / 16u : 30000u, fo = jk_fo(L);
    int32_t g = 32767, x;
    fi = fi < 10000u ? 10000u : fi > 30000u ? 30000u : fi;
    if (own && e < fi) x = (int32_t)((uint64_t)e * 32767u / fi), g = x * (65534 - x) >> 15;
    if (L && e + fo > L) {
        x = e >= L ? 0 : (int32_t)((uint64_t)(L - e) * 32767u / fo);
        x = x * x >> 15;
        if (x < g) g = x;
    }
    return g;
}
static int32_t jk_arc(uint32_t now) { return jk_arc_at(now - jk.t0, jk.len, jk.own); }

static void jk_glide(uint32_t now)              /* the filters' moves glide to where they go (~3 s; while it plays,
                                                 * opened over its opening, closed again as it dies out: + 10 at DRIFT
                                                 * 100 %), back to 0 once it is off */
{
    int32_t d = jk.run ? clamp(jk_drift, 0, 100) : 0, mid = 0, t;
    uint32_t e = now - jk.t0, op = jk_open(jk.len), fo = jk_fo(jk.len);
    if (d) {
        mid = e < op ? (int32_t)((uint64_t)e * 16u / op) : 16;   /* (0 .. 16) */
        if (jk.len && e + fo > jk.len) {
            int32_t c = e >= jk.len ? 0 : (int32_t)((uint64_t)(jk.len - e) * 16u / fo);
            if (c < mid) mid = c;
        }
    }
    for (t = 0; t < (int32_t)NT; t++) {
        jk.cut[t] += (jk.cut_t[t] + mid * d * 256 / 160 + yr_cut - jk.cut[t]) / 64;   /* (2.2: the season's lean) */
        jk_cut[t] = jk.cut[t];
    }
}
static uint32_t jk_dusk(uint32_t now)           /* (2.2) how far into its dusk (its dying out): 0 .. 256 (0: not yet) */
{
    uint32_t e = now - jk.t0, L = jk.len, fo = jk_fo(L);
    if (!jk.run || !L || e + fo <= L) return 0;
    return e >= L ? 256u : 256u - (uint32_t)((uint64_t)(L - e) * 256u / fo);
}
static void jk_move(uint32_t now)               /* DRIFT: a note, a track's presence, the filters' targets */
{
    int32_t d = clamp(jk_drift, 0, 100), t, n;
    uint32_t dk = jk_dusk(now);
    if (!d) { jk_calm(); return; }
    if (jk.own && (int32_t)(now - jk.next_move) >= 0) {   /* (a note: every ~4 min at 1 %, ~25 s at 100 %; in
                                                 * its opening, twice as often) */
        uint32_t m = 240000u - (uint32_t)d * 2150u;
        if (now - jk.t0 < jk_open(jk.len)) m /= 2u;
        if (dk) m *= 2u;                        /* (2.2: its dusk, half as often) */
        jk.next_move = now + m * 6u / 10u + jk_rnd(m * 8u / 10u);
        int32_t k;
        t = jk_rnd(6) ? 1 + (int32_t)jk_rnd(3) : 0;
        n = jk.note[t];
        if (n) {
            if (t == 0) {                       /* (T1, the root: to its fourth or fifth and home again) */
                int32_t home = jk_fit(0, 36 + clamp(sc_root, 0, 11));
                n = n != home && jk_rnd(10) < 6 ? home : jk_fit(0, jk_step(home, jk_rnd(2) ? 3 : 4));
            } else {
                int32_t s = 1 + (int32_t)jk_rnd(2);
                n = jk_step(n, jk_rnd(2) ? s : -s);
                if (n < JK_LO[t] || n > JK_HI[t]) n = jk_step(jk.note[t], n < JK_LO[t] ? s : -s);
                for (k = 0; k < (int32_t)NT; k++)   /* (never on another track's note) */
                    if (k != t && jk.note[k] == n) n = jk_step(n, 1);
                n = clamp(n, JK_LO[t], JK_HI[t]);
            }
            for (k = 0; k < (int32_t)NT; k++)   /* (never on another track's note: this move left out) */
                if (k != t && jk.note[k] == n) n = jk.note[t];
            jk_play((uint32_t)t, n);
        }
    }
    for (t = 0; t < (int32_t)NT && !dk; t++) {   /* (2.2: in its dusk the mix stays as it is) */
        if ((int32_t)(now - jk.next_g[t]) >= 0) {   /* (a track's presence, its filter: every 40 .. 120 s) */
            int32_t g = 32767 - (int32_t)jk_rnd((uint32_t)d * 200u);
            jk.next_g[t] = now + 40000u + jk_rnd(80000u);
            if (t && jk_rnd(250) < (uint32_t)d) g = 3000;   /* (a rest a while) */
            jk_tg[t] = g;
            jk.cut_t[t] = ((int32_t)jk_rnd(29) - 14) * d * 256 / 100;
        }
    }
}

/* ---- RUOHCAT: the main loop picks an event's time and its sound, the audio plays it */
enum { RU_CRACK, RU_DRIP, RU_BOOM, RU_SMP, RU_ANS };   /* (2.1, RU_ANS: the ice's answer) */
typedef struct {
    uint8_t type, hits;                         /* RU_; a crack's sub-cracks to come */
    uint16_t gap;                               /* .. samples between them (at most) */
    int32_t cut1, cut2, amp, pan, send;         /* band-passes (CUTOFF << 8), level (Q15), PAN (0 .. 32767), REV send */
    uint32_t inc;                               /* a drip's, a boom's pitch (phase step); a sample's speed (Q16 of its
                                                 * samples an output sample) */
    uint32_t slot, seg, len;                    /* a sample's slot, its first segment, its length (its samples) */
} ru_ev_t;
static volatile int32_t ru_smp, ru_share = 50, ru_vary = 30;   /* the RUOHCAT page's knobs: SAMPLE (0 OFF, 1 .. 4 a slot,
                                                 * 5 ALL), SHARE %, VARY % */
static const char *const RU_SMP_NAME[RU_NSMP] = {"OFF", "SLOT 1", "SLOT 2", "SLOT 3", "SLOT 4", "ALL"};
static const char *const RU_SMP_SHORT[RU_NSMP] = {"OFF", "S1", "S2", "S3", "S4", "ALL"};
#define RS_N 2u                                 /* samples playing at once at most */
static volatile uint32_t ru_w;                  /* main loop: + 1 an event (ru_q[ru_w % 4]) */
static ru_ev_t ru_q[4];
static uint32_t ru_next;                        /* main loop: the next event's time */
static volatile uint32_t ru_hit;                /* audio: + 1 an event begun (the screen's flash) */
static uint8_t ru_last;                         /* main loop: the last event's type (the screen) */

static volatile uint32_t rs_busy;               /* audio: the samples playing now (the main loop: room for one more) */
static int ru_pick(ru_ev_t *E)                  /* main loop: a sample event into E (0: none to play, no room) */
{
    uint32_t k, n, ok = 0, v = (uint32_t)clamp(ru_vary, 0, 100), sg, nseg;
    int32_t semi = 0;
    static const int8_t SEMI[5] = {-12, -7, -5, 5, 7};
    if (ru_smp <= 0 || rs_busy >= RS_N) return 0;
    for (k = 0; k < SMP_SLOTS; k++)             /* (the slots it may play: ready ones) */
        if (smp[k].ready && smp[k].n >= SMP_SEG * 4u && (ru_smp >= RU_NSMP - 1 || (uint32_t)ru_smp == k + 1u)) ok |= 1u << k;
    if (!ok) return 0;
    do k = jk_rnd(SMP_SLOTS); while (!(ok >> k & 1u));
    n = smp[k].n, nseg = n / SMP_SEG;
    sg = v ? jk_rnd(nseg * v / 100u / 2u + 1u) : 0;   /* (VARY: from up to half way in) */
    E->type = RU_SMP, E->slot = k, E->seg = sg;
    E->len = n - sg * SMP_SEG;
    if (v) E->len -= (uint32_t)(((uint64_t)E->len * jk_rnd(v * 7u + 1u)) / 1000u);   /* (shorter: up to 70 %) */
    if (E->len < SMP_SEG * 4u) E->len = SMP_SEG * 4u;
    if (v && jk_rnd(140) < v) semi = SEMI[jk_rnd(5)];   /* (now and then a fourth, a fifth, an octave) */
    E->inc = pow2_q16(semi * 16) >> 1;          /* (22050 Hz: half a sample of it an output sample) */
    E->amp = 13000 + (int32_t)jk_rnd(5000);
    E->pan = 6000 + (int32_t)jk_rnd(20768);
    E->send = 10000 + (int32_t)jk_rnd(14000);
    return 1;
}

static uint32_t kl_until, kl_mask;              /* (2.2) a flash on the keys: till when, which (key 0 .. 26) */
static void kl_flash(uint32_t type, uint32_t note)   /* (2.2) RUOHCAT's event of type on the keys (RU_ANS: its note) */
{
    uint32_t h = (ru_w + 1u) * 2654435761u >> 16, p, base = (uint32_t)(KEY0 + 12 * set.oct);
    switch (type) {
    case RU_CRACK: p = h % 24u, kl_mask = 7u << p, kl_until = fm1_ms + 140u; break;
    case RU_DRIP: kl_mask = 1u << (20u + h % 7u), kl_until = fm1_ms + 90u; break;
    case RU_BOOM: kl_mask = 7u, kl_until = fm1_ms + 420u; break;
    case RU_ANS:
        while (note < base) note += 12u;
        while (note >= base + 27u) note -= 12u;
        kl_mask = 1u << (note - base), kl_until = fm1_ms + 600u;
        break;
    default: return;
    }
}
static uint32_t kl_keys(void)                   /* (2.2) the keys JIEHKKI and RUOHCAT light now (key 0 .. 26) */
{
    uint32_t m = 0, t, base = (uint32_t)(KEY0 + 12 * set.oct);
    if (jk.run)
        for (t = 0; t < NT; t++)
            if (jk.note[t] >= base && jk.note[t] < base + 27u) m |= 1u << (jk.note[t] - base);
    if ((int32_t)(kl_until - fm1_ms) > 0) m |= kl_mask;
    return m;
}

static uint32_t ra_due, ra_note;                /* main loop: the ice's answer, when (0: none), its note */
static void ru_heard(uint32_t n)                /* main loop: a note played by a hand (a key, MIDI): the ice may answer */
{
    int32_t d = clamp(jk_ruo, 0, 100);
    if (!d || jk.ended || ra_due) return;       /* (RUOHCAT off, the piece over, an answer already coming) */
    if (jk_rnd(100) >= (uint32_t)(25 + d * 6 / 10)) return;   /* (25 % of the notes at 1 %, 85 % at 100 %) */
    ra_note = n, ra_due = fm1_ms + 1500u + jk_rnd(3500);
    if (!ra_due) ra_due = 1u;
}

static void ru_tick(uint32_t now)
{
    int32_t d = clamp(jk_ruo, 0, 100);
    uint32_t mean, r;
    ru_ev_t *E;
    if (ra_due && (int32_t)(now - ra_due) >= 0) {   /* (2.1) the answer: the note an octave up, far off, into SPACE */
        ra_due = 0;
        if (d && !jk.ended) {
            E = &ru_q[ru_w % 4u];
            E->type = RU_ANS, E->inc = pitch_inc((uint32_t)clamp(((int32_t)ra_note + 12) * 16, 0, 2047));
            E->amp = 2600 + (int32_t)jk_rnd(1800), E->pan = (int32_t)jk_rnd(32768), E->send = 26000;
            ru_last = RU_ANS;
            kl_flash(RU_ANS, ra_note + 12u);
            ru_w = ru_w + 1u;
        }
    }
    if (!d || jk.ended) { ru_next = now + 2000u; return; }
    if ((int32_t)(now - ru_next) < 0) return;
    mean = 60000u >> (d / 16);                  /* (1 %: ~a minute apart; 50 %: ~8 s; 100 %: under 1 s) */
    mean -= mean * (uint32_t)(d % 16) / 32u;
    ru_next = now + mean / 4u + jk_rnd(mean * 3u / 2u);
    E = &ru_q[ru_w % 4u];
    r = jk_rnd(100);
    E->type = r < 55u ? RU_CRACK : r < 85u ? RU_DRIP : RU_BOOM;
    if (jk_rnd(100) < (uint32_t)clamp(ru_share, 0, 100) && ru_pick(E)) {
        ru_last = RU_SMP;
        ru_w = ru_w + 1u;
        return;
    }
    if (ru_smp && ru_share >= 100) return;      /* (the samples alone: none ready, nothing) */
    E->pan = (int32_t)jk_rnd(32768);
    E->send = 12000 + (int32_t)jk_rnd(16000);
    switch (E->type) {
    case RU_CRACK:                              /* (a band at 2 .. 6 kHz, its body at 300 .. 800 Hz; 1 .. 6 cracks) */
        E->cut1 = (85 + (int32_t)jk_rnd(22)) << 8, E->cut2 = (46 + (int32_t)jk_rnd(20)) << 8;
        E->hits = (uint8_t)jk_rnd(6), E->gap = (uint16_t)(200u + jk_rnd(1600));
        E->amp = 4500 + (int32_t)jk_rnd(4500);
        break;
    case RU_DRIP:                               /* (1.3 .. 3.2 kHz, falling) */
        E->inc = (1300u + jk_rnd(1900)) * 97391u, E->amp = 1800 + (int32_t)jk_rnd(2400);
        break;
    default:                                    /* (40 .. 70 Hz, a few seconds) */
        E->inc = (40u + jk_rnd(30)) * 97391u, E->amp = 4000 + (int32_t)jk_rnd(4000);
        E->cut1 = (34 + (int32_t)jk_rnd(8)) << 8, E->send = 20000;
        break;
    }
    ru_last = E->type;
    kl_flash(E->type, 0);
    ru_w = ru_w + 1u;
}

#define RU_N 3                                  /* events sounding at once at most */
static struct {
    uint8_t on, type, hits;
    uint16_t gap, cnt;
    uint8_t sh1, sh2;                           /* its envelopes' falls: e -= e >> sh a sample (2^sh samples) */
    int32_t e1, e2, amp, gl, gr, send, n1, n2, n3, n4, lp;   /* (e1, e2: Q23, amp << 8) */
    uint32_t ph, inc, inc_lo, ph2;              /* (ph2: the answer's second partial) */
    tsvf_t f1, f2;
    int32_t k1, k2;
} ru[RU_N];
static struct {                                /* audio: the samples playing */
    uint8_t on, slot;
    uint32_t pos, end, frac, step, att;         /* the next sample to decode, its end; Q16 between; samples played */
    int32_t pred, idx, y0, y1, amp, gl, gr, send;
} ru_sp[RS_N];
static uint32_t ru_r;                           /* audio: the events taken */
static int32_t ru_rng = 0x1B873593;

static void rs_begin(const ru_ev_t *E)
{
    uint32_t i, best = 0;
    const smp_slot_t *S = &smp[E->slot & 3u];
    if (!S->ready) return;
    for (i = 0; i < RS_N; i++) {                /* (a free one; none: the one furthest on goes) */
        if (!ru_sp[i].on) { best = i; break; }
        if (ru_sp[i].att > ru_sp[best].att) best = i;
    }
    i = best;
    ru_sp[i].on = 1, ru_sp[i].slot = (uint8_t)(E->slot & 3u);
    ru_sp[i].pos = E->seg * SMP_SEG, ru_sp[i].end = ru_sp[i].pos + E->len;
    if (ru_sp[i].end > S->n) ru_sp[i].end = S->n;
    ru_sp[i].pred = smp_ipred[E->slot & 3u][E->seg], ru_sp[i].idx = smp_iidx[E->slot & 3u][E->seg];
    ru_sp[i].frac = 0, ru_sp[i].step = E->inc, ru_sp[i].att = 0, ru_sp[i].y0 = ru_sp[i].y1 = 0;
    ru_sp[i].amp = E->amp, ru_sp[i].send = E->send;
    ru_sp[i].gl = 32767 - (E->pan >> 1), ru_sp[i].gr = 16384 + (E->pan >> 1);
    ru_hit++;
}
static void rs_render(int32_t *out, int32_t *rev, uint32_t n)   /* audio: the samples, read on from their slots */
{
    uint32_t k, i, busy = 0;
    for (k = 0; k < RS_N; k++) {
        const smp_slot_t *S = &smp[ru_sp[k].slot];
        if (!ru_sp[k].on) continue;
        if (!S->ready) { ru_sp[k].on = 0; continue; }   /* (its slot cleared, written over) */
        for (i = 0; i < n; i++) {
            int32_t y, g, left;
            for (ru_sp[k].frac += ru_sp[k].step; ru_sp[k].frac >= 65536u; ru_sp[k].frac -= 65536u) {
                ru_sp[k].y0 = ru_sp[k].y1;
                ru_sp[k].y1 = ru_sp[k].pos < ru_sp[k].end ? ima_dec(S->data, ru_sp[k].pos, &ru_sp[k].pred, &ru_sp[k].idx) : 0;
                ru_sp[k].pos++;
            }
            y = ru_sp[k].y0 + (((ru_sp[k].y1 - ru_sp[k].y0) * (int32_t)(ru_sp[k].frac >> 2)) >> 14);
            left = (int32_t)ru_sp[k].end - (int32_t)ru_sp[k].pos;   /* (its last 100 ms: out) */
            g = left <= 0 ? 0 : left < 2205 ? left * 14 : 32767;
            if (ru_sp[k].att < 882u) g = g * (int32_t)ru_sp[k].att / 882;   /* (its first 20 ms: in) */
            ru_sp[k].att++;
            y = mulq15(mulq15(y, g), ru_sp[k].amp);
            out[2u * i] += mulq15(y, ru_sp[k].gl), out[2u * i + 1u] += mulq15(y, ru_sp[k].gr);
            rev[i] += mulq15(y, ru_sp[k].send);
        }
        if (ru_sp[k].pos >= ru_sp[k].end + 2u) ru_sp[k].on = 0;
        busy += ru_sp[k].on;
    }
    rs_busy = busy;
}

static void ru_begin(const ru_ev_t *E)
{
    uint32_t i, best = 0;
    if (E->type == RU_SMP) { rs_begin(E); return; }
    for (i = 0; i < RU_N; i++) {                /* (a free one; none: the quietest goes) */
        if (!ru[i].on) { best = i; break; }
        if (ru[i].e1 < ru[best].e1) best = i;
    }
    i = best;
    ru[i].on = 1, ru[i].type = E->type, ru[i].hits = E->hits, ru[i].gap = E->gap, ru[i].cnt = E->gap;
    ru[i].amp = E->amp, ru[i].e1 = ru[i].e2 = E->amp << 8, ru[i].send = E->send;
    ru[i].gl = 32767 - (E->pan >> 1), ru[i].gr = 16384 + (E->pan >> 1);
    ru[i].n1 = ru[i].n2 = ru[i].n3 = ru[i].n4 = ru[i].lp = 0, ru[i].ph = 0, ru[i].inc = E->inc;
    if (E->type == RU_CRACK) {
        ru[i].k1 = 900, ru[i].k2 = 1800;
        tsvf_coef_k(&ru[i].f1, E->cut1, ru[i].k1), tsvf_coef_k(&ru[i].f2, E->cut2, ru[i].k2);
        ru[i].sh1 = (uint8_t)(8u + (E->gap > 1000u) + (E->gap > 1400u));   /* (a crack ~6 .. 23 ms) */
    } else if (E->type == RU_ANS) {             /* (a bell of ice: its note, and a partial 2.75 x it that dies sooner) */
        ru[i].inc_lo = (E->inc >> 2) * 11u, ru[i].ph2 = 0, ru[i].sh1 = 15, ru[i].sh2 = 13;   /* (~0.7 s, ~0.2 s) */
    } else if (E->type == RU_DRIP) {
        ru[i].inc_lo = E->inc / 2u + E->inc / 16u, ru[i].sh1 = 11;   /* (~46 ms) */
    } else {
        ru[i].inc_lo = E->inc * 3u / 4u, ru[i].sh1 = 16, ru[i].sh2 = 10;   /* (~1.5 s; its rise ~23 ms) */
        tsvf_coef_k(&ru[i].f1, E->cut1, 5000);
    }
    ru_hit++;
}

static void ru_render(int32_t *out, int32_t *rev, uint32_t n)   /* audio: RUOHCAT's sounds into the mix, the REV bus */
{
    uint32_t i, k, w = ru_w;
    if (w - ru_r > 4u) ru_r = w - 4u;
    while (ru_r != w) ru_begin(&ru_q[ru_r++ % 4u]);
    rs_render(out, rev, n);
    for (k = 0; k < RU_N; k++) {
        if (!ru[k].on) continue;
        for (i = 0; i < n; i++) {
            int32_t y, z = (int32_t)(noise32(&ru_rng) >> 1) >> 16;   /* (-16384 .. 16383) */
            switch (ru[k].type) {
            case RU_CRACK:
                y = tsvf_any(&ru[k].f1, ru[k].k1, FT_BP, z, &ru[k].n1, &ru[k].n2) +
                    (tsvf_any(&ru[k].f2, ru[k].k2, FT_BP, z, &ru[k].n3, &ru[k].n4) >> 1);
                y = mulq15(y, ru[k].e1 >> 8);
                ru[k].e1 -= (ru[k].e1 >> ru[k].sh1) + (ru[k].e1 > 0);
                if (ru[k].hits && !--ru[k].cnt) {   /* (the next crack, as loud or softer) */
                    ru[k].hits--, ru[k].cnt = (uint16_t)(ru[k].gap / 2u + (uint32_t)(noise32(&ru_rng) % ru[k].gap));
                    ru[k].e1 = (ru[k].amp * (8 + (int32_t)(noise32(&ru_rng) & 7u)) / 16) << 8;
                }
                break;
            case RU_ANS:
                y = mulq15(sine_i(ru[k].ph), ru[k].e1 >> 8) + (mulq15(sine_i(ru[k].ph2), ru[k].e2 >> 8) >> 2);
                ru[k].ph += ru[k].inc, ru[k].ph2 += ru[k].inc_lo;
                ru[k].e1 -= (ru[k].e1 >> ru[k].sh1) + (ru[k].e1 > 0);
                ru[k].e2 -= (ru[k].e2 >> ru[k].sh2) + (ru[k].e2 > 0);
                break;
            case RU_DRIP:
                y = mulq15(sine_i(ru[k].ph), ru[k].e1 >> 8);
                ru[k].ph += ru[k].inc;
                if (ru[k].inc > ru[k].inc_lo) ru[k].inc -= ru[k].inc >> 9;
                ru[k].e1 -= (ru[k].e1 >> ru[k].sh1) + (ru[k].e1 > 0);
                break;
            default:                            /* (the slow one less the fast one: a soft rise, a long fall) */
                ru[k].lp = tsvf_lp(&ru[k].f1, z, &ru[k].n1, &ru[k].n2);
                y = mulq15(sine_i(ru[k].ph) + ru[k].lp, (ru[k].e1 - ru[k].e2) >> 8);
                ru[k].ph += ru[k].inc;
                if (ru[k].inc > ru[k].inc_lo && !(i & 15u)) ru[k].inc -= ru[k].inc >> 10;
                ru[k].e1 -= (ru[k].e1 >> ru[k].sh1) + (ru[k].e1 > 0);
                ru[k].e2 -= (ru[k].e2 >> ru[k].sh2) + (ru[k].e2 > 0);
                break;
            }
            out[2u * i] += mulq15(y, ru[k].gl), out[2u * i + 1u] += mulq15(y, ru[k].gr);
            rev[i] += mulq15(y, ru[k].send);
        }
        if (ru[k].e1 < 2048 && !ru[k].hits) ru[k].on = 0;   /* (under 8 of its Q15: gone) */
    }
}

/* audio: the output's gain (JIEHKKI's rise and fall), ramped a step a sample (a sweep ~0.7 s at most) */
static void jk_out(int32_t *out, uint32_t n)
{
    static uint32_t snap;
    int32_t g = jk_oga, t = clamp(jk_og, 0, 32767);
    uint32_t i;
    if (snap != jk_snap) snap = jk_snap, g = t;
    if (g == 32767 && t == 32767) return;
    for (i = 0; i < n; i++) {
        g += g < t ? 1 : g > t ? -1 : 0;
        out[2u * i] = mulq16(out[2u * i], (uint32_t)g << 1);   /* (32-bit: no 64-bit multiply in the ISR) */
        out[2u * i + 1u] = mulq16(out[2u * i + 1u], (uint32_t)g << 1);
    }
    jk_oga = g;
}
static int32_t jk_trk(uint32_t t)               /* audio, a block: track t's gain (Q15), ramped (~0.5 s at most) */
{
    int32_t g = jk_tga[t], d = jk_tg[t] - g;
    g += d > 48 ? 48 : d < -48 ? -48 : d;
    return jk_tga[t] = g;
}

/* main loop, each pass: the knob START, the piece, RUOHCAT; touched: a hand's (or a MIDI note's) last time */
static uint32_t ih_next, ih_end;                /* (2.2) the ice's next held breath (0: none due), this one's end */
static void ih_tick(uint32_t now)
{
    int32_t d = clamp(jk_ruo, 0, 100);
    uint32_t m = 90000u - (uint32_t)d * 700u;
    if (rv_hold) {
        if ((int32_t)(now - ih_end) >= 0) rv_hold = 0, ih_next = now + m / 2u + jk_rnd(m);
        return;
    }
    if (!d || jk.ended || rv_size >= RV_INF || rv_mix <= 0) { ih_next = 0; return; }   /* (off, over, INF by hand) */
    if (ih_next && (int32_t)(now - ih_next) >= 0) rv_hold = 1, ih_end = now + 3000u + jk_rnd(7000u);
    else if (!ih_next || ih_next - now > m * 3u / 2u) ih_next = now + m / 2u + jk_rnd(m);   /* (none due; RUOHCAT
                                                 * turned up: sooner) */
}
static void jk_tick(uint32_t now, uint32_t touched)
{
    if (jk.ended && (int32_t)(touched - jk.end_t) > 0) {   /* (over and silent: a hand wakes it) */
        jk.ended = 0, jk_og = 32767;
        jk_calm();
    }
    if (now - jk.tick < JK_TICK) return;
    jk.tick = now;
    if (jk_go != jk.go_was) jk.go_was = jk_go, jk.done = 0;   /* (2.2) START turned: a piece again */
    if (jk_go && !jk.run && !jk.done) jk_start(now);
    else if (!jk_go && jk.run) jk_stop();
    if (jk.run) {
        uint32_t t;
        jk.len = jk_len_ms();                   /* (LENGTH turned while it plays: from its start still) */
        for (t = 1; t < NT; t++)                /* (its own tracks coming in) */
            if (jk.want[t] && (int32_t)(now - jk.enter[t]) >= 0) jk_play(t, jk.want[t]), jk.want[t] = 0;
        jk_og = jk_arc(now);
        if (jk.own && jk_dusk(now))             /* (2.2) its dusk: its own tracks go, the highest first */
            for (t = 1; t < NT; t++)
                if (jk_dusk(now) >= 64u * (NT - t)) jk_play(t, 0), jk.want[t] = 0, jk_tg[t] = 32767;
        jk_move(now);
        mf_tick(now);                           /* (2.2: its motif now and then) */
        if (jk.len && now - jk.t0 >= jk.len) jk_end(now);
    }
    jk_glide(now);
    ru_tick(now);
    ih_tick(now);
    yr_tick(now);                               /* (2.2) the year */
}
