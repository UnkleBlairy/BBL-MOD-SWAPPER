/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 GR!MM */
/* Arctic Scream's DELAY: a tape echo. Written in integers; the design follows X0X's TAPE delay (fx_delay in
 * firmware/src/dsp/fxbus.c of charlesvestal/fm1-x0x, GPL-3.0, itself a port of 9W9's er99_dly_tick, GPL-3.0): wow
 * (0.5 Hz) and flutter (6.1 Hz) on the read position, a darker loop with a tanh saturation that holds it, a 30 Hz DC
 * block inside it, feedback up to past unity. X0X's code is float, which the FM-1 cannot run: none of it is here.
 * The wow and the saturation are in wear.c (the TAPE effect has them too). The integer pieces are Felucca's, as Arctic Scream
 * has them (softclip, soft_knee, sh_tz, the one-pole low-pass that keeps
 * its steps' remainders so a tail ends in exact silence).
 *
 *   at a quarter of the rate (11.025 kHz; 2.1.4, was half: 2.6 s fit in 58 KB, the pool's 58 KB for the rest, the echoes
 *   stop near 5 kHz, as a worn tape's do): the voices (four samples into one, 1 2 2 2 1) -> the line (28992 samples)
 *   -> read TIME back, plus the wow (two slow sines,
 *   0.5 and 0.19 Hz: not quite periodic) and a little flutter (6.1 Hz), between samples, gliding over the block; the
 *   right side 9 ms later -> the loop: a one-pole low-pass (WEAR: ~7 kHz .. ~1.2 kHz), FEEDBACK (0 .. 150 %), a tanh
 *   saturation (WEAR: 1x .. 4x drive, the level made up; and WEAR's wow up to ~11 ms: Arctic Scream 1.3), the DC block -> back into the line with the input,
 *   through a soft knee: no sum can clip. Each repeat: darker, a little saturated, a little more wobbly.
 *   TIME glides to a new value (~50 ms): the pitch bends, as a tape's does.
 *   MIX: the return (the echoes' level: the tracks' DLY sends set how much goes in); the echoes also go into the REV
 *   bus at that level: they fall into SPACE.
 *   PING-PONG (Arctic Scream 1.4, AIR's; the idea from ECHOFIELD's ping-pong delay, Philip Bos, MIT: its code float,
 *   none of it here): the loop reads 2 TIME back (its gain FEEDBACK squared), the left side TIME, the right 2 TIME at
 *   FEEDBACK: the echoes go left, right, left .., each FEEDBACK's gain after the last; TIME at most 1.3 s. PING-PONG's amount: how
 *   far apart the sides are (the other side's share of each echo, 1 .. 0). Nothing runs at MIX 0, or once
 *   the line is all silence and nothing comes in.
 *
 * The audio ISR calls tape_render with the DLY bus, before SPACE (the echoes fall into the reverb); the main loop
 * sets the four parameters. The line and the state are in the pool (zero at boot): ~117 KB. */

#define DL_D 4u                                 /* (2.1.4) the line's rate: 44.1 kHz / DL_D (was 2) */
#define DL_NC 64u                               /* a block at that rate: app_audio's 256 frames */
#define DL_LEN 28992u                           /* 2600 ms (28665 samples; 1.5.2, was 3000) + the wow's reach (1.3: ~11
                                                 * ms) + the right side's 9 ms, a whole number of blocks */
#define DL_SPREAD (99 << 8)                     /* the right side reads 9 ms further back (Q8 samples) */
#define DL_IN 8192                              /* the voices into the line, Q15: a quarter (headroom for the loop; V2:
                                                 * half of 1.0's, its return twice: loud chords never reach its knee) */
#define DL_DCK 560                              /* the DC block: 30 Hz at 11.025 kHz, Q15 */
#define DL_W1 12467522u                         /* the wow: 0.5 Hz, a block's step (2^32 * 256 / 44100 * Hz) */
#define DL_W2 4737658u                          /* .. and 0.19 Hz beside it: not quite periodic */
#define DL_W3 152103765u                        /* the flutter: 6.1 Hz */
#define DL_MSQ8 2822                            /* a ms in Q8 samples at 11.025 kHz */
_Static_assert(2600u * DL_MSQ8 / 256u + 1u + 26u + 99u + 2u < DL_LEN, "DELAY: the longest read stays in the line");

static int16_t dl_buf[DL_LEN] __attribute__((unused));
static struct {
    uint32_t w, quiet;                          /* the write index; half-rate samples with silence in and written */
    uint32_t p1, p2, p3;                        /* the wow's and the flutter's phases */
    int32_t d, m;                               /* TIME gliding to its target, the wow at the block's end (Q8 samples) */
    int32_t x, lp, le, dc, de, ml, mr;          /* the input's last sample; the loop's low-pass and DC block (and
                                                 * their steps' remainders); the last wet out, left / right */
    int32_t l[DL_NC], r[DL_NC];                 /* the block's echoes at half the rate */
} dl __attribute__((unused));

/* the parameters, 0..127, written by the main loop */
static volatile int32_t dl_time = 88, dl_fb = 64, dl_wear = 50, dl_mix = 100;   /* 644 ms, 55 %, return 79 % (the tracks' DLY 0: nothing goes in) */
static volatile int32_t dl_pp;                  /* (1.4) PING-PONG, 0..127: 0 off */
#define DL_PPMAX (((DL_LEN - 400u) / 2u) << 8)    /* PING-PONG's TIME at most (Q8 samples: 2 TIME and the wow in the line) */

/* main loop: the delay gives nothing out (MIX 0, or the line silent and nothing coming in) */
static int tape_idle(void) { return dl_mix <= 0 || dl.quiet >= DL_LEN; }

/* a read d (Q8 samples) behind the write index w, between samples */
static inline int32_t tape_read(uint32_t w, int32_t d)
{
    int32_t i0 = (int32_t)w - (d >> 8), f = d & 255, b0, b1;
    i0 = i0 < 0 ? i0 + (int32_t)DL_LEN : i0;
    b0 = dl_buf[i0];
    b1 = dl_buf[i0 ? i0 - 1 : (int32_t)DL_LEN - 1];   /* one further back */
    return b0 + (((b1 - b0) * f + 128) >> 8);
}

/* the audio ISR: n (= 2 DL_NC) frames of the DLY bus in (mono) -> the echoes added to out (L R) and to the REV bus */
static void tape_render(const int32_t *in, int32_t *out, int32_t *rev, uint32_t n)
{
    uint32_t i, any = 0, w;
    int32_t mix = dl_mix, wear = dl_wear, fbk = dl_fb;
    int32_t target, d0, d1, m1, a, tc, g, ig, fb, f1, pp = clamp(dl_pp, 0, 127), po = 32767 - pp * 258;
    int32_t xp = dl.x, lp = dl.lp, le = dl.le, dc = dl.dc, de = dl.de, ml = dl.ml, mr = dl.mr;
    if (n != DL_D * DL_NC || mix <= 0)
        return;                                 /* MIX 0: the dry alone; the line waits as it is */
    for (i = 0; i < DL_D * DL_NC && !any; i++)
        any = in[i] != 0;
    if (!any && dl.quiet >= DL_LEN)
        return;                                 /* the line silent, nothing coming in: nothing to do */
    wear = clamp(wear, 0, 127);
    fbk = clamp(fbk, 0, 127);

    /* this block's settings: TIME (gliding), the wow, the loop's tone, drive and feedback */
    target = (int32_t)DL_MS[clamp(dl_time, 0, 127)] * DL_MSQ8;   /* ms -> Q8 samples at 11.025 kHz */
    if (pp && target > (int32_t)DL_PPMAX) target = (int32_t)DL_PPMAX;
    if (!dl.d)
        dl.d = target;                          /* (the first block: no glide from nothing) */
    d0 = dl.d;
    d1 = d0 + ((target - d0) >> 3);             /* ~50 ms to a new TIME */
    dl.d = d1;
    dl.p1 += DL_W1, dl.p2 += DL_W2, dl.p3 += DL_W3;
    a = ((10 + wear) * 94 + wear * wear * 3) / 2;   /* the wow's reach, Q8 samples: ~0.17 .. ~11 ms (Arctic Scream 1.3: was
                                                 * 2.3 ms; a worn-out tape at the top) */
    m1 = wear_wow(dl.p1, dl.p2, dl.p3, a);      /* (wear.c) */
    tc = 32767 - wear * 148 - 4467;             /* the loop's low-pass, Q15, as it was at 22.05 kHz (~7 kHz .. ~1.2 kHz), */
    tc = 32768 - (((32768 - tc) * (32768 - tc)) >> 15);   /* .. the same pole over two of its samples at 11.025 */
    g = 4096 + wear * 97;                       /* the saturation's drive, Q12: 1x .. 4x (1.3: was 1.8x) */
    ig = (int32_t)(134217728u / (uint32_t)g) >> 1;   /* .. and the level made up after it, Q15 (the line at
                                                 * half: driven twice as hard, half back: saturating where it did) */
    g *= 2;
    fb = fbk <= 100 ? fbk * 284 : 28400 + (fbk - 100) * 769;   /* FEEDBACK, Q15: 0 .. ~0.87 at 100, then on to 1.5 (Arctic
                                                 * p0larpatch: past unity on purpose, as Audrey II's echo: it grows
                                                 * and saturates) */
    f1 = fb;
    if (pp) fb = (int32_t)(((int64_t)fb * fb) >> 15);   /* (PING-PONG: the loop twice TIME: FEEDBACK twice) */

    w = dl.w;
    {
        int32_t D0 = d0 + dl.m, dD = (d1 + m1) - D0;
        for (i = 0; i < DL_NC; i++) {
            const int32_t *q = in + DL_D * i;
            int32_t x = (xp + 2 * (q[0] + q[1] + q[2]) + q[3]) >> 3, D = D0 + ((dD * (int32_t)i) >> 6);
            int32_t y = tape_read(w, D), v, e;
            xp = q[3];
            x = mulq15(clamp(x, -65535, 65535), DL_IN);
            if (pp) {                           /* PING-PONG: left TIME back, right (and the loop) 2 TIME */
                int32_t y2 = tape_read(w, 2 * D), yr = mulq15(y2, f1);   /* (the right's echo: one FEEDBACK after
                                                 * the left's) */
                dl.l[i] = y + mulq15(yr, po);
                dl.r[i] = yr + mulq15(y, po);
                y = y2;
            } else {
                dl.l[i] = y;
                dl.r[i] = tape_read(w, D + DL_SPREAD);
            }
            e = (y - lp) * tc + le, le = e & 32767, lp += e >> 15;          /* darker each time round */
            v = sh_tz(lp * fb, 15);                                         /* FEEDBACK */
            v = wear_sat(v, g, ig);                                         /* the tape's saturation (wear.c) */
            e = (v - dc) * DL_DCK + de, de = e & 32767, dc += e >> 15;      /* the DC block */
            LV_COUNT(lv_dlk, x + v - dc, 16384);
            v = clamp(soft_knee(x + v - dc, 16384), -32767, 32767);         /* in with the input: never clips */
            dl_buf[w] = (int16_t)v;
            dl.quiet = (v | x) ? 0u : dl.quiet + 1u;
            if (++w == DL_LEN) w = 0;
        }
    }
    dl.w = w, dl.m = m1, dl.x = xp, dl.lp = lp, dl.le = le, dl.dc = dc, dl.de = de;

    /* back to 44.1 kHz, between samples, at the return's level (MIX), into out and into the REV bus */
    {
        int32_t wg = mix * 258;
        for (i = 0; i < DL_NC; i++) {
            int32_t wl = dl.l[i], wr = dl.r[i], *o = out + 2u * DL_D * i, k;
            for (k = 0; k < (int32_t)DL_D; k++) {   /* (from the last toward this one, a quarter on each) */
                int32_t a = 2 * mulq15((ml * (3 - k) + wl * (k + 1)) >> 2, wg), b = 2 * mulq15((mr * (3 - k) + wr * (k + 1)) >> 2, wg);   /* (x 2) */
                o[2 * k] += a, o[2 * k + 1] += b;
                rev[DL_D * i + (uint32_t)k] += (a + b) >> 1;   /* (the echoes, both sides, into SPACE) */
            }
            ml = wl;
            mr = wr;
        }
    }
    dl.ml = ml, dl.mr = mr;
}
