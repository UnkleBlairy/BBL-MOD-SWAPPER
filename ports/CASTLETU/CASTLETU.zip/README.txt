Castletunia 1.4.1 for the BBL Mod Swapper

Original by provostprovost: https://github.com/provostprovost/castletunia
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: CASTLETU-source.zip on the ports page.
