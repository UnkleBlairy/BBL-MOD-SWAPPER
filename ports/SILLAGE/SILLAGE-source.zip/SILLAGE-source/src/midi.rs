//! MIDI for the running firmware: the Teensy's own USB port as a class-compliant USB MIDI device (next to the serial
//! port), and the FM-1's TRS jack (MIDI IN only), whose bytes the terminal forwards in 'M' packets (LINK_PROTOCOL.md).
//! Both reach the firmware through its glue's teensy_midi_in (source 1 USB, 2 TRS); its MIDI out goes to USB.

use usb_device::class_prelude::*;
use usb_device::Result;

const AUDIO: u8 = 0x01;
const AUDIOCONTROL: u8 = 0x01;
const MIDISTREAMING: u8 = 0x03;
const CS_INTERFACE: u8 = 0x24;
const CS_ENDPOINT: u8 = 0x25;

/// USB MIDI 1.0: one cable, in and out. Interfaces: audio control (empty), MIDI streaming (2 bulk endpoints).
pub struct UsbMidi<'a, B: UsbBus> {
    ac: InterfaceNumber,
    ms: InterfaceNumber,
    ep_out: EndpointOut<'a, B>,
    ep_in: EndpointIn<'a, B>,
}

impl<'a, B: UsbBus> UsbMidi<'a, B> {
    pub fn new(alloc: &'a UsbBusAllocator<B>) -> Self {
        UsbMidi { ac: alloc.interface(), ms: alloc.interface(), ep_out: alloc.bulk(64), ep_in: alloc.bulk(64) }
    }
    /// USB-MIDI event packets from the host (4 bytes each); 0 when none.
    pub fn read(&mut self, buf: &mut [u8; 64]) -> usize {
        self.ep_out.read(buf).unwrap_or(0)
    }
    /// Send up to 16 event packets; false if the endpoint is still busy (try again later).
    pub fn write(&mut self, pk: &[u8]) -> bool {
        self.ep_in.write(pk).is_ok()
    }
}

impl<B: UsbBus> UsbClass<B> for UsbMidi<'_, B> {
    fn get_configuration_descriptors(&self, w: &mut DescriptorWriter) -> Result<()> {
        w.iad(self.ac, 2, AUDIO, AUDIOCONTROL, 0, None)?;
        w.interface(self.ac, AUDIO, AUDIOCONTROL, 0)?;
        // AC header: bcdADC 1.00, total 9, one streaming interface
        w.write(CS_INTERFACE, &[0x01, 0x00, 0x01, 0x09, 0x00, 0x01, self.ms.into()])?;
        w.interface(self.ms, AUDIO, MIDISTREAMING, 0)?;
        // MS header (total, as the spec's example counts it: the header, the jacks and the endpoints with theirs:
        // 7 + 6 + 6 + 9 + 9 + 7 + 5 + 7 + 5), then: 1 embedded IN jack, 2 external IN jack, 3 embedded OUT jack
        // (from 2), 4 external OUT jack (from 1)
        w.write(CS_INTERFACE, &[0x01, 0x00, 0x01, 61, 0x00])?;
        w.write(CS_INTERFACE, &[0x02, 0x01, 0x01, 0x00])?;
        w.write(CS_INTERFACE, &[0x02, 0x02, 0x02, 0x00])?;
        w.write(CS_INTERFACE, &[0x03, 0x01, 0x03, 0x01, 0x02, 0x01, 0x00])?;
        w.write(CS_INTERFACE, &[0x03, 0x02, 0x04, 0x01, 0x01, 0x01, 0x00])?;
        w.endpoint(&self.ep_out)?;
        w.write(CS_ENDPOINT, &[0x01, 0x01, 0x01])?; // the host's data -> embedded IN jack 1
        w.endpoint(&self.ep_in)?;
        w.write(CS_ENDPOINT, &[0x01, 0x01, 0x03])?; // embedded OUT jack 3 -> the host
        Ok(())
    }
}

/// Raw MIDI bytes (the TRS jack) into whole messages: running status, realtime anywhere, SysEx skipped.
pub struct Parser {
    st: u8,
    need: u8,
    got: u8,
    d0: u8,
    sysex: bool,
}
impl Parser {
    pub const fn new() -> Self {
        Parser { st: 0, need: 0, got: 0, d0: 0, sysex: false }
    }
    /// A finished message: (status, data 1, data 2).
    pub fn byte(&mut self, b: u8) -> Option<(u8, u8, u8)> {
        if b >= 0xF8 {
            return Some((b, 0, 0)); // realtime keeps running status
        }
        if b & 0x80 != 0 {
            self.sysex = b == 0xF0;
            self.st = if b < 0xF0 { b } else { 0 }; // system common / SysEx cancel running status
            self.need = if b & 0xE0 == 0xC0 { 1 } else { 2 };
            self.got = 0;
            return None;
        }
        if self.sysex || self.st == 0 {
            return None;
        }
        if self.need == 2 && self.got == 0 {
            self.d0 = b;
            self.got = 1;
            return None;
        }
        self.got = 0;
        Some(if self.need == 2 { (self.st, self.d0, b) } else { (self.st, b, 0) })
    }
}

/// A message as a USB-MIDI event packet (cable 0) for the host: (status, d1, d2) -> CIN status d1 d2.
pub fn usb_in_to_msg(p: &[u8]) -> Option<(u8, u8, u8)> {
    let cin = p[0] & 0x0F;
    match cin {
        0x8..=0xE => Some((p[1], p[2], p[3])),
        0xF if p[1] >= 0xF8 => Some((p[1], 0, 0)),
        _ => None, // SysEx and system common: not passed on
    }
}
