/* teensy-fm1: the MIDI hooks for a port that has none yet (its glue, web/emu/felucca_teensy.c, overrides them). */
#include <stdint.h>
__attribute__((weak)) void teensy_midi_in(uint32_t st, uint32_t d1, uint32_t d2, uint32_t source)
{
    (void)st; (void)d1; (void)d2; (void)source;
}
__attribute__((weak)) void teensy_midi_link(uint32_t on) { (void)on; }
__attribute__((weak)) uint32_t teensy_midi_out(uint32_t *out, uint32_t cap) { (void)out; (void)cap; return 0; }
