/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Phase distortion. The waveforms are a C port of the oscillator of
 * CrispyZebra (Leo Kuroshita, GPL-3.0, github.com/hugelton/CrispyZebra), the
 * author's own phase-distortion core: a -cos table read through a bent phase whose
 * bend is DCW. WAVE2 alternates with WAVE every other cycle. A second
 * line (DTN) can be mixed or ring-modulated; SUB adds a sine an octave down.
 * Envelopes are Felucca's own (ADSR, ENV -> DCW).
 * FOLD (E7, 1.5.5, #104): a sine wavefolder on the voice, after the lines and before SUB and the amp. 0 is off (the
 * loop and the sound as before). Up from 0 a soft sine saturation, then folds: the gain rises to ~8x (four folds of a
 * full-scale wave). Alias-aware: the sine fold has no corners (a triangle fold's sharp edges are what alias most), and
 * above A4 the gain added past the saturation falls with the pitch (1/f), so the top notes fold less. */
static const char *const N_PD_WAVE[] = {"SAW", "SQR", "PLS", "DSIN", "SPLS", "RSAW", "RTRI", "RTRP"};
static const char *const N_PD_WAVE2[] = {"-", "SAW", "SQR", "PLS", "DSIN", "SPLS", "RSAW", "RTRI", "RTRP"};
static const char *const N_PD_LINE[] = {"MIX", "RING"};

static inline int32_t pd_cos(uint32_t ph16)             /* -cos, Q15, from the 16-bit PD phase */
{
    return -sine_i(((ph16 & 0xFFFFu) << 16) + 0x40000000u);
}

/* one wave's bend for a block: break points and the slopes of the bent phase
 * (Q16 reciprocals), so a sample costs a multiply instead of a divide (the
 * bent phase comes out the same or 1 lower in 65536) */
typedef struct pd_s {
    uint32_t w, x, peak, rez;
    uint32_t k0, k1;
    const struct pd_s *old;      /* (#41) the last block's bend, DCW having moved since (pd_bends): pd_wave fades from it */
} pd_t;

static inline uint32_t pd_slope(uint32_t span, uint32_t len) { return (span << 16) / (len ? len : 1u); }

static void pd_setup(pd_t *b, uint32_t w, uint32_t dcw)
{
    uint32_t x;
    b->w = w;
    b->old = 0;
    switch (w) {
    case 0:                                                  /* SAW */
        x = 32768u + ((dcw * 32767u) >> 16);
        b->k0 = pd_slope(32768u, x);
        b->k1 = pd_slope(32767u, 65535u - x);
        break;
    case 1:                                                  /* SQUARE */
        x = 32768u - ((dcw * 31120u) >> 16);
        b->k0 = pd_slope(32768u, x);
        b->k1 = pd_slope(32767u, x);
        break;
    case 2:                                                  /* PULSE */
        x = 65535u - ((dcw * 63487u) >> 16);
        b->k0 = pd_slope(65535u, x);
        break;
    case 3:                                                  /* DOUBLE SINE */
        x = 65535u - ((dcw * 49151u) >> 16);
        b->k0 = pd_slope(65535u, x);
        b->k1 = pd_slope(65535u, 65535u - x);
        break;
    case 4:                                                  /* SAW-PULSE */
        x = 65535u - ((dcw * 32767u) >> 16);
        b->peak = (x * (32768u + ((dcw * 29491u) >> 16))) >> 16;
        if (!b->peak)
            b->peak = 1;
        b->k0 = pd_slope(32768u, b->peak);
        b->k1 = pd_slope(32767u, x - b->peak);
        break;
    default:                                                 /* RESONANCE */
        x = 0;
        b->rez = (dcw * 44000u) >> 16;
        break;
    }
    b->x = x;
}

/* one sample at phase ph (16 bit): bipolar Q15 */
static inline __attribute__((always_inline)) int32_t pd_one(const pd_t *b, uint32_t ph)
{
    uint32_t pd, x = b->x;
    switch (b->w) {
    case 0:                                                  /* SAW */
        pd = ph < x ? (ph * b->k0) >> 16 : 32768u + (((ph - x) * b->k1) >> 16);
        break;
    case 1:                                                  /* SQUARE */
        if (ph < x)
            pd = (ph * b->k0) >> 16;
        else if (ph < 32768u)
            pd = 32768u;
        else if (ph < 32768u + x)
            pd = 32768u + (((ph - 32768u) * b->k1) >> 16);
        else
            pd = 65535u;
        break;
    case 2:                                                  /* PULSE */
        pd = ph < x ? (ph * b->k0) >> 16 : 65535u;
        break;
    case 3:                                                  /* DOUBLE SINE */
        pd = ph < x ? (ph * b->k0) >> 16 : ((ph - x) * b->k1) >> 16;
        break;
    case 4:                                                  /* SAW-PULSE */
        if (ph >= x)
            pd = 65535u;
        else if (ph < b->peak)
            pd = (ph * b->k0) >> 16;
        else
            pd = 32768u + (((ph - b->peak) * b->k1) >> 16);
        break;
    default: {                                               /* RESONANCE: windowed sine, rez = pitch of the core */
        uint32_t rp = (ph + ((ph * b->rez) >> 16) * 7u) & 0xFFFFu, win;
        int32_t core = (pd_cos(rp) * 5) >> 3;
        if (b->w == 5)
            win = 65535u - ph;                               /* saw window */
        else if (b->w == 6)
            win = ph < 32768u ? ph << 1 : (65535u - ph) << 1; /* triangle window */
        else
            win = ph < 16384u ? ph << 2 : ph > 49152u ? (65535u - ph) << 2 : 65535u;   /* trapezoid */
        if (win > 65535u)
            win = 65535u;
        return (core * (int32_t)win) >> 16;                  /* |core| <= 20479: fits 32 bits */
    }
    }
    return pd_cos(pd);
}

/* (#41) pd_one, and with b->old the old bend's wave fading into this one's over the block (i: the sample in it), as the
 * amplitude ramps: a bend switched at the block's start steps the wave there, a click each block while ENV -> DCW moves
 * it fast (an attack, a release; PD BRASS's low notes). The old bend has no old: one level */
static int32_t pd_wave(const pd_t *b, uint32_t ph, uint32_t i)
{
    int32_t s = pd_one(b, ph), s0;
    if (!b->old)
        return s;
    s0 = pd_wave(b->old, ph, i);
    return s0 + ((s - s0) * (int32_t)(i + 1u) >> CTL_LOG2);
}

/* the block's bends: b[0] WAVE, b[1] WAVE2 (every other cycle) at the block's DCW; (#41) DCW moved since the last block
 * (v->s[7]; -1 on a fresh note): b[2], b[3] at the last one's, as their .old */
static __attribute__((noinline)) void pd_bends(pd_t *b, const track_t *t, voice_t *v, const vmod_t *m)
{
    const int16_t *p = t->p;
    uint32_t w1 = (uint32_t)p[P_E0] & 7u, w2 = (uint32_t)p[P_E1], was = (uint32_t)v->s[7], dcw, k;
    int32_t depth = (p[P_E2] << 8) + m->cutoff + mulq15(m->envq15, p[P_E3] * 256);
    depth = clamp(depth + (m->shape - (64 << 8)), 0, 127 << 8);
    dcw = (uint32_t)depth * 65535u / (127u << 8);
    dcw = (dcw * 56000u) >> 16;                              /* the classic range of the bend */
    v->s[7] = (int32_t)dcw;
    for (k = 0; k < 2u; k++) {
        uint32_t w = k && w2 ? w2 - 1u : w1;
        pd_setup(&b[k], w, dcw);
        if (was != dcw && was < 56000u) {
            pd_setup(&b[k + 2u], w, was);
            b[k].old = &b[k + 2u];
        }
    }
}

/* s[4] at FOLD 0: the last block had no fold (phase_render: a FOLD going on or off crossfades a block) */
#define PD_UNFOLDED (-2147483647 - 1)

static void phase_note_on(track_t *t, voice_t *v)
{
    v->ph[1] = 0;
    v->ph[2] = 0;
    v->s[0] = 0;                 /* WAVE / WAVE2 toggle, line 1 */
    v->s[1] = 0;                 /* line 2 */
    v->s[4] = t->p[P_E7] > 0 ? 0 : PD_UNFOLDED;   /* FOLD's DC blocker (only FOLD > 0 reads them; kept on a */
    v->s[5] = 0;                                   /* retrigger: .keep) */
    v->s[6] = 163;               /* FOLD's last gain (phase_xfade): FOLD 1's, PD_FOLD_G0, until a folded block */
    v->s[7] = -1;                /* (#41) the last block's DCW (pd_bends): none yet (kept on a retrigger: .keep) */
}

/* FOLD's gain (Q8) for a block: 0.64x at FOLD 1 (sin(pi/2 x) then has a small-signal gain of 1: a soft saturation),
 * ~8x at 127; the part above 0.64x scaled by A4 / the note's pitch above A4 (PD_FOLD_REF: 440 Hz at 44.1 kHz) */
#define PD_FOLD_G0 163u
#define PD_FOLD_REF 42852281u
static inline uint32_t pd_fold_gain(uint32_t fold, uint32_t inc)
{
    uint32_t ext = fold * ((2048u - PD_FOLD_G0) << 4) / 127u;          /* Q12, <= 30160 */
    if (inc > PD_FOLD_REF)
        ext = ext * (PD_FOLD_REF >> 12) / (inc >> 12);              /* < 2^32 */
    return PD_FOLD_G0 + (ext >> 4);
}

/* the loop: fg 0 (a constant: phase_render's loop, the code as it always was), fg > 0 the fold gain (phase_render_f's
 * own copy: the loop without FOLD gains nothing) */
static inline __attribute__((always_inline)) void phase_loop(track_t *t, voice_t *v, int32_t *out, uint32_t n,
                                                            const vmod_t *m, uint32_t fg)
{
    const int16_t *p = t->p;
    uint32_t i, inc = m->inc, inc2;
    int32_t det = p[P_E4], line2 = det != 0 || p[P_E5], ring = p[P_E5], sub = p[P_E6] * 200;
    int32_t d16 = det * 16 / 100, rem = det * 16 - d16 * 100;   /* (cents_inc(), written out: the host
                                                                 * compiler makes the loop slower with it) */
    uint32_t ph0 = v->ph[0], ph1 = v->ph[1], ph2 = v->ph[2];
    int32_t tg0 = v->s[0], tg1 = v->s[1];                    /* WAVE / WAVE2 toggles */
    int32_t fx1 = fg ? v->s[4] : 0, fhp = fg ? v->s[5] : 0;  /* FOLD's DC blocker: the last fold, its output */
    pd_t b[4];                                               /* WAVE, WAVE2; (#41) at the last block's DCW */
    inc2 = pitch_inc(clamp(m->pitch16 + d16, 0, 2047));
    inc2 += (uint32_t)((int32_t)(inc2 >> 12) * (rem * 2367 / 16000));
    pd_bends(b, t, v, m);
    for (i = 0; i < n; i++) {
        uint32_t old = ph0;
        int32_t s;
        s = pd_wave(tg0 ? &b[1] : &b[0], ph0 >> 16, i);
        ph0 += inc;
        if (ph0 < old)
            tg0 ^= 1;
        if (line2) {
            uint32_t old2 = ph1;
            int32_t s2 = pd_wave(tg1 ? &b[1] : &b[0], ph1 >> 16, i);
            ph1 += inc2;
            if (ph1 < old2)
                tg1 ^= 1;
            s = ring ? mulq15(s, s2) : (s + s2) >> 1;     /* both within +-32767 */
        }
        if (fg) {   /* sin(pi/2 s gain): full scale x1 is a quarter turn; then a DC blocker (~14 Hz): folding a wave
                     * that sits off centre (PLS, RING, the RESO windows) moves its DC around */
            int32_t f = sine_i((uint32_t)(s * (int32_t)fg) << 7);
            fhp += f - fx1 - (fhp >> 9);
            fx1 = f;
            s = fhp;
        }
        if (sub) {
            ph2 += inc >> 1;
            s += mulq15(osc_sine(ph2), sub);
        }
        if (fg)     /* (the blocker's step of a full-scale swing, +-65534, and SUB's 25400 on it: s x amp would wrap
                     * 32 bits past 65538; FOLD 0 stays within 58167) */
            s = clamp(s, -65535, 65535);
        out[i] += voice_amp2(s, m, i);
    }
    v->ph[0] = ph0;
    v->ph[1] = ph1;
    v->ph[2] = ph2;
    v->s[0] = tg0;
    v->s[1] = tg1;
    if (fg) {
        v->s[4] = fx1;
        v->s[5] = fhp;
        v->s[6] = (int32_t)fg;
    }
}
static __attribute__((noinline)) void phase_render_f(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    phase_loop(t, v, out, n, m, pd_fold_gain((uint32_t)t->p[P_E7], m->inc));
}

/* FOLD going on or off (a knob, LFO / MOD, automation): FOLD 0 has no DC blocker (the sound as before 1.5.5) and the
 * fold's output has none of the wave's DC, so the switch would step (up to half full scale on PLS / RING). That block
 * is rendered both ways and crossfaded, unfolded -> folded or back (going off: at the last FOLD's gain); going on, the
 * blocker starts afresh as on a note-on (its state from the last FOLD long gone). Once per switch: not the loop's cost */
static int32_t pd_xa[CTL], pd_xb[CTL];
static __attribute__((noinline)) void phase_xfade(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m,
                                                  uint32_t on)
{
    uint32_t ph0 = v->ph[0], ph1 = v->ph[1], ph2 = v->ph[2], i;
    int32_t tg0 = v->s[0], tg1 = v->s[1], dw = v->s[7], k;
    if (n > CTL)
        n = CTL;
    for (i = 0; i < n; i++)
        pd_xa[i] = pd_xb[i] = 0;
    phase_loop(t, v, pd_xa, n, m, 0);                               /* unfolded; then from the same phases: */
    v->ph[0] = ph0;
    v->ph[1] = ph1;
    v->ph[2] = ph2;
    v->s[0] = tg0;
    v->s[1] = tg1;
    v->s[7] = dw;                                                   /* ((#41) and the same last DCW) */
    if (on) {
        v->s[4] = v->s[5] = 0;
        phase_render_f(t, v, pd_xb, n, m);
    } else {
        phase_loop(t, v, pd_xb, n, m, (uint32_t)v->s[6]);          /* (s[6]: set with the last folded block) */
        v->s[4] = PD_UNFOLDED;
    }
    for (i = 0; i < n; i++) {
        k = (int32_t)(on ? i + 1u : n - 1u - i);                    /* the folded one's share, of n */
        out[i] += pd_xa[i] + (pd_xb[i] - pd_xa[i]) * k / (int32_t)n;
    }
}

static void phase_render(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    if (t->p[P_E7] > 0) {
        if (v->s[4] == PD_UNFOLDED)
            phase_xfade(t, v, out, n, m, 1);
        else
            phase_render_f(t, v, out, n, m);
    } else if (v->s[4] != PD_UNFOLDED) {
        phase_xfade(t, v, out, n, m, 0);
    } else {
        phase_loop(t, v, out, n, m, 0);
    }
}

static const preset_t PHASE_PRESETS[] = {
    /* name, {WAVE, WAVE2, DCW, ENV, DTN, LINE, SUB, FOLD}, {A D S R}, fenv, mono */
    {"PD BRASS", {0, 0, 30, 90, 0, 0, 0, 0}, {8, 70, 90, 40}, 0, 0, FX(0, 20, 20, 40), TAG(PT_LEAD)},
    {"PD ORGAN", {3, 0, 40, 0, 0, 0, 0, 0}, {0, 127, 127, 30}, 0, 0, FX(0, 40, 0, 30), TAG(PT_KEYS)},
    {"PD STRINGS", {0, 4, 50, 40, 12, 0, 0, 0}, {40, 90, 100, 70}, 0, 0, FX(0, 50, 20, 60), TAG(PT_PAD)},
    {"RESO", {5, 0, 60, 60, 0, 0, 0, 0}, {0, 70, 30, 60}, 0, 0, FX(0, 0, 40, 40), TAG(PT_LEAD)},
    {"PD BELL", {6, 0, 80, 50, 0, 0, 0, 0}, {0, 95, 0, 90}, 0, 0, FX(0, 0, 30, 70), TAG(PT_KEYS)},
    {"WIRE", {4, 7, 70, 40, 7, 0, 0, 0}, {10, 80, 80, 60}, 0, 0, FX(15, 30, 30, 40), TAG(PT_LEAD)},
    /* (Skiff) for the themes: CRYPT (dungeon synth), NEON (synthwave), QUARK (particles) */
    {"NEUTRINO", {3, 0, 20, 70, 0, 0, 0, 0}, {0, 80, 0, 75}, 0, 0, FX(0, 10, 75, 55), TAG(PT_PLUCK)},
    /* (Skiff phase 9) more for every engine: basses, kits */
    {"PD BASS", {0, 0, 50, 80, 4, 0, 60, 0}, {0, 60, 60, 25}, 0, 1, FX(5, 0, 5, 10), TAG(PT_BASS)},
    {"SOFT KEYS", {3, 0, 30, 60, 6, 0, 0, 0}, {0, 85, 30, 60}, 0, 0, FX(0, 40, 20, 40), TAG(PT_KEYS)},
    {"PHASE BLADE", {5, 4, 49, 73, 7, 1, 14, 26}, {3, 56, 85, 34}, 0, 1, FX(0, 5, 19, 17),
        MORE({P_GLIDE, 16}), TAG(PT_LEAD)},
    {"PHASE TINES", {3, 7, 30, 55, 6, 0, 0, 0}, {1, 84, 25, 54}, 0, 0,
        FX(0, 18, 0, 27), TAG(PT_KEYS)},
    /* Sillage expansion bank. */
    {"CZ SUB WEIGH", {0, 0, 56, 45, 0, 0, 76, 0}, {0, 40, 100, 13}, 0, 1, FX(0, 0, 0, 0), TAG(PT_BASS)},
    {"CZ RUBBER PU", {1, 4, 39, 45, 9, 1, 67, 0}, {1, 72, 70, 22}, 0, 1, FX(0, 0, 0, 0), MORE({P_GLIDE, 16}), TAG(PT_BASS)},
    {"CZ SYNC BARK", {0, 7, 79, 45, 19, 0, 58, 28}, {0, 25, 48, 17}, 0, 1, FX(0, 0, 0, 0), TAG(PT_BASS)},
    {"CZ FRET ATTA", {4, 0, 46, 45, 4, 0, 49, 0}, {0, 55, 18, 15}, 0, 1, FX(0, 0, 0, 0), TAG(PT_BASS)},
    {"CZ HOLLOW ST", {5, 2, 68, 45, 24, 1, 40, 0}, {3, 62, 79, 19}, 0, 1, FX(0, 0, 0, 0), TAG(PT_BASS)},
    {"CZ LOW MOTOR", {2, 6, 30, 45, 7, 0, 31, 28}, {7, 46, 90, 26}, 0, 1, FX(0, 0, 0, 0), TAG(PT_BASS)},
    {"CZ ROUND DRI", {6, 3, 63, 45, 30, 0, 22, 0}, {0, 80, 58, 9}, 0, 1, FX(0, 0, 0, 0), TAG(PT_BASS)},
    {"CZ SOLO BRAS", {5, 0, 84, 25, 0, 0, 0, 0}, {5, 63, 100, 31}, 0, 1, FX(0, 0, 0, 0), TAG(PT_LEAD)},
    {"CZ GLIDE WIR", {1, 4, 67, 25, 9, 1, 0, 0}, {0, 48, 97, 21}, 0, 1, FX(0, 0, 0, 0), TAG(PT_LEAD)},
    {"CZ REED SOLO", {2, 7, 107, 25, 19, 0, 0, 28}, {19, 72, 105, 42}, 0, 1, FX(0, 0, 0, 0), MORE({P_LRATE, 43}, {P_LD_PIT, 4}), TAG(PT_LEAD)},
    {"CZ RING SOLO", {4, 0, 74, 25, 4, 0, 0, 0}, {2, 58, 85, 53}, 0, 1, FX(0, 0, 0, 0), TAG(PT_LEAD)},
    {"CZ NASAL CUT", {6, 2, 96, 25, 24, 1, 0, 0}, {1, 33, 116, 15}, 0, 1, FX(0, 0, 0, 0), TAG(PT_LEAD)},
    {"CZ AIR SOLO", {0, 6, 58, 25, 7, 0, 0, 28}, {24, 70, 95, 50}, 0, 1, FX(0, 0, 0, 0), MORE({P_LRATE, 43}, {P_LD_PIT, 4}), TAG(PT_LEAD)},
    {"CZ SLOW BRAS", {4, 0, 67, 12, 0, 0, 0, 0}, {44, 77, 108, 72}, 0, 0, FX(0, 9, 0, 7), TAG(PT_PAD)},
    {"CZ PWM VELVE", {0, 4, 50, 12, 9, 1, 0, 0}, {66, 85, 112, 88}, 0, 0, FX(0, 11, 0, 10), TAG(PT_PAD)},
    {"CZ DUSK CHOR", {1, 7, 90, 12, 19, 0, 0, 28}, {82, 96, 120, 102}, 0, 0, FX(0, 13, 0, 13), MORE({P_LRATE, 43}, {P_LD_PIT, 4}), TAG(PT_PAD)},
    {"CZ FROZEN AI", {2, 0, 57, 12, 4, 0, 0, 0}, {109, 80, 100, 108}, 0, 0, FX(0, 15, 0, 16), TAG(PT_PAD)},
    {"CZ WARM SWEL", {4, 2, 79, 12, 24, 1, 0, 0}, {53, 70, 88, 62}, 0, 0, FX(0, 17, 0, 19), TAG(PT_PAD)},
    {"CZ ORBIT BED", {0, 6, 41, 12, 7, 0, 0, 28}, {74, 96, 108, 90}, 0, 0, FX(0, 19, 0, 22), MORE({P_LRATE, 43}, {P_LD_PIT, 4}), TAG(PT_PAD)},
    {"CZ DRY TINES", {3, 0, 85, 22, 0, 0, 0, 0}, {0, 76, 36, 38}, 0, 0, FX(0, 0, 0, 0), TAG(PT_KEYS)},
    {"CZ STAGE REE", {2, 4, 68, 22, 9, 1, 0, 0}, {5, 86, 72, 49}, 0, 0, FX(0, 0, 0, 0), TAG(PT_KEYS)},
    {"CZ SOFT MALL", {1, 7, 108, 22, 19, 0, 0, 28}, {0, 63, 0, 35}, 0, 0, FX(0, 0, 0, 0), TAG(PT_KEYS)},
    {"CZ CHURCH KE", {4, 0, 75, 22, 4, 0, 0, 0}, {8, 90, 119, 52}, 0, 0, FX(0, 0, 0, 0), TAG(PT_KEYS)},
    {"CZ CLAVI SNA", {0, 2, 97, 22, 24, 1, 0, 0}, {0, 34, 22, 23}, 0, 0, FX(0, 0, 0, 0), TAG(PT_KEYS)},
    {"CZ GLASS ORG", {3, 6, 59, 22, 7, 0, 0, 28}, {0, 100, 105, 64}, 0, 0, FX(0, 0, 0, 0), TAG(PT_KEYS)},
    {"CZ WOOD PICK", {2, 0, 74, 45, 0, 0, 0, 0}, {0, 49, 0, 29}, 0, 0, FX(0, 0, 0, 0), TAG(PT_PLUCK)},
    {"CZ METAL PIN", {1, 4, 57, 45, 9, 1, 0, 0}, {0, 82, 0, 63}, 0, 0, FX(0, 0, 0, 0), TAG(PT_PLUCK)},
    {"CZ MUTE SNAP", {4, 7, 97, 45, 19, 0, 0, 28}, {0, 29, 0, 12}, 0, 0, FX(0, 0, 0, 0), TAG(PT_PLUCK)},
    {"CZ BELL PICK", {3, 0, 64, 45, 4, 0, 0, 0}, {2, 89, 0, 74}, 0, 0, FX(0, 0, 0, 0), TAG(PT_PLUCK)},
    {"CZ HOLLOW TA", {5, 2, 86, 45, 24, 1, 0, 0}, {0, 65, 8, 44}, 0, 0, FX(0, 0, 0, 0), TAG(PT_PLUCK)},
    {"CZ STRING TI", {0, 6, 48, 45, 7, 0, 0, 28}, {0, 40, 0, 23}, 0, 0, FX(0, 0, 0, 0), TAG(PT_PLUCK)},
    {"CZ DUST PLUC", {6, 3, 81, 45, 30, 0, 0, 0}, {4, 105, 0, 85}, 0, 0, FX(0, 0, 0, 0), TAG(PT_PLUCK)},
    {"CZ DUB ALARM", {5, 0, 48, 54, 0, 0, 0, 0}, {4, 74, 86, 42}, 0, 0, FX(0, 0, 0, 9), TAG(PT_FX)},
    {"CZ RADIO DRO", {6, 4, 31, 54, 9, 1, 0, 0}, {0, 48, 0, 29}, 0, 0, FX(3, 0, 6, 12), TAG(PT_FX)},
    {"CZ METAL CLO", {4, 7, 71, 54, 19, 0, 0, 28}, {68, 100, 90, 100}, 0, 0, FX(6, 0, 12, 15), TAG(PT_FX)},
    {"CZ AIR LIFT", {1, 0, 38, 54, 4, 0, 0, 0}, {105, 95, 98, 113}, 0, 0, FX(0, 0, 18, 18), TAG(PT_FX)},
    {"CZ PULSE ORB", {0, 2, 60, 54, 24, 1, 0, 0}, {8, 49, 54, 61}, 0, 0, FX(3, 0, 24, 21), TAG(PT_FX)},
    {"CZ DUST GATE", {2, 6, 22, 54, 7, 0, 0, 28}, {2, 40, 6, 38}, 0, 0, FX(6, 0, 30, 24), TAG(PT_FX)},
};

static const engine_t ENG_PHASE = {
    .name = "PHASE",
    .page_title = {"PHASE", "LINE"},
    .edit = {
        {"WAVE", N_PD_WAVE, 0, 7, 0, F_ENUM, 0},
        {"WAVE2", N_PD_WAVE2, 0, 8, 0, F_ENUM, 0},
        {"DCW", 0, 0, 127, 60, F_PCT, 0},
        {"ENV", 0, 0, 127, 64, F_PCT, 0},
        {"DETUNE", 0, 0, 127, 0, F_INT, U_CT},
        {"LINE", N_PD_LINE, 0, 1, 0, F_ENUM, 0},
        {"SUB", 0, 0, 127, 0, F_PCT, 0},
        {"FOLD", 0, 0, 127, 0, F_PCT, 0},       /* 1.5.5 (#104): 0 = off, the sound as before */
    },
    .presets = PHASE_PRESETS,
    .npresets = NELEM(PHASE_PRESETS),
    .note_on = phase_note_on,
    .render = phase_render,
    .keep = 0xB0,                /* FOLD's DC blocker (1.5.5), (#41) the last DCW: a retrigger does not restart them */
    .knob = {P_E2, P_E3, P_E4, P_REL},
};
