"""Sloop-type ports (no web build of their own): mkslp.py id 'Name' ver STEM [defines]"""
import shutil,os,re,subprocess,sys
idn,name,ver,stem=sys.argv[1:5]
src='ports/_dl/'+idn; dst='ports/'+idn
ig=shutil.ignore_patterns('*.wav','*.png','*.mp4','*.html','*.js','*.mjs','*.fwsc','__pycache__','*.woff*','*.key')
for d in ('firmware','tests','tools','build/gen','LICENSES'):
    if os.path.isdir(f'{src}/{d}'): shutil.copytree(f'{src}/{d}',f'{dst}/{d}',dirs_exist_ok=True,ignore=ig)
for f in os.listdir(src):
    if re.match(r'(LICEN|NOTICE|README\.md|CREDITS|THIRD)',f) and os.path.isfile(src+'/'+f): shutil.copy(src+'/'+f,dst)
os.makedirs(dst+'/web/emu',exist_ok=True); os.makedirs(dst+'/build/gen',exist_ok=True)
open(dst+'/.gitignore','w').write('build/\n__pycache__/\n*.o\n')
g=lambda *a:subprocess.run(['git','-C',src,*a],capture_output=True,text=True).stdout.strip()
url=g('remote','get-url','origin')
open(dst+'/SOURCE_COMMIT.txt','w').write(f'{url} {g("log","-1","--format=%H %ci")} ({ver})\n')
t=open('target/clip.c').read()
t=re.sub(r'CLIPPER \(isod89/clipper-fm1, 1\.3\.1, a SLOOP fork\)',f'{name} ({url}, {ver}, a SLOOP fork)',t)
h=open(f'{src}/tests/hostsim.c').read()+''.join(open(f'{src}/firmware/src/{f}').read() for f in ('felucca.c','main.c'))
incs=re.findall(r'^\s*#include "([^"]+)"',open(f'{src}/firmware/src/felucca.c').read(),re.M)
a=incs.index('panel.c'); b=next((i for i,x in enumerate(incs) if x.startswith('fm1_flash')),incs.index('storage.c') if 'storage.c' in incs else len(incs))
ui=[x for x in incs[a:b] if x.endswith('.c') and x not in ('storage.c','upreset.c','project.c')]
i=t.index('#include "../../firmware/src/panel.c"'); j=t.index('/* ------------------------------------------------------------ the flash')
t=t[:i]+''.join(f'#include "../../firmware/src/{x}"\n' for x in ui)+'\n'+t[j:]
if not os.path.exists(f'{src}/firmware/hal/fm1_flash_id.h'): t=re.sub(r'#include "../../firmware/hal/fm1_flash_id.h"[^\n]*','#define FL_JEDEC_OK(id) 1',t)
open(dst+'/web/emu/felucca_teensy.c','w').write(t)
open(dst+'/PORT.txt','w').write(f'name {name}\nversion {ver}\nstem {stem}\nincludes build/gen firmware/src firmware/hal tests\nextra \ndefines {" ".join(sys.argv[5:])}\nitcm_banks 10\nnor 0x100000\n')
s=open('ports/sloop/firmware/src/felucca.c').read(); si=re.findall(r'^\s*#include "([^"]+)"',s,re.M)
print(idn,'extra incs',[i for i in incs if i not in si],'missing',[i for i in si if i not in incs])
subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'addmidi.py'), idn])  # MIDI hooks (docs/MIDI.md)
