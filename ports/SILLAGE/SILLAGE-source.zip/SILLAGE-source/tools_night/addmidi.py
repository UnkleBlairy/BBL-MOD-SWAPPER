#!/usr/bin/env python3
"""addmidi.py port... : give a port the MIDI hooks (docs/MIDI.md) in its web/emu/felucca_teensy.c.

Tries the Felucca block (midi_enqueue), then the Sloop block (writes midi_in_q directly); keeps the first that
compiles (a syntax check of the port's unit with its PORT.txt includes and defines). Prints one line per port:
  ENQ / RING  = added,  HAS = already there,  LOOK = neither compiles (left untouched; needs a hand look).
Run it after any generator (mkfel.py, mkslp.py, ...) has made a port.
"""
import os, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MARK = "/* ---------------------------------------------------------------- MIDI (teensy-fm1) --- */"
HEAD = MARK + """
/* The runtime (src/main.rs) hands in whole messages from the FM-1's TRS jack and the Teensy's USB MIDI port, and takes
 * the firmware's MIDI out for USB. usb.config stands in for "a USB MIDI host is there", as on the FM-1 itself.
 * (added by tools_night/addmidi.py, docs/MIDI.md) */
"""
OUT = """EXPORT void teensy_midi_link(uint32_t on) { usb.config = on ? 1u : 0u; }
EXPORT uint32_t teensy_midi_out(uint32_t *out, uint32_t cap)
{
    uint32_t n = 0;
    while (n < cap && mo_r != mo_w) {
        out[n++] = midi_out_q[mo_r % MQ];
        mo_r++;
    }
    return n;
}
"""
ENQ = HEAD + """EXPORT void teensy_midi_in(uint32_t st, uint32_t d1, uint32_t d2, uint32_t source)
{
    if (st >= 0xF8u) {
        if (st == 0xF8u || st == 0xFAu || st == 0xFBu || st == 0xFCu)
            (void)midi_enqueue(0xFu | st << 8, source);
        return;
    }
    if (st < 0x80u || st >= 0xF0u)
        return;
    (void)midi_enqueue((st >> 4) | st << 8 | (d1 & 127u) << 16 | (d2 & 127u) << 24, source);
}
""" + OUT
RING = HEAD + """EXPORT void teensy_midi_in(uint32_t st, uint32_t d1, uint32_t d2, uint32_t source)
{
    (void)source;
    if (st >= 0xF8u ? !(st == 0xF8u || st == 0xFAu || st == 0xFBu || st == 0xFCu) : (st < 0x80u || st >= 0xF0u))
        return;
    if (mi_w - mi_r >= MQ)                          /* as usb.c's midi_in_event, without its SysEx side */
        return;
    midi_in_q[mi_w % MQ] = (st >= 0xF8u ? 0x0Fu : st >> 4) | st << 8 | (d1 & 127u) << 16 | (d2 & 127u) << 24;
    RING_PUBLISH();
    mi_w++;
}
""" + OUT


def port_txt(p):
    d = {}
    for l in open(os.path.join(ROOT, "ports", p, "PORT.txt")):
        k, _, v = l.rstrip("\n").partition(" ")
        d[k] = v.strip()
    return d


def compiles(p, f):
    t = port_txt(p)
    cmd = ["arm-none-eabi-gcc", "-fsyntax-only", "-mcpu=cortex-m7", "-mthumb", "-mfloat-abi=hard", "-mfpu=fpv5-d16",
           "-std=gnu99", "-w", "-Werror=implicit-function-declaration", '-DFELUCCA_VERSION="x"']
    nor = t.get("nor", "0")
    if nor and int(nor, 16 if nor.startswith("0x") else 10):
        cmd.append("-DTEENSY_NOR_ADDR=%su" % nor)
    for i in t.get("includes", "").split():
        cmd += ["-I", os.path.join(ROOT, "ports", p, i)]
    for d in t.get("defines", "").split():
        cmd.append("-D" + d)
    r = subprocess.run(cmd + [f], capture_output=True, text=True)
    return r.returncode == 0, r.stderr


def add(p):
    f = os.path.join(ROOT, "ports", p, "web/emu/felucca_teensy.c")
    src = open(f).read()
    if "teensy_midi_in" in src:
        return "HAS"
    ok, err = compiles(p, f)
    if not ok:
        return "LOOK (does not compile as it is: %s)" % err.strip().splitlines()[0][:120]
    for name, block in (("ENQ", ENQ), ("RING", RING)):
        open(f, "w").write(src.rstrip("\n") + "\n\n" + block)
        if compiles(p, f)[0]:
            return name
    open(f, "w").write(src)
    return "LOOK"


if __name__ == "__main__":
    for p in sys.argv[1:]:
        print(p, add(p), flush=True)
