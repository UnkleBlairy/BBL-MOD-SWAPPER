# MIDI on the BBL Mod Swapper

Since 2026-11-28 (release 1.2) every firmware can have MIDI, both ways:

- **USB:** the Teensy's own USB port is a USB MIDI device ("BBL Mod Swapper (<firmware name>)") next to its serial port
  (src/midi.rs). Notes, CCs, clock and transport in; the firmware's MIDI out back to the computer.
- **TRS:** the FM-1's jack is MIDI IN. The FM-1 terminal reads it (UART1) and forwards the raw bytes in 'M' packets
  (LINK_PROTOCOL.md); the Teensy parses them (running status, realtime anywhere, SysEx dropped).

## The three hooks a port exports (web/emu/felucca_teensy.c)

| function | what the runtime does with it |
| --- | --- |
| `void teensy_midi_in(uint32_t status, uint32_t d1, uint32_t d2, uint32_t source)` | one whole message (channel voice, or F8 FA FB FC with d1 = d2 = 0); source 1 = USB, 2 = TRS |
| `void teensy_midi_link(uint32_t on)` | called every pass: 1 while a computer has the USB port configured |
| `uint32_t teensy_midi_out(uint32_t *out, uint32_t cap)` | up to cap USB-MIDI event packets (cin \| status << 8 \| d1 << 16 \| d2 << 24), oldest first; returns how many |

A port without them still links: src/midi_weak.c has empty weak versions. Nothing is called while the menu is up.

### A Felucca fork (Jam Box, JIANT, Felucca): its usb.c has the rings

```c
EXPORT void teensy_midi_in(uint32_t st, uint32_t d1, uint32_t d2, uint32_t source)
{
    if (st >= 0xF8u) {
        if (st == 0xF8u || st == 0xFAu || st == 0xFBu || st == 0xFCu)
            (void)midi_enqueue(0xFu | st << 8, source);
        return;
    }
    if (st < 0x80u || st >= 0xF0u)
        return;
    (void)midi_enqueue((st >> 4) | st << 8 | (d1 & 127u) << 16 | (d2 & 127u) << 24, source);
}
EXPORT void teensy_midi_link(uint32_t on) { usb.config = on ? 1u : 0u; }   /* midi_out_event checks it */
EXPORT uint32_t teensy_midi_out(uint32_t *out, uint32_t cap)
{
    uint32_t n = 0;
    while (n < cap && mo_r != mo_w) {
        out[n++] = midi_out_q[mo_r % MQ];
        mo_r++;
    }
    return n;
}
```

No `midi_enqueue` (older forks, e.g. Sloop): write into `midi_in_q` / `mi_w` directly, as ports/sloop does. Don't call
`midi_in_event`: it pulls in the SysEx editor code (6 KB) and may not fit slot 3.

### Its own MIDI queues (X0X)

Feed its input queue and tap its MIDI out function: ports/x0x adds `X0X_MIDI_PUT` in host/x0x_host.c's
`plat_midi_out` and drains that ring in `teensy_midi_out`.

## Testing

- Plug the Teensy into a computer: the MIDI device appears. Send notes and clock (e.g. from a DAW), play the keys and
  check that MIDI comes back.
- TRS: a MIDI cable (TRS type A, as the FM-1's) into the FM-1's jack; set the firmware to follow TRS clock if it has
  that choice.
- From a PC with Python: `pip install mido python-rtmidi`, then open the "BBL Mod Swapper" port. Close the port before
  quitting (an open rtmidi port can hang the script on Windows).
