/* SPDX-License-Identifier: GPL-3.0-only
 * BLE MIDI: 2026 DEADACTIVE
 * FM-Link: 2026 DEADACTIVE */
/* ORBIT: ported from Hortator 4e40f27 by DEADACTIVE, felucca-ble ble-kit. */
/* The device role's data (ble_central.c, ROLE DEVICE: a host connects to the FM-1): the GATT table att_server_init
 * reads, in the JieLi SDK's format (apps/common/ble/include/le_trans_data.h: per attribute its size, flags, handle,
 * UUID (16 or 128 bits) and value, little endian, the table ended by 0x0000; flags = the properties | 0x0100
 * DYNAMIC (read / written through the callbacks) | 0x0200 a 128-bit UUID; 128-bit UUIDs stored least significant
 * byte first), the advertising data and the scan response. Pure data: tests/ble/ble_gatt_test.c walks it.
 *   0x0001 the GAP service 1800, 0x0002 / 0x0003 its device name (2A00, READ, DYNAMIC: "ORBIT FM-1")
 *   0x0004 the BLE-MIDI service 03B80E5A-EDE8-4B33-A751-6CE34EC4C700 (MMA BLE-MIDI 1.0)
 *   0x0005 / 0x0006 the BLE-MIDI characteristic 7772E5DB-3868-4112-A1A9-F2669D106BF3: READ (empty), WRITE WITHOUT
 *          RESPONSE (MIDI from the host), NOTIFY (MIDI to it); 0x0007 its CCCD.
 * ORBIT exposes no FM-Link attributes. The legacy constants below are retained
 * for the shared upstream state-machine code, not as advertised services. */
#include <stdint.h>
#define BLE_GATT_NAME 0x0003u
#define BLE_GATT_MIDI 0x0006u
#define BLE_GATT_MIDI_CCC 0x0007u
#define BLE_GATT_FML 0x000Au
#define BLE_GATT_FML_CCC 0x000Bu
static const char BLE_GATT_NAME_STR[] = "ORBIT FM-1";
#define BLE_MIDI_SVC_LE 0x00, 0xC7, 0xC4, 0x4E, 0xE3, 0x6C, 0x51, 0xA7, 0x33, 0x4B, 0xE8, 0xED, 0x5A, 0x0E, 0xB8, 0x03
#define BLE_MIDI_CHR_LE 0xF3, 0x6B, 0x10, 0x9D, 0x66, 0xF2, 0xA9, 0xA1, 0x12, 0x41, 0x68, 0x38, 0xDB, 0xE5, 0x72, 0x77
#define BLE_FML_SVC_LE 0x0C, 0x9B, 0x7A, 0x5D, 0x3E, 0x1F, 0x2D, 0x9C, 0x5B, 0x4A, 0x4C, 0x6E, 0x00, 0x00, 0x11, 0xF3
#define BLE_FML_CHR_LE 0x0C, 0x9B, 0x7A, 0x5D, 0x3E, 0x1F, 0x2D, 0x9C, 0x5B, 0x4A, 0x4C, 0x6E, 0x01, 0x00, 0x11, 0xF3
static const uint8_t BLE_GATT_DB[] = {
    /* 0x0001 PRIMARY_SERVICE 1800 */
    0x0a, 0x00, 0x02, 0x00, 0x01, 0x00, 0x00, 0x28, 0x00, 0x18,
    /* 0x0002 CHARACTERISTIC 2a00 READ | DYNAMIC; 0x0003 its value */
    0x0d, 0x00, 0x02, 0x00, 0x02, 0x00, 0x03, 0x28, 0x02, 0x03, 0x00, 0x00, 0x2a,
    0x08, 0x00, 0x02, 0x01, 0x03, 0x00, 0x00, 0x2a,
    /* 0x0004 PRIMARY_SERVICE BLE-MIDI */
    0x18, 0x00, 0x02, 0x00, 0x04, 0x00, 0x00, 0x28, BLE_MIDI_SVC_LE,
    /* 0x0005 CHARACTERISTIC BLE-MIDI READ | WRITE_WITHOUT_RESPONSE | NOTIFY, its value at 0x0006 */
    0x1b, 0x00, 0x02, 0x00, 0x05, 0x00, 0x03, 0x28, 0x16, 0x06, 0x00, BLE_MIDI_CHR_LE,
    /* 0x0006 its value: those properties, DYNAMIC, a 128-bit UUID */
    0x16, 0x00, 0x16, 0x03, 0x06, 0x00, BLE_MIDI_CHR_LE,
    /* 0x0007 CLIENT_CHARACTERISTIC_CONFIGURATION */
    0x0a, 0x00, 0x0a, 0x01, 0x07, 0x00, 0x02, 0x29, 0x00, 0x00,
    0x00, 0x00,
};
/* the advertising data (flags: LE general discoverable, no BR/EDR; the complete list of 128-bit services) and the scan
 * response (the complete local name). In RAM: the stack keeps the pointers (ble_api.h: a global buffer) */
static uint8_t BLE_ADV_DATA[21] = {0x02, 0x01, 0x06, 0x11, 0x07, BLE_MIDI_SVC_LE};
static uint8_t BLE_RSP_DATA[12] = {0x0b, 0x09, 'O', 'R', 'B', 'I', 'T', ' ', 'F', 'M', '-', '1'};
