/* SPDX-License-Identifier: GPL-3.0-only
 * BLE MIDI test: 2026 DEADACTIVE
 * Drum machine fork: 2026 DEADACTIVE */
/* ORBIT: ported from Hortator 4e40f27 by DEADACTIVE, felucca-ble ble-kit. */
/* Separate BLE compilation unit (tools/build.py, ORBIT_BLE=1). No core-side
 * wiring lives here: ble_api.h binds the platform and exposes the MIDI queues.
 * The default build does not compile or link any BLE object. */
#include <stdint.h>
#include "fm1_time.h"
#include "fm1_ble_hal.h"
#include "ble/ble_core.h"
#include "ble/ble_sdk_abi.h"
#include "ble/ble_sdk.h"
#include "ble/a2dp.h"
#include "ble/ble_platform.c"
uint32_t ble_os_now_ms(void) { return core_ms(); }
#define BLE_DIAG_MAGIC 0xB1E0D1A6u
static struct {
    uint32_t magic, stage, task, starts, trim, delays, last_us, t4_stalls, irq_leaks, fatal;
    uint32_t heap_high, alloc_fails, irq_lowered;
    uint32_t assert_ra, assert_ra2;                /* the library assert's callers (cpu_assert_debug), for the map */
} ble_diag __attribute__((section(".noinit"), unused));
static __attribute__((unused)) void ble_stage(uint32_t s)
{
    if (ble_diag.magic != BLE_DIAG_MAGIC) {
        ble_diag.magic = BLE_DIAG_MAGIC;
        ble_diag.starts = 0;
    }
    if (s == 1u) {
        ble_diag.starts++;
        ble_diag.trim = ble_diag.delays = ble_diag.last_us = ble_diag.t4_stalls = ble_diag.irq_leaks = ble_diag.fatal = 0;
        ble_diag.heap_high = ble_diag.alloc_fails = ble_diag.irq_lowered = 0;
    }
    ble_diag.stage = s;
}
#include "ble/ble_os.c"
#include "ble/ble_midi.c"
#include "ble/ble_scan.c"
#include "ble/ble_vm.c"
#include "ble/ble_port.c"
/* Bluetooth heap in POOL. The former BLE-only 23552-byte heap grows for
 * classic pairing and a concurrent MIDI link. This is a static reservation;
 * its high-water mark under A2DP radio load still needs device measurement. */
#define BLE_HEAP_BYTES 32768u                       /* Classic link/SSP headroom; hardware high-water unmeasured. */
static uint8_t ble_heap[BLE_HEAP_BYTES] __attribute__((section(".pool.bt")));   /* (app_ble.ld: by bd_base) */
static uint8_t ble_on;
int ble_started(void) { return ble_on; }
/* how far the last run got, kept over a crash reboot (.noinit) for the console's `ble`: stage 1 OS ready, 2 stack
 * window, 3 MAC set, 4 in btstack_init, 5 btstack_init returned, 6 profile init, 7 BT_STATUS_INIT_OK; trim = 1 in
 * the radio calibration, 2 after it (ble_port.c's RAM hooks); task = the BT task running (+1), 0 = the core;
 * delays / last_us = delay_us calls and the last one's length; t4_stalls = delays during which TIMER4 did not move;
 * irq_leaks = times a BT task handed back with interrupts still off (ble_port.c re-enables them); fatal = 1 a
 * library assert, 2 a library reset request, 3 a task's stack overflow (`task` names it) (ble_port.c ble_fatal);
 * heap_high / alloc_fails = the heap's most in use and its refused requests; irq_lowered = BT IRQ requests above
 * priority 2, attached at 2 (ble_port.c request_irq) */

#include "ble/ble_gatt.c"                      /* the device role's GATT table and advertising data */
#include "ble/ble_central.c"
void ble_service(void)                             /* the main loop (ed_service): a 5 ms slice for the BT tasks */
{
    static uint8_t kept;
    if (!ble_bound)
        return;
#if BLE_CONSOLE
    ble_loop_note(&loop, core_ui_frames(), core_ms());   /* BT off too: the period to compare with */
#endif
    if (!kept) {                                  /* once a power-on, BT off too: the radio calibration found in flash
                                                   * handed to the firmware to keep (core_rf_keep_put) before its own
                                                   * data can cover the store; a flash scan, no Bluetooth started */
        kept = 1;
        (void)ble_rf_trim_load();
    }
    if (!ble_on)
        return;
    ble_os_service(a2dp_streaming() ? 8000u : 5000u);   /* (a phone's stream: longer turns, measured on the FM-1) */
#if BLE_CONSOLE
    ble_diag.heap_high = ble_os_heap_high();       /* (.noinit: kept over a crash reboot, for the heap's size) */
    ble_diag.alloc_fails = ble_os_alloc_fails();
#endif
    ble_tick();                                    /* the start's deadline */
    ble_auto();                                    /* Device advertising/disconnect and stale input cleanup. */
    a2dp_enable(want);
    ble_out_flush();                               /* MIDI out as BLE-MIDI notifications. */
    /* Input stays queued until the core drains ble_midi_take(). */
}

void ble_user_stop(void)
{
    want = 0;
    mo.t = mo.h;
    ring_t = ring_h;
}
ble_status_t ble_get_status(void)
{
    if (st == BLE_FAILED)
        return BLE_STATUS_FAILED;
    if (!want)
        return con_handle || st == BLE_ADVERTISING ? BLE_STATUS_STOPPING : BLE_STATUS_OFF;
    if (ble_linked())
        return BLE_STATUS_CONNECTED;
    return st == BLE_ADVERTISING ? BLE_STATUS_ADVERTISING : BLE_STATUS_STARTING;
}
const char *ble_last_error(uint32_t *code) { return ble_err(code); }
void ble_midi_out_pkt(uint32_t pkt)
{
    uint8_t m[3] = {(uint8_t)(pkt >> 8), (uint8_t)(pkt >> 16), (uint8_t)(pkt >> 24)};
    uint32_t cin = pkt & 15u, n;
    if (!want || (cin < 8u && cin != 2u && cin != 3u && !(cin == 5u && m[0] == 0xF6u)))
        return;
    n = cin == 2u || cin == 0xCu || cin == 0xDu ? 2u : cin == 5u || cin == 0xFu ? 1u : 3u;
    (void)ble_midi_send(m, n);
}
uint32_t ble_midi_rx_drops(void) { return ring_lost; }
uint32_t ble_midi_tx_drops(void) { return mo.drops; }
