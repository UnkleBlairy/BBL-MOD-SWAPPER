#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
# Host tests (no hardware). Run from the repo root after ./build.sh:
#   tests/run_tests.sh
#
# Regression suite (tests/regress.c, tests/target_budget.py; details at the top of regress.c):
#   golden renders  every engine x preset, the drum kit, voice modes, FX sends, a 4-track mix: one hash
#                   each in tests/golden.txt. A change of the sound fails with the list of renders.
#   health          clipping, DC, peak level, voices free after the release, silence at the end.
#   CPU             cost / sample per preset and mix, relative to the idle + drums mix (tests/cpu_baseline.txt,
#                   +25 %; counted by the kernel or under callgrind, else timed at +35 %), ns printed;
#                   target: loop instructions of the render functions in build/felucca.dis
#                   (tests/target_budget.txt, +10 %; exact, static).
#   voices          the budget of 8, steal fades, MONO / LEGATO / UNISON keep their note, the VOICE cap,
#                   no hanging notes on any MIDI / key routing.
# FM6 (tests/fm6_test.c): the 6-operator FM engine (firmware/src/eng_fm6.c, fm6_core.c, fm6_bank.c): the 32
#                   algorithms' carriers, the operator envelopes ending the voice, retrigger, DC / clipping, the
#                   eight macros, the patch formats (packed, SysEx), the 6-voice cap, the patch bank on a
#                   simulated NOR; demos in build/fm6_demo/.
# After an intended change of the sound: GOLDEN_UPDATE=1 sh tests/run_tests.sh, review the diff
# of tests/golden.txt, commit it with the change. After an intended change of the cost (or a new
# compiler): BUDGET_UPDATE=1 (rewrites cpu_baseline.txt and target_budget.txt). VERBOSE=1: every render.
set -e
export AC79_SDK="${AC79_SDK:-$HOME/fw-AC79_AIoT_SDK}"
cd "$(dirname "$0")/.."
OUT=build/host
mkdir -p "$OUT"
CC="${CC:-cc} -O1 -Wall -Wno-unused-function"
fail=0
run() { echo "== $1"; shift; "$@" || fail=1; }

[ -f build/orbit.fwsc ] || { echo "run sh build.sh first"; exit 1; }
# the generated headers the FM6 engine needs (tools/build.py generate() makes them too; no Pillow needed)
mkdir -p build/gen
[ build/gen/felucca_tables.h -nt tools/gen_tables.py ] || python3 tools/gen_tables.py build/gen/felucca_tables.h
[ build/gen/felucca_fm6.h -nt tools/gen_fm6_patches.py ] || python3 tools/gen_fm6_patches.py build/gen/felucca_fm6.h
python3 tools/gen_op1_cluster.py build/gen/felucca_op1_cluster.h

$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/cluster_test" tests/cluster_test.c -lm
run "official cluster: raw presets, kernel cadence, release and shared arena" "$OUT/cluster_test"
$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/cloud_test" tests/cloud_test.c -lm
run "CLOUD: oscillator grains, presets, extrema, release and arena ownership" "$OUT/cloud_test"
$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/sample_replacement_test" tests/sample_replacement_test.c -lm
run "synthesized sample replacements: preserved IDs/data and audible banks" "$OUT/sample_replacement_test"
$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/chop_attack_test" tests/chop_attack_test.c -lm
run "chop attack (2.8.3): a sample retriggered fades out and restarts from silence, fading voices count in the budget" "$OUT/chop_attack_test"
$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/editor_wide_test" tests/editor_wide_test.c -lm
run "editor WIDE: signed16 round trips and legacy frames" "$OUT/editor_wide_test"

$CC -o "$OUT/storage_test" tests/storage_test.c
run "flash storage (A/B, torn writes)" "$OUT/storage_test"

$CC -o "$OUT/recovery_test" tests/recovery_test.c
run "application USB recovery and boot-loop guard" "$OUT/recovery_test"

$CC -o "$OUT/arranger_test" tests/arranger_test.c
run "song order, timing, repeats and missing scenes" "$OUT/arranger_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/song_audio_test" tests/song_audio_test.c -lm
run "song: four simultaneous tracks, scene transition and stop" "$OUT/song_audio_test" "$OUT/song-demo.wav"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/song_ui_test" tests/song_ui_test.c -lm
run "song screen: commands, load (OCT+ twice), display bounds" "$OUT/song_ui_test" "$OUT/song-screen.ppm"

$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/studio_drums_test" tests/studio_drums_test.c -lm
run "drum lanes, kit audio, metronome, record arm, free take" "$OUT/studio_drums_test" "$OUT/drum-styles.wav"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/seq2_test" tests/seq2_test.c -lm
run "sequencer 2.0: no drift, ratchets, roll, erase / undo, ghost / hard, chords, mute / solo, nudge, locks" "$OUT/seq2_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/hold_rec_test" tests/hold_rec_test.c -lm
run "POLY live recording and MIDI overflow recovery" "$OUT/hold_rec_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/midi_clock_test" tests/midi_clock_test.c -lm
run "external MIDI clock average and immediate tempo jumps" "$OUT/midi_clock_test"

$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/drumkit_test" tests/drumkit_test.c -lm
run "synthesised drum kits: every kit x sound bounded, audible, finite, levels, cost" "$OUT/drumkit_test" "$OUT/drum-kits.wav" "$OUT/drum-kits.txt"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/userkit_test" tests/userkit_test.c -lm
run "user drum kits (KIT USR1..USR3): a user slot's sounds on the drum lanes" "$OUT/userkit_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/dsyn_test" tests/dsyn_test.c -lm
run "SYN1..SYN4 drum kits and editor protocol v10" "$OUT/dsyn_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/drum_steal_test" tests/drum_steal_test.c -lm
run "drum voice steal (2.8.3): free first, a sound's own voice, the oldest but a kick" "$OUT/drum_steal_test"
$CC -O2 -w -DARENA_STATS -Ibuild/gen -Ifirmware/src -o "$OUT/arena_test" tests/arena_test.c -lm
run "shared engine arena: clean takeover, ownership and random transitions" "$OUT/arena_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/punch_test" tests/punch_test.c -lm
run "punch-in FX: 27 effects, bounded, dry after release, FX-held keys, FREEZE, THROW, drum mutes" "$OUT/punch_test" "$OUT/punch-fx.wav"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/insert_test" tests/insert_test.c -lm
run "2.6 sound: INSERT, ANALOG TYPE, mutes, TEXTURE, limiter, THROW, clicks, boundary matrix" "$OUT/insert_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/track_filter_test" tests/track_filter_test.c -lm
run "track FILTER: resonance, band-pass response, bypass transitions and default compatibility" "$OUT/track_filter_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/delay_type_test" tests/delay_type_test.c -lm
run "delay TYPE (0.8.2): MONO, WIDE, PING-PONG, the line cleared on a change" "$OUT/delay_type_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/modulation_test" tests/modulation_test.c -lm
run "2.6 modulation: ENV SYNC, LFO 2 SYNC / TRIG / POL, bend, learn, tempo matrix" "$OUT/modulation_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/midi_learn_test" tests/midi_learn_test.c -lm
run "MIDI settings: learn, channels, IN = CH n, persistence, backup object 10" "$OUT/midi_learn_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/ctrl_test" tests/ctrl_test.c -lm
run "MIDI CONTROLLER mode: combo, keys, knobs, switches, sequencer, exit, settings" "$OUT/ctrl_test"
$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/macro_test" tests/macro_test.c -lm
run "sound macros: MACROS assignment, PERFORM values, presets, projects and backup persistence" "$OUT/macro_test"

$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/ui_pages_test" tests/ui_pages_test.c -lm
run "live UI: pages, layers (punch, steps, erase, roll, key, mix), holds, drums, REC, fuzz" "$OUT/ui_pages_test" "$OUT"
# SLOOP 2.8.4 fixes (ORBIT 0.9.0)
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/knob_walk_test" tests/knob_walk_test.c -lm
run "REC READY and pages: each knob edits one value" "$OUT/knob_walk_test" "$OUT"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/song_arm_test" tests/song_arm_test.c -lm
run "song screen: confirmations ask again after a long elapsed time" "$OUT/song_arm_test"
$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/unison_level_test" tests/unison_level_test.c -lm
run "UNISON: all engines, DETUNE 0 and SAMPLE pending restart" "$OUT/unison_level_test"
$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/phys_tune_test" tests/phys_tune_test.c -lm
run "PHYS string tuning: pitched presets within tolerance" "$OUT/phys_tune_test"
$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/noise_clock_test" tests/noise_clock_test.c -lm
run "NOISE LFSR clock follows high keys; colour poles bounded" "$OUT/noise_clock_test"
$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/sample_pitch_test" tests/sample_pitch_test.c -lm
run "SAMPLE / GRAIN high-note pitch follows the keys" "$OUT/sample_pitch_test"
$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/grain_release_test" tests/grain_release_test.c -lm
run "GRAIN held note is not starved by released notes" "$OUT/grain_release_test"
$CC -O2 -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/fade_noise_test" tests/fade_noise_test.c -lm
run "rounded mix: clean fades on the DAC and USB FULL" "$OUT/fade_noise_test"
run "editor protocol, external inputs, reproducers and boot sounds under ASan + UBSan" \
    env EDFZ_OUT="$OUT/edfz" sh tests/editor_fuzz.sh "${EDFZ_N:-2000}" 1
# Bluetooth build (ORBIT_BLE, orbit-ble.fwsc): its sample header without the melodic sets, the BLE unit, the bridge
$CC -O2 -o "$OUT/a2dp_pcm_test" tests/a2dp_pcm_test.c
run "A2DP PCM: resampling, stereo mix, ring bounds, underrun and drift" "$OUT/a2dp_pcm_test"
mkdir -p build/gen_ble
ORBIT_BLE=1 python3 tools/gen_samples.py build/gen_ble/felucca_samples.h > /dev/null
$CC -O2 -w -DORBIT_BLE=1 -Ibuild/gen_ble -Ibuild/gen -Ifirmware/src -Ifirmware/hal \
    -o "$OUT/ble_samples_test" tests/ble_samples_test.c -lm
run "BLE build: FM stand-ins for the melodic sets, PERC and USR samples kept, GRAIN" "$OUT/ble_samples_test"
$CC -O2 -w -DORBIT_BLE=1 -Ibuild/gen_ble -Ibuild/gen -Ifirmware/src -Ifirmware/hal \
    -o "$OUT/ble_bridge_test" tests/ble_bridge_test.c -lm
run "BLE MIDI bridge: controller, ISR queue, overflow, input and disconnect" "$OUT/ble_bridge_test"
for name in midi scan os vm gatt central; do
    $CC -O2 -w -Ifirmware/src -Ifirmware/hal "tests/ble/ble_${name}_test.c" -o "$OUT/ble_${name}_test"
    run "BLE unit: $name" "$OUT/ble_${name}_test"
done
$CC -O2 -w -Ifirmware/src -Ifirmware/hal -o "$OUT/ble_rf_test" tests/ble_rf_test.c
run "BLE RF trim: stock first, kept copy, recovery defaults saved in OBJ_BLE" "$OUT/ble_rf_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/pick_test" tests/pick_test.c -lm
run "SMK-37 pad sound picker: pages by kind, pads load, < >, drum kits" "$OUT/pick_test" "$OUT"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/fbank_test" tests/fbank_test.c -lm
run "SMK-37 FADER BANK screen: banks wrap, LEVEL / PAN / REVERB / DELAY, fader to value" "$OUT/fbank_test" "$OUT"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/k4led_test" tests/k4led_test.c -lm
run "SMK-37: KNOB BANK opens / closes the pad picker; which modes are a grid" "$OUT/k4led_test" "$OUT"
$CC -O2 -w -Ifirmware/hal -o "$OUT/padgrid_test" tests/padgrid_test.c
run "SMK-37 Pro pads: steps and tiles in reading order, notes low at the bottom" "$OUT/padgrid_test"
$CC -o "$OUT/smk_wheel_test" tests/smk_wheel_test.c
run "SMK-37 Pro pitch wheel: the bend is back to 0 at rest, however slowly the wheel was moved" "$OUT/smk_wheel_test"
# no divide by 0 (the FM-1 runs with the div0 trap off, hal/fm1_irq.h: a real one would give a wrong value
# silently): the UI fuzz, the sequencer, the projects and a minute of random live use, with UBSan
UBSAN="${CC_UB:-cc} -O1 -w -fsanitize=integer-divide-by-zero -fno-sanitize-recover=integer-divide-by-zero -Ibuild/gen -Ifirmware/src -Ifirmware/hal"
$UBSAN -o "$OUT/ui_pages_ub" tests/ui_pages_test.c -lm && $UBSAN -o "$OUT/seq2_ub" tests/seq2_test.c -lm &&
    $UBSAN -o "$OUT/project_ub" tests/project_test.c -lm && $UBSAN -o "$OUT/soak_ub" tests/soak_test.c -lm &&
    $UBSAN -o "$OUT/insert_ub" tests/insert_test.c -lm && $UBSAN -o "$OUT/modulation_ub" tests/modulation_test.c -lm &&
    $UBSAN -o "$OUT/midi_learn_ub" tests/midi_learn_test.c -lm && $UBSAN -o "$OUT/punch_ub" tests/punch_test.c -lm &&
    $UBSAN -o "$OUT/editor_wide_ub" tests/editor_wide_test.c -lm || fail=1
mkdir -p "$OUT/ub"
run "no divide by zero (UBSan): UI fuzz, sequencer, projects, 2.6 sound / modulation / MIDI boundaries, live use" \
    sh -c "'$OUT/ui_pages_ub' '$OUT/ub' >/dev/null && '$OUT/seq2_ub' >/dev/null && '$OUT/project_ub' >/dev/null && '$OUT/insert_ub' >/dev/null && '$OUT/modulation_ub' >/dev/null && '$OUT/midi_learn_ub' >/dev/null && '$OUT/punch_ub' '$OUT/ub/punch.wav' >/dev/null && '$OUT/editor_wide_ub' >/dev/null && '$OUT/soak_ub' 1 >/dev/null && echo 'no divide by zero'"

$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/soak_test" tests/soak_test.c -lm
run "soak: ${SOAK_MIN:-10} minutes of random live use (bounded, no hanging voices, idle after stop)" "$OUT/soak_test" "${SOAK_MIN:-10}"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -Ifirmware/hal -o "$OUT/stress_test" tests/stress_test.c -lm
run "stress (2.4): FONT_L = FONT_S at 2x, hard random use of every 2.4 addition, clean stop" "$OUT/stress_test" "${STRESS_FRAMES:-40000}"
# the same under AddressSanitizer + UBSan: any read or write out of bounds stops it (left shifts of negative values
# and the FM6 phase's wrap-around are left out: the DSP's two's complement idioms, as every compiler builds them)
ASAN="${CC_UB:-cc} -O1 -g -w -fsanitize=address,undefined -fno-sanitize=shift-base,signed-integer-overflow -fno-sanitize-recover=all -Ibuild/gen -Ifirmware/src -Ifirmware/hal"
if $ASAN -o "$OUT/stress_asan" tests/stress_test.c -lm 2>/dev/null; then
    run "stress under ASan + UBSan (no access out of bounds)" "$OUT/stress_asan" "${STRESS_ASAN_FRAMES:-15000}" 7
    $ASAN -DARENA_STATS -o "$OUT/arena_asan" tests/arena_test.c -lm
    run "shared engine arena under ASan + UBSan" "$OUT/arena_asan"
else
    echo "(stress under ASan: this compiler has no AddressSanitizer, skipped)"
fi

$CC -O2 -Wall -Wextra -o "$OUT/cluster_math_test" tests/cluster_math_test.c
run "CLUSTER: bit-identical arithmetic without hot-loop division" "$OUT/cluster_math_test"
$CC -o "$OUT/upreset_test" tests/upreset_test.c
run "user presets (UP_PUT parser, bank round trip, versions)" "$OUT/upreset_test"

$CC -o "$OUT/midi_uart_test" tests/midi_uart_test.c
run "TRS MIDI parser" "$OUT/midi_uart_test"
$CC -Ifirmware/hal -o "$OUT/encoder_test" tests/encoder_test.c
run "knobs: one click = one step (slow, fast, pauses, bounce)" "$OUT/encoder_test"
HALF=$(sed -n 's/^#define HALF_FRAMES \([0-9]*\).*/\1/p' firmware/src/core.h)
$CC -DT_CDC=1 -DHALF_FRAMES=$HALF -o "$OUT/uac_test" tests/uac_test.c -lm
run "USB audio input: descriptors (with CDC), ring and packets" "$OUT/uac_test"
$CC -DT_CDC=0 -DHALF_FRAMES=$HALF -o "$OUT/uac_test_nocdc" tests/uac_test.c -lm
run "USB audio input: descriptors (without CDC), ring and packets" "$OUT/uac_test_nocdc"
$CC -DT_CDC=2 -DHALF_FRAMES=$HALF -o "$OUT/uac_test_seroff" tests/uac_test.c -lm
run "USB audio input: descriptors (CDC built in, menu USB SERIAL OFF), ring and packets" "$OUT/uac_test_seroff"
run "USB SERIAL OFF: the descriptors of a build without CDC, byte for byte" \
    sh -c "[ \"\$(UAC_DUMP=1 '$OUT/uac_test_seroff' | tail -n 2)\" = \"\$(UAC_DUMP=1 '$OUT/uac_test_nocdc' | tail -n 2)\" ] && echo same"
uac_in_app() { ${CC%% *} -E -Ibuild/gen -Ifirmware/hal -Ifirmware/src firmware/src/felucca.c 2>/dev/null | grep -q uac_service; }
run "USB audio input: built into the firmware (FELUCCA_UAC set before usb.c)" uac_in_app

$CC -o "$OUT/ota_test" tests/ota_test.c
run "M-UPGRADE entry" "$OUT/ota_test" build/orbit.fwsc

head -c 200000 build/felucca.bin > "$OUT/old_app.bin"
python3 tools/fm1pkg_make.py "$OUT/old_app.bin" build/loader/ota.bin "$OUT/old.fwsc" >/dev/null
$CC -o "$OUT/ldr_test" tests/ldr_test.c
run "update loader: other app -> this build" "$OUT/ldr_test" "$OUT/old.fwsc" build/orbit.fwsc

# SMK-37 Pro (BOARD_SMK37): the flash map, the OTA staging and the loader windows on SMK-layout packages
# (made here from the FM-1 binaries: only the layout and the protocol are under test)
$CC -DBOARD_SMK37=1 -Ifirmware/hal -o "$OUT/smk_flash_test" tests/smk_flash_test.c
run "SMK-37 Pro flash map: allow-lists never reach the head, BTIF/USRTRIM, USR, key_mac" "$OUT/smk_flash_test"
$CC -DBOARD_SMK37=1 -o "$OUT/smk_owner_test" tests/smk_owner_test.c
run "SMK-37 store owner: ORBIT's family kept, another port's store and untagged data cleared" "$OUT/smk_owner_test"
python3 tools/fm1pkg_make.py --board smk37 build/felucca.bin build/loader/ota.bin "$OUT/smk_new.fwsc" >/dev/null
python3 tools/fm1pkg_make.py --board smk37 "$OUT/old_app.bin" build/loader/ota.bin "$OUT/smk_old.fwsc" >/dev/null
run "SMK-37 Pro package layout (fm1pkg_make --board smk37): PRCT 0x9D000, stock region table"     python3 tests/smk_pkg_test.py "$OUT/smk_new.fwsc"
$CC -DBOARD_SMK37=1 -o "$OUT/ota_test_smk" tests/ota_test.c
run "M-UPGRADE entry, SMK-37 Pro build (staging 0xBB000, parm ota-SMK-37 Pro_016)" "$OUT/ota_test_smk" "$OUT/smk_new.fwsc"
for m in 1 2; do                         # the MODEL=elite / mke builds of ota.c
    $CC -DBOARD_SMK37=1 -DT_MODEL=$m -o "$OUT/ota_test_smk_m$m" tests/ota_test.c
    run "M-UPGRADE entry, SMK-37 model $m (1 Elite, 2 MKE-P37): identity and parm under its name" "$OUT/ota_test_smk_m$m" "$OUT/smk_new.fwsc"
done
for m in "elite:SMK-37 Elite_900" "mke:MKE-P37_900"; do
    f="build/orbit-smk37-${m%%:*}.fwsc"
    [ -f "$f" ] && run "SMK-37 ${m%%:*} build package: layout, identity ${m#*:}" python3 tests/smk_pkg_test.py "$f" "${m#*:}"
done
$CC -DBOARD_SMK37=1 -o "$OUT/ldr_test_smk" tests/ldr_test.c
run "update loader, SMK-37 Pro: app area 0x4000-0x9CFFF, protected ranges untouched"     "$OUT/ldr_test_smk" "$OUT/smk_old.fwsc" "$OUT/smk_new.fwsc"

$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/hostsim" tests/hostsim.c -lm
$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/scale_test" tests/scale_test.c -lm
run "scales: white-key mapping and note lifecycle" "$OUT/scale_test"
run "DSP render (ANALOG preset 0)" "$OUT/hostsim" 0 0 1 "$OUT/render.wav"
mkdir -p build/tracks_demo
run "TRACKS: 4-track pattern, live recording (lengths, swing), voice budget, engine switch, cost" env TRACKS=build/tracks_demo "$OUT/hostsim" 0 0 1 "$OUT/tracks.wav"
$CC -w -Ibuild/gen -Ifirmware/src -o "$OUT/project_test" tests/project_test.c -lm
run "project formats (FUN5 / FUN4 / FUN3 / FUN2 / FUN1 -> ORP7, FUN6 refused), capture / apply, macros" "$OUT/project_test"
$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/slicer_test" tests/slicer_test.c -lm
mkdir -p build/slicer_demo
run "SLICER: no clicks, timing, sync with the sequencer, STUT, cost, demos" "$OUT/slicer_test" build/slicer_demo
$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/fm6_test" tests/fm6_test.c -lm
mkdir -p build/fm6_demo
run "FM6: algorithms, envelopes, retrigger, DC, clipping, macros, patch formats, voices, the bank, demos" "$OUT/fm6_test" build/fm6_demo
$CC -O2 -w -Ibuild/gen -Ifirmware/src -o "$OUT/regress" tests/regress.c -lm
# the CPU budget: counted by the kernel on macOS; elsewhere under callgrind when valgrind is there (exact, ~45 s;
# SKIP_CPU_VALGRIND=1 to time instead, which is only a rough check)
if [ -z "$SKIP_CPU_VALGRIND" ] && command -v valgrind >/dev/null 2>&1; then export CPU_VALGRIND=1; fi
run "regression: golden renders, health, voices, CPU budget" "$OUT/regress" tests/golden.txt tests/cpu_baseline.txt
# SLICE (tests/slice_test.c) needs a FELUCCA_SLICE=1 build; the engine is not built by default

run "regression: target cost of the render loops" python3 tests/target_budget.py \
    build/felucca.dis tests/target_budget.txt

run "installer CLI (fm1_install.py) against a simulated FM-1" python3 tests/install_test.py

if command -v node >/dev/null 2>&1; then
    run "web pages: editor protocol, samples, packages, update protocol" node web/test_web.mjs
else
    echo "== skip web tests (no node)"
fi

[ $fail -eq 0 ] && echo "ALL HOST TESTS PASSED" || { echo "HOST TESTS FAILED"; exit 1; }

