/* SPDX-License-Identifier: GPL-3.0-only */
/* The real UI (ui.c, ui_draw.c, ui_studio.c, ui_layers.c, ui_song.c, ui_menu.c, ui_input.c) on a
 * framebuffer with panel / flash / storage doubles, the audio (mix_block) running between frames as on
 * the device. Renders every screen to PPM for review (DIR/page-*.ppm, live-*.ppm, layer-*.ppm) and
 * drives the panel:
 *   taps    a layer button tapped opens its pages; held + a key / knob it does not
 *   FX      held + a white key: punch-in; knobs: filter, dust, duck
 *   SEQ     held: the steps on the white keys (drums: the sound played last), OCT: pages, a step key
 *           held + KNOB 1..4: sound / note, level, ratchet, nudge (2.4); PRESETS a lock of the parameter
 *           ALGORITHM picks (the sound parameter last touched first); + OCT-: its nudge, locks and fill
 *           condition go; + OCT+: the condition (normal, fill only, no fill)
 *   EDIT    held + a key: erase; OCT- / OCT+: undo / redo; KNOB 1 shift, 2 length x2
 *   ARP     held + a key: a roll; KNOB 1 the rate
 *   SEL     held + a key: the key of the song
 *   GLO     held + keys: mute, solo, fill (held) / fill the next bar, tap tempo; knobs: levels
 *   REC     press: arm / record at once; held: the clear ring, to the end: cleared (undo brings it back)
 *   SAVE    tapped: the song page; held: the SONG layer (sections A..D: play / store, SONG REC; two or more
 *           section taps: a chain, "chain A B" on the sub line)
 *   DRUMS   the grid: sound / step / hit / level knobs, GRID <-> KIT
 * then 20000 frames of random use: every draw stays on the screen. */
#define FELUCCA_ARRANGER 1
#define main hostsim_main
#include "hostsim.c"
#undef main
#include <assert.h>
static uint16_t screen[240*240];
static void lcd_sync(void) {}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *p)
{ uint32_t i,j; assert(x+w<=240 && y+h<=240); for(j=0;j<h;j++) for(i=0;i<w;i++) screen[(y+j)*240+x+i]=p[j*w+i]; }
#include "../firmware/src/gfx.c"
static void lcd_fill(uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint16_t c)
{ uint32_t i,j; assert(x+w<=240&&y+h<=240); for(j=0;j<h;j++)for(i=0;i<w;i++)screen[(y+j)*240+x+i]=swap16(c); }
static int32_t encs[7];
static uint32_t fm1_ticks(void) { return fm1_ms * 1000u * 24u; }
#define FM1_TICKS_PER_US 24u
/* A detent the timer ISR counts just after a read (on the FM-1 the scan runs while a UI pass does): it lands in
 * the same pass. Ordinary tests leave it zero (ported from SLOOP 2.8.4, isod89/sloop-fm1 91f3018). */
static int32_t enc_late[7];
static int32_t fm1_enc_take(uint32_t e) { int32_t s = encs[e]; encs[e] = enc_late[e]; enc_late[e] = 0; return s; }
static uint8_t fm1_led[16], fm1_led_dim[16], fm1_led_bg[16];
static volatile uint16_t fm1_led_bg_ns;
#define FM1_NCOL 16u
#define FM1_NBTN 14u
#define FM1_NENC 7u
static const int8_t FM1_KEYMAP[5][16];
static void fm1_led_key(uint32_t id, int on) { (void)id; (void)on; }
static uint32_t edges_btn, notes_seen;
static uint32_t fm1_input_edges(int x) { uint32_t e = edges_btn; (void)x; edges_btn = 0; return e; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = fm1_in.notes & ~notes_seen; notes_seen = fm1_in.notes; return e; }
static uint32_t wdt_tick_ms;                       /* (stress_test: 1, the blocking PANEL setup's clock runs out) */
static void fm1_wdt_feed(void) { fm1_ms += wdt_tick_ms; }
static int32_t fm1_adc_read(int c) { (void)c; return -1; }
static struct { uint32_t magic, stage, page, home, ui_frames; } felucca_dbg;
#define FELUCCA_ICONS 1
#define SCOPE_N 512u
static int16_t scope_buf[SCOPE_N];
static uint32_t scope_w;
#include "../firmware/src/panel.c"
#include "../firmware/src/ui.c"
static uint32_t saves, loads;
static int project_used(uint32_t i) { return i < 2; }
static void project_save(uint32_t i) { (void)i; saves++; ui_message("SAVED"); }
static void project_load(uint32_t i) { (void)i; loads++; }
static uint32_t erases;
static void project_erase(uint32_t i) { (void)i; erases++; ui_message("ERASED"); }
static void arrangement_save(void) {}
static uint32_t arrangement_ready(void) { return 3; }
static void arrangement_apply(uint32_t s) { (void)s; }
static uint32_t section_bars(uint32_t s) { return s == 1u ? 2u : 1u; }   /* (B: two bars) */
static void song_backup(void) {}
static void song_restore(void) {}
static uint32_t sec_stores, sec_loads;
static void section_store(uint32_t s) { sec_stores++; live_sec = (int8_t)s; }
static void section_load(uint32_t s) { sec_loads++; live_sec = (int8_t)s; }
static int up_used(uint32_t k) { return k < 2; }
static int up_load(uint32_t k) { (void)k; return 0; }
static int up_load_to(track_t *t, uint32_t k) { (void)t; (void)k; return 0; }
static uint32_t up_count(void) { return 2; }
static uint32_t up_nth(uint32_t n) { return n; }
static uint32_t up_rank(uint32_t s) { return s; }
static void up_name(uint32_t k, char *b) { str_cpy(b, k ? "MY PAD" : "MY LEAD", 13); }
static void up_slot_label(char *b, uint32_t k) { fmt_int(b, (int32_t)k + 1); }
static void up_ui(uint32_t op, uint32_t k) { (void)op; (void)k; }
static void settings_save(void) {}
#include "../firmware/src/ui_song.c"
#include "../firmware/src/ui_studio.c"
#include "../firmware/src/icons.c"
#include "../firmware/src/ui_draw.c"
#include "../firmware/src/ui_layers.c"
#include "../firmware/src/ui_menu.c"
#include "../firmware/src/ui_input.c"
#include "../firmware/src/splash.c"
static const char *outdir;
static void ppm(const char *name) {
    char path[512]; snprintf(path,sizeof path,"%s/%s.ppm",outdir,name);
    FILE *f=fopen(path,"wb"); assert(f); fprintf(f,"P6\n240 240\n255\n");
    for(unsigned i=0;i<240*240;i++) { uint16_t p=swap16(screen[i]); uint8_t rgb[3]={(p>>11)*255/31,((p>>5)&63)*255/63,(p&31)*255/31}; fwrite(rgb,1,3,f); }
    fclose(f);
}
/* one UI frame (~16 ms): the audio between (as the ISR does), then input, LEDs, draw */
static void frame(void)
{
    uint32_t q;
    static int32_t o[CTL * 2];
    for (q = 0; q < 22u; q++) {
        uint32_t i;
        mix_block(o, CTL);
        for (i = 1; i < CTL; i += 2u) {             /* the scope, as audio.c fills it (the HOME scope) */
            scope_buf[scope_w++ & (SCOPE_N - 1u)] = vis_tap[2u * i];
        }
    }
    ui_input(); ui_leds(); ui_draw(); fm1_ms += 16;
}
static void frames(uint32_t n) { while (n--) frame(); }
static uint32_t BT(uint32_t b) { return 1u << panel.btn[b]; }
static void press(uint32_t b) { edges_btn |= BT(b); fm1_in.buttons |= BT(b); frame(); }
static void release(uint32_t b) { fm1_in.buttons &= ~BT(b); frame(); }
static void tap(uint32_t b) { press(b); release(b); }
static void key(uint32_t k) { fm1_in.notes |= 1u << k; frame(); fm1_in.notes &= ~(1u << k); frame(); }
static int fails;
static void check(int ok, const char *what) { printf("ui: %-74s %s\n", what, ok ? "ok" : "FAIL"); fails += !ok; }
static const char *sub_line(void) { return layer_sub_shown; }   /* the layer's sub line as last drawn (ui_layers.c) */

#ifndef UI_PAGES_HARNESS_ONLY                       /* (tests/stress_test.c: the harness, its own main) */
static uint32_t lock_count(const track_t *t)        /* the lock slots in use */
{
    uint32_t k, n = 0;
    for (k = 0; k < NLOCK; k++)
        n += t->lock[k].step != LOCK_FREE;
    return n;
}
int main(int argc, char **argv)
{
    uint32_t i;
    outdir = argc > 1 ? argv[1] : "build/host";
    {   /* the preset list by kind (ui.c BANK): every factory preset of every engine once, every name found */
        uint32_t e, k, n, hits;
        bank_resolve();
        for (n = 0; n < NBANK; n++)
            if (bank_pi[n] == 0xFF) {
                printf("ui: BANK %s: no such preset in engine %u\n", BANK[n].name, BANK[n].e);
                fails++;
            }
        for (e = 0; e < NENGINES; e++)
            for (k = 0; k < ENGINES[e]->npresets; k++) {
                for (hits = 0, n = 0; n < NBANK; n++)
                    hits += BANK[n].e == e && bank_pi[n] == k;
                if (hits != 1) {
                    printf("ui: preset %s (engine %u) is %u times in BANK\n", ENGINES[e]->presets[k].name, e, hits);
                    fails++;
                }
            }
    }
    panel = PANEL_DEFAULT;
    layers_init();
    settings.palette = 4;
    palette_set(4);
    host_tracks_init();
    for (i = 0; i < NPART; i++) { set_engine_of(&trk[i], TRK_DEF[i][0]); apply_preset_to(&trk[i], TRK_DEF[i][1]); trk[i].engine = trk[i].eng_req; }
    TDRUM->p[P_E0] = DRUM_DEFAULT_KIT;
    orbit_splash(); ppm("page-splash");
    ui.menu = 2; ui.force = 1; frame(); ppm("page-about"); ui.menu = 0;
    go_home(); ui.force = 1; frame(); ppm("page-tracks");
    open_family(FAM_ENV); ui.force = 1; ui.hot_col = 1; ui.hot_t = 30; frame(); ppm("page-env");
    open_family(FAM_EDIT); ui.force = 1; frame(); ppm("page-edit");
    open_family(FAM_FX); ui.force = 1; frame(); ppm("page-fx");
    open_family(FAM_SEQ); ui.force = 1; frame(); ppm("page-step");
    open_family(FAM_GLO); ui.force = 1; frame(); ppm("page-global");
    open_family(FAM_GLO); ui.force = 1; frame(); ppm("page-master");
    open_family(FAM_SCL); ui.force = 1; frame(); ppm("page-scale");
    {   /* (2.4) GLO > SYSTEM: KNOB 1 is MIDI OUT (KEYS / SEQ), shown as such; the USB status in the third column */
        uint32_t i, m0 = (uint32_t)song.g[G_MIDI];
        for (i = 0; i < NPAGES; i++) if (!strcmp(PAGES[i].title, "SYSTEM")) break;
        open_family(FAM_GLO); ui.page = (uint8_t)i; ui.fam_last[FAM_GLO] = (uint8_t)i; page_entered(); ui.force = 1; frame();
        song.g[G_MIDI] = 0; ui.force = 1; frame();
        encs[panel.enc[EN_K1]] = 1; frame();
        check(i < NPAGES && song.g[G_MIDI] == 1, "GLO > SYSTEM: KNOB 1 sets MIDI = SEQ");
        {
            char val[12]; const char *unit = "";
            int16_t *vp; const param_desc_t *d = page_desc(cur_page(), 0, &vp);
            param_format(d, *vp, val, &unit);
            check(d && !strcmp(d->label, "OUT") && !strcmp(val, "SEQ"), "GLO > SYSTEM: the first column reads OUT SEQ (MIDI OUT)");
        }
        ui.force = 1; frame(); ppm("page-system");
        {   /* (2.4) KNOB 3: IN = CLOCK (notes ignored), kept in the settings word; back to NOTES */
            int16_t r0 = song.g[G_ROUTE];
            int16_t *vp; const param_desc_t *d = page_desc(cur_page(), 2, &vp);
            char val[12]; const char *unit = "";
            encs[panel.enc[EN_K3]] = 1; frame();
            param_format(d, *vp, val, &unit);
            check(song.g[G_ROUTE] == 1 && !strcmp(d->label, "IN") && !strcmp(val, "CLOCK"), "GLO > SYSTEM: KNOB 3 sets IN = CLOCK");
            lights_min = 1;
            check((lights_word() >> 15 & 1u) == 1u, "IN = CLOCK kept in the settings word (bit 15)");
            lights_from_word(lights_word() & ~(1u << 15));
            check(lights_min == 0u, "IN read back from the settings word");
            encs[panel.enc[EN_K3]] = 12; frame();             /* (2.6) on to CH 12 */
            param_format(d, *vp, val, &unit);
            lights_min = (uint8_t)song.g[G_ROUTE];
            {
                uint32_t w = lights_word();
                lights_min = 0;
                lights_from_word(w);
                check(song.g[G_ROUTE] == 13 && !strcmp(val, "CH 12") && lights_min == 13u && !(w >> 15 & 1u) && (w >> 21 & 31u) == 12u
                      && d->max == 17, "2.6: IN = CH 12 (CH 1..16 after CLOCK), kept in the settings word (bits 21-25), read back");
                lights_from_word(w & ~(31u << 21));
                check(lights_min == 0u, "2.6: a settings word from 2.5 (no channel bits): IN = NOTES");
            }
            encs[panel.enc[EN_K3]] = -13; frame();
            song.g[G_ROUTE] = r0;
        }
        song.g[G_MIDI] = (int16_t)m0; go_home(); frame();
    }

    /* ---- taps open pages, holds show layers only after 0.35 s or use */
    go_home(); ui.force = 1; frame();
    press(B_FX); frames(12);
    check(ui.layer == LY_PLAY, "FX held 0.2 s: no layer page");
    release(B_FX);
    check(ui.layer == LY_PLAY, "FX held 0.2 s then released: no layer page");
    go_home(); frame(); press(B_FX); frames(25);
    check(ui.layer == LY_FX, "FX held 0.4 s: the layer page shows");
    release(B_FX); go_home(); frame();
    press(B_FX); encs[panel.enc[EN_K2]] = 1; frame();
    check(ui.layer == LY_FX && song.g[G_DUST] > 0, "FX knob used while held: layer page shows at once");
    release(B_FX); song.g[G_DUST] = 0; go_home(); frame();
    {   /* (SLOOP 2.8.4, clipper-fm1 #24) a firm press, let go untouched within a second, opens what a quick tap
         * opens: a press of 0.6 s used to open nothing (TAP 0.45 s: the layer flashed, the screen stayed);
         * held 1.3 s: a look at the layer, back where it was */
        static const uint32_t LB[7] = {B_FX, B_EDIT, B_ARP, B_SEQ, B_SCL, B_GLO, B_SAVE};
        uint32_t q, ok = 1;
        for (q = 0; q < 7u; q++) {
            uint32_t h_home, h_page, t_home, t_page;
            go_home(); frames(2);
            h_home = ui.home; h_page = ui.page;
            tap(LB[q]); frames(3);
            t_home = ui.home; t_page = ui.page;
            ok &= t_home != h_home || t_page != h_page;                    /* (the tap opens something) */
            go_home(); frames(2);
            press(LB[q]); frames(37); release(LB[q]); frames(3);           /* (0.6 s) */
            ok &= ui.home == t_home && ui.page == t_page && !ui.menu;
            go_home(); frames(2);
            press(LB[q]); frames(80); release(LB[q]); frames(3);           /* (1.3 s) */
            ok &= ui.home == h_home && ui.page == h_page && ui.layer == LY_PLAY;
        }
        go_home(); frames(2);
        check(ok, "FX, EDIT, ARP, SEQ, SEL, GLO, SAVE pressed 0.6 s untouched: what a tap opens; held 1.3 s: no page");
    }
    { uint8_t was = song.sel; song.sel = 0; check(keys_guide() == 0u, "synth track, no layer: no landmarks (a piano)"); song.sel = was; }
    tap(B_SEQ); check(cur_fam() == FAM_SEQ, "SEQ tapped: the SEQ pages");
    go_home(); frame();
    tap(B_FX); check(cur_fam() == FAM_FX, "FX tapped: the FX pages");
    go_home(); frame();
    press(B_FX); frames(22); check(ui.layer == LY_FX && punch.hold, "FX held: the punch layer shows");
    check(keys_guide() == (1u << key_of_white(0) | 1u << key_of_white(4) | 1u << key_of_white(8) | 1u << key_of_white(12)),
          "FX held: keys 1, 5, 9, 13 lit dim (the rows of the grid)");
    ppm("layer-punch");
    fm1_in.notes = 1u << 4; frame(); check(punch.req == 2, "FX + the 3rd white key: punch effect 3");
    ppm("layer-punch-on");
    fm1_in.notes = 0; frame(); check(punch.req == -1, "key up: the mix comes back");
    fm1_in.notes = 1u << 17; frame(); check(punch.req == PX_FREEZE, "FX + the black key A#4: FREEZE (2.6: 11 black-key effects)");
    check(keys_lit() == 1u << 17, "its key lights");
    ppm("layer-punch-black");
    fm1_in.notes = 0; frame(); check(punch.req == -1, "black key up: the mix comes back");
    encs[panel.enc[EN_K2]] = 10; frame(); check(song.g[G_DUST] > 0, "FX + KNOB 2: DUST");
    encs[panel.enc[EN_K1]] = -10; frame(); check(song.g[G_FILT] < 0, "FX + KNOB 1: the filter (low-pass)");
    encs[panel.enc[EN_K4]] = 12; frame(); check(TSEL->p[P_TFLT] > 0 && song.g[G_FILT] < 0, "FX + KNOB 4: the selected track's FILTER (high-pass)");
    ui.force = 1; frame(); ppm("layer-punch-trkflt");
    TSEL->p[P_TFLT] = 0;
    release(B_FX); check(cur_page()->scope == SC_TRK && ui.layer == LY_PLAY, "FX used then let go: no FX page");
    song.g[G_DUST] = 0; song.g[G_FILT] = 0;

    /* ---- a layer locked open: held + HOME tapped; any other button (not PLAY, REC, OCT) lets it go */
    go_home(); frame();
    press(B_FX); frames(3); tap(B_HOME); release(B_FX); frames(3);
    check(ly_lock == LY_FX && ui.layer == LY_FX && punch.hold, "FX held + HOME: locked open, FX let go");
    check(cur_page()->scope == SC_TRK, "FX + HOME: no FX page, no HOME jump");
    fm1_in.notes = 1u << 4; frame(); check(punch.req == 2, "locked FX + the 3rd white key: punch effect 3 (no hands on FX)");
    fm1_in.notes = 0; frame(); check(punch.req == -1, "locked FX, key up: the mix comes back");
    encs[panel.enc[EN_K2]] = 6; frame(); check(song.g[G_DUST] > 0, "locked FX + KNOB 2: DUST");
    ui.force = 1; frame(); ppm("layer-locked");
    { uint8_t was = song.playing; tap(B_PLAY); frames(2);
      check(ly_lock == LY_FX && song.playing != was, "locked: PLAY plays and keeps the lock"); tap(B_PLAY); frames(2); }
    tap(B_ENV); frames(2);
    check(ly_lock == LY_PLAY && ui.layer == LY_PLAY && !punch.hold && cur_page()->scope == SC_TRK,
          "locked, ENV pressed: unlocked, and only that (no ENV page)");
    press(B_FX); frames(3); tap(B_HOME); release(B_FX); frames(3);
    tap(B_HOME); frames(2);
    check(ly_lock == LY_PLAY && ui.layer == LY_PLAY && cur_page()->scope == SC_TRK, "locked, HOME tapped: unlocked");
    press(B_FX); frames(3); tap(B_HOME); release(B_FX); frames(3);
    tap(B_FX); frames(2);
    check(ly_lock == LY_PLAY && ui.layer == LY_PLAY && cur_fam() != FAM_FX, "locked, FX tapped: unlocked, no FX page");
    go_home(); frame();
    press(B_SEQ); frames(3); tap(B_HOME); release(B_SEQ); frames(3);
    press(B_FX); frames(22);
    check(ly_lock == LY_PLAY && ui.layer == LY_FX, "locked SEQ, FX held: unlocked, the FX layer");
    release(B_FX); frames(2); check(ui.layer == LY_PLAY, "and FX let go: back to playing");
    press(B_FX); frames(3); tap(B_HOME); release(B_FX); frames(3);
    press(B_HOME); frames(50); release(B_HOME); frames(2);
    check(ui.menu && ly_lock == LY_PLAY, "locked, HOME held: the menu, unlocked");
    ui.menu = 0; ui.force = 1; frames(2);
    song.g[G_DUST] = 0; song.g[G_FILT] = 0;

    /* ---- SEQ layer: drum steps on the white keys */
    song.sel = TRK_DRUM; go_home(); frame();
    key(4);                                          /* A3: the snare, played: the layer's sound */
    check(pen_lane == 2, "a drum key played: the SEQ layer's sound (snare)");
    press(B_SEQ); frames(10);
    key(0); key(7); key(14);                          /* steps 1, 5, 9 */
    check(dstep_has(&TDRUM->dstep[0], 2) && dstep_has(&TDRUM->dstep[4], 2) && dstep_has(&TDRUM->dstep[8], 2) &&
          !dstep_has(&TDRUM->dstep[1], 2), "SEQ + white keys 1, 5, 9: snare steps");
    ppm("layer-steps");
    fm1_in.notes = 1u << 7; frame();                  /* step 5 held + KNOB 2 / 3: level, ratchet */
    encs[panel.enc[EN_K2]] = 1; frame();
    encs[panel.enc[EN_K3]] = 2; frame();
    fm1_in.notes = 0; frame();
    check(dstep_lvl(&TDRUM->dstep[4], 2) == LV_HARD && dstep_rat(&TDRUM->dstep[4], 2) == 2u,
          "step 5 held + KNOB 2 / 3: hard, x3");
    key(0); check(!dstep_has(&TDRUM->dstep[0], 2), "step 1 again: off");
    release(B_SEQ); check(ui.layer == LY_PLAY && !on_drum_page(), "SEQ used then let go: no page change");

    /* ---- EDIT: undo / redo, erase, length */
    press(B_EDIT); frames(10);
    edges_btn |= BT(B_OCTDN); fm1_in.buttons |= BT(B_OCTDN); frame(); fm1_in.buttons &= ~BT(B_OCTDN); frame();
    check(!dstep_has(&TDRUM->dstep[4], 2) && !dstep_has(&TDRUM->dstep[8], 2), "EDIT + OCT-: undo (the SEQ hold's steps gone)");
    edges_btn |= BT(B_OCTUP); fm1_in.buttons |= BT(B_OCTUP); frame(); fm1_in.buttons &= ~BT(B_OCTUP); frame();
    check(!dstep_has(&TDRUM->dstep[0], 2) && dstep_lvl(&TDRUM->dstep[4], 2) == LV_HARD, "EDIT + OCT+: redo (back, as left)");
    ppm("layer-erase");
    key(4);                                           /* stopped: every snare goes */
    check(!dstep_has(&TDRUM->dstep[4], 2) && !dstep_has(&TDRUM->dstep[8], 2), "EDIT + snare (stopped): every snare erased");
    encs[panel.enc[EN_K2]] = 1; frame();
    check(TDRUM->p[P_SLEN] == 32, "EDIT + KNOB 2: length x2");
    release(B_EDIT);
    edges_btn |= BT(B_EDIT); fm1_in.buttons |= BT(B_EDIT); frame();      /* undo the length too */
    edges_btn |= BT(B_OCTDN); fm1_in.buttons |= BT(B_OCTDN); frame(); fm1_in.buttons &= ~BT(B_OCTDN); frame();
    release(B_EDIT);
    check(TDRUM->p[P_SLEN] == 16, "EDIT + OCT-: the length back to 16");

    /* ---- ARP layer: a roll, rate knob */
    press(B_ARP); frames(10);
    encs[panel.enc[EN_K1]] = 1; frame();
    check(song.g[G_ROLL] == 2, "ARP + KNOB 1: the roll rate (1/32)");
    fm1_in.notes = 1u << 7; frames(3); check(roll[0].on, "ARP + a key: it rolls");
    ppm("layer-roll");
    fm1_in.notes = 0; frame(); check(!roll[0].on, "key up: the roll ends");
    release(B_ARP);

    /* ---- SEL: the key of the song; GLO: mute, solo, tap */
    song.sel = 0; go_home(); frame();
    press(B_SCL); frames(10);
    key(9);                                           /* D4 */
    check(trk[0].p[P_ROOT] == 2 && trk[1].p[P_ROOT] == 2 && trk[2].p[P_ROOT] == 2, "SEL + D: every part in D");
    encs[panel.enc[EN_K1]] = 2; frame();
    check(trk[0].p[P_CHORD] == 2, "SEL + KNOB 1: chords (7TH) on the track");
    ppm("layer-key");
    release(B_SCL);
    press(B_GLO); frames(10);
    key(0); check(trk[0].p[P_MUTE] == 1, "GLO + key 1: track 1 muted");
    key(9); check(song.solo == 2u, "GLO + key 6: track 2 soloed");
    ppm("layer-mix");
    for (i = 0; i < 4u; i++) { fm1_in.notes = 1u << 26; frame(); fm1_in.notes = 0; frames(36); }   /* ~0.6 s apart */
    check(song.g[G_BPM] >= 95 && song.g[G_BPM] <= 105, "GLO + the last key, tapped at ~0.6 s: ~100 BPM");
    key(0); key(9);
    check(!trk[0].p[P_MUTE] && !song.solo, "again: unmuted, no solo");
    /* (2.4) key 9 held: a fill; key 10: the next bar is one (again: cancelled) */
    fm1_in.notes = 1u << key_of_white(8); frame(); frame();
    check(fill_held == 1u && fill_now == 1u && (keys_lit() & (1u << key_of_white(8))) != 0, "GLO + key 9 held: FILL (the key lit)");
    ui.force = 1; frame(); ppm("layer-mix-fill");
    fm1_in.notes = 0; frame(); frame();
    check(fill_held == 0u && fill_now == 0u, "key 9 let go: the fill ends");
    key(key_of_white(9)); check(fill_arm == 1u && (keys_lit() & (1u << key_of_white(9))) != 0, "GLO + key 10: FILL NEXT BAR armed (the key lit)");
    key(key_of_white(9)); check(fill_arm == 0u, "GLO + key 10 again: cancelled");
    release(B_GLO);
    fm1_in.notes = 1u << key_of_white(8); frame();     /* (no layer: a plain key, no fill) */
    check(fill_held == 0u, "key 9 without GLO: no fill");
    fm1_in.notes = 0; frame();
    trk[0].p[P_CHORD] = 0;

    /* ---- SEQ layer (2.4): a step held + KNOB 4 nudges it, PRESETS locks the lock parameter (ALGORITHM picks it),
     * KNOB 1 still edits the note, OCT- clears nudge and locks; PRESETS / ALGORITHM browse nothing meanwhile */
    check(ui.lock_par == P_ED_FLT, "the lock parameter starts as ENV > FLT");
    song.sel = 0; go_home(); frames(16);              /* (KNOB 1..4 quiet ~250 ms after a layer: #39) */
    open_family(FAM_FX); frame();                     /* the FX page: KNOB 1 = DIST */
    encs[panel.enc[EN_K1]] = 2; frame();
    check(ui.lock_par == P_DIST && trk[0].p[P_DIST] > 0, "a sound knob turned (FX > DIST): the lock parameter");
    open_family(FAM_SEQ); frame();                    /* PATTERN page knobs (LEN, DIV..) do not lock */
    open_family(FAM_SEQ); frame();
    if (cur_page()->id[1] == P_SDIV) { encs[panel.enc[EN_K2]] = 1; frame(); encs[panel.enc[EN_K2]] = -1; frame(); }
    check(ui.lock_par == P_DIST, "a pattern knob (DIV) is not a lock parameter");
    go_home(); frame();
    press(B_SEQ); frames(10);
    key(7);                                           /* step 5 set with the pen */
    fm1_in.notes = 1u << 7; frame();                  /* step 5 held */
    {
        uint32_t n0 = trk[0].step[4].note[0];
        encs[panel.enc[EN_K1]] = 2; frame();
        check(trk[0].step[4].note[0] == n0 + 2u && trk[0].step[4].n == 1, "step 5 held + KNOB 1: the note two up (as in 2.3)");
    }
    encs[panel.enc[EN_K4]] = -3; frame();
    encs[panel.enc[EN_K4]] = -4; frame();
    check(trk[0].micro[4] == -7 && trk[0].step[4].n == 1, "step 5 held + KNOB 4: nudged -7 (the step kept)");
    {
        int k0 = lock_find(&trk[0], 4, P_DIST, 0);
        int32_t d0 = trk[0].p[P_DIST];
        uint32_t sel0 = song.sel, eng0 = trk[0].eng_req, pr0 = trk[0].preset;
        encs[panel.enc[EN_PRESET]] = 1; frame();
        {
            int k = lock_find(&trk[0], 4, P_DIST, 0);
            check(k0 < 0 && k >= 0 && trk[0].lock[k].val == d0 + 1, "step 5 held + PRESETS: a DIST lock at the track's value, moved one up");
            encs[panel.enc[EN_PRESET]] = 5; frame();
            check(k >= 0 && trk[0].lock[k].val > d0 + 1 && trk[0].p[P_DIST] == d0, "PRESETS again: the lock moves, the track's DIST does not");
            check(trk[0].eng_req == eng0 && trk[0].preset == pr0, "PRESETS with a step held browses no sound");
        }
        ui.force = 1; frame(); ppm("layer-steps-lock");
        check(step_locked(&trk[0], 4) && !step_locked(&trk[0], 5), "the step shows its mark (a nudge or a lock)");
        encs[panel.enc[EN_ALGO]] = 1; frame();
        check(ui.lock_par == P_CHOR && song.sel == sel0, "step held + ALGORITHM: the lock parameter (DIST -> CHO), the track stays selected");
        encs[panel.enc[EN_ALGO]] = -1; frame(); encs[panel.enc[EN_ALGO]] = -1; frame();
        check(ui.lock_par == P_SGATE && song.sel == sel0, "ALGORITHM back twice: CHO -> DIST -> GATE (LEN, DIV, SWG skipped)");
        encs[panel.enc[EN_PRESET]] = 1; frame();
        check(lock_find(&trk[0], 4, P_SGATE, 0) >= 0 && lock_find(&trk[0], 4, P_DIST, 0) >= 0, "PRESETS: a second lock (GATE) on the same step");
        for (i = 0; i < 80u; i++) { encs[panel.enc[EN_ALGO]] = 1; frame(); if (ui.lock_par == P_SGATE) break; }
        check(i > 0 && i < 80u && ui.lock_par == P_SGATE, "ALGORITHM wraps round through the lockable parameters");
        encs[panel.enc[EN_K4]] = -40; frame();
        check(trk[0].micro[4] == MICRO_MIN, "KNOB 4 bounded at -32");
        edges_btn |= BT(B_OCTDN); fm1_in.buttons |= BT(B_OCTDN); frame(); fm1_in.buttons &= ~BT(B_OCTDN); frame();
        check(trk[0].micro[4] == 0 && lock_find(&trk[0], 4, P_DIST, 0) < 0 && lock_find(&trk[0], 4, P_SGATE, 0) < 0 &&
              trk[0].step[4].n == 1 && ui.step_page == 0, "step held + OCT-: its nudge and locks cleared, the step kept, no page change");
    }
    {   /* (2.4) OCT+ with the step held: its fill condition round; OCT- resets it with the nudge and locks */
        edges_btn |= BT(B_OCTUP); fm1_in.buttons |= BT(B_OCTUP); frame(); fm1_in.buttons &= ~BT(B_OCTUP); frame();
        check(step_fill(&trk[0], 4) == FC_FILL && ui.step_page == 0 && trk[0].step[4].n == 1, "step held + OCT+: FILL ONLY (no page change, the step kept)");
        ui.force = 1; frame(); ppm("layer-steps-fill");
        edges_btn |= BT(B_OCTUP); fm1_in.buttons |= BT(B_OCTUP); frame(); fm1_in.buttons &= ~BT(B_OCTUP); frame();
        check(step_fill(&trk[0], 4) == FC_NOFILL, "OCT+ again: NO FILL");
        ui.force = 1; frame(); ppm("layer-steps-nofill");
        edges_btn |= BT(B_OCTUP); fm1_in.buttons |= BT(B_OCTUP); frame(); fm1_in.buttons &= ~BT(B_OCTUP); frame();
        check(step_fill(&trk[0], 4) == FC_NORM, "OCT+ again: normal");
        edges_btn |= BT(B_OCTUP); fm1_in.buttons |= BT(B_OCTUP); frame(); fm1_in.buttons &= ~BT(B_OCTUP); frame();
        encs[panel.enc[EN_K4]] = 3; frame();
        edges_btn |= BT(B_OCTDN); fm1_in.buttons |= BT(B_OCTDN); frame(); fm1_in.buttons &= ~BT(B_OCTDN); frame();
        check(step_fill(&trk[0], 4) == FC_NORM && trk[0].micro[4] == 0, "FILL ONLY + a nudge, OCT-: the condition and the nudge reset");
    }
    fm1_in.notes = 0; frame();
    check(trk[0].step[4].n == 1, "the step edited is kept when let go");
    fm1_in.notes = 1u << 7; frame(); encs[panel.enc[EN_PRESET]] = 1; frame(); fm1_in.notes = 0; frame();
    check(trk[0].step[4].n == 1 && lock_find(&trk[0], 4, P_SGATE, 0) >= 0, "a set step held + PRESETS: a lock, the step kept");
    fm1_in.notes = 1u << 7; frame();
    edges_btn |= BT(B_OCTUP); fm1_in.buttons |= BT(B_OCTUP); frame(); fm1_in.buttons &= ~BT(B_OCTUP); frame();
    fm1_in.notes = 0; frame();
    key(7);                                           /* a set step pressed and let go: cleared, with its locks and condition */
    check(trk[0].step[4].n == 0 && lock_find(&trk[0], 4, P_SGATE, 0) < 0 && step_fill(&trk[0], 4) == FC_NORM,
          "a step cleared: its locks and fill condition go too");
    { uint32_t sel0 = song.sel; encs[panel.enc[EN_ALGO]] = 1; frame(); check(song.sel == sel0 && ui.lock_par == P_SGATE, "no step held, SEQ held: ALGORITHM does nothing (no track change)"); }
    release(B_SEQ);
    { uint32_t sel0 = song.sel; encs[panel.enc[EN_ALGO]] = 1; frame(); check(song.sel == sel0 + 1u, "SEQ let go: ALGORITHM selects the track again"); song.sel = (uint8_t)sel0; }
    song.sel = TRK_DRUM; go_home(); frame();
    press(B_SEQ); frames(10);
    key(0);                                           /* a drum step: KNOB 1 the sound, KNOB 4 nudges the whole step */
    fm1_in.notes = 1u << 0; frame();
    { uint32_t l0 = pen_lane; encs[panel.enc[EN_K1]] = 1; frame(); check(pen_lane == l0 + 1u, "the drum track: step 1 held + KNOB 1: the sound (as in 2.3)"); }
    encs[panel.enc[EN_K4]] = 5; frame();
    encs[panel.enc[EN_PRESET]] = 1; frame();
    check(TDRUM->micro[0] == 5 && lock_find(TDRUM, 0, P_SGATE, 0) >= 0 && TDRUM->p[P_E0] == DRUM_DEFAULT_KIT,
          "the drum track: step 1 held + KNOB 4 / PRESETS: nudge +5, a lock, the kit untouched");
    fm1_in.notes = 0; frame();
    edges_btn |= BT(B_OCTDN); fm1_in.buttons |= BT(B_OCTDN); frame(); fm1_in.buttons &= ~BT(B_OCTDN); frame();
    check(TDRUM->micro[0] == 5 && ui.step_page == 0, "no step held + OCT-: the page (not a clear)");
    release(B_SEQ);
    fm1_irq_off(); steps_clear(TDRUM); steps_clear(&trk[0]); fm1_irq_on();
    trk[0].p[P_DIST] = 0;
    ui.lock_par = P_ED_FLT;
    song.sel = 0; go_home(); frame();

    /* ---- REC: press arms; held: the ring; to the end: cleared */
    go_home(); frame();
    song.playing = 0; song.rec = 0; rec_wait = 0;
    tap(B_REC); check(rec_wait == 1, "REC tapped (stopped): armed");
    ui.force = 1; frame(); ppm("live-rec-ready");
    tap(B_REC); check(rec_wait == 0, "REC again: cancelled");
    trk[0].step[3].n = 1, trk[0].step[3].note[0] = 60, trk[0].step[3].time = ST_NOTE;
    press(B_REC); frames(50);                         /* 0.8 s: the ring */
    check(ui.hold_kind == 1u && rec_wait == 0, "REC held: the press undone, the clear ring");
    ppm("hold-clear");
    frames(90);                                       /* to the end */
    check(!trk[0].step[3].n && ui.hold_kind == 0, "REC held to the end: track 1 cleared");
    release(B_REC);
    press(B_EDIT); frames(10);
    edges_btn |= BT(B_OCTDN); fm1_in.buttons |= BT(B_OCTDN); frame(); fm1_in.buttons &= ~BT(B_OCTDN); frame();
    release(B_EDIT);
    check(trk[0].step[3].n == 1, "EDIT + OCT-: the cleared track back");
    press(B_REC); frames(60); release(B_REC);         /* let go before the end: nothing */
    check(trk[0].step[3].n == 1 && !rec_wait, "REC let go before the end: nothing cleared");

    /* ---- SAVE: tap = the song page; held = the SONG layer (live sections, SONG REC) */
    go_home(); frame();
    song.playing = 0; live_sec = -1; live_req = -1; srec = 0; arrangement_enabled = 0;
    press(B_SAVE); frames(22); check(ui.layer == LY_SONG, "SAVE held: the song layer");
    key(key_of_white(4)); check(sec_stores == 0 && sec_armed == 1u, "store over a used A: asks again");
    key(key_of_white(4)); check(sec_stores == 1 && live_sec == 0, "again: the loop stored in A");
    key(key_of_white(6)); check(sec_stores == 2 && live_sec == 2, "an empty C: stored at once");
    key(key_of_white(1)); check(sec_loads == 1 && live_sec == 1, "stopped: B loaded as the loop");
    key(key_of_white(3)); check(sec_loads == 1, "an empty D: not played");
    song.playing = 1; clk_beat = 1; clk_pos = 0;
    key(key_of_white(0)); check(live_req == 0, "playing: A asked for the next bar");
    release(B_SAVE); frames(2);
    check(chain_n == 0u && chain_taps == 0u && live_req == 0, "one tap, SAVE let go: no chain (as before)");
    live_req = -1;
    press(B_SAVE); frames(22);                        /* (2.4) SAVE held: A, B, B tapped: a chain on release */
    key(key_of_white(0)); key(key_of_white(1));
    check(live_req == 0 && chain_taps == 2u && chain_n == 0u, "SAVE held, A then B tapped: A asked for, the chain building");
    ui.force = 1; frame();
    check(str_eq(sub_line(), "chain A B"), "the sub line reads \"chain A B\"");
    key(key_of_white(1));
    ui.force = 1; frame(); ppm("layer-song-chain");
    check(chain_taps == 3u && str_eq(sub_line(), "chain A B B"), "B again: \"chain A B B\"");
    release(B_SAVE); frames(2);
    check(chain_n == 3u && chain_i == 0u && chain_sec[0] == 0 && chain_sec[1] == 1 && chain_sec[2] == 1 && chain_bars == 1u && live_req == 0,
          "SAVE let go: the chain A B B plays (A asked for, 1 bar)");
    press(B_SAVE); frames(22);
    check(str_eq(sub_line(), "chain A B B"), "SAVE held again: the chain shown");
    key(key_of_white(1)); release(B_SAVE); frames(2);
    check(chain_n == 0u && live_req == 1, "a single tap of B: the chain ends, B asked for");
    press(B_SAVE); frames(22);
    live_req = -1; song.playing = 0;
    key(key_of_white(13)); check(srec == 1u && !arrangement_enabled, "SONG REC armed (loop mode)");
    ui.force = 1; frame(); ppm("layer-song");
    key(key_of_white(13)); check(srec == 0u, "SONG REC again: off");
    key(key_of_white(12)); check(arrangement_enabled == 1u, "loop / song: song mode");
    key(key_of_white(12)); check(arrangement_enabled == 0u, "again: loop mode");
    release(B_SAVE);
    check(!on_song_page() && saves == 0, "SAVE held and let go: no song page, no save");
    tap(B_SAVE); check(on_song_page(), "SAVE tapped on TRACKS: the song page");
    ui.force = 1; frame(); ppm("page-song");

    /* ---- the drum screen */
    song.sel = TRK_DRUM; studio_open(SC_DRUM); ui.force = 1; frames(16);   /* (after SAVE: the knobs quiet, #39) */
    check(on_drum_page(), "the drum screen");
    encs[panel.enc[EN_K3]] = 1; frame(); check(dstep_has(&TDRUM->dstep[0], 0), "DRUMS: KNOB 3 adds the kick on step 1");
    encs[panel.enc[EN_K4]] = -1; frame(); check(dstep_lvl(&TDRUM->dstep[0], 0) == LV_SOFT, "DRUMS: KNOB 4 softer");
    encs[panel.enc[EN_K1]] = 100; encs[panel.enc[EN_K2]] = 100; frame();
    check(drum_lane == 15 && drum_cursor == 15, "DRUMS: KNOB 1 / 2 bounded (16 sounds, 16 steps)");
    {   /* a scene to look at */
        static const uint8_t BEAT[16] = {0x11, 0x10, 0x10, 0x10, 0x14, 0x10, 0x10, 0x21, 0x11, 0x10, 0x01, 0x10, 0x1C, 0x10, 0x10, 0x20};
        uint32_t j;
        for (j = 0; j < 16u; j++) {
            memset(&TDRUM->dstep[j], 0, sizeof(dstep_t));
            if (BEAT[j] & 1u) dstep_set(&TDRUM->dstep[j], 0, LV_HARD, 0);
            if (BEAT[j] & 4u) dstep_set(&TDRUM->dstep[j], 2, LV_NORM, 0);
            if (BEAT[j] & 8u) dstep_set(&TDRUM->dstep[j], 3, LV_GHOST, 0);
            if (BEAT[j] & 0x10u) dstep_set(&TDRUM->dstep[j], 4, j % 4u ? LV_SOFT : LV_NORM, j == 14u ? 2u : 0u);
            if (BEAT[j] & 0x20u) dstep_set(&TDRUM->dstep[j], 5, LV_NORM, 0);
        }
        for (j = 0; j < 16u; j += 3u) { trk[0].step[j].n = 1; trk[0].step[j].note[0] = 36; trk[0].step[j].time = ST_NOTE; }
        for (j = 0; j < 16u; j += 4u) { trk[1].step[j].n = 3; trk[1].step[j].time = ST_NOTE; }
        drum_lane = 4; drum_cursor = 6; drum_page = 0; ui.force = 1; ui.msg_t = 0;
        drums.hits = 1u | 1u << 4; frame(); ppm("live-grid");
        drum_page = 1; ui.force = 1; drums.hits = 1u | 1u << 4; frame(); ppm("live-kit");
        drum_page = 0; song.sel = 1; go_home(); ui.force = 1;
        transport_req = 1; frames(30); song.rec = 2u; frame(); ui.force = 1; frame(); ppm("live-tracks");
        song.rec = 0; transport_req = 2; frames(2);
        song.sel = TRK_DRUM;
    }
    {   /* the free take screens */
        static track_t keep[NTRK];
        memcpy(keep, trk, sizeof keep);
        for (i = 0; i < NTRK; i++) steps_clear(&trk[i]);
        rec_tempo = 0; rec_count = 0;
        rec_wait = 1; ui.force = 1; frame(); ppm("live-rec-free");
        /* the REC screen's dials (2.3): KNOB 1 MODE, KNOB 2 LENGTH, KNOB 3 START */
        encs[panel.enc[EN_K1]] = 1; frame();
        check(rec_tempo == 1u && rec_wait, "REC screen, empty project: KNOB 1 -> MODE tempo");
        ui.force = 1; frame(); ppm("live-rec-tempo");
        trk[song.sel].p[P_SLEN] = 16;
        encs[panel.enc[EN_K2]] = 1; frame();
        encs[panel.enc[EN_K2]] = 1; frame();
        check(trk[song.sel].p[P_SLEN] == 64, "REC screen: KNOB 2 -> LENGTH 1, 2, 4 bars");
        encs[panel.enc[EN_K2]] = -1; frame();
        check(trk[song.sel].p[P_SLEN] == 32, "REC screen: KNOB 2 back -> 2 bars");
        encs[panel.enc[EN_K3]] = 1; frame();
        check(rec_count == 1u, "REC screen: KNOB 3 -> START count");
        ui.force = 1; frame(); ppm("live-rec-count");
        check((lights_word() >> 9 & 3u) == 3u, "REC screen: MODE and START saved with the settings");
        ci_on = 1; ci_beat = 1; ui.force = 1; frame(); ppm("live-rec-countin");
        encs[panel.enc[EN_K1]] = -1; frame();
        check(rec_tempo == 1u, "REC screen: the count-in running, the dials wait");
        ci_on = 0; ci_beat = 0;
        trk[1].step[0].time = ST_NOTE; trk[1].step[0].n = 1; trk[1].step[0].note[0] = 60;
        encs[panel.enc[EN_K1]] = -1; frame();
        check(rec_tempo == 1u, "REC screen, a project with notes: no MODE (always the tempo set)");
        ui.force = 1; frame(); ppm("live-rec-notes");
        steps_clear(&trk[1]);
        encs[panel.enc[EN_K3]] = -1; frame();
        encs[panel.enc[EN_K1]] = -1; frame();
        check(rec_tempo == 0u && rec_count == 0u, "REC screen: KNOB 3 / 1 back -> note, free");
        rec_count = 1; encs[panel.enc[EN_K3]] = -1; frame();
        check(rec_count == 1u, "REC screen, MODE free: no START (the take starts on the first note)");
        rec_count = 0;
        trk[song.sel].p[P_SLEN] = 16;
        rec_wait = 0; ft_on = 1; ft_t = (uint32_t)(5.4 * FS / CTL); ui.force = 1; ui_draw(); ppm("live-free-take");
        ft_on = 0; ft_t = 0; memcpy(trk, keep, sizeof keep);
        rec_wait = 0; frame();
    }
    for (i = 0; i < DRUM_KITS; i++) { TDRUM->p[P_E0] = (int16_t)i; ui.force = 1; drum_page = 1; frame(); }
    drum_page = 0;

    {   /* menu NOTES (PR #11 by @renebohne): sounding synth voices light their keys */
        song.sel = 0; go_home(); ui.force = 1; frame();
        trk[0].p[P_CHORD] = 0; trk[0].p[P_QUANT] = 0; trk[0].p[P_ROOT] = 0; trk[0].p[P_TRANS] = 0;
        song.octave = 0;
        lights_notes = 0;
        trk[0].v[0].active = 1; trk[0].v[0].gate = 1; trk[0].v[0].stage = 1; trk[0].v[0].note = 60;
        frame();
        check((keys_lit() & (1u << 7)) == 0, "NOTES off: a sounding synth voice lights no key");
        ui.menu = 1; ui.menu_sel = MI_NOTES; ui.force = 1; frame();
        encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = 1; frame();
        check(lights_notes == 1u, "menu NOTES: its knob (KNOB 3) right: ON");
        ui.force = 1; frame(); ppm("page-menu-notes");
        ui.menu = 0; ui.force = 1; go_home(); frame();
        check((keys_lit() & (1u << 7)) != 0, "NOTES on: a sounding synth voice lights key 7 (C4)");
        {   /* a short note (a sequencer 1/16) that starts and ends between two frames still lights its key */
            int32_t o[CTL * 2];
            uint32_t n = 0, f;
            trk[0].v[0].active = 0; trk[0].v[0].gate = 0;
            frame(); frame();
            check((keys_lit() >> 9 & 1u) == 0, "NOTES on: D4 not lit before it plays");
            trk_note_on(&trk[0], 62, 100);
            mix_block(o, CTL);
            trk_note_off(&trk[0], 62);
            for (f = 0; f < 20; f++) mix_block(o, CTL);
            frame();
            check((keys_lit() >> 9 & 1u) != 0, "NOTES on: a note over before the frame still lights its key (D4)");
            for (f = 0; f < 10; f++) { frame(); n += keys_lit() >> 9 & 1u; }
            check(n >= 4u && n <= 7u && (keys_lit() >> 9 & 1u) == 0, "NOTES on: ... for about 6 frames, then off");
            song.sel = 1; frame(); song.sel = 0; frame();
            trk[0].v[0].active = 1; trk[0].v[0].gate = 1; trk[0].v[0].stage = 1; trk[0].v[0].note = 60;
        }
        {   /* every screen and layer: lit where the keys are notes, a glow under the tiles */
            static const struct { uint32_t ly; int lit; const char *name; } L[] = {
                {LY_ERASE, 1, "EDIT erase"}, {LY_ROLL, 1, "ARP roll"}, {LY_SCALE, 1, "SEL key"}, {LY_SONG, 1, "SAVE song"},
                {LY_FX, 0, "FX punch"}, {LY_STEP, 0, "SEQ steps"}, {LY_MIX, 0, "GLO mix"}};
            uint32_t k, ok = 1, ly0 = ui.layer;
            char what[96];
            for (k = 0; k < sizeof L / sizeof L[0]; k++) {
                ui.layer = (uint8_t)L[k].ly;
                if (L[k].lit)
                    ok = (keys_lit() >> 7 & 1u) != 0;
                else
                    ok = (keys_notes_dim() >> 7 & 1u) != 0 && (keys_lit() >> 7 & 1u) == 0;
                snprintf(what, sizeof what, "NOTES on, %s layer: the sounding C4 %s", L[k].name, L[k].lit ? "lit" : "glows under the tiles");
                check(ok, what);
            }
            ui.layer = LY_SCALE;
            check((keys_notes_dim() & scale_keys(0)) == scale_keys(0), "NOTES on, SEL: the scale glows");
            lights_notes = 0;
            ui.layer = LY_ERASE;
            check((keys_lit() >> 7 & 1u) == 0 && keys_notes_dim() == 0u, "NOTES off, EDIT erase: as before (no note lights)");
            ui.layer = LY_SCALE;
            check(keys_notes_dim() == 0u, "NOTES off, SEL: as before");
            lights_notes = 1;
            ui.layer = (uint8_t)ly0;
        }
        song.octave = -1;
        frame();
        check((keys_lit() & (1u << 19)) != 0 && (keys_lit() & (1u << 7)) == 0, "NOTES on: the octave moves the lit key");
        song.octave = 0;
        trk[0].v[0].gate = 0; trk[0].v[0].stage = 3;
        frame();
        check((keys_lit() & (1u << 7)) == 0, "NOTES on: the release turns the key off");
        trk[0].v[0].active = 0;
        check((lights_word() >> 8 & 1u) == 1u, "NOTES: saved with the light settings");
        ui.menu = 1; ui.menu_sel = MI_USB; ui.force = 1; frame(); ppm("menu-usb");
        usb_full = 0;
        encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = 1; frame();
        check(usb_full == 1u && (lights_word() >> 11 & 1u) == 1u, "menu USB AUDIO: its knob (KNOB 2) -> FULL, saved with the settings");
        tap(B_OCTUP);
        check(usb_full == 0u && ui.menu == 1, "menu USB AUDIO: OCT+ toggles back to MASTER");
        ui.menu_sel = MI_SERIAL; ui.force = 1; frame();
        check(usb_serial == 0u && !(lights_word() >> 16 & 1u), "menu USB SERIAL: OFF by default (2.3 settings read so)");
        encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = 1; frame();
        check(usb_serial == 1u && (lights_word() >> 16 & 1u), "menu USB SERIAL: its knob (KNOB 3) -> ON, saved with the settings");
        ui.force = 1; frame(); ppm("menu-serial");
        lights_from_word(lights_word());
        check(usb_serial == 1u, "menu USB SERIAL: read back");
        tap(B_OCTUP);
        check(usb_serial == 0u && ui.menu == 1, "menu USB SERIAL: OCT+ toggles back to OFF");
        ui.menu = 0; ui.force = 1; go_home(); frame();
        ui.menu = 1; ui.menu_sel = MI_NOTES; ui.force = 1; frame();
        tap(B_OCTUP);
        check(lights_notes == 0u && ui.menu == 1, "menu NOTES: OCT+ toggles it off");
        ui.menu = 0; ui.force = 1; go_home(); frame();
    }

    {   /* menu LIGHTS / KEYS: the backlight for playing in the dark */
        uint32_t m, nbits;
        go_home(); ui.force = 1; frame();
        check(lights_lvl == LIGHTS_OFF && fm1_led_bg_ns == 0u && lights_keys_mask() == 0u, "LIGHTS: off by default");
        ui.menu = 1; ui.menu_sel = MI_LIGHTS; ui.force = 1; frame();
        encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = 1; frame();
        check(lights_lvl == LIGHTS_LOW && fm1_led_bg_ns == 500u, "LIGHTS: KNOB 1 right: LOW (a 0.5 us pulse a frame)");
        encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = 1; frame();
        check(lights_lvl == LIGHTS_MID && fm1_led_bg_ns == 1000u, "LIGHTS: MID (1 us)");
        encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = 1; frame(); encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = 1; frame();
        check(lights_lvl == LIGHTS_HIGH && fm1_led_bg_ns == 2000u, "LIGHTS: HIGH (2 us, under the 4 us glow), and it stops there");
        ui.force = 1; frame(); ppm("page-menu-lights");
        encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = -1; frame();
        check(lights_lvl == LIGHTS_MID, "LIGHTS: KNOB 1 left: dimmer");
        tap(B_OCTUP);
        check(lights_lvl == LIGHTS_HIGH && ui.menu == 1, "LIGHTS: OCT+ steps round, the menu stays");
        tap(B_OCTUP);
        check(lights_lvl == LIGHTS_OFF && fm1_led_bg_ns == 0u, "LIGHTS: ... back to OFF");
        ui.menu_sel = MI_KEYS; ui.force = 1; frame();
        encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = 1; frame();
        m = lights_keys_mask();
        check(lights_keys == KEYS_C && lights_lvl == LIGHTS_LOW && m == (1u << 7 | 1u << 19),
              "KEYS (KNOB 2): C KEYS (C4, C5), LIGHTS raised to LOW");
        encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = 1; frame();
        for (m = lights_keys_mask(), nbits = 0; m; m &= m - 1u)
            nbits++;
        check(lights_keys == KEYS_WHITE && nbits == 16u && !(lights_keys_mask() & (1u << 1)),
              "KEYS: WHITE KEYS (16 of 27, F#3 dark)");
        encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = 1; frame(); encs[panel.enc[EN_K1 + mi_row(ui.menu_sel)]] = 1; frame();
        check(lights_keys == KEYS_ALL && lights_keys_mask() == 0x7FFFFFFu, "KEYS: ALL KEYS (every one of the 27 keys), and it stops there");
        ui.force = 1; frame(); ppm("page-menu-keys-all");
        tap(B_OCTUP);
        check(lights_keys == KEYS_OFF, "KEYS: OCT+ from ALL KEYS steps round to OFF");
        lights_keys = KEYS_ALL;
        check(lights_word() >> 4 & 15u, "KEYS: ALL KEYS kept in the settings word");
        lights_from_word(lights_word());
        check(lights_keys == KEYS_ALL, "KEYS: ALL KEYS read back");
        lights_lvl = LIGHTS_OFF; frame();
        check(lights_keys_mask() == 0u && fm1_led_bg_ns == 0u, "KEYS: nothing lit while LIGHTS is OFF");
        lights_keys = KEYS_OFF;
        ui.menu = 0; ui.force = 1; go_home(); frame();
    }

    {   /* the menu in sections (2.4): SELECT the section, KNOB 1..3 its rows, PRESETS the cursor, OCT+ opens */
        uint32_t sec;
        ui.menu = 1; ui.menu_sel = 0; ui.force = 1; frame(); ppm("menu-screen");
        check(mi_sec(ui.menu_sel) == MS_SCREEN, "menu: opens on SCREEN (COLOR, ZOOM)");
        encs[panel.enc[EN_SELECT]] = 1; frame();
        check(mi_sec(ui.menu_sel) == MS_LIGHTS && ui.menu_sel == MI_LIGHTS, "menu: SELECT right: LIGHTS, the cursor on its first row");
        encs[panel.enc[EN_K2]] = 1; frame(); encs[panel.enc[EN_K2]] = 1; frame();
        check(lights_keys == KEYS_WHITE && ui.menu_sel == MI_KEYS, "menu LIGHTS: KNOB 2 sets KEYS (row 2), the cursor follows");
        encs[panel.enc[EN_K3]] = 1; frame();
        check(lights_notes == 1u && ui.menu_sel == MI_NOTES, "menu LIGHTS: KNOB 3 sets NOTES (row 3)");
        encs[panel.enc[EN_K4]] = 1; frame();
        check(ui.menu_sel == MI_NOTES, "menu: KNOB 4 on a section of three rows does nothing");
        ui.force = 1; frame(); ppm("menu-lights");
        encs[panel.enc[EN_PRESET]] = 1; frame();
        check(ui.menu_sel == MI_LIGHTS, "menu: PRESETS moves the cursor round the section's rows");
        encs[panel.enc[EN_SELECT]] = 1; frame(); ui.force = 1; frame(); ppm("menu-audio");
        check(mi_sec(ui.menu_sel) == MS_AUDIO, "menu: SELECT right: AUDIO (LOWCUT, USB AUDIO, USB SERIAL)");
        encs[panel.enc[EN_SELECT]] = 5; frame();
        sec = mi_sec(ui.menu_sel);
        check(sec == MS_SYSTEM, "menu: SELECT stops at the last section, SYSTEM");
        encs[panel.enc[EN_K4]] = 1; ui.force = 1; frame(); ppm("menu-system");
        check(ui.menu_sel == MI_PANEL && MI_COUNT == MI_ABOUT + 1 &&
              swap16(screen[233u * 240u + 4u]) == C_BLACK,
              "menu SYSTEM: unused fourth knob leaves selection unchanged and footer clear");
        encs[panel.enc[EN_K2]] = 1; frame();
        check(ui.menu == 1 && ui.menu_sel == MI_LCLEAR, "menu SYSTEM: KNOB 2 is MIDI LEARN CLEAR (2.6), nothing cleared by a turn");
        encs[panel.enc[EN_K3]] = 1; frame();
        check(ui.menu == 1 && ui.menu_sel == MI_ABOUT, "menu SYSTEM: a knob does not open ABOUT, it moves the cursor");
        tap(B_OCTUP);
        check(ui.menu == 2, "menu SYSTEM: OCT+ on ABOUT opens it");
        tap(B_OCTDN);
        check(ui.menu == 1 && ui.menu_sel == MI_ABOUT, "menu: OCT- from ABOUT: back to SYSTEM");
        tap(B_OCTDN);
        check(ui.menu == 0, "menu: OCT- closes");
        lights_keys = KEYS_OFF; lights_notes = 0; lights_lvl = LIGHTS_OFF;
        go_home(); ui.force = 1; frame();
    }

    {   /* SELECT (2.4): the pages of the family shown; the tempo on HOME (TRACKS), in a layer, on REC */
        int16_t bpm;
        #define PT() (PAGES[ui.page].title)
        #define SEL(n) do { encs[panel.enc[EN_SELECT]] = (n); frame(); } while (0)
        song.playing = 0; song.sel = 0; go_home(); ui.force = 1; frame();
        bpm = song.g[G_BPM];
        SEL(1);
        check(song.g[G_BPM] > bpm, "SELECT on HOME (TRACKS): the tempo");
        song.g[G_BPM] = bpm;
        tap(B_LFO);
        check(!strcmp(PT(), "LFO"), "SELECT: LFO opens its first page");
        SEL(1);
        check(!strcmp(PT(), "LFO 2") && song.g[G_BPM] == bpm, "SELECT on LFO: next page LFO 2 (2.6), the tempo untouched");
        ui.force = 1; frame(); ppm("page-lfo2");
        SEL(1);
        check(!strcmp(PT(), "LFO DEST") && song.g[G_BPM] == bpm, "SELECT: then LFO DEST");
        SEL(1);
        check(!strcmp(PT(), "LFO DEST") && song.g[G_BPM] == bpm, "SELECT: stops at the last page of the family");
        SEL(-1);
        check(!strcmp(PT(), "LFO 2"), "SELECT left: the page before");
        SEL(-1);
        check(!strcmp(PT(), "LFO"), "SELECT left: LFO");
        tap(B_FX); SEL(1);
        check(!strcmp(PT(), "FILTER"), "SELECT on FX: next page, the track FILTER");
        TSEL->p[P_TFLT] = -32; ui.force = 1; frames(2); ppm("page-filter");
        check(!strcmp(ui.big_l[0], "FILT") && !strcmp(ui.big_v[0], "LP50") &&
              !strcmp(ui.big_l[1], "RES") && !strcmp(ui.big_l[2], "TYPE") &&
              !strcmp(ui.big_v[2], "LP/HP") && !ui.big_l[3][0],
              "FILTER page: FILT, RES and TYPE controls, fourth column unused");
        {   /* the big value in the graph strip: white pixels in the middle of the screen */
            uint32_t x, y, lit = 0;
            for (y = Y_GRAPH + 30; y < Y_GRAPH + 90; y++)
                for (x = 40; x < 200; x++)
                    lit += screen[y * 240u + x] != 0;
            check(lit > 300u, "FILTER page: the graph strip shows it");
        }
        {
            uint32_t t;
            for (t = 0; t < 2; t++) {
                int16_t res;
                song.sel = t ? TRK_DRUM : 0;
                TSEL->p[P_TFLT] = -32; TSEL->p[P_TRES] = 40; TSEL->p[P_TFTYPE] = 0;
                ui.force = 1; frame();
                ppm(t ? "page-track-filter-drum-lphp" : "page-track-filter-synth-lphp");
                check(page_for_drum(cur_page()), "track FILTER is available on the drum track");
                encs[panel.enc[EN_K2]] = 1; frame(); res = TSEL->p[P_TRES];
                encs[panel.enc[EN_K3]] = 1; frame();
                check(res > 40 && TSEL->p[P_TFTYPE] == 1 &&
                      !strcmp(ui.big_v[0], "BP25") && !strcmp(ui.big_v[2], "BP"),
                      "synth/drum FILTER knobs edit RES and TYPE and redraw BP formatting");
                ui.force = 1; frame(); ppm(t ? "page-track-filter-drum-bp" : "page-track-filter-synth-bp");
                encs[panel.enc[EN_K1]] = 1; frame();
                check(TSEL->p[P_TFLT] > -32, "synth/drum FILTER knob 1 edits the BP centre");
                TSEL->p[P_TFLT] = 0; ui.force = 1; frame();
                check(!strcmp(ui.big_v[0], "OFF"), "BP FILTER zero displays OFF");
                TSEL->p[P_TRES] = 40; TSEL->p[P_TFTYPE] = 0;
            }
            song.sel = 0;
        }
        TSEL->p[P_TFLT] = 0;
        SEL(9);
        check(!strcmp(PT(), "REV/CHO"), "SELECT on FX: on to the last page, REV/CHO");
        tap(B_EDIT); SEL(-9);
        check(!strcmp(PT(), "EDIT 1"), "SELECT on EDIT: back to the first page");
        SEL(9);
        check(cur_page()->graph == GR_MACROS, "SELECT on EDIT: up to the MACROS assignment page");
        ui.force = 1; frame(); ppm("page-macros");
        SEL(-1);
        check(!strcmp(PT(), "PERFORM"), "MACROS has an adjacent mapped-value PERFORM page");
        ui.force = 1; frame(); ppm("page-perform");
        SEL(-1);
        check(!strcmp(PT(), "VOICE 2"), "PERFORM keeps VOICE 2 independently accessible");
        SEL(1);
        tap(B_HOME);
        check(ui.home, "HOME from EDIT returns directly to Event Tape");
        ui.force = 1; frame(); ppm("page-tape-from-perform");
        tap(B_HOME);
        check(ui.home, "Event Tape HOME stays on Event Tape");
        tap(B_SEQ); SEL(9);
        check(!strcmp(PT(), "PATTERN"), "SELECT on SEQ: STEP <-> PATTERN, not into the SONG screen");
        tap(B_ENV);
        check(!strcmp(PT(), "ENV"), "the button still opens its family");
        tap(B_ENV);
        check(!strcmp(PT(), "ENV DEST"), "... and a second tap still steps the page");
        press(B_GLO); frames(3);
        SEL(1);
        check(!strcmp(PT(), "ENV DEST") && song.g[G_BPM] > bpm, "SELECT with a layer held (GLO): the tempo");
        release(B_GLO); frames(2);
        song.g[G_BPM] = bpm;
        go_home(); frame(); SEL(-1);
        check(song.g[G_BPM] < bpm, "back on HOME: SELECT is the tempo again");
        song.g[G_BPM] = bpm;
        /* 믹서(GLO)의 페이지도 SELECT가 오간다: TRACKS(트랙 1..4 level) -> PAN(트랙 1..4 pan) -> TRACK(예전 경로 그대로: 전역 SWING,
         * 선택 트랙의 LEVEL / LEN / PAN). 템포는 바뀝지 않는다. 같은 knob의 연속 회전은 accel()을 피하려고 frames(5)로 띄운다 */
        {
            int16_t sw = song.g[G_SWING], len = TSEL->p[P_SLEN], lv1 = trk[1].p[P_LEVEL], pan1 = trk[1].p[P_PAN];
            tap(B_GLO); frame();
            check(!ui.home && cur_page()->scope == SC_TRK && !strcmp(PT(), "TRACKS"), "GLO tapped on HOME: the mixer's level page");
            trk[1].p[P_MUTE] = 0; frames(5);
            encs[panel.enc[EN_K2]] = 2; frame();
            check(trk[1].p[P_LEVEL] == lv1 + 2 && song.g[G_SWING] == sw, "mixer TRACKS: KNOB 2 is track 2's level, not the swing");
            SEL(1);
            check(!strcmp(PT(), "PAN") && song.g[G_BPM] == bpm, "SELECT on the mixer: the PAN page, the tempo untouched");
            frames(5);
            encs[panel.enc[EN_K2]] = -5; frame();
            check(trk[1].p[P_PAN] == pan1 - 5 && trk[1].p[P_LEVEL] == lv1 + 2, "mixer PAN: KNOB 2 is track 2's pan");
            SEL(1);
            check(!strcmp(PT(), "TRACK"), "SELECT again: the TRACK page (swing, level, steps, pan of the selected track)");
            frames(5);
            encs[panel.enc[EN_K1]] = 4; frame();
            encs[panel.enc[EN_K3]] = 1; frame();
            check(song.g[G_SWING] == sw + 4 && TSEL->p[P_SLEN] == len + 1 && song.g[G_BPM] == bpm,
                  "mixer TRACK: KNOB 1 the swing (global), KNOB 3 the pattern length, as before");
            SEL(1);
            check(!strcmp(PT(), "TRACK"), "SELECT: stops at the last mixer page");
            SEL(-9);
            check(!strcmp(PT(), "TRACKS") && song.g[G_BPM] == bpm, "SELECT left: back to the level page");
            song.g[G_SWING] = sw; TSEL->p[P_SLEN] = len; trk[1].p[P_LEVEL] = lv1; trk[1].p[P_PAN] = pan1;
            go_home(); frame();
        }
        #undef SEL
        #undef PT
    }

    {   /* Felucca #39 / #102 (2.4): a knob turned as a layer lets go, or while PLAY is pressed in a layer, never
         * edits the page under the layer */
        int16_t r0, w0;
        song.playing = 0; song.sel = 0; go_home(); ui.force = 1; frames(3);
        tap(B_LFO); frames(2);
        r0 = trk[0].p[P_LRATE]; w0 = trk[0].p[P_LWAVE];
        press(B_FX); frames(10);
        encs[panel.enc[EN_K2]] = 3; frame();
        encs[panel.enc[EN_K1]] = 4;                         /* turned in the frame FX comes up */
        fm1_in.buttons &= ~BT(B_FX); frame();
        check(trk[0].p[P_LRATE] == r0, "#39: KNOB 1 turned as FX lets go: the LFO page under it is untouched");
        frames(5); encs[panel.enc[EN_K1]] = 2; frame();
        check(trk[0].p[P_LRATE] == r0, "#39: ... and for a moment after (the knob still turning)");
        frames(20); encs[panel.enc[EN_K1]] = 2; frame();
        check(trk[0].p[P_LRATE] > r0, "#39: then KNOB 1 is the page's again");
        trk[0].p[P_LRATE] = r0;
        press(B_FX); frames(10);
        edges_btn |= BT(B_PLAY); fm1_in.buttons |= BT(B_PLAY);
        encs[panel.enc[EN_K2]] = 2; frame();
        fm1_in.buttons &= ~BT(B_PLAY);
        check(trk[0].p[P_LWAVE] == w0 && song.g[G_DUST] > 0 && transport_req, "#102: PLAY pressed in the FX layer plays, KNOB 2 is DUST only");
        transport_req = 0; song.g[G_DUST] = 0;
        release(B_FX); frames(20);
        song.g[G_BPM] = 120;
    }

    {   /* DRUMS grid (2.4): the keys are the steps of the sound; the sound and the step heard; SELECT grid / kit */
        uint32_t i;
        song.playing = 0; song.sel = TRK_DRUM; go_home(); frame();
        memset(TDRUM->dstep, 0, sizeof TDRUM->dstep);
        TDRUM->p[P_SLEN] = 32;
        studio_open(SC_DRUM); drum_page = 0; drum_lane = 0; drum_cursor = 0; frames(2);
        memset(pad_lit, 0, sizeof pad_lit);
        key(key_of_white(2)); frame();
        check(dstep_has(&TDRUM->dstep[2], 0) && drum_cursor == 2 && !pad_lit[0], "grid: white key 3 sets step 3 of the sound (silent), the cursor on it");
        check((keys_lit() >> key_of_white(2)) & 1u, "grid: its key lit");
        key(key_of_white(2));
        check(!dstep_mask(&TDRUM->dstep[2]), "grid: the key again clears it");
        tap(B_OCTUP);
        check(drum_cursor == 18, "grid: OCT+ picks the next bank, keeping the local cursor");
        key(key_of_white(0));
        check(dstep_has(&TDRUM->dstep[16], 0), "grid: ... and the white keys are its steps (step 17)");
        tap(B_OCTUP);
        check(drum_cursor == 0, "grid: OCT+ wraps at LENGTH, as in the SEQ layer");
        tap(B_OCTDN);
        check(drum_cursor == 16, "grid: OCT- wraps back to the last bank");
        {   /* All black keys select and audition voices; stopped no step is written, while REC runs each hit is recorded. */
            static const uint8_t lanes[11] = {0, 2, 4, 5, 3, 7, 9, 10, 11, 12, 15};
            dstep_t before[NSTEP];
            uint32_t r, n, seen = 0, recorded = 0, ok = 1;
            memset(TDRUM->dstep, 0, sizeof TDRUM->dstep);
            memcpy(before, TDRUM->dstep, sizeof before);
            song.g[G_CLOCK] = 0;
            drum_cursor = 18;
            for (r = 0; r < 2u; r++) {
                song.playing = r; song.rec = r ? 1u << TRK_DRUM : 0;
                for (n = 0; n < 11u; n++) {
                    uint32_t age = drums.age;
                    memset(pad_lit, 0, sizeof pad_lit); drums.hits = 0;
                    key(PUNCH_BLACK[n]);
                    ok &= drum_lane == lanes[n] && drum_cursor == 18 && drums.age != age;
                    if (!r) ok &= !memcmp(before, TDRUM->dstep, sizeof before);
                    ok &= (keys_lit() & (1u << PUNCH_BLACK[n])) != 0;
                    for (i = 0; i < DRUM_LANES; i++) ok &= !pad_lit[i] || i == lanes[n];
                    if (!r) { ok &= !(seen & (1u << drum_lane)); seen |= 1u << drum_lane; }
                }
            }
            for (i = 0; i < NSTEP; i++) recorded |= dstep_mask(&TDRUM->dstep[i]);
            check(ok, "grid: all 11 black keys select and audition unique voices, LED on; stopped: no step change");
            check(recorded == (1u << 0 | 1u << 2 | 1u << 4 | 1u << 5 | 1u << 3 | 1u << 7 | 1u << 9 | 1u << 10 |
                               1u << 11 | 1u << 12 | 1u << 15),
                  "grid: playing with REC, every black key records its voice at once");
            song.playing = 0; song.rec = 0;
            memset(TDRUM->dstep, 0, sizeof TDRUM->dstep);
            {   /* Every white step changes only the chosen lane in the chosen bank. */
                dstep_t expected[NSTEP];
                uint32_t b, w, n, idx;
                ok = 1; TDRUM->p[P_SLEN] = 64;
                memset(TDRUM->dstep, 0, sizeof TDRUM->dstep);
                for (i = 0; i < NSTEP; i++) dstep_set(&TDRUM->dstep[i], 1, LV_SOFT, 2);
                memcpy(expected, TDRUM->dstep, sizeof expected);
                for (n = 0; n < 11u; n++) {
                    key(PUNCH_BLACK[n]);
                    for (b = 0; b < 4u; b++) {
                        drum_cursor = (uint8_t)(b * 16u);
                        for (w = 0; w < 16u; w++) {
                            idx = b * 16u + w;
                            key(key_of_white(w)); dstep_set(&expected[idx], lanes[n], LV_NORM, 0);
                            ok &= drum_cursor == idx && !memcmp(expected, TDRUM->dstep, sizeof expected);
                            key(key_of_white(w)); dstep_clr(&expected[idx], lanes[n]);
                            ok &= !memcmp(expected, TDRUM->dstep, sizeof expected);
                        }
                    }
                }
                check(ok, "grid: all 16 whites toggle only the selected voice and bank, preserving other lanes");
                TDRUM->p[P_SLEN] = 53; drum_cursor = 47;
                tap(B_OCTUP);
                check(drum_cursor == 52, "grid: OCT+ clamps the local cursor on a short fourth bank");
                memcpy(expected, TDRUM->dstep, sizeof expected);
                for (w = 5; w < 16u; w++) key(key_of_white(w));
                check(drum_cursor == 52 && !memcmp(expected, TDRUM->dstep, sizeof expected),
                      "grid: short bank ignores whites beyond LENGTH");
                tap(B_OCTUP); check(drum_cursor == 4, "grid: short bank OCT+ wraps to page 1");
                tap(B_OCTDN); check(drum_cursor == 52, "grid: short bank OCT- wraps to page 4");
                TDRUM->p[P_SLEN] = 1; drum_cursor = 0;
                tap(B_OCTUP); tap(B_OCTDN);
                check(drum_cursor == 0, "grid: one-step pattern keeps both OCT directions bounded");
            }
            {   /* Real C captures: BD/SN/closed HH, all banks, short bank, cursor and playhead. */
                static const uint8_t voice[3] = {0, 2, 4};
                static const char *const names[3] = {"bd", "sn", "hh"};
                uint32_t n, b;
                char name[40];
                memset(TDRUM->dstep, 0, sizeof TDRUM->dstep);
                for (i = 0; i < NSTEP; i++) {
                    if (!(i % 4u)) dstep_set(&TDRUM->dstep[i], 0, LV_NORM, 0);
                    if (i % 8u == 4u) dstep_set(&TDRUM->dstep[i], 2, LV_HARD, 0);
                    if (!(i % 2u)) dstep_set(&TDRUM->dstep[i], 4, LV_SOFT, 0);
                }
                song.playing = 1;
                for (n = 0; n < 3u; n++) {
                    drum_lane = voice[n]; TDRUM->p[P_SLEN] = 64;
                    for (b = 0; b < 4u; b++) {
                        drum_cursor = (uint8_t)(b * 16u + 2u); TDRUM->seq_idx = (uint8_t)(b * 16u + 1u);
                        ui.force = 1; ui_draw();
                        snprintf(name, sizeof name, "grid-%s-page%u", names[n], b + 1u); ppm(name);
                    }
                    TDRUM->p[P_SLEN] = 53; drum_cursor = 52; TDRUM->seq_idx = 48;
                    ui.force = 1; ui_draw();
                    snprintf(name, sizeof name, "grid-%s-page4-short", names[n]); ppm(name);
                }
                drum_lane = 2; drum_cursor = 2; TDRUM->p[P_SLEN] = 64; TDRUM->seq_idx = 4;
                ui.force = 1; ui_draw(); ppm("grid-sn-playhead-hit");
                check(swap16(screen[(24u + 2u * 10u + 5u) * 240u + 24u + 4u * 13u + 3u]) == C_BLACK,
                      "grid: playhead stays visible on a white HARD hit");
                TDRUM->seq_idx = 1; ui.force = 1; ui_draw();
                check(swap16(screen[(24u + 2u * 10u + 5u) * 240u + 24u + 13u + 3u]) == C_WHITE,
                      "grid: playhead stays visible on an empty step");
                {
                    uint32_t row, col, ok = 1;
                    for (row = 0; row < DRUM_LANES; row++)
                        for (col = 0; col < 16u; col++) {
                            const dstep_t *s = &TDRUM->dstep[col];
                            uint16_t want = dstep_has(s, row) ? lvl_col(dstep_lvl(s, row)) :
                                            row == drum_lane ? TE_G2 : TE_G1;
                            ok &= swap16(screen[(24u + row * 10u + 2u) * 240u + 24u + col * 13u + 1u]) == want;
                        }
                    check(ok, "grid: all sixteen instrument rows and sixteen time columns show their own hits");
                }
                song.playing = 0;
            }
            ok = 1; drum_lane = 0;
            for (n = 0; n < DRUM_LANES; n++) {
                if (n) { encs[panel.enc[EN_K1]] = 1; frame(); }
                ok &= drum_lane == n;
            }
            check(ok, "grid: K1 still reaches all 16 voices, including the five without black shortcuts");
            memset(TDRUM->dstep, 0, sizeof TDRUM->dstep);
            TDRUM->p[P_SLEN] = 32; drum_lane = 0; drum_cursor = 16;
        }
        memset(pad_lit, 0, sizeof pad_lit);
        encs[panel.enc[EN_K1]] = 3; frames(2);
        check(drum_lane == 3 && !pad_lit[3], "grid: KNOB 1 picks the sound silently");
        dstep_set(&TDRUM->dstep[20], 5, LV_NORM, 0);
        dstep_set(&TDRUM->dstep[20], 7, LV_SOFT, 0);
        memset(pad_lit, 0, sizeof pad_lit);
        drum_cursor = 19; encs[panel.enc[EN_K2]] = 1; frames(2);
        check(drum_cursor == 20 && !pad_lit[5] && !pad_lit[7] && !pad_lit[3], "grid: KNOB 2 onto a step moves silently");
        encs[panel.enc[EN_SELECT]] = 1; frame();
        check(drum_page == 1, "DRUMS: SELECT right: kit");
        frame();
        memset(pad_lit, 0, sizeof pad_lit);
        key(key_of_white(9)); frame();
        check(pad_lit[9] && !dstep_has(&TDRUM->dstep[25], 3), "kit: the keys play the pads again, no step set");
        {
            dstep_t before[NSTEP];
            memcpy(before, TDRUM->dstep, sizeof before);
            memset(pad_lit, 0, sizeof pad_lit);
            key(3);
            check(pad_lit[lane_of_key(3)] && drum_lane == 3 &&
                  !memcmp(before, TDRUM->dstep, sizeof before), "kit: black keys still play live, no GRID selection or step write");
            ui.force = 1; ui_draw(); ppm("grid-kit-live");
        }
        encs[panel.enc[EN_SELECT]] = -1; frame();
        check(drum_page == 0, "DRUMS: SELECT left: grid");
        {
            dstep_t before[NSTEP];
            uint32_t ok = 1, mute = drum_mute;
            memcpy(before, TDRUM->dstep, sizeof before);
            TDRUM->p[P_SLEN] = 64;
            press(B_SEQ); frames(3);
            for (i = 0; i < 4u; i++) {
                key(PUNCH_BLACK[i]);
                ok &= ui.step_page == i && drum_lane == 3 && drum_cursor == 20;
            }
            release(B_SEQ); frames(20);
            check(ok && !drum_page && !memcmp(before, TDRUM->dstep, sizeof before),
                  "grid + SEQ held: all four black bank shortcuts preserved, no voice or pattern edit");
            er_mute = 0;
            press(B_EDIT); frames(3); key(25); key(key_of_white(0));
            check(er_mute && drum_mute == (mute ^ 1u) && !memcmp(before, TDRUM->dstep, sizeof before),
                  "grid + EDIT held: black mute mode and white live mute preserve the pattern");
            release(B_EDIT); frames(20);
            check(!er_mute && !drum_page, "grid: releasing used SEQ/EDIT layers keeps GRID, not KIT");
            drum_mute = mute; TDRUM->p[P_SLEN] = 32;
        }
        go_home(); frame();
        memset(pad_lit, 0, sizeof pad_lit);
        pen_lane = 0;
        press(B_SEQ); frames(3);
        key(3);
        check(ui.step_page == 1, "SEQ held: first four black keys retain bank shortcuts");
        encs[panel.enc[EN_K1]] = 2; frames(2);
        check(pen_lane == 2 && pad_lit[2], "SEQ layer, drum track: KNOB 1 picks the sound and plays it");
        release(B_SEQ); frames(2);
        song.sel = 1; go_home(); frame();
        trk[1].p[P_SDIV] = 5;
        press(B_SEQ); frames(3);
        for (i = 0; i < 5u; i++) { encs[panel.enc[EN_K2]] = 1; frame(); }
        check(trk[1].p[P_SDIV] == (int16_t)(NDIV_STEP - 1u), "SEQ layer: KNOB 2 DIV goes on to 1/2, 1BAR, 2BAR");
        release(B_SEQ); frames(2);
        trk[1].p[P_SDIV] = 2; TDRUM->p[P_SLEN] = 16; memset(TDRUM->dstep, 0, sizeof TDRUM->dstep);
        song.sel = 0; go_home(); frame();
    }

    {   /* (2.4) STEP, then ALGO to the drum track: "DRUM TRACK" (it drew the drum steps as notes, reading past them) */
        uint32_t j, b0;
        song.sel = 0; go_home(); frames(2);
        for (j = 0; j < NSTEP; j++) dstep_set(&TDRUM->dstep[j], j % 16u, LV_NORM, 3);
        for (j = 0; j < NPAGES; j++) if (!strcmp(PAGES[j].title, "STEP")) break;
        open_family(FAM_SEQ); ui.page = (uint8_t)j; ui.fam_last[FAM_SEQ] = (uint8_t)j; page_entered(); ui.force = 1; frames(2);
        b0 = ui.page;
        for (j = 0; j < 3u; j++) { encs[panel.enc[EN_ALGO]] = 1; frames(2); }
        check(song.sel == TRK_DRUM && ui.page == b0 && !page_for_drum(cur_page()) && !strcmp(PAGES[ui.page].title, "STEP"),
              "STEP on the drum track: not a page for the drums (DRUM TRACK shown, no piano roll of the drum steps)");
        for (j = 0; j < NSTEP; j++) memset(&TDRUM->dstep[j], 0, sizeof(dstep_t));
        song.sel = 0; go_home(); frames(4);
    }
    {   /* STEP chord mode captures the played chord including CHORD+ modifiers; otherwise a single note. */
        uint32_t j, k5 = key_of_white(4), kmin = 1u;            /* key 5 = C4 (I chord); F#3 (key 1): minor */
        track_t *t = &trk[1];
        song.sel = 1; go_home(); frames(2);
        steps_clear(t); t->p[P_SLEN] = 16; t->p[P_VOICE] = V_POLY;
        t->p[P_ROOT] = 0; t->p[P_SCALE] = 1; t->p[P_QUANT] = 0; t->p[P_CHORD] = 1;   /* C major, TRIAD */
        for (j = 0; j < NPAGES; j++) if (!strcmp(PAGES[j].title, "STEP")) break;
        open_family(FAM_SEQ); ui.page = (uint8_t)j; ui.fam_last[FAM_SEQ] = (uint8_t)j; page_entered(); ui.force = 1; frames(2);
        cursor_set(0); frames(1);
        key(k5); frames(2);
        check(t->step[0].n == 3u && t->step[0].note[0] % 12u == 0u && t->step[0].note[1] % 12u == 4u && t->step[0].note[2] % 12u == 7u,
              "STEP page, chord mode TRIAD: C4 writes the chord C E G (not only C)");
        fm1_in.notes = 1u << kmin; frames(2);
        key(k5); frames(2);
        fm1_in.notes = 0; frames(2);
        check(t->step[1].n == 3u && t->step[1].note[1] % 12u == 3u, "STEP page, CHORD+: F# held, C4 writes C minor (C Eb G)");
        t->p[P_CHORD] = 0;
        key(k5); frames(2);
        check(t->step[2].n == 1u && t->step[2].note[0] % 12u == 0u, "STEP page, no chord mode: one note");
        steps_clear(t); song.sel = 0; go_home(); frames(4);
    }
    {   /* the visualiser was removed (RAM): HOME on HOME stays on the TRACKS screen; the HOME scope still reads
         * the mix as if MASTER were all the way up; the settings word writes 0 in the old style bits */
        uint32_t j, k;
        static const uint8_t BASS[2] = {38, 34};
        song.playing = 0; song.sel = 0;
        for (j = 0; j < NTRK; j++) { steps_clear(&trk[j]); trk[j].p[P_SLEN] = 16; }
        for (j = 0; j < 16u; j++) {                 /* a groove to look at */
            step_t *sp;
            if (!(j & 1u)) { sp = &trk[0].step[j]; sp->n = 1; sp->note[0] = (uint8_t)(BASS[j / 8u] + ((j & 2u) ? 12 : 0)); sp->time = ST_NOTE; sp->vel = 100; }
            if ((j % 4u) == 2u) { sp = &trk[1].step[j]; sp->n = 3; sp->note[0] = 65; sp->note[1] = 69; sp->note[2] = 72; sp->time = ST_NOTE; sp->vel = 100; }
            if (!(j % 8u)) { sp = &trk[2].step[j]; sp->n = 2; sp->note[0] = 57; sp->note[1] = 64; sp->time = ST_NOTE; sp->vel = 100; }
            memset(&TDRUM->dstep[j], 0, sizeof(dstep_t));
            if (!(j % 4u)) dstep_set(&TDRUM->dstep[j], 0, LV_NORM, 0);
            if ((j % 8u) == 4u) dstep_set(&TDRUM->dstep[j], 3, LV_NORM, 0);
            dstep_set(&TDRUM->dstep[j], 4, (j & 1u) ? LV_SOFT : LV_NORM, 0);
            for (k = 0; k < 4u; k++) trk[k].seq_active = 1;
        }
        go_home(); frames(20);                      /* (the knobs quiet after the layers above) */
        transport_req = 1; frames(30);
        tap(B_HOME); frames(2);
        check(ui.home && !ui.menu, "HOME on HOME stays on the TRACKS screen");
        tap(B_HOME); frames(2);
        check(ui.home && !ui.menu, "HOME on HOME again: still the TRACKS screen");
        {   /* MASTER at 0: silence out, the scope as if MASTER were all the way up */
            uint32_t m0 = song.master_q12, pk = 0, op = 0, b;
            static int32_t o2[CTL * 2];
            song.master_q12 = 0; frames(20);
            for (j = 0; j < SCOPE_N; j++) { uint32_t a = (uint32_t)(scope_buf[j] < 0 ? -scope_buf[j] : scope_buf[j]); if (a > pk) pk = a; }
            for (b = 0; b < 200u; b++) { mix_block(o2, CTL); for (j = 0; j < CTL * 2u; j++) { uint32_t a = (uint32_t)(o2[j] < 0 ? -o2[j] : o2[j]); if (a > op) op = a; } }
            check(op < 64u && pk > 2000u, "HOME scope: MASTER at 0: no sound, the scope as at full volume");
            song.master_q12 = m0; frames(4);
        }
        check(((lights_word() >> 17) & 15u) == 0u, "settings word: the removed visualiser's style bits are written 0");
        tap(B_LFO); frames(2);
        check(!ui.home && !strcmp(PAGES[ui.page].title, "LFO"), "a page button from HOME opens its page");
        transport_req = 2; frames(4);
        for (j = 0; j < NTRK; j++) steps_clear(&trk[j]);
        song.sel = 0; go_home(); frames(20);
    }

    {   /* ENV / LFO knobs with a range of 100 or more move 1 per slow detent and 12 per fast detent (accel() x3, then
         * x4); enums, the mixer and the tempo keep their steps. frames(5) (80 ms) makes a detent slow */
        int16_t keep[sizeof trk[0].p / sizeof trk[0].p[0]], bpm = song.g[G_BPM];
        uint32_t n;
        #define KN(k, d) do { encs[panel.enc[EN_K1 + (k)]] = (d); frame(); } while (0)
        memcpy(keep, trk[0].p, sizeof keep);
        song.playing = 0; song.sel = 0; go_home(); frames(2);
        ui.fam_last[FAM_ENV] = 0; ui.fam_last[FAM_LFO] = 0;   /* (each button opens its family's first page) */
        tap(B_ENV); frames(5);
        check(!strcmp(PAGES[ui.page].title, "ENV"), "ENV: the envelope page");
        trk[0].p[P_ATK] = 10; KN(0, 1);
        check(trk[0].p[P_ATK] == 11, "ENV ATK: a slow detent moves 1");
        KN(0, 1);
        check(trk[0].p[P_ATK] == 23, "ENV ATK: a fast detent moves 12 (accel x3, x4)");
        frames(5); KN(0, -1);
        check(trk[0].p[P_ATK] == 22, "ENV ATK: a slow negative detent moves 1");
        trk[0].p[P_ATK] = 0;
        for (n = 0; n < 128u && trk[0].p[P_ATK] < 127; n++) { frames(5); KN(0, 1); }
        printf("ui: ENV ATK 0 -> 127 in %u slow detents\n", n);
        check(trk[0].p[P_ATK] == 127 && n == 127u, "ENV ATK: a full sweep takes 127 slow detents (one index each)");
        trk[0].p[P_REL] = 127;
        for (n = 0; n < 128u && trk[0].p[P_REL] > 0; n++) { frames(5); KN(3, -1); }
        check(trk[0].p[P_REL] == 0 && n == 127u, "ENV REL: the sweep down takes 127 slow detents");
        trk[0].p[P_ESYNC] = 1;
        for (n = 0; n < 3u; n++) {
            uint32_t id = n == 0u ? P_ATK : n == 1u ? P_DEC : P_REL;
            uint32_t knob = n == 2u ? 3u : n;
            trk[0].p[id] = 0; frames(5); KN(knob, 1);
            check(trk[0].p[id] == 6, "ENV SYNC: a slow positive detent selects the next name");
            KN(knob, 1);
            check(trk[0].p[id] == 11, "ENV SYNC: a fast positive detent still selects one name");
            KN(knob, -1);
            check(trk[0].p[id] == 6, "ENV SYNC: a fast negative detent selects the previous name");
            frames(5); KN(knob, -1);
            check(trk[0].p[id] == 0, "ENV SYNC: a slow negative detent returns to the first name");
        }
        trk[0].p[P_ESYNC] = 0;
        tap(B_ENV); frames(5);
        check(!strcmp(PAGES[ui.page].title, "ENV DEST"), "ENV again: ENV DEST");
        trk[0].p[P_ED_FLT] = 0; KN(0, -1);
        check(trk[0].p[P_ED_FLT] == -1, "ENV DEST FLT (-64..63): a slow detent moves 1");
        tap(B_LFO); frames(5);
        check(!strcmp(PAGES[ui.page].title, "LFO"), "LFO: the source page");
        trk[0].p[P_LRATE] = 60; KN(0, 1);
        check(trk[0].p[P_LRATE] == 61, "LFO RATE: a slow detent moves 1");
        KN(0, 1);
        check(trk[0].p[P_LRATE] == 73, "LFO RATE: a fast detent moves 12");
        trk[0].p[P_LRATE] = 0;
        for (n = 0; n < 128u && trk[0].p[P_LRATE] < 127; n++) { frames(5); KN(0, 1); }
        printf("ui: LFO RATE 0 -> 127 in %u slow detents\n", n);
        check(trk[0].p[P_LRATE] == 127 && n == 127u, "LFO RATE: a full sweep takes 127 slow detents");
        trk[0].p[P_LWAVE] = 0; frames(5); KN(1, 1);
        check(trk[0].p[P_LWAVE] == 1, "LFO WAVE (an enum): still one wave per detent");
        KN(1, 1);
        check(trk[0].p[P_LWAVE] == 2, "LFO WAVE: a fast detent still moves one");
        tap(B_LFO); frames(5);
        check(!strcmp(PAGES[ui.page].title, "LFO 2"), "LFO again: LFO 2 (2.6)");
        tap(B_LFO); frames(5);
        check(!strcmp(PAGES[ui.page].title, "LFO DEST"), "LFO again: LFO DEST");
        trk[0].p[P_LD_AMP] = 0; KN(3, 1);
        check(trk[0].p[P_LD_AMP] == 1, "LFO DEST AMP: a slow detent moves 1");
        memcpy(trk[0].p, keep, sizeof keep);
        go_home(); frames(2); tap(B_GLO); frames(5);
        trk[1].p[P_MUTE] = 0; trk[1].p[P_LEVEL] = 100; KN(1, 1);
        check(trk[1].p[P_LEVEL] == 101, "mixer level: a slow detent still moves 1");
        KN(1, 1);
        check(trk[1].p[P_LEVEL] == 104, "mixer level: a fast detent still moves 3");
        trk[1].p[P_LEVEL] = keep[P_LEVEL];
        go_home(); frames(5);
        encs[panel.enc[EN_SELECT]] = 1; frame();
        check(song.g[G_BPM] == bpm + 1, "HOME SELECT: the tempo still moves 1 per slow detent");
        song.g[G_BPM] = bpm; frames(2);
        #undef KN
    }

    {   /* REC on the selected, playing track: a sound knob turned writes a parameter lock on the step playing (the
         * existing 24 slots, one undo per pass). Another track's REC, a pattern knob, a global knob and a stopped
         * transport write none; with every slot used: NO LOCK LEFT and no slot changes */
        int16_t keep[sizeof trk[0].p / sizeof trk[0].p[0]], bpm = song.g[G_BPM], gv;
        plock_t none[NLOCK], before[NLOCK];
        uint8_t fam_keep[sizeof ui.fam_last];
        uint32_t i, s1, s2;
        int k;
        #define KN(k, d) do { encs[panel.enc[EN_K1 + (k)]] = (d); frame(); } while (0)
        #define PAGE(name) do { for (i = 0; i < NPAGES && strcmp(PAGES[i].title, name); i++) ; \
            open_family(PAGES[i].fam); ui.page = (uint8_t)i; ui.fam_last[PAGES[i].fam] = (uint8_t)i; page_entered(); \
            frames(16); } while (0)
        memcpy(keep, trk[0].p, sizeof keep);
        memcpy(fam_keep, ui.fam_last, sizeof fam_keep);
        song.sel = 0; song.rec = 0; go_home(); frames(16);
        locks_clear(&trk[0]); locks_clear(&trk[1]);
        memcpy(none, trk[0].lock, sizeof none);
        trk[0].p[P_ESYNC] = 0;
        song.g[G_BPM] = GP[G_BPM].min;                 /* (long steps: two turns land on one step) */
        transport_req = 1; frames(8);
        PAGE("ENV");
        check(song.playing && cur_page()->id[0] == P_ATK && p_lockable(P_ATK), "REC lock: ENV page, transport playing");
        song.rec = 2u; trk[0].p[P_ATK] = 40; KN(0, 1);
        check(trk[0].p[P_ATK] == 41 && !lock_count(&trk[0]) && !lock_count(&trk[1]),
              "REC lock: another track's REC: the knob edits, no lock");
        song.rec = 1u; frames(5); KN(0, 1); s1 = trk[0].seq_idx;
        k = lock_find(&trk[0], s1, P_ATK, 0);
        check(trk[0].p[P_ATK] == 42 && k >= 0 && trk[0].lock[k].val == 42 && lock_count(&trk[0]) == 1u,
              "REC lock: the knob writes a lock on the step playing");
        KN(0, 1); s2 = trk[0].seq_idx;
        k = lock_find(&trk[0], s1, P_ATK, 0);
        check(s1 == s2 && trk[0].p[P_ATK] == 54 && k >= 0 && trk[0].lock[k].val == 54 && lock_count(&trk[0]) == 1u,
              "REC lock: a second turn on the same step overwrites that lock");
        check(undo_swap(0) && !memcmp(none, trk[0].lock, sizeof none), "REC lock: EDIT + OCT- undo takes it back");
        check(undo_swap(1) && lock_find(&trk[0], s1, P_ATK, 0) >= 0, "REC lock: redo brings it again");
        locks_restore(&trk[0]); trk[0].p[P_ATK] = 7;
        lock_step(&trk[0], s1);
        check(trk[0].p[P_ATK] == 54, "REC lock: captured value plays back");
        lock_step(&trk[0], (s1 + 1u) % trk_len(&trk[0]));
        check(trk[0].p[P_ATK] == 7, "REC lock: playback restores the unlocked base");
        memcpy(before, trk[0].lock, sizeof before);
        open_family(FAM_SEQ); frame(); open_family(FAM_SEQ); frames(16);
        check(cur_page()->id[1] == P_SDIV && !p_lockable(P_SDIV), "REC lock: the PATTERN page (DIV, not lockable)");
        KN(1, 1); KN(1, -1);
        check(!memcmp(before, trk[0].lock, sizeof before), "REC lock: a pattern knob writes no lock");
        PAGE("DLY");
        gv = song.g[G_DTIME]; KN(0, gv < GP[G_DTIME].max ? 1 : -1);
        check(cur_page()->scope == SC_GLOBAL && song.g[G_DTIME] != gv && !memcmp(before, trk[0].lock, sizeof before),
              "REC lock: a global knob edits, no lock");
        song.g[G_DTIME] = gv;
        transport_req = 2; frames(8);
        PAGE("ENV");
        song.rec = 1u; trk[0].p[P_DEC] = 30; KN(1, 1);
        check(!song.playing && trk[0].p[P_DEC] == 31 && !memcmp(before, trk[0].lock, sizeof before),
              "REC lock: stopped: the knob edits, no lock");
        song.rec = 0; transport_req = 1; frames(8);
        locks_clear(&trk[0]);
        for (i = 0; i < NLOCK; i++) lock_set(&trk[0], i, P_CHOR, 10);
        memcpy(before, trk[0].lock, sizeof before);
        song.rec = 1u; ui.msg[0] = 0; trk[0].p[P_DEC] = 30; frames(5); KN(1, 1);
        check(lock_count(&trk[0]) == NLOCK && trk[0].p[P_DEC] == 31 && !strcmp(ui.msg, "NO LOCK LEFT") &&
              !memcmp(before, trk[0].lock, sizeof before), "REC lock: every slot used: NO LOCK LEFT, the table unchanged");
        song.rec = 0; transport_req = 2; frames(8);
        locks_clear(&trk[0]);
        memcpy(trk[0].p, keep, sizeof keep);
        song.g[G_BPM] = bpm; ui.msg[0] = 0;
        memcpy(ui.fam_last, fam_keep, sizeof fam_keep);
        go_home(); frames(16);
        #undef PAGE
        #undef KN
    }

    {   /* 2.6, after Felucca 1.4 / 1.5 (Leo Kuroshita): STEP LEN, SEQ VEL, the drum mutes (EDIT + a black key), MIDI
         * LEARN (GLO + F#3, a knob, a CC; LEARN CLEAR in the menu), the INSERT pages (the drum track too), ANALOG's FILTER */
        uint32_t j, w, ins_d = 0, flt_a = 0, flt_o = 0;
        #define K(n, v) do { encs[panel.enc[n]] = (v); frames(5); } while (0)
        #define WALK(fa_, ti_, hit_) do { open_family(fa_); frame(); \
            for (j = 0; j < 12u; j++) { encs[panel.enc[EN_SELECT]] = -1; frame(); } \
            for (j = 0; j < 12u; j++) { if (PAGES[ui.page].fam == (fa_) && !strcmp(PAGES[ui.page].title, ti_)) hit_ = 1; \
                encs[panel.enc[EN_SELECT]] = 1; frame(); } } while (0)
        song.playing = 0;
        song.sel = 0; steps_clear(&trk[0]); trk[0].p[P_SLEN] = 16; go_home(); frames(16);
        press(B_SEQ); frames(10);
        key(7);                                           /* step 5 */
        fm1_in.notes = 1u << 7; frame();
        w = step_vel_shown(&trk[0].step[4]);
        K(EN_K2, 1);
        check(trk[0].step[4].vel == w + 1u && !trk[0].step[4].lvl, "SEQ: step 5 held + KNOB 2: its velocity one up (VEL)");
        ui.force = 1; frame(); ppm("layer-steps-vel");
        fm1_in.notes = 0; frame(); release(B_SEQ); frames(16);
        open_family(FAM_SEQ); frame();
        check(!strcmp(PAGES[ui.page].title, "STEP"), "SEQ: the STEP page first");
        ui.cursor = 4; ui.force = 1; frame();
        K(EN_K3, 1); K(EN_K3, 1);
        check(note_len(&trk[0], 4) == 3u && trk[0].step[5].time == ST_TIE && trk[0].step[6].time == ST_TIE &&
              trk[0].step[7].time != ST_TIE, "STEP page, KNOB 3 on a note: LEN 1 -> 3 (two TIEs after it)");
        ui.force = 1; frame(); ppm("page-step-len");
        K(EN_K3, -1);
        check(note_len(&trk[0], 4) == 2u && trk[0].step[6].time == ST_REST, "KNOB 3 back: LEN 2 (its last TIE a REST)");
        trk[0].step[5].n = 1, trk[0].step[5].note[0] = 64;   /* a TIE holding a note (TIME, or an older SLOOP) */
        K(EN_K3, -1);
        check(note_len(&trk[0], 4) == 1u && trk[0].step[5].time == ST_REST && trk[0].step[5].n == 1u &&
              trk[0].step[5].note[0] == 64u, "LEN shorter over a TIE holding a note: a REST, the note kept (as TIME)");
        go_home(); frames(16);
        press(B_EDIT); frames(10);
        edges_btn |= BT(B_OCTDN); fm1_in.buttons |= BT(B_OCTDN); frame(); fm1_in.buttons &= ~BT(B_OCTDN); frame();
        release(B_EDIT); frames(4);
        check(note_len(&trk[0], 4) == 1u && trk[0].step[5].n == 0u && trk[0].step[4].n == 1u,
              "EDIT + OCT-: the LEN turns on that step undone at once (the steps as before the first)");
        {   /* 2.6: the STEP page takes a MIDI keyboard's notes as the keys (a YouTube comment): the notes played together
             * (CH 1 = track 1, selected) the cursor step, all let go: on to the next; the SEQ layer's pen too; a note for
             * another track (stopped): which track it plays, nothing written; off the page: nothing written */
            #define MIN(c, n, v) (midi_in_q[mi_w++ % MQ] = ((v) ? 0x09u | (0x90u | (c)) << 8 : 0x08u | (0x80u | (c)) << 8) | \
                                  (uint32_t)(n) << 16 | (uint32_t)(v) << 24)
            step_t s9;
            uint32_t k9;
            int16_t v0 = trk[0].p[P_VOICE];
            open_family(FAM_SEQ); frame();
            trk[0].p[P_VOICE] = V_POLY;
            ui.cursor = 8; memset(&trk[0].step[8], 0, sizeof trk[0].step[8]); ui.force = 1; frame();
            MIN(0, 50, 100); MIN(0, 54, 90); frame();
            check(trk[0].step[8].n == 2u && trk[0].step[8].note[0] == 50u && trk[0].step[8].note[1] == 54u &&
                  trk[0].step[8].time == ST_NOTE && ui.cursor == 8u, "STEP page: two MIDI notes held (CH 1): step 9 the chord");
            check(pen_n == 2u && pen_note[0] == 50u && pen_note[1] == 54u, "  and the SEQ layer's pen: that chord");
            MIN(0, 50, 0); frame();
            check(ui.cursor == 8u, "  one let go: still on step 9");
            MIN(0, 54, 0); frame();
            check(ui.cursor == 9u, "  both let go: on to step 10");
            MIN(0, 62, 100); MIN(0, 62, 0); frame();
            check(trk[0].step[9].n == 1u && trk[0].step[9].note[0] == 62u && ui.cursor == 10u && pen_n == 1u && pen_note[0] == 62u,
                  "  a MIDI note tapped (on and off in one frame): step 10, on to step 11; the pen that note");
            fm1_in.notes = 1u << 7; frame(); MIN(0, 67, 100); frame(); fm1_in.notes = 0; frame();
            check(ui.cursor == 10u && trk[0].step[10].n == 2u && trk[0].step[10].note[1] == 67u,
                  "  a key and a MIDI note together: one step; the MIDI note still held: no move");
            MIN(0, 67, 0); frame();
            check(ui.cursor == 11u, "  let go: on");
            s9 = trk[0].step[11]; ui.msg[0] = 0;
            MIN(1, 70, 100); MIN(1, 70, 0); frame();
            check(!memcmp(&s9, &trk[0].step[11], sizeof s9) && ui.cursor == 11u && !strcmp(ui.msg, "MIDI PLAYS TRACK 2"),
                  "  a note on CH 2 (track 2's): nothing written, \"MIDI PLAYS TRACK 2\"");
            go_home(); frame();
            s9 = trk[0].step[11];
            MIN(0, 72, 100); frame(); MIN(0, 72, 0); frame();
            check(!memcmp(&s9, &trk[0].step[11], sizeof s9) && step_in_r == step_in_w, "  off the STEP page: nothing written, the queue read");
            ui.msg[0] = 0; song.rec = 1;                  /* (2.6) recording track 1: a keyboard on track 2's channel */
            MIN(1, 60, 100); MIN(1, 60, 0); frame();
            check(!strcmp(ui.msg, "MIDI PLAYS TRACK 2"), "REC on track 1, a MIDI note on CH 2: \"MIDI PLAYS TRACK 2\" (not recorded)");
            ui.msg[0] = 0;
            MIN(1, 62, 100); MIN(1, 62, 0); frame();
            check(!ui.msg[0], "  said once a take (an external sequencer on track 2 does not flash it)");
            song.rec = 0; frame(); song.rec = 1; ui.msg[0] = 0;   /* a new take; the keyboard on track 1's channel */
            MIN(0, 60, 100); MIN(0, 60, 0); frame();
            MIN(1, 62, 100); MIN(1, 62, 0); frame();
            check(!ui.msg[0], "  a new take, a note on CH 1 (track 1's) first: no message, even with CH 2 after");
            song.rec = 0; ui.msg[0] = 0;
            for (k9 = 0; k9 < NSTEP; k9++) if (trk[0].step[k9].time == ST_NOTE && trk[0].step[k9].note[0] == 60) { trk[0].step[k9].time = ST_REST; trk[0].step[k9].n = 0; }
            trk[0].p[P_VOICE] = v0;
            #undef MIN
        }
        {   /* 2.6, after Felucca 1.5.1: MIDI Program Change (queued by seq.c, loaded here) and FX + OCT- / OCT+: the THROWs */
            uint8_t e0 = trk[1].eng_req, p0 = trk[1].preset;
            int16_t k0 = TDRUM->p[P_E0];
            uint32_t k, tot = NBANK + up_count();
            go_home(); frame();
            pc_req[1] = 1;                                /* PC 0 on track 2's channel: the first sound of the list */
            frame();
            check(trk[1].eng_req == BANK[0].e && trk[1].preset == bank_pi[0] && !strncmp(ui.msg, "T2 PROG 0", 9),
                  "MIDI Program Change 0: track 2 takes the first sound of the PRESETS list (T2 PROG 0)");
            pc_req[3] = 3;                                /* PC 2 on the drum channel: kit 2 */
            frame();
            check(TDRUM->p[P_E0] == 2, "MIDI Program Change on the drum channel: kit 2");
            pc_req[1] = (uint8_t)(tot + 1u);              /* past the end: nothing */
            k = trk[1].eng_req;
            frame();
            check(trk[1].eng_req == k && trk[1].preset == bank_pi[0], "MIDI Program Change past the list: ignored (no wrap)");
            TDRUM->p[P_E0] = k0;
            set_engine_of(&trk[1], e0); apply_preset_to(&trk[1], p0); trk[1].engine = trk[1].eng_req;
            frames(4);
            press(B_FX); frames(10);
            fm1_in.buttons |= BT(B_OCTDN); edges_btn |= BT(B_OCTDN); frame(); frame();
            k = thr_req;
            ui.force = 1; frame(); ppm("layer-fx-throw");
            fm1_in.buttons &= ~BT(B_OCTDN); frame();
            fm1_in.buttons |= BT(B_OCTUP); edges_btn |= BT(B_OCTUP); frame(); frame();
            check(k == 1u && thr_req == 2u && !strcmp(sub_line(), "echo throw"), "FX + OCT-: REV THROW while held, FX + OCT+: ECHO THROW");
            fm1_in.buttons &= ~BT(B_OCTUP); frame();
            release(B_FX); frames(4);
            check(thr_req == 0u && song.octave == 0, "  let go: no THROW, the octave untouched");
        }
        steps_clear(&trk[0]); go_home(); frames(16);
        {   /* SEQ: two steps held + KNOB 2: both one up (the turn accelerated once, not once a step) */
            uint32_t v0, v1;
            song.sel = 0; trk[0].p[P_SLEN] = 16; go_home(); frames(16);
            press(B_SEQ); frames(10);
            key(0); key(7);
            fm1_in.notes = 1u << 0 | 1u << 7; frame();
            v0 = step_vel_shown(&trk[0].step[0]), v1 = step_vel_shown(&trk[0].step[4]);
            K(EN_K2, 1);
            check(trk[0].step[0].vel == v0 + 1u && trk[0].step[4].vel == v1 + 1u, "SEQ: two steps held + KNOB 2: both one up");
            fm1_in.notes = 0; frame(); release(B_SEQ); frames(16);
            steps_clear(&trk[0]); go_home(); frames(16);
        }

        song.sel = TRK_DRUM; go_home(); frames(16);
        dstep_set(&TDRUM->dstep[0], 0, LV_NORM, 0);
        press(B_EDIT); frames(10);
        key(1);                                           /* a black key: mute mode */
        check(er_mute == 1u, "EDIT + a black key (drum track): MUTE mode");
        key(0);                                           /* the kick's key */
        check(drum_mute == 1u && dstep_has(&TDRUM->dstep[0], 0), "MUTE mode + the kick's key: the kick muted, its steps kept");
        ui.force = 1; frame(); ppm("layer-erase-mute");
        key(0);
        check(drum_mute == 0u, "the kick's key again: unmuted");
        key(0);
        release(B_EDIT); frames(2);
        check(er_mute == 0u && drum_mute == 1u, "EDIT let go: out of MUTE mode, the mute stays");
        drum_mute = 0;
        TDRUM->dstep[0] = (dstep_t){0};
        WALK(FAM_FX, "INSERT", ins_d);
        check(ins_d, "the drum track: the INSERT page in FX");
        go_home(); frames(16);

        song.sel = 0; set_engine_of(&trk[0], 0); trk[0].engine = trk[0].eng_req; go_home(); frame();
        WALK(FAM_EDIT, "FILTER", flt_a);
        open_family(FAM_EDIT); frame();
        for (j = 0; j < 30u && strcmp(PAGES[ui.page].title, "FILTER"); j++) { encs[panel.enc[EN_SELECT]] = 1; frame(); }
        ui.force = 1; frame(); ppm("page-filter");
        {   /* on EDIT > FILTER, ALGORITHM to a track that is not ANALOG: not left on a page it does not have */
            int16_t bpm0 = song.g[G_BPM];
            encs[panel.enc[EN_ALGO]] = 1; frames(2);
            check(song.sel == 1u && trk[1].eng_req != 0u && PAGES[ui.page].fam == FAM_EDIT &&
                  strcmp(PAGES[ui.page].title, "FILTER") && page_shown(cur_page()),
                  "EDIT > FILTER, then a track that is not ANALOG: the page before (EDIT 2), not FILTER");
            encs[panel.enc[EN_SELECT]] = 1; frame();
            check(song.g[G_BPM] == bpm0, "  and SELECT turns pages there, not the tempo");
            song.sel = 0; go_home(); frame();
        }
        set_engine_of(&trk[0], 1); trk[0].engine = trk[0].eng_req; go_home(); frame();
        WALK(FAM_EDIT, "FILTER", flt_o);
        check(flt_a && !flt_o, "EDIT: the FILTER page (TYPE) with ANALOG only");
        set_engine_of(&trk[0], TRK_DEF[0][0]); apply_preset_to(&trk[0], TRK_DEF[0][1]); trk[0].engine = trk[0].eng_req;
        go_home(); frames(16);

        for (w = 0; w < ML_N; w++) ml_tab[w] = 0;
        press(B_GLO); frames(10);
        key(1);                                           /* F#3 */
        release(B_GLO); frames(16);
        check(mlu.on == 1u && !mlu.pick, "GLO + F#3: MIDI LEARN on");
        open_family(FAM_FX); frame();
        for (j = 0; j < 12u; j++) { encs[panel.enc[EN_SELECT]] = -1; frame(); }   /* the FX page: KNOB 1 = DIST */
        frames(16);
        ui.force = 1; frame(); ppm("header-learn");
        K(EN_K1, 1);
        check(mlu.pick && mlu.id == P_DIST && mlu.trk == 0u && ml_arm, "LEARN: a knob turned picks its parameter (DIST)");
        midi_cc(&trk[0], 74, 10); frame();
        check(ml_count() == 1u && (ml_tab[0] & 127u) == 74u && (ml_tab[0] >> 9) == ml_code(P_DIST) && !mlu.pick,
              "LEARN: a CC sent: CC 74 = track 1 DIST");
        go_home(); frames(16);
        press(B_GLO); frames(10); key(1); release(B_GLO); frames(4);
        check(!mlu.on, "GLO + F#3 again: LEARN off");
        midi_cc(&trk[1], 74, 127);
        check(trk[0].p[P_DIST] == TP[P_DIST].max, "CC 74 (any channel): track 1's DIST to its top");
        trk[0].p[P_DIST] = 0;
        ui.menu = 1; ui.menu_sel = 0; ui.force = 1; frame();
        for (j = 0; j < 6u; j++) { encs[panel.enc[EN_SELECT]] = 1; frame(); }
        encs[panel.enc[EN_K2]] = 1; frame();
        tap(B_OCTUP);
        check(ui.menu_sel == MI_LCLEAR && ml_count() == 0u, "menu SYSTEM > MIDI LEARN CLEAR, OCT+: nothing learned any more");
        ui.menu = 0; ui.force = 1; go_home(); frames(16);
        {   /* GLO > MIDI: CH1 CH2 CH3 OTHER (2.6) */
            uint32_t hit = 0;
            WALK(FAM_GLO, "MIDI", hit);
            open_family(FAM_GLO); frame();
            for (j = 0; j < 12u && strcmp(PAGES[ui.page].title, "MIDI"); j++) { encs[panel.enc[EN_SELECT]] = 1; frame(); }
            frames(16);
            K(EN_K2, 9);                                  /* CH2: 2 -> 11 */
            check(hit && !strcmp(PAGES[ui.page].title, "MIDI") && song.g[G_CH2] == 11, "GLO > MIDI: the page, KNOB 2 sets track 2's channel (11)");
            ui.force = 1; frame(); ppm("page-midi");
            {   /* 2.6: every MIDI setting in MIDI and MIDI 2; no channel on two tracks */
                const page_t *m = cur_page(), *m2 = &PAGES[ui.page + 1u];
                const char *u;
                char vv[12];
                param_format(&GP[G_DRCH], 0, vv, &u);
                check(m->id[0] == G_CH1 && m->id[1] == G_CH2 && m->id[2] == G_CH3 && m->id[3] == G_DRCH && !strcmp(m2->title, "MIDI 2") &&
                      m2->id[0] == G_ROUTE && m2->id[1] == G_CHOTH && m2->id[2] == G_MIDI && m2->id[3] == G_BEND &&
                      !strcmp(GP[G_DRCH].label, "CH4") && !strcmp(vv, "OFF"),
                      "GLO > MIDI: CH1 CH2 CH3 CH4 (the drums); MIDI 2: IN OTHER OUT BEND; CH4 0 reads OFF");
                song.g[G_CH2] = 2, frame();
                K(EN_K2, 1);                              /* CH2 2 -> 3: track 3's: on to 4 */
                check(song.g[G_CH2] == 4 && !strcmp(ui.msg, "CH 3 = TRACK 3"), "GLO > MIDI: CH2 turned onto track 3's channel: on to 4, \"CH 3 = TRACK 3\"");
                K(EN_K2, -1);                             /* back: 3 taken, on to 2 */
                check(song.g[G_CH2] == 2, "  turned back: over 3 again, to 2");
                K(EN_K4, -7);                             /* DR CH 10 -> 3: track 3's, then 2, 1 (taken): OFF */
                check(song.g[G_DRCH] == 0, "  the drums turned down onto 3, 2, 1 (all taken): OFF");
                song.g[G_DRCH] = 10, frame();
                song.g[G_ROUTE] = 6;                      /* IN = CH 5 */
                go_home(); frame();
                open_family(FAM_GLO); frame();
                for (j = 0; j < 12u && strcmp(PAGES[ui.page].title, "MIDI"); j++) { encs[panel.enc[EN_SELECT]] = 1; frame(); }
                check(!strcmp(ui.msg, "IN CH 5: SEL TRK ONLY"), "GLO > MIDI with IN = CH 5: says the channels are set aside");
                song.g[G_ROUTE] = 0;
            }
            song.g[G_CH2] = 2;
            go_home(); frames(16);
        }
        {   /* GLO > TEXTURE, TEXTURE 2 (2.6) */
            uint32_t h1 = 0, h2 = 0;
            WALK(FAM_GLO, "TEXTURE", h1);
            WALK(FAM_GLO, "TEXTURE 2", h2);
            open_family(FAM_GLO); frame();
            for (j = 0; j < 12u && strcmp(PAGES[ui.page].title, "TEXTURE"); j++) { encs[panel.enc[EN_SELECT]] = 1; frame(); }
            frames(16);
            K(EN_K1, 1);                                  /* SRC: OFF -> VINYL */
            check(h1 && h2 && song.g[G_TXSRC] == 1, "GLO > TEXTURE, TEXTURE 2: the pages; KNOB 1 the source (VINYL)");
            ui.force = 1; frame(); ppm("page-texture");
            song.g[G_TXSRC] = 0;
            go_home(); frames(16);
        }
        #undef K
        #undef WALK
    }

    {   /* 2.6 (a YouTube comment): SAVE > PROJECT, KNOB 2 ERASE, a GO button: one detent arms (AGAIN: ERASE), a second
         * one erases the slot KNOB 1 picks; a turn to the left does nothing */
        uint32_t i, e0 = erases;
        song.playing = 0;
        go_home(); frame();
        for (i = 0; i < NPAGES; i++) if (!strcmp(PAGES[i].title, "PROJECT")) break;
        open_family(PAGES[i].fam); ui.page = (uint8_t)i; ui.fam_last[PAGES[i].fam] = (uint8_t)i; page_entered(); ui.force = 1; frame();
        check(PAGES[ui.page].graph == GR_SLOTS && PAGES[ui.page].id[1] == 0xFFu, "SAVE > PROJECT: KNOB 2 free for ERASE (no parameter)");
        song.g[G_SLOT] = 2;
        encs[panel.enc[EN_K2]] = -1; frames(2);
        check(erases == e0 && ui.arm != 0xE8u, "PROJECT, KNOB 2 left: nothing");
        encs[panel.enc[EN_K2]] = 1; frames(2);
        check(erases == e0 && ui.arm == 0xE8u && !strcmp(ui.msg, "AGAIN: ERASE"), "PROJECT, KNOB 2 one detent: AGAIN: ERASE, nothing erased");
        ui.force = 1; frame(); ppm("page-project-erase");
        encs[panel.enc[EN_K2]] = 1; frames(2);
        check(erases == e0 + 1u && !ui.arm && !strcmp(ui.msg, "ERASED"), "PROJECT, KNOB 2 again: the slot erased");
        encs[panel.enc[EN_K2]] = 1; frames(100);
        encs[panel.enc[EN_K2]] = 1; frames(2);
        check(erases == e0 + 1u && ui.arm == 0xE8u, "  the arm runs out (~1.5 s): a detent after it arms again");
        ui.arm = 0; song.g[G_SLOT] = 1;
        go_home(); frames(4);
    }
    {   /* Review regressions: REC routing, failed automation, drum edits and visible state. */
        uint32_t i, mode;
        settings.palette = 5; palette_set(5);
        for (mode = 0; mode < 2u; mode++) {
            song.playing = song.rec = 0; rec_wait = ft_on = ci_on = 0;
            ft_closed = 0;                               /* independent cases, not the preceding take's 300ms close guard */
            for (i = 0; i < NTRK; i++) steps_clear(&trk[i]);
            if (mode) trk[0].step[0] = (step_t){.note={60}, .n=1, .time=ST_NOTE, .vel=100};
            rec_tempo = (uint8_t)mode; rec_count = 0;
            song.sel = TRK_DRUM; studio_open(SC_DRUM); drum_page = 0; drum_lane = drum_cursor = 0;
            frames(8); tap(B_REC); key(0);
            check(!rec_wait && (mode ? (song.playing && (song.rec & (1u << TRK_DRUM))) : (ft_on && !kb_grid)),
                  "GRID REC: the first key starts a tempo/free take, not a step edit");
            if (ft_on || song.playing) tap(B_PLAY);
            if (rec_wait || song.rec) tap(B_REC);
            frames(8);
        }
        song.playing = song.rec = 0; rec_wait = ft_on = ci_on = 0;
        song.sel = 0; steps_clear(&trk[0]); trk[0].p[P_SLEN] = 64; open_family(FAM_ENV);
        for (i = 0; i < NPAGES; i++)
            if (PAGES[i].fam == FAM_ENV && PAGES[i].id[0] == P_ATK) ui.page = (uint8_t)i;
        for (i = 0; i < NLOCK; i++) lock_set(&trk[0], i, P_ATK, 31);
        trk[0].step[0] = (step_t){.note={60}, .n=1, .time=ST_NOTE, .vel=100};
        undo_mark(&trk[0], 888); trk[0].step[0].note[0] = 64;
        song.playing = 1; rec_begin(); trk[0].seq_idx = 32; trk[0].p[P_ATK] = 10;
        {
            plock_t before[NLOCK]; uint32_t sess = undo.sess;
            memcpy(before, trk[0].lock, sizeof before); edit_param(0, 1);
            check(undo.sess == sess && !memcmp(before, trk[0].lock, sizeof before),
                  "REC full locks: failed insertion preserves the preceding Undo and locks");
            check(undo_swap(0) && trk[0].step[0].note[0] == 60,
                  "REC full locks: the preceding pattern edit remains undoable");
        }
        trk[0].seq_idx = 0; edit_param(0, 1);
        {
            int at = lock_find(&trk[0], 0, P_ATK, 0);
            check(undo.sess == UNDO_REC(&trk[0]) && at >= 0 && trk[0].lock[at].val == trk[0].p[P_ATK],
                  "REC full locks: overwriting an existing entry still records and marks Undo");
        }
        locks_clear(&trk[0]);
        for (i = 0; i < NPAGES; i++) if (PAGES[i].fam == FAM_SEQ && PAGES[i].id[3] == P_SGATE) break;
        ui.page = (uint8_t)i; trk[0].p[P_SGATE] = 70;
        for (i = 0; i < 4u; i++) edit_param(i, 1);
        check(lock_find(&trk[0], 0, P_SGATE, 0) < 0, "REC: all PATTERN controls, including GATE, stay unrecorded");
        song.playing = song.rec = 0; song.sel = TRK_DRUM;
        studio_open(SC_DRUM); drum_page = 0; drum_lane = drum_cursor = 0;
        for (mode = 0; mode < 2u; mode++) {
            steps_clear(TDRUM); TDRUM->p[P_SLEN] = 16; ui.step_sess = 0; undo.valid = 0;
            dstep_set(&TDRUM->dstep[0], 0, LV_NORM, 0);
            TDRUM->micro[0] = 7; step_fill_set(TDRUM, 0, FC_FILL); lock_set(TDRUM, 0, P_TFLT, 31);
            if (!mode) grid_key(0);
            else { encs[panel.enc[EN_K3]] = -1; drum_screen_input(0, BT_NONE); }
            check(!dstep_mask(&TDRUM->dstep[0]) && !TDRUM->micro[0] && !step_fill(TDRUM, 0) &&
                  lock_find(TDRUM, 0, P_TFLT, 0) < 0, "GRID white/K3: last-hit deletion clears the same metadata");
            check(undo_swap(0) && dstep_has(&TDRUM->dstep[0], 0) && TDRUM->micro[0] == 7 &&
                  step_fill(TDRUM, 0) == FC_FILL && lock_find(TDRUM, 0, P_TFLT, 0) >= 0,
                  "GRID white/K3: Undo restores the hit and all metadata");
        }
        steps_clear(TDRUM); drum_lane = drum_cursor = 0; frames(2);
        fm1_in.notes = (1u << 0) | (1u << 3); frame(); fm1_in.notes = 0; frame();
        check(drum_lane == 2 && dstep_has(&TDRUM->dstep[0], 2) && !dstep_has(&TDRUM->dstep[0], 0),
              "GRID same scan: voice selection precedes a lower white key");
        steps_clear(TDRUM); drum_lane = 2; frames(2);
        fm1_in.notes = (1u << 1) | (1u << 26); frame(); fm1_in.notes = 0; frame();
        check(drum_lane == 0 && dstep_has(&TDRUM->dstep[15], 0) && !dstep_has(&TDRUM->dstep[15], 2),
              "GRID same scan: voice selection also precedes a higher white key");
        steps_clear(TDRUM); drum_lane = 0;
        lk_push(KB_GRID, 0, 1); lk_push(KB_GRID, 0, 0); lk_push(KB_GRID, 0, 1); lk_push(KB_GRID, 3, 1); frame();
        check(drum_lane == 2 && !dstep_mask(&TDRUM->dstep[0]),
              "GRID same batch: repeated step presses are not collapsed");
        steps_clear(TDRUM); drum_lane = 0; drum_cursor = 0; aud_lanes = 0;
        grid_key(0);
        check(dstep_has(&TDRUM->dstep[0], 0) && aud_lanes == 0u,
              "GRID white key: the hit is set silently (heard only from the playhead)");
        grid_key(PUNCH_BLACK[1]);
        check(drum_lane == GRID_LANE[1] && aud_lanes == 1u << GRID_LANE[1],
              "GRID black key: selects the voice and auditions it");
        aud_lanes = 0; drum_lane = 0; drum_cursor = 0;
        encs[panel.enc[EN_K1]] = 1; drum_screen_input(0, BT_NONE);
        encs[panel.enc[EN_K2]] = 1; drum_screen_input(0, BT_NONE);
        check(drum_lane == 1 && drum_cursor == 1 && aud_lanes == 0u,
              "GRID KNOB 1 / KNOB 2: the voice and the step move silently");
        song.playing = 1; TDRUM->seq_idx = 1; ui.msg_t = 0; ui.force = 1; ui_draw();
        {
            uint16_t header[240 * 24];
            memcpy(header, screen, sizeof header);
            song.rec = 1u << TRK_DRUM; ui_draw();
            check(memcmp(header, screen, sizeof header) && swap16(screen[9u * 240u + 196u]) == TE_RED,
                  "GRID: REC state redraws a persistent red indicator");
        }
        ppm("review-grid-rec");
        song.sel = 0; song.rec = 0; studio_open(SC_TRK); ui.msg_t = 0; ui.force = 1; ui_draw();
        {
            uint16_t header[240 * 36];
            memcpy(header, screen, sizeof header);
            song.rec = 1; ui_draw();
            check(memcmp(header, screen, sizeof header), "Mixer: REC redraws its live-only header without other changes");
        }
        ppm("review-mixer-rec");
        song.playing = song.rec = 0; ui.msg_t = 0;
        song.sel = TRK_DRUM; open_family(FAM_ENV); frame(); tap(B_HOME); tap(B_EDIT);
        check(on_drum_page(), "Drum help: HOME then EDIT reaches the supported drum editor");
        arrangement.count = 1; arrangement.entry[0].scene = 0; arrangement.entry[0].bars = 64;
        arrangement_clock.running = 1; arrangement_clock.index = 0; arrangement_clock.bar = 63;
        song_cursor = 0; studio_open(SC_SONG); ui.force = 1; ui_draw(); ppm("review-song-64");
        {
            uint32_t x, y, clear = 1;
            for (y = 47; y < 64u; y++) for (x = 235; x < 240u; x++)
                clear &= swap16(screen[y * 240u + x]) == C_BLACK;
            check(clear, "SONG 64 bars: the label and playing marker leave the right edge clear");
        }
        arrangement_clock.running = arrangement_enabled = 0; arr_defaults(&arrangement);
        fm1_in.notes = fm1_in.buttons = 0; song.sel = 0; go_home(); frames(8);
    }
    {   /* fuzz: 20000 frames of random buttons (held or tapped), knobs and keys, with the audio running
         * between frames; every draw stays on the screen (lcd_blit / lcd_fill assert it) */
        uint32_t f, seed = 777, held = 0;
        #define R(n) ((seed = seed * 1664525u + 1013904223u) >> 8) % (n)
        song.sel = 0; go_home(); ui.force = 1;
        for (f = 0; f < 20000u; f++) {
            if (R(6) == 0) {
                uint32_t bt = R(NB);
                edges_btn |= 1u << panel.btn[bt];
                if (bt != B_HOME && R(3) == 0) held ^= 1u << panel.btn[bt];
            }
            if (R(30) == 0) held = 0;
            if (R(700) == 0) ly_lock = (uint8_t)R(LY_COUNT);              /* (a layer locked open, at random) */
            fm1_in.buttons = held & ~(1u << panel.btn[B_HOME]);
            if (R(4) == 0) {
                uint32_t e = R(7);
                int32_t delta = (int32_t)R(5) - 2;
                encs[e] += delta;
            }
            fm1_in.notes = R(10) == 0 ? (1u << R(27)) : (R(3) ? fm1_in.notes : 0);
            frame();
            if (ui.menu) { ui.menu = 0; ui.force = 1; }               /* (the menu is tested above) */
        }
        fm1_in.buttons = 0; fm1_in.notes = 0; frames(4);
        #undef R
    }
    printf("ui: %s\n", fails ? "FAILED" : "pages, layers (punch, steps, erase, roll, key, mix), layer lock, song layer, REC hold, drums, REC, 20000-frame fuzz PASS");
    return fails;
}
#endif
