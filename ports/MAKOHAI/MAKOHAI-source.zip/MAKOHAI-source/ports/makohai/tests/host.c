/* SPDX-License-Identifier: GPL-3.0-only */
/* A fake FM-1 on a computer: the app (firmware/src/makohai.c) runs unchanged on it. platform.c includes
 * this file instead of the hardware when DINGHY_HOST is set. A script presses keys over time; out come
 * the screen (PPM, at the times SHOT asks) and the sound (WAV, as the FM-1 sends it over USB).
 *
 *   mkdir -p build/host
 *   cc -O2 -Wall -DDINGHY_HOST -Ifirmware/src -Ifirmware/gen -o build/host/makohai firmware/src/makohai.c
 *   build/host/makohai build/host/makohai        (-> build/host/makohai.wav, build/host/makohai-<ms>.ppm)
 *   build/host/makohai OUT script.txt [FPS]    (your own script; with FPS: OUT-NNNNN.ppm, a frame every 1/FPS s:
 *                                             a film of your firmware, e.g. ffmpeg -r 30 -i OUT-%05d.ppm ...)
 *
 * Change SCRIPT below to try your own app. */
#include <stdint.h>

#ifndef APP_NAME
#define APP_NAME "MAKOHAI"
#endif
#ifndef APP_VER
#define APP_VER "0.0"
#endif
#define FS 44100u
#define RING_PUBLISH() __asm__ volatile("" ::: "memory")
#define HALF_FRAMES 256u

static volatile uint32_t fm1_ms;
static struct { uint32_t notes, buttons; } fm1_in;
/* teensy-fm1: the panel and the screen are the Teensy's */
static uint32_t din_press, din_rel, din_nedge, din_px;
static int32_t din_enc[8];
static uint8_t din_led[64], din_glow[64];
static uint32_t fm1_input_edges(uint32_t *released) { uint32_t b = din_press; din_press = 0; if (released) *released = din_rel; din_rel = 0; return b; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = din_nedge; din_nedge = 0; return e; }
static int32_t fm1_enc_take(uint32_t e) { int32_t v = din_enc[e & 7u]; din_enc[e & 7u] = 0; return v; }
static void fm1_led_key(uint32_t id, int on) { din_led[id & 63u] = (uint8_t)!!on; }
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            sh_put(j * 240u + i, sh_be16(c));
    din_px += w * h;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            sh_put((y + j) * 240u + x + i, px[j * w + i]);      /* (gfx.c's pixels are high byte first already) */
    din_px += w * h;
}

static uint32_t host_edges, host_rel, host_notes_prev;
static int32_t host_enc[7];



#define FM1_TICKS_PER_US 24u
static uint32_t fm1_ticks(void) { struct timespec ts; clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts); return (uint32_t)(ts.tv_sec * 24000000ull + (uint64_t)ts.tv_nsec * 24u / 1000u); }

static void fm1_glow_all(void) { }
static void fm1_glow_none(void) { }
typedef struct { uint32_t stack_free, stack_size, irq_free, irq_size, ram_free, pool_free, known; } sysmem_t;
static void sys_mem(sysmem_t *m) { m->known = 0; }   /* no FM-1 memory map here */
static uint32_t sys_seed(void) { return 0x1234567u; }   /* host mode stays repeatable */

/* the screen: 240 x 240 RGB565, as the ST7789 gets it (gfx.c sends the bytes swapped) */
#define fb shl_fb



#define CV_MAX (240u * 64u)
#include "gfx.c"

static uint8_t host_store[256 + 4];
static int settings_load(void *p, uint32_t n)
{
    if (host_store[0] != 1 || n > 256u) return -1;
    memcpy(p, host_store + 4, n);
    return 0;
}
static int settings_save(const void *p, uint32_t n)
{
    if (n > sizeof host_store - 4u) return -1;   /* teensy-fm1 */
    host_store[0] = 1;
    memcpy(host_store + 4, p, n);
    printf("%6u ms  settings saved (%u B)\n", fm1_ms, n);
    return 0;
}

static uint8_t mq[64][3];
static uint32_t mq_w, mq_r;
static int midi_get(uint8_t *st, uint8_t *d1, uint8_t *d2)
{
    if (mq_r == mq_w) return 0;
    *st = mq[mq_r % 64u][0]; *d1 = mq[mq_r % 64u][1]; *d2 = mq[mq_r % 64u][2];
    mq_r++;
    return 1;
}
static uint32_t host_midi_out, host_mo_note, host_mo_cc, host_mo_clk, host_mo_bend, host_mo_vel[128], host_mo_rt;
static void midi_isr_send(uint32_t st, uint32_t d1, uint32_t d2)   /* counted by kind (the stats at the end) */
{
    host_midi_out++;
    if ((st & 0xF0u) == 0x90u && d2) { host_mo_note++; host_mo_vel[d2 & 127u]++; }
    else if ((st & 0xF0u) == 0xB0u) host_mo_cc++;
    else if ((st & 0xF0u) == 0xE0u) host_mo_bend++;
    else if (st == 0xF8u) host_mo_clk++;
    else if (st >= 0xF2u) host_mo_rt++;
    (void)d1;
}
static uint32_t midi_out_room(void) { return 64u; }
static uint32_t clk_now(void) { return fm1_ms * 1000u * FM1_TICKS_PER_US; }   /* the clock in's time base: the script's ms */
static volatile uint32_t clk_in_t[32], clk_in_w;            /* the clock in's ticks, stamped as they come */
#define LONGS_LEN 0x25000u                         /* the own parts' store, in memory (it starts erased) */
#define FL_IN(off, n, lo, hi) ((uint32_t)(off) >= (lo) && (uint32_t)(off) <= (hi) && (uint32_t)(n) <= (hi) - (uint32_t)(off))
static uint8_t host_longs[LONGS_LEN];
static int host_longs_init;
static void host_longs_erased(void) { if (!host_longs_init) { memset(host_longs, 0xFF, sizeof host_longs); host_longs_init = 1; } }
static int longs_erase(uint32_t off) { host_longs_erased(); if ((off & 0xFFFu) || !FL_IN(off, 0x1000u, 0, LONGS_LEN)) return -8; memset(host_longs + off, 0xFF, 0x1000u); return 0; }
static int longs_write(uint32_t off, const void *p, uint32_t n) { host_longs_erased(); if (!FL_IN(off, n, 0, LONGS_LEN)) return -8; memcpy(host_longs + off, p, n); return 0; }
#define SLOTS_LEN 0x1000u
static uint8_t host_slots[SLOTS_LEN];
static int slots_erase(void) { memset(host_slots, 0xFF, sizeof host_slots); return 0; }
static int slots_write(uint32_t off, const void *p, uint32_t n) { if (!FL_IN(off, n, 0, SLOTS_LEN)) return -8; memcpy(host_slots + off, p, n); return 0; }
static int slots_read(uint32_t off, void *p, uint32_t n) { if (!FL_IN(off, n, 0, SLOTS_LEN)) return -8; memcpy(p, host_slots + off, n); return 0; }
static int longs_read(uint32_t off, void *p, uint32_t n) { host_longs_erased(); if (!FL_IN(off, n, 0, LONGS_LEN)) return -8; memcpy(p, host_longs + off, n); return 0; }

static void app_audio(int32_t *out, uint32_t n);
static void app_main(void);
