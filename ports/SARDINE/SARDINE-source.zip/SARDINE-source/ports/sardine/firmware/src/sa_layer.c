/* SPDX-License-Identifier: GPL-3.0-only */
/* SARDINE layer engine (sa_layer.h): the patterns, the modifiers as transforms of time spans, the arpeggiator, the
 * chords, and the bar's notes played in time. */
#include "sa_layer.h"

#if TUNA_FREESTANDING                             /* the FM-1 has no C library: Felucca's libc.c has these */
#include <stddef.h>
void *memcpy(void *d, const void *s, size_t n);
void *memset(void *d, int c, size_t n);
int memcmp(const void *a, const void *b, size_t n);
#else
#include <string.h>
#endif

static int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }
static int32_t fdiv(int32_t a, int32_t b) { return a >= 0 ? a / b : -((-a + b - 1) / b); }   /* floor, b > 0 */
static uint32_t hash2(uint32_t a, uint32_t b)
{
    uint32_t h = a * 2654435761u ^ (b + 0x9E3779B9u + (a << 6) + (a >> 2));
    h ^= h >> 15;
    h *= 2246822519u;
    h ^= h >> 13;
    return h;
}
static void cpy(char *d, const char *s, int n)
{
    int i = 0;
    for (; s[i] && i + 1 < n; ++i) d[i] = s[i];
    if (n > 0) d[i] = 0;
}
static void cat(char *d, const char *s, int n)
{
    int k = 0;
    while (d[k]) ++k;
    cpy(d + k, s, n - k);
}
static void fmt_int(char *d, int v)
{
    char b[12];
    int k = 0, neg = v < 0;
    unsigned u = neg ? (unsigned)-v : (unsigned)v;
    do { b[k++] = (char)('0' + u % 10); u /= 10; } while (u && k < 11);
    int j = 0;
    if (neg) d[j++] = '-';
    while (k) d[j++] = b[--k];
    d[j] = 0;
}

/* ---- names ---------------------------------------------------------------------------------------------------- */
static const char *const NOTE_NAMES[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
const char *sa_note_name(int pc) { return NOTE_NAMES[((pc % 12) + 12) % 12]; }
static const char *const SCALE_NAMES[SA_SCALES] = {"MINOR", "DORIAN", "PHRYGIAN", "MAJOR"};
const char *sa_scale_name(int sc) { return SCALE_NAMES[clampi(sc, 0, SA_SCALES - 1)]; }
static const uint8_t SCALE[SA_SCALES][7] = {
    {0, 2, 3, 5, 7, 8, 10}, {0, 2, 3, 5, 7, 9, 10}, {0, 1, 3, 5, 7, 8, 10}, {0, 2, 4, 5, 7, 9, 11}};
static const char *const KIT_NAMES[SA_KITS] = {"TECH", "HOUSE", "DEEP", "HARD", "BOOM", "TIGHT", "AFRO", "DUSTY",
                                               "CLASSIC", "ROOM", "VINTAGE", "MINIMAL", "VOLT", "GARAGE", "DISCO",
                                               "BREAKS", "DUB", "LOFI", "IRON", "ACID", "HYPNO", "RUMBLE", "PUNCH", "SOFT"};
const char *sa_kit_name(int kit) { return KIT_NAMES[clampi(kit, 0, SA_KITS - 1)]; }
static const char *const DV_NAMES[SA_DVS] = {"KICK", "SNARE", "CLAP", "HAT", "OPEN HAT", "RIDE", "CRASH", "RIM",
                                             "TOM", "LOW TOM", "CONGA", "COWBELL", "CLAVE", "SHAKER", "TAMB",
                                             "BONGO", "WOOD", "CABASA", "ZAP"};
/* their notes: General MIDI's; the PERC row's on Sardine's own notes 82..87 (eng_drum.c SA_PERC: the drum engine's
 * percussion on the PERC row's channel; RIDE and CRASH, never offered, play the tambourine) */
static const uint8_t DV_GM[SA_DVS] = {36, 38, 39, 42, 46, 82, 82, 37, 45, 41, 63, 85, 75, 70, 82, 83, 84, 86, 87};
const char *sa_dv_name(int dv) { return DV_NAMES[clampi(dv, 0, SA_DVS - 1)]; }
/* the drums -> their rows (the drum engine's channels: the shaker is a closed hat, the conga a tom, the clave a rim;
 * PERC: tambourine, bongo, wood block, cowbell, cabasa, zap, on its own channel) */
static const uint8_t DV_ROW[SA_DVS] = {SA_DR_KICK, SA_DR_SNARE, SA_DR_CLAP, SA_DR_HATS, SA_DR_HATS, SA_DR_PERC,
                                       SA_DR_PERC, SA_DR_RIM, SA_DR_TOMS, SA_DR_TOMS, SA_DR_TOMS, SA_DR_PERC,
                                       SA_DR_RIM, SA_DR_HATS, SA_DR_PERC, SA_DR_PERC, SA_DR_PERC, SA_DR_PERC,
                                       SA_DR_PERC};
static const uint8_t ROW_DEF[SA_DROWS] = {SA_DV_KICK, SA_DV_SNARE, SA_DV_CLAP, SA_DV_HAT, SA_DV_TOM, SA_DV_RIM,
                                          SA_DV_TAMB};
static const char *const ROW_NAMES[SA_DROWS] = {"KICK", "SNARE", "CLAP", "HATS", "TOMS", "RIM", "PERC"};
int sa_dv_row(int dv) { return DV_ROW[clampi(dv, 0, SA_DVS - 1)]; }
static const char *const DVAR_NAMES[SA_DVARS] = {"", "TIGHT", "ROOM", "HIGH", "LOW", "80", "10", "DEEP"};
static const char *const CLAP_NAMES[SA_DVARS] = {"", "TIGHT", "ROOM", "HIGH", "LOW", "80", "77", "DEEP"};
static const char *const PERC_NAMES[SA_DVARS] = {"", "TIGHT", "ROOM", "HIGH", "LOW", "DARK", "BRIGHT", "DEEP"};
const char *sa_dvar_name(int row, int v)
{
    return (row == SA_DR_CLAP ? CLAP_NAMES : row == SA_DR_PERC ? PERC_NAMES : DVAR_NAMES)[clampi(v, 0, SA_DVARS - 1)];
}
const char *sa_row_name(int row) { return ROW_NAMES[clampi(row, 0, SA_DROWS - 1)]; }
int sa_row_voices(int row, uint8_t *out)
{
    int n = 0;
    for (int v = 0; v < SA_DVS; ++v)
        if (DV_ROW[v] == row && v != SA_DV_RIDE && v != SA_DV_CRASH) out[n++] = (uint8_t)v;   /* (no ride nor crash) */
    return n;
}
uint8_t sa_dv_gm(int dv) { return DV_GM[clampi(dv, 0, SA_DVS - 1)]; }
static const char *const ARP_NAMES[SA_AR_MODES] = {"OFF", "UP", "DOWN", "UP-DOWN", "DOWN-UP", "CONVERGE", "DIVERGE",
                                                   "RANDOM", "THUMB", "PINKY", "STRUM"};
const char *sa_arp_name(int m) { return ARP_NAMES[clampi(m, 0, SA_AR_MODES - 1)]; }
static const char *const RATE_NAMES[SA_RATES] = {"1/4", "1/8", "1/8 T", "1/16", "1/16 T", "1/32"};
static const uint8_t RATE_TICKS[SA_RATES] = {24, 12, 8, 6, 4, 3};
const char *sa_rate_name(int r) { return RATE_NAMES[clampi(r, 0, SA_RATES - 1)]; }

/* ---- the chord progressions: scale degrees (0 = the key's chord), each lasting BARS ---- */
static const struct { uint8_t n, deg[4]; } PROG[SA_PROGS] = {
    {1, {0}},          /* ONE CHORD */
    {2, {0, 5}},       /* i  VI */
    {2, {0, 3}},       /* i  iv */
    {2, {0, 6}},       /* i  VII */
    {4, {0, 6, 5, 6}}, /* i  VII  VI  VII */
    {4, {0, 4, 5, 3}}, /* i  v  VI  iv */
    {4, {0, 2, 6, 5}}, /* i  III  VII  VI */
    {2, {0, 1}},       /* i  ii */
    {4, {5, 6, 0, 0}}, /* VI  VII  i  i */
    {4, {0, 3, 6, 2}}, /* i  iv  VII  III */
};
static const char *const ROMAN[7] = {"I", "II", "III", "IV", "V", "VI", "VII"};
static bool deg_minor(int sc, int d)
{
    int r = SCALE[sc][d % 7], t = SCALE[sc][(d + 2) % 7];
    return ((t - r + 12) % 12) == 3;
}
void sa_prog_name(int p, char *out, int max)
{
    p = clampi(p, 0, SA_PROGS - 1);
    out[0] = 0;
    if (PROG[p].n == 1) {
        cpy(out, "ONE CHORD", max);
        return;
    }
    for (int i = 0; i < PROG[p].n; ++i) {
        int d = PROG[p].deg[i];
        char r[8];
        cpy(r, ROMAN[d], sizeof r);
        if (deg_minor(SA_SC_MINOR, d))             /* minor chords in small letters (named as in the minor key) */
            for (char *c = r; *c; ++c) *c = (char)(*c - 'A' + 'a');
        if (i) cat(out, "-", max);
        cat(out, r, max);
    }
}

/* ---- the patterns ---------------------------------------------------------------------------------------------- */
/* a drum hit: its tick in the bar, its velocity */
typedef struct { uint8_t t, v; } dstep;
typedef struct { const char *name; uint8_t n; dstep s[24]; } dpat;
#define X(i) {(uint8_t)((i) * SA_TPS), 110}
#define A(i) {(uint8_t)((i) * SA_TPS), 127}
#define G(i) {(uint8_t)((i) * SA_TPS), 70}
#define T8(i) {(uint8_t)((i) * 8), 110}
static const dpat DPAT[] = {
    {"4 FLOOR", 4, {A(0), X(4), A(8), X(12)}},
    {"OFFBEAT", 4, {X(2), X(6), X(10), X(14)}},
    {"2 + 4", 2, {A(4), A(12)}},
    {"8THS", 8, {A(0), G(2), X(4), G(2 + 4), A(8), G(10), X(12), G(14)}},
    {"16THS", 16, {A(0), G(1), X(2), G(3), A(4), G(5), X(6), G(7), A(8), G(9), X(10), G(11), A(12), G(13), X(14),
                   G(15)}},
    {"SKIP", 8, {X(2), G(3), X(6), G(7), X(10), G(11), X(14), G(15)}},
    {"GALLOP", 12, {A(0), G(2), X(3), A(4), G(6), X(7), A(8), G(10), X(11), A(12), G(14), X(15)}},
    {"PUSH", 5, {A(0), X(4), A(8), X(12), G(14)}},
    {"2-STEP", 2, {A(0), X(10)}},
    {"BROKEN", 3, {A(0), X(7), X(10)}},
    {"CLAVE", 5, {X(0), X(3), X(6), X(10), X(12)}},
    {"TRESILLO", 6, {A(0), X(3), X(6), A(8), X(11), X(14)}},
    {"ROLL END", 7, {X(0), X(4), X(8), G(12), X(13), A(14), A(15)}},
    {"TRIPLET", 12, {T8(0), T8(1), T8(2), T8(3), T8(4), T8(5), T8(6), T8(7), T8(8), T8(9), T8(10), T8(11)}},
    {"SHUFFLE", 8, {T8(0), T8(2), T8(3), T8(5), T8(6), T8(8), T8(9), T8(11)}},
    {"BELL 12", 7, {T8(0), T8(2), T8(4), T8(5), T8(7), T8(9), T8(11)}},
    {"SPARSE", 2, {X(0), G(11)}},
    {"SYNCO", 4, {X(3), X(6), X(11), X(14)}},
    {"HALF", 2, {A(0), X(8)}},
    {"ONE", 1, {A(0)}},
    {"BREAK", 5, {A(0), X(4), X(10), A(12), G(15)}},
    {"LAST BEAT", 4, {X(12), X(13), A(14), A(15)}},
    {"SHAKE", 16, {G(0), G(1), X(2), G(3), G(4), G(5), X(6), G(7), G(8), G(9), X(10), G(11), G(12), G(13), X(14),
                   G(15)}},
    {"UPBEATS", 6, {X(1), X(5), X(7), X(9), X(13), X(15)}},
};
#undef X
#undef A
#undef G
#undef T8
#define NDPAT ((int)(sizeof DPAT / sizeof DPAT[0]))

/* a synth step: tick, length (ticks), tone (0 root 1 third 2 fifth 3 seventh 4 the root an octave up, SA_CH the
 * chord), octave offset, velocity */
typedef struct { uint8_t t, d, tone; int8_t oct; uint8_t v; } sstep;
/* (0.8.43) a melody's note: its tick from the melody's start (over 2 or 4 bars), length (ticks), tone (a chord tone, or
 * SA_STEP(k): k steps up the scale from the chord's root), velocity */
typedef struct { uint16_t t; uint8_t d, tone, v; } mstep;
#define SA_STEP0 40                                 /* (tones from SA_STEP0 - 20: scale steps, SA_STEP0 the root) */
#define SA_STEP(k) ((uint8_t)(SA_STEP0 + (k)))
typedef struct { const char *name; int8_t oct; uint8_t n; sstep s[16]; } spat;
typedef struct { const mstep *m; uint8_t n, bars; } smel;   /* a melody: its notes over `bars` bars */
#define N(i, len, tone, o, v) {(uint8_t)((i) * SA_TPS), (uint8_t)((len) * SA_TPS / 2), (tone), (o), (v)}
/* (len in eighth-sixteenths: 2 = one sixteenth) */
/* (0.8.43) MELODIES: lead lines over 2 or 4 bars, a call and its answer, in scale steps from the chord's root (0 the
 * root, 2 the third, 4 the fifth, 7 the octave; the others passing notes), so they move with the chords and stay in
 * the key. M(sixteenth, sixteenths long, step): on the beat louder */
#define M(i, len, k) {(uint16_t)((i) * SA_TPS), (uint8_t)((len) * SA_TPS), SA_STEP(k), (uint8_t)((i) % 4 == 0 ? 110 : 95)}
static const mstep MEL_SKYLINE[] = {M(0, 6, 4), M(6, 2, 5), M(8, 4, 4), M(12, 4, 2), M(16, 6, 7), M(22, 2, 6),
                                    M(24, 8, 4), M(32, 6, 4), M(38, 2, 5), M(40, 4, 4), M(44, 4, 7), M(48, 4, 9),
                                    M(52, 4, 7), M(56, 8, 4)};
static const mstep MEL_SIGH[] = {M(0, 3, 2), M(3, 3, 1), M(6, 10, 0), M(16, 3, 4), M(19, 3, 3), M(22, 6, 2),
                                 M(28, 4, 1)};
static const mstep MEL_LADDER[] = {M(0, 2, 0), M(2, 2, 1), M(4, 2, 2), M(6, 2, 3), M(8, 4, 4), M(12, 4, 2),
                                   M(16, 2, 4), M(18, 2, 3), M(20, 2, 2), M(22, 2, 1), M(24, 8, 0)};
static const mstep MEL_ANSWER[] = {M(0, 2, 4), M(3, 2, 4), M(6, 4, 5), M(10, 6, 4), M(20, 2, 2), M(22, 2, 3),
                                   M(24, 8, 2), M(32, 2, 4), M(35, 2, 4), M(38, 4, 5), M(42, 6, 7), M(52, 2, 6),
                                   M(54, 2, 5), M(56, 8, 4)};
static const mstep MEL_SWING[] = {M(2, 2, 7), M(6, 2, 7), M(8, 2, 6), M(10, 4, 4), M(14, 2, 2), M(18, 2, 4),
                                  M(22, 2, 5), M(24, 3, 4), M(27, 3, 2), M(30, 2, 0)};
static const mstep MEL_LONG[] = {M(0, 24, 4), M(24, 8, 2), M(32, 24, 1), M(56, 8, 0)};
static const mstep MEL_PULSE[] = {M(0, 2, 0), M(2, 2, 7), M(4, 2, 0), M(6, 2, 6), M(8, 2, 0), M(10, 2, 4), M(12, 2, 0),
                                  M(14, 2, 3), M(16, 2, 0), M(18, 2, 7), M(20, 2, 0), M(22, 2, 6), M(24, 2, 0),
                                  M(26, 2, 4), M(28, 2, 5), M(30, 2, 4)};
static const mstep MEL_FLOAT[] = {M(0, 6, 4), M(10, 6, 2), M(24, 8, 1)};
static const mstep MEL_RISE[] = {M(0, 2, 0), M(2, 2, 2), M(4, 2, 4), M(6, 2, 7), M(8, 6, 6), M(14, 2, 4), M(16, 2, 5),
                                 M(18, 2, 4), M(20, 2, 2), M(22, 2, 4), M(24, 8, 4), M(32, 2, 0), M(34, 2, 2),
                                 M(36, 2, 4), M(38, 2, 7), M(40, 6, 9), M(46, 2, 7), M(48, 4, 8), M(52, 4, 7),
                                 M(56, 8, 7)};
static const mstep MEL_QUESTION[] = {M(0, 3, 4), M(3, 3, 2), M(8, 2, 4), M(11, 3, 5), M(16, 3, 4), M(19, 3, 2),
                                     M(22, 2, 1), M(26, 6, 0)};
static const mstep MEL_GLIDE[] = {M(0, 4, 0), M(4, 2, 2), M(6, 6, -1), M(12, 4, 0), M(16, 4, 7), M(20, 2, 6),
                                  M(22, 4, 4), M(26, 6, 2)};
static const mstep MEL_BIRD[] = {M(0, 2, 7), M(2, 2, 6), M(4, 2, 7), M(6, 4, 4), M(12, 2, 5), M(14, 2, 4),
                                 M(16, 6, 2), M(22, 2, 3), M(24, 2, 2), M(26, 6, 0)};
static const mstep MEL_ELECTRIC[] = {M(0, 1, 0), M(2, 1, 0), M(3, 2, 2), M(6, 1, 4), M(8, 2, 7), M(11, 2, 4),
                                     M(14, 2, 2), M(16, 1, 0), M(18, 1, 0), M(19, 2, 2), M(22, 1, 4), M(24, 4, 6),
                                     M(28, 4, 4)};
static const mstep MEL_DREAM[] = {M(0, 4, 2), M(6, 2, 4), M(8, 8, 5), M(20, 2, 4), M(22, 2, 2), M(24, 8, 1),
                                  M(32, 4, 2), M(38, 2, 4), M(40, 8, 7), M(52, 2, 6), M(54, 2, 5), M(56, 8, 4)};
static const mstep MEL_HYMN[] = {M(0, 4, 7), M(4, 4, 7), M(8, 4, 6), M(12, 4, 4), M(16, 6, 5), M(22, 2, 4),
                                 M(24, 8, 2)};
static const mstep MEL_HEART[] = {M(0, 2, 4), M(7, 2, 2), M(16, 2, 4), M(19, 2, 5), M(22, 4, 4)};
#undef M
#define MEL(m, bars) {(m), (uint8_t)(sizeof(m) / sizeof(m)[0]), (bars)}
static const smel MELS[] = {MEL(MEL_SKYLINE, 4), MEL(MEL_SIGH, 2), MEL(MEL_LADDER, 2), MEL(MEL_ANSWER, 4),
                            MEL(MEL_SWING, 2), MEL(MEL_LONG, 4), MEL(MEL_PULSE, 2), MEL(MEL_FLOAT, 2),
                            MEL(MEL_RISE, 4), MEL(MEL_QUESTION, 2), MEL(MEL_GLIDE, 2), MEL(MEL_BIRD, 2),
                            MEL(MEL_ELECTRIC, 2), MEL(MEL_DREAM, 4), MEL(MEL_HYMN, 2), MEL(MEL_HEART, 2)};
#undef MEL
#define NMEL ((int)(sizeof MELS / sizeof MELS[0]))
#define MEL(name) {(name), 5, 0, {{0, 0, 0, 0, 0}}}   /* (SPAT's last NMEL: the melodies, in MELS's order) */
static const spat SPAT[] = {
    /* bass lines (octave 2) */
    {"OFFBEAT", 2, 4, {N(2, 3, 0, 0, 110), N(6, 3, 0, 0, 100), N(10, 3, 0, 0, 110), N(14, 3, 0, 0, 100)}},
    {"ROLLER", 2, 8, {N(2, 1, 0, 0, 110), N(3, 1, 0, 0, 80), N(6, 1, 0, 0, 110), N(7, 1, 4, 0, 80),
                      N(10, 1, 0, 0, 110), N(11, 1, 0, 0, 80), N(14, 1, 0, 0, 110), N(15, 1, 2, 0, 80)}},
    {"ROOT 8THS", 2, 8, {N(0, 2, 0, 0, 115), N(2, 2, 0, 0, 90), N(4, 2, 0, 0, 105), N(6, 2, 0, 0, 90), N(8, 2, 0, 0, 115),
                         N(10, 2, 0, 0, 90), N(12, 2, 0, 0, 105), N(14, 2, 0, 0, 90)}},
    {"OCTAVE", 2, 8, {N(0, 2, 0, 0, 115), N(2, 2, 4, 0, 95), N(4, 2, 0, 0, 105), N(6, 2, 4, 0, 95), N(8, 2, 0, 0, 115),
                      N(10, 2, 4, 0, 95), N(12, 2, 0, 0, 105), N(14, 2, 4, 0, 95)}},
    {"PUMP 16", 2, 16, {N(0, 1, 0, 0, 120), N(1, 1, 0, 0, 70), N(2, 1, 0, 0, 95), N(3, 1, 0, 0, 70), N(4, 1, 0, 0, 115),
                        N(5, 1, 0, 0, 70), N(6, 1, 0, 0, 95), N(7, 1, 0, 0, 70), N(8, 1, 0, 0, 120), N(9, 1, 0, 0, 70),
                        N(10, 1, 0, 0, 95), N(11, 1, 0, 0, 70), N(12, 1, 0, 0, 115), N(13, 1, 0, 0, 70),
                        N(14, 1, 0, 0, 95), N(15, 1, 0, 0, 70)}},
    {"SYNCO", 2, 5, {N(0, 3, 0, 0, 115), N(3, 2, 0, 0, 100), N(6, 2, 2, 0, 100), N(10, 3, 0, 0, 110),
                     N(13, 2, 4, 0, 95)}},
    {"SUB HOLD", 2, 1, {N(0, 32, 0, 0, 110)}},
    {"HALF", 2, 2, {N(0, 15, 0, 0, 115), N(8, 15, 2, 0, 105)}},
    {"ACID", 2, 8, {N(0, 2, 0, 0, 120), N(2, 1, 0, 0, 90), N(3, 2, 4, 0, 110), N(6, 2, 2, 0, 100), N(8, 2, 0, 0, 120),
                    N(10, 1, 3, 0, 95), N(11, 2, 0, 0, 100), N(14, 2, 4, 0, 115)}},
    {"GROWL", 2, 5, {N(0, 4, 0, 0, 120), N(4, 4, 0, 0, 110), N(7, 2, 0, 0, 100), N(10, 3, 2, 0, 110),
                     N(12, 7, 0, 0, 115)}},
    {"2-STEP", 2, 4, {N(0, 3, 0, 0, 120), N(6, 2, 0, 0, 100), N(10, 3, 2, 0, 110), N(11, 2, 0, 0, 90)}},
    {"WALK", 2, 4, {N(0, 7, 0, 0, 115), N(4, 7, 1, 0, 100), N(8, 7, 2, 0, 105), N(12, 7, 4, 0, 100)}},
    /* chords (octave 4) */
    {"STAB 1", 4, 1, {N(3, 2, SA_CH, 0, 110)}},
    {"STAB 2", 4, 2, {N(3, 2, SA_CH, 0, 110), N(10, 2, SA_CH, 0, 100)}},
    {"OFFBEATS", 4, 4, {N(2, 2, SA_CH, 0, 105), N(6, 2, SA_CH, 0, 100), N(10, 2, SA_CH, 0, 105),
                        N(14, 2, SA_CH, 0, 100)}},
    {"HOUSE", 4, 5, {N(2, 2, SA_CH, 0, 105), N(5, 2, SA_CH, 0, 95), N(8, 2, SA_CH, 0, 110), N(10, 2, SA_CH, 0, 95),
                     N(13, 2, SA_CH, 0, 100)}},
    {"CHARLESTON", 4, 2, {N(0, 3, SA_CH, 0, 115), N(6, 3, SA_CH, 0, 105)}},
    {"DOWNBEAT", 4, 1, {N(0, 4, SA_CH, 0, 115)}},
    {"PUSH", 4, 2, {N(0, 3, SA_CH, 0, 110), N(14, 3, SA_CH, 0, 100)}},
    {"DOTTED", 4, 5, {N(0, 2, SA_CH, 0, 110), N(3, 2, SA_CH, 0, 100), N(6, 2, SA_CH, 0, 105), N(9, 2, SA_CH, 0, 100),
                      N(12, 2, SA_CH, 0, 105)}},
    /* pads (octave 4) */
    {"WASH", 4, 1, {N(0, 32, SA_CH, 0, 100)}},
    {"TWO HALVES", 4, 2, {N(0, 15, SA_CH, 0, 100), N(8, 15, SA_CH, 0, 95)}},
    {"SWELL", 4, 1, {N(4, 24, SA_CH, 0, 95)}},
    /* leads and arp sources (octave 5) */
    {"TONES UP", 5, 4, {N(0, 7, 0, 0, 105), N(4, 7, 1, 0, 100), N(8, 7, 2, 0, 105), N(12, 7, 4, 0, 100)}},
    {"RIFF", 5, 5, {N(0, 2, 0, 0, 110), N(3, 2, 2, 0, 100), N(6, 2, 4, 0, 105), N(10, 2, 2, 0, 100), N(14, 2, 1, 0, 95)}},
    {"PLUCKS", 5, 8, {N(0, 1, 0, 0, 110), N(2, 1, 2, 0, 90), N(4, 1, 4, 0, 105), N(6, 1, 2, 0, 90), N(8, 1, 1, 0, 105),
                      N(10, 1, 2, 0, 90), N(12, 1, 4, 0, 105), N(14, 1, 2, 0, 90)}},
    {"CALL", 5, 4, {N(0, 4, 2, 0, 110), N(3, 2, 4, 0, 100), N(6, 4, 2, 0, 105), N(12, 6, 1, 0, 100)}},
    {"HOLD NOTE", 5, 1, {N(0, 32, 0, 0, 105)}},
    {"HOLD CHORD", 5, 1, {N(0, 32, SA_CH, 0, 100)}},
    /* (0.8.23) more lead lines, for the styles: after the others (a saved layer keeps its pattern) */
    {"HOOK", 5, 7, {N(0, 2, 4, 0, 110), N(2, 2, 2, 0, 95), N(4, 3, 0, 0, 105), N(7, 2, 1, 0, 95), N(8, 2, 2, 0, 105),
                    N(11, 2, 1, 0, 95), N(12, 4, 0, 0, 100)}},
    {"ECHOES", 5, 3, {N(0, 3, 0, 0, 110), N(6, 3, 2, 0, 95), N(11, 3, 4, 0, 100)}},
    {"BLIPS", 5, 3, {N(2, 1, 4, 0, 105), N(7, 1, 2, 0, 90), N(13, 1, 4, 0, 100)}},
    {"ANTHEM", 5, 16, {N(0, 1, 0, 0, 115), N(1, 1, 0, 0, 80), N(2, 1, 4, 0, 100), N(3, 1, 0, 0, 80),
                       N(4, 1, 2, 0, 105), N(5, 1, 0, 0, 80), N(6, 1, 4, 0, 100), N(7, 1, 0, 0, 80),
                       N(8, 1, 1, 0, 110), N(9, 1, 0, 0, 80), N(10, 1, 4, 0, 100), N(11, 1, 0, 0, 80),
                       N(12, 1, 2, 0, 105), N(13, 1, 0, 0, 80), N(14, 1, 4, 0, 100), N(15, 1, 2, 0, 85)}},
    {"SQUELCH", 5, 8, {N(0, 2, 0, 0, 120), N(2, 1, 0, 1, 90), N(3, 2, 3, 0, 105), N(6, 2, 2, 0, 100),
                       N(8, 1, 0, 0, 115), N(9, 1, 4, 0, 90), N(11, 2, 1, 0, 100), N(14, 2, 2, 1, 110)}},
    {"DISCO RUN", 5, 8, {N(0, 1, 0, 0, 110), N(2, 1, 4, 0, 95), N(4, 1, 2, 0, 105), N(6, 1, 4, 0, 95),
                         N(8, 1, 1, 0, 110), N(10, 1, 4, 0, 95), N(12, 1, 2, 0, 105), N(14, 1, 4, 0, 95)}},
    {"TWO NOTES", 5, 2, {N(0, 15, 0, 0, 105), N(8, 15, 2, 0, 100)}},
    {"UPBEATS", 5, 4, {N(2, 1, 0, 0, 105), N(6, 1, 2, 0, 95), N(10, 1, 0, 0, 105), N(14, 1, 4, 0, 95)}},
    /* (0.8.24) the RAVE sounds' line: sixteenths hammering the root, up to the fifth and the octave at the end */
    {"RATTLE", 5, 16, {N(0, 1, 0, 0, 120), N(1, 1, 0, 0, 90), N(2, 1, 0, 0, 100), N(3, 1, 0, 0, 90),
                       N(4, 1, 0, 0, 115), N(5, 1, 0, 0, 90), N(6, 1, 0, 0, 100), N(7, 1, 0, 0, 90),
                       N(8, 1, 0, 0, 115), N(9, 1, 0, 0, 90), N(10, 1, 0, 0, 100), N(11, 1, 0, 0, 90),
                       N(12, 1, 2, 0, 115), N(13, 1, 2, 0, 95), N(14, 1, 4, 0, 115), N(15, 1, 4, 0, 95)}},
    /* (0.8.43) MELODIES, over 2 or 4 bars */
    MEL("SKYLINE"), MEL("SIGH"), MEL("LADDER"), MEL("ANSWER"), MEL("SWING HOOK"), MEL("LONG TONES"),
    MEL("PULSE RIFF"), MEL("FLOAT"), MEL("RISE"), MEL("QUESTION"), MEL("GLIDE"), MEL("NIGHT BIRD"), MEL("ELECTRIC"),
    MEL("DREAM"), MEL("SAW HYMN"), MEL("HEARTBEAT"),
};
#undef MEL
#undef N
#define NSPAT ((int)(sizeof SPAT / sizeof SPAT[0]))
static const smel *mel_of(int pat)                 /* a synth pattern's melody, 0: a bar of steps */
{
    int i = pat % NSPAT - (NSPAT - NMEL);
    return i >= 0 && i < NMEL ? &MELS[i] : 0;
}
int sa_drum_pats(void) { return NDPAT; }
int sa_synth_pats(void) { return NSPAT; }
const char *sa_pat_name(int type, int i)
{
    return type == SA_T_DRUM ? DPAT[clampi(i, 0, NDPAT - 1)].name : SPAT[clampi(i, 0, NSPAT - 1)].name;
}

/* ---- the modifiers: one flat list, grouped by type, for ALGORITHM to turn through ---- */
typedef struct { uint8_t type, lo, hi; } mrange;   /* values lo..hi (the meaning per type: below) */
static const mrange MODS[] = {
    {SA_M_OFF, 0, 0},
    {SA_M_FAST, 2, 4},                             /* x2 x3 x4 */
    {SA_M_SLOW, 2, 4},                             /* /2 /3 /4 */
    {SA_M_REV, 0, 0},
    {SA_M_EVERY, 2, 8},                            /* every n bars: reversed (2..8) */
    {SA_M_THIN, 1, 9},                             /* 10 .. 90 % of the notes left out */
    {SA_M_EUCLID, 1, 15},                          /* k hits spread over 16 */
    {SA_M_SHIFT, 0, 15},                           /* by -8 .. +7 sixteenths (val - 8, 0 left out) */
    {SA_M_LEN, 3, 15},                             /* the first n sixteenths, looped */
    {SA_M_OCT, 0, 4},                              /* -2 .. +2 (val - 2, 0 left out), synth layers */
    {SA_M_PLY, 2, 4},                              /* each note n times */
};
#define NMODR ((int)(sizeof MODS / sizeof MODS[0]))
static bool mod_skip(int type, int mt, int v)
{
    if (mt == SA_M_SHIFT && v == 8) return true;
    if (mt == SA_M_OCT && (v == 2 || type != SA_T_SYNTH)) return true;
    return false;
}
int sa_mod_opts(int type)
{
    int n = 0;
    for (int r = 0; r < NMODR; ++r)
        for (int v = MODS[r].lo; v <= MODS[r].hi; ++v)
            n += !mod_skip(type, MODS[r].type, v);
    return n;
}
sa_mod sa_mod_opt(int type, int i)
{
    int n = 0;
    for (int r = 0; r < NMODR; ++r)
        for (int v = MODS[r].lo; v <= MODS[r].hi; ++v) {
            if (mod_skip(type, MODS[r].type, v)) continue;
            if (n++ == i) {
                sa_mod m = {MODS[r].type, (uint8_t)v};
                return m;
            }
        }
    sa_mod off = {SA_M_OFF, 0};
    return off;
}
int sa_mod_index(int type, sa_mod m)
{
    int n = sa_mod_opts(type);
    for (int i = 0; i < n; ++i) {
        sa_mod o = sa_mod_opt(type, i);
        if (o.type == m.type && (o.val == m.val || m.type == SA_M_OFF || m.type == SA_M_REV)) return i;
    }
    return 0;
}
void sa_mod_name(sa_mod m, char *out, int max)
{
    char a[8];
    out[0] = 0;
    switch (m.type) {
    case SA_M_FAST: cpy(out, "FAST ", max); fmt_int(a, m.val); cat(out, a, max); break;
    case SA_M_SLOW: cpy(out, "SLOW ", max); fmt_int(a, m.val); cat(out, a, max); break;
    case SA_M_REV: cpy(out, "REV", max); break;
    case SA_M_EVERY: cpy(out, "EVERY ", max); fmt_int(a, m.val); cat(out, a, max); cat(out, ": REV", max); break;
    case SA_M_THIN: cpy(out, "THIN ", max); fmt_int(a, m.val * 10); cat(out, a, max); cat(out, "%", max); break;
    case SA_M_EUCLID: cpy(out, "EUCLID ", max); fmt_int(a, m.val); cat(out, a, max); cat(out, "/16", max); break;
    case SA_M_SHIFT:
        cpy(out, "SHIFT ", max);
        if (m.val > 8) cat(out, "+", max);
        fmt_int(a, (int)m.val - 8);
        cat(out, a, max);
        break;
    case SA_M_LEN: cpy(out, "LEN ", max); fmt_int(a, m.val); cat(out, a, max); break;
    case SA_M_OCT:
        cpy(out, "OCT ", max);
        if (m.val > 2) cat(out, "+", max);
        fmt_int(a, (int)m.val - 2);
        cat(out, a, max);
        break;
    case SA_M_PLY: cpy(out, "PLY ", max); fmt_int(a, m.val); cat(out, a, max); break;
    default: cpy(out, "OFF", max); break;
    }
}

/* ---- the query: a layer's notes over a span of ticks, the modifiers applied from the last one in (each one asks
 * the ones before it for the span it needs). One set of buffers, one per depth: the audio's bar line and the
 * screen's preview never run at once (the glue holds the audio off for the preview) ---- */
typedef struct { int32_t t; uint8_t d, tone, v; int8_t oct, n; } qev;   /* n: an own note (tone SA_NOTE) */
#define SA_NOTE 10                                 /* a query note's tone: an own pattern's note, n above the key */
#define QMAX 64
static qev QB[SA_MODS + 1][QMAX];
static int QN[SA_MODS + 1];
static qev QT[QMAX];                               /* a transform's inner result, copied out of the deeper buffer */

static void qadd(int k, int32_t t, int d, int tone, int oct, int v, int n)
{
    if (QN[k] >= QMAX) return;
    qev *e = &QB[k][QN[k]++];
    e->t = t;
    e->d = (uint8_t)clampi(d, 1, 255);
    e->tone = (uint8_t)tone;
    e->oct = (int8_t)clampi(oct, -4, 4);
    e->v = (uint8_t)clampi(v, 1, 127);
    e->n = (int8_t)n;
}

/* the active modifiers of a code, in order */
static int active_mods(const sa_code *c, sa_mod *out)
{
    int n = 0;
    for (int i = 0; i < SA_MODS; ++i)
        if (c->mod[i].type != SA_M_OFF && c->mod[i].type < SA_M_TYPES) out[n++] = c->mod[i];
    return n;
}

static void query(const sa_code *c, const sa_mod *m, int k, int layer, int32_t a, int32_t b);

/* the inner (depth k - 1) result over [a, b), copied to QT; its count */
static int inner(const sa_code *c, const sa_mod *m, int k, int layer, int32_t a, int32_t b)
{
    query(c, m, k - 1, layer, a, b);
    int n = QN[k - 1];
    memcpy(QT, QB[k - 1], (size_t)n * sizeof(qev));
    return n;
}

static void query(const sa_code *c, const sa_mod *m, int k, int layer, int32_t a, int32_t b)
{
    QN[k] = 0;
    if (b <= a) return;
    if (k == 0) {                                  /* the pattern itself, a bar long, over and over */
        for (int32_t cy = fdiv(a, SA_TPB); cy <= fdiv(b - 1, SA_TPB); ++cy) {
            if (c->own) {                          /* the layer's own: its sixteenths */
                for (int i = 0; i < 16; ++i) {
                    int32_t t = cy * SA_TPB + i * SA_TPS;
                    if (t < a || t >= b) continue;
                    int v = (c->acc >> i) & 1u ? 124 : 104;
                    if (c->type == SA_T_DRUM) {
                        if ((c->hits >> i) & 1u) qadd(0, t, 3, 0, 0, v, 0);
                    } else if ((c->chord >> i) & 1u) {
                        qadd(0, t, c->sl[i] * SA_TPS, SA_CH, 0, v, 0);
                    } else if (c->sn[i] != SA_NO_NOTE) {
                        qadd(0, t, c->sl[i] * SA_TPS, SA_NOTE, 0, v, c->sn[i]);
                    }
                }
                continue;
            }
            if (c->type == SA_T_DRUM) {
                const dpat *p = &DPAT[c->pat % NDPAT];
                for (int i = 0; i < p->n; ++i) {
                    int32_t t = cy * SA_TPB + p->s[i].t;
                    if (t >= a && t < b) qadd(0, t, 3, 0, 0, p->s[i].v, 0);
                }
            } else {
                const spat *p = &SPAT[c->pat % NSPAT];
                const smel *ml = mel_of(c->pat);
                if (ml) {                          /* a melody: this bar's part of it */
                    int bi = (int)(((cy % ml->bars) + ml->bars) % ml->bars);
                    for (int i = 0; i < ml->n; ++i) {
                        int32_t t = cy * SA_TPB + (int32_t)ml->m[i].t - bi * SA_TPB;
                        if (ml->m[i].t / SA_TPB == bi && t >= a && t < b)
                            qadd(0, t, ml->m[i].d, ml->m[i].tone, 0, ml->m[i].v, 0);
                    }
                    continue;
                }
                for (int i = 0; i < p->n; ++i) {
                    int32_t t = cy * SA_TPB + p->s[i].t;
                    if (t >= a && t < b) qadd(0, t, p->s[i].d, p->s[i].tone, p->s[i].oct, p->s[i].v, 0);
                }
            }
        }
        return;
    }
    sa_mod md = m[k - 1];
    int n, x = md.val;
    switch (md.type) {
    case SA_M_FAST:
        n = inner(c, m, k, layer, a * x, b * x);
        for (int i = 0; i < n; ++i) qadd(k, fdiv(QT[i].t, x), QT[i].d / x, QT[i].tone, QT[i].oct, QT[i].v, QT[i].n);
        break;
    case SA_M_SLOW:
        n = inner(c, m, k, layer, fdiv(a, x), fdiv(b + x - 1, x));
        for (int i = 0; i < n; ++i) {
            int32_t t = QT[i].t * x;
            if (t >= a && t < b) qadd(k, t, QT[i].d * x, QT[i].tone, QT[i].oct, QT[i].v, QT[i].n);
        }
        break;
    case SA_M_REV:
    case SA_M_EVERY:
        for (int32_t cy = fdiv(a, SA_TPB); cy <= fdiv(b - 1, SA_TPB); ++cy) {
            int32_t c0 = cy * SA_TPB;
            bool rev = md.type == SA_M_REV || (x > 0 && ((cy % x) + x) % x == x - 1);
            n = inner(c, m, k, layer, c0, c0 + SA_TPB);
            for (int i = 0; i < n; ++i) {
                int32_t t = QT[i].t;
                if (rev) {
                    t = c0 + SA_TPB - (QT[i].t - c0) - QT[i].d;
                    if (t < c0) t = c0;
                }
                if (t >= a && t < b) qadd(k, t, QT[i].d, QT[i].tone, QT[i].oct, QT[i].v, QT[i].n);
            }
        }
        break;
    case SA_M_THIN:
        n = inner(c, m, k, layer, a, b);
        for (int i = 0; i < n; ++i)
            if ((int)(hash2((uint32_t)QT[i].t, (uint32_t)layer * 31u + (uint32_t)k) % 100u) >= x * 10)
                qadd(k, QT[i].t, QT[i].d, QT[i].tone, QT[i].oct, QT[i].v, QT[i].n);
        break;
    case SA_M_EUCLID:
        for (int32_t cy = fdiv(a, SA_TPB); cy <= fdiv(b - 1, SA_TPB); ++cy) {
            int32_t c0 = cy * SA_TPB;
            n = inner(c, m, k, layer, c0, c0 + SA_TPB);
            if (n == 0) continue;
            int j = 0, last = -1;
            for (int s = 0; s < 16; ++s) {
                if (((s * x) % 16) >= x) continue;      /* (Bresenham: x hits spread over 16) */
                int next = 16;
                for (int s2 = s + 1; s2 < 16; ++s2)
                    if (((s2 * x) % 16) < x) { next = s2; break; }
                const qev *e = &QT[j % n];
                int32_t t = c0 + s * SA_TPS;
                int dmax = (next - s) * SA_TPS;
                if (t >= a && t < b) qadd(k, t, e->d < dmax ? e->d : dmax, e->tone, e->oct, e->v, e->n);
                j++;
                last = s;
            }
            (void)last;
        }
        break;
    case SA_M_SHIFT: {
        int32_t sh = (x - 8) * SA_TPS;
        n = inner(c, m, k, layer, a - sh, b - sh);
        for (int i = 0; i < n; ++i) qadd(k, QT[i].t + sh, QT[i].d, QT[i].tone, QT[i].oct, QT[i].v, QT[i].n);
        break;
    }
    case SA_M_LEN: {
        int32_t L = x * SA_TPS;
        for (int32_t j = fdiv(a, L); j <= fdiv(b - 1, L); ++j) {
            n = inner(c, m, k, layer, j * SA_TPB, j * SA_TPB + L);
            for (int i = 0; i < n; ++i) {
                int32_t t = j * L + (QT[i].t - j * SA_TPB);
                int d = QT[i].d;
                if (t + d > (j + 1) * L) d = (int)((j + 1) * L - t);
                if (t >= a && t < b) qadd(k, t, d, QT[i].tone, QT[i].oct, QT[i].v, QT[i].n);
            }
        }
        break;
    }
    case SA_M_OCT:
        n = inner(c, m, k, layer, a, b);
        for (int i = 0; i < n; ++i) qadd(k, QT[i].t, QT[i].d, QT[i].tone, QT[i].oct + (x - 2), QT[i].v, QT[i].n);
        break;
    case SA_M_PLY:
        n = inner(c, m, k, layer, a, b);
        for (int i = 0; i < n; ++i) {
            int d = QT[i].d / x;
            if (d < 1) d = 1;
            for (int r = 0; r < x; ++r) {
                int32_t t = QT[i].t + r * d;
                if (t >= a && t < b) qadd(k, t, d, QT[i].tone, QT[i].oct, QT[i].v - r * 8, QT[i].n);
            }
        }
        break;
    default:
        n = inner(c, m, k, layer, a, b);
        for (int i = 0; i < n; ++i) qadd(k, QT[i].t, QT[i].d, QT[i].tone, QT[i].oct, QT[i].v, QT[i].n);
        break;
    }
}

/* a layer's notes in bar `bar` into QB[depth] (sorted by tick); the count */
static int bar_query(const sa_code *c, int layer, int bar, qev **out)
{
    sa_mod m[SA_MODS];
    int k = active_mods(c, m);
    query(c, m, k, layer, (int32_t)bar * SA_TPB, (int32_t)bar * SA_TPB + SA_TPB);
    qev *e = QB[k];
    int n = QN[k];
    for (int i = 1; i < n; ++i) {                  /* insertion sort by tick */
        qev v = e[i];
        int j = i - 1;
        while (j >= 0 && e[j].t > v.t) { e[j + 1] = e[j]; --j; }
        e[j + 1] = v;
    }
    *out = e;
    return n;
}

uint16_t sa_preview(const sa_groove *g, const sa_code *c, int layer, int bar)
{
    (void)g;
    if (c->type == SA_T_NONE || (c->pat == SA_PAT_OFF && !c->own)) return 0;
    qev *e;
    int n = bar_query(c, layer, bar < 0 ? 0 : bar, &e);
    uint16_t bits = 0;
    for (int i = 0; i < n; ++i) {
        int32_t t = e[i].t - (int32_t)(bar < 0 ? 0 : bar) * SA_TPB;
        if (t >= 0 && t < SA_TPB) bits |= (uint16_t)(1u << (t / SA_TPS));
    }
    return bits;
}

/* ---- the chords ---------------------------------------------------------------------------------------------- */
int sa_degree(const sa_harm *h, int deg)
{
    int o = deg >= 0 ? deg / 7 : -((6 - deg) / 7);
    return 12 * o + SCALE[h->scale % SA_SCALES][deg - 7 * o];
}

int sa_snap(const sa_harm *h, int note)
{
    const uint8_t *sc = SCALE[clampi(h->scale, 0, SA_SCALES - 1)];
    int best = note, bd = 99;
    for (int d = -6; d <= 6; ++d) {
        int pc = ((note + d - h->key) % 12 + 12) % 12;
        for (int i = 0; i < 7; ++i)
            if (sc[i] == pc) {
                int ad = d < 0 ? -d : d;
                if (ad < bd || (ad == bd && d < 0)) { bd = ad; best = note + d; }
            }
    }
    return best;
}

static void chord_of_bar(sa_groove *g, int bar)
{
    const sa_harm *h = &g->s.harm;
    int p = clampi(g->part_b && g->s.progb ? g->s.progb - 1 : h->prog, 0, SA_PROGS - 1);   /* (PART B: its own) */
    int bars = h->bars >= 4 ? 4 : h->bars >= 2 ? 2 : 1;
    int i = (bar < 0 ? 0 : bar / bars) % PROG[p].n;
    int d = PROG[p].deg[i], sc = clampi(h->scale, 0, SA_SCALES - 1);
    if ((SCALE[sc][(d + 4) % 7] - SCALE[sc][d] + 12) % 12 == 6)
        d = (d + 5) % 7;                           /* (a diminished chord in this scale: the chord a third below it,
                                                    * two of its notes the same: dorian's VI the IV, major's VII the
                                                    * V, minor's ii the VII; the bass never on the dim root) */
    for (int t = 0; t < 4; ++t)
        g->chord_pc[t] = (uint8_t)((h->key + SCALE[sc][(d + 2 * t) % 7]) % 12);
    g->chord_deg = (uint8_t)d;
    cpy(g->chord_name, sa_note_name(g->chord_pc[0]), sizeof g->chord_name);
    int third = (g->chord_pc[1] - g->chord_pc[0] + 12) % 12, fifth = (g->chord_pc[2] - g->chord_pc[0] + 12) % 12;
    if (fifth == 6) cat(g->chord_name, "dim", sizeof g->chord_name);
    else if (third == 3) cat(g->chord_name, "m", sizeof g->chord_name);
}

/* the MIDI note of a chord tone at an octave (the third, fifth and seventh above the root) */
static int tone_note(const sa_groove *g, int tone, int oct)
{
    int root = g->chord_pc[0], base = 12 * (oct + 1) + root;
    if (tone >= SA_STEP0 - 20 && tone != SA_NOTE && tone != SA_CH) {   /* a melody's scale step from the root */
        int d = g->chord_deg, k = tone - SA_STEP0;
        return base + sa_degree(&g->s.harm, d + k) - sa_degree(&g->s.harm, d);
    }
    if (tone == 4) return base + 12;
    int t = clampi(tone, 0, 3);
    return base + (g->chord_pc[t] - root + 12) % 12;
}

/* ---- the bar's notes ------------------------------------------------------------------------------------------- */
static void bn_add(sa_groove *g, int tick, int dur, int note, int vel, int layer)
{
    if (g->nbn >= SA_BAR_EVENTS || tick < 0 || tick >= SA_TPB) return;
    int i = g->nbn++;
    while (i > 0 && g->bn[i - 1].tick > tick) { g->bn[i] = g->bn[i - 1]; --i; }   /* kept sorted */
    sa_bar_note *b = &g->bn[i];
    b->tick = (uint8_t)tick;
    b->dur = (uint8_t)clampi(dur, 1, 255);
    b->note = (uint8_t)clampi(note, 0, 127);
    b->vel = (uint8_t)clampi(vel, 1, 127);
    b->layer = (uint8_t)layer;
}

/* the arpeggiator's i-th note of n (sorted low to high) */
static int arp_pick(int mode, uint32_t i, int n, int layer)
{
    if (n <= 1) return 0;
    uint32_t un = (uint32_t)n;
    switch (mode) {
    case SA_AR_DOWN: return n - 1 - (int)(i % un);
    case SA_AR_UPDOWN: { uint32_t p = i % (2 * un - 2); return (int)(p < un ? p : 2 * un - 2 - p); }
    case SA_AR_DOWNUP: { uint32_t p = i % (2 * un - 2); return n - 1 - (int)(p < un ? p : 2 * un - 2 - p); }
    case SA_AR_CONVERGE: { int k = (int)(i % un); return k % 2 ? n - 1 - k / 2 : k / 2; }
    case SA_AR_DIVERGE: { int k = n - 1 - (int)(i % un); return k % 2 ? n - 1 - k / 2 : k / 2; }
    case SA_AR_RANDOM: return (int)(hash2(i, (uint32_t)layer + 77u) % un);
    case SA_AR_THUMB: { uint32_t k = i % (2 * un - 2); return k % 2 ? 1 + (int)(k / 2) : 0; }
    case SA_AR_PINKY: { uint32_t k = i % (2 * un - 2); return k % 2 ? (int)(k / 2) : n - 1; }
    default: return (int)(i % un);
    }
}

/* a layer's code as PART plays it: B's pattern in place of A's (an own pattern is A's) */
static const sa_code *code_now(const sa_groove *g, int l)
{
    static sa_code tmp;
    const sa_code *c = &g->s.code[l];
    uint8_t b = g->s.patb[l];
    if (!g->part_b || b == 0 || g->s.live[l].hand) return c;   /* (MANUAL: A's, always) */
    tmp = *c;
    tmp.own = 0;
    tmp.pat = b == SA_PATB_OFF ? SA_PAT_OFF : (uint8_t)(b - 1);
    return &tmp;
}

/* PHRASE: a synth layer's bar as the phrase has it (four bars: A A A' B). Bar 3: the second half's chord tones a
 * tone up (an own note a step up the scale). Bar 4, the answer: LEAD's first note of the second half on the root,
 * held, nothing after it; BASS and CHORD quiet over the last beat (the fill's room), BASS's last note on the root */
static int phrase_bar(sa_groove *g, int l, qev *e, int n, int32_t b0, int bar)
{
    const sa_code *c = code_now(g, l);
    bool mel = !c->own && c->pat != SA_PAT_OFF && mel_of(c->pat);   /* (a melody: a phrase of its own) */
    int ph = g->s.phrase == 0 && bar >= 0 && !g->s.live[l].hand && !mel ? bar % 4 : 0;
    if (ph < 2 || l >= SA_L_DRUM0) return n;
    int half = SA_TPB / 2, last = 3 * SA_TPB / 4, m = 0, f = -1;
    for (int i = 0; i < n; ++i) {
        int tick = (int)(e[i].t - b0);
        if (ph == 2) {
            if (tick >= half && e[i].tone == SA_NOTE) e[i].n = (int8_t)(sa_snap(&g->s.harm, g->s.harm.key + e[i].n + 2) -
                                                                       g->s.harm.key);
            else if (tick >= half && e[i].tone < 3) e[i].tone = (uint8_t)(e[i].tone + 1);
            e[m++] = e[i];
            continue;
        }
        if (l == SA_L_LEAD) {
            if (tick >= half && f >= 0) continue;
            if (tick >= half) {
                f = m;
                e[i].d = (uint8_t)clampi(SA_TPB - SA_TPS - tick, 1, 255);
            }
        } else {
            if (tick >= last) continue;
            if (tick >= half) f = m;
        }
        e[m++] = e[i];
    }
    if (ph == 3 && f >= 0 && (l == SA_L_LEAD || l == SA_L_BASS) && e[f].tone != SA_CH) {
        if (e[f].tone == SA_NOTE) {                /* (an own note: the chord's root nearest it) */
            int p = g->s.harm.key + e[f].n, dn = ((p - g->chord_pc[0]) % 12 + 12) % 12;
            p += dn > 6 ? 12 - dn : -dn;
            e[f].n = (int8_t)(p - g->s.harm.key);
        } else {
            e[f].tone = 0;
        }
    }
    return m;
}

static void layer_bar(sa_groove *g, int l, int bar)
{
    const sa_code *c = code_now(g, l);
    if (c->type == SA_T_NONE || (c->pat == SA_PAT_OFF && !c->own)) return;
    qev *e;
    int n = bar_query(c, l, bar, &e);
    int32_t b0 = (int32_t)bar * SA_TPB;
    if (c->type == SA_T_DRUM) {                    /* LEVEL; ACCENT (env, 50: as written); CHANCE (cut) */
        const sa_live *v = &g->s.live[l];
        int lv = v->level, note = sa_dv_gm(c->sound), ac = v->env, ch = v->cut;
        for (int i = 0; i < n; ++i) {
            if (ch < 100) {
                uint32_t h = ((uint32_t)bar * 2654435761u) ^ ((uint32_t)e[i].t * 40503u) ^ ((uint32_t)l * 2246822519u);
                h ^= h >> 15;
                h *= 2654435761u;
                if ((int)((h >> 16) % 100u) >= ch) continue;
            }
            int vel = e[i].v;
            vel = vel >= 120 ? 90 + (vel - 90) * ac / 50 : vel * (150 - ac) / 100;
            vel = clampi(vel, 20, 127);
            bn_add(g, (int)(e[i].t - b0), e[i].d, note, vel * (20 + lv * 80 / 100) / 100, l);
        }
        return;
    }
    int poct = c->own ? c->ooct : SPAT[c->pat % NSPAT].oct;
    n = phrase_bar(g, l, e, n, b0, bar);
    for (int i = 0; i < n; ++i) {
        int tick = (int)(e[i].t - b0), oct = poct + e[i].oct;
        int own_note = e[i].tone == SA_NOTE ? g->s.harm.key + e[i].n + 12 * e[i].oct : -1;
        if (own_note >= 0) oct = own_note / 12 - 1;
        if (c->amode == SA_AR_OFF || c->amode >= SA_AR_MODES) {
            if (own_note >= 0) {
                bn_add(g, tick, e[i].d, own_note, e[i].v, l);
            } else if (e[i].tone == SA_CH) {
                for (int t = 0; t < 3; ++t)
                    bn_add(g, tick, e[i].d, tone_note(g, t, oct), e[i].v - t * 4, l);
            } else {
                bn_add(g, tick, e[i].d, tone_note(g, e[i].tone, oct), e[i].v, l);
            }
            continue;
        }
        /* the arpeggiator: the chord's tones over RANGE octaves, from the note's octave up */
        int set[12], ns = 0, range = clampi(c->arange, 1, 4);
        for (int o = 0; o < range; ++o)
            for (int t = 0; t < 3; ++t)
                set[ns++] = tone_note(g, t, oct + o);
        int rate = RATE_TICKS[clampi(c->arate, 0, SA_RATES - 1)];
        int gate = rate * clampi(c->agate, 10, 100) / 100;
        int end = tick + e[i].d;
        if (end > SA_TPB) end = SA_TPB;
        for (int t = tick; t < end; t += rate) {
            if (c->amode == SA_AR_STRUM) {
                for (int s = 0; s < ns; ++s)
                    bn_add(g, t + s, gate > 1 ? gate : 1, set[s], e[i].v - s * 3, l);
            } else {
                int k = arp_pick(c->amode, g->arp_i[l]++, ns, l);
                bn_add(g, t, gate > 1 ? gate : 1, set[k], e[i].v, l);
            }
        }
    }
}

static void bar_build(sa_groove *g)
{
    chord_of_bar(g, g->bar);
    g->nbn = 0;
    g->bn_at = 0;
    for (int l = 0; l < SA_LAYERS; ++l)
        layer_bar(g, l, g->bar);
}

/* ---- the own patterns ------------------------------------------------------------------------------------------ */
bool sa_chordy(const sa_code *c)
{
    if (c->type != SA_T_SYNTH) return false;
    if (c->part == SA_L_CHORD) return true;        /* (the CHORD layer: its steps are chords) */
    if (c->pat == SA_PAT_OFF) return false;
    const spat *p = &SPAT[c->pat % NSPAT];
    for (int i = 0; i < p->n; ++i)
        if (p->s[i].tone == SA_CH) return true;
    return false;
}

void sa_own_make(sa_groove *g, sa_code *c)
{
    if (c->own || c->type == SA_T_NONE) return;
    c->hits = c->acc = c->chord = 0;
    for (int i = 0; i < 16; ++i) {
        c->sn[i] = SA_NO_NOTE;
        c->sl[i] = 1;
    }
    if (c->pat == SA_PAT_OFF) {                    /* (OFF: an empty one, in the layer's octave) */
        c->ooct = (uint8_t)(c->part == SA_L_BASS ? 2 : c->part == SA_L_LEAD ? 5 : 4);
        c->own = 1;
        return;
    }
    if (c->type == SA_T_DRUM) {                    /* (a triplet hit goes to its nearest sixteenth) */
        const dpat *p = &DPAT[c->pat % NDPAT];
        for (int i = 0; i < p->n; ++i) {
            int st = ((p->s[i].t + SA_TPS / 2) / SA_TPS) % 16;
            c->hits |= (uint16_t)(1u << st);
            if (p->s[i].v >= 120) c->acc |= (uint16_t)(1u << st);
        }
    } else {                                       /* the notes as the chord of the bar playing voices them */
        const spat *p = &SPAT[c->pat % NSPAT];
        c->ooct = (uint8_t)p->oct;
        const smel *ml = mel_of(c->pat);
        for (int i = 0; ml && i < ml->n; ++i) {    /* (a melody: its first bar) */
            if (ml->m[i].t >= SA_TPB) continue;
            int st = ((ml->m[i].t + SA_TPS / 2) / SA_TPS) % 16;
            c->sl[st] = (uint8_t)clampi((ml->m[i].d + SA_TPS / 2) / SA_TPS, 1, 16);
            c->sn[st] = (int8_t)clampi(tone_note(g, ml->m[i].tone, p->oct) - g->s.harm.key, -127, 127);
        }
        for (int i = 0; i < p->n; ++i) {
            int st = ((p->s[i].t + SA_TPS / 2) / SA_TPS) % 16;
            int len = (p->s[i].d + SA_TPS / 2) / SA_TPS;
            c->sl[st] = (uint8_t)clampi(len, 1, 16);
            if (p->s[i].v >= 115) c->acc |= (uint16_t)(1u << st);
            if (p->s[i].tone == SA_CH) {
                c->chord |= (uint16_t)(1u << st);
            } else {
                int nn = tone_note(g, p->s[i].tone, p->oct + p->s[i].oct) - g->s.harm.key;
                c->sn[st] = (int8_t)clampi(nn, -127, 127);
            }
        }
    }
    c->own = 1;
}

void sa_step_drum(sa_groove *g, int l, int st)
{
    if (l < 0 || l >= SA_LAYERS || st < 0 || st > 15) return;
    sa_code *c = &g->ed[l];
    if (c->type != SA_T_DRUM) return;
    sa_own_make(g, c);
    c->hits ^= (uint16_t)(1u << st);
    if (!((c->hits >> st) & 1u)) c->acc &= (uint16_t)~(1u << st);
}

void sa_step_note(sa_groove *g, int l, int st, int note)
{
    if (l < 0 || l >= SA_LAYERS || st < 0 || st > 15) return;
    sa_code *c = &g->ed[l];
    if (c->type != SA_T_SYNTH) return;
    bool chordy = sa_chordy(c);
    sa_own_make(g, c);
    if (chordy) {
        c->chord ^= (uint16_t)(1u << st);
        c->sn[st] = SA_NO_NOTE;
    } else {
        int rel = clampi((g->snap ? sa_snap(&g->ed_harm, note) : note) - g->ed_harm.key, -127, 127);
        if (c->sn[st] == rel && !((c->chord >> st) & 1u)) {
            c->sn[st] = SA_NO_NOTE;
        } else {
            c->sn[st] = (int8_t)rel;
            c->chord &= (uint16_t)~(1u << st);
        }
    }
    if (c->sl[st] < 1) c->sl[st] = 1;
}

void sa_step_len(sa_groove *g, int l, int st, int d)
{
    if (l < 0 || l >= SA_LAYERS || st < 0 || st > 15) return;
    sa_code *c = &g->ed[l];
    if (c->type != SA_T_SYNTH) return;
    if (d > 0 && !(sa_own_make(g, c), c->sn[st] != SA_NO_NOTE || ((c->chord >> st) & 1u))) {
        sa_step_turn(g, l, st, 1);                 /* (0.8.48) a rest: a note there first (the one before it; CHORD: the
                                                    * chord), a sixteenth long */
        c->sl[st] = 1;
        return;
    }
    sa_own_make(g, c);
    if (c->sl[st] + d < 1 && (c->sn[st] != SA_NO_NOTE || ((c->chord >> st) & 1u))) {   /* below 1: the note goes */
        c->sn[st] = SA_NO_NOTE;
        c->chord &= (uint16_t)~(1u << st);
        c->sl[st] = 1;
        return;
    }
    c->sl[st] = (uint8_t)clampi(c->sl[st] + d, 1, 16);
}

void sa_step_turn(sa_groove *g, int l, int st, int d)
{
    if (l < 0 || l >= SA_LAYERS || st < 0 || st > 15 || !d) return;
    sa_code *c = &g->ed[l];
    if (c->type != SA_T_SYNTH) return;
    bool chordy = sa_chordy(c);
    sa_own_make(g, c);
    if (c->sl[st] < 1) c->sl[st] = 1;
    if (chordy) {                                  /* CHORD: right on, left off */
        if (d > 0) c->chord |= (uint16_t)(1u << st);
        else c->chord &= (uint16_t)~(1u << st);
        c->sn[st] = SA_NO_NOTE;
        return;
    }
    const sa_harm *h = &g->ed_harm;
    if (c->sn[st] == SA_NO_NOTE) {                 /* a rest: the note before it, else the root (an octave over C3) */
        int rel = SA_NO_NOTE;
        for (int k = 1; k < 16 && rel == SA_NO_NOTE; ++k) rel = c->sn[(st + 16 - k) % 16];
        if (rel == SA_NO_NOTE) rel = 60;
        c->sn[st] = (int8_t)clampi(sa_snap(h, h->key + rel) - h->key, -127, 127);
        c->chord &= (uint16_t)~(1u << st);
        return;
    }
    int n = h->key + c->sn[st], dir = d > 0 ? 1 : -1;
    for (int k = 0; k < (d > 0 ? d : -d); ++k) {   /* d steps of the scale */
        int m = n + dir;
        while (m > 0 && m < 127 && sa_snap(h, m) != m) m += dir;
        if (m <= 12 || m >= 120) break;
        n = m;
    }
    c->sn[st] = (int8_t)clampi(n - h->key, -127, 127);
}

void sa_pat_label(const sa_code *c, char *out, int max)
{
    if (c->own) { cpy(out, "MY STEPS", max); return; }
    cpy(out, c->pat == SA_PAT_OFF ? "OFF" : sa_pat_name(c->type, c->pat), max);
}

/* ---- the gates ---------------------------------------------------------------------------------------------------- */
static const struct { const char *name; uint16_t mask; } GATE[SA_GATES] = {
    {"OFF", 0},
    {"16THS", 0xFFFF},
    {"8THS", 0x5555},
    {"OFFBEATS", 0x4444},
    {"PULSE 4", 0x1111},
    {"TRANCE A", 0x6D6D},                          /* (bit i: the sixteenth i) 0 2 3 5 6 8 10 11 13 14 */
    {"TRANCE B", 0x5B5B},                          /* 0 1 3 4 6 8 9 11 12 14 */
    {"DOTTED", 0x9249},                            /* 0 3 6 9 12 15 */
    {"SYNCO", 0x9999},                             /* 0 3 4 7 8 11 12 15 */
    {"BREATH", 0x7777},                            /* three on, one off */
    {"STUTTER", 0x0F0F},
    {"HALVES", 0x00FF},
    {"SPARSE", 0x0441},                            /* 0 6 10 */
};
const char *sa_gate_name(int p) { return GATE[clampi(p, 0, SA_GATES - 1)].name; }
uint16_t sa_gate_mask(const sa_gate *gt) { return gt->own ? gt->mask : GATE[gt->pat % SA_GATES].mask; }
bool sa_gate_on(const sa_gate *gt) { return gt->own || (gt->pat > 0 && gt->pat < SA_GATES); }
void sa_gate_label(const sa_gate *gt, char *out, int max)
{
    if (gt->own && gt->pat == 0) { cpy(out, "MY GATE", max); return; }
    cpy(out, sa_gate_name(gt->pat), max);
    if (gt->own) cat(out, " EDIT", max);
}
void sa_gate_step(sa_groove *g, int l, int st)
{
    if (l < 0 || l >= SA_LAYERS || st < 0 || st > 15) return;
    sa_gate *gt = &g->ed_gate[l];
    if (!gt->own) {
        gt->mask = GATE[gt->pat % SA_GATES].mask;
        gt->own = 1;
    }
    gt->mask ^= (uint16_t)(1u << st);
}
void sa_gate_pick(sa_groove *g, int l, int d)
{
    if (l < 0 || l >= SA_LAYERS) return;
    sa_gate *gt = &g->ed_gate[l];
    gt->pat = (uint8_t)(((gt->pat + d) % SA_GATES + SA_GATES) % SA_GATES);
    gt->own = 0;
}
static void gate_default(sa_gate *gt)
{
    memset(gt, 0, sizeof *gt);
    gt->depth = 100;
    gt->width = 50;
    gt->smooth = 25;
}

/* each synth part's gate, a block at a time: open on the steps of its layer's gate for WIDTH of the step (an off
 * sixteenth late by FEEL, as the notes), down by DEPTH between them, the edges faded by SMOOTH */
static void gate_block(sa_groove *g, int frames)
{
    float target[SA_SYNTHS] = {1.0f, 1.0f, 1.0f}, fade[SA_SYNTHS] = {1.0f, 1.0f, 1.0f};
    float tf = g->sr * 60.0f / (float)clampi(g->s.bpm, 60, 200) / 24.0f;
    float pos = (float)(g->tick < 0 ? 0 : g->tick) + 1.0f - (tf > 0.0f ? g->wait / tf : 0.0f);   /* ticks into the bar */
    if (pos < 0.0f) pos = 0.0f;
    int st = (int)(pos / (float)SA_TPS) % 16;
    float f = (pos - (float)(st * SA_TPS)) / (float)SA_TPS;   /* 0..1 through the sixteenth */
    if (st % 2 && g->s.feel) {                     /* (an off sixteenth: late, as the swung notes) */
        float sw = (float)g->s.feel / 100.0f * 0.66f;
        f = f < sw ? -1.0f : (f - sw) / (1.0f - sw);
    }
    for (int l = 0; l < SA_LAYERS; ++l) {
        const sa_code *c = &g->s.code[l];
        const sa_gate *gt = &g->s.gate[l];
        if (c->type != SA_T_SYNTH || c->part >= SA_SYNTHS || !g->playing || !sa_gate_on(gt)) continue;
        bool open = ((sa_gate_mask(gt) >> st) & 1u) && f >= 0.0f && f < (float)clampi(gt->width, 10, 100) / 100.0f;
        target[c->part] = open ? 1.0f : 1.0f - (float)gt->depth / 100.0f;
        float ms = 1.0f + (float)gt->smooth * 0.2f;          /* 1 .. 21 ms */
        fade[c->part] = (float)frames / (g->sr * ms * 0.001f);
    }
    for (int p = 0; p < SA_SYNTHS; ++p) {
        float d = target[p] - g->gate_gain[p], k = fade[p] > 1.0f ? 1.0f : fade[p];
        g->gate_gain[p] += d * k;
        if (g->gate_gain[p] < 0.0f) g->gate_gain[p] = 0.0f;
        if (g->gate_gain[p] > 1.0f) g->gate_gain[p] = 1.0f;
        g->gate_off[p] = (uint8_t)((1.0f - g->gate_gain[p]) * 127.0f + 0.5f);
    }
}

/* ---- the panning ---------------------------------------------------------------------------------------------- */
static const char *const PAN_MODES[SA_PAN_MODES] = {"FIXED", "SWEEP", "PING-PONG", "RANDOM"};
static const char *const PAN_RATES[SA_PRATES] = {"1/4 BAR", "1/2 BAR", "1 BAR", "2 BARS", "4 BARS"};
const char *sa_pan_mode_name(int m) { return PAN_MODES[clampi(m, 0, SA_PAN_MODES - 1)]; }
const char *sa_pan_rate_name(int r) { return PAN_RATES[clampi(r, 0, SA_PRATES - 1)]; }
static int pan_val(int pos, int off) { return clampi((pos + off) * 64 / 50, -64, 63); }   /* -50..50 -> -64..63 */
/* a note of a layer: PING-PONG and RANDOM move its part */
static void pan_note(sa_groove *g, int l)
{
    const sa_code *c = &g->s.code[l];
    const sa_pan *p = &g->s.pan[l];
    if (c->type != SA_T_SYNTH || c->part >= SA_SYNTHS) return;
    if (g->s.d3[c->part].on == SA_3D_RANDOM) {     /* 3D RANDOM: each note somewhere round you */
        g->pan_rnd = g->pan_rnd * 1664525u + 1013904223u;
        g->az_now[c->part] = (uint8_t)((g->pan_rnd >> 16) % SA_AZ_STEPS);
        return;
    }
    int w = p->width / 2;                          /* (WIDTH 100: 50 each way) */
    if (p->mode == SA_PAN_PINGPONG) {
        g->pan_side[l] ^= 1u;
        g->pan_now[c->part] = (int8_t)pan_val(p->pos, g->pan_side[l] ? w : -w);
    } else if (p->mode == SA_PAN_RANDOM) {
        g->pan_rnd = g->pan_rnd * 1664525u + 1013904223u;
        int r = w ? (int)((g->pan_rnd >> 16) % (uint32_t)(2 * w + 1)) - w : 0;
        g->pan_now[c->part] = (int8_t)pan_val(p->pos, r);
    }
}
/* every block: FIXED and SWEEP (a triangle from one side to the other and back over RATE) */
int sa_sin5(int k)
{
    static const uint8_t Q[19] = {0, 11, 22, 33, 43, 54, 64, 73, 82, 90, 97, 104, 110, 115, 119, 123, 125, 127, 127};
    k %= SA_AZ_STEPS;
    if (k < 0) k += SA_AZ_STEPS;
    return k <= 18 ? Q[k] : k <= 36 ? Q[36 - k] : k <= 54 ? -Q[k - 36] : -Q[SA_AZ_STEPS - k];
}

static void pan_block(sa_groove *g)
{
    static const uint8_t RATE_Q[SA_PRATES] = {1, 2, 4, 8, 16};     /* in quarter bars */
    for (int l = 0; l < SA_LAYERS; ++l) {
        const sa_code *c = &g->s.code[l];
        const sa_pan *p = &g->s.pan[l];
        if (c->type != SA_T_SYNTH || c->part >= SA_SYNTHS) continue;
        const sa_3d *d = &g->s.d3[c->part];
        if (d->on) {                               /* 3D: where it is now; the angle pans it */
            float len = (float)(SA_TPB / 4 * RATE_Q[g->s.d3rate[c->part] % SA_PRATES]);
            float at = (float)((g->bar < 0 ? 0 : g->bar) * SA_TPB + (g->tick < 0 ? 0 : g->tick));
            float ph = at / len;
            ph -= (float)(int)ph;
            int k = (int)(ph * (float)SA_AZ_STEPS);
            g->el_now[c->part] = d->el;
            if (d->on == SA_3D_FIXED) g->az_now[c->part] = d->az;
            else if (d->on == SA_3D_ORBIT || d->on == SA_3D_FLY) g->az_now[c->part] = (uint8_t)((d->az + k) % SA_AZ_STEPS);
            if (d->on == SA_3D_FLY) g->el_now[c->part] = (int8_t)clampi(d->el + sa_sin5(2 * k) * 30 / 127, -50, 50);
            g->pan_now[c->part] = (int8_t)(sa_sin5(g->az_now[c->part]) * 63 / 127);
        } else if (p->mode == SA_PAN_FIXED) {
            g->pan_now[c->part] = (int8_t)pan_val(p->pos, 0);
        } else if (p->mode == SA_PAN_SWEEP) {
            float len = (float)(SA_TPB / 4 * RATE_Q[p->rate % SA_PRATES]);
            float at = (float)((g->bar < 0 ? 0 : g->bar) * SA_TPB + (g->tick < 0 ? 0 : g->tick));
            float ph = at / len;
            ph -= (float)(int)ph;
            float tri = ph < 0.5f ? ph * 4.0f - 1.0f : 3.0f - ph * 4.0f;   /* -1 .. 1 .. -1 */
            g->pan_now[c->part] = (int8_t)pan_val(p->pos, (int)(tri * (float)(p->width / 2)));
        }
    }
}

/* ---- defaults and checks --------------------------------------------------------------------------------------- */
static void code_drum(sa_code *c, int dv, int pat)
{
    memset(c, 0, sizeof *c);
    c->type = SA_T_DRUM;
    c->sound = (uint8_t)dv;
    c->pat = (uint8_t)pat;
    c->part = SA_PART_DRUMS;
    c->arate = SA_RATE_16;
    c->arange = 1;
    c->agate = 60;
}
static void code_synth(sa_code *c, int sound, int pat, int part)
{
    memset(c, 0, sizeof *c);
    c->type = SA_T_SYNTH;
    c->sound = (uint8_t)sound;
    c->pat = (uint8_t)pat;
    c->part = (uint8_t)part;
    c->arate = SA_RATE_16;
    c->arange = 2;
    c->agate = 60;
}
static void live_default(sa_live *v)
{
    memset(v, 0, sizeof *v);
    v->cut = 100;
    v->reso = 30;
    v->env = 50;
    v->level = 70;                                 /* (0.8.12: 70, headroom; 80 is the sound as it is) */
}

/* the synth sounds the first groove uses (sa_sounds.h indices: kept in step with it) */
#define SA_DEF_BASS 0
#define SA_DEF_STAB 1
static int pat_find(int type, const char *name);
void sa_defaults(sa_settings *s)
{
    memset(s, 0, sizeof *s);
    s->bpm = 126;
    s->filter = 100;
    s->feel = 18;
    s->kit = SA_KIT_TECH;
    s->ktune = 50;
    s->ktone = 55;
    s->kdecay = 50;
    s->kdrive = 15;
    s->pump = 35;
    s->reverb = 70;
    s->delay = 70;
    s->width = 70;
    s->harm.key = 9;                               /* A minor */
    s->harm.scale = SA_SC_MINOR;
    s->harm.prog = 1;
    s->harm.bars = 2;
    for (int l = 0; l < SA_LAYERS; ++l) {
        live_default(&s->live[l]);
        gate_default(&s->gate[l]);
        s->pan[l].width = 60;
        s->pan[l].rate = SA_PRATE_BAR;
    }
    for (int p = 0; p < SA_SYNTHS; ++p) s->d3rate[p] = SA_PRATE_2BARS;
    s->dvol = 70;
    for (int p = 0; p < SA_SYNTHS; ++p) {          /* LEAD 10 %, CHORD 80 %, BASS 50 % until the glue sets it by type */
        static const uint8_t DEP[SA_SYNTHS] = {10, 80, 50};
        s->pl[p].depth = DEP[p];
        s->pl[p].rel = 50;
        s->pl[p].src = SA_PS_KICK;
        s->pl[p].on = 2;
    }
    code_synth(&s->code[SA_L_LEAD], SA_DEF_BASS, pat_find(SA_T_SYNTH, "RIFF"), SA_L_LEAD);   /* (in after a pattern: arrange) */
    code_synth(&s->code[SA_L_CHORD], SA_DEF_STAB, 13, SA_L_CHORD);   /* STAB 2 */
    code_synth(&s->code[SA_L_BASS], SA_DEF_BASS, 1, SA_L_BASS);      /* ROLLER */
    for (int r = 0; r < SA_DROWS; ++r)
        code_drum(&s->code[SA_L_DRUM0 + r], ROW_DEF[r], SA_PAT_OFF);
    s->code[SA_L_DRUM0 + SA_DR_KICK].pat = 0;                         /* 4 FLOOR */
    s->code[SA_L_DRUM0 + SA_DR_HATS].pat = 1;                         /* OFFBEAT */
    s->code[SA_L_DRUM0 + SA_DR_CLAP].pat = 2;                         /* 2 + 4 */
    sa_make_b(s, 1);
}

/* the fixed layers: LEAD CHORD BASS in slots 0..2 on parts 0..2 (a synth layer elsewhere, or a drum there, moves:
 * its code, sound, gate and pan with it); a slot of them empty: that synth, OFF */
static void canon(sa_settings *s)
{
    sa_code c[SA_LAYERS];
    sa_live v[SA_LAYERS];
    sa_gate gt[SA_LAYERS];
    sa_pan pn[SA_LAYERS];
    bool have[3] = {false, false, false}, row[SA_DROWS] = {false};
    memset(c, 0, sizeof c);
    for (int l = 0; l < SA_LAYERS; ++l) {
        live_default(&v[l]);
        gate_default(&gt[l]);
        memset(&pn[l], 0, sizeof pn[l]);
        pn[l].width = 60;
        pn[l].rate = SA_PRATE_BAR;
    }
    for (int l = 0; l < SA_LAYERS; ++l) {           /* the synths to their parts' slots (the first of a part wins) */
        const sa_code *o = &s->code[l];
        int to = -1;
        if (o->type == SA_T_SYNTH && o->part < 3 && !have[o->part]) to = o->part;
        else if (o->type == SA_T_DRUM && !row[DV_ROW[o->sound % SA_DVS]]) to = SA_L_DRUM0 + DV_ROW[o->sound % SA_DVS];
        if (to < 0) continue;                      /* (a second drum on a row's channel: it goes) */
        if (o->type == SA_T_SYNTH) have[to] = true;
        else row[to - SA_L_DRUM0] = true;
        c[to] = *o;
        v[to] = s->live[l];
        gt[to] = s->gate[l];
        pn[to] = s->pan[l];
    }
    for (int p = 0; p < 3; ++p)
        if (!have[p]) code_synth(&c[p], 0, SA_PAT_OFF, p);
    for (int r = 0; r < SA_DROWS; ++r)              /* every row there: OFF if the groove has none */
        if (!row[r]) code_drum(&c[SA_L_DRUM0 + r], ROW_DEF[r], SA_PAT_OFF);
    memcpy(s->code, c, sizeof c);
    memcpy(s->live, v, sizeof v);
    memcpy(s->gate, gt, sizeof gt);
    memcpy(s->pan, pn, sizeof pn);
}

void sa_settings_fix(sa_settings *s)
{
    canon(s);                                      /* (first: the clamps below then hold for every slot) */
    for (int l = 0; l < SA_LAYERS; ++l)            /* no ride, no crash: a set that had one plays the tambourine */
        if (s->code[l].type == SA_T_DRUM && (s->code[l].sound == SA_DV_RIDE || s->code[l].sound == SA_DV_CRASH))
            s->code[l].sound = SA_DV_TAMB;
    s->phrase = (uint8_t)(s->phrase ? 1 : 0);
    s->abauto = (uint8_t)(s->abauto % SA_ABAUTOS);
    s->evolve = (uint8_t)(s->evolve % SA_EVOLVES);
    if (s->progb > SA_PROGS) s->progb = 0;
    for (int l = 0; l < SA_LAYERS; ++l) {
        int t = s->code[l].type == SA_T_DRUM ? sa_drum_pats() : sa_synth_pats();
        if (s->patb[l] != SA_PATB_OFF && s->patb[l] > t) s->patb[l] = 0;
    }
    s->bpm = (uint8_t)clampi(s->bpm, 60, 200);
    s->filter = (uint8_t)clampi(s->filter, 0, 100);
    s->feel = (uint8_t)clampi(s->feel, 0, 60);
    s->kit = (uint8_t)clampi(s->kit, 0, SA_KITS - 1);
    s->ktune = (uint8_t)clampi(s->ktune, 0, 100);
    s->ktone = (uint8_t)clampi(s->ktone, 0, 100);
    s->kdecay = (uint8_t)clampi(s->kdecay, 0, 100);
    s->kdrive = (uint8_t)clampi(s->kdrive, 0, 100);
    s->look = (uint8_t)(s->look ? 1 : 0);
    s->pump = (uint8_t)clampi(s->pump, 0, 100);
    s->reverb = (uint8_t)clampi(s->reverb, 0, 100);
    s->delay = (uint8_t)clampi(s->delay, 0, 100);
    s->width = (uint8_t)clampi(s->width, 0, 100);
    s->harm.key %= 12;
    s->harm.scale = (uint8_t)clampi(s->harm.scale, 0, SA_SCALES - 1);
    s->harm.prog = (uint8_t)clampi(s->harm.prog, 0, SA_PROGS - 1);
    s->harm.bars = (uint8_t)(s->harm.bars >= 4 ? 4 : s->harm.bars >= 2 ? 2 : 1);
    int synths = 0;
    uint8_t parts = 0;
    for (int l = 0; l < SA_LAYERS; ++l) {
        sa_code *c = &s->code[l];
        sa_live *v = &s->live[l];
        if (c->type > SA_T_SYNTH) c->type = SA_T_NONE;
        if (c->type == SA_T_SYNTH) {             /* three at most, each on a part of its own */
            if (synths >= SA_SYNTHS || c->part >= SA_SYNTHS || (parts >> c->part) & 1u) {
                int p = 0;
                while (p < SA_SYNTHS && ((parts >> p) & 1u)) ++p;
                if (synths >= SA_SYNTHS || p >= SA_SYNTHS) c->type = SA_T_NONE;
                else c->part = (uint8_t)p;
            }
            if (c->type == SA_T_SYNTH) {
                parts |= (uint8_t)(1u << c->part);
                synths++;
                if (c->pat != SA_PAT_OFF) c->pat %= (uint8_t)NSPAT;
            }
        }
        if (c->type == SA_T_DRUM) {
            c->part = SA_PART_DRUMS;
            c->sound %= SA_DVS;
            if (c->pat != SA_PAT_OFF) c->pat %= (uint8_t)NDPAT;
        }
        for (int i = 0; i < SA_MODS; ++i) {
            sa_mod *m = &c->mod[i];
            if (m->type >= SA_M_TYPES) m->type = SA_M_OFF;
            for (int r = 0; r < NMODR; ++r)
                if (MODS[r].type == m->type) m->val = (uint8_t)clampi(m->val, MODS[r].lo, MODS[r].hi);
            if (mod_skip(c->type, m->type, m->val)) m->type = SA_M_OFF;
        }
        c->own = (uint8_t)(c->own ? 1 : 0);
        c->ooct = (uint8_t)clampi(c->ooct, 1, 6);
        for (int i = 0; i < 16; ++i)
            c->sl[i] = (uint8_t)clampi(c->sl[i], 1, 16);
        c->amode = (uint8_t)(c->amode < (c->type == SA_T_DRUM ? SA_DVARS : SA_AR_MODES) ? c->amode : 0);   /* (a drum: its
                                                                                                   * variation) */
        c->arate = (uint8_t)clampi(c->arate, 0, SA_RATES - 1);
        c->arange = (uint8_t)clampi(c->arange, 1, 4);
        c->agate = (uint8_t)clampi(c->agate, 10, 100);
        v->mute = (uint8_t)(v->mute ? 1 : 0);
        v->cut = (uint8_t)clampi(v->cut, 0, 100);
        v->reso = (uint8_t)clampi(v->reso, 0, 100);
        v->drive = (uint8_t)clampi(v->drive, 0, 100);
        v->env = (uint8_t)clampi(v->env, 0, 100);
        v->level = (uint8_t)clampi(v->level, 0, 100);
        v->nopump = (uint8_t)(v->nopump ? 1 : 0);
        v->hand = (uint8_t)(v->hand ? 1 : 0);
        sa_gate *gt = &s->gate[l];
        gt->pat %= SA_GATES;
        gt->own = (uint8_t)(gt->own ? 1 : 0);
        gt->depth = (uint8_t)clampi(gt->depth, 0, 100);
        gt->width = (uint8_t)clampi(gt->width, 10, 100);
        gt->smooth = (uint8_t)clampi(gt->smooth, 0, 100);
        sa_pan *pn = &s->pan[l];
        pn->mode = (uint8_t)(pn->mode % SA_PAN_MODES);
        pn->pos = (int8_t)clampi(pn->pos, -50, 50);
        pn->width = (uint8_t)clampi(pn->width, 0, 100);
        pn->rate = (uint8_t)(pn->rate % SA_PRATES);
    }
    for (int p = 0; p < SA_SYNTHS; ++p) {
        sa_pumpl *q = &s->pl[p];
        q->depth = (uint8_t)clampi(q->depth, 0, 100);
        q->rel = (uint8_t)clampi(q->rel, 0, 100);
        q->src = (uint8_t)(q->src % SA_PSRCS);
        if (q->on > 2) q->on = 1;
    }
    for (int p = 0; p < SA_SYNTHS; ++p) {
        sa_3d *d = &s->d3[p];
        d->on = (uint8_t)(d->on % SA_3D_MODES);
        s->d3rate[p] = (uint8_t)(s->d3rate[p] % SA_PRATES);
        s->dvol = (uint8_t)clampi(s->dvol, 0, 100);
        s->mreso = (uint8_t)clampi(s->mreso, 0, 100);
        s->intro %= SA_INTROS;
        s->arc %= SA_ARCS;
        s->dmute = (uint8_t)(s->dmute ? 1 : 0);
        d->az %= SA_AZ_STEPS;
        d->el = (int8_t)clampi(d->el, -50, 50);
        d->dist = (uint8_t)clampi(d->dist, 0, 100);
    }
}

/* ---- a fresh groove ---------------------------------------------------------------------------------------------- */
static uint32_t rnd_next(uint32_t *r)
{
    uint32_t x = *r;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return *r = x;
}
static int rnd(uint32_t *r, int n) { return n > 0 ? (int)((rnd_next(r) >> 8) % (uint32_t)n) : 0; }
static bool streq(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}
static int pat_find(int type, const char *name)
{
    int n = type == SA_T_DRUM ? NDPAT : NSPAT;
    for (int i = 0; i < n; ++i)
        if (streq(type == SA_T_DRUM ? DPAT[i].name : SPAT[i].name, name)) return i;
    return 0;
}
static int pick_pat(uint32_t *r, int type, const char *const *names, int n) { return pat_find(type, names[rnd(r, n)]); }
static int pick_sound(uint32_t *r, const uint8_t *list, int n) { return n > 0 ? list[rnd(r, n)] : 0; }

static const char *const BASS[] = {"OFFBEAT", "ROLLER", "ROOT 8THS", "OCTAVE", "PUMP 16", "SYNCO", "ACID",
                                   "GROWL", "2-STEP", "HALF"};
static const char *const STABS[] = {"STAB 1", "STAB 2", "OFFBEATS", "HOUSE", "CHARLESTON", "DOWNBEAT", "PUSH",
                                    "DOTTED"};
static const char *const PADS[] = {"WASH", "TWO HALVES", "SWELL"};
static const char *const LEADS[] = {"TONES UP", "RIFF", "PLUCKS", "CALL", "HOOK", "ECHOES", "ANTHEM", "UPBEATS",
                                   "TWO NOTES", "SKYLINE", "SIGH", "LADDER", "ANSWER", "SWING HOOK", "LONG TONES",
                                   "PULSE RIFF", "FLOAT", "RISE", "QUESTION", "GLIDE", "NIGHT BIRD", "ELECTRIC",
                                   "DREAM", "SAW HYMN", "HEARTBEAT"};
#define NL(a) ((int)(sizeof a / sizeof a[0]))

/* another pattern of a list than cur (cur not in it: any of it); -1 none */
static int other_in(uint32_t *r, const char *const *names, int n, int cur)
{
    int in = 0, c[32], m = 0;
    for (int i = 0; i < n && i < 32; ++i) {
        int p = pat_find(SA_T_SYNTH, names[i]);
        if (p == cur) in = 1;
        else if (p >= 0) c[m++] = p;
    }
    (void)in;
    return m ? c[rnd(r, m)] : -1;
}

void sa_make_b(sa_settings *s, uint32_t seed)
{
    uint32_t r = seed * 2654435761u ^ 0xB5297A4Du;
    if (!r) r = 1;
    memset(s->patb, 0, sizeof s->patb);
    for (int l = 0; l < SA_SYNTHS; ++l) {
        const sa_code *c = &s->code[l];
        if (c->type != SA_T_SYNTH || c->pat == SA_PAT_OFF) continue;
        int b = -1, cur = c->own ? -1 : c->pat;
        if (l == SA_L_LEAD) b = other_in(&r, LEADS, NL(LEADS), cur);
        else if (l == SA_L_BASS) b = other_in(&r, BASS, NL(BASS), cur);
        else {
            int pad = 0;
            for (int i = 0; i < NL(PADS); ++i) pad |= pat_find(SA_T_SYNTH, PADS[i]) == cur;
            b = pad ? other_in(&r, PADS, NL(PADS), cur) : other_in(&r, STABS, NL(STABS), cur);
        }
        if (b >= 0) s->patb[l] = (uint8_t)(b + 1);
    }
    const sa_code *h = &s->code[SA_L_DRUM0 + SA_DR_HATS];   /* the hats busier */
    if (h->type == SA_T_DRUM && h->pat != SA_PAT_OFF) {
        int p = pat_find(SA_T_DRUM, "16THS");
        if (p == h->pat) p = pat_find(SA_T_DRUM, "OFFBEAT");
        if (p >= 0 && p != h->pat) s->patb[SA_L_DRUM0 + SA_DR_HATS] = (uint8_t)(p + 1);
    }
    s->progb = (uint8_t)((s->harm.prog + 1 + rnd(&r, SA_PROGS - 1)) % SA_PROGS + 1);
}

/* ---- EVOLVE (0.8.32): a part renewed while it rests ---- */
static int other_drum(uint32_t *r, const char *const *names, int n, int cur)
{
    int c[16], m = 0;
    for (int i = 0; i < n && i < 16; ++i) {
        int p = pat_find(SA_T_DRUM, names[i]);
        if (p != cur && streq(DPAT[p].name, names[i])) c[m++] = p;
    }
    return m ? c[rnd(r, m)] : -1;
}
/* a layer of the part (b: B) its new line; false: none to give */
static bool renew_layer(sa_groove *g, int l, bool b, uint32_t *r)
{
    static const char *const HATS2[] = {"OFFBEAT", "16THS", "SKIP", "8THS", "SHUFFLE"};
    static const char *const EXTRA[] = {"SYNCO", "CLAVE", "TRESILLO", "UPBEATS", "SPARSE", "GALLOP"};
    sa_settings *s = &g->s;
    sa_code *c = &s->code[l];
    if (c->type == SA_T_NONE || c->own || s->live[l].hand || sa_layer_pending(g, l)) return false;
    int cur = b && s->patb[l] && s->patb[l] != SA_PATB_OFF ? s->patb[l] - 1 : c->pat;
    if (cur == SA_PAT_OFF || (b && s->patb[l] == SA_PATB_OFF)) return false;   /* (OFF stays OFF: it is the mix's) */
    int n = -1;
    if (l == SA_L_LEAD) n = other_in(r, LEADS, NL(LEADS), cur);
    else if (l == SA_L_BASS) n = other_in(r, BASS, NL(BASS), cur);
    else if (l == SA_L_CHORD) {
        int pad = 0;
        for (int i = 0; i < NL(PADS); ++i) pad |= pat_find(SA_T_SYNTH, PADS[i]) == cur;
        n = pad ? other_in(r, PADS, NL(PADS), cur) : other_in(r, STABS, NL(STABS), cur);
    } else if (l == SA_L_DRUM0 + SA_DR_HATS) n = other_drum(r, HATS2, NL(HATS2), cur);
    else if (l >= SA_L_DRUM0 + SA_DR_TOMS) n = other_drum(r, EXTRA, NL(EXTRA), cur);   /* (TOMS RIM PERC; the kick,
                                                     * the snare and the clap are the backbone: left) */
    if (n < 0 || n == cur) return false;
    if (b) g->s.patb[l] = g->ed_patb[l] = (uint8_t)(n + 1);
    else c->pat = g->ed[l].pat = (uint8_t)n;
    return true;
}
/* up to n of the resting part's layers, picked at random; chords: its progression too */
static int part_renew(sa_groove *g, bool b, int n, bool chords, uint32_t seed)
{
    uint32_t r = seed * 2654435761u ^ 0x5BD1E995u;
    if (!r) r = 1;
    int order[SA_LAYERS], m = 0, done = 0;
    for (int l = 0; l < SA_LAYERS; ++l) order[m++] = l;
    for (int i = m - 1; i > 0; --i) { int j = rnd(&r, i + 1), t = order[i]; order[i] = order[j]; order[j] = t; }
    for (int i = 0; i < m && done < n; ++i) done += renew_layer(g, order[i], b, &r);
    if (chords) {
        sa_harm *h = &g->s.harm;
        if (b) {
            int cur = g->s.progb ? g->s.progb - 1 : h->prog;
            if (g->ed_progb == g->s.progb)
                g->s.progb = g->ed_progb = (uint8_t)((cur + 1 + rnd(&r, SA_PROGS - 1)) % SA_PROGS + 1);
        } else if (!memcmp(&g->ed_harm, h, sizeof *h)) {
            h->prog = (uint8_t)((h->prog + 1 + rnd(&r, SA_PROGS - 1)) % SA_PROGS);
            g->ed_harm.prog = h->prog;
        }
    }
    return done;
}
int sa_part_new(sa_groove *g)
{
    int n = part_renew(g, !g->part_b, SA_LAYERS, true, g->clock * 2246822519u + (uint32_t)g->bar * 977u + 7u);
    g->sound_sig++;
    return n;
}

void sa_random(sa_settings *s, uint32_t seed, const sa_pool *p)
{
    static const char *const HATS[] = {"OFFBEAT", "16THS", "SKIP", "OFFBEAT"};
    static const uint8_t BPM[] = {122, 124, 125, 126, 126, 128, 128, 130};
    static const uint8_t FEEL[] = {0, 8, 14, 18, 18, 24};
    static const uint8_t SCL[] = {SA_SC_MINOR, SA_SC_MINOR, SA_SC_MINOR, SA_SC_MINOR, SA_SC_DORIAN, SA_SC_DORIAN,
                                    SA_SC_PHRYGIAN, SA_SC_MAJOR};
    static const uint8_t BARS[] = {1, 2, 2, 4};
    static const uint8_t PUMP[] = {20, 30, 35, 45};
    uint32_t r = seed * 2654435761u ^ 0x9E3779B9u;
    if (!r) r = 1;
    for (int i = 0; i < 4; ++i) rnd_next(&r);
    sa_defaults(s);
    memset(s->code, 0, sizeof s->code);
    s->bpm = BPM[rnd(&r, sizeof BPM)];
    s->feel = FEEL[rnd(&r, sizeof FEEL)];
    s->kit = (uint8_t)rnd(&r, SA_KITS);
    s->pump = PUMP[rnd(&r, sizeof PUMP)];
    s->harm.key = (uint8_t)rnd(&r, 12);
    s->harm.scale = SCL[rnd(&r, sizeof SCL)];
    s->harm.prog = (uint8_t)rnd(&r, SA_PROGS);
    s->harm.bars = BARS[rnd(&r, sizeof BARS)];
    int l = SA_L_DRUM0;
    /* the drums: a kick, hats, a clap or a snare on 2 and 4; sometimes an open hat, a shaker, a rim, a conga, a ride */
    code_drum(&s->code[l++], SA_DV_KICK, pat_find(SA_T_DRUM, rnd(&r, 8) ? "4 FLOOR" : rnd(&r, 2) ? "2-STEP" : "BROKEN"));
    int hat = pick_pat(&r, SA_T_DRUM, HATS, (int)(sizeof HATS / sizeof HATS[0]));
    code_drum(&s->code[l++], rnd(&r, 5) ? SA_DV_HAT : SA_DV_SHAKER, hat);
    code_drum(&s->code[l++], rnd(&r, 3) ? SA_DV_CLAP : SA_DV_SNARE, pat_find(SA_T_DRUM, "2 + 4"));
    (void)hat;
    switch (rnd(&r, 6)) {                          /* (one more, on a row of its own) */
    case 0: code_drum(&s->code[l++], SA_DV_CLAVE, pat_find(SA_T_DRUM, "CLAVE")); break;
    case 1: code_drum(&s->code[l++], SA_DV_RIM, pat_find(SA_T_DRUM, "SYNCO")); break;
    case 2: code_drum(&s->code[l++], SA_DV_CONGA, pat_find(SA_T_DRUM, "TRESILLO")); break;
    case 3: code_drum(&s->code[l++], SA_DV_TAMB, pat_find(SA_T_DRUM, "SYNCO")); break;
    default: break;
    }
    /* BASS always; CHORD stabs or a pad (sometimes gated, sweeping); LEAD now and then, mostly OFF */
    code_synth(&s->code[SA_L_BASS], pick_sound(&r, p->bass, p->nbass),
               pick_pat(&r, SA_T_SYNTH, BASS, (int)(sizeof BASS / sizeof BASS[0])), SA_L_BASS);
    if (rnd(&r, 100) < 55) {
        code_synth(&s->code[SA_L_CHORD], pick_sound(&r, p->keys, p->nkeys),
                   pick_pat(&r, SA_T_SYNTH, STABS, (int)(sizeof STABS / sizeof STABS[0])), SA_L_CHORD);
    } else {
        code_synth(&s->code[SA_L_CHORD], pick_sound(&r, p->pad, p->npad),
                   pick_pat(&r, SA_T_SYNTH, PADS, (int)(sizeof PADS / sizeof PADS[0])), SA_L_CHORD);
        if (rnd(&r, 100) < 35) s->gate[SA_L_CHORD].pat = (uint8_t)(1 + rnd(&r, SA_GATES - 1));
        if (rnd(&r, 100) < 40) s->pan[SA_L_CHORD].mode = SA_PAN_SWEEP;
    }
    code_synth(&s->code[SA_L_LEAD], pick_sound(&r, p->lead, p->nlead),
               pick_pat(&r, SA_T_SYNTH, LEADS, (int)(sizeof LEADS / sizeof LEADS[0])), SA_L_LEAD);   /* (always: a song
                                                     * has a lead; it comes in after a pattern, arrange) */
    sa_settings_fix(s);
    sa_make_b(s, seed);                            /* (on the slots as canon placed them) */
}

/* ---- the engine ------------------------------------------------------------------------------------------------ */
void sa_init(sa_groove *g, float sample_rate)
{
    memset(g, 0, sizeof *g);
    sa_mix_end(g);
    g->fade_gain = 1.0f;
    g->sr = sample_rate;
    sa_defaults(&g->s);
    g->tick = -1;
    g->bar = 0;
    for (int k = 0; k < 27; ++k) {
        g->key_note[k] = -1;
        g->key_part[k] = -1;
    }
    sa_edit_reset(g);
    chord_of_bar(g, 0);
}

void sa_set_sound(sa_groove *g, void (*fn)(void *ctx, const sa_event *e), void *ctx)
{
    g->sound = fn;
    g->sound_ctx = ctx;
}

void sa_edit_reset(sa_groove *g)
{
    memcpy(g->ed, g->s.code, sizeof g->ed);
    memcpy(g->ed_gate, g->s.gate, sizeof g->ed_gate);
    g->ed_harm = g->s.harm;
    memcpy(g->ed_patb, g->s.patb, sizeof g->ed_patb);
    g->ed_progb = g->s.progb;
    g->drop_armed = false;
}

bool sa_layer_pending(const sa_groove *g, int l)
{
    return l >= 0 && l < SA_LAYERS && (memcmp(&g->ed[l], &g->s.code[l], sizeof g->ed[l]) != 0 ||
                                       memcmp(&g->ed_gate[l], &g->s.gate[l], sizeof g->ed_gate[l]) != 0 ||
                                       g->ed_patb[l] != g->s.patb[l]);
}

int sa_pending(const sa_groove *g)
{
    int n = 0;
    for (int l = 0; l < SA_LAYERS; ++l)
        n += sa_layer_pending(g, l);
    n += memcmp(&g->ed_harm, &g->s.harm, sizeof g->ed_harm) != 0 || g->ed_progb != g->s.progb;
    return n;
}

bool sa_used(const sa_groove *g, int l)
{
    return l >= 0 && l < SA_LAYERS && (g->ed[l].type != SA_T_NONE || g->s.code[l].type != SA_T_NONE);
}

int sa_synth_count(const sa_groove *g)
{
    int n = 0;
    for (int l = 0; l < SA_LAYERS; ++l)
        n += g->ed[l].type == SA_T_SYNTH;
    return n;
}

int sa_synth_free_part(const sa_groove *g, int except)
{
    uint8_t used = 0;
    for (int l = 0; l < SA_LAYERS; ++l)
        if (l != except && g->ed[l].type == SA_T_SYNTH && g->ed[l].part < SA_SYNTHS)
            used |= (uint8_t)(1u << g->ed[l].part);
    for (int p = 0; p < SA_SYNTHS; ++p)
        if (!((used >> p) & 1u)) return p;
    return -1;
}

static void emit(sa_groove *g, int on, int part, int note, int vel)
{
    if (!g->sound) return;
    sa_event e = {(uint8_t)on, (uint8_t)part, (uint8_t)clampi(note, 0, 127), (uint8_t)clampi(vel, 1, 127)};
    g->sound(g->sound_ctx, &e);
}

static void msg(sa_groove *g, const char *m)
{
    cpy(g->msg, m, sizeof g->msg);
    g->msg_new = 1;
}

static void note_off_now(sa_groove *g, int i)
{
    emit(g, 0, g->held[i].part, g->held[i].note, 0);
    g->held[i] = g->held[--g->nheld];
}

void sa_all_off(sa_groove *g)
{
    while (g->nheld > 0)
        note_off_now(g, g->nheld - 1);
    g->npend = 0;
}

static void part_off(sa_groove *g, int part)
{
    for (int i = g->nheld - 1; i >= 0; --i)
        if (g->held[i].part == part) note_off_now(g, i);
    for (int i = g->npend - 1; i >= 0; --i)
        if (g->pend[i].part == part) g->pend[i] = g->pend[--g->npend];
}

static float tick_frames(const sa_groove *g)
{
    if (g->ext && g->ext_tf > 1.0f) return g->ext_tf;   /* (MIDI clock in: as it comes) */
    return g->sr * 60.0f / (float)clampi(g->s.bpm, 60, 200) / 24.0f;
}

/* a note now, its note-off after len frames; the part's note at that pitch still sounding is cut first */
static void note(sa_groove *g, int part, int n, int vel, uint32_t len)
{
    if (part == SA_PART_DRUMS && n == 36) {        /* a kick: the pump starts again */
        g->kick_clock = g->clock;
        g->kicked = true;
    }
    for (int i = 0; i < g->nheld; ++i)
        if (g->held[i].part == part && g->held[i].note == n) {
            note_off_now(g, i);
            break;
        }
    if (g->nheld >= SA_HELD) {                     /* full: the oldest goes */
        int o = 0;
        for (int i = 1; i < g->nheld; ++i)
            if ((int32_t)(g->held[i].off - g->held[o].off) < 0) o = i;
        note_off_now(g, o);
    }
    emit(g, 1, part, n, vel);
    g->held[g->nheld].note = (uint8_t)n;
    g->held[g->nheld].part = (uint8_t)part;
    g->held[g->nheld].off = g->clock + (len > 0 ? len : 1u);
    g->nheld++;
}

/* REC: the copy goes in */
static void drop_now(sa_groove *g)
{
    for (int l = 0; l < SA_LAYERS; ++l) {
        const sa_code *o = &g->s.code[l], *n = &g->ed[l];
        if (!memcmp(o, n, sizeof *o)) continue;
        if (o->type == SA_T_SYNTH && (n->type != SA_T_SYNTH || n->sound != o->sound || n->part != o->part))
            part_off(g, o->part);                  /* (its sound changes or it goes: let go of its notes) */
        bool newpat = n->type != SA_T_NONE && (n->pat != o->pat || n->own != o->own || n->type != o->type) &&
                      (n->pat != SA_PAT_OFF || n->own);
        if (n->type != o->type || newpat) {        /* a new pattern (or a layer back): in with it, muted or not yet in */
            g->s.live[l].mute = 0;
            g->build_out &= (uint16_t)~(1u << l);
        }
        g->arp_i[l] = 0;
        bool steps = n->own && (!o->own || n->hits != o->hits || n->acc != o->acc || n->chord != o->chord ||
                                memcmp(n->sn, o->sn, sizeof n->sn) || memcmp(n->sl, o->sl, sizeof n->sl));
        if (steps && g->ed_patb[l] == g->s.patb[l])
            g->ed_patb[l] = 0;                     /* (0.8.40) steps edited by hand: they play in PART B too (its own B
                                                    * line gone), unless a B line was picked for it in the same drop */
    }
    memcpy(g->s.code, g->ed, sizeof g->ed);
    memcpy(g->s.gate, g->ed_gate, sizeof g->ed_gate);
    g->s.harm = g->ed_harm;
    memcpy(g->s.patb, g->ed_patb, sizeof g->s.patb);
    g->s.progb = g->ed_progb;
    g->drop_armed = false;
    g->sound_sig++;
}

void sa_sound_now(sa_groove *g, int l, int sound)
{
    if (l < 0 || l >= SA_LAYERS || g->s.code[l].type != SA_T_SYNTH) return;
    part_off(g, g->s.code[l].part);
    g->s.code[l].sound = (uint8_t)sound;
    g->ed[l].sound = (uint8_t)sound;
    g->sound_sig++;
}

void sa_drop(sa_groove *g)
{
    if (sa_pending(g) == 0) {                      /* (nothing waits: LIVE's next layer, if a build is on) */
        sa_build_next(g);
        return;
    }
    if (!g->playing) {
        drop_now(g);
        chord_of_bar(g, 0);
        msg(g, "DROPPED");
        return;
    }
    g->drop_armed = true;
}

/* LIVE: the order a mix builds in, by its START (the layers that are off left out); the first in at once (EMPTY:
 * none), the rest out */
static void build_setup(sa_groove *g)
{
    static const uint8_t KICK[10] = {SA_L_DRUM0 + SA_DR_KICK, SA_L_DRUM0 + SA_DR_HATS, SA_L_BASS,
                                            SA_L_DRUM0 + SA_DR_CLAP, SA_L_DRUM0 + SA_DR_SNARE, SA_L_CHORD,
                                            SA_L_DRUM0 + SA_DR_PERC, SA_L_DRUM0 + SA_DR_RIM, SA_L_DRUM0 + SA_DR_TOMS,
                                            SA_L_LEAD};
    static const uint8_t PAD[10] = {SA_L_CHORD, SA_L_DRUM0 + SA_DR_KICK, SA_L_BASS, SA_L_DRUM0 + SA_DR_HATS,
                                           SA_L_DRUM0 + SA_DR_CLAP, SA_L_DRUM0 + SA_DR_SNARE, SA_L_LEAD,
                                           SA_L_DRUM0 + SA_DR_PERC, SA_L_DRUM0 + SA_DR_RIM, SA_L_DRUM0 + SA_DR_TOMS};
    int st = g->build_cue;
    g->build_cue = 0;
    g->build_out = 0;
    g->build_n = 0;
    g->build_req = false;
    if (st == SA_START_FULL) return;
    const uint8_t *o = st == SA_START_PAD ? PAD : KICK;
    for (int i = 0; i < 10; ++i) {                 /* (the four layers' ten slots: the synths and the drum rows) */
        const sa_code *c = &g->s.code[o[i]];
        if (c->type == SA_T_NONE || (c->pat == SA_PAT_OFF && !c->own) || g->s.live[o[i]].hand) continue;   /* (MANUAL:
                                                    * in from the start, yours) */
        g->build_order[g->build_n++] = o[i];
        g->build_out |= (uint16_t)(1u << o[i]);
    }
    if (st != SA_START_EMPTY && g->build_n) g->build_out &= (uint16_t)~(1u << g->build_order[0]);
}
int sa_build_peek(const sa_groove *g)
{
    for (int i = 0; i < g->build_n; ++i)
        if ((g->build_out >> g->build_order[i]) & 1u) return g->build_order[i];
    return -1;
}
const char *sa_build_name(const sa_groove *g, int l)
{
    static const char *const S[3] = {"LEAD", "CHORD", "BASS"};
    (void)g;
    return l < 0 ? "" : l < SA_SYNTHS ? S[l] : sa_row_name(l - SA_L_DRUM0);
}
static void build_in(sa_groove *g)
{
    int l = sa_build_peek(g);
    if (l < 0) return;
    g->build_out &= (uint16_t)~(1u << l);
    char t[24];
    int n = 0;
    for (const char *p = sa_build_name(g, l); *p && n < 16; ++p) t[n++] = *p;
    for (const char *p = sa_build_peek(g) < 0 ? " IN: ALL IN" : " IN"; *p; ++p) t[n++] = *p;
    t[n] = 0;
    msg(g, t);
}
void sa_build_next(sa_groove *g)
{
    if (sa_build_peek(g) < 0) {
        msg(g, "NOTHING TO DROP");
        return;
    }
    if (!g->playing) {
        build_in(g);
        return;
    }
    g->build_req = true;
    msg(g, "IN ON THE 1");
}

/* (1.0.3) how a groove plays by itself, carried from the groove playing into a fresh one as it comes in (not on
 * request: turned on while the fresh one waits for its 1, it stays on too) */
static void keep_play(sa_settings *to, const sa_settings *from)
{
    to->phrase = from->phrase;
    to->abauto = from->abauto;
    to->evolve = from->evolve;
    to->arc = from->arc;
    for (int l = 0; l < SA_LAYERS; ++l) to->live[l].hand = from->live[l].hand;
}
static void set_now(sa_groove *g)
{
    const sa_settings *n = g->set_next;
    uint8_t pal = g->s.palette, look = g->s.look;
    uint8_t ph = g->s.phrase, ab = g->s.abauto, ev = g->s.evolve, arc = g->s.arc, hand[SA_LAYERS];
    for (int l = 0; l < SA_LAYERS; ++l) hand[l] = g->s.live[l].hand;
    g->set_next = 0;
    sa_all_off(g);
    g->s = *n;
    g->s.palette = pal;
    g->s.look = look;
    if (g->set_keep) {                             /* (a fresh groove: how it plays by itself, as it was) */
        g->s.phrase = ph;
        g->s.abauto = ab;
        g->s.evolve = ev;
        g->s.arc = arc;
        for (int l = 0; l < SA_LAYERS; ++l) g->s.live[l].hand = hand[l];
    }
    g->set_keep = false;
    sa_settings_fix(&g->s);
    memset(g->arp_i, 0, sizeof g->arp_i);
    g->part_b = g->part_cue = false;               /* (a groove in: its A) */
    build_setup(g);
    bool nob = g->s.progb == 0;                    /* (an older set: no B yet, made from its A) */
    for (int l = 0; l < SA_LAYERS; ++l) nob &= g->s.patb[l] == 0;
    if (nob) sa_make_b(&g->s, (uint32_t)g->s.bpm * 977u + g->s.harm.key * 31u + g->s.harm.prog);
    sa_edit_reset(g);
    g->sound_sig++;
}

void sa_set_arm(sa_groove *g, const sa_settings *s)
{
    sa_mix_end(g);                                 /* (a mix playing: over, what was armed instead) */
    g->set_next = s;
    if (!g->playing) {
        set_now(g);
        chord_of_bar(g, 0);
    }
}

/* ---- STYLE MIX (0.8.25) ------------------------------------------------------------------------------------- */
static float smooth01(float x) { x = x < 0.0f ? 0.0f : x > 1.0f ? 1.0f : x; return x * x * (3.0f - 2.0f * x); }
void sa_mix_end(sa_groove *g)
{
    g->mx_state = 0;
    g->mx_next = 0;
    for (int l = 0; l < SA_LAYERS; ++l) g->mx_gain[l] = 1.0f;
    for (int p = 0; p < SA_SYNTHS; ++p) g->mx_off[p] = 0;
}
static void mix_block(sa_groove *g);
void sa_mix(sa_groove *g, sa_settings *next, uint16_t keep, int out_bars, int in_bars)
{
    if (!g->playing) {                             /* (1.0.2) stopped: in, and playing, faded in over IN as a mix comes in
                                                    * (the drums first, then BASS, CHORD, LEAD) */
        g->set_keep = true;
        sa_set_arm(g, next);
        sa_play(g, true);
        g->mx_next = next;
        g->mx_keep = 0;
        g->mx_out = 1;
        g->mx_in = (uint8_t)clampi(in_bars, 1, 32);
        g->mx_bar0 = 0;
        g->mx_from = g->s.style;
        g->mx_bpm0 = g->mx_bpm1 = g->s.bpm;
        g->mx_state = 2;
        mix_block(g);                              /* (silent till its first 1) */
        msg(g, "MIX: IN");
        return;
    }
    g->set_next = 0;
    g->drop_armed = false;
    g->mx_next = next;
    g->mx_keep = keep;
    g->mx_out = (uint8_t)clampi(out_bars, 1, 16);
    g->mx_in = (uint8_t)clampi(in_bars, 1, 32);
    g->mx_bar0 = g->bar + 1;                       /* (from the next 1) */
    g->mx_from = g->s.style;
    g->mx_state = 1;
    msg(g, "MIX: OUT ON THE 1");
}
float sa_mix_pos(const sa_groove *g)
{
    if (!g->mx_state || g->bar < g->mx_bar0) return 0.0f;
    int n = g->mx_state == 1 ? g->mx_out : g->mx_in;
    float tf = g->sr * 60.0f / (float)clampi(g->s.bpm, 60, 200) / 24.0f;
    float pos = (float)(g->tick < 0 ? 0 : g->tick) + 1.0f - (tf > 0.0f ? g->wait / tf : 0.0f);
    float x = ((float)(g->bar - g->mx_bar0) * (float)SA_TPB + pos) / ((float)n * (float)SA_TPB);
    return x < 0.0f ? 0.0f : x > 1.0f ? 1.0f : x;
}
/* a layer's slots kept with it: its code, its cards, its B pattern; a synth layer's 3D and pump; a drum row the kit
 * (swapped between two grooves, or copied) */
static void mix_swap_b(void *a, void *b, size_t n)
{
    uint8_t *x = (uint8_t *)a, *y = (uint8_t *)b;
    for (size_t i = 0; i < n; ++i) { uint8_t t = x[i]; x[i] = y[i]; y[i] = t; }
}
static void mix_kept(sa_settings *a, sa_settings *b, uint16_t keep, bool swap)
{
#define MXF(f) (swap ? mix_swap_b(&a->f, &b->f, sizeof a->f) : (void)memcpy(&a->f, &b->f, sizeof a->f))
    bool drums = false;
    for (int l = 0; l < SA_LAYERS; ++l) {
        if (!((keep >> l) & 1u)) continue;
        MXF(code[l]);
        MXF(live[l]);
        MXF(gate[l]);
        MXF(pan[l]);
        MXF(patb[l]);
        if (l < SA_SYNTHS) {
            MXF(d3[l]);
            MXF(pl[l]);
            MXF(d3rate[l]);
        }
        drums |= l >= SA_L_DRUM0;
    }
    if (drums) {
        MXF(kit);
        MXF(ktune);
        MXF(ktone);
        MXF(kdecay);
        MXF(kdrive);
        MXF(dvol);
        MXF(dmute);
    }
#undef MXF
}
/* (0.8.27) the levels a mix never goes past: each layer's LEVEL and MUTE, the MIXER's DRUMS, from src into dst for the
 * layers in mask (the drums' own when all the drum rows are): a mix fades from and to the volumes set, the new
 * style's own levels never in */
static void mix_levels(sa_settings *dst, const sa_settings *src, uint16_t mask)
{
    for (int l = 0; l < SA_LAYERS; ++l)
        if ((mask >> l) & 1u) {
            dst->live[l].level = src->live[l].level;
            dst->live[l].mute = src->live[l].mute;
        }
    uint16_t drums = (uint16_t)(((1u << SA_DROWS) - 1u) << SA_L_DRUM0);
    if ((mask & drums) == drums) {                 /* (a drum row kept: the DRUMS' level kept with it already) */
        dst->dvol = src->dvol;
        dst->dmute = src->dmute;
    }
}
/* the key a mix goes into (0.8.26): the next door one on the circle of fifths, so the two share six of their seven
 * notes: minor to major its relative major (a minor third up), major to minor its relative minor (a minor third down),
 * minor to minor or major to major a fifth up (the lift DJs mix into). DORIAN and PHRYGIAN count as minor */
int sa_mix_key(int key, int scale_from, int scale_to)
{
    bool maj0 = scale_from == SA_SC_MAJOR, maj1 = scale_to == SA_SC_MAJOR;
    int d = maj0 == maj1 ? 7 : maj1 ? 3 : 9;
    return (key + d) % 12;
}
/* on the bar line: OUT over, the next groove in, the kept layers the old ones, in a key next door, the old tempo (no copy of a
 * whole groove: the kept slots swapped, then the two grooves, so mx_next holds the new kept ones for the end); IN
 * over, the kept ones the new ones; the tempo on the way, a step a bar */
static void mix_bar(sa_groove *g)
{
    if (!g->mx_state || !g->mx_next || g->bar < g->mx_bar0) return;
    int b = g->bar - g->mx_bar0;
    sa_settings *n = g->mx_next;
    if (g->mx_state == 1 && b >= g->mx_out) {
        uint8_t pal = g->s.palette, look = g->s.look, bpm = g->s.bpm;
        uint8_t key = (uint8_t)sa_mix_key(g->s.harm.key, g->s.harm.scale, n->harm.scale);
        for (int p = 0; p < SA_SYNTHS; ++p)
            if (!((g->mx_keep >> p) & 1u)) part_off(g, p);
        g->mx_bpm0 = bpm;
        g->mx_bpm1 = n->bpm;
        mix_kept(&g->s, n, g->mx_keep, true);
        mix_swap_b(&g->s, n, sizeof g->s);
        keep_play(&g->s, n);                       /* (1.0.3: n now the old groove: how it played by itself, kept) */
        mix_levels(&g->s, n, (uint16_t)~g->mx_keep);   /* (the new layers at the levels set, the old ones'; now in n) */
        g->s.palette = pal;
        g->s.look = look;
        g->s.harm.key = key;                       /* (a key next door to the old one: the kept bass and the new layers
                                                    * agree, the change heard as a lift) */
        g->s.bpm = bpm;
        sa_settings_fix(&g->s);
        memset(g->arp_i, 0, sizeof g->arp_i);
        g->part_b = g->part_cue = false;
        g->build_out = 0;
        bool nob = g->s.progb == 0;
        for (int l = 0; l < SA_LAYERS; ++l) nob &= g->s.patb[l] == 0;
        if (nob) sa_make_b(&g->s, (uint32_t)g->s.bpm * 977u + g->s.harm.key * 31u + g->s.harm.prog);
        sa_edit_reset(g);
        g->sound_sig++;
        g->mx_state = 2;
        g->mx_bar0 = g->bar;
        msg(g, "MIX: IN");
        return;
    }
    if (g->mx_state != 2) return;
    if (b >= g->mx_in) {                           /* over: the kept layers the new ones too, on this 1 */
        for (int p = 0; p < SA_SYNTHS; ++p)
            if ((g->mx_keep >> p) & 1u) part_off(g, p);
        mix_levels(n, &g->s, 0xFFFFu);             /* (the levels as they are set now, kept through the swap) */
        mix_kept(&g->s, n, g->mx_keep, false);
        g->s.bpm = g->mx_bpm1;
        sa_settings_fix(&g->s);
        sa_edit_reset(g);
        g->sound_sig++;
        sa_mix_end(g);
        msg(g, "MIXED");
        return;
    }
    g->s.bpm = (uint8_t)(g->mx_bpm0 + (g->mx_bpm1 - g->mx_bpm0) * (b + 1) / (g->mx_in + 1));
}
/* each block: the layers' levels in the mix (OUT: those not kept down; IN: drums first, then BASS, CHORD, LEAD) */
static void mix_block(sa_groove *g)
{
    if (!g->mx_state) return;
    float x = sa_mix_pos(g);
    for (int l = 0; l < SA_LAYERS; ++l) {
        float v = 1.0f;
        if (!((g->mx_keep >> l) & 1u)) {
            if (g->mx_state == 1) v = g->bar < g->mx_bar0 ? 1.0f : 1.0f - smooth01(x);
            else {
                float at = l >= SA_L_DRUM0 ? 0.0f : l == SA_L_BASS ? 0.15f : l == SA_L_CHORD ? 0.35f : 0.6f;
                v = smooth01((x - at) / (1.0f - at));
            }
        }
        g->mx_gain[l] = v;
    }
    for (int p = 0; p < SA_SYNTHS; ++p)
        g->mx_off[p] = (uint8_t)((1.0f - g->mx_gain[p]) * 127.0f + 0.5f);
}
/* a drum hit's velocity in the mix (0: not heard) */
static int mix_vel(const sa_groove *g, int l, int vel)
{
    if (!g->mx_state || l < SA_L_DRUM0) return vel;
    return (int)((float)vel * g->mx_gain[l] + 0.5f);
}

static void arrange(sa_groove *g);
/* after a long BREAK, the beat of the two bars each drum row is back on: KICK (and the bass) on the 1, the hats,
 * the metal, the rim, the snare on the second bar's 1, the clap, the toms */
static const uint8_t BACK_BEAT[SA_DROWS] = {0, 4, 5, 1, 6, 3, 2};   /* KICK SNARE CLAP HATS TOMS RIM METAL */
static void bar_line(sa_groove *g)
{
    for (int l = 0; l < SA_LAYERS; ++l) {
        g->hits_last[l] = g->hits[l];
        g->hits[l] = 0;
    }
    if (g->arr_fill && !g->fill_held) g->fill_on = 0;   /* (ARC's roll: over on the 1, its crash there) */
    arrange(g);
    if (g->back_on && ++g->back_bar >= 2) g->back_on = 0;   /* (the build back in: two bars) */
    if (g->brk_on && g->brk_held && g->brk_bars < 255) g->brk_bars++;
    if (g->brk_on && !g->brk_held) {               /* BREAK let go: everything back on this 1; after 4 bars or
                                                    * more the drums one by one over two bars (BACK_BEAT) */
        g->brk_on = false;
        g->back_on = g->brk_bars >= 4;
        g->back_bar = 0;
        msg(g, g->back_on ? "BACK IN" : "DROP");
    }
    if (g->build_out && (g->build_req || (g->build_auto && g->bar > 0 && g->bar % g->build_auto == 0))) {
        g->build_req = false;                      /* LIVE: the next layer in, on this 1 */
        build_in(g);
    }
    if (g->bar >= 0 && g->bar % 4 == 0) {          /* PART on the phrase: A/B by itself, or the one wanted */
        int ab = sa_ab_bars(g->s.abauto);
        if (ab && g->bar > 0 && g->bar % ab == 0) g->part_cue = !g->part_b;
        if (g->part_cue != g->part_b) {
            bool rest = g->part_b;                 /* (the part that goes to rest) */
            g->part_b = g->part_cue;
            for (int l = 0; l < SA_LAYERS; ++l) g->arp_i[l] = 0;
            msg(g, g->part_b ? "PART B" : "PART A");
            if (g->s.evolve) {                     /* EVOLVE: it comes back other: LIGHT a layer, MORE two (and now
                                                    * and then its chords) */
                uint32_t sd = (uint32_t)g->bar * 2654435761u + g->clock;
                bool ch = g->s.evolve == 2 && (sd >> 7) % 2u == 0;
                part_renew(g, rest, g->s.evolve == 2 ? 2 : 1, ch, sd);
                msg(g, g->part_b ? "PART B, A EVOLVES" : "PART A, B EVOLVES");
            }
        }
    }
    mix_bar(g);
    if (g->set_next) {
        set_now(g);
        msg(g, "IN ON THE 1");
    } else if (g->drop_armed) {
        drop_now(g);
        msg(g, "DROPPED");
    }
    bar_build(g);
}

void sa_fade_out(sa_groove *g)
{
    if (!g->playing || g->fade_on) return;
    g->fade_on = 1;
    g->fade_x = 0.0f;
    msg(g, "FADING OUT");
}
/* FADE: each block; over a bar the gain down ((1 - x) squared: the ear hears it go evenly), then stopped; stopped, a
 * second and a half for the tails, then back up in half a second */
static void fade_block(sa_groove *g, int frames)
{
    if (g->fade_on) {
        g->fade_x += (float)frames / (4.0f * 60.0f / (float)clampi(g->s.bpm, 60, 200) * g->sr);
        if (g->fade_x >= 1.0f) {
            g->fade_gain = 0.0f;
            sa_play(g, false);
            g->fade_rest = 0.0f;
            msg(g, "FADED OUT");
        } else {
            g->fade_gain = (1.0f - g->fade_x) * (1.0f - g->fade_x);
        }
    } else if (g->fade_gain < 1.0f && !g->playing) {
        g->fade_rest += (float)frames / g->sr;
        if (g->fade_rest > 1.5f) {
            g->fade_gain += (float)frames / (0.5f * g->sr);
            if (g->fade_gain > 1.0f) g->fade_gain = 1.0f;
        }
    }
}
void sa_play(sa_groove *g, bool on)
{
    if (on == g->playing) return;
    g->fade_on = 0;                                /* (FADE: over; playing again at the full level) */
    if (on) g->fade_gain = 1.0f;
    sa_all_off(g);
    if (g->mx_state == 1 && g->mx_next && g->bar >= g->mx_bar0) {   /* (a mix stopped on its way out: the next
                                                                    * groove in, all of it; on its way in: done) */
        g->set_next = g->mx_next;
        g->set_keep = true;
    } else if (g->mx_state == 2 && g->mx_next) {
        mix_levels(g->mx_next, &g->s, 0xFFFFu);
        mix_kept(&g->s, g->mx_next, g->mx_keep, false);
        g->s.bpm = g->mx_bpm1;
        sa_settings_fix(&g->s);
        sa_edit_reset(g);
        g->sound_sig++;
    }
    sa_mix_end(g);
    g->playing = on;
    g->clock = 0;
    g->wait = 0.0f;
    g->ext_credit = 0;                             /* (MIDI clock in: the first pulse after this, the 1) */
    g->tick = SA_TPB - 1;                          /* the first tick wraps into bar 0 (its bar line) */
    g->bar = -1;
    g->arr_out = 0;
    g->arr_brk = g->arr_fill = g->arr_wob = g->arr_wash = false;
    g->arr_sw0 = g->arr_sw1 = 0.0f;
    g->back_on = 0;
    if (!on) {
        g->tick = -1;
        g->bar = 0;
        if (g->set_next) set_now(g);               /* (stopped: what was armed goes in now) */
        else if (g->drop_armed) drop_now(g);
        chord_of_bar(g, 0);
        for (int l = 0; l < SA_LAYERS; ++l) g->hits[l] = g->hits_last[l] = 0;
    }
}

void sa_mute(sa_groove *g, int l, bool m)
{
    if (l < 0 || l >= SA_LAYERS) return;
    g->s.live[l].mute = (uint8_t)m;
    if (m && g->s.code[l].type == SA_T_SYNTH)
        part_off(g, g->s.code[l].part);
}

/* ---- the drum fill (held) ---------------------------------------------------------------------------------------- */
/* the fills: a bar each, a sixteenth a step, up to three hits a step (General MIDI notes: 36 kick, 38 snare, 37 rim,
 * 39 clap, 42 46 the hats, 41 43 45 47 48 50 the toms low to high, 49 crash); a hit's flag: 1 a second one a 32nd
 * later, 2 a flam (a soft one a moment before). Started on a beat, a fill plays from that beat of its bar, so it
 * always peaks on the bar's last sixteenth */
enum { FILL_ROLL, FILL_TOMS, FILL_BUILD, FILL_STUTTER, FILL_FLAM, FILL_SYNCO, FILL_CLAPS, FILL_GHOST, FILLS };
static const char *const FILL_NAMES[FILLS] = {"ROLL", "TOMS", "BUILD", "STUTTER", "FLAM", "SYNCO", "CLAPS", "GHOST"};
typedef struct { uint8_t n, v, f; } fhit;
typedef struct { fhit h[16][3]; } fprog;
#define K(v) {36, v, 0}
#define S(v) {38, v, 0}
#define SD(v) {38, v, 1}
#define SF(v) {38, v, 2}
#define T(n, v) {n, v, 0}
#define C(v) {39, v, 0}
#define CD(v) {39, v, 1}
#define HH(v) {42, v, 0}
#define OH(v) {46, v, 0}
#define R(v) {37, v, 0}
#define NO {0, 0, 0}
static const fprog FILL_PROG[FILLS] = {
    {{{K(110), S(60), NO}, {S(64), NO, NO}, {S(68), NO, NO}, {S(72), NO, NO}, {K(100), S(76), NO}, {S(80), NO, NO},
      {S(84), NO, NO}, {S(88), NO, NO}, {K(110), S(92), NO}, {S(96), NO, NO}, {S(100), NO, NO}, {S(104), NO, NO},
      {K(110), SD(108), NO}, {SD(114), NO, NO}, {SD(120), NO, NO}, {SD(127), K(120), NO}}},
    {{{K(110), S(118), NO}, {S(50), NO, NO}, {T(50, 104), NO, NO}, {T(50, 88), NO, NO}, {K(100), T(48, 106), NO},
      {T(48, 90), NO, NO}, {T(47, 108), NO, NO}, {T(47, 92), NO, NO}, {K(110), T(45, 110), NO}, {T(45, 94), NO, NO},
      {T(43, 112), NO, NO}, {T(43, 96), NO, NO}, {K(110), T(41, 118), NO}, {T(41, 100), NO, NO}, {SD(124), NO, NO},
      {SD(127), K(120), NO}}},
    {{{K(110), S(72), NO}, {NO, NO, NO}, {S(76), NO, NO}, {NO, NO, NO}, {K(100), S(82), NO}, {NO, NO, NO},
      {S(88), NO, NO}, {NO, NO, NO}, {K(110), S(94), NO}, {S(98), NO, NO}, {S(102), NO, NO}, {S(106), NO, NO},
      {K(110), SD(112), NO}, {SD(118), NO, NO}, {SD(124), NO, NO}, {SD(127), OH(110), K(120)}}},
    {{{K(120), HH(100), NO}, {K(70), HH(70), NO}, {K(90), HH(84), NO}, {K(70), HH(70), NO}, {K(120), HH(100), C(110)},
      {K(70), HH(70), NO}, {K(90), HH(84), NO}, {K(70), HH(70), NO}, {K(120), HH(100), NO}, {HH(70), NO, NO},
      {K(90), HH(84), NO}, {HH(70), NO, NO}, {K(120), HH(104), C(118)}, {K(80), HH(80), NO}, {K(110), C(100), NO},
      {K(127), C(124), OH(100)}}},
    {{{K(110), HH(80), NO}, {NO, NO, NO}, {HH(70), S(42), NO}, {NO, NO, NO}, {SF(120), HH(80), NO}, {NO, NO, NO},
      {K(100), HH(70), NO}, {S(44), NO, NO}, {K(110), HH(80), NO}, {NO, NO, NO}, {HH(70), S(46), NO}, {K(96), NO, NO},
      {SF(124), HH(84), NO}, {S(48), NO, NO}, {SF(116), K(100), NO}, {SF(127), K(120), NO}}},
    {{{K(120), S(110), NO}, {NO, NO, NO}, {S(50), NO, NO}, {K(110), S(104), NO}, {NO, NO, NO}, {S(52), NO, NO},
      {K(112), S(110), NO}, {NO, NO, NO}, {K(116), S(112), NO}, {NO, NO, NO}, {S(54), NO, NO}, {K(114), S(114), NO},
      {NO, NO, NO}, {S(60), NO, NO}, {T(45, 118), K(116), NO}, {T(41, 124), SD(120), NO}}},
    {{{K(110), C(90), NO}, {NO, NO, NO}, {C(80), NO, NO}, {NO, NO, NO}, {K(100), C(96), NO}, {NO, NO, NO},
      {C(88), NO, NO}, {NO, NO, NO}, {K(110), C(100), NO}, {C(80), NO, NO}, {C(96), NO, NO}, {C(84), NO, NO},
      {K(110), CD(108), NO}, {CD(114), NO, NO}, {CD(120), NO, NO}, {CD(127), OH(110), K(120)}}},
    {{{K(110), HH(84), NO}, {S(40), NO, NO}, {HH(70), R(70), NO}, {S(44), NO, NO}, {S(118), HH(84), NO},
      {S(42), NO, NO}, {HH(70), K(96), NO}, {S(46), NO, NO}, {K(110), HH(84), NO}, {S(44), R(64), NO},
      {HH(70), S(48), NO}, {K(100), S(52), NO}, {SF(120), HH(84), NO}, {S(56), NO, NO}, {S(62), R(80), NO},
      {SF(127), OH(104), K(118)}}},
};
#undef K
#undef S
#undef SD
#undef SF
#undef T
#undef C
#undef CD
#undef HH
#undef OH
#undef R
#undef NO
const char *sa_fill_name(int kind) { return FILL_NAMES[clampi(kind, 0, FILLS - 1)]; }
void sa_fill(sa_groove *g, bool down)
{
    if (!down && g->fill_on) {
        g->fill_kind = (uint8_t)((g->fill_kind + 1) % FILLS);   /* (next time, the next fill) */
    }
    g->fill_held = down;
    if (!down) g->fill_on = 0;                     /* (let go: the groove again, at once) */
}
void sa_break(sa_groove *g, bool down)
{
    g->brk_held = down;
    if (down && !g->brk_on) {                      /* out at once: let go of what sounds */
        g->brk_on = true;
        g->brk_bars = 0;
        part_off(g, SA_PART_DRUMS);
        part_off(g, g->s.code[SA_L_BASS].part);
        msg(g, "BREAK");
    }
    if (!g->playing && !down) g->brk_on = false;   /* (stopped: no 1 to wait for) */
}
int sa_ab_bars(int i) { static const uint8_t B[SA_ABAUTOS] = {0, 8, 16}; return B[clampi(i, 0, SA_ABAUTOS - 1)]; }
/* (0.8.31) the bars left before PART changes (1: this is the last bar of the old one), the part it goes to; 0: no change
 * coming (stopped, or nothing cued and A/B OFF) */
int sa_part_next(const sa_groove *g, bool *to_b)
{
    if (!g->playing || g->bar < 0) return 0;
    int b = g->bar, ab = sa_ab_bars(g->s.abauto);
    if (g->part_cue != g->part_b) {                /* cued: on the next phrase (every 4 bars) */
        if (to_b) *to_b = g->part_cue;
        return (b / 4 + 1) * 4 - b;
    }
    if (ab) {                                      /* A/B by itself: every 8 or 16 bars */
        if (to_b) *to_b = !g->part_b;
        return (b / ab + 1) * ab - b;
    }
    return 0;
}
void sa_part(sa_groove *g, bool b)
{
    g->part_cue = b;
    if (!g->playing) {
        g->part_b = b;
        chord_of_bar(g, 0);
    }
}

void sa_sweep(sa_groove *g, bool down)
{
    g->sweep_held = down;
    if (!down) g->sweep_man = 0.0f;                /* (let go: open at once) */
}
int sa_intro_bars(int i) { static const uint8_t B[SA_INTROS] = {0, 4, 8, 16}; return B[clampi(i, 0, SA_INTROS - 1)]; }
int sa_arc_bars(int i) { static const uint8_t B[SA_ARCS] = {0, 16, 32, 64}; return B[clampi(i, 0, SA_ARCS - 1)]; }
/* INTRO and ARC, on each bar line: INTRO, from PLAY: the kick first, the other drums at a quarter of it, BASS at half,
 * CHORD at three quarters, LEAD at its end, the filter opening over it. ARC, after it, a cycle: the groove for half,
 * a break (drums and bass out) for a quarter, a build (the filter closing) for the last quarter, a roll on its last
 * half bar, and the drop on the next 1 */
static void arrange(sa_groove *g)
{
    int n = sa_intro_bars(g->s.intro), len = sa_arc_bars(g->s.arc), b = g->bar < 0 ? 0 : g->bar;
    g->arr_out = 0;
    g->arr_brk = g->arr_fill = g->arr_wob = g->arr_wash = false;
    g->arr_sw0 = g->arr_sw1 = 0.0f;
    if (n == 0) {                                  /* no INTRO: the LEAD in after one pattern (the progression once
                                                    * round, 4..8 bars) */
        const sa_harm *h = &g->s.harm;
        int bars = h->bars >= 4 ? 4 : h->bars >= 2 ? 2 : 1;
        int w = clampi(PROG[clampi(h->prog, 0, SA_PROGS - 1)].n * bars, 4, 8);
        if (b < w) g->arr_out |= (uint16_t)(1u << SA_L_LEAD);
        else if (b == w && g->s.code[SA_L_LEAD].type == SA_T_SYNTH && g->s.code[SA_L_LEAD].pat != SA_PAT_OFF)
            msg(g, "LEAD IN");
    }
    if (b < n) {
        for (int l = 0; l < SA_LAYERS; ++l) {
            int at = l == SA_L_DRUM0 + SA_DR_KICK ? 0 : l >= SA_L_DRUM0 ? n / 4 : l == SA_L_BASS ? n / 2 :
                     l == SA_L_CHORD ? 3 * n / 4 : n;
            if (b < at) g->arr_out |= (uint16_t)(1u << l);
        }
        g->arr_sw0 = 0.8f * (1.0f - (float)b / (float)n);
        g->arr_sw1 = 0.8f * (1.0f - (float)(b + 1) / (float)n);
    } else if (len) {
        int p = (b - n) % len, q = len / 4;
        if (p >= len / 2 && p < 3 * q) g->arr_brk = true;
        if (p >= 3 * q) {
            g->arr_sw0 = 0.7f * (float)(p - 3 * q) / (float)q;
            g->arr_sw1 = 0.7f * (float)(p - 3 * q + 1) / (float)q;
        }
        if (p == len - 1) g->arr_fill = true;
        if (p >= 3 * q + q / 2 && p < len - 1) g->arr_wob = true;   /* (0.8.49) the build's second half: WOBBLE */
        if (p == len - 1) g->arr_wash = true;      /* its last bar: WASH, dry again on the drop (sa_fw.c) */
    }
}
/* a drum note of a fill: the snare's and the clap's as their rows play them (their INSTR), the others as written */
static void fill_hit(sa_groove *g, const fhit *h, uint32_t len)
{
    int n = h->n;
    if (!n) return;
    if (n == 38 && g->s.code[SA_L_DRUM0 + SA_DR_SNARE].type == SA_T_DRUM) n = sa_dv_gm(g->s.code[SA_L_DRUM0 + SA_DR_SNARE].sound);
    float sixteenth = tick_frames(g) * (float)SA_TPS;
    if (h->f == 2 && g->npend < SA_PEND) {         /* a flam: the soft one first, then this a moment later */
        note(g, SA_PART_DRUMS, n, h->v / 3, len);
        g->pend[g->npend].at = g->clock + (uint32_t)(g->sr * 0.022f);
        g->pend[g->npend].part = SA_PART_DRUMS;
        g->pend[g->npend].note = (uint8_t)n;
        g->pend[g->npend].vel = h->v;
        g->pend[g->npend].layer = SA_L_DRUM0;
        g->pend[g->npend].len = len;
        g->npend++;
        return;
    }
    note(g, SA_PART_DRUMS, n, h->v, len);
    if (h->f == 1 && g->npend < SA_PEND) {         /* a 32nd: the second one half a sixteenth later */
        g->pend[g->npend].at = g->clock + (uint32_t)(sixteenth * 0.5f);
        g->pend[g->npend].part = SA_PART_DRUMS;
        g->pend[g->npend].note = (uint8_t)n;
        g->pend[g->npend].vel = (uint8_t)(h->v > 12 ? h->v - 12 : h->v);
        g->pend[g->npend].layer = SA_L_DRUM0;
        g->pend[g->npend].len = len;
        g->npend++;
    }
}
static void fill_tick(sa_groove *g, int s)
{
    const fprog *p = &FILL_PROG[g->fill_kind % FILLS];
    uint32_t len = (uint32_t)(g->sr * 0.25f);
    for (int k = 0; k < 3; ++k) fill_hit(g, &p->h[s & 15][k], len);
}

static void do_tick(sa_groove *g)
{
    if (++g->tick >= SA_TPB) {
        g->tick = 0;
        g->bar++;
        bar_line(g);
    }
    int t = g->tick;
    float tf = tick_frames(g);
    if (t == 48 && g->arr_fill && !g->fill_on) {   /* ARC: a roll on the last half bar */
        g->fill_on = 1;
        g->fill_step = 8;
        g->fill_kind = FILL_ROLL;
    }
    if (t % 24 == 0 && g->fill_held && !g->fill_on) {   /* the fill: from the beat after ENV went down, at that beat
                                                      * of its bar (it peaks on the bar's end) */
        g->fill_on = 1;
        g->fill_step = (uint8_t)(t / SA_TPS);
        msg(g, FILL_NAMES[g->fill_kind % FILLS]);
    }
    if (g->fill_on && t % SA_TPS == 0 && !g->brk_on) {
        fill_tick(g, g->fill_step);
        g->fill_step = (uint8_t)(g->fill_step + 1);
        if (g->fill_step >= 16) {                  /* held past a bar: round again, (0.8.43) with the next fill */
            g->fill_step = 0;
            if (g->fill_held && !g->arr_fill) {
                g->fill_kind = (uint8_t)((g->fill_kind + 1) % FILLS);
                msg(g, FILL_NAMES[g->fill_kind % FILLS]);
            }
        }
    }
    uint32_t delay = 0;
    if (t % 12 == 6 && g->s.feel)                  /* FEEL: the off sixteenths late */
        delay = (uint32_t)(tf * 6.0f * (float)g->s.feel / 100.0f * 0.66f);
    while (g->bn_at < g->nbn && g->bn[g->bn_at].tick <= t) {
        const sa_bar_note *b = &g->bn[g->bn_at++];
        if (b->tick != t) continue;
        const sa_code *c = &g->s.code[b->layer];
        if (c->type == SA_T_NONE || g->s.live[b->layer].mute) continue;
        if (c->type == SA_T_DRUM && g->fill_on) continue;   /* (the fill plays in place of the drums) */
        bool hand = g->s.live[b->layer].hand;      /* (MANUAL: not ARC's break, not held out by INTRO or LIVE) */
        if ((g->brk_on || (g->arr_brk && !hand)) && (c->type == SA_T_DRUM || b->layer == SA_L_BASS)) continue;   /* BREAK: out */
        if (!hand && (((g->arr_out | g->build_out) >> b->layer) & 1u)) continue;   /* INTRO, LIVE: not in yet */
        if (g->back_on && c->type == SA_T_DRUM && b->layer >= SA_L_DRUM0 &&
            g->back_bar * 4 + t / 24 < BACK_BEAT[(b->layer - SA_L_DRUM0) % SA_DROWS]) continue;   /* back one by one */
        if (g->solo && !((g->solo >> (c->type == SA_T_DRUM ? 3 : b->layer)) & 1u)) continue;   /* SOLO: the others out */
        if (g->ed_solo && b->layer != g->ed_solo - 1) continue;   /* EDIT's SOLO: the drum edited alone */
        int part = c->type == SA_T_DRUM ? SA_PART_DRUMS : c->part;
        uint32_t len = c->type == SA_T_DRUM ? (uint32_t)(g->sr * (c->sound == SA_DV_CRASH ? 0.2f :
                                                                  c->sound == SA_DV_OPEN ? 0.4f : 0.3f))
                                            : (uint32_t)((float)b->dur * tf);
        int vel = mix_vel(g, b->layer, b->vel);
        if (vel < 1) continue;                     /* (STYLE MIX: faded all the way) */
        g->hits[b->layer] |= (uint16_t)(1u << (t / SA_TPS));
        if (delay == 0 || g->npend >= SA_PEND) {
            pan_note(g, b->layer);
            note(g, part, b->note, vel, len);
        } else {
            g->pend[g->npend].at = g->clock + delay;
            g->pend[g->npend].part = (uint8_t)part;
            g->pend[g->npend].note = b->note;
            g->pend[g->npend].vel = (uint8_t)vel;
            g->pend[g->npend].layer = b->layer;
            g->pend[g->npend].len = len;
            g->npend++;
        }
    }
}

/* the gain x dB down (0..40), without libm: e^(-x ln10/20), by its eighth (a short series) cubed in squares */
static float db_down(float x)
{
    float y = -x * 0.11512925f / 8.0f, r = 1.0f + y * (1.0f + y * (0.5f + y * (1.0f / 6.0f + y / 24.0f)));
    r *= r;
    r *= r;
    return r * r;
}

/* the pump (1.0.1, made audible): down on the kick in 6 ms, held there 30 ms, then back like a sidechain's release,
 * slowly at first and full again by RELEASE (70 % of a beat at 50); its depth in dB: HOME's PUMP 100 % and the layer's
 * DEPTH 100 %: -18 dB (50 %: -9 dB). It was a cut of the level itself (85 % at most) that came straight back: some
 * 3 dB on a pad at the usual settings, hardly heard */
static void pump_block(sa_groove *g)
{
    float beat = 60.0f / (float)clampi(g->s.bpm, 60, 200), master = (float)g->s.pump / 100.0f;
    for (int p = 0; p < SA_SYNTHS; ++p) {
        const sa_pumpl *pl = &g->s.pl[p];
        float d = 0.0f, t = -1.0f;
        if (g->playing && pl->on && pl->depth && g->s.pump) {
            if (pl->src == SA_PS_BEAT) {
                uint32_t fpb = (uint32_t)(g->sr * beat);
                t = fpb ? (float)(g->clock % fpb) / g->sr : -1.0f;
            } else if (g->kicked) {
                t = (float)(g->clock - g->kick_clock) / g->sr;
            }
        }
        if (t >= 0.0f) {
            float db = 18.0f * master * (float)pl->depth / 100.0f, back = (0.25f + (float)pl->rel * 0.009f) * beat, e = 0.0f;
            if (t < 0.006f) e = t / 0.006f;                       /* down */
            else if (t < 0.036f) e = 1.0f;                        /* held */
            else {
                float k = (t - 0.036f) / (back - 0.036f > 0.01f ? back - 0.036f : 0.01f);
                if (k < 1.0f) e = 1.0f - k * k;                   /* back: slow at first */
            }
            if (e > 0.0f) d = 1.0f - db_down(db * e);
        }
        g->duck[p] = (uint8_t)(d * 127.0f + 0.5f);
    }
}

void sa_process(sa_groove *g, int frames)
{
    fade_block(g, frames);
    if (g->sweep_held && g->sweep_man < 1.0f) {    /* SWEEP: closing over two bars */
        float bars2 = 2.0f * 4.0f * 60.0f / (float)clampi(g->s.bpm, 60, 200) * g->sr;
        g->sweep_man += (float)frames / bars2;
        if (g->sweep_man > 1.0f) g->sweep_man = 1.0f;
    }
    {   /* INTRO, ARC: their sweep over the bar; the deeper of the two */
        float a = g->playing ? g->arr_sw0 + (g->arr_sw1 - g->arr_sw0) * (float)(g->tick < 0 ? 0 : g->tick) / (float)SA_TPB
                             : 0.0f;
        if (g->playing && (g->wobble || g->arr_wob)) {   /* WOBBLE (REC held, or ARC's build): a triangle on the eighths */
            float x = (float)((g->tick < 0 ? 0 : g->tick) % 12) / 12.0f, w = 0.65f * (x < 0.5f ? 2.0f * x : 2.0f - 2.0f * x);
            if (w > a) a = w;
        }
        if (g->playing && g->fill_on) {            /* a fill dips the filter towards its end, the 1 opens it */
            float f = 0.55f * (float)(g->tick < 0 ? 0 : g->tick) / (float)SA_TPB;
            if (f > a) a = f;
        }
        g->sweep = g->sweep_man > a ? g->sweep_man : a;
    }
    if (!g->playing) {
        for (int p = 0; p < SA_SYNTHS; ++p) { g->duck[p] = 0; g->gate_gain[p] = 1.0f; g->gate_off[p] = 0; }
        pan_block(g);
        return;
    }
    float tf = tick_frames(g);
    int left = frames;
    if (g->ext && g->ext_credit > 12) g->ext_credit = 1;   /* (MIDI clock in: half a beat behind, caught up at once) */
    while (left > 0) {
        if (g->wait <= 0.0f) {
            if (!g->ext) {
                do_tick(g);
                g->tick_n++;
                g->wait += tf;
            } else if (g->ext_credit > 0) {        /* MIDI clock in: a tick as each pulse comes, none before it */
                do_tick(g);
                g->tick_n++;
                g->ext_credit--;
                g->wait = g->ext_credit > 0 ? 0.0f : 32.0f;
            } else {
                g->wait = 32.0f;                   /* (waiting for the next: looked again in 32 frames) */
            }
        }
        int chunk = (int)g->wait + 1;
        if (chunk > left) chunk = left;
        if (chunk < 1) chunk = 1;
        g->clock += (uint32_t)chunk;
        g->wait -= (float)chunk;
        left -= chunk;
        for (int k = 0; k < g->npend;) {           /* the swung notes */
            if ((int32_t)(g->clock - g->pend[k].at) >= 0) {
                if (!g->s.live[g->pend[k].layer].mute) {
                    pan_note(g, g->pend[k].layer);
                    note(g, g->pend[k].part, g->pend[k].note, g->pend[k].vel, g->pend[k].len);
                }
                g->pend[k] = g->pend[--g->npend];
            } else {
                ++k;
            }
        }
        for (int k = 0; k < g->nheld;) {           /* the note-offs */
            if ((int32_t)(g->clock - g->held[k].off) >= 0) note_off_now(g, k);
            else ++k;
        }
    }
    pump_block(g);
    gate_block(g, frames);
    mix_block(g);
    pan_block(g);
}

void sa_key_drum(sa_groove *g, int k, int dv, bool down) { sa_key(g, k, -1 - clampi(dv, 0, SA_DVS - 1), down, -2); }

void sa_key(sa_groove *g, int k, int note_in, bool down, int layer)
{
    if (k < 0 || k >= 27) return;
    if (down) {
        if (g->key_note[k] >= 0) emit(g, 0, g->key_part[k], g->key_note[k], 0);
        int part = -1, n = note_in, vel = 104;
        if (layer == -2) {                         /* (sa_key_drum: a drum voice, note -1 - dv) */
            part = SA_PART_DRUMS;
            n = sa_dv_gm(-1 - note_in);
        } else if (layer >= 0 && layer < SA_LAYERS && g->s.code[layer].type == SA_T_DRUM) {
            part = SA_PART_DRUMS;
            n = sa_dv_gm(g->s.code[layer].sound);
        } else {
            if (layer >= 0 && layer < SA_LAYERS && g->s.code[layer].type == SA_T_SYNTH)
                part = g->s.code[layer].part;      /* the open layer's part */
            if (part < 0)                          /* no synth layer open: the first synth layer's */
                for (int l = 0; l < SA_LAYERS && part < 0; ++l)
                    if (g->s.code[l].type == SA_T_SYNTH) part = g->s.code[l].part;
            if (part < 0) return;
            n = g->snap ? sa_snap(&g->s.harm, note_in) : note_in;   /* (SNAP OFF: the key as pressed) */
        }
        g->keys |= 1u << k;
        g->key_note[k] = n;
        g->key_part[k] = part;
        emit(g, 1, part, n, vel);
    } else {
        g->keys &= ~(1u << k);
        if (g->key_note[k] >= 0)
            emit(g, 0, g->key_part[k], g->key_note[k], 0);
        g->key_note[k] = -1;
        g->key_part[k] = -1;
    }
}
