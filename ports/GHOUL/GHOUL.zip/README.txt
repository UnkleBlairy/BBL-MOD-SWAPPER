Ghoulbox 2.4 for the BBL Mod Swapper

Original by jasonpersinger: https://github.com/jasonpersinger/ghoulbox-fm1-dungeon-synth
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: GHOUL-source.zip on the ports page.
