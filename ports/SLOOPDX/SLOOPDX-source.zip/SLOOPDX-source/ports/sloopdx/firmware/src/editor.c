/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Editor protocol: SysEx for the web editor (web/EDITOR_PROTOCOL.md; v2 = user presets + live sync,
 * v3 = four tracks: the v1 / v2 commands act on the selected track, cmds 27-30 reach any track;
 * v4 = TRACK_PARAM (31) and the TRACK_CHANGED push (32), enabled by WATCH bit 1;
 * v5 = SLOOP 2.0: INFO ends with the protocol version (5), steps carry level / ratchet bytes,
 * DRUM_STEP (33) reads / writes the drum track's 16 lanes, TRACK ends with the solo mask;
 * v6 = SLOOP 2.3: BK_LIST / BK_GET / BK_PUT (34-36), backup and restore of the storage objects;
 * v7 = sloopDX: BANK_BEGIN / WRITE / END / INFO / ERASE (37-41) load a DX7 .syx bank in pieces, INFO ends
 * with 7, backup object 8 is the bank; the sample-slot commands 11-15 answer rc 7 (no slots);
 * v8 = sloopDX voice editing: VOICE_GET / PUT (42, 43: a packed voice), VOICE_PARAM (44: one unpacked
 * parameter of a user slot, live; its number in two 7-bit bytes), BANK_SAVE (45: the bank to flash, STORE);
 * v9 = 8 user banks: BANK_SELECT (46) picks the one U01..U32 play and the bank commands act on; BANK_INFO ends
 * with its number; INFO ends with 9.
 *   F0 7D 46 4C cmd args.. F7     (7D = non-commercial ID, "FL")
 * Values are 14 bit, two 7-bit bytes LSB first, offset by 8192 (so -8192..8191).
 * Every request gets a reply with the same cmd; 23/24/26 are also pushed
 * while watched. Frames arrive through sx_frame (usb.c), replies leave
 * through ota_wire_send(). */
#ifndef UI_SMALL                 /* (2.7) compiled for size: not the audio path (gfx.c UI_SMALL); the host tests: nothing */
#define UI_SMALL
#endif
#define ED_HDR0 0x7D
#define ED_HDR1 0x46
#define ED_HDR2 0x4C
enum { ED_INFO = 1, ED_GET, ED_SET, ED_DUMP, ED_DESC, ED_STEP_GET, ED_STEP_SET, ED_PRESET, ED_PROJECT, ED_NAMES,
       ED_SMP_BEGIN, ED_SMP_WRITE, ED_SMP_END, ED_SMP_ERASE, ED_SMP_INFO,
       ED_UP_LIST, ED_UP_GET, ED_UP_PUT, ED_UP_STORE, ED_UP_LOAD, ED_UP_ERASE,   /* v2: user presets */
       ED_WATCH, ED_CHANGED, ED_RELOAD, ED_PING, ED_STEP_CHANGED,              /* v2: live sync */
       ED_TRACK, ED_TRACK_MIX, ED_TRACK_DUMP, ED_TRACK_STEP,                    /* v3: tracks */
       ED_TRACK_PARAM, ED_TRACK_CHANGED,                                        /* v4: any track's parameters */
       ED_DRUM_STEP,                                                            /* v5: the 16 drum lanes */
       ED_BK_LIST, ED_BK_GET, ED_BK_PUT,                                        /* v6: backup / restore (SLOOP 2.3) */
       ED_BANK_BEGIN, ED_BANK_WRITE, ED_BANK_END, ED_BANK_INFO, ED_BANK_ERASE,    /* v7: the DX7 user bank (sloopDX) */
       ED_VOICE_GET, ED_VOICE_PUT, ED_VOICE_PARAM, ED_BANK_SAVE,                /* v8: voice editing (sloopDX) */
       ED_BANK_SELECT,                                                          /* v9: 8 user banks (sloopDX) */
       ED_KIT_DICE };                                                           /* v10: MY KIT (backup object 9), dice */
#define ED_PROTOCOL 12                                                        /* v11: 128 steps (INFO nstep 0 = 128) */
/* v12 (sloopDX 4.0, after SLOOP 2.7): backup object 10 = the MIDI part (MIDI LEARN, GLO > MIDI), 11 = your theme;
 * LIVE = 77 (editor_live.c, SLOOP's number) */

static uint8_t ed_out[600];
static uint32_t ed_n;

UI_SMALL static void ed_begin(uint32_t cmd)
{
    ed_out[0] = 0xF0;
    ed_out[1] = ED_HDR0;
    ed_out[2] = ED_HDR1;
    ed_out[3] = ED_HDR2;
    ed_out[4] = (uint8_t)cmd;
    ed_n = 5;
}
UI_SMALL static void ed_b(uint32_t v)
{
    if (ed_n < sizeof ed_out - 1u)
        ed_out[ed_n++] = (uint8_t)(v & 0x7Fu);
}
UI_SMALL static void ed_v(int32_t v)
{
    uint32_t u = (uint32_t)(clamp(v, -8192, 8191) + 8192);
    ed_b(u);
    ed_b(u >> 7);
}
UI_SMALL static void ed_str(const char *s, uint32_t max)   /* ASCII, 0-terminated */
{
    uint32_t i;
    for (i = 0; s && s[i] && i < max; i++)
        ed_b((uint8_t)s[i] & 0x7Fu);
    ed_b(0);
}
UI_SMALL static void ed_send(void)
{
    ed_out[ed_n++] = 0xF7;
    ota_wire_send(ed_out, ed_n);
}
UI_SMALL static int32_t ed_rv(const uint8_t *p) { return (int32_t)(p[0] | p[1] << 7) - 8192; }

/* sloopDX has no sample slots: SMP_BEGIN / WRITE / END / ERASE answer rc 7 (not here), SMP_INFO no slots */
UI_SMALL static uint32_t ed_unpack7(const uint8_t *a, uint32_t na, uint8_t *out, uint32_t max)
{
    uint32_t n = 0;                                 /* groups: msb byte, then up to 7 bytes */
    while (na && n < max) {
        uint32_t m = *a++, j;
        na--;
        for (j = 0; j < 7u && na && n < max; j++, na--)
            out[n++] = (uint8_t)(*a++ | ((m >> j) & 1u) << 7);
    }
    return n;
}
/* the engine byte of DUMP / RELOAD / TRACK: NENGINES = the drum track (no engine) */
UI_SMALL static uint32_t ed_eng(const track_t *t) { return is_drum(t) ? NENGINES : t->eng_req % NENGINES; }

/* ---- live sync (v2): while the editor WATCHes, device-side changes are pushed.
 * Shadows of the selected track's p[] + song.g[] and of its steps are kept in step
 * with what the editor knows (its own SET / STEP_SET update them); the main loop
 * compares and pushes CHANGED / STEP_CHANGED, or RELOAD after a load or when another
 * track was selected (v3: RELOAD and STEP_CHANGED carry the selected track). Pushes
 * go out only into a half-empty SysEx ring, so they never wait. */
#define ED_PUSH_MAX 4u                                   /* frames per pass */
#define ED_NV (P_COUNT + G_COUNT)
/* v4: the parameters of the tracks that are not selected which TRACK_CHANGED follows (the mixer) */
static const uint8_t ED_TIDS[3] = {P_LEVEL, P_PAN, P_MUTE};
#define ED_NT (NTRK * 3u)
static struct {
    uint8_t on, eng, preset, sel;
    uint8_t v4;                                          /* WATCH bit 1: TRACK_CHANGED pushes too */
    uint32_t pos, last_ms, run_ms, resets;
    int16_t v[ED_NV];                                    /* TSEL->p[], then song.g[] */
    uint16_t t[ED_NV];                                   /* ms (low 16 bits) of the last push */
    uint32_t st[NSTEP];                                  /* step signatures */
    int16_t tv[ED_NT];                                   /* v4: trk[k].p[ED_TIDS[j]] at k * 3 + j */
    uint16_t tt[ED_NT];
    uint32_t tpos;
} ed_w;

UI_SMALL static int16_t *ed_val(uint32_t i) { return i < P_COUNT ? &TSEL->p[i] : &song.g[i - P_COUNT]; }
UI_SMALL static uint32_t ed_step_sig(const step_t *s)              /* all 10 bytes (a drum step's lanes too) */
{
    const uint8_t *b = (const uint8_t *)s;
    uint32_t i, h = 0x811C9DC5u;
    for (i = 0; i < sizeof *s; i++)
        h = (h ^ b[i]) * 16777619u;
    return h;
}
/* the drum track's step as a v1..v4 step (old editors): its first 4 lanes as GM notes, ACC when one is hard */
UI_SMALL static void ed_dstep_old(const dstep_t *d, uint32_t *n, uint8_t *notes, uint32_t *time, uint32_t *flags, uint32_t *vel)
{
    uint32_t l, k = 0, hard = 0;
    for (l = 0; l < DRUM_LANES && k < 4u; l++)
        if (dstep_has(d, l)) {
            notes[k++] = LANE_NOTE[l];
            hard |= dstep_lvl(d, l) == LV_HARD;
        }
    *n = k;
    while (k < 4u)
        notes[k++] = 0;
    *time = *n ? ST_NOTE : ST_REST;
    *flags = hard ? SF_ACCENT : 0u;
    *vel = *n ? 100u : 0u;
}
/* a v1..v4 step written into the drum track: its notes onto their lanes */
UI_SMALL static void ed_dstep_from_old(dstep_t *d, const uint8_t *a)
{
    uint32_t i, n = a[0] > 4u ? 4u : a[0];
    memset(d, 0, sizeof *d);
    if (a[5] != ST_NOTE)
        return;
    for (i = 0; i < n; i++)
        dstep_set(d, lane_of_note(a[1 + i] & 0x7Fu), (a[6] & SF_ACCENT) ? LV_HARD : LV_NORM, 0);
}
/* a step's bytes, as STEP_GET sends them (v5: + level, ratchet) */
UI_SMALL static void ed_step_out(const track_t *t, uint32_t i)
{
    uint32_t k;
    if (is_drum(t)) {
        uint32_t n, time, flags, vel;
        uint8_t nt[4];
        ed_dstep_old(&t->dstep[i], &n, nt, &time, &flags, &vel);
        ed_b(n);
        for (k = 0; k < 4u; k++)
            ed_b(nt[k]);
        ed_b(time);
        ed_b(flags);
        ed_b(vel);
        ed_b(0);                                         /* v5: lvl, hi, rat (DRUM_STEP has the lanes' own) */
        ed_b(0);
        ed_b(0);
        return;
    }
    {
        const step_t *st = &t->step[i];
        ed_b(st->n);
        for (k = 0; k < 4u; k++)
            ed_b(st->note[k]);
        ed_b(st->time);
        ed_b(st->flags);
        ed_b(st->vel);
        ed_b(st->lvl);                                   /* v5 (7 bits each: 4 x 2-bit fields, the top 1 below) */
        ed_b(st->lvl >> 7 | (st->rat >> 7) << 1);
        ed_b(st->rat);
    }
}
/* a step written: n, 4 notes, time, flags, vel [, lvl, hi, rat] */
UI_SMALL static void ed_step_in(track_t *t, uint32_t i, const uint8_t *a, uint32_t na)
{
    uint32_t k;
    if (is_drum(t)) {
        ed_dstep_from_old(&t->dstep[i], a);
        return;
    }
    {
        step_t *st = &t->step[i];
        st->n = (uint8_t)(a[0] > 4u ? 4u : a[0]);
        for (k = 0; k < 4u; k++)
            st->note[k] = a[1 + k] & 0x7Fu;
        st->time = (uint8_t)(a[5] > ST_REST ? ST_REST : a[5]);
        st->flags = a[6] & (SF_ACCENT | SF_SLIDE);
        st->vel = a[7] & 0x7Fu;
        if (na >= 11u) {
            st->lvl = (uint8_t)((a[8] & 0x7Fu) | (a[9] & 1u) << 7);
            st->rat = (uint8_t)((a[10] & 0x7Fu) | ((a[9] >> 1) & 1u) << 7);
        } else {
            st->lvl = st->rat = 0;
        }
    }
}
UI_SMALL static void ed_shadow(void)                              /* the editor is in sync */
{
    uint32_t i;
    for (i = 0; i < ED_NV; i++)
        ed_w.v[i] = *ed_val(i);
    for (i = 0; i < NSTEP; i++)
        ed_w.st[i] = ed_step_sig(&TSEL->step[i]);
    for (i = 0; i < ED_NT; i++)
        ed_w.tv[i] = trk[i / 3u].p[ED_TIDS[i % 3u]];
    ed_w.eng = (uint8_t)ed_eng(TSEL);
    ed_w.preset = TSEL->preset;
    ed_w.sel = song.sel;
    sync_reload = 0;
}
UI_SMALL static int ed_room(void) { return so_w - so_r + 8u <= SXQ / 2u; }
UI_SMALL static void ed_known(uint32_t k, uint32_t id)            /* the editor's own change of trk[k].p[id]: no push */
{
    uint32_t j;
    if (k == song.sel) {
        ed_w.v[id] = trk[k].p[id];
        return;
    }
    for (j = 0; j < 3u; j++)
        if (ED_TIDS[j] == id)
            ed_w.tv[k * 3u + j] = trk[k].p[id];
}

UI_SMALL static void ed_sync(void)                                /* main loop */
{
    uint32_t i, n = 0, now = fm1_ms;
    if (!ed_w.on || now - ed_w.run_ms < 5u)
        return;
    ed_w.run_ms = now;
    if (!usb.config || usb.resets != ed_w.resets || now - ed_w.last_ms > 3000u) {
        ed_w.on = 0;                                     /* no host, USB reset, or 3 s without a request */
        return;
    }
    if (sync_reload || ed_eng(TSEL) != ed_w.eng || TSEL->preset != ed_w.preset || song.sel != ed_w.sel) {
        if (!ed_room())
            return;
        ed_shadow();
        ed_begin(ED_RELOAD);
        ed_b(ed_eng(TSEL));
        ed_b(TSEL->preset);
        ed_b(song.sel);
        ed_send();
        return;
    }
    for (i = 0; i < NSTEP && n < ED_PUSH_MAX; i++) {
        uint32_t h = ed_step_sig(&TSEL->step[i]);
        if (h == ed_w.st[i])
            continue;
        if (!ed_room())
            return;
        ed_w.st[i] = h;
        ed_begin(ED_STEP_CHANGED);
        ed_b(i);
        ed_b(song.sel);
        ed_send();
        n++;
    }
    for (i = 0; i < ED_NV && n < ED_PUSH_MAX; i++) {    /* round robin: nothing starves */
        uint32_t k = (ed_w.pos + i) % ED_NV;
        int16_t v = *ed_val(k);
        if (v == ed_w.v[k] || (uint16_t)(now - ed_w.t[k]) < 20u)
            continue;                                    /* coalesced: the latest value goes out later */
        if (!ed_room())
            return;
        ed_w.v[k] = v;
        ed_w.t[k] = (uint16_t)now;
        ed_begin(ED_CHANGED);
        ed_b(k < P_COUNT ? 0u : 1u);
        ed_b(k < P_COUNT ? k : k - P_COUNT);
        ed_v(v);
        ed_send();
        n++;
        ed_w.pos = k + 1u;
    }
    for (i = 0; ed_w.v4 && i < ED_NT && n < ED_PUSH_MAX; i++) {   /* v4: the other tracks' mix */
        uint32_t k = (ed_w.tpos + i) % ED_NT, tr = k / 3u, id = ED_TIDS[k % 3u];
        int16_t v = trk[tr].p[id];
        if (tr == song.sel || v == ed_w.tv[k] || (uint16_t)(now - ed_w.tt[k]) < 20u)
            continue;                                    /* (the selected track: CHANGED above) */
        if (!ed_room())
            return;
        ed_w.tv[k] = v;
        ed_w.tt[k] = (uint16_t)now;
        ed_begin(ED_TRACK_CHANGED);
        ed_b(tr);
        ed_b(id);
        ed_v(v);
        ed_send();
        n++;
        ed_w.tpos = k + 1u;
    }
}

/* descriptor of parameter id of track t: the engine parameters of the engine it asked for
 * (t->engine follows in the audio ISR, after a short fade) */
static const param_desc_t *ed_tdesc(const track_t *t, uint32_t id)   /* the static ones: an engine's */
{                                                                     /* desc hook is the device display only */
    if(is_drum(t) && id==P_E0) return &DRUM_KIT_DESC;
    if (id >= P_E0 && id <= P_E7)
        return &ENGINES[t->eng_req % NENGINES]->edit[id - P_E0];
    return &TP[id];
}
/* descriptor and value slot of (scope, id): scope 0 = the selected track, 1 = global */
UI_SMALL static const param_desc_t *ed_desc(uint32_t scope, uint32_t id, int16_t **vp)
{
    if (scope == 0 && id < P_COUNT) {
        *vp = &TSEL->p[id];
        return ed_tdesc(TSEL, id);
    }
    if (scope == 1 && id < G_COUNT) {
        *vp = &song.g[id];
        return &GP[id];
    }
    return 0;
}

/* ---- v6: backup / restore (web/EDITOR_PROTOCOL.md). Objects: 0 the working project, 1 the settings
 * (colours, calibration, the song order, the lights, SYNC), 2..5 the projects A..D, 6..7 the user preset
 * banks, 8 the DX7 user bank in use, 9 MY KIT (drums.c ukit_img_t: the drum kit in flash; the editor turns it into a
 * .syx and back), 32..34 the user sample slots USR1..3 (read only here: restored with SMP_BEGIN / WRITE / END).
 * LIST takes a snapshot of the working project and the settings; GET reads 1..256 bytes of an object.
 * PUT stages one object in RAM (begin: id, length, CRC-32; data; commit), checks it as a load would,
 * then writes it through the usual A/B commit: a cut-off restore never leaves half an object. */
#if FELUCCA_FLASH
#define ED_BK_RAW ((uint8_t *)&proj_tmp)                  /* the staging RAM (main loop, as the project loads) */
_Static_assert(sizeof proj_tmp >= sizeof(project_t) && sizeof proj_tmp >= sizeof(up_bank_t) &&
               sizeof proj_tmp >= sizeof(persist_t) && sizeof proj_tmp >= sizeof(ukit_img_t), "backup staging");
static uint8_t ed_smp_buf[256];                         /* a BK_PUT piece, unpacked */
static persist_t ed_bk_set;                             /* LIST's snapshot of the settings */
static uint8_t ed_bk_ml[MIDI_PART];                     /* .. and of the MIDI part (2.6, object 10: project.c) */
static uint8_t ed_bk_valid, ed_bk_put, ed_bk_id;
static uint32_t ed_bk_len, ed_bk_crc, ed_bk_pos, ed_bk_ms;
UI_SMALL static void ed_bk_u32(uint32_t v) { uint32_t i; for (i = 0; i < 5u; i++) ed_b((v >> (7u * i)) & 127u); }
UI_SMALL static uint32_t ed_bk_r32(const uint8_t *a)
{
    return (uint32_t)a[0] | (uint32_t)a[1] << 7 | (uint32_t)a[2] << 14 | (uint32_t)a[3] << 21 | (uint32_t)a[4] << 28;
}
UI_SMALL static void ed_bk_pack(const uint8_t *p, uint32_t n)    /* pack7: a top-bits byte, then up to 7 bytes */
{
    while (n) {
        uint32_t k = n > 7u ? 7u : n, m = 0, i;
        for (i = 0; i < k; i++)
            m |= (uint32_t)(p[i] >> 7) << i;
        ed_b(m);
        for (i = 0; i < k; i++)
            ed_b(p[i] & 127u);
        p += k;
        n -= k;
    }
}
UI_SMALL static const uint8_t *ed_bk_obj(uint32_t id, uint32_t *len)   /* 0 = no such object; *len 0 = empty */
{
    *len = 0;
    if (id == 0u) {
        *len = sizeof(project_t);
        return ED_BK_RAW;
    }
    if (id == 1u) {
        *len = sizeof ed_bk_set;
        return (const uint8_t *)&ed_bk_set;
    }
    if (id >= 2u && id <= 5u) {
        if (project_used(id - 2u))
            *len = sizeof proj_slot[0];
        return (const uint8_t *)&proj_slot[id - 2u];
    }
    if (id == 6u || id == 7u) {                           /* a user preset bank, read where it is (upreset.c) */
        const up_bank_t *bk = up_bank_xip[id - 6u];
        if (bk)
            *len = sizeof *bk;
        return bk ? (const uint8_t *)bk : (const uint8_t *)&up_rec_none;
    }
    if (id == 8u) {                                       /* sloopDX: the DX7 user bank (4096 bytes; 0 = none) */
        if (dx_user_ok)
            *len = sizeof dx_user;
        return &dx_user[0][0];
    }
    if (id == 9u) {                                       /* sloopDX 2.1: MY KIT (LIST took its snapshot) */
        *len = sizeof ukit_img;
        return (const uint8_t *)&ukit_img;
    }
    if (id == 10u) {                                      /* 4.0 (SLOOP 2.6): the MIDI part (the MIDI LEARN map, GLO > MIDI's
                                                         * channels): listed only while it is not the default (its
                                                         * restore leaves them as they are) */
        if (!midi_part_default(ed_bk_ml))
            *len = sizeof ed_bk_ml;
        return ed_bk_ml;
    }
    if (id == 11u) {                                      /* 4.0 (SLOOP 2.7): your theme (gfx.c), listed only when there is one */
        if (theme_valid)
            *len = sizeof theme;
        return (const uint8_t *)&theme;
    }
    return 0;
}
static const uint8_t ED_BK_IDS[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};

/* a flash erase silences the audio for ~50 ms and stalls USB: only while stopped, as the panel (SLOOP 2.4); rc 3 */
UI_SMALL static uint32_t ed_flash_busy(void) { return song.playing || transport_req; }

UI_SMALL static uint32_t ed_bk_commit(void)
{
    uint8_t *raw = ED_BK_RAW;
    uint32_t id = ed_bk_id, n = ed_bk_len;
    if (ed_bk_pos != n || st_crc32(raw, n) != ed_bk_crc)
        return 2;
    if (id == 1u)
        return settings_restore(raw, n);
    if (id <= 5u)
        return project_restore(id == 0u ? 4u : id - 2u, raw, n);
    if (id == 6u || id == 7u) {                           /* a user preset bank (n 0: empty) */
        const up_bank_t *b = (const up_bank_t *)raw;
        if (ed_flash_busy())
            return 3;
        if (n && (n != sizeof *b || b->magic != UP_BANK_MAGIC || b->rsize != sizeof(up_rec_t) || b->nslot != UP_PER_BANK))
            return 2;
        if (!flash_ok || st_save(OBJ_UPRESET0 + id - 6u, raw, n))
            return 4;
        up_bank_find(id - 6u);                            /* (the bank is read where it is now) */
        up_gen++;
        return 0;
    }
    if (id == 8u) {                                       /* the DX7 user bank (n 0: none) */
        if (ed_flash_busy())
            return 3;
        if (n && n != sizeof dx_user)
            return 2;
        if (!n)
            return dx_bank_erase() ? 4u : 0u;
        dx_bank_begin();
        dx_bank_write(0, raw, n);
        if (dx_bank_end(dx_bank_sum()))
            return 2;
        return dx_bank_store() ? 4u : 0u;
    }
    if (id == 9u) {                                       /* MY KIT: checked, played at once, kept in flash */
        if (ed_flash_busy())
            return 3;
        if (n != sizeof(ukit_img_t) || ((const ukit_img_t *)raw)->magic != UKIT_MAGIC)
            return 2;
        fm1_irq_off();
        ukit_from_img((const ukit_img_t *)raw);
        fm1_irq_on();
        ui.force = 1;
        return ukit_store() ? 4u : 0u;
    }
    if (id == 10u) {                                      /* 4.0 (SLOOP 2.6): the MIDI part, written with the settings */
        persist_t p;
        if (ed_flash_busy())
            return 3;
        if (n != MIDI_PART)
            return 2;
        midi_part_read(raw);                              /* (every entry and channel checked) */
        persist_fill(&p);
        if (!flash_ok || settings_write(&p))
            return 4;
        persist_saved = p;
        return 0;
    }
    if (id == 11u) {                                      /* SLOOP 2.7: your theme (n 0: none), written with the settings;
                                                         * sent, it is shown (MENU > COLOR on it) */
        persist_t p;
        if (ed_flash_busy())
            return 3;
        theme_t t;
        if (n && n != sizeof(theme_t) && n != 36u)        /* (36: a first-beta THM1, taken with an accent) */
            return 2;
        memset(&t, 0, sizeof t);
        memcpy(&t, raw, n);
        if (n && !theme_check(&t))
            return 2;
        if (n) {
            theme = t;
            theme_valid = 1;
            theme_on = 1;
        } else {
            memset(&theme, 0, sizeof theme);
            theme_valid = 0;
            theme_on = 0;
        }
        palette_set(settings.palette);
        persist_fill(&p);
        if (!flash_ok || settings_write(&p))
            return 4;
        persist_saved = p;
        return 0;
    }
    return 1;
}

UI_SMALL static int ed_backup(uint32_t cmd, const uint8_t *a, uint32_t na)   /* 1: a backup command (reply built) */
{
    uint32_t i, len, rc;
    const uint8_t *p;
    if (cmd == ED_BK_LIST) {
        rc = !flash_ok ? 4u : 0u;
        if (!rc) {
            proj_capture((project_t *)ED_BK_RAW);           /* the working project, as it is now */
            persist_fill(&ed_bk_set);
            ukit_to_img(&ukit_img);                         /* MY KIT, as it is now */
            midi_part_fill(ed_bk_ml);
            ed_bk_valid = 1;
            ed_bk_put = 0;
        }
        ed_b(rc);
        ed_b(rc ? 0u : (uint32_t)sizeof ED_BK_IDS - (ed_bk_obj(10u, &len) && !len ? 1u : 0u) -
                           (ed_bk_obj(11u, &len) && !len ? 1u : 0u));
        for (i = 0; !rc && i < sizeof ED_BK_IDS; i++) {
            p = ed_bk_obj(ED_BK_IDS[i], &len);
            if ((ED_BK_IDS[i] == 10u || ED_BK_IDS[i] == 11u) && !len)
                continue;                                 /* (nothing learned / no theme: not in the list) */
            ed_b(ED_BK_IDS[i]);
            ed_bk_u32(len);
            ed_bk_u32(st_crc32(p, len));
            fm1_wdt_feed();                               /* (a sample slot: up to 80 KiB through the CRC) */
        }
        return 1;
    }
    if (cmd == ED_BK_GET) {                               /* id, off (5), count (2) -> id, rc, off, count, data */
        uint32_t off = na >= 6u ? ed_bk_r32(a + 1) : 0u, count = na >= 8u ? (uint32_t)a[6] | (uint32_t)a[7] << 7 : 0u;
        p = na >= 1u ? ed_bk_obj(a[0], &len) : 0;
        rc = na != 8u || !p || !count || count > 256u || off > len || count > len - off ? 1u
             : !ed_bk_valid || (a[0] == 0u && ed_bk_put) ? 5u : 0u;   /* 5: LIST first (the snapshot is gone) */
        ed_b(na ? a[0] : 127u);
        ed_b(rc);
        ed_bk_u32(off);
        ed_b(rc ? 0u : count & 127u);
        ed_b(rc ? 0u : count >> 7);
        if (!rc)
            ed_bk_pack(p + off, count);
        return 1;
    }
    if (cmd == ED_BK_PUT) {                               /* op, id, ... -> op, id, rc */
        uint32_t op = na >= 2u ? a[0] : 99u, id = na >= 2u ? a[1] : 127u;
        rc = 1;
        if (!flash_ok) {
            rc = 4;
        } else if (op == 0u && na == 12u && (id <= 11u)) {  /* begin: id, length (5), CRC-32 (5) */
            len = ed_bk_r32(a + 2);
            if (id >= 2u || len) {                        /* (the working project and the settings are never empty) */
                if (len <= sizeof proj_tmp) {
                    ed_bk_put = 1;
                    ed_bk_valid = 0;                      /* (the staging RAM is the snapshot's) */
                    ed_bk_id = (uint8_t)id;
                    ed_bk_len = len;
                    ed_bk_crc = ed_bk_r32(a + 7);
                    ed_bk_pos = 0;
                    ed_bk_ms = fm1_ms;
                    rc = 0;
                }
            }
        } else if (!ed_bk_put || ed_bk_id != id || fm1_ms - ed_bk_ms > 15000u) {
            rc = 5;                                       /* no begin for this object (or too long ago) */
        } else if (op == 1u && na >= 9u && ed_bk_r32(a + 2) == ed_bk_pos) {   /* data: off (5), pack7 */
            uint32_t k = ed_unpack7(a + 7, na - 7u, ed_smp_buf, 256u);
            if (k && k <= ed_bk_len - ed_bk_pos) {
                memcpy(ED_BK_RAW + ed_bk_pos, ed_smp_buf, k);
                ed_bk_pos += k;
                ed_bk_ms = fm1_ms;
                rc = 0;
            }
        } else if (op == 2u && na == 2u) {                /* commit */
            rc = ed_bk_commit();
            ed_bk_put = 0;
            if (!rc) {
                sync_reload = 1;
                ui.force = 1;
            }
        } else if (op == 3u && na == 2u) {                /* abort */
            ed_bk_put = 0;
            rc = 0;
        }
        ed_b(op & 127u);
        ed_b(id & 127u);
        ed_b(rc);
        return 1;
    }
    return 0;
}
#else
UI_SMALL static int ed_backup(uint32_t cmd, const uint8_t *a, uint32_t na)   /* no flash: nothing to back up */
{
    (void)a;
    (void)na;
    if (cmd < ED_BK_LIST || cmd > ED_BK_PUT)
        return 0;
    ed_b(4);
    return 1;
}
#endif

#include "editor_live.c"                              /* v12: SLOOP 2.7's LIVE page (77) */

UI_SMALL static void ed_handle(const uint8_t *f, uint32_t n)   /* f: the bytes between F0 and F7 */
{
    uint32_t cmd = f[3], i;
    const uint8_t *a = f + 4;
    uint32_t na = n - 4u;
    int16_t *vp;
    const param_desc_t *d;
    ed_begin(cmd);
    if (ed_backup(cmd, a, na)) {                           /* v6: backup / restore */
        ed_send();
        return;
    }
    switch (cmd) {
    case ED_LIVE:                                          /* v12: the LIVE page */
        if (na < 1u)
            return;
        ed_live(a, na);
        break;
    case ED_INFO:
        ed_str("FELUCCA " FELUCCA_VERSION, 24);
        ed_b(NENGINES);
        ed_b(P_COUNT);
        ed_b(G_COUNT);
        ed_b(NSTEP & 127u);                                /* (v11: 128 steps go as 0: a SysEx byte holds 0..127) */
        ed_b(P_E0);
        for (i = 0; i < NENGINES; i++)
            ed_str(ENGINES[i]->name, 8);
        ed_b(NTRK);                                       /* v3 */
        ed_b(ED_PROTOCOL);                                /* v5: the protocol version (6: backup, 7: sloopDX bank) */
        break;
    case ED_GET:
    case ED_SET:
        if (na < 2u || !(d = ed_desc(a[0], a[1], &vp)))
            return;
        if (cmd == ED_SET && na >= 4u) {
            if (a[0] == 1 && a[1] == G_ENGSEL) {          /* engine change: the safe path */
                set_engine((uint32_t)clamp(ed_rv(a + 2), 0, NENGINES - 1));
            } else if (d->max > d->min) {
                *vp = (int16_t)clamp(ed_rv(a + 2), d->min, d->max);
                if (!a[0] && a[1] == P_SLEN)
                    slen_set(TSEL, *vp);                  /* (the pool: 256 steps for the four tracks) */
            }
            ui.force = 1;
            ed_w.v[a[0] ? P_COUNT + a[1] : a[1]] = *vp;   /* the editor's own change: no push */
        }
        ed_b(a[0]);
        ed_b(a[1]);
        ed_v(*vp);
        break;
    case ED_DUMP:
        for (i = 0; i < ED_NV; i++)                       /* the editor gets them all here */
            ed_w.v[i] = *ed_val(i);
        ed_b(ed_eng(TSEL));
        ed_b(TSEL->preset);
        for (i = 0; i < P_COUNT; i++)
            ed_v(TSEL->p[i]);
        for (i = 0; i < G_COUNT; i++)
            ed_v(song.g[i]);
        break;
    case ED_DESC:
        if (na < 2u || !(d = ed_desc(a[0], a[1], &vp)))
            return;
        ed_b(a[0]);
        ed_b(a[1]);
        ed_b(d->fmt);
        ed_v(d->min);
        ed_v(d->max);
        ed_v(d->def);
        ed_str(d->label, 8);
        ed_str(d->unit, 8);
        if (d->fmt == F_ENUM && d->names)
            for (i = 0; i <= (uint32_t)(d->max - d->min) && i < 64u; i++)   /* (the 34 drum kits) */
                ed_str(d->names[i], 8);
        break;
    case ED_STEP_GET:
    case ED_STEP_SET:
        if (na < 1u || a[0] >= NSTEP)
            return;
        if (cmd == ED_STEP_SET && na >= 9u) {
            fm1_irq_off();
            ed_step_in(TSEL, a[0], a + 1, na - 1u);
            fm1_irq_on();
            ui.force = 1;
        }
        ed_w.st[a[0]] = ed_step_sig(&TSEL->step[a[0]]);
        ed_b(a[0]);
        ed_step_out(TSEL, a[0]);
        break;
    case ED_PRESET:                                        /* engine, preset */
        if (na < 2u || a[0] >= NENGINES)
            return;
        if (a[0] != TSEL->eng_req)
            set_engine(a[0]);
        apply_preset(a[1]);
        ui.force = 1;
        ed_b(ed_eng(TSEL));
        ed_b(TSEL->preset);
        break;
    case ED_PROJECT:                                       /* 0 = load, 1 = save, 2 = query; slot 0..3 */
        if (na < 2u || a[0] > 2u)
            return;
#if FELUCCA_ARRANGER
        if (a[0] < 2u && (song.playing || transport_req)) {
            ed_b(a[0]); ed_b(a[1] & 3u); ed_b(project_used(a[1] & 3u));
            ed_b(1);                                  /* optional status: transport busy */
            break;
        }
#endif
        if (a[0] == 1u)
            project_save(a[1] & 3u);
        else if (a[0] == 0u)
            project_load(a[1] & 3u);
        ed_b(a[0]);
        ed_b(a[1] & 3u);
        ed_b(project_used(a[1] & 3u));
        break;
    case ED_NAMES:                                         /* preset names of an engine */
        if (na < 1u || a[0] >= NENGINES)
            return;
        ed_b(a[0]);
        ed_b(ENGINES[a[0]]->npresets);
        for (i = 0; i < ENGINES[a[0]]->npresets; i++)
            ed_str(ENGINES[a[0]]->presets[i].name, 12);
        for (i = 0; i < 2u; i++)                           /* then the two edit-page titles */
            ed_str(ENGINES[a[0]]->page_title[i], 8);
        break;
    case ED_SMP_BEGIN:                                     /* (no sample slots in sloopDX) */
    case ED_SMP_ERASE:
    case ED_SMP_END:
        ed_b(na ? a[0] : 0u);
        ed_b(7);
        break;
    case ED_SMP_WRITE:
        ed_b(na ? a[0] : 0u);
        ed_b(na > 1u ? a[1] : 0u);
        ed_b(na > 2u ? a[2] : 0u);
        ed_b(na > 3u ? a[3] : 0u);
        ed_b(7);
        break;
    case ED_SMP_INFO:
        ed_b(0);
        ed_b(0);
        break;
    case ED_UP_LIST: {                                     /* start, count -> start, count, total, per slot: used, engine, name */
        uint32_t s0, cnt;
        if (na < 2u)
            return;
        s0 = a[0];
        cnt = a[1] > 16u ? 16u : a[1];
        if (s0 >= UP_SLOTS)
            cnt = 0;
        else if (s0 + cnt > UP_SLOTS)
            cnt = UP_SLOTS - s0;
        ed_b(s0);
        ed_b(cnt);
        ed_b(UP_SLOTS);
        for (i = s0; i < s0 + cnt; i++) {
            char nm[13] = {0};
            uint32_t j, u = (uint32_t)up_used(i);
            for (j = 0; u && j < 12u; j++)
                nm[j] = up_rec(i)->name[j];
            ed_b(u);
            ed_b(u ? up_rec(i)->engine : 0u);
            ed_str(nm, 12);
        }
        break;
    }
    case ED_UP_GET: {                                      /* slot -> slot, used, engine, name, P_COUNT x v14, 16 x (note, flags) */
        int16_t v[P_COUNT];
        char nm[13] = {0};
        const up_rec_t *r;
        uint32_t u;
        if (na < 1u || a[0] >= UP_SLOTS)
            return;
        r = up_rec(a[0]);
        u = (uint32_t)up_used(a[0]);
        if (u)
            up_values(r, v);                               /* today's P_* order, clamped */
        for (i = 0; u && i < 12u; i++)
            nm[i] = r->name[i];
        ed_b(a[0]);
        ed_b(u);
        ed_b(u ? r->engine : 0u);
        ed_str(nm, 12);
        for (i = 0; i < P_COUNT; i++)
            ed_v(u ? v[i] : 0);
        for (i = 0; i < 16u; i++) {
            ed_b(u ? r->note[i] : 0u);
            ed_b(u ? r->flags[i] : 0u);
        }
        break;
    }
    case ED_UP_PUT: {                                      /* slot, engine, name, values, pattern -> slot, rc */
        static up_rec_t r;
        uint32_t slot = 0, rc;
        if (na < 1u)
            return;
        rc = (uint32_t)up_parse(a, na, &r, &slot);
        if (!rc) {
            int16_t v[P_COUNT];
            up_values(&r, v);                              /* each value inside its range */
            for (i = 0; i < P_COUNT; i++)
                r.p[i] = v[i];
            rc = ed_flash_busy() ? 3u : up_put(slot, &r) ? 2u : 0u;
        }
        ed_b(a[0]);
        ed_b(rc);
        break;
    }
    case ED_UP_STORE: {                                    /* slot, name -> slot, rc */
        char nm[13] = {0};
        uint32_t n0, rc = 1;
        if (na < 1u)
            return;
        for (n0 = 0; 1u + n0 < na && a[1 + n0] && n0 < 13u; n0++)
            ;
        if (a[0] < UP_SLOTS && (!n0 || up_name_ok(a + 1, n0))) {   /* "" = automatic name */
            for (i = 0; i < n0; i++)
                nm[i] = (char)a[1 + i];
            int r = ed_flash_busy() ? -3 : up_store(a[0], nm);
            rc = r == -3 ? 3u : r == 1 ? 1u : r ? 2u : 0u;   /* 1: the drum track is selected; 3: stop first */
        }
        ed_b(a[0]);
        ed_b(rc);
        break;
    }
    case ED_UP_LOAD:                                       /* slot -> slot, rc */
        if (na < 1u)
            return;
        ed_b(a[0]);
        ed_b(a[0] < UP_SLOTS && !up_load(a[0]) ? 0u : 1u);
        break;
    case ED_UP_ERASE:
        if (na < 1u)
            return;
        ed_b(a[0]);
        ed_b(a[0] >= UP_SLOTS ? 1u : ed_flash_busy() ? 3u : up_put(a[0], 0) ? 2u : 0u);
        break;
    case ED_WATCH:                                         /* on -> on */
        if (na < 1u)
            return;
        ed_w.on = a[0] & 1u;
        ed_w.v4 = (uint8_t)(ed_w.on && (a[0] & 2u));     /* v4: also TRACK_CHANGED; the reply says it is known */
        ed_w.resets = usb.resets;
        if (ed_w.on)
            ed_shadow();
        ed_b(ed_w.on | ed_w.v4 << 1);
        break;
    case ED_PING:
        ed_b(0);
        break;
    case ED_TRACK:                                         /* [track] -> selected, NTRK, per track: engine, preset, level, mute, armed */
        if (na >= 1u && a[0] < NTRK && a[0] != song.sel) {
            track_select(a[0]);
            if (ed_w.on)
                ed_shadow();                               /* the editor re-reads it: no RELOAD for this */
        }
        ed_b(song.sel);
        ed_b(NTRK);
        for (i = 0; i < NTRK; i++) {
            ed_b(ed_eng(&trk[i]));
            ed_b(trk[i].preset);
            ed_v(i == TRK_DRUM ? song.g[G_DRLVL] : trk[i].p[P_LEVEL]);
            ed_b(trk[i].p[P_MUTE] != 0);
            ed_b((song.rec >> i) & 1u);
        }
        ed_b(song.solo & 15u);                            /* v5: the tracks soloed */
        break;
    case ED_TRACK_MIX: {                                   /* track [, level v14, mute] -> track, level, mute */
        track_t *t;
        int16_t *lv;
        if (na < 1u || a[0] >= NTRK)
            return;
        t = &trk[a[0]];
        lv = a[0] == TRK_DRUM ? &song.g[G_DRLVL] : &t->p[P_LEVEL];
        if (na >= 4u) {
            *lv = (int16_t)clamp(ed_rv(a + 1), 0, 127);
            t->p[P_MUTE] = (int16_t)(a[3] ? 1 : 0);
            if (a[0] == TRK_DRUM)                          /* the editor's own change: no push */
                ed_w.v[P_COUNT + G_DRLVL] = *lv;
            else
                ed_known(a[0], P_LEVEL);
            ed_known(a[0], P_MUTE);
            ui.force = 1;
        }
        ed_b(a[0]);
        ed_v(*lv);
        ed_b(t->p[P_MUTE] != 0);
        break;
    }
    case ED_TRACK_DUMP:                                    /* track -> track, engine, preset, P_COUNT x v14 */
        if (na < 1u || a[0] >= NTRK)
            return;
        ed_b(a[0]);
        ed_b(ed_eng(&trk[a[0]]));
        ed_b(trk[a[0]].preset);
        for (i = 0; i < P_COUNT; i++)
            ed_v(trk[a[0]].p[i]);
        break;
    case ED_TRACK_STEP:                                    /* track, index [, step] -> track, index, step (as STEP_GET) */
        if (na < 2u || a[0] >= NTRK || a[1] >= NSTEP)
            return;
        if (na >= 10u) {
            fm1_irq_off();
            ed_step_in(&trk[a[0]], a[1], a + 2, na - 2u);
            fm1_irq_on();
            ui.force = 1;
        }
        if (a[0] == song.sel)
            ed_w.st[a[1]] = ed_step_sig(&trk[a[0]].step[a[1]]);
        ed_b(a[0]);
        ed_b(a[1]);
        ed_step_out(&trk[a[0]], a[1]);
        break;
    case ED_DRUM_STEP: {                                   /* index [, on 16 bits, lvl 32 bits, rat 32 bits as 7-bit groups]
                                                            * -> index, on (3), lvl (5), rat (5): the drum track's 16 lanes */
        dstep_t *d;
        uint32_t on, lv, rt;
        if (na < 1u || a[0] >= NSTEP)
            return;
        d = &TDRUM->dstep[a[0]];
        if (na >= 14u) {
            on = (uint32_t)a[1] | (uint32_t)a[2] << 7 | (uint32_t)(a[3] & 3u) << 14;
            lv = (uint32_t)a[4] | (uint32_t)a[5] << 7 | (uint32_t)a[6] << 14 | (uint32_t)a[7] << 21 | (uint32_t)(a[8] & 15u) << 28;
            rt = (uint32_t)a[9] | (uint32_t)a[10] << 7 | (uint32_t)a[11] << 14 | (uint32_t)a[12] << 21 | (uint32_t)(a[13] & 15u) << 28;
            fm1_irq_off();
            memset(d, 0, sizeof *d);
            for (i = 0; i < DRUM_LANES; i++)
                if ((on >> i) & 1u)
                    dstep_set(d, i, (lv >> (2u * i)) & 3u, (rt >> (2u * i)) & 3u);
            fm1_irq_on();
            ui.force = 1;
            if (song.sel == TRK_DRUM)
                ed_w.st[a[0]] = ed_step_sig(&TDRUM->step[a[0]]);
        }
        on = dstep_mask(d);
        lv = (uint32_t)d->lvl[0] | (uint32_t)d->lvl[1] << 8 | (uint32_t)d->lvl[2] << 16 | (uint32_t)d->lvl[3] << 24;
        rt = (uint32_t)d->rat[0] | (uint32_t)d->rat[1] << 8 | (uint32_t)d->rat[2] << 16 | (uint32_t)d->rat[3] << 24;
        ed_b(a[0]);
        ed_b(on);
        ed_b(on >> 7);
        ed_b(on >> 14);
        for (i = 0; i < 5u; i++)
            ed_b(lv >> (7u * i));
        for (i = 0; i < 5u; i++)
            ed_b(rt >> (7u * i));
        break;
    }
    case ED_BANK_BEGIN:                                    /* -> rc: the bank is empty until BANK_END takes it */
        dx_bank_begin();
        ui.force = 1;
        ed_b(0);
        break;
    case ED_BANK_WRITE: {                                  /* offset (2), data (1..512, 7-bit voice bytes) -> offset, rc */
        uint32_t off;
        if (na < 2u)
            return;
        off = (uint32_t)a[0] | (uint32_t)a[1] << 7;
        ed_b(a[0]);
        ed_b(a[1]);
        ed_b(dx_bank_write(off, a + 2, na - 2u));
        break;
    }
    case ED_BANK_END: {                                    /* checksum -> rc (0 ok, 1 checksum, 2 flash, 3 playing: in RAM,
                                                            * not stored) */
        uint32_t rc;
        if (na < 1u)
            return;
        rc = (uint32_t)dx_bank_end(a[0]);
        if (!rc)
            rc = ed_flash_busy() ? 3u : (uint32_t)dx_bank_store();
        ui.force = 1;
        ed_b(rc);
        break;
    }
    case ED_BANK_INFO:                                     /* -> ok, 32 names, (v9) the bank in use, banks */
        ed_b(dx_user_ok);
        for (i = 0; i < DX_NUSER; i++)
            ed_str(dx_user_ok ? dx_user_name[i] : "", 10);
        ed_b(dx_bank_cur);
        ed_b(DX_NBANKS);
        break;
    case ED_BANK_SELECT:                                   /* [bank 0..7] -> bank in use, banks, ok (a bank there) */
        if (na >= 1u && !ed_flash_busy()) {               /* (playing: the bank stays; the reply says which) */
            if (dx_bank_select(a[0]))
                return;
            ui.force = 1;
        }
        ed_b(dx_bank_cur);
        ed_b(DX_NBANKS);
        ed_b(dx_user_ok);
        break;
    case ED_BANK_ERASE:                                    /* -> rc */
        ui.force = 1;
        ed_b(ed_flash_busy() ? 3u : (uint32_t)dx_bank_erase());
        break;
    case ED_VOICE_GET: {                                   /* index 0..48 (VOICE) -> index, 128 packed bytes */
        uint8_t b[128];
        if (na < 1u || a[0] >= DX_NVOICES)
            return;
        dx_voice_get(a[0], b);
        ed_b(a[0]);
        for (i = 0; i < 128u; i++)
            ed_b(b[i]);
        break;
    }
    case ED_VOICE_PUT:                                     /* slot 0..31, 128 packed bytes -> slot, rc (0 ok, 1 args) */
        if (na < 1u)
            return;
        ed_b(a[0]);
        if (a[0] >= DX_NUSER || na < 129u) {
            ed_b(1);
            break;
        }
        dx_user_put(a[0], a + 1);
        ui.force = 1;
        ed_b(0);
        break;
    case ED_VOICE_PARAM: {                                 /* slot, idx (2 x 7 bit) [, value] -> slot, idx (2), value */
        uint32_t idx = na >= 3u ? (uint32_t)a[1] | (uint32_t)a[2] << 7 : DX_NPARAM;   /* (0..154: two bytes) */
        if (na < 3u || a[0] >= DX_NUSER || idx >= DX_NPARAM)
            return;
        if (na >= 4u) {
            dx_user_param_set(a[0], idx, a[3]);
            ui.force = 1;
        }
        ed_b(a[0]);
        ed_b(idx);
        ed_b(idx >> 7);
        ed_b(dx_user_param_get(a[0], idx));
        break;
    }
    case ED_KIT_DICE: {                                    /* seed (3 x 7 bit, 1..65535) -> rc, seed (3): MY KIT rolled,
                                                            * the drum track plays it (not in flash until SAVE) */
        uint32_t seed = na >= 3u ? ((uint32_t)a[0] | (uint32_t)a[1] << 7 | (uint32_t)a[2] << 14) & 0xFFFFu : 0u;
        if (!seed)
            seed = (fm1_ms * 2654435761u >> 16) % 65535u + 1u;
        fm1_irq_off();
        dice_kit(seed);
        TDRUM->p[P_E0] = KIT_USER;
        fm1_irq_on();
        ui.force = 1;
        ed_b(0);
        ed_b(seed & 127u);
        ed_b((seed >> 7) & 127u);
        ed_b(seed >> 14);
        break;
    }
    case ED_BANK_SAVE:                                     /* -> rc (0 ok, 1 no bank, 2 flash) */
        ed_b(!dx_user_ok ? 1u : ed_flash_busy() ? 3u : (uint32_t)dx_bank_store());
        break;
    case ED_TRACK_PARAM: {                                 /* track, id [, v14] -> track, id, v14 */
        track_t *t;
        if (na < 2u || a[0] >= NTRK || a[1] >= P_COUNT)
            return;
        t = &trk[a[0]];
        d = ed_tdesc(t, a[1]);
        if (na >= 4u) {
            if (d->max > d->min)                           /* as SET: clamped; a fixed value stays */
                t->p[a[1]] = (int16_t)clamp(ed_rv(a + 2), d->min, d->max);
            if (a[1] == P_SLEN)
                slen_set(t, t->p[P_SLEN]);
            ed_known(a[0], a[1]);
            ui.force = 1;
        }
        ed_b(a[0]);
        ed_b(a[1]);
        ed_v(t->p[a[1]]);
        break;
    }
    default:
        return;
    }
    ed_send();
}

/* main loop: editor frames first; anything else stays for ota_service() */
UI_SMALL static void ed_service(void)
{
    const uint8_t *p;
    uint32_t n;
    ed_sync();                                             /* v2 pushes (while watched) */
    if (!ota_frame_get(&p, &n) || n < 4u || p[0] != ED_HDR0 || p[1] != ED_HDR1 || p[2] != ED_HDR2)
        return;
    ed_w.last_ms = fm1_ms;                                 /* any request keeps WATCH alive */
    if (p[3] >= ED_SMP_BEGIN) {                            /* large frames: handled in place, then freed */
        ed_handle(p, n);
        ota_frame_done();
        return;
    }
    {
        static uint8_t f[64];
        uint32_t k = n > sizeof f ? sizeof f : n, i;
        for (i = 0; i < k; i++)
            f[i] = p[i];
        ota_frame_done();                                  /* free the frame buffer before replying */
        ed_handle(f, k);
    }
}
