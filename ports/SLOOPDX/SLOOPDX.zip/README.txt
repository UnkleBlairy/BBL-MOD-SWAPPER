SLOOP DX 4.0.1 for the BBL Mod Swapper

Original by zvenson: https://github.com/zvenson/dxsloop
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: SLOOPDX-source.zip on the ports page.
