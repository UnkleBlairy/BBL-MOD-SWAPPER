/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Styves Goupil */
/* FRASIL's screen: RIVER. The river at night, carrying frasil.
 *   pitch is altitude above the waterline; a voice is a current carrying ice crystals, as long and as dense as it
 *   is loud; pressure warms its crystals to lamp light; FREEZE sets them into a lattice and stills the water; the
 *   reverb (SPACE) is the haze off the water; a glint is a glint in the sky, always at the same place for a note;
 *   the bass is the river's bed, a slow swell the river's width at its note's height.
 * The drone's three layers own the river's three things: CHOIR the current, PARTIALS the crystals, BREATH the
 * water's haze around it; their mix shows there, and exactly, as three strata under the waterline on the play page.
 * Three bands, each drawn on the canvas and blitted: the header (0 .. 31), the river (32 .. 175, 20 frames a
 * second), the footer (176 .. 239: the three hands, or the page's second row). The pages' parameters sit in a 2 x 2
 * grid across the river's lower half and the footer; on the play page (SOUND) and for the three hands, a turn shows
 * the value large over the river for a moment instead.
 * Part of the unity build (app.c includes it): gfx.c's canvas (cv_px, byte-swapped RGB565) is in scope. */

#define C_BG RGB(0, 0, 0)               /* the night, pitch black: the most contrast (card #124) */
#define C_STEEL RGB(38, 48, 60)          /* structure: gauge tracks */
#define C_SLATE RGB(74, 85, 99)          /* quiet marks, the waterline */
#define C_MIST RGB(139, 149, 164)        /* labels */
#define C_FOG RGB(220, 227, 234)         /* values, the voices */
#define C_LAMP RGB(242, 166, 90)         /* warm: the hand (pressure, what is being turned, what changed) */
#define C_ICE RGB(110, 208, 255)         /* cold: the ice (PARTIALS' crystals, GLINT, FREEZE, a choice made) */
#define C_HAZE RGB(51, 65, 79)
#define C_SINK RGB(10, 100, 176)         /* SINK's water, a clear blue over the river */
#define C_GLOB RGB(169, 210, 188)         /* an LFO's TARGET that is no track's: the master, the cloud, the effects */
#define C_RED RGB(255, 56, 56)           /* a setting let go of its LFO (LFO held, a knob turned: NO LFO) */
#define C_BATT RGB(72, 214, 120)         /* the header's battery: its charge (yellow at 30 %, C_RED at 10 %) */
#define C_BATT_LOW RGB(255, 208, 64)

#define ML 14                            /* margins */
#define MR 226
#define R1 0                             /* the bands' first rows */
#define R2 32
#define R3 176
#define HZ 175                           /* the waterline */
#define HZ_HOME 116                      /* the play page's: the strata below it */
#define TOUCH_MS 900u                    /* a turned value stays large this long */

#include "frasil_logo.h"                 /* LOGO_W x LOGO_H, 4-bit (tools/gen_logo.py) */

static int32_t oy;                       /* the band being drawn: its first screen row */

/* the header's two looks (GLO > SCREEN's HEADER, app.c hdr): INVERT, the whole band in the selected track's colour
 * (DRONE fog, GLINT ice, BASS lamp), everything on it dark; DARK, the band the night's, everything on it in the track's
 * colour, a hairline of it under the band. C_ONBAND: what is drawn on the band; band_col(): the band under it */
#if PLAT_SMK37
#define C_GLINT_TRACK RGB(28, 124, 255)  /* GLINT's own on the SMK-37: the header band, its marks; saturated and darker than
                                          * the ice, apart from DRONE's fog at a glance (Styves, 2026-11-09) */
#else
#define C_GLINT_TRACK C_ICE
#endif
#if FRS_MIDI_OUT
#define C_MIDI_TRACK RGB(176, 140, 255)  /* MIDI's (card #164): an aurora's violet, the light above the river and not in
                                          * it (its notes go out, nothing sounds here); apart from GLINT's blues and
                                          * LEAD's rose */
#endif
#if FRS_LEAD
#define C_LEAD_TRACK RGB(255, 112, 132)  /* LEAD's (card #144): a warm rose, apart from BASS's lamp and the alerts' red */
static uint16_t track_col(void)
{
#if FRS_MIDI_OUT
    if (mout.sel)
        return C_MIDI_TRACK;
#endif
    return st.lead ? C_LEAD_TRACK : st.glint ? C_GLINT_TRACK : st.bass ? C_LAMP : C_FOG;
}
#else
static uint16_t track_col(void) { return st.glint ? C_GLINT_TRACK : st.bass ? C_LAMP : C_FOG; }
#endif
static uint16_t band_col(void) { return hdr.dark ? C_BG : track_col(); }
static uint16_t band_ink(void) { return hdr.dark ? track_col() : C_BG; }
#define C_ONBAND band_ink()
static uint16_t head_red(void) { return hdr.dark ? C_RED : RGB(170, 16, 16); }   /* a red word on it (NO LFO) */

static struct {
    uint32_t field_at, frames, fps_at, fps;
    uint32_t sig1, sig3;                 /* what the header and the footer showed last */
    uint32_t mid;                        /* the page the middle band showed last, the value large over it or not */
    uint32_t frz_at;                     /* when the freeze last changed (the crystals ease to it) */
    uint8_t frz;
    uint8_t full;
    uint8_t was_logo, was_map, was_pop, was_saver;
    uint8_t logo_again;                  /* the logo's screen still (ANIMATIONS LOW): once more (app_redraw) */
    uint8_t acts;                        /* the words SCENES' box showed last: 4, 2 on NEW SHARD (the tests) */
    uint8_t stack;                       /* the STACK hint the footer drew last: 0 none, 1 OFF, 2 ON (the tests) */
    int8_t semis;                        /* the half-tones LOFI TAPE II's tones stood for, drawn last: 0 none (the tests) */
    uint8_t tonew;                       /* their word: 0 none, 1 TONE, 2 TONES (the tests) */
    uint32_t help_sig;
    float stillt;                        /* the river's time when it froze */
    float lt, gph, wph;                  /* the logo's last frame's time; how far its granules and its water have gone */
    int32_t edge[240];                   /* the haze fades in at the sides: 0 .. 256 */
    float sn[256];                       /* a sine a turn */
} ui;

static uint32_t strlen_(const char *s)
{
    uint32_t n = 0;
    while (s[n])
        n++;
    return n;
}

/* ------------------------------------------------------------ drawing --- */
static inline uint16_t mix565(uint16_t bg, uint16_t c, int32_t a)   /* a of 32, rounded (no green cast) */
{
    uint32_t r = c >> 11, g = (c >> 5) & 63u, b = c & 31u, br = bg >> 11, bgg = (bg >> 5) & 63u, bb = bg & 31u;
    uint32_t ia = 32u - (uint32_t)a;
    return (uint16_t)(((r * (uint32_t)a + br * ia + 16u) >> 5) << 11 | ((g * (uint32_t)a + bgg * ia + 16u) >> 5) << 5 |
                      ((b * (uint32_t)a + bb * ia + 16u) >> 5));
}

static inline void bl(int32_t x, int32_t y, uint16_t c, int32_t a)   /* screen coordinates, a of 32 */
{
    uint16_t *p;
    y -= oy;
    if (a <= 0 || (uint32_t)x >= cv_w || (uint32_t)y >= cv_h)
        return;
    p = &cv_px[(uint32_t)y * cv_w + (uint32_t)x];
    *p = swap16(a >= 32 ? c : mix565(swap16(*p), c, a));
}

#if APP_CPU_LINE
static void cl_band_start(void);
#endif
static void band(int32_t y0, int32_t h)
{
#if APP_CPU_LINE
    cl_band_start();                     /* (the load's line's row first, if it moved: a wait the band has anyway) */
#endif
    oy = y0;
    cv_begin(240, (uint32_t)h, C_BG);
}

static void hline(int32_t x0, int32_t x1, int32_t y, uint16_t c) { cv_rect(x0, y - oy, x1 - x0 + 1, 1, c); }

static int32_t text_tw(const felucca_font_t *f, const char *s, int32_t tr)   /* width, tracked */
{
    int32_t n = (int32_t)strlen_(s);
    return text_w(f, s) + (n > 1 ? tr * (n - 1) : 0);
}

static int32_t text_t(int32_t x, int32_t y, const felucca_font_t *f, const char *s, uint16_t c, int32_t tr)
{
    char ch[2] = {0, 0};
    for (; *s; s++) {
        ch[0] = *s;
        x = cv_text(x, y - oy, f, ch, c) + tr;
    }
    return x - tr;
}

/* a page's title, top left: white, bold (drawn twice a pixel apart), tracked; returns its end */
static int32_t title(const char *s, int32_t tr)
{
    text_t(ML, 8, &FONT_B, s, C_WHITE, tr + 1);
    return text_t(ML + 1, 8, &FONT_B, s, C_WHITE, tr + 1) + 1;
}

static void text_r(int32_t xr, int32_t y, const felucca_font_t *f, const char *s, uint16_t c, int32_t tr)
{
    text_t(xr - text_tw(f, s, tr), y, f, s, c, tr);
}

static void text_c(int32_t xc, int32_t y, const felucca_font_t *f, const char *s, uint16_t c, int32_t tr)
{
    text_t(xc - text_tw(f, s, tr) / 2, y, f, s, c, tr);
}

/* a name in the room it has (w), as large as it fits: FONT_B tracked tr, then closer, then FONT_S, then FONT_XS; cut
 * last. bold: drawn twice, a pixel apart (a title's). Returns its end */
static int32_t fit_text(int32_t x, int32_t y, int32_t w, const char *s, uint16_t c, int bold, int32_t tr)
{
    static const felucca_font_t *const F[3] = {&FONT_B, &FONT_S, &FONT_XS};
    char t[SC_LONG + 8];                 /* (a name and what goes before it: INTO's "09 ") */
    int32_t k, r = 0, n;
    const felucca_font_t *f = 0;
    for (k = 0; k < 3 && !f; k++)
        for (r = k ? 1 : tr; r >= 0; r--)
            if (text_tw(F[k], s, r) + bold <= w) {
                f = F[k];
                break;
            }
    if (!f) {                                /* (still too wide: FONT_XS, as much as fits) */
        f = &FONT_XS;
        r = 0;
    }
    for (n = 0; s[n] && n < (int32_t)sizeof t - 1; n++)
        t[n] = s[n];
    t[n] = 0;
    while (n > 0 && text_tw(f, t, r) + bold > w)
        t[--n] = 0;
    y += f == &FONT_XS;
    if (bold)
        text_t(x, y, f, t, c, r);
    return text_t(x + bold, y, f, t, c, r) + bold;
}

static uint8_t ui_off;                   /* a setting whose effect is off is being drawn (cell_w): slate */

static void gauge(int32_t x, int32_t y, int32_t w, float v, uint16_t fill)
{
    int32_t n = (int32_t)(v * (float)w + 0.5f);
    n = clamp(n, 1, w);
    hline(x, x + w - 1, y, C_STEEL);
    hline(x, x + n - 1, y, fill);
    cv_rect(x + n - 1, y - 2 - oy, 1, 5, ui_off ? C_SLATE : C_FOG);
}

/* an LFO's AMOUNT, slot's (0 .. 11): x1.00 at the middle, x0.00 at the left, x5.00 at the right; filled from the middle
 * to it, a tick there and a short one at the middle */
static void gauge_amt(int32_t x, int32_t y, int32_t w, uint32_t slot, uint16_t bed, uint16_t fill, uint16_t mid)
{
    uint32_t p = P_L1_AMT1 + slot;
    int32_t c = x + (w - 1) / 2, n = x + (int32_t)((float)st.v[p] * (float)(w - 1) / (float)PD[p].max + 0.5f);
    hline(x, x + w - 1, y, bed);
    hline(n < c ? n : c, n < c ? c : n, y, fill);
    cv_rect(c, y - 1 - oy, 1, 3, mid);
    cv_rect(n, y - 2 - oy, 1, 5, fill);
}

/* a factor's gauge (TAPE SPEED: x0.25 .. x1.00 .. x2.00, times_p): filled from its x1.00 (its default) to it, a tick
 * there and a short one at x1.00 */
static void gauge_times(int32_t x, int32_t y, int32_t w, int p, uint16_t fill)
{
    float k = (float)(w - 1) / (float)PD[p].max;
    int32_t c = x + (int32_t)((float)PD[p].def * k + 0.5f), n = x + (int32_t)((float)pv_shown(p) * k + 0.5f);
    hline(x, x + w - 1, y, C_STEEL);
    hline(n < c ? n : c, n < c ? c : n, y, fill);
    cv_rect(c, y - 1 - oy, 1, 3, ui_off ? C_SLATE : C_MIST);
    cv_rect(n, y - 2 - oy, 1, 5, ui_off ? C_SLATE : C_FOG);
}

/* a multiplication sign, s pixels across, its top left at (x, y): its two diagonals 1.6 px thick, smoothed (the fonts
 * have no ×) */
static void times_mark(int32_t x, int32_t y, int32_t s, uint16_t c)
{
    int32_t i, j;
    for (j = 0; j < s; j++)
        for (i = 0; i < s; i++) {
            float u = (float)i + 0.5f, v = (float)j + 0.5f, d1 = fm_fabsf(u - v), d2 = fm_fabsf(u + v - (float)s);
            float d = (d1 < d2 ? d1 : d2) * 0.7071f, a = (0.8f + 0.5f - d) * 32.0f;
            bl(x + i, y + j, c, a >= 32.0f ? 32 : (int32_t)a);
        }
}

/* SEL + K, the header: "LFO n" and AMOUNT on the left, the multiplier large on the right (x0.50, x3.00), and under them
 * a bar from the middle (x1.00), filled to the left down to x0.00 at its end, to the right up to x5.00 */
static void amt_head(uint32_t slot, uint16_t fg, uint16_t soft)
{
    uint32_t v = st.v[P_L1_AMT1 + slot], m = v <= 100u ? v : 100u + 4u * (v - 100u);
    char t[5] = {(char)('0' + m / 100u % 10u), '.', (char)('0' + m / 10u % 10u), (char)('0' + m % 10u), 0};
    char w[6] = {'L', 'F', 'O', ' ', (char)('1' + slot / 4u), 0};
    int32_t x = text_t(ML, 8, &FONT_B, w, fg, 1), xv = MR - text_tw(&FONT_M, t, 0), w0 = MR - ML + 1;
    int32_t c = ML + (w0 - 1) / 2, n = ML + (int32_t)((float)v * (float)(w0 - 1) / (float)PD[P_L1_AMT1 + slot].max + 0.5f);
    text_t(ML + 1, 8, &FONT_B, w, fg, 1);
    text_t(x + 7, 9, &FONT_XS, "AMOUNT", soft, 1);
    text_t(xv, 1, &FONT_M, t, fg, 0);
    times_mark(xv - 11, 10, 8, fg);
    cv_rect(ML, 27 - oy, w0, 3, soft);   /* (the bar: its bed, filled from the middle, the middle marked) */
    cv_rect(n < c ? n : c, 27 - oy, (n < c ? c - n : n - c) + 1, 3, fg);
    cv_rect(c, 25 - oy, 1, 7, fg);
}

/* the control a value is under, before its name, a filled disc: K1 .. K4 ice with the number, the three left
 * encoders amber with a letter (A SELECT, B PRESETS, C ALGORITHM; the SMK-37's their knobs' numbers, 6, 5 and 7:
 * controls.h). Centred on (cx, cy); 14 px across (12 in the strata) */
#define BADGE_W 19                       /* the badge and the gap after it */
/* a glyph's ink: the box of its pixels at least half covered, in its bitmap (columns from the bitmap's left edge, rows
 * from its top); none: 0 .. -1 */
static void glyph_ink(const felucca_font_t *f, char ch, int32_t *x0, int32_t *x1, int32_t *y0, int32_t *y1)
{
    uint32_t gi = glyph(f, (uint8_t)ch), w = f->bw[gi], bpr = (w + 1u) / 2u, gx, gy;
    const uint8_t *gd = f->data + f->off[gi];
    *x0 = *y0 = 0;
    *x1 = *y1 = -1;
    for (gy = 0; gy < f->h; gy++)
        for (gx = 0; gx < w; gx++) {
            uint32_t a = gd[gy * bpr + gx / 2u];
            a = (gx & 1u) ? (a & 15u) : (a >> 4);
            if (a < 8u)
                continue;
            if (*x1 < 0 || (int32_t)gx < *x0)
                *x0 = (int32_t)gx;
            if ((int32_t)gx > *x1)
                *x1 = (int32_t)gx;
            if (*y1 < 0)
                *y0 = (int32_t)gy;
            *y1 = (int32_t)gy;
        }
}

/* the character, drawn twice a pixel apart (bolder; a small disc's smaller), its ink on the pixels round (cx, cy); the
 * disc round the ink's own centre, on a half pixel when the ink is even across or high: centred both ways, exactly,
 * whatever the glyph (its top was a pixel high: the cell's, not the ink's) */
static uint16_t badge_on;                /* on the header's band (this its colour): the disc C_ONBAND, its character the
                                          * band's */
static void badge_r(int32_t cx, int32_t cy, char ch, int knob, float r)
{
    const felucca_font_t *f = r < 6.0f ? &FONT_T : &FONT_XS;
    int32_t x, y, n = (int32_t)r + 2, gx0, gx1, gy0, gy1, iw, ih, ix, iy;
    float dx, dy;
    char t[2] = {ch, 0};
    glyph_ink(f, ch, &gx0, &gx1, &gy0, &gy1);
    iw = gx1 - gx0 + 2;                  /* (the second drawing, a pixel right) */
    ih = gy1 - gy0 + 1;
    ix = cx - iw / 2;                    /* the ink's first column and row */
    iy = cy - ih / 2;
    dx = (float)ix + (float)(iw - 1) * 0.5f;
    dy = (float)iy + (float)(ih - 1) * 0.5f;
    for (y = -n; y <= n; y++)
        for (x = -n; x <= n; x++) {
            float ex = (float)(cx + x) - dx, ey = (float)(cy + y) - dy;
            float c = r + 0.5f - fm_sqrtf(ex * ex + ey * ey);
            c = c < 0.0f ? 0.0f : c > 1.0f ? 1.0f : c;
            bl(cx + x, cy + y, badge_on ? C_ONBAND : ui_off ? C_SLATE : knob ? C_ICE : C_LAMP, (int32_t)(32.0f * c));
        }
    if (gx1 < 0)
        return;
    cv_text(ix - gx0 + f->pad, iy - gy0 - oy, f, t, badge_on ? badge_on : C_BG);
    cv_text(ix - gx0 + f->pad + 1, iy - gy0 - oy, f, t, badge_on ? badge_on : C_BG);
}

static void badge(int32_t cx, int32_t cy, char ch, int knob) { badge_r(cx, cy, ch, knob, 6.5f); }

/* the badge of parameter p on this page (or of encoder enc, the one that turned it): its K slot, or its letter if it
 * is one of the three hands (SELECT A, PRESETS B, ALGORITHM C) and not on this page's K1 .. K4 (TEMPO on GLOBAL) */
static void badge_of(int32_t cx, int32_t cy, int p, int enc)
{
    static const char HAND[3] = {[EN_SELECT] = CN_BADGE_SELECT, [EN_ALGO] = CN_BADGE_ALGO,
                                 [EN_PRESET] = CN_BADGE_PRESETS};
    uint32_t i;
    if (enc >= 0 && enc < EN_K1) {
        badge(cx, cy, HAND[enc], 0);
        return;
    }
    if (enc >= EN_K1) {
        badge(cx, cy, (char)('1' + enc - EN_K1), 1);
        return;
    }
    for (i = 0; i < 4u; i++)
        if (page_knob(fm.page, i) == p) {
            badge(cx, cy, (char)('1' + i), 1);
            return;
        }
#if FRS_LEAD
    if (fm.page == PG_NUAGE3 && p == P_PN_CLOUD) {   /* (CLOUD III's K4, OCT- held: its PAN) */
        badge(cx, cy, '4', 1);
        return;
    }
#endif
    if (p == (int)K_SHAPE) {             /* (an ENV page's K1, OCT- held: its ATTACK SHAPE) */
        badge(cx, cy, '1', 1);
        return;
    }
    for (i = 0; i < 3u; i++)
        if (macro_of(i) == (uint32_t)p) {
            badge(cx, cy, HAND[i], 0);
            return;
        }
}

#if PLAT_SMK37
/* a hand the SMK-37 moves with a button or a wheel rather than its knob (Styves, card #111): that control's name in a
 * key's frame, as the help draws its keys but small (f: FONT_XS, FONT_T in the footer's room), from x, its text's top at
 * y; its width */
static int32_t hand_cap(int32_t x, int32_t y, const felucca_font_t *f, const char *s, uint16_t c)
{
    int32_t w = text_tw(f, s, 1) + 7, y1 = y + (int32_t)f->h;
    hline(x + 1, x + w - 2, y - 2, c);
    hline(x + 1, x + w - 2, y1, c);
    cv_rect(x, y - 1 - oy, 1, y1 - y + 1, c);
    cv_rect(x + w - 1, y - 1 - oy, 1, y1 - y + 1, c);
    text_t(x + 4, y, f, s, c, 1);
    return w;
}
/* the large view's control: KNOB BANK or the mod wheel, when one of them moved the hand (app.c hand_by); else 0, its
 * knob's badge */
static const char *hand_key(void)
{
    return hand_at != fm.touched_at ? 0 : hand_by == 1u ? CN_KBANK : hand_by == 2u ? CN_MODW : 0;
}
#endif

/* a value as the screen writes it, the number large and its unit small; the large size steps down if too wide. A
 * factor ("×0.35": TAPE SPEED) has its × drawn before the number (times_mark), a third of the font high */
static void value_big(int32_t x, int32_t y, int p, int32_t maxw, const felucca_font_t *f, uint16_t c, int align)
{
    char t[24], *u = 0;
    int32_t w, uw = 0, i, xs = 0, xw = 0;
    const felucca_font_t *fv = f;
    {
        int k = list_up((uint32_t)p), un = k >= 0 ? up_in_use((uint32_t)k) : -1;
        if (un >= 0)                     /* a preset of the player's: its name */
            up_name((uint32_t)k, (uint32_t)un, t);
        else if (p == P_TEMPO && ext_bpm()) {   /* TEMPO (EXT): the clock's, past TEMPO's 240 too */
            int_text((int32_t)ext_bpm(), t);
            text_cat(t, " BPM");
        } else
            value_text(p, (uint8_t)pv_shown(p), t);
    }
    if (t[0] == '\xC3' && t[1] == '\x97') {   /* (UTF-8's ×: the fonts have none) */
        for (i = 0; t[i + 2]; i++)
            t[i] = t[i + 2];
        t[i] = 0;
        xs = 1;
    }
    for (i = 0; t[i]; i++)               /* a unit after the number: S, MS, HZ, CT */
        if (t[i] == ' ' && i > 0 && t[i - 1] >= '0' && t[i - 1] <= '9' && t[i + 1] && (t[i + 2] == 0 || t[i + 3] == 0 ||
                                                                                    t[i + 4] == 0))
            u = &t[i + 1];
    if (u)
        u[-1] = 0;
    w = text_w(fv, t);
    if (u)
        uw = 4 + text_w(&FONT_XS, u);
    if (xs)                              /* (the ×: a third of the font, 3/8 of it down, a gap after) */
        xw = (int32_t)fv->h / 3 + 3;
    if (xw + w + uw > maxw) {
        fv = &FONT_B;
        w = text_w(fv, t);
        xw = xs ? (int32_t)fv->h / 3 + 2 : 0;
    }
    if (align == 1)
        x -= (xw + w + uw) / 2;
    else if (align == 2)
        x -= xw + w + uw;
    if (xs)
        times_mark(x, y + (int32_t)fv->h * 3 / 8, (int32_t)fv->h / 3, c);
    x = cv_text(x + xw, y - oy, fv, t, c);
    if (u)
        cv_text(x + 4, y + (int32_t)fv->h - (int32_t)FONT_XS.h - 1 - oy, &FONT_XS, u, C_MIST);
}

/* ------------------------------------------------------------ the river --- */
static uint32_t hsh(uint32_t i, uint32_t k)   /* a repeatable pseudo-random, 0 .. 65535 */
{
    uint32_t v = i * 374761393u + k * 668265263u;
    v = (v ^ (v >> 13)) * 1274126177u;
    return (v ^ (v >> 16)) & 0xFFFFu;
}

static inline float sn(float turns)       /* sin(2 pi turns), from the table */
{
    int32_t i = (int32_t)(turns * 256.0f);
    return ui.sn[(uint32_t)i & 255u];
}

static inline float br_clamp01(float t) { return t < 0.0f ? 0.0f : t > 1.0f ? 1.0f : t; }

static inline float smooth01(float t)
{
    t = t < 0.0f ? 0.0f : t > 1.0f ? 1.0f : t;
    return t * t * (3.0f - 2.0f * t);
}

static float note_y(float n, int32_t top, int32_t bottom)  /* C1 on the waterline, D6 at the top (the LEAD's: as it
                                                            * glides, between two) */
{
    float y = (float)bottom - (n - 24.0f) * (float)(bottom - top) * (1.0f / 62.0f);
    return y < (float)top + 6.0f ? (float)top + 6.0f : y > (float)bottom - 4.0f ? (float)bottom - 4.0f : y;
}

static void haze(int32_t top, int32_t bottom, float dim)   /* SPACE: how high and how dense; stratus rows */
{
    float space = vh(P_ESPACE) / 127.0f, blur = (vh(P_GX_BLUR) + mod[P_GX_BLUR]) / 127.0f;
    int32_t hh, x, y;
    if (blur > 0.0f && space < 0.9f)     /* BLUR: the drone into the cloud, the haze as SPACE would have it */
        space += (0.9f - space) * (blur > 1.0f ? 1.0f : blur);
    hh = (int32_t)((24.0f + 46.0f * space) * (float)(bottom - top) / 143.0f);
    for (y = bottom - hh; y < bottom; y++) {
        float tr = (float)(y - (bottom - hh)) / (float)hh;
        int32_t a = (int32_t)(256.0f * 0.55f * 32.0f * space * dim * tr * tr * ((y & 1) ? 1.0f : 0.6f) *
                              (st.v[P_FREEZE] ? 1.8f : 1.0f));
        for (x = ML; x <= MR; x++) {
            if (st.v[P_FREEZE] && ((y % 3) || (x & 1)))
                continue;
            bl(x, y, C_HAZE, (a * ui.edge[x]) >> 16);
        }
    }
}

/* one crystal of frasil: a grain, a needle along the flow, a disc catching light; set ice is a small cross */
static void crystal(int32_t x, int32_t y, uint16_t col, float b, float kind, int set, int link)
{
    if (set) {
        bl(x, y, col, (int32_t)(32.0f * (b * 1.3f > 1.0f ? 1.0f : b * 1.3f)));
        bl(x + 1, y, col, (int32_t)(16.0f * b));
        bl(x - 1, y, col, (int32_t)(16.0f * b));
        bl(x, y + 1, col, (int32_t)(16.0f * b));
        bl(x, y - 1, col, (int32_t)(16.0f * b));
        if (link) {                      /* a hairline to the next */
            bl(x + 2, y, col, (int32_t)(8.0f * b));
            bl(x + 3, y, col, (int32_t)(8.0f * b));
            bl(x + 4, y, col, (int32_t)(8.0f * b));
        }
    } else if (kind < 0.08f) {
        bl(x, y, col, (int32_t)(32.0f * (b * 1.2f > 1.0f ? 1.0f : b * 1.2f)));
        bl(x + 1, y, col, (int32_t)(13.0f * b));
        bl(x - 1, y, col, (int32_t)(13.0f * b));
        bl(x, y + 1, col, (int32_t)(13.0f * b));
        bl(x, y - 1, col, (int32_t)(13.0f * b));
    } else if (kind < 0.40f) {
        bl(x, y, col, (int32_t)(32.0f * b));
        bl(x + 1, y, col, (int32_t)(22.0f * b));
        bl(x + 2, y, col, (int32_t)(10.0f * b));
    } else {
        bl(x, y, col, (int32_t)(29.0f * b));
    }
}

/* a voice: the water around it, the current, its crystals */
static void current(const frasil_view_t *w, int32_t top, int32_t bottom, float dim, float tt, float fz)
{
    float motion = vh(P_MOUVEMENT) / 127.0f, wob = 1.0f - fz;
    float lvl = w->level, prs = w->pressure > 1.0f ? 1.0f : w->pressure, yc = note_y(w->note, top, bottom);
    float half = 30.0f + lvl * 76.0f, th = 1.4f + lvl * 2.0f + prs * 2.6f, ph = (float)w->note * 0.37f;
    float mc = vh(P_CHOEUR) / 127.0f, mp = vh(P_PARTIELS) / 127.0f, mb = vh(P_SOUFFLE) / 127.0f;
    float drift = tt * (0.004f + 0.03f * motion);
    int32_t xc = 130, x0 = (int32_t)((float)xc - half), x1 = (int32_t)((float)xc + half);
    int32_t rr = (int32_t)(th * 2.4f) + 1, prof[40], nc, k, x;
    uint16_t col = mix565(C_FOG, C_LAMP, (int32_t)(prs * 32.0f));     /* the water and the current */
    uint16_t ice = mix565(fz > 0.5f ? C_ICE : mix565(C_ICE, C_FOG, 10), C_LAMP, (int32_t)(prs * 32.0f));   /* crystals */
    uint32_t seed = (uint32_t)w->note * 31u + 7u;
    if (rr > 19)
        rr = 19;
    for (k = -rr; k <= rr; k++) {        /* the halo's profile across the current (x 256 x 32) */
        float d = (float)k / th;
        prof[k + 20] = (int32_t)(lvl * fm_expf(-d * d) * dim * (0.10f + 0.14f * prs) * (0.15f + 1.1f * mb) * 32.0f * 256.0f);
    }
    if (x0 < 34)
        x0 = 34;
    if (x1 > MR)
        x1 = MR;
    for (x = x0; x <= x1; x++) {
        float e = 1.0f - smooth01(((float)(x > xc ? x - xc : xc - x) - (half - 34.0f)) * (1.0f / 34.0f));
        float yy = yc + wob * (sn((float)x * 0.0064f + ph + drift) * 1.1f +
                               sn((float)x * 0.0154f + 2.0f * ph + drift * 1.7f) * 0.45f);
        int32_t ei = (int32_t)(e * 256.0f), yi = (int32_t)yy, a;
        float f = yy - (float)yi, ca;
        if (ei <= 0)
            continue;
        for (k = -rr; k <= rr; k++)      /* the water around the current */
            bl(x, yi + k, col, (prof[k + 20] * ei) >> 16);
        ca = (0.22f + 0.25f * lvl) * e * dim * (1.0f + 1.2f * fz) * (0.25f + 0.95f * mc);   /* the current: thin, solid
                                                                                             * when set */
        a = (int32_t)(32.0f * (ca > 1.0f ? 1.0f : ca));
        bl(x, yi, col, (int32_t)((float)a * (1.0f - f)));
        bl(x, yi + 1, col, (int32_t)((float)a * f));
    }
    /* the frasil, downstream, faster with MOTION; FREEZE eases it into a lattice */
    nc = (int32_t)((18.0f + 56.0f * lvl + 30.0f * prs) * (dim > 0.5f ? 1.0f : 0.45f) * mp);
    for (k = 0; k < nc; k++) {
        float u = (float)hsh(seed, (uint32_t)k * 3u) * (1.0f / 65536.0f);
        float spread = 0.55f + 0.45f * (float)hsh(seed, (uint32_t)k * 3u + 7u) * (1.0f / 65536.0f);
        float speed = 0.6f + 0.8f * (float)hsh(seed, (uint32_t)k * 5u + 3u) * (1.0f / 65536.0f);
        float p = u + tt * (0.01f + 0.05f * motion) * speed, g, xf, yf, b;
        int32_t cx, cy;
        p -= (float)(int32_t)p;
        xf = (float)xc + (p - 0.5f) * 2.0f * (half - 6.0f) * spread;
        g = ((float)hsh(seed, (uint32_t)k * 3u + 1u) + (float)hsh(seed, (uint32_t)k * 3u + 2u)) * (1.0f / 65536.0f) -
            1.0f;
        yf = yc + g * th * 2.2f + wob * sn(xf * 0.0064f + ph + drift) * 1.1f;
        if (fz > 0.0f) {                 /* the lattice: every 6 px, on the current and 3 px either side */
            float lx = 36.0f + (float)(((int32_t)xf - 36) / 6 * 6) + (k % 3 == 1 ? 3.0f : 0.0f);
            float ly = yc + (float)(k % 3 == 0 ? 0 : k % 3 == 1 ? -3 : 3);
            xf += (lx - xf) * fz;
            yf += (ly - yf) * fz;
        }
        cx = (int32_t)(xf + 0.5f);
        cy = (int32_t)(yf + 0.5f);
        if (cx < 36 || cx > MR)
            continue;
        b = (1.0f - smooth01(((float)(cx > xc ? cx - xc : xc - cx) - (half - 34.0f)) * (1.0f / 34.0f))) *
            (0.45f + 0.55f * (float)hsh(seed, (uint32_t)k * 5u + 11u) * (1.0f / 65536.0f)) * dim;
        if (b > 0.05f)
            crystal(cx, cy, ice, b, (float)hsh(seed, (uint32_t)k * 7u + 5u) * (1.0f / 65536.0f), fz > 0.5f,
                    k % 3 == 0);
    }
}

static void glints(int32_t top, int32_t bottom, float dim)   /* a glint in the sky, rising a little as it fades */
{
    glint_view_t sp[GLINT_NV];
    uint32_t i;
    int32_t j;
    frasil_glint_view(sp);
    for (i = 0; i < GLINT_NV; i++) {
        float l = sp[i].level, rise = (float)sp[i].age * 0.08f;
        int32_t gx, gy, arm, a;
        float lv;
        if (sp[i].note < 0 || l < 0.004f)
            continue;
        lv = br_clamp01(1.0f + fm_log2f(l) * (1.0f / 8.0f));   /* as heard: 48 dB from full to gone */
        gx = 44 + (int32_t)((uint32_t)(sp[i].note * 37) % 23u) * 8 +   /* a note's own place; VIBRATO sways it */
             (int32_t)(sp[i].cents * 0.25f);
        {                                /* in the sky above the river: higher notes higher */
            float u = br_clamp01(((float)sp[i].note - 60.0f) * (1.0f / 48.0f));
            gy = top + 10 + (int32_t)((1.0f - u) * (float)(bottom - top) * 0.32f) - (int32_t)(rise > 8.0f ? 8.0f : rise);
        }
        if (gy < top + 4)
            gy = top + 4;
        a = (int32_t)(32.0f * lv);
        arm = 1 + (int32_t)(lv * 8.0f);
        for (j = 1; j <= arm; j++) {     /* four arms of ice, fading out, around a white core */
            int32_t aj = a * (arm + 1 - j) / (arm + 1);
            bl(gx + j, gy, C_ICE, aj);
            bl(gx - j, gy, C_ICE, aj);
            bl(gx, gy + j, C_ICE, aj * 3 / 4);
            bl(gx, gy - j, C_ICE, aj * 3 / 4);
        }
        bl(gx, gy, C_WHITE, a);
        for (j = 0; j < 6; j++) {        /* a few motes around it */
            uint32_t h = hsh((uint32_t)sp[i].note, (uint32_t)j);
            bl(gx + (int32_t)(h & 15u) - 8, gy + (int32_t)((h >> 4) & 15u) - 8, C_ICE, (a * (int32_t)(h >> 12)) >> 5);
        }
    }
}

/* the bass: a slow swell across the river at its note's height, in lamp (the bass's colour), the water under it a
 * little darker down to the bed, a little warm; pressure brightens it; FREEZE stills it */
static void bass_bed(int32_t top, int32_t bottom, float dim, int labels, float tt, float fz)
{
    bass_view_t b;
    float lvl, prs, yc, amp, a0;
    int32_t x, y, depth;
    uint16_t col;
    frasil_bass_view(&b);
    if (b.note < 0 || b.level < 0.01f)
        return;
    lvl = b.level;
    prs = b.pressure > 1.0f ? 1.0f : b.pressure;
    yc = note_y(b.note, top, bottom);
    amp = (1.5f + 2.5f * lvl) * (1.0f - fz);
    a0 = (0.40f + 0.50f * lvl) * dim;
    col = mix565(C_LAMP, C_WHITE, (int32_t)(prs * 14.0f));
    depth = (int32_t)(bottom - yc);
    for (x = ML; x <= MR; x++) {
        float e = (float)ui.edge[x] * (1.0f / 256.0f);
        float yy = yc + amp * (sn((float)x * 0.0042f + tt * 0.021f) * 0.8f + sn((float)x * 0.0097f - tt * 0.013f) * 0.2f);
        int32_t yi = (int32_t)yy, a = (int32_t)(32.0f * a0 * e);
        float f = yy - (float)yi;
        bl(x, yi, col, (int32_t)((float)a * (1.0f - f)));
        bl(x, yi + 1, col, a);
        bl(x, yi + 2, col, (int32_t)((float)a * f));
        for (y = yi + 3; y < bottom; y++) {   /* the water under it, down to the bed */
            int32_t d = y - yi - 3, af = (int32_t)(8.0f * a0 * e * (1.0f - (float)d / (float)(depth + 4)));
            if (af > 0 && ((x + y) & 1))
                bl(x, y, mix565(C_HAZE, C_LAMP, 8), af);
        }
    }
    if (labels) {                        /* its note, on the right: the voices' are on the left */
        static const char *const NN[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
        char n[8];
        n[0] = 0;
        text_cat(n, NN[b.note % 12]);
        int_text(b.note / 12 - 1, n + strlen_(n));
        text_r(MR, (int32_t)yc - 13, &FONT_XS, n, mix565(C_BG, prs > 0.1f ? C_LAMP : b.gate ? C_MIST : C_SLATE,
                                                        (int32_t)(32.0f * dim)), 0);
    }
}

/* a pixel toward c by a (0 .. 1), each channel rounded on a fixed 4 x 4 pattern: a gradient as smooth as 565 can make
 * it, without bands, and still where nothing changes (screen coordinates) */
static void blf(int32_t x, int32_t y, uint16_t c, float a)
{
    static const uint8_t B4[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};
    float th = ((float)B4[(y & 3) * 4 + (x & 3)] + 0.5f) * (1.0f / 16.0f);
    uint32_t q;
    uint16_t *p;
    y -= oy;
    if (a <= 0.0f || (uint32_t)x >= cv_w || (uint32_t)y >= cv_h)
        return;
    p = &cv_px[(uint32_t)y * cv_w + (uint32_t)x];
    q = swap16(*p);
    *p = swap16((uint16_t)((uint32_t)((float)(q >> 11) + ((float)(c >> 11) - (float)(q >> 11)) * a + th) << 11 |
                           (uint32_t)((float)(q >> 5 & 63u) + ((float)(c >> 5 & 63u) - (float)(q >> 5 & 63u)) * a + th) << 5 |
                           (uint32_t)((float)(q & 31u) + ((float)(c & 31u) - (float)(q & 31u)) * a + th)));
}

/* SINK: the river under water as it is turned, a clear blue veil from the top down, densest at the top, fading out
 * where it reaches and at the sides as the river does; as faint as the river is (a page's strip, the value over it).
 * Its red the background's: over the dark it moves green and blue alone (565's coarse red would put mauve in it) */
static void sink(int32_t top, int32_t bottom, float dim)
{
    float s = (vh(P_GX_SINK) + mod[P_GX_SINK]) / 127.0f, line, fade;
    int32_t h = bottom - top, y, x;
    if (s <= 0.01f)
        return;
    s = s > 1.0f ? 1.0f : s;
    line = (float)top + s * 1.25f * (float)h;
    fade = 0.6f * (float)h;
    for (y = top; y < bottom && (float)y < line; y++) {
        float a = 0.34f * dim * smooth01((line - (float)y) / fade) * smooth01((float)(y - top + 1) * (1.0f / 6.0f));
        for (x = ML; x <= MR; x++)
            blf(x, y, C_SINK, a * (float)ui.edge[x] * (1.0f / 256.0f));
    }
}

#if FRS_LEAD
/* the LEAD (card #200, as Perform's LUCID, card #158): each voice a light in its rose a quarter in from the left, at its
 * note's height as the drone's and the bass's are (top: on the play page under its top row, the harmony's and what goes
 * on, where the LEAD's high notes would be lost), as bright as it sounds, gliding to a new note as the LEAD glides
 * (GLIDE: 2 g^2 s, lead.c's; struck, eased in 0.12 s; from silence there at once); what it sang drifts downstream at
 * the river's pace (MOTION) and fades out in LT_N x LT_MS, thinner as it fades, the currents' sway taking it as it ages:
 * the melody as it was sung, POLY's voices each theirs. In the air over the river: FREEZE stills the water, not it (its
 * own clock); ANIMATIONS LOW: the lights alone. Its newest note named a moment while the keys play the LEAD (HOME). The
 * trail: a point every LT_MS, its note in quarter tones (drawn at any river's height: HOME's, a page's strip) and how
 * bright, two bytes a voice a point */
#define LT_N 20
#define LT_MS 300u
static struct {
    uint32_t at, last, named_at;         /* the trail's newest point; the frame before; the newest note come */
    float p[LEAD_NV];                    /* each light's note as it glides */
    int8_t n[LEAD_NV], named;            /* the note each sings (-1 silent); the voice named */
    uint8_t lv[LEAD_NV], head;           /* how bright each is (the envelope's root), 0 .. 255; the newest point */
    uint8_t tn[LEAD_NV][LT_N], tl[LEAD_NV][LT_N];   /* its trail: (note - 24) x 4, how bright */
} ld;

/* a stretch of a trail, older to the right: a line a pixel thick, a dim row either side as it is bright; a step
 * between two notes drawn whole (never a dotted rise) */
static void lead_seg(float xa, float ya, float xb, float yb, float a, float sw, float ph)
{
    int32_t x = (int32_t)xa + 1, x1 = (int32_t)xb, y, ylo, yhi;
    float k = xb > xa ? (yb - ya) / (xb - xa) : 0.0f;
    int32_t ac = (int32_t)(29.0f * a), ag = a > 0.35f ? (int32_t)(6.0f * a * a) : 0;
    if (ac <= 0)
        return;
    if (x1 > MR)
        x1 = MR;
    for (; x <= x1; x++) {
        float s = sw * sn((float)x * 0.0064f + ph), y0 = ya + k * ((float)x - 0.5f - xa) + s,
              y1 = ya + k * ((float)x + 0.5f - xa) + s, yy = 0.5f * (y0 + y1), f;
        int32_t yi = (int32_t)yy;
        if (y1 - y0 > 1.0f || y0 - y1 > 1.0f) {   /* steep: the rows it crosses */
            ylo = (int32_t)(y0 < y1 ? y0 : y1);
            yhi = (int32_t)(y0 < y1 ? y1 : y0);
            for (y = ylo; y <= yhi; y++)
                bl(x, y, C_LEAD_TRACK, ac);
        } else {
            f = yy - (float)yi;
            bl(x, yi, C_LEAD_TRACK, (int32_t)((float)ac * (1.0f - f)));
            bl(x, yi + 1, C_LEAD_TRACK, (int32_t)((float)ac * f));
            ylo = yi;
            yhi = yi + 1;
        }
        bl(x, ylo - 1, C_LEAD_TRACK, ag);
        bl(x, yhi + 1, C_LEAD_TRACK, ag);
    }
}

static int keys_on_lead(void)
{
#if FRS_MIDI_OUT
    if (mout.sel)
        return 0;
#endif
    return st.lead != 0;
}

static void lead_lights(int32_t top, int32_t bottom, float dim, int labels, float t)
{
    static const char *const NN[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    lead_view_t l;
    uint32_t now = plat_ms(), j, i, k;
    int still = st.v[P_ANIM] != 0;
    float dt = ld.last ? (float)(now - ld.last) * 0.001f : 0.0f, g = vh(P_LD_GLIDE) / 127.0f, tg = 2.0f * g * g, kg;
    float hx = (float)ML + 0.27f * (float)(MR - ML);
    frasil_lead_view(&l);
    ld.last = now;
    if (dt > 0.1f)
        dt = 0.1f;
    kg = 1.0f - fm_expf(-dt * 3.0f / (tg < 0.12f ? 0.12f : tg));
    for (j = 0; j < LEAD_NV; j++) {      /* where each sings, how bright */
        int n = l.vnote[j];
        float lv = n >= 0 ? br_clamp01(l.venv[j]) : 0.0f;
        if (n >= 0 && lv > 0.004f) {
            if (ld.n[j] < 0 || ld.lv[j] < 26u || still)
                ld.p[j] = (float)n;
            else
                ld.p[j] += ((float)n - ld.p[j]) * kg;
            if (n != ld.n[j]) {
                ld.named = (int8_t)j;
                ld.named_at = now;
            }
            ld.n[j] = (int8_t)n;
        } else {
            ld.n[j] = -1;
            lv = 0.0f;
        }
        ld.lv[j] = (uint8_t)(fm_sqrtf(lv) * 255.0f + 0.5f);
    }
    k = (now - ld.at) / LT_MS;           /* the trail: a point every LT_MS (unseen a while, or still: gone) */
    if (still || k > LT_N) {
        memset(ld.tl, 0, sizeof ld.tl);
        ld.at = now;
    } else if (k) {
        for (i = 0; i < k; i++) {
            ld.head = (uint8_t)((ld.head + 1u) % LT_N);
            for (j = 0; j < LEAD_NV; j++) {
                float q = (ld.p[j] - 24.0f) * 4.0f + 0.5f;
                ld.tn[j][ld.head] = (uint8_t)(q < 0.0f ? 0.0f : q > 255.0f ? 255.0f : q);
                ld.tl[j][ld.head] = i + 1u == k ? ld.lv[j] : 0u;
            }
        }
        ld.at += k * LT_MS;
    }
    if (!still) {                        /* the trails: older, further downstream, fainter, swaying more */
        float pace = (float)(MR - ML) * (0.03f + 0.03f * vh(P_MOUVEMENT) / 127.0f), life = (float)(LT_N * LT_MS) * 0.001f;
        float a0 = (float)(now - ld.at) * 0.001f, ph = t * (0.004f + 0.03f * vh(P_MOUVEMENT) / 127.0f) * 0.8f;
        for (j = 0; j < LEAD_NV; j++) {
            float xa = hx, ya = note_y(ld.p[j], top, bottom), la = (float)ld.lv[j] * (1.0f / 255.0f), age = 0.0f;
            for (i = 0; i < LT_N; i++) {
                uint32_t q = (ld.head + LT_N - i) % LT_N;
                float ag = a0 + (float)i * (float)LT_MS * 0.001f, xb = hx + ag * pace;
                float yb = note_y((float)ld.tn[j][q] * 0.25f + 24.0f, top, bottom), lb = (float)ld.tl[j][q] * (1.0f / 255.0f);
                float u = 1.0f - ag / life, a = (la < lb ? la : lb) * u * dim;
                if (xa > (float)MR)
                    break;
                if (a > 0.03f)
                    lead_seg(xa, ya, xb, yb, a, 1.2f * (age / life * 1.6f > 1.0f ? 1.0f : age / life * 1.6f), ph);
                xa = xb;
                ya = yb;
                la = lb;
                age = ag;
            }
        }
    }
    for (j = 0; j < LEAD_NV; j++) {      /* the lights, where they sing: a glow, a white heart */
        float a, lv, yf, r;
        int32_t x0 = (int32_t)(hx + 0.5f), yc, ri, dx, dy;
        uint16_t core;
        if (ld.n[j] < 0)
            continue;
        a = (float)ld.lv[j] * (1.0f / 255.0f);
        lv = a * a;
        a *= dim;
        yf = note_y(ld.p[j], top, bottom);
        yc = (int32_t)(yf + 0.5f);
        r = 3.5f + 4.0f * lv;
        ri = (int32_t)r;
        for (dy = -ri; dy <= ri; dy++)
            for (dx = -ri; dx <= ri; dx++) {
                float d = fm_sqrtf((float)(dx * dx + dy * dy)) / r, e;
                if (d >= 1.0f || (dx == 0 && dy == 0))
                    continue;
                e = 1.0f - d;
                bl(x0 + dx, yc + dy, C_LEAD_TRACK, (int32_t)(32.0f * 0.85f * a * e * e * e));
            }
        core = mix565(C_LEAD_TRACK, C_WHITE, 19);
        bl(x0, yc, core, (int32_t)(32.0f * a));
    }
    if (labels && keys_on_lead() && ld.named >= 0 && ld.n[ld.named] >= 0 && now - ld.named_at < 1800u) {
        float u = 1.4f * (1.0f - (float)(now - ld.named_at) * (1.0f / 1800.0f)), lv = (float)ld.lv[ld.named] / 255.0f;
        int32_t n = ld.n[ld.named], y = (int32_t)note_y(ld.p[ld.named], top, bottom) - (int32_t)FONT_XS.h / 2;
        char s[8];
        if (y < R2 + 17)                 /* (a high note's: under the river's top row, the harmony's) */
            y = R2 + 17;
        s[0] = 0;
        text_cat(s, NN[n % 12]);
        int_text(n / 12 - 1, s + strlen_(s));
        text_r((int32_t)hx - 10, y, &FONT_XS, s,
               mix565(C_BG, C_LEAD_TRACK, (int32_t)(32.0f * (u > 1.0f ? 1.0f : u) * (lv > 0.4f ? lv : 0.4f) * dim)), 0);
    }
}
#endif

static void river(int32_t top, int32_t bottom, float dim, int labels, float t)
{
    static const char *const NN[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    frasil_view_t v[FR_NV];
    float fz, tt, dim0 = dim;            /* (the LEAD's: not the drones' duck, PUMP) */
    int32_t order[FR_NV], nv = 0, i, j, last_label = -100;
    if (ui.frz != st.v[P_FREEZE]) {
        ui.frz = st.v[P_FREEZE];
        ui.frz_at = plat_ms();
        ui.stillt = t;
    }
    fz = smooth01((float)(plat_ms() - ui.frz_at) * (1.0f / 300.0f));   /* 1: set (eased over 300 ms) */
    if (!st.v[P_FREEZE])
        fz = 1.0f - fz;
    tt = st.v[P_FREEZE] ? ui.stillt : t;      /* the river stops when it is set */
    if (st.v[P_PUMP_RATE])               /* PUMP: the river breathes with the drones' duck */
        dim *= 0.45f + 0.55f * frasil_pump_gain();
    haze(top, bottom, dim);
    bass_bed(top, bottom, dim, labels, tt, fz);
    frasil_view(v);                      /* the voices, lowest first: their labels must not collide */
    for (i = 0; i < FR_NV; i++)
        if (v[i].note >= 0 && v[i].level > 0.01f)
            order[nv++] = i;
    for (i = 1; i < nv; i++)
        for (j = i; j > 0 && v[order[j]].note < v[order[j - 1]].note; j--) {
            int32_t k = order[j];
            order[j] = order[j - 1];
            order[j - 1] = k;
        }
    for (i = 0; i < nv; i++) {
        const frasil_view_t *w = &v[order[i]];
        current(w, top, bottom, dim, tt, fz);
        if (labels) {
            int32_t yc = (int32_t)note_y(w->note, top, bottom);
            if (yc < R2 + 24)            /* (a high note's: under the river's top row, the harmony's) */
                yc = R2 + 24;
            if (last_label - yc >= 11 || last_label < 0) {
                char n[8];
                uint16_t lc = w->pressure > 0.1f ? C_LAMP : w->gate ? C_MIST : C_SLATE;
                n[0] = 0;
                text_cat(n, NN[w->note % 12]);
                int_text(w->note / 12 - 1, n + strlen_(n));
                cv_text(ML, yc - 7 - oy, &FONT_XS, n, mix565(C_BG, lc, (int32_t)(32.0f * dim)));
                last_label = yc;
            }
        }
    }
    glints(top, bottom, dim);
    sink(top, bottom, dim);
#if FRS_LEAD
    lead_lights(bottom == HZ_HOME ? top + 12 : top, bottom, dim0, labels, t);   /* (over SINK's veil: in the air) */
#else
    (void)dim0;
#endif
    hline(ML, MR, bottom, mix565(C_BG, st.v[P_FREEZE] ? C_ICE : C_SLATE, (int32_t)(32.0f * dim)));   /* the waterline */
}

/* the play page's corner, top right of the river: what goes on unseen, only what is on (GLINT's sequence or its
 * arpeggio, the bass's sequence, the LFOs running, SWELL) */
static void river_status(void)
{
    int32_t x = MR, y = R2 + 4, i, tr = 1;
    char t[32];
    if (st.v[P_SWELL] || st.swell_btn > 0.0f) {
        text_r(x, y, &FONT_XS, "SWELL", C_LAMP, 1);
        x -= text_tw(&FONT_XS, "SWELL", 1) + 9;
    }
    if (lfo_any) {                       /* LFO, a dot for each: lit, the ones running */
        for (i = NLFO - 1; i >= 0; i--) {
            if (lfo[i].on)
                cv_rect(x - 3, y + 5 - oy, 3, 3, C_ICE);
            else
                cv_rect(x - 2, y + 6 - oy, 1, 1, C_SLATE);
            x -= 6;
        }
        text_r(x - 1, y, &FONT_XS, "LFO", C_MIST, 1);
        x -= text_tw(&FONT_XS, "LFO", 1) + 10;
    }
    if (st.v[P_DQ_ON]) {                 /* the drone's sequence, in fog (slate, stopped) */
        const char *w = st.v[P_DQ_REC] ? "DRONE REC" : "DRONE SEQ";
        text_r(x, y, &FONT_XS, w, st.v[P_DQ_REC] || dq.run ? C_FOG : C_SLATE, 1);
        x -= text_tw(&FONT_XS, w, 1) + 10;
    }
    if (st.v[P_BQ_ON] == SQT_SEQ) {      /* the bass's sequence, in lamp (slate, stopped) */
        const char *w = st.v[P_BQ_REC] ? "BASS REC" : "BASS SEQ";
        text_r(x, y, &FONT_XS, w, st.v[P_BQ_REC] || bq.run ? C_LAMP : C_SLATE, 1);
        x -= text_tw(&FONT_XS, w, 1) + 10;
    } else if (st.v[P_BQ_ON] == SQT_ARP && barp.n) {   /* its arpeggio (the keys' badge says if it is latched) */
        text_r(x, y, &FONT_XS, "BASS ARP", barp.paused ? C_SLATE : C_LAMP, 1);
        x -= text_tw(&FONT_XS, "BASS ARP", 1) + 10;
    }
    if (st.v[P_SQ_TYPE] == SQT_SEQ) {
        const char *w = st.v[P_SQ_REC] ? "REC" : "SEQ";
        text_r(x, y, &FONT_XS, w, st.v[P_SQ_REC] ? C_LAMP : sq.run ? C_ICE : C_SLATE, 1);
        x -= text_tw(&FONT_XS, w, 1) + 10;
    } else if (st.v[P_SQ_TYPE] == SQT_ARP && arp.n) {
        const char *w = arp.latch ? "ARP LATCH" : "ARP";
        text_r(x, y, &FONT_XS, w, arp.paused ? C_SLATE : C_ICE, 1);
        x -= text_tw(&FONT_XS, w, 1) + 10;
    }
    if (!st.v[P_SCALE] && !st.v[P_CHORD])
        return;
    t[0] = 0;                            /* the harmony, quietly, at the left in what they leave: closer, then shorter */
    text_cat(t, NOTE_NAME[st.v[P_ROOT] % 12u]);
    text_cat(t, " ");
    text_cat(t, SCALE_NAME[st.v[P_SCALE] % NSCALES]);
    if (ML + text_tw(&FONT_XS, t, 1) > x)
        tr = 0;
    while (t[0] && ML + text_tw(&FONT_XS, t, tr) > x)
        t[strlen_(t) - 1u] = 0;
    if (t[0])                            /* (the river's notes go under it, not through it) */
        cv_rect(ML - 1, y - 1 - oy, text_tw(&FONT_XS, t, tr) + 3, 12, C_BG);
    text_t(ML, y, &FONT_XS, t, C_MIST, tr);
}

/* ------------------------------------------------------------ the bands --- */
static int touched_now(void) { return fm.touched_at && plat_ms() - fm.touched_at < TOUCH_MS && fm.touched < NPARAM; }
/* an ENV page's K1 its ATTACK SHAPE (K_SHAPE) while OCT- is held, or a moment after it turned (card #122: app.c
 * encoders, MIXER's PANs' way) */
static int shape_hot(void) { return shape_at && plat_ms() - shape_at < TOUCH_MS && fm.page == shape_pg; }
static int shape_shown(void)
{
    return page_shape(fm.page) >= 0 && ((b_held(B_OCTDN) && !b_held(B_OCTUP)) || shape_hot());
}
static int shape_line(void) { return page_shape(fm.page) >= 0 && (st.ashape >> page_shape(fm.page) & 1u); }
/* TRACKS LINK's cell p turned a moment ago (card #212: app.c link_turn) */
static int link_hot(uint32_t p) { return lkh.at && lkh.p == (prm_t)p && plat_ms() - lkh.at < TOUCH_MS; }

#if FRS_MIDI_OUT
/* MIDI OUT's knobs (card #164: app.c mout): a name, a value as the screen writes it */
static const char *mout_name(uint32_t p)
{
    return p == K_MO_CH ? "CHANNEL" : p == K_MO_OCT ? "OCTAVE" : p == K_MO_VEL ? "VELOCITY" : p == K_MO_RET ? "RETURN"
         : p == K_CLKOUT ? "CLOCK OUT" : p == K_NOUT ? "NOTES OUT" : "PRESSURE";
}
static int32_t mout_oct(void) { return mout.sel ? fm.octave : mout.oct; }
static const char *mout_text(uint32_t p, char *t)
{
    static const char *const VEL[4] = {"SOFT", "NORMAL", "HARD", "FIXED"}, *const PRS[3] = {"OFF", "CHANNEL", "POLY"};
    t[0] = 0;
    if (p == K_MO_CH) {
        int_text((int32_t)mout.ch + 1, t);
    } else if (p == K_MO_OCT) {
        if (mout_oct() > 0)
            text_cat(t, "+");
        int_text(mout_oct(), t + strlen_(t));
    } else if (p == K_MO_RET) {          /* (card #169: the computer's audio back, %) */
        int_text((int32_t)mout.ret, t);
        text_cat(t, " %");
    } else if (p == K_CLKOUT || p == K_NOUT) {   /* (NOTES OUT: card #201) */
        text_cat(t, (p == K_CLKOUT ? mout.clk : nout.on) ? "ON" : "OFF");
    } else {
        text_cat(t, p == K_MO_VEL ? VEL[mout.vel & 3u] : PRS[mout.prs % 3u]);
    }
    return t;
}
static uint32_t mout_steps(uint32_t p)
{
    return p == K_MO_CH ? 16u : p == K_MO_OCT ? 6u : p == K_MO_VEL ? 4u : p == K_CLKOUT || p == K_NOUT ? 2u : 3u;
}
static uint32_t mout_at(uint32_t p)      /* the value's place among them */
{
    return p == K_MO_CH ? mout.ch : p == K_MO_OCT ? (uint32_t)(mout_oct() + 3) : p == K_MO_VEL ? mout.vel
         : p == K_CLKOUT ? mout.clk : p == K_NOUT ? nout.on : mout.prs;
}
static int mout_big(void) { return mout.sel && mout.hand_at && plat_ms() - mout.hand_at < TOUCH_MS; }   /* B or C turned */
#endif

static int is_macro(int p)               /* the three hands' */
{
    return p == P_KB || (uint32_t)p == track_preset() || (uint32_t)p == track_algo() || p == P_FL_CUT;
}

static int is_layer(int p) { return p == P_CHOEUR || p == P_PARTIELS || p == P_SOUFFLE || p == P_CHALEUR; }

static int oct_big(void) { return fm.oct_at && plat_ms() - fm.oct_at < TOUCH_MS && fm.octave == fm.oct_v; }

/* the large view of one value: on the play page (but its strata show the three layers), and for the three hands
 * anywhere; SELECT's on the play page alone: on a page, the page stays, a track's following at once, the header's name
 * and colour telling it (Styves, admin #866: a value large over the river, the three hands below, read as the play
 * page between two EDIT pages; 2.5's way again, which 3.0's "the track large a moment" had undone) */
static int overlay_on(void)
{
#if FRS_MIDI_OUT
    if (mout_big())                      /* (MIDI's CHANNEL or OCTAVE, by B or C) */
        return 1;
#endif
    return touched_now() && ((fm.page == PG_SON && !is_layer(fm.touched)) ||
                             (fm.touched_enc < EN_K1 && is_macro(fm.touched) && fm.touched != P_KB));
}

#if defined PLAT_HOST && !defined PLAT_WEB
static struct {                          /* (the tests: the page the screen showed, frame by frame since drawnmark: the
                                          * play page's look, HOME's SOUND or a value large over the river, its three
                                          * hands below, or a page; expect drawnhome, drawnflips, drawnstale) */
    uint32_t home, flips, stale;
    uint8_t last;
    uint8_t mid;                         /* the one the middle band drew last */
} ui_seen;
static uint8_t ui_look(void) { return overlay_on() || fm.page == PG_SON ? (uint8_t)PG_SON : fm.page; }
#endif

/* the play page's mix: under the waterline, each layer a stratum drawn as its thing in the river (the current, the
 * crystals, the haze), as long as it is loud; the one being turned lit */
static void strata(float dim)
{
    static const uint8_t L[4] = {P_CHOEUR, P_PARTIELS, P_SOUFFLE, P_CHALEUR};
    const int32_t x0 = 80, len = 124;
    uint32_t i;
    int32_t x, k;
    for (i = 0; i < 4u; i++) {
        int p = L[i], hot = touched_now() && fm.touched == p;
        int32_t y = HZ_HOME + 10 + (int32_t)i * 14, n = (int32_t)vh_n((uint32_t)p) * len / 127;   /* (the badges apart) */
        uint16_t c = mix565(C_BG, i == 1u ? C_ICE : hot ? C_FOG : C_MIST, (int32_t)((hot || i == 1u ? 32.0f : 28.0f) * dim));
        uint16_t lc = mix565(C_BG, hot ? C_LAMP : C_MIST, (int32_t)(24.0f * dim));
        char t[8];
        badge_r(ML + 6, y, (char)('1' + i), 1, 5.0f);
        text_t(ML + BADGE_W - 2, y - 6, &FONT_T, PD[p].name, lc, 1);
        for (x = x0; x < x0 + len; x += 3)   /* the full length, dotted */
            bl(x, y, C_STEEL, 32);
        if (i == 0) {                    /* CHOIR: the current, a solid line */
            for (x = x0; x < x0 + n; x++) {
                bl(x, y, c, 32);
                bl(x, y - 1, c, 12);
            }
        } else if (i == 1) {             /* PARTIALS: crystals, needles along the flow */
            for (x = x0; x + 2 < x0 + n; x += 4) {
                int32_t jy = (int32_t)(hsh((uint32_t)x, 3u) % 3u) - 1;
                crystal(x, y + jy, c, 0.95f, hsh((uint32_t)x, 9u) < 5000u ? 0.0f : 0.3f, 0, 0);
            }
        } else if (i == 2) {             /* BREATH: haze, stratus rows */
            static const int32_t PROF[5] = {6, 14, 22, 14, 6};
            for (x = x0; x < x0 + n; x++) {
                int32_t e = x > x0 + n - 10 ? (x0 + n - x) * 26 : 256;
                for (k = -2; k <= 2; k++)
                    bl(x, y + k, c, (PROF[k + 2] * e) >> 8);
            }
        } else {                         /* WARMTH: embers, a low glow with sparks along it */
            uint16_t wc = mix565(C_BG, hot ? C_LAMP : RGB(214, 150, 96), (int32_t)(28.0f * dim));
            for (x = x0; x < x0 + n; x++) {
                bl(x, y, wc, 8 + (int32_t)(hsh((uint32_t)x, 5u) & 7u));
                if (hsh((uint32_t)x, 11u) % 6u == 0) {
                    bl(x, y, wc, 32);
                    bl(x, y - 1, wc, 12);
                }
            }
        }
        int_text((int32_t)vh_n((uint32_t)p) * 100 / 127, t);
        text_r(MR, y - 6, &FONT_T, t, lc, 0);
    }
}

/* the header: the band (band_col, C_ONBAND on it); at its right the track, LIVE or STEP while the keys write into its
 * sequence */
static const char *keys_word(void)
{
#if FRS_MIDI_OUT
    if (mout.sel)
        return md[MD_REC] == 2u ? "LIVE" : md[MD_REC] == 1u ? "STEP" : "MIDI";   /* (its take: card #169) */
#endif
#if FRS_LEAD
    if (st.lead)
        return "LEAD";
#endif
    uint32_t r = st.v[st.glint ? P_SQ_REC : st.bass ? P_BQ_REC : P_DQ_REC];
    if (r)
        return r == 2u ? "LIVE" : "STEP";
    return st.glint ? "GLINT" : st.bass ? "BASS" : "DRONE";
}

/* the header's corner on a SEQ page of the track selected: the title says the track, so the corner says how to clear: the
 * two keys, each its own small box */
#if FRS_LEAD
static int clear_corner(void) { return PAGES[fm.page].button == B_SEQ && PAGES[fm.page].track == kb_ui() && fm.page != PG_LNOSEQ; }
#else
static int clear_corner(void) { return PAGES[fm.page].button == B_SEQ && PAGES[fm.page].track == st.v[P_KB]; }
#endif
static int32_t small_cap(int32_t x, const char *s)
{
    int32_t w = text_tw(&FONT_XS, s, 1) + 7;
    hline(x, x + w - 1, 5, C_ONBAND);
    hline(x, x + w - 1, 22, C_ONBAND);
    cv_rect(x, 5 - oy, 1, 18, C_ONBAND);
    cv_rect(x + w - 1, 5 - oy, 1, 18, C_ONBAND);
    text_t(x + 4, 7, &FONT_XS, s, C_ONBAND, 1);
    return x + w;
}
static int32_t clear_w(void)
{
    return text_tw(&FONT_XS, "CLEAR", 1) + 6 + text_tw(&FONT_XS, CN_OCTDN_S, 1) + 7 + 13 + text_tw(&FONT_XS, CN_REC_S, 1) +
           7;
}

/* CHORD before the track (CHORD . GLINT), a little paler, while a key of the selected track plays a chord: its KEYS'
 * NOTES on CHORD and heard (HARMONY on; GLINT not on SEQ, the bass on ARP), not while a take writes (LIVE, STEP), nor on
 * GLOBAL, whose header keeps its room for the load (CPU) */
static const char *notes_why(int p);
static int chord_tag(void)
{
#if FRS_MIDI_OUT
    if (mout.sel)                        /* (MIDI's own KEYS, card #194) */
        return fm.page != PG_GLOBAL && !md[MD_REC] && md[MD_KHARM] && md[MD_KNOTES] && !md_notes_why(MD_KNOTES);
#endif
#if FRS_LEAD
    if (st.lead)                         /* (the LEAD's, card #194: on POLY) */
#if FRS_MIDI_OUT
        return fm.page != PG_GLOBAL && md[MD_LHARM] && md[MD_LNOTES] && !md_notes_why(MD_LNOTES);
#else
        return 0;
#endif
#endif
    uint32_t t = st.glint ? 1u : st.bass ? 2u : 0u;
    int p = (int)(P_KY_DR_NOTES + 4u * t);
    return fm.page != PG_GLOBAL && !st.v[st.glint ? P_SQ_REC : st.bass ? P_BQ_REC : P_DQ_REC] && st.v[p] &&
           st.v[P_KY_DR_HARM + 4u * t] && !notes_why(p);
}
#define CHORD_W (text_tw(&FONT_B, "CHORD", 1) + 1 + 13)

static int32_t track_tag_w(void)
{
    return clear_corner() ? clear_w() : text_tw(&FONT_B, keys_word(), 1) + 2 + (chord_tag() ? CHORD_W : 0);
}

static void track_tag(int32_t x0)
{
    if (clear_corner()) {
        int32_t x = text_t(x0, 7, &FONT_XS, "CLEAR", C_ONBAND, 1) + 6;
        x = small_cap(x, CN_OCTDN_S);    /* (the short forms: the title's room) */
        text_c(x + 6, 7, &FONT_XS, "+", C_ONBAND, 0);
        small_cap(x + 13, CN_REC_S);
        return;
    }
    {
    const char *word = keys_word();
    if (chord_tag()) {                   /* (bold as the track, at about 3/4 of its contrast on the band) */
        uint16_t pale = mix565(band_col(), C_ONBAND, 23);
        int32_t x = text_t(x0, 8, &FONT_B, "CHORD", pale, 1);
        text_t(x0 + 1, 8, &FONT_B, "CHORD", pale, 1);
        cv_rect(x + 6, 14 - oy, 3, 3, pale);
        x0 += CHORD_W;
    }
    text_t(x0, 8, &FONT_B, word, C_ONBAND, 1);
    text_t(x0 + 1, 8, &FONT_B, word, C_ONBAND, 1);
    }
}

/* where the page is among its button's: a dot each under the title, the page's dark (HOME: SOUND, KEYS, MIXER, CLOUD
 * SEND, TRACKS LINK, the logo) */
static void page_dots(void)
{
    uint32_t p, n = 0, i = 0, k, o;
    uint16_t quiet = mix565(band_col(), C_ONBAND, 16);
    for (o = 0; o < NPAGES; o++) {
        p = PAGE_ORDER[o];
        if (PAGES[p].button == PAGES[fm.page].button && !page_hidden(p)) {
            n++;
            if (p == fm.page)
                i = n;
        }
    }
    if (PAGES[fm.page].button == B_HOME) {   /* (its last, the logo) */
        n = 6;
        i = fm.page == PG_KEYS ? 2u : fm.page == PG_MIXER ? 3u : fm.page == PG_CSEND ? 4u : fm.page == PG_LINK ? 5u : 1u;
    }
    if (n < 2u)
        return;
    for (k = 1; k <= n; k++) {                /* big enough, and the others dark enough, to count them at a glance */
        int32_t x = ML + 1 + (int32_t)(k - 1u) * 8;
        if (k == i)
            cv_rect(x - 1, 24 - oy, 5, 5, C_ONBAND);
        else
            cv_rect(x, 25 - oy, 4, 4, quiet);
    }
}

#if APP_CPU_LINE
/* the load's line (app.h APP_CPU_LINE; Styves, admin #672): the screen's last row after its label (admin #729: CPU,
 * small, bottom left, its baseline the row), the render's load (cpu_load, the one the shedding watches) as the part
 * filled from the label's end, the rest of the row 100 % (and over); the rest a track, barely there. Filled in the
 * quiet marks' slate; the whole fill the battery's yellow from 85 %, red from 92 % (each back 2 % under its line: a load
 * sitting on it does not flicker); the label slate in every zone. The load shown: a step every CL_STEP_MS, up at once
 * to the highest read since the last step, down a third of the way a step (some 250 ms): a peak stays a moment. On
 * every screen but the screensaver's and the logo's: a band that reaches the label's box draws the label and the line
 * in before its blit (cl_band: the label wins its box, the line its row; ANCHOR's frame alone reaches them, af_fill
 * keeps off both). A step that moves it: the row alone after the label (cl_row, a fill or two of a row; the label never,
 * it does not move) as the next band starts (band: the wait for the screen's last transfer is the band's anyway), or
 * once no band has started for CL_REST_MS (nothing left in flight): no wait of its own */
#define CL_Y 239                         /* its row */
#define CL_X 19                          /* its first column: CPU before it, FONT_T tracked 1 from x 0 (its ink 0 .. 16),
                                          * 2 px clear */
#define CL_W (240 - CL_X)                /* its pixels: 100 % */
#define CL_LY (CL_Y - 9)                 /* the label's box, x 0 .. CL_X - 1, rows CL_LY .. CL_Y: FONT_T's cell from
                                          * there, its capitals' ink its rows 2 .. 9 (the baseline the line's row) */
#define CL_STEP_MS 100u                  /* ten steps a second at most */
#define CL_REST_MS 50u                   /* (the river's band: one every 50 ms while it moves) */
#define C_CL_TRACK RGB(20, 26, 32)       /* the track: darker than the gauges' steel, barely there on the night */
static struct {
    uint32_t at;                         /* the last step (plat_ms | 1; 0: none yet) */
    uint32_t peak;                       /* the highest load read since, % */
    uint32_t v;                          /* the load shown, 1/16 % */
    uint32_t band_at;                    /* the last band started (plat_ms) */
    uint8_t n, zone;                     /* the pixels filled, the colour (0 slate, 1 yellow, 2 red) */
    uint8_t due;                         /* moved since the row was drawn */
    uint8_t shown;                       /* the screen has it (the last frame's, cl_tick) */
#if defined PLAT_HOST && !defined PLAT_WEB
    uint32_t rows, labels;               /* (the tests: the row drawn alone, cpurows; the label drawn, cpulabels) */
#endif
} cl;

static uint16_t cl_col(void) { return cl.zone == 2u ? C_RED : cl.zone ? C_BATT_LOW : C_SLATE; }

static uint8_t cl_zone(uint32_t v, uint32_t z)   /* the colour at v (1/16 %), z the one drawn: up at once, 2 % back */
{
    if (v >= 92u * 16u || (z == 2u && v >= 90u * 16u))
        return 2u;
    if (v >= 85u * 16u || (z && v >= 83u * 16u))
        return 1u;
    return 0;
}

static void cl_row(void)                 /* the row alone to the screen, after the label */
{
    cl.due = 0;
    if (cl.n)
        lcd_fill(CL_X, CL_Y, cl.n, 1, cl_col());
    if (cl.n < CL_W)
        lcd_fill(CL_X + cl.n, CL_Y, CL_W - cl.n, 1, C_CL_TRACK);
#if defined PLAT_HOST && !defined PLAT_WEB
    cl.rows++;
#endif
}

/* the label and the line in the band being drawn (rows y0 .. y0 + cv_h - 1), over what is there, if the band reaches
 * the label's box: the box the night's, CPU in it, then the line's row after it */
static void cl_band(int32_t y0)
{
    uint16_t *row, f = swap16(cl_col()), t = swap16(C_CL_TRACK), bg = swap16(C_BG);
    int32_t y, y1 = y0 + (int32_t)cv_h, x, k;
    char ch[2] = {0, 0};
    if (CL_Y < y0 || CL_LY >= y1)
        return;
    for (y = CL_LY > y0 ? CL_LY : y0; y < y1 && y <= CL_Y; y++)
        for (row = &cv_px[(uint32_t)(y - y0) * cv_w], x = 0; x < CL_X; x++)
            row[x] = bg;
    for (k = 0, x = 0; "CPU"[k]; k++) {  /* (tracked 1, as text_t would: the band's own rows) */
        ch[0] = "CPU"[k];
        x = cv_text(x, CL_LY - y0, &FONT_T, ch, C_SLATE) + 1;
    }
#if defined PLAT_HOST && !defined PLAT_WEB
    cl.labels++;
#endif
    if (CL_Y >= y1)
        return;
    row = &cv_px[(uint32_t)(CL_Y - y0) * cv_w];
    for (x = CL_X; x < (int32_t)cv_w; x++)
        row[x] = x - CL_X < (int32_t)cl.n ? f : t;
    cl.due = 0;
}

static void cl_band_start(void)          /* a band starts (band): the row first, if due */
{
    cl.band_at = plat_ms();
    if (cl.due && cl.shown)
        cl_row();
}

/* each UI frame, first: the load read; a step every CL_STEP_MS; the row, if it moved and the screen has it (shown: the
 * last frame's), drawn alone now if no band has started for CL_REST_MS (else as the next starts) */
static void cl_tick(int shown)
{
    uint32_t now = plat_ms(), l = cpu_load(), v, n;
    uint8_t z;
    cl.shown = (uint8_t)shown;
    if (l > cl.peak)
        cl.peak = l;
    if (!cl.at || now - cl.at >= CL_STEP_MS) {
        cl.at = now | 1u;
        v = (cl.peak > 100u ? 100u : cl.peak) * 16u;   /* (over the whole width: the whole width, falling from there) */
        cl.peak = 0;
        cl.v = v >= cl.v ? v : cl.v - (cl.v - v + 2u) / 3u;
        n = (cl.v * CL_W + 800u) / 1600u;
        z = cl_zone(cl.v, cl.zone);
        if (n != cl.n || z != cl.zone) {
            cl.n = (uint8_t)n;
            cl.zone = z;
            cl.due = 1;
        }
    }
    if (cl.due && shown && now - cl.band_at >= CL_REST_MS)
        cl_row();
}
#else
#define cl_band(y0) ((void)0)
#endif

/* ANCHOR's frame (app.c anchor_press): while it is set, a violet frame round the whole screen, AF_W pixels (ML 14 well
 * clear; at the foot, the hints that sit lowest drawn above it: STACK's, MIXER's PAN), breathing from full to a fifth and back (ANIMATIONS LOW: still). Its
 * MORPH back: the frame steady, erased place by place counter-clockwise from the top's middle (a clock's twelve), by the
 * clock, gone as the settings arrive: its progress. Each band draws its part before its blit (band_blit); between them
 * only the pixels that change go to the screen (anchor_frame: a breath's step, the whole frame in four fills; the
 * erasing, a fill or two a frame). Its places: the top's left half from the middle, the left side down, the bottom, the
 * right side up, the top's right half back to the middle; AF_W pixels each. (3.0.2-b2's, a thin mauve of two, read as a
 * faint blue line on the FM-1's panel: its green gone, violet; wider; its breath deeper and quicker) */
#define C_ANCHOR RGB(168, 72, 255)
#define AF_W 4                           /* its width */
#define AF_N (960 - 4 * AF_W)            /* its places (944) */
#define AF_BREATH_MS 900u                /* a breath: full, a fifth, full */
#define AF_LO 6u                         /* its dimmest (of 32) */
static struct {
    uint8_t on, lvl;                     /* on the screen, and its brightness there (of 32) */
    uint16_t gone;                       /* its places erased */
    uint8_t want_on, want_lvl;           /* as this frame has it */
    uint16_t want_gone;
} af;

static int32_t af_place(int32_t x, int32_t y)   /* a frame's pixel's place, -1: not the frame's */
{
    if (x >= AF_W && x < 240 - AF_W && y >= AF_W && y < 240 - AF_W)
        return -1;
    if (y < AF_W && x < 120)
        return 119 - x;
    if (x < AF_W)
        return 120 + (y - AF_W);
    if (y >= 240 - AF_W)
        return 360 - AF_W + (x - AF_W);
    if (x >= 240 - AF_W)
        return 600 - 2 * AF_W + (239 - AF_W - y);
    return 840 - 4 * AF_W + (239 - x);
}

static uint16_t af_col(void) { return mix565(C_BG, C_ANCHOR, af.lvl); }

/* the frame's part in the band being drawn (rows y0 .. y0 + cv_h - 1), as it is to be on the screen */
static void af_band(int32_t y0)
{
    int32_t y, x, y1 = y0 + (int32_t)cv_h;
    uint16_t c;
    if (!af.on)
        return;
    c = swap16(af_col());
    for (y = y0; y < y1; y++) {
        uint16_t *row = &cv_px[(uint32_t)(y - y0) * cv_w];
        for (x = 0; x < 240; x = y >= AF_W && y < 240 - AF_W && x == AF_W - 1 ? 240 - AF_W : x + 1)   /* (between the
                                                                             * top and the bottom: its columns alone) */
            if (af_place(x, y) >= (int32_t)af.gone)
                row[x] = c;
    }
}

/* a scene's MORPH (SCENES' MORPH, a time; card #203, admin #1580): its progress round the screen as ANCHOR's MORPH
 * back shows its own (card #225, Styves #1792: #203's line grew the other way), a frame on the frame's places, whole as
 * it starts, erased place by place by the clock from the top's middle counter-clockwise, nearly gone as the settings
 * arrive, gone with the MORPH. In the battery's green: across from ANCHOR's violet, apart from every track's band (the
 * header's top rows on it: INVERT's fog, ice, lamp and rose; the master's pale mint, C_GLOB, faded there, and a pale
 * colour reads washed out on the FM-1's panel, as ANCHOR's thin mauve did). ANCHOR set during it: its frame breathes on
 * the places the green has left, the green steady over the rest; the MORPH done, the violet whole (inside the frame, a
 * second one would cut the battery and the lowest hints). ANCHOR's MORPH back has its frame alone: a scene taken drops
 * ANCHOR, ANCHOR's way back takes the MORPH's place. Each band draws the green over ANCHOR's before its blit; between
 * them, only the places just erased (morph_frame: a fill or two a frame, ANCHOR's violet there if it is set) */
#define C_MORPH C_BATT
static struct {
    uint8_t on;                          /* on the screen */
    uint16_t gone;                       /* its places erased (of AF_N) */
} mf;

/* its part in the band being drawn (rows y0 .. y0 + cv_h - 1), as it is to be on the screen */
static void mf_band(int32_t y0)
{
    int32_t y, x, y1 = y0 + (int32_t)cv_h;
    uint16_t c;
    if (!mf.on || mf.gone >= AF_N)
        return;
    c = swap16(C_MORPH);
    for (y = y0; y < y1; y++) {
        uint16_t *row = &cv_px[(uint32_t)(y - y0) * cv_w];
        for (x = 0; x < 240; x = y >= AF_W && y < 240 - AF_W && x == AF_W - 1 ? 240 - AF_W : x + 1)   /* (as af_band) */
            if (af_place(x, y) >= (int32_t)mf.gone)
                row[x] = c;
    }
}

#if FM1B_MIRROR
/* a row the viewer has wrong: mirror.c dropped it (its ring full) and it has not gone since (mr.dirty, in this unity
 * build on the FM-1 and in the simulator) */
static int mr_row_dirty(uint32_t r) { return (int)(mr.dirty[r >> 5 & 7u] >> (r & 31u) & 1u); }

/* a band to the screen while a viewer mirrors it (card #279), from the row where the mirror last left off: on a slow
 * link it sends what fits and drops the rest, from where a blit starts; started always at the band's top, rows under
 * others that change at every frame (an edit page's values under the river, the logo's tagline in its water) would
 * wait for ever. So: the band's rows from its first one dropped last time (on from the one before), then the rows above
 * it; the next start, the first row dropped from there. The screen gets the same pixels, in two DMAs at most; no
 * viewer: one, as before */
static void band_lcd(uint32_t y0)
{
    static uint8_t from[240u / 16u];     /* (a band's next start, by its first row) */
    uint8_t *f = &from[y0 / 16u % (240u / 16u)];
    uint32_t h = cv_h, s = *f < h ? *f : 0u, k;
    if (!mirror_on || !h) {
        cv_blit(0, y0);
        return;
    }
    lcd_blit(0, y0 + s, cv_w, h - s, cv_px + s * cv_w);
    if (s)
        lcd_blit(0, y0, cv_w, s, cv_px);
    *f = 0;
    for (k = 0; k < h; k++)
        if (mr_row_dirty(y0 + (s + k) % h)) {
            *f = (uint8_t)((s + k) % h);
            break;
        }
}
#else
static void band_lcd(uint32_t y0) { cv_blit(0, y0); }
#endif

static void band_blit(int32_t y0)
{
    af_band(y0);
    mf_band(y0);                         /* (a MORPH's frame over ANCHOR's) */
    cl_band(y0);                         /* (the load's line and its label over it) */
    band_lcd((uint32_t)y0);
}

/* a rectangle of the frame filled with what is under it (the header's band, else the night: frame 0), or with the
 * frame (1) */
#if defined PLAT_HOST && !defined PLAT_WEB
static uint32_t af_px, af_fills;         /* (the tests: what it sent the screen alone, framecost; a MORPH's erasing too) */
static uint8_t af_lo = 255u, af_hi;      /* (... its breath: framelo, framehi) */
#endif
static void af_fill(int32_t x, int32_t y, int32_t w, int32_t h, int frame)
{
    uint16_t head = fm.page == PG_SAVEAS ? C_RED : band_col();
#if APP_CPU_LINE
    if (y + h > CL_Y)                    /* (the last row the load's line's) */
        h = CL_Y - y;
    if (x < CL_X && y + h > CL_LY) {     /* (and the label's box, bottom left: the left side kept above it, the bottom
                                          * right of it; the frame's strips, a side's or the bottom's, never both) */
        if (y >= CL_LY) {
            w -= CL_X - x;
            x = CL_X;
        } else {
            h = CL_LY - y;
        }
    }
#endif
    if (w <= 0 || h <= 0)
        return;
#if defined PLAT_HOST && !defined PLAT_WEB
    af_px += (uint32_t)(w * h);
    af_fills += 1u + (!frame && y < R2 && y + h > R2);
#endif
    if (frame) {
        lcd_fill((uint32_t)x, (uint32_t)y, (uint32_t)w, (uint32_t)h, af_col());
        return;
    }
    if (y < R2) {
        int32_t hh = y + h <= R2 ? h : R2 - y;
        lcd_fill((uint32_t)x, (uint32_t)y, (uint32_t)w, (uint32_t)hh, head);
        y += hh;
        h -= hh;
    }
    if (h > 0)
        lcd_fill((uint32_t)x, (uint32_t)y, (uint32_t)w, (uint32_t)h, C_BG);
}

static void af_paint(int32_t a, int32_t b, int frame)   /* places a .. b - 1 filled as af_fill's frame says (0: gone) */
{
    const int32_t s1 = 360 - AF_W, s2 = 600 - 2 * AF_W, s3 = 840 - 3 * AF_W;   /* (where each side starts, af_place's:
                                                                               * the right side up to the top row) */
    int32_t lo, hi;
    if ((lo = a) < 120 && (hi = b < 120 ? b : 120) > lo)   /* (the top's left half: x 119 - s) */
        af_fill(120 - hi, 0, hi - lo, AF_W, frame);
    if ((lo = a > 120 ? a : 120) < s1 && (hi = b < s1 ? b : s1) > lo)   /* (the left side: y s - 120 + W) */
        af_fill(0, lo - 120 + AF_W, AF_W, hi - lo, frame);
    if ((lo = a > s1 ? a : s1) < s2 && (hi = b < s2 ? b : s2) > lo)   /* (the bottom: x s - s1 + W) */
        af_fill(lo - s1 + AF_W, 240 - AF_W, hi - lo, AF_W, frame);
    if ((lo = a > s2 ? a : s2) < s3 && (hi = b < s3 ? b : s3) > lo)   /* (the right side: y 239 - W - (s - s2)) */
        af_fill(240 - AF_W, 240 - AF_W - (hi - s2), AF_W, hi - lo, frame);
    if ((lo = a > s3 ? a : s3) < AF_N && (hi = b < AF_N ? b : AF_N) > lo)   /* (the top's right half: x 239 - W - (s - s3)) */
        af_fill(240 - AF_W - (hi - s3), 0, hi - lo, AF_W, frame);
}

/* this frame's: what the frame is to be (the bands drawn now draw it so), and on the screen what changed of it */
static void anchor_frame(void)
{
    float k;
    int s = anchor_state(&k);
    af.want_on = s != 0;
    af.want_gone = s == 2 ? (uint16_t)(k * (float)AF_N) : 0u;
    af.want_lvl = s == 2 ? 32u : st.v[P_ANIM] ? 26u   /* (a breath from full: a cosine, its steps two by two) */
                  : (uint8_t)(AF_LO + 2u * (uint32_t)((float)(32u - AF_LO) * 0.25f *
                                                      (1.0f + sn(0.25f + (float)(plat_ms() % AF_BREATH_MS) / (float)AF_BREATH_MS)) + 0.5f));
    if (ui.full || af.want_on != af.on || af.want_gone < af.gone) {   /* (come, gone, or whole again: every band again,
                                                                        * the frame in each) */
        ui.full = 1;
    } else if (af.on && af.want_lvl != af.lvl) {   /* a breath's step: the whole frame (none erased while it breathes),
                                                    * a MORPH's kept: only the places it has left */
        af.lvl = af.want_lvl;
        af.gone = 0;
        if (mf.on) {
            af_paint(0, mf.gone, 1);
        } else {
            af_fill(0, 0, 240, AF_W, 1);
            af_fill(0, 240 - AF_W, 240, AF_W, 1);
            af_fill(0, AF_W, AF_W, 240 - 2 * AF_W, 1);
            af_fill(240 - AF_W, AF_W, AF_W, 240 - 2 * AF_W, 1);
        }
    }
    if (!ui.full && af.on && af.want_gone > af.gone)
        af_paint(af.gone, af.want_gone, 0);
    af.on = af.want_on;
    af.lvl = af.want_lvl;
    af.gone = af.want_gone;
#if defined PLAT_HOST && !defined PLAT_WEB
    if (af.on && s == 1) {
        af_lo = af.lvl < af_lo ? af.lvl : af_lo;
        af_hi = af.lvl > af_hi ? af.lvl : af_hi;
    }
#endif
}

/* this frame's, after ANCHOR's: what a MORPH's frame is to be (the bands drawn now draw it so), and on the screen the
 * places erased since the last, ANCHOR's violet there if it is set (never its way back: that takes the MORPH's place);
 * come, gone or whole again (another scene): every band again */
static void morph_frame(void)
{
    float k;
    uint8_t on = (uint8_t)morph_state(&k);
    uint16_t g = on ? (uint16_t)(k * (float)AF_N) : 0u;
    if (ui.full || on != mf.on || g < mf.gone)
        ui.full = 1;
    else if (on && g > mf.gone)
        af_paint(mf.gone, g, af.on);
    mf.on = on;
    mf.gone = g;
}

/* a line of progress under the title (a MORPH, PLAY held) */
static void head_progress(float k)
{
    int32_t w = MR - ML, n = (int32_t)((k < 0.0f ? 0.0f : k > 1.0f ? 1.0f : k) * (float)w);
    hline(ML, MR, 27, mix565(band_col(), C_ONBAND, 11));
    if (n > 0)
        hline(ML, ML + n - 1, 27, C_ONBAND);
}

static int32_t title_at(int32_t x, const char *s, int32_t tr)   /* a title on the band, from x */
{
    text_t(x, 8, &FONT_B, s, C_ONBAND, tr + 1);
    return text_t(x + 1, 8, &FONT_B, s, C_ONBAND, tr + 1) + 1;
}

/* the scene's name on SOUND, when fit_text would cut it (a name past sixteen, most; one of sixteen beside CHORD . DRONE,
 * some: 3.0 lost their last characters): in FONT_S,
 * bold, rolling in its room: still ROLL_REST_MS, then a pixel each ROLL_PX_MS to its end, still again, back to its start;
 * from its start whenever it comes (the name, its room changed, or the header showed something else). The header draws
 * it where it is (header); between, only its window is drawn, rows ROLL_Y .. ROLL_Y + ROLL_H - 1 across its room, and
 * only when it has moved a pixel (roll_tick: 25 a second, ~2.3 k pixels each), the sides it hides fading into the band.
 * SCENES (LOAD's list) rolls the name K1 points at the same way, in the list's own FONT_B (lroll: scenes_list) */
#define ROLL_Y 8                         /* (the title's row, FONT_S's 16; the page's dots below, from 24) */
#define ROLL_H 16                        /* (FONT_S's and FONT_B's) */
#define ROLL_PX_MS 40u
#define ROLL_REST_MS 1500u
#define ROLL_FADE 8                      /* the hidden side's last columns, into the band */
typedef struct {
    uint32_t at, sig;                    /* when it came; the name and its room it came for */
    int32_t x, y, w, dist, off;          /* its window (x, y: on the screen; w: its room), how far it goes, where it was
                                          * drawn last */
    const felucca_font_t *f;
    int32_t tr, bold;                    /* its tracking; bold: drawn twice, a pixel apart */
    uint16_t band, ink;                  /* under it, and its colour */
    uint8_t on, was;                     /* it shows now (rolling); did before it was drawn again */
    uint32_t draws, px;                  /* its windows drawn, their pixels (the tests: rollcost) */
    char t[SC_LONG + 1];
} roll_t;
static roll_t roll = {.x = ML, .y = ROLL_Y, .f = &FONT_S, .tr = 1, .bold = 1},   /* the header's (its ink: roll_head) */
              lroll = {.f = &FONT_B, .tr = 1};   /* SCENES' */

static int name_fits(const char *s, int32_t w)   /* fit_text draws it whole, bold (in FONT_B, FONT_S or FONT_XS) */
{
    return text_tw(&FONT_B, s, 0) + 1 <= w || text_tw(&FONT_S, s, 0) + 1 <= w || text_tw(&FONT_XS, s, 0) + 1 <= w;
}

static int32_t roll_at(const roll_t *r, uint32_t now)   /* how far it has gone, now: 0 .. dist */
{
    uint32_t go = (uint32_t)r->dist * ROLL_PX_MS, t = (now - r->at) % (2u * (ROLL_REST_MS + go));
    if (t < ROLL_REST_MS)
        return 0;
    if ((t -= ROLL_REST_MS) < go)
        return (int32_t)(t / ROLL_PX_MS);
    if ((t -= go) < ROLL_REST_MS)
        return r->dist;
    return r->dist - (int32_t)((t - ROLL_REST_MS) / ROLL_PX_MS);
}

/* name s, gone off pixels along (of dist), in its window w wide from x0 on the canvas drawn now, its row y (the band's
 * colour under it) */
static void roll_paint(const roll_t *r, const char *s, int32_t x0, int32_t y, int32_t w, int32_t off, int32_t dist)
{
    int32_t k, yy;
    text_t(x0 - off, y, r->f, s, r->ink, r->tr);
    if (r->bold)
        text_t(x0 + 1 - off, y, r->f, s, r->ink, r->tr);
    for (k = 0; k < ROLL_FADE; k++)      /* (the side it hides: fading into the band) */
        for (yy = y; yy < y + ROLL_H; yy++) {
            if (off > 0)
                bl(x0 + k, yy, r->band, 32 - k * 32 / ROLL_FADE);
            if (off < dist)
                bl(x0 + w - 1 - k, yy, r->band, 32 - k * 32 / ROLL_FADE);
        }
}

/* name s rolling in its window (r: x, y; w wide), drawn where it is now (from its start if it is new there) */
static void roll_draw(roll_t *r, const char *s, int32_t w, uint32_t now)
{
    uint32_t sig = 2166136261u, i;
    for (i = 0; s[i]; i++)
        sig = (sig ^ (uint8_t)s[i]) * 16777619u;
    sig ^= (uint32_t)w << 24 ^ (uint32_t)r->y << 16;
    if (!r->was || sig != r->sig) {
        r->sig = sig;
        r->at = now;
        for (i = 0; s[i] && i < SC_LONG; i++)
            r->t[i] = s[i];
        r->t[i] = 0;
        r->w = w;
        r->dist = text_tw(r->f, r->t, r->tr) + r->bold - w;
    }
    r->on = 1;
    r->off = roll_at(r, now);
    roll_paint(r, r->t, r->x, r->y, w, r->off, r->dist);
}

/* header: the name rolling in room w from ML, on the band's colour c (the load's dot at bx - 7 drawn again: its row
 * cleared past the room); its end */
static int32_t roll_head(const char *s, int32_t w, uint16_t c, uint32_t now, int32_t bx)
{
    roll.band = c;
    roll.ink = C_ONBAND;
    roll_draw(&roll, s, w, now);
    cv_rect(0, 0, ML, 32, c);            /* (what it hides: the band's) */
    cv_rect(ML + w, ROLL_Y, 240 - ML - w, ROLL_H, c);
    if (cpu_over())
        cv_rect(bx - 7, 13, 3, 3, C_ONBAND);
    return ML + w;
}

/* each frame its band is not drawn: the name's window again if it has moved */
static void roll_tick(roll_t *r, uint32_t now)
{
    int32_t off;
    if (!r->on || (off = roll_at(r, now)) == r->off)
        return;
    r->off = off;
    oy = r->y;
    cv_begin((uint32_t)r->w, ROLL_H, r->band);
    roll_paint(r, r->t, 0, r->y, r->w, off, r->dist);
    cv_blit((uint32_t)r->x, (uint32_t)r->y);
    r->draws++;
    r->px += (uint32_t)r->w * ROLL_H;
}

/* the battery (#125, app.c batt), in the header's right margin: 6 x 12, its body from the titles' capitals' top to
 * their baseline (rows 10 .. 20), its tip 2 wide on row 9, its two bottom corners off (the band's colour, band); its
 * frame in ink (the band's: the letters'); inside (4 x 9), the charge from the bottom (at least a row), the rest
 * C_SLATE. None: nothing */
static void batt_draw(uint16_t band, uint16_t ink)
{
    int32_t n;
    uint16_t c;
    if (batt.pct < 0)
        return;
    n = ((int32_t)batt.pct * 9 + 50) / 100;
    n = n < 1 ? 1 : n;
    c = batt.zone == 2u ? C_RED : batt.zone ? C_BATT_LOW : C_BATT;
    cv_rect(230, 10 - oy, 6, 11, ink);
    bl(230, 20, band, 32);
    bl(235, 20, band, 32);
    cv_rect(232, 9 - oy, 2, 1, ink);
    cv_rect(231, 11 - oy, 4, 9 - n, C_SLATE);
    cv_rect(231, 20 - n - oy, 4, n, c);
}

#if PLAT_SMK37
#define C_PADOK RGB(64, 224, 112)        /* the SMK-37's OK: pad 2's green */
#define C_PADLOAD RGB(84, 156, 255)      /* LOAD's blue (SAVE's flow, Styves) */
#define C_PADSAVE RGB(24, 200, 150)      /* SAVE's emerald: a green with blue in it */
/* a choice waiting on the SMK-37 (app.c pad_mode): its pads' words, small, at the top right on a dark ground (over a
 * band's colour, the track's tag), pad 1's then pad 2's: CANCEL in red, OK in green (a warning, OK alone); SAVE's flow
 * its own, LOAD in blue and SAVE in emerald (its first page LOAD SAVE; SCENES CANCEL LOAD; WHAT and INTO, the name,
 * CANCEL SAVE). In SEL's and FX's place: the screens name the pads alone */
static void pad_words(const char *l, uint16_t lc, const char *r, uint16_t rc)
{
    int32_t wr = text_tw(&FONT_XS, r, 1), wl = l ? text_tw(&FONT_XS, l, 1) + 8 : 0;
    cv_rect(MR - wr - wl - 5, 4 - oy, wr + wl + 7, 19, C_BG);
    text_r(MR, 7, &FONT_XS, r, rc, 1);
    if (l)
        text_r(MR - wr - 8, 7, &FONT_XS, l, lc, 1);
}
static void pad_hint_as(uint32_t m)
{
    if (m == PA_LOADSAVE)
        pad_words("LOAD", C_PADLOAD, "SAVE", C_PADSAVE);
    else if (m == PA_LOAD)
        pad_words("CANCEL", C_RED, "LOAD", C_PADLOAD);
    else if (m == PA_SAVE)
        pad_words("CANCEL", C_RED, "SAVE", C_PADSAVE);
    else if (m != PA_NONE)
        pad_words(m == PA_OK ? 0 : "CANCEL", C_RED, "OK", C_PADOK);
}
static void pad_hint(int cancel) { pad_hint_as(cancel ? PA_OKCANCEL : PA_OK); }
/* the colour of the LFO that moves setting p (Styves, 2026-11-09): its pad's hue on the screen (app.c PAD_HUE, made for the
 * LEDs: these for the LCD, by the tracks' colours on the dark), LFO 1 blue, 2 cyan, 3 pink; on two (a scene from
 * elsewhere: a pad's or LFO held's assigning takes it off the others), the first; none on, ice as ever */
static uint16_t lfo_col(uint32_t p)
{
    static const uint16_t LC[NLFO] = {RGB(40, 110, 255), RGB(0, 200, 255), RGB(255, 60, 160)};
    uint32_t t, i, k;
    for (t = 1; t < NLFO_TGT && LFO_TGT[t] != p; t++)
        ;
    for (i = 0; t < NLFO_TGT && i < NLFO; i++)
        for (k = 0; k < 4u; k++)
            if (st.v[LFO_BASE[i] + 4u + k] == t && lfo[i].on)
                return LC[i];
    return C_ICE;
}
#endif

/* the header's band to the screen (DARK: no line under it, Styves 2026-11-06, after #105's hairline); the battery on
 * it (SAVE's red: in the night) */
static void head_blit(void)
{
#if PLAT_SMK37
    if (fm.page == PG_SAVE || fm.page == PG_SAVEAS || fm.page == PG_SCENES)   /* (SAVE's flow: its pads' words over the
                                                                               * track's tag) */
        pad_hint_as(pad_mode());
#endif
    batt_draw(fm.page == PG_SAVEAS ? C_RED : band_col(), fm.page == PG_SAVEAS ? C_BG : C_ONBAND);
    band_blit(R1);
}

static void header(void)
{
    char t[40];
    uint32_t now = plat_ms();
    uint16_t band_c = fm.page == PG_SAVEAS ? C_RED : band_col(), soft = mix565(band_c, C_ONBAND, 22);
    int32_t xt, bw = track_tag_w(), bx = MR - bw + 1, xr = bx - 6;
    float ph = play_holding();
    roll.was = roll.on;                  /* (the name rolls on only if this draws it again) */
    roll.on = 0;
    band(R1, 32);
    cv_rect(0, 0, 240, 32, band_c);
    if (fm.page == PG_SAVEAS) {          /* WHAT and INTO: something is about to be written: red, SAVE in white, no track */
        fit_text(ML, 8, MR - ML, "SAVE", C_WHITE, 1, 1);
        head_blit();
        return;
    }
    if (cpu_over())                      /* the render ran over its time just now: a dot by the track (its room kept
                                          * always: the title does not move as it comes and goes) */
        cv_rect(bx - 7, 13 - oy, 3, 3, C_ONBAND);
    xr -= 8;
    if (ph > 0.0f) {                     /* PLAY held: what it is about to do, counting down */
        title_at(ML, holding_any() || !rst_valid ? "RELEASE ALL" : "RESTORE", 0);
        head_progress(ph);
        track_tag(bx);
        head_blit();
        return;
    }
    if (cnt.run) {                       /* COUNT-IN, the beat it is on */
        int32_t x = title_at(ML, "COUNT-IN", 0);
        cv_rect(x + 6, 14 - oy, 3, 3, C_ONBAND);
        t[0] = (char)('0' + (cnt.beat > 4u ? 4u : cnt.beat ? cnt.beat : 1u));
        t[1] = 0;
        title_at(x + 15, t, 0);
        track_tag(bx);
        head_blit();
        return;
    }
    if (now < say.msg_until && say.amt) {   /* SEL + K: an LFO's AMOUNT, large, its bar (the whole band) */
        amt_head(say.amt - 1u, C_ONBAND, soft);
        head_blit();
        return;
    }
    if (now < say.msg_until) {           /* a message for a moment (the track stays, if there is room) */
        int32_t x = text_t(ML, 8, &FONT_B, say.msg[0], C_ONBAND, 1);
        if (say.red == 2u) {             /* (two words alike: ARP ON . SEQ OFF) */
            text_t(ML + 1, 8, &FONT_B, say.msg[0], C_ONBAND, 1);
            cv_rect(x + 6, 14 - oy, 3, 3, C_ONBAND);
            text_t(x + 15, 8, &FONT_B, say.msg[1], C_ONBAND, 1);
            x = text_t(x + 16, 8, &FONT_B, say.msg[1], C_ONBAND, 1);
        } else if (say.msg[1][0] && say.red) {   /* (bold, deep red: twice, a pixel apart, as the titles) */
            text_t(x + 7, 8, &FONT_B, say.msg[1], head_red(), 1);
            x = text_t(x + 8, 8, &FONT_B, say.msg[1], head_red(), 1);
        } else if (say.msg[1][0])
            x = text_t(x + 7, 9, &FONT_XS, say.msg[1], soft, 1);
        if (x + 8 <= bx)
            track_tag(bx);
        head_blit();
        return;
    }
    if (mo.on && !mo.anc && (fm.page == PG_SON || fm.page == PG_SCENES)) {   /* a MORPH: an arrow, the scene it goes
                                                                               * to, how far (elsewhere: the progress
                                                                               * under the page; ANCHOR's: its frame) */
        int32_t i;
        for (i = 0; i < 9; i++)
            bl(ML + i, 16, C_ONBAND, 32);
        for (i = 1; i <= 3; i++) {
            bl(ML + 8 - i, 16 - i, C_ONBAND, 32);
            bl(ML + 8 - i, 16 + i, C_ONBAND, 32);
        }
        if (fm.scene < NSCENES && scn.s[fm.scene].name_more[0] && (scn.used >> fm.scene & 1u)) {   /* (a name past sixteen:
                                                                                                * the engine's has them) */
            char nt[SC_LONG + 1];
            fit_text(ML + 15, 8, bx - 8 - ML - 15, scene_name(fm.scene, nt), C_ONBAND, 1, 1);
        } else {
            title_at(ML + 15, mo.name, 1);
        }
        head_progress((float)(now - mo.t0) / (float)mo.dur);
        track_tag(bx);
        head_blit();
        return;
    }
    if (st.compare) {                    /* EDIT held: the scene as it was saved */
        int32_t x = title_at(ML, "COMPARE", 0);
        text_t(x + 8, 9, &FONT_XS, "AS SAVED", soft, 1);
        track_tag(bx);
        head_blit();
        return;
    }
    /* the title first, the track at the right; between them, by priority while they fit: on GLOBAL the load,
     * FREEZE; last, beside the title, the key; under the title, where the page is among its button's */
    if (fm.page == PG_SON) {             /* the scene: its name, as large as it fits whole (fit_text), else rolling in
                                          * its room (roll_head); a dot while the sound differs; FREEZE's tag if there
                                          * is room left (else a flake) */
        char nt[SC_LONG + 1];
        int32_t room = xr - ML - (st.dirty ? 8 : 0), wf = text_tw(&FONT_XS, "FREEZE", 1) + 8 + 6;
        scene_name(fm.scene, nt);
        if (st.v[P_FREEZE])
            room -= text_tw(&FONT_B, nt, 2) + 1 + wf <= room ? wf : 13;
        xt = name_fits(nt, room) ? fit_text(ML, 8, room, nt, C_ONBAND, 1, 2) : roll_head(nt, room, band_c, now, bx);
        if (st.dirty) {
            cv_rect(xt + 4, 12 - oy, 3, 3, C_ONBAND);
            xt += 8;
        }
    } else if (fm.page == PG_SCENES) {
        xt = title_at(ML, "SCENES", 2);
        if (st.dirty && xt + 8 + text_tw(&FONT_XS, "CHANGED", 1) <= xr)
            xt = text_t(xt + 8, 9, &FONT_XS, "CHANGED", soft, 1);
    } else {                             /* (SAVE's first: as K1 has it) */
        t[0] = 0;
        if (clear_corner() && st.v[st.glint ? P_SQ_REC : st.bass ? P_BQ_REC : P_DQ_REC]) {   /* (a take: the title says which) */
            text_cat(t, st.glint ? "GLINT " : st.bass ? "BASS " : "DRONE ");
            text_cat(t, keys_word());
        }
        xt = fit_text(ML, 8, xr - ML, t[0] ? t : fm.page == PG_SAVE && !sv.load ? "SAVE" : page_name(fm.page),
                      C_ONBAND, 1, 1);
    }
    page_dots();
    if (mo.on && !mo.anc) {
        int32_t w = (int32_t)((float)(now - mo.t0) / (float)mo.dur * (float)(MR - ML));
        hline(ML, MR, 30, mix565(band_c, C_ONBAND, 11));
        if (w > 0)
            hline(ML, ML + (w > MR - ML ? MR - ML : w), 30, C_ONBAND);
    }
#if PLAT_SMK37
    if (fm.page != PG_SAVE && fm.page != PG_SAVEAS && fm.page != PG_SCENES)   /* (the pads' words in its place:
                                                                               * head_blit; the tag cut, they read
                                                                               * "CHOR LOAD SAVE") */
#endif
    track_tag(bx);
    t[0] = 0;
    if (fm.page == PG_GLOBAL) {          /* the load, for the first tests on a device */
        uint32_t n;
        text_cat(t, "CPU ");
        int_text((int32_t)cpu_load(), t + strlen_(t));
        text_cat(t, "%");
        n = strlen_(t);
        text_cat(t, "  ");
        int_text((int32_t)ui.fps, t + strlen_(t));
        text_cat(t, " FPS");
        if (xr - text_tw(&FONT_XS, t, 0) < xt + 30)
            t[n] = 0;                    /* short of room: the load alone */
        if (xr - text_tw(&FONT_XS, t, 0) >= xt + 8) {
            text_r(xr, 9, &FONT_XS, t, soft, 0);
            xr -= text_tw(&FONT_XS, t, 0) + 6;
        }
    }
    if (st.v[P_FREEZE]) {                /* FREEZE: a tag in the band's ink, the word in ice (DARK: the night's) */
        int32_t wf = text_tw(&FONT_XS, "FREEZE", 1) + 8;
        if (xr - wf + 1 >= xt + 6) {
            cv_rect(xr - wf + 1, 7, wf, 16, C_ONBAND);
            text_t(xr - wf + 5, 9, &FONT_XS, "FREEZE", hdr.dark ? C_BG : C_ICE, 1);
            xr -= wf + 7;
        } else if (fm.page == PG_SON) {  /* (a long name: a flake) */
            int32_t k, cx = xr - 4;
            for (k = 1; k <= 4; k++) {
                int32_t dy = (k * 4 + 3) / 7, a = 32 - k * 4;
                bl(cx, 15 - k, C_ONBAND, a);
                bl(cx, 15 + k, C_ONBAND, a);
                if (k < 4) {
                    bl(cx + k, 15 - dy, C_ONBAND, a);
                    bl(cx - k, 15 + dy, C_ONBAND, a);
                    bl(cx + k, 15 + dy, C_ONBAND, a);
                    bl(cx - k, 15 - dy, C_ONBAND, a);
                }
            }
            bl(cx, 15, C_ONBAND, 32);
            xr -= 13;
        }
    }
    head_blit();
}

/* a choice among a few: a dot for each, the chosen one lit; close together under the value, ten pixels apart, three
 * quarters of the cell at most, so that the last of a cell's is never read as the first of the next cell's */
static void steps(int32_t x, int32_t y, int32_t w, uint32_t n, uint32_t i)
{
    uint32_t k, span = (n - 1u) * 10u, most = (uint32_t)w * 3u / 4u;
    if (span > most)
        span = most;
    for (k = 0; k < n; k++) {
        int32_t px = x + (int32_t)(k * span / (n - 1u));
        if (k == i)
            cv_rect(px - 1, y - 1 - oy, 3, 3, ui_off ? C_SLATE : C_ICE);
        else
            cv_rect(px, y - oy, 1, 1, ui_off ? C_SLATE : C_MIST);
    }
}

/* an LFO TARGET's colour: its track's, as the keys' badge has them (DRONE white, GLINT ice, BASS lamp), OFF slate */
static uint16_t tgt_col(uint32_t t)
{
    uint32_t p = LFO_TGT[t % NLFO_TGT];
    if (p >= NPARAM)
        return C_MIST;
    if (p == P_FL_CUT || p == P_FL_RESO || p == P_GX_BLUR || p == P_GX_SINK || p == P_PN_CLOUD ||
        (p >= P_TP_SAT && p <= P_TP_WOBBLE) || (p >= P_TP_FLUTTER && p <= P_TP_DROPOUT) || t % NLFO_TGT >= LFO_T_XM)
        return C_GLOB;                   /* (the LFOs' own too: GLOBAL's, card #199) */
    if (p == P_GL_LEVEL || p == P_GL_BRIGHT || p == P_GL_PING || p == P_GL_SPACE || p == P_MX_GLINT || p == P_ARP_CHANCE ||
        p == P_SQ_LEN || p == P_GX_SPARK || p == P_PN_GLINT || p == P_GL_ATTACK || p == P_GL_DECAY || p == P_GL_SUSTAIN ||
        p == P_GL_RELEASE)
        return C_ICE;
    if (p == P_BS_FILTER || p == P_BS_RESO || p == P_BS_DRIVE || p == P_MX_BASS || p == P_PN_BASS || p == P_BS_ATTACK ||
        p == P_BS_DECAY || p == P_BS_SUSTAIN || p == P_BS_RELEASE)
        return C_LAMP;
#if FRS_LEAD
    if (p >= P_LD_WAVE)                  /* (LEAD's, its MIXER level among them) */
        return C_LEAD_TRACK;
#endif
    return C_FOG;
}

/* a setting's name on its page: CLOUD SEND's are each a SPACE, whose it says */
static const char *cell_name(int p)
{
#if FRS_LEAD
    if (fm.page == PG_CSEND && p == P_LD_SPACE)
        return "LEAD";
#endif
    if (fm.page == PG_CSEND)
        return p == P_ESPACE ? "DRONE" : p == P_GL_SPACE ? "GLINT" : "BASS";
#if FRS_LEAD
    if (fm.page == PG_NUAGE3 && (p == P_MX_CLOUD || p == P_PN_CLOUD))   /* (the cloud's return and its PAN, there) */
        return p == P_MX_CLOUD ? "LEVEL" : "PAN";
#endif
    if (p == P_TEMPO && ext_bpm())       /* (a MIDI clock leads: its tempo, app.c ext_bpm) */
        return "TEMPO (EXT)";
    return pd_name((uint32_t)p);
}

static void cell_w(int32_t x, int32_t y, int p, int32_t w);
static void cell(int32_t x, int32_t y, int p) { cell_w(x, y, p, 96); }
#if FRS_LEAD
/* CLOUD III's K4 its PAN while OCT- is held, or a moment after it turned (app.c encoders: MIXER's way) */
static int cloud_pan_shown(void) { return b_held(B_OCTDN) || (touched_now() && fm.touched == P_PN_CLOUD); }
#endif

/* KEYS' NOTES on CHORD where the keys play one note all the same (eng_key_down): why, under the value; else 0 */
static const char *notes_why(int p)
{
    if ((p != P_KY_GL_NOTES && p != P_KY_BS_NOTES) || !st.v[p])
        return 0;
    if (p == P_KY_BS_NOTES)
        return st.v[P_BQ_ON] == SQT_ARP ? 0 : "(ARP ONLY)";
    return st.v[P_SQ_TYPE] == SQT_SEQ ? "(NOT ON SEQ)" : 0;
}

/* a setting whose effect is off: MASTER FILTER's with its TYPE OFF, MASTER EQ's bands with its PRESET OFF, LOFI
 * TAPE's with TAPE OFF (still turned: slate, its name too, so the page reads off) */
static int param_off(int p)
{
    if (p >= P_KY_DR_HARM && p <= P_KY_BS_STACK && ((uint32_t)(p - P_KY_DR_HARM) & 3u) == 1u)   /* NOTES: HARMONY off, or
                                                                                                 * CHORD not heard here */
        return !st.v[P_KY_DR_HARM + 4u * ((uint32_t)(p - P_KY_DR_HARM) / 4u)] || notes_why(p) != 0;
    return ((p == P_FL_CUT || p == P_FL_RESO || p == P_FL_TRACKS) && !st.v[P_FL_TYPE]) ||
           (p >= P_EQ_LOW && p <= P_EQ_HIGHF && !st.v[P_EQ_PRESET]) ||
           (p >= P_TP_SAT && p <= P_TP_TRACKS && !st.v[P_TP_ON]);
}

static void cell_w(int32_t x, int32_t y, int p, int32_t w)   /* a parameter: its name, its value, a gauge or its
                                                              * choices, w wide */
{
    int hot, f, ext;
    if (p == (int)K_ARP || p == (int)K_SEQ) {   /* ARP's and SEQ's ON, OFF */
        int on = ways_on(PAGES[fm.page].track, p == (int)K_ARP ? SQT_ARP : SQT_SEQ);
        badge_of(x + 7, y + 7, p, -1);
        text_t(x + BADGE_W, y, &FONT_XS, p == (int)K_ARP ? "ARP" : "SEQUENCE", C_MIST, 1);
        cv_text(x, y + 15 - oy, &FONT_M, on ? "ON" : "OFF", on ? C_ICE : C_MIST);
        steps(x + 1, y + 41, w, 2u, (uint32_t)on);
        return;
    }
    if (p == (int)K_IDLE) {              /* SCREEN's IDLE TIME, minutes (SCREENSAVER OFF: slate) */
        char t[4];
        int32_t e;
        hot = saver.min_at && plat_ms() - saver.min_at < TOUCH_MS;
        ui_off = (uint8_t)!st.v[P_SAVER];
        t[0] = (char)(saver.min >= 10u ? '0' + saver.min / 10u : '0' + saver.min);
        t[1] = (char)(saver.min >= 10u ? '0' + saver.min % 10u : 0);
        t[2] = 0;
        badge_of(x + 7, y + 7, p, -1);
        text_t(x + BADGE_W, y, &FONT_XS, "IDLE TIME", ui_off ? (hot ? C_MIST : C_SLATE) : hot ? C_LAMP : C_MIST, 1);
        e = cv_text(x, y + 15 - oy, &FONT_M, t, ui_off ? C_SLATE : C_FOG);
        cv_text(e + 4, y + 15 + (int32_t)FONT_M.h - (int32_t)FONT_XS.h - 1 - oy, &FONT_XS, "MIN", ui_off ? C_SLATE : C_MIST);
        gauge(x, y + 41, w, (float)(saver.min - 1u) / 59.0f, ui_off ? C_SLATE : hot ? C_LAMP : C_MIST);
        ui_off = 0;
        return;
    }
    if (p == (int)K_SHAPE) {             /* an ENV page's ATTACK SHAPE (card #122): CURVE, LINE */
        int line = shape_line();
        hot = shape_hot();
        badge_of(x + 7, y + 7, p, -1);
        text_t(x + BADGE_W, y, &FONT_XS, page_shape(fm.page) == 4 ? "F.ATK SHAPE" : "ATTACK SHAPE", hot ? C_LAMP : C_MIST,
               1);
        cv_text(x, y + 15 - oy, &FONT_M, line ? "LINE" : "CURVE", C_FOG);
        steps(x + 1, y + 41, w, 2u, (uint32_t)line);
        return;
    }
    if (p >= (int)K_LINK && p <= (int)K_LK0 + 3) {   /* TRACKS LINK's (card #212): FOLLOW DRONE, BASS; a track NO LINK,
                                                       * LINKED */
        static const char *const LK_NAME[4] = {"DRONE", "BASS", "GLINT", "MIDI"};
        int t = p - (int)K_LK0, on = p == (int)K_LINK ? lk.follow : (int)(lk.bits >> t & 1u);
        const char *v = p == (int)K_LINK ? (on ? "BASS" : "DRONE") : on ? "LINKED" : "NO LINK";
        hot = link_hot((uint32_t)p);
        badge_of(x + 7, y + 7, p, -1);
        text_t(x + BADGE_W, y, &FONT_XS, p == (int)K_LINK ? "FOLLOW" : LK_NAME[t], hot ? C_LAMP : C_MIST, 1);
        cv_text(x, y + 15 - oy, text_w(&FONT_M, v) > w + 4 ? &FONT_B : &FONT_M, v,
                p == (int)K_LINK ? C_FOG : on ? C_ICE : C_MIST);
        steps(x + 1, y + 41, w, 2u, (uint32_t)on);
        return;
    }
    if (p == (int)K_HEAD) {              /* SCREEN's HEADER: INVERT, DARK */
        const char *v = hdr.dark ? "DARK" : "INVERT";
        hot = hdr.at && plat_ms() - hdr.at < TOUCH_MS;
        badge_of(x + 7, y + 7, p, -1);
        text_t(x + BADGE_W, y, &FONT_XS, "HEADER", hot ? C_LAMP : C_MIST, 1);
        cv_text(x, y + 15 - oy, text_w(&FONT_M, v) > w + 4 ? &FONT_B : &FONT_M, v, C_FOG);
        steps(x + 1, y + 41, w, 2u, hdr.dark);
        return;
    }
#if LD_CH_PAGE
    if (p == (int)K_LDCH) {              /* MIDI's LEAD CH (card #228: the engine's st.ldch), as the tracks' channels */
        char t[8];
        hot = ldch_at && plat_ms() - ldch_at < TOUCH_MS;
        value_text(P_CH_BASS, st.ldch, t);   /* (a channel's words: OFF, 1 .. 16, OMNI) */
        badge_of(x + 7, y + 7, p, -1);
        text_t(x + BADGE_W, y, &FONT_XS, "LEAD CH", hot ? C_LAMP : C_MIST, 1);
        cv_text(x, y + 15 - oy, text_w(&FONT_M, t) > w + 4 ? &FONT_B : &FONT_M, t, C_FOG);
        gauge(x, y + 41, w, (float)st.ldch / (float)PD[P_CH_BASS].max, hot ? C_LAMP : C_MIST);
        return;
    }
#endif
    if (p == (int)K_TUNE) {              /* RECORD's TUNE A4, Hz */
        char t[4];
        int32_t e;
        hot = a4.at && plat_ms() - a4.at < TOUCH_MS;
        t[0] = (char)('0' + a4.hz / 100u);
        t[1] = (char)('0' + a4.hz / 10u % 10u);
        t[2] = (char)('0' + a4.hz % 10u);
        t[3] = 0;
        badge_of(x + 7, y + 7, p, -1);
        text_t(x + BADGE_W, y, &FONT_XS, "TUNE A4", hot ? C_LAMP : C_MIST, 1);
        e = cv_text(x, y + 15 - oy, &FONT_M, t, C_FOG);
        cv_text(e + 4, y + 15 + (int32_t)FONT_M.h - (int32_t)FONT_XS.h - 1 - oy, &FONT_XS, "HZ", C_MIST);
        gauge(x, y + 41, w, (float)(a4.hz - A4_LO) / (float)(A4_HI - A4_LO), hot ? C_LAMP : C_MIST);
        return;
    }
#if FRS_MIDI_OUT
    if ((p >= (int)K_MO_CH && p <= (int)K_MO_PRS) || p == (int)K_CLKOUT || p == (int)K_NOUT) {   /* MIDI OUT's (card
                                                         * #164): CHANNEL a gauge, the others their steps; CLOCK OUT,
                                                         * NOTES OUT (card #201) */
        char t[12];
        hot = mout.at && mout.at_p == (prm_t)p && plat_ms() - mout.at < TOUCH_MS;
        mout_text((uint32_t)p, t);
        badge_of(x + 7, y + 7, p, -1);
        text_t(x + BADGE_W, y, &FONT_XS, mout_name((uint32_t)p), hot ? C_LAMP : C_MIST, 1);
        cv_text(x, y + 15 - oy, text_w(&FONT_M, t) > w + 4 ? &FONT_B : &FONT_M, t, C_FOG);
        if (p == (int)K_MO_CH)
            gauge(x, y + 41, w, (float)mout.ch / 15.0f, hot ? C_LAMP : C_MIST);
        else
            steps(x + 1, y + 41, w, mout_steps((uint32_t)p), mout_at((uint32_t)p));
        return;
    }
    if (p >= (int)K_MD0 && p < (int)K_MDN) {   /* MIDI's ARP and SEQ (card #169): as the GLINT setting it borrows (the
                                                * arpeggio's own, card #172: theirs) */
        char t[16];
        uint32_t i = (uint32_t)p - K_MD0, max = md_max(i), min = md_min(i);
        hot = msq.at && msq.at_i == i && plat_ms() - msq.at < TOUCH_MS;
        ui_off = (uint8_t)(i == MD_NOTE && md[MD_NOTE] == 0u);   /* (a REST: slate, as GLINT's) */
        if ((i == MD_KNOTES || i == MD_LNOTES) && (!md_harm_of(i) || md_notes_why(i)))   /* (KEYS' NOTES, MIDI's
                                                                    * and the LEAD's: HARMONY off, or CHORD not heard
                                                                    * here, as the other tracks', card #194) */
            ui_off = 2;
        md_text(i, t);
        badge_of(x + 7, y + 7, p, -1);
        text_t(x + BADGE_W, y, &FONT_XS, md_name(i), ui_off == 2 ? (hot ? C_MIST : C_SLATE) : hot ? C_LAMP : C_MIST, 1);
        cv_text(x, y + 15 - oy, text_w(&FONT_M, t) > w + 4 ? &FONT_B : &FONT_M, t, ui_off ? C_SLATE : C_FOG);
        if (md_notes_why(i))
            text_t(x + 22, y + 36, &FONT_XS, md_notes_why(i), C_MIST, 1);
        if (max > 16u)
            gauge(x, y + 41, w, (float)(md[i] - min) / (float)(max - min), ui_off ? C_SLATE : hot ? C_LAMP : C_MIST);
        else
            steps(x + 1, y + 41, w, max + 1u, md[i]);
        ui_off = 0;
        return;
    }
#endif
    if (p >= NPARAM)                     /* an empty slot (GLOBAL II) */
        return;
    hot = touched_now() && fm.touched == p;
    f = PD[p].fmt;
    ext = p == P_TEMPO && ext_bpm();     /* TEMPO (EXT): its value and gauge slate, its name read as any */
    ui_off = (uint8_t)(param_off(p) || ext);
    badge_of(x + 7, y + 7, p, -1);
    text_t(x + BADGE_W, y, &FONT_XS, cell_name(p), ext ? C_MIST : ui_off ? (hot ? C_MIST : C_SLATE) : hot ? C_LAMP : C_MIST, 1);
    value_big(x, y + 15, p, w + 4, &FONT_M, ui_off ? C_SLATE : ng.on && ng.pick && ng.p == (prm_t)p ? C_LAMP
                                            : f == F_LTGT ? tgt_col(st.v[p]) : C_FOG, 0);   /* (picked under OCT-: lamp) */
    if (notes_why(p))
        text_t(x + 22, y + 36, &FONT_XS, notes_why(p), C_MIST, 1);
    if (f == F_LTGT) {                   /* (a TARGET: a name, in its track's colour, no scale; its AMOUNT under it, from
                                          * x1.00 at the middle, when it is not x1.00 or SEL + K turns it) */
        uint32_t slot = tgt_slot((uint32_t)p);
        int amt = plat_ms() < say.msg_until && say.amt == slot + 1u;
        ui_off = 0;
        if (slot < 12u && st.v[p] && (amt || st.v[P_L1_AMT1 + slot] != PD[P_L1_AMT1 + slot].def))
            gauge_amt(x, y + 41, w, slot, C_STEEL, amt ? C_LAMP : C_MIST, C_SLATE);
        return;
    }
    if (PD[p].max <= 16u && f != F_PCT)
        steps(x + 1, y + 41, w, PD[p].max + 1u, pv_shown(p));
    else if (times_p(p))                 /* (a factor: from its x1.00) */
        gauge_times(x, y + 41, w, p, ui_off ? C_SLATE : hot ? C_LAMP : C_MIST);
    else
        gauge(x, y + 41, w, step_len_p(p) >= 0 ? (st.v[step_len_p(p)] ? (float)st.v[p] / (float)st.v[step_len_p(p)] : 0.0f)
                                               : (float)pv_shown(p) / (float)PD[p].max,
              ui_off ? C_SLATE : hot ? C_LAMP : C_MIST);
    ui_off = 0;
    if (mod_of((uint32_t)p) != 0.0f && PD[p].max > 16u) {   /* an LFO on it: where it is now, in ice */
        float m = vh(p) + mod_of((uint32_t)p), u;
        if (f == F_LRATE)                /* (an LFO's RATE, an LFO on it: on its own side, free or the grid's; card #199) */
            m = st.v[p] < LFO_NFREE ? (m > (float)(LFO_NFREE - 1u) ? (float)(LFO_NFREE - 1u) : m)
                                    : (m < (float)LFO_NFREE ? (float)LFO_NFREE : m);
        u = br_clamp01(m / (float)PD[p].max);
        int32_t n = clamp((int32_t)(u * (float)w + 0.5f), 1, w);
#if PLAT_SMK37                           /* (the SMK-37: 2 px, in its LFO's colour, its pad's hue: lfo_col) */
        cv_rect(x + (n > w - 1 ? w - 2 : n - 1), y + 41 - 3 - oy, 2, 7, lfo_col(p));
#else
        cv_rect(x + n - 1, y + 41 - 3 - oy, 1, 7, C_ICE);
#endif
    }
}

/* a sequencer recording (STEP or LIVE), its strip ruled, a quiet help far under the notes. Across, x0 .. x1, a
 * hairline each whole tone of the strip's range, a note on one or between two (closer than 4 px, thinned to thirds,
 * tritones, octaves: each divides the octave, the Cs kept, a touch brighter) */
static void pitch_lines(int32_t x0, int32_t x1, int32_t top, int32_t bot, int32_t lo, int32_t hi)
{
    static const uint8_t K[4] = {2, 4, 6, 12};
    int32_t k = 0, n, x, y;
    while (k < 3 && K[k] * (bot - top) < 4 * (hi - lo))
        k++;
    for (n = lo; n <= hi; n++)
        if (n % K[k] == 0)
            for (y = bot - (n - lo) * (bot - top) / (hi - lo), x = x0; x <= x1; x++)
                bl(x, y, C_SLATE, n % 12 ? 4 : 7);
}

/* down, a step's edge, y0 .. y1 */
static void step_line(int32_t x, int32_t y0, int32_t y1)
{
    for (; y0 <= y1; y0++)
        bl(x, y0, C_SLATE, 4);
}

/* the step recorded into (STEP: K1's, where the next key writes; LIVE: the one playing), xa .. xb: a soft band of the
 * track's colour, a shaft of light fading out up and down, its edges a little brighter */
static void rec_band(int32_t xa, int32_t xb, int32_t y0, int32_t y1, uint16_t c)
{
    int32_t x, y, h = (y1 - y0) / 2;
    for (y = y0; y <= y1; y++) {
        int32_t d = y - y0 < y1 - y ? y - y0 : y1 - y, a2 = 2 + 10 * (d > h ? h : d) * (2 * h - d) / (h * h);
        for (x = xa; x <= xb; x++) {     /* (in half steps, the odd ones dithered: no bands) */
            int32_t a = (a2 >> 1) + ((a2 & 1) & (x ^ y));
            bl(x, y, c, x == xa || x == xb ? a + 3 : a);
        }
    }
}

/* a sequence across the strip, GLINT's in ice, the bass's in lamp, one picture: only its SEQ LENGTH's steps, the strip's
 * scale by blocks of four (a step as wide from 5 to 8 steps, from 9 to 12...), what is left of the strip bare. A NOTE is a line at its note's height (the lowest to highest, at least an octave), a mark where it
 * starts (taller with ACCENT), stretched on through its TIEs (the bass's HOLDs), the water under it down to the bed, as
 * in the river (bass_bed); a rest, nothing; TIEs at its start, the note its last steps leave sounding, round. The one
 * playing bright; the playhead going along; the step on K1, a line under it; RECORD on LIVE, a lamp light in the corner,
 * and a bass take's note down drawn bright as it is held, from where it went down to the playhead; off SEQ, the steps
 * slate. Recording, the strip ruled, each step a column, the one recorded into lit */
#if FRS_MIDI_OUT
#define SEQ2_MIDI PG_MSEQ2
#else
#define SEQ2_MIDI NPAGES
#endif
static void seq_scope(int bs)            /* (bs: 0 GLINT's, 1 the bass's, 2 MIDI's) */
{
    const uint8_t *q = bs ? bnote : seq;
    uint16_t lit = bs ? C_LAMP : C_ICE;
    uint32_t steps = bs ? st.v[P_BQ_STEPS] + 1u : seq_len(), cur = st.v[bs ? P_BQ_STEP : P_SQ_STEP] % SC_SEQ;
    uint32_t set_n = bs ? steps : st.v[P_SQ_LEN] + 1u;   /* (the width from SEQ LENGTH as set; SEQ LENGTH as it plays) */
    uint32_t n = set_n > steps ? set_n : steps, cols = (n + 3u) / 4u * 4u, w = bs ? bseq_ticks() : ARP_TICKS[st.v[P_ARP_RATE] % 10u];
    uint32_t i, total = cols * w, at = 0, loop = steps * w;
    int32_t top = 44, bot = 76, bed = 86, lo = 127, hi = 0, y = -1, play = 0, x0, x1, x, j;
    int32_t end = ML + (int32_t)(n * (uint32_t)(MR - ML) / cols);   /* (where its steps end) */
    int32_t pos = bs ? bq.pos : sq.pos, rec = st.v[bs ? P_BQ_REC : P_SQ_REC];
    int on = st.v[bs ? P_BQ_ON : P_SQ_TYPE] == SQT_SEQ, run = on && (bs ? bq.run : sq.run);
    int sounding = bs ? bass_note >= 0 : sq.sounding >= 0, held = bs == 1 && on && bq.tn >= 0 && bseq_playing();
    float into = bs ? bq.t : seq_grid(grid.tick) - (float)sq.n * (float)w;   /* (clocks into the step playing) */
#if FRS_MIDI_OUT
    if (bs == 2) {                       /* MIDI's (card #169: app/mseq.c), its violet */
        q = mseq;
        lit = C_MIDI_TRACK;
        steps = set_n = n = md_len();
        cols = (n + 3u) / 4u * 4u;
        w = ARP_TICKS[md[MD_RATE] % 10u];
        total = cols * w;
        loop = steps * w;
        end = ML + (int32_t)(n * (uint32_t)(MR - ML) / cols);
        cur = md[MD_STEP] % SC_SEQ;
        pos = msq.pos;
        rec = md[MD_REC];
        on = md[MD_TYPE] == SQT_SEQ;
        run = on && msq.run && !msq.wait;
        sounding = msq.sounding >= 0;
        into = msq.t;
    }
#endif
    for (i = 0; i < n; i++) {
        int32_t b = q[i] & 127;
        if (b != (int32_t)SQ_REST && b != (int32_t)SQ_TIE) {
            lo = b < lo ? b : lo;
            hi = b > hi ? b : hi;
        }
    }
    if (held) {                          /* (the note held among them) */
        lo = bq.tn < lo ? bq.tn : lo;
        hi = bq.tn > hi ? bq.tn : hi;
    }
    if (hi < lo) {
        lo = bs == 1 ? 36 : 60;
        hi = lo + 12;
    }
    if (hi - lo < 12) {                  /* at least an octave tall */
        int32_t m = (hi + lo) / 2;
        lo = m - 6;
        hi = m + 6;
    }
    if (on && rec) {                     /* recording: a column a step, the one recorded into lit */
        int32_t r = rec == 1 ? (int32_t)(cur % set_n) : run ? pos : -1;
        for (i = 0; i < n; i++) {
            x0 = ML + (int32_t)(at * (uint32_t)(MR - ML) / total);
            at += w;
            x1 = ML + (int32_t)(at * (uint32_t)(MR - ML) / total);
            if (r == (int32_t)i)
                rec_band(x0, x1, top - 6, bed - 1, lit);
            step_line(x0, top - 6, bed - 1);
        }
        step_line(end, top - 6, bed - 1);
        pitch_lines(ML, end, top, bot, lo, hi);
        at = 0;
    }
    hline(ML, end, bed, C_STEEL);        /* the bed */
    if ((q[0] & 127u) == SQ_TIE) {       /* TIEs first: the note its last steps leave sounding, round its end */
        for (i = steps; i > 1u && (q[i - 1u] & 127u) == SQ_TIE; i--)
            ;
        if (i > 1u && (q[i - 1u] & 127u) != SQ_REST) {
            uint32_t e;
            for (e = 1; e < steps && (q[e] & 127u) == SQ_TIE; e++)
                ;
            y = bot - ((int32_t)(q[i - 1u] & 127u) - lo) * (bot - top) / (hi - lo);
            play = run && sounding && pos >= 0 && (uint32_t)pos < e;
        }
    }
    for (i = 0; i < n; i++) {
        int32_t b = q[i] & 127, in = on && i < steps;
        uint16_t col;
        x0 = ML + (int32_t)(at * (uint32_t)(MR - ML) / total);
        at += w;
        x1 = ML + (int32_t)(at * (uint32_t)(MR - ML) / total);
        if (i == steps && n > steps)     /* the end of what plays, dotted */
            for (j = top - 4; j <= bed; j += 2)
                bl(x0, j, C_SLATE, 24);
        bl(x0, bed - 1, C_SLATE, 32);   /* each step's start, a tick across the bed */
        bl(x0, bed + 1, C_SLATE, 32);
        if (b == (int32_t)SQ_REST) {
            y = -1;
            continue;
        }
        if (b != (int32_t)SQ_TIE) {      /* a NOTE: a line from here (a TIE carries it on), bright while it plays */
            uint32_t e;
            y = bot - (b - lo) * (bot - top) / (hi - lo);
            for (e = i + 1u; e < n && (q[e] & 127u) == SQ_TIE; e++)
                ;
            play = run && sounding && pos >= 0 && (uint32_t)pos >= i && (uint32_t)pos < e;
        }
        if (y < 0)                       /* (a TIE after nothing: nothing) */
            continue;
        if (i == steps)                  /* (past what plays: none of it playing) */
            play = 0;
        col = in ? lit : C_SLATE;
        for (x = x0 + (b != (int32_t)SQ_TIE); x < x1; x++) {   /* (a pixel apart from the one before) */
            int32_t a = play ? 32 : in ? 22 : 12, yy;
            bl(x, y, col, a);
            bl(x, y + 1, col, a * 2 / 5);
            for (yy = y + 2; yy < bed; yy++) {   /* the water under it, fading down to the bed */
                int32_t d = (bed - yy) * 16 / (bed - y);
                if ((x + yy) & 1)
                    bl(x, yy, play ? mix565(C_HAZE, lit, 8) : C_HAZE, (play ? 18 : 12) * d * d / 256);
            }
        }
        if (b != (int32_t)SQ_TIE) {      /* where it starts; ACCENT, taller and twice as wide */
            int32_t ac = (q[i] & SQ_ACC) != 0;
            for (j = y - 2 - 2 * ac; j <= y + 3 + 2 * ac; j++) {
                bl(x0 + 1, j, play ? C_WHITE : col, j == y ? 32 : play ? 20 : in ? 14 : 8);
                if (ac)
                    bl(x0 + 2, j, play ? C_WHITE : col, j == y ? 32 : play ? 20 : in ? 14 : 8);
            }
        }
    }
    if (held) {                          /* the take's note down, bright: from where it went down to the playhead
                                          * (round the loop's end; held a whole turn, all of it) */
        float a = bq.tp > 0.0f ? bq.tp : 0.0f, z = bq.tp + bq.te, w = (float)loop, s[4] = {a, z, 0.0f, 0.0f};
        uint32_t k;
        if (z - a >= w) {
            s[0] = 0.0f;
            s[1] = w;
        } else if (z > w) {
            s[1] = w;
            s[3] = z - w;
        }
        y = bot - (bq.tn - lo) * (bot - top) / (hi - lo);
        for (k = 0; k < 4u; k += 2u)
            for (x = ML + (int32_t)(s[k] * (float)(MR - ML) / (float)total);
                 x < ML + (int32_t)(s[k + 1u] * (float)(MR - ML) / (float)total); x++) {
                int32_t yy;
                bl(x, y, C_LAMP, 32);
                bl(x, y + 1, C_LAMP, 13);
                for (yy = y + 2; yy < bed; yy++) {
                    int32_t d = (bed - yy) * 16 / (bed - y);
                    if ((x + yy) & 1)
                        bl(x, yy, mix565(C_HAZE, C_LAMP, 8), 18 * d * d / 256);
                }
            }
        if (bq.tp >= 0.0f && z - a < w)  /* where it went down */
            for (j = y - 2; j <= y + 3; j++)
                bl(ML + (int32_t)(a * (float)(MR - ML) / (float)total) + 1, j, C_WHITE, j == y ? 32 : 20);
    }
    at = 0;
    for (i = 0; i < n; i++) {            /* the playhead; the step on K1 */
        x0 = ML + (int32_t)(at * (uint32_t)(MR - ML) / total);
        x1 = ML + (int32_t)((at + w) * (uint32_t)(MR - ML) / total);
        if (run && pos == (int32_t)i) {
            float f = into / (float)w;
            x = x0 + (int32_t)((f < 0.0f ? 0.0f : f > 1.0f ? 1.0f : f) * (float)(x1 - x0));
            cv_rect(x, top - 6 - oy, 1, bed - top + 6, mix565(C_BG, lit, 9));
        }
        if (i == cur && rec != 2 && fm.page == (bs == 2 ? SEQ2_MIDI : bs ? PG_BSEQ2 : PG_SEQ2))
            cv_rect(x0 + 1, bed + 4 - oy, x1 - x0 > 2 ? x1 - x0 - 1 : 2, 2, C_LAMP);
        at += w;
    }
}

/* BASS ADSR's and GLINT ADSR's strip: the envelope as one draws it, up to the top over ATTACK, down to SUSTAIN's level
 * over DECAY, held there while the key is (SUSTAIN), down to nothing over RELEASE once let go. Each part as wide as its
 * knob is turned (SUSTAIN's what is left), its time across it, curved as a charge and a discharge are (ATTACK SHAPE's
 * LINE, card #122: ATTACK's straight); the part being turned lit. Each note sounding (the bass's one, GLINT's up to
 * four) a glint riding it: how far along from the engine's times, let go from where it was then. DRONE SHAPE's, while
 * its ATTACK SHAPE shows: up over ATTACK, held, down over RELEASE */
#define ADSR_TOP 42
#define ADSR_BED 82
#define ADSR_HOLD 1.5f                   /* seconds held: a note's glint across SUSTAIN's plateau, then waiting there */
typedef struct {
    float ta, td, tr, sus;               /* the times (s, the engine's: glint.c, bass.c); SUSTAIN's level */
    int32_t x[5];                        /* where each part begins, and the end */
    int line;                            /* ATTACK SHAPE's LINE: ATTACK straight up */
} adsr_t;

static float adsr_fall(float u) { return (fm_expf(-3.0f * u) - 0.049787068f) * (1.0f / 0.950212932f); }   /* 1 .. 0 */

static float adsr_level(const adsr_t *A, int part, float u)   /* the level u (0..1) across a part */
{
    u = br_clamp01(u);
    return part == 0 ? (A->line ? u : 1.0f - adsr_fall(u) * adsr_fall(u))   /* (up quickly, easing into the top; LINE:
                                                                            * straight) */
         : part == 1 ? A->sus + (1.0f - A->sus) * adsr_fall(u)
         : part == 2 ? A->sus : A->sus * adsr_fall(u);
}

static int32_t adsr_y(float g) { return ADSR_BED - (int32_t)(br_clamp01(g) * (float)(ADSR_BED - ADSR_TOP) + 0.5f); }

static int32_t adsr_at(const adsr_t *A, int part, float u)   /* x, u (0..1) across a part */
{
    return A->x[part] + (int32_t)(br_clamp01(u) * (float)(A->x[part + 1] - A->x[part]) + 0.5f);
}

/* a held note's place: ta seconds into its ATTACK, then td into DECAY (and on, SUSTAIN's) -> its part and how far */
static int adsr_held(const adsr_t *A, int attacking, float t, float *u)
{
    if (attacking) {
        *u = t / A->ta;
        return 0;
    }
    if (t < A->td) {
        *u = t / A->td;
        return 1;
    }
    *u = (t - A->td) / ADSR_HOLD;
    return 2;
}

static void adsr_dot(int32_t x, float g, uint16_t col)   /* a note on it: a glow, its arms, a white core */
{
    int32_t y = adsr_y(g), dx, dy, j;
    for (dy = -3; dy <= 3; dy++)
        for (dx = -3; dx <= 3; dx++) {
            int32_t r2 = dx * dx + dy * dy;
            if (r2 <= 10)
                bl(x + dx, y + dy, col, 16 * (11 - r2) / 11);
        }
    for (j = 2; j <= 6; j++) {
        int32_t a = 24 * (7 - j) / 6;
        bl(x + j, y, col, a);
        bl(x - j, y, col, a);
        bl(x, y + j, col, a * 3 / 4);
        bl(x, y - j, col, a * 3 / 4);
    }
    for (dy = -1; dy <= 1; dy++)
        for (dx = -1; dx <= 1; dx++)
            bl(x + dx, y + dy, C_WHITE, dx || dy ? 20 : 32);
}

/* a note's glint: held (attacking: in its ATTACK; t seconds in it, else from DECAY's start), or let go toff seconds
 * ago from there */
static void adsr_note(const adsr_t *A, int held, int attacking, float t, float toff, uint16_t col)
{
    float u, g;
    int part = adsr_held(A, attacking, t, &u);
    g = adsr_level(A, part, u);
    if (held)
        adsr_dot(adsr_at(A, part, u), g, col);
    else
        adsr_dot(adsr_at(A, 3, toff / A->tr), g * adsr_fall(toff / A->tr), col);
}

static void adsr_scope(int glint)        /* (glint: 1 GLINT's, 0 BASS's or the LEAD's, 2 the drones') */
{
    static const char *const PART[4] = {"A", "D", "S", "R"};
#if FRS_LEAD
    const prm_t *P = PAGES[fm.page].p;
    uint16_t col = glint == 2 ? C_FOG : glint ? C_ICE : fm.page == PG_LADSR || fm.page == PG_LFENV ? C_LEAD_TRACK
                 : C_LAMP;           /* (LEAD's: BASS's times) */
#else
    const uint8_t *P = PAGES[fm.page].p;
    uint16_t col = glint == 2 ? C_FOG : glint ? C_ICE : C_LAMP;
#endif
    adsr_t A;
    int dr = glint == 2;                 /* (DRONE SHAPE: ATTACK, RELEASE, no DECAY: held at the top) */
    int32_t x, py = 0, k, lit = -1, w[4];
    float a = vh(P[0]) / 127.0f, d = dr ? 0.0f : vh(P[1]) / 127.0f, r = vh(P[dr ? 1 : 3]) / 127.0f;
    A.sus = dr ? 1.0f : vh(P[2]) / 127.0f;
    A.line = shape_line();
    A.ta = dr ? 0.005f * fm_powf(6000.0f, a) : glint ? 0.002f * fm_powf(750.0f, a) : 0.005f * fm_powf(1000.0f, a);
    A.td = glint ? 0.08f * fm_powf(75.0f, d) : 0.01f * fm_powf(1000.0f, d);
    A.tr = dr ? 0.05f * fm_powf(1200.0f, r) : glint ? 0.02f * fm_powf(300.0f, r) : 0.03f * fm_powf(500.0f, r);
    w[0] = 10 + (int32_t)(44.0f * a + 0.5f);
    w[1] = dr ? 0 : 10 + (int32_t)(44.0f * d + 0.5f);
    w[3] = 10 + (int32_t)(44.0f * r + 0.5f);
    w[2] = MR - ML - w[0] - w[1] - w[3];
    A.x[0] = ML;
    for (k = 0; k < 4; k++)
        A.x[k + 1] = A.x[k] + w[k];
    if (touched_now())
        for (k = 0; k < 4; k++)
            if (P[k] == fm.touched)
                lit = !dr ? k : k == 0 ? 0 : k == 1 ? 3 : -1;   /* (the drones': ATTACK, RELEASE) */
    if (shape_hot())                     /* (ATTACK SHAPE's: ATTACK's part) */
        lit = 0;
    hline(ML, MR, ADSR_BED, C_STEEL);    /* the bed: silence */
    for (k = 0; k < 4; k++) {            /* each part: its curve, the water under it, its letter */
        for (x = A.x[k]; x < A.x[k + 1] + (k == 3); x++) {
            int32_t y = adsr_y(adsr_level(&A, k, (float)(x - A.x[k]) / (float)(A.x[k + 1] - A.x[k]))), yy;
            int32_t y0 = x > ML && py < y ? py : y, y1 = x > ML && py > y ? py : y;
            for (yy = y0; yy <= y1; yy++) {   /* (joined to the last), a soft row under it */
                bl(x, yy, col, k == lit ? 32 : 22);
                bl(x, yy + 1, col, k == lit ? 12 : 7);
            }
            for (yy = y + 2; yy < ADSR_BED; yy++) {
                int32_t f = (ADSR_BED - yy) * 16 / (ADSR_BED - y);
                if ((x + yy) & 1)
                    bl(x, yy, k == lit ? mix565(C_HAZE, col, 10) : C_HAZE, (k == lit ? 20 : 12) * f * f / 256);
            }
            py = y;
        }
        if (!dr || k == 0 || k == 3)     /* (the drones': A and R alone) */
            text_c((A.x[k] + A.x[k + 1]) / 2, ADSR_BED + 4, &FONT_T, PART[k], k == lit ? col : C_SLATE, 0);
    }
    for (k = 1; k < 4; k++) {            /* where one part gives way to the next, a tick across the bed */
        bl(A.x[k], ADSR_BED - 1, C_SLATE, 32);
        bl(A.x[k], ADSR_BED + 1, C_SLATE, 32);
    }
    for (x = adsr_y(A.sus) + 3; x < ADSR_BED - 1; x += 2)   /* let go here: dotted down from the plateau's end */
        bl(A.x[3], x, C_SLATE, 20);
    if (glint == 1) {                    /* each glint sounding (its onset and its DECAY from the strike: DECAY's
                                          * part once ATTACK's time is gone by) */
        glint_view_t v[GLINT_NV];
        uint32_t i;
        frasil_glint_view(v);
        for (i = 0; i < GLINT_NV; i++) {
            float t = v[i].gate ? v[i].t : v[i].t - v[i].toff;
            if (v[i].note >= 0 && v[i].env >= 0.01f)
                adsr_note(&A, v[i].gate, t < A.ta, t < A.ta ? t : t - A.ta, v[i].toff, col);
        }
    } else if (dr) {                     /* (the drones': the curve alone) */
#if FRS_LEAD
    } else if (fm.page == PG_LADSR || fm.page == PG_LFENV) {   /* (LEAD: its curve alone, for now; its filter's the
                                                               * same) */
#endif
    } else {                             /* the bass's note */
        bass_view_t b;
        frasil_bass_view(&b);
        if (b.note >= 0 && b.level * b.level >= 0.005f)
            adsr_note(&A, b.stage < 2u, b.stage < 2u ? b.stage == 0u : b.let_stage == 0u, b.stage < 2u ? b.t : b.let_t,
                      b.t, col);
    }
}

/* MASTER EQ and MASTER FILTER: their response across the strip, 20 HZ to 20 KHZ on a log scale (100, 1K, 10K marked
 * under it). The EQ's (MASTER EQ, II): its three bands' biquads as the engine has them, 0 DB the middle line, +-12 DB
 * the strip; what it raises warms (lamp), what it cuts is ice; each band's knob a small badge on the curve where the
 * band sits, larger while it turns. The FILTER's: 12 DB an octave and its resonance's peak, what passes as water under
 * it, CUTOFF's badge at the corner; OFF, a flat slate line. The curve is worked out again only when a setting changes */
#define RS_TOP 42
#define RS_BED 84
#define RS_N (MR - ML + 1)

static float rs_hz(int32_t x) { return 20.0f * fm_powf(1000.0f, (float)(x - ML) / (float)(RS_N - 1)); }
static int32_t rs_x(float hz) { return ML + (int32_t)(fm_log2f(hz * 0.05f) * (1.0f / 9.9657843f) * (float)(RS_N - 1) + 0.5f); }

static float biquad_db(const float *c, float hz)
{
    float w = 6.2831853f * hz * (1.0f / 44100.0f), c1 = fm_cosf(w), s1 = fm_sinf(w), c2 = fm_cosf(2.0f * w),
          s2 = fm_sinf(2.0f * w);
    float nr = c[0] + c[1] * c1 + c[2] * c2, ni = c[1] * s1 + c[2] * s2;
    float dr = 1.0f + c[3] * c1 + c[4] * c2, di = c[3] * s1 + c[4] * s2;
    return 3.0103f * fm_log2f((nr * nr + ni * ni + 1e-12f) / (dr * dr + di * di + 1e-12f));
}

/* a band's or the corner's badge on the curve: its knob, larger while it turns */
static void rs_badge(float hz, int32_t y, int p, char ch)
{
    int lit = touched_now() && fm.touched == p;
    badge_r(rs_x(hz), y < RS_TOP + 2 ? RS_TOP + 2 : y > RS_BED - 2 ? RS_BED - 2 : y, ch, 1, lit ? 6.5f : 5.0f);
}

static void rs_grid(int32_t zero)
{
    static const float MARK[3] = {100.0f, 1000.0f, 10000.0f};
    static const char *const MARK_NM[3] = {"100", "1K", "10K"};
    int32_t k, y;
    hline(ML, MR, zero, C_STEEL);
    for (k = 0; k < 3; k++) {
        int32_t x = rs_x(MARK[k]);
        for (y = RS_TOP; y <= RS_BED; y += 3)
            bl(x, y, C_STEEL, 24);
        text_c(x, RS_BED + 3, &FONT_T, MARK_NM[k], C_SLATE, 0);
    }
}

static void eq_scope(void)
{
    static int16_t ys[RS_N];
    static uint8_t seen[8] = {255};
    const int32_t zero = (RS_TOP + RS_BED) / 2;
    float lo[5], mid[5], hi[5], flo, fmid, fhi;
    uint8_t now[8];
    int32_t x, py = 0, k, eq2 = fm.page == PG_EQ2, off = !st.v[P_EQ_PRESET];
    for (k = 0; k < 7; k++)
        now[k] = (uint8_t)vh_n(P_EQ_LOW + (uint32_t)k);
    now[7] = 0;
    flo = EQ_LOWF(vh(P_EQ_LOWF) / 127.0f);
    fmid = EQ_MIDF(vh(P_EQ_MIDF) / 127.0f);
    fhi = EQ_HIGHF(vh(P_EQ_HIGHF) / 127.0f);
    frasil_eq_coefs(0, flo, 0.5f * (float)((int32_t)vh_n(P_EQ_LOW) - 24), 0.707f, lo);
    frasil_eq_coefs(1, fmid, 0.5f * (float)((int32_t)vh_n(P_EQ_MID) - 24), EQ_Q(vh(P_EQ_Q) / 127.0f), mid);
    frasil_eq_coefs(2, fhi, 0.5f * (float)((int32_t)vh_n(P_EQ_HIGH) - 24), 0.707f, hi);
    if (memcmp(now, seen, sizeof now)) {
        memcpy(seen, now, sizeof seen);
        for (x = 0; x < RS_N; x++) {
            float f = rs_hz(ML + x), db = biquad_db(lo, f) + biquad_db(mid, f) + biquad_db(hi, f);
            db = db > 13.0f ? 13.0f : db < -13.0f ? -13.0f : db;
            ys[x] = (int16_t)(zero - (int32_t)(db * (float)(zero - RS_TOP) * (1.0f / 12.0f) + (db < 0.0f ? -0.5f : 0.5f)));
        }
    }
    rs_grid(zero);
    for (x = ML; x <= MR; x++) {         /* what it raises warms, what it cuts is ice; the curve over them */
        int32_t y = ys[x - ML], yy, y0 = x > ML && py < y ? py : y, y1 = x > ML && py > y ? py : y;
        for (yy = y < zero ? y + 1 : zero + 1; !off && yy < (y < zero ? zero : y); yy++)
            if ((x + yy) & 1)
                bl(x, yy, y < zero ? C_LAMP : C_ICE, y < zero ? 16 : 12);
        for (yy = y0; yy <= y1; yy++) {  /* (OFF: what it would do, slate) */
            bl(x, yy, off ? C_SLATE : C_FOG, 28);
            bl(x, yy + 1, off ? C_SLATE : C_FOG, 6);
        }
        py = y;
    }
    ui_off = (uint8_t)off;
    rs_badge(flo, ys[rs_x(flo) - ML], eq2 ? P_EQ_LOWF : P_EQ_LOW, eq2 ? '1' : '2');
    rs_badge(fmid, ys[rs_x(fmid) - ML], eq2 ? P_EQ_MIDF : P_EQ_MID, eq2 ? '2' : '3');
    rs_badge(fhi, ys[rs_x(fhi) - ML], eq2 ? P_EQ_HIGHF : P_EQ_HIGH, '4');
    ui_off = 0;
}

static void filter_scope(void)
{
    const int32_t zero = 56;             /* 0 DB; 0.7 px a decibel: +20 at the top, -40 at the bed */
    uint32_t type = st.v[P_FL_TYPE] % 3u;
    float fc = FL_CUT(vh(P_FL_CUT) / 127.0f), q = FL_Q(vh(P_FL_RESO) / 127.0f);
    int32_t x, py = 0, ycut = zero;
    rs_grid(zero);
    for (x = ML; x <= MR; x++) {
        float f = rs_hz(x), r = f / fc, db, re, im;
        int32_t y, yy, y0, y1;
        if (!type) {
            bl(x, zero, C_SLATE, 32);
            continue;
        }
        re = 1.0f - r * r;               /* 1 / (1 - r^2 + j r / q): a low pass; times r^2, a high pass */
        im = r / q;
        db = -3.0103f * fm_log2f(re * re + im * im + 1e-12f) + (type == 2u ? 12.0412f * fm_log2f(r) : 0.0f);
        db = db > 20.0f ? 20.0f : db < -40.0f ? -40.0f : db;
        y = zero - (int32_t)(db * 0.7f + (db < 0.0f ? -0.5f : 0.5f));
        if (x == rs_x(fc))
            ycut = y;
        for (yy = y + 2; yy < RS_BED; yy++) {   /* what passes: water under the curve */
            int32_t a = (RS_BED - yy) * 16 / (RS_BED - y);
            if ((x + yy) & 1)
                bl(x, yy, C_ICE, 10 * a * a / 256);
        }
        y0 = x > ML && py < y ? py : y;
        y1 = x > ML && py > y ? py : y;
        for (yy = y0; yy <= y1; yy++) {
            bl(x, yy, C_ICE, 28);
            bl(x, yy + 1, C_ICE, 7);
        }
        py = y;
    }
    if (type)
        rs_badge(fc, ycut, P_FL_CUT, '2');
}

/* LOFI TAPE: a cassette's two reels across the strip, the tape off the left one round a roller, over the head, round
 * the other roller onto the right one, which fills as the left empties (then a quick rewind). The reels turn
 * anticlockwise as the tape runs, the engine's speed made five times as plain (a
 * wow sways them, a drag nearly stops them); the free spans hang looser and sway as WOBBLE grows, looser still in a
 * drag; SATURATION warms the tape and lights the head, a glow that grows and whitens. Still and slate while TAPE is
 * off */
#define TP_CY 60                          /* the reels' centres */
#define TP_RL 60.0f                       /* their x */
#define TP_RR 180.0f
#define TP_GL 100.0f                      /* the rollers' x, y, radius */
#define TP_GR 140.0f
#define TP_GY 83.0f
static float tp_rot[2], tp_vs = 1.0f;     /* each reel's angle, turns; the speed shown */
static float tp_u = 0.35f;                /* how much of the tape is on the right reel, 0 .. 1 */
static int tp_rew;                        /* rewinding */

/* a thin segment, anti-aliased (screen coordinates), half its width hw, alpha a of 32 */
static void seg_aa(float x0, float y0, float x1, float y1, uint16_t col, int32_t a, float hw)
{
    float dx = x1 - x0, dy = y1 - y0, l2 = dx * dx + dy * dy + 1e-6f;
    int32_t xa = (int32_t)fm_floorf((x0 < x1 ? x0 : x1) - hw - 1.0f), xb = (int32_t)((x0 > x1 ? x0 : x1) + hw + 1.0f);
    int32_t ya = (int32_t)fm_floorf((y0 < y1 ? y0 : y1) - hw - 1.0f), yb = (int32_t)((y0 > y1 ? y0 : y1) + hw + 1.0f);
    int32_t x, y;
    for (y = ya; y <= yb; y++)
        for (x = xa; x <= xb; x++) {
            float t = br_clamp01(((float)x - x0) * dx / l2 + ((float)y - y0) * dy / l2);
            float ex = x0 + t * dx - (float)x, ey = y0 + t * dy - (float)y, c = hw + 0.5f - fm_sqrtf(ex * ex + ey * ey);
            if (c > 0.0f)
                bl(x, y, col, (int32_t)((float)a * (c > 1.0f ? 1.0f : c)));
        }
}

/* a reel at (cx, cy): its flange, the tape wound on it out to pack (a turn of it every other pixel, a splice's mark
 * that turns with it), its hub's ring and three spokes at rot */
static void reel(float cx, float cy, float pack, float rot, uint16_t tape, uint16_t hub, uint16_t rim)
{
    int32_t x, y, k, ix = (int32_t)cx, iy = (int32_t)cy;
    float ms = fm_sin_turns(rot + 0.125f), mc = fm_sin_turns(rot + 0.375f);
    for (y = 0; y <= 27; y++)                /* (a quarter, mirrored: the rings are round about the centre) */
        for (x = 0; x <= 27; x++) {
            float d2 = (float)(x * x + y * y), d, c;
            int32_t ar = 0, at = 0, ah = 0, q;
            if (d2 > 26.5f * 26.5f || (d2 < 24.5f * 24.5f && d2 > (pack + 0.5f) * (pack + 0.5f)) || d2 < 25.0f)
                continue;
            d = fm_sqrtf(d2);
            c = 1.0f - fm_fabsf(d - 25.5f);
            if (c > 0.0f)
                ar = (int32_t)(22.0f * c);
            if (d > 9.0f && d < pack + 0.5f) {
                c = d > pack - 0.5f ? pack + 0.5f - d : d < 10.0f ? d - 9.0f : 1.0f;
                at = (int32_t)((((int32_t)d & 1) ? 30.0f : 22.0f) * c);
            }
            c = 1.0f - fm_fabsf(d - 7.0f);
            if (c > 0.0f)
                ah = (int32_t)(32.0f * c);
            for (q = 0; q < 4; q++) {
                int32_t px = ix + (q & 1 ? -x : x), py = iy + (q & 2 ? -y : y);
                if ((q & 1 && !x) || (q & 2 && !y))
                    continue;
                if (ar)
                    bl(px, py, rim, ar);
                if (at)
                    bl(px, py, tape, at);
                if (ah)
                    bl(px, py, hub, ah);
            }
        }
    seg_aa(cx + (pack - 5.0f) * mc, cy + (pack - 5.0f) * ms, cx + (pack - 0.5f) * mc, cy + (pack - 0.5f) * ms, hub, 20,
           0.6f);
    for (k = 0; k < 3; k++) {
        float a = rot + (float)k * (1.0f / 3.0f), sn = fm_sin_turns(a), cs = fm_sin_turns(a + 0.25f);
        seg_aa(cx + 1.5f * cs, cy + 1.5f * sn, cx + 6.5f * cs, cy + 6.5f * sn, hub, 32, 1.1f);
    }
}

/* where the tape leaves circle a (centre, radius) for circle b, under both: p = a's point, then b's */
static void tape_tangent(float ax, float ay, float ar, float bx, float by, float br, float *p)
{
    float dx = bx - ax, dy = by - ay, l = fm_sqrtf(dx * dx + dy * dy) + 1e-6f, ux = dx / l, uy = dy / l;
    float c = (ar - br) / l, sn = fm_sqrtf(1.0f - c * c), nx = c * ux - sn * uy, ny = c * uy + sn * ux;
    if (ny < 0.0f) {
        nx = c * ux + sn * uy;
        ny = c * uy - sn * ux;
    }
    p[0] = ax + ar * nx;
    p[1] = ay + ar * ny;
    p[2] = bx + br * nx;
    p[3] = by + br * ny;
}

/* a free span of tape from (x0, y0) to (x1, y1), hanging sag pixels at its middle (a quadratic's) */
static void tape_span(const float *p, float sag, uint16_t col, int32_t a)
{
    float dx = p[2] - p[0], dy = p[3] - p[1], l = fm_sqrtf(dx * dx + dy * dy) + 1e-6f, nx = -dy / l, ny = dx / l;
    float cx, cy, px = p[0], py = p[1];
    int32_t k;
    if (ny < 0.0f) {                     /* (it hangs down) */
        nx = -nx;
        ny = -ny;
    }
    cx = 0.5f * (p[0] + p[2]) + 2.0f * sag * nx;
    cy = 0.5f * (p[1] + p[3]) + 2.0f * sag * ny;
    for (k = 1; k <= 10; k++) {
        float t = (float)k * 0.1f, u = 1.0f - t;
        float x = u * u * p[0] + 2.0f * u * t * cx + t * t * p[2], y = u * u * p[1] + 2.0f * u * t * cy + t * t * p[3];
        seg_aa(px, py, x, y, col, a, 0.6f);
        px = x;
        py = y;
    }
}

/* VINYL (LOFI TAPE's MEDIA, card #99): a record from above, lit from the top (a sheen down its grooves), its label
 * turning at 33 1/3 a minute (TAPE SPEED's times, its wow made five times as plain, as the reels'), warmer and glowing
 * as SATURATION grows, set off the spindle as WOBBLE grows (the label swaying round it); the arm from the right, its
 * needle in the groove; dust going round with the record as NOISE grows, bright where the light is */
#define VN_CX 100                         /* the spindle */
#define VN_CY 60
static float vn_rot;                      /* the record's turn, 0 .. 1 */

static void vinyl_scope(void)
{
    static uint32_t last;
    uint32_t now = plat_ms();
    int still = st.v[P_ANIM] != 0;
    float dt = (float)(now - last) * 0.001f, sat = vh(P_TP_SAT) / 127.0f, wob = vh(P_TP_WOBBLE) / 127.0f;
    float nz = vh(P_TP_NOISE) / 127.0f, cs, sn, lx, ly;
    uint16_t lab = mix565(RGB(120, 48, 40), C_LAMP, (int32_t)(12.0f + 20.0f * sat));
    int32_t x, y, k, n;
    last = now;
    dt = dt > 0.1f ? 0.1f : dt;
    tp_vs += (frasil_tape_speed() - tp_vs) * (dt > 0.15f ? 1.0f : dt * 6.7f);   /* (smoothed as the reels') */
    if (!still)                          /* clockwise, as a turntable's */
        vn_rot += dt * 0.5555556f * fm_exp2f(tape_l2) * (1.0f + 5.0f * (tp_vs - 1.0f));
    vn_rot -= fm_floorf(vn_rot);
    cs = fm_sin_turns(vn_rot + 0.25f);
    sn = fm_sin_turns(vn_rot);
    lx = (float)VN_CX + 2.5f * wob * cs;  /* the label's centre: the record's, off the spindle */
    ly = (float)VN_CY + 2.5f * wob * sn;
    for (y = 0; y <= 31; y++)            /* the record: its rim, its grooves a ring every other pixel, the run-out smooth;
                                          * the sheen down from the top (a quarter, mirrored) */
        for (x = 0; x <= 31; x++) {
            float d2 = (float)(x * x + y * y), d, c;
            int32_t a, q;
            if (d2 > 30.5f * 30.5f || d2 < 11.0f * 11.0f)
                continue;
            d = fm_sqrtf(d2);
            c = (float)y / d;
            c *= c;
            a = d > 29.5f ? 18 : d < 13.0f ? 6 : ((int32_t)d & 1) ? 12 : 7;
            a += (int32_t)(14.0f * c * c * c * c);
            for (q = 0; q < 4; q++) {
                if ((q & 1 && !x) || (q & 2 && !y))
                    continue;
                bl(VN_CX + (q & 1 ? -x : x), VN_CY + (q & 2 ? -y : y), C_MIST, a);
            }
        }
    for (y = -11; y <= 11; y++)          /* the label, a glow round it as SATURATION grows */
        for (x = -11; x <= 11; x++) {
            float ex = (float)(VN_CX + x) - lx, ey = (float)(VN_CY + y) - ly, d = fm_sqrtf(ex * ex + ey * ey);
            if (d < 9.5f)
                bl(VN_CX + x, VN_CY + y, lab, d > 8.5f ? (int32_t)(32.0f * (9.5f - d)) : 32);
            else if (d < 11.0f && sat > 0.0f)
                bl(VN_CX + x, VN_CY + y, C_LAMP, (int32_t)(10.0f * sat * (11.0f - d)));
        }
    seg_aa(lx + 3.5f * cs, ly + 3.5f * sn, lx + 8.0f * cs, ly + 8.0f * sn, C_FOG, 22, 0.6f);   /* its print, turning */
    bl(VN_CX, VN_CY, C_FOG, 32);         /* the spindle */
    n = (int32_t)(18.0f * nz + 0.5f);
    for (k = 0; k < n; k++) {            /* the dust, going round with it (on its grooves: 13 .. 27.6 from its centre,
                                          * inside the rim with the label off the spindle too) */
        uint32_t h = (uint32_t)k * 2654435761u;
        float r = 13.0f + 0.47f * (float)(h >> 27), at = vn_rot + (float)(h >> 8 & 1023u) * (1.0f / 1024.0f);
        float px = lx + r * fm_sin_turns(at + 0.25f), py = ly + r * fm_sin_turns(at), c = (py - (float)VN_CY) / r;
        bl((int32_t)(px + 0.5f), (int32_t)(py + 0.5f), C_FOG, 8 + (int32_t)(22.0f * c * c * nz));
    }
    for (y = -5; y <= 5; y++)            /* the arm: its pivot's ring, the arm, the headshell on the groove */
        for (x = -5; x <= 5; x++) {
            float c = 1.0f - fm_fabsf(fm_sqrtf((float)(x * x + y * y)) - 4.0f);
            if (c > 0.0f)
                bl(170 + x, 32 + y, C_SLATE, (int32_t)(30.0f * c));
        }
    seg_aa(170.0f, 32.0f, 128.0f, 70.0f, C_MIST, 30, 0.7f);
    seg_aa(128.0f, 70.0f, 121.0f, 75.0f, C_FOG, 32, 1.3f);
}

/* AM (LOFI TAPE's MEDIA, card #99): a radio's dial across the strip, 530 to 1700 kHz (a few numbers, in tens, as a
 * dial's), its needle on a station; the lamp behind the glass glowing with the signal as it comes in (dimmer in its
 * fades, WOBBLE's and DROPOUT's: frasil_tape_signal), warmer and whiter as SATURATION grows; static along the glass as
 * NOISE grows, brighter in a fade */
static void am_scope(void)
{
    static const uint16_t KHZ[4] = {550, 700, 1000, 1400};
    static const char *const MARK[4] = {"55", "70", "100", "140"};
    const float k = 184.0f / fm_log2f(1700.0f / 530.0f), sig = frasil_tape_signal();
    float sat = vh(P_TP_SAT) / 127.0f, nz = vh(P_TP_NOISE) / 127.0f, g = (0.25f + 0.75f * sig) * (0.6f + 0.4f * sat);
    int32_t x, y, xn = 28 + (int32_t)(k * fm_log2f(880.0f / 530.0f) + 0.5f), n, i;
    uint16_t lamp = mix565(C_LAMP, C_FOG, (int32_t)(14.0f * sat * sat));
    uint32_t h = st.v[P_ANIM] ? 7u : plat_ms() / 40u;
    for (y = 0; y <= 24; y++)            /* the lamp's glow round the needle (a quarter, mirrored) */
        for (x = 0; x <= 22; x++) {
            float ex = (float)x * (1.0f / 22.0f), ey = (float)y * (1.0f / 24.0f), d = ex * ex + ey * ey;
            int32_t a = d < 1.0f ? (int32_t)(22.0f * g * (1.0f - d) * (1.0f - d)) : 0, q;
            for (q = 0; q < 4 && a; q++)
                if (!(q & 1 && !x) && !(q & 2 && !y))
                    bl(xn + (q & 1 ? -x : x), 62 + (q & 2 ? -y : y), lamp, a);
        }
    hline(28, 212, 74, C_SLATE);         /* the scale: a tick each 50 kHz to 1000, then each 100; its numbers */
    for (i = 550; i <= 1700; i += i < 1000 ? 50 : 100) {
        int32_t xt = 28 + (int32_t)(k * fm_log2f((float)i / 530.0f) + 0.5f);
        cv_rect(xt, 71 - oy, 1, 3, C_SLATE);
    }
    for (i = 0; i < 4; i++) {
        int32_t xt = 28 + (int32_t)(k * fm_log2f((float)KHZ[i] / 530.0f) + 0.5f);
        cv_rect(xt, 68 - oy, 1, 6, C_MIST);
        text_c(xt, 78, &FONT_XS, MARK[i], C_MIST, 1);
    }
    n = (int32_t)(40.0f * nz * nz + (nz > 0.0f ? 2.0f : 0.0f));
    for (i = 0; i < n; i++) {            /* the static, along the glass (another each frame) */
        h = h * 1664525u + 1013904223u;
        bl(28 + (int32_t)(h >> 8 & 0xFFu) * 184 / 256, 64 + (int32_t)(h >> 20 & 7u), C_FOG,
           (int32_t)((float)(6u + (h >> 26 & 15u)) * (1.5f - 0.5f * sig)));   /* (louder in a fade) */
    }
    seg_aa((float)xn, 44.0f, (float)xn, 82.0f, mix565(C_LAMP, C_FOG, (int32_t)(20.0f * sig)), 32, 0.8f);   /* the needle */
}

/* PHONE (LOFI TAPE's MEDIA, card #218): an old telephone's handset across the strip, side on and lit from the top as
 * the record (its earpiece left, its mouthpiece right), its coiled cord off the mouthpiece, sagging away to the right
 * (swaying slowly as WOBBLE grows); the earpiece's face lit with the line and its sound going out under it in rings
 * (frasil_tape_signal: dimmer as the line drifts, WOBBLE's, gone while DROPOUT cuts it), warmer and glowing as
 * SATURATION grows, the far rings as loud as the near ones (its compression); TONE, the band's top: the rings closer;
 * static along the cord as NOISE grows (another each frame), brighter in a cut */
#define PH_X 92                           /* the handset's middle */
#define PH_Y 45.0f                        /* its handle's top (the middle of its thickness) */
#define PH_R 150.0f                       /* the handle's arch, a circle's radius */
#define PH_E 46                           /* the earpiece's and the mouthpiece's centres, from its middle */
#define PH_T 50                           /* the cups' tops (y, in the handle) */
#define PH_F 67                           /* the earpiece's face (y; the mouthpiece's a pixel higher) */
#define PH_CN 24                          /* the cord's line measured in so many pieces */
#define PH_CR 3.0f                        /* its coil's radius */
#define PH_CK 2.0f                        /* how far its loops lean along it (the coil seen a little from above) */
#define PH_CP 6.0f                        /* a turn of it, along the cord */

/* a line a pixel thick, anti-aliased as Wu's (a pixel's step along its longer axis, shared between the two pixels
 * across it), its last point left to the next one (a polyline's joints drawn once); alpha a of 32 (screen
 * coordinates) */
static void line_aa(float x0, float y0, float x1, float y1, uint16_t c, int32_t a)
{
    float dx = x1 - x0, dy = y1 - y0, ax = fm_fabsf(dx), ay = fm_fabsf(dy);
    int32_t i, m = (int32_t)((ax > ay ? ax : ay) + 0.5f);
    m = m < 1 ? 1 : m;
    for (i = 0; i < m; i++) {
        float t = (float)i / (float)m, x = x0 + t * dx, y = y0 + t * dy, f;
        if (ay > ax) {                   /* (steep: two pixels side by side each row) */
            int32_t iy = (int32_t)fm_floorf(y + 0.5f);
            f = fm_floorf(x);
            bl((int32_t)f, iy, c, (int32_t)((float)a * (1.0f - (x - f)) + 0.5f));
            bl((int32_t)f + 1, iy, c, (int32_t)((float)a * (x - f) + 0.5f));
        } else {
            int32_t ix = (int32_t)fm_floorf(x + 0.5f);
            f = fm_floorf(y);
            bl(ix, (int32_t)f, c, (int32_t)((float)a * (1.0f - (y - f)) + 0.5f));
            bl(ix, (int32_t)f + 1, c, (int32_t)((float)a * (y - f) + 0.5f));
        }
    }
}

/* the cord's line at u (0 .. 1: a cubic's, p its four points), o its point and its direction there (of length 1) */
static void ph_cord(const float *p, float u, float *o)
{
    float v = 1.0f - u, b0 = v * v * v, b1 = 3.0f * v * v * u, b2 = 3.0f * v * u * u, b3 = u * u * u;
    float tx = v * v * (p[2] - p[0]) + 2.0f * v * u * (p[4] - p[2]) + u * u * (p[6] - p[4]);
    float ty = v * v * (p[3] - p[1]) + 2.0f * v * u * (p[5] - p[3]) + u * u * (p[7] - p[5]);
    float l = 1.0f / (fm_sqrtf(tx * tx + ty * ty) + 1e-6f);
    o[0] = b0 * p[0] + b1 * p[2] + b2 * p[4] + b3 * p[6];
    o[1] = b0 * p[1] + b1 * p[3] + b2 * p[5] + b3 * p[7];
    o[2] = tx * l;
    o[3] = ty * l;
}

static void phone_scope(void)
{
    const float sig = frasil_tape_signal(), sat = vh(P_TP_SAT) / 127.0f, wob = vh(P_TP_WOBBLE) / 127.0f;
    const float nz = vh(P_TP_NOISE) / 127.0f, sp = 6.0f - 2.0f * vh(P_TP_TONE) / 127.0f;   /* (the rings' spacing) */
    const int still = st.v[P_ANIM] != 0;
    const float t = still ? 6.0f : (float)plat_ms() * 0.001f, sw = wob * fm_sin_turns(t * 0.11f);
    const float ph = t * 0.9f - fm_floorf(t * 0.9f), ex = (float)(PH_X - PH_E), ey = (float)PH_F + 1.0f;
    const float cord[8] = {(float)(PH_X + PH_E) + 8.0f, (float)PH_F - 4.0f, (float)(PH_X + PH_E) + 16.0f + 4.0f * sw,
                           98.0f, 200.0f + 8.0f * sw, 96.0f - 2.0f * sw, 248.0f, 82.0f};
    uint16_t light = mix565(C_MIST, C_LAMP, (int32_t)(14.0f + 18.0f * sat));
    uint32_t h = still ? 7u : plat_ms() / 40u;
    float o[4], len[PH_CN + 1], cs[16], px, py;
    int32_t x, y, i, n;
    for (x = PH_X - PH_E - 15; x <= PH_X + PH_E + 15; x++) {   /* the handset: the handle's arch, its ends round, a cup
                                          * under each (the earpiece's wider), dark, its edge lit, brighter along the
                                          * top (a column at a time: the arch's height once) */
        float dx = (float)(x - PH_X), ax = fm_fabsf(dx), e = fm_fabsf(ax - (float)PH_E), yc = 0.0f, hv = 0.0f;
        float wt = dx < 0.0f ? 6.0f : 5.5f, wf = dx < 0.0f ? 13.5f : 11.0f, yf = (float)(PH_F - (dx < 0.0f ? 0 : 1));
        const float end = (float)PH_E + 6.0f;
        int32_t ya = PH_T, yb = e < wf + 1.0f ? (int32_t)yf : 0;
        if (ax < end) {
            float s = fm_sqrtf(PH_R * PH_R - dx * dx);
            yc = PH_Y + PH_R - s;
            hv = 4.0f * PH_R / s;        /* (as thick across the arch) */
            ya = (int32_t)(yc - hv) - 1;
            yb = yb ? yb : (int32_t)(yc + hv) + 1;
        }
        for (y = ya; y <= yb; y++) {
            float fy = (float)y, co = 0.0f, ci = 0.0f, top = 0.0f;
            if (ax < end) {              /* (its coverage, and a pixel in: the difference, its edge) */
                float dv = fm_fabsf(fy - yc), r = ax > end - hv ? ax - (end - hv) : 0.0f;
                r = r > 0.0f ? fm_sqrtf(r * r + dv * dv) : dv;   /* (round at its ends) */
                co = br_clamp01(hv + 0.5f - r);
                ci = br_clamp01(hv - 0.5f - r);
                top = fy < yc ? 1.0f : 0.0f;
            }
            if (y >= PH_T) {             /* (the cup, flaring to its face) */
                float u = (fy - (float)PH_T) / (yf - (float)PH_T), w = wt + (wf - wt) * u * u;
                float c = br_clamp01(w + 0.5f - e), c2 = y < yb ? br_clamp01(w - 0.5f - e) : 0.0f;
                co = c > co ? c : co;
                ci = c2 > ci ? c2 : ci;
            }
            bl(x, y, C_MIST, (int32_t)(10.0f * co + (12.0f + 10.0f * top) * (co - ci)));
        }
    }
    for (y = 0; y <= 24; y++)            /* under the earpiece: its sound going out in rings, a glow as it saturates (a
                                          * half, mirrored) */
        for (x = 0; x <= 19; x++) {
            float d = fm_sqrtf((float)(x * x + y * y)), c = (float)y / (d + 1e-6f), wa = br_clamp01((c - 0.5f) * 5.0f);
            float a = 0.0f, g = d < 14.0f ? 10.0f * sat * sig * (1.0f - d / 14.0f) * (1.0f - d / 14.0f) : 0.0f;
            int32_t k;
            for (k = 0; k < 3 && wa > 0.0f; k++) {   /* (each from the face outward, in, then fading: compressed,
                                                      * only at the last) */
                float pos = ((float)k + ph) * (1.0f / 3.0f), rc = 1.0f - 1.1f * fm_fabsf(d - 3.0f - 3.0f * sp * pos);
                if (rc > 0.0f)
                    a += rc * br_clamp01(pos * 7.0f) * br_clamp01((1.0f - pos) / (0.85f - 0.6f * sat));
            }
            a *= 34.0f * sig * wa;
            bl((int32_t)ex + x, (int32_t)ey + y, C_LAMP, (int32_t)g);
            bl((int32_t)ex + x, (int32_t)ey + y, light, (int32_t)a);
            if (x) {
                bl((int32_t)ex - x, (int32_t)ey + y, C_LAMP, (int32_t)g);
                bl((int32_t)ex - x, (int32_t)ey + y, light, (int32_t)a);
            }
        }
    seg_aa(ex - 12.5f, ey, ex + 12.5f, ey, light, (int32_t)(6.0f + 26.0f * sig), 0.6f);   /* the earpiece's face, lit */
    len[0] = 0.0f;                       /* the cord's length along it (its turns spaced evenly by it, whatever its
                                          * curve's pace) */
    ph_cord(cord, 0.0f, o);
    px = o[0];
    py = o[1];
    for (i = 1; i <= PH_CN; i++) {
        ph_cord(cord, (float)i * (1.0f / PH_CN), o);
        len[i] = len[i - 1] + fm_sqrtf((o[0] - px) * (o[0] - px) + (o[1] - py) * (o[1] - py));
        px = o[0];
        py = o[1];
    }
    for (i = 0; i < 8; i++) {            /* (a turn of the coil in eight: across the cord, toward the eye) */
        cs[i] = fm_sin_turns((float)i * 0.125f);
        cs[i + 8] = fm_sin_turns((float)i * 0.125f + 0.25f);
    }
    for (i = 0, n = 0; (float)i * (PH_CP / 8.0f) <= len[PH_CN]; i++) {   /* the coil: a line a pixel thick round and
                                          * round the cord (its loops), a turn each PH_CP of its length, the near
                                          * side of each bright, the far side dim; off the strip's edge */
        float s = (float)i * (PH_CP / 8.0f), x1, y1;
        while (n < PH_CN - 1 && len[n + 1] < s)
            n++;
        ph_cord(cord, ((float)n + (s - len[n]) / (len[n + 1] - len[n] + 1e-6f)) * (1.0f / PH_CN), o);
        x1 = o[0] - PH_CR * cs[i & 7] * o[3] + PH_CK * cs[(i & 7) + 8] * o[2];
        y1 = o[1] + PH_CR * cs[i & 7] * o[2] + PH_CK * cs[(i & 7) + 8] * o[3];
        if (i) {
            float nr = cs[((i - 1) & 7) + 8] + cs[(i & 7) + 8];   /* (how near: -2 .. 2, the segment's middle) */
            line_aa(px, py, x1, y1, nr > 0.0f ? C_MIST : C_SLATE, nr > 0.0f ? (int32_t)(20.0f + 4.0f * nr) : 20);
        }
        if (x1 > 241.0f && px > 241.0f)
            break;
        px = x1;
        py = y1;
    }
    n = (int32_t)(40.0f * nz * nz + (nz > 0.0f ? 2.0f : 0.0f));
    for (i = 0; i < n; i++) {            /* the static, along the cord (another each frame) */
        float r;
        h = h * 1664525u + 1013904223u;
        ph_cord(cord, (float)(h >> 8 & 1023u) * (0.9f / 1024.0f), o);
        r = 0.8f * ((float)(h >> 20 & 15u) - 7.5f);
        bl((int32_t)(o[0] - r * o[3] + 0.5f), (int32_t)(o[1] + r * o[2] + 0.5f), C_FOG,
           (int32_t)((float)(10u + (h >> 26 & 15u)) * (1.5f - 0.5f * sig)));   /* (louder in a cut) */
    }
}

static void tape_scope(void)
{
    static uint32_t last;
    const float gr = 4.0f, hy = TP_GY + gr, a0 = 10.0f * 10.0f, a1 = 23.0f * 23.0f;
    uint32_t now = plat_ms();
    int on = st.v[P_TP_ON] != 0, still = st.v[P_ANIM] != 0;
    if (st.v[P_TP_ON] == FR_VINYL || st.v[P_TP_ON] == FR_AM || st.v[P_TP_ON] == FR_PHONE) {   /* (MEDIA's others) */
        if (st.v[P_TP_ON] == FR_VINYL)
            vinyl_scope();
        else if (st.v[P_TP_ON] == FR_AM)
            am_scope();
        else
            phone_scope();
        return;
    }
    float dt = (float)(now - last) * 0.001f, sat = vh(P_TP_SAT) / 127.0f, wob = vh(P_TP_WOBBLE) / 127.0f;
    float spd = on ? frasil_tape_speed() : 1.0f, tl[4], tr[4], loose, t = still ? 6.0f : (float)now * 0.001f, pl, pr;
    uint16_t tape = on ? mix565(RGB(120, 72, 40), C_LAMP, (int32_t)(32.0f * sat)) : C_STEEL;
    uint16_t hub = on ? C_FOG : C_SLATE, rim = on ? C_SLATE : C_STEEL;
    int32_t x, y;
    last = now;
    dt = dt > 0.1f ? 0.1f : dt;
    tp_vs += ((on ? spd : 1.0f) - tp_vs) * (dt > 0.15f ? 1.0f : dt * 6.7f);   /* (the engine's speed, read a frame
                                                                            * at a time: smoothed, 150 ms) */
    pl = fm_sqrtf(a0 + (1.0f - tp_u) * (a1 - a0));   /* the packs: the tape off the left one onto the right one, its
                                                      * length (their area) the same */
    pr = fm_sqrtf(a0 + tp_u * (a1 - a0));
    if (on && !still) {                  /* the tape at some 60 px a second past the head, each reel turning at its
                                          * radius, anticlockwise as a cassette's, TAPE SPEED's times faster or slower
                                          * (as it glides: core.c tape_l2); at the end, rewound in a second and a half,
                                          * quickly the other way */
        float v = tp_rew ? -400.0f : 60.0f * fm_exp2f(tape_l2) * (1.0f + 5.0f * (tp_vs - 1.0f));
        v = (!tp_rew && v < 0.0f ? 0.0f : v) * dt;
        tp_u += tp_rew ? -dt * (1.0f / 1.5f) : v * (1.0f / 5400.0f);   /* (some 90 s a side) */
        if (tp_u >= 1.0f)
            tp_rew = 1;
        if (tp_u <= 0.0f) {
            tp_u = 0.0f;
            tp_rew = 0;
        }
        tp_u = tp_u > 1.0f ? 1.0f : tp_u;
        tp_rot[0] -= v / (6.2831853f * pl);
        tp_rot[1] -= v / (6.2831853f * pr);
        tp_rot[0] -= fm_floorf(tp_rot[0]);
        tp_rot[1] -= fm_floorf(tp_rot[1]);
    }
    if (on && sat > 0.0f) {              /* the head's glow: wider and whiter as SATURATION grows, flickering a little;
                                          * a white-hot core past halfway (a quarter, mirrored) */
        float rad = 10.0f + 22.0f * sat, g = (0.35f + 0.65f * sat) * (0.85f + 0.15f * fm_sin_turns(t * 2.3f) *
                                                                         fm_sin_turns(t * 0.37f));
        uint16_t gc = mix565(C_LAMP, C_FOG, (int32_t)(12.0f * sat * sat));
        int32_t hx = 120, hyi = (int32_t)hy, q;
        for (y = 0; y <= (int32_t)rad; y++)
            for (x = 0; x <= (int32_t)(rad * 1.6f); x++) {
                float ex = (float)x * (1.0f / 1.6f), ey = (float)y, d = fm_sqrtf(ex * ex + ey * ey) / rad;
                int32_t a, w = 0;
                if (d >= 1.0f)
                    break;
                a = (int32_t)(30.0f * g * (1.0f - d) * (1.0f - d));
                if (sat > 0.5f && d < 0.3f)
                    w = (int32_t)(40.0f * (sat - 0.5f) * (0.3f - d) / 0.3f);
                for (q = 0; q < 4; q++) {
                    int32_t px = hx + (q & 1 ? -x : x), py = hyi + (q & 2 ? -y : y);
                    if ((q & 1 && !x) || (q & 2 && !y) || py >= 93)
                        continue;
                    bl(px, py, gc, a);
                    if (w)
                        bl(px, py, C_FOG, w);
                }
            }
    }
    reel(TP_RL, (float)TP_CY, pl, tp_rot[0], tape, hub, rim);
    reel(TP_RR, (float)TP_CY, pr, tp_rot[1], tape, hub, rim);
    loose = on ? wob * (4.0f + 3.0f * fm_sin_turns(t * 0.7f)) + (still ? 0.0f : 60.0f * (spd < 1.0f ? 1.0f - spd : 0.0f))
               : 0.0f;
    loose = loose > 10.0f ? 10.0f : loose;
    tape_tangent(TP_RL, (float)TP_CY, pl, TP_GL, TP_GY, gr, tl);
    tape_tangent(TP_GR, TP_GY, gr, TP_RR, (float)TP_CY, pr, tr);
    tape_span(tl, loose, tape, 30);
    tape_span(tr, on ? wob * (4.0f + 3.0f * fm_sin_turns(t * 0.7f + 0.4f)) : 0.0f, tape, 30);
    seg_aa(TP_GL, hy, TP_GR, hy, on ? mix565(tape, C_FOG, (int32_t)(26.0f * sat)) : tape, 32, 0.6f + 0.4f * sat);
                                         /* (over the head, taut, hot as it saturates) */
    for (y = (int32_t)(TP_GY - gr) - 1; y <= (int32_t)(TP_GY + gr) + 1; y++)   /* the rollers: rings, a pin */
        for (x = (int32_t)(TP_GL - gr) - 1; x <= (int32_t)(TP_GR + gr) + 1; x++) {
            float cxr = x < 120 ? TP_GL : TP_GR, ex = (float)x - cxr, ey = (float)y - TP_GY;
            float d = fm_sqrtf(ex * ex + ey * ey), c = 1.0f - fm_fabsf(d - (gr - 0.5f));
            if (fm_fabsf(ex) > gr + 1.0f)
                continue;
            if (c > 0.0f)
                bl(x, y, hub, (int32_t)(26.0f * c));
            if (d < 1.2f)
                bl(x, y, hub, 24);
        }
    cv_rect(113, (int32_t)hy + 1 - oy, 15, 4, on ? (sat > 0.5f ? mix565(C_LAMP, C_FOG, (int32_t)(40.0f * (sat - 0.5f)))
                                                        : C_LAMP) : C_SLATE);   /* the head, its gap */
    cv_rect(120, (int32_t)hy + 1 - oy, 1, 4, C_BG);
}

/* LOFI TAPE II: TAPE SPEED landed on a half-tone (params.c tape_semis), the tones it moves the pitch between the reels,
 * over the tape's path: the number (half a tone ".5": "-1.5", "-1", "+3.5", "-6"), TONE under it for one, TONES
 * otherwise; amber, as the head. X1.00 and between half-tones nothing. A MIDI clock leading, the pitch alone moves: as
 * true. Drawn with the strip each frame (the band cleared under it), over the head's glow; on VINYL right of the
 * record, on AM right of the needle (card #99), on PHONE right of the handset, over its cord (card #218) */
static void tones_tag(void)
{
    char w[12];
    int n = tape_semis(pv_shown(P_TP_FLUTTER)), a = n < 0 ? -n : n;   /* (as its cell shows it: ANCHOR's glide back
                                                                       * too) */
    int32_t xc = st.v[P_TP_ON] == FR_VINYL || st.v[P_TP_ON] == FR_PHONE ? 204 : st.v[P_TP_ON] == FR_AM ? 176 : 120;
    ui.semis = (int8_t)n;
    ui.tonew = (uint8_t)(!n ? 0 : a == 2 ? 1 : 2);
    if (!n)
        return;
    w[0] = 0;
    text_cat(w, n > 0 ? "+" : "-");
    int_text(a / 2, w + 1);
    if (a & 1)
        text_cat(w, ".5");
    text_c(xc, 40, &FONT_M, w, C_LAMP, 1);
    text_c(xc, 64, &FONT_XS, a == 2 ? "TONE" : "TONES", mix565(C_BG, C_LAMP, 25), 1);
}

/* ROUTING: the chain as it is. The tracks along the top, the cloud on a lane below them (its share taken, its return
 * given back); MASTER FILTER before the branch (PRE: the cloud fed it filtered) or after the return (POST), LOFI TAPE on
 * the tracks' lane alone (PRE: the cloud left clean) or after the return; each slate while it is off. CLOUD PUMP: a
 * duck on the return; SPK/JACK: the speaker at the end, crossed out while it is quiet */
static void rt_block(int32_t cx, int32_t cy, const char *s, uint16_t col, int on)
{
    int32_t w = text_tw(&FONT_XS, s, 1) + 10, x0 = cx - w / 2, x, a = on ? 30 : 16;
    cv_rect(x0, cy - 7 - oy, w, 15, C_BG);
    for (x = x0 + 1; x < x0 + w - 1; x++) {
        bl(x, cy - 7, col, a);
        bl(x, cy + 7, col, a);
    }
    for (x = cy - 6; x <= cy + 6; x++) {
        bl(x0, x, col, a);
        bl(x0 + w - 1, x, col, a);
    }
    text_t(x0 + 5, cy - 5, &FONT_XS, s, on ? col : C_SLATE, 1);
}

static void routing_scope(void)
{
    const int32_t yt = 52, yc = 80, xs = 64, xm = 118;
    int fon = st.v[P_FL_TYPE] != 0, ton = st.v[P_TP_ON] != 0, fpre = st.v[P_FL_PRE] != 0, tpre = st.v[P_TP_PRE] != 0;
    int32_t y, x;
    hline(ML, MR - 14, yt, C_SLATE);         /* the tracks */
    for (y = yt; y <= yc; y++) {             /* the cloud's lane: its share down, its return up */
        bl(xs, y, C_SLATE, 32);
        bl(xm, y, C_SLATE, 32);
    }
    hline(xs, xm, yc, C_SLATE);
    rt_block((xs + xm) / 2, yc, "CLOUD", C_MIST, 1);
    if (st.v[P_PUMP_CLOUD])                  /* the return ducked with the drone: a little saw beside it */
        for (x = 0; x < 9; x++) {
            bl(xm + 3 + x, yc - 6 + (x % 3) * 2, C_LAMP, 30);
            bl(xm + 3 + x, yc - 5 + (x % 3) * 2, C_LAMP, 14);
        }
    rt_block(fpre ? 37 : 143, yt, "FILTER", C_ICE, fon);
    {                                        /* LOFI's block, its MEDIA's name (TAPE, VINYL, AM, PHONE: card #229); after
                                              * the return, its left edge where TAPE's was (169: PHONE's two pixels from
                                              * FILTER's and from the speaker) */
        const char *md = lofi_name(0) + 5;
        rt_block(tpre ? (xs + xm) / 2 : 169 + (text_tw(&FONT_XS, md, 1) + 10) / 2, yt, md, C_LAMP, ton);
    }
    {                                        /* the speaker: a box and its cone; crossed out while quiet */
        int32_t sx = MR - 8, on = st.v[P_SPEAKER] != 0;
        uint16_t sc = on ? C_FOG : C_SLATE;
        cv_rect(sx, yt - 2 - oy, 3, 5, sc);
        for (x = 0; x < 4; x++) {
            bl(sx + 3 + x, yt - 2 - x, sc, 32);
            bl(sx + 3 + x, yt + 2 + x, sc, 32);
        }
        for (y = yt - 5; y <= yt + 5; y++)
            bl(sx + 7, y, sc, 32);
        if (!on)
            for (x = -5; x <= 5; x++) {
                bl(sx + 3 + x, yt + x, C_LAMP, 32);
                bl(sx + 3 + x, yt - x, C_LAMP, 32);
            }
    }
}

/* an LFO's pages: its shape over a turn (four for RANDOM and DRIFT: the three before and this one) across the strip,
 * as deep as DEPTH (a little even at 0, to be seen), from where POLARITY puts it (the middle, the bottom, the top);
 * where it is now, a glint; slate while it is off */
static void lfo_scope(uint32_t i)
{
    const uint8_t *L = &st.v[LFO_BASE[i]];
    uint32_t s = L[0] % 7u, pol = L[3] % 3u;
    int rnd = s >= 5u, on = lfo[i].on;
    float d = 0.2f + 0.8f * vh(LFO_BASE[i] + 2u) / 127.0f, turns = rnd ? 4.0f : 1.0f, now;
    int32_t top = 40, bot = 80, x, py = 0, w = MR - ML;
    uint16_t col = on ? C_ICE : C_SLATE;
    int32_t base = pol == 1u ? bot : pol == 2u ? top : (top + bot) / 2;
    hline(ML, MR, base, C_STEEL);
    for (x = 0; x <= w; x++) {
        float u = (float)x / (float)w * turns, sv, y;
        uint32_t c = rnd ? lfo[i].cyc + (uint32_t)u - 3u : 0u;
        int32_t yi, y0, y1, k;
        sv = lfo_shape(s, rnd ? u - (float)(int32_t)u : (u >= 1.0f ? 0.9999f : u), i, c);
        y = pol == 1u ? (float)bot - 0.5f * (sv + 1.0f) * (float)(bot - top) * d
          : pol == 2u ? (float)top + 0.5f * (sv + 1.0f) * (float)(bot - top) * d
                      : (float)base - sv * 0.5f * (float)(bot - top) * d;
        yi = (int32_t)(y + 0.5f);
        y0 = x ? (py < yi ? py : yi) : yi;
        y1 = x ? (py > yi ? py : yi) : yi;
        for (k = y0; k <= y1; k++) {     /* (joined to the last: a square's edges), a soft second row under it */
            bl(ML + x, k, col, on ? 24 : 12);
            bl(ML + x, k + 1, col, on ? 7 : 4);
        }
        py = yi;
    }
    now = rnd ? (3.0f + lfo[i].ph) / 4.0f : lfo[i].ph;
    {
        int32_t gx = ML + (int32_t)(now * (float)w + 0.5f), gy, j;
        float sv = lfo[i].out;
        gy = (int32_t)((pol == 1u ? (float)bot - 0.5f * (sv + 1.0f) * (float)(bot - top) * d
                      : pol == 2u ? (float)top + 0.5f * (sv + 1.0f) * (float)(bot - top) * d
                                  : (float)base - sv * 0.5f * (float)(bot - top) * d) + 0.5f);
        cv_rect(gx, top - 4 - oy, 1, bot - top + 8, mix565(C_BG, col, 6));
        int32_t dx, dy;
        for (dy = -3; dy <= 3; dy++)     /* a glow, */
            for (dx = -3; dx <= 3; dx++) {
                int32_t r2 = dx * dx + dy * dy;
                if (r2 <= 10)
                    bl(gx + dx, gy + dy, col, (on ? 16 : 8) * (11 - r2) / 11);
            }
        for (j = 2; j <= 7; j++) {       /* four arms, */
            int32_t a = (on ? 26 : 12) * (8 - j) / 7;
            bl(gx + j, gy, col, a);
            bl(gx - j, gy, col, a);
            bl(gx, gy + j, col, a * 3 / 4);
            bl(gx, gy - j, col, a * 3 / 4);
        }
        for (dy = -1; dy <= 1; dy++)     /* a white core */
            for (dx = -1; dx <= 1; dx++)
                bl(gx + dx, gy + dy, on ? C_WHITE : C_MIST, dx || dy ? 20 : 32);
    }
}

/* MIXER: a fader for each track, its level (100: as it is, a mark; 127 at the top), and beside it the track's meter,
 * live (48 dB). Each in its colour: DRONE white, BASS lamp, GLINT ice, CLOUD the haze lit. While the computer's audio
 * comes back (card #172: app.c rin), a fifth, RETURN, MIDI's violet: its track up to the mark (100 %, its most), its
 * meter the stream's; the five closer, each knob's badge at its fader's foot (no room for it beside the name) */
#define MIX_TOP 44
#define MIX_BOT 160                      /* (166 till 3.3.1: the footer's labels, values and the PAN hint up, room between
                                          * them and the CPU line, card #169) */
static uint32_t mix_n(void) { return 4u + (uint32_t)MIX_RET(); }
static int32_t mix_x(uint32_t i) { return mix_n() > 4u ? ML + 19 + (int32_t)i * 43 : ML + 26 + (int32_t)i * 53; }
#if FRS_MIDI_OUT
static int mix_ret_hot(void) { return mout.at && mout.at_p == K_MO_RET && plat_ms() - mout.at < TOUCH_MS; }
#endif
#if FRS_LEAD                             /* (K4 the LEAD's, its rose; admin #744) */
static uint16_t mix_col(uint32_t i) { return i == 0 ? C_FOG : i == 1u ? C_LAMP : i == 2u ? C_ICE : C_LEAD_TRACK; }
#define MIX_PANS 3u                      /* (the LEAD has no PAN) */
#else
static uint16_t mix_col(uint32_t i)
{
    return i == 0 ? C_FOG : i == 1u ? C_LAMP : i == 2u ? C_ICE : mix565(C_MIST, C_ICE, 12);
}
#define MIX_PANS 4u
#endif

static void mixer(void)
{
    float m[5];
    uint32_t i;
    frasil_meters(m);
#if FRS_LEAD
    m[3] = frasil_lead_meter();          /* (K4 the LEAD's: its meter, not the cloud's) */
#endif
#if FRS_MIDI_OUT
    m[4] = rin.lvl;                      /* (RETURN's: the computer's, card #172) */
#endif
    for (i = 0; i < mix_n(); i++) {
        int ret = i == 4u, p = ret ? 0 : PAGES[PG_MIXER].p[i], hot = ret ? 0 : touched_now() && fm.touched == p;
        int32_t x = mix_x(i), h = MIX_BOT - MIX_TOP, y, dx, yl, yu = MIX_BOT - 100 * h / 127, ym;
        uint16_t c = ret ? C_MIDI_TRACK : mix_col(i);
        float db = 6.0206f * fm_log2f(m[i] + 1e-6f), f = br_clamp01((db + 48.0f) * (1.0f / 48.0f));
#if FRS_MIDI_OUT
        if (ret)
            hot = mix_ret_hot();
        yl = MIX_BOT - (ret ? (int32_t)mout.ret : (int32_t)vh_n((uint32_t)p)) * h / 127;
#else
        yl = MIX_BOT - (int32_t)vh_n((uint32_t)p) * h / 127;
#endif
        for (y = ret ? yu : MIX_TOP; y <= MIX_BOT; y += 2)   /* the track (RETURN's to its most) */
            bl(x, y, C_STEEL, 32);
        for (dx = -7; dx <= 7; dx++)              /* the unity mark */
            bl(x + dx, yu, C_SLATE, dx & 1 ? 0 : 28);
        for (y = yl + 2; y <= MIX_BOT; y++)       /* the level, a column of its colour */
            for (dx = -5; dx <= 5; dx++)
                bl(x + dx, y, c, hot ? 11 : 6);
        cv_rect(x - 11, yl - 1 - oy, 23, 3, hot ? C_LAMP : c);   /* the fader's cap */
        ym = MIX_BOT - (int32_t)(f * (float)h);   /* the meter */
        for (y = ym; y <= MIX_BOT; y++) {
            bl(x + 15, y, c, 30);
            bl(x + 16, y, c, 30);
        }
        if (mix_n() > 4u)                         /* (five: its knob's badge at its foot, the footer's names alone) */
            badge(x, 168, ret ? CN_BADGE_ALGO : (char)('1' + i), !ret);
        if (i < MIX_PANS) {                       /* its PAN above it: a short scale, the centre ticked, a dot */
            int pp = P_PN_DRONE + (int)i, ph = touched_now() && fm.touched == pp;
            int32_t xp = x + ((int32_t)vh_n((uint32_t)pp) - 50) * 11 / 50;
            for (dx = -11; dx <= 11; dx++)
                bl(x + dx, 38, C_STEEL, 32);
            bl(x, 37, C_SLATE, 32);
            bl(x, 39, C_SLATE, 32);
            cv_rect(xp - 1, 37 - oy, 3, 3, ph ? C_LAMP : st.v[pp] == 50u ? C_SLATE : c);
        }
    }
}

static void mixer_footer(void)
{
    uint32_t i, n = mix_n();
    for (i = 0; i < n; i++) {
        int pans = b_held(B_OCTDN) || (touched_now() && fm.touched >= P_PN_DRONE && fm.touched <= P_PN_CLOUD);
        int q, p, hot;
        int32_t x = mix_x(i), w, x0;
#if FRS_MIDI_OUT
        if (i == 4u) {                   /* RETURN (card #172): ALGORITHM's, its % as the tracks' levels */
            char t[4];
            hot = mix_ret_hot();
            t[0] = 0;
            int_text((int32_t)mout.ret, t);
            text_c(x, 177, &FONT_XS, "RETURN", hot ? C_LAMP : C_MIST, 0);
            cv_text(x - text_w(&FONT_M, t) / 2, 192 - oy, &FONT_M, t, hot ? C_LAMP : C_MIDI_TRACK);
            continue;
        }
#endif
        q = PAGES[PG_MIXER].p[i];
        p = pans && i < MIX_PANS ? P_PN_DRONE + (int)i : q;
        hot = touched_now() && fm.touched == p;
        w = 15 + text_tw(&FONT_XS, PD[q].name, 0);
        x0 = x - w / 2;
        if (n > 4u) {                    /* (five: the name alone, its badge at the fader's foot: mixer) */
            text_c(x, 177, &FONT_XS, PD[q].name, hot ? C_LAMP : C_MIST, 0);
        } else {
            badge(x0 + 6, 184, (char)('1' + i), 1);
            text_t(x0 + 15, 177, &FONT_XS, PD[q].name, hot ? C_LAMP : C_MIST, 0);   /* (the track: its level, or its
                                                                                    * PAN while OCT- is held) */
        }
        value_big(x, 192, p, n > 4u ? 42 : 50, &FONT_M, hot ? C_LAMP : mix_col(i), 1);
    }
    {                                        /* (the pans' gesture, hidden: told at the bottom, OCT- as a key) */
        static const char *const H0 = "PAN: HOLD", *const H1 = "AND K";
        int32_t wk = text_tw(&FONT_XS, CN_OCTDN, 1) + 10, w = text_tw(&FONT_XS, H0, 1) + 5 + wk + 5 + text_tw(&FONT_XS, H1, 1);
        int32_t x = (ML + MR) / 2 - w / 2, y = 215;   /* (above ANCHOR's frame, four rows clear of the values and of the
                                                       * CPU line) */
        x = text_t(x, 217, &FONT_XS, H0, C_SLATE, 1) + 5;
        hline(x + 1, x + wk - 2, y, C_SLATE);   /* the key: a rounded box (its corners left out) */
        hline(x + 1, x + wk - 2, y + 16, C_SLATE);
        cv_rect(x, y + 1 - oy, 1, 15, C_SLATE);
        cv_rect(x + wk - 1, y + 1 - oy, 1, 15, C_SLATE);
        text_t(x + 5, 217, &FONT_XS, CN_OCTDN, C_MIST, 1);
        text_t(x + wk + 5, 217, &FONT_XS, H1, C_SLATE, 1);
    }
}

/* MASTERING: the compressor's gain reduction, live, a bar from the right (20 dB across) */
static void gr_meter(void)
{
    float gr = st.v[P_MS_RATIO] ? -frasil_comp_gr() : 0.0f;
    int32_t w = MR - ML + 1, n = (int32_t)(br_clamp01(gr * (1.0f / 20.0f)) * (float)w), k;
    char s[16];
    text_t(ML, 42, &FONT_XS, "REDUCTION", C_MIST, 1);
    s[0] = 0;
    if (!st.v[P_MS_RATIO]) {
        text_cat(s, "OFF");
    } else {
        int32_t d = (int32_t)(gr * 10.0f + 0.5f);
        text_cat(s, d ? "-" : "");
        int_text(d / 10, s + strlen_(s));
        text_cat(s, ".");
        int_text(d % 10, s + strlen_(s));
        text_cat(s, " DB");
    }
    text_r(MR, 42, &FONT_XS, s, gr > 0.5f ? C_LAMP : C_MIST, 0);
    hline(ML, MR, 70, C_STEEL);
    for (k = 0; k <= 4; k++)                 /* a tick every 5 dB */
        cv_rect(MR - k * (w - 1) / 4, 66 - oy, 1, 9, C_SLATE);
    if (n > 0)
        cv_rect(MR - n + 1, 64 - oy, n, 13, C_LAMP);
}

#if PLAT_SMK37
#define SC_ACT_TR 0                      /* (SCENES' two actions, the SMK-37's SEQ PLAY and BT + SEQ REC: untracked, inside
                                          * their box) */
#else
#define SC_ACT_TR 1
#endif
/* SCENES: five lines around the one K1 points at: NEW SHARD first, then the sixteen slots, each its number, its name
 * (in FONT_B; one past its room rolls there, as SOUND's does, if K1 points at it, else shows its start, its end faded),
 * what it holds (what it plays, FACTORY, EMPTY: left out for a long name); the one K1 points at framed in ice, the one
 * loaded marked NOW. NEW SHARD is no slot, a sound to start from: a plus for its number, START
 * FRESH for what it holds, framed in lamp. Under them, apart in a box of their own, the page's two actions: PLAY loads,
 * SAVE and REC store (on NEW SHARD, PLAY LOAD alone) */
#define SC_ROW 22
#define SC_BOX 150                        /* the actions' box: its top */
static void scenes_list(void)
{
    int32_t first = (fm.pick >= NSCENES ? 0 : (int32_t)fm.pick + 1) - 2, i;   /* (the lines: NEW SHARD's 0, a slot's
                                                                               * its number) */
    uint32_t now = plat_ms();
    first = first < 0 ? 0 : first > (int32_t)NSCENES - 4 ? (int32_t)NSCENES - 4 : first;
    for (i = 0; i < 5; i++) {
        uint32_t s = first + i ? (uint32_t)(first + i - 1) : SC_NEW, used = s < NSCENES && (scn.used >> s & 1u);
        int32_t y = 36 + i * SC_ROW, pick = s == fm.pick, x, wn, xn = ML + 27, room, held;
        uint16_t fc = s == SC_NEW ? C_LAMP : C_ICE, ink;
        scene_t sc;
        char n[4], t[24], nt[SC_LONG + 1];
        scene_get(s, &sc);
        scene_name(s, nt);
        if (pick) {                      /* framed, lit a little */
            cv_rect(ML - 4, y - oy, MR - ML + 9, SC_ROW - 2, mix565(C_BG, fc, 3));
            hline(ML - 3, MR + 3, y, fc);
            hline(ML - 3, MR + 3, y + SC_ROW - 3, fc);
            cv_rect(ML - 4, y + 1 - oy, 1, SC_ROW - 4, fc);
            cv_rect(MR + 4, y + 1 - oy, 1, SC_ROW - 4, fc);
        }
        t[0] = 0;
        if (s == SC_NEW) {
            text_cat(t, "START FRESH");
        } else if (!used) {
            text_cat(t, s < NFACTORY ? "FACTORY" : "EMPTY");
        } else if (sc.nch || sc.narp || sc.nbarp || sc.bass >= 0) {   /* what it plays */
            if (sc.nch) {
                int_text(sc.nch, t);
                text_cat(t, " DR");
            }
            if (sc.narp)
                text_cat(t, t[0] ? " ARP" : "ARP");
            if (sc.bass >= 0 || sc.nbarp)
                text_cat(t, t[0] ? " BS" : "BASS");
        } else {
            text_cat(t, "SOUND");
        }
        x = MR + 1;                      /* from the right: NOW, then what it holds, if the name leaves room */
        if (s == fm.scene)
            x -= text_tw(&FONT_XS, "NOW", 1) + 8;
        wn = text_tw(&FONT_B, nt, 1);
        if ((held = xn + wn + 8 <= x - text_tw(&FONT_XS, t, 1) - 8) != 0)
            x -= text_tw(&FONT_XS, t, 1) + 8;
        room = x - 8 - xn;
        ink = pick ? C_WHITE : used || s < NFACTORY || s == SC_NEW ? C_FOG : C_SLATE;
        if (text_tw(&FONT_B, nt, 0) <= room) {   /* whole in FONT_B (closer if need be) */
            fit_text(xn, y + 2, room, nt, ink, 0, 1);
        } else {                         /* past its room: FONT_B all the same, never smaller; what it drew past it, the
                                          * row's again */
            uint16_t bg = pick ? mix565(C_BG, fc, 3) : C_BG;
            if (pick) {
                lroll.x = xn;
                lroll.y = y + 2;
                lroll.band = bg;
                lroll.ink = ink;
                roll_draw(&lroll, nt, room, now);
            } else {
                roll_t r = {.f = &FONT_B, .tr = 1};
                r.band = bg;
                r.ink = ink;
                roll_paint(&r, nt, xn, y + 2, room, 0, wn - room);
            }
            cv_rect(0, y + 2 - oy, xn, ROLL_H, C_BG);
            cv_rect(xn + room, y + 2 - oy, 240 - xn - room, ROLL_H, C_BG);
            if (pick) {
                cv_rect(ML - 4, y + 2 - oy, xn - ML + 4, ROLL_H, bg);
                cv_rect(xn + room, y + 2 - oy, MR + 4 - xn - room, ROLL_H, bg);
                cv_rect(ML - 4, y + 2 - oy, 1, ROLL_H, fc);
                cv_rect(MR + 4, y + 2 - oy, 1, ROLL_H, fc);
            }
        }
        if (s < NSCENES) {
            n[0] = (char)('0' + (s + 1u) / 10u);
            n[1] = (char)('0' + (s + 1u) % 10u);
            n[2] = 0;
            text_t(ML + 1, y + 2, &FONT_B, n, pick ? C_ICE : C_SLATE, 1);
        }
        if (s == SC_NEW) {               /* its mark: a plus, two pixels wide */
            cv_rect(ML + 3, y + 8 - oy, 11, 2, pick ? C_LAMP : C_SLATE);
            cv_rect(ML + 7, y + 4 - oy, 2, 10, pick ? C_LAMP : C_SLATE);
        }
        if (held)
            text_t(x + 8, y + 4, &FONT_XS, t, used && t[0] != 'S' ? C_ICE : pick && s == SC_NEW ? C_LAMP : C_SLATE, 1);
        if (s == fm.scene)               /* the one loaded: NOW */
            text_t(MR + 1 - text_tw(&FONT_XS, "NOW", 1), y + 4, &FONT_XS, "NOW", C_LAMP, 1);
    }
    {                                    /* the two actions, in their box: PLAY LOAD, SAVE + REC STORE */
        static const char *const W[4] = {CN_PLAY, "LOAD", CN_SAVE " + " CN_REC, "STORE"};
        int32_t w = 0, x, k, y = SC_BOX, h = 22, nw = fm.pick < NSCENES ? 4 : 2;   /* (NEW SHARD: nothing to store) */
        uint16_t fill = mix565(C_BG, C_ICE, 6);
        ui.acts = (uint8_t)nw;
        for (k = 0; k < nw; k++)
            w += text_tw(&FONT_XS, W[k], SC_ACT_TR) + 1;
        w += nw == 4 ? 6 + 23 + 6 : 6;   /* (a key and its word 6 apart; the two 23 apart, a hairline between) */
        cv_rect(ML - 4, y + 1 - oy, MR - ML + 9, h - 2, fill);   /* the box: filled, its corners rounded */
        hline(ML - 3, MR + 3, y, fill);
        hline(ML - 3, MR + 3, y + h - 1, fill);
        x = 120 - w / 2;
        for (k = 0; k < nw; k++) {
            uint16_t c = k & 1 ? C_ICE : C_WHITE;
            text_t(x, y + 4, &FONT_XS, W[k], c, SC_ACT_TR);
            x = text_t(x + 1, y + 4, &FONT_XS, W[k], c, SC_ACT_TR) + 1;   /* (bold) */
            if (k == 1 && nw == 4) {
                cv_rect(x + 11, y + 5 - oy, 1, h - 10, mix565(fill, C_ICE, 12));
                x += 23;
            } else {
                x += 6;
            }
        }
    }
}

/* CHOIR II and III: the wave SHAPE makes (frasil.c's: a saw minus a of itself w later; a SAW, the SQUARE at the middle,
 * then a PULSE ever narrower), two turns across the strip, its width swaying as the engine sways it; faint, the bare
 * shape; bright, the wave as heard: SOFT's integrators (frasil.c choir_run: each k / (0.15 k + j w), at harmonic n
 * 1 / (0.15 + j n), mixed by quarter turns), then CHOIR's filter (FILTER and TIMBRE where it cuts, RESONANCE, TYPE: its
 * first harmonics). CHOIR II: SHAPE's badge on the edge it moves; III: SOFT's on the wave's top, near the strip's
 * start */
#define CS_N 40
static void choir_scope(float t)
{
    const int32_t zero = 62, half = 20;
    const float ph0 = 0.18f;             /* (no edge on the strip's ends) */
    float sh = br_clamp01((vh(P_CH_SHAPE) + mod[P_CH_SHAPE]) * (1.0f / 127.0f));
    float a = sh < 0.5f ? 2.0f * sh : 1.0f, w0 = sh < 0.5f ? 0.5f : 0.5f - 0.8f * (sh - 0.5f);
    float sw = sh > 0.5f ? 0.03f + 0.18f * (sh - 0.5f) : 0.03f * a;
    float w = w0 + sw * fm_sinf(6.2831853f * 0.21f * t);
    float ce = br_clamp01((vh(P_FILTRE) + mod[P_FILTRE]) * (1.0f / 127.0f) +
                          ((vh(P_TIMBRE) + mod[P_TIMBRE]) * (1.0f / 127.0f) - 0.5f) * 0.6f);
    float hc = 1.0f + 39.0f * ce * ce, rs = br_clamp01((vh(P_CH_RESO) + mod[P_CH_RESO]) * (1.0f / 127.0f));
    float q = 0.5f * fm_powf(40.0f, rs), cr[CS_N], ci[CS_N], raw[RS_N], out[RS_N], pr = 1e-3f, po = 1e-3f, edge, pk = -1e9f;
    float so = br_clamp01((vh(P_CH_SOFT) + mod[P_CH_SOFT]) * (1.0f / 127.0f)), s0 = 1.0f, s1 = 0.0f, s2 = 0.0f;
    uint32_t type = st.v[P_CH_TYPE] % 3u, n;
    int32_t x, py = 0, qy = 0, ex, top = 0, tx = 0;
    w = w < 0.04f ? 0.04f : w > 0.96f ? 0.96f : w;
    if (so > 0.002f) {                   /* SOFT's mix, as the engine's (its gains k and k^2 in the stages here) */
        float g = 3.14159265f * (so < 0.5f ? so : so - 0.5f), c = fm_cosf(g), sn = fm_sinf(g);
        s0 = so < 0.5f ? c : 0.0f;
        s1 = so < 0.5f ? sn : c;
        s2 = so < 0.5f ? 0.0f : sn;
    }
    for (n = 0; n < CS_N; n++) {          /* each harmonic: the saw's, less a of it w later, softened, through the filter */
        float k = (float)(n + 1), r = k / hc, th = 6.2831853f * k * w, c0 = -0.63661977f / k;
        float xr = c0 * (1.0f - a * fm_cosf(th)), xi = c0 * (-a * fm_sinf(th)), dr, di, nr, ni, m;
        if (so > 0.002f) {               /* s0 + s1 / (L + j k) + s2 / (L + j k)^2, L = 0.15 (the engine's leak) */
            float dd = 1.0f / (0.0225f + k * k), ir = 0.15f * dd, ii = -k * dd;
            float hr = s0 + s1 * ir + s2 * (ir * ir - ii * ii), hi = s1 * ii + s2 * 2.0f * ir * ii, tr = xr * hr - xi * hi;
            xi = xr * hi + xi * hr;
            xr = tr;
        }
        if (rs > 0.002f || type) {       /* the state-variable: 1 / (1 - r^2 + j r / q), its low, band or high */
            dr = 1.0f - r * r;
            di = r / q;
            nr = type == 2u ? -r * r : type == 1u ? 0.0f : 1.0f;
            ni = type == 1u ? r / q : 0.0f;
        } else {                         /* two one-poles: 1 / (1 + j r)^2 */
            dr = 1.0f - r * r;
            di = 2.0f * r;
            nr = 1.0f;
            ni = 0.0f;
        }
        m = 1.0f / (dr * dr + di * di + 1e-9f);
        {
            float hr = (nr * dr + ni * di) * m, hi = (ni * dr - nr * di) * m;
            cr[n] = xr * hr - xi * hi;
            ci[n] = xr * hi + xi * hr;
        }
    }
    for (x = 0; x < RS_N; x++) {
        float ph = ph0 + 2.0f * (float)x / (float)RS_N, f1 = ph - (float)(int32_t)ph, f2 = ph + w;
        float zr = fm_cosf(6.2831853f * ph), zi = fm_sinf(6.2831853f * ph), ur = zr, ui = zi, y = 0.0f, tmp;
        f2 -= (float)(int32_t)f2;
        raw[x] = (2.0f * f1 - 1.0f) - a * (2.0f * f2 - 1.0f);
        for (n = 0; n < CS_N; n++) {     /* (e^(j n ph) by turning, not by n sines) */
            y += cr[n] * ui + ci[n] * ur;
            tmp = ur * zr - ui * zi;
            ui = ur * zi + ui * zr;
            ur = tmp;
        }
        out[x] = y;
        pr = fm_fabsf(raw[x]) > pr ? fm_fabsf(raw[x]) : pr;
        po = fm_fabsf(y) > po ? fm_fabsf(y) : po;
    }
    hline(ML, MR, zero, C_STEEL);
    for (x = 0; x < RS_N; x++) {
        int32_t X = ML + x, yr = zero - (int32_t)(raw[x] / pr * (float)half + (raw[x] < 0.0f ? -0.5f : 0.5f));
        int32_t yo = zero - (int32_t)(out[x] / po * (float)half + (out[x] < 0.0f ? -0.5f : 0.5f)), yy, y0, y1;
        y0 = x && py < yr ? py : yr;     /* the bare shape, faint, its edges drawn */
        y1 = x && py > yr ? py : yr;
        for (yy = y0; yy <= y1; yy++)
            bl(X, yy, C_SLATE, 14);
        py = yr;
        for (yy = yo < zero ? yo + 2 : zero + 1; yy < (yo < zero ? zero : yo - 1); yy++) {   /* water to the line */
            int32_t d = yo < zero ? zero - yy : yy - zero, s = yo < zero ? zero - yo : yo - zero, al = d * 16 / (s ? s : 1);
            if ((X + yy) & 1)
                bl(X, yy, C_ICE, 10 * al * al / 256);
        }
        y0 = x && qy < yo ? qy : yo;     /* the wave heard */
        y1 = x && qy > yo ? qy : yo;
        for (yy = y0; yy <= y1; yy++) {
            bl(X, yy, C_ICE, 28);
            bl(X, yy + 1, C_ICE, 7);
        }
        qy = yo;
        if (x >= 16 && x < 16 + RS_N / 2 && out[x] > pk) {   /* (its top over a whole turn, clear of the strip's
                                                               * start: a peak, never where the strip cuts the wave) */
            pk = out[x];
            top = yo;
            tx = X;
        }
    }
    if (fm.page == PG_CHOEUR3) {         /* SOFT's badge on the wave's top */
        badge_r(tx, top - 2 < RS_TOP + 2 ? RS_TOP + 2 : top - 2, '1', 1,
                touched_now() && fm.touched == P_CH_SOFT ? 6.5f : 5.0f);
        return;
    }
    edge = (a > 0.05f ? 1.0f - w : 0.0f) - ph0;   /* SHAPE's edge in the first turn: the shifted saw's jump, else the saw's */
    edge -= (float)(int32_t)edge;
    edge += edge < 0.0f ? 1.0f : 0.0f;
    ex = ML + (int32_t)(edge * 0.5f * (float)RS_N + 0.5f);
    badge_r(ex, zero - half - 2 < RS_TOP + 2 ? RS_TOP + 2 : zero - half - 2, '1', 1,
            touched_now() && fm.touched == P_CH_SHAPE ? 6.5f : 5.0f);
}

/* NOT AVAILABLE FOR DRONE, in the middle of the page */
static void no_arp(void)
{
    text_c(120, 104, &FONT_B, "NOT AVAILABLE", C_MIST, 2);
    text_c(120, 126, &FONT_XS, "FOR DRONE", C_SLATE, 2);
}

#if FRS_LEAD
/* LEAD's (card #144): its ARP and SEQ, NOT AVAILABLE FOR LEAD (its KEYS its own since card #194: keys_scope) */
static void no_lead(void)
{
    text_c(120, 104, &FONT_B, "NOT AVAILABLE", C_MIST, 2);
    text_c(120, 126, &FONT_XS, "FOR LEAD", C_SLATE, 2);
}
#endif
#if FRS_MIDI_OUT
/* MIDI's (card #164): its ENV, NOT AVAILABLE FOR MIDI */
static void no_midi(void)
{
    text_c(120, 104, &FONT_B, "NOT AVAILABLE", C_MIST, 2);
    text_c(120, 126, &FONT_XS, "FOR MIDI", C_SLATE, 2);
}
/* MIDI OUT's strip: the keys as the computer gets them, a line each (a black one short), those down a bar in MIDI's
 * violet, risen as they are pressed; their range under it; the last note out and its velocity; USB lit while a
 * computer listens. The SMK-37: its 37, C3 to C6 at OCTAVE 0 */
#if PLAT_SMK37
#define MO_NK 37u
#define MO_LO 48
#else
#define MO_NK NKEYS
#define MO_LO 53
#endif
static void mout_scope(void)
{
    char t[8];
    uint32_t k, j, own = mout_held(), kp;
    int32_t kw = PLAT_SMK37 ? 5 : 7, x0 = 120 - (int32_t)MO_NK * kw / 2, lo = MO_LO + 12 * fm.octave, x, h;
    int listen = plat_midi_out_room(TO_USB) != 0;
    if (mout.sent) {                     /* the last note out, its velocity */
        t[0] = 0;
        text_cat(t, NOTE_NAME[mout.last % 12u]);
        int_text((int32_t)mout.last / 12 - 1, t + strlen_(t));
        x = cv_text(ML, 38 - oy, &FONT_B, t, C_FOG);
        int_text((int32_t)mout.last_vel, t);
        text_t(x + 6, 44, &FONT_XS, "VEL", C_MIST, 1);
        text_t(x + 6 + text_tw(&FONT_XS, "VEL", 1) + 4, 44, &FONT_XS, t, C_FOG, 1);
    }
    x = MR - text_tw(&FONT_XS, "USB", 1) - 6;   /* (a box, as the header's small caps) */
    hline(x, MR, 38, listen ? C_MIDI_TRACK : C_SLATE);
    hline(x, MR, 55, listen ? C_MIDI_TRACK : C_SLATE);
    cv_rect(x, 38 - oy, 1, 18, listen ? C_MIDI_TRACK : C_SLATE);
    cv_rect(MR, 38 - oy, 1, 18, listen ? C_MIDI_TRACK : C_SLATE);
    text_t(x + 4, 40, &FONT_XS, "USB", listen ? C_MIDI_TRACK : C_SLATE, 1);
    for (k = 0; k < MO_NK; k++) {
        int n = lo + (int)k, black = (0x54Au >> ((uint32_t)(n + 120) % 12u)) & 1u, down = 0;
        x = x0 + (int32_t)k * kw + kw / 2;
        for (j = 0, kp = 0; j < FRS_NKEYS; j++) {   /* (a note out at this place: its key's pressure; a chord's
                                                     * each, card #194) */
            uint32_t i;
            for (i = 0; (own >> j & 1u) && i < MAXCHORD; i++)
                if (mout.note[j][i] == n && mout.kp[j] >= kp)
                    down = 1, kp = mout.kp[j];
        }
        if (down) {
            h = 7 + (int32_t)kp * 13 / 127;
            cv_rect(x - (kw > 5 ? 2 : 1), 77 - h - oy, kw > 5 ? 5 : 3, h, C_MIDI_TRACK);
        } else {
            cv_rect(x, (black ? 59 : 57) - oy, 1, black ? 12 : 20, black ? C_STEEL : C_SLATE);
        }
    }
    for (k = 0; k < 2u; k++) {           /* the range: the first key's note, the last's */
        int n = lo + (k ? (int)MO_NK - 1 : 0);
        t[0] = 0;
        if (n >= 0 && n <= 127) {
            text_cat(t, NOTE_NAME[n % 12]);
            int_text(n / 12 - 1, t + strlen_(t));
        }
        text_t(k ? MR - text_tw(&FONT_XS, t, 1) : ML, 79, &FONT_XS, t, C_MIST, 1);
    }
}
/* the three hands on MIDI: TRACK MIDI, B its CHANNEL, C RETURN (card #169: the computer's audio back, its % small; the
 * one turned bright, the others dim; the SMK-37: TRACK's KNOB BANK in its key, the others their knobs' badges, as
 * footer's) */
static void mout_hands(void)
{
    static const char *const LB[3] = {"TRACK", "CHANNEL", "RETURN"};
    static const char BG[3] = {CN_BADGE_SELECT, CN_BADGE_PRESETS, CN_BADGE_ALGO};
    char v[3][8];
    int32_t w[3], tr = 1, bx, x0;
    uint32_t i, lit = mout_big() ? (mout.at_p == K_MO_CH ? 2u : 4u) : overlay_on() ? 1u : 7u;
    v[0][0] = 0;
    text_cat(v[0], "MIDI");
    mout_text(K_MO_CH, v[1]);
    v[2][0] = 0;
    int_text((int32_t)mout.ret, v[2]);
    for (;;) {
        for (i = 0; i < 3u; i++)
            w[i] = BADGE_W + text_tw(&FONT_XS, LB[i], tr);
#if PLAT_SMK37
        w[0] -= BADGE_W;
#endif
        if (w[0] + w[1] + w[2] + 12 <= MR - ML || tr == 0)
            break;
        tr = 0;
    }
    bx = ML + w[0] + (MR - w[2] - (ML + w[0]) - w[1]) / 2;
    for (i = 0; i < 3u; i++) {
        int on = (int)(lit >> i & 1u);
        uint16_t lc = mix565(C_BG, C_MIST, on ? 32 : 16), vc = mix565(C_BG, C_FOG, on ? 32 : 13);
        x0 = i == 0 ? ML : i == 1u ? bx : MR - w[2];
#if PLAT_SMK37
        if (i == 0) {                    /* (KNOB BANK's key above TRACK) */
            hand_cap(ML, 178, &FONT_T, CN_KBANK, mix565(C_BG, C_LAMP, on ? 32 : 16));
            text_t(x0, 192, &FONT_XS, LB[i], lc, tr);
        } else
#endif
        {
            badge(x0 + 7, 199, BG[i], 0);
            text_t(x0 + BADGE_W, 192, &FONT_XS, LB[i], lc, tr);
        }
        if (i == 2u) {                   /* (RETURN: the number, its % small after it) */
            int32_t uw = 4 + text_w(&FONT_XS, "%"), xn = MR - uw - text_w(&FONT_M, v[i]);
            cv_text(cv_text(xn, 207 - oy, &FONT_M, v[i], vc) + 4, 207 + (int32_t)FONT_M.h - (int32_t)FONT_XS.h - 1 - oy,
                    &FONT_XS, "%", mix565(C_BG, C_MIST, on ? 32 : 16));
            continue;
        }
        cv_text(i == 0 ? ML : 120 - text_w(&FONT_M, v[i]) / 2, 207 - oy, &FONT_M, v[i], vc);
    }
}
#endif

/* ARP's strip: the arpeggio's notes in the order they play, a bar each as tall as it is high, the one sounding bright; off,
 * empty outlines */
static void arp_scope(int bs)            /* (bs: 0 GLINT's, 1 the bass's, 2 MIDI's) */
{
    const arp_t *a = bs ? &barp : &arp;
    uint16_t c = bs ? C_LAMP : C_ICE;
    int on = ways_on(bs ? 2u : 1u, SQT_ARP), sounding = a->sounding >= 0;
#if FRS_MIDI_OUT
    if (bs == 2) {
        a = &marp;
        c = C_MIDI_TRACK;
        on = ways_on(T_MIDI, SQT_ARP);
        sounding = ma.note[0] >= 0;      /* (its note out on GATE's time: card #172) */
    }
#endif
    uint32_t n = on && a->pn ? (a->pn > 16u ? 16u : a->pn) : 0u, i, s = n ? n : 4u;
    int32_t lo = 127, hi = 0, w = (MR - ML) / (int32_t)(s < 8u ? 8u : s), bot = 88;
    static const int8_t OUT[4] = {10, 18, 26, 18};
    for (i = 0; i < n; i++) {
        lo = a->play[i] < lo ? a->play[i] : lo;
        hi = a->play[i] > hi ? a->play[i] : hi;
    }
    hline(ML, MR, bot + 1, C_STEEL);
    for (i = 0; i < s; i++) {
        int32_t x = ML + (int32_t)i * w, h = n ? 10 + (a->play[i] - lo) * 34 / (hi - lo > 0 ? hi - lo : 1) : OUT[i], y;
        if (!n) {
            for (y = bot - h; y <= bot; y += 2) {
                bl(x, y, C_SLATE, 24);
                bl(x + w - 7, y, C_SLATE, 24);
            }
            hline(x, x + w - 7, bot - h, C_STEEL);
            continue;
        }
        cv_rect(x, bot - h + 1 - oy, w - 6, h, sounding && a->src == a->play[i] ? c : mix565(C_BG, c, 8));
    }
}

/* DRONE SEQ's strip: a column a step, the step's notes at their heights, a tie carrying the one before on; only its SEQ
 * LENGTH's steps, the scale by blocks of four as the others'; the step playing lit; STEP's underlined on SEQ II */
static void dseq_scope(void)
{
    uint32_t len = st.v[P_DQ_LEN] + 1u, cur = st.v[P_DQ_STEP] % SC_DSEQ, cols = (len + 3u) / 4u * 4u, i, j;
    int32_t lo = 127, hi = 0, top = 42, bot = 86, on = st.v[P_DQ_ON] != 0;
    const uint8_t *last = 0;
    for (i = 0; i < len; i++)
        for (j = 0; j < DQ_NOTES && dnote[i][j] && dnote[i][j] != DQ_TIE; j++) {
            lo = dnote[i][j] < lo ? dnote[i][j] : lo;
            hi = dnote[i][j] > hi ? dnote[i][j] : hi;
        }
    if (hi < lo) {
        lo = 48;
        hi = 72;
    }
    if (hi - lo < 24) {
        int32_t m = (hi + lo) / 2;
        lo = m - 12;
        hi = m + 12;
    }
    hline(ML, ML + (int32_t)(len * (uint32_t)(MR - ML) / cols), bot + 2, C_STEEL);
    for (i = 0; i < len; i++) {
        int32_t x0 = ML + (int32_t)(i * (uint32_t)(MR - ML) / cols), x1 = ML + (int32_t)((i + 1u) * (uint32_t)(MR - ML) / cols);
        int in = on && i < len, play = in && dq.run && dq.pos == (int32_t)i, tie = dnote[i][0] == DQ_TIE;
        uint16_t c = play ? C_WHITE : in ? C_FOG : C_SLATE;
        const uint8_t *q = tie ? last : dnote[i];
        if (play)
            cv_rect(x0 + 1, top - 2 - oy, x1 - x0 - 2, bot - top + 3, mix565(C_BG, C_FOG, 3));
        if (dnote[i][0] && !tie)
            last = dnote[i];
        else if (!tie)
            last = 0;
        bl(x0, bot + 1, C_SLATE, 32);
        bl(x0, bot + 3, C_SLATE, 32);
        for (j = 0; q && j < DQ_NOTES && q[j] && q[j] != DQ_TIE; j++) {
            int32_t y = bot - ((int32_t)q[j] - lo) * (bot - top) / (hi - lo);
            hline(tie ? x0 : x0 + 2, x1 - 2, y, c);
        }
        if (i == cur && fm.page == PG_DSEQ2 && st.v[P_DQ_REC] != 2u)
            cv_rect(x0 + 1, bot + 5 - oy, x1 - x0 - 2, 2, C_LAMP);
    }
}

/* the SEQ pages and the arpeggios': the selected track's STACK (what holding SEQ turns), on or off, and how to turn
 * it, centred at the foot of the screen, a little dimmer than a value (amber ON, mist OFF) */
static void stack_tag(void)
{
    int on = st.v[P_KY_DR_STACK + 4u * st.v[P_KB]] != 0;
    const char *w = on ? "STACK ON (HOLD SEQ)" : "STACK OFF (HOLD SEQ)";
    text_c(120, 224, &FONT_XS, w, mix565(C_BG, on ? C_LAMP : C_MIST, 25), 1);   /* (above ANCHOR's frame) */
    ui.stack = (uint8_t)(on ? 2 : 1);
}

/* KEYS' strip: an octave of keys, what a key does now. The scale's notes dotted with HARMONY ON (none: chromatic); with
 * CHORD, the notes of the chord on the root, lit; a solid outline for LATCH, dotted for HOLD (GLINT: LATCH only on ARP,
 * ARP II's, card #143); NOTES or CHORDS for what STACK piles up. MIDI's (card #194): its HARMONY and NOTES, HOLD */
static void keys_scope(void)
{
    static const uint8_t WH[7] = {0, 2, 4, 5, 7, 9, 11}, BL[5] = {1, 3, 6, 8, 10};
    uint32_t t = st.v[P_KB], k;
    const uint8_t *v = &st.v[P_KY_DR_HARM + 4u * t];
    int why = notes_why((int)(P_KY_DR_NOTES + 4u * t)) != 0;
    int latch = t == 1u ? st.v[P_SQ_TYPE] == SQT_ARP && arp.latch : v[2] != 0;
    uint16_t bits, c = track_col();
    int r = st.v[P_ROOT] % 12, chord;
    chord_t ch;
    int root;
    uint32_t lit12 = 0;
    const int32_t x0 = 62, w = 16, y0 = 42, h = 44, x1 = x0 + 7 * w;
    int32_t x, y, i;
#if FRS_MIDI_OUT
    uint8_t mv[4];
    if (mout.sel || st.lead) {           /* (MIDI's, the LEAD's: their HARMONY and NOTES, HOLD) */
        uint32_t ni = mout.sel ? MD_KNOTES : MD_LNOTES;
        mv[0] = md[ni - 1u];
        mv[1] = md[ni];
        mv[2] = mv[3] = 0;
        v = mv;
        why = md_notes_why(ni) != 0;
        latch = 0;
    }
#endif
    bits = v[0] ? SCALE_BITS[st.v[P_SCALE] % NSCALES] : 0xFFFu;
    chord = v[0] && v[1] && !why;
    chord_build(60 + r, st.v, &ch, &root);
    for (i = 0; chord && i < (int32_t)ch.k; i++)
        lit12 |= 1u << ((ch.n[i] % 12 + 12) % 12);
    for (k = 0; k < 7u; k++) {
        x = x0 + (int32_t)k * w;
        if (k)
            for (y = y0 + 1; y < y0 + h; y++)
                bl(x, y, C_SLATE, 16);
        if (lit12 >> WH[k] & 1u)
            cv_rect(x + 3, y0 + h - 14 - oy, w - 5, 10, c);
        else if (v[0] && (bits >> ((WH[k] - r + 12) % 12) & 1u))
            cv_rect(x + 7, y0 + h - 9 - oy, 3, 3, C_MIST);
    }
    for (k = 0; k < 5u; k++) {
        static const uint8_t AT[5] = {1, 2, 4, 5, 6};
        x = x0 + (int32_t)AT[k] * w - 5;
        cv_rect(x, y0 + 1 - oy, 10, h / 2 + 4, C_STEEL);
        if (lit12 >> BL[k] & 1u)
            cv_rect(x + 2, y0 + h / 2 - 7 - oy, 6, 8, c);
        else if (v[0] && (bits >> ((BL[k] - r + 12) % 12) & 1u))
            cv_rect(x + 4, y0 + h / 2 - 3 - oy, 3, 3, C_MIST);
    }
    for (x = x0; x <= x1; x++)           /* LATCH: the outline solid; HOLD: dotted */
        if (latch || !((x - x0) & 2)) {
            bl(x, y0, c, 28);
            bl(x, y0 + h, c, 28);
        }
    for (y = y0; y <= y0 + h; y++)
        if (latch || !((y - y0) & 2)) {
            bl(x0, y, c, 28);
            bl(x1, y, c, 28);
        }
    text_t(ML, y0 + 2, &FONT_T, latch ? "LATCH" : "HOLD", C_MIST, 1);
    if (v[3])
        text_t(ML, y0 + 14, &FONT_T, v[1] && chord ? "CHORDS" : "NOTES", C_MIST, 1);
}

static void keycap(int32_t xr, int32_t y, const char *s, int on, int here);
/* the flow's foot: SAVE, what it does next, and FX, back; only those lit (app.c) */
static void flow_foot(const char *next)
{
#if PLAT_SMK37                           /* (the SMK-37: the pads' words in the header, pad_hint) */
    (void)next;
    return;
#endif
    keycap(ML + text_tw(&FONT_B, CN_SEL, 1) + 15, 204, CN_SEL, 0, 0);
    text_t(ML + text_tw(&FONT_B, CN_SEL, 1) + 25, 209, &FONT_XS, next, C_MIST, 1);
    keycap(MR - text_tw(&FONT_XS, "BACK", 1) - 10, 204, CN_FX, 0, 0);
    text_r(MR, 209, &FONT_XS, "BACK", C_MIST, 1);
}

/* SAVE's first page: K1, LOAD or SAVE, two tiles, the one chosen framed in the track's colour */
static void save_tiles(void)
{
    uint32_t i;
    uint16_t c = track_col();
#if PLAT_SMK37                           /* (the SMK-37: no K1, its pads 1 and 2: LOAD in blue at the left, SAVE in emerald
                                          * at the right, as the pads sit) */
    for (i = 0; i < 2u; i++) {
        int32_t x = ML + (int32_t)i * 110, w = 102, y = 72, h = 76;
        uint16_t pc = i ? C_PADSAVE : C_PADLOAD;
        cv_rect(x, y - oy, w, h, mix565(C_BG, pc, 4));
        hline(x, x + w - 1, y, pc);
        hline(x, x + w - 1, y + h - 1, pc);
        cv_rect(x, y - oy, 1, h, pc);
        cv_rect(x + w - 1, y - oy, 1, h, pc);
        text_c(x + w / 2, y + 28, &FONT_M, i ? "SAVE" : "LOAD", C_WHITE, 1);
    }
    (void)c;
    return;
#endif
    badge(ML + 7, 56, '1', 1);
    for (i = 0; i < 2u; i++) {
        int32_t x = ML + (int32_t)i * 110, on = (int32_t)(i == 0u) == sv.load, w = 102, y = 72, h = 76;
        cv_rect(x, y - oy, w, h, on ? mix565(C_BG, c, 4) : C_BG);
        hline(x, x + w - 1, y, on ? c : C_STEEL);
        hline(x, x + w - 1, y + h - 1, on ? c : C_STEEL);
        cv_rect(x, y - oy, 1, h, on ? c : C_STEEL);
        cv_rect(x + w - 1, y - oy, 1, h, on ? c : C_STEEL);
        text_c(x + w / 2, y + 28, &FONT_M, i ? "SAVE" : "LOAD", on ? C_WHITE : C_SLATE, 1);
    }
}

/* INTO's words: a slot and what is in it; for a preset NEW, or the player's it replaces */
static void into_text(char *t)
{
    t[0] = 0;
    if (!sv.what) {
        char nt[SC_LONG + 1];
        t[0] = (char)('0' + (sv.into + 1u) / 10u);
        t[1] = (char)('0' + (sv.into + 1u) % 10u);
        t[2] = ' ';
        t[3] = 0;
        if ((scn.used >> sv.into & 1u) || sv.into < NFACTORY) {
            text_cat(t, scene_name(sv.into, nt));
        } else {
            text_cat(t, "EMPTY");
        }
    } else if (!sv.into) {
        text_cat(t, "NEW");
    } else {
        up_name(sv.what - 1u, sv.into - 1u, t);
    }
}

static void save_what(void)
{
    static const char *const W[4 + FRS_LEAD] = {"SCENE", "DRONE PRESET", "GLINT PRESET", "BASS PRESET",
#if FRS_LEAD
                                                "LEAD PRESET"
#endif
    };
    char t[SC_LONG + 8];
    badge(ML + 7, 49, '1', 1);
    text_t(ML + BADGE_W, 42, &FONT_XS, "WHAT", C_MIST, 1);
    text_t(ML, 58, &FONT_M, W[sv.what % (4u + FRS_LEAD)], C_FOG, 0);
    badge(ML + 7, 113, '2', 1);
    text_t(ML + BADGE_W, 106, &FONT_XS, "INTO", C_MIST, 1);
    into_text(t);
    if (text_w(&FONT_M, t) <= MR - ML)
        cv_text(ML, 122 - oy, &FONT_M, t, C_FOG);
    else
        fit_text(ML, 123, MR - ML, t, C_FOG, 0, 0);
}


static void middle(float t)
{
#if defined PLAT_HOST && !defined PLAT_WEB
    ui_seen.mid = ui_look();             /* (the tests: drawnstale) */
#endif
    lroll.was = lroll.on;                /* (SCENES' long name rolls on only if this draws it again) */
    ui.semis = 0;                        /* (LOFI TAPE II's tones: drawn again below, or none) */
    ui.tonew = 0;
    lroll.on = 0;
    band(R2, 144);
    if (overlay_on()) {                  /* the value large, over a dimmed river */
        int p = fm.touched;
        river(R2, fm.page == PG_SON ? HZ_HOME : HZ, 0.35f, 0, t);
        if (fm.page == PG_SON)
            strata(0.5f);
#if FRS_MIDI_OUT
        uint32_t mk = mout_big() ? mout.at_p : 0u;   /* MIDI's: the track, or B's CHANNEL, C's OCTAVE (card #164) */
        const char *nm = mk ? mout_name(mk) : pd_name((uint32_t)p);
#else
        const uint32_t mk = 0;
        const char *nm = pd_name((uint32_t)p);
#endif
#if PLAT_SMK37
        if (hand_key() && !mk) {         /* (KNOB BANK's or the mod wheel's turn: its name in its key, not a badge) */
            int32_t w = text_tw(&FONT_XS, hand_key(), 1) + 7 + 6 + text_tw(&FONT_XS, nm, 3), x0 = 120 - w / 2;
            x0 += hand_cap(x0, 36, &FONT_XS, hand_key(), C_LAMP) + 6;
            text_t(x0, 36, &FONT_XS, nm, C_MIST, 3);
        } else
#endif
        {
            int32_t w = BADGE_W + text_tw(&FONT_XS, nm, 3), x0 = 120 - w / 2;
            if (mk)
                badge(x0 + 7, 43, mk == K_MO_CH ? CN_BADGE_PRESETS : CN_BADGE_ALGO, 0);
            else
                badge_of(x0 + 7, 43, p, fm.touched_enc);
            text_t(x0 + BADGE_W, 36, &FONT_XS, nm, C_MIST, 3);
        }
        if (p == P_KB && !mk) {          /* TRACK: its name, a step each track (DRONE .. LEAD, MIDI: card #164) */
            uint32_t n = PD[P_KB].max + 1u + FRS_MIDI_OUT, at = MOUT_SEL() ? n - 1u : st.v[P_KB];
#if FRS_MIDI_OUT
            if (mout.sel)
                text_c(120, 52, &FONT_L, "MIDI", C_FOG, 0);
            else
#endif
                value_big(120, 52, p, 200, &FONT_L, C_FOG, 1);
            steps(120 - (int32_t)(n - 1u) * 5, 91, 120, n, at);
#if FRS_MIDI_OUT
        } else if (mk) {
            char v[8];
            text_c(120, 52, &FONT_L, mout_text(mk, v), C_FOG, 0);
            if (mk == K_MO_CH)
                gauge(60, 92, 120, (float)mout.ch / 15.0f, C_LAMP);
            else if (mk == K_MO_RET)     /* (card #169) */
                gauge(60, 92, 120, (float)mout.ret / 100.0f, C_LAMP);
            else
                steps(95, 91, 52, 6u, (uint32_t)(mout_oct() + 3));
#endif
        } else {
            value_big(120, 52, p, 200, &FONT_L, C_FOG, 1);
            if (times_p(p))              /* (a factor: from its x1.00) */
                gauge_times(60, 92, 120, p, C_LAMP);
            else
                gauge(60, 92, 120, (float)pv_shown(p) / (float)PD[p].max, C_LAMP);
        }
    } else if (fm.page == PG_SON) {
        river(R2, HZ_HOME, 1.0f, 1, t);
        river_status();
        strata(1.0f);
    } else if (fm.page == PG_MIXER) {
        mixer();
    } else {                             /* an edit page: the river as a strip above the grid */
        if (fm.page == PG_MASTER)
            gr_meter();
        else if (fm.page >= PG_LFO1 && fm.page <= PG_LFO3T)
            lfo_scope(fm.page >= PG_LFO3 ? 2u : fm.page >= PG_LFO2 ? 1u : 0u);
        else if (fm.page >= PG_SEQ && fm.page <= PG_SEQ3)
            seq_scope(0);
        else if (fm.page == PG_BSEQ || fm.page == PG_BSEQ2 || fm.page == PG_BSEQ3)
            seq_scope(1);
        else if (fm.page == PG_DSEQ || fm.page == PG_DSEQ2 || fm.page == PG_DSEQ3)
            dseq_scope();
        else if (fm.page == PG_ARP || fm.page == PG_ARP2 || fm.page == PG_BARP || fm.page == PG_BARP2)
            arp_scope(fm.page == PG_BARP || fm.page == PG_BARP2);
#if FRS_MIDI_OUT
        else if (fm.page == PG_MOUT)
            mout_scope();
        else if (fm.page == PG_MARP || fm.page == PG_MARP2 || fm.page == PG_MARP3)   /* (its ARP and SEQ: card #169) */
            arp_scope(2);
        else if (fm.page == PG_MSEQ || fm.page == PG_MSEQ2 || fm.page == PG_MSEQ3)
            seq_scope(2);
        else if (fm.page == PG_MNOENV)
            no_midi();
        else if (fm.page == PG_KEYS && mout.sel)   /* (MIDI's own KEYS, card #194) */
            keys_scope();
#endif
#if FRS_LEAD
        else if (fm.page == PG_LNOARP || fm.page == PG_LNOSEQ)
            no_lead();
        else if (fm.page == PG_LADSR || fm.page == PG_LFENV)
            adsr_scope(0);
#endif
        else if (fm.page == PG_KEYS)
            keys_scope();
        else if (fm.page == PG_NOARP)
            no_arp();
        else if (fm.page == PG_BASS3 || fm.page == PG_GLINT3)
            adsr_scope(fm.page == PG_GLINT3);
        else if (fm.page == PG_FORME && shape_shown())   /* (DRONE SHAPE, its ATTACK SHAPE shown: the drones' envelope
                                                          * in place of the river, card #122) */
            adsr_scope(2);
        else if (fm.page == PG_EQ || fm.page == PG_EQ2)
            eq_scope();
        else if (fm.page == PG_FILTER)
            filter_scope();
        else if (fm.page == PG_CHOEUR2 || fm.page == PG_CHOEUR3)
            choir_scope(t);
        else if (fm.page == PG_TAPE || fm.page == PG_TAPE2) {
            tape_scope();
            if (fm.page == PG_TAPE2)
                tones_tag();
        }
        else if (fm.page == PG_ROUTING)
            routing_scope();
        else if (fm.page == PG_SCREEN) {   /* why one would turn ANIMATIONS (the user's words) */
            text_t(ML, 50, &FONT_XS, "REDUCE ANIMATIONS TO SAVE", C_MIST, 1);
            text_t(ML, 62, &FONT_XS, "CPU IN HEAVY SCENES", C_MIST, 1);
        }
        else if (fm.page != PG_SCENES && fm.page != PG_SAVE && fm.page != PG_SAVEAS)
            river(R2, 86, 0.45f, 0, t);
        if (fm.page == PG_SAVE) {
            save_tiles();
        } else if (fm.page == PG_SAVEAS) {
            save_what();
        } else if (fm.page == PG_SCENES) {
            scenes_list();
        } else {
            cell(ML, 100, shape_shown() ? (int)K_SHAPE : page_knob(fm.page, 0u));   /* (OCT- held on an
                                          * ENV page: K1 its ATTACK SHAPE) */
            cell(130, 100, page_knob(fm.page, 1u));
        }
    }
    if (oct_big()) {                     /* OCT+, OCT-: the octave large a moment, over the strip, the page as it is */
        char o[8];
        o[0] = 0;
        if (fm.octave > 0)
            text_cat(o, "+");
        int_text(fm.octave, o + strlen_(o));
        cv_rect(0, 33 - oy, 240, 62, C_BG);
        text_c(120, 36, &FONT_XS, "OCTAVE", C_MIST, 3);
        text_c(120, 50, &FONT_L, o, C_FOG, 0);
        steps(95, 90, 52, 6u, (uint32_t)(fm.octave + 3));
    }
    band_blit(R2);
}

static void footer(void)
{
    band(R3, 64);
    ui.stack = 0;
#if FRS_MIDI_OUT
    if ((overlay_on() || fm.page == PG_SON) && mout.sel) {
        mout_hands();
    } else
#endif
    if (overlay_on() || fm.page == PG_SON) {   /* the three hands, as the three encoders on the left sit: TRACK, its
                                              * PRESET (the bass's MODEL), its
                                              * TIMBRE, BRIGHT or FILTER */
        const uint32_t M[3] = {P_KB, track_preset(), track_algo()};   /* A B C, as the badges read */
        const char *lb[3];
        int32_t w[3], tr = 1, bx;
        uint32_t i;
#if PLAT_SMK37                           /* (the SMK-37's: TRACK's KNOB BANK and the ALGORITHM setting's mod wheel, not
                                          * the LEAD's, in a key over the label, no badge: Styves, card #111) */
        const char *const ky[3] = {CN_KBANK, 0, st.lead ? 0 : CN_MODW};
#endif
        for (i = 0; i < 3u; i++)
            lb[i] = PD[M[i]].name;
        for (;;) {                       /* the labels as they fit, closer if they must */
            for (i = 0; i < 3u; i++)
                w[i] = BADGE_W + text_tw(&FONT_XS, lb[i], tr);
#if PLAT_SMK37
            for (i = 0; i < 3u; i++)
                if (ky[i])
                    w[i] -= BADGE_W;
#endif
            if (w[0] + w[1] + w[2] + 12 <= MR - ML || tr == 0)
                break;
            tr = 0;
        }
        bx = ML + w[0] + (MR - w[2] - (ML + w[0]) - w[1]) / 2;   /* B: in the middle of what A and C leave */
        for (i = 0; i < 3u; i++) {
            int on = !overlay_on() || fm.touched == M[i] || !is_macro(fm.touched);
            uint16_t lc = mix565(C_BG, C_MIST, on ? 32 : 16), vc = mix565(C_BG, C_FOG, on ? 32 : 13);
            int32_t x0 = i == 0 ? ML : i == 1u ? bx : MR - w[2];
#if PLAT_SMK37
            if (ky[i]) {                 /* (its key above the label, at A's left, at C's right) */
                uint16_t kc = mix565(C_BG, C_LAMP, on ? 32 : 16);
                int32_t kw = text_tw(&FONT_T, ky[i], 1) + 7;
                hand_cap(i == 0 ? ML : MR - kw + 1, 178, &FONT_T, ky[i], kc);
                text_t(x0, 192, &FONT_XS, lb[i], lc, tr);
            } else
#endif
            {
                badge(x0 + 7, 199, i == 0u ? CN_BADGE_SELECT : i == 1u ? CN_BADGE_PRESETS : CN_BADGE_ALGO, 0);
                text_t(x0 + BADGE_W, 192, &FONT_XS, lb[i], lc, tr);
            }
            if (i == 0)
                value_big(ML, 207, (int)M[i], 44, &FONT_M, vc, 0);
            else if (i == 1)
                value_big(120, 207, (int)M[i], 92, &FONT_M, vc, 1);
            else
                value_big(MR, 207, (int)M[i], 60, &FONT_M, vc, 2);
        }
    } else if (fm.page == PG_SAVE || fm.page == PG_SAVEAS) {
        flow_foot("NEXT");
    } else if (fm.page == PG_MIXER) {
        mixer_footer();
    } else if (fm.page == PG_SCENES) {   /* MORPH, LOAD and K4's place, empty: three, narrower */
        cell_w(ML, 180, PAGES[PG_SCENES].p[1], 60);
        cell_w(ML + 75, 180, PAGES[PG_SCENES].p[2], 60);
        cell_w(ML + 150, 180, PAGES[PG_SCENES].p[3], 60);
#if FRS_LEAD
    } else if (fm.page == PG_NUAGE3) {   /* K4 the cloud's LEVEL, OCT- held its PAN (MIXER's way; admin #744), told
                                          * under the cells as STACK is (its gauges at 221: MIXER's key box there) */
        cell(ML, 180, page_knob(fm.page, 2u));
        cell(130, 180, cloud_pan_shown() ? P_PN_CLOUD : page_knob(fm.page, 3u));
        text_c(120, 224, &FONT_XS, "PAN: HOLD " CN_OCTDN " AND K4", mix565(C_BG, C_MIST, 25), 1);
#endif
    } else {
        cell(ML, 180, page_knob(fm.page, 2u));
        cell(130, 180, page_knob(fm.page, 3u));
        if (page_shape(fm.page) >= 0)    /* (an ENV page's ATTACK SHAPE, OCT- held: told under the cells as CLOUD III's
                                             * PAN is, card #122) */
            text_c(120, 224, &FONT_XS, "SHAPE: HOLD " CN_OCTDN " AND K1", mix565(C_BG, C_MIST, 25), 1);
#if FRS_LEAD
        if (!st.lead && (PAGES[fm.page].button == B_SEQ || (PAGES[fm.page].button == B_ARP && fm.page != PG_NOARP)))
#else
        if (PAGES[fm.page].button == B_SEQ || (PAGES[fm.page].button == B_ARP && fm.page != PG_NOARP))
#endif
            stack_tag();
    }
    band_blit(R3);
}

/* ---------------------------------------------------------- the logo --- */
#define LOGO_X ((240 - (int32_t)LOGO_W) / 2)
#define LOGO_Y 126                        /* its waterline at 146: some 60 % sky, the rest water */
#define C_SEA RGB(52, 128, 236)          /* the logo's lower half, deep in the water */

/* what is playing, for the logo's screen: how much sounds, how hard it is pressed, how loud it comes out */
typedef struct {
    float energy;                        /* the voices' levels together, 0 .. 1 */
    float press;                         /* the hardest pressed, 0 .. 1 */
    float out;                           /* the output's peak, 0 .. 1 */
    float speed;                         /* the granules' pace (MOTION, and more as more sounds) */
    int frozen;
} live_t;

static live_t live_now(int still)
{
    live_t L = {0.0f, 0.0f, 0.0f, 1.0f, 0};
    frasil_view_t v[FR_NV];
    uint32_t i;
    if (still)                           /* the splash, before the engine: quiet */
        return L;
    frasil_view(v);
    for (i = 0; i < FR_NV; i++)
        if (v[i].note >= 0) {
            L.energy += v[i].level * 0.4f;
            if (v[i].pressure > L.press)
                L.press = v[i].pressure;
        }
    {                                    /* and the bass */
        bass_view_t b;
        frasil_bass_view(&b);
        if (b.note >= 0) {
            L.energy += b.level * 0.4f;
            if (b.pressure > L.press)
                L.press = b.pressure;
        }
    }
    L.energy = br_clamp01(L.energy);
    L.press = br_clamp01(L.press);
    L.out = br_clamp01(frasil_out_level() * 1.6f);
    L.speed = (0.3f + 0.7f * (float)st.v[P_MOUVEMENT] / 127.0f) * (0.6f + 0.8f * L.energy);
    L.frozen = st.v[P_FREEZE];
    return L;
}

/* frasil drifting by in three depths (the far ones small and slow), more of them and faster as more sounds, the
 * near ones ice, warmed to amber by pressure; a haze along the logo's waterline breathing with the output */
static void granules(float t, const live_t *L)
{
    int32_t k, x, y, n = 100 + (int32_t)(110.0f * L->energy);
    int32_t cut = LOGO_Y + (int32_t)LOGO_CUT;
    int32_t ha = 6 + (int32_t)(18.0f * L->out);
    uint16_t hz = mix565(C_HAZE, C_ICE, (int32_t)(8.0f + 14.0f * L->out));
    for (y = cut - 9; y <= cut + 9; y++) {           /* the haze */
        int32_t d = y - cut, a = ha - (d < 0 ? -d : d) * ha / 10;
        if (a <= 0 || y < oy || y >= oy + (int32_t)cv_h)
            continue;
        for (x = 0; x < 240; x += 1 + (y & 1))
            bl(x, y, hz, a * ui.edge[x] >> 8);
    }
    n = n * (cut - 6) / 240;             /* the sky alone: as dense as they were over the whole screen */
    for (k = 0; k < n; k++) {
        uint32_t h = hsh(0xF5A51u, (uint32_t)k), h2 = hsh(0x1CEu, (uint32_t)k);
        int32_t depth = k % 3, a;
        float speed = (depth == 0 ? 5.0f : depth == 1 ? 11.0f : 21.0f) * (0.7f + 0.6f * (float)(h2 & 255u) / 255.0f);
        float fx = (float)(h & 1023u) * (280.0f / 1024.0f) + ui.gph * speed;
        float fy = (float)(h >> 6 & 1023u) * ((float)(cut - 10) / 1024.0f);   /* over the waterline */
        uint16_t c;
        y = (int32_t)(fy + sn(t * 0.05f + (float)(h2 >> 8 & 255u) * (1.0f / 256.0f)) * 3.0f);
        if (y < oy - 2 || y >= oy + (int32_t)cv_h + 2)   /* (another band's) */
            continue;
        fx -= 280.0f * (float)(int32_t)(fx * (1.0f / 280.0f));
        x = (int32_t)fx - 20;
        a = depth == 0 ? 6 : depth == 1 ? 12 + (int32_t)(h2 >> 4 & 3u) : 20 + (int32_t)(h2 >> 4 & 7u);
        a = (int32_t)((float)a * (0.7f + 0.6f * L->out));
        a = a * (x < 20 ? (x < 0 ? 0 : x) : x > 220 ? 240 - x : 20) / 20;   /* they appear and go at the sides */
        if (L->frozen)
            c = C_ICE;
        else if (depth == 2 && (h2 >> 20 & 255u) < (uint32_t)(L->press * 200.0f))
            c = C_LAMP;                  /* pressed: some of the near ones warm */
        else if (depth == 2)
            c = k % 2 ? C_ICE : C_FOG;
        else if (depth == 1 && (k & 7) == 1)
            c = C_ICE;
        else
            c = C_MIST;
        crystal(x, y, c, br_clamp01((float)a * (1.0f / 32.0f)),
                depth == 0 ? 0.9f : (float)(h2 >> 12 & 15u) * (1.0f / 16.0f), L->frozen, 0);
    }
}

/* the water under the logo's waterline, the screen's lower third: a body of night blue, lighter by the horizon, with
 * long slow swells of light coming through it toward us (closer together far off), a colour a row; on it the sky's
 * light, short strokes in perspective (fine by the horizon, longer near), each coming and going slowly, more of
 * them under the logo. Livelier as more comes out; FREEZE stills it, the strokes in ice. The logo's lower half is
 * drawn over it, in the water */
static void water_body(const live_t *L)   /* (first: written over the bare band, a colour a row) */
{
    int32_t cut = LOGO_Y + (int32_t)LOGO_CUT, x, y;
    int32_t y0 = cut + 1 > oy ? cut + 1 : oy, y1 = oy + (int32_t)cv_h < 240 ? oy + (int32_t)cv_h : 240;
    float sw = 1.0f + 0.5f * L->out;
    float g0 = (float)(C_BG >> 5 & 63u), gd = (float)(C_ICE >> 5 & 63u) - g0;
    float b0 = (float)(C_BG & 31u), bd = (float)(C_ICE & 31u) - b0;
    for (y = y0; y < y1; y++) {
        float z = (float)(y - cut) * (1.0f / (float)(240 - cut));
        float lv = 0.6f + 3.2f * (1.0f - z) * (1.0f - z) +
                   1.1f * sw * (1.0f - 0.5f * z) * sn(2.2f * fm_sqrtf(z) - ui.wph * 0.08f);
        uint32_t g, b;
        uint16_t c, *row = &cv_px[(uint32_t)(y - oy) * cv_w];
        if (lv < 0.0f)
            lv = 0.0f;
        /* from the background toward ice, lv of 32: green and blue each rounded on its own, red the background's
         * (a grain of two levels flickered as the swells went through, and red's coarse steps put mauve in it) */
        g = (uint32_t)(g0 + gd * lv * (1.0f / 32.0f) + 0.5f);
        b = (uint32_t)(b0 + bd * lv * (1.0f / 32.0f) + 0.5f);
        c = swap16((uint16_t)((C_BG & 0xF800u) | (g > 63u ? 63u : g) << 5 | (b > 31u ? 31u : b)));
        for (x = 0; x < 240; x++)
            row[x] = c;
    }
}

static void water(const live_t *L)
{
    int32_t cut = LOGO_Y + (int32_t)LOGO_CUT, x, r, j, i;
    int32_t y1 = oy + (int32_t)cv_h < 240 ? oy + (int32_t)cv_h : 240;
    for (r = 0; r < 14; r++) {           /* the strokes of light, a row at a time down to the near water */
        float z = ((float)r + 0.5f) * (1.0f / 14.0f);
        int32_t yr = cut + 3 + (int32_t)(75.0f * z * fm_sqrtf(z));
        float sway = 1.5f * z * sn(ui.wph * 0.11f + (float)yr * 0.031f);
        if (yr < oy || yr >= y1)
            continue;
        for (j = 0; j < 9; j++) {
            uint32_t h = hsh((uint32_t)(r * 31 + j), 0x5EAu), h2 = hsh((uint32_t)(r * 31 + j), 0x7EDu);
            int32_t len = 1 + (int32_t)(z * 7.0f) + (int32_t)(h & 1u);
            float vx = ((float)(h2 & 255u) * (1.0f / 255.0f) - 0.5f) * 2.0f;   /* drifting, a pixel or so a second */
            float fx = (float)(h >> 4 & 1023u) * (280.0f / 1024.0f) + ui.wph * vx, life, a, dx;
            uint16_t c = L->frozen || (h2 >> 16 & 3u) ? C_ICE : C_FOG;
            fx -= 280.0f * fm_floorf(fx * (1.0f / 280.0f));
            fx += sway - 20.0f;
            life = sn(ui.wph * (0.11f + 0.08f * (float)(h2 >> 8 & 255u) * (1.0f / 255.0f)) +
                      (float)(h >> 8 & 255u) * (1.0f / 256.0f));
            if (life <= 0.0f)            /* each is there half the time, fading in and out */
                continue;
            dx = (fx - 120.0f) * (1.0f / 110.0f);
            a = (8.0f + 10.0f * L->out + 4.0f * (1.0f - z)) * life * life * (0.3f + 0.7f * br_clamp01(1.0f - dx * dx));
            for (i = 0; i < len; i++) {  /* its ends softer */
                float e = len > 1 ? fm_fabsf(2.0f * (float)i / (float)(len - 1) - 1.0f) : 0.0f;
                x = (int32_t)fx + i;
                if (x >= 0 && x < 240)
                    bl(x, yr, c, (int32_t)(a * (1.0f - 0.6f * e) * (float)ui.edge[x] * (1.0f / 256.0f) + 0.5f));
            }
        }
    }
}

/* the logo, its lower half (under the water) tinted ice as the output rises */
static uint32_t logo_px(int32_t x, uint32_t y)   /* the logo's intensity at (x, y), 0..15 (0 outside) */
{
    uint32_t b;
    if (x < 0 || x >= (int32_t)LOGO_W)
        return 0;
    b = LOGO_PX[(y * LOGO_W + (uint32_t)x) >> 1];
    return (x & 1) ? (b & 15u) : (b >> 4);
}

/* the logo: over the waterline as it is; under it, in the water: blue, ice by the surface, deep sea blue at the bottom
 * (a little lighter as the output rises), and swaying slowly, the deeper the more (a pixel and a half at the bottom),
 * as a thing seen through moving water */
static void logo_draw(float out, float t)
{
    int32_t x, y, y0 = oy - LOGO_Y > 0 ? oy - LOGO_Y : 0;
    int32_t y1 = oy + (int32_t)cv_h - LOGO_Y < (int32_t)LOGO_H ? oy + (int32_t)cv_h - LOGO_Y : (int32_t)LOGO_H;
    for (y = y0; y < y1; y++) {          /* (this band's rows) */
        if (y <= (int32_t)LOGO_CUT) {
            for (x = 0; x < (int32_t)LOGO_W; x++) {
                uint32_t i = logo_px(x, (uint32_t)y);
                if (i)
                    bl(LOGO_X + x, LOGO_Y + y, C_FOG, (int32_t)(i * 32u / 15u));
            }
        } else {
            float d = (float)(y - (int32_t)LOGO_CUT) / (float)(LOGO_H - LOGO_CUT);
            float dx = (0.35f + 1.15f * d) * sn(t * 0.23f + (float)y * 0.045f), f, g;
            uint16_t under = mix565(C_ICE, C_SEA, (int32_t)((10.0f + 22.0f * d) * (1.0f - 0.35f * out)));
            uint8_t px[LOGO_W + 4u];     /* the row, unpacked, two bare pixels each side */
            float tt = t * 0.31f + (float)y * 0.07f;
            uint32_t ph;                 /* the light: turns, 16.16 */
            int32_t k = (int32_t)(-dx + 64.0f) - 64;      /* the row's sway: x - dx = x + k + f */
            f = -dx - (float)k;
            g = (1.0f - f) * (32.0f / 15.0f);
            ph = (uint32_t)((tt - (float)(int32_t)tt) * 65536.0f);
            f *= 32.0f / 15.0f;
            px[0] = px[1] = px[LOGO_W + 2u] = px[LOGO_W + 3u] = 0;
            for (x = 0; x < (int32_t)LOGO_W; x++)
                px[x + 2] = (uint8_t)logo_px(x, (uint32_t)y);
            for (x = 0; x < (int32_t)LOGO_W; x++) {
                const uint8_t *q = &px[x + k + 2];
                float a = (float)q[0] * g + (float)q[1] * f;
                if (a > 0.5f) {          /* light moving under */
                    a *= 0.86f + 0.1f * ui.sn[(ph + (uint32_t)x * 852u) >> 8 & 255u];
                    bl(LOGO_X + x, LOGO_Y + y, under, (int32_t)a);
                }
            }
        }
    }
}

/* the whole screen in two bands: the sky's granules and the water behind, the glints around, the site up in the sky,
 * the logo, the tagline under it, the author at the bottom. still: the splash, before anything plays */
static void logo_scene(float t, int still)
{
    live_t L = live_now(still);
    float dt = t - ui.lt;
    int32_t b;
    ui.lt = t;
    if (dt < 0.0f || dt > 0.25f)         /* (its first frame, or back to it after a while) */
        dt = 0.05f;
    if (L.frozen)
        t = ui.stillt;                   /* set: the granules stop where they are */
    else {                               /* their paces added up a frame at a time: t times a pace the sound changes
                                          * would leap ahead as a pad comes in, and race back as it fades */
        ui.gph += dt * L.speed;
        ui.wph += dt * (0.7f + 0.3f * L.speed);
    }
    for (b = 0; b < 2; b++) {
        band(b ? 144 : 0, b ? 96 : 144);
        water_body(&L);
        granules(t, &L);
        water(&L);
        if (!still)
            glints(0, 150, 1.0f);
        logo_draw(L.out, t);
        text_c(120, 176, &FONT_T, APP_TAGLINE, mix565(C_MIST, C_ICE, (int32_t)(6.0f + 12.0f * L.out)), 2);
        text_c(120, 44, &FONT_S, APP_SITE, C_FOG, 1);   /* the site: its River keeps and edits the scenes */
        text_c(120, 62, &FONT_T, APP_SITE_NOTE, C_MIST, 2);
        text_c(120, 218, &FONT_S, APP_AUTHOR, C_WHITE, 1);
        {                                /* the version, top right ("DEV" but for a release) */
            char v[16] = {0};
            if (APP_VERSION[0] >= '0' && APP_VERSION[0] <= '9')
                text_cat(v, "v");
            text_cat(v, APP_VERSION);
            text_r(MR, 10, &FONT_XS, v, C_MIST, 1);
        }
        band_lcd((uint32_t)oy);          /* (a viewer mirroring: in turning slices, as the pages' bands) */
    }
}

/* power-on, before the engine: the same, still */
void app_splash(void)
{
    uint32_t i;
    for (i = 0; i < 240u; i++) {
        float e = smooth01((float)((int32_t)i - ML) / 40.0f) * smooth01((float)(MR - (int32_t)i) / 40.0f);
        ui.edge[i] = (int32_t)(e * 256.0f);
    }
    logo_scene(0.0f, 1);
}

/* --------------------------------------------------------------- the help --- */
/* HOME held: what each control does, four to a page, in the panel's order; SELECT turns the pages, HOME closes it.
 * Each line: what it does, large; its control on the right (a key cap, or an encoder's badge); what it does held,
 * small, in amber, or the track it plays on, in the track's colour. The page's button ringed in ice, the modes that
 * are on (the keys not on drones, the latch) lit. Each control by its panel's name (controls.h) */
#if PLAT_SMK37
enum { H_BTN, H_ENC, H_GEST, H_KEY };    /* (H_KEY: the SMK-37's, a key's name, then its knob's badge b: card #111) */
#else
enum { H_BTN, H_ENC, H_GEST };
#endif
typedef struct {
    uint8_t kind, b;                     /* H_BTN: button b; H_ENC: badge b ('A', 'B', 'C', the SMK-37's '6', '5', '7', or 0:
                                          * OCT); H_GEST */
    const char *does, *control, *held;
} help_t;
#if PLAT_SMK37                           /* (no pressure on the SMK-37's keys: the swell ENV's, held, card #111; SCALE + KEY
                                          * closer, beside ADD A NOTE) */
#define HELP_SWELL {H_GEST, 0, "SWELL IT", "HOLD " CN_ENV, ""}
#define HELP_ADD {H_GEST, 0, "ADD A NOTE", CN_SEL "+KEY", "OVER WHAT IS HELD"}
#define HELP_TRACK {H_KEY, CN_BADGE_SELECT, "TRACK", CN_KBANK, CN_OCTDN " +: THE KEYS ALONE"}   /* (KNOB BANK, K6) */
#define HELP_ALGO {H_KEY, CN_BADGE_ALGO, "FILTER", CN_MODW, CN_GLO " +: MASTER FILTER"}   /* (the mod wheel, K7) */
#define HELP_SEL {H_BTN, B_SEL, "HARMONY", CN_SEL, "HOLD + KEY: ONE NOTE / + K: LFO AMOUNT"}   /* (NOTES: FADER BANK) */
#else
#define HELP_SWELL {H_GEST, 0, "SWELL IT", "PRESS IN", "HOLD THE KEY, PRESS HARDER"}
#define HELP_ADD {H_GEST, 0, "ADD A NOTE", CN_SEL " + KEY", "OVER WHAT IS HELD"}
#define HELP_TRACK {H_ENC, CN_BADGE_SELECT, "TRACK", CN_SELECT, CN_OCTDN " +: THE KEYS ALONE"}
#define HELP_ALGO {H_ENC, CN_BADGE_ALGO, "FILTER", CN_ALGO, CN_GLO " +: MASTER FILTER"}
#define HELP_SEL {H_BTN, B_SEL, "HARMONY", CN_SEL, "HOLD: NOTES / HOLD + K: LFO AMOUNT"}   /* (held alone: NOTES, card
                                                                                    * #194; + KEY: ADD A NOTE's) */
#endif
static const char *const HELP_TITLE[HELP_PAGES] = {"BUTTONS", "BUTTONS", "BUTTONS", "ENCODERS", "KEYS"};
static const help_t HELP[HELP_PAGES][4] = {
    {{H_BTN, B_FX, "GENERATIVE FX", CN_FX, "AGAIN: CLOUD, PUMP / HOLD: FREEZE"},
     HELP_SEL,
     {H_BTN, B_ENV, "ENVELOPE", CN_ENV, "HOLD: SWELL"}, {H_BTN, B_LFO, "LFO 1, 2, 3", CN_LFO, "AGAIN: NEXT PAGE / HOLD + K: ROUTE"}},
    {{H_BTN, B_EDIT, "SOUND PAGES", CN_EDIT, "HOLD + KEY: JUMP / " CN_OCTDN " +: COMPARE"},
     {H_BTN, B_GLO, "GLOBAL", CN_GLO, "AGAIN: MIDI / HOLD + CC: LEARN"},
     {H_BTN, B_HOME, "KEYS, MIXER", CN_HOME, "AGAIN: NEXT PAGE / HOLD: HELP"},
     {H_BTN, B_SAVE, "LOAD, SAVE", CN_SAVE, "HOLD + KEY: LOAD / + " CN_REC ": STORE"}},
    {{H_BTN, B_ARP, "ARPEGGIO", CN_ARP, "HOLD: LATCH"}, {H_BTN, B_SEQ, "SEQUENCE", CN_SEQ, "HOLD: STACK"},
     {H_BTN, B_PLAY, "START, STOP", CN_PLAY, "TWICE OR HOLD: RELEASE ALL"},
     {H_BTN, B_REC, "RECORD", CN_REC, "AGAIN: STEP, OFF / HOLD: METRONOME"}},
    {HELP_TRACK, {H_ENC, CN_BADGE_PRESETS, "PRESET", CN_PRESETS, CN_OCTDN " +: PICK UNHEARD"}, HELP_ALGO,
     {H_ENC, 0, "OCTAVE", CN_OCTDN_S " " CN_OCTUP_S, "BOTH: RESET"}},
    {{H_GEST, 0, "LIGHT A DRONE", "TAP", "A CHORD WITH HARMONY"}, {H_GEST, 0, "LET IT GO", "TAP AGAIN", ""},
     HELP_SWELL, HELP_ADD},
};

static void keycap(int32_t xr, int32_t y, const char *s, int on, int here)   /* right edge xr */
{
    int32_t w = text_tw(&FONT_B, s, 1) + 16, x = xr - w + 1;
    uint16_t edge = here || on ? C_ICE : C_SLATE;
    if (on)
        cv_rect(x, y - oy, w, 22, C_ICE);
    hline(x + 1, x + w - 2, y, edge);
    hline(x + 1, x + w - 2, y + 21, edge);
    cv_rect(x, y + 1 - oy, 1, 20, edge);
    cv_rect(x + w - 1, y + 1 - oy, 1, 20, edge);
    text_t(x + 8, y + 4, &FONT_B, s, on ? C_BG : here ? C_ICE : C_FOG, 1);
}

static void help_screen(void)
{
    int32_t b, i;
    uint32_t pg = fm.help_page % HELP_PAGES;
    for (b = 0; b < 2; b++) {
        band(b ? 144 : 0, b ? 96 : 144);
        {                                /* the header: HELP, the page's name, its dots, SELECT's badge */
            int32_t x = title("HELP", 0), k;
            text_t(x + 8, 9, &FONT_XS, HELP_TITLE[pg], C_MIST, 1);
            for (k = 0; k < HELP_PAGES; k++)
                cv_rect(MR - (HELP_PAGES - 1 - k) * 8 - 3, 13 - oy, k == (int32_t)pg ? 5 : 3, k == (int32_t)pg ? 5 : 3,
                        k == (int32_t)pg ? C_ICE : C_SLATE);
            badge(MR - HELP_PAGES * 8 - 10, 15, CN_BADGE_SELECT, 0);
            hline(ML, MR, 30, C_STEEL);
            if (!b)
                batt_draw(C_BG, C_WHITE);
        }
        for (i = 0; i < 4; i++) {
            const help_t *h = &HELP[pg][i];
            int32_t y = 36 + i * 50;
            text_t(ML, y + 3, &FONT_M, h->does, C_WHITE, 0);
            if (h->held[0])              /* (closer if it must: inside the margin) */
                text_t(ML, y + 30, &FONT_XS, h->held, C_LAMP, text_tw(&FONT_XS, h->held, 1) <= MR - ML ? 1 : 0);
            if (h->kind == H_BTN) {
                int on = (h->b == B_REC && rec_any()) ||
                         (h->b == B_ARP && (st.bass || st.glint) && (st.bass ? barp.latch : arp.latch)) || (h->b == B_FX && st.v[P_FREEZE]);
                keycap(MR, y + 4, h->control, on, PAGES[fm.page].button == h->b);
#if PLAT_SMK37
            } else if (h->kind == H_KEY) {   /* (its key, then its knob's badge) */
                badge_r(MR - 10, y + 15, (char)h->b, 0, 9.0f);
                keycap(MR - 26, y + 4, h->control, 0, 0);
#endif
            } else if (h->kind == H_ENC && h->b) {
                badge_r(MR - 10, y + 15, (char)h->b, 0, 9.0f);
                text_r(MR - 26, y + 9, &FONT_XS, h->control, C_MIST, 1);
            } else {
                keycap(MR, y + 4, h->control, 0, 0);
            }
            if (i < 3)
                hline(ML, MR, y + 47, C_STEEL);
        }
        cl_band(oy);
        cv_blit(0, (uint32_t)oy);
    }
}

/* ------------------------------------------------------------ a pop-up --- */
/* app.c's popup: where it comes from, small, by a light in its colour; the title large, in lamp (a warning) or ice
 * (done); the waterline, brighter in the middle; what to do; and its one way out, a button framed in its colour, in
 * the middle: OK, SEL's key in it */
static void popup_screen(void)
{
    int32_t b, i, x, k;
    uint16_t c = pop.kind == POP_DONE ? C_ICE : C_LAMP;
    int32_t wk = text_tw(&FONT_B, CN_SEL, 1) + 16, w = 20 + text_tw(&FONT_B, "OK", 2) + 14 + wk + 8, h = 38;
    int32_t x0 = 120 - w / 2, y0 = 190;
    for (b = 0; b < 2; b++) {
        band(b ? 144 : 0, b ? 96 : 144);
        for (k = 0; k < 49; k++) {       /* the light: a round dot and its glow */
            int32_t dx = k % 7 - 3, dy = k / 7 - 3, d = dx * dx + dy * dy;
            bl(ML + 3 + dx, 46 + dy, c, d <= 2 ? 32 : d <= 5 ? 12 : d <= 9 ? 4 : 0);
        }
        text_t(ML + 13, 40, &FONT_XS, pop.kicker, C_MIST, 1);
        text_t(ML, 58, &FONT_L, pop.title, c, 1);
        for (x = ML; x <= MR; x++) {     /* the waterline */
            int32_t d = x - 120 < 0 ? 120 - x : x - 120;
            bl(x, 102, C_FOG, 22 - d * 18 / (MR - 120));
        }
        for (i = 0; i < 3; i++)
            if (pop.line[i][0])
                text_t(ML, 116 + i * 21, &FONT_S, pop.line[i], C_FOG, 0);
        cv_rect(x0 + 1, y0 + 1 - oy, w - 2, h - 2, mix565(C_BG, c, 3));   /* the button: lit a little, framed */
        for (k = 0; k < 2; k++) {
            hline(x0 + 1 + k, x0 + w - 2 - k, y0 + k, c);
            hline(x0 + 1 + k, x0 + w - 2 - k, y0 + h - 1 - k, c);
            cv_rect(x0 + k, y0 + 1 + k - oy, 1, h - 2 - 2 * k, c);
            cv_rect(x0 + w - 1 - k, y0 + 1 + k - oy, 1, h - 2 - 2 * k, c);
        }
        text_t(x0 + 20, y0 + 11, &FONT_B, "OK", C_WHITE, 2);
#if PLAT_SMK37
        pad_hint(0);                     /* (pad 2, not SEL) */
#else
        keycap(x0 + w - 9, y0 + 8, CN_SEL, 0, 0);
#endif
        cl_band(oy);
        cv_blit(0, (uint32_t)oy);
    }
}

/* fm1-base's restore question (app.h APP_BACKUP_ASK), as a pop-up: RESTORE FROM USB by a lamp light, RESTORE? large,
 * what it does; its two answers side by side as on the panel: NO, FX's key (at the left, the panel's first), YES, SEL's,
 * framed in ice */
static void ask_button(int32_t x0, int32_t y0, int32_t w, const char *word, const char *key, uint16_t c)
{
    int32_t k, h = 38;
    cv_rect(x0 + 1, y0 + 1 - oy, w - 2, h - 2, mix565(C_BG, c, 3));
    for (k = 0; k < 2; k++) {
        hline(x0 + 1 + k, x0 + w - 2 - k, y0 + k, c);
        hline(x0 + 1 + k, x0 + w - 2 - k, y0 + h - 1 - k, c);
        cv_rect(x0 + k, y0 + 1 + k - oy, 1, h - 2 - 2 * k, c);
        cv_rect(x0 + w - 1 - k, y0 + 1 + k - oy, 1, h - 2 - 2 * k, c);
    }
    text_t(x0 + 13, y0 + 11, &FONT_B, word, C_WHITE, 2);
#if PLAT_SMK37                           /* (the pads', in the header: pad_hint) */
    (void)key;
#else
    keycap(x0 + w - 8, y0 + 8, key, 0, 0);
#endif
}

void app_backup_ask_screen(void)
{
    int32_t b, x, k;
    for (b = 0; b < 2; b++) {
        band(b ? 144 : 0, b ? 96 : 144);
        for (k = 0; k < 49; k++) {       /* the light */
            int32_t dx = k % 7 - 3, dy = k / 7 - 3, d = dx * dx + dy * dy;
            bl(ML + 3 + dx, 46 + dy, C_LAMP, d <= 2 ? 32 : d <= 5 ? 12 : d <= 9 ? 4 : 0);
        }
        text_t(ML + 13, 40, &FONT_XS, "RESTORE FROM USB", C_MIST, 1);
        text_t(ML, 58, &FONT_L, "RESTORE?", C_LAMP, 1);
        for (x = ML; x <= MR; x++) {     /* the waterline */
            int32_t d = x - 120 < 0 ? 120 - x : x - 120;
            bl(x, 102, C_FOG, 22 - d * 18 / (MR - 120));
        }
        text_t(ML, 116, &FONT_S, "IT REPLACES ALL SCENES,", C_FOG, 0);
        text_t(ML, 137, &FONT_S, "THE SETTINGS AND ITS PRESETS.", C_FOG, 0);
        ask_button(ML - 2, 190, 96, "NO", CN_FX, C_SLATE);
        ask_button(MR - 108, 190, 112, "YES", CN_SEL, C_ICE);
#if PLAT_SMK37
        pad_hint(1);
#endif
        cv_blit(0, (uint32_t)oy);
    }
}

/* Learn's START (app.c learn_*): WELCOME TO by an ice light, LEARN MODE large, the waterline, in the middle; nothing to
 * answer: up until a button, a key or a knob, which closes it alone (app.c welcome_buttons, admin #881) */
static struct {
    uint8_t on, drawn;
} welcome;

static void welcome_screen(void)
{
    int32_t b, x, k;
    for (b = 0; b < 2; b++) {
        band(b ? 144 : 0, b ? 96 : 144);
        for (k = 0; k < 49; k++) {       /* the light */
            int32_t dx = k % 7 - 3, dy = k / 7 - 3, d = dx * dx + dy * dy;
            bl(ML + 3 + dx, 94 + dy, C_ICE, d <= 2 ? 32 : d <= 5 ? 12 : d <= 9 ? 4 : 0);
        }
        text_t(ML + 13, 88, &FONT_XS, "WELCOME TO", C_MIST, 1);
        text_t(ML, 106, &FONT_L, "LEARN MODE", C_ICE, 1);
        for (x = ML; x <= MR; x++) {     /* the waterline */
            int32_t d = x - 120 < 0 ? 120 - x : x - 120;
            bl(x, 150, C_FOG, 22 - d * 18 / (MR - 120));
        }
        cl_band(oy);
        cv_blit(0, (uint32_t)oy);
    }
}

/* app.c's name: where it goes, small, by an ice light; the sixteen places of the name, the cursor's framed in ice; how
 * to write it (OCT- OCT+ the cursor, K4 the letters, K3 the digits); FX, and the one to store it, framed in ice: SEL for
 * STORE's (SAVE + REC, stored already), SAVE for the flow's. The SMK-37's: < > the cursor, then its knobs two by two in
 * their order (K1 letters, K2 digits, K3 a space, K4 clear: app.c name_input); its answers its pads', in the header */
static void name_screen(void)
{
    int32_t b, i, k, x;
    char t[SC_NAME + 16], ch[2] = {0, 0};
    int32_t w = text_tw(&FONT_B, "SAVE", 1) + 16 + 18, h = 38;
    int32_t two = nm.len > SC_NAME, y1 = two ? 59 : 63, chh = two ? 26 : 32, gy = two ? 4 : 7, dy = two ? 18 : 0;
    int32_t x0 = MR - w + 1, y0 = 188;
    t[0] = 0;
    if (nm.flow && sv.what) {
        static const char *const W[3 + FRS_LEAD] = {"DRONE PRESET", "GLINT PRESET", "BASS PRESET",
#if FRS_LEAD
                                                    "LEAD PRESET"
#endif
        };
        text_cat(t, W[(sv.what - 1u) % (3u + FRS_LEAD)]);
        if (!sv.into)
            text_cat(t, " NEW");
        else {
            k = (int32_t)strlen_(t);
            t[k] = ' ';
            t[k + 1] = (char)('0' + sv.into / 10u);
            t[k + 2] = (char)('0' + sv.into % 10u);
            t[k + 3] = 0;
        }
    } else if (nm.flow) {
        text_cat(t, "SCENE ");
        k = (int32_t)strlen_(t);
        t[k] = (char)('0' + (sv.into + 1u) / 10u);
        t[k + 1] = (char)('0' + (sv.into + 1u) % 10u);
        t[k + 2] = 0;
    } else {
        text_cat(t, "STORED IN ");
        t[10] = (char)('0' + (nm.slot + 1u) / 10u);
        t[11] = (char)('0' + (nm.slot + 1u) % 10u);
        t[12] = 0;
    }
    for (b = 0; b < 2; b++) {
        band(b ? 144 : 0, b ? 96 : 144);
        if (nm.flow) {                   /* the flow's: the header in the track's colour, what it stores under it */
            int32_t tw = track_tag_w();
            cv_rect(0, 0 - oy, 240, 32, band_col());
            title_at(ML, "NAME IT", 1);
#if PLAT_SMK37
            (void)tw;                    /* (the pads' words in its place) */
#else
            track_tag(MR - tw + 1);
#endif
            if (!b)
                batt_draw(band_col(), C_ONBAND);
            text_t(ML, 42, &FONT_XS, t, C_MIST, 1);
        } else {
            for (k = 0; k < 49; k++) {   /* the light */
                int32_t dx = k % 7 - 3, dy = k / 7 - 3, d = dx * dx + dy * dy;
                bl(ML + 3 + dx, 18 + dy, C_ICE, d <= 2 ? 32 : d <= 5 ? 12 : d <= 9 ? 4 : 0);
            }
            text_t(ML + 13, 12, &FONT_XS, t, C_MIST, 1);
            text_t(ML, 28, &FONT_M, "NAME IT", C_WHITE, 2);
        }
        for (i = 0; i < (int32_t)nm.len; i++) {   /* the places, 13 px each, sixteen a row (a scene's two, shorter, the
                                                   * controls lower): a line under each, the cursor's framed */
            int32_t cx = 16 + (i % (int32_t)SC_NAME) * 13, cy = y1 + (i / (int32_t)SC_NAME) * (chh + 3), cur = i == (int32_t)nm.cur, cw;
            ch[0] = nm.name[i];
            if (cur) {
                cv_rect(cx, cy - oy, 13, chh, mix565(C_BG, C_ICE, 4));
                hline(cx, cx + 12, cy - 1, C_ICE);
                hline(cx, cx + 12, cy + chh, C_ICE);
                cv_rect(cx - 1, cy - oy, 1, chh, C_ICE);
                cv_rect(cx + 13, cy - oy, 1, chh, C_ICE);
            } else {
                hline(cx + 2, cx + 10, cy + chh - 1, C_STEEL);
            }
            if (ch[0] != ' ') {          /* (bold: drawn twice) */
                cw = text_w(&FONT_B, ch) + 1;
                text_t(cx + 7 - cw / 2, cy + gy, &FONT_B, ch, cur ? C_ICE : C_WHITE, 0);
                text_t(cx + 8 - cw / 2, cy + gy, &FONT_B, ch, cur ? C_ICE : C_WHITE, 0);
            }
        }
#if PLAT_SMK37
        {
            static const char *const W[4] = {"LETTERS", "DIGITS", "SPACE", "CLEAR"};
            x = ML + text_tw(&FONT_B, "<", 1) + 15;
            keycap(x, 106 + dy, "<", 0, 0);
            x += 6 + text_tw(&FONT_B, ">", 1) + 16;
            keycap(x, 106 + dy, ">", 0, 0);
            text_t(x + 10, 111 + dy, &FONT_XS, "MOVE CURSOR", C_MIST, 1);
            for (k = 0; k < 4; k++) {    /* (K1 .. K4, two a row) */
                badge(ML + 7 + (k & 1) * 106, 147 + dy + (k >> 1) * 30, (char)('1' + k), 1);
                text_t(ML + 18 + (k & 1) * 106, 141 + dy + (k >> 1) * 30, &FONT_XS, W[k], C_MIST, 1);
            }
        }
#else
        x = ML + text_tw(&FONT_B, "OCT", 1) + 15;   /* every control, in knob order: OCT, or K1, the cursor */
        keycap(x, 106 + dy, "OCT", 0, 0);
        text_t(x + 8, 110 + dy, &FONT_B, "/", C_MIST, 0);
        badge(x + 29, 117 + dy, '1', 1);
        text_t(x + 41, 111 + dy, &FONT_XS, "MOVE CURSOR", C_MIST, 1);
        badge(ML + 7, 147 + dy, '2', 1);         /* K2 a space, K3 digits, K4 letters */
        x = text_t(ML + 18, 141 + dy, &FONT_XS, "SPACE", C_MIST, 1);
        badge(x + 16, 147 + dy, '3', 1);
        x = text_t(x + 27, 141 + dy, &FONT_XS, "DIGITS", C_MIST, 1);
        badge(x + 16, 147 + dy, '4', 1);
        text_t(x + 27, 141 + dy, &FONT_XS, "LETTERS", C_MIST, 1);
#endif
#if PLAT_SMK37                           /* (the SMK-37: its pads' words in the header: CANCEL and SAVE in the flow, OK
                                          * for STORE's) */
        pad_hint_as(pad_mode());
        (void)x0;
        (void)y0;
        (void)h;
#else
        x = text_t(ML, y0 + 13, &FONT_B, "CANCEL", C_MIST, 1) + 8;   /* FX cancels; SAVE stores: the main thing, framed */
        keycap(x + text_tw(&FONT_B, "FX", 1) + 15, y0 + 8, "FX", 0, 0);
        cv_rect(x0 + 1, y0 + 1 - oy, w - 2, h - 2, mix565(C_BG, C_ICE, 3));
        for (k = 0; k < 2; k++) {
            hline(x0 + 1 + k, x0 + w - 2 - k, y0 + k, C_ICE);
            hline(x0 + 1 + k, x0 + w - 2 - k, y0 + h - 1 - k, C_ICE);
            cv_rect(x0 + k, y0 + 1 + k - oy, 1, h - 2 - 2 * k, C_ICE);
            cv_rect(x0 + w - 1 - k, y0 + 1 + k - oy, 1, h - 2 - 2 * k, C_ICE);
        }
        keycap(x0 + w - 9, y0 + 8, "SAVE", 0, 1);
#endif
        cl_band(oy);
        cv_blit(0, (uint32_t)oy);
    }
}

/* the grid of names (app.c): the header in the track's colour, the setting's name and where it is, n / total; two columns
 * of ten, down the left one then down the right; the choice framed in ice (picked under OCT-, in lamp); a dash a page at
 * the foot */
static void round_box(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c)
{
    hline(x + 3, x + w - 4, y, c);
    hline(x + 3, x + w - 4, y + h - 1, c);
    cv_rect(x, y + 3 - oy, 1, h - 6, c);
    cv_rect(x + w - 1, y + 3 - oy, 1, h - 6, c);
    cv_rect(x + 1, y + 1 - oy, 2, 1, c);
    cv_rect(x + w - 3, y + 1 - oy, 2, 1, c);
    cv_rect(x + 1, y + h - 2 - oy, 2, 1, c);
    cv_rect(x + w - 3, y + h - 2 - oy, 2, 1, c);
    cv_rect(x + 1, y + 2 - oy, 1, 1, c);
    cv_rect(x + w - 2, y + 2 - oy, 1, 1, c);
    cv_rect(x + 1, y + h - 3 - oy, 1, 1, c);
    cv_rect(x + w - 2, y + h - 3 - oy, 1, 1, c);
}

/* an LFO's TARGET: each section a rounded box, column by column, from its name to its last */
#if FRS_LEAD                             /* (each section's colour, TGT_HEAD's; LEAD's three its rose; the LFOs' GLOBAL's) */
#define TGT_HC {C_FOG, C_FOG, C_FOG, C_FOG, C_ICE, C_ICE, C_LAMP, C_GLOB, C_GLOB, C_LEAD_TRACK, C_LEAD_TRACK, C_LEAD_TRACK, \
                C_GLOB}
#else
#define TGT_HC {C_FOG, C_FOG, C_FOG, C_FOG, C_ICE, C_ICE, C_LAMP, C_GLOB, C_GLOB, C_GLOB}
#endif
static void tgt_boxes(uint32_t first)
{
    static const uint16_t HC[] = TGT_HC;
    uint32_t c, r;
    for (c = 0; c < 2u; c++) {
        int32_t top = -1, last = -1;
        uint16_t col = C_FOG;
        for (r = 0; r <= NG_ROWS; r++) {
            int32_t sl = r < NG_ROWS ? TGT_SLOTS[first + c * NG_ROWS + r] : TH_NONE;
            if (sl < TH_NONE && top < 0) {
                top = (int32_t)r;
                col = HC[-sl - 2];
            }
            if (top >= 0 && sl >= 0)
                last = (int32_t)r;
        }
        if (top >= 0)
            round_box(6 + (int32_t)c * 114, 34 + top * 19, 112, (last - top + 1) * 19 + 4, mix565(C_BG, col, 11));
    }
}

static void grid_screen(void)
{
    int tg = PD[ng.p].fmt == F_LTGT;     /* (an LFO's TARGET: its pages by section, TGT_SLOTS) */
    uint32_t p = ng.p, n = list_n(p), page = tg ? tgt_page(ng.v) : ng.v / NG_PER;
    uint32_t pages = tg ? NG_TPAGES : (n + NG_PER - 1u) / NG_PER, i, first = page * NG_PER, at_t = 0;
    int none = p == P_DR_PRESET || p == P_EQ_PRESET || PD[p].fmt == F_LTGT;   /* (its first: no choice, not counted) */
    uint16_t c = track_col(), fc = ng.pick ? C_LAMP : C_ICE;
    char t[24], at[12];
    int32_t b, x;
#if FRS_LEAD
    uint8_t lb[LDP_ALL];                 /* (LEAD's: the player's names read once a draw, not once a row) */
    int lr = list_lead(p) && first + NG_PER > PD[p].max + 1u && ldp_read(lb);
#endif
    at[0] = 0;
    int_text((int32_t)ng.v + (none ? 0 : 1), at);
    text_cat(at, " / ");
    int_text((int32_t)n - (none ? 1 : 0), at + strlen_(at));
    for (b = 0; b < 2; b++) {
        band(b ? 144 : 0, b ? 96 : 144);
        cv_rect(0, 0 - oy, 240, 32, band_col());
        badge_on = band_col();
        if (ng.enc >= EN_K1)
            badge(ML + 6, 16, (char)('1' + ng.enc - EN_K1), 1);
        else
            badge(ML + 6, 16, ng.enc == EN_PRESET ? CN_BADGE_PRESETS : CN_BADGE_ALGO, 0);
        badge_on = 0;
        title_at(ML + BADGE_W, PD[p].name, 0);
        if (grid_asks()) {               /* (no delay: SEL says so; the SMK-37's pads) */
#if PLAT_SMK37
            pad_hint(1);
#else
            int32_t tw = text_tw(&FONT_XS, "SELECT", 1);
            small_cap(MR - tw - 6 - (text_tw(&FONT_XS, CN_SEL, 1) + 7), CN_SEL);
            text_r(MR, 7, &FONT_XS, "SELECT", C_ONBAND, 1);
#endif
        } else {
            text_r(MR, 9, &FONT_XS, at, C_ONBAND, 1);
        }
        if (!b)
            batt_draw(band_col(), C_ONBAND);
        if (tg) {
            tgt_boxes(first);
            for (i = 0, at_t = 0; i < first; i++)
                at_t += TGT_SLOTS[i] >= 0;
        }
        for (i = 0; i < NG_PER && (tg || first + i < n); i++) {
            int32_t cx = 8 + (int32_t)(i / NG_ROWS) * 114, cy = 37 + (int32_t)(i % NG_ROWS) * 19, w = 110, on;
            int32_t sl = tg ? TGT_SLOTS[first + i] : 0;
            uint16_t col;
            if (sl == TH_NONE)
                continue;
            if (sl < TH_NONE) {          /* a section's name, in its colour */
                static const uint16_t HC[] = TGT_HC;
                text_t(cx + 6, cy + 2, &FONT_XS, tgt_head((uint32_t)(-sl - 2)), HC[-sl - 2], 2);
                continue;
            }
            on = tg ? at_t == ng.v : first + i == ng.v;
            if (tg) {                    /* (inside its box) */
                cx += 2;
                w -= 4;
            }
#if FRS_LEAD
            if (lr && first + i > PD[p].max)
                ldu_name_of(lb, first + i - PD[p].max - 1u, t);
            else
#endif
                list_name(p, tg ? at_t : first + i, t);
            col = tg ? tgt_col((uint32_t)sl) : first + i > PD[p].max ? C_FOG : C_MIST;
            at_t++;
            if (on) {
                cv_rect(cx, cy - oy, w, 17, mix565(C_BG, fc, 7));
                hline(cx, cx + w - 1, cy, fc);
                hline(cx, cx + w - 1, cy + 16, fc);
                cv_rect(cx, cy - oy, 1, 17, fc);
                cv_rect(cx + w - 1, cy - oy, 1, 17, fc);
            }
            fit_text(cx + (tg ? 4 : 6), cy + 1, w - 10, t, on ? C_WHITE : col, 0, 0);
        }
        if (pages > 1u) {
            x = 120 - (int32_t)pages * 9;
            for (i = 0; i < pages; i++, x += 18)
                cv_rect(x, 234 - oy, 14, 2, i == page ? C_FOG : C_STEEL);
        }
        cl_band(oy);
        cv_blit(0, (uint32_t)oy);
    }
}

/* -------------------------------------------------------- the screensaver --- */
/* app.c's saver: the screen black, the logo (the screen's own, smaller: SAVER_PX) drifting a pixel a step on both axes,
 * a step every SAVER_STEP_MS (40 a second: smooth, ~40 pixels a second); at an edge it turns back and takes
 * FRASIL's next colour (and, now and then, a corner). Its letters in the logo's two tones, the lower half paler and a
 * little toward the sea, at 3/4 of their light (a dark room). A step draws its old box and its new one together, one
 * small canvas (~2.5 k pixels: the river's band is 35 k, twenty times a second); the first, the screen black */
static const uint16_t SAVER_COL[] = {C_FOG, C_ICE, C_LAMP, C_GLOB, C_SEA};
#define SAVER_NCOL (sizeof SAVER_COL / sizeof SAVER_COL[0])

static uint32_t saver_px(uint32_t x, uint32_t y)   /* the small logo's intensity, 0..15 */
{
    uint8_t b = SAVER_PX[(y * SAVER_W + x) >> 1];
    return (x & 1u) ? (b & 15u) : (b >> 4);
}

static void saver_draw(int32_t ox, int32_t oy0)   /* the logo where it is now, its box at (ox, oy0) cleared */
{
    int32_t x0 = ox < saver.x ? ox : saver.x, y0 = oy0 < saver.y ? oy0 : saver.y;
    int32_t ax = saver.x - x0, ay = saver.y - y0;
    uint32_t w = SAVER_W + (uint32_t)(ox > saver.x ? ox - saver.x : saver.x - ox);
    uint32_t h = SAVER_H + (uint32_t)(oy0 > saver.y ? oy0 - saver.y : saver.y - oy0), x, y;
    uint16_t top = SAVER_COL[saver.col % SAVER_NCOL], low = mix565(top, C_SEA, 10);
    cv_begin(w, h, C_BLACK);
    for (y = 0; y < SAVER_H; y++)
        for (x = 0; x < SAVER_W; x++) {
            uint32_t i = saver_px(x, y);
            if (i)
                cv_px[(y + (uint32_t)ay) * w + x + (uint32_t)ax] =
                    swap16(mix565(C_BLACK, y <= SAVER_CUT ? top : low, (int32_t)(i * 24u / 15u)));
        }
    cv_blit((uint32_t)x0, (uint32_t)y0);
#if defined PLAT_HOST && !defined PLAT_WEB
    ui_cost.draws++;
    ui_cost.px += w * h;
#endif
}

/* ---- a corner: CORNER! ---- */
/* The logo in a corner (app.c): SAVER_PARTY_MS of celebration, the logo still, then the drift on. A ring of frost runs
 * out from the corner; ice crystals (six arms, the bigger with twigs) burst from it into the screen, each its own way
 * and speed, slowed by the air (PARTY_TAU) and then drifting down (PARTY_FALL), turning, twinkling, fading; CORNER! in
 * the middle (FONT_L), letter after letter, in FRASIL's five colours, which pass along it every PARTY_TURN_MS. A frame
 * (every PARTY_FRAME_MS) draws again only the 16 x 16 tiles where something is or was (one blit a run of them in a
 * row; the logo's tiles drawn with it): fewer pixels a second than the river awake, never the whole screen */
#define SAVER_PARTY_MS 2600u
#define PARTY_FRAME_MS 40u                /* 25 frames a second */
#define PARTY_N 56                        /* crystals */
#define PARTY_TAU 0.42f                   /* a crystal's speed falls by e in this (s) */
#define PARTY_FALL 20.0f                  /* then it drifts down this fast (px/s) */
#define PARTY_RING_MS 700u
#define PARTY_TURN_MS 180u
#define PARTY_TILE 16
#define PARTY_TILES 15                    /* 240 / 16, both ways */
static const char PARTY_WORD[] = "CORNER!";
#define PARTY_LETTERS (sizeof PARTY_WORD - 1u)
static struct {
    uint32_t drawn_at, seed, text_sig;
    uint16_t was[PARTY_TILES], now[PARTY_TILES];   /* the tiles with something in them, last frame and this one */
    int32_t cx, cy, sx, sy;               /* the corner's pixel; into the screen from it (+1 / -1) */
    int32_t x0;                           /* the run being drawn: its first column (oy: its first row) */
    float ring_r;                         /* the frost ring: its radius, its light of 32 (0: gone) */
    int32_t ring_a;
    int16_t lx[PARTY_LETTERS];            /* CORNER!: each letter's x; its row; each letter's light and colour */
    int16_t ty, tx1;                      /* (its end) */
    uint8_t la[PARTY_LETTERS], lc[PARTY_LETTERS];
    struct {
        int16_t x, y;                     /* (off the screen: not drawn) */
        uint8_t r, a, col, ang;           /* arm length 1..4, light of 32, colour, turn (of 256) */
    } c[PARTY_N];
} party;

/* a pixel of the run being drawn (screen coordinates), c over what is there, a of 32 */
static inline void party_px(int32_t x, int32_t y, uint16_t c, int32_t a)
{
    uint16_t *p;
    x -= party.x0;
    y -= oy;
    if (a <= 0 || (uint32_t)x >= cv_w || (uint32_t)y >= cv_h)
        return;
    p = &cv_px[(uint32_t)y * cv_w + (uint32_t)x];
    *p = swap16(a >= 32 ? c : mix565(swap16(*p), c, a));
}

static void party_mark(int32_t x0, int32_t y0, int32_t x1, int32_t y1)   /* the tiles over a box (inclusive) */
{
    int32_t r;
    uint16_t m;
    x0 = x0 < 0 ? 0 : x0;
    y0 = y0 < 0 ? 0 : y0;
    x1 = x1 > 239 ? 239 : x1;
    y1 = y1 > 239 ? 239 : y1;
    if (x0 > x1 || y0 > y1)
        return;
    x0 /= PARTY_TILE;
    x1 /= PARTY_TILE;
    m = (uint16_t)(((1u << (x1 - x0 + 1)) - 1u) << x0);
    for (r = y0 / PARTY_TILE; r <= y1 / PARTY_TILE; r++)
        party.now[r] |= m;
}

static inline int32_t party_round(float v) { return (int32_t)(v + 1024.5f) - 1024; }

/* the corner reached: where it is, the way in, CORNER!'s letters placed */
static void party_begin(void)
{
    uint32_t i;
    int32_t x, tw = text_tw(&FONT_L, PARTY_WORD, 3) + 1;
    memset(&party, 0, sizeof party);
    party.seed = saver.party_at * 2654435761u ^ saver.corners;
    party.cx = saver.x ? 239 : 0;
    party.sx = saver.x ? -1 : 1;
    party.cy = saver.y ? 239 : 0;
    party.sy = saver.y ? -1 : 1;
    for (i = 0, x = 120 - tw / 2; i < PARTY_LETTERS; i++) {
        party.lx[i] = (int16_t)x;
        x += FONT_L.adv[glyph(&FONT_L, (uint8_t)PARTY_WORD[i])] + 3;
    }
    party.tx1 = (int16_t)(x - 2);
    party.ty = (int16_t)(120 - (int32_t)FONT_L.h / 2);
}

/* where everything is at ms into it; the tiles it covers into party.now */
static void party_place(uint32_t ms)
{
    float t = (float)ms * 0.001f, e = 1.0f - fm_expf(-t * (1.0f / PARTY_TAU)), u;
    uint32_t i, sig = 2166136261u, turn = ms / PARTY_TURN_MS;
    int32_t tx, ty;
    memset(party.now, 0, sizeof party.now);
    /* the ring: out fast, easing, fading */
    party.ring_a = 0;
    if (ms < PARTY_RING_MS) {
        u = (float)ms / (float)PARTY_RING_MS;
        party.ring_r = 330.0f * (1.0f - (1.0f - u) * (1.0f - u) * (1.0f - u));
        party.ring_a = (int32_t)(30.0f * (1.0f - u) * (1.0f - u));
        for (ty = 0; ty < PARTY_TILES && party.ring_a > 0; ty++)   /* the tiles the ring's band crosses */
            for (tx = 0; tx < PARTY_TILES; tx++) {
                int32_t ax = tx * PARTY_TILE - party.cx, bx = ax + PARTY_TILE - 1, ay = ty * PARTY_TILE - party.cy,
                        by = ay + PARTY_TILE - 1;
                int32_t nx = ax > 0 ? ax : bx < 0 ? bx : 0, ny = ay > 0 ? ay : by < 0 ? by : 0;
                int32_t fx = ax * ax > bx * bx ? ax : bx, fy = ay * ay > by * by ? ay : by;   /* (the farther) */
                float lo = party.ring_r - 2.0f, hi = party.ring_r + 2.0f;
                if ((float)(nx * nx + ny * ny) <= hi * hi && (float)(fx * fx + fy * fy) >= lo * lo)
                    party.now[ty] |= (uint16_t)(1u << tx);
            }
    }
    /* CORNER!: a letter every 45 ms from 100 ms, each in 120 ms; all gone from 2150 to 2500 */
    for (i = 0; i < PARTY_LETTERS; i++) {
        float a = br_clamp01(((float)ms - 100.0f - 45.0f * (float)i) * (1.0f / 120.0f)) *
                  br_clamp01((2500.0f - (float)ms) * (1.0f / 350.0f));
        party.la[i] = (uint8_t)(a * 32.0f + 0.5f);
        party.lc[i] = (uint8_t)((i + SAVER_NCOL * 8u - turn % SAVER_NCOL + saver.col) % SAVER_NCOL);
        sig = (sig ^ (uint32_t)party.la[i] << 8 ^ party.lc[i]) * 16777619u;
    }
    if (sig != party.text_sig) {         /* (it changed: its tiles again) */
        party.text_sig = sig;
        party_mark(party.lx[0] - 3, party.ty, party.tx1 + 3, party.ty + (int32_t)FONT_L.h);
    }
    /* the crystals: each from the corner its way, slowed, then down; turning, twinkling, gone between 1.4 and 2.55 s */
    for (i = 0; i < PARTY_N; i++) {
        uint32_t h0 = hsh(i, party.seed), h1 = hsh(i, party.seed + 1u), h2 = hsh(i, party.seed + 2u);
        float th = (0.10f + 1.37f * (float)(h0 & 1023u) * (1.0f / 1023.0f));   /* 6 .. 84 degrees off the edge */
        float q = (float)(h0 >> 10) * (1.0f / 63.0f), v = 120.0f + 520.0f * q * fm_sqrtf(q);   /* (more slow ones) */
        float d = v * PARTY_TAU * e, tf = 1.5f + 0.7f * (float)(h1 & 255u) * (1.0f / 255.0f);
        float x = (float)party.cx + (float)party.sx * fm_cosf(th) * d + 3.0f * sn(0.8f * t + (float)(h2 & 255u) / 256.0f) * e;
        float y = (float)party.cy + (float)party.sy * fm_sinf(th) * d + PARTY_FALL * (t - PARTY_TAU * e);
        float a = br_clamp01(t * 20.0f) * br_clamp01(1.0f - (t - tf) * (1.0f / 0.35f)) *
                  (0.62f + 0.38f * sn(2.6f * t + (float)(h2 >> 8) / 256.0f));
        uint32_t k = (h1 >> 8) & 15u;
        int32_t cr = k < 4u ? 1 : k < 8u ? 2 : k < 12u ? 3 : k < 15u ? 4 : 5;
        int32_t X = party_round(x), Y = party_round(y);
        party.c[i].a = (uint8_t)(a * 32.0f + 0.5f);
        party.c[i].r = (uint8_t)cr;
        party.c[i].col = (uint8_t)((h2 >> 4) % SAVER_NCOL);
        party.c[i].ang = (uint8_t)((int32_t)((h1 >> 12) * 16u) +   /* turning 40 .. 90 degrees a second, either way */
                                   (int32_t)((float)((h2 & 1u) ? 30 + (int32_t)(h1 & 31u) : -30 - (int32_t)(h1 & 31u)) * t));
        if (!party.c[i].a || X < -5 || X > 244 || Y < -5 || Y > 244) {
            party.c[i].a = 0;
            continue;
        }
        party.c[i].x = (int16_t)X;
        party.c[i].y = (int16_t)Y;
        party_mark(X - cr - 1, Y - cr - 1, X + cr + 1, Y + cr + 1);
    }
}

/* a crystal: its centre, six arms of r (the tips paler), the bigger with a twig each side near the tip (5: two) */
static void party_crystal(int32_t X, int32_t Y, int32_t r, uint32_t ang, uint16_t c, int32_t a)
{
    float ux[6], uy[6];
    int32_t k, d;
    ux[0] = ui.sn[(ang + 64u) & 255u];
    uy[0] = ui.sn[ang & 255u];
    for (k = 1; k < 6; k++) {            /* each 60 degrees on */
        ux[k] = ux[k - 1] * 0.5f - uy[k - 1] * 0.8660254f;
        uy[k] = uy[k - 1] * 0.5f + ux[k - 1] * 0.8660254f;
    }
    party_px(X, Y, c, a);
    for (k = 0; k < 6; k++) {
        for (d = 1; d <= r; d++)
            party_px(X + party_round(ux[k] * (float)d), Y + party_round(uy[k] * (float)d), c,
                     d == r && r > 1 ? a * 9 / 16 : a * 7 / 8);
        for (d = r - 1; r >= 3 && d >= (r == 5 ? 2 : r - 1); d -= 2) {   /* the twigs: a pixel toward the arms beside */
            float bx = ux[k] * (float)d, by = uy[k] * (float)d;
            party_px(X + party_round(bx + ux[(k + 1) % 6]), Y + party_round(by + uy[(k + 1) % 6]), c, a / 2);
            party_px(X + party_round(bx + ux[(k + 5) % 6]), Y + party_round(by + uy[(k + 5) % 6]), c, a / 2);
        }
    }
}

/* a run of tiles, x0 .. x0 + w - 1 by y0 .. y0 + h - 1: black, the logo, the ring, CORNER!, the crystals; sent */
static void party_run(int32_t x0, int32_t y0, int32_t w, int32_t h)
{
    uint32_t i;
    int32_t x, y;
    party.x0 = x0;
    oy = y0;
    cv_begin((uint32_t)w, (uint32_t)h, C_BLACK);
    if (saver.x < x0 + w && saver.x + (int32_t)SAVER_W > x0 && saver.y < y0 + h && saver.y + (int32_t)SAVER_H > y0) {
        uint16_t top = SAVER_COL[saver.col % SAVER_NCOL], low = mix565(top, C_SEA, 10);
        int32_t xa = x0 > saver.x ? x0 : saver.x, xb = x0 + w < saver.x + (int32_t)SAVER_W ? x0 + w : saver.x + (int32_t)SAVER_W;
        int32_t ya = y0 > saver.y ? y0 : saver.y, yb = y0 + h < saver.y + (int32_t)SAVER_H ? y0 + h : saver.y + (int32_t)SAVER_H;
        for (y = ya; y < yb; y++)
            for (x = xa; x < xb; x++) {
                uint32_t v = saver_px((uint32_t)(x - saver.x), (uint32_t)(y - saver.y));
                if (v)
                    cv_px[(uint32_t)(y - y0) * (uint32_t)w + (uint32_t)(x - x0)] =
                        swap16(mix565(C_BLACK, (uint32_t)(y - saver.y) <= SAVER_CUT ? top : low, (int32_t)(v * 24u / 15u)));
            }
    }
    if (party.ring_a > 0) {              /* the ring: a soft band 1.6 px either side of its radius */
        float lo = party.ring_r - 1.6f, hi = party.ring_r + 1.6f;
        for (y = y0; y < y0 + h; y++)
            for (x = x0; x < x0 + w; x++) {
                float dx = (float)(x - party.cx), dy = (float)(y - party.cy), q = dx * dx + dy * dy;
                if (q > lo * lo && q < hi * hi) {
                    float o = fm_sqrtf(q) - party.ring_r;
                    party_px(x, y, C_ICE, (int32_t)((float)party.ring_a * (1.0f - (o < 0.0f ? -o : o) * 0.625f)));
                }
            }
    }
    if (y0 < party.ty + (int32_t)FONT_L.h && y0 + h > party.ty)
        for (i = 0; i < PARTY_LETTERS; i++) {   /* CORNER!: the letters over this run */
            char ch[2] = {PARTY_WORD[i], 0};
            uint32_t g = glyph(&FONT_L, (uint8_t)ch[0]);
            int32_t gx = party.lx[i] - (int32_t)FONT_L.pad;
            uint16_t c = mix565(C_BLACK, SAVER_COL[party.lc[i]], party.la[i]);
            if (!party.la[i] || gx >= x0 + w || gx + (int32_t)FONT_L.bw[g] + 1 <= x0)
                continue;
            cv_text(party.lx[i] - x0, party.ty - y0, &FONT_L, ch, c);       /* (bold: twice, a pixel apart) */
            cv_text(party.lx[i] + 1 - x0, party.ty - y0, &FONT_L, ch, c);
        }
    for (i = 0; i < PARTY_N; i++) {
        int32_t r = party.c[i].r + 1;
        if (party.c[i].a && party.c[i].x + r >= x0 && party.c[i].x - r < x0 + w && party.c[i].y + r >= y0 &&
            party.c[i].y - r < y0 + h)
            party_crystal(party.c[i].x, party.c[i].y, party.c[i].r, party.c[i].ang, SAVER_COL[party.c[i].col],
                          party.c[i].a);
    }
    cv_blit((uint32_t)x0, (uint32_t)y0);
#if defined PLAT_HOST && !defined PLAT_WEB
    ui_cost.prun++;
    ui_cost.ppx += (uint32_t)(w * h);
#endif
}

/* a frame of it: the tiles where something is now or was, run by run; at its end the screen black, the logo, the
 * drift on */
static void saver_party(void)
{
    uint32_t now = plat_ms(), ms = now - saver.party_at;
    int32_t r, a, b;
#if defined PLAT_HOST && !defined PLAT_WEB
    uint32_t px0;
#endif
    if (ms >= SAVER_PARTY_MS) {
        saver.party = 0;
        lcd_fill(0, 0, 240, 240, C_BLACK);
        saver.step_at = now;
        saver_draw(saver.x, saver.y);
        return;
    }
    if (party.drawn_at && now - party.drawn_at < PARTY_FRAME_MS)
        return;
    party.drawn_at = now;
#if defined PLAT_HOST && !defined PLAT_WEB
    px0 = ui_cost.ppx;
#endif
    party_place(ms);
    for (r = 0; r < PARTY_TILES; r++) {
        uint32_t m = (uint32_t)(party.was[r] | party.now[r]);
        for (a = 0; a < PARTY_TILES; a = b) {
            if (!(m >> a & 1u)) {
                b = a + 1;
                continue;
            }
            for (b = a; b < PARTY_TILES && (m >> b & 1u); b++)
                ;
            party_run(a * PARTY_TILE, r * PARTY_TILE, (b - a) * PARTY_TILE, PARTY_TILE);
        }
    }
    memcpy(party.was, party.now, sizeof party.was);
    ui.frames++;
#if defined PLAT_HOST && !defined PLAT_WEB
    ui_cost.pframes++;
    ui_cost.pmax = ui_cost.ppx - px0 > ui_cost.pmax ? ui_cost.ppx - px0 : ui_cost.pmax;
#endif
}

static void saver_screen(void)
{
    uint32_t now = plat_ms(), n;
    int32_t ox = saver.x, oy0 = saver.y;
    if (!saver.drawn) {
        lcd_fill(0, 0, 240, 240, C_BLACK);
        saver.drawn = 1;
        saver.step_at = now;
        saver_draw(ox, oy0);
        return;
    }
    if (saver.party) {
        saver_party();
        return;
    }
    n = (now - saver.step_at) / SAVER_STEP_MS;
    if (!n)
        return;
    saver.step_at = n > 8u ? now : saver.step_at + n * SAVER_STEP_MS;   /* (after a long pass, no leap) */
    for (n = n > 8u ? 8u : n; n; n--) {
        if (saver_move(&saver.x, &saver.y, &saver.dx, &saver.dy)) {
            saver.bounces++;
            saver.col = (uint8_t)((saver.col + 1u) % SAVER_NCOL);
        }
        saver.steps++;
#if defined PLAT_HOST && !defined PLAT_WEB
        saver_out += saver.x < 0 || saver.x > SAVER_MAXX || saver.y < 0 || saver.y > SAVER_MAXY;
#endif
        if (saver_cornered(saver.x, saver.y)) {   /* a corner: celebrated (the logo drawn there first) */
            saver.corners++;
            if (!saver.corner_step)
                saver.corner_step = saver.steps;
            saver.party = 1;
            saver.party_at = now;
            party_begin();
            break;
        }
    }
    saver_draw(ox, oy0);
    ui.frames++;
}

/* -------------------------------------------------------------- frames --- */
static void ui_init(void)
{
    uint32_t i;
    for (i = 0; i < 256u; i++)
        ui.sn[i] = fm_sinf(6.2831853f * (float)i / 256.0f);
    for (i = 0; i < 240u; i++) {
        float e = smooth01((float)((int32_t)i - ML) / 40.0f) * smooth01((float)(MR - (int32_t)i) / 40.0f);
        ui.edge[i] = (int32_t)(e * 256.0f);
    }
    lcd_fill(0, 0, 240, 240, C_BG);
    ui.full = 1;
    ui.was_saver = 0;
}

#if FM1B_MIRROR
/* the screen mirror (fm1.toml mirror = true, base device/mirror.c; card #279): a viewer came, or a slow link dropped a
 * part of what was drawn: drawn again at the next frame. A page: its bands with rows the viewer has wrong (mirror.c's
 * mr.dirty, in this unity build on the FM-1 and in the simulator), the river's band 20 times a second anyway, so the
 * header and the footer (the values) are not drawn again each time it is; a pop-up, the help, the screensaver, the whole
 * screen; the logo's, alive, nothing (it draws itself again every 50 ms). The main loop, between frames (mirror_step);
 * rows the viewer already has are not sent again */
static int mr_rows_dirty_in(uint32_t y0, uint32_t y1)
{
    for (uint32_t r = y0; r < y1; r++)
        if (mr_row_dirty(r))
            return 1;
    return 0;
}

void app_redraw(void)
{
    if (saver.on) {                      /* the screensaver: black, the logo where it is; its corner, every tile */
        if (saver.party)
            memset(party.was, 0xFF, sizeof party.was);
        else
            saver.drawn = 0;
        return;
    }
    if (ui.was_pop || ui.was_map) {      /* a pop-up, a name, the grid, the welcome, the help: whole, then the page */
        ui.was_pop = ui.was_map = 0;
        ui.help_sig = ~0u;
        ui.full = 1;
        return;
    }
    if (ui.was_logo) {                   /* the logo's screen: alive, it draws itself again every 50 ms; still, once more
                                          * (never was_logo cleared: the CPU line would come over it) */
        ui.logo_again = (uint8_t)(st.v[P_ANIM] != 0);
        return;
    }
    if (ui.full)
        return;
    if (mr_rows_dirty_in(R1, R2))        /* a page: its bands the viewer has wrong (a band's signature changed: drawn
                                          * again) */
        ui.sig1 ^= 1u;
    if (mr_rows_dirty_in(R2, R3) && (fm.page == PG_SAVE || fm.page == PG_SAVEAS))
        ui.mid = ~0u;                    /* (the middle draws itself again within 250 ms anyway, but on SAVE's pages:
                                          * not forced, so the footer is not sent behind it each time) */
    if (mr_rows_dirty_in(R3, 240u))
        ui.sig3 ^= 1u;
}
#endif

/* what a band shows, as a number: it is drawn again when that changes */
static uint32_t sig_add(uint32_t h, uint32_t v) { return (h ^ v) * 16777619u; }

static void ui_frame(void)
{
    uint32_t now = plat_ms(), s1 = 2166136261u, s3 = 2166136261u, i;
    int ov = overlay_on();
#if APP_CPU_LINE
    cl_tick(!ui.was_saver && (ui.was_pop || ui.was_map || !ui.was_logo));   /* (the load's line: the last frame's
                                                                              * screen not the saver's, nor the logo's
                                                                              * with nothing over it) */
#endif
    if (saver.on) {                      /* the screensaver: over everything, what was there kept */
        saver_screen();
        ui.was_saver = 1;
        return;
    }
    if (ui.was_saver) {                  /* woken: what was there, all of it again (a pop-up, a name, the help, the logo) */
        ui.was_saver = 0;
        ui.was_pop = ui.was_map = ui.was_logo = 0;
        ui.full = 1;
        ui.help_sig = ~0u;
    }
    {                                    /* (the battery moved: NAME IT's and the grid's headers drawn again) */
        static uint32_t batt_was;
        uint32_t bn = (uint32_t)(batt.pct + 1) | (uint32_t)batt.zone << 8;
        if (bn != batt_was) {
            batt_was = bn;
            nm.drawn = 0;
            ng.drawn = 0;
        }
    }
    if (pop.on) {                        /* a pop-up: over everything, drawn once */
        if (!pop.drawn || !ui.was_pop)
            popup_screen();
        pop.drawn = 1;
        ui.was_pop = 1;
        return;
    }
    if (welcome.on) {                    /* Learn's welcome: the same, gone at a button, a key, a knob (app.c) */
        if (!welcome.drawn || !ui.was_pop)
            welcome_screen();
        welcome.drawn = 1;
        ui.was_pop = 1;
        return;
    }
    if (nm.on) {                         /* a name being written: over everything, drawn as it changes */
        if (!nm.drawn || !ui.was_pop)
            name_screen();
        nm.drawn = 1;
        ui.was_pop = 1;
        return;
    }
    if (ng.on) {                         /* the grid of names: the same */
        if (!ng.drawn || !ui.was_pop)
            grid_screen();
        ng.drawn = 1;
        ui.was_pop = 1;
        return;
    }
    if (ui.was_pop) {                    /* closed: back where we were, all of it (the help too) */
        ui.was_pop = 0;
        ui.full = 1;
        ui.was_logo = 0;
        ui.help_sig = ~0u;
    }
    if (fm.help) {                       /* the help: drawn again when its page or a mode changes */
        uint32_t hs = fm.help_page | (uint32_t)st.bass << 4 | (uint32_t)st.glint << 5 |
                      (uint32_t)(st.bass ? barp.latch : arp.latch) << 6 |
                      (uint32_t)rec_any() << 7 | (uint32_t)fm.page << 8 |
                      (uint32_t)st.v[P_FREEZE] << 16 | (uint32_t)(batt.pct + 1) << 20 | (uint32_t)batt.zone << 28;
        if (!ui.was_map || hs != ui.help_sig)
            help_screen();
        ui.help_sig = hs;
        ui.was_map = 1;
        return;
    }
    if (ui.was_map) {                    /* let go: back where we were, all of it */
        ui.was_map = 0;
        ui.full = 1;
        ui.was_logo = 0;
    }
    if (fm.logo && fm.logo_until && now >= fm.logo_until)
        fm.logo = 0;
    if (fm.logo) {                       /* the logo's screen, alive: 20 frames a second, 12 while the sound takes
                                          * most of the processor (it moves slowly; the keys stay quick) */
        if (!ui.was_logo || ui.logo_again || (!st.v[P_ANIM] && now - ui.field_at >= (cpu_load() > 75u ? 80u : 50u))) {
            ui.logo_again = 0;
            ui.field_at = now;           /* (ANIMATIONS LOW: drawn once, still) */
            logo_scene(st.v[P_ANIM] ? 6.0f : (float)now * 0.001f, 0);
            ui.frames++;
        }
        ui.was_logo = 1;
        return;
    }
    if (ui.was_logo) {                   /* back from it: everything again */
        ui.was_logo = 0;
        ui.full = 1;
    }
    anchor_frame();                      /* (ANCHOR's frame: what changed of it now, ui.full if it came or went) */
    morph_frame();                       /* (a MORPH's frame round the edge: the same) */
    /* the header: the page, the freeze, the keys' mode, the octave, a message, the harmony, the load */
    s1 = sig_add(s1, fm.page | (uint32_t)st.v[P_FREEZE] << 8 | (uint32_t)st.glint << 9 | (uint32_t)(now < say.msg_until) << 10 |
                         (uint32_t)arp.latch << 11 | (uint32_t)(st.v[P_SQ_TYPE] != 0) << 12 | (uint32_t)st.bass << 13 |
                         (uint32_t)st.v[P_KEYS] << 14 | (uint32_t)st.v[P_SQ_TYPE] << 15 | (uint32_t)st.v[P_SQ_REC] << 17 |
                         (uint32_t)st.dirty << 19 | (uint32_t)st.compare << 20 | (uint32_t)cpu_over() << 21 |
                         (uint32_t)(mo.on && !mo.anc) << 22 | (uint32_t)fm.scene << 23);
    s1 = sig_add(s1, hdr.dark | (uint32_t)st.v[P_TP_ON] << 8);   /* (HEADER: INVERT, DARK; MEDIA: LOFI's title, card
                                                                 * #229) */
#if FRS_MIDI_OUT
    s1 = sig_add(s1, mout.sel | (uint32_t)md[MD_REC] << 1);   /* (MIDI's word and violet; its take's word) */
    s3 = sig_add(s3, mout.ret | (uint32_t)mout.clk << 7 | (uint32_t)(msq.at && now - msq.at < TOUCH_MS) << 8 |
                         (uint32_t)msq.at_i << 9 | (uint32_t)nout.on << 16);   /* (RETURN, CLOCK OUT; MIDI's ARP and
                                                                              * SEQ: card #169; NOTES OUT, #201) */
    for (i = 0; i < NMD; i++)
        s3 = sig_add(s3, md[i]);
    if (PAGES[fm.page].track == T_MIDI) {   /* (their strips: the steps, the playhead, the arpeggio) */
        for (i = 0; i < SC_SEQ; i++)
            s3 = sig_add(s3, mseq[i]);
        s3 = sig_add(s3, (uint32_t)(msq.pos + 1) | (uint32_t)(msq.sounding + 1) << 8 | (uint32_t)marp.pn << 17 |
                             (uint32_t)(ma.note[0] + 1) << 22);
    }
    s3 = sig_add(s3, mout.sel | (uint32_t)mout.ch << 1 | (uint32_t)(mout_oct() + 3) << 5 | (uint32_t)mout.vel << 8 |
                         (uint32_t)mout.prs << 10 | (uint32_t)mout_big() << 12 |
                         (uint32_t)(mout.at && now - mout.at < TOUCH_MS) << 13 | (uint32_t)mout.at_p << 14);
    if (fm.page == PG_MOUT) {            /* (its strip: the keys down, their pressure, the last out, USB) */
        uint32_t k, h = mout_held() ^ mout.sent << 7 ^ (uint32_t)(plat_midi_out_room(TO_USB) != 0) << 31;
        for (k = 0; k < NKEYS; k++)
            h = sig_add(h, mout.kp[k] >> 3);
        s3 = sig_add(s3, h);
    }
#endif
    s1 = sig_add(s1, (uint32_t)(batt.pct + 1) | (uint32_t)batt.zone << 8);   /* (the battery) */
    s1 = sig_add(s1, st.v[P_BQ_ON] | (uint32_t)st.v[P_BQ_REC] << 2 | (uint32_t)barp.latch << 4 | (uint32_t)st.v[P_DQ_REC] << 5 |
                         (uint32_t)st.v[P_DQ_ON] << 7 | (uint32_t)cnt.run << 8 | (uint32_t)cnt.beat << 9 |
                         (uint32_t)sv.load << 12);
    s1 = sig_add(s1, (uint32_t)(play_holding() * 32.0f) |
                         (mo.on && !mo.anc ? (now - mo.t0) * 64u / (mo.dur ? mo.dur : 1u) : 0u) << 8);
    s1 = sig_add(s1, (uint32_t)(fm.octave + 8) | (uint32_t)chord_tag() << 8);   /* (CHORD . the track) */
    s1 = sig_add(s1, (uint32_t)oct_big());
    s1 = sig_add(s1, say.msg_until);
    s1 = sig_add(s1, st.v[P_ROOT] | st.v[P_SCALE] << 4 | (uint32_t)st.v[P_CHORD] << 8);
    for (i = 0; i < SC_LONG && fm.scene < NSCENES; i++)   /* (the scene's name, as it may change: NAME IT, a
                                                           * restore; NEW SHARD's never does) */
        s1 = sig_add(s1, (uint8_t)(i < SC_NAME ? scn.s[fm.scene].name[i] : scn.s[fm.scene].name_more[i - SC_NAME]) |
                             (scn.used >> fm.scene & 1u) << 8);
    if (fm.page == PG_GLOBAL)
        s1 = sig_add(s1, cpu_load() << 8 | ui.fps);
    /* the footer: the page, the overlay, the values */
    s3 = sig_add(s3, fm.page | (uint32_t)ov << 8 | (uint32_t)st.dirty << 9 | (uint32_t)fm.pick << 10 |
                         (uint32_t)sv.load << 15 | (uint32_t)sv.what << 16 | (uint32_t)sv.into << (18 + FRS_LEAD));
    s3 = sig_add(s3, (uint32_t)(up_cur[0] + 1) | (uint32_t)(up_cur[1] + 1) << 8 | (uint32_t)(up_cur[2] + 1) << 16
#if FRS_LEAD
                         | (uint32_t)(up_cur[3] + 1) << 24
#endif
                     );
    s3 = sig_add(s3, (touched_now() ? fm.touched : 255u) | (uint32_t)st.v[P_TP_ON] << 16);   /* (MEDIA: ROUTING's
                                          * LOFI, its name) */
    for (i = 0; i < 4u; i++) {           /* (and where an LFO has them) */
        prm_t p = page_knob(fm.page, i);
        s3 = sig_add(s3, p);
        s3 = sig_add(s3, p == P_TEMPO ? st.v[p] | ext_bpm() << 8   /* (TEMPO (EXT): the clock's, as it comes and goes) */
                         : p < NPARAM ? st.v[p]
                         : p == K_IDLE ? saver.min | (uint32_t)(saver.min_at && now - saver.min_at < TOUCH_MS) << 8
                         : p == K_HEAD ? hdr.dark | (uint32_t)(hdr.at && now - hdr.at < TOUCH_MS) << 8
                         : p >= K_LINK && p <= K_LK0 + 3u ? (uint32_t)(lk.bits | lk.follow << 4) |
                                                                (uint32_t)(link_hot(p)) << 8
                         : p == K_TUNE ? a4.hz | (uint32_t)(a4.at && now - a4.at < TOUCH_MS) << 9 : 0u);
        s3 = sig_add(s3, p < NPARAM ? (uint32_t)(int32_t)(mod_of(p) * 2.0f) : 0u);
        if (tgt_slot(p) < 12u)           /* (a TARGET's AMOUNT, lit while SEL + K turns it) */
            s3 = sig_add(s3, st.v[P_L1_AMT1 + tgt_slot(p)] |
                                 (uint32_t)(now < say.msg_until && say.amt == tgt_slot(p) + 1u) << 8);
    }
    s3 = sig_add(s3, st.v[P_KB] | (uint32_t)st.v[track_preset()] << 8 | (uint32_t)st.v[track_algo()] << 16 |
                         (uint32_t)st.v[P_SQ_TYPE] << 24 | (uint32_t)st.v[P_BQ_ON] << 26 | (uint32_t)st.v[P_DQ_ON] << 28);   /* (the three
                                                                                  * hands; ARP's and SEQ's ON, OFF) */
    s3 = sig_add(s3, st.v[P_KY_DR_STACK + 4u * st.v[P_KB]]);   /* (the STACK hint, as SEQ held turns it) */
    if (mo.on && mo.anc)                 /* (ANCHOR's MORPH back: the values as they are heard, the page with them) */
        for (i = 0; i < NMORPH; i++)
            s3 = sig_add(s3, vh_n(i));
    if (fm.page == PG_MIXER)             /* (the pans, and OCT- held: the footer shows them; RETURN come or gone) */
        s3 = sig_add(s3, st.v[P_PN_DRONE] | st.v[P_PN_BASS] << 7 | (uint32_t)st.v[P_PN_GLINT] << 14 |
                             (uint32_t)st.v[P_PN_CLOUD] << 21 | (uint32_t)b_held(B_OCTDN) << 28 |
                             (uint32_t)MIX_RET() << 29);
#if FRS_LEAD
    if (fm.page == PG_NUAGE3)            /* (CLOUD III's K4, OCT- held: the cloud's PAN) */
        s3 = sig_add(s3, st.v[P_PN_CLOUD] | (uint32_t)cloud_pan_shown() << 8);
#endif
    if (page_shape(fm.page) >= 0)        /* (an ENV page's K1, OCT- held: its ATTACK SHAPE; the strip's ATTACK with it) */
        s3 = sig_add(s3, (uint32_t)shape_line() | (uint32_t)shape_shown() << 1 | (uint32_t)shape_hot() << 2);
#if LD_CH_PAGE
    if (fm.page == PG_GLOBAL2)           /* (MIDI's LEAD CH, card #228) */
        s3 = sig_add(s3, st.ldch | (uint32_t)(ldch_at && now - ldch_at < TOUCH_MS) << 5);
#endif
    if (ui.full || s1 != ui.sig1) {
        ui.sig1 = s1;
        header();
    } else {
        roll_tick(&roll, now);           /* (a long name: its window alone, as it rolls) */
    }
    if (ui.full || (fm.page | (uint32_t)ov << 8) != ui.mid ||
        ((fm.page == PG_SAVE || fm.page == PG_SAVEAS) ? s3 != ui.sig3
         : st.v[P_ANIM] ? s3 != ui.sig3 || now - ui.field_at >= 250u : now - ui.field_at >= 50u)) {
        ui.field_at = now;               /* the river moves: 20 frames a second; ANIMATIONS LOW: still (its time
                                          * stopped), drawn again as a value changes and four times a second (what
                                          * tells: meters, playheads). Another page, the value large come or gone: at
                                          * once, with the header and the footer (never a frame of the page before
                                          * under the new one's name: admin #866) */
        ui.mid = fm.page | (uint32_t)ov << 8;
        middle(st.v[P_ANIM] ? 6.0f : (float)now * 0.001f);
        ui.frames++;
    } else if (!oct_big()) {
        roll_tick(&lroll, now);          /* (SCENES: a long name's window alone, as it rolls) */
    }
    if (ui.full || s3 != ui.sig3) {
        ui.sig3 = s3;
        footer();
    }
    if (now - ui.fps_at >= 1000u) {
        ui.fps = ui.frames;
        ui.frames = 0;
        ui.fps_at = now;
    }
    ui.full = 0;
#if defined PLAT_HOST && !defined PLAT_WEB
    {                                    /* (the tests: this frame's page, as its header and footer show it, and the
                                          * middle band's another's) */
        uint8_t look = ui_look();
        ui_seen.home += look == PG_SON;
        ui_seen.flips += look != ui_seen.last;
        ui_seen.stale += ui_seen.mid != look;
        ui_seen.last = look;
    }
#endif
}
