/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Styves Goupil */
/* FRASIL's engine, alone: the instrument whole (its sound, engine/dsp/; its brain, engine/core.c), for a platform
 * without the FM-1's shell (an iPad, a plug-in, tests). Built from frasil_engine.c and the DSP's units (dsp/:
 * frasil.c, glint.c, bass.c, nuage.c; with the LEAD, -DFRS_LEAD=1 and lead.c: below, LEAD), -ffp-contract=off (no
 * fused multiply-add: the FM-1's samples, bit for bit, at 44.1 kHz).
 *
 * One engine a process: its state is static. frs_init opens it (a second open while it is open is refused),
 * frs_close closes it. Two plug-in instances in one process cannot both have it.
 *
 * It has no thread of its own. Call it from one thread at a time, the one that renders (an audio thread takes the
 * UI's calls from a queue of its own), or serialize the calls. From any thread, at any time (open or not, while the
 * audio thread renders): frs_param_count, frs_param_info, frs_param_kind, frs_param_text (but for GLINT SEQ's NOTE
 * and BASS SEQ's NOTE, whose words carry the OCTAVE the audio thread puts on them: those from the thread that
 * renders; and DRONE SEQ II's NOTES, whose words are the step's on STEP), frs_version, frs_scene_new, frs_scene_factory, frs_scene_over, frs_lfo_targets, frs_lfo_target and frs_tracks_bits,
 * which read the engine's constant tables alone (into what the caller gives them), frs_fx_response (the floats it is
 * given alone), and frs_snapshot and frs_snapshot_fx, the views a UI reads. Nothing else: frs_param_get and frs_dirty
 * too read what the audio thread changes (frs_snapshot has the dirty flag).
 *
 * Its time: it renders blocks of FRS_BLOCK frames and runs its brain every millisecond between them (the sequencers,
 * the LFOs, the MIDI), as the FM-1 does. A call between two renders acts at once; what it plays sounds from the next
 * block. MIDI is taken at its millisecond: frs_midi's at the next one, frs_midi_at's at the one its frame falls in (so
 * a clock's beats keep their time whatever the host's buffer). A host's tempo and transport (frs_host_tempo) run the
 * grid as a MIDI clock and Start would. What a message plays sounds from the first block rendered after its
 * millisecond: 0 to FRS_BLOCK frames (5.8 ms at 44.1 kHz) after its frame.
 *
 * Built with -DFRASIL_FS_CONST (as the FM-1's DSP is, for the bench): 44.1 kHz alone, frs_init a second time does not
 * start the sound from nothing, and frs_panic silences the voices, the bass and the queued notes alone (no echoes, no
 * cloud's tail).
 *
 * The settings are the FM-1's, a byte each, 0 .. their max, numbered as frasil_params.h has them (P_EQ_LOW ...;
 * frs_param_info; the River's schema.json names them: "ids", "params"): a platform's UI takes them by name, the
 * numbers past NSOUND move when a setting is added (2.5: 23 higher than 2.0's; 2.6: one more; 2.7's numbered last, none
 * moved, P_BQ_LEN the bass's one RATE, P_BQ_ON its PLAYS: KEYS, ARP, SEQ as GLINT's P_SQ_TYPE; 3.0's after them, the
 * drone's sequence's P_DQ_ON .. P_DQ_STEP, 197 .. 205; then P_DQ_NOTES .. P_COUNT_IN, 206 .. 224: the drone's step
 * editing and UNDO TAKE, ARP II's LATCH, KEYS, METRONOME and COUNT-IN; P_ARP_SNAP 225, P_SAVER 226, none moved; LOFI TAPE II's P_TP_FLUTTER .. P_TP_DROPOUT 227 .. 230, the scene's, last; the LFOs' AMOUNTs, P_L1_AMT1 ..
 * P_L3_AMT4 231 .. 242, the scene's, last; with the LEAD, its 25, P_LD_WAVE .. P_LD_FRELEASE 243 .. 267, NPARAM 268).
 * A scene is FRS_SCENE_BYTES bytes in the River's layout (scene_t: its name, its sound, what it plays, its sequences,
 * its TEMPO); a shard, FRS_SHARD_BYTES ("FRS~", card #152), the scene then its LEAD; what is kept beside it, the
 * engine's state (frs_state_save). */
#pragma once
#include <stdint.h>
#include "frasil_params.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef FRS_CHORDS                       /* CHORD PADS (card #208, chords.c): FrasilVibe's engine; 0, every other build
                                          * (the FM-1's and the SMK-37's app, the iPad, STREAM, the tests but theirs) */
#define FRS_CHORDS 0
#endif

#define FRS_VERSION "3.4.1"           /* the FRASIL this engine is (VERSION's: engine/tests/run.sh checks them alike) */
#define FRS_BLOCK 256u                   /* frames the engine renders at a time (frs_render takes any count) */
#define FRS_SCENE_BYTES 619u             /* a scene, a shard ("FRS}": its name's characters 17 .. 32, the LFOs' AMOUNTs and
                                          * SWELL last; the same bytes in "FRS|", 3.0.2-b5's test builds', its AMOUNTs as
                                          * -100 % .. +100 %: frs_scene_amt_over; 590 in "FRS{", LOFI TAPE II's four last;
                                          * 586 in 3.0's "FRSz", the
                                          * drone's sequence last; 324 in "FRSy",
                                          * before it; 323 in 2.7's "FRSx", 322 in its "FRSw", 319 in its "FRSv", 298 in
                                          * its first test builds, "FRSu"; 297 in 2.6, "FRSt": frs_scene_over makes them
                                          * over; 296 in 2.5, 273 till 2.0, the River makes the old over) */
#define FRS_LEAD_BYTES 25u               /* a shard's LEAD (card #152): its settings, P_LD_WAVE .. P_LD_FRELEASE */
#define FRS_LEAD_NV 6u                   /* the LEAD's voices (POLY's; frs_view_t's lead_note, lead_level) */
#define FRS_SHARD_BYTES 644u             /* a shard, "FRS~" (card #152, the River's and a stream's): a scene's
                                          * FRS_SCENE_BYTES, then its LEAD's FRS_LEAD_BYTES (frs_lead_*); "FRS}" and
                                          * every earlier one, the scene alone: its LEAD MOSS */
#define FRS_SHARD_LAYOUT "FRS~"
#define FRS_STATE_BYTES 64u              /* the engine's state beside a scene, at most (frs_state_save; 3.0's: 45, KEYS'
                                          * twelve and ARP SNAP with it; 32 till then) */
#define FRS_LIVE 53u                     /* frs_live's floats */
#define FRS_LIVE_FX 40u                  /* frs_live_fx's floats */
#define FRS_KEYS 32u                     /* keys down at once (frs_key_*: 0 .. FRS_KEYS - 1) */
#define FRS_TEXT 32u                     /* a setting's words, at most (frs_param_text) */

/* ------------------------------------------------------------------ life --- */
int frs_init(float fs);                  /* open it at the rate fs (Hz: 44.1 kHz .. 96 kHz; the FM-1's build, 44.1 kHz
                                          * alone), everything from the start, NEW SHARD taken, nothing playing. 0; -1
                                          * a rate it can't run at; -2 open already (frs_close first) */
void frs_close(void);                    /* silent, closed (another rate: frs_close, then frs_init) */
const char *frs_version(void);           /* FRS_VERSION as the engine was built ("3.0"; any thread, open or not) */
float frs_rate(void);
void frs_render(float *left, float *right, uint32_t n);   /* n frames, -1 .. 1 (the left's and the right's) */
void frs_render_i24(int32_t *lr, uint32_t n);   /* the same, as the FM-1 renders it: interleaved, 24-bit */
/* frs_render with n frames of an outside input (a guitar, a voice: a Vibe's IN 1 and IN 2) into CLOUD, left and right:
 * added to what the tracks send it, before its diffusion (FREEZE holds it, SHIMMER takes it up), FRS_BLOCK frames late
 * (the engine renders a block ahead); its level, the host's. in_l or in_r 0: none, frs_render's samples bit for bit.
 * Not the FM-1's (the AC79 has no input) */
void frs_render_in(const float *in_l, const float *in_r, float *left, float *right, uint32_t n);
void frs_cloud_clear(void);              /* CLEAR: the cloud emptied (its tail, what FREEZE holds), its return faded out
                                          * over the next block (no click); its settings kept, FREEZE too */
void frs_gain(float g);                  /* the output's level, 0 .. 1 (the FM-1's MASTER; 1 at the start) */
void frs_panic(void);                    /* silence at once, all of it: every note let go (the drones', GLINT's, the
                                          * bass's, MIDI's, HOLD's), the arpeggio and the sequences stopped, the MIDI
                                          * waiting dropped, the echoes and the cloud's tail gone */
void frs_cut(void);                      /* CUT (the FM-1's OCT- held, PLAY): RELEASE ALL, then the echoes, the cloud's
                                          * lines and the tape's loop emptied over the next two blocks, the first faded
                                          * out (no click). 2.5.1's, the FM-1's too: some 40 ms on, what the cloud's
                                          * filters kept comes back faint (some 35 dB under) and dies away; a note given
                                          * before the second block is dropped by the sound (the brain has it) */
void frs_cut_stop(void);                 /* CUT as the iPad's transport has it: every track stopped (frs_track_play's
                                          * stop), each keeping what it plays, the sound emptied as frs_cut empties it;
                                          * PLAY (frs_play), frs_release_all or a track's own play brings each back.
                                          * RESTORE's notes as they were. frs_cut as it was (a stream's CUT from
                                          * before it) */
uint32_t frs_ms(void);                   /* the engine's clock: the millisecond it runs next */
uint32_t frs_ms_after(uint32_t frames);  /* frs_ms once frames more are rendered (each block runs the milliseconds before
                                          * it: what a render of them runs is frs_ms() up to this, less one) */
/* a recipe played from any place (a stream, FRASIL STREAM's radio). frs_tick_hook: fn first in every millisecond of the
 * brain, inside frs_render and frs_skip_to, there to call what a replay calls; from the thread that renders, never
 * frs_close, frs_init or frs_render inside it; 0 takes it off, and frs_init does. frs_skip_to: the brain alone from here
 * to the millisecond ms: the hook, the sequences, the LFOs, the notes kept up, nothing rendered: what plays there is what
 * a render to there would play, but the drones and the bass start from their attacks, the cloud, the echoes and the tape
 * empty, a GLINT struck in the skip gone. Ask 5 s early and render them unheard: the sound fills in. Each millisecond
 * costs what a block of a few frames does, nothing like a render */
void frs_tick_hook(void (*fn)(void *), void *user);
void frs_skip_to(uint64_t ms);

/* -------------------------------------------------------------- settings --- */
uint32_t frs_param_count(void);
int frs_param_info(uint32_t p, const char **name, uint32_t *max, uint32_t *def);   /* 0, or -1: no setting p */
/* what a setting is (frs_param_kind): one of these */
#define FRS_P_SCENE 1u                   /* kept in a scene: the sound (MASTER EQ, MASTER FILTER, LOFI TAPE, ROUTING, the
                                          * pans, CHOIR III's SOFT too), TEMPO, the bass's PLAYS, SEQ LENGTH, RATE,
                                          * TRANSPOSE, its arpeggio's MODE, RANGE, CHANCE, its GATE; the drone's
                                          * sequence's ON, RATE, SEQ LENGTH, GATE, CHANCE, TRANSPOSE (3.0); LOFI TAPE II's
                                          * four, the LFOs' AMOUNTs, SWELL ("FRS}": ENV held and CC 11 swell it too, of the
                                          * moment); the LEAD's 25 (card #152: not in scene_t, in a shard after it,
                                          * frs_lead_*) */
#define FRS_P_STATE 2u                   /* kept beside it (frs_state_save): KEY MODE, the MIDI channels, LOAD, CLOCK; KEYS
                                          * (3.0: P_KY_DR_HARM .. P_KY_BS_STACK), ARP SNAP (3.0: P_ARP_SNAP, a new chord into
                                          * an arpeggio taken on its grid; 1/4 at the start) */
#define FRS_P_MOMENT 3u                  /* kept nowhere, what plays now: FREEZE, KEYS, MORPH, RECORD, STEP, ARP
                                          * II's LATCH (P_GA_LATCH, P_BA_LATCH: the arpeggios' latch as it is) */
#define FRS_P_STEP 4u                    /* the step STEP points at: NOTE, ACCENT, LENGTH, the sequences' (it changes with
                                          * STEP; the drone's NOTES and LENGTH, P_DQ_NOTES, P_DQ_NLEN) */
#define FRS_P_ACTION 5u                  /* an action, not a value: turned to 2 it acts and comes back to 0 (CLEAR,
                                          * NEW TAKE, UNDO TAKE: the drone's P_DQ_UNDO too); not a plug-in's automation */
#define FRS_P_NONE 6u                    /* no setting (its number kept), or the FM-1's alone (SPK/JACK, ANIMATIONS,
                                          * SCREENSAVER; METRONOME and COUNT-IN, P_METRO and P_COUNT_IN:
                                          * frs_metronome, frs_record_metronome, frs_count_in here, which they show) */
uint32_t frs_param_kind(uint32_t p);
/* LFO TARGET's choices (P_L1_T1 .. P_L3_T4: 0 OFF, then 1 .. frs_lfo_targets()): the setting choice t moves (frs_param_*'s
 * number), or -1 (OFF, or none t). 2.5's: the 40 before, then MASTER FILTER's CUTOFF and RESONANCE, the four pans;
 * 2.6's 47th: CHOIR III's SOFT; then the ADSRs (48 .. 55), TAPE SAT and WOBBLE (56, 57); 3.2's 58 .. 61: LOFI TAPE II's
 * TAPE SPEED, TONE, NOISE, DROPOUT; 62 .. 83 the LEAD's (-1 without it, FRS_LEAD: a list shows none of them, a scene's
 * taken as OFF); 84 .. 89 the LFOs' own (card #199): LFO 1's RATE and DEPTH, LFO 2's, LFO 3's (one LFO on another's
 * pace, in octaves, or on its depth; on its own too) */
uint32_t frs_lfo_targets(void);
int frs_lfo_target(uint32_t t);
/* MASTER FILTER's and LOFI TAPE's TRACKS (P_FL_TRACKS, P_TP_TRACKS): the setting's values, and the tracks each is on
 * (frs_live_fx's bits: FRS_TRK_DRONE the drones and the cloud's return with them, unless ROUTING has the effect before
 * the cloud) */
#define FRS_TRACKS_ALL 0u
#define FRS_TRACKS_DRONE 1u
#define FRS_TRACKS_GLINT 2u
#define FRS_TRACKS_BASS 3u
#define FRS_TRACKS_DRONE_GLINT 4u
#define FRS_TRACKS_DRONE_BASS 5u
#define FRS_TRACKS_GLINT_BASS 6u
#define FRS_TRK_DRONE 1u
#define FRS_TRK_GLINT 2u
#define FRS_TRK_BASS 4u
uint32_t frs_tracks_bits(uint32_t tracks);   /* a TRACKS value's bits (FRS_TRK_*) */
/* LOFI TAPE's MEDIA (P_TP_ON, its first setting; card #99): its values. TAPE the tape as it ever was (ON's 1 before
 * them); an engine before them takes VINYL and AM as TAPE (a setting past its range: its range's last). PHONE (card
 * #218) after AM: an engine with VINYL and AM but not it takes it as AM, one before them as TAPE */
#define FRS_MEDIA_OFF 0u
#define FRS_MEDIA_TAPE 1u
#define FRS_MEDIA_VINYL 2u
#define FRS_MEDIA_AM 3u
#define FRS_MEDIA_PHONE 4u
uint32_t frs_param_get(uint32_t p);
void frs_param_set(uint32_t p, uint32_t x);   /* as the FM-1's encoder or a CC sets it: a preset's sound, CUSTOM from
                                               * a drone's setting turned, a layer's PLAYS; the sequences' steps: STEP,
                                               * then NOTE, ACCENT, the note's LENGTH (P_BQ_NLEN, P_SQ_NLEN: 1 .. 32 steps,
                                               * written as HOLDs or TIEs after it, to SEQ LENGTH's end); an action turned
                                               * twice (x 2) */
void frs_param_edit(uint32_t p, uint32_t x);  /* as the River's editor sets it: a sound setting or TEMPO, a sequence's
                                               * step (STEP: the step's own NOTE shown), the LEAD's (card #152:
                                               * frs_lead_get has them); what the shard plays edited once a step
                                               * changes (frs_scene_edited) */
void frs_param_text(uint32_t p, uint32_t x, char *out);   /* x as the FM-1's screen writes it (FRS_TEXT bytes) */
uint32_t frs_state_save(uint8_t *out);   /* the engine's state beside a scene (FRS_P_STATE's settings, MORPH's mark,
                                          * the metronome): FRS_STATE_BYTES at most, its length (its version 3: 2.6's
                                          * numbers, 3.0's after them; a 2.5 engine's, 2, and a 2.0 engine's, 1, are read
                                          * with their numbers made over; one before 3.0's, with KEY MODE and no KEYS: KEY
                                          * MODE read in as the drones' and the bass's LATCH; MORPH's mark, 254 then 1,
                                          * card #202: a scene's MORPH as this engine makes it, none while frs_morph_331;
                                          * TRACKS LINK's, 252 then frs_link_get's, while a track is moved, 251 then its
                                          * note followed once one is, 246 .. 249 then each track's baseline once it has
                                          * one: card #212, a state without them none linked, the note from what the one
                                          * followed holds, each baseline none) */
int frs_state_load(const uint8_t *in, uint32_t n);   /* back (what it doesn't know left as it is): 0, or -1 not one */
int frs_state_link(const uint8_t *in, uint32_t n);   /* its TRACKS LINK alone, as frs_state_load takes it: after a scene
                                          * taken (which leaves every baseline none), a stream's start takes the
                                          * state's again (fst_fresh). 0, or -1 not one */
/* ATTACK SHAPE (card #122, the FM-1's ENV pages: OCT- held, K1): each envelope's attack LINE (straight up) or CURVE (as
 * ever), a bit each: FRS_ASH_DRONE the drones', FRS_ASH_GLINT, FRS_ASH_BASS, FRS_ASH_LEAD the LEAD's, FRS_ASH_LFILT its
 * filter's (the LEAD's two kept without FRS_LEAD, heard with it); a bit set its LINE, 0 every one CURVE (at the start).
 * No setting: in no scene, of the moment, kept in the state (frs_state_save's pair, 253; a state without it, every one
 * CURVE). Heard from the next block. A recorder journals a change as FST_STATE, frs_state_save's bytes (the FM-1's
 * Perform LIVE: "FRst", its version, the pair alone). From the thread that renders (frs_view_t's ashape: a UI's) */
#define FRS_ASH_DRONE 1u
#define FRS_ASH_GLINT 2u
#define FRS_ASH_BASS 4u
#define FRS_ASH_LEAD 8u
#define FRS_ASH_LFILT 16u
void frs_ashape_set(uint32_t bits);      /* the five at once (past FRS_ASH_LFILT's: none) */
uint32_t frs_ashape_get(void);
/* LEAD CH (card #228, the FM-1's GLO › MIDI K4): the LEAD's MIDI channel, 0 OFF, 1 .. 16, 17 OMNI (FRS_LDCH_DEF, OFF,
 * at the start: a take with notes on a channel, a setup sending on one, as before it; past 17 OFF), its notes as they
 * come, MONO's or POLY's as the keys'; chord: on POLY, each one HARMONY's chord as a key on CHORD plays it (the FM-1's
 * LEAD KEYS, card #194). Another channel lets MIDI's notes on the LEAD go. No setting: in no scene, kept in the state
 * (frs_state_save's pair, 250, while not OFF, the chord with it; OFF: none, the state as before it; a state without it,
 * OFF, no chord). A recorder journals a change as FST_STATE (the FM-1's Perform LIVE: "FRst", its version, ATTACK
 * SHAPE's pair and this one). Without the LEAD: nothing (get: FRS_LDCH_DEF). From the thread that renders */
#define FRS_LDCH_DEF 0u
#define FRS_LDCH_CHORD 0x20u                 /* (get's: the channel in the bits under it) */
void frs_lead_midi_set(uint32_t ch, uint32_t chord);
uint32_t frs_lead_midi_get(void);
/* the running state (Perform LIVE, card #131, engine/live.c): what a start (a scene, the state, the moves) does not hold,
 * so that an engine opened on the same start goes on as this one does: the brain whole (the notes and what holds them,
 * the keys down, the arpeggiators and their draws, the sequences where they are and their takes, the grid and its
 * clock, the LFOs where in their turns, SPARKLE, MORPH, ANCHOR, SWELL, COUNT-IN, RESTORE's notes, UNDO's, the sound as
 * saved, TUNE A4), the sound's at half precision (each voice's drift, envelope, pressure and phases, the bass, the tide,
 * the generators, the cloud's sways, the tape's phases), the engine alone's own (the tracks stopped, the fingers). Not
 * the buffers: the cloud's room, GLINT's echoes and ringing glints, the tape's loop, a filter's state. scene: the
 * start's scene it goes with (FRS_SCENE_BYTES: the scene's bytes in it are kept against it), or 0. Compact (noughts in
 * runs): a few hundred bytes to some 2 KB, FRS_LIVE_BYTES at most.
 *   frs_live_save: its length, or 0 (max too small). Between two renders, from the thread that renders.
 *   frs_live_load: after the start was opened (fst_fresh), or in an engine that played on from somewhere near it: the
 *   engine runs on from that millisecond (frs_ms its), every sample as the saved one's would have been but for what the
 *   buffers held, the DSP's half precision, and on the FM-1's a block's own place in time. 0, or -1: another engine's
 *   (FRS_VERSION's layout, NPARAM, the scene's length), or cut short (the engine as it was, or partly loaded: open it
 *   again). From the thread that renders, between two renders or inside a frs_tick_hook.
 *   With the LEAD (card #152, FRS_LEAD's engines): two parts, "FRlv" (the rest, the settings before the LEAD's: the
 *   layout an engine without it reads, 4096 bytes at most) then "FRld" (the LEAD's: its settings, its keys, its
 *   voices, 1024 at most), each its own head; frs_live_save gives both, frs_live_load takes the first alone or both
 *   (an FM-1's STATE tells them apart, a listener joins them: design/perform/LIVE.md section 6). Loaded without the
 *   LEAD's: the keys on it let go, its settings as they are; a part it doesn't know (another LEAD's, another name's):
 *   left. An engine without the LEAD leaves the LEAD's, and lets the first's keys on it go */
#define FRS_LIVE_BYTES 5120u
uint32_t frs_live_save(uint8_t *out, uint32_t max, const uint8_t *scene);
int frs_live_load(const uint8_t *in, uint32_t n, const uint8_t *scene);
uint32_t frs_live_ms(const uint8_t *in, uint32_t n);   /* the millisecond a running state runs next (0: not one) */

/* --------------------------------------------------------------- playing --- */
/* a key down (key: 0 .. FRS_KEYS - 1, its note as played, MIDI's numbers; vel 1 .. 127): what the keys play (KEYS:
 * the drones, GLINT, BASS) and KEY MODE (LATCH, HOLD) say; single: one note on the drones, whatever CHORD says. With
 * frs_keys_touch on, each layer's KEYS say it instead (below: the FM-1's keys, 3.0) */
void frs_key_down(uint32_t key, int note, uint32_t vel, int single);
void frs_key_up(uint32_t key);
void frs_key_pressure(uint32_t key, uint32_t p);   /* 0 .. 127 */
/* the notes a key makes as the FM-1's KEYS make them on the LEAD and on MIDI (card #194: their HARMONY and NOTES, the
 * shell's own settings, never the engine's): harm 0, the note as played (the FM-1's at the start); harm 1 and chord 0
 * (SINGLE NOTE), the scale's note at or below it; harm 1 and chord 1 (CHORD), HARMONY's chord on it (ROOT, SCALE, CHORD,
 * VOICING: the drones'), its root first, the notes past 0 .. 127 left out (all of them: the scale's note alone). Into
 * out (FRS_CHORD_MAX at most), their count (1 at least). The LEAD's: chord only on POLY (P_LD_MODE 1; MONO, one voice:
 * chord 0), each note on a key number of its own, frs_key_down(k, note, vel, 1) (its first on the finger's key), each
 * let go with the finger (frs_key_up), its pressure each's: Perform LIVE and a stream's listener take them as keys of
 * their own (a listener can't build the chord). MIDI OUT's are its own (FRS_MO_HARM, FRS_MO_NOTES). A UI turning NOTES to
 * CHORD with HARMONY OFF turns HARMONY on too (the FM-1's knobs). The thread that renders (HARMONY as it is now) */
#define FRS_CHORD_MAX 4u
uint32_t frs_key_notes(int note, uint32_t harm, uint32_t chord, uint8_t *out);
/* THE KEYS, as the River has them, the track's (0 the drones, 1 GLINT's arpeggio, 2 the bass), the note as it sounds:
 * latched, or let go if it is (1 latched, 0 let go, -1 nothing: full, or under the scale's lowest); held while down
 * (nothing kept); cleared. GLINT's on KEYS: the same notes, the last four to come in ringing, held: a latch with four
 * there or more retires the oldest to come in (frs_view's arp, low to high, has what stayed; a scene's come in low to
 * high).
 *   Several fingers: frs_hold counts them, a note held by two lets go at the last up (each down needs its up); the
 *   bass plays one note, the last finger's: its top one up, the last still down plays again, the last up, back to the
 *   note under them (latched before, or over them meanwhile), or silent. A latch, CLEAR or an edit (frs_param_edit)
 *   lets go what it acts on alone: what the fingers hold sounds on (the River's editor lets it go first); a note
 *   latched that a finger holds (GLINT's, the bass's) stays once the finger lets go. A scene stored has what is
 *   latched, not what is held. A scene taken (but LOAD SND ONLY), frs_scene_stop, frs_panic, frs_release_all and
 *   MIDI's All Sound Off forget the fingers: what they held let go, their ups do nothing (KEY MODE turned: the
 *   drones' and the bass's fingers; All Notes Off on the drones' channel: theirs). A finger held at the down plays the
 *   same note at its up, OCTAVE turned meanwhile or not. An up lost (a touch cancelled): frs_hold_off.
 *   RECORD on (P_SQ_REC, P_BQ_REC: LIVE or STEP, the layer on SEQ), a finger on GLINT or the bass writes into its
 *   sequence as the FM-1's keys do (LIVE: the step nearest the playhead, the sequence playing; the bass's note as long
 *   as it is held), sounding while down; no ACCENT (a finger has no velocity).
 *   chord, the drones' (the other tracks' ignore it): FRS_CHORD_HARMONY, the chord HARMONY's
 * CHORD makes; else that CHORD's (0 SINGLE: one note, VOICING CLOSE; 1 FIFTH .. 14 DIM, frs_param_text's words),
 * HARMONY's ROOT, SCALE and VOICING as they are, for this note alone: CHORD stays as it is set (nothing edited, no
 * MORPH's step). A latched chord keeps its own notes whatever HARMONY becomes */
#define FRS_CHORD_HARMONY (-1)
int frs_latch(uint32_t track, uint32_t note, int chord);
void frs_hold(uint32_t track, uint32_t note, int down, int chord);
void frs_hold_off(uint32_t track);       /* every finger on the track's notes up (a touch cancelled, ups lost) */
void frs_clear(uint32_t track);
/* a track stopped, or played again (on), as a moment: nothing of it kept in a scene (a scene stored meanwhile has what
 * the track would play), nothing edited (frs_dirty as it was; but the bass's LIVE take under way, closed and written
 * as PLAY closes it), nothing in frs_state_save.
 *   0 the drones: stopped, every latched chord lets go and rings out, kept as it was latched (frs_view's kept; MIDI's
 *     and HOLD's chords, held, sound on); played again, the kept chords latch again, each with its own notes, at
 *     velocity 100 (as a scene's). A chord latched while they are stopped plays them again with it alone: what was
 *     kept goes.
 *   1 GLINT: on ARP the arpeggio waits, its notes kept (a HOLD meanwhile sounds its glint alone); again, it goes on
 *     from its pattern's top. On KEYS its notes the same, ringing or not. On SEQ the sequence stops; again, it plays from the grid's next step, in phase with the
 *     bass's sequence if that one plays: its steps where they would be had the two begun together (where the bass's
 *     began), whatever their loops' lengths, so mid-pattern; else from its first step.
 *   2 the bass: on ARP, as GLINT's. On SEQ (with notes in it), stopped; again, from the grid's next step, in phase with
 *     GLINT's sequence if that one plays (as GLINT's with the bass's), else from its first step. Else its latched note lets
 *     go, kept (a note held, MIDI's or a key's in HOLD, sounds on and is not kept); again, it plays. A note latched
 *     while it is stopped plays it again with that note: the kept one goes.
 * A stopped track stays stopped through MIDI's transport and a host's start or locate (they start the others). A scene
 * taken (but SCENES' LOAD SND ONLY), frs_scene_stop, frs_panic and frs_release_all leave no track stopped by the
 * player and nothing kept (what they play, or let go, as they always have: RELEASE ALL stops the sequences); so do
 * MIDI's All Sound Off and All Notes Off. KEY MODE turned lets what a stopped track keeps go (as it lets the latched
 * notes go). frs_clear on a stopped track clears what it keeps (it stays stopped). A setting that starts a track
 * (a layer's PLAYS turned, RECORD) plays it again */
void frs_track_play(uint32_t track, int on);
/* every track at once: stopped (each as frs_track_play has it), or played again: with no sequence playing, the
 * sequences from their first steps together, the beat beginning there as PLAY begins it (following a MIDI clock or
 * a host, at the grid's next step), the arpeggio from its pattern's top, the drones' and the bass's kept notes;
 * with one playing (a sequence, the arpeggio), each track as frs_track_play starts it, the grid as it is */
void frs_play_all(int on);
/* a MIDI message in (notes on each track's channel, their pressure, sustain, the CCs, clock, All Notes Off, All Sound
 * Off, Program Change: frs_callbacks; the transport, TRANSPORT on FOLLOW (card #204): Start, Stop (the sequences stop,
 * the arpeggios wait, the drones sound on), Continue (on from there), Song Position (its sixteenths: stopped, where
 * Continue goes on from; on a clock, there at once; each sequence where it would be had it played from the Start)):
 * at the next millisecond; _at: at the frame `offset` of the next frs_render (the host's time-stamp in its buffer).
 * One or the other: they wait in one queue, in order */
void frs_midi(uint8_t status, uint8_t d1, uint8_t d2);
void frs_midi_at(uint32_t offset, uint8_t status, uint8_t d1, uint8_t d2);
void frs_midi_ms(uint64_t ms, uint8_t status, uint8_t d1, uint8_t d2);   /* at the engine's millisecond ms itself: for a
                                          * replay, from a frs_tick_hook, where no frame is at hand */
/* the host's tempo and transport at the first frame of the next frs_render (a plug-in's host: its BPM, its beat
 * position, playing or not): playing, the grid follows it as a MIDI clock (its tempo exactly, PUMP, the delay, the LFOs
 * on the grid), and it begins as a MIDI Start does (the grid's top where the host starts or locates, not on the
 * host's bar: FRASIL has no song position); stopped, the grid runs on TEMPO again. bpm 13 to 999, else (0) no host
 * tempo; the beat finite (|beat| up to 1e9; NaN: 0). CLOCK INTERNAL (P_CLOCK 1): the host's tempo not followed, the
 * grid on TEMPO; back to AUTO while the host plays, it begins there as a Start (the grid's top, the sequences' first
 * steps) */
void frs_host_tempo(double bpm, double beat, int playing);
/* SONG POSITION for a host (an AUv3's): on, a host's start or locate puts the grid and each sequence where they would be
 * had they played from the host's beat 0, as MIDI's Song Position then Continue do (card #204: GLINT's on the grid's
 * steps, the bass's and the drone's in their loops, a step under way silent till the next; the arpeggios on the grid's
 * step), and its stop is a Stop (the sequences stop, the arpeggios wait, the drones sound on; played again, from the
 * host's place); a start before beat 0 (a count-in; a start on it, its first millisecond's), a Start as without it,
 * the grid's top there. TRANSPORT TEMPO ONLY or CLOCK INTERNAL: none of it, as MIDI's. Off at the start (frs_init's):
 * the host's start the grid's top, its stop TEMPO again, as before it. The shell's to keep (none in a scene or the
 * state) */
void frs_host_song(int on);
int frs_play(void);                      /* PLAY tapped (2.5's): nothing playing at all, the scene given last's three
                                          * tracks (what RELEASE ALL let go, else its own notes, its sequences from their
                                          * first steps, the beat beginning there); what the transport stopped
                                          * (frs_track_play, frs_play_all) and nothing else playing: that, back
                                          * (frs_play_all(1)); else the sequences stop together, or start together from
                                          * the top, the arpeggio playing alone beside them starting again with them (an
                                          * arpeggio alone: it waits, or goes on). 1: something played as it was tapped
                                          * (the FM-1's: tapped again within FRS_PLAY_TWICE_MS, frs_release) */
#define FRS_PLAY_TWICE_MS 350u           /* PLAY tapped twice quick (the second within it of one that returned 1) */
void frs_release(void);                  /* PLAY tapped twice quick: RELEASE ALL (what it let go kept for RESTORE), never
                                          * RESTORE; the beat begins there */
void frs_release_all(void);              /* PLAY held: RELEASE ALL while anything plays; else RESTORE (what it let go,
                                          * else the scene given last's notes) */
int frs_record(void);                    /* REC, the layer the keys play (on the drones, GLINT): OFF, LIVE, STEP, OFF, its
                                          * PLAYS turned to SEQ as it begins (its arpeggio's notes kept): 1 GLINT's
                                          * recording, 2 the bass's, 0 off (P_SQ_REC, P_BQ_REC say LIVE or STEP); no
                                          * count-in (2.x's) */
int frs_record_layer(uint32_t layer);    /* REC on a layer (3.0's: 0 the drone, 1 GLINT, 2 the bass): OFF, LIVE, STEP,
                                          * OFF; LIVE turns its PLAYS to SEQ (the drone's: P_DQ_ON), its sequence playing
                                          * at once, or, COUNT-IN on (frs_count_in) and nothing playing (no sequence, no
                                          * arpeggio), after a bar counted in, everything from the downbeat with the
                                          * take (frs_view's counting); STEP on the drone: a chord from the keys and
                                          * fingers down, STEP on past it (its LENGTH, P_DQ_NLEN) as the last lets go.
                                          * Recording already, REC moves that layer's take on, else the one recording;
                                          * OFF ends a count under way. Each take begins with UNDO TAKE's copy (P_SQ_UNDO,
                                          * P_BQ_UNDO, P_DQ_UNDO). 1 GLINT's recording, 2 the bass's, 3 the drone's, 0
                                          * none (P_DQ_REC as P_SQ_REC) */
void frs_swell(int held);                /* the drone swells while held (the FM-1's ENV held) */
void frs_metronome(int on);              /* a tick on each of the grid's beats, recording or not (off: only a take's) */
void frs_record_metronome(int on);       /* REC's metronome: a take's ticks (on its sequence's beats from its first
                                          * step; on at the start, as the FM-1's; frs_state_save keeps it). P_METRO
                                          * shows the two (0 OFF, 1 REC: a take's, 2 ALWAYS: frs_metronome's), the FM-1's
                                          * GLO › RECORD K1; set, it sets them (2: both on) */
void frs_count_in(int on);               /* COUNT-IN: frs_play_all(1) with nothing playing and a LIVE take armed (P_SQ_REC
                                          * or P_BQ_REC 2, the layer on SEQ) ticks a bar first (four beats at the grid's
                                          * tempo, the one high, whatever the metronome), then starts on the downbeat
                                          * after it, the take with it (frs_view's counting, count_beat). A stop, CUT,
                                          * PANIC, RELEASE ALL, a track played or stopped, a scene taken or stopped: no
                                          * more count, nothing started. Off at the start (P_COUNT_IN shows it: the
                                          * FM-1's GLO › RECORD K2, on there at the start; frs_record_layer counts in
                                          * too) */
#define FRS_LINK_DRONE 1u                /* TRACKS LINK's tracks (frs_link_set, frs_link_get) */
#define FRS_LINK_BASS 2u
#define FRS_LINK_GLINT 4u
#define FRS_LINK_MIDI 8u                 /* (MIDI OUT's, FRS_MIDI_OUT's engines) */
#define FRS_LINK_FOLLOW_BASS 16u         /* (frs_link_get: the bass followed) */
void frs_link_set(uint32_t follow, uint32_t tracks);   /* TRACKS LINK (card #212, the FM-1's HOME › TRACKS LINK): the
                                          * track followed (0 the drone, 1 the bass) and those LINKED (FRS_LINK_*; the
                                          * one followed's kept but not moving it, for when the other is followed:
                                          * FOLLOW turned leaves each as it was; none moved: off). Its note struck last
                                          * (the drone's chord's root, its sequence step's lowest; the bass's note as
                                          * played) is the note followed; each track linked has its own baseline, the
                                          * note followed as it was LINKED (nothing moves then; nothing followed yet,
                                          * the next one); FOLLOW turned, each keeps its offset (its baseline made
                                          * from what the other holds now, or from its first note); none with a scene
                                          * taken. The degrees of SCALE from a track's
                                          * baseline to the note followed, -n/2 .. n/2: it plays its notes that many
                                          * steps along the scale (the drones' notes held struck again there, the
                                          * bass's retuned, GLINT's and MIDI OUT's next ones), what they play and record
                                          * as played. The engine's, in no scene: frs_state_save keeps it. Off at the
                                          * start */
uint32_t frs_link_get(void);             /* its tracks LINKED as set (FRS_LINK_*), FRS_LINK_FOLLOW_BASS the bass
                                          * followed */
void frs_overdub(int on);                /* OVERDUB: a LIVE take adds its notes to the sequence (on at the start, as the
                                          * FM-1's). Off, its first turn replaces it: each step, as the playhead comes to
                                          * it, a rest (the bass's a CUT), what was there heard until then, unless the take
                                          * wrote it; a turn on, it adds */
void frs_step_stays(int on);             /* RECORD STEP (P_SQ_REC, P_BQ_REC, P_DQ_REC 1) without moving on: STEP stays
                                          * where it is, the UI moving it (P_SQ_STEP, P_BQ_STEP, P_DQ_STEP); a key on
                                          * GLINT's or the bass's step writes its one note there (the one before
                                          * replaced, LENGTH 1), the drone's adds beside its notes. Off at the start (the
                                          * FM-1's: STEP on past what was written) */
void frs_tape_302(int on);               /* TAPE SPEED's byte as 3.0.2 read it (log2's own: a 32nd of an octave a step
                                          * under X1.00, a 63rd over; X0.79 at 53, X0.89 since 3.1), what it moves and its
                                          * words: a take of 3.0.2's layout replayed on its own steps (fst_fresh sets it
                                          * from the stream: card #160). Off at the start, frs_init's */
void frs_morph_331(int on);              /* a scene's MORPH as 3.3.1 and the engines before made it: the notes LOAD
                                          * SND+NOTES lets go and plays on the ATTACK and RELEASE heard then (since card
                                          * #202, over the MORPH's length), MASTERING's THRESHOLD and GAIN, CLOUD's level
                                          * and MASTER EQ at the scene's at once: a stream of theirs as it played
                                          * (fst_fresh sets it before a state, a state since sets it off: its mark,
                                          * frs_state_save). Off at the start, frs_init's */
void frs_compare(int on);               /* the scene as taken sounds, not as it is now (the FM-1's EDIT held) */
void frs_trying(int on);                 /* the player tries a line on GLINT's sequence (RECORD OFF): its keys play
                                          * their glints, the sequence as it was (the FM-1's GLINT SEQ pages) */

/* ---------------------------------------------------------------- scenes --- */
void frs_scene_take(const uint8_t *scene);   /* as a load takes it: its sound, what it plays, its sequences from the
                                              * top (the FM-1's LOAD SND+NOTES) */
void frs_scene_play(const uint8_t *scene, int hold);   /* the River's: taken, its notes edited from here (frs_latch...,
                                                        * frs_scene_edited); hold: one that plays nothing holds a chord
                                                        * on its ROOT (▶: never saved) */
void frs_scene_go(const uint8_t *scene);     /* as the FM-1's SCENES has it: MORPH (its time), LOAD (SND ONLY: what
                                              * plays stays) */
float frs_morph_progress(void);          /* a scene's MORPH under way (frs_scene_go with MORPH's time, a Program Change's
                                          * scene gone to too; card #225, the FM-1's frame round its screen): how far, 0 ..
                                          * 1 by the engine's clock; -1 none (ANCHOR's way back: frs_anchor_state's). The
                                          * thread that renders; frs_view_t's morph from any (frs_snapshot) */
void frs_scene_stop(void);               /* every note let go, the sequences stopped */
void frs_scene_store(uint8_t *out, const uint8_t *from);   /* the scene as STORE keeps it now (its sound, what plays,
                                                            * its sequences, its TEMPO; its name from `from`, its 32,
                                                            * else NEW SHARD's), and the sound marked as saved */
void frs_scene_edited(const uint8_t *played, uint8_t *out);   /* the River's: the shard played as it is now (its
                                                               * notes once edited) */
void frs_scene_new(uint8_t *out);        /* NEW SHARD */
void frs_keys_defaults(void);            /* KEYS back to their defaults, as NEW SHARD gives them on the FM-1 (a scene
                                          * keeps none: the runner's NEW SHARD calls this) */
int frs_scene_factory(uint32_t i, uint8_t *out);   /* the factory scenes: 0, or -1: none i */
int frs_scene_over(uint8_t *scene, uint32_t n);   /* a scene read from an earlier layout, its n bytes first in scene,
                                          * which holds FRS_SCENE_BYTES: every one with no name past sixteen, every LFO
                                          * AMOUNT at x1.00 and SWELL at 0 (as they played: "FRS{"'s 590, that alone),
                                          * LOFI TAPE II's four as the tape was (64, 64, 0, 0: TAPE SPEED X1.00, TONE 0; not their defaults; 3.0's 586, "FRSz", that alone), the drone's sequence none (off,
                                          * every step a rest, its settings their defaults): 3.0's first, 324 ("FRSy"),
                                          * that alone; 2.7's 323 ("FRSx": AUTO VIB at 0), 322 ("FRSw": the bass's SPACE too), 319 ("FRSv": BASS TONE too); 2.6's 297 ("FRSt": its bass's sixteen notes, then
                                          * their lengths, onto the one grid, the FM-1's own rule) or 2.7's first test
                                          * builds' 298 ("FRSu"), made over in place: PLAYS' 1 (SEQUENCE on) is 2, the
                                          * bass's arpeggio none, its settings and GATE their defaults, whatever bytes
                                          * were after n. FRS_SCENE_BYTES itself: as it is. 0, or -1 a size it does not
                                          * know, scene untouched */
void frs_scene_amt_over(uint8_t *scene); /* a scene of "FRS|" (3.0.2-b5's test builds: the same 619 bytes, each LFO AMOUNT
                                          * -100 % .. +100 %, 100 its 0 %) made "FRS}"'s in place: each AMOUNT the
                                          * multiplier of its size, |v - 100| (+100 % x1.00, -35 % x0.35, 0 % x0.00: a
                                          * multiplier has no sign); one past 200 x1.00 */
int frs_dirty(void);                     /* the sound changed since the scene was taken or stored */

/* ------------------------------------------------------------------ LEAD --- */
/* LEAD (card #144, dsp/lead.c; the app's builds and STREAM's: FRS_LEAD 1): a fourth track over everything, played from
 * the keys alone (KEYS' TRACK P_KB 3, then frs_key_down, frs_key_up, frs_key_pressure: a stream's FST_KEY_LEAD sets
 * P_KB so and downs the key, FST_KEY_UP and FST_KEY_PRESSURE as any key's; no arpeggio, no sequence, nothing latches,
 * RELEASE ALL leaves a key held; frs_panic and frs_cut silence it), MONO (the last key down sounding, a key played
 * while another is down gliding there: GLIDE, not struck) or POLY (FRS_LEAD_NV voices, a free one, else the quietest
 * let go, else the oldest held). Its settings are FRS_P_SCENE's, P_LD_PRESET a preset's sound; LFO TARGET's 62 .. 83
 * are its 22 (as the FM-1's). What sounds: frs_view_t's lead_note, lead_level, lead_held, lead_meter. A scene keeps none of it
 * (scene_t, FRS_SCENE_BYTES: the FM-1 keeps each scene's LEAD in an object of its own); a shard does: "FRS~",
 * FRS_SHARD_BYTES, the scene's bytes then the LEAD's FRS_LEAD_BYTES, its settings P_LD_WAVE .. P_LD_FRELEASE in order
 * (WAVE, FILTER, RESONANCE, DETUNE, GLIDE, FILTER ENV, VIBRATO, OCTAVE, ATTACK, DECAY, SUSTAIN, RELEASE, TIME, FEEDBACK,
 * MIX, SPACE, its MIXER level P_MX_LEAD, PRESET, MODE, BREATH, DRIVE, F.ATTACK, F.DECAY, F.SUSTAIN, F.RELEASE). An
 * older shard ("FRS}" and before): its LEAD MOSS, every setting its default. A shard played: frs_scene_play (or
 * _take, _go) with its first FRS_SCENE_BYTES, then frs_lead_take with the rest; stored: frs_scene_store, then
 * frs_lead_get after it. ANCHOR keeps none of the LEAD.
 *   frs_lead_none: MOSS's bytes (any thread, open or not).
 *   frs_lead_take: in's into the settings as a scene's LEAD is taken (the FM-1's scene load): each past its max its
 *   default (PRESET's CUSTOM, its last: the settings as they came, no preset's sound over them), the LEAD as saved
 *   with them (frs_dirty), its voices as they are (a MODE changed so: the next key in it).
 *   frs_lead_put: in's as the LEAD is now (an edit: each past its max its default, PRESET's CUSTOM; the LEAD as saved
 *   left; MODE changed: its voices let go, as frs_param_set's); a preset's sound, frs_param_set on P_LD_PRESET
 *   (CUSTOM: its name alone).
 *   frs_lead_get: the settings as they are.
 *   frs_lead_wheels: the SMK-37's wheels on it: mod 0 .. 127 (VIBRATO's depth, if more), the pitch wheel -8192 .. 8191
 *   (two semitones either way).
 * Built without the LEAD (FRS_LEAD 0: the iPad's copy, a plug-in's): frs_lead_none and frs_lead_get give MOSS, the rest
 * does nothing, NPARAM has none of its settings; a shard it makes ("FRS~") has MOSS. From the thread that renders, but
 * frs_lead_none */
void frs_lead_none(uint8_t *out);
void frs_lead_take(const uint8_t *in);
void frs_lead_put(const uint8_t *in);
void frs_lead_get(uint8_t *out);
void frs_lead_wheels(uint32_t mod, int32_t bend);

/* -------------------------------------------------------------- MIDI OUT --- */
/* MIDI OUT (card #192, engine/mout.c: built with FRS_MIDI_OUT 1, the iPad's; the FM-1's is its app's, app/mseq.c): a
 * fifth track whose notes go out over MIDI, never sounding here. Its keys (frs_mout_key: the shell's key numbers,
 * shared with frs_key_down's, one never both at once; the note as played, no HARMONY, the shell's octave on it) go out
 * on KEYS, into its arpeggio on ARP (the engine's arpeggiator on FRASIL's grid: GLINT's MODE, RATE, RANGE, CHANCE, LATCH,
 * ARP SNAP; GATE, VELOCITY, SWING its own), or nowhere on SEQ (its 32 steps, GLINT's bytes: 0 a rest, 127 a tie, else
 * the note, + 128 ACCENT; SEQ LENGTH, RATE, GATE, CHANCE, TRANSPOSE along the scale). A key's pressure goes out as
 * PRESSURE says (CHANNEL: the hardest key's, POLY: each key's). VELOCITY: NORMAL as played, SOFT more for a light
 * touch, HARD less, FIXED 100. Its KEYS (card #194, the FM-1's MIDI KEYS page): HARMONY OFF the note as played (at the
 * start), ON the scale's note at or below it, with NOTES CHORD HARMONY's chord on it (frs_key_notes'), every note of it
 * out on CHANNEL at the key's velocity and each let go with its key (a note two keys have out: on once, off with the
 * last), into its arpeggio each, its SEQ one note (a step's). CLOCK OUT: the grid's clocks, Start and Stop with its
 * sequence (and FRASIL's transport; after frs_skip_to, the transport as it is there: Start, Stop, or Stop then Start for
 * a Start the skip went past).
 *   NOTES OUT (card #201, the FM-1's GLO › MIDI II K3; frs_mout_notes, off at the start): the notes FRASIL plays by
 * itself out too, its sound as it was: GLINT's arpeggio and sequence on channel 14, SPARKLE's glints on 15, the bass's
 * arpeggio and sequence on 16 (PULSE's gaps too), each as it sounds (GLINT's OCTAVE, the bass's on it) at its strike's
 * velocity, let go as the engine lets its own go; all of them at RELEASE ALL, CUT, a scene's load, a panic, off. A note
 * of a channel out once (struck again by another: let go first); none struck in frs_skip_to (what lets go, out). The
 * keys', the drones', the LEAD's, MIDI in's: none. Not MIDI OUT's own (its strip, frs_mout_view's out, has none).
 * frs_play_all plays or stops its sequence and its arpeggio with the others; frs_cut, frs_cut_stop, frs_release_all and
 * frs_panic end every note it sent. Its settings and steps are the shell's to keep: none in a scene, a shard or a stream.
 * Each message is stamped with the engine's millisecond (frs_ms's clock) as it went out: frs_mout_read after each render
 * (the ms of the frames it rendered: frs_ms_after), as the shell sends them. From the thread that renders */
#if FRS_MIDI_OUT
enum { FRS_MO_TYPE, FRS_MO_MODE, FRS_MO_RATE, FRS_MO_RANGE, FRS_MO_CHANCE, FRS_MO_LATCH, FRS_MO_LEN, FRS_MO_GATE,
       FRS_MO_TRANS, FRS_MO_AGATE, FRS_MO_AVEL, FRS_MO_SWING, FRS_MO_CH, FRS_MO_VEL, FRS_MO_PRS, FRS_MO_CLOCK,
       FRS_MO_HARM, FRS_MO_NOTES, FRS_MO_N };
/* TYPE: 0 KEYS, 1 ARP, 2 SEQ; AGATE: GATE 5 .. 100 %, 101 LEGATO; AVEL: 0 AS PLAYED, else 1 .. 127; SWING: 0 OFF, else
 * 50 + it %; CH: 0 .. 15; VEL: SOFT, NORMAL, HARD, FIXED; PRS: OFF, CHANNEL, POLY; CLOCK: OFF, ON; HARM: HARMONY OFF, ON;
 * NOTES: SINGLE NOTE, CHORD (a key's notes changed, the keys down keep theirs). The others GLINT's settings' ranges and
 * words */
typedef struct {
    uint32_t ms;                         /* the engine's millisecond it went out at */
    uint8_t status, d1, d2, pad;
} frs_mout_ev_t;
typedef struct {
    uint8_t v[FRS_MO_N];                 /* its settings */
    uint8_t seq[32];                     /* its steps */
    uint32_t out[4];                     /* the notes out now: bit n % 32 of out[n / 32] */
    int8_t pos;                          /* its sequence's step playing, -1 none */
    uint8_t playing;                     /* its sequence playing, or its arpeggio stepping */
    uint8_t last, last_vel;              /* the last note out, its velocity */
    int8_t arp[16];                      /* its arpeggio's notes, low to high, -1 past narp */
    uint8_t narp;
    int16_t sounding;                    /* the arpeggio's note out, -1 none */
    uint32_t sent;                       /* messages out since frs_init */
} frs_mout_view_t;
void frs_mout_key(uint32_t k, int note, uint32_t vel, int down);
void frs_mout_pressure(uint32_t k, uint32_t p);
void frs_mout_set(uint32_t i, uint32_t v);
uint32_t frs_mout_get(uint32_t i);
uint32_t frs_mout_min(uint32_t i);       /* (any thread) */
uint32_t frs_mout_max(uint32_t i);       /* (any thread) */
void frs_mout_text(uint32_t i, uint32_t v, char *out);   /* its words (FRS_TEXT; any thread) */
void frs_mout_play(int on);              /* its sequence (from its top), its arpeggio: on or stopped */
int frs_mout_playing(void);
void frs_mout_steps(const uint8_t *in);  /* its 32 steps */
void frs_mout_step(uint32_t i, uint32_t b);
void frs_mout_clear(void);               /* its steps and its arpeggio's notes gone */
void frs_mout_view(frs_mout_view_t *v);
uint32_t frs_mout_read(frs_mout_ev_t *out, uint32_t max);   /* the messages out since the last read, oldest first */
void frs_mout_notes(int on);             /* NOTES OUT on, or off (what it sent let go) */
uint64_t frs_mout_frames(void);          /* frames rendered since frs_init: frame f is millisecond f * 1000 / the rate */
#endif

/* ---------------------------------------------------------------- ANCHOR --- */
/* ANCHOR (the FM-1's OCT- and OCT+ together): the scene as it is now, kept in RAM alone (no store), to come back to after
 * playing on, at once or gliding. What comes back: what a scene keeps of the sound and its tracks (every setting of the
 * sound, the effects, HARMONY, each layer's PLAYS, ARP's and SEQ's settings, TEMPO, BASS TONE, LOFI TAPE II, the LFOs'
 * AMOUNTs, SWELL, the three sequences' steps); not what plays (the notes latched or held sound on, the sequences play on from where they are), nor KEYS,
 * FREEZE, what the keys play, nor SWELL's ENV held and CC 11 (of the moment). A take under way keeps its track's steps,
 * PLAYS and SEQ LENGTH.
 *   Gliding (ms): the settings that glide (the sound's that SCENES' MORPH glides, BASS TONE's, the bass's SPACE, AUTO
 * VIB, SWELL) from where they are heard to the anchor's, smoothstep, a hundred steps a second (the DSP gliding under
 * them: no zipper); the rest (a preset, a MODEL or TYPE, HARMONY's ROOT, SCALE, CHORD, a TARGET and its AMOUNT, a RATE,
 * PLAYS, TEMPO, SEQ LENGTH, LOFI TAPE II, the steps) switch together at its half. A setting set meanwhile (frs_param_set, a CC) leaves it, the rest going on; a
 * scene taken or gone to (frs_scene_take, _play, _go) drops the anchor and the way back, which glides on from where it
 * is to the new scene's. frs_scene_store meanwhile stores where it goes (its switch made then).
 *   A stream (frasil_stream.h: FST_ANCHOR, FST_ANCHOR_BACK, FST_ANCHOR_DROP) replays both bit for bit: a recorder
 * journals the anchor's bytes as it is set (frs_anchor_get, an FSTJ_SCENE for FST_ANCHOR), the way back's ms, a drop;
 * one that starts while anchored writes FST_ANCHOR first */
#define FRS_ANCHOR_MS 8000u              /* the FM-1's press: MORPH back (its long press until 3.1; 3500 until 3.0.2-b2, 14000 in b3) */
void frs_anchor_set(void);               /* set (again: the scene as it is now); a way back under way switches first */
int frs_anchor_back(uint32_t ms);        /* back to it, ms 0 at once, else gliding over ms; the anchor let go. None set: a
                                          * way back under way ends at once, its values there. 0, or -1 nothing to do */
void frs_anchor_drop(void);              /* let go (a way back under way goes on) */
int frs_anchor_state(float *k);          /* 0 none, 1 set, 2 a way back under way (*k, if given: how far, 0 .. 1) */
uint32_t frs_anchor_get(uint8_t *out);   /* the anchor's bytes (a scene's: FRS_SCENE_BYTES), its length; 0 none set */
void frs_anchor_put(const uint8_t *scene);   /* set as those bytes (a stream's replay) */
uint32_t frs_param_heard(uint32_t p);    /* setting p as it is heard (the thread that renders): during a way back (state
                                          * 2) a setting that glides on its way there, rounded, so that a screen moves
                                          * with the sound (frs_param_get has the anchor's at once); else frs_param_get's */

/* -------------------------------------------------- the drone's sequence --- */
/* DRONE SEQ (3.0): FRS_DQ_STEPS steps, each the notes it plays, FRS_DQ_NOTES at most: a chord as it was built (a chord
 * latched, single notes stacked over it), replayed as it was. Its settings, as GLINT's and the bass's: P_DQ_ON (OFF, ON;
 * no ARP), P_DQ_RATE (every step's, the bass's RATE's values: 1/16 .. 16 BARS, a beat, a bar, 2 and 4 BARS among them;
 * 1 BAR to begin with), P_DQ_LEN (SEQ LENGTH - 1: 1 .. 32 steps, 4 to begin with), P_DQ_GATE, P_DQ_CHANCE, P_DQ_TRANS
 * (along the scale, -14 .. +14 around 14), kept in the scene; P_DQ_REC (OFF, STEP, LIVE), P_DQ_CLEAR (turned twice: x
 * 2), P_DQ_STEP (the step RECORD STEP writes into), not kept.
 *   Playing: from the top with the other sequences (PLAY, a scene, MIDI Start; turned on, at the grid's next step), part
 * of the drones' track (frs_track_play 0 stops it with their chords, plays it again from its first step). A step's
 * notes sound on the drone as a held chord does, every layer, its own slow envelopes, let go at GATE's end in its last
 * step (a tie: on) or as the next step begins; a note a chord latched holds too is struck once and sounds while either
 * holds it. CHANCE leaves a step out (silent), on its own draws.
 *   RECORD: what the drones' keys sound goes into it, TRANSPOSE taken off (it plays as it was played): a chord latched
 * (frs_latch 0), a finger (frs_hold 0), a key (frs_key_down on the drones), a MIDI note on the drones' channel. LIVE:
 * into the step nearest the playhead, beside the notes it has (none twice, FRS_DQ_NOTES at most), its sequence playing
 * (stopped: they sound, nothing written; with frs_count_in, PLAY counts in for it as for the others; frs_overdub off, its
 * first turn replaces it as theirs do). STEP: into the step on P_DQ_STEP; it moves on once the last finger or key down
 * lets go (a latch adds to it, STEP staying: a chord built there, latch by latch). The keys play as they always do
 * meanwhile: a chord latched stays latched, over the sequence.
 *   Its steps in frs_view_t's dnote (and the step playing, dseq_pos); each step's bytes: its notes low to high, 1 .. 126,
 * as the step keeps them (TRANSPOSE off them), 0 after the last; all 0: a rest; FRS_DQ_TIE first (the rest 0): a tie,
 * the step before's notes held on.
 *   From knobs (3.0, the FM-1's DRONE SEQ II and III): P_DQ_NOTES, the step on P_DQ_STEP: 0 REST, 1 its notes, 2 TIE
 * (turned off its notes, they are kept; back to 1: those, with the drones' keys and fingers held now beside them; none at
 * all, HARMONY's chord on ROOT); P_DQ_NLEN, its chord's LENGTH in steps (its ties; on a tie, the chord it carries on;
 * RECORD STEP: the length the next chord takes, STEP on past it); P_DQ_UNDO turned twice, the sequence and its SEQ
 * LENGTH before the last take (RECORD on, from OFF) or CLEAR (again: back) */
#define FRS_DQ_STEPS 32u
#define FRS_DQ_NOTES 8u
#define FRS_DQ_TIE 127u
int frs_dseq_step(uint32_t step, const uint8_t *notes, uint32_t n);   /* step's notes set (n of them, as the step keeps
                                                                        * them: put low to high, none twice, the first
                                                                        * FRS_DQ_NOTES, past 1 .. 126 left out; n 0: a
                                                                        * rest; one FRS_DQ_TIE: a tie). 0, or -1 no step */
int frs_dseq_note(uint32_t step, uint32_t note, int on);   /* one note into the step (on: beside its others; a tie there
                                                            * becomes it; full: nothing) or out of it. 0, or -1 */
void frs_dseq_clear_step(uint32_t step);   /* a rest */

/* ------------------------------------------------------------------ KEYS --- */
/* KEYS (3.0; the iPad's TOUCH box, the FM-1's HOME › KEYS page): each layer's HARMONY (OFF: the keys chromatic, no
 * chord), NOTES (SINGLE NOTE, CHORD: HARMONY's chord, built on GLINT and the bass here too, each of its notes into their
 * arpeggio or sounding, as FrasilModel.press builds them; the bass on KEYS, GLINT on SEQ: one note), LATCH (OFF: HOLD,
 * the keys sound while down; GLINT's keys on KEYS sound so whatever it says, card #143, on ARP ARP II's LATCH theirs;
 * GLINT's turned OFF lets frs_latch's ring of four go), STACK (OFF: SWAP,
 * a new hand's key or chord in place of what the layer holds, keys down together stacking, as FrasilModel.latch's swap;
 * on, it adds, a tap on what is latched letting it go). P_KY_DR_HARM + 4 x layer + 0 .. 3 (0 the drone, 1 GLINT, 2 the
 * bass), FRS_P_STATE (frs_state_save: the device's, not a scene's). At the start: HARMONY ON, NOTES CHORD, LATCH ON
 * (the iPad's TOUCH defaults), STACK the drone's ON, GLINT's and the bass's OFF (the FM-1's ways). On ARP the
 * arpeggio's own LATCH says whether its notes stay (P_GA_LATCH, P_BA_LATCH: ARP II's, its latch as it is, ARP held
 * turning it); STACK says whether a new hand replaces them (latched).
 *   LATCH replaces KEY MODE (P_KEYS, GLOBAL's K4 till 3.0): KEY MODE set sets the drone's and the bass's LATCH (LATCH 0,
 * HOLD 1: off), every note let go as it always was; the drone's LATCH set shows in KEY MODE (a state of 2.x read in, an
 * FM-1 that still turns KEY MODE: the same). LATCH turned OFF lets that layer's latched notes go (the drones' chords,
 * GLINT's ring on KEYS, the bass's note on KEYS), what is held sounding on.
 *   Who honours them: the keys (frs_key_down, the FM-1's) once frs_keys_touch(1) (off at the start: the keys as 2.x's,
 *   KEY MODE's); MIDI's notes on the drones' channel always HARMONY and NOTES (as their defaults always did; GLINT's and
 *   the bass's MIDI notes come as they are played, LATCH and STACK not MIDI's: its note-offs, its sustain).
 *   frs_latch, frs_hold, frs_clear, THE KEYS', are as they were: the iPad's FrasilModel makes its TOUCH itself.
 * The iPad's way over (a later step): PlayChoices' latches, stacks, singles, harmonys read and written as these settings
 * (frs_param_get, frs_param_set; NOTES is !single), so that the iPad and the FM-1 tell one story; then either (a) keep
 * FrasilModel's latch/press as they are, reading these, or (b) hand the keys to the engine: frs_keys_touch(1), each
 * finger a key (frs_key_down with its note as played, the track the layer P_KB says, frs_key_up; a tap on a lit one lets
 * it go as on the FM-1), FrasilModel's SWAP and chord building gone. Its FM1Remote: the twelve as the FM-1's other
 * settings (P_KEYS no longer needed once it does) */
void frs_keys_touch(int on);

/* --------------------------------------------------------- a layer's preset --- */
/* A user's preset (3.0: the FM-1's and the iPad's UserPresets): a layer's sound under a name, apart from the scenes. Each
 * layer's settings (frs_preset_param: the iPad's UserPresets.sets, in its order): the drone's 33 a factory preset sets
 * (the River's DRONE_P), GLINT's ten (RATIO, BRIGHT, DECAY, SPACE, RELEASE, ATTACK, PING, SUSTAIN, VIBRATO, AUTO VIB), the
 * bass's fourteen (MODEL, DRIVE, FILTER, RESONANCE, GLIDE, ATTACK, DECAY, SUSTAIN, RELEASE, PULSE, WEIGHT, PUNCH, BITE,
 * SPACE); never LEVEL, OCTAVE, PRESET. Its bytes, FRS_PRESET_BYTES at most: "FRp", its version (1), its layer (0 the
 * drone, 1 GLINT, 2 the bass), n, its name (16 characters, NUL-padded, as a scene's), then n pairs: a setting's number,
 * its value. No storage here: the FM-1's store (the firmware's) and the iPad's presets.json keep them */
#define FRS_PRESET_HEAD 22u              /* its bytes before its pairs */
#define FRS_PRESET_BYTES 88u             /* a drone's, the longest */
uint32_t frs_preset_capture(uint32_t layer, const char *name, uint8_t *out);   /* the layer's sound as it sounds now,
                                                                                * named (NUL-ended, 16 at most; 0 none),
                                                                                * into out: its length, 0 no such layer */
int frs_preset_apply(const uint8_t *in, uint32_t n);   /* taken: its layer's settings each set as a hand sets them (the
                                                        * drone: CUSTOM, from them), another layer's or a setting it does
                                                        * not have left as they are: its layer, -1 not one */
int frs_preset_is(const uint8_t *in, uint32_t n);   /* the sound is it now: 1, else 0; -1 not one (the one lit) */
int frs_preset_param(uint32_t layer, uint32_t i);   /* the layer's setting i (0 ..), -1 past the last (any thread) */

/* ----------------------------------------------------------- CHORD PADS --- */
/* CHORD PADS (card #208, engine/chords.c; built with FRS_CHORDS 1: FrasilVibe's, the FM-1's and the SMK-37's to come
 * from its keys or MIDI notes). A chord: a DEGREE of HARMONY's key (ROOT, SCALE: 0 its I .. 6 its VII; a pentatonic
 * built on its mode's seven, MAJOR's or MINOR's, CHROMATIC on MAJOR's) and a TYPE: TRIAD, 6, 7, 9, SUS2, SUS4, ADD9 up
 * the scale from it, MAJOR, MINOR, DOM 7 the same on every degree (V7 in a minor key, IV minor in a major one).
 *   frs_chord_go moves the scene into it, the tracks frs_chord_follow names following (all five at the start):
 *   DRONE: the drones play the chord, HARMONY's VOICING on it, its root the nearest to where they played when it took
 *     them; what they play themselves (latched, held, their sequence) goes on silent, heard again once it gives them
 *     back (frs_chord_home, DRONE no longer following). Something that lets every drone note go meanwhile (KEY MODE,
 *     CUT's transport, RELEASE ALL) gives them back.
 *   GLINT, BASS, LEAD: each note they play from then on (their arpeggios, their sequences, a latched or held note, the
 *     keys, MIDI's, SPARKLE's) moved along the scale by the chord's degree (from the scale's I: up to three steps, up
 *     or down, the nearest way), and a note out of the scale that the chord has (A7's C# in D minor) altered so; the
 *     bass's note sounding goes there at once (gliding as its GLIDE does), GLINT's and the LEAD's ringing keep theirs.
 *   MIDI: a shell's MIDI track (frs_chord_note with FRS_CM_MIDI): its notes moved as GLINT's.
 *   GLIDE (on_beat 0): at once, the drones' voices one by one over MORPH's time (P_MORPH; CUT: together). ON THE BEAT
 *   (1): everything at the grid's next beat (or 4 s, its clock stopped), the drones together.
 * A scene taken (but LOAD SND ONLY's), frs_panic, frs_release, frs_release_all, frs_cut, All Sound Off: no move (the
 * drones given back). Nothing of it in a scene, a shard or frs_state_save; in the running state, the engine alone's
 * part. Without a move the engine renders what it rendered without FRS_CHORDS, sample for sample. From the thread that
 * renders, but frs_chord_notes, frs_chord_name and frs_chord_type_name (any thread: what they are given alone) */
#define FRS_CM_TYPES 10u                 /* TRIAD, 6, 7, 9, SUS2, SUS4, ADD9, MAJOR, MINOR, DOM 7 */
#define FRS_CM_DRONE 1u
#define FRS_CM_GLINT 2u
#define FRS_CM_BASS 4u
#define FRS_CM_LEAD 8u
#define FRS_CM_MIDI 16u
#define FRS_CM_ALL 31u
#if FRS_CHORDS
/* the chord's notes, close (its root in C4's octave, 60 .. 71, the rest above it), low to high: how many, 5 at most (0:
 * no such degree or type) */
uint32_t frs_chord_notes(uint32_t root, uint32_t scale, uint32_t degree, uint32_t type, int8_t *out);
/* its words: name ("Bbmaj7", "Em7b5", "A7": 16 bytes), its numeral ("VI7", "ii°7", "V7": 16 bytes); either may be 0 */
void frs_chord_name(uint32_t root, uint32_t scale, uint32_t degree, uint32_t type, char *name, char *numeral);
void frs_chord_spell(uint32_t root, uint32_t scale, uint32_t degree, uint32_t type, char *out);   /* its notes as the key
                                                                          * spells them, low to high ("Bb D F A", "A C# E G":
                                                                          * 24 bytes) */
const char *frs_chord_type_name(uint32_t type);   /* "TRIAD", "6TH" .. "DOM 7" ("" none) */
void frs_chord_go(uint32_t degree, uint32_t type, int on_beat);
void frs_chord_follow(uint32_t tracks);  /* FRS_CM_* bits */
void frs_chord_home(void);               /* no move: the scene as it is (RESET) */
int frs_chord_note(uint32_t track, int note);   /* a note as track (an FRS_CM_* bit) plays it now */
#endif

/* ---------------------------------------------------------------- a UI's --- */
typedef struct {
    uint32_t latched[4];                 /* the drones' chords latched, by root: bit n % 32 of latched[n / 32] */
    uint32_t held[4];                    /* the notes the drones' chords hold */
    int8_t arp[16];                      /* GLINT's arpeggio's notes (without OCTAVE), low to high */
    uint8_t narp;
    uint8_t seq[32];                     /* GLINT's sequence: 0 a rest, 127 a tie, else the note; + 128 ACCENT */
    uint8_t bnote[32];                   /* the bass's sequence: 0 CUT, 127 HOLD (the note before goes on), else the
                                          * note; + 128 ACCENT */
    uint8_t bq_steps, bq_len;            /* its SEQ LENGTH - 1, its RATE (P_BQ_LEN's value, every step's) */
    int8_t bass;                         /* the bass's note held, as it sounds; -1 none */
    int8_t seq_pos, bseq_pos;            /* the steps playing; -1 none */
    uint8_t seq_run, bseq_run;           /* the sequences playing */
    uint8_t arp_latch, arp_paused;
    int8_t barp[16];                     /* the bass's arpeggio's notes (without OCTAVE), low to high, as GLINT's */
    uint8_t nbarp;
    uint8_t barp_latch, barp_paused;
    int8_t barp_note;                    /* the note its step sounds (its RANGE's octaves on it, without OCTAVE), -1 none:
                                          * what GLINT's has in frs_live's 39 */
    uint8_t dirty;                       /* frs_dirty */
    float grid;                          /* the grid: MIDI clocks since its top (24 a beat) */
    float tempo;                         /* the BPM the grid runs at (a MIDI clock's, a host's, else TEMPO) */
    uint32_t ms;                         /* the engine's clock then */
    uint32_t kept[4];                    /* the drones' chords kept while they are stopped, by root (as latched) */
    uint8_t playing;                     /* bit t: track t plays (frs_track_play; 0 the drones, 1 GLINT, 2 the bass): a
                                          * transport's. GLINT on SEQ: its sequence runs; on ARP: its arpeggio doesn't
                                          * wait; the bass on ARP or SEQ, the same; else: not stopped */
    int8_t bass_kept;                    /* the bass's note kept while it is stopped, as it sounds; -1 none */
    uint8_t counting;                    /* PLAY counting in (frs_count_in) */
    uint8_t count_beat;                  /* its beats ticked, 1 .. 4 (0: its first about to) */
    uint8_t dnote[32][8];                /* the drone's sequence's steps (FRS_DQ_STEPS of FRS_DQ_NOTES: each its notes low
                                          * to high, 0 after them; a rest all 0; FRS_DQ_TIE first, a tie) */
    uint8_t dq_len, dq_rate;             /* its SEQ LENGTH - 1, its RATE (P_DQ_LEN's, P_DQ_RATE's values) */
    int8_t dseq_pos;                     /* the step playing; -1 none */
    uint8_t dseq_run;                    /* playing */
    uint8_t dq_snd[8], dq_nsnd;          /* the notes its step sounds now (TRANSPOSE on them), how many */
    int8_t lead_note[FRS_LEAD_NV];       /* the LEAD's voices (card #152; MONO the first alone): each one's note as it
                                          * sounds (OCTAVE on it), -1 silent; without the LEAD all -1 */
    uint8_t lead_held;                   /* its voices held (keys down on it) */
    float lead_level[FRS_LEAD_NV];       /* each one's envelope, 0..1 (a key's light) */
    float lead_meter;                    /* its recent peak, 0..1 (MIXER's K4, as the tracks' are frs_live's 42 .. 45) */
    float morph;                         /* a scene's MORPH under way, how far (frs_morph_progress: 0 .. 1, -1 none) */
    uint8_t ashape;                      /* ATTACK SHAPE's LINEs (frs_ashape_get: FRS_ASH_* bits) */
    /* CHORD PADS (card #208, FRS_CHORDS's engines; else all 0): the chord the scene is moved into */
    uint8_t cm_on;                       /* a chord's move in effect (frs_chord_go); 0 the scene as it is (home) */
    uint8_t cm_degree, cm_type;          /* its chord */
    uint8_t cm_follow;                   /* the tracks that follow it (FRS_CM_* bits) */
    uint8_t cm_wait;                     /* a move waiting for the grid's next beat (ON THE BEAT) */
    uint8_t cm_degree_next, cm_type_next;   /* ... its chord */
    uint8_t cm_hold;                     /* the drones play its chord (their own notes silent meanwhile) */
    int8_t cm_notes[8];                  /* the chord as the drones voice it, low to high, cm_n of them */
    uint8_t cm_n;
    float cm_glide;                      /* the drones' glide into it, 0 .. 1 (1: there) */
    int8_t cm_off[12];                   /* the semitones a note of each pitch class moves now, for a track that
                                          * follows (0 without a move): what the brain says GLINT's arpeggio and the
                                          * bass play (arp, bass) as they sound */
} frs_view_t;
void frs_view(frs_view_t *v);            /* now (the thread that renders) */
void frs_live(float *out);               /* what sounds now, FRS_LIVE floats (engine/core.c eng_live: the voices, the
                                          * glints, the bass, the LFOs, the steps, the meters, the tide, LOFI TAPE's
                                          * drag) */
int frs_snapshot(frs_view_t *v, float *live);   /* both, as they were after the last block, from any thread (a UI's,
                                                 * while the audio thread renders): 0, or -1 none yet (or busy: again) */
/* the effects as they sound now, FRS_LIVE_FX floats (the thread that renders; frs_snapshot_fx from any thread, as they
 * were after the last block):
 *    0 LOFI TAPE's mix (0 off .. 1)    1 its speed (1 as it should run: the reels)   2 3 4 its wow's, drift's and
 *      flutter's phases (turns)        5 a drag's depth (its deepest, 0: none)       6 7 SATURATION, WOBBLE as they sound
 *    8 MASTER FILTER's mix   9 its type (0 off, 1 low pass, 2 high pass)   10 its cutoff now (Hz)   11 its Q now
 *   12 its tracks (FRS_TRK_* bits)   13 before the cloud (1)
 *   14 MASTER EQ's mix   15 .. 29 its three biquads now (low shelf, bell, high shelf), each b0 b1 b2 a1 a2 (a0 divided
 *      out; frs_fx_response draws them)
 *   30 MASTERING's gain reduction now (dB, 0 or less)   31 the mix's recent peak (0..1, the louder side; before
 *      frs_gain, the FM-1's meter's)   32 33 the output's peak, left and right (0..1, after frs_gain: frs_render's)
 *   34 35 its RMS, left and right (0..1; some 300 ms; after frs_gain)
 *   36 PUMP's duck now (0..1: each track's gain 1 - 0.95 x its DEPTH x it; 0: no duck, RATE OFF)
 *   37 LOFI TAPE's medium sounding (FRS_MEDIA_*: 0 none; card #99; PHONE's 4: card #218)   38 39 (none yet: 0) */
void frs_live_fx(float *out);
int frs_snapshot_fx(float *fx);
/* what MASTER FILTER (which 0) or MASTER EQ (which 1) does at hz, in dB, as fx (frs_live_fx's, a snapshot's) has it
 * now, at the engine's rate (fs): its curve for a screen, from any thread (it reads fx alone) */
float frs_fx_response(const float *fx, int which, float hz, float fs);
/* the engine's words ("SEQUENCE" "CLEARED"; a: up to 23 characters, b too) and a Program Change on the drones'
 * channel (n: 0 .. 127, the app's to take a scene for), as they happen, in the thread that renders. The words live
 * during the call alone: copy them to keep them */
void frs_callbacks(void (*say)(void *user, const char *a, const char *b), void (*program)(void *user, uint32_t n),
                   void *user);

#ifdef __cplusplus
}
#endif
