/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Styves Goupil */
/* FRASIL's parameters: each one a byte (0 .. its max), how the screen writes it, and what the sound gets from them
 * all (params_to_engine). A scene is the first NSOUND of them. The engine's (core.c includes it; the pages the FM-1
 * shows them on: app/pages.c) */

#include "frasil_params.h"

/* how a value reads */
enum { F_PCT, F_ATT, F_REL, F_DECAY, F_PREDELAY, F_HZ, F_TAU, F_PERIOD, F_INTERVAL, F_CENTS, F_CHANNEL, F_ROOT, F_SCALE,
       F_CHORD, F_VOICING, F_KEYS, F_GPRESET, F_RATIO, F_OCTAVE, F_GDECAY, F_ARPMODE, F_ARPRATE, F_RANGE, F_BPM, F_GATTACK, F_DTIME, F_DMODE,
       F_GLIDE, F_BOCTAVE, F_BATT, F_BREL, F_ONOFF, F_PCTOFF, F_HZBASS, F_BMODEL, F_TRKCH, F_PUMP, F_THRESH, F_CRATIO,
       F_CREL, F_DBGAIN, F_LEVEL, F_PATT, F_SHAPE, F_CINT, F_HARM, F_BPITCH, F_SIGNED, F_CTYPE, F_LSHAPE, F_LRATE, F_LPOL,
       F_LTGT, F_SQLEN, F_SQNOTE, F_SQREC, F_SQCLEAR, F_SQTRANS, F_DPRESET, F_SQTYPE, F_KB, F_MORPH, F_LOAD, F_UNDO, F_NEWTAKE,
       F_BQNOTE, F_BQLEN, F_BDEC, F_BPULSE, F_GREL, F_EQPRESET, F_EQDB, F_EQLOWF, F_EQMIDF, F_EQQ, F_EQHIGHF, F_FLTYPE,
       F_FLCUT, F_FLTRACKS, F_PREPOST, F_PAN, F_ANIM, F_CLOCK, F_BQNLEN, F_DQNOTES, F_KNOTES, F_METRO, F_COUNTIN, F_ARPSNAP, F_TSPEED,
       F_AMT, F_XPORT
#if FRS_LEAD
       , F_LWAVE, F_LCUT, F_LOCT, F_LPRESET, F_LMODE   /* LEAD's (card #144) */
#endif
       , F_MEDIA                         /* LOFI TAPE's MEDIA (card #99) */
};

typedef struct {
    const char *name;
    uint8_t max, def, fmt;
} pdesc_t;

#define NLFO_TGT 90u                     /* an LFO TARGET's choices: OFF and the settings (LFO_TGT, below; LEAD's 22
                                          * after the rest, card #144, none on an engine without it; the LFOs' own RATE
                                          * and DEPTH last, card #199) */
#define LFO_T_XM 84u                     /* (LFO 1's RATE, the first of the LFOs' six: LFO_TGT) */
#define NDRONE 33u                       /* the settings a drone preset sets (DRONE_P, below) */
#define NDPRESET 36u
#define NPULSE 7u                        /* PULSE's choices: OFF, then its divisions (PULSE_TICKS, below) */
#if FRS_LEAD
#define NLPRESET 20u                     /* LEAD's presets (LEAD_PRESET, below) */
#define LP_MOSS 0u                       /* MOSS, the first LEAD's sound, LEAD's at every start */
#define LP_CUSTOM NLPRESET               /* CUSTOM, PRESET's last choice (admin #873, #875): no preset's sound, the
                                          * settings as they are; a number past the presets read so (lead_in) */
#endif
static const pdesc_t PD[NPARAM] = {
    [P_CHOEUR] = {"CHOIR", 127, 76, F_PCT},
    [P_PARTIELS] = {"PARTIALS", 127, 89, F_PCT},
    [P_SOUFFLE] = {"BREATH", 127, 32, F_PCT},
    [P_CHALEUR] = {"WARMTH", 127, 19, F_PCT},
    [P_DESACCORD] = {"DETUNE", 127, 51, F_PCT},
    [P_FILTRE] = {"FILTER", 127, 44, F_PCT},
    [P_PENTE] = {"TILT", 127, 57, F_PCT},
    [P_IMPAIRS] = {"ODD", 127, 25, F_PCT},
    [P_ETIREMENT] = {"STRETCH", 127, 0, F_PCT},
    [P_RESONANCE] = {"RESONANCE", 127, 70, F_PCT},
    [P_COULEUR] = {"COLOR", 127, 0, F_PCT},
    [P_ECART] = {"SPREAD", 127, 89, F_PCT},
    [P_ATTAQUE] = {"ATTACK", 127, 89, F_ATT},
    [P_RELACHE] = {"RELEASE", 127, 83, F_REL},
    [P_PRESSION] = {"PRESSURE", 127, 76, F_PCT},
    [P_VELOCITE] = {"VELOCITY", 127, 38, F_PCT},
    [P_MOUVEMENT] = {"MOTION", 127, 44, F_PCT},
    [P_VITESSE] = {"RATE", 127, 51, F_TAU},
    [P_MAREE] = {"TIDE", 127, 25, F_PCT},
    [P_PERIODE] = {"PERIOD", 127, 38, F_PERIOD},
    [P_TAILLE] = {"SIZE", 127, 95, F_PCT},
    [P_DUREE] = {"DECAY", 127, 79, F_DECAY},
    [P_TEINTE] = {"TONE", 127, 64, F_PCT},
    [P_SHIMMER] = {"SHIMMER", 127, 0, F_PCT},
    [P_DIFFUSION] = {"DIFFUSION", 127, 95, F_PCT},
    [P_MODULATION] = {"MODULATION", 127, 64, F_PCT},
    [P_PREDELAI] = {"PRE-DELAY", 127, 13, F_PREDELAY},
    [P_INTERVALLE] = {"INTERVAL", 4, 0, F_INTERVAL},
    [P_COUPEBAS] = {"LOW CUT", 127, 25, F_HZ},
    [P_LARGEUR] = {"WIDTH", 127, 127, F_PCT},
    [P_ACCORD] = {"TUNE", 100, 50, F_CENTS},
    [P_TIMBRE] = {"TIMBRE", 127, 64, F_PCT},
    [P_ESPACE] = {"SPACE", 127, 57, F_PCT},
    [P_ROOT] = {"ROOT", 11, 2, F_ROOT},
    [P_SCALE] = {"SCALE", 11, 0, F_SCALE},
    [P_CHORD] = {"CHORD", 14, 0, F_CHORD},
    [P_VOICING] = {"VOICING", 2, 0, F_VOICING},
    [P_GL_PRESET] = {"PRESET", 22, 8, F_GPRESET},
    [P_GL_RATIO] = {"RATIO", 12, 6, F_RATIO},
    [P_GL_BRIGHT] = {"BRIGHT", 127, 70, F_PCT},
    [P_GL_DECAY] = {"DECAY", 127, 70, F_GDECAY},
    [P_GL_LEVEL] = {"LEVEL", 127, 90, F_PCT},
    [P_GL_OCTAVE] = {"OCTAVE", 3, 2, F_OCTAVE},
    [P_GL_SPACE] = {"SPACE", 127, 90, F_PCT},
    [P_GL_RELEASE] = {"RELEASE", 127, 76, F_GREL},     /* 20 ms .. 6 s, once let go (600 MS: as DECAY's default
                                                        * let it go before) */
    [P_GL_ATTACK] = {"ATTACK", 127, 0, F_GATTACK},
    [P_GL_PING] = {"PING", 127, 68, F_PCT},
    [P_GD_TIME] = {"TIME", 11, 7, F_DTIME},            /* 1/32 .. 1/2, ping-pong (12 .. 23 till 2.5: the same, % 12) */
    [P_GD_FB] = {"FEEDBACK", 127, 50, F_PCT},
    [P_GD_MODE] = {"MODE", 1, 1, F_DMODE},             /* (kept for the store; TIME says it now) */
    [P_GD_MIX] = {"MIX", 127, 40, F_PCT},
    [P_ARP_MODE] = {"MODE", 4, 0, F_ARPMODE},          /* UP, DOWN, UPDOWN, RANDOM, DRIFT */
    [P_ARP_RATE] = {"RATE", 9, 5, F_ARPRATE},
    [P_ARP_RANGE] = {"RANGE", 2, 1, F_RANGE},
    [P_ARP_CHANCE] = {"CHANCE", 127, 127, F_PCT},
    [P_BS_DRIVE] = {"DRIVE", 127, 20, F_PCT},
    [P_BS_FILTER] = {"FILTER", 127, 80, F_HZBASS},
    [P_BS_GLIDE] = {"GLIDE", 127, 20, F_GLIDE},
    [P_BS_LEVEL] = {"LEVEL", 127, 90, F_PCT},
    [P_BS_OCTAVE] = {"OCTAVE", 2, 1, F_BOCTAVE},   /* -2 .. 0 under the keys */
    [P_BS_ATTACK] = {"ATTACK", 127, 30, F_BATT},
    [P_BS_RELEASE] = {"RELEASE", 127, 50, F_BREL},
    [P_BS_DECAY] = {"DECAY", 127, 64, F_BDEC},         /* 10 ms .. 10 s, from the top down to SUSTAIN */
    [P_BS_SUSTAIN] = {"SUSTAIN", 127, 127, F_PCT},     /* the level held (100 %: no decay, the bass as it was) */
    [P_BS_PULSE] = {"PULSE", NPULSE - 1u, 0, F_BPULSE},   /* OFF, 1/8 BEAT .. 4 BEATS */
    [P_BS_MODEL] = {"MODEL", BASS_NMODEL - 1, 0, F_BMODEL},
    [P_BS_RESO] = {"RESONANCE", 127, 20, F_PCT},
    [P_PUMP_RATE] = {"RATE", 6, 0, F_PUMP},
    [P_PUMP_DRONE] = {"DRONE", 127, 90, F_PCT},
    [P_PUMP_BASS] = {"BASS", 127, 60, F_PCT},
    [P_PUMP_GLINT] = {"GLINT", 127, 40, F_PCT},
    [P_MS_THRESH] = {"THRESHOLD", 40, 28, F_THRESH},   /* -40 .. 0 dB */
    [P_MS_RATIO] = {"RATIO", 7, 0, F_CRATIO},
    [P_MS_RELEASE] = {"RELEASE", 127, 62, F_CREL},
    [P_MS_GAIN] = {"GAIN", 18, 0, F_DBGAIN},           /* 0 .. +18 dB */
    [P_MX_DRONE] = {"DRONE", 127, 100, F_LEVEL},       /* 100: as it is (unity), up to 127 */
    [P_MX_BASS] = {"BASS", 127, 100, F_LEVEL},
    [P_MX_GLINT] = {"GLINT", 127, 100, F_LEVEL},
    [P_MX_CLOUD] = {"CLOUD", 127, 100, F_LEVEL},
    [P_SH_TONE] = {"BRIGHT", 127, 57, F_PCT},          /* the shimmer: ~2.1 kHz by default, softer than it was */
    [P_PUMP_REL] = {"RELEASE", 127, 127, F_PCT},       /* 10 .. 100 % of the period (100: as it was) */
    [P_PUMP_ATT] = {"ATTACK", 127, 36, F_PATT},        /* 1 .. 300 ms (5 ms by default) */
    [P_PUMP_OFF] = {"OFFSET", 127, 0, F_PCT},          /* the duck's place in the period, 0 .. 100 % */
    [P_CH_SHAPE] = {"SHAPE", 127, 0, F_SHAPE},         /* SAW .. SQUARE (the middle) .. a narrow PULSE */
    [P_CH_INTERVAL] = {"INTERVAL", 3, 0, F_CINT},      /* the centre saw: UNISON, -12, +7, +12 */
    [P_CH_RESO] = {"RESONANCE", 127, 0, F_PCT},
    [P_CH_TYPE] = {"TYPE", 2, 0, F_CTYPE},             /* the filter: LOW, BAND, HIGH */
    [P_CH_SOFT] = {"SOFT", 127, 0, F_PCT},             /* 0: the wave as SHAPE makes it; 50 %: a triangle of the
                                                        * square; 100 %: near a sine */
    [P_PA_EVOLVE] = {"EVOLVE", 127, 0, F_PCT},         /* 0: as MOTION has them */
    [P_PA_BEAT] = {"BEAT", 127, 0, F_PCT},
    [P_PA_FORMANT] = {"FORMANT", 127, 85, F_HARM},     /* the 1st .. 8th harmonic (the 4th by default) */
    [P_PA_PEAK] = {"PEAK", 127, 0, F_PCT},
    [P_BR_GRAIN] = {"GRAIN", 127, 0, F_PCT},
    [P_BR_PITCH] = {"PITCH", 4, 1, F_BPITCH},          /* -12, UNISON, +12, +19, +24 */
    [P_BR_TONE] = {"TONE", 127, 64, F_SIGNED},         /* 64: the noise white */
    [P_BR_AIR] = {"AIR", 127, 0, F_PCT},
    [P_GL_SUSTAIN] = {"SUSTAIN", 127, 0, F_PCT},
    [P_L1_SHAPE] = {"SHAPE", 6, 0, F_LSHAPE},
    [P_L1_RATE] = {"RATE", 75, 25, F_LRATE},           /* free (10 s by default), then on the grid */
    [P_L1_DEPTH] = {"DEPTH", 127, 0, F_PCT},           /* 0: the LFO off */
    [P_L1_POL] = {"POLARITY", 2, 0, F_LPOL},
    [P_L1_T1] = {"TARGET 1", NLFO_TGT - 1u, 0, F_LTGT},
    [P_L1_T2] = {"TARGET 2", NLFO_TGT - 1u, 0, F_LTGT},
    [P_L1_T3] = {"TARGET 3", NLFO_TGT - 1u, 0, F_LTGT},
    [P_L1_T4] = {"TARGET 4", NLFO_TGT - 1u, 0, F_LTGT},
    [P_L2_SHAPE] = {"SHAPE", 6, 0, F_LSHAPE},
    [P_L2_RATE] = {"RATE", 75, 25, F_LRATE},
    [P_L2_DEPTH] = {"DEPTH", 127, 0, F_PCT},
    [P_L2_POL] = {"POLARITY", 2, 0, F_LPOL},
    [P_L2_T1] = {"TARGET 1", NLFO_TGT - 1u, 0, F_LTGT},
    [P_L2_T2] = {"TARGET 2", NLFO_TGT - 1u, 0, F_LTGT},
    [P_L2_T3] = {"TARGET 3", NLFO_TGT - 1u, 0, F_LTGT},
    [P_L2_T4] = {"TARGET 4", NLFO_TGT - 1u, 0, F_LTGT},
    [P_SQ_TYPE] = {"PLAYS", 2, 0, F_SQTYPE},     /* GLINT I's K2: KEYS, ARP, SEQ (TYPE till 1.1, then SEQ) */
    [P_GX_SPARK] = {"SPARKLE", 127, 0, F_PCT},
    [P_GX_BLUR] = {"BLUR", 127, 0, F_PCT},
    [P_GX_SINK] = {"SINK", 127, 0, F_PCT},
    [P_L3_SHAPE] = {"SHAPE", 6, 0, F_LSHAPE},
    [P_L3_RATE] = {"RATE", 75, 25, F_LRATE},
    [P_L3_DEPTH] = {"DEPTH", 127, 0, F_PCT},
    [P_L3_POL] = {"POLARITY", 2, 0, F_LPOL},
    [P_L3_T1] = {"TARGET 1", NLFO_TGT - 1u, 0, F_LTGT},
    [P_L3_T2] = {"TARGET 2", NLFO_TGT - 1u, 0, F_LTGT},
    [P_L3_T3] = {"TARGET 3", NLFO_TGT - 1u, 0, F_LTGT},
    [P_L3_T4] = {"TARGET 4", NLFO_TGT - 1u, 0, F_LTGT},
    [P_SQ_LEN] = {"SEQ LENGTH", 31, 15, F_SQLEN},      /* 1 .. 32 steps */
    [P_SQ_GATE] = {"GATE", 127, 64, F_PCT},            /* a note's length, 5 .. 100 % of its step */
    [P_SQ_TRANS] = {"TRANSPOSE", 28, 14, F_SQTRANS},   /* -14 .. +14 steps of the scale */
    [P_SQ_STEP] = {"STEP", 31, 0, F_SQLEN},
    [P_SQ_NOTE] = {"NOTE", 127, 0, F_SQNOTE},          /* REST, a note, TIE */
    [P_SQ_ACC] = {"ACCENT", 1, 0, F_ONOFF},
    [P_SQ_REC] = {"RECORD", 2, 0, F_SQREC},            /* OFF (the keys transpose), STEP, LIVE */
    [P_SQ_CLEAR] = {"CLEAR", 2, 0, F_SQCLEAR},         /* turned twice: the steps cleared */
    [P_DR_PRESET] = {"PRESET", NDPRESET, 0, F_DPRESET},   /* PRESETS': CUSTOM, then the 36 */
    [P_DR_FULL] = {"BODY", 127, 127, F_PCT},           /* 100 %: the drone as its settings have it; down, thinner */
    [P_SWELL] = {"SWELL", 127, 0, F_PCT},
    [P_KB] = {"TRACK", 2 + FRS_LEAD, 0, F_KB},                    /* what they play */
    [P_MORPH] = {"MORPH", 8, 0, F_MORPH},              /* CUT, 1 S .. 2:00: the sound glides to the scene's */
    [P_LOAD] = {"LOAD", 1, 0, F_LOAD},                 /* SND+NOTES: the sound and its notes; SND ONLY: what plays goes on */
    [P_TRANSPORT] = {"TRANSPORT", 1, 0, F_XPORT},      /* TEMPO ONLY: MIDI's Start, Stop, Continue, Song Position
                                                        * ignored (card #204) */
    [P_SQ_NEW] = {"NEW TAKE", 2, 0, F_NEWTAKE},
    [P_SQ_UNDO] = {"UNDO TAKE", 2, 0, F_UNDO},
    [P_BQ_STEP] = {"STEP", 31, 0, F_SQLEN},
    [P_BQ_NOTE] = {"NOTE", 127, 0, F_BQNOTE},          /* CUT, a note, HOLD */
    [P_BQ_LEN] = {"RATE", 8, 0, F_BQLEN},              /* every step's: 1/16 .. 16 BARS (BQ_TICKS, NBQLEN) */
    [P_BQ_NLEN] = {"LENGTH", 32, 0, F_BQNLEN},         /* the note on STEP's: 1 .. 32 steps (0: no note there, -) */
    [P_BQ_REC] = {"RECORD", 2, 0, F_SQREC},            /* OFF (the keys transpose), STEP, LIVE */
    [P_BQ_STEPS] = {"SEQ LENGTH", 31, 15, F_SQLEN},    /* 1 .. 32 steps */
    [P_BQ_ON] = {"PLAYS", 2, 0, F_SQTYPE},             /* BASS I's K2: KEYS, ARP, SEQ, as GLINT's */
    [P_BQ_CLEAR] = {"CLEAR", 2, 0, F_SQCLEAR},         /* turned twice: every step a CUT */
    [P_BQ_TRANS] = {"TRANSPOSE", 28, 14, F_SQTRANS},   /* -14 .. +14 steps of the scale */
    [P_BA_MODE] = {"MODE", 4, 0, F_ARPMODE},           /* UP, DOWN, UPDOWN, RANDOM, DRIFT */
    [P_BA_RANGE] = {"RANGE", 2, 1, F_RANGE},
    [P_BA_CHANCE] = {"CHANCE", 127, 127, F_PCT},
    [P_BQ_GATE] = {"GATE", 127, 127, F_PCT},           /* a note let go, 5 .. 100 % of its last step: at 100 %, on to the
                                                        * next NOTE or CUT, as it always went */
    [P_BQ_ACC] = {"ACCENT", 1, 0, F_ONOFF},
    [P_BS_WEIGHT] = {"WEIGHT", 127, 0, F_PCT},         /* BASS TONE's: 0 the bass as it was, each */
    [P_BS_PUNCH] = {"PUNCH", 127, 0, F_PCT},
    [P_BS_BITE] = {"BITE", 127, 0, F_PCT},
    [P_BS_SPACE] = {"SPACE", 127, 0, F_PCT},           /* the cloud's, as GLINT's: 0 none of the bass in it */
    [P_GL_VIB_AUTO] = {"AUTO VIB", 127, 0, F_PCT},     /* every glint's own wobble, fading in; VIBRATO's the finger's */
    [P_DQ_ON] = {"SEQUENCE", 1, 0, F_ONOFF},           /* the drone's sequence (core.c dnote): OFF, ON (no ARP) */
    [P_DQ_RATE] = {"RATE", 8, 4, F_BQLEN},             /* every step's, as the bass's: 1/16 .. 16 BARS (a beat, a bar, 2
                                                        * BARS, 4 BARS among them); 1 BAR to begin with (the owner's:
                                                        * a take heard back in four bars, not sixteen) */
    [P_DQ_LEN] = {"SEQ LENGTH", 31, 3, F_SQLEN},       /* 1 .. 32 steps (4 to begin with: four bars) */
    [P_DQ_GATE] = {"GATE", 127, 127, F_PCT},           /* a step's notes let go, 5 .. 100 % of its last step (a tie on) */
    [P_DQ_CHANCE] = {"CHANCE", 127, 127, F_PCT},
    [P_DQ_TRANS] = {"TRANSPOSE", 28, 14, F_SQTRANS},   /* -14 .. +14 steps of the scale */
    [P_DQ_REC] = {"RECORD", 2, 0, F_SQREC},            /* OFF, STEP, LIVE: what the drones' keys sound, into it */
    [P_DQ_CLEAR] = {"CLEAR", 2, 0, F_SQCLEAR},         /* turned twice: every step a rest */
    [P_DQ_STEP] = {"STEP", 31, 0, F_SQLEN},            /* the step RECORD STEP writes into */
    [P_DQ_NOTES] = {"NOTES", 2, 0, F_DQNOTES},         /* the step on STEP: REST, its notes (how many; one: its name), TIE */
    [P_DQ_NLEN] = {"LENGTH", 32, 0, F_BQNLEN},         /* its chord's, 1 .. 32 steps (0: no chord there, -) */
    [P_DQ_UNDO] = {"UNDO TAKE", 2, 0, F_UNDO},
    [P_GA_LATCH] = {"LATCH", 1, 1, F_ONOFF},           /* the arpeggios latched from the start */
    [P_BA_LATCH] = {"LATCH", 1, 1, F_ONOFF},
    [P_KY_DR_HARM] = {"HARMONY", 1, 1, F_ONOFF},       /* KEYS: the owner's defaults, what NEW SCENE gives back: CHORD */
    [P_KY_DR_NOTES] = {"NOTES", 1, 1, F_KNOTES},       /* the drone's, GLINT and the bass SINGLE NOTE; LATCH on, STACK off */
    [P_KY_DR_LATCH] = {"LATCH", 1, 1, F_ONOFF},
    [P_KY_DR_STACK] = {"STACK", 1, 0, F_ONOFF},
    [P_KY_GL_HARM] = {"HARMONY", 1, 1, F_ONOFF},
    [P_KY_GL_NOTES] = {"NOTES", 1, 0, F_KNOTES},
    [P_KY_GL_LATCH] = {"LATCH", 1, 1, F_ONOFF},
    [P_KY_GL_STACK] = {"STACK", 1, 0, F_ONOFF},
    [P_KY_BS_HARM] = {"HARMONY", 1, 1, F_ONOFF},
    [P_KY_BS_NOTES] = {"NOTES", 1, 0, F_KNOTES},
    [P_KY_BS_LATCH] = {"LATCH", 1, 1, F_ONOFF},
    [P_KY_BS_STACK] = {"STACK", 1, 0, F_ONOFF},
    [P_METRO] = {"METRONOME", 2, 1, F_METRO},          /* OFF, REC (a take's ticks: the FM-1's at the start), ALWAYS */
    [P_COUNT_IN] = {"COUNT-IN", 1, 1, F_COUNTIN},      /* OFF, 1 BAR (the FM-1's; the engine alone's off at the start) */
    [P_ARP_SNAP] = {"ARP SNAP", 5, 3, F_ARPSNAP},     /* OFF, 1/16, 1/8, 1/4, 1/2, 1 BAR (ARP_SNAP_TICKS) */
    [P_BQ_NEW] = {"NEW TAKE", 2, 0, F_NEWTAKE},
    [P_BQ_UNDO] = {"UNDO TAKE", 2, 0, F_UNDO},
    [P_SQ_NLEN] = {"LENGTH", 32, 0, F_BQNLEN},         /* the note on STEP's: 1 .. 32 steps (0: no note there, -) */
    [P_SPEAKER] = {"SPK/JACK", 1, 1, F_ONOFF},        /* OFF: the speaker and headphones quiet, USB audio as ever */
    [P_ANIM] = {"ANIMATIONS", 1, 0, F_ANIM},           /* LOW: the river, the tape, the logo still (for the sound) */
    [P_TP_FLUTTER] = {"SPEED", 127, 64, F_TSPEED},        /* LOFI TAPE II: X0.25 .. X2.00, X1.00 at 64, X0.01 a detent
                                                         * from X0.48 to X1.58 (tape_oct; FLUTTER RATE's byte until
                                                         * it: the flutter now 5 HZ). TAPE SPEED till card #229: SPEED
                                                         * on every MEDIA */
    [P_TP_TONE] = {"TONE", 127, 74, F_SIGNED},         /* the tape's pole times 0.25 .. 4, as it was in the middle; +10 its
                                                        * default */
    [P_TP_NOISE] = {"NOISE", 127, 0, F_PCT},           /* the hiss */
    [P_TP_DROPOUT] = {"DROPOUT", 127, 0, F_PCT},       /* now and then the level dips */
    [P_L1_AMT1] = {"AMOUNT 1", 200, 100, F_AMT},       /* LFO AMOUNT: x0.00 .. x5.00, x1.00 (the LFOs as they were) in
                                                        * the middle */
    [P_L1_AMT2] = {"AMOUNT 2", 200, 100, F_AMT},
    [P_L1_AMT3] = {"AMOUNT 3", 200, 100, F_AMT},
    [P_L1_AMT4] = {"AMOUNT 4", 200, 100, F_AMT},
    [P_L2_AMT1] = {"AMOUNT 1", 200, 100, F_AMT},
    [P_L2_AMT2] = {"AMOUNT 2", 200, 100, F_AMT},
    [P_L2_AMT3] = {"AMOUNT 3", 200, 100, F_AMT},
    [P_L2_AMT4] = {"AMOUNT 4", 200, 100, F_AMT},
    [P_L3_AMT1] = {"AMOUNT 1", 200, 100, F_AMT},
    [P_L3_AMT2] = {"AMOUNT 2", 200, 100, F_AMT},
    [P_L3_AMT3] = {"AMOUNT 3", 200, 100, F_AMT},
    [P_L3_AMT4] = {"AMOUNT 4", 200, 100, F_AMT},
#if FRS_LEAD
    /* LEAD (card #144): its preset EMBER (LEAD_PRESET's, below: the first LEAD's sound): a warm saw, a little square in
     * it, the second oscillator a few cents up; the filter half open, the envelope opening it more; a short glide; its
     * own delay a quarter second, a few echoes, into the cloud */
    [P_LD_PRESET] = {"PRESET", LP_CUSTOM, LP_MOSS, F_LPRESET},   /* (LEAD_PRESET_NAME's, then CUSTOM) */
    [P_LD_WAVE] = {"WAVE", 128, 24, F_LWAVE},          /* SAW (0) .. SQUARE (64) .. PULSE (127), WHISTLE (128) */
    [P_LD_CUT] = {"FILTER", 127, 58, F_LCUT},          /* 60 HZ .. 12 KHZ */
    [P_LD_MODE] = {"MODE", 1, 0, F_LMODE},             /* MONO, POLY */
    [P_LD_BREATH] = {"BREATH", 127, 0, F_PCTOFF},      /* noise before the filter (WHISTLE's: some always) */
    [P_LD_DRIVE] = {"DRIVE", 127, 32, F_PCT},          /* (32: the first LEAD's, lead.h LEAD_DRIVE_0) */
    [P_LD_RESO] = {"RESONANCE", 127, 40, F_PCT},
    [P_LD_DETUNE] = {"DETUNE", 127, 40, F_PCT},        /* the second oscillator 0 .. 25 cents up */
    [P_LD_GLIDE] = {"GLIDE", 127, 30, F_GLIDE},        /* legato: a key played while another is down */
    [P_LD_FENV] = {"FILTER ENV", 127, 55, F_PCT},      /* the ADSR on the filter, 0 .. 5 octaves */
    [P_LD_VIB] = {"VIBRATO", 127, 0, F_PCTOFF},        /* at rest (the mod wheel's, if more) */
    [P_LD_OCTAVE] = {"OCTAVE", 4, 3, F_LOCT},          /* -2 .. +2: +1, over the keys' F2 start (the drones') */
    [P_LD_ATTACK] = {"ATTACK", 127, 15, F_BATT},       /* (BASS's times) */
    [P_LD_DECAY] = {"DECAY", 127, 70, F_BDEC},
    [P_LD_SUSTAIN] = {"SUSTAIN", 127, 90, F_PCT},
    [P_LD_RELEASE] = {"RELEASE", 127, 50, F_BREL},
    [P_LD_DTIME] = {"TIME", 11, 3, F_DTIME},           /* GLINT's: 1/32 .. 1/2, ping-pong (1/8T: the first LEAD's
                                                        * 201 MS the nearest at TEMPO's 90 BPM) */
    [P_LD_DFB] = {"FEEDBACK", 127, 51, F_PCT},         /* (x 0.88, GLINT's: 51 the first LEAD's 50 x 0.9) */
    [P_LD_DMIX] = {"MIX", 127, 40, F_PCT},
    [P_LD_SPACE] = {"SPACE", 127, 70, F_PCT},          /* its share of the cloud, its echoes with it */
    [P_MX_LEAD] = {"LEAD", 127, 100, F_LEVEL},         /* MIXER's K4: 100 as it is */
    [P_LD_FATTACK] = {"F.ATTACK", 127, 15, F_BATT},    /* FILTER ENV's own (admin #619): the amp's times, its */
    [P_LD_FDECAY] = {"F.DECAY", 127, 70, F_BDEC},      /* defaults the amp's (FILTER ENV as it was, the amp's own) */
    [P_LD_FSUSTAIN] = {"F.SUSTAIN", 127, 90, F_PCT},
    [P_LD_FRELEASE] = {"F.RELEASE", 127, 50, F_BREL},
#endif
    [P_SAVER] = {"SCREENSAVER", 1, 1, F_ONOFF},        /* ON: ten minutes untouched, the logo drifts on black (app.c) */
    [P_CLOCK] = {"CLOCK", 1, 0, F_CLOCK},              /* INTERNAL: an incoming MIDI clock ignored */
    [P_EQ_PRESET] = {"PRESET", 8, 0, F_EQPRESET},      /* OFF, CUSTOM (the bands as they are), then EQ_PRESETS' seven */
    [P_EQ_LOW] = {"LOW", 48, 24, F_EQDB},              /* -12 .. +12 DB, half a decibel a step */
    [P_EQ_MID] = {"MID", 48, 24, F_EQDB},
    [P_EQ_HIGH] = {"HIGH", 48, 24, F_EQDB},
    [P_EQ_LOWF] = {"LOW FREQ", 127, 59, F_EQLOWF},     /* a shelf, 30 .. 600 HZ (120) */
    [P_EQ_MIDF] = {"MID FREQ", 127, 64, F_EQMIDF},     /* a bell, 80 HZ .. 12 KHZ (1 KHZ) */
    [P_EQ_Q] = {"Q", 127, 39, F_EQQ},                  /* the bell's, 0.4 .. 8 (1.0) */
    [P_EQ_HIGHF] = {"HIGH FREQ", 127, 90, F_EQHIGHF},  /* a shelf, 1.5 .. 16 KHZ (8 KHZ) */
    [P_FL_TYPE] = {"TYPE", 2, 0, F_FLTYPE},            /* OFF, LOW PASS, HIGH PASS: 12 DB an octave */
    [P_FL_CUT] = {"CUTOFF", 127, 127, F_FLCUT},        /* 20 HZ .. 20 KHZ */
    [P_FL_RESO] = {"RESONANCE", 127, 0, F_PCT},
    [P_FL_TRACKS] = {"TRACKS", 6, 0, F_FLTRACKS},      /* ALL, DRONE (its CLOUD with it), GLINT, BASS, and the pairs */
    [P_TP_ON] = {"MEDIA", 4, 0, F_MEDIA},   /* LOFI TAPE's: OFF, TAPE (ON's 1 until card #99), VINYL, AM, PHONE (card
                                          * #218; frasil.c's MEDIA); an engine before them takes VINYL and AM as TAPE,
                                          * one with them PHONE as AM (past its range, its last: core.c sound_val,
                                          * param_set) */
    [P_TP_SAT] = {"SATURATION", 127, 50, F_PCT},
    [P_TP_WOBBLE] = {"WOBBLE", 127, 40, F_PCT},         /* the speed's wow and flutter, and now and then a hiccup */
    [P_TP_TRACKS] = {"TRACKS", 6, 0, F_FLTRACKS},
    [P_FL_PRE] = {"FILTER", 1, 0, F_PREPOST},          /* POST: after the cloud (DRONE's return in it); PRE: before it,
                                                        * the cloud fed filtered */
    [P_TP_PRE] = {"LOFI", 1, 0, F_PREPOST},            /* (TAPE till card #229; the FM-1's ROUTING says the MEDIA:
                                                        * app/pages.c pd_name) */
    [P_PUMP_CLOUD] = {"CLOUD PUMP", 1, 1, F_ONOFF},   /* ON: the cloud's return ducked with the drone */
    [P_PN_DRONE] = {"DRONE PAN", 100, 50, F_PAN},     /* L50 .. C .. R50, a balance */
    [P_PN_BASS] = {"BASS PAN", 100, 50, F_PAN},
    [P_PN_GLINT] = {"GLINT PAN", 100, 50, F_PAN},
    [P_PN_CLOUD] = {"CLOUD PAN", 100, 50, F_PAN},
    [P_GL_VIBRATO] = {"VIBRATO", 127, 50, F_PCTOFF},
    [P_KEYS] = {"KEY MODE", 1, 0, F_KEYS},
    [P_CANAL] = {"DRONE CH", 17, 1, F_TRKCH},   /* a track's MIDI channel: OFF, 1 .. 16, OMNI */
    [P_CH_GLINT] = {"GLINT CH", 17, 2, F_TRKCH},
    [P_CH_BASS] = {"BASS CH", 17, 3, F_TRKCH},
    [P_TEMPO] = {"TEMPO", 210, 60, F_BPM},   /* 30 .. 240 BPM */
    [P_FREEZE] = {"FREEZE", 1, 0, F_ONOFF},
};

static const float INTERVALS[5] = {12.0f, 7.0f, 5.0f, 19.0f, -12.0f};
static const float COMP_RATIO[8] = {1.0f, 1.5f, 2.0f, 3.0f, 4.0f, 6.0f, 10.0f, 20.0f};   /* the first: OFF */
static const char *const COMP_RATIO_NAME[8] = {"OFF", "1.5:1", "2:1", "3:1", "4:1", "6:1", "10:1", "20:1"};
/* PUMP's rates, in MIDI clocks (24 a beat, 96 a bar) */
static const uint16_t PUMP_TICKS[7] = {0, 384, 192, 96, 48, 24, 12};
static const char *const PUMP_NAME[7] = {"OFF", "4 BARS", "2 BARS", "1 BAR", "1/2", "1/4", "1/8"};
/* BASS II's PULSE: the bass's note let go and played again every this many MIDI clocks, an eighth of a beat .. four
 * beats (app.c pulse_run) */
static const uint8_t PULSE_TICKS[NPULSE] = {0, 3, 6, 12, 24, 48, 96};
static const char *const PULSE_NAME[NPULSE] = {"OFF", "1/8 BEAT", "1/4 BEAT", "1/2 BEAT", "1 BEAT", "2 BEATS",
                                               "4 BEATS"};

/* ------------------------------------------------------------ scenes --- */
#define NSCENES 16u
#define SC_CHORDS 8u                     /* latched drone chords a scene keeps */
#define SC_ARP 16u                       /* and each arpeggio's notes, GLINT's, the bass's */
#define SC_SEQ 32u                       /* and GLINT's sequence: a byte a step (app.c, SQ_*) */
#define SC_NAME 16u                      /* a name's characters, its first (scene_t's name) */
#define SC_NAME_MORE 16u                 /* and past them (scene_t's name_more, "FRS}"'s) */
#define SC_NAME_ALL (SC_NAME + SC_NAME_MORE)   /* 32 in all */
#define SC_LFO_AMT 12u                   /* the LFOs' AMOUNTs a scene keeps: each LFO's four (P_L1_AMT1 ..) */
#define SC_BSEQ 32u                      /* and the bass's sequence: a byte a step (core.c, bnote), one STEP LENGTH */
#define SC_DSEQ 32u                      /* and the drone's sequence: its steps (core.c dnote), */
#define DQ_NOTES 8u                      /* each up to eight notes */
#define DQ_TIE 127u                      /* (a step's first byte: a tie, the notes before held on) */
#define NDQ 6u                           /* scene_t's from dq_on to dq_trans */
typedef struct {
    char name[SC_NAME];                  /* NUL-padded; all sixteen used, none (core.c name_text); the rest in name_more */
    uint8_t v[NSOUND];
    uint8_t nch, narp;                   /* what it plays: none (a factory scene) keeps what is playing */
    int8_t ch[SC_CHORDS][5];             /* each chord: its root, then its notes (-1: none) */
    int8_t arp[SC_ARP];                  /* the arpeggio's notes, low to high */
    int8_t bass;                         /* the bass's note, -1: none */
    uint8_t seq[SC_SEQ];                 /* GLINT's sequence */
    uint8_t bnote[SC_BSEQ];              /* the bass's sequence (kept apart from the rest: app.c OBJ_BSEQ; till 2.7 its
                                          * sixteen notes, then their lengths, here: core.c bseq_over) */
    uint8_t bq_on, bq_steps, bq_trans;   /* and its PLAYS, SEQ LENGTH, TRANSPOSE: a scene plays its own, as GLINT's */
    uint8_t tempo;                       /* its TEMPO (P_TEMPO's value), with the bass's sequence in the store: LOAD
                                          * SND+NOTES takes it (app.c scene_take) */
    uint8_t bq_len;                      /* the bass's RATE (2.7's first: the layouts before end at TEMPO) */
    uint8_t ba_mode, ba_range, ba_chance;   /* its arpeggio's MODE, RANGE, CHANCE (FRSv: the layouts before end at bq_len) */
    uint8_t bq_gate;                     /* its sequence's GATE (ACCENT is in its steps: app.c SQ_ACC) */
    uint8_t bs_weight, bs_punch, bs_bite;   /* BASS TONE's WEIGHT, PUNCH, BITE */
    uint8_t nbarp;                       /* what it plays: the bass's arpeggio's notes, as narp and arp are GLINT's */
    int8_t barp[SC_ARP];                 /* low to high, without BASS's OCTAVE */
    uint8_t bs_space;                    /* the bass's SPACE, the cloud's (FRSx: the layouts before end at barp) */
    uint8_t gl_vib;                      /* GLINT's AUTO VIB (FRSy: the layouts before end at bs_space) */
    uint8_t dq_on, dq_rate, dq_len, dq_gate, dq_chance, dq_trans;   /* the drone's sequence (3.0's FRSz: the layouts before
                                                                     * end at gl_vib, read with none, core.c dseq_none):
                                                                     * on, RATE, SEQ LENGTH - 1, GATE, CHANCE, TRANSPOSE
                                                                     * (P_DQ_*'s values; app.c OBJ_DSEQ) */
    uint8_t dnote[SC_DSEQ][DQ_NOTES];    /* its steps, each the notes it plays as they were played on the drones (MIDI's,
                                          * TRANSPOSE off them), 1 .. 126 low to high, 0 after the last: none, a rest;
                                          * DQ_TIE first (the rest 0), a tie */
    uint8_t tp_flutter, tp_tone, tp_noise, tp_dropout;   /* LOFI TAPE II's TAPE SPEED (FLUTTER RATE's byte until it),
                                                          * TONE, NOISE, DROPOUT ("FRS{": the layouts before end at
                                                          * dnote, read with these as the tape was, TAPE_NONE, core.c
                                                          * tape_none) */
    char name_more[SC_NAME_MORE];        /* the name's characters 17 .. 32, NUL-padded (only after a first sixteen all
                                          * used; "FRS}": the layouts before end at tp_dropout, read with no name's
                                          * rest, the AMOUNTs at x1.00, SWELL 0, core.c more_none) */
    uint8_t lfo_amt[SC_LFO_AMT];         /* each LFO TARGET's AMOUNT: LFO 1's four, LFO 2's, LFO 3's (P_L1_AMT1 ..'s
                                          * values: 100 x1.00; "FRS|"'s in percent, 200 +100 %: frs_scene_amt_over) */
    uint8_t swell;                       /* SWELL, GENERATIVE FX's K1 (P_SWELL's value) */
} scene_t;
#define NBQ 12u                          /* scene_t's from bq_on to bq_gate, what the scene's "changed" looks at */

/* the factory scenes (slots 1 .. 7 until something is saved over them: app.c factory_get), each made as NEW SHARD is
 * (every setting at its default, its GLINT preset, the arpeggiator's and the delay's defaults), then its own settings
 * (P: a parameter and its value, to P_END), or its sound whole as an FM-1 stored it (one made on the device); its TEMPO
 * (BPM - 30), and what it plays: the drones it latches (each key's chord as the harmony makes it, or the chords as
 * latched), the arpeggio's notes, the bass's note held or its sequence, GLINT's sequence. Each
 * sounding like none of the others: their tempo, key and scale, the drone (one of its presets), what GLINT and the bass
 * do, the LFOs moving them. Notes: MIDI numbers; GLINT's without its OCTAVE, the bass's sequence's without the bass's (as
 * the sequencers keep them: app.c); a step 0 is a rest or a CUT, 127 a TIE or a HOLD, A() an accent */
#define P_END 0xFFu
#define FACTORY_NV 130u                  /* the sound the whole ones were stored with (app.c FRSL_NV) */
#define A(n) ((n) | 0x80)
#define H 127                            /* (a HOLD) */
typedef struct {
    char name[SC_NAME + 1];              /* (its sixteen and the literal's NUL: only SC_NAME go into the scene) */
    uint8_t tempo;
    uint8_t p[52][2];                    /* its settings over NEW SHARD's base (to P_END) */
    uint8_t whole;                       /* 1: its sound whole instead, as an FM-1 stored it (sound: before MASTER EQ,
                                          * MASTER FILTER and LOFI TAPE, at their defaults) */
    uint8_t sound[FACTORY_NV];
    int8_t keys[4];                      /* the drones latched, each key's chord as the harmony makes it (0: none) */
    uint8_t nch;                         /* or its chords as latched (ch: root, then notes; -1 none) */
    int8_t ch[SC_CHORDS][5];
    int8_t arp[SC_ARP];                  /* the arpeggio's notes, low to high (0: none) */
    int8_t bass;                         /* the bass's note held, as it sounds (-1: none) */
    uint8_t seq[SC_SEQ];                 /* GLINT's sequence */
    uint8_t bnote[SC_BSEQ];              /* the bass's: its steps (a NOTE, CUT 0, HOLD 127) */
    uint8_t bq_on, bq_steps, bq_trans;   /* its PLAYS (2: SEQ), SEQ LENGTH (steps - 1), TRANSPOSE */
    uint8_t bq_len;                      /* its RATE (BQ_LEN_NAME's) */
} factory_t;
static const factory_t FACTORY[] = {
    /* NORTH RIVER: the user's own, made on the FM-1 and kept whole as it stored it (its sound, every setting, in
     * params.c's order: a layout that changes a setting's meaning makes it over, as it would a stored scene). F# minor
     * pentatonic at 90 BPM: two sevenths latched wide, on B2 and F#3; FROST's arpeggio at random in sixteenths over three
     * octaves; SUB's line of five notes, struck on each beat (PULSE) */
    {.name = "NORTH RIVER", .tempo = 60, .whole = 1,
     .sound = {74, 77, 103, 104, 91, 26, 39, 71, 5, 70, 0, 89, 87, 83, 114, 61, 120, 51, 79, 43, 99, 79, 88, 19, 95, 64,
               13, 0, 25, 127, 50, 58, 78, 6, 11, 3, 2, 6, 11, 45, 55, 75, 2, 110, 72, 3, 7, 2, 79, 0, 68, 23,
               111, 1, 127, 81, 38, 23, 126, 1, 3, 81, 5, 127, 53, 0, 90, 60, 40, 23, 2, 72, 5, 76, 99, 34, 96, 100,
               127, 36, 0, 0, 3, 0, 0, 0, 0, 85, 0, 23, 1, 40, 0, 0, 0, 24, 42, 0, 26, 0, 0, 0, 0, 16,
               17, 0, 35, 23, 0, 0, 15, 64, 14, 0, 51, 5, 32, 93, 0, 36, 0, 0, 0, 1, 0, 0, 0, 90, 13, 4},
     .nch = 2, .ch = {{47, 35, 52, 57, 61}, {54, 42, 59, 64, 69}},
     .arp = {52, 61, 64}, .bass = -1,
     .seq = {0},
     .bnote = {66, H, H, H, H, H, H, H, 57, H, H, H, 59, H, 59, 61}, .bq_on = 2, .bq_steps = 15, .bq_trans = 14,
     .bq_len = 2},                       /* (1/4: 2.6's 2 BARS, 1 BAR, 1/2, 1/4, 1/4) */
    /* LUMIERE NOCTURNE: the user's own too, kept whole the same way. A major at 60 BPM, a light in the night: an add9
     * latched wide on D2, the drone all PARTIALS and BREATH, slow to come and to go, in a long, bright hall; GLINT's
     * arpeggio on one note, A1, an octave up; SAW's A2 held, struck on each half beat (PULSE); three slow LFOs (TIMBRE
     * and BREATH, SPACE and SPREAD, GLINT's BRIGHT and the bass's FILTER) */
    {.name = "LUMIERE NOCTURNE", .tempo = 30, .whole = 1,
     .sound = {0, 115, 98, 40, 50, 46, 60, 20, 0, 60, 0, 100, 96, 90, 76, 30, 64, 36, 30, 38, 118, 94, 95, 29, 100, 85,
               20, 2, 56, 127, 50, 64, 66, 9, 1, 6, 2, 8, 1, 32, 90, 90, 1, 90, 84, 0, 5, 1, 127, 10, 0, 19,
               50, 1, 40, 48, 54, 26, 96, 2, 0, 94, 3, 50, 45, 0, 90, 60, 40, 28, 0, 62, 0, 72, 100, 100, 100, 83,
               127, 36, 0, 0, 0, 0, 0, 0, 0, 85, 0, 0, 1, 50, 0, 0, 0, 18, 14, 0, 1, 7, 0, 0, 0, 14,
               12, 0, 2, 24, 0, 0, 15, 64, 14, 0, 87, 0, 21, 16, 0, 26, 31, 0, 0, 1, 26, 0, 0, 99, 0, 3},
     .nch = 1, .ch = {{38, 26, 42, 45, 52}},
     .arp = {33}, .bass = 45,
     .seq = {0},
     .bnote = {0}, .bq_on = 0, .bq_steps = 15, .bq_trans = 14},
    /* RESILIENCE: the user's own, kept whole. F# minor pentatonic at 90 BPM: two sevenths latched wide, on B2 and A3, a
     * full drone (all four layers up, WARMTH most) moving on its own (MOTION, TIDE); HARP's arpeggio at random in
     * sixteenths over three octaves, through a long ping-pong echo; REESE driven, its line far under */
    {.name = "RESILIENCE", .tempo = 60, .whole = 1,
     .sound = {98, 88, 103, 126, 91, 26, 39, 71, 5, 70, 0, 89, 87, 83, 114, 61, 120, 51, 79, 43, 99, 79, 88, 0, 95, 64,
               13, 0, 25, 127, 50, 58, 78, 6, 11, 3, 2, 13, 1, 34, 85, 90, 1, 80, 80, 3, 7, 2, 91, 0, 110, 23,
               111, 1, 127, 106, 86, 35, 126, 0, 30, 50, 4, 127, 53, 0, 90, 60, 40, 23, 2, 72, 0, 81, 72, 78, 96, 57,
               127, 36, 0, 0, 3, 0, 0, 0, 0, 85, 0, 37, 1, 40, 0, 0, 0, 25, 0, 0, 0, 0, 0, 0, 0, 25,
               0, 0, 0, 0, 0, 0, 15, 64, 14, 0, 87, 0, 25, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 64, 127, 0},
     .nch = 2, .ch = {{47, 35, 52, 57, 61}, {57, 45, 61, 66, 71}},
     .arp = {47, 54, 57}, .bass = -1,
     .seq = {0},
     .bnote = {54, H, H, H, H, H, H, H, H, H, H, H, H, 61, 61, H, 57, H, H, H, H, H, H, 59, H, H, H, H, H, 49, H, H},
     .bq_on = 2, .bq_steps = 31, .bq_trans = 14, .bq_len = 1},   /* (1/8: 2.6's nine steps, 1/16 the shortest, in
                                                                   * 64 of them: as core.c bseq_over makes them over,
                                                                   * the four bars kept, the two F#s a 1/16 later) */
    /* LONG NIGHT: A Phrygian at 60 BPM, dark and slow (as the user remade it on the FM-1, kept whole). NOCTURNE's
     * resonant low drone on a wide fifth; REESE's line gliding in bars and halves (six bars) under BOWED glass, ratio 9,
     * long tied notes in four (they drift apart) far in an echo; LFO 1 a slow drift on both filters, LFO 3 now and then a
     * little SINK; a long, dark hall */
    {.name = "LONG NIGHT", .tempo = 30, .whole = 1,
     .sound = {76, 89, 32, 19, 51, 44, 57, 25, 0, 70, 0, 89, 89, 83, 76, 38, 44, 51, 25, 38, 120, 115, 30, 0, 95, 64,
               13, 0, 25, 127, 50, 64, 57, 9, 4, 1, 2, 15, 10, 21, 62, 38, 1, 125, 118, 0, 3, 1, 76, 120, 0, 19,
               96, 1, 99, 40, 40, 60, 95, 1, 40, 70, 4, 116, 50, 0, 90, 60, 40, 28, 0, 62, 0, 100, 100, 72, 100, 57,
               127, 36, 0, 0, 0, 0, 0, 0, 0, 85, 0, 0, 1, 64, 0, 0, 6, 8, 50, 0, 31, 9, 0, 0, 0, 67,
               30, 2, 29, 0, 0, 0, 15, 110, 14, 17, 100, 5, 31, 20, 1, 40, 28, 0, 0, 2, 0, 30, 0, 90, 100, 0},
     .nch = 1, .ch = {{45, 33, 52, -1, -1}},
     .arp = {0}, .bass = -1,
     .seq = {64, 127, 127, 127, 0, 0, 65, 127, 62, 127, 127, 0, 60, 127, 69, 127},
     .bnote = {45, H, H, H, 41, 40, 45, H, 46, 45, H, H}, .bq_on = 2, .bq_steps = 11, .bq_trans = 14,
     .bq_len = 3},                       /* (1/2: 2.6's bars and halves) */
    /* OPEN WATER: the river open again, D Dorian at 118 BPM. PULSE's quick beating on a sus2, ducked on each beat (PUMP);
     * MARIMBA's sixteenths, syncopated, accents, an echo; a driven SAW in eighths, plucked (DECAY, SUSTAIN), its
     * filter swept over two bars (LFO 1); the mastering pressing a little */
    {.name = "OPEN WATER", .tempo = 88,
     .p = {{P_ROOT, 2}, {P_SCALE, 3}, {P_CHORD, 4}, {P_VOICING, 1}, {P_DR_PRESET, 19}, {P_DR_FULL, 70},
      {P_GL_PRESET, 10}, {P_SQ_TYPE, 2}, {P_GL_OCTAVE, 1}, {P_ARP_RATE, 7}, {P_SQ_LEN, 15}, {P_SQ_GATE, 50},
      {P_GL_LEVEL, 95}, {P_GL_BRIGHT, 70}, {P_GD_TIME, 7}, {P_GD_MIX, 35}, {P_GD_FB, 40},
      {P_BS_MODEL, 3}, {P_BS_FILTER, 55}, {P_BS_RESO, 60}, {P_BS_DRIVE, 50}, {P_BS_LEVEL, 95}, {P_BS_ATTACK, 0},
      {P_BS_RELEASE, 30}, {P_BS_DECAY, 45}, {P_BS_SUSTAIN, 40}, {P_BS_GLIDE, 0},
      {P_PUMP_RATE, 5}, {P_PUMP_DRONE, 100}, {P_PUMP_BASS, 0}, {P_PUMP_GLINT, 30},
      {P_TAILLE, 80}, {P_DUREE, 60}, {P_TEINTE, 70}, {P_MS_RATIO, 3}, {P_MS_THRESH, 22}, {P_MS_GAIN, 6},
      {P_L1_SHAPE, 1}, {P_L1_RATE, 67}, {P_L1_DEPTH, 45}, {P_L1_T1, 31},
      {P_END, 0}},
     .keys = {50}, .arp = {0}, .bass = -1,
     .seq = {A(62), 0, 69, 0, 65, A(69), 0, 72, 0, 67, A(64), 0, 69, 0, 72, 74},
     .bnote = {50, 0, 50, 53, 0, 55, 57, 0, 50, 0, 60, 57, 0, 55, 53, 0}, .bq_on = 2, .bq_steps = 15, .bq_trans = 14,
     .bq_len = 1},                       /* (1/8) */
    /* WHITEOUT: C# minor at 72 BPM, snow on the wind. WIND's breath alone, a wide sus4, its air gusting (LFO 1, at
     * random) and its spread drifting (LFO 2); FROST's flurries, an arpeggio at random in sixteenth triplets over three
     * octaves, mostly silent, LFO 3 bringing them in; a sub far under, slow; BLUR and the widest cloud */
    {.name = "WHITEOUT", .tempo = 42,
     .p = {{P_ROOT, 1}, {P_SCALE, 2}, {P_CHORD, 5}, {P_VOICING, 2}, {P_DR_PRESET, 9}, {P_DR_FULL, 127},
      {P_GL_PRESET, 6}, {P_SQ_TYPE, 1}, {P_ARP_MODE, 3}, {P_ARP_RATE, 8}, {P_ARP_RANGE, 2}, {P_ARP_CHANCE, 35},
      {P_GL_OCTAVE, 1}, {P_GL_LEVEL, 70}, {P_GL_BRIGHT, 50},
      {P_BS_MODEL, 5}, {P_BS_LEVEL, 70}, {P_BS_ATTACK, 110}, {P_BS_RELEASE, 100}, {P_BS_FILTER, 30},
      {P_GX_BLUR, 70}, {P_GX_SINK, 20}, {P_MS_RATIO, 2}, {P_MS_THRESH, 24}, {P_MS_GAIN, 5},
      {P_TAILLE, 127}, {P_DUREE, 105}, {P_TEINTE, 55}, {P_DIFFUSION, 127}, {P_MODULATION, 100}, {P_LARGEUR, 127},
      {P_L1_SHAPE, 5}, {P_L1_RATE, 44}, {P_L1_DEPTH, 35}, {P_L1_T1, 23}, {P_L1_T2, 21},
      {P_L2_SHAPE, 6}, {P_L2_RATE, 4}, {P_L2_DEPTH, 60}, {P_L2_T1, 24}, {P_L2_T2, 22},
      {P_L3_SHAPE, 1}, {P_L3_RATE, 17}, {P_L3_DEPTH, 50}, {P_L3_POL, 1}, {P_L3_T1, 36}, {P_L3_T2, 30},
      {P_END, 0}},
     .keys = {49}, .arp = {61, 64, 68, 71}, .bass = 25,
     .seq = {0},
     .bnote = {0}, .bq_on = 0, .bq_steps = 15, .bq_trans = 14},
    /* THAW: E-flat major at 78 BPM, warm and dripping. EMBER's glowing square choir, add9, open, its warmth and body
     * swaying (LFO 1); DROP's arpeggio drifting in eighth triplets, half of its steps; FM's bass held, struck again on
     * each half beat (PULSE); LFO 2 sinking everything slowly now and then, LFO 3 the strike's and the bass's tone at
     * random */
    {.name = "THAW", .tempo = 48,
     .p = {{P_ROOT, 3}, {P_SCALE, 1}, {P_CHORD, 6}, {P_VOICING, 1}, {P_DR_PRESET, 6}, {P_DR_FULL, 110},
      {P_GL_PRESET, 5}, {P_SQ_TYPE, 1}, {P_ARP_MODE, 4}, {P_ARP_RATE, 6}, {P_ARP_RANGE, 1}, {P_ARP_CHANCE, 75},
      {P_GL_OCTAVE, 1}, {P_GL_LEVEL, 60},
      {P_BS_MODEL, 7}, {P_BS_LEVEL, 85}, {P_BS_FILTER, 50}, {P_BS_DECAY, 60}, {P_BS_SUSTAIN, 80},
      {P_BS_ATTACK, 10}, {P_BS_RELEASE, 45}, {P_BS_PULSE, 3}, {P_GX_SINK, 15}, {P_MS_RATIO, 2}, {P_MS_GAIN, 2},
      {P_TAILLE, 95}, {P_DUREE, 80}, {P_TEINTE, 50}, {P_MODULATION, 90},
      {P_L1_SHAPE, 0}, {P_L1_RATE, 19}, {P_L1_DEPTH, 40}, {P_L1_T1, 4}, {P_L1_T2, 35},
      {P_L2_SHAPE, 6}, {P_L2_RATE, 5}, {P_L2_DEPTH, 45}, {P_L2_POL, 1}, {P_L2_T1, 40},
      {P_L3_SHAPE, 5}, {P_L3_RATE, 38}, {P_L3_DEPTH, 30}, {P_L3_T1, 27}, {P_L3_T2, 31},
      {P_END, 0}},
     .keys = {51}, .arp = {63, 67, 70, 74, 77}, .bass = 27,
     .seq = {0},
     .bnote = {0}, .bq_on = 0, .bq_steps = 15, .bq_trans = 14},
};
#undef A
#undef H
/* NEW SHARD: SCENES' first line, above slot 01. No slot (nothing is stored into it): a sound to begin a shard from,
 * in the code as the factory scenes are (app.c new_shard), playing nothing. A calm drone, CUSTOM: the choir soft, a
 * little PARTIALS and BREATH, warm; slow to come and to go; MOTION at half, its drift slow; a lush cloud, not a wash
 * (LOW CUT at 83 HZ: no boom swelling under it as the drift moves the low notes). A seventh in A minor, open (A E G C:
 * Am7 on A). GLINT's SINE */
#define S(n, ...) {n, {__VA_ARGS__}, 0, 0, {{0}}, {0}, -1, {0}, {0}, 0, 15, 14, 60, 0, 0, 1, 127, 127, 0, 0, 0, 0, {0}, 0, 0, \
                   0, 4, 3, 127, 127, 14, {{0}}, 64, 64, 0, 0, {0}, \
                   {200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200}, 0}   /* playing nothing, at 90 BPM; the
                                                                                      * drone's sequence off, empty; the
                                                                                      * tape as it was, the LFOs whole */
static const scene_t NEW_SHARD = S("NEW SHARD", 84, 50, 44, 40, 50, 46, 60, 20, 0, 60, 0, 100, 96, 90, 76, 30, 64, 36,
                                   30, 38, 98, 82, 60, 0, 100, 85, 20, 0, 56, 127, 50, 64, 66,
                                   9, 2, 3, 1, 8);
/* ... and its settings past the factory scenes' (the rest at their defaults): BODY at half (the drone thinner, the
 * SUB under it), the breath's noise darker; GLINT dim (BRIGHT a quarter); the bass a SUB, soft, slow to come. The
 * three LFOs on, slow sines (23 S, 37 S, 16 S: never in step), a little deep, each on two settings (TARGET's values:
 * LFO_TGT, below): LFO 1 the drone's breath, TIMBRE and BREATH; LFO 2 its distance, SPACE and SPREAD; LFO 3 the
 * other two tracks' tone, GLINT's BRIGHT and the bass's FILTER */
static const uint8_t NEW_SHARD_P[][2] = {
    {P_DR_FULL, 64}, {P_BR_TONE, 50}, {P_GL_BRIGHT, 32},
    {P_BS_MODEL, 5}, {P_BS_DRIVE, 16}, {P_BS_FILTER, 34}, {P_BS_RESO, 10}, {P_BS_ATTACK, 96}, {P_BS_RELEASE, 88},
    {P_L1_RATE, 18}, {P_L1_DEPTH, 14}, {P_L1_T1, 1}, {P_L1_T2, 7},       /* TIMBRE, BREATH */
    {P_L2_RATE, 14}, {P_L2_DEPTH, 12}, {P_L2_T1, 2}, {P_L2_T2, 24},      /* SPACE, SPREAD */
    {P_L3_RATE, 21}, {P_L3_DEPTH, 16}, {P_L3_T1, 26}, {P_L3_T2, 31},     /* GL BRIGHT, BS FILTER */
    {P_SQ_TYPE, 1},                      /* GLINT's SEQ on ARP (app.c SQT_ARP): its keys arpeggiated, latched */
};
#undef S
#define NFACTORY (sizeof FACTORY / sizeof FACTORY[0])
#define SC_NEW NSCENES                   /* NEW SHARD's number: the scene loaded (st.scene), SCENES' K1, the settings'
                                          * scene byte (app.c settings_t) */

/* GLINT's presets: PRESET loads one into the parameters after it, which then shape it */
#define NGPRESET 23u
static const char *const GLINT_NAME[NGPRESET] = {"ICE", "BELL", "BLIP", "GLASS", "CHIME", "DROP", "FROST", "CELESTA",
                                                 "SINE", "KALIMBA", "MARIMBA", "MUSIC BOX", "VIBES", "HARP", "PIPE",
                                                 "BOWED", "WARM LEAD", "BRASS", "SQUARE", "SUB LEAD", "STRINGS", "REED",
                                                 "PIANO"};
static const uint8_t GLINT_PRESET[NGPRESET][10] = {
    /* RATIO BRIGHT DECAY LEVEL OCTAVE SPACE RELEASE ATTACK PING SUSTAIN (RELEASE as DECAY let each go before it:
     * glint_release_of) */
    {6, 70, 70, 90, 2, 90, 76, 0, 68, 0},       /* ICE: a high bell */
    {2, 80, 95, 85, 1, 80, 87, 0, 68, 0},       /* BELL: inharmonic, long */
    {3, 55, 25, 95, 2, 70, 50, 0, 68, 0},       /* BLIP */
    {9, 50, 85, 80, 2, 100, 80, 0, 68, 0},      /* GLASS */
    {4, 75, 110, 80, 1, 90, 99, 0, 68, 0},      /* CHIME: a bar's modes */
    {1, 90, 30, 100, 1, 60, 54, 0, 68, 0},      /* DROP */
    {11, 45, 55, 75, 2, 110, 72, 0, 68, 0},     /* FROST: glitter high up */
    {7, 60, 60, 90, 2, 80, 76, 0, 68, 0},       /* CELESTA */
    {1, 0, 90, 90, 1, 90, 84, 10, 0, 0},        /* SINE: pure */
    {1, 45, 50, 95, 1, 70, 69, 0, 120, 0},      /* KALIMBA: a woody pluck, its ring nearly pure */
    {7, 60, 35, 95, 0, 60, 57, 0, 127, 0},      /* MARIMBA: a bar, short */
    {8, 40, 75, 85, 2, 85, 76, 0, 90, 0},       /* MUSIC BOX */
    {3, 40, 100, 85, 1, 85, 91, 5, 40, 0},      /* VIBES: round, long */
    {1, 70, 80, 90, 1, 80, 76, 0, 110, 0},      /* HARP */
    {1, 25, 105, 80, 1, 90, 95, 75, 10, 0},     /* PIPE: a soft flute, breathed in */
    {3, 35, 120, 80, 1, 100, 106, 105, 0, 0},   /* BOWED: glass rubbed, slow to sound */
    /* the leads: held while the key is down (SUSTAIN), the modulator at the note or near it (a saw's harmonics, a
     * pulse's), PING the filter's sweep at the start, drier */
    {1, 62, 95, 88, 1, 55, 87, 12, 45, 105},    /* WARM LEAD: all the harmonics, round, a little bite at the start */
    {1, 78, 80, 88, 1, 50, 76, 45, 85, 95},     /* BRASS: swells in bright, settles darker */
    {3, 58, 100, 85, 1, 55, 91, 8, 25, 115},    /* SQUARE: the odd harmonics, hollow */
    {0, 55, 100, 90, 1, 45, 91, 8, 35, 110},    /* SUB LEAD: an octave under it too */
    {1, 48, 110, 85, 1, 85, 99, 85, 15, 120},   /* STRINGS: slow to come, an ensemble */
    {5, 45, 95, 85, 1, 55, 87, 15, 40, 100},    /* REED: nasal (no third harmonic) */
    {1, 40, 95, 92, 1, 75, 87, 0, 0, 0},        /* PIANO: lofi, an old upright's: a long dark ring, no PING (the user's,
                                                 * 2.5) */
};
/* the drone's presets (PRESETS turns them): each sets the NDRONE settings in DRONE_P, the three layers (their
 * levels, their pages and their second pages, CHOIR III's SOFT) and the drone's own (DRONE TONE but FULLNESS,
 * ALGORITHM's: a hand that stays where it is; DRONE SHAPE's ATTACK and RELEASE; DRONE MOTION). 0 is CUSTOM: the
 * settings as turned (app.c keeps them while a preset plays, and in the scenes) */
static const uint8_t DRONE_P[NDRONE] = {P_CHOEUR, P_PARTIELS, P_SOUFFLE, P_CHALEUR, P_DESACCORD, P_FILTRE, P_PENTE,
                                        P_IMPAIRS, P_ETIREMENT, P_RESONANCE, P_COULEUR, P_ECART, P_ATTAQUE, P_RELACHE,
                                        P_MOUVEMENT, P_VITESSE, P_MAREE, P_PERIODE, P_TIMBRE, P_ESPACE, P_CH_SHAPE,
                                        P_CH_INTERVAL, P_CH_RESO, P_CH_TYPE, P_PA_EVOLVE, P_PA_BEAT, P_PA_FORMANT,
                                        P_PA_PEAK, P_BR_GRAIN, P_BR_PITCH, P_BR_TONE, P_BR_AIR, P_CH_SOFT};
static const char *const DRONE_NAME[NDPRESET + 1u] = {"CUSTOM", "MIST", "CATHEDRAL", "GLACIER", "ABYSS", "AURORA", "EMBER", "TIDE", "DUST", "WIND", "ORGAN", "HOLLOW", "VOWEL", "SHIMMER", "CHANTER", "ENSEMBLE", "BELLS", "NOCTURNE", "HAZE", "PULSE", "RIME", "DEEP", "SPECTRAL", "RUST", "STILL", "VELVET", "CHROME", "SWARM", "FOGHORN", "SOLAR", "CAVE", "GLASS HARP", "MONK", "STATIC", "LULLABY", "STORM", "PRISM"};
static const uint8_t DRONE_PRESET[NDPRESET][NDRONE] = {
    /* CHO PAR SOU WAR DET FIL TIL ODD STR BRES COL SPR ATT REL MOT RAT TID PER TIM SPA SHP INT CRES TYP EVO BEAT
     * FORM PEAK GRN PIT TONE AIR SOFT (SOFT 0 in each: as they were made, before it) */
    {76, 89, 32, 19, 51, 44, 57, 25, 0, 70, 0, 89, 89, 83, 44, 51, 25, 38, 64, 57, 0, 0, 0, 0, 0, 0, 85, 0, 0, 1, 64, 0, 0},  /* MIST: the default: all three, gently */
    {110, 50, 20, 25, 85, 55, 60, 30, 0, 60, 0, 110, 100, 100, 60, 40, 20, 50, 60, 95, 0, 1, 20, 0, 10, 0, 85, 0, 0, 1, 64, 0, 0},  /* CATHEDRAL: a wide choir, an octave under, a long hall */
    {20, 100, 70, 5, 30, 60, 35, 50, 60, 115, 127, 100, 80, 110, 40, 30, 30, 40, 80, 90, 0, 0, 0, 0, 40, 15, 100, 30, 20, 2, 80, 0, 0},  /* GLACIER: glass: stretched partials, bell resonators */
    {90, 70, 25, 50, 70, 20, 90, 40, 0, 50, 0, 70, 100, 105, 50, 25, 50, 25, 40, 70, 30, 1, 40, 0, 20, 0, 60, 0, 0, 0, 30, 0, 0},  /* ABYSS: dark and deep, an octave under, warm */
    {60, 105, 40, 15, 45, 65, 40, 15, 10, 85, 60, 115, 90, 105, 55, 45, 45, 50, 75, 95, 0, 0, 0, 0, 70, 25, 90, 35, 0, 2, 75, 10, 0},  /* AURORA: the spectrum wandering, a light formant */
    {100, 55, 20, 80, 40, 40, 70, 60, 0, 50, 30, 80, 70, 80, 35, 40, 20, 40, 55, 50, 64, 0, 50, 0, 10, 0, 70, 0, 0, 1, 50, 0, 0},  /* EMBER: a warm square choir, glowing low */
    {80, 80, 45, 25, 60, 45, 55, 30, 10, 75, 40, 100, 95, 100, 70, 30, 110, 60, 60, 70, 0, 0, 30, 0, 30, 0, 85, 0, 0, 1, 64, 0, 0},  /* TIDE: a deep tide on the timbre */
    {25, 40, 85, 20, 40, 50, 60, 30, 20, 100, 60, 120, 60, 90, 50, 50, 30, 40, 60, 75, 0, 0, 0, 0, 30, 0, 85, 0, 90, 2, 85, 40, 0},  /* DUST: grains ringing in resonators, crackle */
    {0, 20, 85, 0, 40, 50, 60, 30, 0, 20, 30, 127, 80, 95, 90, 80, 50, 70, 64, 80, 0, 0, 0, 0, 0, 0, 85, 0, 0, 1, 75, 50, 0},  /* WIND: air: breath alone, moving */
    {40, 115, 10, 30, 10, 50, 45, 0, 0, 60, 0, 60, 40, 60, 15, 40, 10, 40, 64, 50, 0, 2, 0, 0, 0, 0, 85, 0, 0, 1, 64, 0, 0},  /* ORGAN: steady pipes, a fifth over, still */
    {105, 80, 25, 20, 35, 50, 50, 110, 0, 70, 64, 90, 80, 90, 40, 45, 25, 40, 60, 65, 64, 0, 40, 1, 15, 0, 85, 0, 0, 1, 60, 0, 0},  /* HOLLOW: odd harmonics, a band-passed square */
    {65, 125, 15, 10, 30, 55, 30, 20, 0, 70, 0, 85, 90, 95, 45, 35, 60, 45, 64, 70, 0, 0, 60, 1, 20, 0, 95, 105, 0, 1, 64, 0, 0},  /* VOWEL: a sung overtone, a vowel */
    {45, 100, 50, 10, 55, 75, 25, 20, 15, 100, 90, 120, 85, 110, 50, 55, 30, 40, 85, 100, 0, 3, 0, 0, 40, 50, 100, 20, 10, 3, 90, 20, 0},  /* SHIMMER: bright beating partials, a halo a twelfth up */
    {105, 45, 15, 40, 30, 55, 60, 70, 0, 60, 30, 70, 50, 70, 30, 45, 15, 40, 60, 45, 110, 0, 35, 1, 0, 0, 85, 0, 0, 1, 64, 0, 0},  /* CHANTER: a reed: a narrow pulse, nasal */
    {115, 40, 20, 30, 75, 60, 55, 25, 0, 60, 0, 115, 95, 90, 55, 55, 20, 40, 65, 75, 90, 0, 15, 0, 0, 0, 85, 0, 0, 1, 64, 0, 0},  /* ENSEMBLE: strings: detuned pulses swaying */
    {15, 115, 45, 5, 25, 50, 30, 20, 95, 110, 127, 95, 40, 110, 30, 40, 20, 40, 75, 85, 0, 0, 0, 0, 30, 30, 85, 0, 0, 2, 80, 0, 0},  /* BELLS: stretched into bells, ringing */
    {90, 60, 30, 35, 55, 25, 85, 30, 0, 55, 0, 90, 110, 115, 45, 20, 40, 20, 45, 85, 20, 1, 70, 0, 25, 0, 70, 0, 0, 0, 35, 0, 0},  /* NOCTURNE: slow and dark, a resonant low-pass */
    {85, 50, 60, 10, 60, 70, 50, 25, 0, 40, 30, 120, 100, 105, 60, 50, 30, 50, 70, 90, 0, 3, 20, 2, 20, 0, 85, 0, 0, 2, 80, 30, 0},  /* HAZE: airy: high-passed, an octave up */
    {50, 95, 25, 20, 30, 50, 45, 30, 0, 70, 20, 100, 60, 80, 30, 50, 20, 40, 64, 65, 0, 0, 0, 0, 15, 100, 85, 0, 0, 1, 64, 0, 0},  /* PULSE: every partial beating, quick */
    {30, 110, 70, 0, 20, 80, 20, 40, 30, 120, 100, 110, 70, 100, 35, 60, 20, 40, 90, 90, 0, 3, 0, 2, 30, 20, 110, 40, 40, 4, 100, 15, 0},  /* RIME: thin ice, two octaves up, glittering */
    {100, 100, 0, 40, 25, 25, 100, 20, 0, 50, 0, 60, 90, 95, 25, 30, 20, 30, 40, 45, 0, 1, 10, 0, 0, 0, 40, 0, 0, 0, 30, 0, 0},  /* DEEP: weight: the fundamental, an octave under */
    {20, 120, 15, 5, 20, 50, 20, 10, 0, 70, 0, 90, 90, 100, 50, 40, 80, 50, 64, 80, 0, 0, 0, 0, 50, 10, 85, 127, 0, 1, 64, 0, 0},  /* SPECTRAL: one overtone alone, singing */
    {80, 50, 40, 100, 50, 45, 65, 60, 20, 80, 40, 80, 60, 80, 40, 55, 25, 40, 55, 55, 70, 0, 80, 1, 20, 15, 75, 0, 60, 1, 45, 20, 0},  /* RUST: gritty: driven, grains, a resonant band */
    {0, 125, 0, 0, 0, 50, 127, 0, 0, 50, 0, 60, 100, 100, 5, 20, 0, 40, 50, 70, 0, 0, 0, 0, 0, 0, 85, 0, 0, 1, 64, 0, 0},  /* STILL: almost a sine, unmoving */
    {95, 45, 10, 15, 35, 40, 85, 20, 0, 50, 0, 100, 105, 110, 35, 30, 20, 45, 52, 70, 0, 0, 10, 0, 0, 0, 85, 0, 0, 1, 50, 0, 120},  /* VELVET: plush: rounded voices, nothing sharp */
    {35, 115, 15, 35, 15, 75, 15, 120, 45, 90, 80, 85, 60, 90, 35, 55, 15, 40, 85, 60, 64, 3, 85, 2, 20, 35, 110, 70, 0, 3, 95, 0, 0},  /* CHROME: metal: odd stretched partials over a resonant high square */
    {120, 75, 30, 30, 120, 60, 40, 30, 0, 60, 20, 127, 70, 85, 110, 100, 40, 15, 70, 60, 120, 0, 40, 1, 40, 70, 85, 0, 30, 2, 70, 20, 0},  /* SWARM: alive: narrow pulses far detuned, everything moving fast */
    {127, 60, 15, 70, 20, 22, 95, 90, 0, 40, 0, 50, 120, 120, 20, 20, 60, 70, 35, 65, 64, 1, 60, 0, 0, 0, 40, 30, 0, 0, 30, 0, 30},  /* FOGHORN: a low square an octave under, slow to come and go */
    {70, 105, 45, 20, 55, 90, 15, 15, 5, 80, 30, 120, 100, 110, 60, 50, 70, 35, 100, 90, 10, 3, 15, 2, 60, 25, 120, 40, 0, 3, 110, 30, 0},  /* SOLAR: blazing: open saws an octave up, a high spectrum */
    {55, 40, 95, 30, 30, 18, 110, 30, 0, 100, 60, 70, 110, 120, 30, 20, 45, 60, 30, 100, 0, 1, 50, 0, 10, 0, 40, 0, 50, 0, 18, 5, 60},  /* CAVE: deep breath, an octave under, far away */
    {10, 120, 20, 0, 12, 60, 30, 10, 25, 100, 90, 110, 50, 120, 25, 30, 15, 55, 90, 95, 0, 3, 0, 0, 45, 40, 120, 110, 0, 4, 100, 0, 127},  /* GLASS HARP: a wet rim: high singing overtones, pure */
    {110, 85, 10, 25, 30, 38, 70, 40, 0, 60, 0, 70, 100, 100, 30, 25, 30, 65, 50, 80, 0, 1, 55, 1, 15, 0, 62, 90, 0, 1, 50, 0, 90},  /* MONK: a low chant, a sung vowel over it */
    {35, 40, 127, 15, 40, 70, 40, 50, 0, 110, 90, 127, 40, 70, 80, 110, 20, 20, 80, 55, 30, 0, 30, 2, 0, 0, 85, 0, 85, 3, 100, 40, 0},  /* STATIC: a radio between stations: bright grains */
    {85, 70, 8, 10, 22, 45, 100, 10, 0, 60, 0, 80, 110, 120, 20, 15, 35, 80, 55, 85, 0, 2, 0, 0, 10, 8, 85, 20, 0, 1, 64, 0, 110},  /* LULLABY: sweet and simple: soft voices, a fifth over, a slow breath */
    {80, 40, 110, 90, 70, 28, 90, 40, 0, 70, 40, 127, 90, 110, 100, 85, 120, 25, 40, 75, 30, 1, 70, 0, 50, 20, 60, 0, 70, 0, 35, 60, 20},  /* STORM: dark and rough: a heavy tide, wind and grit */
    {50, 120, 25, 10, 40, 65, 25, 60, 15, 90, 50, 120, 85, 105, 60, 45, 50, 40, 80, 90, 0, 3, 20, 1, 100, 30, 105, 80, 0, 2, 85, 10, 40},  /* PRISM: colours: partials evolving, a moving peak */
};

/* the LFOs: RATE's free values (LFO_NFREE of them, 0.005 Hz .. 10 Hz), then its values on the grid, in MIDI clocks
 * (24 a quarter note); what they can move (TARGET's values, 0 OFF): the settings the engine takes as they turn */
#define NLFO 3u
static const uint8_t LFO_BASE[NLFO] = {P_L1_SHAPE, P_L2_SHAPE, P_L3_SHAPE};   /* each LFO's first parameter (SHAPE,
                                                                             * RATE, DEPTH, POLARITY, its TARGETs) */
#define LFO_NFREE 64u
static const uint16_t LFO_TICKS[12] = {1536, 768, 384, 192, 96, 48, 32, 24, 16, 12, 8, 6};
static const char *const LFO_SYNC_NAME[12] = {"16 BARS", "8 BARS", "4 BARS", "2 BARS", "1 BAR", "1/2", "1/2T", "1/4",
                                             "1/4T", "1/8", "1/8T", "1/16"};
static const char *const LFO_SHAPE_NAME[7] = {"SINE", "TRIANGLE", "SAW", "RAMP", "SQUARE", "RANDOM", "DRIFT"};
static const char *const LFO_POL_NAME[3] = {"BIPOLAR", "UP", "DOWN"};
#if FRS_LEAD                             /* (OFF, NPARAM, past a byte with LEAD's settings) */
static const uint16_t LFO_TGT[NLFO_TGT] = {
#else
static const uint8_t LFO_TGT[NLFO_TGT] = {
#endif
   NPARAM, P_TIMBRE, P_ESPACE, P_MOUVEMENT, P_CHALEUR, P_CHOEUR, P_PARTIELS, P_SOUFFLE,
                                    P_DESACCORD, P_FILTRE, P_CH_SHAPE, P_CH_RESO, P_PENTE, P_IMPAIRS, P_ETIREMENT,
                                    P_PA_EVOLVE, P_PA_BEAT, P_PA_FORMANT, P_PA_PEAK, P_RESONANCE, P_COULEUR, P_BR_GRAIN,
                                    P_BR_TONE, P_BR_AIR, P_ECART, P_GL_LEVEL, P_GL_BRIGHT, P_GL_PING, P_GL_SPACE,
                                    P_MX_DRONE, P_MX_GLINT, P_BS_FILTER, P_BS_RESO, P_BS_DRIVE, P_MX_BASS, P_DR_FULL,
                                    P_ARP_CHANCE, P_SQ_LEN, P_GX_SPARK, P_GX_BLUR, P_GX_SINK, P_FL_CUT, P_FL_RESO,
                                    P_PN_DRONE, P_PN_BASS, P_PN_GLINT, P_PN_CLOUD, P_CH_SOFT, P_GL_ATTACK, P_GL_DECAY,
                                    P_GL_SUSTAIN, P_GL_RELEASE, P_BS_ATTACK, P_BS_DECAY, P_BS_SUSTAIN,
                                    P_BS_RELEASE, P_TP_SAT, P_TP_WOBBLE, P_TP_FLUTTER, P_TP_TONE, P_TP_NOISE,
                                    P_TP_DROPOUT
#if FRS_LEAD                             /* LEAD's (card #144; mod_ld): all but PRESET, MODE and OCTAVE (no LFO flips a
                                          * mode, loads a preset or jumps octaves); WAVE short of WHISTLE */
                                    , P_LD_CUT, P_LD_RESO, P_LD_WAVE, P_LD_DETUNE, P_LD_BREATH, P_LD_DRIVE, P_LD_GLIDE,
                                    P_LD_FENV, P_LD_VIB, P_LD_ATTACK, P_LD_DECAY, P_LD_SUSTAIN, P_LD_RELEASE, P_LD_DTIME,
                                    P_LD_DFB, P_LD_DMIX, P_LD_SPACE, P_MX_LEAD, P_LD_FATTACK, P_LD_FDECAY,
                                    P_LD_FSUSTAIN, P_LD_FRELEASE
#else                                    /* (theirs none here: a scene's taken as OFF, core.c sound_val; the numbers
                                          * after them the same on every engine) */
                                    , NPARAM, NPARAM, NPARAM, NPARAM, NPARAM, NPARAM, NPARAM, NPARAM, NPARAM, NPARAM,
                                    NPARAM, NPARAM, NPARAM, NPARAM, NPARAM, NPARAM, NPARAM, NPARAM, NPARAM, NPARAM,
                                    NPARAM, NPARAM
#endif
                                    /* the LFOs' own (card #199): one LFO on another's pace or depth, or its own
                                     * (core.c lfo_run, a moment later) */
                                    , P_L1_RATE, P_L1_DEPTH, P_L2_RATE, P_L2_DEPTH, P_L3_RATE, P_L3_DEPTH
};   /* (GLINT's CHANCE, its SEQ LENGTH, SPARKLE: app.c's, arp_chance, seq_len, sparkle_run; LOFI TAPE II's four past
      * NSOUND: mod_tp) */
_Static_assert(LFO_T_XM + 6u == NLFO_TGT, "the LFOs' six TARGETs last");
static const char *const LFO_TGT_NAME[NLFO_TGT] = {"OFF", "TIMBRE", "SPACE", "MOTION", "WARMTH", "CHOIR", "PARTIALS",
                                             "BREATH", "CH DETUNE", "CH FILTER", "CH SHAPE", "CH RESO", "PA TILT", "PA ODD",
                                             "PA STRETCH", "PA EVOLVE", "PA BEAT", "PA FORMANT", "PA PEAK", "BR RESO", "BR COLOR",
                                             "BR GRAIN", "BR TONE", "BR AIR", "BR SPREAD", "GL LEVEL", "GL BRIGHT", "GL PING",
                                             "GL SPACE", "DRONE LVL", "GLINT LVL", "BS FILTER", "BS RESO",
                                             "BS DRIVE", "BASS LVL", "BODY", "GL CHANCE", "SEQ LEN",
                                             "SPARKLE", "BLUR", "SINK", "MS CUTOFF", "MS RESO", "DRONE PAN", "BASS PAN",
                                             "GLINT PAN", "CLOUD PAN", "CH SOFT", "GL ATTACK", "GL DECAY", "GL SUSTAIN",
                                             "GL RELEASE", "BS ATTACK", "BS DECAY", "BS SUSTAIN",
                                             "BS RELEASE", "LOFI SAT", "WOBBLE", "SPEED", "LOFI TONE",
                                             "LOFI NOISE", "DROPOUT"
                                             , "LD FILTER", "LD RESO", "LD WAVE", "LD DETUNE", "LD BREATH", "LD DRIVE",
                                             "LD GLIDE", "LD FLT ENV", "LD VIBRATO", "LD ATTACK", "LD DECAY", "LD SUSTAIN",
                                             "LD RELEASE", "LD TIME", "LD FEEDBK", "LD MIX", "LD SPACE", "LEAD LVL",
                                             "LD F.ATK", "LD F.DEC", "LD F.SUS", "LD F.REL"
                                             , "LFO1 RATE", "LFO1 DEPTH", "LFO2 RATE", "LFO2 DEPTH", "LFO3 RATE",
                                             "LFO3 DEPTH"
};   /* (new ones at the end: a saved TARGET keeps its setting; LOFI TAPE's own no TAPE in them, whatever its MEDIA:
      * TAPE SAT, TAPE SPEED, TAPE TONE, TAPE NOISE till card #229) */
static float lfo_hz(float r) { return 0.005f * fm_powf(2000.0f, r / (float)(LFO_NFREE - 1u)); }   /* (r: a free
                                          * RATE, an LFO on it between its steps: core.c lfo_run) */
/* GLINT's OCTAVE, in semitones: every glint is played without it, the engine puts it on (a key's, a MIDI note's, the
 * arpeggio's, the sequence's; those sounding too, at once: glint.c), and NOTE shows the steps so (app.c sets it) */
static int32_t seq_shift;
/* BASS's OCTAVE, in semitones: every note of the bass is played without it, the engine puts it on (folded up to C1;
 * the one sounding moves there at once: bass.c), and NOTE shows the steps so */
static int32_t bseq_shift;
/* DRONE SEQ II's NOTES as the step on STEP has them (core.c dseq_view): its notes' count and, one alone, it (as it
 * sounds: TRANSPOSE aside) */
static uint8_t dq_view_n, dq_view_note;
/* a scene's MORPH, ANCHOR's way back: what each setting still lacks of where it goes, in its own steps, toward 0
 * (core.c morph_run): the sound's, and the six a scene keeps past it that sound as it does (SWELL, BASS TONE's WEIGHT,
 * PUNCH, BITE, the bass's SPACE, AUTO VIB: ANCHOR's alone glides them; SWELL's heard by core.c eng_swell) */
#define NMORPH (P_GL_VIB_AUTO + 1)
static float morph_off[NMORPH];
/* a MORPH as the engines before card #202 made it (frs_morph_331: a stream of theirs, its state without MORPH's mark,
 * core.c STATE_MORPH): the notes a scene swaps on the ATTACK and RELEASE heard then, MASTERING's THRESHOLD and GAIN,
 * CLOUD's level and MASTER EQ's seven at the scene's at once (their glide unheard). Off at the start, frs_init's */
static uint8_t morph_331;
/* what the LFOs add to each setting now, in its own steps (app.c, lfo_run); params_to_engine takes them */
static float mod[NSOUND];
/* the same for LOFI TAPE II's four, past NSOUND (TAPE SPEED, TONE, NOISE, DROPOUT): beside mod, not in it, so mod keeps
 * its length (a LIVE snapshot's); lfo_run writes them anew every 10 ms */
static float mod_tp[4];
#if FRS_LEAD                             /* and LEAD's, past the rest (card #144: the SMK-37's), the same way */
static float mod_ld[P_LD_FRELEASE - P_LD_WAVE + 1];
static float *mod_at(uint32_t p)         /* where setting p's LFO offset is; 0: no LFO moves it */
{
    return p < NSOUND ? &mod[p] : p >= P_TP_FLUTTER && p <= P_TP_DROPOUT ? &mod_tp[p - P_TP_FLUTTER]
         : p >= P_LD_WAVE && p <= P_LD_FRELEASE ? &mod_ld[p - P_LD_WAVE] : 0;
}
#else
static float *mod_at(uint32_t p)         /* where setting p's LFO offset is; 0: no LFO moves it */
{
    return p < NSOUND ? &mod[p] : p >= P_TP_FLUTTER && p <= P_TP_DROPOUT ? &mod_tp[p - P_TP_FLUTTER] : 0;
}
#endif
static float mod_of(uint32_t p) { const float *m = mod_at(p); return m ? *m : 0.0f; }
_Static_assert(P_TP_DROPOUT == P_TP_FLUTTER + 3 && P_TP_FLUTTER >= NMORPH, "LOFI TAPE II's four: mod_tp, no MORPH");

/* GLINT's delay, in MIDI clocks (24 a quarter note): T triplets, D dotted */
static const uint8_t GD_TICKS[12] = {3, 4, 6, 8, 9, 12, 16, 18, 24, 32, 36, 48};
static const char *const GD_NAME[12] = {"1/32", "1/16T", "1/16", "1/8T", "1/16D", "1/8", "1/4T", "1/8D", "1/4", "1/2T",
                                        "1/4D", "1/2"};
/* the arpeggiator's steps, in MIDI clocks (24 a quarter note) */
static const uint8_t ARP_TICKS[10] = {96, 48, 32, 24, 16, 12, 8, 6, 4, 3};
static const uint8_t ARP_SNAP_TICKS[6] = {0, 6, 12, 24, 48, 96};   /* ARP SNAP's grid, in MIDI clocks (0: OFF) */
static const char *const ARP_RATE_NAME[10] = {"1/1", "1/2", "1/2T", "1/4", "1/4T", "1/8", "1/8T", "1/16", "1/16T",
                                              "1/32"};
/* the bass's RATE, its arpeggio's and each step of its sequence's: a quarter of a beat .. sixty-four beats (16 BARS), each twice the
 * one before, in MIDI clocks (24 a beat). Till 2.7 each step had its own, BQ_OLD's (dotted ones too: core.c bseq_over
 * makes those over) */
#define NBQLEN 9u
static const uint16_t BQ_TICKS[NBQLEN] = {6, 12, 24, 48, 96, 192, 384, 768, 1536};
static const char *const BQ_LEN_NAME[NBQLEN] = {"1/16", "1/8", "1/4", "1/2", "1 BAR", "2 BARS", "4 BARS", "8 BARS",
                                                "16 BARS"};
#define OLD_BSEQ 16u                     /* the bass's steps till 2.7: each a note and a length (bseq_over) */
#define NBQOLD 13u
static const uint16_t BQ_OLD[NBQOLD] = {6, 12, 24, 36, 48, 72, 96, 144, 192, 288, 384, 768, 1536};
static const float GLINT_RATIO[13] = {0.5f, 1.0f, 1.414f, 2.0f, 2.756f, 3.0f, 3.5f, 4.0f, 5.0f, 7.0f, 9.0f, 11.0f, 13.6f};
static const char *const RATIO_NAME[13] = {"X0.5", "X1", "X1.41", "X2", "X2.76", "X3", "X3.5", "X4", "X5", "X7", "X9",
                                           "X11", "X13.6"};

static void arp_defaults(uint8_t *v)     /* a factory scene's arpeggiator (off, eighths over two octaves) and
                                          * GLINT's delay (dotted eighths, ping-pong, some) */
{
    v[P_GD_TIME] = 7;                    /* (1/8D) */
    v[P_GD_FB] = 50;
    v[P_GD_MODE] = 1;
    v[P_GD_MIX] = 40;
    v[P_SQ_TYPE] = 0;
    v[P_ARP_MODE] = 0;
    v[P_ARP_RATE] = 5;
    v[P_ARP_RANGE] = 1;
    v[P_ARP_CHANCE] = 127;
}

static void later_defaults(uint8_t *v, uint32_t from)   /* the parameters from `from` on (added after the factory
                                                       * scenes, or after a saved scene's layout): their defaults; and
                                                       * GLINT DELAY's TIME, ping-pong always since 2.5 (12 .. 23 the
                                                       * same times, ping-pong, before: % 12) */
{
    uint32_t p;
    for (p = from; p < NSOUND; p++)
        v[p] = PD[p].def;
    v[P_GD_TIME] %= 12u;
}

/* GLINT's RELEASE as DECAY let a glint go before RELEASE was one (where SCATTER was: an earlier layout's made over,
 * app.c sound_over; the River's and the server's from the schema's table): DECAY's time up to 0.6 s, else half of it,
 * 0.6 s at least */
static uint8_t glint_release_of(uint32_t decay)
{
    float t = 0.08f * fm_powf(75.0f, (float)(decay > 127u ? 127u : decay) / 127.0f), r, x;
    r = t < 0.6f ? t : t * 0.5f > 0.6f ? t * 0.5f : 0.6f;
    x = 127.0f * fm_log2f(r / 0.02f) / fm_log2f(300.0f) + 0.5f;
    return (uint8_t)(x < 0.0f ? 0.0f : x > 127.0f ? 127.0f : x);
}

static void glint_preset(uint8_t *v, uint32_t i)   /* preset i into the GLINT parameters */
{
    uint32_t k;
    i %= NGPRESET;
    v[P_GL_PRESET] = (uint8_t)i;
    for (k = 0; k < 7u; k++)
        v[P_GL_RATIO + k] = GLINT_PRESET[i][k];
    v[P_GL_ATTACK] = GLINT_PRESET[i][7];
    v[P_GL_PING] = GLINT_PRESET[i][8];
    v[P_GL_SUSTAIN] = GLINT_PRESET[i][9];
}

#if FRS_LEAD
/* LEAD's presets (card #144; twenty since admin #870: eighteen too like the others taken out, six made apart): MOSS
 * first, the first LEAD's sound (PD's defaults: the same, the dry sample for sample), WARM JACKET (admin #629: Styves's
 * own, read from his SMK-37, scene 7 RETURN), then soft (round, slow, the filter low; MOTH a WHISTLE, breathy), warm
 * (saws and squares, the filter half open, a glide), MAHOGANY glowing (admin #615: a saw with some pulse in it, the
 * four-pole closed round a kilohertz, swelling as brass does), three a little sharper (still round: no narrow pulse,
 * the resonance and the envelope moderate) and FURNACE aggressive (its bite the drive and the low mids, not the
 * treble): none glassy, the brightest at MOSS's or a little over (Styves, 2026-11-09). The six of admin #870 (tuned by
 * measurement, never listened to), each apart from the rest by its envelopes, the level's and the filter's, and its
 * space:
 *   NEBULA    POLY, a slow swell (ATTACK 1.5 s), a long tail (RELEASE some 7 s), its filter opening after the level
 *             (F.ATTACK 2 s), detuned saws and some breath, all of it into the cloud and the delay (1/4T);
 *   WICKER    MONO, a pulse, nasal as a reed, breathy, close: no delay, no cloud, a short RELEASE (none of the
 *             six a square: two of them at their random phases cancel on a short note, some 16 dB from one to
 *             the next);
 *   UMBER     MONO an octave down, bowed (ATTACK 0.4 s), a long glide and a wide vibrato, a dense trail of echoes
 *             (1/8, FEEDBACK high) into the cloud;
 *   DAYBREAK  MONO, a narrow pulse whose filter opens late (F.ATTACK 2 s, FILTER ENV high), gliding, singing; the
 *             delay and the cloud between the dry ones' and the wet ones';
 *   RAIN      POLY, a WHISTLE plucked (no SUSTAIN: gone in some 0.3 s), its echoes on the dotted eighth louder than
 *             it, into the cloud;
 *   THORN     MONO an octave down, a driven saw, tight (RELEASE 60 ms), its filter a quick blip (F.SUSTAIN low), dry:
 *             no delay, no cloud.
 * The delay GLINT's (TIME on the beat: at TEMPO's 90 BPM 1/8 333 ms, 1/4T 444, 1/8D 500), discreet on the soft. Each
 * sets every LEAD setting but its MIXER level: LEAD_PRESET_P's, the values as the knobs have them. The filter's ADSR
 * (admin #619) the amp's but WARM JACKET's, PRISM's (a pluck in it: the filter quick down, the level held) and the new
 * ones' (UMBER's aside). Then CUSTOM (LP_CUSTOM): no preset's */
static const uint16_t LEAD_PRESET_P[23] = {P_LD_WAVE, P_LD_CUT, P_LD_RESO, P_LD_MODE, P_LD_DETUNE, P_LD_BREATH, P_LD_DRIVE,
                                           P_LD_GLIDE, P_LD_FENV, P_LD_VIB, P_LD_OCTAVE, P_LD_ATTACK, P_LD_DECAY,
                                           P_LD_SUSTAIN, P_LD_RELEASE, P_LD_DTIME, P_LD_DFB, P_LD_DMIX, P_LD_SPACE,
                                           P_LD_FATTACK, P_LD_FDECAY, P_LD_FSUSTAIN, P_LD_FRELEASE};
static const char *const LEAD_PRESET_NAME[NLPRESET] = {
    "MOSS", "WARM JACKET",
    "VELVET", "MOTH", "HUSH", "NEBULA", "DRIFTWOOD", "HALO",
    "COPPER", "HONEY", "WICKER", "UMBER", "DAYBREAK",
    "MAHOGANY",
    "PRISM", "COMET", "RAIN", "FLINT",
    "FURNACE", "THORN"};
static const uint8_t LEAD_PRESET[NLPRESET][23] = {
    /* WAVE CUT RESO MODE DET BRTH DRV GLD FENV VIB OCT   A   D   S   R TIME  FB MIX SPACE F.A F.D F.S F.R */
    {   24,  58,  40,  0,  40,   0,  32, 30,  55,  0,  3, 15, 70, 90, 50,   3, 51, 40,  70,  15,  70,  90,  50},   /* MOSS */
    {    0,  53,   0,  1,  64,   8,  84,  0,  37,  0,  3, 39,103, 67, 82,   7, 30,  0,  98, 101, 123,  26,  43},   /* WARM
                                                                                              * JACKET: Styves's, as
                                                                                              * his SMK-37 had it */
    {   64,  44,  15,  1,  30,  10,  20,  0,  25, 15,  3, 70, 80,100, 75,   7, 40, 26,  85,  70,  80, 100,  75},   /* VELVET */
    {  128,  70,   0,  0,   0,  50,  10, 40,   0, 40,  3, 50, 70,110, 60,   7, 42, 26,  80,  50,  70, 110,  60},   /* MOTH */
    {   20,  36,  10,  1,  50,  30,  16,  0,  20,  0,  2, 85, 90,115, 85,   6, 45, 28, 105,  85,  90, 115,  85},   /* HUSH */
    {    0,  48,  15,  1, 100,  25,  20,  0,  50, 10,  2,108,100,115,116,   6, 95, 70, 127, 112, 100, 100, 116},   /* NEBULA */
    {   10,  42,  30,  0,  55,   8,  28, 60,  35, 20,  3, 35, 80, 95, 65,   5, 48, 32,  80,  35,  80,  95,  65},   /* DRIFTWOOD */
    {   56,  48,  15,  1,  60,  20,  18,  0,  20, 10,  3, 90, 90,110, 90,   7, 50, 30, 110,  90,  90, 110,  90},   /* HALO */
    {   10,  54,  30,  1,  55,   0,  34,  0,  40,  0,  3, 30, 75, 95, 62,   5, 42, 30,  75,  30,  75,  95,  62},   /* COPPER */
    {   56,  48,  40,  0,  20,   8,  30, 42,  45, 30,  3, 20, 75, 92, 55,   3, 48, 34,  65,  20,  75,  92,  55},   /* HONEY */
    {  100,  46,  20,  0,  50,  70,  40, 20,  30, 15,  3, 40, 70,110, 30,   5,  0,  0,   0,  30,  60,  90,  30},   /* WICKER */
    {   16,  54,  26,  0,  45,  14,  50, 72,  30, 40,  2, 82, 90,118, 90,   5,112, 85, 127,  82,  90, 118,  90},   /* UMBER */
    {  112,  24,  48,  0,  30,   6,  40, 58,  72, 30,  3, 30, 80,120, 62,   9, 40, 30,  62, 112, 100, 105,  80},   /* DAYBREAK */
    {   36,  47,  20,  1,  55,   4,  28,  0,  34,  0,  2, 60, 90,105, 85,   7, 46, 30, 100,  60,  90, 105,  85},   /* MAHOGANY */
    {   88,  58,  30,  1,  40,   0,  32,  0,  50,  0,  3,  8, 60, 80, 55,   4, 40, 28,  65,   5,  50,  45,  50},   /* PRISM */
    {   70,  58,  40,  0,  30,   0,  40, 25,  55,  0,  3,  5, 55, 80, 45,   5, 42, 30,  55,   5,  55,  80,  45},   /* COMET */
    {  128,  60,   0,  1,   0,   0,  30,  0,   0,  0,  3,  0, 70,  0, 50,   7,105,110, 127,   0,  70,   0,  50},   /* RAIN */
    {   80,  54,  30,  1,  20,   0,  36,  0,  60,  0,  3,  2, 55, 65, 50,   4, 38, 30,  60,   2,  55,  65,  50},   /* FLINT */
    {   30,  58,  50,  1,  90,   0, 100,  0,  40,  0,  2,  8, 70, 92, 55,   5, 42, 26,  55,   8,  70,  92,  55},   /* FURNACE */
    {    0,  40,  62,  0,  24,   0,  96, 18,  80,  0,  2,  0, 48, 72, 14,   3,  0,  0,   0,   0,  34,  10,  14},   /* THORN */
};

static void lead_preset(uint8_t *v, uint32_t i)   /* preset i into LEAD's settings (its MIXER level as it is); CUSTOM
                                                   * (LP_CUSTOM, or past it) its name alone, the settings as they are */
{
    uint32_t k;
    if (i >= NLPRESET) {
        v[P_LD_PRESET] = (uint8_t)LP_CUSTOM;
        return;
    }
    v[P_LD_PRESET] = (uint8_t)i;
    for (k = 0; k < sizeof LEAD_PRESET_P / sizeof LEAD_PRESET_P[0]; k++)
        v[LEAD_PRESET_P[k]] = LEAD_PRESET[i][k];
}
/* a LEAD setting as a scene, a shard, the player's preset or Perform's state brings it (core.c lead_set, live.c, app.c
 * ldu_take): in its range as it is, past it its default, but PRESET's CUSTOM (a number no preset has now: the
 * settings as they came, none named); never a preset's sound over them. No number is made over (admin #875: no FRASIL
 * released had the LEAD): one stored before admin #870 (Styves's own FM-1s alone) names the preset there now, its
 * sound its own settings' */
static uint8_t lead_in(uint32_t p, uint32_t x)
{
    return x <= PD[p].max ? (uint8_t)x : p == P_LD_PRESET ? (uint8_t)LP_CUSTOM : PD[p].def;
}
#endif

/* MOSS's LEAD (card #152): P_LD_WAVE .. P_LD_FRELEASE as PD has their defaults (LEAD_PRESET's first, its MIXER level
 * 100), a shard's LEAD when it has none ("FRS}" and before, a scene stored without one); in every build, so that an
 * engine without the LEAD makes its shards ("FRS~") with it (engine/tests/lead.c: PD's, each) */
#define LEAD_BYTES 25u
static const uint8_t LEAD_MOSS[LEAD_BYTES] = {24, 58, 40, 40, 30, 55, 0, 3, 15, 70, 90, 50,   /* WAVE .. RELEASE */
                                              3, 51, 40, 70, 100, 0, 0, 0, 32,             /* TIME .. DRIVE */
                                              15, 70, 90, 50};                             /* F.ATTACK .. F.RELEASE */

/* ---------------------------------------------------------- the engine --- */
/* MASTER EQ and MASTER FILTER: their mappings (the engine's and the screen's), their names */
#define EQ_LOWF(u) (30.0f * fm_powf(20.0f, (u)))
#define EQ_MIDF(u) (80.0f * fm_powf(150.0f, (u)))
#define EQ_HIGHF(u) (1500.0f * fm_powf(10.6667f, (u)))
#define EQ_Q(u) (0.4f * fm_powf(20.0f, (u)))
#define FL_CUT(u) (20.0f * fm_powf(1000.0f, (u)))
#define FL_Q(u) (0.7071f * fm_powf(17.0f, (u)))  /* RESONANCE: 0.71 (no peak) .. 12 */
#define EQ_NPRESET 7u
static const char *const EQ_PRESET_NAME[2u + EQ_NPRESET] = {"OFF", "CUSTOM", "FLAT", "WARM", "AIR", "MUD CUT", "BOX CUT",
                                                           "LOUD", "SMALL SPEAKER"};
/* each preset's LOW, MID, HIGH (half decibels, 24: 0 DB), LOW FREQ, MID FREQ, Q, HIGH FREQ (as the knobs have them):
 * FLAT 0 everywhere; WARM +2.5 DB under 150 HZ, -2 DB over 7 KHZ; AIR +3 DB over 10 KHZ; MUD CUT -3.5 DB at 300 HZ;
 * BOX CUT -3 DB at 600 HZ, narrower; LOUD +3 DB under 100 HZ, +2.5 DB over 9 KHZ, -1 DB round 1 KHZ; SMALL SPEAKER
 * -6 DB under 120 HZ (what a small speaker cannot carry), +2 DB of presence at 2.5 KHZ */
static const uint8_t EQ_PRESETS[EQ_NPRESET][7] = {
    {24, 24, 24, 59, 64, 39, 90}, {29, 24, 20, 68, 64, 39, 83}, {24, 24, 30, 59, 64, 39, 102}, {24, 17, 24, 59, 34, 39, 90},
    {24, 18, 24, 59, 51, 53, 90}, {30, 22, 29, 51, 64, 24, 96}, {12, 28, 24, 59, 87, 29, 90}};
static const char *const FL_TRACKS_NAME[7] = {"ALL", "DRONE", "GLINT", "BASS", "DRONE+GLINT", "DRONE+BASS", "GLINT+BASS"};

/* LOFI TAPE II's TAPE SPEED, as the octaves it moves (log2 of its factor), the one mapping (the FM-1, the stream's
 * readers, the iPad's engine; its text, F_TSPEED): X1.00 at 64 exactly (so that a tape from before plays as it did),
 * X0.01 a detent from X0.48 (12) to X1.58 (122): X0.50 (14) an octave down, X1.50 (114) a fifth up; past them a
 * half-tone a detent (X0.47 .. X0.25 at 0, two octaves down; X1.59 .. X2.00 at 127, one up). Until 3.1 the byte was
 * log2's own, a 32nd of an octave a detent under X1.00 (X0.79, X0.77: two hundredths) and a 63rd over: tape_302 reads it
 * so (frs_tape_302, a stream of 3.0.2's layout: card #160) */
static uint8_t tape_302;
static float tape_oct(uint32_t x)
{
    if (tape_302)                        /* (3.0.2's own sum, as its engine made it: its takes' grid on its very steps) */
        return x <= 64u ? ((float)x - 64.0f) * (1.0f / 32.0f) : ((float)(x > 127u ? 127u : x) - 64.0f) * (1.0f / 63.0f);
    return x == 64u ? 0.0f
         : x < 12u  ? ((float)x - 24.0f) * (1.0f / 12.0f)
         : x > 122u ? ((float)(x > 127u ? 127u : x) - 115.0f) * (1.0f / 12.0f)
                    : fm_log2f((float)(36u + x) * 0.01f);
}

/* ... between its detents too (an LFO on it, TARGET's TAPE SPEED: x, 0 .. 127, with what it adds), from one detent's
 * octaves to the next's; on a detent, tape_oct's own */
static float tape_octf(float x)
{
    uint32_t i;
    if (x <= 0.0f)
        return tape_oct(0);
    if (x >= 127.0f)
        return tape_oct(127);
    i = (uint32_t)x;
    x -= (float)i;
    return x == 0.0f ? tape_oct(i) : tape_oct(i) + (tape_oct(i + 1u) - tape_oct(i)) * x;
}

/* the half-tones TAPE SPEED at x moves the pitch, when it lands on one: 12 log2 of its factor within 0.1 of a whole
 * number, and nearer it than the detents beside (one detent a half-tone: X1.50, not X1.49, for the fifth); 0 at
 * X1.00 and between them (LOFI TAPE II, between the reels: -3 as "-1.5 TONES") */
static int tape_semis(uint32_t x)
{
    float s = 12.0f * tape_oct(x), e;
    int n = (int)(s < 0.0f ? s - 0.5f : s + 0.5f);
    e = fm_fabsf(s - (float)n);
    if (!n || e > 0.1f || (x > 0u && fm_fabsf(12.0f * tape_oct(x - 1u) - (float)n) < e) ||
        (x < 127u && fm_fabsf(12.0f * tape_oct(x + 1u) - (float)n) < e))
        return 0;
    return n;
}

/* LOFI TAPE II's four as the tape was before them (TAPE SPEED X1.00, TONE in the middle, no hiss, no dropouts), not their
 * defaults (TONE +10): what a scene, a shard or the settings from before "FRS{" (and every factory scene) are made over
 * with, so they sound as they did (core.c tape_none; the schema's tape.none) */
static const uint8_t TAPE_NONE[4] = {64, 64, 0, 0};

static float u7(const uint8_t *v, int p)  /* a setting, 0..1, with what the LFOs add to it */
{
    float x = ((float)v[p] + (p < NSOUND ? mod[p] + morph_off[p] : p < NMORPH ? morph_off[p] : mod_of((uint32_t)p))) /
              (float)PD[p].max;
    return x < 0.0f ? 0.0f : x > 1.0f ? 1.0f : x;
}

/* a setting where a MORPH's way has it heard, of those taken as they are, no LFO on them: MASTERING's THRESHOLD and
 * GAIN, CLOUD's level, MASTER EQ's seven (until card #202, at the scene's at once: morph_331) */
static float morph_heard(const uint8_t *v, int p) { return morph_331 ? (float)v[p] : (float)v[p] + morph_off[p]; }

/* the drones' ATTACK and RELEASE: u7's, past 1 as far as a scene's MORPH takes them (core.c eng_scene_go: the notes it
 * swaps go out and come in over its length, card #202; at 1, 30 s and 60 s, a MORPH up to 2:00) */
static float u7_env(const uint8_t *v, int p)
{
    float top = ((float)v[p] + morph_off[p]) / (float)PD[p].max, x;
    if (top <= 1.0f)
        return u7(v, p);
    x = ((float)v[p] + (mod[p] + morph_off[p])) / (float)PD[p].max;
    return x < 0.0f ? 0.0f : x > top ? top : x;
}

static void params_to_engine(const uint8_t *v, int freeze, frasil_params_t *b)
{
    b->choir = u7(v, P_CHOEUR);
    b->partials = u7(v, P_PARTIELS);
    b->souffle = u7(v, P_SOUFFLE);
    b->drive = u7(v, P_CHALEUR);
    b->detune = u7(v, P_DESACCORD);
    b->cutoff = u7(v, P_FILTRE);
    b->tilt = u7(v, P_PENTE);
    b->odd = u7(v, P_IMPAIRS);
    b->stretch = u7(v, P_ETIREMENT);
    b->resonance = u7(v, P_RESONANCE);
    b->color = u7(v, P_COULEUR);
    b->spread = u7(v, P_ECART);
    b->attack = u7_env(v, P_ATTAQUE);
    b->release = u7_env(v, P_RELACHE);
    b->pressure = u7(v, P_PRESSION);
    b->velocity = u7(v, P_VELOCITE);
    b->motion = u7(v, P_MOUVEMENT);
    b->motion_rate = u7(v, P_VITESSE);
    b->tide = u7(v, P_MAREE);
    b->tide_rate = u7(v, P_PERIODE);
    b->timbre = u7(v, P_TIMBRE);
    b->mix = u7(v, P_ESPACE);
    b->tune = ((float)v[P_ACCORD] - 50.0f) * 0.01f;
    b->rev.size = u7(v, P_TAILLE);
    b->rev.decay = u7(v, P_DUREE);
    b->rev.damp = u7(v, P_TEINTE);
    b->rev.shimmer = u7(v, P_SHIMMER);
    b->rev.shimmer_tone = u7(v, P_SH_TONE);
    b->rev.diffusion = u7(v, P_DIFFUSION);
    b->rev.mod = u7(v, P_MODULATION);
    b->rev.predelay = u7(v, P_PREDELAI);
    b->rev.interval = INTERVALS[v[P_INTERVALLE] % 5u];
    b->rev.lowcut = u7(v, P_COUPEBAS);
    b->rev.width = u7(v, P_LARGEUR);
    b->rev.freeze = freeze;
    b->glint.ratio = GLINT_RATIO[v[P_GL_RATIO] % 13u];
    b->glint.octave = (int)v[P_GL_OCTAVE];
    b->glint.bright = u7(v, P_GL_BRIGHT);
    b->glint.decay = u7(v, P_GL_DECAY);
    b->glint.level = u7(v, P_GL_LEVEL);
    b->glint.space = u7(v, P_GL_SPACE);
    b->glint.release = u7(v, P_GL_RELEASE);
    b->glint.attack = u7(v, P_GL_ATTACK);
    b->glint.ping = u7(v, P_GL_PING);
    b->glint.delay_fb = u7(v, P_GD_FB);
    b->glint.delay_mix = u7(v, P_GD_MIX);
    b->glint.delay_pp = 1;               /* (always: TIME's 12 .. 23 till 2.5) */
    b->glint.delay_s = 0.25f;            /* the app puts the tempo's in (glint_delay_s) */
    b->glint.vibrato = u7(v, P_GL_VIBRATO);
    b->glint.vib_auto = u7(v, P_GL_VIB_AUTO);
    b->glint.sustain = u7(v, P_GL_SUSTAIN);
    b->pump_drone = u7(v, P_PUMP_DRONE);
    b->pump_bass = u7(v, P_PUMP_BASS);
    b->pump_glint = u7(v, P_PUMP_GLINT);
    b->pump_rel = 0.1f + 0.9f * u7(v, P_PUMP_REL);
    b->pump_att = 0.001f * fm_powf(300.0f, u7(v, P_PUMP_ATT));
    b->pump_off = u7(v, P_PUMP_OFF);
    b->comp_thr = morph_heard(v, P_MS_THRESH) - 40.0f;
    b->comp_ratio = COMP_RATIO[v[P_MS_RATIO] % 8u];
    b->comp_rel = 0.03f * fm_powf(50.0f, u7(v, P_MS_RELEASE));
    b->comp_gain = v[P_MS_RATIO] ? fm_exp2f(morph_heard(v, P_MS_GAIN) * 0.166096405f) : 1.0f;   /* (RATIO OFF: no GAIN) */
    b->mx_drone = u7(v, P_MX_DRONE) * 1.27f;
    b->mx_bass = u7(v, P_MX_BASS) * 1.27f;
    b->mx_glint = u7(v, P_MX_GLINT) * 1.27f;
    b->mx_cloud = morph_heard(v, P_MX_CLOUD) * 0.01f;
    {                                    /* the layers' second pages */
        static const float CH_IV[4] = {1.0f, 0.5f, 1.4983071f, 2.0f}, BR_IV[5] = {0.5f, 1.0f, 2.0f, 2.9966142f, 4.0f};
        float tn = u7(v, P_BR_TONE) * 127.0f;
        b->ch_shape = u7(v, P_CH_SHAPE);
        b->ch_interval = CH_IV[v[P_CH_INTERVAL] % 4u];
        b->ch_reso = u7(v, P_CH_RESO);
        b->ch_soft = u7(v, P_CH_SOFT);
        b->ch_type = v[P_CH_TYPE] % 3u;
        b->pa_evolve = u7(v, P_PA_EVOLVE);
        b->pa_beat = u7(v, P_PA_BEAT);
        b->pa_formant = 3.0f * u7(v, P_PA_FORMANT);
        b->pa_peak = u7(v, P_PA_PEAK);
        b->br_grain = u7(v, P_BR_GRAIN);
        b->br_pitch = BR_IV[v[P_BR_PITCH] % 5u];
        b->br_tone = tn >= 126.5f ? 1.0f : (tn - 64.0f) * (1.0f / 63.0f);   /* -1 .. 1 */
        b->br_air = u7(v, P_BR_AIR);
    }
    b->fullness = u7(v, P_DR_FULL);
    {                                    /* MASTER EQ, MASTER FILTER, LOFI TAPE (TRACKS: ALL, DRONE, GLINT, BASS, the
                                          * pairs: the engine's bits) */
        static const uint8_t TRK[7] = {7, 1, 2, 4, 3, 5, 6};
        float lo = morph_heard(v, P_EQ_LOW), mid = morph_heard(v, P_EQ_MID), hi = morph_heard(v, P_EQ_HIGH);
        b->eq_on = v[P_EQ_PRESET] != 0 &&    /* (its bands flat: nothing to do, nothing spent) */
                   (lo != 24.0f || mid != 24.0f || hi != 24.0f);
        b->eq_low = 0.5f * (lo - 24.0f);
        b->eq_mid = 0.5f * (mid - 24.0f);
        b->eq_high = 0.5f * (hi - 24.0f);
        b->eq_lowf = EQ_LOWF(morph_heard(v, P_EQ_LOWF) / 127.0f);
        b->eq_midf = EQ_MIDF(morph_heard(v, P_EQ_MIDF) / 127.0f);
        b->eq_q = EQ_Q(morph_heard(v, P_EQ_Q) / 127.0f);
        b->eq_highf = EQ_HIGHF(morph_heard(v, P_EQ_HIGHF) / 127.0f);
        b->fl_type = v[P_FL_TYPE] % 3u;
        b->fl_cut = FL_CUT(u7(v, P_FL_CUT));
        b->fl_q = FL_Q(u7(v, P_FL_RESO));
        b->fl_tracks = TRK[v[P_FL_TRACKS] % 7u];
        b->tp_on = v[P_TP_ON] > 4u ? 4 : v[P_TP_ON];   /* (MEDIA: 0 off, FR_TAPE, FR_VINYL, FR_AM, FR_PHONE) */
        b->tp_sat = u7(v, P_TP_SAT);
        b->tp_wobble = u7(v, P_TP_WOBBLE);
        b->tp_flutter = 5.0f;            /* (fixed since TAPE SPEED took its byte; 7.3 HZ before) */
        {
            float t = (float)v[P_TP_TONE] + mod_of(P_TP_TONE);   /* (with what an LFO adds: TARGET's TAPE TONE) */
            t = t < 0.0f ? 0.0f : t > 127.0f ? 127.0f : t;
            b->tp_tone = t == 64.0f ? 1.0f : fm_powf(2.0f, (t - 64.0f) * (1.0f / 32.0f));
        }
        b->tp_noise = u7(v, P_TP_NOISE);
        b->tp_dropout = u7(v, P_TP_DROPOUT);
        b->tp_tracks = TRK[v[P_TP_TRACKS] % 7u];
        b->fl_pre = v[P_FL_PRE] != 0;
        b->tp_pre = v[P_TP_PRE] != 0;
        b->pump_cloud = v[P_PUMP_CLOUD] != 0;
        b->pan[0] = u7(v, P_PN_DRONE) * 2.0f - 1.0f;   /* the groups' order: the drones (and the cloud's
                                                               * return, CLOUD PAN's), GLINT, BASS */
        b->pan[1] = u7(v, P_PN_GLINT) * 2.0f - 1.0f;   /* (with what an LFO adds: TARGET's DRONE PAN ...) */
        b->pan[2] = u7(v, P_PN_BASS) * 2.0f - 1.0f;
        b->pan[3] = u7(v, P_PN_CLOUD) * 2.0f - 1.0f;
    }
    {                                    /* GENERATIVE FX: BLUR, the drone into the cloud (wetter, longer, more
                                          * diffuse, the glints further in too); SINK, the engine's */
        float bl = u7(v, P_GX_BLUR);
        if (b->mix < 0.9f)
            b->mix += (0.9f - b->mix) * bl;
        b->rev.decay += (1.0f - b->rev.decay) * 0.7f * bl;
        b->rev.diffusion += (1.0f - b->rev.diffusion) * bl;
        b->rev.mod += (1.0f - b->rev.mod) * 0.5f * bl;
        b->glint.space += (1.0f - b->glint.space) * 0.8f * bl;
        b->sink = u7(v, P_GX_SINK);
    }
    b->bass.model = v[P_BS_MODEL];
    b->bass.drive = u7(v, P_BS_DRIVE);
    b->bass.filter = u7(v, P_BS_FILTER);
    b->bass.resonance = u7(v, P_BS_RESO);
    b->bass.glide = u7(v, P_BS_GLIDE);
    b->bass.level = u7(v, P_BS_LEVEL);
    b->bass.attack = u7(v, P_BS_ATTACK);
    b->bass.release = u7(v, P_BS_RELEASE);
    b->bass.decay = u7(v, P_BS_DECAY);
    b->bass.sustain = u7(v, P_BS_SUSTAIN);
    b->bass.weight = u7(v, P_BS_WEIGHT);
    b->bass.punch = u7(v, P_BS_PUNCH);
    b->bass.bite = u7(v, P_BS_BITE);
    b->bass.space = u7(v, P_BS_SPACE);
    b->bass.octave = (int)v[P_BS_OCTAVE] - 2;   /* (-2 .. 0) */
#if FRS_LEAD
    b->lead.whistle = v[P_LD_WAVE] > 127u;   /* (128 WHISTLE, past PULSE: the knob's alone, an LFO's never) */
    {
        float w = ((float)v[P_LD_WAVE] + mod_of(P_LD_WAVE)) / 127.0f;   /* (u7's, as the first LEAD had it) */
        b->lead.wave = w < 0.0f ? 0.0f : w > 1.0f ? 1.0f : w;
    }
    b->lead.poly = v[P_LD_MODE] != 0;
    b->lead.breath = u7(v, P_LD_BREATH);
    b->lead.drive = u7(v, P_LD_DRIVE);
    b->lead.cutoff = u7(v, P_LD_CUT);
    b->lead.resonance = u7(v, P_LD_RESO);
    b->lead.detune = u7(v, P_LD_DETUNE);
    b->lead.glide = u7(v, P_LD_GLIDE);
    b->lead.fenv = u7(v, P_LD_FENV);
    b->lead.vibrato = u7(v, P_LD_VIB);
    b->lead.octave = (int)v[P_LD_OCTAVE] - 2;   /* (-2 .. +2) */
    b->lead.attack = u7(v, P_LD_ATTACK);
    b->lead.decay = u7(v, P_LD_DECAY);
    b->lead.sustain = u7(v, P_LD_SUSTAIN);
    b->lead.release = u7(v, P_LD_RELEASE);
    b->lead.fattack = u7(v, P_LD_FATTACK);   /* (FILTER ENV's own: the amp's way, the same settings the same curve) */
    b->lead.fdecay = u7(v, P_LD_FDECAY);
    b->lead.fsustain = u7(v, P_LD_FSUSTAIN);
    b->lead.frelease = u7(v, P_LD_FRELEASE);
    b->lead.dfb = u7(v, P_LD_DFB);       /* (TIME's seconds, on the beat: core.c delay_sync, engine_push) */
    b->lead.dmix = u7(v, P_LD_DMIX);
    b->lead.space = u7(v, P_LD_SPACE);
    b->lead.level = u7(v, P_MX_LEAD) * 1.27f;
#endif
}

#include "harmony.c"

/* ---------------------------------------------------------- the words --- */
static void text_cat(char *d, const char *s)
{
    while (*d)
        d++;
    while (*s)
        *d++ = *s++;
    *d = 0;
}

static void int_text(int32_t v, char *b)     /* signed, no padding */
{
    char t[12];
    int n = 0;
    uint32_t u = (uint32_t)(v < 0 ? -v : v);
    do
        t[n++] = (char)('0' + u % 10u);
    while ((u /= 10u) && n < 11);
    if (v < 0)
        *b++ = '-';
    while (n)
        *b++ = t[--n];
    *b = 0;
}

/* a time in seconds as the screen writes it: 12 MS, 340 MS, 1.4 S, 12 S, 2:30 */
static void time_text(float s, char *b)
{
    char t[12];
    b[0] = 0;
    if (s < 1.0f) {
        int_text((int32_t)(s * 1000.0f + 0.5f), b);
        text_cat(b, " MS");
    } else if (s < 10.0f) {
        int32_t d = (int32_t)(s * 10.0f + 0.5f);
        int_text(d / 10, b);
        text_cat(b, ".");
        int_text(d % 10, t);
        text_cat(b, t);
        text_cat(b, " S");
    } else if (s < 100.0f) {
        int_text((int32_t)(s + 0.5f), b);
        text_cat(b, " S");
    } else {
        int32_t m = (int32_t)(s + 0.5f);
        int_text(m / 60, b);
        text_cat(b, ":");
        if (m % 60 < 10)
            text_cat(b, "0");
        int_text(m % 60, t);
        text_cat(b, t);
    }
}

static char *text_end(char *b)
{
    while (*b)
        b++;
    return b;
}

/* a frequency as the screen writes it: 830 HZ, 1.2 KHZ, 12 KHZ */
static void hz_text(float hz, char *b)
{
    if (hz < 999.5f) {
        int_text((int32_t)(hz + 0.5f), b);
        text_cat(b, " HZ");
    } else if (hz < 9950.0f) {
        int32_t d = (int32_t)(hz * 0.01f + 0.5f);
        int_text(d / 10, b);
        text_cat(b, ".");
        int_text(d % 10, text_end(b));
        text_cat(b, " KHZ");
    } else {
        int_text((int32_t)(hz * 0.001f + 0.5f), b);
        text_cat(b, " KHZ");
    }
}

/* parameter p at value x, as the screen writes it (the same mappings as the engine's) */
static void value_text(int p, uint8_t x, char *b)
{
    float u = PD[p].max ? (float)x / (float)PD[p].max : 0.0f;   /* (UNDO's place, gone: nothing to turn) */
    b[0] = 0;
    switch (PD[p].fmt) {
    case F_ATT:
        time_text(0.005f * fm_powf(6000.0f, u), b);
        break;
    case F_REL:
        time_text(0.05f * fm_powf(1200.0f, u), b);
        break;
    case F_DECAY:
        time_text(0.4f * fm_powf(150.0f, u), b);
        break;
    case F_TAU:                          /* the drift's time constant */
        time_text(20.0f * fm_powf(0.025f, u), b);
        break;
    case F_PERIOD:                       /* one turn of the tide */
        time_text(300.0f * fm_powf(1.0f / 30.0f, u), b);
        break;
    case F_PREDELAY:
        int_text((int32_t)(u * 200.0f + 0.5f), b);
        text_cat(b, " MS");
        break;
    case F_HZ:
        int_text((int32_t)(20.0f * fm_powf(25.0f, u) + 0.5f), b);
        text_cat(b, " HZ");
        break;
    case F_INTERVAL: {
        static const char *const IV[5] = {"+12", "+7", "+5", "+19", "-12"};
        text_cat(b, IV[x % 5u]);
        break;
    }
    case F_CENTS:
        if (x > 50u)
            text_cat(b, "+");
        int_text((int32_t)x - 50, b + (x > 50u));
        text_cat(b, " CT");
        break;
    case F_ROOT:
        text_cat(b, NOTE_NAME[x % 12u]);
        break;
    case F_SCALE:
        text_cat(b, SCALE_NAME[x % NSCALES]);
        break;
    case F_CHORD:
        text_cat(b, CHORD_NAME[x % NCHORDS]);
        break;
    case F_VOICING: {
        static const char *const VO[3] = {"CLOSE", "OPEN", "WIDE"};
        text_cat(b, VO[x % 3u]);
        break;
    }
    case F_GPRESET:
        text_cat(b, GLINT_NAME[x % NGPRESET]);
        break;
    case F_RATIO:
        text_cat(b, RATIO_NAME[x % 13u]);
        break;
    case F_OCTAVE:
        text_cat(b, "+");
        int_text(x, b + 1);
        break;
    case F_GDECAY:
        time_text(0.08f * fm_powf(75.0f, u), b);
        break;
    case F_GREL:
        time_text(0.02f * fm_powf(300.0f, u), b);
        break;
    case F_DTIME:                        /* (ping-pong, always) */
        text_cat(b, GD_NAME[x % 12u]);
        break;
    case F_PREPOST:
        text_cat(b, x ? "PRE CLOUD" : "POST CLOUD");
        break;
    case F_PAN:                          /* L50 .. C .. R50 */
        if (x == 50u) {
            text_cat(b, "C");
        } else {
            text_cat(b, x < 50u ? "L" : "R");
            int_text(x < 50u ? 50 - (int32_t)x : (int32_t)x - 50, b + 1);
        }
        break;
    case F_TSPEED: {                     /* "×0.25" .. "×1.00" (64) .. "×2.00", as the LFO AMOUNTs (UTF-8's ×: the FM-1
                                          * draws its own, ui.c value_big) */
        int32_t d = (int32_t)(fm_exp2f(tape_oct(x)) * 100.0f + 0.5f);
        char *e;
        text_cat(b, "\xC3\x97");
        int_text(d / 100, b + 2);
        text_cat(b, d % 100 < 10 ? ".0" : ".");
        for (e = b; *e; e++)
            ;
        int_text(d % 100, e);
        break;
    }
    case F_AMT: {                        /* LFO AMOUNT: "×0.00" .. "×1.00" (100) .. "×5.00" (200), by 0.01 on the left,
                                          * 0.04 on the right (UTF-8's ×: the FM-1 draws its own, ui.c amt_head) */
        uint32_t m = x <= 100u ? x : 100u + 4u * (x - 100u);
        char d[5] = {(char)('0' + m / 100u % 10u), '.', (char)('0' + m / 10u % 10u), (char)('0' + m % 10u), 0};
        text_cat(b, "\xC3\x97");
        text_cat(b, d);
        break;
    }
#if FRS_LEAD
    case F_LWAVE:                        /* LEAD's: a saw, through a square, to a narrow pulse; then WHISTLE */
        if (x == 0)
            text_cat(b, "SAW");
        else if (x == 64u)
            text_cat(b, "SQUARE");
        else if (x == 127u)
            text_cat(b, "PULSE");
        else if (x > 127u)
            text_cat(b, "WHISTLE");
        else
            int_text((int32_t)((float)x * (100.0f / 127.0f) + 0.5f), b);
        break;
    case F_LPRESET:
        text_cat(b, x < NLPRESET ? LEAD_PRESET_NAME[x] : "CUSTOM");
        break;
    case F_LMODE:
        text_cat(b, x ? "POLY" : "MONO");
        break;
    case F_LCUT:
        hz_text(60.0f * fm_powf(200.0f, u), b);
        break;
    case F_LOCT:
        if (x > 2u)
            text_cat(b, "+");
        int_text((int32_t)x - 2, b + (x > 2u));
        break;
#endif
    case F_ANIM:
        text_cat(b, x ? "LOW" : "NORMAL");
        break;
    case F_CLOCK:
        text_cat(b, x ? "INTERNAL" : "AUTO");
        break;
    case F_XPORT:
        text_cat(b, x ? "TEMPO ONLY" : "FOLLOW");
        break;
    case F_MORPH: {
        static const char *const MO[9] = {"CUT", "1 S", "2 S", "4 S", "8 S", "15 S", "30 S", "60 S", "2:00"};
        text_cat(b, MO[x % 9u]);
        break;
    }
    case F_LOAD:
        text_cat(b, x ? "SND ONLY" : "SND+NOTES");
        break;
    case F_UNDO:
    case F_NEWTAKE:
        text_cat(b, x ? "AGAIN" : "-");   /* (turned twice: it acts, and is back at -) */
        break;
    case F_KB: {
#if FRS_LEAD
        static const char *const KB[4] = {"DRONE", "GLINT", "BASS", "LEAD"};
        text_cat(b, KB[x % 4u]);
#else
        static const char *const KB[3] = {"DRONE", "GLINT", "BASS"};
        text_cat(b, KB[x % 3u]);
#endif
        break;
    }
    case F_SQTYPE: {
        static const char *const TY[3] = {"KEYS", "ARP", "SEQ"};
        text_cat(b, TY[x % 3u]);
        break;
    }
    case F_DMODE:
        text_cat(b, x ? "PING-PONG" : "MONO");
        break;
    case F_GATTACK:
        time_text(0.002f * fm_powf(750.0f, u), b);
        break;
    case F_BMODEL: {
        static const char *const BM[BASS_NMODEL] = {"SINE", "TRIANGLE", "SQUARE", "SAW", "REESE", "SUB", "ORGAN", "FM"};
        text_cat(b, BM[x % BASS_NMODEL]);
        break;
    }
    case F_EQPRESET:
        text_cat(b, EQ_PRESET_NAME[x % (2u + EQ_NPRESET)]);
        break;
    case F_EQDB:                         /* half a decibel a step, 0 at the middle */
        if (x == 24u) {
            text_cat(b, "0 DB");
        } else {
            int32_t h = (int32_t)x - 24;
            text_cat(b, h > 0 ? "+" : "-");
            h = h < 0 ? -h : h;
            int_text(h / 2, b + 1);
            if (h & 1)
                text_cat(b, ".5");
            text_cat(b, " DB");
        }
        break;
    case F_EQLOWF:
        hz_text(EQ_LOWF(u), b);
        break;
    case F_EQMIDF:
        hz_text(EQ_MIDF(u), b);
        break;
    case F_EQHIGHF:
        hz_text(EQ_HIGHF(u), b);
        break;
    case F_EQQ: {
        int32_t q = (int32_t)(EQ_Q(u) * 10.0f + 0.5f);
        int_text(q / 10, b);
        text_cat(b, ".");
        int_text(q % 10, text_end(b));
        break;
    }
    case F_FLTYPE:
        text_cat(b, x == 0u ? "OFF" : x == 1u ? "LOW PASS" : "HIGH PASS");
        break;
    case F_FLCUT:
        hz_text(FL_CUT(u), b);
        break;
    case F_FLTRACKS:
        text_cat(b, FL_TRACKS_NAME[x % 7u]);
        break;
    case F_HZBASS:                       /* BASS's low-pass */
        int_text((int32_t)(40.0f * fm_powf(125.0f, u) + 0.5f), b);
        text_cat(b, " HZ");
        break;
    case F_GLIDE:
        if (2.0f * u * u < 0.002f)
            text_cat(b, "OFF");
        else
            time_text(2.0f * u * u, b);
        break;
    case F_BOCTAVE:
        int_text((int32_t)x - 2, b);
        break;
    case F_BATT:
        time_text(0.005f * fm_powf(1000.0f, u), b);
        break;
    case F_BREL:
        time_text(0.03f * fm_powf(500.0f, u), b);
        break;
    case F_BDEC:
        time_text(0.01f * fm_powf(1000.0f, u), b);
        break;
    case F_BPULSE:
        text_cat(b, PULSE_NAME[x % NPULSE]);
        break;
    case F_ONOFF:
        text_cat(b, x ? "ON" : "OFF");
        break;
    case F_MEDIA:
        text_cat(b, x == 0u ? "OFF" : x == 1u ? "TAPE" : x == 2u ? "VINYL" : x == 3u ? "AM" : "PHONE");
        break;
    case F_PCTOFF:
        if (!x)
            text_cat(b, "OFF");
        else
            int_text((int32_t)((u * 100.0f) + 0.5f), b);
        break;
    case F_ARPMODE: {
        static const char *const AM[5] = {"UP", "DOWN", "UPDOWN", "RANDOM", "DRIFT"};
        text_cat(b, AM[x % 5u]);
        break;
    }
    case F_ARPRATE:
        text_cat(b, ARP_RATE_NAME[x % 10u]);
        break;
    case F_RANGE:
        int_text(x + 1, b);
        text_cat(b, " OCT");
        break;
    case F_BPM:
        int_text(x + 30, b);
        text_cat(b, " BPM");
        break;
    case F_KEYS:
        text_cat(b, x ? "HOLD" : "LATCH");
        break;
    case F_PUMP:
        text_cat(b, PUMP_NAME[x % 7u]);
        break;
    case F_PATT:
        time_text(0.001f * fm_powf(300.0f, u), b);
        break;
    case F_SHAPE:
        if (x == 0)                     /* frasil.c's: the square at the middle, the narrowest pulse at the end */
            text_cat(b, "SAW");
        else if (x == (PD[p].max + 1u) / 2u)
            text_cat(b, "SQUARE");
        else if (x >= PD[p].max)
            text_cat(b, "PULSE");
        else
            int_text((int32_t)((u * 100.0f) + 0.5f), b);
        break;
    case F_CINT: {
        static const char *const IV[4] = {"UNISON", "-12", "+7", "+12"};
        text_cat(b, IV[x % 4u]);
        break;
    }
    case F_BPITCH: {
        static const char *const IV[5] = {"-12", "UNISON", "+12", "+19", "+24"};
        text_cat(b, IV[x % 5u]);
        break;
    }
    case F_HARM: {                       /* the harmonic, a decimal: H1.0 .. H8.0 */
        int32_t h = (int32_t)(fm_exp2f(3.0f * u) * 10.0f + 0.5f);
        char *e;
        text_cat(b, "H");
        int_text(h / 10, b + 1);
        text_cat(b, ".");
        for (e = b; *e; e++)
            ;
        int_text(h % 10, e);
        break;
    }
    case F_CTYPE: {
        static const char *const TY[3] = {"LOW", "BAND", "HIGH"};
        text_cat(b, TY[x % 3u]);
        break;
    }
    case F_LSHAPE:
        text_cat(b, LFO_SHAPE_NAME[x % 7u]);
        break;
    case F_LPOL:
        text_cat(b, LFO_POL_NAME[x % 3u]);
        break;
    case F_LTGT:
        text_cat(b, LFO_TGT_NAME[x % NLFO_TGT]);
        break;
    case F_LRATE:                        /* free: a period (under 1 Hz) or Hz; then the grid's */
        if (x >= LFO_NFREE) {
            text_cat(b, LFO_SYNC_NAME[(x - LFO_NFREE) % 12u]);
        } else {
            float hz = lfo_hz((float)x);
            if (hz >= 1.0f) {
                int32_t d = (int32_t)(hz * 10.0f + 0.5f);
                char *e;
                int_text(d / 10, b);
                text_cat(b, ".");
                for (e = b; *e; e++)
                    ;
                int_text(d % 10, e);
                text_cat(b, " HZ");
            } else {
                time_text(1.0f / hz, b);
            }
        }
        break;
    case F_DPRESET:
        text_cat(b, DRONE_NAME[x % (NDPRESET + 1u)]);
        break;
    case F_SQLEN:
        int_text(x + 1, b);
        break;
    case F_SQNOTE:                       /* REST, TIE, or the note with GLINT's OCTAVE on it (TRANSPOSE aside; C4: 60) */
        if (x == 0)
            text_cat(b, "REST");
        else if (x >= 127u)
            text_cat(b, "TIE");
        else {
            char *e;
            int32_t n = (int32_t)x + seq_shift;
            n = n > 127 ? 127 : n;
            text_cat(b, NOTE_NAME[n % 12]);
            for (e = b; *e; e++)
                ;
            int_text(n / 12 - 1, e);
        }
        break;
    case F_BQNOTE:                       /* CUT, HOLD, or the note with BASS's OCTAVE on it, as it sounds (TRANSPOSE
                                          * aside) */
        if (x == 0)
            text_cat(b, "CUT");
        else if (x >= 127u)
            text_cat(b, "HOLD");
        else {
            char *e;
            int32_t n = (int32_t)x + bseq_shift;
            while (n < 24)
                n += 12;
            n = n > 127 ? 127 : n;
            text_cat(b, NOTE_NAME[n % 12]);
            for (e = b; *e; e++)
                ;
            int_text(n / 12 - 1, e);
        }
        break;
    case F_BQLEN:
        text_cat(b, BQ_LEN_NAME[x % NBQLEN]);
        break;
    case F_BQNLEN:                       /* steps (0: no note on STEP) */
        if (!x) {
            text_cat(b, "-");
        } else {
            int_text(x, b);
            text_cat(b, x == 1u ? " STEP" : " STEPS");
        }
        break;
    case F_DQNOTES:                      /* REST, TIE, or the step's notes: one, its name; more, how many */
        if (x == 0)
            text_cat(b, "REST");
        else if (x >= 2u)
            text_cat(b, "TIE");
        else if (dq_view_n == 1u) {
            char *e;
            text_cat(b, NOTE_NAME[dq_view_note % 12u]);
            for (e = b; *e; e++)
                ;
            int_text((int32_t)(dq_view_note / 12u) - 1, e);
        } else if (!dq_view_n) {         /* (no step before it: the schema's word) */
            text_cat(b, "NOTES");
        } else {
            int_text(dq_view_n, b);
            text_cat(b, " NOTES");
        }
        break;
    case F_KNOTES:
        text_cat(b, x ? "CHORD" : "SINGLE NOTE");
        break;
    case F_METRO: {
        static const char *const MT[3] = {"OFF", "REC", "ALWAYS"};
        text_cat(b, MT[x % 3u]);
        break;
    }
    case F_COUNTIN:
        text_cat(b, x ? "1 BAR" : "OFF");
        break;
    case F_ARPSNAP: {
        static const char *const SN[6] = {"OFF", "1/16", "1/8", "1/4", "1/2", "1 BAR"};
        text_cat(b, SN[x % 6u]);
        break;
    }
    case F_SQREC: {
        static const char *const RC[3] = {"OFF", "STEP", "LIVE"};
        text_cat(b, RC[x % 3u]);
        break;
    }
    case F_SQCLEAR: {
        static const char *const CL[3] = {"-", "AGAIN", "CLEARED"};
        text_cat(b, CL[x % 3u]);
        break;
    }
    case F_SQTRANS:                      /* steps of the scale, around 0 */
        if (x > 14u)
            text_cat(b, "+");
        int_text((int32_t)x - 14, b + (x > 14u));
        break;
    case F_SIGNED:                       /* around the middle: 0 there */
        if (x > 64u)
            text_cat(b, "+");
        int_text((int32_t)x - 64, b + (x > 64u));
        break;
    case F_THRESH:
        int_text((int32_t)x - 40, b);
        text_cat(b, " DB");
        break;
    case F_CRATIO:
        text_cat(b, COMP_RATIO_NAME[x % 8u]);
        break;
    case F_CREL:
        time_text(0.03f * fm_powf(50.0f, u), b);
        break;
    case F_DBGAIN:
        text_cat(b, "+");
        int_text(x, b + 1);
        text_cat(b, " DB");
        break;
    case F_LEVEL:
        int_text(x, b);
        break;
    case F_TRKCH:
        if (x == 0)
            text_cat(b, "OFF");
        else if (x > 16u)
            text_cat(b, "OMNI");
        else
            int_text(x, b);
        break;
    case F_CHANNEL:
        if (x == 0)
            text_cat(b, "OMNI");
        else
            int_text(x, b);
        break;
    default:
        int_text((int32_t)((u * 100.0f) + 0.5f), b);
        break;
    }
}
