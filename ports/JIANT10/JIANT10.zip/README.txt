JIANT FM 10 10.8.42 for the BBL Mod Swapper

Original by juanjiant-bit: https://github.com/juanjiant-bit/JIANT
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: JIANT10-source.zip on the ports page.
