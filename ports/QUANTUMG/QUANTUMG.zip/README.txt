Quantum GammaWave 2.3.16 for the BBL Mod Swapper

Original by Guillel51: https://github.com/Guillel51/Quantum-GammaWave
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: QUANTUMG-source.zip on the ports page.
