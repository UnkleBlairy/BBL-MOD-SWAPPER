/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Shared DSP building blocks for the Felucca engines (all fixed point).
 * Voice output convention: add sample * amp to out[], where a full-scale
 * oscillator at amp = 1.0 (Q15 32767) contributes VOICE_FS. */
#define VOICE_FS 24000           /* per-voice level: one voice peaks near -6 dBFS before the master */

static inline int32_t mulq15(int32_t a, int32_t b) { return (a * b) >> 15; }
/* (F5) THE DC BLOCKER'S POLE, WRITTEN SO IT CANNOT OVERFLOW. Both additive engines filter with
 * ((v * 32744) + 16384) >> 15. The constant is 0.9994 in Q15 and the expression is fine for a normal sample,
 * but the intermediate is not bounded by the sample: 96 000 (a post-filter voice peak) times 32 744 already
 * passes 2^31, and the ASan/UBSan fuzz run reached it (signed integer overflow, eng_additive.c:197, seed 17).
 * v * 32768 is an exact multiple of 32768, so the sum splits without loss: v + ((16384 - 24v) >> 15). Every
 * in-range result is bit-identical to the old expression (checked over every 7th value of the whole range) and
 * the product is 4096x smaller. The clamp only catches a state no sample path produces (a fuzzed scene, a bad
 * restore). */
static inline int32_t dc_pole(int32_t v)
{
    if (v > 1048575) v = 1048575; else if (v < -1048575) v = -1048575;
    return v + ((16384 - v * 24) >> 15);
}
/* a * k / 65536 without 64-bit: a up to 2^31, k Q16 */
static inline __attribute__((always_inline)) int32_t mulq16(int32_t a, uint32_t k)
{
    return (int32_t)(((a >> 16) * (int32_t)k) + (int32_t)(((uint32_t)(a & 0xFFFF) * k) >> 16));
}
static inline int32_t clamp(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }
/* the same, bounded +-k and in one unsigned compare: v outside +-k is exactly
 * (unsigned)v + k > 2k (no overflow: unsigned wraps, and the sum is 0..2k inside the range),
 * and only then does the sign choose the bound. Also used by the SVF's two state clamps. */
static inline int32_t clamp_sym(int32_t v, int32_t k)
{
    return (uint32_t)v + (uint32_t)k > (uint32_t)(2 * k) ? (v < 0 ? -k : k) : v;
}

/* (ETAPA 2) the sine, rebuilt here instead of stored: the app slot keeps SINE_D2, the 1 025 points' second
 * differences as int8 (1 025 B, was 2 050 B of the one resource this firmware runs out of first), and this turns
 * them back into the exact same integers with adds. It lives in .bss and every caller below reads it as before,
 * so a lookup is a RAM read instead of an XIP one. Same arrangement as WT_GEN and FM6's exp2 curve. */
int16_t SINE[SINE_N];
void sine_init(void)
{
    int32_t i, v = SINE_V0, d = SINE_D1;
    SINE[0] = (int16_t)v;
    for (i = 1; i < (int32_t)SINE_N; i++) {
        v += d;
        SINE[i] = (int16_t)v;
        if (i <= (int32_t)SINE_D2_N) d += SINE_D2[i - 1];   /* the step's own change, the next one */
    }
}
/* sine, linearly interpolated between the 1024 table points (plain lookup: THD -55 dB) */
static inline __attribute__((always_inline)) int32_t sine_i(uint32_t ph)
{
    uint32_t i = ph >> 22;
    int32_t a = SINE[i], b = SINE[(i + 1u) & 1023u];
    return a + (((b - a) * (int32_t)((ph >> 7) & 0x7FFFu)) >> 15);
}
static inline int32_t osc_sine(uint32_t ph) { return sine_i(ph); }

/* polyBLEP residual (Q15) around a wrap of a phase accumulator */
static inline int32_t blep(uint32_t ph, uint32_t inc)
{
    if (ph >= inc && ph <= ~inc)
        return 0;
    uint32_t d = inc >> 15;
    if (!d)
        return 0;
    if (ph < inc) {
        int32_t x = (int32_t)(ph / d);                       /* 0..32767 */
        return x + x - ((x * x) >> 15) - 32768;
    }
    {
        int32_t x = -(int32_t)((0xFFFFFFFFu - ph) / d);       /* -32767..0 */
        return ((x * x) >> 15) + x + x + 32768;
    }
}

static inline int32_t osc_saw(uint32_t ph, uint32_t inc)
{
    return ((int32_t)(ph >> 16) - 32768) - blep(ph, inc);
}

static inline int32_t osc_pulse(uint32_t ph, uint32_t inc, uint32_t pw)
{
    return (osc_saw(ph, inc) - osc_saw(ph + pw, inc)) >> 1;
}

static inline int32_t osc_tri(uint32_t ph)
{
    int32_t s = (int32_t)(ph >> 15);                 /* 0..131071 */
    return s < 65536 ? s - 32768 : 98303 - s;
}

/* tanh(x / 32768) * 32767, linearly interpolated (a plain lookup gives
 * 256-unit steps, audible on quiet signals) */
static inline __attribute__((always_inline)) int32_t softclip(int32_t x)
{
    int32_t a = x < 0 ? -x : x, i = a >> 8, y;
    if (i >= 256)
        y = TANH_Q15[256];                           /* continuous with the table */
    else
        y = TANH_Q15[i] + (((TANH_Q15[i + 1] - TANH_Q15[i]) * (a & 255)) >> 8);
    return x < 0 ? -y : y;
}

/* xorshift32 */
static inline __attribute__((always_inline)) uint32_t noise32(int32_t *st)
{
    uint32_t s = (uint32_t)*st;
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    *st = (int32_t)s;
    return s;
}

/* Trapezoidal SVF (A. Simper), unconditionally stable. Coefficients per
 * block in Q13; signals stay within +-150000 so products fit in 32 bits. */
typedef struct { int32_t a1, a2, a3; } tsvf_t;
static inline __attribute__((always_inline)) void tsvf_coef_k(tsvf_t *c, int32_t cut, int32_t k)   /* cut: 0..127 << 8, k: damping Q12 */
{
    int32_t i, g, den;
    cut = clamp(cut, 0, 127 << 8);
    i = cut >> 8;
    g = SVF_G[i];
    if (i < 127)                                       /* between table points: sweeps without 128 steps */
        g += ((SVF_G[i + 1] - g) * (cut & 255)) >> 8;
    den = 4096 + ((g * (g + k)) >> 12);
    c->a1 = (int32_t)((4096u << 13) / (uint32_t)den);
    c->a2 = (c->a1 * g) >> 12;
    c->a3 = (c->a2 * g) >> 12;
}
static inline void tsvf_coef(tsvf_t *c, int32_t cut, int32_t reso)   /* reso 0..127: damping 2.0 .. ~0.15 */
{
    tsvf_coef_k(c, cut, 8192 - reso * 7600 / 127);
}

static inline int32_t tsvf_lp(const tsvf_t *c, int32_t in, int32_t *ic1, int32_t *ic2)
{
    int32_t v3 = in - *ic2;
    int32_t v1 = (c->a1 * *ic1 + c->a2 * v3) >> 13;
    int32_t v2 = *ic2 + ((c->a2 * *ic1 + c->a3 * v3) >> 13);
    *ic1 = clamp_sym(2 * v1 - *ic1, 150000);
    *ic2 = clamp_sym(2 * v2 - *ic2, 150000);
    return v2;
}

/* amplitude ramp over the block. Blocks are always CTL long, so x / CTL is a
 * shift (rounded towards zero, as a division); the compiler at -Os keeps
 * even constant divisions as a hardware divide, once per sample and voice */
#define CTL_LOG2 5
#if (1 << CTL_LOG2) != CTL
#error "CTL_LOG2 does not match CTL"
#endif
static inline int32_t amp_at(const vmod_t *m, uint32_t i)
{
    int32_t x = (m->amp1 - m->amp0) * (int32_t)i;
    return m->amp0 + ((x + ((x >> 31) & (CTL - 1))) >> CTL_LOG2);
}

/* a voice's sample s (Q15) at the amplitude ramp's sample i, scaled to the voice level (VOICE_FS);
 * engines whose signal peaks near half scale add it << 1 */
static inline int32_t voice_amp(int32_t s, const vmod_t *m, uint32_t i)
{
    return mulq15(mulq15(s, amp_at(m, i)), VOICE_FS);
}

/* linear up to k, then a soft knee: only the peaks above k saturate (|y| - k must stay < 2^30) */
static inline int32_t soft_knee(int32_t y, int32_t k)
{
    int32_t a = y < 0 ? -y : y;
    if (a <= k)
        return y;
    a = k + (softclip((a - k) * 2) >> 1);
    return y < 0 ? -a : a;
}

/* phase increment of pitch16 (1/16 semitone) plus ct cents: whole 1/16 semitones from the table,
 * the rest (and fine, in 1/4096) as a factor (1 ct = 2.367 / 4096) */
static inline uint32_t cents_inc(int32_t pitch16, int32_t ct, int32_t fine)
{
    int32_t d16, rem;
    ct += tune_cents(pitch16);            /* (FASE 7) the note's own temperament, then the detune on top */
    d16 = ct * 16 / 100;
    rem = ct * 16 - d16 * 100;            /* rem: 1/1600 semitone */
    uint32_t inc = pitch_inc(clamp(pitch16 + d16, 0, 2047));
    return inc + (uint32_t)((int32_t)(inc >> 12) * (rem * 2367 / 16000 + fine));
}
