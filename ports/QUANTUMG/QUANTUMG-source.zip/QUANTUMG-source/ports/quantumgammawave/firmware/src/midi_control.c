/* SPDX-License-Identifier: GPL-3.0-only
 * Adapted from MIDI control contribution by ChanceTheMaker (2026).
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Shared USB/TRS channel controls. Included by seq.c after its input helpers.
 * USB and TRS intentionally share channel state, matching the existing routing.
 * A synth part has one live bend/wheel state; channels assigned to the same part
 * share it (last controller wins). Drum hits ignore bend and sustain. CC1 keeps the existing matrix routing. */
typedef struct {
    int16_t bend;                           /* signed 14-bit value, zero = centre */
    uint8_t wheel, pedal, targets;
    uint8_t owned[NTRK];                    /* held/pedal notes per track, at most 128 per channel */
    uint8_t ready, semis, cents;
    uint8_t rpn_msb, rpn_lsb;
} midi_channel_t;
static midi_channel_t midi_ch[16];
/* A nibble per note (JIANT: two to a byte, 1 KB): low bits track + 1, bit 3 key released, held by its channel's pedal */
static uint8_t midi_sel_on[16][64];
static uint32_t mn_get(uint32_t ch, uint32_t note) { return (midi_sel_on[ch & 15u][(note & 127u) >> 1] >> ((note & 1u) * 4u)) & 15u; }
static void mn_set(uint32_t ch, uint32_t note, uint32_t v)
{
    uint8_t *b = &midi_sel_on[ch & 15u][(note & 127u) >> 1];
    uint32_t sh = (note & 1u) * 4u;
    *b = (uint8_t)((*b & ~(15u << sh)) | (v & 15u) << sh);
}
static uint16_t midi_owners[NTRK];           /* avoids rescanning all 2048 entries for CC123 */
#define MIDI_PEDAL_NOTE 0x8u

static midi_channel_t *midi_channel(uint32_t ch)
{
    midi_channel_t *c = &midi_ch[ch];
    if (!c->ready) {
        c->semis = 2;
        c->rpn_msb = c->rpn_lsb = 127;
        c->ready = 1;
    }
    return c;
}

static uint32_t midi_targets(uint32_t ch)
{
    return midi_channel(ch)->targets | (1u << trk_index(midi_track(ch)));
}

static void midi_expression(track_t *t, const midi_channel_t *c)
{
    int32_t range = ((int32_t)c->semis * 100 + c->cents) * 256 / 100;
    if (drum_track(t))
        return;
    midi_bend_target[trk_index(t)] = (int32_t)c->bend * range / (c->bend < 0 ? 8192 : 8191);
}

static void midi_expression_channel(uint32_t ch)
{
    uint32_t i, mask = midi_targets(ch);
    for (i = 0; i < NPART; i++)
        if (mask & (1u << i))
            midi_expression(&trk[i], midi_channel(ch));
}

/* a MIDI note of track t sounds note */
static int midi_note_held(const track_t *t, uint32_t note)
{
    uint32_t ch, id = trk_index(t) + 1u;
    for (ch = 0; ch < 16u; ch++)
        if ((mn_get(ch, note) & 0x7u) == id)
            return 1;
    return 0;
}

/* a key held on track t sounds note */
static int midi_local_held(const track_t *t, uint32_t note)
{
    uint32_t k;
    for (k = 0; k < 27u; k++)
        if (kb_on[k] && kb_trk[k] == trk_index(t)) {   /* (0.6.81: a key's chord, the notes started) */
            uint32_t i;
            for (i = 0; i < kb_on[k]; i++)
                if (kb_snd[k][i] == note)
                    return 1;
        }
    return 0;
}

static void midi_release(uint32_t ch, uint32_t note)
{
    uint32_t id = mn_get(ch, note) & 0x7u;
    mn_set(ch, note, 0);
    if (id) {
        midi_owners[id - 1u]--;
        if (!--midi_ch[ch].owned[id - 1u])
            midi_ch[ch].targets &= (uint8_t)~(1u << (id - 1u));
    }
    if (id && !midi_local_held(&trk[id - 1u], note))
        input_off(&trk[id - 1u], note);           /* input_off also checks other MIDI owners */
}

/* a MIDI note-on (ch, note) of track t. A note another key or MIDI note holds already sounds: not started again */
static void midi_play(track_t *t, uint32_t ch, uint32_t note, uint32_t vel)
{
    (void)ch;
    if (!midi_note_held(t, note) && !midi_local_held(t, note))
        input_on(t, note, vel);
}

static void midi_note_event(uint32_t ch, uint32_t note, uint32_t vel)
{
    midi_channel_t *c = midi_channel(ch);
    uint32_t id = mn_get(ch, note) & 0x7u;
    if (vel) {
        track_t *t = midi_track(ch);
        /* Repeated notes replace the previous press, including a pedal-held one. */
        if (id)
            midi_release(ch, note);
        midi_expression(t, c);
        if (t != TSEL)
            midi_hint = (uint8_t)(trk_index(t) + 1u);
        c->targets |= (uint8_t)(1u << trk_index(t));
        midi_play(t, ch, note, vel);
        mn_set(ch, note, (uint8_t)(trk_index(t) + 1u));
        midi_owners[trk_index(t)]++;
        c->owned[trk_index(t)]++;
    } else if (id) {
        if (c->pedal && !drum_track(&trk[id - 1u]))
            mn_set(ch, note, mn_get(ch, note) | MIDI_PEDAL_NOTE);
        else
            midi_release(ch, note);
    }
}

static void midi_pedal_up(uint32_t ch)
{
    uint32_t note;
    midi_channel(ch)->pedal = 0;
    for (note = 0; note < 128u; note++)
        if (mn_get(ch, note) & MIDI_PEDAL_NOTE)
            midi_release(ch, note);
}

/* Preset/project panic and CC120 must discard ownership so a later pedal-up
 * or note-off cannot release notes subsequently started on another patch. */
static void __attribute__((noinline)) midi_forget_track(uint32_t track)
{
    uint32_t ch, note;
    for (ch = 0; ch < 16u; ch++) {
        if (!(midi_ch[ch].targets & (1u << track)))
            continue;
        for (note = 0; note < 128u; note++)
            if ((mn_get(ch, note) & 0x7u) == track + 1u)
                mn_set(ch, note, 0);
        midi_ch[ch].targets &= (uint8_t)~(1u << track);
        midi_ch[ch].owned[track] = 0;
    }
    midi_owners[track] = 0;
    midi_bend_q8[track] = midi_bend_target[track] = 0;
}

static void midi_silence_track(uint32_t track)
{
    track_t *t = &trk[track];
    uint32_t i;
    trk_all_off(t);
    t->nheld = t->arp_phys = t->rh_n = 0;
    arp_forget(t);
    t->seq_n = t->seq_hold = t->slide_glide = 0;
    for (i = 0; i < NVOICE; i++)
        if (V(t, i).active)
            voice_kill(&V(t, i));             /* one-block fade, regardless of RELEASE */
    slicer_drop();                            /* do not keep replaying captured sound (the SLICER's bus) */
    midi_forget_track(track);
}

static int midi_track_held(uint32_t track)
{
    uint32_t k;
    if (midi_owners[track])
        return 1;
    for (k = 0; k < 27u; k++)
        if ((fm1_in.notes & (1u << k)) && kb_trk[k] == track)
            return 1;
    return 0;
}

/* The standard CC map (#103): always on, these CCs only, on the track the channel plays (ROUT as notes). A CC
 * sets its parameter as a knob would, 0..127 over the parameter's range (64: the middle of a bipolar one), and
 * AUTOMATION records it as a knob move (motion_capture: the selected track, armed and playing). CC74 / CC71 are
 * the engine's own brightness / resonance (MIDI_CC_ENG); an engine without one ignores them. CC121 resets none
 * of them (RP-015: they are the sound's) */
#define MCC_CUT 0xFEu
#define MCC_RES 0xFFu
static const uint8_t MIDI_CC_MAP[][2] = {
    {5, P_GLIDE}, {7, P_LEVEL}, {10, P_PAN}, {71, MCC_RES}, {72, P_REL}, {73, P_ATK}, {74, MCC_CUT}, {75, P_DEC}, {76, P_HARM}, {77, P_LSHP},
    {91, P_REV}, {93, P_CHOR}, {94, P_DLY},
};
/* per engine (ENGINES[] order): CC74's E index + 1 in the high nibble, CC71's in the low one, 0 = none */
static const uint8_t MIDI_CC_ENG[NENGINES] = {
    0x56, 0x00, 0x30, 0x80, 0x50, 0x07, 0x67, 0x00,   /* ANALOG CUT RES, -, PHASE DCW, LOFI TONE, SAMPLE CUT, VOICE Q,
                                                       * TRIO CUT RES, WHEEL - */
    0x80, 0x30, 0x30, 0x34, 0x30,                     /* GRAIN TONE, PHYS BRIT, DRUM TONE, NOISE FREQ RES, FM6 MLVL */
    0x80,                                             /* SLICE TONE (retired: ANALOG's played) */
};
/* (1.9.2) MIDI Learn, kept across a power cycle. CC 119 arms a parameter of the channel's track (its value is the
 * parameter id) and CC 111 one of the macros (0..3 = M1..M4); the next CC binds to it and moves it. CC 118 forgets the
 * whole map, the settings keep it. The map is eight bindings of two bytes in favorites.factory[15][0..15], bytes no
 * engine uses and 0 in every older settings record: an old record simply has no map, so no format moves and nothing
 * is migrated. A binding that names a parameter its engine does not have is ignored (a corrupted byte reaches no
 * voice), and no project, user preset or factory sound is touched. */
#define MIDI_LEARN_MAX 8u
static uint8_t midi_learn_arm;
#define MIDI_MAP midi_learn_map                      /* (core.h) cc + 1 (0 = empty), then the parameter id */
static void midi_map_keep(void) { midi_map_req = 1u; }   /* project.c: the settings write, transport stopped */
static uint32_t midi_find(uint32_t cc)
{
    uint32_t i;
    for (i = 0; i < MIDI_LEARN_MAX; i++)
        if (MIDI_MAP[2u * i] == cc + 1u)
            return MIDI_MAP[2u * i + 1u];
    return 0xFFFFu;
}
static void midi_learn_reset(void)                   /* (CC 118) no binding at all */
{
    memset(MIDI_MAP, 0, 2u * MIDI_LEARN_MAX);
    midi_map_msg = 4u;
    midi_map_cc = 0;
    midi_map_keep();
}
static void midi_learn_bind(uint32_t cc, uint32_t param)
{
    uint32_t i, slot = MIDI_LEARN_MAX;
    midi_map_msg = 1u;                               /* BOUND */
    midi_map_cc = (uint8_t)cc;
    for (i = 0; i < MIDI_LEARN_MAX; i++)
        if (MIDI_MAP[2u * i] == cc + 1u) {            /* the CC was another parameter's: it is this one's now */
            slot = i;
            midi_map_msg = 2u;                       /* TAKEN */
            break;
        }
    for (i = 0; slot == MIDI_LEARN_MAX && i < MIDI_LEARN_MAX; i++)
        if (!MIDI_MAP[2u * i])
            slot = i;
    if (slot == MIDI_LEARN_MAX) {
        midi_map_msg = 3u;                           /* NO ROOM: nothing changes, nothing is saved */
        return;
    }
    MIDI_MAP[2u * slot] = (uint8_t)(cc + 1u);
    MIDI_MAP[2u * slot + 1u] = (uint8_t)param;
    midi_map_keep();
}
static uint32_t midi_std(uint32_t cc)                /* the parameter the standard map already gives this CC */
{
    uint32_t i;
    for (i = 0; i < NELEM(MIDI_CC_MAP); i++)
        if (MIDI_CC_MAP[i][0] == cc)
            return MIDI_CC_MAP[i][1];
    return cc == 1u || cc == 64u ? 0u : 0xFFFFu;     /* (the wheel and the pedal are the channel's own) */
}
static void __attribute__((noinline)) midi_cc_map(track_t *t, uint32_t cc, uint32_t value)
{
    const param_desc_t *d;
    uint32_t i, id = midi_find(cc), e;
    int32_t v;
    if (id != 0xFFFFu && !IS_MAC_ID(id) && (id >= P_COUNT || !param_desc_of(eng_idx(t->eng_req), id)))
        return;                                      /* a byte that names nothing on this engine: never applied */
    if (id == 0xFFFFu)
        id = midi_std(cc);
    if (id >= G_MAC1 && id <= G_MAC4) {              /* (1.9.2) a learned macro: M1..M4, 0..127 as its page turns it */
        macro_set(id - G_MAC1, (int32_t)value);
        return;
    }
    if (id >= MCC_CUT) {
        if (id == 0xFFFFu)
            return;
        e = MIDI_CC_ENG[eng_idx(t->eng_req)] >> (id == MCC_CUT ? 4 : 0) & 15u;
        if (!e)
            return;
        id = P_E0 + e - 1u;
    }
    d = param_desc_of(eng_idx(t->eng_req), id);
    if (!d)
        return;
    v = d->min + ((int32_t)value * (d->max - d->min) + 63) / 127;
    if (d->max <= d->min || t->p[id] == v)
        return;
    t->p[id] = (int16_t)v;
    (void)motion_capture(t, id, (int16_t)v);
}

static void midi_control(uint32_t ch, uint32_t cc, uint32_t value)
{
    midi_channel_t *c = midi_channel(ch);
    uint32_t i, mask;
    switch (cc) {
    case 1:
        c->wheel = (uint8_t)value;
        break;
    case 120:                                      /* All Sound Off: ignores the pedal */
        mask = midi_targets(ch);
        for (i = 0; i < NTRK; i++)
            if (mask & (1u << i))
                midi_silence_track(i);
        break;
    case 123:                                      /* All Notes Off: normal releases, honours pedal */
        mask = midi_targets(ch);
        for (i = 0; i < 128u; i++)
            if (mn_get(ch, i))
                midi_note_event(ch, i, 0);
        for (i = 0; i < NTRK; i++)
            if ((mask & (1u << i)) && !midi_track_held(i)) {
                trk_all_off(&trk[i]);
                trk[i].nheld = trk[i].arp_phys = trk[i].rh_n = 0;
                arp_forget(&trk[i]);
            }
        break;
    case 121:                                      /* Reset All Controllers, keep bend sensitivity */
        c->bend = 0;
        c->wheel = 0;
        c->rpn_msb = c->rpn_lsb = 127;
        midi_expression_channel(ch);
        midi_pedal_up(ch);
        break;
    case 64:
        if (value >= 64u)
            c->pedal = 1;
        else
            midi_pedal_up(ch);
        break;
    case 101: c->rpn_msb = (uint8_t)value; break;
    case 100: c->rpn_lsb = (uint8_t)value; break;
    case 99: case 98:                              /* NRPN selection cancels RPN data entry */
        c->rpn_msb = c->rpn_lsb = 127;
        break;
    case 6: case 38:
        if (!c->rpn_msb && !c->rpn_lsb) {           /* RPN 0: +/-0..24 semitones, 0..99 cents */
            if (cc == 6u)
                c->semis = (uint8_t)(value > 24u ? 24u : value);
            else
                c->cents = (uint8_t)(value > 99u ? 99u : value);
            midi_expression_channel(ch);
        }
        break;
    case 78:                                       /* (v1.8.5) QUANTUM MORPH: the position between A and B,
                                                    * 0..127, through the page's own slew (nothing bigger than
                                                    * one step of 127 reaches the engines). The morph is one,
                                                    * of the selected track, so every channel moves it */
        msc_midi_pos((int32_t)value);
        break;
    case 79:                                       /* .. and an end taken from this channel's track */
        if (value >= 64u)
            msc_midi_store(0, midi_track(ch));
        break;
    case 80:
        if (value >= 64u)
            msc_midi_store(1, midi_track(ch));
        break;
    case 118:                                      /* (1.7) MIDI Learn: forget every binding (117 puts it back) */
        midi_learn_reset();
        break;
    case 119:                                      /* (1.7) MIDI Learn: arm the parameter the value names */
        if (value < P_COUNT && param_desc_of(eng_idx(midi_track(ch)->eng_req), value))
            midi_learn_arm = (uint8_t)(value + 1u);
        break;
    case 111:                                      /* (1.9.2) arm a macro: 0..3 is M1..M4 */
        if (value < 4u)
            midi_learn_arm = (uint8_t)(G_MAC1 + value + 1u);
        break;
    default:
        if (midi_learn_arm) {                      /* (1.7) the next CC becomes its controller */
            uint32_t param = midi_learn_arm - 1u;
            midi_learn_arm = 0;
            midi_learn_bind(cc, param);
        }
        midi_cc_map(midi_track(ch), cc, value);
        break;
    }
}

/* ROUT CH1-4 listens to channels 1..4 only. A switch to it from SEL (events_block, before the queue) lets go
 * of what channels 5..16 hold: their notes released (also pedal-held ones), their pedal, bend, wheel and RPN
 * selection reset, so no note can hang on a channel that is no longer heard. Each part's bend then follows
 * its own channel (1..4), as CH1-4 routes it. */
static void __attribute__((noinline)) midi_route_ch14(void)
{
    uint32_t ch, note;
    for (ch = NPART; ch < 16u; ch++) {
        midi_channel_t *c = midi_channel(ch);
        for (note = 0; note < 128u; note++)
            if (mn_get(ch, note))
                midi_release(ch, note);
        c->pedal = c->wheel = 0;
        c->bend = 0;
        c->rpn_msb = c->rpn_lsb = 127;
    }
    for (ch = 0; ch < NPART; ch++)
        midi_expression(&trk[ch], midi_channel(ch));
}

/* (JIANT 0.6.72) PROGRAM CHANGE n on the channel a track plays: the n + 1-th sound of the PRESETS list (every engine's
 * presets in their order, then the user presets; the favourites filter aside), loaded by the UI between frames (a
 * sound load is the main loop's: ui.c midi_pc_poll). 0 none, else n + 1 */
static volatile uint8_t midi_pc_req[NTRK];
/* (JIANT 0.6.80) PROGRAM CHANGE on channel 16, the song's own (never a track's, whatever ROUTE): 0..3 the section A..D
 * (in on the next bar, as the song layer's keys), 16..23 the project 1..8 (stopped only, as SAVE > PROJECT). The UI
 * takes it between frames (ui.c midi_pc_poll). 0 none, else n + 1 */
static volatile uint8_t midi_song_req;

/* Keep the occasional controller/panic dispatch outside the hot rendering loop. Channel voice messages only
 * (realtime and clock are handled in events_block, SysEx never reaches here). With ROUT CH1-4 channels
 * 5..16 are ignored entirely: notes, bend, CCs (CC1/11/64, RPN, and the CC120/121/123 panic and reset),
 * channel aftertouch, so they stay free for other instruments. */
static void __attribute__((noinline)) midi_event(uint32_t st, uint32_t ch, uint32_t d1, uint32_t d2)
{
    if (st == 0xC0u && ch == 15u) {                    /* (0.6.80) channel 16's PROGRAM CHANGE: a section, a project */
        midi_song_req = (uint8_t)(d1 + 1u);
        return;
    }
    if (ch >= NPART && !song.g[G_ROUTE])
        return;
    if (st == 0x90u || st == 0x80u)
        midi_note_event(ch, d1, st == 0x90u ? d2 : 0);
    else if (st == 0xE0u) {
        midi_channel(ch)->bend = (int16_t)((int32_t)(d1 | (d2 << 7)) - 8192);
        midi_expression_channel(ch);
    } else if (st == 0xB0u) {
        mod_midi(midi_track(ch), st, d1, d2);
        midi_control(ch, d1, d2);
    } else if (st == 0xD0u)
        mod_midi(midi_track(ch), st, d1, d2);
    else if (st == 0xA0u)                              /* (QG-1 1.6) polyphonic aftertouch: per key, external MIDI */
        mod_pat(midi_track(ch), d1, d2);
    else if (st == 0xC0u)                          /* (0.6.72) PROGRAM CHANGE: the UI loads it (ui.c midi_pc_poll) */
        midi_pc_req[trk_index(midi_track(ch)) % NTRK] = (uint8_t)(d1 + 1u);
}
