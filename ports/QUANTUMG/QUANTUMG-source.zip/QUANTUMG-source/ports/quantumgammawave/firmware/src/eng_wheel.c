/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* WHEEL: a tonewheel-style additive organ. Felucca's own design.
 *
 * Partials: nine sines per voice at the classic drawbar footages, 16' 5 1/3' 8' 4' 2 2/3' 2'
 * 1 3/5' 1 1/3' 1' (0.5, 1.5, 1, 2, 3, 4, 5, 6, 8 times the note), each with a level 0..8
 * (about 3 dB a step). One shared sine table (plain lookup), one free-running integer phase
 * per partial: a note starts wherever its wheels are, as on the real generators. A partial
 * above ~6 kHz folds back an octave (as the top of a tonewheel set does), so nothing aliases.
 * Partials at level 0 are skipped (their phase still runs).
 *
 * Registration: 8 knobs cannot hold 9 drawbars, so REG picks one of 16 drawbar settings
 * (DRW_REG: our list of common registrations) and SUB / BODY / TOP add -8..+8 to its sub
 * bars (16', 5 1/3'), its body (8', 4') and its upper bars (2 2/3' .. 1'). The louder the
 * registration, the less each bar gets (a soft normalisation: full bars are louder than one
 * bar, but they do not stack up to clipping).
 *
 * PERC: a decaying partial on the 2nd (4') or 3rd (2 2/3') harmonic, normal or soft, fast
 * or slow. Single trigger: it only strikes on a note that starts while no other key of the
 * part is held (legato playing gets none). With PERC on the 1' bar is silent and, at normal
 * level, the bars drop by ~3 dB, as on the real circuit.
 * CLICK: a short burst of high-passed noise at the key contact (half as loud at the release).
 * DRIVE: a per-voice soft overdrive (tanh); for chord growl add the track's DIST.
 * ROTR: a cheap rotary speaker effect: two rotors (a low one and a high one, split by partial
 * frequency at ~800 Hz) that spin SLOW or FAST and ramp between the speeds (the high rotor in
 * ~1 s, the low one in ~4 s); each gives its partials an amplitude and a pitch (Doppler)
 * modulation whose depth follows its speed. All of it is folded into the per-block partial
 * gains and increments: no delay line, no per-sample cost. OFF fades it out and stops them.
 *
 * Envelope: an organ gate (the presets set A 0, S 127, a short R); the track ADSR still applies.
 * Cost: per sample and partial one table lookup and a multiply-add (a gain ramp only for the
 * partials whose gain moved: percussion, rotary, knobs); the bar levels, the rotor and the
 * percussion run once per block. State: the per-track rotor and bar gains (drw_trk) and the
 * per-voice phases / gains (drw_vc) live here, indexed by part and voice; voice_t is unused. */
#define DRW_NP 9                 /* partials */
#define DRW_FOLD 584366000u      /* ~6 kHz as a phase increment: partials above fold down an octave */
#define DRW_XOVER 77915000u      /* ~800 Hz: below the low rotor, above the high rotor */

/* drawbar level 0..8 -> Q15, 3 dB a step */
static const uint16_t DRW_LV[9] = {0, 2920, 4125, 5827, 8231, 11627, 16423, 23198, 32767};

/* the 16 registrations, one digit per bar: 16' 5 1/3' 8' 4' 2 2/3' 2' 1 3/5' 1 1/3' 1' */
static const char *const N_DRW_REG[] = {"FLUTE", "MELLO", "HOLLW", "SMOOT", "3BAR", "BLUES", "GOSPL", "ROCK",
                                        "TOPS", "CLARI", "REED", "STRNG", "CHAPL", "BRITE", "BASS", "FULL"};
static const char DRW_REG[16][DRW_NP + 1] = {
    "008000000", /* FLUTE  one soft flute */
    "008400000", /* MELLO  flute and octave */
    "800800000", /* HOLLW  sub and octave, hollow */
    "838000000", /* SMOOT  smooth comping */
    "888000000", /* 3BAR   the first three bars out */
    "888800000", /* BLUES  three bars and the octave */
    "888600006", /* GOSPL  body with a little shimmer */
    "888000888", /* ROCK   body and the top three */
    "800000888", /* TOPS   sub and the top only */
    "008080800", /* CLARI  odd harmonics, reedy-hollow */
    "008765432", /* REED   a falling slope, brassy */
    "006876540", /* STRNG  bright and thin */
    "004432000", /* CHAPL  soft, churchy */
    "008888000", /* BRITE  even bars, bright */
    "858000000", /* BASS   for the left hand */
    "888888888", /* FULL   everything */
};
static const char *const N_DRW_PERC[] = {"OFF", "2ND", "3RD", "2SOFT", "3SOFT", "2SLOW", "3SLOW"};
static const char *const N_DRW_ROTR[] = {"OFF", "SLOW", "FAST"};

/* partial frequency / note frequency, as a shift-and-add of the note's increment; FOLD_LIM:
 * the note increment above which the partial would pass DRW_FOLD */
static const uint32_t DRW_FOLD_LIM[DRW_NP] = {
    DRW_FOLD * 2u, DRW_FOLD / 3u * 2u, DRW_FOLD, DRW_FOLD / 2u, DRW_FOLD / 3u, DRW_FOLD / 4u, DRW_FOLD / 5u,
    DRW_FOLD / 6u, DRW_FOLD / 8u,
};
static inline uint32_t drw_ratio(uint32_t k, uint32_t x)
{
    switch (k) {
    case 0: return x >> 1;
    case 1: return x + (x >> 1);
    case 2: return x;
    case 3: return x << 1;
    case 4: return x * 3u;
    case 5: return x << 2;
    case 6: return x * 5u;
    case 7: return x * 6u;
    default: return x << 3;
    }
}

/* rotor speeds as phase increments per block (CTL samples): Hz * CTL / FS * 2^32 */
#define DRW_HZ(h) ((int32_t)((h) * 3116457.0))
static const int32_t DRW_ROT_SPD[2][3] = {
    {0, DRW_HZ(0.8), DRW_HZ(6.7)},   /* high rotor: OFF (stops), SLOW, FAST */
    {0, DRW_HZ(0.7), DRW_HZ(5.8)},   /* low rotor */
};

typedef struct {                 /* per part, once per block (wheel_block) */
    int32_t g[DRW_NP];           /* bar gains, Q15, normalised */
    int32_t pk, plev;            /* percussion: partial (DRW_NP = off), level Q15 */
    uint32_t pdec;               /* its decay per block, Q16 */
    int32_t clk;                 /* click level Q15 */
    int32_t dg, dcomp;           /* drive gain, Q8; output compensation, Q8 (0 = no drive) */
    uint32_t rph[2];             /* rotor phases (0 high, 1 low) */
    int32_t rsp[2];              /* rotor speeds (phase increment per block) */
    int32_t rwet;                /* rotary amount, Q15 (ramps on / off) */
    int32_t am[2];               /* this block's amplitude, Q15, per rotor */
    int32_t fm[2];               /* this block's pitch offset, Q16 of the increment, per rotor */
} drw_trk_t;

typedef struct {                 /* per voice */
    uint32_t ph[DRW_NP];
    int32_t gp[DRW_NP];          /* each partial's gain at the end of the last block (the ramp start) */
    int32_t perc;                /* percussion envelope, Q15 */
    int32_t clk;                 /* click envelope, Q15 */
    int32_t nz, hp;              /* click noise state, its high-pass state */
    uint8_t gate, init;
} drw_vc_t;

static drw_trk_t drw_t[NPART];
static drw_vc_t drw_v[VPOOLN];   /* (3.5) one entry per pool slot, not per part: it follows the voice */

static uint32_t drw_part(const track_t *t) { return (uint32_t)(t - trk) % NPART; }

/* (3.0) x / 1270, exact for the leak's range (x <= 65534 * 127): the target's divide is one of the
 * slowest instructions in a loop, and a multiply-high has the same result here. */
static inline int32_t drw_div1270(uint32_t x)
{
    return (int32_t)(((uint64_t)x * 13527457u) >> 34);
}

/* one rotor, once per block: called twice with k a constant, so the k branches fold away */
static inline void drw_rotor(drw_trk_t *T, uint32_t k, uint32_t rot, int32_t ra)
{
    int32_t sp, c, sn, dep, tgt = DRW_ROT_SPD[k][rot];
    if (rot && ra)                                  /* (FASE 2) ROTOR+: up to 4x the speed, neutral at 127 */
        tgt += (int32_t)(((int64_t)tgt * ra * 3) / 127);
    T->rsp[k] += (tgt - T->rsp[k]) >> (k ? 11 : 9);
    sp = T->rsp[k];
    T->rph[k] += (uint32_t)sp;
    sn = sine_i(T->rph[k]);
    c = sine_i(T->rph[k] + 0x40000000u);
    dep = k ? 7000 : 13000;                         /* AM depth: low rotor 21 %, high 40 % */
    T->am[k] = 32767 - mulq15(dep, (32767 - c) >> 1);
    T->fm[k] = (sn * (sp >> (k ? 17 : 16))) >> 15;  /* Doppler: +-0.5 % fast (high), +-0.2 % (low) */
}

/* the bar level 0..8 of partial k: the registration plus SUB / BODY / TOP */
static int32_t drw_level(const int16_t *p, uint32_t k)
{
    int32_t d = DRW_REG[(uint32_t)p[P_E0] & 15u][k] - '0';
    d += k < 2u ? p[P_E1] : k < 4u ? p[P_E2] : p[P_E3];
    return clamp(d, 0, 8);
}

/* once per block, before the voices: bar gains, percussion, click, drive, the rotors */
static void wheel_block(track_t *t)
{
    drw_trk_t *T = &drw_t[drw_part(t)];
    const int16_t *p = t->p;
    uint32_t k, perc = (uint32_t)p[P_E4] % 7u, rot = (uint32_t)p[P_E7] % 3u;
    int32_t s = 0, lv[DRW_NP];
    uint32_t norm;
    for (k = 0; k < DRW_NP; k++) {
        lv[k] = perc && k == DRW_NP - 1u ? 0 : DRW_LV[drw_level(p, k)];   /* PERC on: the 1' bar is off */
        s += lv[k];
    }
    /* sum of the gains = 2.4 s / (s + 1.5) (s in units of a full bar): one bar 0.96, three 1.6,
     * all nine 2.06 */
    norm = (uint32_t)(2u * 39322u * 32768u) / (uint32_t)(s + 49152);
    if (perc == 1u || perc == 2u || perc == 5u || perc == 6u)
        norm = (norm * 23170u) >> 15;                   /* normal percussion: the bars -3 dB */
    for (k = 0; k < DRW_NP; k++)
        T->g[k] = (int32_t)(((uint32_t)lv[k] * norm) >> 15);
    {   /* (FASE 2) CHARACTER: LEAK, the neighbouring tonewheels bleeding into each bar (the wiring's crosstalk),
         * from the gains just made; up to ~10 % at full. Neutral at 127. */
        int32_t leak = xamt(p, 0);
        if (leak) {
            /* one pass: prev is the unmodified g[k-1], next is g[k+1] (not touched yet) and g0 is
             * the first bar, which k = 8 needs before this pass changed it */
            int32_t prev = T->g[DRW_NP - 1u], next0 = T->g[0];
            for (k = 0; k < DRW_NP; k++) {
                int32_t cur = T->g[k];
                int32_t next = k + 1u < DRW_NP ? T->g[k + 1u] : next0;
                T->g[k] = cur + drw_div1270((uint32_t)(prev + next) * (uint32_t)leak);
                prev = cur;
            }
        }
    }
    T->pk = perc ? (int32_t)(3u + ((perc - 1u) & 1u)) : DRW_NP;   /* 2ND: 4', 3RD: 2 2/3' */
    T->plev = perc == 3u || perc == 4u ? 12000 : 24000;
    T->pdec = perc >= 5u ? 65457u : 65219u;             /* tau 0.6 s / 0.15 s */
    if (p[P_MORPH])                                     /* (FASE 2) CHARACTER 3: PERC DCY, a longer percussion */
        T->pdec = 65536u - (uint32_t)(((uint64_t)(65536u - T->pdec) * (uint32_t)(127 - p[P_MORPH])) / 127u);
    T->clk = p[P_E5] * 180;
    if (p[P_E6]) {                                      /* y = 6 / (2 + g) tanh(g x / 2) */
        T->dg = 256 + p[P_E6] * 6;                      /* 1 .. 4 */
        T->dcomp = (6 * 256 * 256) / (512 + T->dg);
    } else {
        T->dg = 0;
    }
    /* rotors: each speed eases to its target (high rotor tau ~0.37 s, low ~1.5 s). Two of them,
     * unrolled: no loop, no k test per block, and one xamt() for both. */
    {
        int32_t ra = rot ? xamt(p, 1) : 0;
        drw_rotor(T, 0, rot, ra);
        drw_rotor(T, 1, rot, ra);
    }
    T->rwet += ((rot ? 32767 : 0) - T->rwet) >> 5;      /* ~25 ms in or out */
    T->am[0] = 32767 - mulq15(T->rwet, 32767 - T->am[0]);
    T->am[1] = 32767 - mulq15(T->rwet, 32767 - T->am[1]);
    T->fm[0] = mulq15(T->fm[0], T->rwet);
    T->fm[1] = mulq15(T->fm[1], T->rwet);
}

static void wheel_note_on(track_t *t, voice_t *v)
{
    uint32_t vi = VSLOT(v), k, held = 0;
    drw_vc_t *V = &drw_v[vi];
    for (k = 0; k < NVOICE; k++)                        /* single trigger: another key of the part held? */
        if (&V(t, k) != v && V(t, k).active && V(t, k).gate && V(t, k).stage != 4u)
            held = 1;
    if (!V->init || (!V->gate && FELUCCA_WSEED)) {      /* the wheels: spread start phases, then free running.
                                                         * (3.6) the spread is the voice's place in its part, not
                                                         * the pool slot it happens to sit in, and a slot with no
                                                         * note on it seeds again: FELUCCA_WSEED=1, else as before */
        uint32_t id = FELUCCA_WSEED ? vindex(t, v) : vi;
        for (k = 0; k < DRW_NP; k++) {
            V->ph[k] = (k * 0x9E3779B9u) ^ (id * 0x7F4A7C15u);
            if (FELUCCA_WSEED && !V->gate)
                V->gp[k] = 0;                           /* (3.6) a slot with no note starts its ramps from 0,
                                                             * as a virgin slot of the old layout did */
        }
        V->nz = 0x13579BDF + (int32_t)id;
        V->init = 1;
    }
    V->perc = held ? 0 : 32767;
    V->clk = 32767;
    V->hp = 0;
    V->gate = 1;
}

static void wheel_render(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    const drw_trk_t *T = &drw_t[drw_part(t)];
    drw_vc_t *V = &drw_v[VSLOT(v)];
    int32_t acc[CTL], perc1, clk0, clk1;
    uint32_t i, k;
    if (n > CTL)
        n = CTL;
    for (i = 0; i < n; i++)
        acc[i] = 0;
    perc1 = (int32_t)(((uint32_t)V->perc * T->pdec) >> 16);
    for (k = 0; k < DRW_NP; k++) {
        uint32_t x = m->inc, inc, ph = V->ph[k];
        int32_t g1 = T->g[k], g0 = V->gp[k], r;
        if ((int32_t)k == T->pk)
            g1 += mulq15(T->plev, perc1);
        while (x > DRW_FOLD_LIM[k])                     /* fold back above ~6 kHz */
            x >>= 1;
        inc = drw_ratio(k, x);
        r = inc < DRW_XOVER;                            /* 1: the low rotor */
        g1 = mulq15(g1, T->am[r]);
        inc += (uint32_t)((int32_t)(inc >> 16) * T->fm[r]);
        V->gp[k] = g1;
        if (!g0 && !g1) {
            V->ph[k] = ph + inc * n;
            continue;
        }
        if (g0 == g1) {
            for (i = 0; i < n; i++) {
                ph += inc;
                acc[i] += (SINE[ph >> 22] * g1) >> 15;
            }
        } else {                                        /* gain ramp over the block (CTL = 32) */
            int32_t gq = g0 << 5, dg = g1 - g0;
            for (i = 0; i < n; i++) {
                ph += inc;
                gq += dg;
                acc[i] += (SINE[ph >> 22] * (gq >> 5)) >> 15;
            }
        }
        V->ph[k] = ph;
    }
    V->perc = perc1;
    /* key click: high-passed noise, at the key contact and (half) at the release */
    if (V->gate && !v->gate) {
        V->gate = 0;
        V->clk = 16384;
    }
    clk0 = mulq15(V->clk, T->clk);
    if (clk0 > 16) {
        int32_t nst = V->nz, hp = V->hp, dc;
        V->clk = (V->clk * 3) >> 2;                     /* tau ~2.5 ms */
        clk1 = mulq15(V->clk, T->clk);
        dc = clk1 - clk0;
        clk0 <<= 5;
        for (i = 0; i < n; i++) {
            int32_t z = (int32_t)(noise32(&nst) >> 17) - 16384, y = z - hp;
            hp += y >> 3;
            clk0 += dc;
            acc[i] += (y * (clk0 >> 5)) >> 15;
        }
        V->nz = nst;
        V->hp = hp;
    }
    if (T->dg || m->shape != (64 << 8)) {               /* overdrive; (0.6.81) LFO / ENV -> SHAPE drive it (SHAPE did
                                                         * nothing on the organ) */
        int32_t dg = T->dg, dcomp = T->dcomp;
        if (m->shape != (64 << 8)) {
            dg = clamp((dg ? dg : 256) + ((m->shape - (64 << 8)) * 3 >> 5), 256, 1024);
            dcomp = (6 * 256 * 256) / (512 + dg);
        }
        for (i = 0; i < n; i++)
            acc[i] = (softclip((acc[i] * dg) >> 9) * dcomp) >> 8;
    }
    for (i = 0; i < n; i++)                             /* acc: Q15 with headroom to 4.0 */
        out[i] += voice_amp(acc[i] >> 1, m, i) * 2;   /* (v1.5.16) the amp is signed: * 2, not << 1 */
}

static const preset_t WHEEL_PRESETS[] = {
    /* name, {REG, SUB, BODY, TOP, PERC, CLICK, DRIVE, ROTR}, {A D S R}, fenv, mono */
    {"FULL ORGAN", {15, 0, 0, 0, 0, 30, 20, 1}, {0, 64, 127, 45}, 0, 0, FX(0, 28, 8, 30), PAT(5),
     {XP(P_LRATE, 18), XP(P_LWAVE, 1), XP(P_LD_AMP, 6), XP(P_HARM, 6)}},
    {"JAZZ PERC", {4, 0, 0, 0, 2, 50, 8, 1}, {0, 64, 127, 40}, 0, 0, FX(0, 20, 4, 22), PAT(3),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18), XP(P_HARM, 14)}},
    {"GOSPEL", {6, 0, 0, 0, 1, 60, 40, 2}, {0, 64, 127, 45}, 0, 0, FX(6, 32, 4, 38), PAT(6),
     {XP(P_LRATE, 20), XP(P_LWAVE, 0), XP(P_LD_AMP, 8)}},
    {"SOFT FLUTE", {1, 0, -2, 0, 0, 10, 0, 1}, {0, 64, 127, 55}, 0, 0, FX(0, 22, 16, 54), PAT(5),
     {XP(P_LRATE, 26), XP(P_LWAVE, 0), XP(P_LD_PIT, 4), XP(P_M1SRC, 7), XP(P_M1DST, 2), XP(P_M1AMT, 10)}},
    {"ROCK DRIVE", {7, 0, 0, 0, 0, 70, 100, 2}, {0, 64, 127, 40}, 0, 0, FX(38, 0, 10, 22), PAT(4),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 20), XP(P_HARM, 18)}},
    /* (GAMMAWAVE) cathedral & overdriven tonewheel patches */
    {"DOOM CATH", {15, 6, 4, 3, 0, 45, 78, 1}, {20, 85, 127, 75}, 0, 0, FX(36, 28, 24, 86), PAT(5),
     {XP(P_LRATE, 12), XP(P_LWAVE, 6), XP(P_LD_FLT, 14), XP(P_LD_AMP, 8)}},
    {"BAKELITE", {11, 4, 2, -2, 3, 65, 92, 2}, {2, 70, 120, 50}, 0, 0, FX(44, 18, 30, 42), PAT(6),
     {XP(P_LRATE, 24), XP(P_LWAVE, 4), XP(P_LD_FLT, 12)}},
    /* (1.2-GW, issue #17: ambient and expressive) an organ drone: flutes, the slow rotor, a long swell */
    {"DRONE ORGAN", {0, 4, 2, -4, 0, 0, 0, 1}, {60, 64, 127, 90}, 0, 0, FX(0, 38, 20, 86), PAT(5),
     {XP(P_LRATE, 10), XP(P_LWAVE, 6), XP(P_LD_FLT, 12), XP(P_LD_AMP, 6)}},
    /* (QUANTUM // QG-1) a bright drawbar set with percussion, a soft chapel */
    {"QUANTUM DRAW", {9, 2, 1, 1, 2, 40, 30, 2}, {0, 64, 127, 45}, 0, 0, FX(12, 20, 16, 38), PAT(6),
     {XP(P_LRATE, 20), XP(P_LWAVE, 1), XP(P_LD_FLT, 10)}},
    {"CHAPEL SOFT", {2, 2, -1, 0, 0, 5, 0, 1}, {40, 64, 127, 80}, 0, 0, FX(0, 28, 20, 82), PAT(5),
     {XP(P_LRATE, 11), XP(P_LWAVE, 6), XP(P_LD_FLT, 10), XP(P_HARM, -8)}},
    /* (QG-1 EXPANSION: Hurdy Gurdy & Acoustic Traditional) */
    {"HURDY GURDY", {10, 4, 3, -2, 1, 85, 45, 0}, {5, 60, 127, 40}, 0, 1, FX(16, 10, 16, 28), PAT(3),
     {XP(P_LRATE, 34), XP(P_LWAVE, 1), XP(P_LD_PIT, 5), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 12)}},
    {"GURDY DRONE", {8, 6, 4, -4, 0, 95, 60, 0}, {20, 80, 127, 70}, 0, 0, FX(24, 18, 20, 58), PAT(5),
     {XP(P_LRATE, 16), XP(P_LWAVE, 1), XP(P_LD_PIT, 4), XP(P_LD_FLT, 10)}},
    {"MEDIEVAL VIEL", {6, 3, 2, -1, 0, 40, 25, 0}, {10, 70, 120, 50}, 0, 1, FX(10, 14, 16, 44), PAT(4),
     {XP(P_LRATE, 28), XP(P_LWAVE, 1), XP(P_LD_FLT, 8)}},
    {"FOLK DRONE", {12, 5, 3, 0, 0, 50, 35, 1}, {45, 80, 127, 85}, 0, 0, FX(12, 24, 24, 74), PAT(5),
     {XP(P_LRATE, 13), XP(P_LWAVE, 6), XP(P_LD_FLT, 12)}},
    {"NORDIC ORGAN", {7, 3, 0, 1, 1, 30, 15, 1}, {15, 64, 127, 65}, 0, 0, FX(0, 34, 28, 68), PAT(6),
     {XP(P_LRATE, 19), XP(P_LWAVE, 0), XP(P_LD_AMP, 6)}},
    {"GOTHIC SHRINE", {15, 7, 5, 4, 0, 60, 85, 2}, {30, 90, 127, 95}, 0, 0, FX(38, 42, 34, 94), PAT(5),
     {XP(P_LRATE, 12), XP(P_LWAVE, 6), XP(P_LD_FLT, 14), XP(P_LD_AMP, 6)}},

    /* (QG-1 1.6) EVOLVE: the rotor's swell and the filter wander together, slowly */
    {"CATHEDRAL REED", {5, 2, 3, 1, 2, 30, 10, 1}, {45, 70, 127, 90}, 0, 0, FX(0, 35, 25, 88), PAT(5),
     {XP(P_LRATE, -1), XP(P_LWAVE, 6), XP(P_LD_FLT, 14), XP(P_LD_AMP, 8)}},
    {"TIDAL ORGAN", {13, 6, 6, 3, 0, 55, 45, 2}, {60, 85, 127, 95}, 0, 0, FX(15, 50, 30, 85), PAT(5),
     {XP(P_LRATE, 3), XP(P_LWAVE, 6), XP(P_LD_FLT, 20)}},
    /* (6.0) the remaster's new sounds: one per family, each with its own motion and sends */
    {"TONE CABINET", {6, 1, 2, 1, 1, 35, 25, 1}, {0, 72, 100, 40}, 16, 0, FX(0, 40, 10, 34), PAT(6),
     {XP(P_LRATE, 22), XP(P_LWAVE, 1), XP(P_LD_AMP, 6)}},  /* KEYS: organ */
    {"SALT REED", {3, 2, -1, 2, 2, 25, 18, 1}, {8, 78, 92, 56}, 10, 0, FX(0, 30, 18, 52), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18), XP(P_HARM, 8)}},  /* KEYS: reed */
    {"BARKING PIPE", {11, 3, 3, -2, 4, 80, 55, 0}, {0, 74, 66, 40}, 28, 1, FX(20, 12, 20, 30), PAT(1),
     {XP(P_LRATE, 32), XP(P_LWAVE, 4), XP(P_LD_FLT, 12), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 14)}},  /* D: industrial reed */
    {"CORAL ORGAN", {13, 2, 4, 2, 0, 20, 8, 2}, {30, 90, 116, 88}, 6, 0, FX(0, 52, 26, 70), PAT(5),
     {XP(P_LRATE, 14), XP(P_LWAVE, 1), XP(P_LD_FLT, 10)}},  /* B: organ pad */
};

static const param_desc_t WHEEL_CH[3] = {
    {"LEAK", F_PCTINV, 0, 127, 127, 0, 0}, {"ROTOR+", F_PCTINV, 0, 127, 127, 0, 0},
    {"P.DCY", F_PCT, 0, 127, 0, 0, 0},
};

static const engine_t ENG_WHEEL = {
    .name = "WHEEL",
    .page_title = {"BARS", "TONE", "CHAR"},
    .edit = {
        {"REG", F_ENUM, 0, 15, 4, N_DRW_REG, 0},
        {"SUB", F_INT, -8, 8, 0, 0, 0},
        {"BODY", F_INT, -8, 8, 0, 0, 0},
        {"TOP", F_INT, -8, 8, 0, 0, 0},
        {"PERC", F_ENUM, 0, 6, 0, N_DRW_PERC, 0},
        {"CLICK", F_PCT, 0, 127, 40, 0, 0},
        {"DRIVE", F_PCT, 0, 127, 0, 0, 0},
        {"ROTOR", F_ENUM, 0, 2, 1, N_DRW_ROTR, 0},
    },
    .presets = WHEEL_PRESETS,
    .npresets = NELEM(WHEEL_PRESETS),
    .ch = WHEEL_CH,
    .ch_n = 3,
    .note_on = wheel_note_on,
    .render = wheel_render,
    .knob = {P_E0, P_E4, P_E6, P_E7},
    .block = wheel_block,
};
