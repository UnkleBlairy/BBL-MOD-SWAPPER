/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* I2S output (ALNK0 -> external codec) and the
 * audio ISR: per half buffer, blocks of CTL samples: mix_block (fx.c: events ->
 * each synth part -> dist -> level / pan -> sends -> buses -> master) -> USB audio (uac_tap) -> the metronome's
 * click (click.c, the DAC only) -> 24-bit stereo. */
/* registers: hal/fm1_audio.h */
#define HALF_WORDS (HALF_FRAMES * 2u)
#define DAC_TICKS 544u            /* TIMER4 ticks per I2S frame (24 MHz / 44,117.6 Hz) */
#define CPU_AVG (4096u / HALF_FRAMES)   /* halves the load meter averages: ~93 ms whatever the half */
#define OUT_SHIFT 7               /* Q15 -> 24-bit, -6 dBFS ceiling (M0f ran clean at -18 dBFS) */

static int32_t abuf[2u * HALF_WORDS] __attribute__((aligned(4)));

/* diagnostics, kept across resets and UBOOT entry: read with `fm1t memr` */
#define DBG_MAGIC 0x44424731u                       /* "DBG1" */
struct felucca_dbg {
    uint32_t magic, halves, max_us, nested, in_audio, late, timer_irqs, ui_frames;
    uint32_t last_us, cpu_q8, boots;
    uint32_t stage, page, home;           /* where the main loop is (breadcrumbs) */
    uint32_t prev_stage, prev_page, prev_home, prev_rst, prev_frames;   /* as found at boot */
} felucca_dbg __attribute__((unused));
static volatile uint32_t audio_halves, audio_max_us;
static volatile uint32_t t5_nested_ticks;              /* TIMER4 ticks TIMER5 spent nested in this ISR (main.c) */
static uint32_t audio_cpu_rem;                         /* keep the fractional IIR step: no low-load bias */
static uint32_t audio_last_half = 2u, audio_lost;     /* (1.2.1-GW, JIANT 0.8.9) halves never rendered: a render past
                                                         * two halves (console) */
#define SCOPE_N 256u
static int16_t scope_buf[SCOPE_N];                     /* the left channel: the scope draws it */
static int16_t scope_r[SCOPE_N];                       /* (1.9) the right one: its meter had nothing to read */
static uint32_t scope_w;

/* The ring's contract, because two contexts touch it. dac_scope is the only writer and it runs in the
 * audio ISR; audio_out_peak, ui_being.c and ui_graph.c only read. Every access is a naturally aligned
 * 16-bit sample or the 32-bit position, which pi32v2 stores and loads whole, and the writer only ever
 * advances the position, so a reader can at worst catch a frame that is one store newer than the frame
 * beside it -- a level a hair off for one screen, which is what a meter is allowed to be. No lock, no
 * seqlock and no atomic costs the ISR anything; the alternative (a copy under a lock) would either block
 * the ISR or double the buffer. tests/audio_test.c feeds the ring by hand and checks both channels and
 * both edges; tests/six_track_live_test.c runs the real render while the meters are read.
 *
 * The index arithmetic relies on SCOPE_N being a power of two (the mask) and on the ring holding whole
 * blocks, so a reader never sees a window that is mostly the block being written. */
_Static_assert((SCOPE_N & (SCOPE_N - 1u)) == 0u, "the scope ring masks with SCOPE_N - 1: it must be a power of two");
_Static_assert(SCOPE_N >= 8u * CTL, "the scope ring must hold eight blocks: a reader needs room behind the writer");
_Static_assert(SCOPE_N <= 4096u, "the scope ring is walked per screen: keep it small");

/* (1.9) the peak |sample| each DAC channel reached across the scope's history, 0..32768. The main loop calls
 * this, never the ISR: the audio path pays one store more per frame and no comparison at all, which is what
 * keeps fm1_alnk0_irq inside the static cost budget (tests/target_budget.py). 256 frames of every other
 * sample: ~11.6 ms of the master, the window a meter wants. */
int32_t audio_out_peak(uint32_t ch)
{
    const int16_t *b = ch ? scope_r : scope_buf;
    uint32_t i, w = scope_w;
    int32_t pk = 0;
    for (i = 0; i < SCOPE_N; i++) {
        int32_t v = b[(w - 1u - i) & (SCOPE_N - 1u)];
        if (v < 0) v = -v;
        if (v > pk) pk = v;
    }
    return pk;
}

/* one block of the master output into the scope's history: both channels, one store each, nothing else */
static void dac_scope(const int32_t *out, uint32_t n)
{
    uint32_t i;
    for (i = 1; i < n; i += 2u) {                       /* the music, before the click */
        uint32_t w = scope_w++ & (SCOPE_N - 1u);
        scope_buf[w] = (int16_t)out[2u * i];      /* master_out holds |out| <= 32767 (fx.c), so the cast is exact */
        scope_r[w] = (int16_t)out[2u * i + 1u];
    }
}

/* (1.4.2.1) NO POP AT POWER-ON. The codec and its amp come up while the first blocks are already being rendered,
 * and the step that makes -- DC offset settling, the codec's own transient -- went straight to the speaker under
 * the splash. The DAC output is faded in over BOOT_FADE samples (~27 ms at 44.1 kHz): too slow to hear as a ramp,
 * fast enough that the first keystroke is at level, and it silences the click.
 * (1.4.5) The fade is applied by fx.c to the gain the master ALREADY ramps across the block (lev_cur / lev_dg):
 * the same multiply happened anyway, so the second pass over every sample this used to run cost the ISR its
 * budget and bought nothing. Only the fade's position advances here, once a block. */
#define BOOT_FADE 1200u
static uint32_t boot_gain;                             /* 0 .. 32768, Q15: the fade's position */
/* (FASE 3) THE FADE WAS SPENT WHILE THE SPEAKER WAS STILL MUTED. fm1_audio_init unmutes the output stage
 * (pc6) only at its very end, 25 ms after the engine started on the zeroed buffer -- and the ramp above ran
 * from the first block, so by that unmute it was already at ~93 %: what reached the speaker was the step the
 * fade existed to hide. Two things follow, and both are now handled here:
 *   1. the output stays at digital silence (gain 0, exact zeros) until audio_fade_in() arms the ramp, which
 *      main.c calls once the boot's own interrupts-off stages are done, so the fade is not spent under a
 *      muted stage and the unmute lands on zeros;
 *   2. the same window covers the boot's critical sections (the second core's start runs with interrupts off
 *      for up to 20 ms, seven 2.9 ms halves): the engine may lose halves there, but it loses them on zeros,
 *      which is silence, not a click.
 * The ramp still ends ~27 ms after arming, during the splash: nothing is added to the boot's length. */
static volatile uint8_t boot_armed = 1;                /* 0: silence; 1: the ramp above runs (armed by default: see
                                                        * audio_fade_in / audio_boot_hold below) */
/* (1.4.12) THE DEFAULT IS ARMED, and main.c is what holds the output for the boot: audio_init() leaves the ramp
 * running, so a caller that is not the instrument's boot (every host test renders through audio_block, and the
 * emulator too) gets the engine's output without having to know about the boot's timing -- without this, the
 * whole host suite rendered -180 dB of exact silence after FASE 3 gated the master on this flag. main.c calls
 * audio_boot_hold() right after audio_init() and audio_fade_in() once the interrupts-off stages are done, which
 * is the behaviour the fade was added for. */
void audio_fade_in(void) { boot_gain = 0; boot_armed = 1; }
void audio_boot_hold(void) { boot_gain = 0; boot_armed = 0; }
void fx_boot_gain(int32_t g);                          /* fx.c: the fade, folded into the block's master gain */
static void audio_block(int32_t *out, uint32_t n)       /* mix (fx.c), then Q15 -> 24 bit */
{
    uint32_t i;
    fx_boot_gain(boot_armed ? (int32_t)boot_gain : 0);  /* (1.4.5) the fade is on the master: USB and DAC stay the
                                                         * same signal, and it costs no pass of its own. (FASE 3)
                                                         * until armed: 0, so the output is exact silence */
    mix_block(out, n);
    if (boot_armed && boot_gain < 32768u) {
        boot_gain += (uint32_t)n * (32768u / BOOT_FADE);
        if (boot_gain > 32768u) boot_gain = 32768u;
    }
#if FELUCCA_UAC
    uac_tap(out, n);                                    /* the USB audio input: the same master output */
#endif
    if (fx_usb_fixed)                                   /* USB LEVEL FIXED: USB took the full level, the DAC */
        usb_fixed_dac(out, n);                          /* (speaker, headphones) gets MASTER's (fx.c) */
    dac_scope(out, n);                                  /* the HOME scope: both channels of the music */
    click_render(out, n);                               /* the metronome (click.c): the DAC only, not USB */
    for (i = 0; i < n; i++) {
        out[2u * i] *= 1 << OUT_SHIFT;
        out[2u * i + 1u] *= 1 << OUT_SHIFT;
    }
}

/* Overload: two halves in a row above 80 % (0.6.15: was 85, too late: a click first, the UI starved) (the render plus TIMER5 nested in it), fade one voice over the
 * next block, and one more each half while it lasts. Keep each part's
 * lowest POLY note and MONO / LEGATO / UNISON lead, as the shared budget does. */
static volatile uint8_t shed_req;
static uint8_t shed_over;                              /* bit k: the half k halves ago was over 80 % */
#define SHED_TICKS ((HALF_FRAMES * 1000000u / FS) * 80u / 100u * FM1_TICKS_PER_US)   /* 80 % of a half */
static uint32_t shed_count;

/* end of a half: all = its ticks, TIMER5 nested in it included -> the render alone in us. The deadline sees
 * both; shed after 2 overloaded halves in a row (out of line: keeps the ISR's render loops as they were) */
#define TIGHT_ON ((HALF_FRAMES * 1000000u / FS) * 65u / 100u * FM1_TICKS_PER_US)    /* (0.6.16) the load budget (0.6.17: 65 %, was 70) */
#define TIGHT_OFF ((HALF_FRAMES * 1000000u / FS) * 60u / 100u * FM1_TICKS_PER_US)
#define TIGHT_ON_ECO ((HALF_FRAMES * 1000000u / FS) * 50u / 100u * FM1_TICKS_PER_US)   /* (0.6.70) LOAD ECO: the budget */
#define TIGHT_OFF_ECO ((HALF_FRAMES * 1000000u / FS) * 45u / 100u * FM1_TICKS_PER_US)  /* sooner: room kept for the peaks */
static uint8_t tight_calm;                             /* halves in a row under 60 % */
static __attribute__((noinline)) uint32_t shed_check(uint32_t all)
{
    uint32_t r = all - t5_nested_ticks;                /* (0.6.19) the budget on the render alone: a key scan or
                                                         * USB burst nested in it is not the sound's */
    uint32_t eco = sys_load == LOAD_ECO;
    if (r > (eco ? TIGHT_ON_ECO : TIGHT_ON)) {         /* (voice.c load_tight: no voice added while set) */
        load_tight = 1;
        tight_calm = 0;
    } else if (load_tight && r < (eco ? TIGHT_OFF_ECO : TIGHT_OFF) && ++tight_calm >= 16u) {
        load_tight = 0;
    }
    shed_over = (uint8_t)(shed_over << 1 | (all > SHED_TICKS));
    if ((shed_over & 3u) == 3u)                        /* (0.6.19: two in a row again, as before 0.6.17: one
                                                         * spike shed a voice every 2.9 ms, tails cut, clicks) */
        shed_req = 1;
    return (all - t5_nested_ticks) / FM1_TICKS_PER_US;
}

/* (v1.5.23) NOINLINE, like shed_check above and for the same reason: this scans NPART x NVOICE twice, and the static
 * budget of the render path (tests/target_budget.py) weighs a loop inside fm1_alnk0_irq far more than a call to a
 * function out of line. Measured: inlined, the IRQ read 290 instructions / 158 in loops / cost 854 against a budget of
 * 291 (OVER BUDGET +193 %); out of line it is the call it always was. The work and the behaviour are identical. */
static __attribute__((noinline)) void shed_voice(void)
{
    uint32_t p, i, best_p = 0;
    voice_t *best = 0;
    /* (v1.5.23, FASE 2) ONE ACTION PER EPISODE. shed_req is armed by two halves in a row above 80 % of the deadline,
     * and a shed voice is not gone: it fades for six blocks (~4.4 ms) and, until it does, the load it costs is
     * unchanged. A spike longer than that armed another shed while the first was still fading, so a single episode
     * could take three or four voices (each one a cut the player hears) where one was the answer. While a voice is
     * in its stage-4 fade the guard has already acted: wait for the load to see it. */
    for (p = 0; p < NPART; p++)
        for (i = 0; i < NVOICE; i++)
            if (V(&trk[p], i).active && V(&trk[p], i).stage == 4u)
                return;
    for (p = 0; p < NPART; p++)
        for (i = 0; i < NVOICE; i++) {
            voice_t *v = &V(&trk[p], i);
            if (v->active && !v->gate && v->stage != 4u && (!best || v->env < best->env))
                best = v;
        }
    if (best) {
        voice_kill(best);
        shed_count++;
        return;
    }
    for (p = 0; p < NPART; p++) {
        const track_t *t = &trk[p];
        uint32_t mode = trk_vmode(t), low = mode == V_POLY ? lowest_held(t) : 0u;
        for (i = 0; i < NVOICE; i++) {
            voice_t *v = &V(&trk[p], i);
            if (v->active && v->gate && v->stage != 4u &&
                ((mode == V_POLY && i != low) || (mode != V_POLY && i > 0u))) {
                /* (v1.5.23, FASE 2) THE QUIETEST, NOT THE OLDEST. The candidates here are held notes the part may keep
                 * sounding; the oldest is the one that has been held longest, which is exactly the sustained body of
                 * the chord (loud, at its sustain), while the note just struck is still climbing its attack and is a
                 * fifth as audible. The measure is the same v_energy the allocator uses (the envelope times the
                 * part's level), with the age only breaking a tie. */
                uint32_t e = v_energy(t, v), be = best ? v_energy(&trk[best_p], best) : 0u;
                if (!best || e < be || (e == be && v->age < best->age)) {
                    best = v;
                    best_p = p;
                }
            }
        }
    }
    if (best) {
        voice_kill(best);
        shed_count++;
    }
}

void fm1_alnk0_irq(void)                       /* via isr_alnk0 (hal/fm1_isr.S) */
{
    uint8_t p;
    uint32_t t0;
    felucca_dbg.in_audio = 1;                   /* first: TIMER5 nests from here on (main.c) */
    p = fm1_audio_pending();
    t0 = fm1_ticks();
    t5_nested_ticks = 0;
    fm1_audio_ack_aux(p);
    if (p & FM1_AUDIO_HALF) {
        uint32_t half = fm1_audio_free_half(), b, us;
        int32_t *o = &abuf[half * HALF_WORDS];
        fm1_audio_ack_half();                           /* (1.2.1-GW, JIANT 0.8.9) first: a flip during a late render */
        if (half == audio_last_half)                    /* stays pending and this ISR runs again at once for the other */
            audio_lost++;                               /* half (acked after the render, a late half lost the next one: */
        audio_last_half = half;                         /* its stale 2.9 ms played again, a click, USB short) */
        if (shed_req) {
            shed_req = 0;
            shed_voice();
        }
#if FELUCCA_UAC
        uac_render_start();
#endif
        for (b = 0; b < HALF_FRAMES; b += CTL) {
#ifdef FM1_INPUT_LAT
            kb_out_tick = t0 + (HALF_FRAMES + b) * DAC_TICKS;   /* when this block plays (seq.c kb_lat) */
#endif
            audio_block(o + 2u * b, CTL);
        }
        audio_halves++;
        us = shed_check(fm1_ticks() - t0);
        if (us > audio_max_us)
            audio_max_us = us;
        {
            uint32_t load = song.cpu_q8 * (CPU_AVG - 1u) + (us * 256u) / (HALF_FRAMES * 1000000u / FS) + audio_cpu_rem;
            song.cpu_q8 = load / CPU_AVG;
            audio_cpu_rem = load % CPU_AVG;
        }
        if (fm1_audio_free_half() != half)
            felucca_dbg.late++;                         /* the DMA moved on while we rendered (1.2.1-GW: caught up
                                                         * at once, its half pending; a click only past ~1.7 halves) */
        {   /* (0.6.17) MENU > ABOUT's numbers (voice.c load_diag) */
            uint32_t pc = us * 100u / (HALF_FRAMES * 1000000u / FS);
            if (pc > load_diag.peak) load_diag.peak = pc;
            if (us) load_diag.valid = 1u;                /* (3.0) there is a measurement to show */
            load_diag.late = felucca_dbg.late;
            load_diag.shed = shed_count;
        }
        felucca_dbg.halves++;
        felucca_dbg.last_us = us;
        if (us > felucca_dbg.max_us)
            felucca_dbg.max_us = us;
        felucca_dbg.cpu_q8 = song.cpu_q8;
    }
    felucca_dbg.in_audio = 0;
}
extern void isr_alnk0(void);

static void audio_init(void)                   /* codec and ALNK0 bring-up (fm1_audio.h) */
{
    uint32_t i;
    for (i = 0; i < 2u * HALF_WORDS; i++)
        abuf[i] = 0;
    boot_gain = 0;                                     /* (1.4.2.1) the fade starts at silence ... */
    boot_armed = 1;                                    /* ... armed here: main.c holds it with audio_boot_hold() */
    fm1_audio_init(abuf, HALF_WORDS, isr_alnk0, 3);
}
