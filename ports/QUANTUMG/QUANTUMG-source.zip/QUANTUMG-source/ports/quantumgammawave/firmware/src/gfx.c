/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Small-canvas renderer (no full framebuffer). Draw text/lines into
 * an off-screen strip, then blit it in one DMA transfer. Pixels are stored
 * byte-swapped (the panel takes RGB565 big-endian).
 * Text and icons are 4-bit alpha bitmaps made at build time (tools/gen_aa_font.py: Inter Tight;
 * tools/gen_aa_icons.py: Fukiai). A glyph is trimmed to its ink box, advances are in 1/16 px, and
 * each glyph is rasterised at 1 << psh horizontal phases (S M 4, L 2: drawn at a pen of +0, +1/4 .. px);
 * cv_text takes the phase that puts it within a phase step of its true place. Blending uses a 16-entry
 * ramp per (ink, background) pair, cached, so a pixel costs a nibble read and a store. Colours come from the theme tokens. */
/* (FASE 1, 2026-11-16) one phase of a glyph. The advance is the same in every phase (tools/gen_aa_font.py
 * checks it), so it lives once per glyph in aafont_t.adv: 6 B a phase instead of 8, 840 B less XIP. */
typedef struct { uint16_t off; int8_t bx; uint8_t by, bw, bh; } aag_t;
typedef struct {
    uint8_t h, asc, first, last, nex;   /* line height, baseline; ASCII range; extras */
    uint16_t nk;                        /* kerning pairs */
    const aag_t *g;
    const void *adv;                    /* the glyph's advance, 1/16 px: one per glyph, not per phase; byte-wide
                                         * when adv8, 16 bits otherwise (the faces' fits: 210 B less XIP) */
    const uint8_t *data;
    const uint16_t *kkey;               /* a << 8 | b, sorted */
    const int8_t *kd;                   /* 1/16 px */
    const uint8_t *ex;                  /* codes of the extra glyphs */
    uint8_t psh;                        /* log2 of the phases per glyph: g[i << psh] .. g[(i << psh) + phases - 1] */
    uint8_t adv8;                       /* the advances in adv are bytes, not the 16-bit words of aafont_t.adv */
    const uint8_t *hc;                  /* data's Huffman code (cv_alpha_hc), 0 = 2 px per byte (cv_alpha) */
} aafont_t;
typedef struct { const char *name; uint16_t bg, surf, text, theme, accent; } ui_pal_t;
typedef struct { uint16_t off; uint8_t w; const char *label; } kc_t;
#include "ui_fonts.h"                   /* AF_S 12 px / 400, AF_M 15 px / 500, AF_L 28 px / 600 */
#include "ui_palettes.h"
#include "ui_keycaps.h"                 /* KC_*: the keycaps / badges (tools/gen_aa_keycaps.py), KNOB_* arcs */
#define ELLIPSIS '\x85'                 /* the ellipsis glyph of AF_S and AF_M */

/* host tests hook in here (layout lint, draw cost); nothing in the firmware */
#ifndef GFX_HOOK_TEXT
#define GFX_HOOKS 0                     /* (the firmware: what only the hooks read is not even computed) */
#define GFX_HOOK_TEXT(x0, y0, x1, y1, s, flags) ((void)0)   /* an ink box; flags 1 ellipsised, 2 cut, 4 icon, 8 free text, 32 in a scrolled view */
#define GFX_HOOK_BLIT(x, y, r0) ((void)0)
#ifndef GFX_HOOK_BLIT_ROWS                             /* (v1.5.15) a run of rows [r0, r1): what the panel really got */
#define GFX_HOOK_BLIT_ROWS(x, y, r0, r1) ((void)0)
#endif
#ifndef GFX_HOOK_BLIT_BAND                             /* .. and the band itself, once, for the layout lint: the */
#define GFX_HOOK_BLIT_BAND(x, y) ((void)0)             /* canvas landed on the panel whatever rows it sent */
#endif
#define GFX_HOOK_BEGIN() ((void)0)
#define GFX_HOOK_PIXELS(n) ((void)0)
#endif
#ifndef GFX_HOOKS
#define GFX_HOOKS 1
#endif
#ifndef GFX_HOOK_CELL
#define GFX_HOOK_CELL(x0, y0, x1, y1) ((void)0)    /* a cell, card, row or button (cv_rrect): a box touching it lies inside it */
#endif
#ifndef GFX_HOOK_INK
#define GFX_HOOK_INK(ink, bg) ((void)0)            /* a text, icon or keycap label's ink and what it is drawn on */
#endif
#ifndef GFX_HOOK_RULE
#define GFX_HOOK_RULE(x, y, w, h) ((void)0)        /* a divider drawn on the screen (ui_draw.c lcd_rule): no box may touch it */
#endif
#ifndef GFX_HOOK_FILL
#define GFX_HOOK_FILL(w, h) ((void)0)              /* (FASE 8) the pixels a fill paints: counted, never computed, on the device */
#endif
/* the alignment check (tests/ui_render.c): GFX_HOOK_ALIGN declares that the next item(s) drawn (a text, an icon, a
 * keycap, a cushion) are meant to sit centred in the box x0..x1, y0..y1 (canvas drawing coordinates, x1 y1 past it)
 * along AL_H and / or AL_V; AL_N(n): the next n items together. A text's ink is measured across (its glyphs' boxes)
 * and its capitals' band up and down (GFX_HOOK_PEN: its line top and face); an icon's ink from its cell
 * (GFX_HOOK_ITEM). The tag names the place in the report. */
#ifndef GFX_HOOK_ALIGN
#define GFX_HOOK_ALIGN(x0, y0, x1, y1, mode, tag) ((void)0)
#define GFX_HOOK_PEN(y, f) ((void)0)
#define GFX_HOOK_ITEM(x0, y0, x1, y1) ((void)0)
#define GFX_HOOK_ICON(x, y, size, id) ((void)0)        /* (an icon drawn: GFX_HOOK_ITEM with its ink, icons.c icon_ink) */
#endif
#define AL_H 1u                                    /* centred across */
#define AL_V 2u                                    /* centred up and down (a row's items: on the same centre line) */
#define AL_HV 3u
#define AL_B 4u                                    /* on the baseline y1 (a text: its capitals' bottom) */
#define AL_R 8u                                    /* the ink ending at x1 */
#define AL_PASS 16u                                /* (its item counts for the place declared before it too) */
#define AL_CELLS 32u                               /* the next cells (cv_rrect), not ink: a row of keys, a fill */
#define AL_N(n) ((uint32_t)(n) << 8)

/* (1.4.11) THE PANEL'S SLICE, and the reason its storage is here: the controller's frame memory is 240x320 and the
 * panel shows 240 rows of it, so every window lcd.c writes has to land on the 240-row slice the module is bonded
 * to. 0 is rows 0..239 (what every build before 1.4.11 assumed); 80 is rows 80..319, the slice the common 240x240
 * ST7789 modules use. MENU > EXTRA > PANEL Y sets it (panel.c settings_yoff, persisted), lcd_window adds it and the
 * full-screen clear fills the rows it leaves out. It is defined here, in the one source every translation unit
 * builds, because the host harness and the emulator stub lcd_fill / lcd_blit instead of compiling lcd.c. */
uint32_t lcd_yoff;

#define CV_MAX (240u * 124u)      /* the graph strip is 240 x 124 */
/* (ISO C11 6.5.2.3) Union type-punning provides well-defined 32-bit word access without strict-aliasing UB */
static union {
    uint16_t px[CV_MAX];
    uint32_t w32[CV_MAX / 2u];
} cv_buf __attribute__((unused, aligned(4)));
#define cv_px (cv_buf.px)
static uint32_t cv_w, cv_h;
static uint16_t cv_bg;           /* what cv_begin cleared the canvas to */
static uint8_t cv_scroll;        /* 1: drawing a scrolled view (its text may run past the canvas) */
static int32_t cv_oy;            /* y offset for graph drawing */
static int16_t cv_cy0, cv_cy1;   /* text clip: canvas rows cv_cy0 .. cv_cy1 - 1 (cv_begin: the whole canvas) */
static uint8_t cv_flip;          /* cv_alpha_hc: the cell mirrored left <-> right (the header's metronome, ui_draw.c) */

#define RGB(r, g, b) ((uint16_t)((((r) >> 3) << 11) | (((g) >> 2) << 5) | ((b) >> 3)))

/* ------------------------------------------------------------- theme --- */
/* Five stored colours per palette, the rest derived with fixed blends (tools/gen_ui_palettes.py) */
static struct {
    uint16_t bg, surf, text, theme, accent;
    uint16_t mid, dim, line, sel, tint, ink, rec, raise, key, lane, grid;
    uint16_t key_w, key_b;       /* (3.0) the keyboard's two greys: a light key and a dark one, both
                                  * derived from this palette so every theme keeps its own warmth */
    uint8_t light, mono;
    uint8_t bw;                  /* (3.0) MONO is the palette being DRAWN (for the graphics that must keep to black,
                                  * white and its one grey, which used to test settings.palette instead) */
    uint8_t chamfer;             /* (JIANT 0.5) the JIANT palette: corners cut on the diagonal (cv_rrect), not rounded */
    uint8_t style;               /* MENU > STYLE (ui.c style_apply): ST_FLAT, ST_LINE */
    uint32_t gen;                /* bumped by palette_set (the text ramps follow) */
} ux;
/* STYLE: FLAT, the filled SURF cards and panels; LINE, no SURF (it is BG) and 1 px T_RULE dividers between the
 * areas instead (ui_draw.c draw_frame). (1.0.2: PIXEL, LINE un-antialiased, retired; a saved PIXEL reads as LINE.)
 * Selections, accents, keys and gauges keep their fills in every style */
#define ST_FLAT 0u
#define ST_LINE 1u
#define T_RULE ux.dim            /* LINE: the dividers (DIM: visible on NIGHT, GREY, MONO and PAPER, quieter than labels) */
#define T_BG ux.bg               /* background */
#define T_SURF ux.surf           /* dialogs, menu rows, mixer strips */
#define T_TEXT ux.text           /* primary text */
#define T_THEME ux.theme         /* values, curves, the gauge's end line */
#define T_ACCENT ux.accent       /* the one active thing: hot knob, cursor, playhead */
#define T_MID ux.mid             /* labels, units, secondary text */
#define T_DIM ux.dim             /* inactive, empty */
#define T_LINE ux.line           /* 1 px dividers, gauge track */
#define T_SEL ux.sel             /* selection and gauge fill */
#define T_TINT ux.tint           /* a faint theme area */
#define T_INK ux.ink             /* text on T_SEL / T_THEME */
#define T_REC ux.rec             /* REC: fixed red (GREY, MONO: the accent) */
#define T_RAISE ux.raise         /* a raised area on a surface: stubs, guides, slots, chips, button wells */
#define T_KEY ux.key             /* a keycap's fill (its label: T_INK; unavailable: a T_DIM fill) */
#define T_KEYW ux.key_w          /* (3.0) a keyboard's white key: the light grey of every palette */
#define T_KEYB ux.key_b          /* .. and its black key: the darker grey, one clear step under it */
#define T_LANE ux.lane           /* the piano roll: an in-scale row (SURF -> THEME 10 %) */
#define T_GRID ux.grid           /* the piano roll: a step line (SURF -> TEXT 6 %; beats and C rows: RAISE) */
#define NPALETTES UI_NPALETTES

static inline uint16_t ux_gray(uint32_t x5) { return (uint16_t)((x5 << 11) | (x5 << 6) | x5); }
/* a + (b - a) * pct / 100 per channel, rounded; GREY on the red channel, so it stays gray */
#ifdef GFX_MIX_COUNT
/* (v1.7.21, tests only) how many blends a frame of this screen asks for: a COUNT, not a time, so the test that guards
 * the veil's table cannot flake on a busy host. Nothing at all when the macro is off, which is every shipped build. */
uint32_t gfx_mix_n;
#endif
static uint16_t ux_mix(uint16_t a, uint16_t b, int32_t pct)
{
    static const uint8_t SH[3] = {11, 5, 0}, MK[3] = {31, 63, 31};
    uint32_t out = 0, k;
#ifdef GFX_MIX_COUNT
    gfx_mix_n++;
#endif
    /* pct may overshoot 100 % on purpose (a spark, a rim that pops): every channel saturates at its
     * own width here, because an unclamped 5-bit result shifts its bits into the next channel and a
     * GREY or MONO screen ends up with a coloured pixel (648 of them in tests/ui_render.c). */
    if (ux.mono) {
        int32_t x = a >> 11, d = ((b >> 11) - x) * pct, v = x + (d + (d >= 0 ? 50 : -50)) / 100;
        return ux_gray((uint32_t)(v < 0 ? 0 : v > 31 ? 31 : v));
    }
    for (k = 0; k < 3u; k++) {
        int32_t x = (a >> SH[k]) & MK[k], d = (((b >> SH[k]) & MK[k]) - x) * pct;
        int32_t v = x + (d + (d >= 0 ? 50 : -50)) / 100;
        if (v < 0) v = 0;
        if ((uint32_t)v > MK[k]) v = MK[k];
        out |= (uint32_t)v << SH[k];
    }
    return (uint16_t)out;
}
static uint32_t ux_luma(uint16_t c)        /* 0..255 */
{
    return ((c >> 11) * 255u / 31u * 54u + ((c >> 5) & 63u) * 255u / 63u * 183u + (c & 31u) * 255u / 31u * 19u) >> 8;
}

/* (3.9) DEEPER, NOT DIMMER. The screen asked for more depth without touching the panel's backlight, which means
 * the tones, not the pixels: a surface is the palette's own surf shaded down `pct` per cent (a shade keeps the
 * hue, where a mix towards the background would have flattened it), so a card or a bay sits *under* the ink and
 * above the page instead of beside it, and the separation between the three reads at a glance. MONO keeps its
 * one grey (the block below overrides every derived tone) and PAPER is shaded as anything else: it loses 10 % of
 * its surface, not its legibility. */
static uint16_t ux_shade(uint16_t c, int32_t pct)
{
    int32_t r = (c >> 11) & 31, g = (c >> 5) & 63, b = c & 31, k = 100 - pct;
    int32_t nr = (r * k + 50) / 100, nb = (b * k + 50) / 100, ng = (g * k + 50) / 100;
    if (r == b && g == r * 2)                 /* a grey stays on the grey line (R = B, G = 2 R), exactly: GREY's
                                              * whole screen is checked for it (tests/ui_test.c screen_gray) */
        nb = nr, ng = nr * 2;
    return (uint16_t)((nr << 11) | (ng << 5) | nb);
}
/* (FASE 2/3) THE TWO GLOBAL ADJUSTMENTS, at the tokens, so every screen of every palette feels them once.
 * Dark zones: on a dark palette the background goes a step deeper than the surface, so the blacks and the
 * deep blues are defined and the step between background, panels and the parts widens instead of closing.
 * Bright zones: the theme and the accent move a little further from their own luma -- more cyan, more blue,
 * more violet, more turquoise, and the gradients built on them carry further. No channel is re-hued and no
 * colour is introduced; the percentages are small on purpose. A light palette keeps its paper (ux.light),
 * and GREY keeps every ink on the grey line (the whole screen is checked for it, tests/ui_test.c). */
#define UI_DEEP_BG_PCT 16      /* the background, that much darker */
#define UI_DEEP_SURF_PCT 5     /* the surface, a third as much: the step to the background widens */
#define UI_VIVID_PCT 18        /* the theme and the accent, that much further from their luma */
static uint16_t ux_sat(uint16_t c, int32_t pct)
{
    int32_t r = (c >> 11) & 31, g = (c >> 5) & 63, b = c & 31;
    int32_t y = (r * 2 + g * 5 + b) / 8, nr, ng, nb;
    nr = r + (r - y) * pct / 100; ng = g + (g - y) * pct / 100; nb = b + (b - y) * pct / 100;
    nr = nr < 0 ? 0 : nr > 31 ? 31 : nr;
    ng = ng < 0 ? 0 : ng > 63 ? 63 : ng;
    nb = nb < 0 ? 0 : nb > 31 ? 31 : nb;
    return (uint16_t)((nr << 11) | (ng << 5) | nb);
}
static void palette_set(uint32_t i)
{
    const ui_pal_t *p = &UI_PALETTES[i % NPALETTES];
    uint16_t bg = p->bg, surf = p->surf, theme = p->theme, accent = p->accent;
    i %= NPALETTES;
    ux.mono = i == UI_GREY_INDEX;
    ux.bw = i == UI_BW_INDEX;
    ux.chamfer = i == UI_JIANT_INDEX || i == UI_GAMMA_INDEX || i == UI_WRAITH_INDEX || i == UI_QUANTUM_INDEX ||
                 i == UI_SOLARIS_INDEX || i == UI_CYBER_INDEX || i == UI_NORDIC_INDEX;
    if (ux_luma(bg) <= 128u) {                     /* a dark palette: the darkest zones a step deeper */
        bg = ux_shade(bg, UI_DEEP_BG_PCT);
        surf = ux_shade(surf, UI_DEEP_SURF_PCT);
    }
    if (!ux.mono && !ux.bw) {                     /* GREY and MONO: set, never blended (tools/gen_ui_palettes.py) */
        theme = ux_sat(theme, UI_VIVID_PCT);
        accent = ux_sat(accent, UI_VIVID_PCT);
    }
    ux.bg = bg; ux.surf = ux.style ? bg : ux_shade(surf, 10); ux.text = p->text;
    ux.theme = theme; ux.accent = accent;
    ux.mid = ux_mix(bg, p->text, UI_MID_PCT);
    ux.dim = ux_mix(bg, p->text, UI_DIM_PCT);
    ux.line = ux_mix(bg, p->text, UI_LINE_PCT);
    ux.sel = ux_mix(bg, p->theme, UI_SEL_PCT);
    ux.tint = ux_mix(bg, p->theme, UI_TINT_PCT);
    ux.ink = bg;
    ux.raise = ux_mix(ux.surf, p->text, UI_RAISE_PCT);
    ux.key = ux_mix(bg, p->text, UI_KEY_PCT);
    /* (3.0) the Punch-in FX keyboard: a light grey and a darker one, two clear steps apart on every
     * palette (66 % and 26 % from the background to the text), never the background itself, so the
     * accidentals read as keys and not as holes */
    ux.key_w = ux_mix(bg, p->text, 66);
    ux.key_b = ux_mix(bg, p->text, 26);
    ux.lane = ux_mix(ux.surf, p->theme, 10);
    ux.grid = ux_mix(ux.surf, p->text, 6);
    ux.light = ux_luma(bg) > 128u;
    ux.rec = ux.mono ? p->accent : ux.light ? UI_REC_LIGHT : UI_REC_DARK;
    if (i == UI_BW_INDEX) {                      /* MONO: black and white, set, not blended (tools/gen_ui_palettes.py) */
        ux.mid = ux.sel = ux.key = ux.key_w = ux.rec = p->text;   /* a selection, a keycap, REC: white, its INK black */
        ux.dim = ux.line = ux.raise = ux.lane = ux.key_b = UI_BW_GREY;   /* the one grey: inactive, tracks, wells */
        ux.tint = ux.grid = p->bg;
    }
    ux.gen++;                                    /* the text ramps change with the coverage curve */
}

/* settings store a tagged id; ids below 20 are the palettes of earlier firmware */
static uint32_t palette_from_stored(uint32_t v)
{
    uint32_t i;
    if (v >= UI_PAL_TAG && v - UI_PAL_TAG < NPALETTES) i = v - UI_PAL_TAG;
    else if (v < 20u) i = UI_PALETTE_MIGRATE[v];
    else return UI_GREY_INDEX;
    return UI_PAL_LIVE[UI_PAL_SLOT[i]];                  /* (3.5) a retired palette reads as the live one it was
                                                         * retired into, and is stored as that */
}
static uint32_t palette_to_stored(uint32_t i) { return UI_PAL_TAG + i % NPALETTES; }
static int palette_stored_ok(uint32_t v) { return v < 20u || (v >= UI_PAL_TAG && v - UI_PAL_TAG < NPALETTES); }

static inline uint16_t swap16(uint32_t c) { return (uint16_t)(((c >> 8) & 0xFFu) | ((c & 0xFFu) << 8)); }

/* ------------------------------------------------------------ canvas --- */
static void cv_begin(uint32_t w, uint32_t h, uint16_t bg)
{
    uint32_t i, n;
    uint16_t s = swap16(bg);
    if (w * h > CV_MAX)
        h = CV_MAX / w;
    lcd_sync();                     /* the last blit may still read cv_px */
    GFX_HOOK_BEGIN();
    /* (FASE 2) A NEW CANVAS STARTS UNSHIFTED. cv_oy is the graph's vertical offset; the full-body screens
     * (HOME's visualizer and its views) set it to -26 / -114 for their passes and never put it back, and the
     * next frame's header and cards inherited it: their content landed above their own canvas and what was
     * blitted was the empty background, so the BPM, the battery, the arm and the first card vanished for as
     * long as their signatures matched -- exactly the strips that went missing after walking HOME's views.
     * Every drawer that wants the offset sets it after this call; none has to remember to clear it. */
    cv_oy = 0;
    cv_w = w;
    cv_h = h;
    cv_cy0 = 0;
    cv_cy1 = (int16_t)h;
    cv_bg = bg;
    n = w * h;
    {   /* (32-bit word fill via union) 2 pixels per 32-bit word store: faster than row copy,
         * identical bytes, zero strict aliasing UB, and eliminates 480 B of .bss row buffer */
        uint32_t s32 = ((uint32_t)s << 16) | s;
        uint32_t words = n >> 1;
        for (i = 0; i < words; i++)
            cv_buf.w32[i] = s32;
        if (n & 1u)
            cv_buf.px[n - 1u] = s;
    }
}

/* (GEN fix) screen rows the canvases leave alone (cv_hole0 .. cv_hole1 - 1; cv_hole1 0: none): the GEN screen's
 * pop-up, so the page drawn again under it never paints there (on the panel every write shows: the page and the
 * pop-up took turns, a knob's every detent) */
static uint16_t cv_hole0, cv_hole1;
/* (GEN fix) what the blits and fills cover in a band (cv_rec_y0 .. y1), recorded while cv_rec_on: an area's gaps
 * cleared after (the pop-up gone, the keys' lines on or off: the page drawn over it first, then what it does not
 * paint; a fill before it blinked) */
#define CV_REC_N 32u
static struct { uint8_t x0, x1, y0, y1; } cv_rec[CV_REC_N];
static uint8_t cv_rec_on, cv_rec_n, cv_rec_y0, cv_rec_y1;
static void cv_rec_add(uint32_t x, uint32_t y, uint32_t w, uint32_t h)
{
    if (!cv_rec_on || !w || !h || y >= cv_rec_y1 || y + h <= cv_rec_y0)
        return;
    if (cv_rec_n >= CV_REC_N) {
        cv_rec_n = 0xFFu;                           /* (too many: the caller falls back) */
        cv_rec_on = 0;
        return;
    }
    cv_rec[cv_rec_n].x0 = (uint8_t)x;
    cv_rec[cv_rec_n].x1 = (uint8_t)(x + w > 240u ? 240u : x + w);
    cv_rec[cv_rec_n].y0 = (uint8_t)y;
    cv_rec[cv_rec_n].y1 = (uint8_t)(y + h > 240u ? 240u : y + h);
    cv_rec_n++;
}
/* (v1.5.15) rows [r0, r1) of the canvas at (x, y), split around the hole if one is armed */
static void cv_blit_run(uint32_t x, uint32_t y, uint32_t r0, uint32_t r1)
{
    uint32_t a, b;
    if (r1 > cv_h)
        r1 = cv_h;
    if (r0 >= r1)
        return;
    if (cv_hole1 <= y + r0 || cv_hole0 >= y + r1) {
        lcd_blit(x, y + r0, cv_w, r1 - r0, cv_px + r0 * cv_w);
        return;
    }
    a = cv_hole0 > y ? cv_hole0 - y : 0u;           /* the rows above the hole, then those below it */
    b = cv_hole1 > y ? cv_hole1 - y : 0u;
    if (a > r1)
        a = r1;
    if (b > r1)
        b = r1;
    if (a > r0)
        lcd_blit(x, y + r0, cv_w, a - r0, cv_px + r0 * cv_w);
    if (b > r0 && b < r1)
        lcd_blit(x, y + b, cv_w, r1 - b, cv_px + b * cv_w);
}
/* one row's hash: two pixels a load, as the band's own (the words of the row, then the odd pixel if cv_w is odd) */
static uint32_t cv_row_hash(uint32_t r)
{
    uint32_t i, n = cv_w >> 1, base = (r * cv_w) >> 1, s = 0x811C9DC5u;
    for (i = 0; i < n; i++)
        s = (s ^ cv_buf.w32[base + i]) * 0x01000193u;
    if (cv_w & 1u)
        s = (s ^ cv_px[r * cv_w + cv_w - 1u]) * 0x01000193u;
    return s;
}
static void cv_blit_rows(uint32_t x, uint32_t y, uint32_t r0)
{
    uint32_t a, b;
    if (r0 >= cv_h)
        return;
    if (cv_hole1 <= y + r0 || cv_hole0 >= y + cv_h) {
        lcd_blit(x, y + r0, cv_w, cv_h - r0, cv_px + r0 * cv_w);
        return;
    }
    a = cv_hole0 > y ? cv_hole0 - y : 0u;           /* (the canvas rows above the hole, then those below) */
    b = cv_hole1 - y;
    if (a > r0)
        lcd_blit(x, y + r0, cv_w, a - r0, cv_px + r0 * cv_w);
    if (b < r0)
        b = r0;
    if (b < cv_h)
        lcd_blit(x, y + b, cv_w, cv_h - b, cv_px + b * cv_w);
}
/* (v1.5.6) THE PAGE BAND THE PANEL ALREADY HAS IS NOT SENT. Every page redraws its band into the canvas and this is
 * the only path to lcd_blit, so an idle frame -- nothing on it changed -- used to push the same 240 x 122 px to the
 * panel again: measured on the host harness, 29 280 px per idle frame on every page and 1 485 216 px over the 201
 * scenes of `ui_render --idle`, every one of them identical to what the panel already showed. The panel is a memory:
 * sending the same pixels to the same window changes nothing but the time core 0 spends in SPI, next to the audio.
 * The check is on the PIXELS, not on a page's state, so no signature can miss a change: an FNV-1a over the canvas'
 * 32-bit words (two pixels a load, the same bytes) against the one last sent to that same window. The bands with a
 * signature of their own (header, cards, footer) are a few hundred pixels and skip this; the page band is the one
 * that costs. Anything else that writes the panel outside this path -- a fill (draw_frame, the GEN screen, a
 * full-screen clear) -- calls gfx_forget(), and so does the host harness when it empties its own framebuffer. */
#define CV_SENT_MIN_H 16u                            /* (v1.5.15: 16, was 64) rows: a canvas worth hashing. HOME's
                                                      * body is three windows -- a 26-row cap and two 88-row passes --
                                                      * and 26 was below the old floor, so the cap was re-sent whole
                                                      * (6 240 px) every eighth frame for nothing. A band this small
                                                      * costs one hash a row to know that. */
extern uint32_t lcd_gen;                             /* (lcd.c: a fill changes what the panel shows) */
static struct { uint16_t x, y, w, h; uint32_t hh, gen; uint8_t on; } cv_last;
/* (v1.5.15) THE ROWS THE PANEL ALREADY HAS ARE NOT SENT EITHER. The whole-band hash above only skips a band that
 * is identical from top to bottom. HOME's three screens and the MIXER are not: their ambient layer (hv_air: sixteen
 * embers that step every eighth frame) and their meters change a handful of rows, so the band differed, the hash
 * never matched, and the panel was made to write all 240 x 88 px of each of the two passes (plus the 26-row cap)
 * for forty-odd pixels that moved -- ~48 000 px at ~7.5 Hz on OVERVIEW, 240 x 122 px every frame on MIXER while a
 * sequence runs, which is the whole body re-sent for nothing and was reported as the flicker. This keeps a hash per
 * ROW of the last window sent to the panel and writes only the runs of rows whose pixels differ: same pixels, same
 * order, 1/10 of the bus. Nothing about the drawing changes, so an animation animates exactly as before.
 * Cost: one 32-bit hash a row (the band's own hash, split) and CV_ROW_MAX x 4 B of .bss for the table. */
#define CV_ROW_MAX 240u
/* indexed by the PANEL's row, not by the canvas': HOME draws its body in three windows whose cap and first pass
 * share rows 26..46, and a per-window table would throw the shared rows away every time the window changed --
 * which is exactly what sent the whole 240 x 176 body again. One table of the panel's own rows needs no key: a row
 * whose pixels are the ones the panel already shows is not sent, whichever canvas drew it. */
static uint32_t cv_rowh[CV_ROW_MAX];                 /* panel row -> hash of what the panel shows there */
static uint8_t cv_rowv[CV_ROW_MAX];                  /* .. and whether that hash still describes the panel: a */
                                                     /* canvas that does not go through the table (the columns, */
                                                     /* the header, anything narrower than 240 or shorter than */
                                                     /* CV_SENT_MIN_H) writes rows it cannot vouch for */
static uint8_t cv_rowh_on;
/* (FASE 4) WHAT THE FILLS TOUCHED, since the last blit: the rows and the rects. lcd.c calls gfx_fill_rows() on every
 * fill (a weak symbol: a test that links lcd.c alone still builds), and a panel that goes to sleep calls
 * gfx_panel_forget() -- everything on it is unknown then. Eight rects is every fill a page draws in a frame; past
 * that the rows are all that is kept and the narrow windows under them are forgotten, which is the safe answer. */
static uint16_t cv_fl_x0[8], cv_fl_x1[8], cv_fl_ya[8], cv_fl_yb[8];
static uint8_t cv_fl_n;
static uint32_t cv_fl_lo = 240u, cv_fl_hi;
void gfx_fill_rows(uint32_t x, uint32_t y, uint32_t w, uint32_t h)
{
    if (y < cv_fl_lo)
        cv_fl_lo = y;
    if (y + h > cv_fl_hi)
        cv_fl_hi = y + h;
    if (cv_fl_n < 8u) {
        cv_fl_x0[cv_fl_n] = (uint16_t)x;
        cv_fl_x1[cv_fl_n] = (uint16_t)(x + w);
        cv_fl_ya[cv_fl_n] = (uint16_t)y;
        cv_fl_yb[cv_fl_n] = (uint16_t)(y + h);
        cv_fl_n++;
    } else {
        cv_fl_x0[0] = 0u; cv_fl_x1[0] = 240u; cv_fl_ya[0] = 0u; cv_fl_yb[0] = 240u;
    }
}
void gfx_panel_forget(void)
{
    cv_fl_lo = 0u;
    cv_fl_hi = 240u;
    cv_fl_x0[0] = 0u;
    cv_fl_x1[0] = 240u;
    cv_fl_ya[0] = 0u;
    cv_fl_yb[0] = 240u;
    cv_fl_n = 1u;
}
/* (FASE 6) THE NARROW-WINDOW CACHE: MEASURED, OFF UNTIL XIP HAS ~2,8 KB MORE. With the flag on the host harness
 * measures 21 440 px per idle frame (29 952 with it off) and the 3 056 frames of its sweep are identical;
 * `FELUCCA_WINCACHE=1 ./build.sh` does not link -- region `XIP' overflowed by 2 752 bytes -- and cutting code does
 * not pay, because this TU's size pass re-decides globally: a ten-instruction probe in cv_blit costs +2 592 B and
 * 306 of the 1 645 functions move by a median of 4 B. docs/FASE6_XIP_NARROW.md has the numbers and the way out. */
#ifndef FELUCCA_WINCACHE
#define FELUCCA_WINCACHE 0
#endif
#if FELUCCA_WINCACHE
/* THE NARROW WINDOWS THE PANEL ALREADY HAS ARE NOT SENT EITHER. The row table speaks only for a canvas
 * 240 wide and at least CV_SENT_MIN_H tall: EDIT's four columns (4 x 57 x 56 = 12 768 px a frame), the MIXER's
 * strips and the FX > BUSES modules fall through to the path below, which had no memory, so an idle frame pushed
 * them again. This is the half of the Fase 4 windows table that fits: a 32-bit FNV-1a of the whole canvas, kept for
 * the last CV_WIN_N windows that went to the panel, so a window drawn again byte for byte is not sent at all. One
 * that changed is sent whole (3 192 px for an EDIT column); a per-row table would send less, and cost 3,9 KB.
 * A hash speaks only for what the panel shows: a drawing over the window's rect -- another canvas, a wide band, a
 * fill -- clears it, and so does a sleeping panel (gfx_panel_forget). hh 0 never is a hash: it means empty. */
#define CV_WIN_N 4u
/* (FASE 6) in .noinit, like the panel's learned table: eight bytes of it would have moved every .bss global that
 * follows by eight, and measured, that alone is +2 600 B of XIP in this build (Fase 2 saw the same: +120 B of
 * struct, +2 952 B of code). .noinit is a window of its own, so no other global moves. It does not survive a reset
 * with its meaning: hh 0 is "empty", and cv_win_seen() clears the whole table whenever cv_rowh_on says no 240-wide
 * band has drawn since the last forget -- the only state in which a slot could be believed without one. */
static struct { uint16_t x, y, w, h; uint32_t hh; } cv_win[CV_WIN_N] __attribute__((unused));
#endif

/* (FASE 4) the rows the panel was filled under since the last blit: unknown, so forgotten (see gfx_fill_rows) */
__attribute__((noinline)) static void cv_fill_rows(void)
{
    uint32_t r, i, j;
    if (cv_fl_hi <= cv_fl_lo)
        return;
#if FELUCCA_WINCACHE
    for (i = 0; i < CV_WIN_N; i++)                       /* (FASE 6) a window a fill landed on is unknown */
        for (j = 0; j < cv_fl_n; j++)
            if (cv_fl_x0[j] < cv_win[i].x + cv_win[i].w && cv_win[i].x < cv_fl_x1[j] &&
                cv_fl_ya[j] < cv_win[i].y + cv_win[i].h && cv_win[i].y < cv_fl_yb[j])
                cv_win[i].hh = 0u;
#endif
    for (r = cv_fl_lo; r < cv_fl_hi && r < CV_ROW_MAX; r++)
        cv_rowv[r] = 0;
    cv_fl_n = 0;
    cv_fl_lo = 240u;
    cv_fl_hi = 0u;
}
void gfx_forget(void)
{
    uint32_t r, i;
    cv_last.on = 0;
    cv_rowh_on = 0;
#if FELUCCA_WINCACHE
    for (i = 0; i < CV_WIN_N; i++)
        cv_win[i].hh = 0u;
#endif
    for (r = 0; r < CV_ROW_MAX; r++)
        cv_rowv[r] = 0;
}
#if FELUCCA_WINCACHE
/* (FASE 6) 1: the panel already shows exactly this canvas, do not send it. The hash is recorded for the window
 * either way; out of line so the wide-band path stays as small as it was. */
__attribute__((noinline)) static int cv_win_seen(uint32_t x, uint32_t y)
{
    uint32_t i, n = (uint32_t)cv_w * cv_h, s = 0x811C9DC5u;
    int k = -1;
    if (!cv_rowh_on) {                               /* (nothing on this panel is vouched for: not these slots) */
        for (i = 0; i < CV_WIN_N; i++)
            cv_win[i].hh = 0u;
        return 0;
    }
    for (i = 0; i < (n >> 1); i++)
        s = (s ^ cv_buf.w32[i]) * 0x01000193u;
    if (n & 1u)
        s = (s ^ cv_px[n - 1u]) * 0x01000193u;
    if (!s)
        s = 1u;                                      /* (0 is "empty": a hash of 0 becomes 1, a miss, never a hit) */
    for (i = 0; i < CV_WIN_N; i++) {
        if (cv_win[i].x == x && cv_win[i].y == y && cv_win[i].w == cv_w && cv_win[i].h == cv_h) {
            if (cv_win[i].hh == s)
                return 1;                            /* the panel already shows exactly this window */
            k = (int)i;                              /* (the same window, a new picture) */
            break;
        }
        if (!cv_win[i].hh && k < 0)
            k = (int)i;
    }
    if (k >= 0) {
        cv_win[k].x = (uint16_t)x;
        cv_win[k].y = (uint16_t)y;
        cv_win[k].w = (uint16_t)cv_w;
        cv_win[k].h = (uint16_t)cv_h;
        cv_win[k].hh = s;
    }
    return 0;
}
#endif
__attribute__((noinline)) static void cv_blit(uint32_t x, uint32_t y)
{
    uint32_t n = cv_w * cv_h, i;
    cv_fill_rows();                                  /* (FASE 4) what a fill touched is not on the panel */
    cv_rec_add(x, y, cv_w, cv_h);                    /* (the cover, out or not: cv_gaps clears what none covers) */
    if (cv_h >= CV_SENT_MIN_H && x == 0u && cv_w == 240u) {
        uint32_t r, run0 = 0, in_run = 0;
        int same = cv_rowh_on;                       /* (FASE 4) the table describes what the panel shows now:
                                                      * cv_fill_rows() has already forgotten the filled rows */
        if (!same) {                                      /* first band after power-on or a fill: all of it */
            for (r = 0; r < CV_ROW_MAX; r++)
                cv_rowv[r] = 0;
            cv_rowh_on = 1;
        }
        GFX_HOOK_BLIT_BAND(x, y);
        /* the rows whose pixels differ from what the panel shows there, sent as runs (nothing changed: nothing) */
        for (r = 0; r < cv_h; r++) {
            uint32_t yy = y + r, hh;
            int ch;
            if (yy >= CV_ROW_MAX)
                break;
            hh = cv_row_hash(r);
            ch = !same || !cv_rowv[yy] || cv_rowh[yy] != hh;
            cv_rowh[yy] = hh;
            cv_rowv[yy] = 1;
            if (ch && !in_run) {
                run0 = r;
                in_run = 1;
            } else if (!ch && in_run) {
                GFX_HOOK_BLIT_ROWS(x, y, run0, r);
                cv_blit_run(x, y, run0, r);
                in_run = 0;
            }
        }
        if (in_run) {
            GFX_HOOK_BLIT_ROWS(x, y, run0, cv_h);
            cv_blit_run(x, y, run0, cv_h);
        }
        cv_last.on = 0;                               /* the row table is the record now */
#if FELUCCA_WINCACHE
        for (r = 0; r < CV_WIN_N; r++)                /* (FASE 6) the rows it redrew, windows and all */
            if (x < cv_win[r].x + cv_win[r].w && cv_win[r].x < x + cv_w &&
                y < cv_win[r].y + cv_win[r].h && cv_win[r].y < y + cv_h)
                cv_win[r].hh = 0u;
#endif
        return;
    } else if (cv_last.on && x < (uint32_t)cv_last.x + cv_last.w && cv_last.x < x + cv_w &&
               y < (uint32_t)cv_last.y + cv_last.h && cv_last.y < y + cv_h)
        cv_last.on = 0;                              /* (drawn over it: what it held is gone) */
#if FELUCCA_WINCACHE
    if (cv_win_seen(x, y))                           /* (FASE 6) the panel already shows exactly this window */
        return;
#endif
    {   /* (v1.5.15) rows this canvas wrote without the table's knowing what it put there: unknown until a 240-wide
         * band draws them again and says what they hold */
        uint32_t r;
        for (r = 0; r < cv_h; r++)
            if (y + r < CV_ROW_MAX)
                cv_rowv[y + r] = 0;
    }
    GFX_HOOK_BLIT(x, y, 0u);
    cv_blit_rows(x, y, 0u);
}

static int16_t cv_ink = 100;    /* (1.3.5) how much of a dot's ink it lays down; see cv_line_a */
static inline void cv_pset(int32_t x, int32_t y, uint16_t c)
{
    uint32_t i;
    y += cv_oy;
    if ((uint32_t)x >= cv_w || (uint32_t)y >= cv_h)
        return;
    i = (uint32_t)y * cv_w + (uint32_t)x;
    /* (1.3.5) at 100 % (every caller but a translucent line) this is the store it always was */
    cv_px[i] = cv_ink >= 100 ? swap16(c) : swap16(ux_mix(swap16(cv_px[i]), c, cv_ink));
}

static void cv_rect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c)
{
    int32_t x1 = x + w, y1 = y + h + cv_oy, i;
    uint16_t sc = swap16(c);
    y += cv_oy;                             /* clipped once, then filled row by row */
    if (x < 0)
        x = 0;
    if (y < 0)
        y = 0;
    if (x1 > (int32_t)cv_w)
        x1 = (int32_t)cv_w;
    if (y1 > (int32_t)cv_h)
        y1 = (int32_t)cv_h;
    GFX_HOOK_FILL((int32_t)(x1 - x), (int32_t)(y1 - y));   /* (FASE 8) what this fill costs, after clipping */
    if (x1 <= x || y1 <= y)
        return;                                         /* clipped away: a fill of nothing still cost the loop */
    /* (v1.5.10) TWO PIXELS PER STORE. cv_rect is the canvas' most used primitive -- every card, well, bar and
     * band is one -- and it wrote a 16-bit pixel at a time. The canvas is 4-byte aligned (cv_buf), so once a row's
     * first index is even the rest of it goes in 32-bit stores of the same two pixels: identical bytes, half the
     * stores. An odd start lays its first pixel down alone and an odd tail its last, so no row is skipped. */
    {
        uint32_t sc32 = ((uint32_t)sc << 16) | (uint32_t)sc;
        int32_t n;
        for (; y < y1; y++) {
            uint32_t off = (uint32_t)y * cv_w + (uint32_t)x;
            n = x1 - x;
            if (off & 1u) {
                cv_buf.px[off++] = sc;
                n--;
            }
            for (i = 0; i < (n >> 1); i++)
                cv_buf.w32[(off >> 1) + (uint32_t)i] = sc32;
            if (n & 1)
                cv_buf.px[off + (uint32_t)(n - 1)] = sc;
        }
    }
}

/* (FASE EXTRA) A SEE-THROUGH WELL. cv_rect() paints whole, so a scope's floor filled with the plate's tone hid
 * the deep field, its dust, its band and its worlds -- everything the visualizer draws behind it. This lays `c`
 * down at `pct` over the pixels the canvas already holds: ux_mix() against the colour that is there, the same
 * blend cv_ink does per dot, so the field keeps showing through the well while the grid and the trace, drawn
 * after it, stay solid on top. It is a real blend of the frame buffer (which is readable), not a dithered
 * imitation of one, and it clips exactly as cv_rect does. */
/* (v1.7.21) THE SHARE IS THE SAME FOR EVERY DOT, SO THE BLEND IS THREE TABLES. cv_rect_a is the visualizer's veil
 * over the scope well (144 x 72, in each of the two passes) and every pixel of it went through a full ux_mix: two
 * colour unpacks, three multiplies, three divisions by 100 and three clamps, ten thousand times a frame. The mix of
 * a channel with a FIXED share is a map dst -> out that fits in the channel's own width, so it is computed once
 * (32 + 64 + 32 entries, the same expression ux_mix uses, the same rounding) and applied as three lookups. The
 * pixels are identical -- tests/ui_pixels.txt and regress hold that -- and the frame measured 371 -> 292 us on the
 * host. Clipping is done once here instead of per dot, which is the rest of the win. */
static void cv_rect_a(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c, int32_t pct)
{
    int32_t i, j, x0, x1, y0, y1, k;
    uint8_t tb[3][64];
    static const uint8_t SH[3] = {11, 5, 0}, MK[3] = {31, 63, 31};
    if (ux.mono) {                  /* one channel, one tone: the old path is exact and rare */
        cv_ink = (int16_t)pct;
        for (j = y; j < y + h; j++)
            for (i = x; i < x + w; i++)
                cv_pset(i, j, c);
        cv_ink = 100;
        return;
    }
    for (k = 0; k < 3; k++) {
        int32_t src = (c >> SH[k]) & MK[k], d0;
        for (d0 = 0; d0 <= MK[k]; d0++) {
            int32_t d = (src - d0) * pct, v = d0 + (d + (d >= 0 ? 50 : -50)) / 100;
            if (v < 0) v = 0;
            if (v > MK[k]) v = MK[k];
            tb[k][d0] = (uint8_t)v;
        }
    }
    y += cv_oy;
    x0 = x < 0 ? 0 : x;
    y0 = y < 0 ? 0 : y;
    x1 = x + w > (int32_t)cv_w ? (int32_t)cv_w : x + w;
    y1 = y + h > (int32_t)cv_h ? (int32_t)cv_h : y + h;
    if (x1 <= x0 || y1 <= y0)
        return;
    for (j = y0; j < y1; j++) {
        uint16_t *row = cv_px + (uint32_t)j * cv_w;
        for (i = x0; i < x1; i++) {
            uint16_t d = swap16(row[i]);
            row[i] = swap16((uint16_t)(((uint32_t)tb[0][(d >> 11) & 31] << 11) |
                                       ((uint32_t)tb[1][(d >> 5) & 63] << 5) | tb[2][d & 31]));
        }
    }
}

/* a divider (LINE): a 1 px T_RULE line on the canvas, a cell edge for the host lint */
static void cv_rule(int32_t x, int32_t y, int32_t w, int32_t h)
{
    GFX_HOOK_CELL(x, y + cv_oy, x + w, y + h + cv_oy);
    cv_rect(x, y, w, h, T_RULE);
}

/* a 1 px outline */
static void cv_frame(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c)
{
    cv_rect(x, y, w, 1, c);
    cv_rect(x, y + h - 1, w, 1, c);
    cv_rect(x, y, 1, h, c);
    cv_rect(x + w - 1, y, 1, h, c);
}

/* (FASE 4) THE TWO PRIMITIVES EVERY ROUND THING WANTED. A knob at 8 px and a planet at 40 were both being
 * built out of chords and rectangles: the first read as a stepped polygon (the "square knob"), the second cost
 * a scan per row. A one-pixel circle by the midpoint octant rule and a filled disc by spans give every dial,
 * dot, meter head and orbit marker the same clean edge, and neither needs trigonometry. */
static void cv_line(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c)
{
    int32_t dx = x1 > x0 ? x1 - x0 : x0 - x1, sx = x0 < x1 ? 1 : -1;
    int32_t dy = y1 > y0 ? y0 - y1 : y1 - y0, sy = y0 < y1 ? 1 : -1;
    int32_t err = dx + dy, guard = 2000;
    while (guard--) {                       /* bounded: a line is never longer than 480 px */
        int32_t e2 = 2 * err;               /* both tests use the same error value */
        cv_pset(x0, y0, c);
        if (x0 == x1 && y0 == y1)
            break;
        if (e2 >= dy) {
            err += dy;
            x0 += sx;
        }
        if (e2 <= dx) {
            err += dx;
            y0 += sy;
        }
    }
}

/* a line `thick` px tall (the scope's trace: 2) */
static void cv_line_t(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c, int32_t thick)
{
    int32_t t;
    for (t = 0; t < thick; t++)
        cv_line(x0, y0 + t, x1, y1 + t, c);
}

/* (1.3.5) SEE-THROUGH INK. The frame buffer is readable, so transparency here is not a guess: a pixel of ink
 * becomes the colour already in it mixed towards the ink, nothing else. A scope over the spectrogram keeps the
 * bands under its line, a filter response keeps the grid it crosses, and the layers stay apart because each one
 * carries its own share -- the signal solid, the curves under it, the modulation lighter still.
 *
 * One control rather than a second line routine: cv_ink is the share of ink a single dot lays down, and the walk
 * that draws a line, a circle or a trace is the one already there. It is read by cv_pset only, so fills (cv_rect,
 * the bands, the floor) keep painting whole, and every blended call puts it back before it returns. */
#define CV_A_SIGNAL 84                   /* the oscilloscope: the strongest line on the bay */
#define CV_A_CURVE  70                   /* a filter response drawn over the data */
#define CV_A_MOD    56                   /* a modulation range: a hint, not a curve */
#define CV_A_WAVE   74                   /* a drawn waveform (a kit's lane, a ribbon) */
static void cv_line_t(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c, int32_t thick);
/* a line in a share of its ink: what is underneath stays visible through it */
static void cv_line_a(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c, int32_t pct, int32_t thick)
{
    cv_ink = (int16_t)pct;
    cv_line_t(x0, y0, x1, y1, c, thick);
    cv_ink = 100;
}

/* coverage (0..16) of corner pixel (i, j) of a radius-r corner, (0, 0) the outermost: 4 x 4 samples */
static uint32_t rr_cov(int32_t r, int32_t i, int32_t j)
{
    int32_t sx, sy, n = 0;
    for (sy = 0; sy < 4; sy++)
        for (sx = 0; sx < 4; sx++) {
            int32_t dx = r * 8 - ((i * 4 + sx) * 2 + 1), dy = r * 8 - ((j * 4 + sy) * 2 + 1);   /* 1/8 px */
            n += dx * dx + dy * dy <= r * r * 64;
        }
    return (uint32_t)n;
}
/* a filled rectangle with rounded corners (r <= 8), the corners anti-aliased against `under` (what lies
 * behind it): the flat look's cards, panels, rows, bars and buttons */
/* (FASE 3) A PANEL IS A SURFACE, NOT A FLAT PLATE.
 * FX > BUSES already drew its modules as raised surfaces -- a lit edge, a shaded foot, a frame and the
 * theme's corner mark -- while every other screen filled a big panel with one plain colour, which is why
 * the rest of the interface read flatter than that screen. This is the same treatment, applied by the
 * primitive every panel goes through, so all 189 screens gain it at once and none of them invents its own.
 * It is a BEVEL, not a wash: four rows of fade under the top bezel, a frame, four rows at the foot ending in
 * a warm floor line and a shadow. A full-area gradient was the first attempt and cost 590 us a frame on the
 * host -- more than the whole HOME screen -- because every panel re-filled its entire area; nine thin rows
 * cost almost nothing and read the same at 240x240.
 * Nothing here invents a colour: every value is ux_mix() between two colours of the palette in use, which
 * saturates per channel, so GREY and MONO stay neutral and no ink is drawn on its own tone. Small plates --
 * keycaps, chips, 3 px gauges, meter bars -- are left exactly as they were. */
static void gw_dither(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t a, uint16_t b, int32_t pct);   /* (1.0)
                                  * the short plates' single dithered fill: defined below, after the grounds */
static uint8_t cv_plate_flat;                 /* (FASE 3) the next plate is filled flat: see cv_rrect */
/* (1.2.6) EVERY PLATE TALL ENOUGH TO SHOW A RAMP TAKES IT. The chamfered style asked for 36 px of height, so the
 * 28 px modules of FX > MASTER (EQ / DEPTH / SLICER) and every other short box stayed a flat T_SURF panel beside a
 * page that is a gradient -- the same defect the owner reported on the first FX page. 24 px is the shortest body
 * where the ramp still reads as light coming from above (two bands of the cut ground) and where the frame's own
 * two lines leave it room, so the threshold drops for the chamfered and the rounded styles alike. */
#define PLATE_MIN_H 24          /* (1.2.6) shortest plate that takes the ramp: FX > MASTER's 28 px modules do */
/* (FASE 7) THE RAMP IS THE SAME FOR EVERY CARD OF A FRAME. A screen draws four to eight plates with one height
 * and one pair of colours, and each was mixing its own ramp again -- 21 ux_mix() calls per card, three
 * saturating channels each, for a list of colours that never changed inside the frame. The list is cached on
 * (rows, hi, lo) and rebuilt only when one of them moves, so a screen pays for it once. */
#define PLATE_CACHE 64          /* (128 B of .bss: a card needs 21, a panel 50, the graph falls back) */
static struct {
    int32_t n;
    uint16_t hi, lo;
    uint16_t g[PLATE_CACHE];
} plate_cache;
static uint16_t plate_ramp_at(int32_t k, int32_t n, uint16_t hi, uint16_t lo)
{
    if (n > 0 && n <= PLATE_CACHE) {
        if (plate_cache.n != n || plate_cache.hi != hi || plate_cache.lo != lo) {
            int32_t i;
            for (i = 0; i < n; i++) {
                int32_t t = (i + 1) * 100 / n;
                plate_cache.g[i] = ux_mix(hi, lo, t * t / 100);      /* (FASE 4) dark-heavy: see cv_plate_ground */
            }
            plate_cache.n = n, plate_cache.hi = hi, plate_cache.lo = lo;
        }
        return plate_cache.g[k];
    }
    {
        int32_t t = (k + 1) * 100 / n;
        return ux_mix(hi, lo, t * t / 100);
    }
}
static void cv_plate_ground(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c)
{
    int32_t k, n;
    cv_rect(x + r, y, w - 2 * r, 1, ux_mix(c, T_LINE, 55));           /* the frame */
    cv_rect(x + r, y + h - 1, w - 2 * r, 1, ux_mix(c, T_LINE, 38));
    cv_rect(x, y + r, 1, h - 2 * r, ux_mix(c, T_LINE, 48));
    cv_rect(x + w - 1, y + r, 1, h - 2 * r, ux_mix(c, T_LINE, 48));
    cv_rect(x + r + 2, y, 10, 1, T_ACCENT);                           /* the mark, as LINE's modules have */
    cv_rect(x, y + r + 2, 1, 8, T_ACCENT);
    /* (FASE 3) THE PLATE IS A GRADIENT, one row per pixel: a lit top (a little of T_TEXT mixed in) down to a
     * shaded foot (T_BG), so the surface reads as a lit panel instead of a flat rectangle with a hard band
     * under the bezel -- five rows, which at 240x240 is what looked pixelated. One cv_rect a row: a card of
     * 104 px is 104 fills, a row of a list is 16, and nothing is drawn per pixel, so a screen costs a few
     * hundred fills in total and the whole sweep stays the same order as before (measured below). */
    /* (FASE 7) A SHORT PLATE TAKES FEWER RUNS. A list row is 16..18 px tall: at one run per 2 rows that is
     * eight fills where the flat row was one, and MENU draws seven of them -- the page measured 10 % slower
     * for a gradient nobody can resolve at that height. (1.0) A row that short takes ONE fill, dithered
     * between the ends of its own ramp, instead of four bands: the same pass over the same pixels as the flat
     * row it replaced, and a slightly textured row instead of four visible steps. Cards keep the banded
     * ramp, which is where the depth reads. */
    if (h < 24) {
        gw_dither(x + 1, y + 1, w - 2, h - 2, ux_mix(c, T_TEXT, 4), ux_mix(c, T_BG, 74), 50);   /* (FASE 4) */
        return;
    }
    n = (h - 2 + 1) / 2;
    {
        /* Only the rows whose quantised colour CHANGES are filled: on a 16-bit palette a ramp this long has

         * about ten values, so a run of one fill covers several rows and the picture is the same one. */

        /* (FASE 4) DARKER AND CLEANER: the lit top is 4 % of the text colour instead of 7 (a card was pale under
         * a bright label), the foot goes 66 % of the way to T_BG instead of 58, and plate_ramp_at squares its
         * position so the middle of the plate sits close to the foot and the light stays in the first rows. The
         * result is one quiet surface with a lit edge -- a gradient, not a wash -- and it is the same primitive
         * for all 191 screens. cv_plate_rows and cv_plate_cut_ground carry the same numbers: a strip repainted
         * alone has to leave the surface the full pass leaves. */
        uint16_t hi = ux_mix(c, T_TEXT, 4), lo = ux_mix(c, T_BG, 74), g = plate_ramp_at(0, n, hi, lo);
        int32_t r0 = 0, bh = (h - 2) / n;
        for (k = 1; k < n; k++) {
            uint16_t gn = plate_ramp_at(k, n, hi, lo);
            if (gn != g) {
                cv_rect(x + 1, y + 1 + r0 * bh, w - 2, (k - r0) * bh, g);
                g = gn;
                r0 = k;
            }
        }
        cv_rect(x + 1, y + 1 + r0 * bh, w - 2, h - 2 - r0 * bh, g);
    }
}
/* (1.0) THE ROWS OF A PLATE, ON THEIR OWN. A card that repaints only its value strip (a digit rolling) has to
 * leave the surface a full render leaves, and a card's surface is the ramp above, not a flat colour: the strip
 * cleared to T_SURF and stayed a shade lighter than the rows just above and below it, which the roll test and
 * the 150 000-frame soak read as a stale card (ui_test). The same bands and the same colours as
 * cv_plate_ground, of which these are rows y0..y1 of a plate h tall filled with c. */
static void cv_plate_rows(int32_t x, int32_t y0, int32_t y1, int32_t w, int32_t h, uint16_t c)
{
    int32_t n = h >= 24 ? (h - 1) / 2 : (h > 6 ? 4 : 1), bh, k, a, b;
    uint16_t hi = ux_mix(c, T_TEXT, 4), lo = ux_mix(c, T_BG, 74);   /* (FASE 4) the numbers of cv_plate_ground */
    if (w < 3 || h < 3 || n < 1)
        return;
    bh = (h - 2) / n;
    if (bh < 1) bh = 1;
    for (k = 0; k < n; k++) {
        a = 1 + k * bh;
        b = k == n - 1 ? h - 2 : 1 + (k + 1) * bh;
        if (a < y0) a = y0;
        if (b > y1) b = y1;
        if (b > a)
            cv_rect(x + 1, a, w - 2, b - a, plate_ramp_at(k, n, hi, lo));
    }
}
/* (FASE 3) the same ramp on a chamfered plate: every row, from the top of the body to its foot, inset by the
 * corner's cut and stopped short of the frame's two lines. One fill a run of rows with the same colour and the
 * same width, so the two columns the three-rect fill left flat cost no more than the corners do. */
static void cv_plate_cut_ground(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c)
{
    int32_t j, n = h > 7 ? (h - 4 + 1) / 2 : 1, y0 = 0, w0 = -1;
    uint16_t hi = ux_mix(c, T_TEXT, 8), lo = ux_mix(c, T_BG, 74), g = 0;   /* (FASE 4) as cv_plate_ground */
    for (j = 0; j <= h - 4; j++) {
        int32_t dy = j + 2, db = h - 3 - j;                  /* rows to the plate's top and to its foot */
        int32_t d = dy < db ? dy : db, in = d < r ? r - d : 0;
        int32_t bw = w - 2 * in;
        uint16_t gn = plate_ramp_at(j / 2, n, hi, lo);
        if (w0 < 0) {
            g = gn, w0 = bw, y0 = j;
        } else if (gn != g || bw != w0) {
            cv_rect(x + (w - w0) / 2, y + 2 + y0, w0, j - y0, g);
            g = gn, w0 = bw, y0 = j;
        }
    }
    if (w0 > 0)
        cv_rect(x + (w - w0) / 2, y + 2 + y0, w0, h - 4 - y0, g);
}
static void cv_rrect(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c, uint16_t under)
{
    int32_t i, j, cut = ux.chamfer && r > 0;      /* (GAMMA / WRAITH: 45-degree chamfered octagonal modules) */
    GFX_HOOK_CELL(x, y + cv_oy, x + w, y + h + cv_oy);   /* (the lint: what is drawn on it stays inside it) */
    if (r < 0) r = -r;                           /* (-r: rounded in every style: a keycap-like cushion) */
    else if (ux.style == ST_LINE) r = 0;         /* LINE: square cursors, selections and fills (FLAT: rounded) */
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    if (r < 1) {
        cv_rect(x, y, w, h, c);
        return;
    }
    if (cut && c == T_SURF && T_SURF == T_BG) {  /* (JIANT: SURF is black) */
        cv_rect(x, y, w, h, c);
        return;
    }
    /* (FASE 8) EACH PLATE WAS PAINTED TWICE. These three rects filled the whole plate and the ramp painted every
     * one of those pixels again (frame and corners included: cv_plate_ground and cv_plate_cut_ground draw their
     * own, and the corner loop below the corners). With the ramp on, the base fill is skipped and the plate is
     * painted once: MENU went from 83 644 to 47 940 filled pixels a frame (docs/PERFORMANCE_FASE8.md), with no
     * pixel of the picture changed. */
    if (!(c == T_SURF && !cv_plate_flat && (cut ? (w >= 36 && h >= PLATE_MIN_H) : (w >= 40 && h >= 16)))) {
        cv_rect(x + r, y, w - 2 * r, h, c);
        cv_rect(x, y + r, r, h - 2 * r, c);
        cv_rect(x + w - r, y + r, r, h - 2 * r, c);
    }
    /* (FASE 3) A CHAMFERED MODULE IS A GRADIENT TOO, and the gradient has to reach its sides. This style fills
     * its plate as three rects (body, left band, right band); painting the ramp on the body only left a flat r-px
     * column down each side of every knob card, which read as two panels glued together. The ramp is per row now,
     * inset by the corner's cut, so it covers the whole surface and stops exactly where the chamfer begins. */
    if (cut && c == T_SURF && w >= 36 && h >= PLATE_MIN_H && !cv_plate_flat)
        cv_plate_cut_ground(x, y, w, h, r, c);
    if (cut) {
        int mod_box = (c == T_SURF && w >= 36 && h >= PLATE_MIN_H);
        uint16_t brd = mod_box ? T_RAISE : c;
        for (j = 0; j < r; j++)
            for (i = 0; i < r; i++) {
                int32_t s = i + j;
                uint16_t px = s < r - 1 ? under : s == r - 1 ? ux_mix(under, brd, 70) : (mod_box && s == r ? brd : c);
                cv_pset(x + i, y + j, px);
                cv_pset(x + w - 1 - i, y + j, px);
                cv_pset(x + i, y + h - 1 - j, px);
                cv_pset(x + w - 1 - i, y + h - 1 - j, px);
            }
        if (mod_box) {
            int32_t blen = w > 100 ? 14 : 9;
            cv_rect(x + r, y, w - 2 * r, 1, T_LINE);
            /* (FASE 2) the panel has a lit edge and a shaded one: a 1 px highlight inside the top border and a
             * 1 px shade inside the bottom, mixed from the panel's own colour, so the module reads as a raised
             * surface in every palette instead of a flat rectangle. Large panels only (mod_box), and no text
             * sits on either line. */
            cv_rect(x + r, y + 1, w - 2 * r, 1, ux_mix(c, T_TEXT, 13));
            cv_rect(x + r, y + h - 2, w - 2 * r, 1, ux_mix(c, T_BG, 52));
            cv_rect(x + r, y + h - 1, w - 2 * r, 1, T_LINE);
            cv_rect(x, y + r, 1, h - 2 * r, T_LINE);
            cv_rect(x + w - 1, y + r, 1, h - 2 * r, T_LINE);
            /* Signature GammaWave Top-Left angled corner bracket (GroupedComponent::paint) */
            cv_rect(x + r, y, blen, 1, T_THEME);
            cv_rect(x, y + r, 1, blen - 2, T_THEME);
            for (i = 0; i < r; i++) {
                cv_pset(x + i, y + r - 1 - i, T_THEME);
                if (i + 1 < r) cv_pset(x + i + 1, y + r - 1 - i, T_THEME);
            }
        }
        return;
    }
    /* (FASE 3) cv_plate_flat: a panel that paints its own ground (the graph bay, which creams its own ramp and
     * bezel right after) keeps a flat plate. Its ramp would otherwise show in the rows the bay leaves unpainted
     * -- the strip under its bezel -- and the oscilloscope would sit on a lit band instead of on shadow. */
    if (c == T_SURF && w >= 40 && h >= 16 && !cv_plate_flat)
        cv_plate_ground(x, y, w, h, r, c);
    for (j = 0; j < r; j++)
        for (i = 0; i < r; i++) {
            uint32_t a = rr_cov(r, i, j);
            uint16_t px = a >= 16u ? c : a == 0u ? under : ux_mix(under, c, (int32_t)(a * 100u / 16u));
            cv_pset(x + i, y + j, px);
            cv_pset(x + w - 1 - i, y + j, px);
            cv_pset(x + i, y + h - 1 - j, px);
            cv_pset(x + w - 1 - i, y + h - 1 - j, px);
        }
}

/* ------------------------------------------------- 4-bit alpha blit --- */
/* coverage curves: a little heavier for light ink on dark, lighter for dark ink on light */
static const uint8_t CURVE_DARK[16] = {0, 24, 43, 62, 80, 97, 114, 130, 147, 163, 178, 194, 210, 225, 240, 255};
static const uint8_t CURVE_LIGHT[16] = {0, 12, 27, 42, 58, 75, 91, 109, 126, 144, 162, 180, 199, 217, 236, 255};
/* (1.2.6) the BOLD pass of the same glyphs: the coverage a nibble takes when the text is the four knob cards' label.
 * The bitmaps, the advance, the baseline and the fit are the face's own -- the ink box is the plain one -- and what
 * changes is how solid the strokes are: an edge that was a quarter covered is three quarters now, so the stems gain
 * the column that a second weight in flash would have paid for in XIP. The 15 nibble a stem already is stays 255. */
static const uint8_t CURVE_BOLD[16] = {0, 62, 96, 126, 152, 175, 195, 212, 227, 240, 250, 255, 255, 255, 255, 255};
/* (1.5.28) SIX WAS TOO SMALL FOR A SCREEN. The sweep counts what a frame rebuilds, and a page with four knob
 * cards, a value, a unit, a label and an accent asks for 10 to 17 distinct (ink, ground, heat, curve) pairs:
 * with six slots the one a glyph needed next had already been evicted, so the same ramps were built again and
 * again every frame. A build walks 16 coverage levels through three channels, and it costs nothing but .bss to
 * remember them: 20 slots are 760 B of the 11 KiB of RAM the linker leaves free, and no byte of XIP (the
 * modulo is a constant). Output is untouched by construction -- a cache hit returns the very array a rebuild
 * would have written, which is what the golden renders check. */
#define NRAMP 20u
/* (1.5.28) HOW OFTEN A RAMP IS BUILT, because it is the text path's biggest cost: a miss walks 16 coverage
 * levels and three channels each. Counter only, no behaviour: the sweep reads it to say whether the cache is
 * big enough for a screen (see tests/ui_render.c). */
unsigned gfx_ramp_builds;
static struct {
    uint16_t fg[NRAMP], bg[NRAMP], hot[NRAMP], v[NRAMP][16];   /* v: byte-swapped panel values */
    uint32_t gen;
    uint8_t next, n, bold[NRAMP];                 /* (1.2.6) which curve built it: see CURVE_BOLD */
} rc;
static uint8_t cv_bold;                          /* (1.2.6) the next text is the bold pass */

/* (Solar Heat) ramp(fg, bg, 0) is the plain ink ramp text and graphs use. ramp(fg, bg, hot) is the icons':
 * the levels that are nearly transparent carry an ink pulled towards `hot` -- the palette's heat -- and the
 * solid ones the ink itself, so the fringe of every glyph glows warm like a print that sat in the sun.
 * It is the same one code path and the same cache, so an extra colour costs no extra state. */
static const uint16_t *ramp(uint16_t fg, uint16_t bg, uint16_t hot)
{
    static const uint8_t SH[3] = {11, 5, 0}, MK[3] = {31, 63, 31};
    const uint8_t *cv = cv_bold ? CURVE_BOLD : ux.light ? CURVE_LIGHT : CURVE_DARK;
    uint32_t i, a, k;
    uint16_t *v;
    if (fg == bg)                                /* MONO: DIM on a RAISE well (one grey): black, recessed */
        fg = ux.bg;
    GFX_HOOK_INK(fg, bg);
    if (rc.gen != ux.gen) {
        rc.gen = ux.gen;
        rc.n = rc.next = 0;
    }
    for (i = 0; i < rc.n; i++)
        if (rc.fg[i] == fg && rc.bg[i] == bg && rc.hot[i] == hot && rc.bold[i] == cv_bold)
            return rc.v[i];
    i = rc.next;
    gfx_ramp_builds++;
    rc.next = (uint8_t)((i + 1u) % NRAMP);
    if (rc.n < NRAMP)
        rc.n++;
    rc.fg[i] = fg;
    rc.bg[i] = bg;
    rc.hot[i] = hot;
    rc.bold[i] = cv_bold;
    v = rc.v[i];
    for (a = 0; a < 16u; a++) {
        uint32_t out = 0;
        int32_t w = cv[a];
        uint16_t ink = hot && a < 6u ? ux_mix(fg, hot, (6 - (int32_t)a) * 17) : fg;
        if (ux.mono) {
            int32_t x = bg >> 11;
            out = ux_gray((uint32_t)(x + ((((ink >> 11) - x) * w + 128) >> 8)));
        } else {
            for (k = 0; k < 3u; k++) {
                int32_t x = (bg >> SH[k]) & MK[k], y = (ink >> SH[k]) & MK[k];
                out |= (uint32_t)(x + (((y - x) * w + 128) >> 8)) << SH[k];
            }
        }
        v[a] = swap16(out);
    }
    return v;
}

/* w x h nibbles, rows back to back, at canvas (x, y) */
/* (QG-1 1.7) 16-BIT CHROME ---------------------------------------------------------------
 * The plates, keys and meters are built the way the 16-bit consoles built theirs: a flat
 * face, one lighter edge, one darker edge, and a two-colour ordered dither where a smooth
 * gradient would have gone. All three are plain fills on the canvas the page already owns:
 * no state, no allocation, and no colour of their own -- the caller passes the palette's
 * tokens, so GREY / MONO / FLAT / LINE keep working unchanged. */
static void gw_bevel(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t face, uint16_t hi, uint16_t lo)
{
    cv_rect(x, y, w, h, face);
    cv_rect(x, y, w, 1, hi);
    cv_rect(x, y, 1, h, hi);
    cv_rect(x, y + h - 1, w, 1, lo);
    cv_rect(x + w - 1, y, 1, h, lo);
}
/* (v2.3.9) the diagram pages' depth: a projected shadow, never a stack of copies. One contour and one body, both
 * the shape's own ink dragged toward the background -- the same degradation the curves' back layers use -- sitting 1
 * and 2 px down and right of it, so the box or the bar reads as lifted with the panel still flat behind it. */
static void cv_shadow(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t ink)
{
    if (x + w + 2 > 240) return;                  /* a box against the right edge keeps its 2 px */
    cv_rrect(x + 2, y + 2, w, h, r, ux_mix(ink, T_BG, 74), T_BG);   /* the projection: the ink at 26 % */
    cv_rrect(x + 1, y + 1, w, h, r, ux_mix(ink, T_BG, 86), T_BG);   /* and the contour at its foot, at 14 % */
}
/* a 4 x 4 ordered dither: `pct` of the pixels take `b`, the rest `a`. Its levels are the
 * fixed steps a 16-bit palette had for a gradient, and the pattern never moves, so a static
 * frame stays static (the splash's hold rewrites nothing). */
static void gw_dither(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t a, uint16_t b, int32_t pct)
{
    static const uint8_t BAY[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};
    int32_t i, j;
    if (pct <= 0 || w <= 0 || h <= 0)
        return;
    if (pct >= 100) {
        cv_rect(x, y, w, h, b);
        return;
    }
    for (j = 0; j < h; j++)
        for (i = 0; i < w; i++)
            cv_rect(x + i, y + j, 1, 1, (int32_t)BAY[(j & 3) * 4 + (i & 3)] * 100 / 16 < pct ? b : a);
}
/* (3.6) THE GROUND, ONCE. A screen that sits on a dithered ramp -- HOME's views (hv_grad), FX > BUSES'
 * blocks (fxb_grad) -- was building its own band loop, so the same picture had two implementations and a
 * change to the ramp had to be made twice. This is the one primitive: `n` bands from y to y + h, each
 * dithered between two colours that walk along two ramps (`a` from the panel, `b` from the accent), and
 * only the rows inside [clip_y0, clip_y1) painted, because HOME draws its body in two passes. The last
 * band takes the remainder, so a height that is not a multiple of `n` loses no row. `pct` is the dither: 50
 * is the 4 x 4 checker HOME and FX > BUSES use, where the two tones of a band are close; 100 is a solid band,
 * which is what a page with a grid drawn over the ground needs -- a checker under the sequencer's rows read
 * as dirt on the panel, not as depth (gw_dither fills the band at 100). */
static void ux_ground_bands(int32_t x, int32_t y, int32_t w, int32_t h, int32_t n,
                            int32_t a0, int32_t da, int32_t b0, int32_t db,
                            int32_t clip_y0, int32_t clip_y1, int32_t pct)
{
    int32_t k, band = h / n;
    if (band <= 0 || n <= 0)
        return;
    for (k = 0; k < n; k++) {
        int32_t yy = y + band * k;
        int32_t hh = k == n - 1 ? h - band * (n - 1) : band;
        int32_t y0 = yy < clip_y0 ? clip_y0 : yy;
        int32_t y1 = yy + hh > clip_y1 ? clip_y1 : yy + hh;
        if (y1 <= y0)
            continue;
        gw_dither(x, y0, w, y1 - y0, ux_mix(T_BG, T_SURF, a0 + da * k), ux_mix(T_BG, T_ACCENT, b0 + db * k), pct);
    }
}
/* (FASE 3) THE GROUND, ROW BY ROW. ux_ground_bands walks a colour per BAND, so the ramp jumps once every h/n
 * rows: on HOME's 174 px body twelve bands are 14 px of one colour each, and a 4 x 4 checker on top of that is
 * what read as pixels. This walks the ramp by ROW and fills one run per colour the palette actually has, so the
 * steps are as fine as 16-bit allows (1-4 px) and the cost is a handful of fills, not one per pixel. `a` and `b`
 * are the two ramps (panel, accent) as percentages, and only the rows inside [clip_y0, clip_y1) are painted
 * because HOME draws its body in two passes. */
static void ux_ground_rows(int32_t x, int32_t y, int32_t w, int32_t h,
                           int32_t a0, int32_t a1, int32_t b0, int32_t b1,
                           int32_t clip_y0, int32_t clip_y1, int32_t pct)
{
    int32_t j, y0 = 0, have = 0;
    uint16_t ca = 0, cb = 0;
    if (h <= 0)
        return;
    for (j = 0; j <= h; j++) {
        uint16_t na = 0, nb = 0;
        if (j < h) {
            int32_t k = h > 1 ? j * 100 / (h - 1) : 0;
            /* (FASE 4) DARK-HEAVY, AND THE ACCENT AS A HINT. The ramp was linear, so a 200 px body spent half
             * its height above the middle tone and the panel's ground read as a wash of teal under the content
             * (the spectrum and the curve of HOME had to fight it). Squaring the position keeps most of the
             * height within a few percent of T_BG and spends the lift in the last rows, where it reads as depth
             * instead of as colour; and the accent's band is cut to three quarters for the same reason: the ground
             * should sit under the page, not tie with it. Both changes are here, in the one primitive, so every
             * page that owns a ground moves together. */
            int32_t q = k * k / 100, aa = (a0 + (a1 - a0) * q / 100) * 4 / 5, bb = (b0 + (b1 - b0) * q / 100) / 2;
            na = ux_mix(T_BG, T_SURF, aa);
            nb = ux_mix(T_BG, T_ACCENT, bb);
        }
        if (!have) {
            ca = na, cb = nb, y0 = j, have = 1;
        } else if (j == h || na != ca || nb != cb) {
            int32_t ya = y + y0, yb = y + j;
            if (ya < clip_y0) ya = clip_y0;
            if (yb > clip_y1) yb = clip_y1;
            if (yb > ya)
                gw_dither(x, ya, w, yb - ya, ca, cb, pct);
            if (j < h)
                ca = na, cb = nb, y0 = j;
        }
    }
}
/* (1.2.6) THE COLOUR ux_ground_rows PAINTS AT ROW j, when the rows are solid (pct 100): what a text or an icon
 * sitting on that ground has to be blended over. Passing the plate's T_SURF instead left every glyph with a halo
 * of a colour that was not under it, which is exactly what the layout lint calls an ink on its own tone. */
static uint16_t ux_ground_at(int32_t j, int32_t h, int32_t b0, int32_t b1)
{
    /* (no clamp() here: this file is included before dsp.c in the target's unity object, and that file has its own
     * static clamp -- a call from here would be an implicit declaration of it) */
    int32_t k = 0;
    if (h > 1) {
        if (j < 0) j = 0;
        if (j > h - 1) j = h - 1;
        k = j * 100 / (h - 1);
    }
    k = k * k / 100;                                     /* (FASE 4) the same dark-heavy curve as the rows */
    return ux_mix(T_BG, T_ACCENT, (b0 + (b1 - b0) * k / 100) / 2);
}
/* (FASE 6) A RAMP BETWEEN TWO COLOURS, in `n` solid bands. ux_ground_bands walks two of the palette's own
 * ramps (T_BG -> T_SURF, T_BG -> T_ACCENT) because HOME and FX > BUSES start from the page behind the panel;
 * a page's own panel starts ON T_SURF, so interpolating from T_BG there painted a dark block in the middle of
 * the plate instead of a gradient. This is the general form: from -> to, nothing else assumed. */
/* (FASE 7) the same cache for the panel's ramp: one graph page mixes the whole height once a frame, and the
 * rows were mixing it again every time (`ux_mix` is three saturating channels). Keyed on (rows, from, to). */
static struct {
    int32_t h;
    uint16_t from, to;
    uint16_t g[PLATE_CACHE];
} ramp_cache;
static uint16_t ramp_at(int32_t k, int32_t h, uint16_t from, uint16_t to)
{
    if (h > 1 && h <= PLATE_CACHE) {
        if (ramp_cache.h != h || ramp_cache.from != from || ramp_cache.to != to) {
            int32_t i;
            for (i = 0; i < h; i++) {
                int32_t t = (i + 1) * 100 / (h - 1);
                ramp_cache.g[i] = ux_mix(from, to, t * t / 100);   /* (FASE 4) dark-heavy, as the ground */
            }
            ramp_cache.h = h, ramp_cache.from = from, ramp_cache.to = to;
        }
        return ramp_cache.g[k];
    }
    {
        int32_t t = (k + 1) * 100 / (h > 1 ? h - 1 : 1);
        return ux_mix(from, to, t * t / 100);
    }
}
static void ux_ground_ramp(int32_t x, int32_t y, int32_t w, int32_t h, int32_t n, uint16_t from, uint16_t to, int32_t pct)
{
    int32_t k, y0 = 0;
    uint16_t g, gn;
    (void)n;                                        /* (FASE 3) per row, not per band: `n` is now only a hint */
    if (h < 2)
        return;
    g = ramp_at(0, h, from, to);
    for (k = 1; k < h; k++) {
        gn = ramp_at(k, h, from, to);
        if (gn != g) {
            gw_dither(x, y + y0, w, k - y0, from, g, pct);
            g = gn, y0 = k;
        }
    }
    gw_dither(x, y + y0, w, h - y0, from, g, pct);
}
/* a segmented meter, bottom up: `seg` px blocks with a 1 px gap, the ones under the level
 * lit. The empty blocks are drawn too -- a 16-bit meter always shows its scale. */
static void gw_seg_v(int32_t x, int32_t y, int32_t w, int32_t h, int32_t lvl, int32_t seg,
                     uint16_t on, uint16_t off)
{
    int32_t b;
    for (b = 0; b * (seg + 1) < h; b++) {
        int32_t by = y + h - (b + 1) * seg - b;
        if (by < y)
            break;
        cv_rect(x, by, w, seg, b * (seg + 1) < lvl ? on : off);
    }
}
/* the 4-bit face's cells. The columns that land on the canvas are worked out once per glyph (sx0 .. sx1)
 * and the rows outside the clip are skipped without reading them, so the inner loop has no bounds test:
 * a glyph entirely off the canvas (a scrolled page, the credits) costs nothing but the call. */
static void cv_alpha(int32_t x, int32_t y, uint32_t w, uint32_t h, const uint8_t *d, const uint16_t *rv)
{
    int32_t sx0 = 0, sx1 = (int32_t)w, cw = (int32_t)cv_w;
    uint32_t gx, gy;
    if (x < 0)
        sx0 = -x;
    if (x + (int32_t)w > cw)
        sx1 = cw - x;
    y += cv_oy;
    if (sx0 >= sx1 || y >= cv_cy1 || y + (int32_t)h <= cv_cy0) {
        GFX_HOOK_PIXELS(w * h);
        return;
    }
    for (gy = 0; gy < h; gy++) {
        int32_t py = y + (int32_t)gy;
        uint16_t *row;
        uint32_t k;
        if (py < cv_cy0 || py >= cv_cy1)
            continue;
        row = cv_px + (uint32_t)py * cv_w + x;
        k = gy * w + (uint32_t)sx0;
        for (gx = (uint32_t)sx0; gx < (uint32_t)sx1; gx++, k++) {
            uint32_t v = (d[k >> 1] >> ((k & 1u) ? 0 : 4)) & 15u;
            if (v)
                row[gx] = rv[v];
        }
    }
    GFX_HOOK_PIXELS(w * h);
}

/* the same from a glyph's Huffman-coded bit stream (tools/gen_aa_font.py huff_pack): canonical codes, MSB
 * first; hc = the number of codes of each length 1..15, then the symbols in code order, each a value and
 * its repeat count ((count - 1) << 4 | value: runs of zeros and 15s). Codes of up to 8 bits come from a
 * 256-entry table made once per font in RAM (symbol | length << 8; 0 = a longer code: bit by bit). The
 * stream is read in order, so rows outside the clip are decoded and dropped; a run spans rows */
#define HC_FONTS 3                       /* the codes: the faces M and L (gen_aa_font.py HUFF), the icons (AI_HC) */
static struct { const uint8_t *hc; uint16_t lut[256]; } hc_tab[HC_FONTS];
/* (1.3.2) A "last slot used" cache in front of this search was built and measured: +16 B of XIP (the binding region)
 * for one compare instead of up to three. Refused, docs/BUILD_AC791N.md 8.2: the pointer compare is not what a frame
 * spends. hc_lut keeps the plain search. */
static const uint16_t *hc_lut(const uint8_t *hc)
{
    uint32_t k, len, code = 0, sym = 15, i;
    for (k = 0; k < HC_FONTS - 1u && hc_tab[k].hc && hc_tab[k].hc != hc; k++)
        ;
    if (hc_tab[k].hc != hc) {                        /* (more fonts than slots: the last slot is rebuilt) */
        hc_tab[k].hc = hc;
        for (i = 0; i < 256u; i++)
            hc_tab[k].lut[i] = 0;
        for (len = 1; len <= 8u; len++, code <<= 1)
            for (i = 0; i < hc[len - 1u]; i++, code++, sym++) {
                uint32_t a = code << (8u - len), n = 1u << (8u - len);
                while (n--)
                    hc_tab[k].lut[a + n] = (uint16_t)(hc[sym] | len << 8);
            }
    }
    return hc_tab[k].lut;
}

static void cv_alpha_hc(int32_t x, int32_t y, uint32_t w, uint32_t h, const uint8_t *d, const uint8_t *hc,
                        const uint16_t *rv)
{
    const uint16_t *lut = hc_lut(hc);
    uint32_t gy, v = 0, run = 0, acc = 0, nb = 0;
    y += cv_oy;
    /* (FASE 6) a glyph whose rows and columns all land off the canvas is not decoded at all: the stream is
     * only walked because the pixels had to be read, and a scrolled page (the credits) spends most of its
     * time in cells nothing shows */
    if (y >= cv_cy1 || y + (int32_t)h <= cv_cy0 || x >= (int32_t)cv_w || x + (int32_t)w <= 0) {
        GFX_HOOK_PIXELS(w * h);
        return;
    }
    for (gy = 0; gy < h; gy++) {
        int32_t py = y + (int32_t)gy;
        uint16_t *row = py < cv_cy0 || py >= cv_cy1 ? 0 : cv_px + (uint32_t)py * cv_w;
        uint32_t gx = 0;
        while (gx < w) {
            uint32_t n;
            if (!run) {                              /* the next symbol */
                uint32_t e, s;
                while (nb < 16u) {                   /* (the data ends with 2 spare bytes) */
                    acc = acc << 8 | *d++;
                    nb += 8;
                }
                e = lut[(acc >> (nb - 8u)) & 255u];
                if (e) {
                    nb -= e >> 8;
                    s = e & 255u;
                } else {                             /* a code over 8 bits */
                    uint32_t code = 0, first = 0, idx = 0, len = 0;
                    for (;;) {
                        code |= (acc >> --nb) & 1u;
                        if (code - first < hc[len])
                            break;
                        idx += hc[len];
                        first = (first + hc[len]) << 1;
                        code <<= 1;
                        len++;
                    }
                    s = hc[15u + idx + code - first];
                }
                v = s & 15u;
                run = (s >> 4) + 1u;
            }
            n = run < w - gx ? run : w - gx;
            if (v && row) {
                int32_t px = cv_flip ? x + (int32_t)(w - 1u - gx) : x + (int32_t)gx, dx = cv_flip ? -1 : 1;
                uint32_t k;
                for (k = 0; k < n; k++, px += dx)
                    if ((uint32_t)px < cv_w)
                        row[px] = rv[v];
            }
            gx += n;
            run -= n;
        }
    }
    GFX_HOOK_PIXELS(w * h);
}

/* ------------------------------------------------------------- text --- */
/* the glyph number of ch in f, -1 = not in the face */
static int32_t glyph_at(const aafont_t *f, uint32_t ch)
{
    uint32_t i;
    if (ch >= f->first && ch <= f->last)
        return (int32_t)(ch - f->first);
    for (i = 0; i < f->nex; i++)
        if (f->ex[i] == ch)
            return (int32_t)(f->last - f->first + 1u + i);
    return -1;
}

/* the table entry of ch at phase 0 (its other phases follow it). Not in the face: the ellipsis as '.',
 * else '?', else the face's first glyph (L is sparse: its space) */
static uint32_t glyph(const aafont_t *f, uint32_t ch)
{
    int32_t k;
    if (ch >= 'a' && ch <= 'z' && f->last < 'a')
        ch -= 32u;                                   /* L has capitals only */
    if ((k = glyph_at(f, ch)) < 0 && (ch != (uint8_t)ELLIPSIS || (k = glyph_at(f, '.')) < 0) &&
        (k = glyph_at(f, '?')) < 0)
        k = 0;
    return (uint32_t)k << f->psh;
}

static int32_t kern(const aafont_t *f, uint32_t a, uint32_t b)       /* 1/16 px */
{
    uint32_t key = (a << 8) | b, lo = 0, hi = f->nk;
    while (lo < hi) {
        uint32_t m = (lo + hi) / 2u;
        if (f->kkey[m] == key)
            return f->kd[m];
        if (f->kkey[m] < key)
            lo = m + 1u;
        else
            hi = m;
    }
    return 0;
}

static uint32_t fold(const aafont_t *f, uint32_t c) { return c >= 'a' && c <= 'z' && f->last < 'a' ? c - 32u : c; }

/* the x advance of glyph i, 1/16 px, from the byte- or word-wide table the face carries */
static uint32_t advance(const aafont_t *f, uint32_t i)
{
    return f->adv8 ? ((const uint8_t *)f->adv)[i] : ((const uint16_t *)f->adv)[i];
}

static int32_t text_w(const aafont_t *f, const char *s)
{
    int32_t pen = 0;
    uint32_t prev = 0;
    for (; *s; s++) {
        uint32_t c = fold(f, (uint8_t)*s);
        if (prev)
            pen += kern(f, prev, c);
        pen += advance(f, glyph(f, c) >> f->psh);
        prev = c;
    }
    return (pen + 8) >> 4;
}

static int32_t text_run(int32_t x, int32_t y, const aafont_t *f, const char *s, const uint16_t *rv, int32_t *bb)
{
    int32_t pen = 0, err = 0, x0 = 0x7FFF, y0 = 0x7FFF, x1 = -0x7FFF, y1 = -0x7FFF;
    const int32_t step = 16 >> f->psh;
    uint32_t prev = 0;
    for (; *s; s++) {
        uint32_t c = fold(f, (uint8_t)*s), gi = glyph(f, c);
        const aag_t *g;
        int32_t pos, d0, d1;
        if (prev)
            pen += kern(f, prev, c);
        g = &f->g[gi];
        if (f->psh && g[1].off != g->off) {
            pos = pen - (pen & (step - 1));          /* the phase position at or left of the pen */
            d0 = pos - pen - err;                    /* .. and the one right of it: which keeps the gap truer */
            d1 = d0 + step;
            if ((d0 < 0 ? -d0 : d0) > (d1 < 0 ? -d1 : d1))
                pos += step;
            g += ((uint32_t)pos >> (4u - f->psh)) & ((1u << f->psh) - 1u);
        } else {
            pos = (pen + 8) & ~15;                   /* one phase (figures, ., blanks): the rounded pen */
        }
        err = pos - pen;
        if (g->bw) {
            int32_t gx = x + (pos >> 4) + g->bx, gy = y + g->by;
            if (!rv)
                ;                                    /* (text_ink: measured only) */
            else if (f->hc)
                cv_alpha_hc(gx, gy, g->bw, g->bh, f->data + g->off, f->hc, rv);
            else
                cv_alpha(gx, gy, g->bw, g->bh, f->data + g->off, rv);
            if (gx < x0) x0 = gx;
            if (gx + g->bw > x1) x1 = gx + g->bw;
            if (GFX_HOOKS && gy < y0) y0 = gy;       /* (the rows: for the host's lint only) */
            if (GFX_HOOKS && gy + g->bh > y1) y1 = gy + g->bh;
        }
        pen += advance(f, gi >> f->psh);
        prev = c;
    }
    bb[0] = x0;
    bb[2] = x1;
    if (GFX_HOOKS) {
        bb[1] = y0;
        bb[3] = y1;
    }
    return pen;
}
/* y = top of the line box (the baseline is y + f->asc); returns the pen x at the end.
 * fg on bg: bg is what lies under the text (the canvas, a card, a selection).
 * Placement (text_run): the pen (1/16 px) lies between two phase positions a step (16 >> psh) apart; the glyph takes
 * the one whose offset from the pen is nearer the previous glyph's offset, so the space between neighbours stays
 * truest and no glyph is a whole step from its true place (tools/aa_raster.py, text_spacing_test.py).
 * A glyph with one phase (its phases share one bitmap: figures and .) sits at the rounded pen, as when it
 * is drawn alone at text_w of what precedes it (ui_draw.c roll_text). */
static int32_t cv_text_flags(int32_t x, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg,
                             uint32_t flags)
{
    int32_t b[4], pen = text_run(x, y, f, s, ramp(fg, bg, 0), b);
    if (GFX_HOOKS && b[2] > b[0]) {
        int32_t y0 = b[1], y1 = b[3];
        if (b[0] < 0 || b[2] > (int32_t)cv_w || y0 + cv_oy < cv_cy0 || y1 + cv_oy > cv_cy1)
            flags |= 2u;                             /* cut by the canvas */
        if (cv_scroll) {                             /* a scrolled view: what lands on the screen is its visible part */
            flags |= 32u;
            if (y0 + cv_oy < cv_cy0) y0 = cv_cy0 - cv_oy;
            if (y1 + cv_oy > cv_cy1) y1 = cv_cy1 - cv_oy;
        }
        GFX_HOOK_PEN(y, f);
        GFX_HOOK_TEXT(b[0], y0 + cv_oy, b[2], y1 + cv_oy, s, flags);
    }
    (void)flags;
    return x + ((pen + 8) >> 4);
}
static int32_t cv_text_on(int32_t x, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg)
{
    return cv_text_flags(x, y, f, s, fg, bg, 0);
}
/* .. on the canvas background */
static int32_t cv_text(int32_t x, int32_t y, const aafont_t *f, const char *s, uint16_t fg)
{
    return cv_text_flags(x, y, f, s, fg, cv_bg, 0);
}
/* right-aligned: the advance ends at xr */
static int32_t cv_text_r(int32_t xr, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg)
{
    int32_t w = text_w(f, s);
    cv_text_on(xr - w, y, f, s, fg, bg);
    return xr - w;
}
/* (centred: cv_text_in, by the ink; by the advance a text sat up to 1.5 px off) */

/* centring by ink: the ink of s in f drawn at (0, 0) across (b[0] .. b[2], past it; b[2] <= b[0]: none); up and down
 * a text is centred by its face's capitals' band (AF_S_CAP_Y ..: the ink of H; figures and round letters reach at most
 * a faint row past it), so the words of a row keep one baseline */
static void text_ink(const aafont_t *f, const char *s, int32_t *b) { text_run(0, 0, f, s, 0, b); }
#define HALF_UP(v) ((v) >> 1)                       /* half, a pixel left over going left / up (also below 0) */
/* the line top that centres face F's (S M) capitals' band in h rows (a row, a cell, a button): constant */
#define CAP_IN(F, h) (HALF_UP((h) - AF_##F##_CAP_H) - AF_##F##_CAP_Y)
/* the pen x that centres s's ink in w px */
static int32_t ink_in(const aafont_t *f, const char *s, int32_t w)
{
    int32_t b[4];
    text_ink(f, s, b);
    return HALF_UP(w - (b[2] - b[0])) - b[0];
}
/* s with its ink centred across x0 .. x0 + w (y: its line top, CAP_IN to centre it up and down too); a pixel left
 * over goes left / up, as everywhere (the cushions too) */
static int32_t cv_text_in(int32_t x0, int32_t y, int32_t w, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg)
{
    return cv_text_on(x0 + ink_in(f, s, w), y, f, s, fg, bg);
}

/* s into d (n bytes), at most maxw px wide: never a smaller font, the end ellipsised. 1 = cut */
static int text_fit(char *d, uint32_t n, const char *s, const aafont_t *f, int32_t maxw)
{
    uint32_t k = 0;
    while (s[k] && k + 1u < n) {
        d[k] = s[k];
        k++;
    }
    d[k] = 0;
    if (!s[k] && text_w(f, d) <= maxw)
        return 0;
    if (k + 2u > n)
        k = n - 2u;
    for (;;) {                                       /* drop characters until "text..." fits */
        while (k && d[k - 1u] == ' ')
            k--;
        d[k] = ELLIPSIS;
        d[k + 1u] = 0;
        if (!k || text_w(f, d) <= maxw)
            return 1;
        k--;
    }
}
/* text in maxw px, ellipsised when it is longer: a label or a value should always fit (the host
 * layout lint reports a cut one), free text (cv_free_text: a preset name, a message) may be cut */
static int32_t cv_text_fit(int32_t x, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg,
                           int32_t maxw)
{
    char b[48];
    int cut = text_fit(b, sizeof b, s, f, maxw);
    return cv_text_flags(x, y, f, b, fg, bg, cut ? 1u : 0u);
}
/* (1.2.6) THE SAME FACE, BOLDER. The four knob cards' labels were the thinnest ink on their own card -- 12 px of a
 * light face beside a value in the 15 px one -- and the owner asked for them heavier. A second weight in flash was
 * not the way: the face's bitmaps are the bulk of the font in XIP and the image was closing with 1 276 B of margin.
 * The same fit and the same glyphs are drawn, with the coverage CURVE_BOLD gives: the ink box the layout lint reads
 * is the plain one (same masks, same advance), the letters just read heavier, and nothing about the card moves. */
static int32_t cv_text_fit_bold(int32_t x, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg,
                                int32_t maxw)
{
    char b[48];
    int cut = text_fit(b, sizeof b, s, f, maxw), e;
    cv_bold = 1;
    e = cv_text_flags(x, y, f, b, fg, bg, cut ? 1u : 0u);
    cv_bold = 0;
    return e;
}
static int32_t cv_free_text(int32_t x, int32_t y, const aafont_t *f, const char *s, uint16_t fg, uint16_t bg,
                            int32_t maxw)
{
    char b[48];
    int cut = text_fit(b, sizeof b, s, f, maxw);
    return cv_text_flags(x, y, f, b, fg, bg, cut ? 9u : 8u);
}

/* ---------------------------------------------------------- keycaps --- */
/* a pre-rendered pill (tools/gen_aa_keycaps.py): nibble 0 outside, 1..4 the edge over `under`, 5 the fill,
 * 6..15 the label over the fill; the 16 colours per (under, fill, ink) are cached like the text ramps */
#define NKRAMP 4u
static struct {
    uint16_t key[NKRAMP][3], v[NKRAMP][16];
    uint32_t gen;
    uint8_t next, n;
} kr __attribute__((unused));      /* (zero-initialised; outside .bss) */
static const uint16_t *kc_ramp(uint16_t under, uint16_t fill, uint16_t ink)
{
    uint32_t i, a;
    uint16_t *v;
    if (ink == fill)                             /* (as ramp) */
        ink = ux.bg;
    GFX_HOOK_INK(ink, fill);
    if (kr.gen != ux.gen) {
        kr.gen = ux.gen;
        kr.n = kr.next = 0;
    }
    for (i = 0; i < kr.n; i++)
        if (kr.key[i][0] == under && kr.key[i][1] == fill && kr.key[i][2] == ink)
            return kr.v[i];
    i = kr.next;
    kr.next = (uint8_t)((i + 1u) % NKRAMP);
    if (kr.n < NKRAMP)
        kr.n++;
    kr.key[i][0] = under;
    kr.key[i][1] = fill;
    kr.key[i][2] = ink;
    v = kr.v[i];
    v[0] = swap16(under);
    for (a = 1; a < 16u; a++) {
        int32_t p = a < 5u ? (int32_t)a * 20 : (int32_t)(a - 5u) * 10;
        v[a] = swap16(a < 5u ? ux_mix(under, fill, p) : ux_mix(fill, ink, p));
    }
    return v;
}
static int32_t kc_w(uint32_t id) { return id < KC_COUNT ? KC[id].w : 0; }
/* keycap / badge `id` with its top-left at (x, y), KC_H tall: fill and label tinted with tokens, `under` what lies
 * behind its corners; returns its right edge */
static int32_t cv_keycap(int32_t x, int32_t y, uint32_t id, uint16_t fill, uint16_t ink, uint16_t under)
{
    const kc_t *k = &KC[id < KC_COUNT ? id : 0u];
    const uint16_t *rv = kc_ramp(under, fill, ink);
    /* (FASE 4) the pills are Huffman-coded like the glyphs (a run of the fill and a run of what is
     * outside are most of a pill), so they decode with the same table-free walker: the same pixels, 1 947
     * B less of constants (tools/gen_aa_keycaps.py, runs 0/5) */
    cv_alpha_hc(x, y, k->w, KC_H, KC_DATA + k->off, KC_HC, rv);
    if (x < 0 || x + k->w > (int32_t)cv_w || y + cv_oy < 0 || y + KC_H + cv_oy > (int32_t)cv_h)
        GFX_HOOK_TEXT(x, y + cv_oy, x + k->w, y + KC_H + cv_oy, k->label, 6u);      /* cut by the canvas */
    else
        GFX_HOOK_TEXT(x, y + cv_oy, x + k->w, y + KC_H + cv_oy, k->label, 4u);
    return x + k->w;
}

/* a key hint: the keycap, then what it does (S, TEXT); unavailable: a DIM keycap and a DIM word. The word sits on
 * the keycap's centre line (S caps 9 rows, the keycap's 7). act may be 0 (the keycap alone); returns the end x */
#define KH_GAP 4                                  /* keycap -> its word */
static int32_t kh_w(uint32_t id, const char *act) { return kc_w(id) + (act && act[0] ? KH_GAP + text_w(&AF_S, act) : 0); }
/* .. its ink: the keycap to the word's last inked column (centring a hint by what is seen) */
static int32_t kh_ink(uint32_t id, const char *act)
{
    int32_t b[4];
    if (!act || !act[0])
        return kc_w(id);
    text_ink(&AF_S, act, b);
    return kc_w(id) + KH_GAP + b[2];
}
static int32_t cv_key_hint(int32_t x, int32_t y, uint32_t id, const char *act, int on, uint16_t under)
{
    x = cv_keycap(x, y, id, on ? T_KEY : T_DIM, T_INK, under);
    if (act && act[0]) {
        GFX_HOOK_ALIGN(0, y, 0, y + KC_H, AL_V | AL_PASS, "key hint word on its keycap's line");
        x = cv_text_on(x + KH_GAP, y - 1, &AF_S, act, on ? T_TEXT : T_DIM, under);
    }
    return x;
}
/* a row of key hints from x0 to x1: the first at x0, the last ending at x1, the space shared between them. When
 * the row is too wide the action words go first, from the last hint back (the keycaps never shrink).
 * on: a bit per hint (1 = available) */
typedef struct { uint8_t key; const char *act; } khint_t;
static void cv_key_row(int32_t x0, int32_t x1, int32_t y, const khint_t *h, uint32_t n, uint32_t on, uint16_t under)
{
    uint32_t i, words = n;                         /* hints 0 .. words-1 keep their word */
    int32_t w, gap, x = x0;
    for (;;) {
        w = 0;
        for (i = 0; i < n; i++)
            w += kh_w(h[i].key, i < words ? h[i].act : 0);
        if (w + 6 * (int32_t)(n - 1u) <= x1 - x0 || !words)
            break;
        words--;
    }
    gap = n > 1u ? (x1 - x0 - w) / (int32_t)(n - 1u) : 0;
    for (i = 0; i < n; i++) {
        if (n > 1u && i + 1u == n)
            x = x1 - kh_w(h[i].key, i < words ? h[i].act : 0);   /* the last one flush right */
        x = cv_key_hint(x, y, h[i].key, i < words ? h[i].act : 0, (on >> i) & 1u, under) + gap;
    }
}

/* "[OCT+]..." -> the keycap's id and the length of the bracket, else -1 (a bracketed word that is no keycap is text) */
static int32_t kc_tag(const char *s, uint32_t *len)
{
    uint32_t i, n;
    if (s[0] != '[')
        return -1;
    for (n = 1; s[n] && s[n] != ']'; n++)
        if (n > 8u)
            return -1;
    if (s[n] != ']')
        return -1;
    for (i = 0; i < KC_COUNT; i++) {
        const char *l = KC[i].label;
        uint32_t k = 0;
        while (k + 1u < n && l[k] == s[k + 1u])
            k++;
        if (k + 1u == n && !l[k]) {
            *len = n + 1u;
            return (int32_t)i;
        }
    }
    return -1;
}
/* free text (S) that may start with a keycap, "[SAVE] HOLD TO UNDO", or have one after its first word,
 * "HOLD [GLO] QUICK": the word, the keycap, then the rest, cut to maxw */
static int32_t cv_free_hint(int32_t x, int32_t y, const char *s, uint16_t fg, uint16_t bg, int32_t maxw)
{
    uint32_t n, i;
    int32_t id = kc_tag(s, &n), x0 = x;
    for (i = 0; id < 0 && i < 7u && s[i] && s[i] != ' '; i++)
        ;
    if (id < 0 && i && s[i] == ' ' && (id = kc_tag(s + i + 1u, &n)) >= 0) {
        char w[8] = {0};
        uint32_t j;
        for (j = 0; j < i; j++)
            w[j] = s[j];
        GFX_HOOK_ALIGN(0, y + 1, 0, y + 1 + KC_H, AL_V | AL_PASS, "free hint words on the keycap's line");
        x = cv_text_on(x, y, &AF_S, w, fg, bg) + KH_GAP;
        s += i + 1u;
    }
    if (id >= 0 && kc_w((uint32_t)id) + KH_GAP < maxw - (x - x0)) {
        x = cv_keycap(x, y + 1, (uint32_t)id, T_KEY, T_INK, bg) + KH_GAP;
        s += n;
        while (*s == ' ')
            s++;
        if (!*s)
            return x - KH_GAP;
        GFX_HOOK_ALIGN(0, y + 1, 0, y + 1 + KC_H, AL_V | AL_PASS, "free hint words on the keycap's line");
    }
    return cv_free_text(x, y, &AF_S, s, fg, bg, maxw - (x - x0));
}

/* one-shot: a line of text in a box of colour bg, blitted (align: 0 left, 1 centre, 2 right) */
static void draw_text_line(uint32_t x, uint32_t y, uint32_t w, const aafont_t *f, const char *s,
                           uint16_t c, uint16_t bg, int align)
{
    int32_t tw = text_w(f, s), tx = 0;
    cv_begin(w, f->h, bg);
    if (align == 1) {
        tx = ink_in(f, s, (int32_t)w);
        GFX_HOOK_ALIGN(0, 0, (int32_t)w, 0, AL_H, "one-shot line centred");
    }
    else if (align == 2)
        tx = (int32_t)w - tw;
    cv_text(tx, 0, f, s, c);
    cv_blit(x, y);
    lcd_sync();                     /* one-shots (boot, crash, UBOOT, update) finish here */
}
static void draw_text_box(uint32_t x, uint32_t y, uint32_t w, const aafont_t *f, const char *s,
                          uint16_t c, int align)
{
    draw_text_line(x, y, w, f, s, c, T_BG, align);
}
