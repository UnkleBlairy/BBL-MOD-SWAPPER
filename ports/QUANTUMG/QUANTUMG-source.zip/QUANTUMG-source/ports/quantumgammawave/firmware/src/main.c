/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* FELUCCA boot and main loop. Boot order: WDT first, boot-loop guard, fatal vectors,
 * guards; then LCD, input (TIMER5 IRQ, 10 kHz), audio (ALNK0 IRQ). */
extern uint32_t _data_start[], _data_end[], _data_load[], _bss_start[], _bss_end[];
extern uint32_t _pool_start[], _pool_end[], _rt_start[], _rt_end[], _rt_load[];
#if FELUCCA_DUAL_CORE
extern uint32_t _c1t_start[], _c1t_end[], _c1t_load[];   /* (0.6.71) the second core's loop (app.ld .c1_text) */
extern uint32_t _hot_start[], _hot_end[], _hot_load[];   /* (0.6.78) core 0's hottest audio code (app.ld .hot_text) */
extern uint32_t _low_start[], _low_end[];                /* (0.6.78) main-loop buffers below the RAM code (app.ld) */
#endif


/* TIMER5 outranks ALNK0, so the scan keeps its 100 us pace while a half buffer renders: before,
 * the ticks stopped for the whole render (0.7 ms idle, several ms loaded), the column lit when it
 * began stayed lit that long (a ~16 Hz flicker over all LEDs, beating with the scan) and the
 * encoders lost frames. Nested in ALNK0 it only scans (GPIO + fm1_in, nothing the audio ISR touches)
 * and counts ms; USB and UART polls wait for the first tick after the render, as they always did,
 * and the time spent nested is handed to the audio ISR so its load figures stay render-only.
 * The USB audio stream cannot wait for the render (one packet per 1 ms frame, a render takes up to
 * ~5 ms): uac_service also runs nested. It touches only EP4 (INDEX is set on every access) and the
 * consumer side of the audio ring, and usb_poll never runs nested, so the two never interleave. */
void fm1_timer5_irq(void)
{
    static uint32_t sub, owed;
    uint32_t t0 = fm1_ticks(), ph = sub % 5u, usb_due = ph == 0u;   /* (FASE 1) the modulo once, not twice */
    fm1_timer5_ack();
    felucca_dbg.timer_irqs++;
    fm1_input_tick();
    {   /* milliseconds from the 24 MHz TIMER4 (robust to a late tick) */
        static uint32_t last, acc;
        acc += t0 - last;
        last = t0;
        while (acc >= 1000u * FM1_TICKS_PER_US) {
            acc -= 1000u * FM1_TICKS_PER_US;
            fm1_ms++;
        }
    }
    if (usb_due)
        owed |= 1u;                             /* 2 kHz: all USB SIE traffic lives here */
#if FELUCCA_UART
    if (ph == 2u)
        owed |= 2u;                             /* 2 kHz: <= ~7 bytes per call at 31250 baud */
#endif
    if (++sub == 10u)
        sub = 0;
    if (felucca_dbg.in_audio) {
        felucca_dbg.nested++;
#if FELUCCA_UAC
        if (usb_due)
            uac_service();
#endif
        t5_nested_ticks += fm1_ticks() - t0;
        return;
    }
    if (owed & 1u)
        usb_poll();
#if FELUCCA_UART
    if (owed & 2u)
        uart_midi_poll();
#endif
    owed = 0;
}
extern void isr_timer5(void);

static void timer5_start(void)                 /* OSC /4 = 6 MHz, PRD 600 -> 10 kHz */
{
    fm1_timer5_start(isr_timer5, 4);   /* above ALNK0 (3): the scan nests into the render (see fm1_timer5_irq) */
}

static void hexs(char *b, uint32_t v)
{
    uint32_t i;
    for (i = 0; i < 8u; i++)
        b[i] = "0123456789ABCDEF"[(v >> (28u - 4u * i)) & 15u];
    b[8] = 0;
}

static void fm1_fault(const fm1_crash_t *c)
{
    char b[12];
    uint32_t t0;
#if FELUCCA_DUAL_CORE
    if (fm1_mc_on)
        fm1_mc_bar_set();                             /* (0.6.71) a crash beside the second core: one core until power-off */
    fm1_mc_hold();
#endif
    fm1_audio_stop();
    scr_wake_now();                                   /* (MENU > SCREEN OFF: the panel on first) */
    lcd_fill(0, 0, 240, 240, UI_CRASH_BG);            /* fixed, outside the palettes */
    draw_text_line(0, 8, 240, &AF_M, "GAMMAWAVE CRASH", UI_CRASH_INK, UI_CRASH_BG, 1);
    hexs(b, c->vec);
    draw_text_line(10, 40, 220, &AF_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->pc);
    draw_text_line(10, 60, 220, &AF_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->emu);
    draw_text_line(10, 84, 220, &AF_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->dbg);
    draw_text_line(10, 102, 220, &AF_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->rets);
    draw_text_line(10, 120, 220, &AF_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    t0 = fm1_ticks();
    while ((uint32_t)(fm1_ticks() - t0) < 4000u * 1000u * FM1_TICKS_PER_US)
        ;
    fm1_reboot();
}

/* power-on: the parts with their engines' defaults and first sounds (TRK_DEF's engines; JIANT 0.6.40: as INIT SYSTEM,
 * was TRK_DEF's presets); the sequencers empty. RESTORE LAST ON brings the last session back after (autosave_boot) */
static void felucca_init(void)
{
    uint32_t i;
    if (song_idx.magic == SONG_MAGIC && song_cur < NSONG && chain_valid(&song_idx.rows[song_cur]))
        chain_config = song_idx.rows[song_cur];       /* (JIANT 0.6.81) the song's rows as persist_boot read them (it
                                                       * runs first): reset here, the main loop then saved the empty
                                                       * rows over them, the ARRANGE lost at every power-on */
    else
        chain_defaults(&chain_config);
    for (i = 0; i < G_COUNT; i++)
        song.g[i] = GP[i].def;
    voices_boot();                            /* (3.5) the voice pool: every part's window, the inert slot */
    load_depth++;                             /* (the power-on loads: one outer load) */
    fm6_init();                               /* every track's FM6 patch: the init voice */
    wt_gen_init();                            /* (FASE 1, FASE 6) WAVETABLE's band limits: built here, not stored */
    /* (FASE 1/8, 2026-11-21) The two curves are already decoded by voices_boot() -- it calls sine_init() and
     * fm6_exp2_init() because every host harness enters through it -- and nothing between that call and this
     * point writes either table (fm6_init reads the exp2 curve, wt_gen_init builds band limits elsewhere).
     * The second pair of calls rebuilt 1 025 sine differences and 2 054 exp2 points for nothing at every
     * power-on; they are gone. */
    for (i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        track_defaults(t);
        init_sound_of(t, TRK_DEF[i][0]);      /* (0.6.49: as INIT SOUND: the engine's defaults, dry, FM6 the init
                                               * voice; was its first preset with its sends) */
        t->engine = t->eng_req;
        track_defaults_steps(t);              /* (a sound load never touches them) */
        if (TRK_DEF[i][2])
            load_pat16(t, PATTERNS[TRK_DEF[i][2] - 1u].note, PATTERNS[TRK_DEF[i][2] - 1u].flags);
        pat_sig[i] = steps_sig(t);            /* a default pattern, not the user's */
        pat_last[i] = TRK_DEF[i][2];
    }
    load_depth--;
    song.sel = 0;
    song.master_q12 = 2048;                   /* (the pot's level replaces it before the audio starts: master_boot) */
    ui.home = 1;
    ui.force = 1;
}

/* The power-on LED sweep (1.1, hal/fm1_led_anim.h: a soft light over the keys left to right, then the buttons swell
 * and settle on the glow; ~0.70 s), started before the scan and run by it: nothing waits for it, the splash's ~2 s (JIANT 0.5: the signature written, then held)
 * and the first ~0.27 s of the UI go by under it (the UI's LEDs from its end, or at once on a key or a button down).
 * Every LEDS setting: it is no idle glow; with DIM HI / DIM LO it ends on that glow (and is drawn over that glow
 * level), with OFF / INV dark. Not with MENU > ANIM OFF (no motion: the LEDs as the UI has them at once), not after a crash (a crash record newer than the last boot saw: the crash screen's
 * reset), a hang (a WDT reset) or a failed boot (bootguard: the last one died within its first 30 s): straight to the
 * UI. The UBOOT paths never get here. */
static uint32_t crash_seen __attribute__((unused));   /* fm1_crash.count at the last boot */
static uint8_t boot_clean;                    /* no crash, hang (WDT) or failed boot before this one (boot_leds):
                                               * the sweep runs and the autosave is restored (project.c autosave_boot) */
static void boot_leds(void)
{
    uint32_t crashed = fm1_crash.magic == FM1_CRASH_MAGIC && fm1_crash.count != crash_seen;
    crash_seen = fm1_crash.count;
    boot_clean = !crashed && !bootguard.failed && !(fm1_boot.p3_rst & 4u);
    fm1_led_dim_level(settings_leds == LEDS_DIM_LO);
    if (boot_clean && !(ui_prefs & PREF_ANIM_OFF))
        fm1_led_anim_start(settings_leds == LEDS_DIM || settings_leds == LEDS_DIM_LO);
}

/* (FASE 2/5) THE SPLASH'S OWN CLOCK, from TIMER4 and from the frame's first pixel.
 * It was the millisecond counter, and that one only starts with TIMER5 (timer5_start, half way down
 * this function). So everything between draw_splash() and timer5_start -- the input and ADC setup, the
 * panel, the engines' boot, AUDIO, USB, the LED sweep, the guard, the second core -- ran while the
 * counter stood at 0: the picture was already on screen, and it sat on its first frame for all of it.
 * That dead second or two before the animation moved is what the report was about; the timer itself was
 * never the problem. The stages below now paint the splash as they finish, and the deadline is measured
 * from the first pixel, so the same seconds are not then spent again in the timed loop. */
static uint32_t spl_t0_us;
static void splash_step(void)
{
    if (ui_splash != 2u)
        splash_write((fm1_micros() - spl_t0_us) / 1000u);
}

static void fm1_main(void)
{
    persist_boot();
#if FELUCCA_OTA
    if (flash_ok)
        ota_boot_cleanup();                             /* staging area left by an update */
#endif
    settings_init();
    prefs_update();                                     /* (JIANT 0.6.44) FX LATCH ON by default, once */
    usb_serial_apply();                                 /* (#67: the saved USB SERIAL before usb_start) */
    lcd_init(T_BG);                                /* (QG-1 v1.5) the whole 240x320 in the theme's background */
    spl_anim = ui_splash == 0u;                        /* (JIANT 0.5) the signature written: splash_write. (v1.5)
                                                        * FULL writes it on; SHORT and OFF have it whole */
    if (ui_splash != 2u) {                            /* (v1.5) STARTUP SPLASH OFF: no splash at all -- lcd_init has
                                                        * already brought the panel up, so the hardware init is the
                                                        * same in all three; the UI below redraws from a clean frame */
        draw_splash();                                /* ui_draw.c (1.1.5) */
        spl_t0_us = fm1_micros();                     /* (FASE 2/5) the clock starts at this pixel */
    }
    if (felucca_dbg.magic != DBG_MAGIC) {
        memset(&felucca_dbg, 0, sizeof felucca_dbg);
        felucca_dbg.magic = DBG_MAGIC;
    }
    felucca_dbg.boots++;
    felucca_dbg.max_us = 0;
    felucca_dbg.in_audio = 0;                       /* .noinit: a reset inside the audio ISR left it set, and
                                                       TIMER5 would treat every tick as nested (no USB poll) */
    felucca_dbg.prev_stage = felucca_dbg.stage;     /* a WDT reset leaves the last breadcrumb here */
    felucca_dbg.prev_page = felucca_dbg.page;
    felucca_dbg.prev_home = felucca_dbg.home;
    felucca_dbg.prev_frames = felucca_dbg.ui_frames;
    felucca_dbg.prev_rst = fm1_boot.p3_rst;
    fm1_input_init();
    fm1_adc_init();
    panel_init();
    splash_step();
    felucca_init();
    master_boot();
    kb_boot_hold = 1;                         /* #137: no notes from the keys before the UI (seq.c keyboard_block) */
    audio_boot_hold();                        /* (1.4.12) silence through the interrupts-off stages: armed by default
                                               * for every other caller, held here until audio_fade_in() below. (FASE 2)
                                               * BEFORE audio_init, not after it: fm1_audio_init starts the engine and
                                               * unmutes the output stage (pc6) 25 ms later, and it renders those 25 ms
                                               * through audio_block -- with the gate armed it advanced the 27 ms fade to
                                               * 92 % on the very block before the unmute, so the open amp met a DAC
                                               * already 92 % in and the fade it exists for was spent behind a mute. Held
                                               * first, every block of the bring-up is exact digital silence and the
                                               * unmute lands on zeros whatever the codec's own offset does. */
    audio_init();
    splash_step();
    usb_start();
    splash_step();
#if FELUCCA_UART
    uart_midi_init();
#endif
    boot_leds();
    timer5_start();
    fm1_guard_lock_top();
    fm1_irq_enable_all();
    fm1_delay_ms(30);
    if ((fm1_in.buttons & 3u) == 3u) {
        panel_setup();                        /* OCT- + OCT+ held at power-on */
        settings_save();
    }
#if FELUCCA_DUAL_CORE
    /* (0.6.71) the second core, unless REC is held at power-on (one core this session: mc_off), a boot failed (a second
     * would enter UBOOT), or it was given up / beside a crash since power-on (hal/fm1_multicore.h fm1_mc_bar). Its entry
     * word is in the protected top of RAM: opened for it, interrupts off (up to 20 ms: under the splash)
     * (QG-1 v1.5) MENU > CPU MODE decides the request: AUTO keeps the power-on key as the session's opt-out (what it
     * has always done), DUAL CORE asks for the second core whatever that key does, SAFE SINGLE never starts it. In
     * every mode a core that has failed still wins: fm1_mc_barred() (given up or beside a crash since power-on) and a
     * failed boot are never overridden, so no setting can force a core that did not come up. */
    mc_off = (uint8_t)(ui_cpu_mode == 2u ||
                       (ui_cpu_mode != 1u && (fm1_in.buttons >> panel.btn[B_REC]) & 1u));
    if (!mc_off && !bootguard.failed && !fm1_mc_barred()) {
        fm1_irq_off();
        fm1_guard_unlock_top();
        fm1_mc_start();
        fm1_guard_lock_top();
        fm1_irq_on();
    }
#endif
    /* (FASE 3) THE OUTPUT OPENS HERE, ON ZEROS. Everything above ran with the DAC silent: the unmute inside
     * fm1_audio_init happened on zeros, and the second core's start (interrupts off) dropped its halves on
     * zeros too. From this line the master ramps 0 -> full in ~27 ms, which lands inside the splash's hold. */
    audio_fade_in();
    /* (v2.9.7) THE BOOT RUNS UNDER THE PICTURE, one stage a frame. The splash already painted itself as
     * the earlier stages finished, but the three that reach the flash -- the autosave's read, the TAKES
     * reel and the session's dice -- all ran before the animation took a single step, so the picture sat
     * on its first frame for the whole SPI read. They are now the loop's own work: a frame is written,
     * then one stage runs, then the next frame. The order of the stages is untouched (autosave, reel,
     * dice: the dice still mixes the ticks of a boot that has read the session), and the clock is still
     * the one that starts at the first pixel, so nothing is added to the boot's length -- the work moves
     * into the frames that were already being waited for. A stalled clock still runs every stage once,
     * after the loop: no path leaves the music unread. */
    {
        uint32_t n, stage = 0u, now;
        uint32_t span = ui_splash == 2u ? 0u : ui_splash == 1u ? SPL_SHORT : SPL_WRITE + SPL_HOLD;
        uint32_t el = (fm1_micros() - spl_t0_us) / 1000u;
        if (ui_splash == 0u && el + SPL_FADE > span)
            span = el + SPL_FADE;
        /* (1.4) The bound follows the span. It was a flat 600 steps of 4 ms (2.4 s) while STARTUP SPLASH FULL
         * runs SPL_WRITE + SPL_HOLD (4.5 s): the loop stopped 2.1 s before the art was written, so the boot
         * handed over to HOME with the signature half drawn -- a short splash whatever the menu said. */
        for (n = 0; n < span / 4u + 400u; n++) {
            if (stage == 0u) {
                autosave_boot(boot_clean);              /* (1.2) the last session's music */
                stage = 1u;
            } else if (stage == 1u) {
#if FELUCCA_FLASH
                reel_boot();                            /* (1.0-GW TAKES v2) the TAKES reel and its SET */
#endif
                stage = 2u;
            } else if (stage == 2u) {
                session_dice(fm1_ticks() ^ (uint32_t)fm1_adc_read(FM1_ADC_BATT) << 16);  /* (JIANT 0.4) */
                stage = 3u;
            }
            now = (fm1_micros() - spl_t0_us) / 1000u;
            splash_write(now);
            if (stage >= 3u && now >= span)
                break;
            fm1_delay_ms(4);
            master_poll();                              /* (MIDI IN plays under it) */
        }
        if (stage < 1u) {                               /* a stalled clock: the frames are over, the boot is not */
            autosave_boot(boot_clean);
            stage = 1u;
        }
        if (stage < 2u) {
#if FELUCCA_FLASH
            reel_boot();
#endif
            stage = 2u;
        }
        if (stage < 3u)
            session_dice(fm1_ticks() ^ (uint32_t)fm1_adc_read(FM1_ADC_BATT) << 16);
    }
    kb_boot_hold = 0;
    lcd_fill(0, 0, 240, 240, T_BG);
    scrn.idle = fm1_ms;                        /* (MENU > SCREEN OFF: from here) */

    for (;;) {
        uint32_t m = fm1_ms;
        fm1_wdt_feed();
        usb_retry(fm1_ms);
        if (fm1_ms > 30000u && bootguard.pending) {     /* a crash or hang in the first 30 s counts */
            bootguard.pending = 0;
            bootguard.failed = 0;
        }
        {
            int32_t b = fm1_adc_read(FM1_ADC_BATT);     /* battery: slow IIR */
            if (b > 0)
                song.batt_raw = song.batt_raw ? song.batt_raw + (b - song.batt_raw) / 32 : b;
        }
        master_poll();
        cpu_mode_step();                           /* (FASE 3) MENU > CPU MODE asked for a start / a stop */
        {   /* OCT- + OCT+ held 5 s: enter UBOOT with RAM intact (debug / update); a countdown
             * shows from 2 s over the whole screen (the menu and the dialogs too: ui_draw), letting
             * go cancels it */
            static uint32_t t0;
            uint32_t both = (1u << panel.btn[B_OCTDN]) | (1u << panel.btn[B_OCTUP]);
            if ((fm1_in.buttons & both) != both) {
                if (ui.uboot) {
                    ui.uboot = 0;
                    ui.force = 1;                       /* what the countdown covered */
                    ui_message("UPDATE CANCELLED");
                }
                t0 = fm1_ms;
            } else if (fm1_ms - t0 > 2000u && fm1_ms - t0 <= 5000u) {
                uint32_t left = (5000u - (fm1_ms - t0) + 999u) / 1000u;
                if (left != ui.uboot) {
                    ui.uboot = (uint8_t)left;
                    ui.force = 1;
                }
            } else if (fm1_ms - t0 > 5000u) {
                fm1_audio_stop();
                scr_wake_now();
                lcd_fill(0, 0, 240, 240, T_BG);
                draw_text_box(0, 110, 240, &AF_M, "UBOOT", T_THEME, 1);
                usb_detach();
                fm1_delay_ms(30);
                bootguard.pending = 0;                  /* intentional reset: not a failed boot */
                fm1_enter_uboot();
            }
        }
#if FELUCCA_OTA
        ed_service();                                   /* web editor SysEx */
        ota_service();                                  /* M-UPGRADE handshake */
        if (usb.ota_req) {                              /* M-UPGRADE upgrade command */
            usb.ota_req = 0;
            panic_req = (1u << NTRK) - 1u;               /* every track (bit per track) */
            scr_wake_now();                             /* (its progress on the screen) */
            if (flash_ok)
                ota_session();                          /* returns only if nothing was committed */
            lcd_fill(0, 0, 240, 240, T_BG);
            ui.force = 1;
        }
#endif
        if (usb.uboot_req) {                            /* SysEx F0 22 24 35 7D F7 from the host */
            fm1_audio_stop();
            scr_wake_now();
            lcd_fill(0, 0, 240, 240, T_BG);
            draw_text_box(0, 110, 240, &AF_M, "UBOOT (USB)", T_THEME, 1);
            fm1_delay_ms(20);
            usb_detach();
            fm1_delay_ms(30);
            bootguard.pending = 0;
            fm1_enter_uboot();
        }
#if FELUCCA_CDC
        cdc_task();
#endif
        felucca_dbg.ui_frames++;
        felucca_dbg.page = ui.page;
        felucca_dbg.home = ui.home;
        felucca_dbg.stage = 1;
        ui_input();
        settings_poll();                              /* queued settings save: only while stopped */
        autosave_poll();                              /* (1.2) the music, stopped and idle: project.c */
#if FELUCCA_FLASH
        reel_save_poll();                             /* (1.0-GW TAKES v2) the TAKES reel, the same way */
#endif
        mutate_poll();                                /* (JIANT 0.6.43) MUTATE on the bar: project.c */
        song_poll();                                  /* the song: the next section staged, the music back after it */
        msc_tick();                                   /* (FASE 6) the morph between two scenes, walked */
        felucca_dbg.stage = 2;
        ui_leds();
        ui_draw();
        felucca_dbg.stage = 9;
        while (fm1_ms - m < 15u) {                               /* ~60 UI frames/s at most */
            ui_input();
#if FELUCCA_OTA
            ed_service();                       /* editor replies without waiting for the next frame */
#endif
        }
    }
}

void fm1_cstart(void)
{
    uint32_t *s, *d, p3, src, wdt;
    fm1_time_init();
    fm1_reset_reason();
    p3 = fm1_boot.p3_rst;
    src = fm1_boot.rst_src;
    wdt = fm1_boot.wdt_con;
    fm1_wdt_arm(0x0D);
    fm1_core1_stop();                           /* (0.6.71) a second core a reset left running would read the RAM
                                                 * cleared below */
    if (bootguard.magic != BOOTGUARD_MAGIC) {
        bootguard.magic = BOOTGUARD_MAGIC;
        bootguard.failed = 0;
        bootguard.pending = 0;
    }
    if (bootguard.pending)
        bootguard.failed++;
    bootguard.pending = 1;
    if (bootguard.failed >= 2u) {
        bootguard.failed = 0;
        bootguard.pending = 0;
        fm1_enter_uboot();
    }
    fm1_irq_init();
    for (d = _bss_start; d < _bss_end; d++)
        *d = 0;
    for (d = _pool_start; d < _pool_end; d++)
        *d = 0;
    for (d = _low_start; d < _low_end; d++)
        *d = 0;
    for (s = _data_load, d = _data_start; d < _data_end; s++, d++)
        *d = *s;
    for (s = _rt_load, d = _rt_start; d < _rt_end; s++, d++)
        *d = *s;                                /* flash driver code that must run from RAM */
#if FELUCCA_DUAL_CORE
    for (s = _c1t_load, d = _c1t_start; d < _c1t_end; s++, d++)
        *d = *s;                                /* (0.6.71) the second core's waiting loop (hal/fm1_multicore.h) */
#endif
    for (s = _hot_load, d = _hot_start; d < _hot_end; s++, d++)
        *d = *s;                                /* (0.6.78) core 0's hottest audio code (core.h HOTRAM) */
    fm1_mailbox_clear();
    fm1_guard_enable(FM1_GUARD_STACK | FM1_GUARD_WRITE | FM1_GUARD_BUS | FM1_GUARD_PC);
    fm1_boot.p3_rst = (uint8_t)p3;
    fm1_boot.rst_src = src;
    fm1_boot.wdt_con = (uint8_t)wdt;
    fm1_main();
    for (;;)
        ;
}
