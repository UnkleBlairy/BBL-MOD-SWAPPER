/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* NOISE: from analog-style noise to shift-register noise, through a resonant filter.
 *
 * MODE picks the source:
 *   ANLG  xorshift white noise, plus random impulses (DENS: their density, 0 = none)
 *   DUST  the impulses only: crackle, drops (through a resonant filter)
 *   LFSR  a long shift register (LEN: 23 down to 7 bits) clocked CLK semitones above the key
 *   META  one cycle of a short register sequence per period of the key (LEN: which one): a metallic tone
 * COLR tilts the source from white (0) through pink (64, -3 dB/oct) to brown (127, -6 dB/oct).
 * FREQ / RES: a trapezoidal SVF that morphs from low-pass (RES 0) to a narrow band-pass (RES 127);
 * TRK key-tracks FREQ (127 = one semitone a semitone, around C4). DRFT: a slow random wander of FREQ
 * (and the clock), the level following it. CRSH (ANLG, DUST): sample-and-hold and fewer bits.
 * The track's FLT moves FREQ, SHP moves COLR, PIT the key (so FREQ with TRK, and the clock).
 *
 * State: s[0] s[1] the filter, s[2] the random generator (seeded by the note and the unison detune: a
 * note from silence sounds the same each time), s[3] the drift target and its countdown, s[4..6] the pink
 * poles, s[7] the brown pole; ph[0] the clock phase (LFSR, META) or the hold count (CRSH), ph[1] the
 * register, the held sample or META's DC blocker, ph[2] the drift. */
static const char *const N_NOISE_MODE[] = {"ANLG", "DUST", "LFSR", "META"};
enum { NZ_ANLG, NZ_DUST, NZ_LFSR, NZ_META };
static const char *const N_NOISE_LONG[] = {"L23", "L20", "L17", "L15", "L13", "L11", "L9", "L7", 0};
static const char *const N_NOISE_META[] = {"127", "127B", "93", "63", "63B", "31", "15", "7", 0};
static const param_desc_t NOISE_LONG = {"LEN", F_INT, 0, 127, 0, N_NOISE_LONG, 0};   /* = edit[5] but the names */
static const param_desc_t NOISE_META = {"LEN", F_INT, 0, 127, 0, N_NOISE_META, 0};
static const param_desc_t NOISE_CLK = {"CLOCK", F_INT, 0, 127, 0, 0, "st"};           /* = edit[7]: above the key */

/* Galois taps of the long registers (maximal length: 2^n - 1 clocks) */
static const uint32_t NOISE_TAPS[8] = {0x420000u, 0x90000u, 1u << 16 | 1u << 13, 0x6000u, 0x100Du, 0x500u, 0x110u, 0x60u};

/* sqrt((8192 - res * 7800 / 127) << 12), res 0..127: the band-pass gain. RES has 128 values, so the
 * per-block square root is a table lookup (its two loops were most of noise_render's inner cost). */
static const uint16_t NOISE_BPG[128] = {
    5792, 5771, 5749, 5727, 5705, 5683, 5661, 5638, 5616, 5594, 5571, 5548, 5525, 5503, 5480, 5457,
    5434, 5410, 5387, 5364, 5340, 5317, 5293, 5269, 5245, 5221, 5197, 5173, 5149, 5124, 5099, 5075,
    5050, 5025, 5000, 4975, 4949, 4924, 4898, 4872, 4847, 4820, 4794, 4768, 4742, 4715, 4688, 4661,
    4634, 4607, 4580, 4552, 4525, 4496, 4469, 4440, 4412, 4383, 4354, 4326, 4296, 4267, 4238, 4207,
    4178, 4147, 4117, 4086, 4055, 4024, 3993, 3961, 3929, 3897, 3865, 3832, 3799, 3766, 3732, 3699,
    3664, 3630, 3595, 3560, 3524, 3489, 3453, 3416, 3379, 3341, 3303, 3265, 3226, 3187, 3147, 3107,
    3066, 3025, 2984, 2941, 2898, 2854, 2810, 2765, 2719, 2672, 2624, 2576, 2526, 2477, 2426, 2373,
    2319, 2264, 2208, 2151, 2091, 2030, 1967, 1902, 1834, 1765, 1693, 1616, 1537, 1452, 1363, 1267,
};

/* META: one period of a register's output bit (bit i of the words, from the state 1), its length,
 * and the levels of a 1 and a 0 (no DC, the larger at 16384). 7-bit taps 0x60 and 0x78, the 15-bit
 * register with its feedback from bits 0 and 6 (period 93), 6-bit 0x30 and 0x2D, 5-bit, 4-bit, 3-bit */
static const struct { uint32_t w[4]; uint8_t len; int16_t hi, lo; } NOISE_SEQ[8] = {
    {{0xD13C50C1u, 0x91C2F95Cu, 0xA58DED6Cu, 0x01FD533Bu}, 127, 16128, -16384},
    {{0xDBD165F1u, 0x9E46A1FDu, 0x84C15692u, 0x019B1CEBu}, 127, 16128, -16384},
    {{0x41008001u, 0x00492402u, 0x00824824u, 0x00000000u}, 93, 16384, -3404},
    {{0x27179461u, 0x03F566EDu, 0x00000000u, 0x00000000u}, 63, 15872, -16384},
    {{0x75A6C487u, 0x02FCA8CFu, 0x00000000u, 0x00000000u}, 63, 15872, -16384},
    {{0x05763E69u, 0x00000000u, 0x00000000u, 0x00000000u}, 31, 15360, -16384},
    {{0x00000F59u, 0x00000000u, 0x00000000u, 0x00000000u}, 15, 14336, -16384},
    {{0x0000001Du, 0x00000000u, 0x00000000u, 0x00000000u}, 7, 12288, -16384},
};

static const param_desc_t *noise_desc(const track_t *t, uint32_t k)
{
    int32_t mode = t->p[P_E0];
    if (k == 5u && mode >= NZ_LFSR)
        return mode == NZ_LFSR ? &NOISE_LONG : &NOISE_META;
    if (k == 7u && mode >= NZ_LFSR)
        return &NOISE_CLK;
    return 0;
}

/* phase increment of pitch p (1/16 semitone) past the table's top, up to one step a sample */
static uint32_t noise_inc(int32_t p)
{
    uint32_t sh = 0, inc;
    while (p > 2047) {
        p -= 192;
        sh++;
    }
    inc = tune_inc((uint32_t)clamp(p, 0, 2047));
    return sh && inc >= 0x80000000u >> (sh - 1u) ? 0xFFFFFFFFu : inc << sh;
}

static void noise_note_on(track_t *t, voice_t *v)
{
    uint32_t seed = (v->note + 1u) * 0x9E3779B9u ^ (uint32_t)v->fine * 0x85EBCA6Bu;   /* UNISON: each its own */
    (void)t;
    v->s[0] = v->s[1] = 0;
    v->s[2] = (int32_t)(seed ? seed : 1u);
    v->s[3] = 0;                                      /* a new drift target at once */
    v->s[4] = v->s[5] = v->s[6] = v->s[7] = 0;
    v->ph[0] = 0;
    v->ph[1] = 0;
    v->ph[2] = 0;
}

/* (FASE 2) CHARACTER's two extra filters, keyed by the pool slot: NOISE already keeps every s[] and ph[] entry */
static int32_t nz_bp1[VPOOLN], nz_bp2[VPOOLN], nz_hp[VPOOLN];

static void noise_render(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    const int16_t *p = t->p;
    uint32_t vi = VSLOT(v);
    int32_t banda = xamt(p, 0), evola = xamt(p, 1), hpa = p[P_MORPH];
    int32_t bp1 = nz_bp1[vi], bp2 = nz_bp2[vi], hslp = nz_hp[vi];
    uint32_t mode = (uint32_t)p[P_E0] & 3u, sel = ((uint32_t)p[P_E5] >> 4) & 7u, i;
    int32_t res = p[P_E3], drft = p[P_E6], crsh = mode < NZ_LFSR ? p[P_E7] : 0;
    if (evola)                                        /* (FASE 2) EVOL: the drift deeper, so the colour wanders */
        drft = clamp(drft + evola * 96, 0, 127);
    int32_t ic1 = v->s[0], ic2 = v->s[1], rng = v->s[2], b0 = v->s[4], b1 = v->s[5], b2 = v->s[6], br = v->s[7];
    uint32_t ph = v->ph[0], reg = v->ph[1];         /* state in locals: out[] may alias v->s[] */
    int32_t drift = (int32_t)v->ph[2], d16 = 0, gain = 32767, gq, colr, cut, k, a1, a2, a3, g, bpg, mix, cf, thr = 0;
    uint32_t inc = 0, taps = NOISE_TAPS[sel];
    const uint32_t *seqw = NOISE_SEQ[sel].w;            /* META's period, its length and its two levels: the same
                                                         * table read every sample, hoisted out of the loop */
    uint32_t seqlen = NOISE_SEQ[sel].len;
    int32_t seqhi = NOISE_SEQ[sel].hi, seqlo = NOISE_SEQ[sel].lo;
    /* drift: a new random target every 0.7..3 s, followed with a 0.7 s lag */
    if (drft) {
        int32_t tg = v->s[3] >> 16, cnt = v->s[3] & 0xFFFF;
        if (--cnt <= 0) {
            uint32_t r = noise32(&rng);
            tg = (int32_t)(r >> 16) - 32768;
            cnt = 1024 + (int32_t)(r & 3071u);
        }
        v->s[3] = (int32_t)((uint32_t)tg << 16 | (uint32_t)cnt);
        drift += (tg * 16 - drift) >> 10;              /* Q19 (v1.5.16: * 16, a shift of a negative is undefined) */
        d16 = ((drift >> 11) * drft * drft) >> 14;    /* up to about +-16 semitones */
        gain = 32767 - ((((32767 - (drift >> 4)) >> 1) * drft) >> 8);   /* down to -6 dB as it falls */
    }
    /* COLR (+ SHP), 0..127 << 8: white -> pink -> brown */
    colr = clamp((p[P_E1] << 8) + m->shape - (64 << 8), 0, 127 << 8);
    cf = colr <= (64 << 8) ? colr << 1 : ((colr - (64 << 8)) * 520) >> 8;   /* the crossfade, Q15 */
    /* FREQ (+ FLT), key-tracked by TRK around C4, the drift: SVF cutoff units (256 an index, 0.86 st) */
    cut = (p[P_E2] << 8) + m->cutoff + (((m->pitch16 - 60 * 16) * p[P_E4] * 151) >> 10) + ((d16 * 4785) >> 8);
    cut = clamp(cut, 0, 127 << 8);
    g = SVF_G[cut >> 8];
    if (cut < (127 << 8))
        g += ((SVF_G[(cut >> 8) + 1] - g) * (cut & 255)) >> 8;
    k = 8192 - res * 7800 / 127;                      /* damping, Q12: 2.0 .. 0.1 */
    a1 = (int32_t)((4096u << 13) / (uint32_t)(4096 + ((g * (g + k)) >> 12)));
    a2 = (a1 * g) >> 12;
    a3 = (a2 * g) >> 12;
    /* RES is 0..127; the guard only keeps a damaged project from indexing past the table (it
     * changes no valid value). */
    bpg = NOISE_BPG[res < 0 ? 0 : res > 127 ? 127 : res];   /* band-pass x 1.5 sqrt(damping) */
    mix = res * 258;                                  /* low-pass -> band-pass, Q15 */
    {   /* level: make up most of what the filter takes from white noise (less for pink and brown), +12 dB for
         * the sparse DUST, the drift's level; Q12, mk in 1/256 octave: 2^(mk / 256), at most x 16 */
        int32_t wf = 32767 - ((colr * 230) >> 8), mk = (((((127 << 8) - cut) >> 8) * 7) * wf) >> 15;
        mk += 214 + (mode == NZ_DUST ? 512 : 0);
        if (mk > 1279)
            mk = 1279;
        gq = (4096 + ((mk & 255) << 4)) << (mk >> 8);
        gq = (gq * (gain >> 3)) >> 12;
        if (gq > 65535)
            gq = 65535;
    }
    if (mode <= NZ_DUST && (p[P_E5] || mode == NZ_DUST)) {   /* impulses: 1 .. 2000 a second */
        uint32_t dn = p[P_E5] ? (uint32_t)p[P_E5] : 48u;          /* (0.6.46) DUST is nothing but them: at DENS 0
                                                                   * some still (~16 a second), never silence */
        uint32_t e = dn * 22u, r = 1u << (e >> 8);    /* 2^(DENS * 11 / 127), Q8 fraction */
        r += (r * (e & 255u)) >> 8;
        thr = (int32_t)((r * 97391u) >> 16);          /* per 2^16 of a sample: rate * 65536 / FS, Q16 */
    }
    if (mode == NZ_LFSR) {
        uint32_t mask = taps;                         /* the register's own bits (MODE / LEN changes) */
        inc = noise_inc(m->pitch16 + p[P_E7] * 16 + d16);
        mask |= mask >> 1;
        mask |= mask >> 2;
        mask |= mask >> 4;
        mask |= mask >> 8;
        mask |= mask >> 16;
        if (!(reg & mask))                            /* a new note: the register from the note's seed */
            reg = (uint32_t)rng | 1u;
        reg &= mask;
    } else if (mode == NZ_META) {
        inc = p[P_E7] || d16 ? noise_inc(m->pitch16 + p[P_E7] * 16 + d16) : m->inc;
    }
    for (i = 0; i < n; i++) {
        int32_t w, x, v1, v2, v3, y;
        switch (mode) {
        case NZ_DUST:
        case NZ_ANLG: {
            uint32_t r = noise32(&rng);
            w = mode == NZ_ANLG ? (int32_t)(r >> 17) - 16384 : 0;
            if ((int32_t)(r & 0xFFFFu) < thr) {       /* an impulse, random size and sign */
                int32_t a = 8192 + (int32_t)((r >> 18) & 0x7FFFu);
                w += (r & 0x20000u) ? a : -a;
            }
            break;
        }
        case NZ_LFSR: {
            ph += inc;
            if (ph < inc)                             /* the same overflow test as `ph < ph_before`, without
                                                         * keeping the old phase: unsigned wrap is exact */
                reg = (reg >> 1) ^ (-(reg & 1u) & taps);
            w = (reg & 1u) ? 12000 : -12000;
            break;
        }
        default: {
            uint32_t j = ((ph >> 16) * seqlen) >> 16;
            ph += inc;
            w = (seqw[j >> 5] >> (j & 31u)) & 1u ? seqhi : seqlo;
            break;
        }
        }
        x = w;
        if (colr) {                                   /* pink: three leaky poles (Kellet), brown: a leaky integrator */
            int32_t pk;
            b0 = ((b0 * 32690) >> 15) + ((w * 3245) >> 15);
            b1 = ((b1 * 31555) >> 15) + ((w * 9716) >> 15);
            b2 = ((b2 * 18678) >> 15) + ((w * 17247) >> 14);
            pk = (b0 + b1 + b2 + ((w * 6055) >> 15)) >> 2;
            if (colr <= (64 << 8)) {
                x = w + mulq15(pk - w, cf);
            } else {
                br = ((br * 32580) >> 15) + ((w * 3480) >> 15);
                x = pk + mulq15(br - pk, cf);
            }
        }
        if (banda) {                                  /* (FASE 2) BAND: a second, narrower band inside the source */
            int32_t co = g, co2 = clamp(g - banda * 20, 256, 4096);
            bp1 += ((x - bp1) * co) >> 12;
            {
                int32_t hpv = x - bp1;
                bp2 += ((hpv - bp2) * co2) >> 12;
            }
            x += mulq15(bp2 * 2 - x, banda * 258);
        }
        /* the SVF (dsp.c tsvf_lp, with the band-pass), rounded: at low cutoffs the floor of the shifts
         * walked the integrators off zero (DC) */
        v3 = x - ic2;
        v1 = (a1 * ic1 + a2 * v3 + 4096) >> 13;
        v2 = ic2 + ((a2 * ic1 + a3 * v3 + 4096) >> 13);
        ic1 = clamp(2 * v1 - ic1, -150000, 150000);
        ic2 = clamp(2 * v2 - ic2, -150000, 150000);
        v1 = (v1 * bpg * 3) >> 13;
        y = v2 + (((v1 - v2) * (mix >> 3)) >> 12);
        y = soft_knee(((y >> 4) * gq) >> 8, 24000);
        if (mode == NZ_META) {                        /* the knee bends a lopsided tone: a DC blocker, ~14 Hz */
            reg += (uint32_t)(((y << 8) - (int32_t)reg) >> 9);
            y -= (int32_t)reg >> 8;
        }
        if (crsh) {                                   /* hold 1..16 samples, 16 .. 4 bits */
            if ((int32_t)--ph <= 0 || ph > 16u) {
                ph = 1u + (uint32_t)crsh / 8u;
                reg = (uint32_t)(y >> (crsh / 11)) << (crsh / 11);   /* (v1.5.16) the floor, still a pair of shifts, but
                                                         * the left one on an unsigned value: y is negative
                                                         * half the time and a left shift of a negative is
                                                         * undefined. Same bits, same cost (target_budget) */
            }
            y = (int32_t)reg;
        }
        if (hpa) {                                    /* (FASE 2) HPF: the SVF's low end taken back out */
            hslp += (y - hslp) >> 4;
            y -= mulq15(hslp, hpa * 258);
        }
        out[i] += voice_amp(y, m, i);
    }
    v->s[0] = ic1;
    v->s[1] = ic2;
    v->s[2] = rng;
    v->s[4] = b0;
    v->s[5] = b1;
    v->s[6] = b2;
    v->s[7] = br;
    v->ph[0] = ph;
    v->ph[1] = reg;
    v->ph[2] = (uint32_t)drift;
    nz_bp1[vi] = bp1;
    nz_bp2[vi] = bp2;
    nz_hp[vi] = hslp;
}

/* {MODE, COLR, FREQ, RES, TRK, DENS, DRFT, CRSH / CLK} */
static const preset_t NOISE_PRESETS[] = {
    {"WIND", {NZ_ANLG, 64, 70, 100, 127, 0, 70, 0}, {90, 90, 110, 90}, 0, 0, FX(0, 34, 24, 74), PAT(5),
     {XP(P_LRATE, 12), XP(P_LWAVE, 6), XP(P_LD_FLT, 20), XP(P_LD_AMP, 8), XP(P_LEVEL, 120)}},
    {"RAIN", {NZ_DUST, 30, 88, 80, 64, 105, 40, 0}, {10, 90, 127, 70}, 0, 0, FX(0, 0, 22, 68), PAT(5),
     {XP(P_LRATE, 20), XP(P_LWAVE, 4), XP(P_LD_FLT, 10), XP(P_LEVEL, 114)}},
    /* a 7-bit register (127 steps) clocked 84 semitones (7 octaves) above the key: one period per key period,
     * a pitched chip-style buzz */
    {"ARCADE", {NZ_LFSR, 0, 127, 0, 127, 112, 0, 84}, {0, 80, 0, 50}, 0, 0, FX(6, 0, 12, 14), PAT(3),
     {XP(P_LRATE, 50), XP(P_LWAVE, 4), XP(P_LD_FLT, 14), XP(P_LEVEL, 127), XP(P_HARM, 16)}},
    {"METAL", {NZ_META, 0, 100, 40, 100, 32, 0, 0}, {0, 75, 40, 60}, 10, 0, FX(10, 18, 28, 32), PAT(7),
     {XP(P_LRATE, 34), XP(P_LWAVE, 4), XP(P_LD_FLT, 16), XP(P_LEVEL, 127)}},
    /* (GAMMAWAVE / WRAITH) radiation & industrial atmosphere patches */
    {"CHERENKOV", {NZ_DUST, 24, 96, 92, 90, 88, 75, 36}, {18, 90, 115, 88}, 16, 0, FX(24, 34, 48, 80), PAT(5),
     {XP(P_LRATE, 26), XP(P_LWAVE, 6), XP(P_LD_FLT, 18), XP(P_LEVEL, 127)}},
    {"REACTOR", {NZ_META, 82, 58, 78, 110, 48, 60, 24}, {35, 92, 110, 85}, 20, 1, FX(46, 18, 34, 60), PAT(8),
     {XP(P_LRATE, 30), XP(P_LWAVE, 4), XP(P_LD_SHP, 14), XP(P_LEVEL, 97)}},
    {"VOID WASH", {NZ_ANLG, 90, 52, 88, 64, 0, 95, 0}, {85, 95, 118, 102}, 12, 0, FX(8, 48, 44, 92), PAT(5),
     {XP(P_LRATE, 14), XP(P_LWAVE, 6), XP(P_LD_FLT, 16), XP(P_LD_AMP, 8), XP(P_LEVEL, 127), XP(P_LSHP, 26)}},
    /* (1.2-GW, issue #17: ambient and expressive) the sea (a slow swell of filtered noise), a dust haze */
    {"OCEAN", {NZ_ANLG, 40, 50, 30, 0, 0, 110, 0}, {100, 90, 127, 110}, 0, 0, FX(0, 30, 10, 90), PAT(5),
     {XP(P_LRATE, 6), XP(P_LWAVE, 0), XP(P_LD_AMP, 40), XP(P_LD_FLT, 12), XP(P_LEVEL, 127)}},
    {"DUST HAZE", {NZ_DUST, 80, 110, 45, 30, 60, 60, 0}, {80, 90, 120, 100}, 0, 0, FX(0, 40, 30, 88), PAT(5),
     {XP(P_LRATE, 18), XP(P_LWAVE, 6), XP(P_LD_FLT, 12), XP(P_LD_AMP, 6), XP(P_LEVEL, 127)}},
    /* (QUANTUM // QG-1) a riser (the LFO a slow saw on the filter), a counter's clicks, foam */
    {"RISER", {NZ_ANLG, 60, 40, 90, 0, 0, 80, 0}, {120, 90, 127, 60}, 20, 0, FX(0, 30, 40, 80), PAT(5),
     {XP(P_LRATE, 4), XP(P_LWAVE, 2), XP(P_LD_FLT, 40), XP(P_LEVEL, 127), XP(P_LSHP, -24)}},
    {"GEIGER CNT", {NZ_DUST, 28, 90, 60, 64, 30, 30, 0}, {0, 60, 100, 40}, 0, 0, FX(12, 0, 28, 26), PAT(5),
     {XP(P_LRATE, 54), XP(P_LWAVE, 4), XP(P_LD_FLT, 12), XP(P_LEVEL, 127)}},
    {"QUANTUM FOAM", {NZ_DUST, 50, 100, 85, 90, 95, 85, 20}, {30, 90, 115, 90}, 12, 0, FX(10, 48, 44, 88), PAT(5),
     {XP(P_LRATE, 16), XP(P_LWAVE, 6), XP(P_LD_FLT, 18), XP(P_LD_SHP, 8), XP(P_LEVEL, 127)}},
    /* (QG-1 EXPANSION: Ambient Atmospheres & Experimental Noise Textures) */
    {"COSMIC WINDS", {NZ_ANLG, 55, 60, 90, 80, 0, 90, 0}, {95, 90, 120, 105}, 0, 0, FX(0, 45, 30, 95), PAT(5),
     {XP(P_LRATE, 8), XP(P_LWAVE, 1), XP(P_LD_FLT, 16), XP(P_LEVEL, 127)}},
    {"POLAR AURORA", {NZ_DUST, 40, 95, 80, 50, 70, 70, 10}, {70, 90, 118, 95}, 0, 0, FX(0, 58, 34, 86), PAT(5),
     {XP(P_LRATE, 13), XP(P_LWAVE, 6), XP(P_LD_FLT, 14), XP(P_LD_AMP, 6), XP(P_LEVEL, 127)}},
    {"STATIC HAZE", {NZ_DUST, 75, 105, 50, 40, 50, 50, 30}, {85, 90, 120, 100}, 0, 0, FX(16, 28, 26, 60), PAT(5),
     {XP(P_LRATE, 40), XP(P_LWAVE, 4), XP(P_LD_FLT, 14), XP(P_LEVEL, 127)}},
    {"ABYSS DRONE", {NZ_ANLG, 80, 35, 95, 64, 0, 100, 0}, {100, 95, 127, 110}, 0, 0, FX(8, 36, 20, 92), PAT(5),
     {XP(P_LRATE, 9), XP(P_LWAVE, 6), XP(P_LD_FLT, 20), XP(P_LD_AMP, 8), XP(P_LEVEL, 127)}},

    /* (QG-1 1.6) EVOLVE: a texture whose colour and level breathe together */
    {"SOLAR WIND", {1, 32, 45, 52, 88, 60, 100, 0}, {96, 90, 124, 108}, 0, 0, FX(0, 45, 30, 88), PAT(5),
     {XP(P_LRATE, 3), XP(P_LWAVE, 6), XP(P_LD_FLT, 22), XP(P_LD_AMP, 12), XP(P_LEVEL, 127), XP(P_HARM, 8)}},

    /* (6.0) the remaster's new sounds: one per family, each with its own motion and sends */
    {"SANDSTORM", {1, 44, 96, 62, 40, 104, 40, 6}, {16, 80, 90, 70}, 0, 0, FX(0, 34, 30, 64), PAT(5),
     {XP(P_LRATE, 16), XP(P_LWAVE, 6), XP(P_LD_FLT, 16), XP(P_LD_AMP, 6), XP(P_LEVEL, 111)}},  /* B: texture */
    {"COLD FUSION", {0, 52, 40, 88, 20, 0, 90, 0}, {40, 88, 110, 86}, 0, 0, FX(6, 44, 26, 86), PAT(5),
     {XP(P_LRATE, 11), XP(P_LWAVE, 6), XP(P_LD_FLT, 22), XP(P_LEVEL, 97)}},  /* B: drone */
    {"BIT SWARM", {2, 12, 120, 40, 64, 96, 62, 26}, {0, 66, 30, 40}, 0, 0, FX(30, 20, 36, 30), PAT(1),
     {XP(P_LRATE, 58), XP(P_LWAVE, 4), XP(P_LD_FLT, 18), XP(P_LEVEL, 118)}},  /* D: digital */
    {"META DUST", {3, 88, 96, 74, 88, 112, 0, 8}, {0, 72, 20, 44}, 0, 1, FX(24, 0, 28, 22), PAT(1),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 16), XP(P_LEVEL, 127), XP(P_HARM, 12)}},  /* F: metal perc */
    {"LLUVIA DE CENIZA", {1, 60, 84, 50, 30, 104, 100, 0}, {60, 90, 108, 88}, 0, 0, FX(0, 42, 34, 88), PAT(5),
     {XP(P_LRATE, 9), XP(P_LWAVE, 6), XP(P_LD_FLT, 18), XP(P_LD_AMP, 6), XP(P_LEVEL, 109)}},  /* G: ash rain */
};

static const param_desc_t NOISE_CH[3] = {
    {"BAND", F_PCTINV, 0, 127, 127, 0, 0}, {"EVOL", F_PCTINV, 0, 127, 127, 0, 0},
    {"HPF", F_PCT, 0, 127, 0, 0, 0},
};

static const engine_t ENG_NOISE = {
    .name = "NOISE",
    .page_title = {"SRC", "MOVE", "CHAR"},
    .edit = {
        {"MODE", F_ENUM, 0, 3, 0, N_NOISE_MODE, 0},
        {"COLOR", F_PCT, 0, 127, 64, 0, 0},
        {"FREQ", F_CUTOFF, 0, 127, 80, 0, 0},
        {"PEAK", F_PCT, 0, 127, 30, 0, 0},   /* (0.5.1: was RES, beside the FILTER page's own RES) */
        {"TRK", F_PCT, 0, 127, 64, 0, 0},
        {"DENSE", F_PCT, 0, 127, 0, 0, 0},           /* LFSR, META: the register (noise_desc) */
        {"DRIFT", F_PCT, 0, 127, 0, 0, 0},
        {"CRUSH", F_PCT, 0, 127, 0, 0, 0},           /* LFSR, META: the clock above the key */
    },
    .presets = NOISE_PRESETS,
    .npresets = NELEM(NOISE_PRESETS),
    .ch = NOISE_CH,
    .ch_n = 3,
    .note_on = noise_note_on,
    .render = noise_render,
    .knob = {P_E2, P_E3, P_E1, P_REL},
    .keep = 0xF3,                /* the filter, the colour poles */
    .desc = noise_desc,
};
