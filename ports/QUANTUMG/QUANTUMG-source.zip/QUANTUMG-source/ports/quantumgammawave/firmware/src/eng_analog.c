/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* ANALOG: two band-limited oscillators (saw / square / tri / sine / PWM),
 * noise, drive and a trapezoidal low-pass. (JIANT 0.4, TRIO folded in: TRIO's sounds play here, project.c) three more
 * WAVEs in a loop of their own (analog_ext): SYNC (osc 2's saw restarted by osc 1, DTN its ratio 1 .. 8.9: the sync
 * lead's sweep), RING (osc 1's saw times osc 2's sine at that ratio: bells, metal), SAW3 (three saws, osc 2 DTN cents up,
 * osc 3 down: TRIO's fat stack). MIX: osc 1 against the other(s) as before. INT (0.4, once KTR): osc 2 INT semitones
 * from osc 1, as a classic two-oscillator synth (fifths, octaves; SAW3: its osc 2). (FASE 2) PM: osc 2 (a saw) bends
 * osc 1's phase before the mix -- FM's cousin with the two oscillators this engine already has; the index is MORPH
 * plus SHAPE (0.78 .. ~4 rad) and the ratio INT / DTUNE, as SYNC and RING's. Appended: the stores' 0..9 stay. */
static const char *const N_ANALOG_WAVE[] = {"SAW", "SQR", "TRI", "SIN", "PWM", "SYNC", "RING", "SAW3", "TUBE", "FOLD", "PM"};
enum { AW_SYNC = 5, AW_RING, AW_SAW3, AW_TUBE, AW_FOLD, AW_PM };   /* (FASE 2: PM appended, the stores' values stay) */
/* (JIANT 0.5) FILTER TYPE (P_FTYPE): LP as before (analog_render's loop); HP BP from the same state-variable filter
 * (analog_ext's loop, every WAVE); COMB the filter open, the part's sum through a feedback comb tuned to the newest
 * note and CUT (+-32 semitones about it), RES its feedback (voice.c track_comb) */
enum { FT_LP, FT_HP, FT_BP, FT_COMB, FT_VOWEL, FT_SCREAM, FT_NOTCH, FT_SHELF };   /* (FASE 3) NOTCH = LP + HP (the
                                                    * cutoff taken out, both sides pass), DIP = LP - BP (a
                                                    * lowpass with its own corner scooped): both from this SVF */
static inline int32_t svf_mode(const tsvf_t *c, int32_t in, int32_t *ic1, int32_t *ic2, uint32_t ft, int32_t k)
{
    int32_t v3 = in - *ic2;
    int32_t v1 = (c->a1 * *ic1 + c->a2 * v3) >> 13;
    int32_t v2 = *ic2 + ((c->a2 * *ic1 + c->a3 * v3) >> 13);
    int32_t s1 = 2 * v1 - *ic1;
    if (ft == FT_SCREAM)
        s1 = softclip(s1 >> 1) << 1;
    *ic1 = clamp(s1, -150000, 150000);
    *ic2 = clamp(2 * v2 - *ic2, -150000, 150000);
    if (ft == FT_VOWEL) {
        int32_t bp = (k * v1) >> 12;
        return (v2 >> 1) + bp - (softclip(in - bp) >> 2);
    }
    if (ft == FT_SCREAM)
        return v2 + (softclip(v1) >> 1);
    if (ft == FT_NOTCH)                                 /* (FASE 3) LP + HP: the cutoff taken out */
        return in - ((k * v1) >> 12);
    if (ft == FT_SHELF)                                 /* (FASE 3) x + LP: a low shelf, +6 dB under the corner */
        return in + v2;
    return ft == FT_HP ? in - v2 - ((k * v1) >> 12) : ft == FT_BP ? (k * v1) >> 12 : ft == FT_COMB ? in : v2;
}

static void analog_note_on(track_t *t, voice_t *v)
{
    (void)t;
    v->ph[1] = v->ph[0] + 0x40000000u;
    v->s[0] = v->s[1] = 0;                            /* filter */
    if (!v->s[2])
        v->s[2] = 0x1234567 + (int32_t)v->age;        /* noise state */
}

/* (0.6.45) MORPH: the plain WAVEs (SAW SQR TRI SIN) on towards the next ones: the place, Q8 from WAVE (0..1536), the
 * knob and the SHAPE modulation (LFO / ENV -> SHAPE) together; -1: none (the WAVE as it is). (0.6.81) Round in a
 * loop: SIN on towards SAW (it did nothing from SIN) */
static int32_t an_mpos(const int16_t *p, int32_t mq8, const vmod_t *m)   /* (mq8: the morph Q8, track_t.mo_cur) */
{
    int32_t mo;
    if (p[P_E0] >= 4 || (!mq8 && m->shape == (64 << 8)))
        return -1;
    mo = clamp(mq8 + m->shape - (64 << 8), 0, 127 << 8);
    return clamp(p[P_E0] * 256 + mo * 768 / (127 << 8), 0, 1536);
}
/* (0.6.81) MORPH on PWM SYNC RING SAW3 (and the SHAPE modulation on the last three, which had none): how far, Q8
 * 0..127 << 8, the knob and SHAPE together */
static int32_t an_mext(int32_t mq8, const vmod_t *m)
{
    return clamp(mq8 + m->shape - (64 << 8), 0, 127 << 8);
}
/* (1.0-GW) TUBE and FOLD: a sine made dirty in the oscillator, computed (no table), before the filter, so its
 * fundamental stays (a dirty 808 keeps its sub): TUBE after GammaWave's Hearth, an asymmetric tube (even harmonics,
 * warmth; its DC taken off), FOLD after WRAITH's Blast, the sine of a sine (odd harmonics, a growl, metal). How dirty:
 * MORPH and the SHAPE modulation together (an_mext: ENV > SHAPE makes it dirty on the hit, clean as it rings) */
typedef struct { int32_t g, b, cb, dc, kf; } an_dirt_t;
static void an_dirt_set(an_dirt_t *d, int32_t mx)        /* mx: Q8, 0 .. 127 << 8 */
{
    int32_t a = clamp(mx, 0, 127 << 8) >> 8, k, sum = 0;
    d->g = 4096 + a * 200;                              /* TUBE: Q12, the sine x1 .. x7.2 into the curve .. */
    d->b = a * 60;                                      /* .. biased (up to ~0.23): its asymmetry */
    d->cb = softclip(d->b);
    for (k = 0; k < 16; k++)                            /* (its DC over a cycle, taken off: no thump at the gate) */
        sum += softclip(((SINE[k * 64] * d->g) >> 12) + d->b) - d->cb;
    d->dc = sum >> 4;
    d->kf = 5215 + a * 287;                             /* FOLD: sin(g sin x), g 1 .. 8 rad (the phase scale / 4) */
}
static inline int32_t an_dirt(uint32_t w, uint32_t ph, const an_dirt_t *d)
{
    int32_t s = osc_sine(ph);
    if (w == AW_TUBE)
        return softclip(((s * d->g) >> 12) + d->b) - d->cb - d->dc;
    return (sine_i((uint32_t)(s * d->kf) << 2) * 3 + s) >> 2;   /* (a quarter of the sine under it, as Blast's) */
}
static inline int32_t an_osc(uint32_t w, uint32_t ph, uint32_t inc)
{
    w &= 3u;
    return w == 1u ? osc_pulse(ph, inc, 0x80000000u) : w == 2u ? osc_tri(ph) : w == 3u ? osc_sine(ph) : osc_saw(ph, inc);
}
static inline int32_t an_morph(int32_t pos, uint32_t ph, uint32_t inc)
{
    int32_t a = an_osc((uint32_t)pos >> 8, ph, inc), f = pos & 255;
    return f ? a + (((an_osc(((uint32_t)pos >> 8) + 1u, ph, inc) - a) * f) >> 8) : a;
}

/* (0.6.45) MORPH: the plain WAVEs blended toward the next (an_mpos), osc 2 as analog_render's, the same noise, drive
 * and filter as analog_ext (a loop of its own: the others' as they were) */
static __attribute__((noinline)) void analog_morph(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m,
                                                   int32_t mpos0, int32_t mpos1)   /* (0.6.50: ramped mpos0 -> mpos1) */
{
    const int16_t *p = t->p;
    uint32_t i, inc1 = m->inc, ph0 = v->ph[0], ph1 = v->ph[1], ft = (uint32_t)p[P_FTYPE] % 8u;
    uint32_t inc2 = p[P_E1] || p[P_E7] ? cents_inc(m->pitch16 + p[P_E7] * 16, p[P_E1], 0) : inc1;
    int32_t m2 = p[P_E2] * 258, m1 = 32767 - m2, nz = p[P_E3] * 200, drv = p[P_E6], kd = 8192 - p[P_E5] * 7600 / 127;
    int32_t drive = 32768 + drv * 512, cut = (p[P_E4] << 8) + m->cutoff + ((v->pitch16 - 60 * 16) * 4);
    int32_t ic1 = v->s[0], ic2 = v->s[1], nst = v->s[2];
    tsvf_t flt;
    tsvf_coef(&flt, cut, p[P_E5]);
    int32_t dq = (mpos1 - mpos0) * 256 / (int32_t)(n ? n : 1u);   /* (v1.5.16) the step is signed: * 256 */
    for (i = 0; i < n; i++) {
        int32_t mpos = mpos0 + ((dq * (int32_t)i) >> 8);
        int32_t s = mulq15(an_morph(mpos, ph0, inc1), m1) + mulq15(an_morph(mpos, ph1, inc2), m2);
        ph0 += inc1;
        ph1 += inc2;
        if (nz)
            s += mulq15((int32_t)(noise32(&nst) >> 17) - 16384, nz);
        if (drv)
            s = softclip(((s >> 2) * (drive >> 2)) >> 11);
        out[i] += voice_amp(soft_knee(svf_mode(&flt, s >> 1, &ic1, &ic2, ft, kd), 16000) * 2, m, i) * 2;
    }
    v->ph[0] = ph0;
    v->ph[1] = ph1;
    v->s[0] = ic1;
    v->s[1] = ic2;
    v->s[2] = nst;
}

/* PWM's width: SHAPE as before, (0.6.81) MORPH narrowing it further (toward ~4 %) */
static uint32_t an_pw(const track_t *t, const vmod_t *m)
{
    int32_t q = (m->shape - (64 << 8)) + (t->p[P_E0] == 4 ? t->mo_cur * 2 : 0);
    return 0x80000000u + (uint32_t)(clamp(q, -16384, 65000) << 15);
}

/* SYNC RING SAW3 (see the top): a render of their own (the other WAVEs' loop untouched), the same noise, drive and
 * filter */
static __attribute__((noinline)) void analog_ext(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    const int16_t *p = t->p;
    uint32_t wave = (uint32_t)p[P_E0], i, inc1 = m->inc, ph0 = v->ph[0], ph1 = v->ph[1], ph2 = v->ph[2], r, inc2, inc3;
    uint32_t ft = (uint32_t)p[P_FTYPE] % 8u, pw = an_pw(t, m);
    int32_t mx = wave >= AW_SYNC ? an_mext(t->mo_cur, m) : 0;   /* (0.6.81) MORPH, SHAPE on SYNC RING SAW3 */
    /* (FASE 2) PM's index, Q0 phase units per sample of osc 2: 0.78 rad with MORPH at 0 up to ~4 rad, the MORPH
     * knob and SHAPE together (an_mext). The oscillator ratio is SYNC / RING's r, so INT and DTUNE retune it */
    uint32_t pmk = wave == AW_PM ? (uint32_t)mx * 5u / 2u + 16384u : 0u;
    int32_t det = p[P_E1] + (wave == AW_SAW3 ? mx * 40 / (127 << 8) : 0), m2 = p[P_E2] * 258, m1 = 32767 - m2, nz = p[P_E3] * 200, drv = p[P_E6], kd = 8192 - p[P_E5] * 7600 / 127;
    int32_t drive = 32768 + drv * 512, cut = (p[P_E4] << 8) + m->cutoff + ((v->pitch16 - 60 * 16) * 4);
    int32_t ic1 = v->s[0], ic2 = v->s[1], nst = v->s[2];
    tsvf_t flt;
    tsvf_coef(&flt, cut, p[P_E5]);
    r = 16u + (uint32_t)det + (wave != AW_SAW3 ? (uint32_t)(mx * 64 / (127 << 8)) : 0u);   /* SYNC / RING: osc 2 at r / 16
                                                         * of osc 1 (1 .. 8.9; 0.6.81: MORPH up to 4 more) */
    inc2 = wave == AW_SAW3 ? cents_inc(m->pitch16 + p[P_E7] * 16, det, 0) : (inc1 >> 4) * r;   /* (SAW3: osc 2 at INT) */
    if (wave != AW_SAW3 && p[P_E7]) {                   /* (JIANT 0.5) SYNC / RING: INT moves osc 2 too, semitones */
        inc2 = (cents_inc(m->pitch16 + p[P_E7] * 16, 0, 0) >> 4) * r;
        r = inc1 >> 8 ? (inc2 / (inc1 >> 8)) >> 4 : r; /* (its ratio to osc 1, x16: the restart below) */
        if (r < 1u) r = 1u;
    }
    inc3 = wave == AW_SAW3 ? cents_inc(m->pitch16, -det, 0) : 0u;
    if (wave < AW_SYNC)                                 /* (JIANT 0.5: HP BP COMB) the plain WAVEs: osc 2 as analog_render */
        inc2 = det || p[P_E7] ? cents_inc(m->pitch16 + p[P_E7] * 16, det, 0) : inc1;
    for (i = 0; i < n; i++) {
        int32_t a = osc_saw(ph0, inc1), b, s;
        if (wave < AW_SYNC) {
            switch (wave) {
            case 1: a = osc_pulse(ph0, inc1, 0x80000000u); b = osc_pulse(ph1, inc2, 0x80000000u); break;
            case 2: a = osc_tri(ph0); b = osc_tri(ph1); break;
            case 3: a = osc_sine(ph0); b = osc_sine(ph1); break;
            case 4: a = osc_pulse(ph0, inc1, pw); b = osc_pulse(ph1, inc2, pw); break;
            default: b = osc_saw(ph1, inc2); break;
            }
        } else if (wave == AW_SAW3) {
            b = (osc_saw(ph1, inc2) + osc_saw(ph2, inc3)) >> 1;
            ph2 += inc3;
        } else if (wave == AW_SYNC) {
            b = osc_saw(ph1, inc2);
        } else if (wave == AW_PM) {
            b = osc_saw(ph1, inc2);                       /* osc 2, the modulator */
            a = osc_sine(ph0 + (uint32_t)b * pmk);         /* PM: it bends osc 1's phase (a signed product, wrapped
                                                            * as the phase wraps: unsigned, no UB) */
        } else {
            b = ((a >> 1) * (osc_sine(ph1) >> 1)) >> 13;   /* RING (32 bits) */
        }
        ph1 += inc2;
        if (wave == AW_SYNC && ph0 + inc1 < ph0)        /* osc 1 starts a cycle: osc 2 with it */
            ph1 = ((ph0 + inc1) >> 4) * r;              /* (the new cycle's fraction, at osc 2's rate) */
        ph0 += inc1;
        s = mulq15(a, m1) + mulq15(b, m2);
        if (nz)
            s += mulq15((int32_t)(noise32(&nst) >> 17) - 16384, nz);
        if (drv)
            s = softclip(((s >> 2) * (drive >> 2)) >> 11);
        out[i] += voice_amp(soft_knee(svf_mode(&flt, s >> 1, &ic1, &ic2, ft, kd), 16000) * 2, m, i) * 2;
    }
    v->ph[0] = ph0;
    v->ph[1] = ph1;
    v->ph[2] = ph2;
    v->s[0] = ic1;
    v->s[1] = ic2;
    v->s[2] = nst;
}

static __attribute__((noinline)) void analog_render(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    const int16_t *p = t->p;
    uint32_t wave = (uint32_t)p[P_E0], i;
    int32_t det = p[P_E1], mix = p[P_E2], noise = p[P_E3];
    int32_t cut = (p[P_E4] << 8) + m->cutoff + ((v->pitch16 - 60 * 16) * 4);
    tsvf_t flt;
    int32_t drive = 32768 + p[P_E6] * 512;                       /* 1x .. 3x */
    uint32_t inc1 = m->inc;
    uint32_t inc2 = det || p[P_E7] ? cents_inc(m->pitch16 + p[P_E7] * 16, det, 0) : inc1;   /* (JIANT 0.4) osc 2: INT
                                                         * semitones away, DTN cents */
    uint32_t pw = an_pw(t, m);
    int32_t m2 = mix * 258, m1 = 32767 - m2;                    /* osc mix Q15 */
    int32_t nz = noise * 200, drv = p[P_E6];
    uint32_t ph0 = v->ph[0], ph1 = v->ph[1];                  /* state in locals: out[] may alias v->s[] */
    int32_t ic1 = v->s[0], ic2 = v->s[1], nst = v->s[2];
    tsvf_coef(&flt, cut, p[P_E5]);
    for (i = 0; i < n; i++) {
        int32_t a, b, s;
        switch (wave) {
        case 1:
            a = osc_pulse(ph0, inc1, 0x80000000u);
            b = osc_pulse(ph1, inc2, 0x80000000u);
            break;
        case 2:
            a = osc_tri(ph0);
            b = osc_tri(ph1);
            break;
        case 3:
            a = osc_sine(ph0);
            b = osc_sine(ph1);
            break;
        case 4:
            a = osc_pulse(ph0, inc1, pw);
            b = osc_pulse(ph1, inc2, pw);
            break;
        default:
            a = osc_saw(ph0, inc1);
            b = osc_saw(ph1, inc2);
            break;
        }
        ph0 += inc1;
        ph1 += inc2;
        s = mulq15(a, m1) + mulq15(b, m2);
        if (nz)
            s += mulq15((int32_t)(noise32(&nst) >> 17) - 16384, nz);
        if (drv)
            s = softclip(((s >> 2) * (drive >> 2)) >> 11);   /* pre-shifts: drive is up to 3x, no overflow */
        {   /* filter, linear up to half scale, then a soft knee (only resonance peaks saturate); soft_knee()
             * written out: the host compiler makes this loop 1 % slower with the call */
            int32_t y = tsvf_lp(&flt, s >> 1, &ic1, &ic2), a = y < 0 ? -y : y;
            if (a > 16000) {
                a = 16000 + (softclip((a - 16000) * 2) >> 1);
                y = y < 0 ? -a : a;
            }
            s = y * 2;                   /* (1.7) not a shift of a negative value (UB): same code, defined */
        }
        out[i] += voice_amp(s, m, i) * 2;   /* (1.7) same value, no shift of a negative (UB) */
    }
    v->ph[0] = ph0;
    v->ph[1] = ph1;
    v->s[0] = ic1;
    v->s[1] = ic2;
    v->s[2] = nst;
}

/* (1.0-GW) TUBE FOLD: a render of their own (analog_render's and analog_ext's loops untouched: tests/target_budget.txt),
 * osc 2 the same wave at INT / DETUNE, the same noise, drive and filter (every FILTER TYPE); how dirty: once a block */
static __attribute__((noinline)) void analog_dirty(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    const int16_t *p = t->p;
    uint32_t wave = (uint32_t)p[P_E0], i, inc1 = m->inc, ph0 = v->ph[0], ph1 = v->ph[1], ft = (uint32_t)p[P_FTYPE] % 8u;
    uint32_t inc2 = p[P_E1] || p[P_E7] ? cents_inc(m->pitch16 + p[P_E7] * 16, p[P_E1], 0) : inc1;
    int32_t m2 = p[P_E2] * 258, m1 = 32767 - m2, nz = p[P_E3] * 200, drv = p[P_E6], kd = 8192 - p[P_E5] * 7600 / 127;
    int32_t drive = 32768 + drv * 512, cut = (p[P_E4] << 8) + m->cutoff + ((v->pitch16 - 60 * 16) * 4);
    int32_t ic1 = v->s[0], ic2 = v->s[1], nst = v->s[2];
    tsvf_t flt;
    an_dirt_t dt;
    tsvf_coef(&flt, cut, p[P_E5]);
    an_dirt_set(&dt, an_mext(t->mo_cur, m));
    for (i = 0; i < n; i++) {
        int32_t s = mulq15(an_dirt(wave, ph0, &dt), m1) + mulq15(an_dirt(wave, ph1, &dt), m2);
        ph0 += inc1;
        ph1 += inc2;
        if (nz)
            s += mulq15((int32_t)(noise32(&nst) >> 17) - 16384, nz);
        if (drv)
            s = softclip(((s >> 2) * (drive >> 2)) >> 11);
        out[i] += voice_amp(soft_knee(svf_mode(&flt, s >> 1, &ic1, &ic2, ft, kd), 16000) * 2, m, i) * 2;
    }
    v->ph[0] = ph0;
    v->ph[1] = ph1;
    v->s[0] = ic1;
    v->s[1] = ic2;
    v->s[2] = nst;
}

/* (FASE 2) CHARACTER: KTR+ opens the filter a little more up the keyboard (the fixed tracking it always had stays),
 * TONE is a one-pole high shelf: a little more (or less) edge on every oscillator, after the filter, so it does not
 * fight RES. Both are neutral at their stored 127; s[3] / s[4] are free in ANALOG. */
static void analog_character(track_t *t, voice_t *v, int32_t *out, uint32_t n)
{
    int32_t a = xamt(t->p, 1), lp = v->s[4];
    uint32_t i;
    if (!a)
        return;
    for (i = 0; i < n; i++) {
        int32_t s = out[i];
        lp += (s - lp) >> 6;
        out[i] = soft_knee(s + (((s - lp) * a) >> 8), 30000);
    }
    v->s[4] = lp;
}

/* the engine's render: SYNC RING SAW3 (0.4) and the FILTER TYPEs HP BP COMB (0.5) in analog_ext, (1.0-GW) TUBE FOLD in
 * analog_dirty, the rest (LP) here (a dispatch of its own: analog_render's loop as before) */
static void analog_dispatch(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    int32_t m1 = an_mpos(t->p, t->mo_cur, m), m0 = an_mpos(t->p, t->mo_prev, m);
    vmod_t mm;
    int32_t ktr = xamt(t->p, 0);
    const vmod_t *pm = m;
    if (ktr) {                                        /* (FASE 2) KTR+: the fixed key tracking was a constant since 1.0 */
        mm = *m;
        mm.cutoff = clamp(m->cutoff + (((v->pitch16 - 60 * 16) * ktr * 151) >> 12), -150 * 256, 190 * 256);
        pm = &mm;
    }
    if (m1 >= 0 || m0 >= 0) {                         /* (0.6.45) MORPH; (0.6.50) ramped from the last block's */
        int32_t base = (int32_t)t->p[P_E0] * 256;      /* (as it leaves or comes: the plain WAVE) */
        analog_morph(t, v, out, n, pm, m0 < 0 ? base : m0, m1 < 0 ? base : m1);
    }
    else if ((uint32_t)t->p[P_E0] >= AW_TUBE && (uint32_t)t->p[P_E0] != AW_PM)
        analog_dirty(t, v, out, n, pm);              /* (PM is not a dirty sine: it goes through analog_ext) */
    else if ((uint32_t)t->p[P_E0] >= AW_SYNC || t->p[P_FTYPE])
        analog_ext(t, v, out, n, pm);
    else
        analog_render(t, v, out, n, pm);
    analog_character(t, v, out, n);
}

static const preset_t ANALOG_PRESETS[] = {
    {"SAW LEAD", {0, 12, 64, 0, 90, 30, 10, 12}, {4, 70, 100, 50}, 20, 1, FX(0, 10, 45, 30), PAT(4),
     {XP(P_LRATE, 42), XP(P_LWAVE, 1), XP(P_LD_FLT, 12), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 22)}},
    {"SOFT PAD", {0, 20, 64, 4, 60, 10, 0, 0}, {80, 90, 110, 95}, 10, 0, FX(0, 62, 26, 74), PAT(5),
     {XP(P_LRATE, 22), XP(P_LWAVE, 6), XP(P_LD_FLT, 18), XP(P_M1SRC, 7), XP(P_M1DST, 2), XP(P_M1AMT, 15)}},
    {"SQR BASS", {1, 0, 0, 0, 50, 70, 40, 0}, {0, 60, 40, 30}, 30, 1, FX(28, 0, 0, 8), PAT(2),
     {XP(P_LRATE, 30), XP(P_LWAVE, 4), XP(P_LD_FLT, 22), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18)}},
    {"PWM STR", {4, 8, 40, 0, 75, 20, 0, 0}, {60, 80, 110, 85}, 8, 0, FX(0, 58, 24, 62), PAT(5),
     {XP(P_LRATE, 18), XP(P_LWAVE, 1), XP(P_LD_AMP, 10), XP(P_M1SRC, 7), XP(P_M1DST, 2), XP(P_M1AMT, 12)}},
    {"ACID", {0, 0, 0, 0, 50, 100, 25, 0}, {0, 55, 20, 30}, 48, 1, FX(34, 0, 38, 12), PAT(1),
     {XP(P_LRATE, 46), XP(P_LWAVE, 4), XP(P_LD_FLT, 10), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 30)}},
    {"SINE KEY", {3, 6, 50, 0, 127, 0, 0, 0}, {2, 80, 30, 70}, 0, 0, FX(0, 26, 30, 42), PAT(6),
     {XP(P_LRATE, 26), XP(P_LWAVE, 1), XP(P_LD_AMP, 6), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 20)}},
    {"RAVE", {4, 30, 64, 0, 85, 20, 30, 7}, {20, 80, 110, 60}, 10, 1, FX(32, 34, 26, 22), PAT(13),
     {XP(P_LRATE, 34), XP(P_LWAVE, 3), XP(P_LD_FLT, 16), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18)}},
    {"SUB BASS", {3, 0, 0, 0, 40, 0, 20, 0}, {0, 60, 100, 20}, 0, 1, FX(18, 0, 0, 0), PAT(8),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 14), XP(P_HARM, -18)}},
    {"PLUCK", {0, 8, 50, 0, 30, 40, 0, 0}, {0, 88, 0, 60}, 55, 0, FX(0, 22, 52, 34), PAT(3),
     {XP(P_LRATE, 20), XP(P_LWAVE, 1), XP(P_LD_FLT, 14), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 26)}},
    {"BRASS", {0, 10, 64, 0, 45, 20, 10, 0}, {35, 70, 90, 45}, 40, 0, FX(10, 24, 18, 36), PAT(6),
     {XP(P_LRATE, 24), XP(P_LWAVE, 1), XP(P_LD_FLT, 12), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 22)}},
    {"WIND", {0, 0, 0, 90, 30, 90, 0, 0}, {60, 90, 60, 80}, 50, 0, FX(0, 36, 42, 72), PAT(5),
     {XP(P_LRATE, 14), XP(P_LWAVE, 6), XP(P_LD_FLT, 24), XP(P_LD_AMP, 8), XP(P_LEVEL, 85), XP(P_LSHP, 26)}},
    {"STRINGS", {0, 25, 64, 0, 70, 10, 0, 0}, {70, 90, 115, 90}, 5, 0, FX(0, 66, 24, 74), PAT(5),
     {XP(P_LRATE, 16), XP(P_LWAVE, 1), XP(P_LD_FLT, 14), XP(P_LD_AMP, 6), XP(P_LEVEL, 86), XP(P_LSHP, 22)}},
    /* (JIANT 0.4: TRIO's, folded in) SYNC (ratio 1 + 11/16), RING (1 + 18/16), SAW3 (9 ct a side) */
    {"SYNC LEAD", {5, 11, 90, 0, 82, 30, 10, 0}, {2, 70, 100, 40}, 18, 1, FX(14, 12, 44, 28), PAT(4),
     {XP(P_LRATE, 38), XP(P_LWAVE, 2), XP(P_LD_FLT, 10), XP(P_M1SRC, 7), XP(P_M1DST, 11), XP(P_M1AMT, 14)}},
    {"RING BELL", {6, 18, 100, 0, 110, 20, 0, 0}, {0, 92, 0, 80}, 0, 0, FX(0, 18, 38, 58), PAT(7),
     {XP(P_LRATE, 28), XP(P_LWAVE, 1), XP(P_LD_AMP, 10), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 24)}},
    {"FAT BASS", {7, 9, 64, 0, 62, 45, 20, -12}, {0, 62, 60, 25}, 40, 1, FX(26, 0, 0, 8), PAT(2),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 20), XP(P_HARM, -14)}},
    /* (GAMMAWAVE / WRAITH) industrial & darksynth signature patches */
    {"INGOT SUB", {3, 4, 48, 8, 44, 38, 65, -12}, {0, 64, 95, 28}, 26, 1, FX(30, 0, 0, 6), PAT(2),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 16), XP(P_HARM, -20)}},
    {"WORM REESE", {7, 18, 64, 12, 56, 62, 75, -12}, {8, 85, 110, 48}, 34, 1, FX(48, 26, 12, 18), PAT(8),
     {XP(P_LRATE, 26), XP(P_LWAVE, 6), XP(P_LD_FLT, 12), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 14)}},
    {"GRAVE GROWL", {5, 22, 96, 16, 48, 84, 90, -12}, {2, 68, 80, 35}, 52, 1, FX(58, 12, 22, 16), PAT(1),
     {XP(P_LRATE, 30), XP(P_LWAVE, 4), XP(P_LD_SHP, 10), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18)}},
    {"HEARTH LD", {0, 14, 64, 10, 86, 45, 60, 7}, {4, 76, 100, 52}, 28, 1, FX(34, 22, 48, 32), PAT(4),
     {XP(P_LRATE, 40), XP(P_LWAVE, 2), XP(P_LD_FLT, 12), XP(P_M1SRC, 7), XP(P_M1DST, 11), XP(P_M1AMT, 10)}},
    {"WRAITH PAD", {4, 24, 64, 18, 64, 42, 25, 12}, {75, 95, 112, 98}, 16, 0, FX(12, 68, 38, 84), PAT(5),
     {XP(P_LRATE, 20), XP(P_LWAVE, 6), XP(P_LD_FLT, 16), XP(P_M1SRC, 7), XP(P_M1DST, 2), XP(P_M1AMT, 12)}},
    {"SCREAM 303", {0, 0, 0, 4, 42, 114, 80, 0}, {0, 52, 15, 26}, 58, 1, FX(52, 0, 42, 14), PAT(1),
     {XP(P_LRATE, 44), XP(P_LWAVE, 4), XP(P_GLIDE, 30), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 28)}},
    /* (QUANTUM GAMMAWAVE // QG-1) Latest GammaWave Wave 1/2 + Hearth Physics presets */
    {"SOLAR BASS", {7, 11, 64, 6, 54, 68, 72, -12}, {0, 62, 85, 32}, 44, 1, FX(40, 10, 18, 12), PAT(14),
     {XP(P_LRATE, 28), XP(P_LWAVE, 1), XP(P_LD_FLT, 8), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18)}},
    {"PDRESO ACID", {5, 16, 82, 4, 46, 108, 64, 0}, {0, 56, 25, 28}, 54, 1, FX(44, 8, 36, 18), PAT(14),
     {XP(P_LRATE, 42), XP(P_LWAVE, 4), XP(P_LD_FLT, 10), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 26)}},
    {"BITSINE ARP", {6, 14, 70, 8, 88, 36, 35, 12}, {0, 74, 40, 52}, 32, 0, FX(24, 38, 52, 46), PAT(15),
     {XP(P_LRATE, 52), XP(P_LWAVE, 3), XP(P_LD_FLT, 14), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 16)}},
    {"SINGULARITY", {5, 24, 96, 18, 52, 88, 95, -12}, {4, 78, 92, 46}, 48, 1, FX(56, 22, 32, 26), PAT(16),
     {XP(P_LRATE, 24), XP(P_LWAVE, 6), XP(P_LD_FLT, 20), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 14)}},
    {"PHOTOSPHERE", {4, 22, 64, 14, 78, 40, 28, 7}, {48, 92, 110, 94}, 22, 0, FX(10, 62, 44, 86), PAT(17),
     {XP(P_LRATE, 18), XP(P_LWAVE, 6), XP(P_LD_FLT, 14), XP(P_LD_AMP, 6), XP(P_LSHP, -20), XP(P_HARM, 16)}},
    {"ANALOG DRFT", {0, 19, 64, 6, 72, 32, 18, 0}, {18, 84, 96, 76}, 24, 0, FX(8, 52, 42, 70), PAT(15),
     {XP(P_LRATE, 22), XP(P_LWAVE, 1), XP(P_LD_FLT, 16), XP(P_M1SRC, 7), XP(P_M1DST, 2), XP(P_M1AMT, 10)}},
    /* (1.2-GW, issue #17: ambient and expressive) a pad that drifts by itself (a slow LFO on the filter, each note its own
     * mix), a string machine (three saws, the ensemble chorus), a drone on a fifth that breathes */
    {"EVOLVE PAD", {AW_SAW3, 46, 64, 4, 58, 22, 0, 0}, {92, 90, 112, 100}, 8, 0, FX(0, 64, 22, 82), PAT(5),
     {XP(P_LRATE, 14), XP(P_LWAVE, 1), XP(P_LFADE, 70), XP(P_LD_FLT, 16), XP(P_M1SRC, 5), XP(P_M1DST, 14)}},
    {"SOLINA", {AW_SAW3, 30, 70, 0, 88, 8, 0, 0}, {50, 90, 118, 82}, 0, 0, FX(0, 115, 10, 70), PAT(5),
     {XP(P_LRATE, 52), XP(P_LD_PIT, 2), XP(P_LEVEL, 88), XP(P_LSHP, 24)}},
    {"DEEP DRONE", {0, 20, 50, 10, 42, 70, 20, 7}, {100, 90, 127, 110}, 0, 0, FX(10, 40, 30, 95), PAT(5),
     {XP(P_LRATE, 8), XP(P_LWAVE, 1), XP(P_LD_FLT, 20), XP(P_LD_AMP, 18), XP(P_LEVEL, 114), XP(P_LSHP, 28)}},
    /* (QUANTUM // QG-1) 808 and drill slides (LEGATO glide), reese, the dirty waves, the filter types as sounds of their own, and
     * pads that move by themselves (the NOISE wander on the cutoff) */
    {"808 BOOM", {3, 0, 0, 0, 60, 0, 40, 0}, {0, 80, 60, 40}, 0, 1, FX(25, 0, 0, 5), PAT(2),
     {XP(P_GLIDE, 36), XP(P_ELOOP, 2)}},
    {"DRILL SLIDE", {3, 4, 30, 0, 64, 10, 55, -12}, {0, 90, 80, 45}, 0, 1, FX(35, 0, 0, 8), PAT(14),
     {XP(P_GLIDE, 58), XP(P_ELOOP, 2)}},
    {"REESE QUAKE", {AW_SAW3, 24, 64, 4, 50, 50, 70, -12}, {4, 80, 110, 40}, 30, 1, FX(40, 30, 10, 15), PAT(8),
     {XP(P_LRATE, 20), XP(P_LD_FLT, 14), XP(P_HARM, -12), XP(P_LSHP, -18)}},
    {"TUBE KEYS", {AW_TUBE, 8, 50, 0, 80, 20, 30, 12}, {0, 82, 40, 60}, 20, 0, FX(12, 32, 28, 42), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 22), XP(P_M2SRC, 7), XP(P_M2DST, 11), XP(P_M2AMT, 8)}},
    {"FOLD LEAD", {AW_FOLD, 10, 64, 0, 92, 28, 40, 7}, {2, 72, 100, 45}, 22, 1, FX(20, 10, 45, 30), PAT(4),
     {XP(P_LFADE, 50), XP(P_LD_PIT, 3), XP(P_HARM, 26), XP(P_LSHP, -16)}},
    {"HYPER SAW", {AW_SAW3, 70, 64, 0, 96, 20, 15, 12}, {6, 80, 110, 55}, 10, 0, FX(0, 74, 42, 58), PAT(13),
     {XP(P_LRATE, 26), XP(P_LWAVE, 1), XP(P_LD_FLT, 10), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 16)}},
    {"COMB PLUCK", {0, 6, 50, 10, 70, 80, 0, 0}, {0, 70, 0, 55}, 40, 0, FX(0, 14, 44, 42), PAT(15),
     {XP(P_LRATE, 24), XP(P_LWAVE, 1), XP(P_LD_FLT, 10), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 24)}},
    {"VOWEL BASS", {0, 12, 64, 0, 60, 70, 50, -12}, {0, 70, 90, 30}, 36, 1, FX(30, 0, 10, 10), PAT(8),
     {XP(P_FTYPE, 4), XP(P_LRATE, 40), XP(P_LD_FLT, 24), XP(P_HARM, 10)}},
    {"SCREAM LEAD", {AW_SYNC, 14, 90, 4, 76, 90, 70, 0}, {2, 70, 95, 40}, 40, 1, FX(45, 10, 40, 25), PAT(4),
     {XP(P_FTYPE, 5), XP(P_HARM, 30)}},
    {"QUANTUM PAD", {AW_SAW3, 36, 64, 6, 62, 30, 10, 7}, {85, 92, 115, 100}, 12, 0, FX(0, 80, 35, 90), PAT(17),
     {XP(P_LRATE, 10), XP(P_LWAVE, 1), XP(P_LD_FLT, 18), XP(P_M1SRC, 14), XP(P_M1DST, 2), XP(P_M1AMT, 10)}},
    {"TRAP PLUCK", {0, 10, 50, 0, 40, 30, 10, 12}, {0, 76, 0, 50}, 50, 0, FX(0, 22, 58, 38), PAT(15),
     {XP(P_LRATE, 20), XP(P_LWAVE, 1), XP(P_LD_FLT, 10), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 22)}},
    {"CHERENKOV LD", {AW_RING, 20, 80, 0, 90, 30, 20, 0}, {2, 74, 90, 50}, 16, 1, FX(10, 20, 50, 40), PAT(4),
     {XP(P_LRATE, 58), XP(P_LFADE, 60), XP(P_LD_PIT, 2), XP(P_HARM, 24)}},
    /* (QG-1 EXPANSION: Ambient, Drones, Evolving Pads, Organic Plucks) */
    {"BOREALIS PAD", {AW_SAW3, 32, 64, 8, 68, 24, 0, 12}, {90, 92, 118, 105}, 10, 0, FX(0, 85, 30, 92), PAT(5),
     {XP(P_LRATE, 10), XP(P_LWAVE, 1), XP(P_LD_FLT, 22), XP(P_LEVEL, 119), XP(P_LSHP, 30), XP(P_HARM, -14)}},
    {"NEBULA DRONE", {AW_TUBE, 18, 55, 6, 48, 62, 18, 7}, {110, 90, 125, 115}, 0, 0, FX(12, 45, 35, 95), PAT(5),
     {XP(P_LRATE, 6), XP(P_LWAVE, 1), XP(P_LD_FLT, 16), XP(P_LD_AMP, 14), XP(P_LEVEL, 124), XP(P_LSHP, 26)}},
    {"AURA STRINGS", {4, 26, 70, 0, 78, 16, 0, 7}, {65, 88, 112, 90}, 5, 0, FX(0, 68, 28, 72), PAT(5),
     {XP(P_LRATE, 15), XP(P_LWAVE, 1), XP(P_LD_FLT, 12), XP(P_LD_AMP, 8), XP(P_LSHP, 20)}},
    {"SOLARIS GLOW", {AW_FOLD, 14, 60, 4, 72, 35, 30, 0}, {80, 90, 115, 95}, 14, 0, FX(6, 72, 42, 86), PAT(5),
     {XP(P_LRATE, 17), XP(P_LWAVE, 6), XP(P_LD_FLT, 12), XP(P_M1SRC, 7), XP(P_M1DST, 2), XP(P_M1AMT, 10)}},
    {"WOOD PLUCK", {0, 6, 50, 0, 42, 28, 0, 0}, {0, 72, 0, 45}, 45, 0, FX(0, 18, 46, 32), PAT(15),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 26), XP(P_ELOOP, 2)}},
    {"BAMBOO FLUTE", {3, 10, 40, 30, 68, 20, 0, 12}, {18, 75, 40, 55}, 15, 0, FX(0, 38, 34, 66), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 14), XP(P_M2SRC, 7), XP(P_M2DST, 11), XP(P_M2AMT, 12)}},
    {"HARP PLUCK", {3, 8, 60, 0, 74, 58, 0, 12}, {0, 72, 0, 45}, 62, 0, FX(0, 26, 46, 52), PAT(15),
     {XP(P_LRATE, 22), XP(P_LWAVE, 1), XP(P_LD_FLT, 8), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 24)}},

    /* (QG-1 1.6) EVOLVE / MOTION: the EVO wave (a smooth random walk) at a musical division, the matrix on top */
    {"QUANTUM BLOOM", {AW_SAW3, 40, 66, 4, 58, 26, 6, 7}, {96, 94, 120, 108}, 10, 0, FX(0, 72, 28, 88), PAT(5),
     {XP(P_LRATE, -1), XP(P_LWAVE, 6), XP(P_LFADE, 90), XP(P_LD_FLT, 24), XP(P_LD_AMP, 14), XP(P_LEVEL, 114)}},
    {"ABYSSAL DRONE", {AW_TUBE, 20, 58, 10, 44, 58, 14, -12}, {112, 90, 126, 118}, 0, 0, FX(10, 50, 32, 72), PAT(5),
     {XP(P_LRATE, 5), XP(P_LWAVE, 6), XP(P_LD_FLT, 30), XP(P_LD_SHP, 18), XP(P_LD_AMP, 8), XP(P_LEVEL, 125)}},
    {"PRISM KEYS", {4, 12, 70, 0, 66, 18, 0, 12}, {0, 84, 40, 60}, 30, 0, FX(0, 40, 35, 55), PAT(6),
     {XP(P_M1AMT, 46), XP(P_M2AMT, 30), XP(P_HARM, 14)}},
    {"GLASS BELL", {AW_RING, 18, 80, 0, 84, 24, 0, 12}, {0, 92, 0, 88}, 42, 0, FX(0, 30, 40, 78), PAT(7),
     {XP(P_M1AMT, 50), XP(P_M2AMT, 34), XP(P_HARM, 20)}},
    {"AURORA PLUCK", {AW_FOLD, 8, 58, 2, 48, 30, 12, 0}, {0, 74, 0, 52}, 46, 0, FX(0, 25, 52, 45), PAT(15),
     {XP(P_M1AMT, 52), XP(P_M2AMT, 26), XP(P_ELOOP, 2), XP(P_HARM, 10)}},


    {"OCEANIC PAD", {AW_SAW3, 34, 68, 12, 54, 32, 0, 7}, {104, 94, 122, 112}, 6, 0, FX(0, 78, 34, 90), PAT(5),
     {XP(P_LRATE, 7), XP(P_LWAVE, 6), XP(P_LD_FLT, 26), XP(P_LD_AMP, 10), XP(P_LEVEL, 119), XP(P_LSHP, 30)}},
    {"EMBER LEAD", {AW_TUBE, 16, 74, 0, 70, 40, 34, 12}, {4, 72, 92, 48}, 24, 1, FX(28, 20, 42, 30), PAT(4),
     {XP(P_M1AMT, 34), XP(P_M2AMT, 18), XP(P_HARM, 22)}},
    /* (6.0) the remaster's new sounds: one per family, each with its own motion and sends */
    {"NEON RIDER", {0, 14, 64, 0, 88, 34, 22, 7}, {2, 72, 98, 46}, 26, 1, FX(18, 16, 46, 30), PAT(4),
     {XP(P_LRATE, 44), XP(P_LWAVE, 1), XP(P_LD_FLT, 10), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 22)}},  /* A: lead */
    {"VELVET SCREAM", {8, 20, 70, 0, 74, 44, 38, 12}, {6, 74, 92, 50}, 30, 1, FX(26, 18, 40, 28), PAT(4),
     {XP(P_LRATE, 36), XP(P_LWAVE, 4), XP(P_LD_FLT, 12), XP(P_M1SRC, 7), XP(P_M1DST, 11), XP(P_M1AMT, 10)}},  /* A: TUBE lead */
    {"GLASS BLADE", {5, 24, 80, 0, 86, 26, 14, 0}, {1, 68, 90, 40}, 18, 1, FX(10, 20, 50, 34), PAT(3),
     {XP(P_LRATE, 48), XP(P_LWAVE, 2), XP(P_LD_FLT, 8), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 20)}},  /* A: sync lead */
    {"NIGHT SHIFT", {1, 0, 50, 0, 54, 58, 34, -12}, {0, 58, 70, 24}, 32, 1, FX(30, 0, 6, 4), PAT(2),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 20), XP(P_HARM, -16)}},  /* E: analog bass */
    {"MOLTEN CORE", {9, 16, 64, 0, 52, 72, 68, -12}, {0, 64, 86, 30}, 44, 1, FX(44, 0, 0, 6), PAT(2),
     {XP(P_LRATE, 28), XP(P_LWAVE, 4), XP(P_LD_SHP, 14), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 16)}},  /* E: folded bass */
    {"PAPER LANTERN", {4, 18, 60, 2, 64, 18, 6, 7}, {72, 92, 110, 96}, 10, 0, FX(0, 58, 28, 72), PAT(5),
     {XP(P_LRATE, 19), XP(P_LWAVE, 6), XP(P_LD_FLT, 14), XP(P_LD_AMP, 8), XP(P_LSHP, 18)}},  /* B: pad */
    {"SLOW TIDE", {7, 38, 64, 6, 58, 26, 8, 12}, {84, 94, 116, 102}, 14, 0, FX(0, 64, 30, 80), PAT(5),
     {XP(P_LRATE, 21), XP(P_LWAVE, 6), XP(P_LD_FLT, 16), XP(P_M1SRC, 7), XP(P_M1DST, 2), XP(P_M1AMT, 10)}},  /* B: SAW3 pad */
    {"AMBER GLASS", {2, 8, 56, 0, 96, 14, 0, 12}, {0, 86, 34, 64}, 24, 0, FX(0, 30, 34, 50), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 24), XP(P_HARM, 16)}},  /* C: keys */
    {"TIN ROOF", {6, 14, 80, 0, 102, 22, 0, 12}, {0, 84, 0, 70}, 30, 0, FX(0, 22, 42, 44), PAT(3),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 24), XP(P_LRATE, 20), XP(P_LWAVE, 1), XP(P_LD_AMP, 6)}},  /* C: RING pluck */
    {"CLOCKWORK", {1, 6, 52, 0, 72, 44, 10, 12}, {0, 72, 20, 44}, 34, 0, FX(0, 26, 52, 30), PAT(8),
     {XP(P_LRATE, 58), XP(P_LWAVE, 3), XP(P_LD_FLT, 12), XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18)}},  /* A: arp */
    {"PUENTE DE LUZ", {0, 16, 66, 0, 80, 30, 18, 7}, {10, 76, 94, 58}, 20, 1, FX(12, 30, 48, 36), PAT(4),
     {XP(P_LRATE, 34), XP(P_LWAVE, 1), XP(P_LD_PIT, 5), XP(P_M1SRC, 7), XP(P_M1DST, 11), XP(P_M1AMT, 10)}},  /* G: lead */
    {"SIESTA DORADA", {6, 8, 96, 6, 52, 40, 28, -12}, {58, 90, 108, 92}, 12, 0, FX(0, 62, 30, 76), PAT(5),
     {XP(P_LRATE, 17), XP(P_LWAVE, 6), XP(P_LD_FLT, 12), XP(P_LD_AMP, 6), XP(P_LSHP, 22)}},  /* G: warm pad */
    {"AURORA DRIFT", {7, 38, 64, 6, 58, 20, 8, 12}, {44, 96, 118, 104}, 16, 0, FX(34, 58, 34, 84), PAT(5),
     {XP(P_LRATE, 13), XP(P_LWAVE, 6), XP(P_LD_FLT, 18), XP(P_M1SRC, 7), XP(P_M1DST, 2), XP(P_M1AMT, 12)}},  /* (v1.5.19) a slow pad whose cut breathes with the wheel */
    /* (FASE 6) the bank's own demos: each one names the function it was written for, so the sound is a
     * demonstration and not only a sound. NOTCH PAD is the filter type that played as LP until v1.12.14 put all
     * eight on the per-voice filter; PUMP PAD is the LFO shape TRAP, which holds at both ends where a triangle
     * only passes through them; STEP LEAD is STEP, the staircase that repeats every cycle; CRUSH BASS is DIST's
     * sixth model, the one that takes resolution away instead of adding harmonics. */
    {"NOTCH PAD", {AW_SAW3, 22, 64, 6, 74, 26, 0, 12}, {80, 90, 112, 95}, 8, 0, FX(0, 62, 30, 78), PAT(5),
     {XP(P_FTYPE, 6), XP(P_LRATE, 20), XP(P_LWAVE, 1), XP(P_LD_FLT, 24), XP(P_LSHP, 22), XP(P_HARM, 10)}},
    {"PUMP PAD", {0, 18, 64, 4, 58, 14, 0, 0}, {70, 88, 112, 100}, 6, 0, FX(0, 60, 28, 80), PAT(5),
     {XP(P_LWAVE, 10), XP(P_LRATE, -4), XP(P_LD_AMP, 44), XP(P_LFADE, 60), XP(P_FTYPE, 7), XP(P_LD_FLT, 6)}},
    {"STAIR LEAD", {0, 16, 70, 0, 70, 40, 20, 0}, {2, 68, 100, 45}, 30, 1, FX(24, 12, 40, 28), PAT(4),
     {XP(P_LWAVE, 11), XP(P_LRATE, 12), XP(P_LD_FLT, 30), XP(P_LFADE, 40), XP(P_LSHP, 18), XP(P_HARM, 16)}},
    {"CRUSH BASS", {1, 0, 0, 0, 46, 62, 30, -12}, {0, 62, 45, 30}, 28, 1, FX(64, 0, 0, 6), PAT(2),
     {XP(P_DTYPE, 5), XP(P_DTONE, 18), XP(P_LRATE, 28), XP(P_LWAVE, 4), XP(P_LD_FLT, 18), XP(P_HARM, 8)}},
};

static const param_desc_t ANALOG_CH[2] = {
    {"KTR+", F_PCTINV, 0, 127, 127, 0, 0}, {"TONE", F_PCTINV, 0, 127, 127, 0, 0},
};

static const engine_t ENG_ANALOG = {
    .name = "ANALOG",
    .page_title = {"OSC", "FLT", "CHAR"},
    .edit = {
        {"WAVE", F_ENUM, 0, 10, 0, N_ANALOG_WAVE, 0},  /* (1.0-GW: TUBE FOLD appended; FASE 2: PM) */
        {"DETUNE", F_INT, 0, 127, 10, 0, "ct"},
        {"MIX", F_PCT, 0, 127, 64, 0, 0},
        {"NOISE", F_PCT, 0, 127, 0, 0, 0},
        {"CUT", F_CUTOFF, 0, 127, 90, 0, 0},
        {"RES", F_PCT, 0, 127, 30, 0, 0},
        {"DRIVE", F_PCT, 0, 127, 0, 0, 0},
        {"INT", F_SEMI, -24, 24, 0, 0, 0},             /* (JIANT 0.4: osc 2's interval, was KTR: the filter's key
                                                         * tracking, fixed at its old default, half) */
    },
    .presets = ANALOG_PRESETS,
    .npresets = NELEM(ANALOG_PRESETS),
    .ch = ANALOG_CH,
    .ch_n = 2,
    .note_on = analog_note_on,
    .render = analog_dispatch,
    .knob = {P_E4, P_E5, P_ATK, P_REL},
    .keep = 0x03,                /* the filter */
};
