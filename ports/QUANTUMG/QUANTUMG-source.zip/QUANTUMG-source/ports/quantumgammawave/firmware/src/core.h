/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* FELUCCA core types: tracks, voices, engines, parameters.
 * Four tracks, each a synth part: its own engine, preset, parameters, voices and 64-step
 * pattern. The parts share one budget of NVOICE sounding voices (voice.c). Drums are the DRUM
 * engine (General MIDI map) on any part; the SAMPLE engine's PERC set is retired (drum_from_perc).
 * Sections: sizes, parameters, voices and engines, tracks and the song, system. */
#include <stdint.h>

/* (1.8) Audio meters published by fx.c: 0..2 the chorus/delay/reverb sends, 3..5 their wet returns. */
extern volatile int32_t fx_vu[8];
/* (3.6) One meter's ballistics, the FX page's four bars and any other bar that reads a bus: an immediate
 * attack (the level the DSP measured this block is shown at once), a release that falls a quarter of the
 * way each frame (so a peak between two frames is still seen and the bar does not snap), and a peak hold
 * that stands 30 frames over the bar and then falls a pixel a frame. Pure arithmetic on three bytes: no
 * state of its own, a few instructions per meter per frame. target and the result are px, 0..mh. */
/* (v1.8.4) A PEAK FROM fx.c AS THE PAGE'S 0..255 TARGET. fx.c measures |x| of the part's own sample after
 * its FX (Q15, 0..32767); the FX page's four bars used to divide by 7000, a scale left over from the old
 * 0..7000 envelope, so a plain note (17 638 on the probe) clamped the DIST card at the top and read as "1 %
 * of distortion pegs the meter". One helper, so the page and tests/fx_meter_test.c cannot drift apart again. */
static inline int32_t fx_meter_target(int32_t pk)
{
    if (pk < 0)
        pk = -pk;
    if (pk > 32767)
        pk = 32767;
    return pk * 255 / 32767;
}

static inline int32_t fx_meter_step(uint8_t *vu, uint8_t *hold, uint8_t *hold_t, int32_t target, int32_t mh)
{
    int32_t v;
    if (target < 0) target = 0;
    if (target > mh) target = mh;
    v = *vu;
    if (target >= v)
        v = target;                                   /* attack: immediate, like a real meter */
    else
        v -= (v - target + 3) / 4;                    /* release: a quarter of the way, a frame */
    *vu = (uint8_t)v;
    if (v >= (int32_t)*hold) {
        *hold = (uint8_t)v;                           /* a new peak: the hold takes it and waits again */
        *hold_t = 0;
    } else if (++(*hold_t) >= 30u) {
        *hold_t = 30u;
        if (*hold)
            (*hold)--;                                /* 30 frames of rest, then a pixel a frame */
    }
    return v;
}
/* (2.1) the level a factory preset loads with, measured from its own render (preset_level.c,
 * tools/gen_preset_levels.py): 100 is the fader's own, untouched, 0..127 are LEVEL_Q12 indices */
uint8_t preset_level_of(uint32_t e, uint32_t pi);   /* 0..2 the chorus/delay/reverb sends, 3..5 their wet returns,
                                     * (2.1) 6..7 the mix's own left and right peaks: the two mono
                                     * meters HOME shows */
/* (3.0) The delay's echo train, measured -- not inferred from a level. A hit at the delay's send
 * starts repeat 1 one delay time later, repeat 2 one time after that, and so on; fx_buses peaks the
 * wet return inside each of those windows (fx_dly_rep[0] is repeat 1). Zero when nothing is ringing,
 * so the page shows no bars at all rather than a silent VU. fx_dly_gen is the repeat sounding now
 * (0: the hit itself, 1..6 the repeats) and fx_dly_frac is 0..256 through its period. */
extern volatile int32_t fx_dly_rep[6];
extern volatile uint8_t fx_dly_gen;
extern volatile uint16_t fx_dly_frac;
/* (1.8) dB response of the master EQ at a 0..127 frequency index, Q8 dB (0 = 0 dB). */
int32_t fx_master_eq_db(int32_t freq_idx);
/* (1.8.6) the same response at a real frequency in Hz (20..20000), for the graph's log axis. */
int32_t fx_master_eq_hz_db(int32_t hz);

/* ------------------------------------------------------------ sizes --- */
#ifndef NVOICE
#define NVOICE 12                /* voices per part, and the budget shared by all parts (3.8: was 10). The pool
                                  * (below) is what made 12 affordable: at 12 voices the .bss is smaller than the
                                  * 10-voice build of 3.7 was. Overridable: FELUCCA_VOICES=10/12 for the target
                                  * (tools/build.py) and POLY=10/12 for the host tests (tests/run_tests.sh). */
#endif
/* (3.5) the voice pool. A part used to own NVOICE voice_t of storage of its own, so six parts reserved
 * NPART * NVOICE slots for a budget of NVOICE voices that sound at once. Now one pool holds the storage and
 * each part publishes a window of slots into it (track_t.vidx / vn): the addresses, the sound and the
 * allocator read the same way, but six parts no longer cost six times the storage.
 *
 * VDEAD is the pool's inert slot: a window's tail (entries vn..NVOICE-1) points at it, so a scan that still
 * runs to NVOICE reads a voice that is never active, never free and never stolen. Nothing is granted it. */
#ifndef VPOOLN
#define VPOOLN (NVOICE + NPART)       /* slots in the pool (its inert slot included): the budget plus one slot
                                  * of slack for every other part, which is what lets a single part reach its
                                  * own cap while five parts keep one each (measured, docs/VOICE_POOL.md).
                                  * FELUCCA_VPOOL=N overrides it (tools/build.py). */
#endif
#define VDEAD (VPOOLN - 1)            /* the pool's last slot: inert, and never granted to a part */
/* (v1.5.23, FASE 2) WHAT A CHORD KEEPS WHILE A PART IS BUSY CHANGING SOUND, AND WHY IT IS SPLIT IN TWO.
 * track_t.xp_note/xp_vel keep the notes pressed while an engine switch fades (engine_block replays them on the new
 * engine) and track_t.mono_stack keeps the keys a MONO / LEGATO part still has down (mono_pick decides again from it
 * on every release). Both held four / eight, so a twelve-key chord -- the pool's own size -- lost eight of them at a
 * preset change that switches engine, and a LEGATO part with PRIO LOW/HIGH could lose the key that decides the pitch.
 * The capacity is now NVOICE; the storage is NOT.
 *
 * track_t IS 1 760 B AND THE WHOLE INSTRUMENT READS IT: inserting those bytes where the arrays live moved every field
 * after them and every `trk[i].field` in the UI paid for a longer displacement. Measured, the AC791N `--release`
 * build: the two arrays grown in place take the image from 581 816 to 584 768 B (**+2 952 B** of XIP against a 1 796 B
 * free slot: it does not link), and at the end of the struct 584 736 B (+2 920). The growth is not in the files that
 * changed: `nm --size-sort` on the two objects puts it in ui_input_frame +608, gen_make +210, graph_signature +182,
 * draw_graph +170, tools_key +210 .. -- one longer displacement each, thousands of times. Beside the tracks the same
 * capacity costs **+160 B** of flash and 128 B of .bss, which is what this does. */
#ifndef XP_N
#define XP_N NVOICE                   /* notes a part keeps across a sound load, capacity (overridable, as NVOICE:
                                       * the host build with -DXP_N=4 is how the v1.5.22 behaviour is measured
                                       * beside it, tests/poly_phase2_test.c) */
#endif
#ifndef MONO_STACK_N
#define MONO_STACK_N NVOICE           /* keys held by a MONO / LEGATO / UNISON part's stack (same override) */
#endif
#define XP_IN_T 4                     /* of those, the ones track_t carries (its layout is frozen: above) */
#define MS_IN_T 8
_Static_assert(XP_N >= XP_IN_T && MONO_STACK_N >= MS_IN_T, "the in-struct slots are the first of the capacity");
/* (FASE 3) MENU > AUDIO > VOICES: how many voices the parts may sound together, 8, 10 or 12 (12 ships).
 * NVOICE and VPOOLN above are the storage the pool is built for and never change with the setting, so
 * turning the polyphony down costs nothing in .bss and nothing in the render loop: the cap is one
 * comparison in voice.c voice_cap/trk_vcap. 0 = 12, which is what every settings record written before
 * this setting existed holds, so a project or a unit that never touched it sounds exactly as it did. */
extern volatile uint8_t voice_ucap;
#define VOICE_UCAP_N 3u               /* 8, 10, 12 (menu_items.c VOICES_N, in that order) */
uint32_t voice_budget(void);            /* voice.c: the cap the allocator applies right now */
static inline uint32_t voice_user_budget(void)
{
    return voice_ucap == 2u ? 8u : voice_ucap == 1u ? 10u : (uint32_t)NVOICE;
}
/* (3.6) the experiments behind docs/VOICE_POOL.md. Both change the sound of the instrument (see that page), so
 * both are OFF by default and no shipped profile sets them. */
#ifndef FELUCCA_VRESET
#define FELUCCA_VRESET 1              /* a voice starting from silence clears its oscillator / filter state: the
                                       * pool lends slots between parts, and nothing may inherit another note's
                                       * oscillators. 0 restores the pre-pool sound exactly (docs/VOICE_POOL.md) */
#endif
#ifndef FELUCCA_WSEED
#define FELUCCA_WSEED 1               /* WHEEL seeds its wheels from the voice's place in its part, and reseeds a
                                       * slot with no note on it, never from the pool slot number */
#endif
/* (FASE 1) is the other core rendering a block right now? 0 on the host and in a one-core build; the firmware
 * (felucca.c) points it at fm1_mc_job_busy(), and voice.c postpones a note it cannot place safely. */
#ifndef FELUCCA_MC_BUSY
#define FELUCCA_MC_BUSY() 0
#endif
#define NPART 6                  /* synth parts: tracks 1..6 (JIANT 0.6: was 4) */
#define NTRK NPART               /* tracks (the formats and the protocol count these): every track is a part */
#define NSTEP 64
#define HALF_FRAMES 128          /* I2S half buffer: 2.9 ms at 44.1 kHz (a key waits 0..1 half, then plays 1 half later) */
#ifndef FELUCCA_FM4
#define FELUCCA_FM4 0            /* the DIGITAL engine (eng_digital.c, four-operator FM): kept in the tree, not built
                                  * by default; replaced by FM6, its sounds convert (fm4_convert.c) */
#endif
#define NENGINES 16              /* the stores' engine numbers 0..15 (engines.c ENGINES[], append-only) */
#define ENGI_DIGITAL 1u          /* reserved without FELUCCA_FM4: never selectable (eng_ok), its sounds load as FM6 */
#define NENG_SHOWN (NENGINES - !FELUCCA_FM4 - 5)   /* the engines one can pick: PRESETS, the EDIT layer, the editor,
                                                * in the display order of engines.c ENGINE_ORDER (PHYS 9, and in
                                                * JIANT SAMPLE 4, GRAIN 8, SLICE 13: retired) */
/* (FASE 2) the factory categories the browser filters by: tools/gen_preset_categories.py, four bits a sound,
 * indexed by the engine and the sound's index in its table (PCAT_BASE, PCAT_NIB, PCAT_NAME, pcat_of) */
#include "preset_cats.h"
/* (JIANT 0.6.71) the second core (hal/fm1_multicore.h; fx.c mix_block hands it some synth tracks). MC_CPU(): the core
 * running this, for the scratch each core has its own of (fx.c part_buf and the mix, mod.c's matrix, fm6_core.c's
 * buses, voice.c's filter flags). The host (tests): no second core; mc_host runs its jobs at once, as core 1 */
#ifndef FELUCCA_DUAL_CORE
#define FELUCCA_DUAL_CORE 0
#endif
#if FELUCCA_DUAL_CORE
#define MC_CPU() fm1_cnum()
#else
static uint8_t mc_host, mc_host_cpu;     /* tests: 1 = jobs handed over (run at once); the core "running" */
#define MC_CPU() ((uint32_t)mc_host_cpu)
#endif
/* (JIANT 0.6.78) the hottest audio code in RAM, for core 0 (felucca.c FELUCCA_HOTRAM): app.ld puts these functions'
 * sections (-ffunction-sections) in .hot_text by name, so the compiler builds them as before (this clang inlines
 * nothing across a section attribute, not even a static inline). Core 1 keeps running the flash copies (fx.c
 * mix_part_m, fx_run): it now and then reads a word of RAM wrong (hal/fm1_multicore.h) */
#ifndef FELUCCA_HOTRAM
#define FELUCCA_HOTRAM 1
#endif
/* (1.9.2) the MIDI Learn map: eight bindings of two bytes (CC + 1, then the parameter id or G_MAC1 + m; CC + 1 = 0
 * is an empty slot). It lives in the settings' favorites.factory[15][0..15], bytes no engine uses and 0 in every older
 * record, so nothing is migrated and a corrupt entry is ignored when it is read (midi_control.c). */
static uint8_t midi_learn_map[16];
#define UP_SLOTS 32u             /* user presets (upreset.c) */
#define NELEM(a) (sizeof(a) / sizeof((a)[0]))

/* ------------------------------------------------------- parameters --- */
enum {
    F_INT, F_PCT, F_BIPCT, F_TIME, F_LFOHZ, F_CUTOFF, F_DB, F_SEMI, F_ENUM, F_BPM, F_NOTE,
    F_ONOFF, F_OCT, F_STEPS,
    F_PCTINV                     /* (JIANT 0.6.37) a share of 127 shown and turned the other way: 0 is 100 % */
};

typedef struct {
    const char *label;
    uint8_t fmt;
    int16_t min, max, def;
    const char *const *names;   /* F_ENUM */
    const char *unit;           /* F_INT / F_ENUM optional unit */
} param_desc_t;

enum {                          /* per-track parameters */
    P_LEVEL,
    P_ATK, P_DEC, P_SUS, P_REL,
    P_ED_FLT, P_ED_PIT, P_ED_SHP, P_ED_FX,     /* P_ED_FX (once unused): JIANT 0.4's ENV LOOP, P_ELOOP */
    P_LRATE, P_LWAVE, P_LPHASE, P_LFADE,
    P_LD_PIT, P_LD_FLT, P_LD_SHP, P_LD_AMP,
    P_AMODE, P_ARATE, P_AOCT, P_AGATE,
    P_ASWING, P_APROB, P_AHOLD, P_AORDER,
    P_ROOT, P_SCALE, P_QUANT, P_TRANS,
    P_SLEN, P_SDIV, P_SSWING, P_SGATE,
    P_DIST, P_CHOR, P_DLY, P_REV,
    P_VOICE, P_GLIDE, P_PAN, P_MUTE,
    P_GLMODE, P_PRIO, P_ALLOC, P_DETUNE,
    P_SLCR, P_SLPAT, P_SLRATE, P_SLDEPTH,      /* SLICER insert (slicer.c) */
    P_M1SRC, P_M1DST, P_M1AMT,                 /* modulation matrix (mod.c): 4 slots of SRC, DST, AMT; */
    P_M2SRC, P_M2DST, P_M2AMT,                 /* new common parameters go just before P_E0 (user presets */
    P_M3SRC, P_M3DST, P_M3AMT,                 /* and projects map by count) */
    P_M4SRC, P_M4DST, P_M4AMT,
    P_FM1_ATK, P_FM1_DEC, P_FM1_SUS, P_FM1_REL, P_FM1_LEVEL,
    P_FM2_ATK, P_FM2_DEC, P_FM2_SUS, P_FM2_REL, P_FM2_LEVEL,
    P_FM3_ATK, P_FM3_DEC, P_FM3_SUS, P_FM3_REL, P_FM3_LEVEL,
    P_FM4_ATK, P_FM4_DEC, P_FM4_SUS, P_FM4_REL, P_FM4_LEVEL,
    P_SOFS, P_POFS,                            /* (JIANT; the former chord keys) the sequence offset: OFS steps, PIT semitones */
    P_LN0, P_LN1, P_LN2, P_LN3, P_LN4, P_LN5, P_LN6, P_LN7,   /* DRUM lane levels (eng_drum.c, #97): KICK .. BELL */
    P_DTYPE, P_DTONE,                          /* (JIANT, FUNB) DIST's type and tone (fx.c track_dist) */
    P_MSLEN, P_MSDIV, P_MSSLW,                 /* (JIANT, FUNB) the modulation sequence (mod.c MS_STEP): its length, */
    P_MS0, P_MS15 = P_MS0 + 15,                /* rate and slew, its 16 levels */
    P_FTYPE,                                   /* (JIANT 0.5) the filter's type: LP HP BP COMB (eng_analog.c, voice.c) */
    P_FCUT, P_FRES,                            /* .. every other engine's: a filter on the part's sum (voice.c track_filter) */
    P_MSTART, P_NRATE,                         /* (3.5) last of the common ones, as the count map wants them: M.STRT, a
                                               * note starts a little late, at random (voice.c); N.RATE, how long the
                                               * random wander (mod.c MS_NOISE) holds a point */
    P_HARM,                                    /* (v1.12.4) TILT: the per-voice spectral tilt (voice.c tilt_voice). It takes
                                                * a free id AFTER M.STRT and N.RATE (v1.12.13; it was inserted above them
                                                * and moved both): P_COUNT goes 125 -> 126 of the 127 the 7-bit motion
                                                * records name, and a store written before it reads 0 (OFF, its default),
                                                * so every project, preset and unit sounds exactly as it did */
    P_LSHP,                                    /* (v1.12.5) LFO CURVE: the phase's own bend (voice.c lfo_skew).
                                                * (v1.12.13) AFTER M.STRT and N.RATE, not above them: it was inserted
                                                * between FRES and M.STRT and moved both, so a store written before
                                                * v1.12.4 read its M.STRT as the tilt and its N.RATE as the curve.
                                                * With it P_COUNT reaches 127, the last id the 7-bit motion records
                                                * can name: the parameter space is FULL, and the next one needs a
                                                * new store format rather than a slot */
    P_E0, P_E1, P_E2, P_E3, P_E4, P_E5, P_E6, P_E7,
    P_COUNT
};
#define P_LRTRG P_FM1_ATK              /* (JIANT 0.6.12) LOFI BYTE / FLOAT's RTRG: a note restarts the formula's time (voice.c
                                         * voice_start), in a slot of the retired DIGITAL's (0: OFF, its default) */
#define P_TCHAN P_FM1_DEC              /* (JIANT 0.6.37) SHIFT > CHANCE: how much of the track's steps it skips, 0 none (100 %,
                                         * every project and preset before it); seq.c trk_chance; DIGITAL's OP1 DEC slot */
/* (JIANT 0.6.43) MUTATE (project.c mutate_poll), in DIGITAL's OP1 REL / OP2 slots (0, every project and preset before it:
 * OFF, 0 %, ORBIT): SOUND and PATTERN every OFF / 1 / 2 / 4 / 8 / 16 / 32 bars, AMOUNT, MODE ORBIT / DRIFT */
#define P_MSND P_FM1_REL
#define P_MPAT P_FM2_ATK
#define P_MAMT P_FM2_DEC
#define P_MMODE P_FM2_REL
#define P_MORPH P_FM3_ATK              /* (JIANT 0.6.45) EDIT > MORPH: ANALOG PHASE LOFI's wave on towards the next ones
                                         * (0: as WAVE has it; every project and preset before it), in DIGITAL's slot */
#define P_CLEN P_FM3_DEC               /* (JIANT 0.6.47) SHIFT > C.LEN: the step components as a lane of their own, steps
                                         * 1..C.LEN's read in turn as the track plays (polymetric over the steps); 0 OFF
                                         * (each step its own: every project and preset before it); seq.c comp_lane */
#define P_DXIMG P_FM3_REL              /* (JIANT 0.6.48) a DRUM track's EDIT > IMAGE: one knob through the kit's pan maps
                                         * (eng_drum.c dx_img_pan; 0: every sound in the middle, as before) */
/* (JIANT 0.6.81) SCL > CHORD (seq.c chord_build), in DIGITAL's OP4 slots (0, every project and preset before it: OFF,
 * CLOSE, no strum) */
#define P_CHRD P_FM4_ATK               /* OFF; in the scale: TRIAD 7TH ADD9 SUS2 SUS4; any key: MAJ MIN 7 MAJ7 MIN7 POWER */
#define P_CVOI P_FM4_DEC               /* CLOSE, LEAD (each chord the inversion nearest the last), OPEN, +BASS */
#define P_CSTR P_FM4_REL               /* STRUM: 0 at once; up to ~63 ms between the notes, low to high */
/* (JIANT 0.6.87) SEQ > HUMAN, in DIGITAL's OP1 SUS / LEVEL and OP2 SUS slots (127, every project and preset before
 * it: shown as 0 %, none): how much each note's VELOCITY, TIME (a little late) and GATE vary at random as the sequencer
 * plays them (seq.c hum_amt); stored the other way round, 127 - the amount */
#define P_HVEL P_FM1_SUS
#define P_HTIM P_FM1_LEVEL
#define P_HGAT P_FM2_SUS
#define P_HRQ P_FM2_LEVEL              /* (0.6.88) SEQ > TIMING's REC Q: how much live recording snaps to the grid, 127 (every
                                         * project before it) 100 %: on it; less: the notes keep that much of where they were */
#define P_ELOOP P_ED_FX                /* (JIANT 0.4) ENV LOOP: OFF / ON (voice.c env_tick) */
/* (FASE 2) The engine CHARACTER bank. P_COUNT is at 125 of the 127 ids the motion records (7 bits) and the
 * stores can name, so the bank does not add parameters: it reuses the four values of the retired DIGITAL engine's
 * third and fourth operator envelopes (P_FM3_SUS / P_FM3_LEVEL / P_FM4_SUS / P_FM4_LEVEL), which every firmware
 * since JIANT stores and no page of a default build can reach. Their stored default is 127, so an old preset or
 * project reads as "0 %": the bank's amounts are neutral at 127 and full at 0 (F_PCTINV), and every engine's
 * DSP leaves the sound exactly as it was at 0. P_XCH (the track's MORPH value) is the third slot for the engines
 * that do not use MORPH themselves; it is neutral at 0. This keeps P_COUNT, every project format and every user
 * preset byte-compatible. */
#define P_X0 P_FM3_SUS
#define P_X1 P_FM3_LEVEL
#define P_X2 P_FM4_SUS                 /* LFO SLEW (voice.c track_lfo_tick) */
#define P_X3 P_FM4_LEVEL               /* LFO INVERT (..) */
#define P_XCH P_MORPH                  /* the third CHARACTER slot, on engines without a native MORPH */
static const uint8_t P_XID[4] = {P_X0, P_X1, P_X2, P_X3};
/* the amount of CHARACTER slot k, 0..127: 0 at the stored neutral 127 (P_X0..P_X3) */
static inline int32_t xamt(const int16_t *p, uint32_t k) { return 127 - p[P_XID[k & 3u]]; }
/* (JIANT 0.6.9) AUTO PAN (fx.c mix_part), in the slots of the old per-track SLICER (one on a bus since 0.6.3, its
 * slots stored, never read but by proj_sl_migrate). Laid so what old stores hold means OFF: DPTH where SLCR was (0, or
 * 1..2 from a project of before 0.6.3: inaudible), RATE where PAT was (1..16: slow), WAVE where RATE was (1: TRI), SYNC
 * where DEPTH was (127: BEAT) */
#define P_APDEP P_SLCR                 /* depth 0..127 (0: off) */
#define P_APRATE P_SLPAT               /* FREE: 0..127 as the LFO's RATE; BEAT: 0..7, 4 BARS .. 1/32 (fx.c AP_SIXT) */
#define P_APWAVE P_SLRATE              /* SIN TRI SAW SQR S&H (N_LWAVE) */
#define P_APSYNC P_SLDEPTH             /* FREE / BEAT (any value but 0: BEAT) */

enum {                          /* global parameters */
    G_BPM, G_SWING, G_CLOCK, G_TUNE,
    G_DTIME, G_DFDBK, G_DCOLOR, G_DMIX,
    G_RSIZE, G_RDAMP, G_CRATE, G_CDEPTH,
    G_MIDI, G_DREL, G_ROUTE, G_INFO,   /* G_DREL (JIANT): DUCK's release; was G_SYNC, a placeholder ("--", 0..0) */   /* G_ROUTE: MIDI IN, 0 CH1-4 (channels 1..4 -> parts 1..4, 5..16 ignored), 1 SEL (seq.c) */
    G_SLOT, G_NAME, G_LOAD, G_SAVE,
    G_ENGSEL, G_CLIP,           /* no page: the editor switches the engine with a SET of G_ENGSEL. G_CLIP (JIANT):
                                 * the master clipper; was G_ENGGO, unused (0..0) */
    G_CLRSEQ, G_INITSND,
    G_RTYPE,                    /* REVERB TYPE: 0 ROOM, 1 SPRING (fx.c). Was G_DRCH, the GM drum part's MIDI
                                 * channel (inert since 1.0, never read); projects of formats before FUN7 load it
                                 * as ROOM (project.c proj_rtype_room) */
    G_PUNCH, G_DUCK,            /* (JIANT) the drum bus's PUNCH and the kick's DUCK of the synths (fx.c, eng_drum.c).
                                 * Were G_DRLVL / G_DRREV, inert since 1.0 (0..0): the GM drum part's level and
                                 * reverb send, read only by the import of a project of before 1.0
                                 * (proj_drums_to_part, which clears them after) */
    G_NSTORE,                   /* the 27 a project's header holds (FUN7 on: their ids kept) */
    G_DHPF = G_NSTORE,          /* (JIANT, FUNB: after the punch-in lane, project.c) the delay's feedback low cut (0.4:
                                 * in DLY's TONE; stored, unused); 0.6.9: the CHORUS's STEREO (G_CSTER), */
    G_WIDTH,                    /* the buses' stereo width (the delay's right echo later, the chorus's taps apart), */
    G_RMOD, G_RRATE,            /* the reverb's modulation (ROOM: its combs' lengths; SPRING: its wobble) depth, rate, */
    G_RPRE,                     /* its pre-delay */
    G_RFILT, G_RWIDE,           /* (JIANT 0.3) the reverb's tone (darker / brighter) and width, */
    G_DPIT, G_DSPRY,            /* the delay's grains: their pitch (0: a plain delay) and spray */
    G_STRN,                     /* (JIANT 0.4) every sequence moved this many steps of its scale (seq.c seq_step) */
    G_SLMODE, G_SLPAT, G_SLRATE, G_SLDEP,   /* (JIANT 0.6.3) the SLICER, one on a bus (slicer.c): OFF / GATE / STUT, its */
    G_SLT1, G_SLT6 = G_SLT1 + 5, G_SLFX,    /* pattern, step, depth; which tracks go in (and FX: the delay, reverb and */
    G_SLPLEN, G_SLPQ,                       /* chorus returns); the repeats' pitch sequence: its length, CHR / SCL, */
    G_SLP0, G_SLP15 = G_SLP0 + 15,          /* its 16 steps (semitones) */
    G_DMOD,                     /* (0.6.86) the delay's tape drift (WOW and FLUTTER) depth (project.c: its own block, 'DM') */
    G_DTYPE, G_DPING,           /* (0.6.90) the delay's TYPE (ANALOG / DIGITAL) and PING-PONG (project.c: block 'DT') */
    G_CTYPE,                    /* (QG-1) the CHORUS bus's TYPE: CHORUS (the ensemble) / PHASER (fx.c cho_phaser; project.c:
                                 * bit 1 of block 'DT's TYPE byte, which a firmware before it masks off) */
    G_EQMODE, G_EQFREQ, G_EQGAIN, G_EQQ, /* (QG-1 v1.4) Parametric Master EQ: OFF/PEAK/NOTCH/LOWSH/HIGHSH, FREQ, GAIN, Q */
    G_MWIDTH,                   /* (QG-1 v1.4) Master Stereo Width 0..127, def 64 (100% neutral/bypass), 0 = mono sum */
    G_COUNT
};
#define G_SL_N (G_SLP15 + 1 - G_SLMODE)     /* the SLICER's globals (stored together: project.c, song_chain.c) */
#define G_CSTER G_DHPF                 /* (JIANT 0.6.9) CHORUS STEREO -64..63: 0 as before (G_DHPF's 0), - narrower .. mono */
/* (2.1) MASTER's page: the level and limiter stages as fx.c runs them (32768 = unity) */
void perf_reset(void);   /* (2.1) a new preset: the punch-in latches, the macros and the buffers */
int32_t fx_master_g(void);
int32_t fx_lim_env(void);
void fx_preset_flush(void);   /* (2.1) a new preset: the buses' short state and their small lines */
int fxb_sel(void);            /* (6.1) FX > BUSES: the link the console's knobs edit */
void fxb_step(int32_t d);     /* .. walked by KNOB 1 */

#define G_SYNC G_DREL                   /* (the old names, for the formats' importers and their tests) */
#define G_ENGGO G_CLIP
#define G_DRLVL G_PUNCH
#define G_DRREV G_DUCK

/* stored parameters of an older layout -> today's P_* order. A store keeps np = the P_COUNT it was
 * written with; common parameters are only ever added just before P_E0, so the first np - 8 are
 * P_LEVEL.. in order and the last 8 are P_E0..P_E7; the parameters a store does not have take def[]
 * (user presets, projects of formats 1 and 2) */
static void params_by_count(int16_t *out, const int16_t *in, uint32_t np, const int16_t *def)
{
    uint32_t i, nc = np - 8u;
    for (i = 0; i < P_E0; i++)
        out[i] = i < nc ? in[i] : def[i];
    for (i = 0; i < 8u; i++)
        out[P_E0 + i] = in[nc + i];
}

/* engine indices the stores name (engines.c ENGINES[]: append-only) */
#define ENGI_ANALOG 0u           /* (JIANT 0.5: named for its FILTER page) */
#define ENGI_PHYS 9u
#define ENGI_DRUM 10u
#define ENGI_LOFI 3u             /* LOFI (engines.c ENGINES[3]): BYTE / FLOAT's T.CLK lives here */
#define ENGI_GRAIN 8u
#define ENGI_SLICE 13u
#define ENGI_SAMPLE 4u
#define ENGI_TRIO 6u             /* (JIANT 0.4) folded into ANALOG (analog_from_trio) */
#define ENGI_WAVETABLE 14u       /* (QG-1 3.0) WAVETABLE (eng_wavetable.c): the morphing table */
#define ENGI_ADDITIVE 15u        /* (QG-1 1.2.6) ADDITIVE (eng_additive.c): eight partials, per-partial decay */
/* (JIANT) the retired engines: PHYS, and the sample engines SAMPLE GRAIN SLICE (their 123 KB of samples and GRAIN's
 * 27 KB of RAM went to DRUM-X and the effects). Their numbers stay reserved (engines.c ENG_GONE), never offered; a sound
 * of theirs that arrives -- a project, a user preset, the editor -- plays as ANALOG's first preset (SAMPLE's old PERC
 * set as DRUM first: drum_from_perc) */
static inline int eng_gone(uint32_t e)
{
    return e == ENGI_PHYS || e == ENGI_SAMPLE || e == ENGI_GRAIN || e == ENGI_SLICE || e == ENGI_TRIO;
}
/* (JIANT 0.4) a sound stored before 0.4 -> today's E values, in place: LOFI (3) {.., SWP, VIB, ARP, TONE} -> {.., CUT
 * (its TONE), VIB, BEND 0, MASK 0}; ANALOG (0) KTR -> INT 0 (the key tracking fixed at its old default). Projects
 * (project.c: the kit's marker below 3, or an older format) and user presets (upreset.c: no UP_V04_MARK) */
static void sound_v04(uint32_t engine, int16_t *e)
{
    if (engine == 3u) {
        e[4] = e[7];
        e[6] = e[7] = 0;
    } else if (engine == 0u) {
        e[7] = 0;
    }
}
/* (JIANT 0.4) TRIO (engine 6) folded into ANALOG: its sound's E values -> ANALOG's, in place, the nearest WAVE (its
 * three saws SAW3, its sync sets SYNC, its ring sets RING, pulses PWM, triangles TRI, noise as NOIS), INT2 as the
 * SYNC / RING ratio (DTN: 16 x (2^(st/12) - 1)), DTN, CUT and RES kept; 1 = it was TRIO (its engine is ANALOG now):
 * projects, user presets, the editor's PRESET and SET (project.c, upreset.c, ui.c). {WAVE INT2 INT3 DTN MODE CUT RES
 * PW} -> {WAVE DTN MIX NOIS CUT RES DRV KTR} */
static int analog_from_trio(uint32_t engine, int16_t *e)
{
    static const uint8_t W[16] = {7, 4, 4, 7, 2, 0, 1, 4, 0, 5, 5, 5, 6, 6, 6, 6};
    static const uint8_t R[25] = {0, 1, 2, 3, 4, 5, 6, 8, 9, 11, 12, 14, 16, 18, 20, 22, 25, 27, 30, 34, 37, 41, 45, 49,
                                  54};   /* (16 x (2^(st/12) - 1), st 0..24) */
    uint32_t w = (uint32_t)e[0] & 15u;
    int32_t st = e[1] < 0 ? -e[1] : e[1];
    if (engine != ENGI_TRIO)
        return 0;
    e[0] = W[w];
    e[1] = W[w] >= 5u ? (int16_t)R[st > 24 ? 24 : st] : (int16_t)(e[3] > 0 ? e[3] : 6);
    e[2] = (int16_t)(w == 8u ? 0 : 64);
    e[3] = (int16_t)(w == 7u ? 60 : w == 8u ? 100 : 0);
    e[4] = e[5];                                        /* CUT */
    e[5] = e[6];                                        /* RES */
    e[6] = 0;
    e[7] = 64;
    return 1;
}
/* PHYS MODEL DRUM (MODEL 4, before 1.0) -> the DRUM engine, its E values in place: {MODEL, TUNE, TONE, DECY,
 * SNAP, ACC, KICK, PERC} -> {MRPH 64, TUNE, TONE, DECY, NOIS 64, FM 0, -, DRV 0}. 1 = it was one (its engine is
 * ENGI_DRUM now); projects (project.c) and user presets (upreset.c) */
static int drum_from_phys(uint32_t engine, int16_t *e)
{
    if (engine != ENGI_PHYS || e[0] != 4)
        return 0;
    e[0] = e[4] = 64;
    e[5] = e[6] = e[7] = 0;                             /* (ACC is gone: E5 is FM now, off) */
    return 1;
}

/* SAMPLE SET 4 was PERC, the GM-mapped drum kit (tools/gen_samples.py); retired after 1.0.2: its index stays
 * (SET / GRAIN SRC 4 is an alias of PIANO; 5..7, once USR1..3, clamp to it). A sound that selected it is the DRUM engine with
 * its default kit (eng_drum.c DRUM_PRESETS[0]: the same GM key map, so its patterns still play as drums): its E
 * values become the kit's, the rest of the sound (mix, sends, matrix, ..) stays. 1 = it was one (its engine is
 * ENGI_DRUM now); projects (project.c proj_perc), user presets (upreset.c up_migrate), factory preset 4 and
 * favourites (ui.c, settings_persist.c). Idempotent */
#define SMP_SET_PERC 4u
#define DRUM_KIT_E {64, 64, 70, 64, 64, 0, 0, 0}   /* {MRPH, TUNE, TONE, DECY, NOIS, FM, WARP, DRV} (eng_drum.c) */
static int drum_from_perc(uint32_t engine, int16_t *e)
{
    static const int16_t KIT[8] = DRUM_KIT_E;
    uint32_t i;
    if (engine != ENGI_SAMPLE || e[0] != (int16_t)SMP_SET_PERC)
        return 0;
    for (i = 0; i < 8u; i++)
        e[i] = KIT[i];
    return 1;
}

/* ------------------------------------------------- voices, engines --- */
enum { V_POLY, V_MONO, V_LEGATO, V_UNISON };   /* P_VOICE */
typedef struct {
    uint8_t note, vel, gate, active;
    uint8_t stage;               /* env: 0 off, 1 attack, 2 decay/sustain, 3 release, 4 given up (fading) */
    uint8_t kfade;               /* (0.6.74) stage 4: the fade's blocks so far (voice.c env_tick) */
    uint16_t fin_d;              /* (0.6.81) a chord glide's new note fading in (seq.c chord_glide); 0.6.82: as its glide
                                  * goes, the distance it set out from (1/16 st; 0 none) */
    int32_t env;                 /* Q24 */
    int32_t env_out;             /* last control-rate amplitude, Q15 */
    int32_t pitch16, pitch_cur;  /* 1/16 semitone, with glide */
    int32_t gstep;               /* glide TIME mode: 1/16 st per control tick, Q8 (0.6.82: slow glides smooth), 0 = RATE */
    int32_t fine;                /* unison detune: phase increment * (1 + fine / 4096) */
    uint32_t ph[3];
    int32_t s[8];                /* engine state (filters, envs) */
    int32_t tilt_lp;             /* (v1.12.4) TILT's one pole: the low band every voice leans against (voice.c) */
    uint32_t age;
    uint8_t mstart;              /* (3.5) M.STRT: blocks of silence before this note's first sample (0: none) */
    uint8_t mvel;                /* mod.c: the note-on velocity (before UNISON scaling) and RAND of the note */
    uint8_t pat;                 /* (QG-1 1.6) this key's polyphonic aftertouch (MIDI 0xA0), 0 = none */
    uint8_t gacc;                /* (0.6.82) the glide's fraction of a 1/16 st carried (gstep Q8) */
    int16_t mrnd;
} voice_t;

typedef struct {                 /* per-voice control-rate modulation, computed in voice.c */
    uint32_t inc;                /* phase increment of the base pitch */
    int32_t pitch16;
    int32_t amp0, amp1;          /* Q15 ramp over the block */
    int32_t cutoff;              /* 0..127 << 8 */
    int32_t shape;               /* 0..127 << 8 */
    int32_t tilt;                /* (v1.12.4) TILT's amount, -64..63: the knob plus MD_HARM's own */
    int32_t envq15;              /* env value (for engines that use it as a mod source) */
    int32_t fine;                /* the residual below 1/16 semitone in inc: unison detune, TUNE, bend (1/4096) */
} vmod_t;

typedef struct {
    const char *name;
    int8_t e[8];                 /* P_E0..P_E7 (signed: an interval below the note; every value fits) */
    uint8_t env[4];              /* ATK DEC SUS REL */
    int8_t fenv;                 /* ENV -> FILTER amount (-64..63) */
    uint8_t mono;                /* 1 = MONO (bass / lead), 0 = POLY */
    /* the rest of the patch; each value is stored + 1, 0 = the default */
    uint8_t fx[4];               /* DIST, CHORUS, DELAY, REVERB sends */
    uint8_t pat;                 /* suggested pattern (PATTERNS[pat - 1], 0 = none): only a hint. A sound load
                                  * never touches the steps; SEQ > PATTERNS loads a pattern (ui.c pat_load). The
                                  * arp is the track's too: a preset does not set it */
    struct { uint8_t id; int8_t v; } x[6];   /* (1.2-GW) up to six more of the sound's values a preset sets (P_* + 1,
                                  * 0 = none; its value as is): the LFO, the matrix, VOICE, GLIDE .. so a pad moves by
                                  * itself. None in the presets before 1.2: they load as they did */
    uint8_t legacy;              /* (QG-1 1.6 audit) kept at its old index for projects and user presets, not shown
                                  * by the browser and not part of the 200-sound library: DRUM 10, 11 */
} preset_t;
#define FX(d, c, dl, r) .fx = {(d) + 1, (c) + 1, (dl) + 1, (r) + 1}
#define XP(id, v) {(id) + 1, (v)}
#define PAT(n) .pat = (n)
/* (QG-1 1.6) the matrix source / destination numbers a preset's x[] may name: mod.c MS_* / MD_* (asserted there,
 * so a reordering of either list breaks the build rather than the sound) */
#define QG_SRC_VEL 3             /* MS_VEL */
#define QG_SRC_AT 7              /* MS_AT: channel aftertouch */
#define QG_SRC_PAT 15            /* MS_PAT: this key's polyphonic aftertouch */
#define QG_DST_CUT 2             /* MD_CUT */
#define QG_DST_SHP 3             /* MD_SHP */
#define QG_DST_REV 9             /* MD_REV */
#define QG_DST_VIB 11            /* MD_VIB */
#define QG_DST_E1 12             /* MD_E1: the engine's first EDIT parameter (a formant's vowel, FM6's algorithm) */
#define QG_SRC_N 17              /* MS_N: the matrix's sources (mod.c checks the count); (FASE 5) +1: BAR */
#define QG_DST_N 32              /* MD_N: its destinations ((FASE 3) +1: RES; FASE 5 +3: ATK DEC REL;
                                  * v1.12.4 +1: HARM, TILT; v1.12.5 +1: LSHP, the LFO's curve) */

struct track;
typedef struct {                 /* an engine (engines.c ENGINES[]; the eng_*.c files) */
    const char *name;            /* "ANALOG" (PRESETS, the editor) */
    const char *page_title[3];   /* EDIT 1, EDIT 2 and CHARACTER (FASE 2) */
    param_desc_t edit[8];        /* P_E0..P_E7 */
    const preset_t *presets;
    uint8_t npresets;
    uint8_t legacy_n;            /* (FASE 2) how many entries are legacy aliases: engine_library leaves them out of
                                  * the list, and eng_preset_nth / eng_preset_rank step over them wherever they sit
                                  * (DRUM keeps its two pre-1.6 kits at ids 10 and 11, inside the table). Their own
                                  * ids never move: a project that stored one loads it */
    uint8_t knob[4];             /* HOME: the four parameters on KNOB 1..4 */
    uint8_t poly;                /* voice cap for POLY and UNISON, 0 = NVOICE */
    uint8_t sampled;             /* 1 = plays recorded material (a position, not a phase): voice.c keeps
                                  * no phases over a retrigger, spreads none for UNISON, renders at SUS 0 */
    uint8_t keep;                /* bit k: s[k] is kept when a sounding voice is retriggered (filters) */
    uint8_t oneshot;             /* 1 = hits (DRUM): always POLY, no glide; amp ends its voices (eng_drum.c) */
    /* (FASE 2) the CHARACTER page's slots: ch[0] and ch[1] are P_X0 / P_X1 (amounts, 0 at 127), ch[2] is P_XCH
     * (an amount, 0 at 0) and only used by the engines without a native MORPH. ch_n = 0: no CHARACTER page for
     * this engine (DRUM-X already edits lanes, transient, pitch envelope, tune, decay and kits on its own pages). */
    const param_desc_t *ch;
    uint8_t ch_n;
    void (*note_on)(struct track *t, voice_t *v);
    void (*render)(struct track *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m);
    /* optional (0 = none): the voice amplitude instead of the ADSR curve, once per control tick;
     * gets the ADSR value (Q15, env_tick already ran: it still gates the voice), returns Q15 */
    int32_t (*amp)(struct track *t, voice_t *v, int32_t adsr);
    /* optional: a mode-dependent descriptor of EDIT k (the same range and default as edit[k],
     * another label / value names), 0 = edit[k] */
    const param_desc_t *(*desc)(const struct track *t, uint32_t k);
    /* optional: once per block and part, before its voices (also with no voice sounding) */
    void (*block)(struct track *t);
    /* optional: the note of key k (0 = the lowest) when the engine maps the keys itself, else -1
     * (then the scale keyboard of seq.c kb_map) */
    int32_t (*keys)(const struct track *t, uint32_t k);
    /* 1 = the engine's own envelopes are the voice's amplitude (FM6): voice.c renders it at 1.0 (no ADSR, no
     * velocity; LFO -> AMP, the matrix's AMP and the fades still apply; ENV is 0) and the voice ends when
     * done() says so (once per control tick, before the render), not at the end of the ADSR's release */
    uint8_t ownenv;
    int (*done)(struct track *t, voice_t *v);
} engine_t;
/* (QG-1 1.6 audit) the sounds browsing offers: the table's, less the legacy ones kept at its end so a project made
 * before they were retired still loads the exact kit it saved. No index moves (npresets stays the table's size, and
 * every stored index is taken modulo it), so DRUM 10 HEARTH KIT and 11 CYBER DRUM still resolve. */
/* (FASE 2) the sounds browsing shows, in their own order. The legacy aliases are skipped ANYWHERE, not only
 * at the end: DRUM keeps its two pre-1.6 kits at ids 10 and 11, inside the table, so trimming the tail listed
 * 18 sounds where the editor, the documents and the 273-sound library say 16. Their ids do not move: a project
 * that stored HEARTH KIT still loads it */
static inline uint32_t engine_library(const engine_t *e) { return e->npresets - e->legacy_n; }
/* (FASE 2) the list's n-th sound as its index in the table, and back. The legacy aliases are not in the list and
 * do not count, wherever they sit; an engine without them is the identity */
static inline uint32_t eng_preset_nth(const engine_t *e, uint32_t n)
{
    uint32_t i;
    if (!e->legacy_n)
        return n;
    for (i = 0; i < e->npresets; i++)
        if (!e->presets[i].legacy && !n--)
            return i;
    return 0;
}
static inline uint32_t eng_preset_rank(const engine_t *e, uint32_t k)
{
    uint32_t i, n = 0;
    if (!e->legacy_n)
        return k;
    for (i = 0; i < k && i < e->npresets; i++)
        n += !e->presets[i].legacy;
    return n;
}

/* ------------------------------------------------- tracks, the song --- */
enum { ST_NOTE, ST_TIE, ST_REST };
#define SF_ACCENT 1u
#define SF_SLIDE 2u
#define SF_RATCH_SH 3u                   /* RATCH: the hits of a NOTE step - 1 (0..3: x1..x4, seq.c seq_ratchet); */
#define SF_RATCH (3u << SF_RATCH_SH)     /* bits 3..4, so a user preset's pattern (flag 4 = tie) carries it too */
#define NLANE 8                  /* drum lanes of a step (the DRUM engine's: eng_drum.c DRUM_LANE_NOTE) */
typedef struct {                 /* acid-style step: up to 4 notes (POLY), time, accent, slide; drum hits */
    uint8_t note[4];
    uint8_t n;                   /* notes in use, 0 = empty */
    uint8_t time;                /* ST_NOTE / ST_TIE / ST_REST */
    uint8_t flags;               /* SF_ACCENT | SF_SLIDE | SF_RATCH */
    uint8_t vel;
    uint8_t hit;                 /* bit l: lane l hits (its GM note, on any engine): the DRUM grid */
    uint8_t acc;                 /* bit l: that hit is accented (velocity 127) */
    uint8_t probability;         /* 0 = legacy 100%; 1..100 = percent, 101 = silent */
    uint8_t comp, carg;          /* (JIANT 0.6.39) the step's component (CP_*, 0 none) and its arguments (seq.c) */
    uint8_t comp2, carg2;        /* (0.6.82) a second component (SEQ > COMP 2), the same way */
    uint8_t cwhen;               /* (0.6.82) WHEN each plays: bits 0-1 comp's, 2-3 comp2's (CW_*) */
    uint8_t ctime;               /* (0.6.82) bits 0-2 DIV: RATCH's and ECHO's parts a step/2 .. /8 apart (0: the step
                                  * shared out, as before); bits 3-6 LEN: a part's gate n/16 (0: the track's GATE) */
} step_t;
/* (0.6.82) WHEN a component plays: ALWAYS, on odd loops (1:2), on even loops (2:2), SKIP (kept, not played) */
enum { CW_ALWAYS, CW_ODD, CW_EVEN, CW_SKIP };
#define CW_OF(s, k) (((uint32_t)(s)->cwhen >> ((k) * 2u)) & 3u)
enum { EV_ALWAYS, EV_1_2, EV_2_2, EV_SKIP, EV_1_3, EV_2_3, EV_3_3, EV_1_4, EV_2_4, EV_3_4, EV_4_4, EV_1_8, EV_FIRST,
       EV_NOT1, EV_N };
#define ST_EVERY(s) ((uint32_t)(s)->cwhen & 15u)
#define ST_EVERY_SET(s, e) ((s)->cwhen = (uint8_t)(((s)->cwhen & 0xF0u) | ((uint32_t)(e) & 15u)))
/* (0.6.88) TIMING: the step's own place off the grid, -8 .. +7 sixteenths of a step (0 on it), in cwhen's bits 4-7
 * (stored with it, project.c); recorded off the grid (REC Q) or set on SEQ > TIMING. seq.c: late by a queue, early by
 * ending the step before it that much sooner */
#define ST_MICRO(s) ((int32_t)(int8_t)(s)->cwhen >> 4)
#define ST_MICRO_SET(s, m) ((s)->cwhen = (uint8_t)(((s)->cwhen & 15u) | (((uint32_t)(m) & 15u) << 4)))
#define CT_DIV(s) ((uint32_t)(s)->ctime & 7u)
#define CT_LEN(s) (((uint32_t)(s)->ctime >> 3) & 15u)
#define CT_NDIV 6u
static const uint8_t CT_DIVS[CT_NDIV] = {0, 2, 3, 4, 6, 8};
/* (JIANT 0.6.39) step components, OP-Z style (SEQ > COMP): one a step, on a NOTE step of a melodic track.
 * ARP NOTES / SEQ / SCALE: the step plays an arpeggio, RATE notes in its length, over the TIEs after it; its notes
 * (NOTES: the step's own, SEQ: every note of the track's pattern, both over RANGE octaves; SCALE: the scale up from
 * the step's lowest note, RANGE: 3 5 8 15 degrees) in the ORDER. TRIG: the step plays on some loops of the pattern
 * only (1:2 the first of every two, .., FIRST, NOT FIRST). carg: ARP ORDER bits 0-1, RATE 2-4, RANGE 5-6; TRIG the
 * condition. */
/* (0.6.42) RAND: the notes up / down the scale at random (carg 1..7 degrees); OCT: an octave (carg: +1, -1, +1 every
 * other loop, -1 every other loop, + / - by turns, at random); TONAL: the rest of the loop moved (carg 0..14: -7..+7
 * degrees); BEND: the notes glide over the step (carg 0..24: -12..+12 semitones); ECHO: repeats fading (carg 0..2:
 * x2..x4; 0.6.82: .. x8); PULSE: its notes again on the empty steps after it (carg 0..3: every 1..4); JUMP: then step carg + 1;
 * REV: back from here to step 1 (ping-pong); FILL: only while FX is held; KILL: what the track sounds cut first */
enum { CP_NONE, CP_ARPN, CP_ARPQ, CP_ARPS, CP_TRIG, CP_RAND, CP_OCT, CP_TONAL, CP_BEND, CP_ECHO, CP_PULSE, CP_JUMP,
       CP_REV, CP_FILL, CP_KILL, CP_WALK, CP_CLIMB, CP_N };
#define CP_WRATE(a) ((uint32_t)(a) & 15u)
#define CP_WMODE(a) (((uint32_t)(a) >> 4) & 3u)
#define CP_WRNG(a) (((uint32_t)(a) >> 6) & 3u)
#define CP_WARG(r, m, g) ((uint8_t)(((r) & 15u) | ((m) & 3u) << 4 | ((g) & 3u) << 6))
#define CP_NWRATE 12u
static const uint8_t CP_WRATES[CP_NWRATE] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 16};
static const uint8_t CP_WDEGS[4] = {3, 5, 7, 12};
/* the range of carg each component's KNOB 3 turns (ARP: KNOB 3 / 4 their own) */
static const uint8_t CP_AMAX[CP_N] = {0, 0, 0, 0, 11, 7, 5, 14, 24, 6, 3, 63, 0, 0, 0, 0, 0};
static const uint8_t CP_ADEF[CP_N] = {0, 0, 0, 0, 0, 2, 0, 9, 7, 1, 0, 0, 0, 0, 0, 0x40, 0x00};
static const uint8_t CP_AMIN[CP_N] = {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#define CP_ORD(a) ((uint32_t)(a) & 3u)            /* UP DOWN UP-DN RND */
/* (0.6.62) JUMP: its step (bits 0-5) and TIMES (bits 6-7); REV: TIMES (bits 0-1). TIMES: ALWAYS, x1 (once a pass of
 * the pattern, then it plays on), x2, 1:2 (once, every other pass). 0, ALWAYS: as a JUMP / REV of before (seq.c fl_ok) */
#define CP_JTO(a) ((uint32_t)(a) & 63u)
#define CP_TIMES(c, a) ((c) == CP_JUMP ? ((uint32_t)(a) >> 6) & 3u : (uint32_t)(a) & 3u)
#define CP_RATE(a) (((uint32_t)(a) >> 2) & 7u)    /* 0..4: x2 x3 x4 x6 x8 */
#define CP_RNG(a) (((uint32_t)(a) >> 5) & 3u)     /* 0..3: 1..4 octaves (SCALE: 3 5 8 15 degrees) */
#define CP_ARG(o, r, g) ((uint8_t)(((o) & 3u) | ((r) & 7u) << 2 | ((g) & 3u) << 5))
#define CP_NRATE 5u
#define CP_NTRIG 12u
static const uint8_t CP_RATES[CP_NRATE] = {2, 3, 4, 6, 8};
static const uint8_t CP_DEGS[4] = {3, 5, 8, 15};
static const uint8_t CP_TRIGS[CP_NTRIG][2] = {{1, 2}, {2, 2}, {1, 3}, {2, 3}, {3, 3}, {1, 4}, {2, 4}, {3, 4}, {4, 4},
                                              {1, 8}, {0, 1}, {0, 2}};   /* (a of b; {0, 1} FIRST, {0, 2} NOT FIRST) */
static int cp_isarp(uint32_t c) { return c >= CP_ARPN && c <= CP_ARPS; }
typedef struct {                 /* a step as formats 1..4 (projects to FUN4) stored it: no hits */
    uint8_t note[4];
    uint8_t n, time, flags, vel;
} step8_t;

/* Probability keeps zero-initialized and legacy patterns at 100%. */
static uint32_t step_chance(const step_t *s) { return !s->probability ? 100u : s->probability <= 100u ? s->probability : 0u; }
static void step_set_chance(step_t *s, uint32_t chance) { s->probability = (uint8_t)(chance >= 100u ? 0u : chance ? chance : 101u); }
/* RATCH: a NOTE step plays its notes and hits this many times (1..4), in equal parts of the step; every older
 * pattern holds 0 there, x1 */
static uint32_t step_ratchet(const step_t *s) { return ((s->flags & SF_RATCH) >> SF_RATCH_SH) + 1u; }
static void step_set_ratchet(step_t *s, uint32_t hits)
{
    s->flags = (uint8_t)((s->flags & ~SF_RATCH) | ((hits < 1u ? 0u : hits > 4u ? 3u : hits - 1u) << SF_RATCH_SH));
}
#define MOTION_MAX 64u
/* Four tracks x64 steps fit one byte (JIANT 0.6, six tracks: the track's bit 2 is value's bit 12 flipped against its
 * sign, MOTION_TRK; values stay within -64..127, so an old record reads as track 0..3). Values retain their signed parameter range.
 * param: the P_* id (< 128: P_COUNT is at most 127, project.c), bit 7 (MOTION_LOCK, 1.1) a parameter lock: the value
 * sounds on that step only and goes back after it (motion.c motion_step); without it an automation event, the
 * value holds until another one changes it. One record per (track, step, id), of either kind */
#define MOTION_LOCK 0x80u
#define MOTION_ID(e) ((uint32_t)(e)->param & 0x7Fu)
#define MOTION_HI(e) ((uint32_t)(((e)->value >> 12) ^ ((e)->value >> 15)) & 1u)
#define MOTION_TRK(e) ((uint32_t)(e)->place >> 6 | MOTION_HI(e) << 2)
#define MOTION_STEP(e) ((uint32_t)(e)->place & 63u)
#define MOTION_PLACE(e) (MOTION_TRK(e) << 6 | MOTION_STEP(e))   /* track << 6 | step */
#define MOTION_VAL(e) ((int16_t)((e)->value ^ (int32_t)(MOTION_HI(e) << 12)))
typedef struct { uint8_t place, param; int16_t value; } motion_event_t;
typedef struct { uint8_t count, on, rsv[2]; motion_event_t event[MOTION_MAX]; } motion_store_t;
static void motion_at(motion_event_t *e, uint32_t place, int16_t v)   /* place: track << 6 | step; v: the value */
{
    e->place = (uint8_t)(place & 255u);
    e->value = (int16_t)(v ^ (int32_t)(((place >> 8) & 1u) << 12));
}
_Static_assert(sizeof(motion_store_t) == 260u, "motion disk layout");
#define CHAIN_ROWS 16u
typedef struct { uint8_t slot, bars; } chain_row_t;   /* a song row: section A..D (a project slot), 1..CHAIN_BARS bars */
#define CHAIN_BARS 64u
typedef struct {
    uint8_t count, rsv[3];
    chain_row_t row[CHAIN_ROWS];
} chain_config_t;

typedef struct track {
    int16_t p[P_COUNT];
    int16_t mx[4][3];            /* (FASE 8) the matrix's slots 5..8 (mod.c): SRC, DST, AMT each. Not p[] ids: the
                                  * 7-bit ids the motion records and the stores carry are full (P_COUNT 125 of 127).
                                  * They travel with the project (project.c 'M' 'X' block) and with a user preset
                                  * (upreset.c's spare bytes), and they are not automatable. */
    uint8_t engine, preset;      /* engine: what the audio ISR renders */
    uint8_t eng_req;             /* engine the UI asked for (the ISR switches at a block start) */
    uint8_t user;                /* user preset slot + 1 the sound came from (UI), 0 = none */
    uint8_t vidx[NVOICE];        /* (3.5) the pool slots this part owns: V(t, i) is the voice at i. Ballast
                                  * beyond vn points at VDEAD, so the scans that run to NVOICE read inert voices */
    uint8_t vn;                  /* slots granted to this part (its window's length; <= NVOICE) */
    /* LFO */
    uint32_t lfo_ph;
    int32_t lfo_val;             /* Q15 */
    int32_t lfo_fade;            /* Q15 ramp after note-on */
    uint32_t lfo_rnd;
    /* keyboard / arp input: held notes in press order */
    uint8_t held[16];
    uint8_t nheld;
    uint8_t arp_phys;            /* keys physically held for the arp */
    uint8_t latched;             /* HOLD: keep notes after release */
    /* arp runtime */
    uint32_t arp_pos;            /* q8 samples into the current arp step */
    uint32_t arp_idx;
    uint8_t arp_note;            /* sounding arp note, 0 = none */
    uint8_t arp_walk;            /* WALK: the place in the note list it stands on */
    uint8_t arp_ch[3];           /* CHORD: the other notes sounding with arp_note, 0 = none */
    uint32_t arp_off;            /* q8 sample time of its note-off */
    /* sequencer */
    step_t step[NSTEP];
    uint32_t seq_pos;            /* q8 samples into the current step */
    uint16_t seq_idx;
    uint8_t seq_notes[4 + NLANE];   /* sounding seq notes (the step's notes, then its hits) */
    uint8_t seq_n;
    uint8_t seq_hold;            /* last step slides: keep the notes until the next step */
    uint8_t slide_glide;         /* next legato note glides (slide) */
    uint8_t rat_left;            /* RATCH: repeats of the playing step still to come (seq.c seq_ratchet) */
    uint8_t arp_from;            /* (0.6.39) an ARP component playing: its step + 1 (0: none), over the TIEs after it */
    uint8_t arp_k;               /* .. the arpeggio's next note (its position in the ORDER) */
    uint16_t loops;              /* (0.6.39) the pattern's loops since PLAY (TRIG components) */
    int8_t tonal;                /* (0.6.42) TONAL: the rest of the loop this many degrees up / down */
    uint8_t pulse_from, pulse_k; /* .. PULSE: its step + 1 (0: none), the empty steps since */
    uint8_t jump_to, rev;        /* .. JUMP: the next step + 1 (0: the next one); REV: backwards to step 1 */
    uint16_t mo_cur, mo_prev;    /* (0.6.50) MORPH as the engines play it: Q8, slewed a block at a time (voice.c
                                  * track_render) and ramped across the block from mo_prev (no step: no click) */
    uint8_t cpos, cv_on;         /* (0.6.47) C.LEN: the component lane's next step; the step playing is cvs */
    step_t cvs, cva, cvp;        /* .. the step playing with the lane's component; the ARP's and PULSE's (CV_IDX) */
    uint32_t seq_off;
    uint8_t seq_active;          /* any step programmed */
    uint8_t rskip_idx;           /* live recording put notes into the step about to play: */
    uint8_t rskip_n, rskip[NLANE];   /* do not trigger them again there (they sound already) */
    /* live recording of held notes (seq.c rec_hold): the steps they are held into become TIEs */
    uint8_t rh_n, rh_note[4];    /* recorded notes still held, 0 = none */
    uint8_t rh_start;            /* the step they were recorded into */
    uint8_t rh_ties;             /* TIE steps written after it */
    uint8_t rh_last;             /* the last of them; rh_bak: what it held (an early release puts it back) */
    step_t rh_bak;
    /* mono */
    uint8_t mono_stack[MS_IN_T];     /* (v1.5.23) the first MS_IN_T of MONO_STACK_N: the rest is beside the tracks */
    uint8_t nmono;
    uint8_t mono_note;           /* note the MONO / LEGATO / UNISON voice(s) play, 0 = none */
    uint8_t rr;                  /* POLY ROTATE: next voice to try */
    /* mix runtime */
    int32_t peak;                /* the block's post-FX peak (fx.c mix_part) */
    int32_t vu;                  /* (v1.9) a peak envelope: fast attack, ~23 ms release, so the meters see
                                  * the audio between two UI frames instead of one 32-sample block */
    int32_t dist_hp, dist_lp1, dist_lp2;   /* DIST insert state (fx.c) */
    int32_t dist_dc, dist_hold;  /* (JIANT) RECT's DC; CRUSH's held sample */
    uint8_t dist_hc;             /* .. CRUSH's hold count */
    int32_t ms_v;                /* (JIANT) the modulation sequence's level now (mod.c MS_STEP, Q15, slewed) */
    uint8_t tail;                /* blocks to mix after the last voice (the DIST tail) */
    int16_t armp, aholdp;        /* P_AMODE / P_AHOLD as last seen by the ISR */
    /* engine switch (voice.c engine_block): the old engine's voices fade out, then it switches */
    uint8_t xf_on, xf;           /* fading; blocks of the fade still to render */
    uint8_t xf_len, xf_dip;      /* (0.6.41) the fade's length; a dip (an engine's list value changed: the voices stay) */
    uint8_t xin, xin_len;        /* (0.6.41) fading in after it: blocks still to come, of xin_len */
    int16_t pe_old[8];           /* P_E0..P_E7 of the sounding engine: the fade renders with these */
    uint8_t xp_n, xp_note[XP_IN_T], xp_vel[XP_IN_T];   /* note-ons during the fade, played on the new engine (the
                                                        * first XP_IN_T of XP_N: the rest is beside the tracks) */
    /* modulation matrix (mod.c): MIDI performance controllers of the track's channel, 0..127 */
    uint8_t mw, at;              /* CC1 mod wheel, channel aftertouch */
    uint8_t ex_off;              /* 127 - CC11 expression (0: full, the MIDI default) */
    uint8_t m_vel, m_key, m_vi;  /* the latest note-on: velocity, note, voice index (per-block destinations) */
    int16_t m_rnd;               /* .. its RAND */
    int32_t m_env;               /* the amp envelope of voice m_vi, last block (Q15) */
    /* the punch-in MIDI effects (pfx.c), the ISR's: what acts on this track this block, never saved */
    int8_t trn;                  /* ARP TRNS (seq.c): the semitones the keys set (from C4), on the steps' notes */
    uint8_t pfx;                 /* PFX_* */
    int16_t pfx_pit;             /* OCT- / OCT+: 1/16 semitones on every voice */
    int16_t pfx_rpit;            /* RANDOM: the next note's offset (1/16 semitones), drawn by trk_note_on */
    int8_t dpit;                 /* (0.6.82) the sequencer's next drum hits: their tune (semitones; a step's OCT, RAND,
                                  * TONAL, ARP SCALE on a kit) */
    int16_t dbend;               /* .. BEND: where the hit glides to over dbt blocks (1/16 semitones; eng_drum.c) */
    uint16_t dbt;
    uint8_t ss_n, ss_i;          /* (0.6.84) STRUM on the sequencer's chords: the step's notes still to come in, in */
    uint8_t ss_nn[4 + NLANE], ss_vv[4 + NLANE];  /* order low to high (seq.c seq_step, seq_tick), ss_due samples to the next */
    uint32_t ss_due, ss_gap;     /* (.. and the gap between them; 0.6.88: 32 bits, a long TIMING) */
    uint16_t ext;                /* (0.6.88) TIMING: samples the playing step began before its place (it is early) */
    int8_t mic;                  /* .. the playing step's own TIMING (ST_MICRO), late: seq_step queues its notes */
    uint8_t pfx_half;            /* 1/2 TEMPO: the odd sample carried; pfx_rs: let go, back to the real place */
    uint8_t pfx_rs;
    uint16_t pfx_idx0;           /* .. where it was pressed (step, samples into it) and the samples since */
    uint32_t pfx_pos0, pfx_el;
    uint8_t pfx_ln[4], pfx_lv[4], pfx_lnn;   /* the last notes struck together (a step's), STUTTER / ARP repeat them */
    uint32_t pfx_lblk;           /* .. the block they were struck in */
    uint8_t pfx_sn[4], pfx_snn;  /* the notes a repeat holds now */
    uint8_t pfx_si;              /* ARP: the next of them */
    uint32_t pfx_sc;             /* samples since the last repeat */
} track_t;
/* (3.5) the one storage of voices, and a part's window into it. V(t, i) is an lvalue: every use of a voice is
 * the same expression it was when the array lived in track_t. */
extern voice_t vpool[VPOOLN];
#define V(t, i) vpool[(t)->vidx[(i)]]
#define VSLOT(v) ((uint32_t)((v) - vpool))     /* a voice's pool slot: the engines' per-voice state is keyed by it */
/* (3.5) every voice of a part back to silence (what a memset of the old per-part array did), leaving the
 * pool's inert slot alone: it is shared, and clearing it would make it stealable */
static inline void voices_clear(track_t *t)
{
    uint32_t i;
    for (i = 0; i < NVOICE; i++)
        if (t->vidx[i] != VDEAD)
            memset(&V(t, i), 0, sizeof(voice_t));
}
/* the window index of a sounding voice (0..NVOICE-1), NVOICE when it is not this part's: what per-part,
 * per-voice arrays of the engines are keyed by. A note-on path's helper, never per sample */
static inline uint32_t vindex(const track_t *t, const voice_t *v)
{
    uint32_t i, s = VSLOT(v);
    for (i = 0; i < NVOICE; i++)
        if (t->vidx[i] == s)
            return i;
    return NVOICE;
}
enum { PFX_RND = 1, PFX_HALF = 2, PFX_REP = 4, PFX_DEC = 8, PFX_ATK = 16 };   /* (track_t.pfx) */

typedef struct {
    int16_t g[G_COUNT];
    uint8_t playing, seq_mode;
    uint8_t grid;                /* 1: the keys are the DRUM grid (ui.c grid_on): only the lane keys play (seq.c);
                                  * 2: NAME (ui_name.c): no key plays */
    uint8_t rec;                 /* live recording armed: bit per track */
    uint8_t sel;                 /* selected track 0..NTRK-1: keys, pages, editor */
    int8_t octave;
    uint32_t tick;               /* sub-blocks since play */
    uint32_t cpu_q8;             /* audio ISR load, 1/256 */
    uint32_t master_q12;
    int32_t batt_raw;            /* smoothed ADC ch3 (battery divider), 0 = not read yet */
} song_t;

static track_t trk[NTRK];        /* the instrument: four parts */
static song_t song;
/* (v1.5.23, FASE 2) THE REST OF EACH CHORD ARRAY, BESIDE THE TRACKS. track_t keeps its size and its layout (see the
 * measurement at XP_N); the slots past the ones it carries live here, and the note-on path reaches them through the
 * two accessors. Six parts: 6 * ((12 - 4) * 2 + (12 - 8)) = 120 B of .bss, against 11 520 B free. Neither array is
 * saved in a project or a backup (project.c copies named fields), so no stored layout moves either. */
static uint8_t xp_more[NTRK][XP_N - XP_IN_T], xp_morev[NTRK][XP_N - XP_IN_T];
static uint8_t ms_more[NTRK][MONO_STACK_N - MS_IN_T];
static inline uint32_t xp_kt(const track_t *t) { return (uint32_t)(t - trk) % NTRK; }
static inline uint8_t *xp_note_p(const track_t *t, uint32_t i)
{
    return i < XP_IN_T ? (uint8_t *)&t->xp_note[i] : &xp_more[xp_kt(t)][i - XP_IN_T];
}
static inline uint8_t *xp_vel_p(const track_t *t, uint32_t i)
{
    return i < XP_IN_T ? (uint8_t *)&t->xp_vel[i] : &xp_morev[xp_kt(t)][i - XP_IN_T];
}
static inline uint8_t *ms_p(const track_t *t, uint32_t i)
{
    return i < MS_IN_T ? (uint8_t *)&t->mono_stack[i] : &ms_more[xp_kt(t)][i - MS_IN_T];
}
#define TSEL (&trk[song.sel])

/* (1.2.6) SOUND EDITED: a track's sound changed since the last load or save. A load or a save clears it
 * (snd_clean); it is worked out by comparing the sound against the snapshot they left (ui_notices, ui_input.c),
 * so every path that writes p[] / mx[] -- a knob, the quick layer, the editor, a project recall, the A/B swap --
 * is covered without a hook in each of them. Never stored: the sound itself is the truth. */
static uint8_t snd_dirty;                       /* bit per track */
static uint8_t snd_first = 1;                   /* the boot sound is the starting point, not an edit */
static uint32_t snd_ref[NTRK];                  /* the sound as the last load / save left it */
static inline uint32_t snd_trk(const track_t *t) { return (uint32_t)(t - trk) % NTRK; }
/* (FASE 2/9) A WORD AT A TIME. p[] and mx[] are 16-bit, so the byte walk this used to do stepped twice per
 * value it was actually hashing -- and it runs every frame on all six tracks (ui_notices). Two values go into
 * one FNV step now, built from 16-bit loads (p is 2-byte aligned, not 4: a 32-bit read would be an unaligned
 * access on pi32v2 and a fault). The hash is only ever compared with another of its own (snd_ref), so its
 * values are nobody else's business; what is hashed is the same sound, value for value. */
static uint32_t snd_hash(const track_t *t)
{
    uint32_t h = 2166136261u, i;
    for (i = 0; i + 1u < (uint32_t)P_COUNT; i += 2u)
        h = (h ^ ((uint32_t)(uint16_t)t->p[i] | ((uint32_t)(uint16_t)t->p[i + 1u] << 16))) * 16777619u;
    if (P_COUNT & 1)
        h = (h ^ (uint32_t)(uint16_t)t->p[P_COUNT - 1]) * 16777619u;
    for (i = 0; i < 4u * 3u; i += 2u)
        h = (h ^ ((uint32_t)(uint16_t)t->mx[i / 3u][i % 3u] |
                  ((uint32_t)(uint16_t)t->mx[(i + 1u) / 3u][(i + 1u) % 3u] << 16))) * 16777619u;
    return (h ^ (uint32_t)t->eng_req * 2654435761u ^ (uint32_t)t->preset * 40503u) * 16777619u;
}
static void pc_arm(track_t *t);                 /* (FASE 4/9) the sound a load or a save left, ui.c */
static void snd_clean(track_t *t)
{
    uint32_t k = snd_trk(t);
    snd_ref[k] = snd_hash(t);
    snd_dirty &= (uint8_t)~(1u << k);
    pc_arm(t);                                  /* (FASE 4/9) PRESET COMPARE: the reference to come back to */
}
static uint32_t snd_edited(const track_t *t) { return (snd_dirty >> snd_trk(t)) & 1u; }    /* the selected track */

/* (V10.38, adapted) an interval chosen by chance (GEN and the sound dice): unison, fourth, fifth,
 * octave or the octave-and-fifth, up or down, within the parameter's range; random macros never aim
 * at an interval. Defined in params.c, before every user of it. */
int32_t param_semi_pick(uint32_t r, int32_t lo, int32_t hi);
int32_t param_semi_snap(int32_t v);

/* SWING of a track's step clock: the track's own plus the global one, at most 100 (#31). The sequencer
 * (seq.c step_samples) and the SLICER (slicer.c sl_enter) both time steps with it. At 100 the even
 * steps are 1.4 x the straight length and the odd ones 0.6 x. */
#define SWING_MAX 100
static inline int32_t track_swing(const track_t *t)
{
    int32_t sw = t->p[P_SSWING] + song.g[G_SWING];
    return sw < 0 ? 0 : sw > SWING_MAX ? SWING_MAX : sw;
}
/* the length of step idx of a straight length `base`, swung: even steps longer, odd ones shorter */
static inline uint32_t swing_step_len(const track_t *t, uint32_t base, uint32_t idx)
{
    int32_t sw = track_swing(t) * (int32_t)base / 250;
    return base + (uint32_t)((idx & 1u) ? -sw : sw);
}

/* ----------------------------------------------------------- system --- */
/* (v1.5.6) gfx.c: forget the last canvas blit, so the next one is sent even if its pixels match. Call it from every
 * path that writes the panel outside gfx's cv_blit (lcd_fill, the panels' own clears). */
void gfx_forget(void);
#define RING_PUBLISH() __asm__ volatile("" ::: "memory")   /* slot store before the index update */
static volatile uint32_t fm1_ms;  /* milliseconds since boot (TIMER4-based, TIMER5 ISR in main.c) */
/* boot-loop guard (main.c): two boots in a row that die in the first 30 s -> UBOOT */
#define BOOTGUARD_MAGIC 0x42475244u
struct { uint32_t magic, failed, pending; } bootguard __attribute__((unused));
