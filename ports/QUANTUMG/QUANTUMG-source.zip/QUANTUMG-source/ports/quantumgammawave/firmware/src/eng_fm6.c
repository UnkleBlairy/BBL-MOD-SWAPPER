/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* FM6: classic 6-operator FM. The synthesis is msfa (Dexed's core), ported to integer C in fm6_core.c
 * (Apache-2.0); this file is the Felucca engine around it.
 *
 * The patch is the sound: every track has one (fm6_patch, the generic 155-byte single-voice layout: six
 * operators with their 4-rate / 4-level envelopes, keyboard level and rate scaling, velocity, ratio or
 * fixed frequency, detune; 32 algorithms, feedback, LFO, pitch envelope, transpose). It is edited in the
 * web editor (EDITOR_PROTOCOL.md FM6_*: a .syx voice sent to a track), loaded from the factory slots, and saved inside
 * projects (FUN8) and user presets (up_fm6.c). Whatever is loaded becomes the track's patch.
 * On the device the eight EDIT values are macros on top of it:
 *   ALG   PAT = the patch's algorithm, 1..32 another one
 *   FB    added to the patch's feedback (0..7)
 *   MLVL  the output level of every operator that is not a carrier (-36 .. +36 dB): the brightness
 *   MRAT  added to the coarse ratio of the modulators (ratio mode only)
 *   MEG   the modulators' envelope times: + slower (rates down to 40 steps), - faster
 *   VMOD  added to the modulators' velocity sensitivity (0..7)
 *   DTUN  spreads the carriers apart in pitch (up to about +-36 cents between the outer ones)
 *   SLOT  F1..F8 load a factory patch; OWN (8) is the track's own patch: what a project, a user preset or the
 *         editor put there. A load shows F n when the patch is that factory one unchanged, else OWN (fm6_adopt).
 *         B1..B32 (9..40, JIANT 0.6.11 from Felucca 1.4.1) load a voice of the 32-voice bank in flash (fm6_vbank.c)
 *         as F n do; a bank slot without a voice is skipped by the knob (params.c enum_step) and refused anywhere
 *         else (fm6_poll). Turning SLOT from OWN to F n / B n keeps the own patch aside; back to OWN brings it back.
 *         Before 1.0.3 the values 8..34 were F1..F8 then B1..B27, a flash bank (retired: its patches moved into
 *         the user presets, up_fm6.c). A stored value is never a bank slot: projects, user presets and motion
 *         load 9..40 as 8, OWN (params.c param_fit), and the patch comes with the project / the record. So a
 *         project or a preset made with a bank voice sounds the same after the bank is replaced
 * The operator envelopes are the voice's amplitude and end it (engine_t.ownenv / done): (0.6.81) the track's ADSR
 * moves the carriers' (ATK DEC REL slower, SUS below 127 their sustain level; 0 0 127 0 the patch as it is); ENV DEST
 * and the matrix's ENV do nothing here. The track's FLT moves MLVL (ENV / LFO -> FLT, the
 * matrix's CUT), SHP the feedback, PIT the pitch (bend, glide, tune: the voice's pitch and fine factor).
 * Six voices per part at most (engine_t.poly).
 *
 * State: per voice an fm6_note_t (fm6_note, 244 bytes, a side array as PHYS's slots: voice_t.s[] is too
 * small), per part the patch, the patch through the macros (fm6_eff, rebuilt in the audio ISR when either
 * changes) and the LFO (once a block). */
#include "fm6_core.c"
#include "felucca_fm6.h"         /* tools/gen_fm6_patches.py: FM6_INIT, FM6_FACTORY[] */

#define ENGI_FM6 12u             /* engines.c ENGINES[] (append-only) */
#define FM6_POLY 4               /* engine_t.poly (0.6.16: 4, was 6: six operators a voice, the heaviest engine) */
#define FM6_OWN FM6_NFACTORY     /* SLOT: the track's own patch (F1..F8 before it) */
#define FM6_NBANK 32u            /* SLOT: B1..B32 after OWN, the voice bank (fm6_vbank.c) */
#define FM6_PACKED 128u

static uint8_t fm6_patch[NTRK][FP_SIZE + 1u];   /* the tracks' patches (main loop writes, then fm6_pgen) */
static volatile uint8_t fm6_pgen[NTRK];          /* +1 after each write of fm6_patch[t] */
static uint8_t fm6_slot[NTRK];                   /* the SLOT value last loaded (main loop); 0xFF = none */
static uint8_t fm6_own[NTRK][FM6_PACKED];        /* the own patch while SLOT shows a factory one (fm6_poll) */
static uint8_t fm6_own_ok;                       /* bit tr: fm6_own[tr] holds it */
static struct {                                  /* the patch through the macros: the audio ISR's copy */
    uint8_t p[FP_SIZE + 1u];
    uint8_t gen, alg, fb, ok;
    int16_t e[7];                                /* P_E0..P_E6 it was made with */
    int16_t env[4];                              /* (0.6.81) .. and the track's ATK DEC SUS REL */
    int32_t dt[6];                               /* DTUN: per operator, Q24 log2 */
} fm6_eff[NTRK];
static fm6_lfo_t fm6_lfo[NTRK];
static int32_t fm6_lfo_v[NTRK], fm6_lfo_d[NTRK]; /* this block's LFO value and delay (Q24) */
static fm6_note_t fm6_note[NTRK][FM6_POLY];
/* the voice bank (fm6_vbank.c; in the pool, zeroed at boot: no bank without the store) */
static uint32_t fm6_bank_used __attribute__((unused));   /* bit k: B k+1 holds a voice */
static int (*fm6_bank_read)(uint32_t k, uint8_t *pk) __attribute__((unused));   /* voice k -> pk, 0 = read */

/* SLOT value s is a bank slot (B1..B32): its voice number, else -1 */
static int32_t fm6_bank_slot(int32_t s)
{
    return s > (int32_t)FM6_OWN && s <= (int32_t)(FM6_OWN + FM6_NBANK) ? s - (int32_t)FM6_OWN - 1 : -1;
}
/* SLOT value s can load: a factory slot, OWN, or a bank slot with a voice */
static int fm6_slot_ok(int32_t s)
{
    int32_t k = fm6_bank_slot(s);
    return k < 0 ? s >= 0 && s <= (int32_t)FM6_OWN : (int)((fm6_bank_used >> k) & 1u);
}
/* (JIANT 0.6.8, "certain syx sounds glitchy and noisy") a voice's output above the level every voice is made for
 * (VOICE_FS, dsp.c: the bus at 2^26) takes the track's trim down so it sits there: DX7 voices with several carriers
 * at full came out up to 5x the factory patches, and their chords held the master's limiter 10 dB down. A voice's own
 * peak (a chord still adds up), never up, ramped across the block; back to none with each new patch. As an
 * attenuation: the gain is (256 - it) / 256 (0: none, the power-on value). The factory patches stay under it */
#define FM6_TRIM_REF (1 << 26)
static uint8_t fm6_trim[NTRK], fm6_tgen[NTRK];
static uint8_t fm6_trim_keep;                    /* bit tr: the new patch is an edit of the last (ui_fm6op.c): its trim stays */

/* ------------------------------------------------------- patch formats --- */
/* the highest value of each byte of the 155-byte voice */
static uint32_t fm6_max(uint32_t i)
{
    static const uint8_t OPMAX[21] = {99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 3, 3, 7, 3, 7, 99, 1, 31, 99, 14};
    static const uint8_t VMAX[19] = {99, 99, 99, 99, 99, 99, 99, 99, 31, 7, 1, 99, 99, 99, 99, 1, 5, 7, 48};
    if (i < 126u)
        return OPMAX[i % 21u];
    if (i < FP_NAME)
        return VMAX[i - 126u];
    return 126u;
}

/* every value inside its range (a name byte outside 32..126 becomes a space) */
static void fm6_sanitize(uint8_t *v)
{
    uint32_t i;
    for (i = 0; i < FP_SIZE; i++) {
        if (i >= FP_NAME)
            v[i] = v[i] < 32u || v[i] > 126u ? ' ' : v[i];
        else if (v[i] > fm6_max(i))
            v[i] = (uint8_t)fm6_max(i);
    }
    v[FP_SIZE] = 0;
}

/* 128-byte packed record (the 32-voice bank's) -> 155-byte voice; bits a record does not use are ignored */
static void fm6_unpack(const uint8_t *b, uint8_t *v)
{
    uint32_t k, i;
    for (k = 0; k < 6u; k++) {
        const uint8_t *o = b + k * 17u;
        uint8_t *d = v + k * FP_OP;
        for (i = 0; i < 11u; i++)
            d[i] = o[i] & 0x7Fu;
        d[FP_LC] = o[11] & 3u;
        d[FP_RC] = (o[11] >> 2) & 3u;
        d[FP_RS] = o[12] & 7u;
        d[FP_DET] = (o[12] >> 3) & 15u;
        d[FP_AMS] = o[13] & 3u;
        d[FP_KVS] = (o[13] >> 2) & 7u;
        d[FP_OL] = o[14] & 0x7Fu;
        d[FP_MODE] = o[15] & 1u;
        d[FP_FC] = (o[15] >> 1) & 31u;
        d[FP_FF] = o[16] & 0x7Fu;
    }
    for (i = 0; i < 9u; i++)
        v[FP_PR1 + i] = b[102 + i] & 0x7Fu;              /* pitch EG, algorithm */
    v[FP_ALG] &= 31u;
    v[FP_FB] = b[111] & 7u;
    v[FP_OKS] = (b[111] >> 3) & 1u;
    for (i = 0; i < 4u; i++)
        v[FP_LFS + i] = b[112 + i] & 0x7Fu;
    v[FP_LKS] = b[116] & 1u;
    v[FP_LFW] = (b[116] >> 1) & 7u;
    v[FP_LPMS] = (b[116] >> 4) & 7u;
    v[FP_TRNSP] = b[117] & 0x7Fu;
    for (i = 0; i < 10u; i++)
        v[FP_NAME + i] = b[118 + i] & 0x7Fu;
    fm6_sanitize(v);
}

/* 155-byte voice -> 128-byte packed record (7-bit bytes: it travels in SysEx as it is) */
static void fm6_pack(const uint8_t *v, uint8_t *b)
{
    uint32_t k, i;
    for (k = 0; k < 6u; k++) {
        const uint8_t *o = v + k * FP_OP;
        uint8_t *d = b + k * 17u;
        for (i = 0; i < 11u; i++)
            d[i] = o[i] & 0x7Fu;
        d[11] = (uint8_t)((o[FP_LC] & 3u) | (o[FP_RC] & 3u) << 2);
        d[12] = (uint8_t)((o[FP_RS] & 7u) | (o[FP_DET] & 15u) << 3);
        d[13] = (uint8_t)((o[FP_AMS] & 3u) | (o[FP_KVS] & 7u) << 2);
        d[14] = o[FP_OL] & 0x7Fu;
        d[15] = (uint8_t)((o[FP_MODE] & 1u) | (o[FP_FC] & 31u) << 1);
        d[16] = o[FP_FF] & 0x7Fu;
    }
    for (i = 0; i < 9u; i++)
        b[102 + i] = v[FP_PR1 + i] & 0x7Fu;
    b[110] &= 31u;
    b[111] = (uint8_t)((v[FP_FB] & 7u) | (v[FP_OKS] & 1u) << 3);
    for (i = 0; i < 4u; i++)
        b[112 + i] = v[FP_LFS + i] & 0x7Fu;
    b[116] = (uint8_t)((v[FP_LKS] & 1u) | (v[FP_LFW] & 7u) << 1 | (v[FP_LPMS] & 7u) << 4);
    b[117] = v[FP_TRNSP] & 0x7Fu;
    for (i = 0; i < 10u; i++)
        b[118 + i] = v[FP_NAME + i] & 0x7Fu;
}

/* ---------------------------------------------------- the track's patch --- */
/* track tr's patch = v (155 bytes, sanitized). Main loop: the ISR takes it at its next block */
static void fm6_set_patch(uint32_t tr, const uint8_t *v)
{
    uint8_t s[FP_SIZE + 1u];
    tr %= NTRK;
    memcpy(s, v, FP_SIZE);
    fm6_sanitize(s);                                /* not in place: fm6_sync must never copy an unsanitized byte */
    memcpy(fm6_patch[tr], s, FP_SIZE + 1u);
    RING_PUBLISH();
    fm6_pgen[tr]++;
}

/* SLOT value s < FM6_NFACTORY: that factory patch into track tr; a bank slot: its voice (0 = loaded; 1 = the bank
 * has none there, nothing changed) */
static int fm6_load_slot(uint32_t tr, uint32_t s)
{
    uint8_t v[FP_SIZE + 1u], pk[FM6_PACKED];
    int32_t k = fm6_bank_slot((int32_t)s);
    if (k < 0) {
        s %= FM6_NFACTORY;
        memcpy(pk, FM6_FACTORY[s], FM6_PACKED);
    } else if (!fm6_slot_ok((int32_t)s) || !fm6_bank_read || fm6_bank_read((uint32_t)k, pk)) {
        return 1;
    }
    fm6_unpack(pk, v);
    fm6_set_patch(tr, v);
    fm6_slot[tr % NTRK] = (uint8_t)s;
    return 0;
}

/* track tr's patch was just put in as its own (a project, a user preset, the editor, a conversion): an FM6 track's
 * SLOT shows the factory patch it equals unchanged (F n; the SLOT it had first), else OWN; nothing reloads over it
 * (fm6_poll) */
static void fm6_adopt(uint32_t tr)
{
    track_t *t = &trk[tr % NTRK];
    int32_t s = t->p[P_E7];
    tr %= NTRK;
    fm6_own_ok &= (uint8_t)~(1u << tr);
    if (t->eng_req == ENGI_FM6) {
        uint8_t v[FP_SIZE + 1u];
        uint32_t k, f = s >= 0 && s < (int32_t)FM6_NFACTORY ? (uint32_t)s : 0u;
        for (k = 0; k < FM6_NFACTORY; k++) {
            fm6_unpack(FM6_FACTORY[(f + k) % FM6_NFACTORY], v);
            if (!memcmp(v, fm6_patch[tr], FP_SIZE))
                break;
        }
        s = k < FM6_NFACTORY ? (int32_t)((f + k) % FM6_NFACTORY) : (int32_t)FM6_OWN;
        t->p[P_E7] = (int16_t)s;
    }
    fm6_slot[tr] = (uint8_t)s;
}

/* a factory sound load put a SLOT value in (a preset, an engine change): its patch (OWN: the patch stays) */
static void fm6_track_loaded(const track_t *t)
{
    uint32_t tr = (uint32_t)(t - trk);
    if (tr < NTRK && t->eng_req == ENGI_FM6) {
        fm6_own_ok &= (uint8_t)~(1u << tr);
        if (t->p[P_E7] >= 0 && t->p[P_E7] < (int32_t)FM6_NFACTORY)
            fm6_load_slot(tr, (uint32_t)t->p[P_E7]);
        else if (fm6_bank_slot(t->p[P_E7]) < 0 || fm6_load_slot(tr, (uint32_t)t->p[P_E7]))   /* (1.2-GW) a preset
                                                          * on a bank slot: its voice (GW-1 KEYS, or the bank sent) */
            fm6_adopt(tr);
    }
}

/* (0.6.46) INIT SOUND / NEW PROJECT: track t the init voice (OP1 alone at 99, the rates at 99: a plain sine) as its
 * own patch (SLOT OWN), nothing kept aside */
static void fm6_init_voice(track_t *t)
{
    uint8_t v[FP_SIZE + 1u];
    uint32_t tr = (uint32_t)(t - trk);
    if (tr >= NTRK || t->eng_req != ENGI_FM6)
        return;
    fm6_unpack(FM6_INIT, v);
    fm6_set_patch(tr, v);
    fm6_own_ok &= (uint8_t)~(1u << tr);
    fm6_slot[tr] = FM6_OWN;
    t->p[P_E7] = FM6_OWN;
}

/* power-on: every track the init voice (what a project stores for the tracks that never played FM6) */
static void fm6_init(void)
{
    uint8_t v[FP_SIZE + 1u];
    uint32_t tr;
    fm6_unpack(FM6_INIT, v);
    for (tr = 0; tr < NTRK; tr++) {
        fm6_set_patch(tr, v);
        fm6_slot[tr] = 0xFFu;
    }
}

/* main loop: SLOT turned (a knob, the editor, MIDI, motion) -> that factory patch or bank voice; from OWN the own
 * patch is kept aside (fm6_own), and turning back to OWN brings it back. A bank slot without a voice (the editor, a
 * MIDI CC) is refused: SLOT goes back to what it was, nothing loads */
static void fm6_poll(void)
{
    uint32_t tr, bit;
    for (tr = 0; tr < NTRK; tr++) {
        int32_t s = trk[tr].p[P_E7];
        if (trk[tr].eng_req != ENGI_FM6 || s == fm6_slot[tr])
            continue;
        bit = 1u << tr;
        if (s < 0 || (s >= (int32_t)FM6_NFACTORY && fm6_bank_slot(s) < 0)) {   /* OWN */
            if (fm6_own_ok & bit) {
                uint8_t v[FP_SIZE + 1u];
                fm6_unpack(fm6_own[tr], v);
                fm6_set_patch(tr, v);
            }
            fm6_own_ok &= (uint8_t)~bit;
            fm6_slot[tr] = FM6_OWN;
            if (s != FM6_OWN)
                trk[tr].p[P_E7] = FM6_OWN;
            continue;
        }
        if (fm6_slot[tr] == FM6_OWN && !(fm6_own_ok & bit) && fm6_slot_ok(s)) {
            fm6_pack(fm6_patch[tr], fm6_own[tr]);
            fm6_own_ok |= (uint8_t)bit;
        }
        if (fm6_load_slot(tr, (uint32_t)s))                  /* a bank slot without a voice: SLOT back */
            trk[tr].p[P_E7] = (int16_t)(fm6_slot[tr] <= FM6_OWN + FM6_NBANK ? fm6_slot[tr] : FM6_OWN);
    }
}

/* -------------------------------------------------------------- macros --- */
/* the patch through E0..E6 (audio ISR; cheap when nothing changed) */
static void fm6_sync(const track_t *t)
{
    uint32_t tr = (uint32_t)(t - trk), k, j, car, n = 0;
    const int16_t *e = &t->p[P_E0];
    int32_t meg, step;
    if (tr >= NTRK)
        return;
    if (fm6_eff[tr].ok && fm6_eff[tr].gen == fm6_pgen[tr]) {
        for (k = 0; k < 7u && fm6_eff[tr].e[k] == e[k]; k++)
            ;
        for (j = 0; k == 7u && j < 4u && fm6_eff[tr].env[j] == t->p[P_ATK + j]; j++)
            ;
        if (k == 7u && j == 4u)
            return;
    }
    fm6_eff[tr].gen = fm6_pgen[tr];
    memcpy(fm6_eff[tr].p, fm6_patch[tr], FP_SIZE);
    for (k = 0; k < 7u; k++)
        fm6_eff[tr].e[k] = e[k];
    for (j = 0; j < 4u; j++)
        fm6_eff[tr].env[j] = t->p[P_ATK + j];
    {
        uint8_t *p = fm6_eff[tr].p;
        uint32_t alg = e[0] >= 1 && e[0] <= 32 ? (uint32_t)e[0] - 1u : p[FP_ALG] & 31u;
        fm6_eff[tr].alg = (uint8_t)alg;
        fm6_eff[tr].fb = (uint8_t)clamp(p[FP_FB] + e[1], 0, 7);
        car = fm6_carriers(alg);
        meg = clamp(e[4], -64, 63) * 40 / 64;               /* MEG: rate steps (+ slower) */
        step = clamp(e[6], 0, 127) * (12 * 13981) / 127;    /* DTUN: up to 12 cents a step (1 cent = 13981) */
        for (k = 0; k < 6u; k++) {
            uint8_t *op = p + (5u - k) * FP_OP;              /* OP1 first: carriers in their order */
            uint32_t ki = 5u - k;
            fm6_eff[tr].dt[ki] = 0;
            if ((car >> ki) & 1u) {                          /* carriers 0, +1, -1, +2, -2, +3 steps apart */
                static const int8_t SPREAD[6] = {0, 1, -1, 2, -2, 3};
                fm6_eff[tr].dt[ki] = SPREAD[n++] * step;
                /* (0.6.81) the track's ADSR on the carriers, relative to the patch (its defaults 0 0 127 0: the
                 * patch as it is; the ENV page did nothing on FM6): ATK DEC REL slow their stages, SUS sets the
                 * sustain level */
                op[FP_R1] = (uint8_t)clamp(op[FP_R1] - clamp(t->p[P_ATK], 0, 127) * 90 / 127, 1, 99);
                op[FP_R1 + 1u] = (uint8_t)clamp(op[FP_R1 + 1u] - clamp(t->p[P_DEC], 0, 127) * 90 / 127, 1, 99);
                if (t->p[P_SUS] < 127)                       /* (SUS below the top: the carriers' sustain level, so
                                                         * a decaying patch can be held too) */
                    op[FP_L1 + 2u] = (uint8_t)(t->p[P_SUS] > 0 ? 50 + clamp(t->p[P_SUS], 0, 126) * 49 / 126 : 0);   /* (the
                                                         * EG's levels are logarithmic, ~0.75 dB a step: 50..99) */
                op[FP_R1 + 3u] = (uint8_t)clamp(op[FP_R1 + 3u] - clamp(t->p[P_REL], 0, 127) * 90 / 127, 1, 99);
                continue;
            }
            if (!op[FP_MODE])
                op[FP_FC] = (uint8_t)clamp(op[FP_FC] + e[3], 0, 31);
            for (j = 0; j < 4u; j++)
                op[FP_R1 + j] = (uint8_t)clamp(op[FP_R1 + j] - meg, 0, 99);
            op[FP_KVS] = (uint8_t)clamp(op[FP_KVS] + e[5], 0, 7);
        }
        fm6_lfo_reset(&fm6_lfo[tr], p);
    }
    fm6_eff[tr].ok = 1;
}

/* --------------------------------------------------------------- voice --- */
static fm6_note_t *fm6_note_of(track_t *t, voice_t *v)
{
    uint32_t i;
    if (t < &trk[0] || t >= &trk[NPART])
        return 0;
    i = vindex(t, v);
    return i < FM6_POLY ? &fm6_note[t - trk][i] : 0;
}

static void fm6_note_on(track_t *t, voice_t *v)
{
    fm6_note_t *n = fm6_note_of(t, v);
    uint32_t tr = (uint32_t)(t - trk);
    const uint8_t *p;
    if (!n)
        return;
    fm6_sync(t);
    p = fm6_eff[tr].p;
    fm6_note_init(n, p, (int32_t)v->note + p[FP_TRNSP] - 24, v->mvel ? v->mvel : v->vel,
                  (!v->env && !v->env_out) || !n->live);    /* from silence: phases and gains from 0 */
    n->trim = 255;                                      /* (its first block: the track's trim at once) */
    fm6_lfo_key(&fm6_lfo[tr]);
}

static void fm6_block(track_t *t)       /* once a block and part: the macros, the LFO */
{
    uint32_t tr = (uint32_t)(t - trk);
    if (tr >= NTRK)
        return;
    fm6_sync(t);
    if (fm6_tgen[tr] != fm6_pgen[tr]) {                 /* a new patch: its own trim, from none (an edit: kept) */
        fm6_tgen[tr] = fm6_pgen[tr];
        if (!((fm6_trim_keep >> tr) & 1u))
            fm6_trim[tr] = 0;
        fm6_trim_keep &= (uint8_t)~(1u << tr);
    }
    fm6_lfo_v[tr] = fm6_lfo_sample(&fm6_lfo[tr]);
    fm6_lfo_d[tr] = fm6_lfo_delay(&fm6_lfo[tr]);
}

/* (FASE 12) How long a released voice keeps its tail before the fade that gives the voice back: the operator
 * envelope's stage 4 holds L4 for ever, so a patch whose L4 is audible would never free its voice. 5 s is longer
 * than any tail the FM4 conversions are measured on (1 s) and shorter than the 12 s the health checks allow; 60 ms
 * of fade make the cut inaudible. */
#define FM6_REL_MAX (5 * 44100)
#define FM6_REL_FADE 2646

/* every carrier has gone silent for good: the voice ends (voice.c, engine_t.done) */
static int fm6_done(track_t *t, voice_t *v)
{
    fm6_note_t *n = fm6_note_of(t, v);
    uint32_t tr = (uint32_t)(t - trk);
    if (!n || !n->live)
        return 1;
    if (!fm6_note_done(n, fm6_eff[tr].p, fm6_eff[tr].alg))
        return 0;
    n->live = 0;
    return 1;
}

static void fm6_render(track_t *t, voice_t *v, int32_t *out, uint32_t len, const vmod_t *m)
{
    fm6_note_t *n = fm6_note_of(t, v);
    uint32_t tr = (uint32_t)(t - trk), i;
    const uint8_t *p;
    int32_t bus[FM6_N], lf, fb, lvl, k, a, da, pk = 0, fg = 65536;
    uint32_t tb;
    if (!n || !n->live || len != FM6_N)
        return;
    p = fm6_eff[tr].p;
    if (!v->gate && n->down)
        fm6_note_key(n, p, 0);
    lf = fm6_note_logfreq(m->pitch16 + (p[FP_TRNSP] - 24) * 16,
                             m->fine + tune_cents(m->pitch16) * 13981 / 100);   /* (FASE 7) the temperament */
    fb = clamp(fm6_eff[tr].fb + ((m->shape - (64 << 8)) >> 11), 0, 7);
    lvl = clamp(t->p[P_E2], -64, 63) * 24 + clamp(m->cutoff >> 8, -150, 150) * 16 +   /* microsteps */
          clamp((m->shape - (64 << 8)) >> 8, -150, 150) * 16;   /* (0.6.81) SHAPE: the modulators' depth too (the
                                                         * feedback alone was silent where its operator is quiet) */
    if (!fm6_note_compute(n, p, bus, fm6_lfo_v[tr], fm6_lfo_d[tr], lf, fm6_eff[tr].alg, fb, fm6_eff[tr].dt, lvl * 65536))   /* (v1.5.16) lvl is signed: * 65536 */
        return;                                         /* every carrier below the threshold */
    /* (FASE 12) A RELEASED NOTE GETS ITS TAIL, THEN ITS VOICE BACK. Stage 4 of the operator envelopes holds L4, and a
     * patch whose L4 is audible once the key is up kept the voice for ever (tests/regress: SILT KEYS and FERROUS PAD
     * still sounding 12 s after the note-offs, DC left behind). The tail is kept exactly as it was — the FM4
     * conversions measure it at 1 s and must keep passing — and after FM6_REL_MAX the voice fades out over
     * FM6_REL_FADE samples, so the voice comes back without a click. A held note never counts. */
    if (!n->down) {
        n->rel_t += FM6_N;
        if (n->rel_t >= FM6_REL_MAX + FM6_REL_FADE) {
            n->live = 0;
            return;
        }
        if (n->rel_t > FM6_REL_MAX)
            fg = ((FM6_REL_MAX + FM6_REL_FADE - n->rel_t) << 16) / FM6_REL_FADE;
    }
    /* the voice's amplitude ramp x VOICE_FS (one carrier at full: VOICE_FS / 2), six voices in unison ~ one */
    k = t->p[P_VOICE] == V_UNISON ? VOICE_FS * 2 / 5 : VOICE_FS;
    for (i = 0; i < FM6_N; i++) {                       /* the block's peak first: its trim from this block on */
        int32_t x = bus[i] - n->dc, ax = x < 0 ? -x : x;   /* (as it goes out: past the DC blocker) */
        pk = ax > pk ? ax : pk;
    }
    pk >>= 10;                                            /* (2^26 >> 10 = 2^16: the products fit 32 bits) */
    if ((uint32_t)pk * (256u - fm6_trim[tr]) > (uint32_t)(FM6_TRIM_REF >> 10) << 8) {   /* over: down to there */
        uint32_t g = ((uint32_t)(FM6_TRIM_REF >> 10) << 8) / (uint32_t)pk;   /* the gain that would sit there */
        fm6_trim[tr] = (uint8_t)(256u - (g < 8u ? 8u : g));   /* (-30 dB at most) */
    }
    if (n->trim == 255u)                                /* (255: never a trim, -30 dB is 248) */
        n->trim = fm6_trim[tr];
    tb = 256u - fm6_trim[tr];                           /* the trim from the note's last block to the track's now */
    a = (mulq15(m->amp0, k) * (int32_t)(256u - n->trim)) >> 8;
    da = (((mulq15(m->amp1, k) * (int32_t)tb) >> 8) - a) >> FM6_LG_N;
    n->trim = fm6_trim[tr];
    for (i = 0; i < FM6_N; i++) {
        int32_t x = bus[i] - n->dc;
        n->dc += x >> 10;                                 /* a one-pole high-pass, ~7 Hz: FM puts sidebands at 0 Hz */
        a += da;
        out[i] += fg == 65536 ? (int32_t)(((int64_t)x * a) >> 26) : (int32_t)(((int64_t)x * a * fg) >> 42);
    }
    {   /* (FASE 2) CHARACTER: TONE (a one-pole high shelf), FOLD (a symmetric wavefolder: odd harmonics). They run
         * after the voice's amplitude, so the envelope is untouched and a zero block stays silent. s[0] is free in
         * FM6 (its state is fm6_note), both neutral at 127. */
        int32_t ta = xamt(t->p, 0), fa = xamt(t->p, 1), lp = v->s[0];
        if (ta) {
            for (i = 0; i < FM6_N; i++) {
                int32_t y = out[i];
                lp += (y - lp) >> 6;
                out[i] = soft_knee(y + (((y - lp) * ta) >> 8), 30000);
            }
            v->s[0] = lp;
        }
        if (fa)
            for (i = 0; i < FM6_N; i++)
                out[i] = softclip((out[i] * (4096 + fa * 24)) >> 12);
    }
}

/* --------------------------------------------------------- the engine --- */
static const char *const N_FM6_ALG[] = {"PAT", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13",
                                        "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25",
                                        "26", "27", "28", "29", "30", "31", "32", 0};
static const char *const N_FM6_PATCH[] = {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "OWN",
                                          "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9", "B10", "B11", "B12",
                                          "B13", "B14", "B15", "B16", "B17", "B18", "B19", "B20", "B21", "B22", "B23",
                                          "B24", "B25", "B26", "B27", "B28", "B29", "B30", "B31", "B32", 0};
_Static_assert(NELEM(N_FM6_PATCH) == FM6_OWN + FM6_NBANK + 2u, "a SLOT name per value");

/* {ALG, FB, MLVL, MRAT, MEG, VMOD, DTUN, SLOT}: the factory patch F1..F8 as it is, DTUN on the pad */
static const preset_t FM6_PRESETS[] = {
    {"SILT KEYS", {0, 4, 0, 0, 0, 0, 10, 12}, {6, 74, 116, 58}, 0, 0, FX(0, 58, 34, 62), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 16), XP(P_HARM, 16)}},  /* C: hybrid */
    {"BELL", {0, 0, 0, 0, 0, 0, 0, 1}, {0, 0, 127, 0}, 0, 0, FX(0, 10, 30, 72), PAT(7),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 22), XP(P_HARM, 22)}},
    {"FM BASS", {0, 0, 0, 0, 0, 0, 0, 2}, {0, 0, 127, 0}, 0, 1, FX(16, 0, 8, 8), PAT(2),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18), XP(P_LEVEL, 115), XP(P_HARM, -10)}},
    {"BRASS", {0, 0, 0, 0, 0, 0, 0, 3}, {0, 0, 127, 0}, 0, 0, FX(8, 26, 22, 38), PAT(4),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 20), XP(P_HARM, 18)}},
    {"PAD", {0, 0, 0, 0, 0, 0, 30, 4}, {0, 0, 127, 0}, 0, 0, FX(0, 62, 32, 72), PAT(5),
     {XP(P_LRATE, 16), XP(P_LWAVE, 6), XP(P_LD_FLT, 12), XP(P_LD_AMP, 6), XP(P_LEVEL, 122)}},
    {"MARIMBA", {0, 0, 0, 0, 0, 0, 0, 5}, {0, 0, 127, 0}, 0, 0, FX(0, 0, 26, 38), PAT(3),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 26), XP(P_LEVEL, 127), XP(P_ELOOP, 2)}},
    {"ORGAN", {0, 0, 0, 0, 0, 0, 0, 6}, {0, 0, 127, 0}, 0, 0, FX(10, 42, 4, 28), PAT(6),
     {XP(P_LRATE, 19), XP(P_LD_AMP, 6), XP(P_LSHP, 20)}},
    {"PLUCK", {0, 0, 0, 0, 0, 0, 0, 7}, {0, 0, 127, 0}, 0, 0, FX(0, 20, 36, 28), PAT(13),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 24), XP(P_ELOOP, 2)}},
    /* (1.2-GW, issue #17: ambient and expressive) on GW-1 KEYS, the bank FM6 has built in (B1.., fm6_vbank.c): electric
     * pianos, bells, mallets, pads; velocity opens their brightness (each voice's own KVS) */
    {"SOFT EP", {0, 0, 0, 0, 0, 0, 0, 9}, {0, 0, 127, 0}, 0, 0, FX(0, 50, 26, 44), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 22), XP(P_HARM, 8)}},
    {"REED PIANO", {0, 0, 0, 0, 0, 0, 0, 10}, {0, 0, 127, 0}, 0, 0, FX(6, 40, 22, 34), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 22), XP(P_HARM, 12)}},
    {"FM PIANO", {0, 0, 0, 0, 0, 0, 0, 11}, {0, 0, 127, 0}, 0, 0, FX(0, 20, 16, 44), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 24), XP(P_HARM, 10)}},
    {"GLASS KEYS", {0, 0, 0, 0, 0, 0, 10, 12}, {0, 0, 127, 0}, 0, 0, FX(0, 56, 36, 58), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 20), XP(P_HARM, 20)}},
    {"CRYSTAL BELL", {0, 0, 0, 0, 0, 0, 0, 13}, {0, 0, 127, 0}, 0, 0, FX(0, 30, 46, 84), PAT(7),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 20), XP(P_HARM, 26)}},
    {"KALIMBA", {0, 0, 0, 0, 0, 0, 0, 14}, {0, 0, 127, 0}, 0, 0, FX(0, 14, 36, 54), PAT(3),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 26), XP(P_ELOOP, 2)}},
    {"VIBES", {0, 0, 0, 0, 0, 0, 0, 15}, {0, 0, 127, 0}, 0, 0, FX(0, 20, 26, 58), PAT(7),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 22), XP(P_HARM, 16)}},
    {"MUSIC BOX", {0, 0, 0, 0, 0, 0, 0, 16}, {0, 0, 127, 0}, 0, 0, FX(0, 24, 42, 74), PAT(3),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 20), XP(P_ELOOP, 2)}},
    {"WARM PAD", {0, 0, 0, 0, 0, 0, 20, 17}, {0, 0, 127, 0}, 0, 0, FX(0, 68, 30, 84), PAT(5),
     {XP(P_LRATE, 14), XP(P_LWAVE, 6), XP(P_LD_FLT, 10), XP(P_LD_AMP, 6)}},
    {"GLASS PAD", {0, 0, 0, 0, 0, 0, 20, 18}, {0, 0, 127, 0}, 0, 0, FX(0, 68, 36, 88), PAT(5),
     {XP(P_LRATE, 13), XP(P_LWAVE, 6), XP(P_LD_FLT, 12), XP(P_LD_AMP, 6)}},
    {"CELESTA", {0, 0, 0, 0, 0, 0, 0, 19}, {0, 0, 127, 0}, 0, 0, FX(0, 24, 36, 64), PAT(7),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 22), XP(P_HARM, 18)}},
    /* (QG-1 EXPANSION: Bells, Acoustic, Ethnic & Experimental) */
    {"TEMPLE BELL", {0, 0, 0, 0, 0, 0, 0, 1}, {0, 0, 127, 0}, 0, 0, FX(0, 34, 42, 88), PAT(7),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18), XP(P_HARM, -8)}},
    {"TIBET BOWL", {0, 0, 0, 0, 0, 0, 12, 13}, {0, 0, 127, 0}, 0, 0, FX(0, 48, 44, 92), PAT(7),
     {XP(P_LRATE, 10), XP(P_LWAVE, 6), XP(P_LD_FLT, 12), XP(P_LD_AMP, 6)}},
    {"GONG SHIMMER", {0, 4, 16, 0, -10, 2, 26, 1}, {0, 0, 127, 0}, 0, 0, FX(0, 38, 48, 86), PAT(7),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18), XP(P_HARM, -18)}},
    /* (FASE 3) KOTO HARP now carries two of the four new values: the part filter is a NOTCH (the cut taken out,
     * so the pluck rings hollow) and the LFO is PLUK, a decay inside every cycle (its `(1-x)^4` falls where the
     * sine would still be rising), sweeping that cut. Velocity still opens the cut. */
    {"KOTO HARP", {0, 0, 0, 0, 0, 0, 0, 7}, {0, 0, 127, 0}, 0, 0, FX(0, 18, 32, 44), PAT(15),
     {XP(P_FTYPE, 6), XP(P_FCUT, 58), XP(P_LRATE, 30), XP(P_LWAVE, 9), XP(P_LD_FLT, 44)}},
    /* (FASE 3) SITAR RESON carries the other two: a SHELF (x + LP: +6 dB under the corner, the top where it was)
     * and the matrix's RES destination, so the velocity opens the resonance of that shelf instead of its cut. */
    {"SITAR RESON", {0, 0, 0, 0, 0, 0, 0, 14}, {0, 0, 127, 0}, 0, 0, FX(16, 28, 36, 58), PAT(3),
     {XP(P_M1SRC, 3), XP(P_M1DST, 26), XP(P_M1AMT, 24), XP(P_FTYPE, 7), XP(P_FCUT, 44), XP(P_HARM, 14)}},
    {"IRON PLUCK", {0, 0, 62, 0, 0, 0, 0, 5}, {0, 0, 112, 18}, 0, 0, FX(0, 18, 40, 54), PAT(3),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 30), XP(P_HARM, 22)}},  /* C: performance */
    {"STEEL DRUM", {0, 0, 0, 0, 0, 0, 0, 5}, {0, 0, 127, 0}, 0, 0, FX(0, 10, 26, 48), PAT(3),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 24), XP(P_LEVEL, 119), XP(P_ELOOP, 2)}},

    /* (QG-1 1.6) EVOLVE: the bell's tail keeps moving while it rings */
    {"EVOLVE BELL", {0, 0, 0, 0, 0, 0, 0, 1}, {0, 0, 127, 0}, 0, 0, FX(0, 25, 30, 74), PAT(7),
     {XP(P_LRATE, -2), XP(P_LWAVE, 6), XP(P_LFADE, 70), XP(P_LD_FLT, 18), XP(P_LD_AMP, 8)}},
    /* (QG-1 1.6) TOUCH: the EP's brightness follows velocity, its vibrato the pressure */
    {"VELVET EP", {0, 0, 0, 0, 0, 0, 0, 0}, {0, 70, 30, 25}, 0, 0, FX(0, 55, 30, 48), PAT(6),
     {XP(P_M1AMT, 40), XP(P_M2AMT, 24), XP(P_HARM, 6)}},


    {"AURORA FM", {0, 0, 0, 0, 0, 0, 0, 4}, {30, 90, 60, 8}, 0, 0, FX(0, 52, 35, 64), PAT(5),
     {XP(P_LRATE, -3), XP(P_LWAVE, 6), XP(P_LFADE, 80), XP(P_LD_FLT, 20), XP(P_LD_AMP, 10)}},
    /* (6.0) the remaster's new sounds: one per family, each with its own motion and sends */
    {"EMBER TINES", {0, 2, 0, 0, 0, 0, 10, 0}, {0, 0, 127, 0}, 18, 0, FX(4, 40, 28, 40), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 24), XP(P_HARM, 10)}},  /* C: EP */
    {"FROST MUSIC", {0, -3, 0, 0, 0, 0, 0, 16}, {0, 0, 127, 0}, 10, 0, FX(0, 24, 44, 72), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 20), XP(P_HARM, 24)}},  /* C: music box */
    {"FERROUS PAD", {0, 0, 0, 0, 0, 0, 0, 6}, {46, 84, 108, 92}, 0, 0, FX(0, 48, 30, 80), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18), XP(P_LEVEL, 96)}},  /* C: texture */
    {"ALLOY BASS", {0, 6, 0, 0, 0, 0, 0, 2}, {0, 62, 72, 22}, 30, 1, FX(22, 0, 6, 6), PAT(2),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18), XP(P_HARM, -6)}},  /* E: FM bass */
    {"SUBMARINE BELL", {0, 0, 0, 0, 0, 0, 14, 13}, {0, 0, 127, 0}, 8, 0, FX(0, 28, 48, 88), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18), XP(P_HARM, -14)}},  /* C: bell */
    {"PAPER ORGAN", {0, 4, 0, 0, 0, 0, 6, 6}, {10, 0, 127, 25}, 12, 0, FX(10, 44, 6, 30), PAT(6),
     {XP(P_LRATE, 20), XP(P_LD_AMP, 6), XP(P_LSHP, 22)}},  /* KEYS: organ */
    {"CINTA MAGNETICA", {0, -2, 0, 0, 0, 0, 20, 9}, {20, 0, 127, 40}, 16, 0, FX(8, 52, 30, 64), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 20), XP(P_HARM, -10)}},  /* G: tape keys */
    {"TEMPLE CIRCUIT", {0, 3, -12, -5, 12, 0, 8, 1}, {0, 0, 127, 0}, 12, 0, FX(0, 32, 46, 90), PAT(6),
     {XP(P_M1SRC, 3), XP(P_M1DST, 2), XP(P_M1AMT, 18), XP(P_HARM, -12)}},  /* C: temple bell */
};

static const param_desc_t FM6_CH[2] = {
    {"TONE", F_PCTINV, 0, 127, 127, 0, 0}, {"FOLD", F_PCTINV, 0, 127, 127, 0, 0},
};

static const engine_t ENG_FM6 = {
    .name = "FM6",
    .page_title = {"OPS", "PATCH", "CHAR"},
    .edit = {
        {"ALG", F_INT, 0, 32, 0, N_FM6_ALG, 0},
        {"FB", F_INT, -7, 7, 0, 0, 0},
        {"MOD", F_BIPCT, -64, 63, 0, 0, 0},
        {"RATIO", F_INT, -16, 16, 0, 0, 0},
        {"MEG", F_BIPCT, -64, 63, 0, 0, 0},
        {"VMOD", F_INT, -7, 7, 0, 0, 0},
        {"DETUNE", F_PCT, 0, 127, 0, 0, 0},
        {"SLOT", F_INT, 0, FM6_OWN + FM6_NBANK, 0, N_FM6_PATCH, 0},
    },
    .presets = FM6_PRESETS,
    .npresets = NELEM(FM6_PRESETS),
    .ch = FM6_CH,
    .ch_n = 2,
    .note_on = fm6_note_on,
    .render = fm6_render,
    .knob = {P_E2, P_E3, P_E4, P_E7},
    .poly = FM6_POLY,
    .block = fm6_block,
    .ownenv = 1,
    .done = fm6_done,
};
