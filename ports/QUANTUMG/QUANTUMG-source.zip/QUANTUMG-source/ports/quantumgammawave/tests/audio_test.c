/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* The real audio ISR with a simulated DMA and clock: overload must free work
 * within one block without cutting another part's lead or bass. */
#define main hostsim_main
#include "hostsim.c"
#undef main

#define FM1_AUDIO_HALF 0x80u
#define FM1_TICKS_PER_US 1u
static uint32_t host_clock, host_us, host_half_reads, host_dma_advanced, host_acks, host_nest;
static uint8_t host_pending;
static volatile uint32_t t5_nested_ticks;              /* audio.c's: TIMER5 nested in the render (main.c) */
static uint32_t fm1_ticks(void) { t5_nested_ticks = host_nest; host_clock += host_us; return host_clock; }
static uint8_t fm1_audio_pending(void) { return host_pending; }
static void fm1_audio_ack_aux(uint8_t p) { (void)p; }
static uint32_t fm1_audio_free_half(void) { return host_dma_advanced && host_half_reads++ > 0u; }
static void fm1_audio_ack_half(void) { host_acks++; }
static void fm1_audio_init(int32_t *b, uint32_t n, void (*isr)(void), uint32_t p)
{ (void)b; (void)n; (void)isr; (void)p; }
void isr_alnk0(void) {}
#define FELUCCA_UAC 1                                  /* audio.c taps USB audio: here into host_tap */
static int32_t host_tap[2 * 64];
static uint32_t host_tap_n;
static void uac_tap(const int32_t *out, uint32_t n) { memcpy(host_tap, out, 8u * n); host_tap_n = n; }
static uint32_t host_acks_at_start;
static void uac_render_start(void) { host_acks_at_start = host_acks; }   /* (just before the blocks) */
#include "../firmware/src/audio.c"
enum { FM1_ADC_BATT = 3, FM1_ADC_MASTER = 4 };
static int32_t host_pot = 1023;                        /* the MASTER pot as the ADC reads it (-1: timeout) */
static int32_t fm1_adc_read(uint32_t ch) { return ch == FM1_ADC_MASTER ? host_pot : 620; }
#include "../firmware/src/master.c"

static int bad;
static void check(const char *what, int ok)
{
    printf("audio: %-74s %s\n", what, ok ? "ok" : "FAIL");
    bad += !ok;
}
static void fresh(void)
{
    uint32_t p;
    memset(trk, 0, sizeof trk);
    memset(&song, 0, sizeof song);
    memset(&chain, 0, sizeof chain);
    host_tracks_init();
    audio_fade_in();   /* (FASE 5) since the boot gate (FASE 3) the output is exact silence until main.c arms the
                        * ramp at the splash's end; these tests render blocks, not that timeline, so they arm
                        * it here and let the ramp spend itself in the first blocks */
    for (p = 0; p < NPART; p++) host_preset(&trk[p], 0, 0);
    memset(&felucca_dbg, 0, sizeof felucca_dbg);
    audio_cpu_rem = audio_halves = audio_max_us = 0;
    shed_req = 0; shed_count = 0; shed_over = 0;
    load_tight = 0; tight_calm = 0; memset((void *)&load_diag, 0, sizeof load_diag);
    host_clock = host_us = host_half_reads = host_dma_advanced = host_acks = host_nest = 0;
    host_pending = FM1_AUDIO_HALF;
    transport_req = panic_req = 0;
}
static voice_t *held(track_t *t, uint32_t note)
{
    uint32_t i;
    for (i = 0; i < NVOICE; i++)
        if (V(t, i).active && V(t, i).note == note) return &V(t, i);
    return 0;
}
static void overload(void)
{
    voice_t *lead, *bass, *extra;
    uint32_t mode, i;
    int32_t out[2 * CTL];
    fresh();
    trk[0].p[P_VOICE] = V_MONO;
    trk_note_on(&trk[0], 40, 100);
    trk[1].p[P_VOICE] = V_POLY;
    trk_note_on(&trk[1], 48, 100);
    trk_note_on(&trk[1], 60, 100);
    lead = held(&trk[0], 40); bass = held(&trk[1], 48); extra = held(&trk[1], 60);
    shed_voice();
    check("overload keeps each part's MONO lead and lowest POLY note",
          lead && bass && extra && lead->gate && bass->gate && extra->stage == 4u && shed_count == 1u);
    check("overload: its victim leaves the budget at once (it fades, 0.6.74)", voices_busy() == 2u);
    for (i = 0; i < 6u; i++) mix_block(out, CTL);
    check("overload frees its victim within 6 control blocks (~4 ms, faded: 0.6.74, was one)", extra && !extra->active && voices_busy() == 2u);
    shed_voice();
    check("a lead alone on each part stays protected", lead->gate && bass->gate && shed_count == 1u);

    fresh();
    host_preset(&trk[0], ENGI_DRUM, 0);
    trk_note_on(&trk[0], 36, 100); trk_note_on(&trk[0], 38, 100);
    lead = held(&trk[0], 36); extra = held(&trk[0], 38);
    shed_voice();
    for (i = 0; i < 6u; i++) mix_block(out, CTL);
    check("overload frees a held one-shot drum without waiting for its decay (faded over ~4 ms)",
          lead && extra && lead->active && !extra->active && voices_busy() == 1u);

    fresh();
    trk[0].p[P_VOICE] = V_UNISON;
    trk_note_on(&trk[0], 55, 100);
    shed_voice(); mix_block(out, CTL);
    check("UNISON loses an extra voice and retains its lead", V(&trk[0], 0).active && V(&trk[0], 0).gate && voices_busy() == NVOICE - 1u);

    for (mode = V_MONO; mode <= V_LEGATO; mode++) {
        fresh(); trk[0].p[P_VOICE] = V_POLY;
        for (i = 0; i < NVOICE; i++) trk_note_on(&trk[0], 48u + 2u * i, 100);
        trk[0].p[P_VOICE] = (int16_t)mode;
        shed_voice(); mix_block(out, CTL);
        check("overload can reclaim stale POLY voices after a MONO / LEGATO change",
              shed_count == 1u && V(&trk[0], 0).gate && voices_busy() == NVOICE - 1u);
    }

    fresh();
    trk[0].p[P_VOICE] = V_POLY;
    trk_note_on(&trk[0], 60, 100); trk_note_on(&trk[0], 64, 100);
    lead = held(&trk[0], 60); extra = held(&trk[0], 64);
    trk_note_off(&trk[0], 60); trk_note_off(&trk[0], 64);
    lead->env = 10000; extra->env = 10;
    shed_voice();
    check("released voices shed the quieter tail first", extra->stage == 4u && lead->stage != 4u);

    /* (v1.5.23, FASE 2) A HELD VOICE TOO: the guard used to take the oldest note it was allowed to, which is the
     * sustained body of a chord -- the loudest thing a part has -- while the note just struck and still climbing its
     * attack is a fifth as audible. The measure is v_energy (the envelope and the part's level), the same one the
     * allocator uses; the age only breaks a tie. */
    fresh();
    trk[0].p[P_VOICE] = V_POLY;
    voice_room(&trk[0], 0);                            /* a third slot, so the part has two notes it may lose */
    trk_note_on(&trk[0], 60, 100);
    trk_note_on(&trk[0], 67, 100);
    trk_note_on(&trk[0], 72, 100);
    bass = held(&trk[0], 60); lead = held(&trk[0], 67); extra = held(&trk[0], 72);
    lead->env_out = 24000; extra->env_out = 600;      /* 67 is the sustained one and loud, 72 was just struck */
    lead->age = 1u; extra->age = 2u;                  /* .. and 67 is the older: the old rule took that one */
    bass->env_out = 24000;
    shed_voice();
    check("a held note: the quietest goes, not the oldest (the bass is kept)",
          extra->stage == 4u && lead->stage != 4u && bass->stage != 4u);
    check(".. and the guard counts it once", shed_count == 1u);
    /* (v1.5.23, FASE 2) ONE ACTION PER EPISODE: a shed voice fades for six blocks, and until it does the load it costs
     * is unchanged, so a spike that lasts longer than that armed a second shed and a single episode could take three or
     * four voices. While a voice is in its stage-4 fade the guard has already acted. */
    shed_voice();
    check("a second request while the first is still fading takes nothing", shed_count == 1u);
    for (i = 0; i < 6u; i++)
        mix_block(out, CTL);
    check(".. the fade ends, and the pool is one voice smaller", !extra->active && voices_busy() == 2u);
    shed_voice();                                      /* the fade is done: a candidate is the loud held note */
    check(".. and once it is gone the guard can act again", shed_count == 2u && lead->stage == 4u);
}
static void dma(void)
{
    uint32_t i, expected;
    fresh();
    host_pending = 0;
    fm1_alnk0_irq();
    check("an auxiliary interrupt does not render a DMA half", !host_acks && !audio_halves && !felucca_dbg.in_audio);
    host_pending = FM1_AUDIO_HALF;
    host_us = 5000;
    fm1_alnk0_irq();
    check("one slow half records elapsed load, tightens the budget, does not shed yet (0.6.19: two in a row again)",
          host_acks == 1u && !shed_req && felucca_dbg.last_us == 5000u && !felucca_dbg.late && load_tight &&
          load_diag.peak >= 80u);
    fm1_alnk0_irq();
    check("a second slow half in a row requests shedding", host_acks == 2u && shed_req);
    shed_req = 0;
    host_half_reads = 0; host_dma_advanced = 1; host_us = 100;
    fm1_alnk0_irq();
    check("DMA advancing during a render is counted once", host_acks == 3u && felucca_dbg.late == 1u && !felucca_dbg.in_audio && !shed_req);
    check("(1.2.1-GW) the half is acknowledged before it renders: a flip during a late render stays pending",
          host_acks_at_start == host_acks && host_acks_at_start == 3u);
    {   /* the free half alternates: none lost; the same half twice in a row: the one between was never rendered */
        uint32_t lost0;
        audio_last_half = 2u; audio_lost = 0;
        host_dma_advanced = 0;                          /* (free half 0 each time) */
        fm1_alnk0_irq();
        lost0 = audio_lost;
        fm1_alnk0_irq();
        check("(1.2.1-GW) the same free half twice in a row counts a lost half (audio_lost)", audio_lost == lost0 + 1u);
    }
    fresh();
    expected = HALF_FRAMES * 1000000u / FS;            /* the half's deadline in us */
    host_us = expected * 90u / 100u; host_nest = expected * 30u / 100u;   /* the render 60 %, TIMER5 nested 30 % */
    fm1_alnk0_irq(); fm1_alnk0_irq();
    check("TIMER5 nested in the render counts toward the deadline", shed_req && felucca_dbg.last_us == host_us - host_nest);
    fresh();
    host_us = 5000;
    fm1_alnk0_irq(); host_us = 100; fm1_alnk0_irq(); host_us = 5000; fm1_alnk0_irq();
    check("a lone slow half between fast ones does not shed (0.6.19: a spike is not an overload)", !shed_req);
    fresh();
    host_us = 580;
    for (i = 0; i < 512u; i++) fm1_alnk0_irq();
    expected = host_us * 256u / (HALF_FRAMES * 1000000u / FS);
    check("steady CPU load converges without integer smoothing bias", song.cpu_q8 >= expected - 1u && song.cpu_q8 <= expected);
}
/* MENU > USB LEVEL (fx.c fx_usb_fixed, audio.c audio_block): MASTER (default) as before, USB = the DAC's signal and
 * follows the knob; FIXED: USB at the full level whatever MASTER is (MASTER 0: USB still plays, the DAC is silent),
 * the DAC exactly USB scaled by MASTER */
static double block_rms(const int32_t *b, uint32_t n)
{
    double s = 0;
    uint32_t i;
    for (i = 0; i < 2u * n; i++) s += (double)b[i] * b[i];
    return sqrt(s / (2.0 * n));
}
static double usb_run(uint32_t fixed, uint32_t master, int dac_is_tap_scaled_ok[1], double *dac_rms)
{
    int32_t out[2 * 32];
    uint32_t b, i;
    double usb = 0, dac = 0;
    fresh();
    lim_env = LIM_T; lev_env = 0; lev_g = lev_cur = 32768; lev_dg = 0; dc_l = dc_r = dce_l = dce_r = 0;    /* (the master's state as at power-on: runs compare) */
    trk[0].p[P_VOICE] = V_POLY;
    trk[0].p[P_DIST] = trk[0].p[P_CHOR] = trk[0].p[P_DLY] = trk[0].p[P_REV] = 0;   /* (no tails between runs) */
    trk_note_on(&trk[0], 48, 110); trk_note_on(&trk[0], 55, 110); trk_note_on(&trk[0], 64, 110);
    fx_usb_fixed = (uint8_t)fixed;
    song.master_q12 = master;
    dac_is_tap_scaled_ok[0] = 1;
    for (b = 0; b < 400u; b++) {                       /* ~0.3 s */
        audio_block(out, 32);
        for (i = 0; i < 64u; i++) {
            /* the firmware multiplies by 1 << OUT_SHIFT (audio_block); a left shift of a negative sample would
             * be undefined, so the test says what the firmware does */
            int32_t want = fixed ? ((host_tap[i] * (int32_t)master) >> 12) * (1 << OUT_SHIFT)
                                 : host_tap[i] * (1 << OUT_SHIFT);
            if (out[i] != want) dac_is_tap_scaled_ok[0] = 0;
        }
        if (b >= 100u) { usb += block_rms(host_tap, 32); dac += block_rms(out, 32) / (1 << OUT_SHIFT); }
    }
    fx_usb_fixed = 0;
    *dac_rms = dac / 300.0;
    return usb / 300.0;
}
static void usb_level(void)
{
    int ok_full, ok_quiet, ok_off, ok_fixed, ok_fixed0;
    double d_full, d_quiet, d_off, d_fixed, d_fixed0;
    double u_full = usb_run(0, 4096, &ok_full, &d_full), u_quiet = usb_run(0, 1024, &ok_quiet, &d_quiet);
    double u_off = usb_run(0, 0, &ok_off, &d_off), u_fixed = usb_run(1, 1024, &ok_fixed, &d_fixed);
    double u_fixed0 = usb_run(1, 0, &ok_fixed0, &d_fixed0);
    printf("audio: USB / DAC rms: MASTER full %.0f / %.0f, 1/4 %.0f / %.0f, 0 %.0f / %.0f; FIXED 1/4 %.0f / %.0f, 0 %.0f / %.0f\n",
           u_full, d_full, u_quiet, d_quiet, u_off, d_off, u_fixed, d_fixed, u_fixed0, d_fixed0);
    check("USB LEVEL MASTER (default): USB is the DAC's signal and follows the knob (0: silent)",
          ok_full && ok_quiet && ok_off && u_full > 1000.0 && u_quiet < u_full * 0.5 && u_off == 0.0);
    check("USB LEVEL FIXED: USB at the full level whatever MASTER is (within 0.1 dB), MASTER 0 too",
          fabs(20.0 * log10(u_fixed / u_full)) < 0.1 && fabs(20.0 * log10(u_fixed0 / u_full)) < 0.1);
    check("USB LEVEL FIXED: the DAC gets exactly USB scaled by MASTER (MASTER 0: silent, 1/4: -12 dB)",
          ok_fixed && ok_fixed0 && d_fixed0 == 0.0 && fabs(20.0 * log10(d_fixed / u_fixed) + 12.04) < 0.2);
}

/* #137: keys pressed under the splash. main.c: master_boot before audio_init (the pot's level from the first block),
 * kb_boot_hold until the splash ends (seq.c keyboard_block: the keys sound nothing; one held across stays silent until
 * pressed again); the splash polls the pot (master_poll). boot 0: as before the fix */
static void boot_fresh(void)
{
    fresh();
    audio_init();                                      /* (FASE 5) the boot's own state: not armed -- since FASE 3
                                                        * audio_init leaves the output at exact silence and main.c
                                                        * arms it when the splash ends, which is what this checks */
    lim_env = LIM_T; lev_env = 0; lev_g = lev_cur = 32768; lev_dg = 0; dc_l = dc_r = dce_l = dce_r = 0;
    memset(kb_note, 0, sizeof kb_note); kb_prev = 0; kb_layer = 0;
    trk[0].p[P_VOICE] = V_POLY;
    trk[0].p[P_DIST] = trk[0].p[P_CHOR] = trk[0].p[P_DLY] = trk[0].p[P_REV] = 0;
}
static double boot_run(int32_t pot, int boot, uint32_t *splash_peak, uint32_t *first_master, uint32_t *busy)
{
    int32_t out[2 * 32];
    uint32_t b, i, peak = 0;
    double r = 0;
    boot_fresh();
    song.master_q12 = 2048;                            /* felucca_init */
    master_knob = 512 * 16;
    host_pot = pot;
    if (boot) {
        master_boot();
        kb_boot_hold = 1;
    } else
        audio_fade_in();                               /* (FASE 5) boot 0 = before the fix: audible from the start */
    *first_master = song.master_q12;
    for (b = 0; b < 600u; b++) {                       /* the splash, ~0.43 s: keys hammered, one held at its end */
        fm1_in.notes = b >= 580u ? 1u << 12 : (b / 40u) & 1u ? (1u << 7) | (1u << 11) : 1u << 4;
        if (b % 14u == 0u && boot)
            master_poll();
        audio_block(out, 32);
        for (i = 0; i < 64u; i++)
            if ((uint32_t)abs(out[i]) > peak) peak = (uint32_t)abs(out[i]);
    }
    *splash_peak = peak;
    kb_boot_hold = 0;                                  /* the UI */
    if (boot)
        audio_fade_in();                               /* (FASE 5) main.c: the splash's end */
    *busy = 0;
    for (b = 0; b < 400u; b++) {                       /* the held key (silent), let go; then a chord pressed */
        fm1_in.notes = b < 40u ? 1u << 12 : b < 60u ? 0u : (1u << 0) | (1u << 4) | (1u << 7);
        audio_block(out, 32);
        if (b >= 60u) r += block_rms(out, 32);
        if (b == 39u) *busy = voices_busy();
    }
    fm1_in.notes = 0;
    return r / 340.0;
}
static void boot_keys(void)
{
    uint32_t peak, peak0, peak_old, m, m0, m_old, busy, busy0, busy_old, ref_m, b;
    double quiet, silent, old, ref = 0;
    int32_t out[2 * 32];
    quiet = boot_run(300, 1, &peak, &m, &busy);
    silent = boot_run(0, 1, &peak0, &m0, &busy0);
    old = boot_run(300, 0, &peak_old, &m_old, &busy_old);
    boot_fresh();                                      /* the reference: the chord, MASTER at the pot's level by hand */
    audio_fade_in();
    host_pot = 300;                                    /* (FASE 5) the same route as boot_run: master_boot, not a
                                                        * master_q12 written by hand, so the two paths can agree */
    master_boot();
    ref_m = song.master_q12;
    for (b = 0; b < 340u; b++) {
        if (b < 40u) {                                 /* (FASE 5) let the boot ramp spend itself first, in silence,
                                                        * as boot_run does before the chord: the sum then starts on
                                                        * the chord's first block in both */
            fm1_in.notes = 0;
            audio_block(out, 32);
            continue;
        }
        fm1_in.notes = (1u << 0) | (1u << 4) | (1u << 7);
        audio_block(out, 32);
        ref += block_rms(out, 32);
    }
    fm1_in.notes = 0;
    ref /= 340.0;
    printf("audio: boot, pot 300 (MASTER %u): splash peak %u, then rms %.0f (by hand %.0f); before the fix: "
           "MASTER %u, splash peak %u, then rms %.0f\n", m, peak, quiet, ref, m_old, peak_old, old);
    check("#137 boot: MASTER is the pot's level before the first block (pot 300, pot 0)",
          m == ref_m && m0 == 0u && m_old == 2048u);
    check("#137 boot: keys hammered under the splash sound nothing (before the fix: they did)",
          peak == 0u && peak0 == 0u && peak_old > 0u);
    check("#137 boot: a key held across the splash's end stays silent until pressed again",
          busy == 0u && busy0 == 0u && busy_old > 0u);
    /* (FASE 5) This used to demand quiet == ref to 1e-9, which only held while nothing armed the output: the two
     * runs have different histories before the chord (600 blocks of hammered keys and one held across in the boot
     * path, none in the by-hand one), so the envelopes cannot land on the same sample. What the check is for is the
     * LEVEL, and the boot path can be pinned against the pre-fix path, which is the same instrument with MASTER at
     * unity: quiet must be old scaled by the pot's master, and nothing at all with the pot at 0. */
    {
        double want = old * (double)ref_m / 2048.0;    /* the pre-fix path's MASTER was 2048: the scale down */
        printf("audio: boot level: pot 300 rms %.0f, before the fix (MASTER 2048) %.0f scaled to %u: %.0f; by hand %.0f\n",
               quiet, old, ref_m, want, ref);
        check("#137 boot: after the splash the keys play at the pot's level, as set by hand (pot 0: silent)",
              ref > 100.0 && ref_m == 351u && fabs(quiet - want) < want * 0.05 && silent == 0.0);
    }
}

/* (1.2.1-GW) the delay's reads stay inside its line: the longest TIME, MOD's drift at 127 at its peak, the Hermite's
 * two older taps (past the line's length the read wrapped onto the newest samples: the input in the wet) */
static void delay_edge(void)
{
    uint32_t g, b, worst = 0;
    int32_t m0, dm, mmax = 0;
    for (g = 0; g < 256u; g++) {
        song.g[G_DTIME] = (int16_t)g;
        if (delay_samples() > worst) worst = delay_samples();
    }
    /* (ETAPA 7) the guard that would have caught the above: a zeroed sine reads as no drift at all */
    check("the sine the drift rides is decoded at boot (sine_init)", osc_sine(0x40000000u) > 30000);
    song.g[G_DMOD] = 127;
    for (b = 0; b < 20000u; b++) {
        dly_wow_adv(CTL, &m0, &dm);
        if (m0 > mmax) mmax = m0;
    }
    check("(1.2.1-GW) the delay's farthest read (longest TIME, MOD 127's drift, two older taps) inside its line",
          worst + (uint32_t)((mmax + 255) >> 8) + 2u <= DLY_LEN - 1u && mmax > 1000);
    song.g[G_DMOD] = 20;
    song.g[G_DTIME] = GP[G_DTIME].def;
}
/* (v1.9) the meters read an envelope, not one 32-sample block: a held note has to keep the bar up on
 * every block of a UI frame (the frame samples the DSP once and used to catch a single near-zero block),
 * and silence has to leave it dark (HOME drew a floor of 24/96 so a quiet track looked like it played). */
static void meter_envelope(void)
{
    int32_t out[2 * CTL];
    uint32_t i, lit = 0;
    fresh();
    trk_note_on(&trk[0], 60, 100);
    for (i = 0; i < 40u; i++) {
        mix_block(out, CTL);
        if (trk[0].vu > 0)
            lit++;
    }
    check("(v1.9) a held note keeps the meter envelope up on every block", lit == 40u && trk[0].vu > 64);
    trk_note_off(&trk[0], 60);
    for (i = 0; i < 4000u; i++)
        mix_block(out, CTL);
    check("(v1.9) after the release the envelope falls to silence, so no bar stays lit", trk[0].vu == 0);
}
/* (1.9) the master's meters are two, one per DAC channel. audio.c used to keep out[2i], the left channel,
 * in the only buffer the UI could read, so the right meter had nothing of its own: a part panned right moved
 * nothing and both sides showed one value. dac_scope now stores both channels and audio_out_peak reads them
 * from the main loop, so the ISR pays one store per frame and no comparison (tests/target_budget.py). */
static void clear_scope(void)
{
    memset(scope_buf, 0, sizeof scope_buf);
    memset(scope_r, 0, sizeof scope_r);
    scope_w = 0;
}
static void feed(int32_t l, int32_t r)
{
    int32_t out[2 * CTL];
    uint32_t i;
    for (i = 0; i < CTL; i++) {
        out[2u * i] = (i & 1u) ? -l : l;
        out[2u * i + 1u] = (i & 1u) ? -r : r;
    }
    dac_scope(out, CTL);
}
static void stereo_meters(void)
{
    clear_scope();
    check("(1.9) no signal: both channel meters read silence", audio_out_peak(0) == 0 && audio_out_peak(1) == 0);
    clear_scope(); feed(8000, 8000);
    check("(1.9) mono: the two meters read the same level", audio_out_peak(0) == 8000 && audio_out_peak(1) == 8000);
    clear_scope(); feed(12000, 0);
    check("(1.9) hard left: the right meter stays dark instead of copying the left",
          audio_out_peak(0) == 12000 && audio_out_peak(1) == 0);
    clear_scope(); feed(0, 9000);
    check("(1.9) hard right: the right meter moves (it used to stay dark)",
          audio_out_peak(0) == 0 && audio_out_peak(1) == 9000);
    clear_scope(); feed(3000, 9000);
    check("(1.9) an unbalanced mix reads two different values, not one twice",
          audio_out_peak(0) == 3000 && audio_out_peak(1) == 9000);
    clear_scope(); feed(6000, 6000);
    {
        int32_t a0 = audio_out_peak(0), a1 = audio_out_peak(1);
        clear_scope(); feed(3000, 3000);
        check("(1.9) a level change moves both meters and leaves no stale peak",
              a0 == 6000 && a1 == 6000 && audio_out_peak(0) == 3000 && audio_out_peak(1) == 3000);
    }
    clear_scope(); feed(12000, 12000);               /* PAN hard left .. hard right in two frames */
    {
        int32_t l0 = audio_out_peak(0), r0 = audio_out_peak(1);
        clear_scope(); feed(0, 12000);
        check("(1.9) a pan to the right takes the left meter down and the right one up",
              l0 == 12000 && r0 == 12000 && audio_out_peak(0) == 0 && audio_out_peak(1) == 12000);
    }
    clear_scope();
}
/* (1.9) the ring wraps and the window is the newest 256 frames. A loud passage that has scrolled out of it must
 * not still own the meter, and a block written after it must: this is the index arithmetic the ISR and the screen
 * share, tested where it can be seen rather than only in the field. */
static void scope_window(void)
{
    int32_t out[2 * CTL];
    uint32_t blk, i;
    clear_scope();
    for (blk = 0; blk < 40u; blk++) {                 /* 40 blocks x 16 frames = 640: the 256-frame ring wraps */
        int32_t l = blk < 20u ? 20000 : 1000;         /* the loud part is 320 frames back: out of the window */
        int32_t r = blk < 20u ? 1000 : 20000;
        for (i = 0; i < CTL; i++) { out[2u * i] = l; out[2u * i + 1u] = r; }
        dac_scope(out, CTL);
    }
    check("(1.9) the scope's window is the newest frames: a passage that scrolled out owns neither meter",
          audio_out_peak(0) == 1000 && audio_out_peak(1) == 20000);
    clear_scope();
    feed(1, 1);                                        /* one block only: the window is mostly the cleared ring */
    check("(1.9) after a wrap and a clear the meters start from the new block, not from the old one",
          audio_out_peak(0) == 1 && audio_out_peak(1) == 1);
    clear_scope();
}
int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    /* (ETAPA 7) the boot state first: since ETAPA 2 the sine is decoded into .bss by sine_init (voices_boot), not a
     * table in flash, so a harness that starts from zeroed memory has no oscillator at all -- delay_edge's MOD
     * sweep was reading a silent sine (mmax 0) and failing, and the rest of the file would have run on a dead
     * instrument. fresh() is the boot: defaults, the pool's windows, the tables. */
    fresh();
    delay_edge();
    meter_envelope();
    stereo_meters();
    scope_window();
    usb_level();
    boot_keys();
    overload(); dma();
    printf(bad ? "audio: %d FAILED\n" : "audio: all passed\n", bad);
    return bad != 0;
}
