/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Host test of the Felucca update loader (firmware/loader/ldr_core.c): a fake
 * host serves a package over the SysEx protocol, the "device" flash starts as
 * another package's flash.bin (as if that firmware were installed).
 *   ldr_test OLD.fwsc NEW.fwsc */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FELUCCA_ID "ota-FM-1_965"
#define FELUCCA_OTA_DRYRUN 0

static uint8_t nor[0x100000], *logical;
static size_t logical_len;
static uint8_t rx[1024];
static uint32_t rx_len, rx_full, now_ms, requests, erases, bad_range, record_cleared, f0_asked;
static uint32_t flip_addr = 0xFFFFFFFFu, flip_seen, flip_on;   /* serve addr's flip_on-th reply with a byte changed */
static uint32_t bad_finish;                     /* serve a wrong 0xF0000000 acknowledgement */
static long prog_budget = -1;                  /* power loss after this many programmed bytes; -1 = none */
static uint32_t power_cuts;                     /* simulated power losses during ldr_prog() */
static long erase_fail_at = -1, prog_fail_at = -1, read_fail_at = -1;   /* fault injection */
static uint32_t erase_ops, prog_ops, read_ops;
static uint32_t prog_done;                      /* bytes programmed by the last session (the cut points below) */

static uint32_t pack7(const uint8_t *in, uint32_t n, uint8_t *out)
{
    uint32_t acc = 0, nb = 0, o = 0;
    while (n--) {
        acc |= (uint32_t)*in++ << nb;
        nb += 8;
        while (nb >= 7) { out[o++] = acc & 0x7F; acc >>= 7; nb -= 7; }
    }
    if (nb) out[o++] = acc & 0x7F;
    return o;
}
static uint32_t unpack7h(const uint8_t *in, uint32_t n, uint8_t *out)
{
    uint32_t acc = 0, nb = 0, o = 0;
    while (n--) {
        acc |= (uint32_t)*in++ << nb;
        nb += 7;
        if (nb >= 8) { out[o++] = (uint8_t)acc; acc >>= 8; nb -= 8; }
    }
    return o;
}

static int ota_wire_send(const uint8_t *p, uint32_t n)
{
    uint8_t u[64], m[600];
    uint32_t addr, len, i, s = 0;
    unpack7h(p + 1, n - 2, u);
    if (u[2] == 0x11) return 0;
    addr = u[7] | u[8] << 8 | u[9] << 16 | (uint32_t)u[10] << 24;
    len = u[11] | u[12] << 8 | u[13] << 16;
    requests++;
    memcpy(m, "\x00\x59\x30", 3);
    m[3] = (uint8_t)(len + 8); m[4] = (uint8_t)((len + 8) >> 8); m[5] = 0; m[6] = 0;
    memcpy(m + 7, &addr, 4);
    m[11] = (uint8_t)len; m[12] = (uint8_t)(len >> 8); m[13] = 0;
    if (addr >= 0xE0000000u) {
        f0_asked += addr == 0xF0000000u;
        memset(m + 14, 0, len);
        memcpy(m + 14, bad_finish ? "succesx" : "success", 8);
    } else {
        if (addr + len > logical_len) { printf("read past the package %#x\n", addr); exit(1); }
        memcpy(m + 14, logical + addr, len);
        if (addr == flip_addr && ++flip_seen == flip_on)
            m[14 + len / 2u] ^= 0x10;                /* a transfer error the frame checksum does not see */
    }
    for (i = 6; i < 14 + len; i++) s += m[i];
    m[14 + len] = (uint8_t)~s;
    rx_len = pack7(m, 15 + len, rx);
    rx_full = 1;
    return 0;
}
static int ota_frame_get(const uint8_t **p, uint32_t *n) { if (!rx_full) return 0; *p = rx; *n = rx_len; return 1; }
static void ota_frame_done(void) { rx_full = 0; }
static uint32_t ota_now_ms(void) { return now_ms; }
static void ota_idle(void) { now_ms++; }
static int ota_erase(uint32_t off) { (void)off; return -1; }
static int ota_prog(uint32_t off, const void *p, uint32_t n) { (void)off; (void)p; (void)n; return -1; }
static int ota_fread(uint32_t off, void *p, uint32_t n) { memcpy(p, nor + off, n); return 0; }
static void ota_show(uint32_t step, int32_t code) { (void)step; (void)code; }
static void ota_commit(const uint8_t *parm) { (void)parm; }
#include "../firmware/src/ota.c"

static int ldr_fread(uint32_t off, void *p, uint32_t n)
{
    if (read_fail_at >= 0 && (long)read_ops++ == read_fail_at) return -1;
    memcpy(p, nor + off, n);
    return 0;
}
static int ldr_erase(uint32_t off)
{
    if (off < 0x4000u || off >= 0xE5000u || (off & 0xFFFu) || (off >= 0x93000u && off < 0xE0000u))
        bad_range++;
    if (off == 0xE8000u) { printf("ERASE IN THE VM BACKUP %#x\n", off); exit(1); }
    if (off < 0x4000u) { printf("ERASE IN THE HEAD %#x\n", off); exit(1); }
    if (erase_fail_at >= 0 && (long)erase_ops++ == erase_fail_at) return -1;
    erases++;
    memset(nor + off, 0xFF, 0x1000);
    return 0;
}
static int ldr_prog(uint32_t off, const void *p, uint32_t n)
{
    const uint8_t *s = p;
    uint32_t i, limit = n;
    if (prog_fail_at >= 0 && (long)prog_ops++ == prog_fail_at) return -1;
    if ((off < 0x4000u || off + n > 0x93000u) &&
        !(off >= 0xE8F00u && off + n <= 0xE8F50u)) bad_range++;
    if (((off & 0xFFu) + n) > 256u) bad_range++;
    if (prog_budget >= 0) {
        if (prog_budget <= 0) { prog_budget = -1; power_cuts++; return -1; }
        if ((long)n > prog_budget) limit = (uint32_t)prog_budget;
    }
    for (i = 0; i < limit; i++) nor[off + i] &= s[i];
    if (limit != n) { prog_budget = -1; power_cuts++; return -1; }
    if (prog_budget >= 0) prog_budget -= n;
    if (off < 0x93000u) prog_done += n;          /* the app area only: the record cleanup after the commit is not a cut point */
    return 0;
}
static void ldr_record_clear(void) { record_cleared++; }
static int flash_unknown;                      /* the chip is not one the firmware writes */
static int ldr_flash_known(void) { return !flash_unknown; }
static void ldr_progress(uint32_t done, uint32_t total) { (void)done; (void)total; }
#include "../firmware/loader/ldr_core.c"

static void put_record(uint32_t off)                 /* the step-1 record, valid */
{
    uint8_t r[112] = {0};
    r[2] = 0x0D; r[3] = 0x5A; r[4] = 0x01; r[5] = 0x5A; r[6] = 0x41; r[7] = 0x54;
    ota_wr16(r, ota_crc16(r + 2, 78, 0));
    memcpy(nor + off, r, sizeof r);
}

static uint8_t *load_logical(const char *path, size_t *len)
{
    FILE *f = fopen(path, "rb");
    uint8_t *raw = malloc(0x200000), *lg;
    size_t n, i;
    if (!f) { perror(path); exit(2); }
    n = fread(raw, 1, 0x200000, f);
    fclose(f);
    if (n < 20 * 48 + 0x400) { printf("%s: too short for a package\n", path); exit(2); }
    lg = malloc(n);
    for (i = 0; i < 20; i++) memcpy(lg + i * 47, raw + i * 48, 47);
    memcpy(lg + 20 * 47, raw + 20 * 48, n - 20 * 48);
    *len = n - 20;
    free(raw);
    return lg;
}

static uint32_t flash_off(const uint8_t *lg)        /* flash.bin offset in the logical image */
{
    uint8_t h[0x400];
    uint32_t i, n;
    memcpy(h, lg, sizeof h);
    ota_jl_enc(h, 0x40);
    n = ota_rd16(h + 8);
    for (i = 0; i < n; i++) {
        uint8_t *e = h + 0x40 + i * 0x50u;
        ota_jl_enc(e, 0x50);
        if (ota_rd16(e) == 0) return ota_rd32(e + 8);
    }
    return 0;
}

static int check(const char *what, int ok) { printf("%-56s %s\n", what, ok ? "ok" : "FAIL"); return ok ? 0 : 1; }

int main(int argc, char **argv)
{
    size_t olen;
    static uint8_t user[0x1000], vm[0x1000], auto_s[0x1000], usr[0x1000];
    uint8_t *old, head[0x4000];
    uint32_t ofo, nfo, i;
    int bad = 0, rc;
    if (argc < 3) { printf("usage: ldr_test OLD.fwsc NEW.fwsc\n"); return 2; }
    old = load_logical(argv[1], &olen);
    logical = load_logical(argv[2], &logical_len);
    ofo = flash_off(old);
    nfo = flash_off(logical);
    /* device: OLD installed, plus a valid update record at 0xE4F00 (Felucca's step 1) and 0xE8F00 (the stock
     * firmware's, a first install from it); user sample data in Felucca's store that looks like a record */
    memset(nor, 0xFF, sizeof nor);
    memcpy(nor, old + ofo, 0x93000);
    memcpy(head, nor, sizeof head);
    {
        put_record(0xE4F00);
        put_record(0xE8F00);
        for (i = 0; i < 0x1000u; i++) nor[0xA0000 + i] = (uint8_t)(i * 7u);
        put_record(0xA0F00);
        memcpy(user, nor + 0xA0000, sizeof user);
        /* record-looking tails in the VM, the autosave/FM6 bank and USR must survive */
        for (i = 0; i < 0x1000u; i++) {
            nor[0x93000 + i] = (uint8_t)(i * 3u);
            nor[0xE5000 + i] = (uint8_t)(i * 5u);
            nor[0xEB000 + i] = (uint8_t)(i * 11u);
        }
        nor[0xE8F80] = 0x5A;                         /* VM backup data beside the stock record */
        put_record(0x93F00); put_record(0xE5F00); put_record(0xEBF00);
        memcpy(vm, nor + 0x93000, sizeof vm);
        memcpy(auto_s, nor + 0xE5000, sizeof auto_s);
        memcpy(usr, nor + 0xEB000, sizeof usr);
    }
    /* a damaged package (one byte deep in the app area): refused before anything is erased */
    {
        size_t at = nfo + 0x50123u;
        logical[at] ^= 0x01;
        erases = 0;
        rc = ldr_session();
        bad += check("damaged package (flash.bin CRC) refused, nothing erased", rc == -12 && erases == 0 &&
                     !memcmp(nor + 0x4000, old + ofo + 0x4000, 0x93000 - 0x4000) && nor[0xE4F06] == 0x41);
        logical[at] ^= 0x01;
        requests = 0;
    }
    /* an unknown flash chip: nothing is written, not even the update records */
    {
        flash_unknown = 1;
        erases = 0;
        record_cleared = 0;
        rc = ldr_session();
        bad += check("unknown flash chip refused, no erase, no program, records untouched", rc == -15 &&
                     !memcmp(nor + 0x4000, old + ofo + 0x4000, 0x93000 - 0x4000) && !record_cleared &&
                     erases == 0 && nor[0xE4F06] == 0x41 && nor[0xE8F06] == 0x41);
        flash_unknown = 0;
        record_cleared = 0;
        requests = 0;
    }
    /* a sector that comes in different the second time (a transfer error after the check) is read again */
    flip_addr = nfo + 0x20000u; flip_on = 2; flip_seen = 0;
    rc = ldr_session();
    printf("  rc %d, %u requests, %u sector erases\n", rc, requests, erases);
    bad += check("install completes", rc == 0);
    bad += check("a sector changed in transfer after the check is read again", flip_seen == 3);
    flip_addr = 0xFFFFFFFFu;
    bad += check("app area == the new package's flash.bin", !memcmp(nor + 0x4000, logical + nfo + 0x4000, 0x93000 - 0x4000));
    bad += check("flash head [0, 0x4000) untouched", !memcmp(nor, head, sizeof head));
    bad += check("finish asked (0xF0000000)", f0_asked >= 1);
    bad += check("update records cleared (RAM + flash 0xE4F00, the stock firmware's 0xE8F00)",
                 record_cleared && nor[0xE4F06] == 0xFF && nor[0xE8F06] == 0x00);
    bad += check("the stock record's VM sector is invalidated in place, not erased", nor[0xE8F80] == 0x5A);
    bad += check("user data in Felucca's store that looks like a record is kept", !memcmp(nor + 0xA0000, user, sizeof user));
    bad += check("VM sector with a record-looking block is kept", !memcmp(nor + 0x93000, vm, sizeof vm));
    bad += check("autosave/FM6 sector with a record-looking block is kept", !memcmp(nor + 0xE5000, auto_s, sizeof auto_s));
    bad += check("USR sector with a record-looking block is kept", !memcmp(nor + 0xEB000, usr, sizeof usr));
    bad += check("no write outside the allowed windows", bad_range == 0);
    /* same package again: nothing to erase */
    erases = 0; requests = 0;
    rc = ldr_session();
    bad += check("re-run with the same package erases nothing", rc == 0 && erases == 0);
    /* a package for another chip key is refused before any erase */
    {
        uint8_t save = logical[nfo + 0x4000 + 5];
        logical[nfo + 0x4000 + 5] ^= 0x5A;           /* app area head no longer decrypts */
        memcpy(nor, old + ofo, 0x93000);
        erases = 0;
        rc = ldr_session();
        bad += check("foreign key / damaged app head refused, nothing erased", rc == -6 && erases == 0);
        logical[nfo + 0x4000 + 5] = save;
    }
    /* a missing or wrong final ACK must not clear the update record or commit */
    {
        memcpy(nor, old + ofo, 0x93000);
        memcpy(nor, head, sizeof head);
        put_record(0xE4F00); put_record(0xE8F00);
        bad_finish = 1; record_cleared = 0; f0_asked = 0; erases = 0; bad_range = 0;
        rc = ldr_session();
        bad += check("wrong final ACK: no commit and the record is kept",
                     rc == -14 && !record_cleared && nor[0xE4F06] == 0x41);
        bad_finish = 0;
        rc = ldr_session();
        bad += check("correct ACK after a wrong one: commits and clears the record",
                     rc == 0 && record_cleared && nor[0xE4F06] == 0xFF &&
                     !memcmp(nor, head, sizeof head) && !bad_range);
    }
    /* power loss during the write: the record survives, the next session resumes and finishes.
     * The cut points are derived from what this package's install actually programs: a fixed list
     * stopped cutting (0x80000 B) the moment the old app and the new build shared enough sectors
     * that fewer bytes were written -- the first session then completed and the check failed on
     * its own assumption, not on the loader. A cut at `total - 1` is still inside the last write. */
    {
        uint32_t cuts[5], cand[5], total, ncut = 0, ci;
        memcpy(nor, old + ofo, 0x93000);
        memcpy(nor, head, sizeof head);
        put_record(0xE4F00); put_record(0xE8F00);
        prog_budget = -1; prog_done = 0; power_cuts = 0; record_cleared = 0; erases = 0; bad_range = 0;
        rc = ldr_session();
        total = prog_done;
        bad += check("baseline install: the app area actually gets programmed", rc == 0 && total > 0x1000u);
        cand[0] = 0; cand[1] = total / 16u; cand[2] = total / 4u; cand[3] = total / 2u; cand[4] = total - 1u;
        for (ci = 0; ci < 5u; ci++)
            if (ci == 0u || cand[ci] != cand[ci - 1u])
                cuts[ncut++] = cand[ci];
        for (ci = 0; ci < ncut; ci++) {
            memcpy(nor, old + ofo, 0x93000);
            memcpy(nor, head, sizeof head);
            put_record(0xE4F00); put_record(0xE8F00);
            prog_budget = (long)cuts[ci]; power_cuts = 0; record_cleared = 0; erases = 0; bad_range = 0; f0_asked = 0;
            rc = ldr_session();
            if (rc == 0 && power_cuts == 0) {          /* this install programs less than the budget */
                printf("  cut %#x: the write ends before it, skipped\n", cuts[ci]);
                prog_budget = -1;
                continue;
            }
            if (rc == 0 || power_cuts != 1 || record_cleared || nor[0xE4F06] != 0x41) {
                printf("  cut %#x: rc %d, cuts %u, record_cleared %u\n", cuts[ci], rc, power_cuts, record_cleared);
                bad++;
            }
            prog_budget = -1;
            rc = ldr_session();
            if (rc || !record_cleared || memcmp(nor + 0x4000, logical + nfo + 0x4000, 0x93000 - 0x4000) ||
                memcmp(nor, head, sizeof head) || memcmp(nor + 0xA0000, user, sizeof user) || bad_range)
                printf("  resume %#x: rc %d, cleared %u, app %d, head %d, user %d, bad %u\n", cuts[ci], rc,
                       record_cleared, !memcmp(nor + 0x4000, logical + nfo + 0x4000, 0x93000 - 0x4000),
                       !memcmp(nor, head, sizeof head), !memcmp(nor + 0xA0000, user, sizeof user), bad_range);
            bad += check("power cut resumes and completes", rc == 0 && record_cleared &&
                         !memcmp(nor + 0x4000, logical + nfo + 0x4000, 0x93000 - 0x4000) &&
                         !memcmp(nor, head, sizeof head) && !memcmp(nor + 0xA0000, user, sizeof user) && bad_range == 0);
        }
    }
    /* power loss at every program page the loader actually writes: the number of pages comes from an
     * uncut reference run, so every step below is a real cut (the loader skips sectors already equal) */
    {
        uint32_t total = 0, cut, done = 0, fails = 0, ref_eras, reached_commit = 0;
        memcpy(nor, old + ofo, 0x93000);
        memcpy(nor, head, sizeof head);
        put_record(0xE4F00); put_record(0xE8F00);
        erases = 0; prog_budget = -1; bad_range = 0; record_cleared = 0;
        rc = ldr_session();
        ref_eras = erases;
        if (rc == 0)
            total = ref_eras * 0x1000u;
        printf("  reference write: rc %d, %u sector erases, %u B to program\n", rc, ref_eras, total);
        if (!total) bad++;
        for (cut = 0; cut < total; cut += 256u) {
            memcpy(nor, old + ofo, 0x93000);
            memcpy(nor, head, sizeof head);
            put_record(0xE4F00); put_record(0xE8F00);
            prog_budget = (long)cut; power_cuts = 0; record_cleared = 0; f0_asked = 0; bad_range = 0;
            rc = ldr_session();
            if (rc == 0 && power_cuts == 0) break;          /* the write ended before this page */
            if (rc == 0 && record_cleared) {               /* the cut fell after the commit, in cleanup */
                printf("  cut %#x: after the commit (cleanup), matrix ends\n", cut);
                reached_commit = 1;
                break;
            }
            if (power_cuts != 1 || record_cleared) {
                fails++;
                printf("  cut %#x: rc %d, cuts %u, record cleared %u\n", cut, rc, power_cuts, record_cleared);
                continue;
            }
            prog_budget = -1;
            rc = ldr_session();
            if (rc || !record_cleared ||
                memcmp(nor + 0x4000, logical + nfo + 0x4000, 0x93000 - 0x4000) ||
                memcmp(nor, head, sizeof head) || memcmp(nor + 0xA0000, user, sizeof user) || bad_range) {
                fails++;
                printf("  resume after %#x: rc %d, cleared %u, bad range %u\n", cut, rc, record_cleared, bad_range);
            }
            done++;
        }
        printf("  page cuts: %u cut states, %u failures\n", done, fails);
        bad += check("a power cut at every programmed page resumes and completes exactly",
                     fails == 0 && done >= 8 && reached_commit);
    }
    /* injected flash faults: an erase error and a program error abort without committing, and a read
     * error before the first erase leaves the device exactly as it was */
    {
        int f_bad = 0;
        for (i = 0; i < 2; i++) {
            memcpy(nor, old + ofo, 0x93000);
            memcpy(nor, head, sizeof head);
            put_record(0xE4F00); put_record(0xE8F00);
            record_cleared = 0; erase_ops = prog_ops = read_ops = 0;
            erase_fail_at = i == 0 ? 0 : -1;
            prog_fail_at = i == 1 ? 0 : -1;
            rc = ldr_session();
            erase_fail_at = prog_fail_at = -1;
            if (rc >= 0 || record_cleared || nor[0xE4F06] != 0x41) {
                printf("  fault %d: rc %d, cleared %u\n", i, rc, record_cleared);
                f_bad++;
            }
        }
        bad += check("an erase error and a program error abort without committing", f_bad == 0);

        memcpy(nor, old + ofo, 0x93000);
        memcpy(nor, head, sizeof head);
        put_record(0xE4F00); put_record(0xE8F00);
        record_cleared = 0; read_ops = 0; erases = 0; read_fail_at = 0;
        rc = ldr_session();
        read_fail_at = -1;
        bad += check("a flash read error before any erase aborts and erases nothing",
                     rc < 0 && erases == 0 && !record_cleared && nor[0xE4F06] == 0x41);
    }
    /* a retry with another package (the previous one) rewrites the app area and commits */
    {
        uint8_t *keep = logical;
        size_t keep_len = logical_len;
        memcpy(nor, logical + nfo, 0x93000);
        memcpy(nor, head, sizeof head);
        put_record(0xE4F00);
        logical = old; logical_len = olen; nfo = ofo;
        record_cleared = 0; erases = 0; bad_range = 0;
        rc = ldr_session();
        bad += check("a retry with the previous package rewrites the app area and commits",
                     rc == 0 && record_cleared && !bad_range &&
                     !memcmp(nor + 0x4000, old + ofo + 0x4000, 0x93000 - 0x4000));
        logical = keep; logical_len = keep_len; nfo = flash_off(logical);
    }
    free(old);
    free(logical);
    printf("%s\n", bad ? "LOADER TEST FAILED" : "loader test passed");
    return bad != 0;
}
