/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Renders of the firmware UI (firmware/src/ui*.c on tests/ui_test.c's stubs), the layout lint, the GREY and MONO
 * checks and the host draw cost.
 *   ui_render OUTDIR [SLOTDIR]   (run by tests/run_tests.sh; tests/ui_render.py makes the PNGs;
 *                                 SLOTDIR: filmstrips of the rolling digits, GREY MONO and GREEN)
 * Layout lint, over every screen below in every palette, every page of every engine and every value of every
 * column: the ink box of every text and icon drawn (gfx.c GFX_HOOK_TEXT) as it lands on the screen. A finding:
 * a box off the screen, cut by its canvas, partly covered by a later strip or fill, overlapping another box, or
 * ellipsised when it is not free text (labels and values must fit; names and messages may be ellipsised), or
 * spilling out of its cell: touching a rounded rectangle of its canvas (gfx.c cv_rrect: a cell, card, row, button,
 * GFX_HOOK_CELL) without lying inside it, though still on the screen (the FX map's REVERSE), or drawn in the
 * colour it is drawn on (gfx.c GFX_HOOK_INK: a text, icon or keycap label that cannot be seen; MONO's tokens share
 * values, DIM and RAISE its one grey).
 * GREY: every pixel of every screen is RGB565 gray (R = B, G = 2 R). MONO (black and white, blended per channel):
 * every pixel is neutral (R = B, G within 2 of 2 R).
 * MENU > STYLE LINE: every screen again in every palette, the same lint; a text or icon on a divider
 * (ui_draw.c lcd_rule, GFX_HOOK_RULE: the rules between the strips; cv_rule's are cells) is a finding too.
 * Rolling digits: every frame of a header BPM roll and a card roll, up and down, in every palette (lint, GREY, MONO).
 * FM6 charts (ui_graph.c graph_fm6, its parts through FM6_CHART_HOOK), every algorithm and every chart drawn: no two
 * operator boxes overlapping or touching, no route, loop, bus or label inside a box or touching one it does not
 * connect, no two nets (one gap's routes that share an operator, the output, the loop, the label) sharing or
 * touching a pixel, everything inside the panel.
 * Output: OUTDIR/ppm/<PALETTE>_<screen>.ppm for GREY MONO GREEN PAPER NIGHT, OUTDIR/report.txt (findings, ellipsised
 * free text, the draw cost), OUTDIR/text_audit.tsv (GREY, per screen: texts, icons and keycaps with their ink-box px,
 * the ellipsised ones, the texts closer than 2 px to their cell's edge, the words).
 * Alignment (gfx.c GFX_HOOK_ALIGN): every place where a text, icon or keycap is meant to sit centred (in a cell, a
 * chip, a button, a row, a column, a knob, a strip) or on a line shared with its neighbours (an icon on its label's
 * line, a word on its keycap's, a unit on its value's baseline) declares its box; the ink drawn there (a text: its
 * glyphs' boxes across, its capitals' band up and down; an icon: its cell's nibbles; a keycap: its pill; also the
 * keycaps' labels in their pills, from the data, and rows of keys or bars against their panel) is measured against
 * it, on every screen above in FLAT and LINE and every palette, the page / value sweep, and align_sweeps (every value
 * each place can show). 0.5 px is the odd pixel left over (it goes left / up); 1 px or more is a finding.
 * OUTDIR/align.txt: per place, how often measured, the worst offsets and where.
 * Exit 1 on a finding, a GREY pixel off gray, a MONO one off neutral, or an alignment 1 px or more off. */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <math.h>

typedef struct { int16_t x0, y0, x1, y1; uint8_t flags; char s[28]; } rbox_t;
static rbox_t pend[256], scr[1200];
static int16_t cells[64][4];                    /* GFX_HOOK_CELL: the cells and cards of the canvas being drawn */
static uint32_t ncells, nspill;
static FILE *aud;                               /* OUTDIR/text_audit.tsv: GREY, the text of each screen */
static char tight[400];                         /* .. the texts of this screen closer than 2 px to their cell's edge */
static uint32_t ntight;
static uint32_t npend, nscr, nfind, nfree;
static uint64_t px_visited, n_text, blit_px;
static FILE *rep;
static const char *cur_name = "";
static char free_seen[64][40];
static uint32_t nfree_seen;
/* the alignment check (gfx.c GFX_HOOK_ALIGN): a place declares the box its next item(s) are meant to be centred in,
 * across and / or up and down; the items' ink as drawn (a text: its glyphs' boxes across, its capitals' band up and
 * down, a text of no letter or figure: across only; an icon: the ink of its cell; a keycap: its pill; a cushion: the
 * cushion) against the box: the offset of the ink's centre from the box's, in half pixels. 0.5 is the odd pixel
 * left over (it goes left / up: a +0.5 is counted apart); 1 px or more is a finding. Per place (its tag): how
 * often it was measured, the worst offsets and where, in OUTDIR/align.txt */
typedef struct { int32_t x0, y0, x1, y1, ix0, iy0, ix1, iy1; uint32_t mode, left, nv; const char *tag; char s[24]; } al_t;
typedef struct { const char *tag; uint32_t n, nfail, half_lo, half_hi; int32_t wh2, wv2; char ex_h[112], ex_v[112]; } alstat_t;
static al_t al_stk[8];
static uint32_t al_n, al_fail, al_lost, al_count, al_off;
static int32_t al_cy0, al_cy1;                  /* GFX_HOOK_PEN: the capitals' band of the text being hooked */
static alstat_t al_st[160];
static uint32_t al_nst;
static FILE *al_rep;
static alstat_t *al_stat(const char *tag)
{
    uint32_t i;
    for (i = 0; i < al_nst && strcmp(al_st[i].tag, tag); i++) ;
    if (i == al_nst && al_nst < 160u) { memset(&al_st[i], 0, sizeof al_st[i]); al_st[i].tag = tag; al_nst++; }
    return &al_st[i < 160u ? i : 159u];
}
/* one measurement: offsets in half pixels (h2, v2; 99: not measured) */
static void al_record(const char *tag, int32_t h2, int32_t v2, const char *s, int32_t bx0, int32_t by0, int32_t bx1,
                      int32_t by1, int32_t ix0, int32_t iy0, int32_t ix1, int32_t iy1)
{
    alstat_t *a = al_stat(tag);
    int32_t ah = h2 == 99 ? 0 : h2 < 0 ? -h2 : h2, av = v2 == 99 ? 0 : v2 < 0 ? -v2 : v2;
    a->n++;
    al_count++;
    if (h2 == 1 || v2 == 1) a->half_hi++;
    if (h2 == -1 || v2 == -1) a->half_lo++;
    if (ah > a->wh2 || (!a->ex_h[0] && h2 != 99)) {
        if (ah > a->wh2) a->wh2 = ah;
        snprintf(a->ex_h, sizeof a->ex_h, "%+.1f '%s' %s ink x %d..%d box %d..%d", h2 / 2.0, s, cur_name, ix0, ix1, bx0, bx1);
    }
    if (av > a->wv2 || (!a->ex_v[0] && v2 != 99)) {
        if (av > a->wv2) a->wv2 = av;
        snprintf(a->ex_v, sizeof a->ex_v, "%+.1f '%s' %s ink y %d..%d box %d..%d", v2 / 2.0, s, cur_name, iy0, iy1, by0, by1);
    }
    if (ah >= 2 || av >= 2) {
        a->nfail++;
        al_fail++;
        if (al_rep && a->nfail <= 3u)
            fprintf(al_rep, "OFF  %-28s %-26s '%s' across %+.1f, up/down %+.1f  (ink %d,%d-%d,%d box %d,%d-%d,%d)\n", tag, cur_name,
                    s, h2 == 99 ? 0.0 : h2 / 2.0, v2 == 99 ? 0.0 : v2 / 2.0, ix0, iy0, ix1, iy1, bx0, by0, bx1, by1);
    }
}
static void hk_align(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint32_t mode, const char *tag)
{
    al_t *a;
    if (al_off) return;                         /* (the draw cost: timed without the check)  */
    if (al_n >= 8u) { al_lost++; return; }
    a = &al_stk[al_n++];
    memset(a, 0, sizeof *a);
    a->x0 = x0; a->y0 = y0; a->x1 = x1; a->y1 = y1; a->mode = mode; a->tag = tag;
    a->left = mode >> 8 ? mode >> 8 : 1u;
    a->ix0 = a->iy0 = 1 << 20; a->ix1 = a->iy1 = -(1 << 20);
}
/* an item drawn (cell: a cv_rrect, else ink): its extent across (x0..x1), up and down (y0..y1; vy 0: none), to the
 * place declared last (AL_PASS, its item done: to the one before it too) */
static void al_item_k(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int vy, const char *s, int cell)
{
    al_t *a;
    int32_t h2 = 99, v2 = 99;
    uint32_t pass;
    if (!al_n) return;
    a = &al_stk[al_n - 1u];
    if (!(a->mode & 32u) != !cell) return;          /* (AL_CELLS: its cells only; else ink only) */
    if (x0 < a->ix0) a->ix0 = x0;
    if (x1 > a->ix1) a->ix1 = x1;
    if (vy) {
        if (y0 < a->iy0) a->iy0 = y0;
        if (y1 > a->iy1) a->iy1 = y1;
        a->nv++;
    }
    if (!a->s[0] || strlen(a->s) + strlen(s) + 2u < sizeof a->s)
        snprintf(a->s + strlen(a->s), sizeof a->s - strlen(a->s), "%s%s", a->s[0] ? "+" : "", s);
    if (--a->left) return;
    al_n--;
    pass = a->mode & 16u;
    if (a->mode & 1u) h2 = (a->ix0 + a->ix1) - (a->x0 + a->x1);       /* AL_H: the centres */
    if (a->mode & 8u) h2 = 2 * (a->ix1 - a->x1);                      /* AL_R: the right edges */
    if (a->nv && (a->mode & 2u)) v2 = (a->iy0 + a->iy1) - (a->y0 + a->y1);
    if (a->nv && (a->mode & 4u)) v2 = 2 * (a->iy1 - a->y1);           /* AL_B: the baselines (capitals' bottoms) */
    al_record(a->tag, h2, v2, a->s, a->x0, a->y0, a->x1, a->y1, a->ix0, a->iy0, a->ix1, a->iy1);
    if (pass) al_item_k(x0, y0, x1, y1, vy, s, cell);
}
static void al_item(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int vy, const char *s) { al_item_k(x0, y0, x1, y1, vy, s, 0); }
static int al_alnum(const char *s)
{
    for (; *s; s++)
        if ((*s >= 'A' && *s <= 'Z') || (*s >= 'a' && *s <= 'z') || (*s >= '0' && *s <= '9')) return 1;
    return 0;
}
static void al_text(int32_t x0, int32_t y0, int32_t x1, int32_t y1, const char *s, uint32_t flags)
{
    if (!al_n || ((flags & 4u) && !strcmp(s, "icon"))) return;      /* (an icon: GFX_HOOK_ICON) */
    if (flags & 4u) al_item(x0, y0, x1, y1, 1, s);                    /* a keycap: its pill */
    else al_item(x0, al_cy0, x1, al_cy1, al_alnum(s), s);
}
static void al_flush(void)                      /* a canvas blitted or begun: declared places left without their items */
{
    uint32_t i;
    for (i = 0; i < al_n; i++)
        if (al_rep && al_lost + i < 12u) fprintf(al_rep, "LOST %-28s %s (declared, nothing drawn after it)\n", al_stk[i].tag, cur_name);
    al_lost += al_n;
    al_n = 0;
}
static int32_t icon_cell(uint32_t *size, uint32_t id);
static void hk_icon(int32_t x, int32_t y, uint32_t size, uint32_t id);   /* (after the icons: their cells' nibbles) */
#define GFX_HOOK_ALIGN(x0, y0, x1, y1, mode, tag) hk_align(x0, (y0) + cv_oy, x1, (y1) + cv_oy, mode, tag)
#define GFX_HOOK_PEN(y, f) (al_n ? (al_cy0 = (y) + cv_oy + (f)->g[glyph((f), 'H')].by, al_cy1 = al_cy0 + (f)->g[glyph((f), 'H')].bh) : 0)
#define GFX_HOOK_ITEM(x0, y0, x1, y1) al_item(x0, (y0) + cv_oy, x1, (y1) + cv_oy, 1, "cushion")
#define GFX_HOOK_ICON(x, y, size, id) hk_icon(x, (y) + cv_oy, size, id)
static char splash_seen[96];                    /* the splash scene: its texts as drawn, '|' between (draw) */
static uint8_t in_splash;
static void hk_text(int32_t x0, int32_t y0, int32_t x1, int32_t y1, const char *s, uint32_t flags)
{
    al_text(x0, y0, x1, y1, s, flags);
    if (in_splash && strlen(splash_seen) + strlen(s) + 2u < sizeof splash_seen)
        snprintf(splash_seen + strlen(splash_seen), sizeof splash_seen - strlen(splash_seen), "%s%s", splash_seen[0] ? "|" : "", s);
    n_text++;
    if (npend >= 256u) return;
    pend[npend] = (rbox_t){(int16_t)x0, (int16_t)y0, (int16_t)x1, (int16_t)y1, (uint8_t)flags, {0}};
    strncpy(pend[npend].s, s, 27);
    npend++;
}
static void hk_cell(int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    al_item_k(x0, y0, x1, y1, 1, "cell", 1);
    if (ncells < 64u) {
        cells[ncells][0] = (int16_t)x0; cells[ncells][1] = (int16_t)y0;
        cells[ncells][2] = (int16_t)x1; cells[ncells][3] = (int16_t)y1;
        ncells++;
    }
}
static void hk_blit(uint32_t x, uint32_t y, uint32_t r0, uint32_t w, uint32_t h);
static void hk_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h);
/* STYLE LINE: the dividers drawn on the screen (ui_draw.c lcd_rule) while no later blit or fill covers them */
static int16_t rules[32][4];
static uint32_t nrules;
static void hk_rule(uint32_t x, uint32_t y, uint32_t w, uint32_t h)
{
    if (nrules < 32u) {
        rules[nrules][0] = (int16_t)x; rules[nrules][1] = (int16_t)y;
        rules[nrules][2] = (int16_t)(x + w); rules[nrules][3] = (int16_t)(y + h);
        nrules++;
    }
}
static void rules_cover(int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    uint32_t i, k = 0;
    for (i = 0; i < nrules; i++)
        if (!(rules[i][0] >= x0 && rules[i][2] <= x1 && rules[i][1] >= y0 && rules[i][3] <= y1))
            memcpy(rules[k++], rules[i], sizeof rules[i]);
    nrules = k;
}
static void hk_run(uint32_t x, uint32_t y, uint32_t r0, uint32_t r1);   /* (v1.5.15) below, after the canvas: */
static void hk_blit_band(uint32_t x, uint32_t y);                       /* gfx.c calls them through the hooks */
#define GFX_HOOK_TEXT(x0, y0, x1, y1, s, flags) hk_text(x0, y0, x1, y1, s, flags)
#define GFX_HOOK_BLIT(x, y, r0) hk_blit(x, y, r0, cv_w, cv_h)
#define GFX_HOOK_BLIT_ROWS(x, y, r0, r1) hk_run((x), (y), (r0), (r1))   /* (v1.5.15) a run of rows */
#define GFX_HOOK_BLIT_BAND(x, y) hk_blit_band((x), (y))
#define GFX_HOOK_BEGIN() (npend = ncells = 0, al_flush())
#define GFX_HOOK_CELL(x0, y0, x1, y1) hk_cell(x0, y0, x1, y1)
#define GFX_HOOK_RULE(x, y, w, h) hk_rule(x, y, w, h)
static uint32_t nink;                           /* GFX_HOOK_INK: inks drawn on their own colour */
static void hk_ink(uint16_t ink, uint16_t bg);
#define GFX_HOOK_INK(ink, bg) hk_ink(ink, bg)
#define GFX_HOOK_PIXELS(n) (px_visited += (n))
static uint64_t px_fill;                        /* (FASE 8) the pixels every cv_rect paints: exact, not timed */
static uint64_t n_fill;                         /* (1.5.29) how many cv_rect calls a screen asks for */
extern unsigned gfx_ramp_builds;               /* (1.5.28) text ramps rebuilt: a cache miss in gfx.c's ramp() */
#define GFX_HOOK_FILL(w, h) \
    (n_fill++, px_fill += ((w) > 0 && (h) > 0) ? (uint64_t)(uint32_t)(w) * (uint64_t)(uint32_t)(h) : 0u)
#define UI_FILL_HOOK(x, y, w, h) hk_fill(x, y, w, h)
static void fm6_hook(uint32_t kind, uint32_t a, uint32_t b);
#define FM6_CHART_HOOK(kind, a, b) fm6_hook(kind, a, b)
/* MENU > LARGE: the tall cards' values by the face they got (ui_draw.c LARGE_HOOK), the characters L lacked */
static uint64_t lg_n[4];
static char lg_miss[96], lg_wide[16][12], lg_small[16][12];
static uint32_t lg_nwide, lg_nsmall;
static void lg_hook(const char *s, int why);
#define LARGE_HOOK(s, why) lg_hook(s, why)
#define UI_TEST_NO_MAIN 1
#define PF_MS 900u                                       /* (0.6.61) the page name drawn (ui_test.c: off) */
/* (v1.5.11) THE GOLDEN PIXELS DO NOT DEPEND ON THE DAY THE SUITE RAN. ABOUT prints the firmware's build
 * date (__DATE__, ui_menu.c), so a suite that crosses midnight found 32 changed frames -- the about page in
 * every palette -- and failed on a clock, not on a drawing. Pinned here, in the harness only: the device
 * still shows the date it was built. */
#undef __DATE__
#define __DATE__ "Nov 19 2026"

#include "ui_test.c"

static uint8_t large_on;                         /* the LARGE pass: every scene with MENU > LARGE ON */
static void lg_hook(const char *s, int why)
{
    uint32_t i;
    lg_n[why & 3]++;
    if (why == 1)
        for (; *s; s++) {
            uint32_t c = fold(&AF_L, (uint8_t)*s);
            if (glyph_at(&AF_L, c) < 0 && !strchr(lg_miss, (int)c) && strlen(lg_miss) + 1u < sizeof lg_miss)
                lg_miss[strlen(lg_miss)] = (char)c;
        }
    if (why == 2 || why == 3) {                     /* a few of each, distinct */
        char (*l)[12] = why == 2 ? lg_wide : lg_small;
        uint32_t *n = why == 2 ? &lg_nwide : &lg_nsmall;
        for (i = 0; i < *n && strcmp(l[i], s); i++) ;
        if (i == *n && *n < 16u) snprintf(l[(*n)++], 12, "%s", s);
    }
}

/* an icon drawn: its ink, read from its cell's nibbles here (not icons.c icon_ink's table: measured, not trusted) */
/* n alpha values of a cell from its bit stream (the canonical Huffman code AI_HC, as gen_aa_font.py huff_unpack:
 * decoded here bit by bit, not by gfx.c's table) */
static void icon_unpack(const uint8_t *d, uint8_t *out, uint32_t n)
{
    uint32_t k = 0, pos = 0;
    while (k < n) {
        uint32_t code = 0, first = 0, idx = 0, len, s, r;
        for (len = 0; len < 15u; len++) {
            code |= (d[pos >> 3] >> (7u - (pos & 7u))) & 1u;
            pos++;
            if (code - first < AI_HC[len]) break;
            idx += AI_HC[len];
            first = (first + AI_HC[len]) << 1;
            code <<= 1;
        }
        s = AI_HC[15u + idx + code - first];
        for (r = 0; r <= s >> 4 && k < n; r++) out[k++] = (uint8_t)(s & 15u);
    }
}
static void hk_icon(int32_t x, int32_t y, uint32_t size, uint32_t id)
{
    int32_t k, x0 = 99, y0 = 99, x1 = -1, y1 = -1;
    uint32_t i;
    const uint8_t *c;
    uint8_t cell[24 * 24];
    if (!al_n || (k = icon_cell(&size, id)) < 0) return;
    c = size == 24u ? AI24_DATA + AI24_OFF[k] : size == 16u ? AI16_DATA + AI16_OFF[k] : AI12_DATA + AI12_OFF[k];
    icon_unpack(c, cell, size * size);
    for (i = 0; i < size * size; i++)
        if (cell[i]) {
            int32_t px = (int32_t)(i % size), py = (int32_t)(i / size);
            if (px < x0) x0 = px;
            if (px + 1 > x1) x1 = px + 1;
            if (py < y0) y0 = py;
            if (py + 1 > y1) y1 = py + 1;
        }
    if (cv_flip) { int32_t t = x0; x0 = (int32_t)size - x1; x1 = (int32_t)size - t; }   /* (mirrored: the metronome) */
    al_item(x + x0, y + y0, x + x1, y + y1, 1, "icon");
}

/* the FM6 chart lint: each part of a chart (FMH_*) drawn alone onto a canvas of SENT, its pixels kept in fmp_mask
 * (bit: the part), then the canvas as drawn restored with the part on it; at FMH_END the parts are checked */
#define FMP_MAX 48u
#define FMP_SENT 0x0861u
static uint64_t fmp_mask[CV_MAX];
static uint16_t fmp_save[CV_MAX];
static uint8_t fmp_kind[FMP_MAX], fmp_a[FMP_MAX], fmp_b[FMP_MAX];
static int32_t fmp_bx0[FMP_MAX], fmp_by0[FMP_MAX], fmp_bx1[FMP_MAX], fmp_by1[FMP_MAX];   /* each part's extent */
static uint32_t fmp_n, fmp_charts;
static void finding(const char *what, const rbox_t *b, const rbox_t *o);
/* (v2.3.16) the second rect was the same pixel again: it says the rectangle of the box or the part whose ring the
 * pixel is in, which is what a fix needs to know */
static void fmp_find2(uint32_t alg, const char *what, uint32_t i, int32_t x, int32_t y, uint32_t j, int32_t ex, int32_t ey)
{
    static const char *const KIND[] = {"box", "route", "carrier", "bus", "loop", "label"};
    rbox_t b = {(int16_t)x, (int16_t)y, (int16_t)x, (int16_t)y, 0, {0}}, o = b;
    snprintf(b.s, sizeof b.s, "ALG %u %s %u>%u", alg + 1u, KIND[fmp_kind[i]], fmp_a[i] + 1u, fmp_b[i] + 1u);
    snprintf(o.s, sizeof o.s, "%s %u>%u", j < FMP_MAX ? KIND[fmp_kind[j]] : "panel", j < FMP_MAX ? fmp_a[j] + 1u : 0u,
             j < FMP_MAX ? fmp_b[j] + 1u : 0u);
    if (j < FMP_MAX) { o.x0 = (int16_t)fmp_bx0[j]; o.y0 = (int16_t)fmp_by0[j]; o.x1 = (int16_t)fmp_bx1[j]; o.y1 = (int16_t)fmp_by1[j]; }
    else { o.x0 = (int16_t)ex; o.y0 = (int16_t)ey; o.x1 = (int16_t)ex; o.y1 = (int16_t)ey; }
    finding(what, &b, &o);
}
#define fmp_find(alg, what, i, x, y, j) fmp_find2(alg, what, i, x, y, j, x, y)
static void fmp_check(uint32_t alg)
{
    int32_t *const bx0 = fmp_bx0, *const by0 = fmp_by0, *const bx1 = fmp_bx1, *const by1 = fmp_by1;
    int32_t x, y, dx, dy;
    uint32_t net[FMP_MAX], par[12], i, j, w = cv_w, h = cv_h;
    for (i = 0; i < 12u; i++) par[i] = i;               /* the routes' nets: an operator as source (0..5), as destination (6..11) */
    #define FMP_ROOT(v) ({ uint32_t r_ = (v); while (par[r_] != r_) r_ = par[r_]; r_; })
    for (i = 0; i < fmp_n; i++)
        if (fmp_kind[i] == FMH_ROUTE) par[FMP_ROOT(fmp_a[i])] = FMP_ROOT(6u + fmp_b[i]);
    for (i = 0; i < fmp_n; i++) {
        net[i] = fmp_kind[i] == FMH_ROUTE ? FMP_ROOT(6u + fmp_b[i]) : fmp_kind[i] == FMH_CAR || fmp_kind[i] == FMH_BUS ? 20u
                 : 21u + fmp_kind[i];
        bx0[i] = by0[i] = 9999; bx1[i] = by1[i] = -1;
    }
    #undef FMP_ROOT
    for (y = 0; y < (int32_t)h; y++)                     /* each part's extent */
        for (x = 0; x < (int32_t)w; x++)
            for (i = 0; i < fmp_n; i++)
                if (fmp_mask[y * w + x] >> i & 1u) {
                    if (x < bx0[i]) bx0[i] = x;
                    if (y < by0[i]) by0[i] = y;
                    if (x > bx1[i]) bx1[i] = x;
                    if (y > by1[i]) by1[i] = y;
                }
    for (i = 0; i < fmp_n; i++)                          /* boxes: apart, by a pixel at least */
        for (j = 0; j < i; j++)
            if (fmp_kind[i] == FMH_BOX && fmp_kind[j] == FMH_BOX && bx0[i] <= bx1[j] + 1 && bx0[j] <= bx1[i] + 1 &&
                by0[i] <= by1[j] + 1 && by0[j] <= by1[i] + 1)
                fmp_find(alg, "FM6 boxes overlap", i, bx0[i], by0[i], j);
    for (y = 0; y < (int32_t)h; y++)
        for (x = 0; x < (int32_t)w; x++) {
            uint64_t mk = fmp_mask[y * w + x];
            if (!mk) continue;
            for (i = 0; i < fmp_n; i++) {
                if (!(mk >> i & 1u) || fmp_kind[i] == FMH_BOX) continue;
                if (x < 6 || x > 233 || y < 2 || y > 119)
                    fmp_find(alg, "FM6 part off the panel", i, x, y, FMP_MAX);
                for (j = 0; j < fmp_n; j++) {
                    if (fmp_kind[j] != FMH_BOX) continue;
                    if (x >= bx0[j] && x <= bx1[j] && y >= by0[j] && y <= by1[j])
                        fmp_find(alg, "FM6 part through a box", i, x, y, j);
                    else if (x >= bx0[j] - 1 && x <= bx1[j] + 1 && y >= by0[j] - 1 && y <= by1[j] + 1 &&
                             !((fmp_kind[i] == FMH_ROUTE && (fmp_a[i] == fmp_a[j] || fmp_b[i] == fmp_a[j])) ||
                               ((fmp_kind[i] == FMH_CAR || fmp_kind[i] == FMH_FB) && fmp_a[i] == fmp_a[j])))
                        fmp_find(alg, "FM6 part touches a box", i, x, y, j);
                }
                for (dy = -1; dy <= 1; dy++)              /* another net on this pixel or next to it */
                    for (dx = -1; dx <= 1; dx++) {
                        int32_t nx = x + dx, ny = y + dy;
                        uint64_t mn;
                        if (nx < 0 || ny < 0 || nx >= (int32_t)w || ny >= (int32_t)h) continue;
                        mn = fmp_mask[ny * w + nx];
                        for (j = 0; j < fmp_n; j++)
                            if (mn >> j & 1u && fmp_kind[j] != FMH_BOX && net[j] != net[i])
                                fmp_find(alg, "FM6 nets cross or touch", i, x, y, j);
                    }
            }
        }
    fmp_charts++;
}
static void fm6_hook(uint32_t kind, uint32_t a, uint32_t b)
{
    uint32_t i, n = cv_w * cv_h;
    if (fmp_n) {                                         /* the part just drawn: its pixels */
        for (i = 0; i < n; i++)
            if (cv_px[i] != FMP_SENT) fmp_mask[i] |= (uint64_t)1u << (fmp_n - 1u);
            else cv_px[i] = fmp_save[i];
    } else {
        memset(fmp_mask, 0, n * sizeof fmp_mask[0]);
    }
    if (kind == FMH_END) {
        fmp_check(a);
        fmp_n = 0;
        return;
    }
    if (fmp_n >= FMP_MAX) { fprintf(stderr, "ui_render: an FM6 chart of more than %u parts\n", FMP_MAX); exit(1); }
    memcpy(fmp_save, cv_px, n * sizeof cv_px[0]);
    for (i = 0; i < n; i++) cv_px[i] = FMP_SENT;
    fmp_kind[fmp_n] = (uint8_t)kind; fmp_a[fmp_n] = (uint8_t)a; fmp_b[fmp_n] = (uint8_t)b;
    fmp_n++;
}

static void finding(const char *what, const rbox_t *b, const rbox_t *o)
{
    static char seen[600][64];
    static uint32_t nseen;
    char key[64];
    uint32_t i;
    nfind++;
    if (!rep) rep = stderr;                      /* (4.3) QG_DUMP renders one screen before the report is opened: a
                                                  * finding said so by crashing on a NULL FILE* */
    snprintf(key, sizeof key, "%.20s|%.14s|%.24s", cur_name, what, b->s ? b->s : "(unlabelled)");
    for (i = 0; i < nseen && strcmp(seen[i], key); i++) ;
    if (i < nseen) return;                       /* each finding once per screen */
    if (nseen < 600u) strcpy(seen[nseen++], key);
    else return;
    /* (FASE 4) a box can carry no label (an icon's ink, a drawing's own frame): say so instead of dereferencing it --
     * a NULL here segfaulted the dump instead of reporting the finding */
    fprintf(rep, "LINT %-22s %-32s '%s' (%d,%d)-(%d,%d)", cur_name, what, b->s ? b->s : "(unlabelled)",
            b->x0, b->y0, b->x1, b->y1);
    if (o) fprintf(rep, " / '%s' (%d,%d)-(%d,%d)", o->s ? o->s : "(unlabelled)", o->x0, o->y0, o->x1, o->y1);
    fputc('\n', rep);
}
/* a rectangle of the screen is drawn again: boxes inside it are gone, boxes it covers in part are hidden */
static void cover(int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    uint32_t i, k = 0;
    for (i = 0; i < nscr; i++) {
        rbox_t *b = &scr[i];
        int in = b->x0 >= x0 && b->x1 <= x1 && b->y0 >= y0 && b->y1 <= y1;
        int touch = b->x0 < x1 && x0 < b->x1 && b->y0 < y1 && y0 < b->y1;
        if (in) continue;
        if (touch && !(b->flags & 48u)) finding("hidden in part by a later draw", b, 0);
        if (touch && (b->flags & 48u)) scr[k++] = *b;   /* split across bands / scrolled: drawn on purpose */
        else scr[k++] = *b;
    }
    nscr = k;
}
static void hk_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h)
{
    cover((int32_t)x, (int32_t)y, (int32_t)(x + w), (int32_t)(y + h));
    rules_cover((int32_t)x, (int32_t)y, (int32_t)(x + w), (int32_t)(y + h));
}
/* a text across two bands (the menu and the document draw 124 + 85 rows): each band draws its part, the same
 * screen box twice, cut at the band edge; together they are whole (flag 16) */
static int split_pair(rbox_t *b)
{
    uint32_t j;
    if (!(b->flags & 2u)) return 0;
    for (j = 0; j < nscr; j++) {
        rbox_t *o = &scr[j];
        if ((o->flags & 2u) && o->x0 == b->x0 && o->x1 == b->x1 && o->y0 == b->y0 && o->y1 == b->y1 && !strcmp(o->s, b->s)) {
            o->flags = (uint8_t)((o->flags & ~2u) | 16u);
            return 1;
        }
    }
    return 0;
}
/* a text or icon box that touches a cell or card of its canvas (GFX_HOOK_CELL) but spills past its edge; for the
 * audit, a text inside its smallest cell closer than 2 px to an edge */
static void contain(int32_t x, int32_t y)
{
    uint32_t i, c;
    for (i = 0; i < npend; i++) {
        const rbox_t *b = &pend[i];
        int32_t best = 1 << 30, gap = 99;
        for (c = 0; c < ncells && !(b->flags & 4u); c++) {   /* (texts only: an icon's box is its whole cell) */
            const int16_t *r = cells[c];
            int32_t a = (r[2] - r[0]) * (r[3] - r[1]), g;
            if (b->x0 < r[0] || b->x1 > r[2] || b->y0 < r[1] || b->y1 > r[3] || a >= best) continue;
            best = a;
            g = b->x0 - r[0];
            if (r[2] - b->x1 < g) g = r[2] - b->x1;
            if (b->y0 - r[1] < g) g = b->y0 - r[1];
            if (r[3] - b->y1 < g) g = r[3] - b->y1;
            gap = g;
        }
        if (gap < 2 && aud && b->s) {   /* (an icon's ink has no label: the tight-cell audit names texts only) */
            pend[i].flags |= 64u;       /* (FASE 8) the box itself, so a sweep value can say whether ITS card was
                                         * the tight one: the per-screen counters cannot tell the four cards apart */
            ntight++;
            if (strlen(tight) + strlen(b->s) + 8u < sizeof tight)
                snprintf(tight + strlen(tight), sizeof tight - strlen(tight), "%s'%s' %dpx", tight[0] ? ", " : "", b->s, (int)gap);
        }
        for (c = 0; c < ncells; c++) {
            const int16_t *r = cells[c];
            int touch = b->x0 < r[2] && r[0] < b->x1 && b->y0 < r[3] && r[1] < b->y1;
            int in = b->x0 >= r[0] && b->x1 <= r[2] && b->y0 >= r[1] && b->y1 <= r[3];
            int around = r[0] >= b->x0 && r[2] <= b->x1 && r[1] >= b->y0 && r[3] <= b->y1;   /* (a mark inside the box) */
            if (touch && !in && !around) {
                rbox_t t = *b, o = {(int16_t)(r[0] + x), (int16_t)(r[1] + y), (int16_t)(r[2] + x), (int16_t)(r[3] + y), 0, "cell"};
                t.x0 += (int16_t)x; t.x1 += (int16_t)x; t.y0 += (int16_t)y; t.y1 += (int16_t)y;
                nspill++;
                finding("spills out of its cell", &t, &o);
                break;
            }
        }
    }
}
static uint8_t bb_on;                            /* (v1.5.6) --idle: track where the blits land */
static int32_t bb[4];
static void hk_blit_at(uint32_t x, uint32_t y, uint32_t r0, uint32_t w, uint32_t h, int count)
{
    uint32_t i, k = 0;
    if (bb_on && getenv("UI_IDLE_BLITS"))
        printf("      blit x=%u y=%u w=%u h=%u\n", x, y, w, h);
    if (getenv("UI_BANDS_DEBUG"))
        printf("      run x=%u y=%u..%u w=%u\n", x, y + r0, y + h, w);
    if (bb_on && w && h > r0) {
        if (bb[2] < 0 || (int32_t)x < bb[0]) bb[0] = (int32_t)x;
        if (bb[2] < 0 || (int32_t)(x + w) > bb[2]) bb[2] = (int32_t)(x + w);
        if (bb[2] < 0 || (int32_t)(y + r0) < bb[1]) bb[1] = (int32_t)(y + r0);
        if ((int32_t)(y + h) > bb[3]) bb[3] = (int32_t)(y + h);
    }
    al_flush();
    contain((int32_t)x, (int32_t)y);
    ncells = 0;
    if (count)
        blit_px += (uint64_t)w * (h > r0 ? h - r0 : 0u);
    for (i = 0; i < npend; i++) {
        rbox_t b = pend[i];
        if (b.y1 <= (int32_t)r0) continue;           /* rows not blitted */
        if (b.y0 < (int32_t)r0) b.flags |= 2u;
        b.x0 += (int16_t)x; b.x1 += (int16_t)x; b.y0 += (int16_t)y; b.y1 += (int16_t)y;
        if (!split_pair(&b)) pend[k++] = b;
    }
    cover((int32_t)x, (int32_t)(y + r0), (int32_t)(x + w), (int32_t)(y + h));
    rules_cover((int32_t)x, (int32_t)(y + r0), (int32_t)(x + w), (int32_t)(y + h));
    for (i = 0; i < k && nscr < 1200u; i++)
        scr[nscr++] = pend[i];
    npend = 0;
}
static void hk_blit(uint32_t x, uint32_t y, uint32_t r0, uint32_t w, uint32_t h)
{
    hk_blit_at(x, y, r0, w, h, 1);                   /* (v1.5.15) a whole canvas: counted */
}
static void hk_blit_band(uint32_t x, uint32_t y)     /* .. the band, once: the lint's books, not the pixels */
{
    hk_blit_at(x, y, 0u, cv_w, cv_h, 0);
}
static void hk_run(uint32_t x, uint32_t y, uint32_t r0, uint32_t r1)
{   /* (v1.5.15) a run of rows: it counts what the panel wrote, and nothing else. The lint's books (the text boxes,
     * what covers what) are the BAND's, once, in hk_blit_band -- a box spanning two runs must not be entered twice. */
    if (getenv("UI_BANDS_DEBUG"))
        printf("      run x=%u y=%u..%u w=%u\n", x, y + r0, y + r1, cv_w);
    blit_px += (uint64_t)cv_w * (r1 - r0);
    if (bb_on && r1 > r0) {
        if (bb[2] < 0 || (int32_t)x < bb[0]) bb[0] = (int32_t)x;
        if (bb[2] < 0 || (int32_t)(x + cv_w) > bb[2]) bb[2] = (int32_t)(x + cv_w);
        if (bb[2] < 0 || (int32_t)(y + r0) < bb[1]) bb[1] = (int32_t)(y + r0);
        if ((int32_t)(y + r1) > bb[3]) bb[3] = (int32_t)(y + r1);
    }
}

static void lint(void)
{
    uint32_t i, j;
    for (i = 0; i < nscr; i++) {
        const rbox_t *b = &scr[i];
        if (b->x0 < 0 || b->y0 < 0 || b->x1 > 240 || b->y1 > 240) finding("off the screen", b, 0);
        if ((b->flags & 2u) && !(b->flags & 32u)) finding("cut by its canvas", b, 0);
        if ((b->flags & 1u) && !(b->flags & 8u)) finding("ellipsised (not free text)", b, 0);
        if ((b->flags & 9u) == 9u) {
            for (j = 0; j < nfree_seen && strcmp(free_seen[j], b->s); j++) ;
            if (j == nfree_seen && nfree_seen < 64u) {
                snprintf(free_seen[nfree_seen++], 40, "%s", b->s);
                fprintf(rep, "free   %-22s ellipsised '%s'\n", cur_name, b->s);
            }
            nfree++;
        }
        for (j = i + 1u; j < nscr; j++) {
            const rbox_t *o = &scr[j];
            if (b->x0 < o->x1 && o->x0 < b->x1 && b->y0 < o->y1 && o->y0 < b->y1) finding("overlaps", b, o);
        }
        for (j = 0; j < nrules; j++) {               /* a divider is a cell edge: nothing on it */
            const int16_t *r = rules[j];
            rbox_t o = {r[0], r[1], r[2], r[3], 0, "divider"};
            if (b->x0 < r[2] && r[0] < b->x1 && b->y0 < r[3] && r[1] < b->y1) finding("touches a divider", b, &o);
        }
    }
}

/* the audit of one screen (GREY): its texts (count, ink-box px), icons, keycaps, the ellipsised and tight texts,
 * and the words themselves */
static FILE *audf;
static void audit_scene(const char *name)
{
    uint32_t i, nt = 0, ni = 0, nk = 0, ne = 0, at = 0, ai = 0, ak = 0;
    char words[1200] = "";
    if (!audf) return;
    for (i = 0; i < nscr; i++) {
        const rbox_t *b = &scr[i];
        uint32_t a = (uint32_t)((b->x1 - b->x0) * (b->y1 - b->y0));
        if ((b->flags & 4u) && !strcmp(b->s, "icon")) { ni++; ai += a; continue; }
        if (b->flags & 4u) { nk++; ak += a; continue; }
        nt++; at += a;
        if (b->flags & 1u) ne++;
        if (strlen(words) + strlen(b->s) + 4u < sizeof words)
            snprintf(words + strlen(words), sizeof words - strlen(words), "%s%s", words[0] ? " | " : "", b->s);
    }
    fprintf(audf, "%s\t%u\t%u\t%u\t%u\t%u\t%u\t%u\t%u\t%s\t%s\t\t\t\n",
            name, nt, at, ni, ai, nk, ak, ne, ntight, words, tight);
}
/* (FASE 7/8) EVERY VALUE THE COLUMN SWEEP DRAWS, WRITTEN DOWN. The audit above only ever saw the free text of
 * the 191 screens, so the labels the sweep itself draws -- RATE's synced divisions (-14 .. -1: 1/32T .. 1/64),
 * the DIV columns' N_DIV names (8T, 16T, 2BAR ...) and every other named value -- had no record: they were
 * covered by the lint alone, which judges the string as it draws it and writes nothing down, so nothing could
 * look at them again afterwards, and under LARGE nothing compared them at all. Each value the sweep draws now
 * writes the row of a screen -- the string the card actually showed, its ink box in px, whether the card
 * ellipsised it and whether it sat closer than 2 px to its cell -- under the name "<engine>/<page>/<LABEL>=<value>",
 * in GREY and again under LARGE. RATE keeps its own three columns (rate_value / rate_px / rate_elided) so the
 * records written before this are still read the same way. */
static uint32_t nvalue_audit, nrate_audit;
static void audit_value(const char *base, const param_desc_t *d, int32_t v)
{
    char val[16], screen[112], rate[64] = "";
    const char *unit = "";
    uint32_t i, w = 0, a = 0, found = 0, elided = 0, tightc = 0;
    int is_rate;
    if (!audf || !d->label) return;
    param_format(d, v, val, &unit);
    is_rate = !strcmp(d->label, "RATE");
    for (i = 0; i < nscr; i++)                       /* the card's own box: the last one drawn with this text */
        if (!strcmp(scr[i].s, val)) {
            w = (uint32_t)(scr[i].x1 - scr[i].x0);
            a = w * (uint32_t)(scr[i].y1 - scr[i].y0);
            elided = (scr[i].flags & 1u) ? 1u : 0u;
            tightc = (scr[i].flags & 64u) ? 1u : 0u;
            found = 1;
        }
    if (is_rate) {                                   /* the three columns FASE 7 added, unchanged */
        snprintf(rate, sizeof rate, "%s\t%u\t%s", val, w, found ? (elided ? "yes" : "no") : "missing");
        nrate_audit++;
    }
    snprintf(screen, sizeof screen, "%s/%s=%s", base, d->label, val);
    fprintf(audf, "%s\t1\t%u\t0\t0\t0\t0\t%u\t%u\t%s\t\t%s\n", screen, a, elided, tightc, val, rate);
    nvalue_audit++;
}
/* GREY: every pixel RGB565 gray (R = B, G = 2 R); MONO (black and white, its edges blended per channel): neutral
 * (R = B, G within 2 of 2 R, the 5-6-5 rounding). Other palettes: nothing */
static uint32_t mono_bad;
static void mono_check(void)
{
    uint32_t i, bw = settings.palette == UI_BW_INDEX;
    if (settings.palette != UI_GREY_INDEX && !bw) return;
    for (i = 0; i < 240u * 240u; i++) {
        uint16_t c = swap16(host_screen[i]);
        int32_t d = (int32_t)((c >> 5) & 63u) - (int32_t)(c >> 11) * 2;
        if ((c >> 11) != (c & 31u) || (bw ? d < -2 || d > 2 : d != 0)) {
            if (!mono_bad) fprintf(rep, "%s %s: pixel %u,%u = %04x off %s\n", bw ? "MONO" : "GREY", cur_name, i % 240u, i / 240u, c,
                                   bw ? "neutral" : "gray");
            mono_bad++;
        }
    }
}
static void hk_ink(uint16_t ink, uint16_t bg)
{
    if (ink != bg) return;
    if (nink < 20u) fprintf(rep, "%s: ink %04x drawn on its own colour (%s)\n", cur_name, ink, UI_PALETTES[settings.palette % NPALETTES].name);
    nink++;
}
static void write_ppm(const char *dir, const char *pal, const char *name)
{
    char path[512];
    uint32_t i;
    FILE *f;
    snprintf(path, sizeof path, "%s/ppm/%s_%s.ppm", dir, pal, name);
    f = fopen(path, "wb");
    if (!f) { fprintf(stderr, "cannot write %s\n", path); return; }
    fprintf(f, "P6\n240 240\n255\n");
    for (i = 0; i < 240u * 240u; i++) {
        uint16_t c = swap16(host_screen[i]);
        uint8_t b[3] = {(uint8_t)((c >> 11) * 255u / 31u), (uint8_t)(((c >> 5) & 63u) * 255u / 63u), (uint8_t)((c & 31u) * 255u / 31u)};
        fwrite(b, 1, 3, f);
    }
    fclose(f);
}

/* ------------------------------------------------------------------ the screens --- */
static void pal(uint32_t p) { settings.palette = p; palette_set(p); }
static void state(void)                          /* a playing song with steps on every track */
{
    uint32_t i;
    ui_power_on();
    dx_mute_set(0);
    memset(macro_v, 0, sizeof macro_v);
    if (large_on) ui_prefs |= PREF_LARGE;
    song.playing = 1;
    song.g[G_BPM] = 124;
    clk_pos = 0; clk_step = 8; cin_total = cin_left = 0;   /* the bar's 3rd beat: the header's metronome at rest */
    for (i = 0; i < NTRK; i++) trk[i].seq_idx = 5;
    my_steps(&trk[1]);
    trk[0].step[2].flags |= SF_ACCENT;
    trk[0].step[6].flags |= SF_SLIDE;
    for (i = 0; i < SCOPE_N; i++) {               /* a stand-in signal for the scope */
        double ph = fmod(i / 64.0, 1.0);
        scope_buf[i] = (int16_t)((ph * 2.0 - 1.0) * 9000.0 + sin(i * 0.4908) * 2500.0);
    }
    scope_w = 0;
}
static void drum(uint32_t kit)
{
    uint32_t i;
    song.sel = 3;
    trk[3].p[P_E0] = (int16_t)kit;
    for (i = 0; i < 16u; i++) {
        step_t *s = &trk[3].step[i];
        memset(s, 0, sizeof *s);
        s->time = ST_NOTE; s->vel = 100;
        if (i % 4u == 0u) s->hit |= 1u;
        if (i == 4u || i == 12u) s->hit |= 2u, s->acc |= 2u;
        if (i == 10u) s->hit |= 4u;
        if (i % 2u == 0u) s->hit |= 8u;
        if (i == 14u) s->hit |= 16u;
        if (i == 7u || i == 15u) s->hit |= 32u;
        if (i == 3u) s->hit |= 64u;
        if (i == 0u) s->hit |= 128u, s->acc |= 128u;
    }
    trk[3].p[P_SLEN] = 32;
}
static void eng(uint32_t e) { set_engine_of(TSEL, e); }
/* the FM engine of the FM screens: DIGITAL with FELUCCA_FM4, else FM6 (DIGITAL retired: its own screens, the OP ENV /
 * OP LEVEL pages and the algorithm charts, exist only there: fm4_screen) */
#define E_FM (FELUCCA_FM4 ? ENGI_DIGITAL : ENGI_FM6)

enum { S_HOME, S_HOME_IDLE, S_MESSAGE, S_MESSAGE_KEY, S_MESSAGE_NOFILE, S_PRESETS, S_PRESETS_NOFAV, S_USER, S_PHRASES, S_PROJECT, S_TOOLS,
       S_SONG_EMPTY, S_SONG, S_STEP, S_PATTERN, S_CHANCE, S_COMP, S_COMP_TRIG, S_COMP_ECHO, S_MUTATE, S_MORPH, S_DXIMG, S_DXSEND, S_PFLASH, S_PFLASH_HOME, S_FUGUE, S_MOTION, S_DRUM, S_DRUM_HAND, S_DRUM_CYM, S_MIXER, S_MIXER_PAN,
       S_ENV, S_ENVDEST, S_LFO, S_MOD, S_FX, S_SLICER, S_SLBUS, S_SLPITCH, S_DLY, S_SHIFT, S_ARP, S_VOICE, S_GLOBAL, S_SYSTEM, S_MONITOR,
       S_EDIT_ANALOG, S_EDIT_DIGITAL, S_OP_ENV, S_EDIT_WHEEL, S_EDIT_SAMPLE, S_EDIT_GRAIN, S_EDIT_LOFI, S_EDIT_LOFI_FREE, S_EDIT_PHASE,
       S_EDIT_CHAR, S_EDIT_VOICE_CHAR, S_LFO_SHAPE,          /* (FASE 2) */
       S_ALG1, S_ALG2, S_ALG3, S_ALG4, S_ALG5, S_ALG6, S_ALG7, S_ALG8, S_OP_LEVEL,
       S_FM6_ALG1, S_FM6_ALG5, S_FM6_ALG22, S_FM6_ALG32, S_DRUMX, S_DRUMX_HIT, S_DX_SOUND, S_DX_SOUND2,
       S_CONFIRM_SEQ, S_CONFIRM_PROJ, S_CONFIRM_USER, S_CONFIRM_PAT, S_CONFIRM_MOTION, S_CONFIRM_ERASE,
       S_MENU, S_MENU_SPEAKER, S_ABOUT, S_ABOUT_REC, S_ABOUT_CREDITS, S_ABOUT_END, S_UBOOT, S_CALIBRATION, S_SPLASH,
       S_BATT0, S_BATT1, S_BATT2, S_BATT3, S_BATT_USB, S_MOTION_REC, S_MOTION_OFF, S_MOTION_CARD, S_SONG_HOME,
       S_FX_PEEK, S_FX_HELD, S_FX_WAIT, S_FX_HARM, S_MENU_HOLD, S_MENU_LEDS, S_MENU_END, S_MENU_SYSTEM, S_MENU_SLIDE, S_REVERB, S_REVERB_RESO, S_REVERB_CLOUD,
       S_GLO_PEEK, S_GLO_ACTIVE, S_GLO_EXT, S_SCL_PEEK, S_SCL_ACTIVE, S_EDIT_PEEK, S_EDIT_ACTIVE, S_EDIT_USER, S_EDIT_DRUM, S_LAYER_HINT, S_LAYER_LOCK, S_LAYER_LOCK_FX, S_LAYER_SONG, S_LAYER_SONG_CHAIN,
       S_SEQ_TOOLS, S_SEQ_TOOLS_DRUM, S_SEQ_TOOLS_SONG,
       S_NAME_USER, S_NAME_TYPING, S_NAME_123, S_NAME_EMPTY, S_NAME_FULL, S_NAME_PLAYING, S_PROJECT_NAMED, S_SONG_NAMED,
       S_USER_FOOT,
       S_ROLL_EMPTY, S_ROLL_ACID, S_ROLL_CHORDS, S_ROLL_TIES, S_ROLL_LEN32, S_ROLL_HIGH, S_ROLL_LOW, S_ROLL_WIDE, S_ROLL_PLAYING,
       S_ROLL_LOCKS, S_ROLL_LOCK_HELD, S_DRUM_LOCKS, S_DRUM_LOCK_HELD, S_MOTION_LOCKS, S_AUTO_LIST, S_AUTO_LIST_ADD, S_AUTO_LIST_DRUM, S_REC_LAYER, S_REC_LAYER_SET, S_REC_LAYER_SONG, S_MACRO_LAYER, S_MACROS, S_MSEQ, S_DIST_PAGE, S_DLY2, S_REVERB2, S_CHORUS, S_MASTER, S_MASTER_EQ, S_RETRIG, S_RETRIG_FREE, S_LFO_DEST,
       S_COUNTIN, S_COUNTIN2, S_MENU_AUDIO, S_HEAD_PLAY_REC, S_HEAD_REC_OTHER, S_HEAD_BPM_TURN, S_HEAD_BPM_LOCK,
       S_HEAD_BPM_LOCKED, S_HEAD_GLO_TURN, S_HEAD_DOWNBEAT, S_HEAD_BEAT_2,
       S_MIXER_T4, S_HOME_T4, S_MENU_EXTRA,
       S_SCL_SCALE, S_SCL_CHORD, S_SCL_TUNE, S_SCL_TUNE_PLAY, S_SCL_PROG, S_FX_BUSES, S_SEQ_TOOLS_EDITS,
       S_TILT, S_LFO_CURVE, S_EDIT_FILTER, S_FM_OP_ENV, S_EDIT_FILTER_SHELF, S_EDIT_FILTER_NOTCH,
       S_EDIT_FILTER_VOWEL, S_EDIT_FILTER_SCREAM,                       /* (v1.12.9) the two pages v1.12.4 and v1.12.5 added: they had no
                                                   * frame in this sweep at all, so neither the pixel baseline nor
                                                   * the alignment lint had ever seen them. BEFORE S_MOCK_HOME, which
                                                   * starts the mock branch: after it, setup() never reaches them */   S_MOCK_HOME, S_MOCK_PRESETS, S_MOCK_SEQ, S_MOCK_DRUM, S_MOCK_MIXER, S_MOCK_DIALOG,
       S_MOCK_MENU, S_HOME_VIZ, S_HOME_OVERVIEW, S_HOME_MIX, S_HOME_PERF,
       S_SCENES, S_SCENES_EMPTY, S_PRESETS_POP, S_COUNT };   /* (v1.8.5) QUANTUM MORPH: a captured pair and an empty one */
static const char *const S_NAME[S_COUNT] = {"home", "home_idle", "message", "message_key", "message_nofile", "presets", "presets_nofav", "user",
    "phrases", "project", "tools", "song_empty", "song", "step", "pattern", "chance", "comp", "comp_trig", "comp_echo", "mutate", "morph", "dx_image", "dx_send", "page_flash", "page_flash_home", "fugue", "motion", "drum",
    "drum_hand", "drum_cym", "mixer", "mixer_pan", "env", "env_dest", "lfo", "mod", "fx", "slicer", "slbus", "slpitch", "dly", "shift", "arp",
    "voice", "global", "system", "monitor", "edit_analog", FELUCCA_FM4 ? "edit_digital" : "edit_fm6", "op_env", "edit_wheel", "edit_voice",
    "edit_noise", "edit_lofi", "edit_lofi_free", "edit_phase", "edit_char", "edit_voice_char", "lfo_shape", "alg_1", "alg_2", "alg_3", "alg_4", "alg_5", "alg_6", "alg_7", "alg_8", "op_level", "fm6_alg_01", "fm6_alg_05", "fm6_alg_22", "fm6_alg_32", "drumx", "drumx_hit", "dx_sound", "dx_sound2", "confirm_seq", "confirm_project", "confirm_user", "confirm_pattern",
    "confirm_motion", "confirm_erase", "menu", "menu_speaker", "about", "about_rec", "about_credits", "about_end", "uboot", "calibration", "splash",
    "batt_0", "batt_1", "batt_2", "batt_3", "batt_usb", "motion_rec", "motion_off", "motion_card", "song_home",
    "perform_peek", "perform_held", "perform_wait", "perform_harm", "menu_hold", "menu_leds", "menu_end", "menu_system", "menu_slide", "reverb_spring", "reverb_reso", "reverb_cloud",
    "layer_glo_peek", "layer_glo_active", "layer_glo_ext", "layer_scl_peek", "layer_scl_active", "layer_edit_peek",
    "layer_edit_active", "layer_edit_user", "layer_edit_drum", "layer_hint", "layer_lock", "layer_lock_fx", "layer_song", "layer_song_chain",
    "layer_seq_tools", "layer_seq_tools_drum", "layer_seq_tools_song",
    "name_user", "name_typing", "name_123", "name_empty", "name_full", "name_playing", "project_named", "song_named",
    "user_foot",
    "roll_empty", "roll_acid", "roll_chords", "roll_ties", "roll_len32_p2", "roll_high", "roll_low", "roll_wide", "roll_playing",
    "roll_locks", "roll_lock_held", "drum_locks", "drum_lock_held", "motion_locks", "auto_list", "auto_list_add", "auto_list_drum", "layer_rec", "layer_rec_set", "layer_rec_song", "layer_macro", "macros", "mseq", "dist", "dly2", "reverb2", "chorus", "master", "master_eq", "retrig_note", "retrig_free", "lfo_dest",
    "countin", "countin_2bars", "menu_audio", "head_play_rec", "head_rec_other", "head_bpm_turn", "head_bpm_lock",
    "head_bpm_locked", "head_glo_turn", "head_downbeat", "head_beat_2",
    "mixer_tracks4", "home_tracks4", "menu_extra",
    "scl_scale", "scl_chord", "scl_tune", "scl_tune_play", "scl_prog", "fx_buses", "seq_tools_edits", "tilt", "lfo_curve", "edit_filter", "fm_op_env", "filter_shelf", "filter_notch", "filter_vowel", "filter_scream", "mock_home", "mock_presets", "mock_seq", "mock_drum", "mock_mixer", "mock_dialog", "mock_menu", "home_viz", "home_overview", "home_mix", "home_perf", "scenes", "scenes_empty", "presets_pop"};

/* the scenes of the UI design screens: the state the UI-redesign
 * prototype drew them from (its setup(): two pattern tracks, the drum pattern on track 4, a synthetic scope),
 * plus the hot knob each mock shows; tests/ui_mockcmp.py compares these renders with the mock PNGs */
static void mock_state(int s)
{
    uint32_t i;
    ui_power_on();
    if (large_on) ui_prefs |= PREF_LARGE;
    usb.config = 0;
    song.batt_raw = 600;
    for (i = 0; i < SCOPE_N; i++) {                  /* a saw with a little second harmonic */
        double ph = fmod(i / 64.0, 1.0);
        scope_buf[i] = (int16_t)((ph * 2.0 - 1.0) * 9000.0 + sin(i * 0.4908) * 2500.0);
    }
    scope_w = 0;
    song.playing = 1;
    song.g[G_BPM] = 124;
    clk_pos = 0; clk_step = 8; cin_total = cin_left = 0;   /* (as state()) */
    for (i = 0; i < NTRK; i++) trk[i].seq_idx = 5;
    load_pat16(&trk[0], PATTERNS[0].note, PATTERNS[0].flags);
    load_pat16(&trk[1], PATTERNS[4].note, PATTERNS[4].flags);
    for (i = 0; i < 16u; i++) {
        step_t *st = &trk[3].step[i];
        memset(st, 0, sizeof *st);
        st->time = ST_NOTE; st->vel = 100;
        if (i % 4u == 0u) st->hit |= 1u;
        if (i == 4u || i == 12u) st->hit |= 2u, st->acc |= 2u;
        if (i == 10u) st->hit |= 4u;
        if (i % 2u == 0u) st->hit |= 8u;
        if (i == 14u) st->hit |= 16u;
        if (i == 7u || i == 15u) st->hit |= 32u;
        if (i == 3u) st->hit |= 64u;
        if (i == 0u) st->hit |= 128u, st->acc |= 128u;
    }
    trk[3].p[P_SLEN] = 32;
    switch (s) {
    case S_PRESETS_POP:                             /* (v1.8.7) the transient preset card, up, mid-turn */
        favorite_set(0, 4, 1);
        go_page(GR_BROWSE);
        preset_step(2);                             /* two detents: the card shows its neighbours */
        fm1_ms = 4000u;                              /* mid-window: the card is up (1.5 s from the detent) */
        ui.preset_pop_ms = 3900u;
        break;
    case S_SCENES:                                  /* (v1.8.5) two scenes captured, the position at 96 */
        TSEL->p[P_FCUT] = 30; msc_capture(0);
        TSEL->p[P_FCUT] = 100; msc_capture(1);
        msc_ui_a = 1; msc_ui_b = 2; msc_ui_p = 96;
        msc_sync(); msc_pos = msc_want = 96; msc_apply(96);
        go_page(GR_SCENES);
        break;
    case S_SCENES_EMPTY:                            /* .. and nothing stored: the rail empty, no fill */
        msc_have = 0; msc_on = 0; msc_ui_p = 0; msc_pos = msc_want = 0;
        go_page(GR_SCENES);
        break;
    case S_MOCK_HOME: ui.home = 1; ui.hot_col = 1; ui.hot_t = 30; break;
    case S_MOCK_PRESETS: go_page(GR_BROWSE); break;
    case S_MOCK_SEQ: song.sel = 0; song.rec = 1; go_page(GR_ROLL); ui.cursor = 6; ui.hot_col = 0; ui.hot_t = 30; break;
    case S_MOCK_DRUM: song.sel = 3; go_page(GR_ROLL); ui.cursor = 4; ui.lane = 1; trk[3].seq_idx = 9; ui.hot_col = 0; ui.hot_t = 30; break;
    case S_MOCK_MIXER:
        go_page(GR_TRK);
        trk[0].p[P_LEVEL] = 100; trk[1].p[P_LEVEL] = 84; trk[2].p[P_LEVEL] = 64; trk[3].p[P_LEVEL] = 110;
        trk[0].p[P_PAN] = -20; trk[1].p[P_PAN] = 24; trk[2].p[P_PAN] = 0; trk[3].p[P_PAN] = -4;
        trk[0].p[P_REV] = 30; trk[1].p[P_REV] = 80; trk[2].p[P_REV] = 10; trk[3].p[P_REV] = 0;
        trk[2].p[P_MUTE] = 1;
        song.rec = 2u;
        trk[0].peak = 11000; trk[1].peak = 3300; trk[3].peak = 20000;     /* (the mock's stand-in meters) */
        ui.hot_col = 1; ui.hot_t = 30;
        break;
    case S_MOCK_DIALOG: ui.confirm = CF_OVR_PROJ; ui.confirm_trk = 0; go_page(GR_PATS); break;
    case S_MOCK_MENU: ui.menu = 1; ui.menu_sel = 0; break;
    case S_HOME_VIZ: ui.home = 1; ui.home_viz = 1; ui.force = 1; break;
    case S_HOME_OVERVIEW:                           /* (3.0) HOME's second screen, from the mock's own state */
        mock_state(S_MOCK_HOME);
        ui.home = 1; ui.home_viz = 0; ui.home_view = HV_OVERVIEW; ui.force = 1;
        break;
    case S_HOME_MIX:                                /* (3.1) HOME's third: the desk, six rows of real meters */
        mock_state(S_MOCK_HOME);
        ui.home = 1; ui.home_viz = 0; ui.home_view = HV_MIX; ui.force = 1;
        break;
    case S_HOME_PERF:                               /* (3.2) HOME's fourth: the live settings */
        mock_state(S_MOCK_HOME);
        ui.home = 1; ui.home_viz = 0; ui.home_view = HV_PERF; ui.force = 1;
        break;
    default: break;
    }
}

/* the STEP page's piano roll (ui_graph.c graph_roll) on track 1, stopped unless said: an empty pattern; ACID in
 * A minor; POLY chords (Am7 F C G, tied); a line with ties, slides and accents in C major; LEN 32 on its second
 * page, playing; high (A6..) and low (C-1..) notes; a page wider than the view (edge marks); ACID playing with a
 * key held (A3, its row lit) */
static void step_put(step_t *st, uint32_t time, uint32_t flags, uint32_t n, const uint8_t *notes)
{
    uint32_t j;
    memset(st, 0, sizeof *st);
    st->time = (uint8_t)time; st->flags = (uint8_t)flags; st->n = (uint8_t)n; st->vel = 100;
    for (j = 0; j < n; j++) st->note[j] = notes[j];
}
static void roll_scene(int s)
{
    static const uint8_t AM7[] = {57, 60, 64, 67}, FM7[] = {53, 57, 60, 64}, CMA[] = {60, 64, 67}, GMA[] = {55, 59, 62, 67};
    static const uint8_t LINE[16] = {48, 0, 55, 60, 0, 59, 0, 0, 62, 64, 0, 67, 0, 65, 64, 0};
    static const uint8_t LINE_T[16] = {0, 1, 0, 0, 1, 0, 2, 2, 0, 0, 1, 0, 1, 0, 0, 2};   /* 0 note, 1 tie, 2 rest */
    track_t *t;
    uint32_t i;
    song.sel = 0; t = TSEL;
    song.playing = 0;
    track_defaults_steps(t);
    t->p[P_SLEN] = 16;
    go_page(GR_ROLL);
    ui.cursor = 0;
    switch (s) {
    case S_ROLL_EMPTY: break;
    case S_ROLL_ACID:
    case S_ROLL_PLAYING:
        load_pat16(t, PATTERNS[0].note, PATTERNS[0].flags);
        t->p[P_ROOT] = 9; t->p[P_SCALE] = 2; ui.cursor = 6;
        if (s == S_ROLL_PLAYING) {
            song.playing = 1; t->seq_idx = 9;
            kb_trk[3] = 0; kb_on[3] = 1; kb_snd[3][0] = 57;           /* A3 held */
        }
        break;
    case S_ROLL_CHORDS:
        t->p[P_VOICE] = V_POLY; t->p[P_ROOT] = 9; t->p[P_SCALE] = 2;
        for (i = 0; i < 16u; i++) {
            const uint8_t *c = i / 4u == 0u ? AM7 : i / 4u == 1u ? FM7 : i / 4u == 2u ? CMA : GMA;
            uint32_t n = i / 4u == 2u ? 3u : 4u;
            if (i % 4u == 0u) step_put(&t->step[i], ST_NOTE, i == 8u ? SF_ACCENT : 0u, n, c);
            else if (i % 4u == 1u) step_put(&t->step[i], ST_TIE, 0, 0, c);
            else if (i % 4u == 2u) step_put(&t->step[i], ST_NOTE, 0, n, c);
            else step_put(&t->step[i], ST_REST, 0, 0, c);
        }
        ui.cursor = 4;
        break;
    case S_ROLL_TIES:
        t->p[P_ROOT] = 0; t->p[P_SCALE] = 1;
        for (i = 0; i < 16u; i++) {
            uint8_t n = LINE[i];
            uint32_t f = (i == 3u || i == 9u ? SF_SLIDE : 0u) | (i == 0u || i == 8u || i == 13u ? SF_ACCENT : 0u);
            if (LINE_T[i] == 0u) step_put(&t->step[i], ST_NOTE, f, 1, &n);
            else step_put(&t->step[i], LINE_T[i] == 1u ? ST_TIE : ST_REST, 0, 0, &n);
        }
        t->step[2].flags |= SF_SLIDE;                  /* (slides into a note, from before a tie) */
        ui.cursor = 9;
        break;
    case S_ROLL_LEN32:
        load_pat16(t, PATTERNS[0].note, PATTERNS[0].flags);
        t->p[P_SLEN] = 32;
        for (i = 16; i < 32u; i++) {
            uint8_t n = (uint8_t)(60 + (i * 5u) % 12u);
            if (i % 3u != 2u) step_put(&t->step[i], ST_NOTE, i % 8u == 0u ? SF_ACCENT : 0u, 1, &n);
        }
        ui.cursor = 20; song.playing = 1; t->seq_idx = 22;
        break;
    case S_ROLL_HIGH:
    case S_ROLL_LOW:
        for (i = 0; i < 16u; i += 2u) {
            uint8_t n = (uint8_t)(s == S_ROLL_HIGH ? 112 + (i * 7u) % 15u : (i * 7u) % 15u);
            step_put(&t->step[i], ST_NOTE, 0, 1, &n);
        }
        ui.cursor = 2;
        break;
    case S_ROLL_WIDE:
        t->p[P_VOICE] = V_POLY;
        for (i = 0; i < 16u; i += 2u) {
            uint8_t n[2] = {(uint8_t)(36 + i), (uint8_t)(72 + i)};
            step_put(&t->step[i], ST_NOTE, 0, 2, n);
        }
        ui.cursor = 4;
        break;
    default: break;
    }
    ui.bank = (uint8_t)(ui.cursor / 16u);
}

static void setup(int s)
{
    memset(kb_on, 0, sizeof kb_on);               /* no key held (roll_playing holds one) */
    live.req = live.cur = -1; live.mode = live.srec = live.dirty = 0; lys.nqc = 0;   /* (the song layer: off) */
    trk_live = NTRK;                              /* (the six awake but on *_tracks4) */
    if (s >= S_MOCK_HOME) {
        mock_state(s);
        return;
    }
    state();
    switch (s) {
    case S_HOME: song.octave = 2; song.rec = 1; usb.config = 1; break;
    case S_HOME_IDLE: song.playing = 0; song.batt_raw = 570; ui.hot_col = 1; ui.hot_t = 30; break;
    case S_MESSAGE: ui_say("LOADED ", "07 A VERY LONG PATTERN NAME"); break;
    case S_MESSAGE_KEY: ui_message("[SAVE] HOLD TO UNDO"); break;            /* a message with a keycap */
    case S_MESSAGE_NOFILE: ui_message(MSG_NOFILE "NO FILE"); break;   /* a message led by the no-file icon */
    case S_PRESETS: favorite_set(0, 4, 1); favorite_set(0, 5, 1); go_page(GR_BROWSE); break;
    case S_PRESETS_NOFAV: favorites.filter = 1; go_page(GR_BROWSE); break;
    case S_USER: song.playing = 0; up_store(3, "MY LONG BASS NAME"); up_store(4, "PAD"); ui.uslot = 3; go_page(GR_USER); break;
    case S_PHRASES: go_page(GR_PATS); break;
    case S_PROJECT: song.playing = 0; project_save(1); song.g[G_SLOT] = 2; go_page(GR_SLOTS); ui.act = 4; break;
    case S_TOOLS: go_page(GR_TOOLS); ui.act = 1; break;
    case S_SONG_EMPTY: song.playing = 0; go_page(GR_SONG); break;
    case S_SONG:
        song.playing = 0; project_save(0); project_save(1);
        chain_config.count = 3;
        chain_config.row[0] = (chain_row_t){0, 2}; chain_config.row[1] = (chain_row_t){1, 4}; chain_config.row[2] = (chain_row_t){2, 1};
        ui.song_row = 1; go_page(GR_SONG); chain_prepare(); events_block(32);
        break;
    case S_STEP: song.rec = 1; go_page(GR_ROLL); ui.cursor = 6; break;
    case S_PATTERN: go_title("PATTERN"); ui.cursor = 3; break;
    case S_FUGUE:                                       /* (0.6.52) heads 2 x2 +2, 3 1/2 REV -3, playing */
        for (uint32_t j = 0; j < 8u; j++) { uint8_t nn = (uint8_t)(60 + (j * 5u) % 12u); step_put(&TSEL->step[j], ST_NOTE, 0, 1, &nn); }
        TSEL->p[P_SLEN] = 8;
        fg_set[song.sel][0] = (fg_set_t){7, 0, 2}; fg_set[song.sel][1] = (fg_set_t){3, 1, -3};
        fg_head[song.sel][0].idx = 5; fg_head[song.sel][1].idx = 2; song.playing = 1; fg_ui = 1;
        go_page(GR_FUGUE);
        break;
    case S_PFLASH:                                      /* (0.6.51) a page changed by hand: its name big, held */
        go_title("LFO"); page_flash(); pf_ms = fm1_ms - 200u;
        break;
    case S_PFLASH_HOME:                                 /* (0.6.61) a track picked on HOME: its engine, "T1 HOME" */
        ui.home = 1; page_flash(); pf_ms = fm1_ms - 200u;
        break;
    case S_DXIMG:                                       /* (0.6.48) DRUM IMAGE 40 */
        set_engine_of(TSEL, ENGI_DRUM); TSEL->p[P_DXIMG] = 40; go_title("STEREO");
        break;
    case S_DXSEND:                                      /* (0.6.48) SEND: the snare to the REVERB, 70 % */
        set_engine_of(TSEL, ENGI_DRUM); dx_ui_lane = 1; dx_snd[1] = 3u << 6 | 47u; dx_lay[1] = 0x26; go_title("SOUND 4");
        break;
    case S_MORPH:                                       /* (0.6.45) ANALOG SAW, MORPH 50 */
        set_engine_of(TSEL, ENGI_ANALOG); TSEL->p[P_E0] = 0; TSEL->p[P_MORPH] = 50; go_page(GR_MORPH);
        break;
    case S_MUTATE:                                      /* (0.6.43) three tracks mutating, bar 5 */
        trk[0].p[P_MSND] = 2; trk[0].p[P_MPAT] = 4; trk[1].p[P_MSND] = 3; trk[1].p[P_MMODE] = 1; trk[3].p[P_MPAT] = 1;
        bar_n = 5; go_page(GR_MUTATE);
        break;
    case S_CHANCE: go_page(GR_CHANCE); step_set_chance(&TSEL->step[0], 65); break;
    case S_COMP:                                        /* (0.6.39) an ARP NOTES step: UP-DN x6 over two octaves */
    case S_COMP_TRIG:                                   /* .. a TRIG 3:4 */
    case S_COMP_ECHO:                                   /* (0.6.42) .. an ECHO x4, a JUMP, a PULSE */
        TSEL->step[0] = (step_t){ .note = {60, 63, 67}, .n = 3, .time = ST_NOTE, .flags = 0, .vel = 100 };
        TSEL->step[0].comp = s == S_COMP ? CP_ARPN : s == S_COMP_ECHO ? CP_ECHO : CP_TRIG;
        TSEL->step[0].carg = s == S_COMP ? CP_ARG(2u, 3u, 1u) : s == S_COMP_ECHO ? 2u : 7u;
        if (s == S_COMP_ECHO) { TSEL->step[10].comp = CP_JUMP; TSEL->step[10].carg = 2; TSEL->step[12].comp = CP_PULSE; }
        TSEL->step[4].comp = CP_TRIG; step_set_chance(&TSEL->step[6], 50); step_set_ratchet(&TSEL->step[8], 3);
        go_page(GR_COMP);
        break;
    case S_MOTION: go_page(GR_MOTION); break;
    /* 1.1.5, the REC layer (REC held): over HOME, the settings as they come (CLICK OFF, COUNT-IN OFF, LEVEL MID);
     * over STEP armed, CLICK REC, COUNT-IN 2 BARS, LEVEL HIGH (KNOB 2 just turned); a song playing on an empty
     * track (CLEAR dimmed: STOP TO EDIT) */
    case S_REC_LAYER: go_home(); ui.layer = LAYER_REC; break;
    case S_MSEQ: {                                   /* a rising, falling line over LEN 12, step 5 picked, playing */
        static const uint8_t L[16] = {10, 40, 70, 100, 127, 90, 60, 30, 0, 50, 110, 20, 80, 80, 80, 80};
        uint32_t k;
        for (k = 0; k < 16u; k++) TSEL->p[P_MS0 + k] = L[k];
        TSEL->p[P_MSLEN] = 12; ms_ui_step = 4; ms_clock = div_samples(2) * 6u + 3u;
        TSEL->ms_v = 60 * 258;
        go_title("MSEQ");
        break;
    }
    case S_DIST_PAGE: TSEL->p[P_DIST] = 70; TSEL->p[P_DTYPE] = 2; TSEL->p[P_DTONE] = 20; go_title("DIST"); break;
    /* (JIANT 0.5) the technical graphs (ui_tech.c) */
    case S_DLY2: song.g[G_WIDTH] = 90; song.g[G_DPIT] = 5; song.g[G_DSPRY] = 60; go_title("DLY 2"); break;
    case S_REVERB2: song.g[G_RMOD] = 80; song.g[G_RWIDE] = 100; go_title("REVERB 2"); break;
    case S_CHORUS: song.g[G_CDEPTH] = 90; go_title("CHORUS"); break;
    case S_MASTER: song.g[G_CLIP] = 60; song.g[G_PUNCH] = 50; song.g[G_DUCK] = 40; go_title("MASTER"); break;
    case S_MASTER_EQ:                                  /* +24 dB low shelf at 20 Hz: the extreme that used to fold */
        song.g[G_EQMODE] = 3; song.g[G_EQFREQ] = 0; song.g[G_EQGAIN] = 24; song.g[G_EQQ] = 64;
        go_title("MASTER EQ"); break;
    case S_RETRIG: case S_RETRIG_FREE:                 /* (3.4) LOFI BYTE's T.CLK, both clocks */
        set_engine_of(TSEL, ENGI_LOFI); TSEL->engine = TSEL->eng_req;
        TSEL->p[P_E1] = RW_BYTE; TSEL->p[P_E2] = 4; TSEL->p[P_LRTRG] = s == S_RETRIG_FREE;
        go_title("RETRIG"); break;
    case S_LFO_DEST: TSEL->p[P_LD_PIT] = 63; TSEL->p[P_LD_FLT] = -64; TSEL->p[P_LD_AMP] = 60;   /* (v1.12.1) los dos extremos: el tope tiene que leer +100 % */
        /* (FASE EXTRA) the LFO running, so the page draws its playhead, the level dot and the live bars: a still
         * LFO is a still page, and this frame is the one that has to prove they are drawn from state */
        TSEL->lfo_ph = 0x50000000u; TSEL->lfo_val = 18000; TSEL->lfo_fade = 32767;
        go_title("LFO DEST"); break;
    case S_MACRO_LAYER:                              /* M1: T1 CUT and T4's MRPH; M2: CLIP; M3 at 0, M4 none */
        go_home(); ui.layer = LAYER_MACRO;
        macro_v[0] = 90; macro_v[1] = 40; macro_v[3] = 127;
        trk[0].p[P_M1SRC] = MS_M1; trk[0].p[P_M1DST] = MD_CUT; trk[0].p[P_M1AMT] = 40;
        trk[3].p[P_M2SRC] = MS_M1; trk[3].p[P_M2DST] = MD_E1; trk[3].p[P_M2AMT] = -20;
        trk[1].p[P_M1SRC] = MS_M1 + 1; trk[1].p[P_M1DST] = MD_CLIP; trk[1].p[P_M1AMT] = 63;
        trk[2].p[P_M1SRC] = MS_M1 + 2; trk[2].p[P_M1DST] = MD_REV; trk[2].p[P_M1AMT] = 30;
        break;
    case S_REC_LAYER_SET: song.rec = 1; go_page(GR_ROLL); ui.cursor = 6; rp_put(RP_CLICK, 1u); rp_put(RP_COUNTIN, 2u);
        rp_put(RP_LEVEL, 2u); ui.layer = LAYER_REC; ui.hot_col = 1; ui.hot_t = 30; break;
    case S_REC_LAYER_SONG: drum(1); track_defaults_steps(TSEL); go_page(GR_SONG); chain.running = 1; ui.layer = LAYER_REC;
        break;
    /* 1.1 (Discussion #131): the count-in over the page: 1 BAR on its second beat (3 to go); 2 BARS, the first bar's
     * first beat (STEP under it); the MENU's AUDIO tab with CLICK REC selected, COUNT-IN 1 BAR */
    case S_COUNTIN: song.playing = 0; song.rec = 1; cin_total = 4; cin_left = 3; go_home(); break;
    case S_COUNTIN2: song.playing = 0; song.rec = 1; cin_total = 8; cin_left = 8; go_page(GR_ROLL); break;
    case S_MENU_AUDIO: ui.menu = 1; ui.menu_sel = MI_CLICK; rp_put(RP_CLICK, 1u); rp_put(RP_COUNTIN, 1u); break;
    /* 1.2: the header's three slots (ui_draw.c draw_head): playing with the selected track armed; another track armed;
     * the BPM being turned (the accent's); BPM LOCK ON (the lock right of the BPM), and its message after a turn;
     * GLO with the tempo turned and BPM LOCK ON (the label right of the lock); the metronome on the bar's 1st beat
     * (the accent's) and its 2nd (mirrored) */
    case S_HEAD_PLAY_REC: song.rec = 1u << song.sel; go_home(); break;
    case S_HEAD_REC_OTHER: song.rec = 1u << ((song.sel + 2u) % NTRK); go_home(); break;
    case S_HEAD_BPM_TURN: song.g[G_BPM] = 128; ui.roll_bpm = 128; ui.bpm_t = 40; go_home(); break;
    case S_HEAD_BPM_LOCK: ui_prefs |= PREF_BPM_LOCK; go_home(); break;
    case S_HEAD_BPM_LOCKED: ui_prefs |= PREF_BPM_LOCK; go_home(); ui_message("BPM LOCKED"); break;
    case S_HEAD_GLO_TURN: ui_prefs |= PREF_BPM_LOCK; go_home(); ui.layer = LAYER_GLO; ui.bpm_t = 40; break;
    case S_HEAD_DOWNBEAT: clk_step = 1; song.rec = 1u << song.sel; go_home(); break;
    case S_HEAD_BEAT_2: clk_step = 5; song.rec = 1u << song.sel; go_home(); break;
    case S_DRUM: drum(0); go_page(GR_ROLL); ui.cursor = 4; ui.lane = 1; trk[3].seq_idx = 9; break;
    case S_DRUM_HAND: drum(1); go_page(GR_ROLL); ui.lane = 5; ui.cursor = 7; break;
    case S_DRUM_CYM: drum(2); go_page(GR_ROLL); ui.lane = 7; break;
    case S_MIXER:
        go_page(GR_TRK);
        trk[0].p[P_LEVEL] = 100; trk[1].p[P_LEVEL] = 84; trk[2].p[P_LEVEL] = 64; trk[3].p[P_LEVEL] = 110;
        trk[0].p[P_PAN] = -20; trk[1].p[P_PAN] = 24; trk[3].p[P_PAN] = -4; trk[1].p[P_REV] = 80;
        trk[2].p[P_MUTE] = 1; trk[3].p[P_MUTE] = 1; song.rec = 2u | 8u; trk[0].peak = 9000;
        break;
    case S_MIXER_T4:                             /* (0.6.22) TRACKS 4: T5, T6 asleep, grey, OFF */
        go_page(GR_TRK); trk_live = 4; break;
    case S_HOME_T4: trk_live = 4; break;
    case S_MIXER_PAN:                            /* PAN just turned, the ends of each knob, OFF, armed while stopped */
        go_page(GR_TRK); song.playing = 0; song.sel = 1;
        trk[0].p[P_LEVEL] = 127; trk[1].p[P_LEVEL] = 0; trk[2].p[P_LEVEL] = 1; trk[3].p[P_LEVEL] = 104;
        trk[0].p[P_PAN] = -64; trk[1].p[P_PAN] = 63; trk[2].p[P_PAN] = 0; trk[3].p[P_PAN] = 1;
        trk[0].p[P_REV] = 127; trk[2].p[P_REV] = 1; trk[3].p[P_MUTE] = 1;
        song.rec = 1u | 8u; ui.hot_col = 3; ui.hot_t = 30;
        break;
    case S_ENV: go_title("ENV"); ui.hot_col = 2; ui.hot_t = 30; break;
    case S_ENVDEST: go_title("ENV DEST"); break;
    case S_LFO: go_title("LFO"); break;
    case S_MACROS:                                  /* (FASE 8) the MACROS page: four values, two of them driving
                                                     * the matrix from the slots of this track */
        macro_set(0, 90); macro_set(1, 32); macro_set(2, 0); macro_set(3, 120);
        TSEL->p[P_M1SRC] = MS_M1; TSEL->p[P_M1DST] = MD_CUT; TSEL->p[P_M1AMT] = 40;
        TSEL->mx[0][0] = MS_M1 + 1; TSEL->mx[0][1] = MD_PAN; TSEL->mx[0][2] = -20;
        TSEL->mx[1][0] = MS_M1; TSEL->mx[1][1] = MD_REV; TSEL->mx[1][2] = 25;
        go_page(GR_MACROS);
        break;
    case S_MOD: TSEL->p[P_M1SRC] = 1; TSEL->p[P_M1DST] = 2; TSEL->p[P_M1AMT] = 40; TSEL->p[P_M2SRC] = 6;
        TSEL->p[P_M2DST] = 14; TSEL->p[P_M2AMT] = -64; mod_ui_slot = 1; go_title("MOD"); break;
    case S_FX: go_title("FX"); break;
    case S_SLICER: song.g[G_SLMODE] = 1; go_title("SLICER"); break;   /* (0.6.3: the bus) */
    case S_SLBUS: song.g[G_SLMODE] = 2; song.g[G_SLT1 + 2] = 0; song.g[G_SLFX] = 0; go_title("SL BUS 2"); break;
    case S_SLPITCH: {
        static const int8_t PS[16] = {0, 7, 12, -5, 0, 3, 24, -12, 5, 0, -24, 7, 12, 0, 0, 0};
        for (uint32_t k = 0; k < 16u; k++) song.g[G_SLP0 + k] = PS[k];
        song.g[G_SLMODE] = 2; song.g[G_SLPLEN] = 12; sl_ui_step = 2; go_title("SL PITCH");
        break;
    }
    case S_DLY: go_title("DLY"); break;
    case S_SCL_SCALE:                        /* (2.8) the SCL tools: a pentatonic (the D1 case), the chords of
                                              * a major key, its voicings, dorian's intervals, a progression and
                                              * the twelve keys of CHR (the widest grid) */
        TSEL->p[P_ROOT] = 0; TSEL->p[P_SCALE] = 6; go_title("SCALE"); break;
    case S_SCL_CHORD:
        TSEL->p[P_ROOT] = 0; TSEL->p[P_SCALE] = 1; TSEL->p[P_CHRD] = 1; go_title("CHORD"); break;
    case S_SEQ_TOOLS_EDITS:
        sq_op = 2; sq_amt = 3; go_title("TOOLS"); break;
    case S_FX_BUSES:                          /* (6.1) the routing console: the delay link, its three params */
        song.g[G_DMIX] = 71; song.g[G_RSIZE] = 71; song.g[G_CDEPTH] = 47; song.g[G_DTIME] = 40;
        song.g[G_DFDBK] = 60; song.g[G_SLMODE] = 1; song.g[G_SLPAT] = 0x5A; song.g[G_SLDEP] = 100;
        song.g[G_PUNCH] = 80; song.g[G_DUCK] = 60;
        {   /* the page draws the buses' peaks: give it a mix to draw, as the engine would while it sounds */
            static const int32_t VU[8] = {3200, 4400, 3600, 2600, 5200, 4600, 5400, 4200};
            uint32_t k;
            for (k = 0; k < 8u; k++) fx_vu[k] = VU[k];
        }
        fxb_tab = 2; go_title("BUSES"); break;
    case S_SCL_TUNE:                          /* (FASE 7) the twelve cents of the instrument: the circle, a spoke
                                               * a note, the profile's offset and the four numbers the knobs own */
        TSEL->p[P_ROOT] = 0; go_title("TUNE"); break;
    case S_SCL_TUNE_PLAY:                     /* (v2.3.12) a hand on the keys: C E G, so the circle lights them and
                                               * the foot line names the chord */
        TSEL->p[P_ROOT] = 0; TSEL->nheld = 3; TSEL->held[0] = 48; TSEL->held[1] = 52; TSEL->held[2] = 55;
        go_title("TUNE"); break;
    case S_SCL_PROG:
        TSEL->p[P_ROOT] = 0; TSEL->p[P_SCALE] = 2; scl_prog = 0; go_title("PROG"); break;
    case S_SHIFT: TSEL->p[P_SOFS] = -3; TSEL->p[P_POFS] = 7; go_title("SHIFT"); break;
    case S_ARP:                              /* (FASE 3) an arp that is really running: three keys held, UPDN over two
                                              * octaves, the route's fifth step sounding (64), so the screen draws
                                              * its keyboard, route and meters from state, not from a pattern */
        TSEL->p[P_AMODE] = AM_UPDN; TSEL->p[P_ARATE] = 2; TSEL->p[P_AOCT] = 2; TSEL->p[P_AGATE] = 80;
        TSEL->p[P_ASWING] = 25; TSEL->p[P_APROB] = 100; TSEL->p[P_AHOLD] = 0; TSEL->p[P_AORDER] = 0;
        TSEL->nheld = 3; TSEL->held[0] = 48; TSEL->held[1] = 52; TSEL->held[2] = 55;
        TSEL->arp_idx = 5; TSEL->arp_note = 64; TSEL->arp_ch[0] = TSEL->arp_ch[1] = TSEL->arp_ch[2] = 0;
        TSEL->arp_pos = div_samples(2) / 3;              /* (FASE 8) a third into the step, gate still open */
        TSEL->arp_off = div_samples(2) * 80 / 128 - TSEL->arp_pos / 2;
        go_title("ARP"); break;
    case S_VOICE: go_title("VOICE"); break;
    case S_GLOBAL: go_title("GLOBAL"); break;
    case S_SYSTEM: go_title("SYSTEM"); break;
    case S_MONITOR: go_title("MONITOR"); break;   /* (QG-1) GLO > MONITOR: the live diagnostics */
    case S_EDIT_ANALOG: go_title("EDIT 1"); break;
    case S_EDIT_DIGITAL: eng(E_FM); go_title("EDIT 1"); break;
    case S_OP_ENV: eng(1); go_title("OP1 ENV"); break;
    case S_EDIT_WHEEL: eng(7); go_title("EDIT 1"); ui.hot_col = 1; ui.hot_t = 30; break;
    case S_EDIT_SAMPLE: eng(5); go_title("EDIT 1"); break;   /* (JIANT: SAMPLE retired; VOICE in its place) */
    case S_EDIT_GRAIN: eng(11); go_title("EDIT 2"); break;   /* (GRAIN retired: NOISE's second page) */
    case S_EDIT_LOFI: eng(3); go_title("EDIT 1"); break;        /* (3.4) the chip panel, T.CLK NOTE */
    case S_EDIT_LOFI_FREE: eng(3); TSEL->p[P_LRTRG] = 1; go_title("EDIT 2"); break;   /* .. and FREE */
    case S_EDIT_PHASE: eng(2); go_title("EDIT 1"); break;       /* (3.6) PHASE's own screen */
    /* (FASE 2) the contextual CHARACTER page (ANALOG's two slots, VOICE's three) and LFO SHAPE */
    case S_EDIT_CHAR: eng(0); TSEL->p[P_X0] = 80; TSEL->p[P_X1] = 34; go_title("CHARACTER"); break;
    case S_EDIT_VOICE_CHAR: eng(5); TSEL->p[P_X0] = 96; TSEL->p[P_X1] = 44; TSEL->p[P_MORPH] = 70; go_title("CHARACTER"); break;
    case S_LFO_SHAPE: TSEL->p[P_X2] = 40; TSEL->p[P_X3] = 90; go_title("LFO SHAPE"); break;
    case S_EDIT_FILTER_SHELF: TSEL->p[P_FTYPE] = 7; TSEL->p[P_E5] = 80; TSEL->p[P_E6] = 40; go_page(GR_FILTER); break;
    case S_EDIT_FILTER_NOTCH: TSEL->p[P_FTYPE] = 6; TSEL->p[P_E5] = 90; TSEL->p[P_E6] = 70; go_page(GR_FILTER); break;
    case S_EDIT_FILTER_VOWEL: TSEL->p[P_FTYPE] = 4; TSEL->p[P_E5] = 20; TSEL->p[P_E6] = 30; go_page(GR_FILTER); break;
    case S_EDIT_FILTER_SCREAM: TSEL->p[P_FTYPE] = 5; TSEL->p[P_E5] = 110; TSEL->p[P_E6] = 120; go_page(GR_FILTER); break;
    case S_FM_OP_ENV:                                    /* (v2.3.5) OP ENV: the operator envelope, now in depth */
        eng(ENGI_FM6); go_title("OP ENV"); break;
    case S_EDIT_FILTER:                                  /* (v2.3.4) the FILTER page draws its response now */
        TSEL->p[P_FTYPE] = 0; TSEL->p[P_E5] = 98; TSEL->p[P_E6] = 84; go_page(GR_FILTER); break;
    case S_TILT: TSEL->p[P_HARM] = 45; go_page(GR_TILT); break;         /* (v1.12.9) the page and its graph:
                                                    * go_title() searches the page FAMILY the UI is in, and this file
                                                    * starts at HOME, so it landed on HOME and the frame lied */
    case S_LFO_CURVE:
        TSEL->p[P_LSHP] = 40;
        go_page(GR_LFO);
        {   /* GR_LFO is the LFO page's graph too: this page is the one whose KNOB 1 is the curve */
            uint32_t i;
            for (i = 0; i < NPAGES; i++)
                if (PAGES[i].graph == GR_LFO && PAGES[i].id[0] == P_LSHP)
                    ui.page = (uint8_t)i;      /* go_page(GR_LFO) already put the UI in the LFO family */

        }
        break;
    case S_ALG1: case S_ALG2: case S_ALG3: case S_ALG4: case S_ALG5: case S_ALG6: case S_ALG7: case S_ALG8:
        eng(1); TSEL->p[P_E0] = (int16_t)(s - S_ALG1);      /* the 8 DIGITAL charts; FB on the odd ones, IDX high .. 0 */
        TSEL->p[P_E6] = (s - S_ALG1) & 1 ? 40 : 0; TSEL->p[P_E4] = (int16_t)((S_ALG8 - s) * 18);
        go_title("EDIT 2"); break;
    case S_OP_LEVEL: eng(1); TSEL->p[P_E0] = 1; TSEL->p[P_FM4_LEVEL] = 0; go_title("OP LEVEL");   /* op 4 silent, op 3 hot */
        ui.hot_col = 2; ui.hot_t = 30; break;
    /* FM6's algorithm charts: 1 as it is; 5 with FB +3 just turned; 22 on EDIT 2, DTUN just turned (the carriers);
     * 32 with operator 6 at output level 0, MLVL just turned (no routes: nothing in ACCENT but nothing either) */
    case S_FM6_ALG1: eng(ENGI_FM6); TSEL->p[P_E0] = 1; go_title("EDIT 1"); break;
    /* DRUM-X: the specimen at rest; then a kick and a hat just struck (their petals swell and light up) */
    case S_DRUMX: eng(ENGI_DRUM); TSEL->p[P_E0] = 40; go_title("EDIT 1"); break;
    case S_DRUMX_HIT:
        eng(ENGI_DRUM); TSEL->p[P_E0] = 100; go_title("EDIT 1");
        trk_note_on(TSEL, 36, 120); trk_note_on(TSEL, 42, 100); events_block(256);
        break;
    /* EDIT > SOUND / SOUND 2: the snare's patch B (its organ singled out, the anatomy at B), PTCH just turned */
    case S_DX_SOUND:
        eng(ENGI_DRUM); dx_ui_lane = 1; dx_ui_side = 1; dx_ui_seen = last_note;
        go_title("SOUND"); ui.hot_col = 2; ui.hot_t = 30;
        break;
    case S_DX_SOUND2:
        eng(ENGI_DRUM); dx_ui_lane = 0; dx_ui_side = 0; dx_ui_seen = last_note;
        go_title("SOUND 2");
        break;
    case S_FM6_ALG5: eng(ENGI_FM6); TSEL->p[P_E0] = 5; TSEL->p[P_E1] = 3; go_title("EDIT 1"); ui.hot_col = 1; ui.hot_t = 30; break;
    case S_FM6_ALG22: eng(ENGI_FM6); TSEL->p[P_E0] = 22; TSEL->p[P_E6] = 40; go_title("EDIT 2"); ui.hot_col = 2; ui.hot_t = 30; break;
    case S_FM6_ALG32:
        eng(ENGI_FM6); TSEL->p[P_E0] = 32; fm6_patch[song.sel][FP_OL] = 0; fm6_pgen[song.sel]++;   /* (op 6: the patch's first) */
        go_title("EDIT 1"); ui.hot_col = 2; ui.hot_t = 30;
        break;
    case S_CONFIRM_SEQ: ui.confirm = CF_CLEAR_SEQ; ui.confirm_trk = 2; break;
    case S_CONFIRM_PROJ: ui.confirm = CF_OVR_PROJ; ui.confirm_trk = 0; break;
    case S_CONFIRM_USER: song.playing = 0; up_store(6, "A VERY LONG SOUND NAME"); ui.confirm = CF_OVR_USER; ui.confirm_trk = 6; break;
    case S_CONFIRM_PAT: ui.confirm = CF_LOAD_PAT; ui.confirm_trk = 0; ui.ppick = 4; break;
    case S_CONFIRM_MOTION: ui.confirm = CF_CLEAR_MOTION; ui.confirm_trk = 3; break;
    case S_CONFIRM_ERASE: song.playing = 0; up_store(6, "A VERY LONG SOUND NAME"); ui.confirm = CF_ERASE_USER; ui.confirm_trk = 6; break;
    case S_MENU: ui.menu = 1; ui.menu_sel = 0; song.rec = 1; break;
    case S_MENU_SPEAKER: ui.menu = 1; ui.menu_sel = MI_LOWCUT; settings.lowcut = 2; break;
    case S_ABOUT: ui.menu = 2; ui.menu_scroll = 0; break;
    case S_ABOUT_REC: ui.menu = 2; ui.menu_scroll = 0; song.rec = 1; break;          /* the REC mark beside OCT- BACK */
    case S_ABOUT_CREDITS: ui.menu = 2; ui.menu_scroll = 360; break;
    case S_ABOUT_END: ui.menu = 2; ui.menu_scroll = (uint16_t)menu_scroll_max(); break;
    case S_UBOOT: ui.uboot = 3; break;
    /* the header's battery at each stock level (raw ADC: under 531, 531.., 561.., 591..) and on USB power */
    case S_BATT0: usb.config = 0; song.batt_raw = 500; go_home(); break;
    case S_BATT1: usb.config = 0; song.batt_raw = 540; go_home(); break;
    case S_BATT2: usb.config = 0; song.batt_raw = 570; go_home(); break;
    case S_BATT3: usb.config = 0; song.batt_raw = 600; go_home(); break;
    case S_BATT_USB: usb.config = 1; usb.suspended = 0; song.batt_raw = 500; go_home(); break;
    case S_MOTION_REC: song.rec = 1u << song.sel; go_page(GR_MOTION); break;    /* recording into the motion */
    case S_MOTION_OFF: song.playing = 0; go_page(GR_MOTION); ui.act = 4; break;  /* stopped, CLEAR picked */
    case S_MOTION_CARD: {                                          /* #63: HOME, MOTION drives KNOB 1 and 3 (3 just turned) */
        const engine_t *en = ENGINES[TSEL->eng_req];
        motion_set_event(TSEL, 2, en->knob[0], TSEL->p[en->knob[0]]);
        motion_set_event(TSEL, 6, en->knob[2], TSEL->p[en->knob[2]]);
        go_home(); ui.hot_col = 2; ui.hot_t = 30;
        break;
    }
    case S_SONG_HOME:                            /* the song playing: the disc and its row in the header */
        song.playing = 0; project_save(0); project_save(1);
        chain_config.count = 2;
        chain_config.row[0] = (chain_row_t){0, 2}; chain_config.row[1] = (chain_row_t){1, 4};
        go_page(GR_SONG); chain_prepare(); events_block(32); go_home(); ui.msg_t = 0;
        break;
    /* the FX layer's map: held alone; REPEAT 1/16 + LPF + a mute playing with the macros turned;
     * at 72 BPM: a REPEAT 1/16 waiting for its 1/16 (shown THEME) beside LPF playing, and REPEAT 1/8
     * held, too long at that tempo (dimmed) */
    case S_FX_PEEK: go_title("ENV"); ui.layer = LAYER_FX; break;
    case S_FX_HELD:
        go_home(); ui.layer = LAYER_FX;
        perf_held = perf_act = PF_BIT(PF_R16) | PF_BIT(PF_LPF) | PF_BIT(PF_M1 + 1);
        perf_k[0] = -40; perf_k[1] = 25; perf_k[3] = 30; ui.hot_col = 0; ui.hot_t = 30;
        break;
    case S_FX_WAIT:
        song.playing = 1; song.g[G_BPM] = 72; ui.layer = LAYER_FX;
        perf_held = PF_BIT(PF_R16) | PF_BIT(PF_R8) | PF_BIT(PF_LPF); perf_act = PF_BIT(PF_LPF);
        perf_k[2] = 100;
        break;
    case S_FX_HARM:                                 /* (TONIC: no harmonizer) HPF playing, KNOB 4 DEPTH turned */
        song.playing = 1; ui.layer = LAYER_FX;
        perf_held = perf_act = PF_BIT(PF_HPF);
        perf_k[3] = 60; ui.hot_col = 3; ui.hot_t = 30;
        break;
    case S_REVERB: go_title("REVERB"); song.g[G_RTYPE] = 1; ui.hot_col = 0; ui.hot_t = 30; break;   /* TYPE: SPRING */
    case S_REVERB_RESO: go_title("REVERB"); song.g[G_RTYPE] = 3; song.g[G_RDAMP] = 2; song.g[G_RPRE] = 4; break;   /* (0.6.5) PITCH, FOLW */
    case S_REVERB_CLOUD: go_title("REVERB"); song.g[G_RTYPE] = 4; song.g[G_RSIZE] = 108; song.g[G_RRATE] = 96;
        song.g[G_RMOD] = 72; song.g[G_RPRE] = 12; fx_vu[5] = 21000; break;   /* (3.2) the second reverb picture: a
        * swarm that breathes and puffs -- rendered so RESO and CLOUD can be compared side by side, not described */
    case S_MENU_HOLD: ui.menu = 1; ui.menu_sel = MI_HOLD; settings_hold = 2; break;
    case S_MENU_LEDS: ui.menu = 1; ui.menu_sel = MI_LEDS; settings_leds = LEDS_INV; break;
    case S_MENU_END: ui.menu = 1; ui.menu_sel = MI_COUNT - 1u; ui_prefs = 0xFF; ui_rec_prefs = 0x2A; break;   /* the last row,
                                                     * every flag set (CLICK ON, LEVEL HIGH, COUNT-IN 2 BARS) */
    /* the MENU's tabs (1.0.5): menu DISPLAY (COLOR), menu_hold CONTROL, menu_speaker AUDIO, menu_system SYSTEM (USB
     * SERIAL); menu_slide: from DISPLAY to CONTROL with ANIM ON, the frame half way (draw) */
    case S_MENU_SYSTEM: ui.menu = 1; ui.menu_sel = MI_SERIAL; break;
    case S_MENU_SLIDE: ui.menu = 1; ui.menu_sel = MI_ACCEL; ui_prefs |= PREF_LATCH; break;
    case S_MENU_EXTRA: ui.menu = 1; ui.menu_sel = MI_SELHOME; break;   /* the fifth tab, its only row (the star) */
    /* the GLO SCL EDIT layers (ui_layer.c): just opened (a peek), and in use: GLO with T2 muted, T3 soloed (its key
     * held) and KNOB 1 turned; with CLK EXT (TAP dimmed); SCL at D# minor, KNOB 2 turned; EDIT on DIGITAL preset 3,
     * a favourite; a user preset; the hint after a tap */
    case S_GLO_PEEK: go_title("ENV"); ui.layer = LAYER_GLO; break;
    case S_GLO_ACTIVE:
        go_home(); ui.layer = LAYER_GLO; trk[1].p[P_MUTE] = 1; perf_solo = 4; trk[0].p[P_LEVEL] = 90;
        ui.hot_col = 0; ui.hot_t = 30;
        break;
    case S_GLO_EXT: go_home(); ui.layer = LAYER_GLO; song.g[G_CLOCK] = 1; trk[0].p[P_MUTE] = trk[3].p[P_MUTE] = 1; break;
    case S_SCL_PEEK: go_title("ENV"); ui.layer = LAYER_SCL; break;
    case S_SCL_ACTIVE: go_home(); ui.layer = LAYER_SCL; TSEL->p[P_ROOT] = 3; TSEL->p[P_SCALE] = 2; ui.hot_col = 1; ui.hot_t = 30; break;
    case S_EDIT_PEEK: go_title("EDIT 1"); ui.layer = LAYER_EDIT; break;
    case S_EDIT_ACTIVE: eng(E_FM); apply_preset_to(TSEL, 2); favorite_set(E_FM, 2, 1); go_home(); ui.layer = LAYER_EDIT;
        ui.hot_col = 0; ui.hot_t = 30; break;
    case S_EDIT_DRUM: eng(ENGI_DRUM); go_home(); dx_mute_set(DXM_LANE(2) | DXM_LANE(6)); ui.layer = LAYER_EDIT; break;
    case S_EDIT_USER: song.playing = 0; eng(7); up_store(6, "MY LONG WHEEL NAME"); up_load(6); favorite_set(NENGINES, 6, 1);
        go_home(); ui.layer = LAYER_EDIT; break;
    case S_LAYER_HINT: go_page(GR_TRK); ui.msg_t = 0; layer_tap(LAYER_GLO); break;
    /* #83: locked open by a double tap (the lock after the header's name): EDIT and FX */
    case S_LAYER_LOCK: go_title("ENV"); ui.layer = LAYER_EDIT; break;   /* (TONIC: no lock; the map as held) */
    case S_LAYER_LOCK_FX: go_title("ENV"); ui.layer = LAYER_FX; break;
    /* JIANT: the song layer, section B playing, SONG mode, SONG REC on; then a quick chain being tapped */
    case S_LAYER_SONG: go_home(); ui.layer = LAYER_SAVE; live.cur = 1; live.mode = 1; live.srec = 2; live.dirty = 4; break;
    case S_LAYER_SONG_CHAIN:
        go_home(); ui.layer = LAYER_SAVE; live.cur = 0; live.req = 2;
        lys.nqc = 4; lys.qc[0] = 0; lys.qc[1] = 1; lys.qc[2] = 1; lys.qc[3] = 2;
        break;
    /* 1.2 SEQ TOOLS (SEQ held on STEP): a melodic track (the sequence's tools), the DRUM grid (+ BEAT, the lane's tools,
     * the lanes; CLAP selected), a song playing (every tool dimmed: STOP TO EDIT) */
    case S_SEQ_TOOLS: go_page(GR_ROLL); ui.layer = LAYER_SEQ; break;
    case S_SEQ_TOOLS_DRUM: drum(0); go_page(GR_ROLL); ui.lane = 2; ui.layer = LAYER_SEQ; break;
    case S_SEQ_TOOLS_SONG: drum(1); go_page(GR_ROLL); ui.lane = 5; chain.running = 1; ui.layer = LAYER_SEQ; break;
    /* NAME (ui_name.c): USER SAVE prefilled; a letter cycling (RS: S, R next); 123 on a project; an empty project name
     * (the placeholder); 12 of the widest letters, the cursor past them; playing (OCT+ dim) */
    case S_NAME_USER: song.playing = 0; go_page(GR_USER); ui.uslot = 6; name_open(NK_USER_SAVE, 6); break;
    case S_NAME_TYPING:
        song.playing = 0; go_page(GR_USER); name_open(NK_USER_SAVE, 6);
        str_cpy(nm.s, "SUB BAS", sizeof nm.s); nm.len = 7; nm.cur = 6; nm.key = 9; nm.tap = 1; nm.t = fm1_ms;
        break;
    case S_NAME_123:
        song.playing = 0; go_page(GR_SLOTS); name_open(NK_PROJ_SAVE, 1);
        str_cpy(nm.s, "LIVE 2026", sizeof nm.s); nm.len = 9; nm.cur = 5; nm.num = 1;
        break;
    case S_NAME_EMPTY: song.playing = 0; go_page(GR_SLOTS); proj_name[0] = 0; name_open(NK_PROJ_SAVE, 2); break;
    case S_NAME_FULL:
        song.playing = 0; up_store(4, "PAD"); go_page(GR_USER); name_open(NK_USER_RENAME, 4);
        str_cpy(nm.s, "MWMWMWMWMWMW", sizeof nm.s); nm.len = nm.cur = 12;
        break;
    case S_NAME_PLAYING: go_page(GR_USER); name_open(NK_USER_SAVE, 6); ui_message("STOP TO SAVE"); break;
    case S_PROJECT_NAMED:
        song.playing = 0; project_save_as(0, "LOFI JAM"); project_save_as(1, "MWMWMWMWMWMW"); project_save_as(2, "");
        song.g[G_SLOT] = 2; go_page(GR_SLOTS); ui.act = 4; ui.msg_t = 0;
        break;
    case S_SONG_NAMED:
        song.playing = 0; project_save_as(0, "LOFI JAM"); project_save_as(1, "MWMWMWMWMWMW");
        chain_config.count = 3;
        chain_config.row[0] = (chain_row_t){0, 2}; chain_config.row[1] = (chain_row_t){1, 4}; chain_config.row[2] = (chain_row_t){2, 1};
        ui.song_row = 0; go_page(GR_SONG); ui.msg_t = 0;
        break;
    case S_ROLL_EMPTY: case S_ROLL_ACID: case S_ROLL_CHORDS: case S_ROLL_TIES: case S_ROLL_LEN32: case S_ROLL_HIGH:
    case S_ROLL_LOW: case S_ROLL_WIDE: case S_ROLL_PLAYING: roll_scene(s); break;
    /* 1.1 parameter locks (ui_input.c lock_*): the roll's steps with a lock marked under them; a step held (the note
     * key of its entry) shows what KNOB 1..4 lock (HOME's: ANALOG E5 E6 ATK REL), the locked ones bright; the DRUM grid
     * with its marks over the steps; a step key held after FX (DIST CHO DLY REV, REV and DLY locked); AUTOMATION's
     * LOCK count */
    case S_ROLL_LOCKS: case S_ROLL_LOCK_HELD:
        roll_scene(S_ROLL_ACID);
        motion_set_lock(TSEL, 2, P_REV, 100); motion_set_lock(TSEL, 6, P_E4, 20); motion_set_lock(TSEL, 6, P_ATK, 90);
        motion_set_lock(TSEL, 9, P_E5, 110); motion_set_lock(TSEL, 13, P_REV, 80);
        if (s == S_ROLL_LOCK_HELD) {
            ui.plk_src = 0;
            ui.entry_open = 1;
            fm1_in.notes = 1u << 10;
            ui.hot_col = 0; ui.hot_t = 30;
        }
        break;
    case S_DRUM_LOCKS: case S_DRUM_LOCK_HELD:
        drum(0); go_page(GR_ROLL); ui.cursor = 4; ui.lane = 1; trk[3].seq_idx = 9;
        motion_set_lock(TSEL, 2, P_E1, 90); motion_set_lock(TSEL, 4, P_REV, 100); motion_set_lock(TSEL, 4, P_DLY, 70);
        motion_set_lock(TSEL, 8, P_E2, 30); motion_set_lock(TSEL, 15, P_E1, 40);
        if (s == S_DRUM_LOCK_HELD) {
            uint32_t i;
            for (i = 0; i < NPAGES && PAGES[i].graph != GR_FX; i++)
                ;
            ui.plk_src = (uint8_t)(i + 1u);
            fm1_in.notes = 1u << key_at(0, 4);
            ui.hot_col = 3; ui.hot_t = 30;
        }
        break;
    case S_MOTION_LOCKS:
        motion_set_event(TSEL, 1, P_REV, 40); motion_set_lock(TSEL, 2, P_REV, 100); motion_set_lock(TSEL, 6, P_ATK, 90);
        go_page(GR_MOTION);
        break;
    /* 1.1.5 SEQ > AUTO LIST (ui_events.c): locks and automation events of the track, the 4th row selected, its
     * VALUE just turned; empty (+ ADD LOCK: step 5, the first knob of HOME); a DRUM track's long list, scrolled
     * (its lane levels, E names, the last row), playing */
    case S_AUTO_LIST:
        motion_set_event(TSEL, 0, P_LRATE, 70); motion_set_lock(TSEL, 2, P_REV, 100); motion_set_lock(TSEL, 2, P_ED_FLT, -30);
        motion_set_lock(TSEL, 6, P_ATK, 90); motion_set_lock(TSEL, 6, P_E4, 20); motion_set_event(TSEL, 8, P_PAN, -40);
        motion_set_lock(TSEL, 11, P_LD_FLT, 50); motion_set_lock(TSEL, 13, P_DLY, 80); motion_set_lock(TSEL, 15, P_GLIDE, 60);
        go_page(GR_EVENTS); ui.ev_row = 3; ui.hot_col = 3; ui.hot_t = 30;
        break;
    case S_AUTO_LIST_ADD: ui.cursor = 4; go_page(GR_EVENTS); break;
    case S_AUTO_LIST_DRUM: {
        uint32_t i;
        drum(0); go_page(GR_ROLL);
        for (i = 0; i < 12u; i++)
            motion_set_lock(TSEL, i, i & 1u ? P_LN0 + i % 8u : P_E0 + i % 8u, 100);
        motion_set_event(TSEL, 15, P_REV, 127);
        go_page(GR_EVENTS); ui.ev_row = 13; song.playing = 1;
        break;
    }
    case S_USER_FOOT: song.playing = 0; up_store(3, "MY BASS"); ui.uslot = 3; go_page(GR_USER); break;   /* EDIT NAME lit */
    default: break;
    }
    if (s != S_FUGUE)
        memset(fg_set, 0, sizeof fg_set);
    if (s != S_PFLASH && s != S_PFLASH_HOME)      /* (0.6.51) the page's big name: its own screen only (the clock stands */
        pf_on = 0;                                /* still here: it would never go) */
}
static void draw(int s)
{
    nscr = npend = nrules = 0;
    ntight = 0;
    tight[0] = 0;
    memset(host_screen, 0, sizeof host_screen); gfx_forget();
    if (s == S_CALIBRATION) {                     /* the blocking setup screen: its two drawing steps */
        setup_title();
        setup_show("TURN RIGHT", "ALGORITHM");
        return;
    }
    if (s == S_SPLASH) {                          /* the power-on splash (main.c, before the UI): its lines, the version
                                                   * shown FELUCCA_VERSION (run_tests.sh: src/felucca.c's) */
        /* (v2.6.0 splash cleanup) the splash draws SPLASH_LINES = {FELUCCA_VERSION, ""}: the version
         * alone, the name line was removed on purpose, so the lint asks for exactly that. */
        /* (v2.7.0) the splash carries its tagline again: SPLASH_LINES = {FELUCCA_VERSION,
         * "QUANTUM GAMMAWAVE // QG-1"}, so the lint asks for both, in order. */
        static const char WANT[] = FELUCCA_VERSION "|QUANTUM GAMMAWAVE // QG-1";
        splash_seen[0] = 0;
        in_splash = 1;
        draw_splash();
        in_splash = 0;
        {   /* the signature written whole (spl_anim 0): its ink in its band (y 40 .. 164), the rest of the band BG */
            uint16_t bg = host_screen[0];
            uint32_t x, y, ink = 0;
            for (y = 40; y < 164u; y++)
                for (x = 0; x < 240u; x++)
                    ink += host_screen[y * 240u + x] != bg;
            if (ink < 600u) {
                if (rep) fprintf(rep, "FIND %-26s the splash's signature has %u pixels of ink (< 600)\n", cur_name, ink);
                nfind++;
            }
        }
        if (strcmp(splash_seen, WANT)) {
            if (rep) fprintf(rep, "FIND %-26s the splash shows '%s', not '%s'\n", cur_name, splash_seen, WANT);
            nfind++;
        } else {
            static uint8_t said;
            if (!said++) printf("ui_render: the splash shows the version " FELUCCA_VERSION " (FELUCCA_VERSION) and its lines\n");
        }
        {   /* (QG-1 v1.5) the boot timeline exactly as main.c runs it -- one step every 4 ms over
             * SPL_WRITE + SPL_HOLD: how many of those steps change the framebuffer AT ALL. splash_sig redraws
             * only when its signature moves, so this counts the identical rewrites the hold used to pay for,
             * on the pixels themselves rather than by arithmetic. */
            const uint32_t np = (uint32_t)(sizeof host_screen / sizeof host_screen[0]);
            uint32_t ms, steps = 0, changed = 0, prev = 0, i, run = 0, maxrun = 0;
            uint8_t anim0 = spl_anim;
            uint32_t prefs0 = ui_prefs;
            static uint8_t saidcost;
            spl_anim = 1;
            ui_prefs &= ~(uint32_t)PREF_ANIM_OFF;
            for (ms = 0; ms < SPL_WRITE + SPL_HOLD; ms += 4u) {
                uint32_t h = 2166136261u;
                splash_write(ms);
                for (i = 0; i < np; i++) { h ^= (uint32_t)host_screen[i]; h *= 16777619u; }
                if (!steps) prev = h;
                else if (h != prev) { changed++; prev = h; run = 0; }
                else if (++run > maxrun) maxrun = run;      /* (FASE 5) the longest stretch that stands still */
                steps++;
            }
            spl_anim = anim0;
            ui_prefs = prefs0;
            {   /* the frame the whole timeline leaves must be the frame a whole draw produces: the guard may
                 * only skip work, never pixels. (3.2) The hold ends in SPL_FADE ms of HAND-OVER -- the sky
                 * contracting toward HOME's bay -- so the frame compared is the one where the art is still
                 * whole, and the last frame must then be DIFFERENT, or the hand-over never ran. */
                uint16_t end[sizeof host_screen / sizeof host_screen[0]], last[sizeof host_screen / sizeof host_screen[0]];
                uint32_t whole_ms = SPL_WRITE + SPL_HOLD - SPL_FADE;
                uint8_t ap = spl_anim;
                uint32_t pp = ui_prefs;
                memcpy(last, host_screen, sizeof last);
                spl_anim = 1;                            /* (the loop's state, put back before the comparison) */
                ui_prefs &= ~(uint32_t)PREF_ANIM_OFF;
                splash_write(whole_ms);
                memcpy(end, host_screen, sizeof end);
                spl_anim = 0;
                draw_splash();
                spl_anim = ap;
                ui_prefs = pp;
                if (memcmp(end, host_screen, sizeof end)) {
                    uint32_t q, nd = 0, fq = 0;
                    for (q = 0; q < (uint32_t)(sizeof end / sizeof end[0]); q++)
                        if (end[q] != host_screen[q]) { if (!nd) fq = q; nd++; }
                    if (rep) fprintf(rep, "FIND %-26s the splash timeline's whole frame is not the whole splash "
                                     "(%u px, first %u,%u: %04x vs %04x)\n", cur_name, nd, fq % 240u, fq / 240u,
                                     end[fq], host_screen[fq]);
                    nfind++;
                }
                if (!memcmp(last, end, sizeof end)) {
                    if (rep) fprintf(rep, "FIND %-26s the splash's hand-over draws nothing new\n", cur_name);
                    nfind++;
                }
            }
            /* (FASE 5) THE SPLASH MAY NOT STAND STILL. Until 5.0 the test bounded the number of frames that
             * change (150..300 of 1125) because the hold was meant to rewrite nothing: that is exactly the
             * 1.6 s of frozen picture the phase removed, so the bound would now fail the fix. What is asserted
             * instead is the property that was wanted -- the art keeps moving for the whole timeline and no
             * stretch of it is still for longer than 120 ms -- plus the same step count as main.c's loop. A
             * still run longer than that is the freeze coming back, whatever the frame count says. */
            if (steps != (SPL_WRITE + SPL_HOLD) / 4u || changed < 200u || maxrun * 4u > 120u) {
                if (rep) fprintf(rep, "FIND %-26s the splash timeline: %u steps of 4 ms, %u change the screen, "
                                 "longest still run %u steps (%u ms)\n", cur_name, steps, changed, maxrun, maxrun * 4u);
                nfind++;
            } else if (!saidcost++) {
                printf("ui_render: splash timeline: %u steps of 4 ms, %u of them change the screen, "
                       "longest still run %u ms\n", steps, changed, maxrun * 4u);
            }
        }
        {   /* (1.4) MENU > ANIM OFF MUST NOT FREEZE THE BOOT ART. That bit is about values (rolling digits,
             * glides); it used to gate the splash too, so a unit with ANIM OFF -- which is how the owner's
             * unit was set -- drew FULL whole and it looked exactly like SHORT: a still picture. The mode
             * alone decides now, and this asserts it on the pixels: with ANIM OFF, FULL still writes the art. */
            const uint32_t np2 = (uint32_t)(sizeof host_screen / sizeof host_screen[0]);
            uint32_t ms, i2, changed2 = 0, prev2 = 0;
            uint8_t a0 = spl_anim;
            uint32_t p0 = ui_prefs;
            spl_anim = 1;
            ui_prefs |= (uint32_t)PREF_ANIM_OFF;
            for (ms = 0; ms < SPL_WRITE; ms += 4u) {
                uint32_t h2 = 2166136261u;
                splash_write(ms);
                for (i2 = 0; i2 < np2; i2++) { h2 ^= (uint32_t)host_screen[i2]; h2 *= 16777619u; }
                if (!ms) prev2 = h2;
                else if (h2 != prev2) { changed2++; prev2 = h2; }
            }
            spl_anim = a0;
            ui_prefs = p0;
            if (changed2 < 20u) {
                if (rep) fprintf(rep, "FIND %-26s MENU > ANIM OFF freezes the splash (%u changes over SPL_WRITE)\n",
                                 cur_name, changed2);
                nfind++;
            } else {
                static uint8_t saidoff;
                if (!saidoff++) printf("ui_render: MENU > ANIM OFF no longer freezes the splash (%u frames written)\n",
                                       changed2);
            }
        }
        return;
    }
    ui.force = 1;
    mt.frame = ui.frame + 7u;                         /* (the MENU's tabs settled, as when it opens) */
    if (s == S_MENU_SLIDE) mt.pos = 0, mt.frame = ui.frame;   /* (one step of the slide from DISPLAY) */
    ui_draw();
}

/* every value of every column on every page of every engine: labels and values fit their column */
static uint32_t nsweep, nmotion;
/* #63: the page drawn again with MOTION driving each of its cards' track parameters (the motion icon beside
 * every label, the long ones too): the lint over it; the motion cleared again */
static void sweep_motion(void)
{
    uint32_t c, any = 0;
    for (c = 0; c < 4u; c++) {
        int16_t *vp = 0;
        const param_desc_t *d = ui.home ? home_param(c, &vp) : page_desc(cur_page(), c, &vp);
        uintptr_t id = vp ? ((uintptr_t)vp - (uintptr_t)TSEL->p) / sizeof *vp : P_COUNT;
        if (d && d->label && d->label[0] != '-' && id < P_COUNT && !motion_set_event(TSEL, c, (uint32_t)id, *vp))
            any = 1;
    }
    if (!any) return;
    draw(-1);
    for (c = 0; c < 4u; c++) nmotion += (card_mot >> c) & 1u;
    lint();
    memset(&motion, 0, sizeof motion);
}
static void sweep_columns(void)
{
    uint32_t e, i, c;
    char name[64];
    for (e = 0; e < NENGINES; e++) {
        if (!eng_ok(e))
            continue;                                    /* (DIGITAL without FELUCCA_FM4: no track has it) */
        for (i = 0; i < NPAGES; i++) {
            state();
            pal(UI_GREY_INDEX);
            eng(e);
            ui.home = 0; ui.page = (uint8_t)i; page_entered();
            if (!page_visible(i)) continue;
            snprintf(name, sizeof name, "%s%s/%s", large_on ? "LARGE " : "", ENGINES[e]->name, PAGES[i].title);
            cur_name = name;
            for (c = 0; c < 4u; c++) {
                int16_t *vp;
                const param_desc_t *d = PAGES[i].scope == SC_GLOBAL || PAGES[i].scope == SC_TRACK || PAGES[i].scope == SC_ENGINE
                                        ? page_desc(cur_page(), c, &vp) : 0;
                int32_t v, v0;
                if (!d || !d->label || d->label[0] == '-' || PAGES[i].graph == GR_MOD) continue;
                v0 = *vp;
                for (v = d->min; v <= d->max; v++) {
                    *vp = (int16_t)v;
                    nscr = npend = 0;
                    ui.force = 1;
                    draw_columns();
                    lint();
                    audit_value(name, d, v);          /* (every value, not only RATE: the divisions too) */
                    nsweep++;
                    if (v - d->min > 300) v = d->max - 1;      /* wide ranges: the ends */
                }
                *vp = (int16_t)v0;
            }
            draw(-1);                                    /* the whole page */
            lint();
            sweep_motion();
        }
        state(); pal(UI_GREY_INDEX); eng(e); go_home();   /* HOME's four knobs of this engine */
        snprintf(name, sizeof name, "%s%s/HOME", large_on ? "LARGE " : "", ENGINES[e]->name);
        cur_name = name;
        draw(-1);
        lint();
        sweep_motion();
    }
    for (e = 0; e < 4u; e++) {                           /* the MOD page: every source and destination */
        int32_t v;
        state(); pal(UI_GREY_INDEX); go_title("MOD");
        cur_name = large_on ? "LARGE MOD sweep" : "MOD sweep";
        for (v = 0; v < MD_N; v++) {
            TSEL->p[P_M1SRC] = (int16_t)(v % MS_N); TSEL->p[P_M1DST] = (int16_t)v; TSEL->p[P_M1AMT] = (int16_t)(e * 40 - 64);
            mod_ui_slot = (uint8_t)(v & 3u);
            draw(-1);
            lint();
        }
    }
}

/* the rolling digits (ui_draw.c roll_*): GLOBAL, SELECT and KNOB 4 turned together, BPM 129 -> 130 in the header
 * and TUNE 19 -> 20 on a card, then back. Every frame is linted and (GREY, MONO) checked for gray; with a directory,
 * filmstrips of both (each frame side by side, x4: the static frame before, then the roll's frames) as
 * DIR/<PALETTE>_bpm_roll.ppm and DIR/<PALETTE>_card_roll.ppm, the up roll above the down roll. */
#define FS_N (1u + ROLL_FRAMES)                   /* frames per filmstrip row */
#define FS_Z 4u                                   /* zoom */
#define FS_GAP 2u                                 /* px between frames, before the zoom */
static void roll_turns(int32_t s)                 /* one UI frame with the tempo and KNOB 4 moved by s */
{
    song.g[G_BPM] = (int16_t)(song.g[G_BPM] + s);  /* (0.6.67: SELECT alone scrolls the pages; the tempo set here) */
    host_enc[panel.enc[EN_K4]] += s * panel.dir[EN_K4];
    host_ticks += 16000u; fm1_ms += 16u;
    ui_input();
    ui_draw();
    host_ticks += 200000u;
}
static void roll_film_put(uint8_t *img, uint32_t iw, uint32_t row, uint32_t k, int32_t x0, int32_t y0, uint32_t w, uint32_t h)
{
    uint32_t x, y;
    for (y = 0; y < h * FS_Z; y++)
        for (x = 0; x < w * FS_Z; x++) {
            uint16_t c = swap16(host_screen[(uint32_t)(y0 + (int32_t)(y / FS_Z)) * 240u + (uint32_t)x0 + x / FS_Z]);
            uint8_t *p = img + (((row * (h + FS_GAP) + FS_GAP) * FS_Z + y) * iw + (k * (w + FS_GAP) + FS_GAP) * FS_Z + x) * 3u;
            p[0] = (uint8_t)((c >> 11) * 255u / 31u);
            p[1] = (uint8_t)(((c >> 5) & 63u) * 255u / 63u);
            p[2] = (uint8_t)((c & 31u) * 255u / 31u);
        }
}
static void roll_film_save(const char *dir, const char *pal, const char *name, const uint8_t *img, uint32_t iw, uint32_t ih)
{
    char path[512];
    FILE *f;
    snprintf(path, sizeof path, "%s/%s_%s.ppm", dir, pal, name);
    f = fopen(path, "wb");
    if (!f) { fprintf(stderr, "cannot write %s\n", path); return; }
    fprintf(f, "P6\n%u %u\n255\n", iw, ih);
    fwrite(img, 1, (size_t)iw * ih * 3u, f);
    fclose(f);
}
static void roll_frames(const char *dir)
{
    enum { HX = 56, HW = 48, HH = H_HEAD };       /* the header crop: the tempo icon and the BPM strip */
    static uint8_t bimg[(FS_N * (HW + FS_GAP) + FS_GAP) * FS_Z * (2u * (HH + FS_GAP) + FS_GAP) * FS_Z * 3u];
    static uint8_t cimg[(FS_N * (COL_W + FS_GAP) + FS_GAP) * FS_Z * (2u * (COL_H + FS_GAP) + FS_GAP) * FS_Z * 3u];
    const uint32_t biw = (FS_N * (HW + FS_GAP) + FS_GAP) * FS_Z, bih = (2u * (HH + FS_GAP) + FS_GAP) * FS_Z;
    const uint32_t ciw = (FS_N * (COL_W + FS_GAP) + FS_GAP) * FS_Z, cih = (2u * (COL_H + FS_GAP) + FS_GAP) * FS_Z;
    uint32_t p, row, k;
    for (p = 0; p < NPALETTES; p++) {
        char name[64];
        memset(bimg, 90, sizeof bimg);
        memset(cimg, 90, sizeof cimg);
        state(); song.playing = 0; pal(p);
        song.g[G_BPM] = 129; song.g[G_TUNE] = 19;
        go_title("GLOBAL");
        snprintf(name, sizeof name, "%s/roll", UI_PALETTES[p].name);
        cur_name = name;
        draw(-1);
        for (k = 0; k < 8u; k++) { ui.hot_t = 0; ui.bpm_t = 0; ui_draw(); }   /* settled, nothing hot */
        lint();
        for (row = 0; row < 2u; row++) {
            roll_film_put(bimg, biw, row, 0, HX, 0, HW, HH);
            roll_film_put(cimg, ciw, row, 0, CARD_X(3), Y_LABEL, COL_W, COL_H);
            for (k = 1; k < FS_N; k++) {
                if (k == 1u) roll_turns(row ? -1 : 1);
                else ui_draw();
                lint();
                mono_check();
                roll_film_put(bimg, biw, row, k, HX, 0, HW, HH);
                roll_film_put(cimg, ciw, row, k, CARD_X(3), Y_LABEL, COL_W, COL_H);
            }
            if (ui.roll[3].from[0] || ui.roll[ROLL_BPM].from[0] || song.g[G_BPM] != (row ? 129 : 130) ||
                song.g[G_TUNE] != (row ? 19 : 20)) {
                fprintf(rep, "ROLL %s: not over after %u frames (BPM %d TUNE %d)\n", name, ROLL_FRAMES, song.g[G_BPM], song.g[G_TUNE]);
                nfind++;
            }
            for (k = 0; k < 8u; k++) ui_draw();
        }
        if (dir && (p == UI_GREY_INDEX || p == UI_BW_INDEX || !strcmp(UI_PALETTES[p].name, "GREEN"))) {
            roll_film_save(dir, UI_PALETTES[p].name, "bpm_roll", bimg, biw, bih);
            roll_film_save(dir, UI_PALETTES[p].name, "card_roll", cimg, ciw, cih);
        }
    }
}
/* the host cost of a roll frame: the header and the cards (draw_head, draw_columns) while both strips roll,
 * against the same calls on an idle frame (nothing drawn) and a full redraw of the four cards and the header */
static void roll_cost(void)
{
    enum { N = 400 };
    uint32_t i, k;
    double t_roll = 0, t_full = 0;
    uint64_t px_roll = 0, bl_roll = 0, nroll = 0, px_full = 0, bl_full = 0;
    for (i = 0; i < N; i++) {
        clock_t c0;
        state(); song.playing = 0; pal(1);
        song.g[G_BPM] = 129; song.g[G_TUNE] = 19;
        go_title("GLOBAL");
        draw(-1);
        for (k = 0; k < 8u; k++) { ui.hot_t = 0; ui.bpm_t = 0; ui_draw(); }
        px_visited = 0; blit_px = 0;
        c0 = clock();
        ui.force = 1; ui.frame++; draw_head(); draw_columns(); ui.force = 0;
        t_full += (double)(clock() - c0); px_full += px_visited; bl_full += blit_px;
        nscr = npend = 0;
        roll_turns(i & 1u ? -1 : 1);                /* the change: the card and the header redrawn whole */
        for (k = 2; k < ROLL_FRAMES; k++) {         /* the strip-only frames */
            px_visited = 0; blit_px = 0;
            c0 = clock();
            ui.frame++; draw_head(); draw_columns();
            t_roll += (double)(clock() - c0); px_roll += px_visited; bl_roll += blit_px; nroll++;
            nscr = npend = 0;
        }
    }
    fprintf(rep, "  roll frame (header BPM 129->130 and card TUNE 19->20, strips only): %.2f us, %llu glyph px, %llu px blitted;"
            " header + 4 cards redrawn whole: %.2f us, %llu glyph px, %llu px blitted\n",
            t_roll / CLOCKS_PER_SEC / (double)nroll * 1e6, (unsigned long long)(px_roll / nroll), (unsigned long long)(bl_roll / nroll),
            t_full / CLOCKS_PER_SEC / N * 1e6, (unsigned long long)(px_full / N), (unsigned long long)(bl_full / N));
}

/* the alignment check over every value its places can show, beyond the screens above (FLAT and LINE, GREY): the
 * track cushions 1..4 at 12 16 24 px; every icon in a card's icon slot; the dialogs of every kind; every menu row with
 * each of its values; NAME's every key, letter and cycle in ABC and 123, the field holding every character; the
 * piano roll's C labels C-1 .. C9; the drum lanes of every kit; the mixer's LEVEL, PAN and REV over their ranges */
static void align_sweeps(void)
{
    uint32_t st, i, k, nf = nfind;
    FILE *r0 = rep, *nul = fopen("/dev/null", "w");
    int32_t v;
    if (nul) rep = nul;                              /* (not lint scenes: their draws pile up) */
    for (st = ST_FLAT; st <= ST_LINE; st++) {
        state(); pal(UI_GREY_INDEX);
        ui_style = (uint8_t)st; style_apply();
        cur_name = st ? "sweep LINE: cushions" : "sweep FLAT: cushions";
        for (k = 0; k < NTRK; k++)
            for (i = 0; i < 3u; i++) {
                cv_begin(40, 40, T_SURF);
                cv_icon_on(4, 4, i == 0u ? 12u : i == 1u ? 16u : 24u, trk_icon(k, 1), T_ACCENT, T_SURF);
            }
        cur_name = st ? "sweep LINE: card icons" : "sweep FLAT: card icons";
        for (i = 0; i < ICON_COUNT; i++) {
            ui.force = 1;
            draw_column(i & 3u, "LVL", "64", "", T_THEME, 500, i);
            ui.col[i & 3u][0] = 0;
        }
        cur_name = st ? "sweep LINE: LARGE card icons" : "sweep FLAT: LARGE card icons";
        ui_prefs = PREF_LARGE; ui.home = 1;             /* (tall: HOME) */
        for (i = 0; i < ICON_COUNT; i++) {
            ui.force = 1; ui.hot_col = (uint8_t)(i & 3u); ui.hot_t = (uint8_t)(i & 4u);
            draw_column(i & 3u, "LVL", i & 8u ? "OFF" : "64", i & 16u ? "%" : "", T_THEME, 500, i);
            ui.col[i & 3u][0] = 0;
        }
        ui.layer = LAYER_FX;                            /* (the labels in M: a layer's cards) */
        for (i = 0; i < ICON_COUNT; i++) {
            ui.force = 1; ui.hot_col = (uint8_t)(i & 3u); ui.hot_t = (uint8_t)(i & 4u);
            draw_column(i & 3u, "LVL", "64", "", T_THEME, 500, i);
            ui.col[i & 3u][0] = 0;
        }
        ui.layer = 0; ui.hot_t = 0; ui_prefs = 0;
        cur_name = st ? "sweep LINE: dialogs" : "sweep FLAT: dialogs";
        for (i = CF_CLEAR_SEQ; i <= CF_DICE_SOUND; i++)   /* (0.6.65: every dialog, the sound dice's CANCEL / OK too) */
            for (k = 0; k < 4u; k++) {
                ui.confirm = (uint8_t)i; ui.confirm_trk = (uint8_t)k;
                draw_confirm();
            }
        ui.confirm = 0;
        cur_name = st ? "sweep LINE: menu rows" : "sweep FLAT: menu rows";
        ui.menu = 1;
        for (i = 0; i < MI_COUNT; i++)
            for (k = 0; k < 4u; k++) {
                ui.menu_sel = (uint8_t)i; ui_prefs = k & 1u ? 0xFFu : 0u; settings_hold = (uint8_t)k; settings.lowcut = (uint8_t)(k % 3u);
                ui_rec_prefs = (uint8_t)((k % 3u) | (k % 3u) << 2 | ((k + 1u) % 3u) << 4);   /* (CLICK, LEVEL, COUNT-IN: each value) */
                settings_leds = (uint8_t)(k % LEDS_COUNT); ui.force = 1;   /* (every LEDS name) */
                draw_menu();
            }
        cur_name = st ? "sweep LINE: menu tabs sliding" : "sweep FLAT: menu tabs sliding";
        for (i = 0; i < MI_COUNT; i++)                  /* every tab, from every place of the bar, S and M */
            for (k = 0; k <= (MTAB_COUNT - 1u) * 16u; k++) {
                ui.menu_sel = (uint8_t)i; ui_prefs = k & 1u ? PREF_LARGE : 0u;
                mt.pos = (int16_t)(k * 4u); mt.frame = ui.frame - 1u; ui.force = 1;
                draw_menu();
            }
        ui.menu = 0; ui_prefs = 0; ui_rec_prefs = 0; settings_hold = 0; settings.lowcut = 0; settings_leds = 0;
        cur_name = st ? "sweep LINE: REC layer values" : "sweep FLAT: REC layer values";
        ui.home = 1; ui.layer = LAYER_REC;              /* (the map and the cards: every value of the three, each track) */
        for (k = 0; k < 27u * 2u; k++) {
            rp_put(RP_CLICK, k % 3u); rp_put(RP_COUNTIN, k / 3u % 3u); rp_put(RP_LEVEL, k / 9u % 3u);
            song.sel = (uint8_t)(k % NTRK); ui_prefs = k >= 27u ? PREF_LARGE : 0u;
            ui.force = 1; draw_layer(); ui.force = 0;
        }
        ui.layer = 0; song.sel = 0; ui_prefs = 0; ui_rec_prefs = 0;
        cur_name = st ? "sweep LINE: count-in" : "sweep FLAT: count-in";
        for (i = 1; i <= 2u; i++)                       /* 1 and 2 bars, every beat */
            for (k = 4u * i; k >= 1u; k--) {
                cin_total = (uint8_t)(4u * i); cin_left = (uint8_t)k; ui.force = 1;
                draw_countin();
            }
        cin_total = cin_left = 0;
        state(); pal(UI_GREY_INDEX);
        cur_name = st ? "sweep LINE: NAME" : "sweep FLAT: NAME";
        song.playing = 0; go_page(GR_USER); name_open(NK_USER_SAVE, 6);
        for (k = 0; k < 2u; k++) {                       /* ABC, 123: every key cycling, every letter typed next */
            nm.num = (uint8_t)k;
            for (i = 0; i <= 16u; i++) {
                uint32_t n = i ? str_len(nm_group(i - 1u)) : 1u, j;
                for (j = 0; j < n; j++) {
                    nm.key = (uint8_t)i; nm.tap = (uint8_t)j;
                    nm_draw_panel();
                }
            }
        }
        nm.key = 0;
        for (i = 0; i < sizeof NM_SET - 1u; i += NM_LEN) {   /* the field: every character */
            for (k = 0; k < NM_LEN; k++) nm.s[k] = NM_SET[(i + k) % (sizeof NM_SET - 1u)];
            nm.s[NM_LEN] = 0; nm.len = NM_LEN; nm.cur = 0;
            nm_draw_field();
        }
        name_close();
        cur_name = st ? "sweep LINE: piano roll" : "sweep FLAT: piano roll";
        roll_scene(S_ROLL_ACID);
        for (v = 0; v + PR_ROWS <= 128; v++) {
            proll.lo = (uint8_t)v;
            cv_begin(240, H_GRAPH, T_SURF);
            graph_roll(TSEL, T_THEME);
        }
        state(); pal(UI_GREY_INDEX);
        cur_name = st ? "sweep LINE: drum kits" : "sweep FLAT: drum kits";
        for (k = 0; k < 4u; k++) {
            drum(k);
            for (i = 0; i < NLANE; i++) {
                ui.lane = (uint8_t)i;
                cv_begin(240, H_GRAPH, T_SURF);
                graph_grid(TSEL, T_THEME);
            }
        }
        state(); pal(UI_GREY_INDEX);
        cur_name = st ? "sweep LINE: mixer" : "sweep FLAT: mixer";
        go_page(GR_TRK);
        for (v = 0; v < 256; v++) {                    /* (then with LARGE: the strip) */
            ui_prefs = v >= 128 ? PREF_LARGE : 0u;
            trk[0].p[P_LEVEL] = (int16_t)(v & 127); trk[0].p[P_PAN] = (int16_t)((v & 127) - 64); trk[0].p[P_REV] = (int16_t)(v & 127);
            trk[1].p[P_MUTE] = (int16_t)(v & 1); song.rec = v & 2 ? 2u : 0u; ui.hot_t = (uint8_t)(v & 4); ui.hot_col = 3;
            ts.meter[0] = (uint8_t)(v % (TS_MH - 1));
            ui.force = 1;
            draw_tracks();
        }
        ui_prefs = 0; ui.hot_t = 0;
        ui.force = 0;
    }
    ui_style = ST_FLAT; style_apply();
    state();
    nscr = npend = nrules = 0;
    nfind = nf;
    rep = r0;
    if (nul) fclose(nul);
}

/* the keycaps' labels in their pills (tools/gen_aa_keycaps.py), from the data: the label's ink (nibbles 6..15) in the
 * pill (KC_H rows, its width) */
static void al_keycaps(void)
{
    static uint16_t nib[16];                        /* (v1.5.16) the ramp that turns the decoder's nibble into the
                                                     * pixel: KC_DATA is Huffman-coded (tools/gen_aa_keycaps.py,
                                                     * cv_alpha_hc), so reading it as nibbles ran off the array and
                                                     * this check measured noise. Decode it with the real decoder. */
    uint32_t id;
    cur_name = "keycap data";
    for (id = 0; id < 16u; id++)
        nib[id] = (uint16_t)id;
    for (id = 0; id < KC_COUNT; id++) {
        const kc_t *k = &KC[id];
        int32_t x, y, x0 = 999, y0 = 999, x1 = -1, y1 = -1, w = k->w;
        cv_begin((uint32_t)w, KC_H, 0x0000u);
        cv_alpha_hc(0, 0, (uint32_t)w, KC_H, KC_DATA + k->off, KC_HC, nib);
        for (y = 0; y < KC_H; y++)
            for (x = 0; x < w; x++)
                if (cv_px[(uint32_t)y * (uint32_t)w + (uint32_t)x] >= 6u) {   /* (nibble 6..: the label) */
                    if (x < x0) x0 = x;
                    if (y < y0) y0 = y;
                    if (x + 1 > x1) x1 = x + 1;
                    if (y + 1 > y1) y1 = y + 1;
                }
        al_record("keycap label in its pill", (x0 + x1) - w, (y0 + y1) - KC_H, k->label, 0, 0, w, KC_H, x0, y0, x1, y1);
        if (al_rep) fprintf(al_rep, "keycap %-8s w %2d  ink x %2d..%2d y %d..%d  across %+.1f up/down %+.1f\n", k->label, w, x0, x1, y0, y1,
                            ((x0 + x1) - w) / 2.0, ((y0 + y1) - KC_H) / 2.0);
    }
}
static void al_table(void)
{
    uint32_t i;
    if (!al_rep) return;
    fprintf(al_rep, "\n%-30s %8s %5s %5s %5s %6s %6s\n", "place", "measured", "1px+", "-0.5", "+0.5", "across", "up/dn");
    for (i = 0; i < al_nst; i++) {
        const alstat_t *a = &al_st[i];
        if (!strcmp(a->tag, "self-test")) continue;
        fprintf(al_rep, "%-30s %8u %5u %5u %5u %6.1f %6.1f\n", a->tag, a->n, a->nfail, a->half_lo, a->half_hi, a->wh2 / 2.0,
                a->wv2 / 2.0);
        if (a->ex_h[0]) fprintf(al_rep, "    across  worst %s\n", a->ex_h);
        if (a->ex_v[0]) fprintf(al_rep, "    up/down worst %s\n", a->ex_v);
    }
    fprintf(al_rep, "\n%u measurements, %u places, %u off by 1 px or more; %u declared places drawn without their items\n",
            al_count, al_nst, al_fail, al_lost);
}

/* ------------------------------------------------------------------ the regions --- */
/* (v1.5.5) THE BEFORE / AFTER OF A FIX, MEASURED ON THE RECTANGLES IT TOUCHES. The phase-2 report's three open UI
 * defects are boxes of a few hundred pixels in a 57 600 px frame, and a whole-frame comparison cannot say which box
 * moved. `ui_render --regions` draws the same screens the suite does and compares TWO STATES of the UI three ways:
 *   - the pixels that stand DIFFERENT inside a named rectangle (what the eye sees: the fragments a closed pop-up
 *     leaves in the MIXER's dB zone), and
 *   - the pixels the drawer WROTE in that frame (blit_px, gfx.c's blits): a repaint under something opaque spends
 *     them without changing a pixel, which is exactly "the whole mixer redrawn";
 *   - the ink of ONE element, isolated by changing only its value (the header's tempo against the track numbers).
 * The numbers go to stdout, no report files, no PPMs: a fix's commit carries them. Exit 1 when an AFTER number is
 * not what the fix promises (the guard the three cases leave in the suite). */
typedef struct { const char *n; int32_t x0, y0, x1, y1; } reg_t;
static uint16_t rref[240 * 240];
static int32_t rw[4];                            /* the box of the pixels that differ (x0 y0 x1 y1, x1 = -1: none) */
static uint32_t rframe(void) { ui.force = 1; memset(host_screen, 0, sizeof host_screen); gfx_forget(); blit_px = 0; ui_draw(); return (uint32_t)blit_px; }
static uint32_t rnext(void) { blit_px = 0; ui_draw(); return (uint32_t)blit_px; }
static void rsnap(void) { memcpy(rref, host_screen, sizeof rref); }
/* the pixels of r that differ from the snapshot, and their box in rw */
static uint32_t rdiff(const reg_t *r)
{
    uint32_t n = 0;
    int32_t x, y;
    rw[0] = rw[1] = 240; rw[2] = rw[3] = -1;
    for (y = r->y0; y < r->y1; y++)
        for (x = r->x0; x < r->x1; x++)
            if (host_screen[(uint32_t)y * 240u + (uint32_t)x] != rref[(uint32_t)y * 240u + (uint32_t)x]) {
                n++;
                if (x < rw[0]) rw[0] = x;
                if (y < rw[1]) rw[1] = y;
                if (x > rw[2]) rw[2] = x;
                if (y > rw[3]) rw[3] = y;
            }
    return n;
}
static void rrow(const reg_t *r) { printf("  %-42s %6u px distintos\n", r->n, rdiff(r)); }
static uint32_t rcell(const reg_t *r)              /* the diff's pixels inside another rectangle */
{
    uint32_t n = 0;
    int32_t x, y;
    for (y = r->y0; y < r->y1; y++)
        for (x = r->x0; x < r->x1; x++)
            n += host_screen[(uint32_t)y * 240u + (uint32_t)x] != rref[(uint32_t)y * 240u + (uint32_t)x];
    return n;
}
static reg_t rrect(const char *n, int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    reg_t r;
    r.n = n; r.x0 = x0; r.y0 = y0; r.x1 = x1; r.y1 = y1;
    return r;
}
/* two states of one screen: `f0` draws the first (a fresh forced frame), `f1` the second; the diffs are printed and
 * the first one's count is returned (the number a fix drives to zero) */
/* (v1.5.6) THE IDLE FRAME: what the drawer still writes when NOTHING changed. Every band has a signature and the
 * columns have their own stamps, so an idle frame should write 0 px; whatever it writes is work the panel pays for
 * nothing (bandwidth, CPU on core 0 next to the audio) and, when it repeats, is what a blinking or flickering strip
 * looks like. Each scene is forced once, then drawn three more times with the clock RUNNING (33 ms a frame, the
 * instrument's own rate), and the three are summed: the least of them hid a page that repainted every other frame
 * (three draws always hold two of the same ui.frame parity) and a still clock never let a fade settle. */
#define IDLE_LIMIT 33000u                      /* (FASE 4) measured 29 952 with the fills' own rows forgotten;
                                                * v1.5.6 measured 109 056 through this same harness, 1 485 216
                                                * before it. The harness sums three idle draws now (see main()). */
static int idle_main(void)
{
    uint32_t s, k, w, tot = 0, worst[8] = {0}, wn[8] = {0};
    reg_t all = rrect("frame", 0, 0, 240, 240);
    rep = al_rep = audf = fopen("/dev/null", "w");
    if (!rep)
        return 1;
    printf("idle: what an untouched frame costs -- px the panel writes and px that change (forced frame, then 3 idle draws)\n");
    for (s = 0; s < S_COUNT; s++) {
        state();
        setup((int)s);
        rframe();
        rsnap();
        bb[2] = -1; bb_on = 1;
        /* (FASE 4) THREE idle draws, ADDED UP -- not the least of them. The least hid a page that repaints
         * every other frame: three draws always contain two of the same frame parity, so the "cheapest" of
         * the three was 0 for a page the panel was still fed 54 528 px every two frames. The sum is what the
         * instrument spends standing still: 0 for a still page, and for a blink exactly the frames it moved
         * (one of three, a third of its cost, which is the price of keeping the blink). */
        w = 0;
        for (k = 0; k < 3u; k++) {
            fm1_ms += 33u;                            /* (FASE 4) the instrument's clock runs between frames (30 fps):
                                                       * a fade that is timed against fm1_ms never settled with it
                                                       * frozen, and a page mid-animation repaints whole every
                                                       * frame -- measured as waste that the unit does not spend
                                                       * once the animation is done. */
            host_ticks += 33000u;
            w += rnext();                             /* an idle draw: no state moved since the snapshot */
        }
        w /= 3u;                                      /* per idle frame, the unit the budget is in */
        bb_on = 0;
        if (!rdiff(&all))
            tot += w;                                 /* wrote px, changed none: pure waste */
        if (getenv("UI_IDLE_DEBUG") && w)
            printf("    [%s] w=%u bb=%d,%d..%d,%d page=%u home=%u layer=%u\n", S_NAME[s], w, bb[0], bb[1], bb[2], bb[3],
                   ui.page, ui.home, ui.layer);
        else
            continue;                                 /* an animation: its writes are its content */
        for (k = 0; k < 8u; k++)
            if (w > worst[k]) {
                uint32_t i;
                for (i = 7u; i > k; i--) { worst[i] = worst[i - 1u]; wn[i] = wn[i - 1u]; }
                worst[k] = w; wn[k] = s;
                break;
            }
    }
    printf("  %u px escritos y 0 cambiados, sumando las escenas quietas (tope %u: el piso medido +10 %%)\n", tot,
           (uint32_t)IDLE_LIMIT);
    for (k = 0; k < 8u; k++)
        if (worst[k])
            printf("  %-28s %6u px escritos, 0 cambiados\n", S_NAME[wn[k]], worst[k]);
    return tot > IDLE_LIMIT;                     /* the guard: the quiet scenes' floor, not a wish for zero -- a
                                                  * page whose canvas really moves every frame is not waste */
}
static int rbad;
static int regions_main(void)
{
    uint32_t k, written;
    int32_t bx[4];
    reg_t panel, pop, db, hdr, cards, foot, c3, c4;

    /* the lint's own files (a finding goes to `rep`): this mode reports on stdout and keeps none of them */
    rep = al_rep = audf = fopen("/dev/null", "w");
    if (!rep)
        return 1;
    printf("regions: what each defect costs, before / after (blit_px = the pixels the panel was made to write)\n");

    /* ---- A. the preset pop-up over the MIXER: its box is not a column's, so closing it must repaint the panel.
     * The HUD is drawn over rows 96..182 of the six-column mixer, the LEVEL knob and its dB word among them; the
     * page must come back exactly as it was, and the report is the pixels left behind. ---- */
    printf("\nA. pop-up de preset sobre el MIXER (QUANTUM, seis columnas)\n");
    state(); setup(S_MIXER); pal(UI_QUANTUM_INDEX);
    written = rframe();
    rsnap();
    fm1_ms = 10000u;                                /* the HUD's 1.5 s window is measured against the clock */
    ui.preset_pop_ms = fm1_ms;
    written = rnext();
    printf("  el pop-up: %u px escritos\n", written);
    {   /* (v1.8.7) AND ONCE. The card's pixels are a function of the sound picked; while the knob rests it was sent
         * again every frame of its 1.5 s window -- the same 17 888 px, thirty times a second, changing nothing.
         * A second frame with the card up and nothing moved must write 0 px. */
        uint32_t again = rnext();
        printf("  el pop-up, un frame después y sin cambios: %u px escritos\n", again);
        if (again) {
            printf("  FALLA: la tarjeta se vuelve a enviar sin que haya cambiado nada\n");
            rbad++;
        }
    }
    {   /* (v1.5.15) AND IT PAINTS ITS OWN BOX, NOTHING ELSE. The pop-up used to composite itself into whatever canvas
         * the page had left and blit it as the whole band: on the MIXER that band was a stale canvas -- preset names
         * of a previous draw -- sent over the desk, which is the report's "preset names drawn over the mixer". The
         * panel outside the plate must be exactly what it was. */
        uint32_t x, y, out = 0;
        for (y = 0; y < 240u; y++)
            for (x = 0; x < 240u; x++) {
                int inpop = x >= 16u && x < 224u && y >= (uint32_t)(Y_GRAPH + 18) &&
                            y < (uint32_t)(Y_GRAPH + 18 + 86);
                if (!inpop && host_screen[y * 240u + x] != rref[y * 240u + x])
                    out++;
            }
        printf("  px del panel tocados FUERA de la caja del pop-up: %u\n", out);
        if (out) {
            printf("  FALLA: el pop-up escribe fuera de su caja (el MIXER queda con tinta encima)\n");
            rbad++;
        }
    }
    ui.preset_pop_ms = fm1_ms - 1600u;              /* 1.5 s: it has closed */
    written = rnext();
    printf("  al cerrarse: %u px escritos\n", written);
    panel = rrect("panel del MIXER (Y_GRAPH .. +H_GRAPH)", 0, Y_GRAPH, 240, Y_GRAPH + H_GRAPH);
    pop = rrect("la caja del pop-up (16..224 x 96..182)", 16, Y_GRAPH + 18, 224, Y_GRAPH + 18 + 86);
    db = rrect("la zona dB de las columnas (y 118..148)", 0, Y_GRAPH + 40, 240, Y_GRAPH + 70);
    hdr = rrect("la cabecera (no la toca)", 0, 0, 240, H_HEAD);
    rrow(&panel);
    rrow(&pop);
    rrow(&db);
    rrow(&hdr);
    if (rdiff(&panel) || rdiff(&hdr)) {
        printf("  FALLA: el MIXER no vuelve a su frame al cerrarse el pop-up\n");
        rbad++;
    }

    /* ---- B. the tempo's ink against the track numbers. Only the BPM changes (124 -> 60, both three digits, so the
     * block does not move): the pixels that differ ARE the tempo's ink, and the cushions' cells are the rectangles
     * of T3 and T4 in the layout drawn. In every layout the two must not share a pixel. ---- */
    printf("\nB. la tinta del tempo contra las almohadillas de T3/T4\n");
    /* the six columns, then MENU > LARGE's four-track strip: only the BPM changes (124 -> 60, both three digits, so
     * the block does not move), so the pixels that differ ARE the tempo's ink; the cushions are the boxes of T3 and
     * T4 in the layout drawn, and the two must not share a pixel */
    hdr = rrect("la cabecera", 0, 0, 240, H_HEAD);
    for (k = 0; k < 2u; k++) {
        state(); setup(S_MIXER); pal(UI_QUANTUM_INDEX);
        if (k) { large_on = 1; ui_prefs |= PREF_LARGE; }
        rframe();
        rsnap();
        song.g[G_BPM] = 60;
        {   uint32_t f;
            for (f = 0; f < 30u; f++)
                rnext();                        /* the header's rolling digits settle */ }
        (void)rdiff(&hdr);
        if (k)
            c3 = rrect("T3", CARD_X(2) + 4, LG_Y_GRAPH + 4, CARD_X(2) + 20, LG_Y_GRAPH + 20),
            c4 = rrect("T4", CARD_X(3) + 4, LG_Y_GRAPH + 4, CARD_X(3) + 20, LG_Y_GRAPH + 20);
        else
            c3 = rrect("T3", T6_X(2) + 4, Y_GRAPH + 5, T6_X(2) + 20, Y_GRAPH + 21),
            c4 = rrect("T4", T6_X(3) + 4, Y_GRAPH + 5, T6_X(3) + 20, Y_GRAPH + 21);
        printf("  %s: el tempo x %d..%d, y %d..%d; almohadillas y %d..%d; solapamiento T3 %u px, T4 %u px\n",
               k ? "LARGE (cuatro pistas)" : "seis columnas", rw[0], rw[2], rw[1], rw[3], c3.y0, c3.y1,
               rcell(&c3), rcell(&c4));
        if (rcell(&c3) || rcell(&c4)) {
            printf("  FALLA: el badge del tempo comparte pixel con los numeros de T3/T4\n");
            rbad++;
        }
        large_on = 0;
    }

    /* ---- C. the track change with ALGORITHM (ui_input.c: the EN_ALGO encoder calls page track_select). Only the
     * selection moves: the header's cushion, the two columns whose accent swaps, the cards' and the footer's own
     * signatures. The strip's ground, the other columns and the panel are the same pixels, so the panel must not be
     * refilled nor the frame forced; the number that says how much was paid is blit_px. ---- */
    printf("\nC. cambio de pista en el MIXER (ALGORITHM, ui.c track_select)\n");
    state(); setup(S_MIXER); pal(UI_QUANTUM_INDEX);
    printf("  el frame entero, forzado: %u px escritos\n", rframe());
    rsnap();
    {
        static const reg_t col[4] = {{"T1", 3, 78, 41, 200}, {"T2", 42, 78, 80, 200},
                                     {"T3", 81, 78, 119, 200}, {"T4", 120, 78, 158, 200}};
        uint32_t old = song.sel, inside = 0, total;
        track_select((old + 1u) % trk_live);        /* the ALGORITHM encoder's own call: its invalidation */
        written = rnext();
        printf("  el cambio de pista: %u px escritos\n", written);
        panel = rrect("el panel del MIXER", 0, Y_GRAPH, 240, Y_GRAPH + H_GRAPH);
        total = rdiff(&panel);
        inside = rcell(&col[old]) + rcell(&col[(old + 1u) % trk_live]);
        printf("  distintos en el panel: %u, de ellos en las dos columnas de la seleccion: %u, en el resto: %u\n",
               total, inside, total - inside);
        if (total - inside) {
            printf("  FALLA: el cambio de pista toca el panel fuera de las dos columnas\n");
            rbad++;
        }
        {   /* the fix has to be invisible: the frame it leaves is the one a whole redraw of the new selection
             * makes, pixel for pixel (the footer is left out: the track's flash owns it for PF_MS) */
            static uint16_t got[240 * 240];
            uint32_t x, y, bad = 0;
            memcpy(got, host_screen, sizeof got);
            state(); setup(S_MIXER); pal(UI_QUANTUM_INDEX);
            song.sel = (uint8_t)((old + 1u) % trk_live);
            rframe();
            for (y = 0; y < Y_FOOT; y++)
                for (x = 0; x < 240u; x++)
                    bad += got[y * 240u + x] != host_screen[y * 240u + x];
            printf("  el frame que deja, contra un redibujo entero: %u px distintos\n", bad);
            if (bad) {
                printf("  FALLA: el cambio de pista ya no deja el frame de un redibujo entero\n");
                rbad++;
            }
        }
    }
    (void)bx;
    return rbad ? 1 : 0;
}

/* ------------------------------------------------------------------ the bands --- */
/* (v1.5.15) WHAT ONE STEP OF HOME'S AMBIENCE COSTS THE PANEL, AND THE MIXER'S METERS. The three HOME screens and
 * the MIXER repaint their whole body (a 26-row cap and two 88-row passes: 48 480 px) whenever anything in their
 * signature moved, and their ambient layer -- hv_air's sixteen embers, the strip's breathing bar -- steps every
 * eighth frame. That is the body re-sent at ~7.5 Hz for forty-odd pixels, which is what the report called flicker.
 * gfx.c now keeps a hash a row and sends only the rows that differ. The numbers: px written per step (the panel's
 * bus) and px that really changed (the picture), plus a check that the rows left unsent were already right: the
 * frame the incremental draw leaves is the one a whole redraw makes, pixel for pixel. Animating is not disabled --
 * the step still changes pixels, they are just carried by the rows that hold them. */
#define BANDS_LIMIT 9000u                              /* px a step may write (48 480 before: the whole body) */
/* (v1.5.20, issue #106) THE HEADERS OF HOME 2..5, FRAME BY FRAME. The report's first symptom was a header cell that
 * flickered with nothing changing, whatever the STYLE (FLAT / LINE) and with ANIM OFF. This is the measurement that
 * says so or not: the same state drawn twice with one step of the clock between, in every combination, counting what
 * the panel is asked to write and what actually changes inside the header band (0..H_HEAD). A pixel that changes
 * there with no value changing IS the flicker, and the frame must also be the one a whole redraw leaves (no stale
 * rows). A last case moves the tempo on purpose, so a header that simply never repaints cannot pass: its ink has to
 * be inside the band, and the rest of the frame has to stay where it was. */
static int headers_main(void)
{
    static const struct { const char *nm; int s; } SC[] = {{"HOME 2/5 VISUALS", S_HOME_VIZ},
                                                          {"HOME 3/5 OVERVIEW", S_HOME_OVERVIEW},
                                                          {"HOME 4/5 MIXER", S_HOME_MIX},
                                                          {"HOME 5/5 PERFORM", S_HOME_PERF}};
    reg_t hdr = rrect("la cabecera (0..H_HEAD)", 0, 0, 240, H_HEAD);
    uint32_t k, st, an, bad = 0;
    rep = al_rep = audf = fopen("/dev/null", "w");
    if (!rep)
        return 1;
    printf("headers: HOME 2..5 x STYLE x ANIM, un paso del reloj: px escritos y cambiados en la cabecera\n");
    for (st = 0; st < 2u; st++)
        for (an = 0; an < 2u; an++)
            for (k = 0; k < 4u; k++) {
                uint32_t written, changed;
                state();
                setup(SC[k].s);
                pal(UI_QUANTUM_INDEX);
                ui_style = (uint8_t)st;
                style_apply();
                if (an)
                    ui_prefs &= ~(uint32_t)PREF_ANIM_OFF;
                else
                    ui_prefs |= PREF_ANIM_OFF;
                rframe();                             /* the whole frame: the panel has it */
                (void)rnext();                        /* .. and the row table built */
                rsnap();
                ui.frame += 8u;                       /* one step of the ambience, the clock too */
                fm1_ms += 16u;
                written = rnext();
                changed = rdiff(&hdr);
                printf("  %-17s %s %-4s  escritos %5u px (todo el frame), cabecera %3u px%s\n", SC[k].nm,
                       st ? "LINE" : "FLAT", an ? "ANIM" : "OFF", written, changed,
                       SC[k].s == S_HOME_VIZ ? "  (el campo del visualizador anima a proposito)" : "");
                /* VISUALS is the screen whose field IS the animation: its body has no quiet frame on purpose, so
                 * the write budget (FOR HOME 3..5) does not apply to it; its HEADER still has to stand still. */
                if (changed || (SC[k].s != S_HOME_VIZ && written > BANDS_LIMIT)) {
                    printf("  FALLA: %s\n", changed ? "la cabecera parpadea con nada cambiando"
                                                  : "el frame reenvia el cuerpo entero de una pagina quieta");
                    bad++;
                }
            }
    {   /* the control: the tempo moves, so the header has to answer, and only inside its band */
        uint32_t in, out = 0, x, y;
        state();
        setup(S_HOME_OVERVIEW);
        pal(UI_QUANTUM_INDEX);
        ui_style = 0;
        style_apply();
        ui_prefs &= ~(uint32_t)PREF_ANIM_OFF;
        rframe();
        (void)rnext();
        rsnap();
        song.g[G_BPM] = (int16_t)(song.g[G_BPM] > 60 ? song.g[G_BPM] - 1 : song.g[G_BPM] + 1);
        (void)rnext();
        in = rdiff(&hdr);
        for (y = 0; y < 240u; y++)
            for (x = 0; x < 240u; x++)
                if (y >= H_HEAD && host_screen[y * 240u + x] != rref[y * 240u + x])
                    out++;
        printf("  control: el tempo cambia  cabecera %u px, fuera de la cabecera %u px\n", in, out);
        if (!in || out) {
            printf("  FALLA: %s\n", !in ? "la cabecera no responde al tempo (no se repinta)"
                                          : "el tempo escribe fuera de la cabecera");
            bad++;
        }
    }
    printf("headers: %s\n", bad ? "FAILED" : "ningun encabezado cambia un pixel con la pantalla quieta, en FLAT y LINE, con ANIM y sin el");
    return bad ? 1 : 0;
}

/* (v1.5.20, issue #105) WHAT THE INSTRUMENT WOULD SAY (ui.c ann_ui, through announce.c's real framing). The capture
 * is tests/ui_test.c's ann_wire_send: the SAY texts, in the order they would go out. The checks are the whole path a
 * reader depends on: silence with nobody listening; HELLO answered and the screen said; the row of MENU said as the
 * selection moves, with the tab, the name and the value; a turn of its knob said once it settles (never per step);
 * and WHERE answering with the page and the row again. The reader itself (the voice, the page) is not here: this is
 * the bytes, host x86-64. */
static int ann_said(const char *t, uint32_t from)
{
    uint32_t i;
    for (i = from; i < ann_wire_log_n; i++)
        if (!strcmp(ann_wire_log[i], t))
            return 1;
    return 0;
}
static int ann_said_sub(const char *t, uint32_t from)
{
    uint32_t i;
    for (i = from; i < ann_wire_log_n; i++)
        if (strstr(ann_wire_log[i], t))
            return 1;
    return 0;
}
static void ann_flush(void)
{
    ui.force = 1;
    gfx_forget();
    ui_draw();
    ui.force = 0;
}
static int announce_main(void)
{
    uint8_t f[5] = {0x7D, 0x53, 0x52, 1, 1};
    uint32_t n0, bad = 0;
    char want[48];
    rep = al_rep = audf = fopen("/dev/null", "w");
    if (!rep)
        return 1;
    printf("announce: lo que el instrumento diria, por el camino real (ann_ui -> announce.c)\n");
    state();
    setup(S_HOME);
    pal(UI_QUANTUM_INDEX);
    ann_wire_log_n = 0;
    ann_flush();
    printf("  sin lector: %u lineas\n", ann_wire_log_n);
    if (ann_wire_log_n) {
        printf("  FALLA: habla sin que nadie escuche\n");
        bad++;
    }
    (void)ann_frame(f, sizeof f, fm1_ms);          /* HELLO: a reader arrives */
    n0 = ann_wire_log_n;
    ann_flush();
    printf("  HELLO y primer cuadro: %s\n", ann_said("HOME MAIN", n0) ? "la pantalla, dicha" : "NADA");
    if (!ann_said("HOME MAIN", n0)) bad++;
    ui.menu = 1;                                    /* MENU, the first row: DISPLAY COLOR <name> */
    ui.menu_sel = MI_COLOR;
    n0 = ann_wire_log_n;
    ann_flush();
    {
        menu_ann_row(want, sizeof want, MI_COLOR);
        printf("  MENU: dice \"%s\" (%s)\n", want,
               ann_said(want, n0) && ann_said("MENU", n0) ? "pagina y fila" : "NO");
        if (!ann_said(want, n0) || !ann_said("MENU", n0) || !strstr(want, "DISPLAY COLOR ")) bad++;
    }
    ui.menu_sel = MI_ANIM;                          /* the selection moves: said at once */
    n0 = ann_wire_log_n;
    ann_flush();
    menu_ann_row(want, sizeof want, MI_ANIM);
    printf("  otra fila: \"%s\" (%s)\n", want, ann_said(want, n0) ? "dicha" : "NO");
    if (!ann_said(want, n0)) bad++;
    {   /* the knob: nothing per step, one line once it settles */
        uint32_t before = ann_wire_log_n, was = menu_get(MI_ANIM);
        menu_put(MI_ANIM, was ^ 1u);
        ann_flush();
        printf("  anim cambiada: %u lineas en el acto (0 = espera a que pare)\n", ann_wire_log_n - before);
        if (ann_wire_log_n != before) bad++;
        ann_tick(fm1_ms + 400u);
        menu_ann_row(want, sizeof want, MI_ANIM);
        printf("  .. y al asentarse: \"%s\" (%s)\n", want, ann_said(want, before) ? "dicha" : "NO");
        if (!ann_said(want, before)) bad++;
        menu_put(MI_ANIM, was);
    }
    f[3] = 3;                                       /* WHERE: page and row again, with the value back as it was */
    (void)ann_frame(f, sizeof f, fm1_ms);
    n0 = ann_wire_log_n;
    menu_ann_row(want, sizeof want, MI_ANIM);
    ann_flush();
    printf("  WHERE: %s\n", ann_said("MENU", n0) && ann_said(want, n0) ? "pagina y fila otra vez" : "NADA");
    if (!ann_said("MENU", n0) || !ann_said(want, n0)) bad++;
    ui.menu = 0;
    n0 = ann_wire_log_n;
    ann_flush();
    printf("  al cerrar MENU: %s\n", ann_said("HOME MAIN", n0) ? "vuelve a HOME MAIN" : "NADA");
    if (!ann_said("HOME MAIN", n0)) bad++;
    /* (FASE 8) THE PAGES THAT ARE NOT HOME. Until now only HOME's cards were read out: a list's row, a
     * sequencer step and any other page's knobs were silent. Here, on the real path, on the pages the states
     * build: the row with its place in the list, the step with its bank, the knob of the page (not HOME's,
     * through page_desc), and WHERE saying the page and the four values it holds. */
    setup(S_PHRASES);
    f[3] = 1;                                        /* the reader says HELLO again (the device forgets one after 5 s) */
    f[4] = 1;
    (void)ann_frame(f, sizeof f, fm1_ms);
    n0 = ann_wire_log_n;
    ann_flush();
    printf("  PHRASES (lista): %s\n", ann_said_sub("PATTERN ", n0) && ann_said_sub(" OF ", n0) ? "fila y lugar" : "NADA");
    if (!ann_said_sub("PATTERN ", n0) || !ann_said_sub(" OF ", n0)) bad++;
    setup(S_STEP);
    n0 = ann_wire_log_n;
    ann_flush();
    printf("  STEP (cursor): %s\n", ann_said_sub("STEP 7 OF 16", n0) ? "el paso del cursor" : "NADA");
    if (!ann_said_sub("STEP 7 OF 16", n0)) bad++;
    go_title("TUNE");                                /* (FASE 7) a page with four knobs of its own (page_desc) */
    {
        uint32_t before = ann_wire_log_n, col = 0, c;
        char val[12], want2[48];
        const char *unit = 0;
        int16_t *vp = 0;
        const param_desc_t *d = 0;
        for (c = 0; c < 4u; c++) {
            int16_t *v2 = 0;
            d = page_desc(cur_page(), c, &v2);
            if (d && v2) {
                vp = v2;
                col = c;
                break;
            }
            d = 0;
        }
        (void)ann_frame(f, sizeof f, fm1_ms);
        ann_flush();                                 /* a fresh HELLO means WHERE: that answer goes out here */
        before = ann_wire_log_n;
        ui.hot_col = (uint8_t)col;
        ui.hot_t = 40;
        ann_flush();
        printf("  perilla de una pagina: %u lineas en el acto (0 = espera a que pare)\n", ann_wire_log_n - before);
        if (ann_wire_log_n != before) bad++;
        ann_tick(fm1_ms + 400u);
        want2[0] = 0;
        if (d && d->label && d->label[0]) {
            param_format(d, *vp, val, &unit);
            snprintf(want2, sizeof want2, "%s %s%s%s", d->label, val, unit && unit[0] ? " " : "", unit && unit[0] ? unit : "");
        }
        printf("  .. y al asentarse: \"%s\" (%s)\n", want2, ann_said(want2, before) ? "dicha" : "NO");
        if (!ann_said(want2, before)) bad++;
        ui.hot_t = 0;
    }
    {   /* (FASE 8) WHERE on a page says the page and its row again (the four values are the panel's own,
         * said as each knob turns; they are not repeated here) */
        uint32_t before = ann_wire_log_n;
        f[3] = 3;
        (void)ann_frame(f, sizeof f, fm1_ms);
        ann_flush();
        printf("  WHERE en una pagina: %s\n", ann_said("TUNE", before) ? "la pagina otra vez" : "NADA");
        if (!ann_said("TUNE", before)) bad++;
    }
    printf("announce: %s\n", bad ? "FAILED" : "lo que se dice es lo que la pantalla tiene, y nada sin lector");
    return bad ? 1 : 0;
}

/* ------------------------------------------------------------------ the visualizer's top --- */
/* The visualizer's top section -- the cap over rows 20..45 and the panel's first rows, where the title, the
 * engine's name, the rule and the tracks' seven blocks are -- holds nothing that moves: the field, the trace
 * and the bars below it do. If any of those pixels move between two frames with the same signal, the section
 * is being cleared and repainted (a flicker on the panel) and this says how many and where.
 * It also checks the one thing a repaint can lose: that the title is ink in every frame, never a blank. */
static int viz_main(void)
{
    static uint16_t prev[240 * 240];
    uint32_t f, y, x, bad = 0;
    rep = al_rep = audf = fopen("/dev/null", "w");
    if (!rep)
        return 1;
    printf("viz: la cabecera y el cap del visualizador (filas 0..25) entre cuadros seguidos\n");
    state();
    setup(S_HOME_VIZ);
    pal(UI_QUANTUM_INDEX);
    rframe();
    for (f = 0; f < 6u; f++) {
        uint32_t moved = 0, rows = 0, first = 999u, ink = 0, wrote = 0;
        memcpy(prev, host_screen, sizeof prev);
        ui.frame += 1u;                                /* one frame of the ambient layer, same audio */
        fm1_ms += 16u;
        bb_on = 1;                                     /* (v1.11) what the panel is made to write, row by row */
        wrote = rnext();
        bb_on = 0;
        for (y = 0; y <= 25u; y++) {   /* (v1.11) the header and the six-row cap: nothing here moves, ever */
            uint32_t row = 0;
            for (x = 0; x < 240u; x++)
                if (prev[y * 240u + x] != host_screen[y * 240u + x]) {
                    row++;
                    if (y < first) first = y;
                }
            if (row) rows++;
            moved += row;
        }
        for (x = 0; x < 240u; x++)                     /* the title's own row: ink, in every frame */
            if (host_screen[30u * 240u + x] != host_screen[26u * 240u + x]) ink++;
        printf("  cuadro %u: %4u px movidos en %2u filas%s%s, tinta del titulo %u px, escritos %u px\n", f + 1u,
               moved, rows, rows ? ", la primera " : "", rows ? "" : " (quieta)", ink, wrote);
        if (rows)
            printf("  FALLA: la cabecera o el cap se repintan con el mismo sonido (fila %u)\n", first);
        if (!ink) {
            printf("  FALLA: el titulo no tiene tinta\n");
            bad++;
        }
        bad += rows ? 1u : 0u;
    }
    printf("viz: %s\n", bad ? "FAILED" : "la seccion superior queda quieta entre cuadros, y el titulo siempre esta");
    return bad ? 1 : 0;
}

static int bands_main(void)
{
    /* (v1.11) A STEP OF THE AMBIENT LAYER AND A SOUND LOAD ARE NOT THE SAME EVENT, so they do not share a ceiling.
     * BANDS_LIMIT is "one animation step costs the rows that change"; the PRESETS scene loads a whole sound -- the
     * header's engine, the four cards' parameter labels and values, the list and the pop-up all change -- and its
     * budget is its own MEASUREMENT plus 10 %, not a number that fits the others. What the scene holds it to is
     * the check that matters for the report: not one row left unsent (stale 0), so every row the panel shows was
     * sent once and is the row the frame needed. */
    static const struct { const char *nm; int s; uint32_t cap; } SC[] = {
            {"HOME 2/5 OVERVIEW", S_HOME_OVERVIEW, BANDS_LIMIT},
            {"HOME 3/5 MIXER", S_HOME_MIX, BANDS_LIMIT},
            {"HOME 4/5 PERFORM", S_HOME_PERF, BANDS_LIMIT},
            {"GLO MIXER (meters)", S_MIXER, BANDS_LIMIT},
            {"PRESETS (knob)", S_PRESETS, 71400u}};   /* measured 64 848 px + 10 % */
    static uint16_t got[240 * 240];
    reg_t all = rrect("frame", 0, 0, 240, 240);
    uint32_t k, bad = 0;
    rep = al_rep = audf = fopen("/dev/null", "w");
    if (!rep)
        return 1;
    printf("bands: one step of the ambient layer / a meter, px the panel writes vs px that change (tope %u)\n",
           (uint32_t)BANDS_LIMIT);
    for (k = 0; k < sizeof SC / sizeof SC[0]; k++) {
        uint32_t written, changed, x, y, stale = 0;
        state();
        setup(SC[k].s);
        pal(UI_QUANTUM_INDEX);
        rframe();                                      /* the body, forced: the panel has all of it */
        (void)rnext();                                 /* rframe forgets the row table: this frame rebuilds it */
        rsnap();
        if (k == 3u)                                   /* the MIXER: a meter of T1 moves, nothing else */
            trk[0].vu = (int32_t)((uint32_t)trk[0].vu + 9000u) > 30000 ? 9000 : trk[0].vu + 9000;
        if (k == 4u)                                   /* (v1.11) the PRESETS knob: one step of the list, and the
                                                        * popup it puts over the graph -- the report's flicker */
            presets_turn(1);
        ui.frame += 8u;                                /* one step of hv_air's field and the strip's pulse */
        fm1_ms += 16u;
        bb_on = 1;
        written = rnext();
        bb_on = 0;
        changed = rdiff(&all);
        memcpy(got, host_screen, sizeof got);          /* what the incremental draw left on the panel */
        ui.force = 1;                                  /* .. and what a whole redraw of the same state leaves */
        gfx_forget();
        ui_draw();
        for (y = 0; y < 240u; y++)
            for (x = 0; x < 240u; x++)
                stale += got[y * 240u + x] != host_screen[y * 240u + x];
        printf("  %-20s escritos %5u px (tope %5u), cambiados %5u px, filas no enviadas que estaban mal %u\n",
               SC[k].nm, written, SC[k].cap, changed, stale);
        if (written > SC[k].cap || stale || !changed) {
            printf("  FALLA: %s\n", written > SC[k].cap ? "el paso del ambiente reenvia el cuerpo entero"
                                      : stale ? "una fila que no se envio no era la que el panel tenia"
                                              : "el paso no animo nada (se apago la animacion)");
            bad++;
        }
    }
    printf("bands: %s\n", bad ? "FAILED" : "cada paso cuesta las filas que cambian, y el frame queda exacto");
    return bad ? 1 : 0;
}

/* (v1.12) THE ENVELOPE'S PLAYHEAD MUST SIT ON THE DRAWN CURVE, AND THIS MEASURES IT. Both tracks (ENV 1 and ENV 2),
 * three ADSR settings and the three live stages: the page is drawn with a voice at a known level and then again with
 * that voice gone. The difference between the two frames is the dot and its drop line; on the dot's centre row the
 * reference frame says where the curve's ink is, and the dot's column must be within 2 px of it. The two frames are
 * the same page in the same state, so nothing else can account for the pixels that differ. */
static int env_main(void)
{
    static const struct { const char *nm; int a, d, s, r; } CFG[] = {
        {"rapido", 6, 20, 40, 14}, {"normal", 64, 64, 71, 64}, {"lento", 120, 104, 88, 120}};
    static const struct { const char *nm; uint8_t st; } STG[] = {{"ataque", 1u}, {"decay", 2u}, {"release", 3u}};
    static uint16_t A[240 * 240], B[240 * 240];
    uint32_t n, k, j, v, worst = 0;
    int bad = 0;
    rep = al_rep = audf = fopen("/dev/null", "w");
    printf("env: el punto de la envolvente sobre la curva dibujada (ENV 1 y ENV 2 x 3 ADSR x 3 etapas)\n");
    for (n = 0; n < 2u; n++)
        for (k = 0; k < 3u; k++)
            for (j = 0; j < 3u; j++) {
                uint32_t x, y, bx0 = 240u, bx1 = 0u, by0 = 240u, cx, cy, bg, ink = 900u, d;
                int32_t sus, lvl;
                state();
                song.sel = (uint8_t)n;
                TSEL->p[P_ATK] = CFG[k].a;
                TSEL->p[P_DEC] = CFG[k].d;
                TSEL->p[P_SUS] = CFG[k].s;
                TSEL->p[P_REL] = CFG[k].r;
                go_title("ENV");
                for (v = 0; v < NVOICE; v++) {          /* one voice alive: the one this test places */
                    V(TSEL, v).stage = 0;
                    V(TSEL, v).env = 0;
                }
                sus = TSEL->p[P_SUS] * 1000 / 127;
                lvl = STG[j].st == 1u ? 450 : STG[j].st == 2u ? (1000 + sus) / 2 : sus / 2;
                if (lvl < 1)
                    lvl = 1;
                V(TSEL, 0).stage = STG[j].st;
                V(TSEL, 0).env = (int32_t)(((int64_t)lvl * (1 << 24)) / 1000);
                rframe();                               /* the page, with the dot */
                memcpy(A, host_screen, sizeof A);
                V(TSEL, 0).stage = 0;
                V(TSEL, 0).env = 0;
                rframe();                               /* the same page, without it */
                memcpy(B, host_screen, sizeof B);
                for (y = 0; y < 240u; y++)
                    for (x = 0; x < 240u; x++)
                        if (A[y * 240u + x] != B[y * 240u + x]) {
                            if (x < bx0) bx0 = x;
                            if (x > bx1) bx1 = x;
                            if (y < by0) by0 = y;
                        }
                if (bx0 > bx1) {
                    printf("  ENV %u %s %s: FALLA, no hay punto que medir\n", n + 1u, CFG[k].nm, STG[j].nm);
                    bad++;
                    continue;
                }
                cx = (bx0 + bx1) / 2u;
                cy = by0 + 3u;                          /* the box is 7 px tall: its centre row */
                bg = B[cy * 240u + 6u];                 /* the page's tone, left of the panel */
                for (x = 4; x < 236u; x++)
                    if (B[cy * 240u + x] != bg) {
                        d = x > cx ? x - cx : cx - x;
                        if (d < ink)
                            ink = d;
                    }
                if (ink > worst)
                    worst = ink;
                printf("  ENV %u %-7s %-8s desvio %2u px%s\n", n + 1u, CFG[k].nm, STG[j].nm, ink,
                       ink > 2u ? "   <-- FUERA DE LA CURVA" : "");
                if (ink > 2u)
                    bad++;
            }
    /* (y despues de navegar: HOME y de vuelta, el punto otra vez sobre su curva) */
    {
        uint32_t x, y, bx0 = 240u, bx1 = 0u, by0 = 240u, cx, cy, bg, ink = 900u, d;
        int32_t sus, lvl;
        state();
        song.sel = 0;
        TSEL->p[P_ATK] = 40; TSEL->p[P_DEC] = 90; TSEL->p[P_SUS] = 60; TSEL->p[P_REL] = 60;
        go_title("ENV");
        go_home();
        go_title("ENV");
        for (v = 0; v < NVOICE; v++) { V(TSEL, v).stage = 0; V(TSEL, v).env = 0; }
        sus = TSEL->p[P_SUS] * 1000 / 127;
        lvl = (1000 + sus) / 2;
        V(TSEL, 0).stage = 2u;
        V(TSEL, 0).env = (int32_t)(((int64_t)lvl * (1 << 24)) / 1000);
        rframe();
        memcpy(A, host_screen, sizeof A);
        V(TSEL, 0).stage = 0; V(TSEL, 0).env = 0;
        rframe();
        for (y = 0; y < 240u; y++)
            for (x = 0; x < 240u; x++)
                if (A[y * 240u + x] != host_screen[y * 240u + x]) {
                    if (x < bx0) bx0 = x;
                    if (x > bx1) bx1 = x;
                    if (y < by0) by0 = y;
                }
        cx = (bx0 + bx1) / 2u;
        cy = by0 + 3u;
        bg = host_screen[cy * 240u + 6u];
        for (x = 4; x < 236u; x++)
            if (host_screen[cy * 240u + x] != bg) {
                d = x > cx ? x - cx : cx - x;
                if (d < ink) ink = d;
            }
        printf("  ENV 1 tras HOME y vuelta: desvio %u px%s\n", ink, ink > 2u ? "   <-- FUERA DE LA CURVA" : "");
        if (ink > 2u)
            bad++;
        if (ink > worst) worst = ink;
    }
    printf("env: %s (peor desvio %u px)\n", bad ? "FAILED" : "el punto cae sobre la curva en las 19 medidas", worst);
    return bad ? 1 : 0;
}

/* (v1.12.2) HOME'S FIVE SCREENS, WALKED WITH THE TAP THE FIRMWARE USES. go_home() on HOME advances the view; a
 * real tap is the only thing this mode does between frames, so what it measures is what a finger sees: the frame
 * after the switch must be exactly the frame a full redraw of that same state leaves (no row of the screen the
 * previous view drew still on the glass -- the report's "boxes and indicators that disappear"), the header and the
 * four cards must still carry ink, and a screen that is not animating must cost nothing once it has settled. */
static int home_main(void)
{
    static const char *const NM[HV_COUNT] = {"MAIN", "VISUALS", "OVERVIEW", "MIX", "PERFORM"};
    static uint16_t got[240 * 240];
    static uint16_t hist[4096];
    uint32_t k, bad = 0;
    rep = al_rep = audf = fopen("/dev/null", "w");
    printf("home: un toque recorre las cinco pantallas; filas viejas, tinta de cabecera y tarjetas, y lo que cuesta\n");
    for (k = 0; k < (uint32_t)HV_COUNT; k++) {
        uint32_t x, y, stale = 0, inkh = 0, inkc = 0, step, still, i, mx, mode_h = 0, mode_c = 0;
        state();
        ui.home = 1;                                /* already on HOME: the tap changes the screen */
        ui.home_view = (uint8_t)k;
        ui.home_viz = k == HV_VIZ;
        go_home();                                  /* the real tap: the next screen */
        rframe();                                   /* the body, once */
        (void)rnext();
        {   /* the counters ui_draw itself moves, kept so the reference pass starts from the same state */
            uint32_t fr0 = ui.frame, ht0 = ui.hot_t, bt0 = ui.bpm_t, mt0 = ui.msg_t;
            step = rnext();                         /* the frame after the switch, incremental */
            memcpy(got, host_screen, sizeof got);
            ui.force = 1, gfx_forget();              /* .. and what a whole redraw of that same state leaves */
            ui.frame = fr0 - 1u; ui.hot_t = ht0; ui.bpm_t = bt0; ui.msg_t = mt0;
            ui_draw();
        }
        for (y = 0; y < 240u; y++)
            for (x = 0; x < 240u; x++)
                stale += got[y * 240u + x] != host_screen[y * 240u + x];
        memset(hist, 0, sizeof hist);
        for (y = 0; y < 26u; y++)
            for (x = 0; x < 240u; x++)
                hist[(host_screen[y * 240u + x] >> 4) & 0xFFFu]++;
        for (i = 0; i < 4096u; i++)
            if (hist[i] > hist[mode_h])
                mode_h = i;
        mx = hist[mode_h];
        inkh = 240u * 26u - mx;                     /* everything in the bar that is not its ground */
        memset(hist, 0, sizeof hist);
        for (y = 26u; y < 84u; y++)
            for (x = 0; x < 240u; x++)
                hist[(host_screen[y * 240u + x] >> 4) & 0xFFFu]++;
        for (i = 0; i < 4096u; i++)
            if (hist[i] > hist[mode_c])
                mode_c = i;
        inkc = 240u * 58u - hist[mode_c];
        still = rnext();                            /* a frame with nothing new to say */
        /* (v1.12.2) THE EXACT CHECK IS FOR THE SCREENS THAT SETTLE. MAIN and VISUALS animate -- the field's embers,
         * the bay, the meters that fall ~2 dB on every draw -- so a second pass of the same state is a different
         * frame by design and its difference is not a defect. On the three that do not move (OVERVIEW, MIX, PERFORM)
         * the frame after the tap must be pixel for pixel the one a full redraw leaves, and on all five the header
         * and the four cards must still carry their ink: that is what "the boxes and indicators vanish when walking
         * the pages" would look like from here. */
        {
            int anim = still > 0u, fail = inkh < 400u || inkc < 2000u || (!anim && stale);
            printf("  %-8s paso %5u px, filas viejas %3u%s, cabecera %4u px de tinta, tarjetas %5u px, en reposo %5u px %s\n",
                   NM[(k + 1u) % HV_COUNT], step, stale, anim ? " (animada)" : " (quieta)", inkh, inkc, still,
                   fail ? "<-- FALLA" : "");
            if (fail)
                bad++;
        }
    }
    printf("home: %s\n", bad ? "FAILED" : "cada pantalla queda exacta al llegar, con su cabecera y sus cuatro tarjetas");
    return bad ? 1 : 0;
}

int main(int argc, char **argv)
{
    const char *out = argc > 1 ? argv[1] : "build/ui_new";
    char path[600];
    uint32_t p, s;
    if (argc > 1 && !strcmp(argv[1], "--regions"))
        return regions_main();
    if (argc > 1 && !strcmp(argv[1], "--idle"))
        return idle_main();
    if (argc > 1 && !strcmp(argv[1], "--bands"))
        return bands_main();
    if (argc > 1 && !strcmp(argv[1], "--home"))
        return home_main();
    if (argc > 1 && !strcmp(argv[1], "--env"))
        return env_main();
    if (argc > 1 && !strcmp(argv[1], "--viz"))
        return viz_main();
    if (argc > 1 && !strcmp(argv[1], "--headers"))
        return headers_main();
    if (argc > 1 && !strcmp(argv[1], "--announce"))
        return announce_main();
    static const char *const SHOW[] = {"GREY", "MONO", "GREEN", "PAPER", "NIGHT", "THERMAL", "GAMMA", "WRAITH", "QUANTUM"};   /* (NIGHT: #50, to review) */
    /* QG_DUMP=<screen>[,<palette>]: render one screen into /tmp/qg_dump.ppm for a visual review.
     * It is the same draw() the suite measures, so what it shows is what the panel gets; the
     * palette is an index into the generated table (13 QUANTUM, 15 CYBERPUNK, 16 NORDIC, 0 GREY,
     * 9 MONO, ...). No effect on the measurements: the run exits right after the frame. */
    if (getenv("QG_DUMP")) {
        unsigned scr = 0u, pal_i = UI_QUANTUM_INDEX, yy, xx;
        sscanf(getenv("QG_DUMP"), "%u,%u", &scr, &pal_i);
        if (getenv("QG_DUMP_NAME")) {            /* by name: the index of S_NAME's entry, so a review can say the
                                                  * screen it means instead of counting an enum */
            uint32_t k;
            for (k = 0; k < S_COUNT; k++)
                if (!strcmp(S_NAME[k], getenv("QG_DUMP_NAME"))) { scr = k; break; }
        }
        state();
        setup(scr >= S_COUNT ? S_HOME : scr);
        if (getenv("QG_DUMP_LARGE")) {           /* the MENU > LARGE layout of that screen, as the LARGE pass draws it */
            large_on = 1;
            ui_prefs |= PREF_LARGE;
        }
        pal(pal_i);
        if (getenv("QG_DUMP_FX")) {   /* the echo train as the bus measures it (tests/dly_echo_test) and the
                                       * buses' peaks as fx.c publishes them (fx_vu), put in after setup so
                                       * the FX page has real signal to draw: the delay train, the four sends /
                                       * returns, the track's own post-FX envelope and the mix's L/R peaks */
            static const int32_t T[6] = {15463, 6515, 2747, 1159, 489, 208};
            static const int32_t V[8] = {19000, 9200, 4300, 12400, 3100, 1600, 20500, 13800};
            int k;
            for (k = 0; k < 6; k++) fx_dly_rep[k] = T[k];
            for (k = 0; k < 8; k++) fx_vu[k] = V[k];
            trk[0].vu = 15600;
            fx_dly_gen = 2; fx_dly_frac = 96;
        }
        draw(scr >= S_COUNT ? S_HOME : scr);
        {
            FILE *f = fopen("/tmp/qg_dump.ppm", "wb");
            if (!f) { fprintf(stderr, "cannot write /tmp/qg_dump.ppm\n"); return 1; }
            fprintf(f, "P6 240 240 255\n");
            for (yy = 0; yy < 240u; yy++)
                for (xx = 0; xx < 240u; xx++) {
                    uint16_t c = swap16(host_screen[yy * 240u + xx]);
                    unsigned char rgb[3] = {(unsigned char)(((c >> 11) & 31) * 255 / 31),
                                            (unsigned char)(((c >> 5) & 63) * 255 / 63),
                                            (unsigned char)((c & 31) * 255 / 31)};
                    fwrite(rgb, 1, 3, f);
                }
            fclose(f);
        }
        return 0;
    }
    snprintf(path, sizeof path, "%s/report.txt", out);
    rep = fopen(path, "w");
    if (!rep) { fprintf(stderr, "cannot write %s\n", path); return 1; }
    {
        char ap[600];
        snprintf(ap, sizeof ap, "%s/align.txt", out);
        al_rep = fopen(ap, "w");
        if (al_rep) fprintf(al_rep, "alignment: the ink of each centred text / icon / keycap against its box (gfx.c GFX_HOOK_ALIGN);"
                            " offsets in px, + right / down\n\n");
    }
    {
        char ap[600];
        snprintf(ap, sizeof ap, "%s/text_audit.tsv", out);
        audf = fopen(ap, "w");
    }
    if (audf) fprintf(audf, "screen\ttexts\ttext_px\ticons\ticon_px\tkeycaps\tkeycap_px\tellipsised\ttight\twords\ttight_list"
        "\trate_value\trate_px\trate_elided\n");            /* the last three: the column sweep's RATE labels; the
                                                             * sweep's other values are rows like a screen's */
    {   /* the lint itself: an overlap, a value too wide for its column, a text past its canvas, one past its cell */
        state(); pal(0); cur_name = "self-test";
        nscr = npend = 0;
        cv_begin(COL_W, COL_H, T_BG);
        cv_text(0, 0, &AF_S, "AAAA", T_TEXT);
        cv_text(10, 4, &AF_S, "BBBB", T_TEXT);
        cv_text_fit(0, 15, &AF_M, "WWWWWWWW", T_THEME, T_BG, COL_W);
        cv_text(40, 30, &AF_M, "CUT", T_THEME);
        cv_rrect(2, 31, 20, 13, 3, T_SURF, T_BG);          /* a cell narrower than its word */
        cv_text(4, 31, &AF_S, "SPILL", T_TEXT);
        cv_blit(4, Y_LABEL);
        lint();
        nrules = 0;                                         /* a word on a divider (STYLE LINE) */
        lcd_rule(0, 120, 240, 1);
        cv_begin(40, 16, T_BG);
        cv_text(2, 0, &AF_S, "RULE", T_TEXT);
        cv_blit(8, 112);
        lint();
        nrules = 0;
        {   /* the alignment check: a word 2 px right of its box's centre, one centred */
            uint32_t f0 = al_fail;
            cv_begin(60, 20, T_BG);
            GFX_HOOK_ALIGN(0, 0, 60, 20, AL_HV, "self-test");
            cv_text_in(4, 0 + CAP_IN(S, 20), 60, &AF_S, "OFF", T_TEXT, T_BG);
            GFX_HOOK_ALIGN(0, 0, 60, 20, AL_HV, "self-test");
            cv_text_in(0, 0 + CAP_IN(S, 20), 60, &AF_S, "MID", T_TEXT, T_BG);
            if (al_fail - f0 != 1u) { fprintf(stderr, "ui_render: the alignment check missed its self-test (%u)\n", al_fail - f0); return 1; }
            al_fail = f0;
            al_count -= 2u;
            npend = 0;
        }
        if (nfind < 5u || !nspill) { fprintf(stderr, "ui_render: the lint missed its self-test (%u)\n", nfind); return 1; }
        fprintf(rep, "(self-test: %u findings above are expected)\n\n", nfind);
        nfind = 0;
    }
    for (p = 0; p < NPALETTES; p++)
        for (s = 0; s < S_COUNT; s++) {
            char name[64];
            uint32_t k;
            if (!FELUCCA_FM4 && (s == S_OP_ENV || (s >= S_ALG1 && s <= S_OP_LEVEL)))
                continue;                           /* (DIGITAL's own screens: FELUCCA_FM4=1 only) */
            snprintf(name, sizeof name, "%s/%s", UI_PALETTES[p].name, S_NAME[s]);
            cur_name = name;
            setup((int)s);
            pal(p);
            if (p == UI_GREY_INDEX) aud = audf;
            draw((int)s);
            lint();
            if (p == UI_GREY_INDEX) { audit_scene(S_NAME[s]); aud = 0; }
            mono_check();
            for (k = 0; k < sizeof SHOW / sizeof SHOW[0]; k++)
                if (!strcmp(UI_PALETTES[p].name, SHOW[k])) write_ppm(out, SHOW[k], S_NAME[s]);
        }
    {   /* STYLE LINE (gfx.c ST_*): every screen in every palette, linted (GREY: gray, MONO: neutral); GREY MONO NIGHT
         * PAPER as OUTDIR/ppm/<STYLE>_<PALETTE>_<screen>.ppm (ui_render.py: sheet_<STYLE>_<PALETTE>.png) */
        static const char *const ST_N[2] = {"FLAT", "LINE"}, *const ST_PAL[] = {"GREY", "MONO", "NIGHT", "PAPER"};
        uint32_t st, k, n0 = nfind, nruled = 0;
        for (st = ST_LINE; st <= ST_LINE; st++)
            for (p = 0; p < NPALETTES; p++) {
                for (k = 0; k < sizeof ST_PAL / sizeof ST_PAL[0] && strcmp(UI_PALETTES[p].name, ST_PAL[k]); k++) ;
                for (s = 0; s < S_COUNT; s++) {
                    char name[64], tag[24];
                    if (!FELUCCA_FM4 && (s == S_OP_ENV || (s >= S_ALG1 && s <= S_OP_LEVEL)))
                        continue;
                    if (s == S_PRESETS_POP)            /* (v1.8.7) the preset card is the graph's, not a tall card's: the
                                                        * LARGE pass measures the strip's labels, and the card over it is
                                                        * not part of that layout (its own pass is the FLAT one) */
                        continue;
                    snprintf(tag, sizeof tag, "%s_%s", ST_N[st], UI_PALETTES[p].name);
                    snprintf(name, sizeof name, "%s/%s", tag, S_NAME[s]);
                    cur_name = name;
                    setup((int)s);
                    pal(p);
                    ui_style = (uint8_t)st; style_apply();
                    draw((int)s);
                    if (ux.style != st) { fprintf(stderr, "ui_render: %s drawn in style %u\n", name, ux.style); return 1; }
                    nruled += nrules != 0u;
                    lint();
                    mono_check();
                    if (k < sizeof ST_PAL / sizeof ST_PAL[0]) write_ppm(out, tag, S_NAME[s]);
                }
            }
        ui_style = ST_FLAT; style_apply();
        if (nruled < 100u) { fprintf(stderr, "ui_render: dividers on %u STYLE screens only\n", nruled); return 1; }
        fprintf(rep, "STYLE LINE (every palette): %u lint findings\n", nfind - n0);
    }
    {   /* MENU > LARGE (ui.c large_kind): every screen in every palette in FLAT and LINE, linted (GREY: gray, MONO:
         * neutral); GREY MONO in FLAT as OUTDIR/ppm/LARGE_<PALETTE>_<screen>.ppm (ui_render.py: sheet_LARGE_<PALETTE>.png),
         * LINE GREY as LARGE-LINE_GREY; the tall cards' value faces counted (lg_hook) */
        static const char *const ST_N[2] = {"LARGE", "LARGE-LINE"};
        uint32_t st, n0 = nfind, ntall = 0;
        large_on = 1;
        for (st = ST_FLAT; st <= ST_LINE; st++)
            for (p = 0; p < NPALETTES; p++)
                for (s = 0; s < S_COUNT; s++) {
                    char name[64], tag[24];
                    if (!FELUCCA_FM4 && (s == S_OP_ENV || (s >= S_ALG1 && s <= S_OP_LEVEL)))
                        continue;
                    if (s == S_PRESETS_POP)            /* (v1.8.7) the preset card is the graph's, not a tall card's: the
                                                        * LARGE pass measures the strip's labels, and the card over it is
                                                        * not part of that layout (its own pass is the FLAT one) */
                        continue;
                    snprintf(tag, sizeof tag, "%s_%s", ST_N[st], UI_PALETTES[p].name);
                    snprintf(name, sizeof name, "%s/%s", tag, S_NAME[s]);
                    cur_name = name;
                    setup((int)s);
                    ui_prefs |= PREF_LARGE;
                    pal(p);
                    ui_style = (uint8_t)st; style_apply();
                    draw((int)s);
                    ntall += !ui.menu && !ui.confirm && !name_on() && large_kind() == LK_TALL;
                    lint();
                    mono_check();
                    if ((p == UI_GREY_INDEX || (!st && p == UI_BW_INDEX)))
                        write_ppm(out, tag, S_NAME[s]);
                }
        ui_style = ST_FLAT; style_apply();
        sweep_columns();                                /* every value of every column, tall */
        large_on = 0;
        if (ntall < 100u) { fprintf(stderr, "ui_render: LARGE drew %u screens with tall cards only\n", ntall); return 1; }
        fprintf(rep, "MENU > LARGE (FLAT and LINE, every palette, the page / value sweep): %u lint findings; %u screens with tall"
                " cards\n", nfind - n0, ntall);
        fprintf(rep, "  tall card values: %llu in L, %llu in M (a glyph not in L: \"%s\"), %llu in M (L too wide), %llu in S\n",
                (unsigned long long)lg_n[0], (unsigned long long)lg_n[1], lg_miss, (unsigned long long)lg_n[2],
                (unsigned long long)lg_n[3]);
        fprintf(rep, "  too wide for L, e.g.:");
        for (s = 0; s < lg_nwide; s++) fprintf(rep, " '%s'", lg_wide[s]);
        fprintf(rep, "\n  in S, e.g.:");
        for (s = 0; s < lg_nsmall; s++) fprintf(rep, " '%s'", lg_small[s]);
        fprintf(rep, "\n");
    }
    {   /* every FM6 chart (the lint above, fmp_check, runs on each), in GREY: gray */
        uint32_t a, c0 = fmp_charts;
        for (a = 1; a <= 32u; a++) {
            char name[32];
            snprintf(name, sizeof name, "FM6 ALG %u", a);
            cur_name = name;
            state(); pal(UI_GREY_INDEX); eng(ENGI_FM6); TSEL->p[P_E0] = (int16_t)a; go_title("EDIT 1");
            draw(-1);
            lint();
            mono_check();
        }
        if (fmp_charts - c0 != 32u) { fprintf(stderr, "ui_render: %u FM6 charts drawn of 32\n", fmp_charts - c0); return 1; }
    }
    sweep_columns();
    roll_frames(argc > 2 ? argv[2] : 0);
    al_off = 1;                                     /* (the alignment check is not timed) */
    /* draw cost: a full redraw of a screen (all strips), and HOME frame by frame (the scope, every other frame) */
    {
        static const int COST[] = {S_HOME, S_PRESETS, S_STEP, S_ROLL_CHORDS, S_DRUM, S_MIXER, S_MENU, S_ABOUT_CREDITS, S_CONFIRM_PROJ,
                                   S_FX, S_REVERB2, S_MASTER, S_DRUMX};   /* (3.6) the FX, Reverb, Master and DRUM-X pages too:
                                                                           * a change to those pages can be measured, not guessed */
        enum { N = 200 };
        uint32_t i, k;
        fprintf(rep, "\ndraw cost on the host (cc -O1; only the ratios mean anything on the device):\n");
        fprintf(rep, "  screen            full redraw us   texts+icons   glyph px read     px filled      fills\n");
        for (k = 0; k < sizeof COST / sizeof COST[0]; k++) {
            clock_t c0;
            uint64_t px, nt;
            setup(COST[k]); pal(1);
            draw(COST[k]);
            px_visited = n_text = 0;
            px_fill = 0; n_fill = 0; gfx_ramp_builds = 0;
            c0 = clock();
            for (i = 0; i < N; i++) draw(COST[k]);
            px = px_visited / N; nt = n_text / N;
            fprintf(rep, "  %-16s %15.1f %13llu %15llu %14llu %9llu\n", S_NAME[COST[k]],
                    (double)(clock() - c0) / CLOCKS_PER_SEC / N * 1e6,
                    (unsigned long long)nt, (unsigned long long)px, (unsigned long long)(px_fill / N),
                    (unsigned long long)(n_fill / N));
            fprintf(rep, "  %-16s ramps rebuilt per frame: %u\n", S_NAME[COST[k]], gfx_ramp_builds / N);
            /* (1.5.28) A STEADY-STATE FRAME REBUILDS NOTHING. The cache holds every (ink, ground, heat, curve)
             * a screen uses, so from the second frame on the ramps are hits; more than two per frame means the
             * table is too small again and the same work is being redone 200 times in this very loop. */
            if (gfx_ramp_builds / N > 2u) {
                nfind++;
                fprintf(rep, "  ! %s rebuilds %u text ramps per frame (limit 2: the cache is too small)\n",
                        S_NAME[COST[k]], gfx_ramp_builds / N);
            }
            /* (1.5.29) A CEILING ON OVERDRAW, because it is the number a redraw costs the panel and nothing
             * watched it. A 240 x 240 screen is 57 600 px; the worst screen here paints 160 481 (2.8x, FX's
             * wells and buses) and the limit is 200 000 -- a change that doubles a screen's painted area now
             * fails the sweep instead of quietly eating the frame time. */
            if (px_fill / N > 200000u) {
                nfind++;
                fprintf(rep, "  ! %s paints %llu px in a redraw (limit 200000; a whole screen is 57600)\n",
                        S_NAME[COST[k]], (unsigned long long)(px_fill / N));
            }
        }
        {
            clock_t c0;
            setup(S_HOME); pal(1); draw(S_HOME);
            px_visited = n_text = 0;
            c0 = clock();
            for (i = 0; i < N * 4; i++) { ui_draw(); nscr = npend = 0; }
            fprintf(rep, "  HOME, a frame without force (lazy strips): %.1f us, %llu texts\n",
                    (double)(clock() - c0) / CLOCKS_PER_SEC / (N * 4) * 1e6, (unsigned long long)(n_text / (N * 4)));
        }
        {   /* (1.7) what the new chrome costs: the splash's written steps (the hold rewrites nothing) and
             * HOME's visualizer, its busiest screen, redrawn whole */
            clock_t c0;
            int pg;
            double sp;
            c0 = clock();
            for (i = 0; i < N; i++)
                for (pg = 0; pg < 256; pg++)
                    splash_sig((uint32_t)pg, 0);
            sp = (double)(clock() - c0) / CLOCKS_PER_SEC / (N * 256.0) * 1e6;
            {   /* the visualizer's own breakdown: HIGH against LOW, the difference being the embers
                 * and the trace's sampling step (ui_being.c vz_step / vz_flares) */
                double vh, vl;
                setup(S_HOME_VIZ); pal(1); draw(S_HOME_VIZ); ui_viz_q = 0;
                px_visited = n_text = 0;
                c0 = clock();
                for (i = 0; i < N * 4; i++) { ui.force = 1; draw_graph(); ui.force = 0; nscr = npend = 0; }
                vh = (double)(clock() - c0) / CLOCKS_PER_SEC / (N * 4) * 1e6;
                ui_viz_q = 2;
                c0 = clock();
                for (i = 0; i < N * 4; i++) { ui.force = 1; draw_graph(); ui.force = 0; nscr = npend = 0; }
                vl = (double)(clock() - c0) / CLOCKS_PER_SEC / (N * 4) * 1e6;
                ui_viz_q = 0;
                fprintf(rep, "  splash: one written frame %.1f us; HOME's visualizer %.1f us a frame HIGH, "
                             "%.1f us at LOW (the embers and the step)\n", sp, vh, vl);
            }
        {   /* the floor under the visualizer: its two 240 x 88 bands cleared and blitted with nothing
             * drawn. If this is the cost, the page is blit-bound and no amount of drawing is cheaper. */
            clock_t c0;
            uint32_t bd;
            c0 = clock();
            for (i = 0; i < N * 4; i++)
                for (bd = 0; bd < 2u; bd++) {
                    cv_begin(240, 88, T_BG);
                    cv_blit(0, 26u + bd * 88u);
                    nscr = npend = 0;
                }
            fprintf(rep, "  visualizer floor: the two bands alone %.1f us a frame\n",
                    (double)(clock() - c0) / CLOCKS_PER_SEC / (N * 4) * 1e6);
        }
        }
        {   /* the STEP page's piano roll: its panel alone redrawn, and a frame that changes nothing (the signature only) */
            static const int G[] = {S_ROLL_CHORDS, S_ROLL_PLAYING, S_DRUM};
            for (k = 0; k < 3u; k++) {
                clock_t c0;
                double tg, ti;
                setup(G[k]); pal(1); draw(G[k]);
                c0 = clock();
                for (i = 0; i < N * 4; i++) { ui.force = 1; draw_graph(); ui.force = 0; nscr = npend = 0; }
                tg = (double)(clock() - c0) / CLOCKS_PER_SEC / (N * 4) * 1e6;
                song.playing = 0;                        /* (no playhead moving) */
                ui_draw(); ui_draw(); nscr = npend = 0;
                c0 = clock();
                for (i = 0; i < N * 4; i++) { ui.frame++; draw_graph(); nscr = npend = 0; }
                ti = (double)(clock() - c0) / CLOCKS_PER_SEC / (N * 4) * 1e6;
                fprintf(rep, "  %s: the panel redrawn %.1f us; an unchanged frame (signature only) %.2f us\n", S_NAME[G[k]], tg, ti);
            }
        }
        roll_cost();
        {   /* MENU > LARGE: the same full redraws, tall cards and the strip */
            static const int LC[] = {S_HOME, S_EDIT_ANALOG, S_ENV, S_LFO, S_MIXER, S_FX, S_PATTERN};
            fprintf(rep, "  MENU > LARGE:\n");
            large_on = 1;
            for (k = 0; k < sizeof LC / sizeof LC[0]; k++) {
                clock_t c0;
                uint64_t px, nt;
                setup(LC[k]); pal(1);
                draw(LC[k]);
                px_visited = n_text = 0;
                c0 = clock();
                for (i = 0; i < N; i++) draw(LC[k]);
                px = px_visited / N; nt = n_text / N;
                fprintf(rep, "  %-16s %15.1f %13llu %15llu\n", S_NAME[LC[k]], (double)(clock() - c0) / CLOCKS_PER_SEC / N * 1e6,
                        (unsigned long long)nt, (unsigned long long)px);
            }
            {
                clock_t c0;
                setup(S_HOME); pal(1); draw(S_HOME);
                px_visited = n_text = 0;
                c0 = clock();
                for (i = 0; i < N * 4; i++) { ui_draw(); nscr = npend = 0; }
                fprintf(rep, "  LARGE HOME, a frame without force (lazy strips): %.1f us, %llu texts\n",
                        (double)(clock() - c0) / CLOCKS_PER_SEC / (N * 4) * 1e6, (unsigned long long)(n_text / (N * 4)));
                setup(S_ENV); pal(1); draw(S_ENV);
                px_visited = n_text = 0;
                c0 = clock();
                for (i = 0; i < N * 4; i++) { ui_draw(); nscr = npend = 0; }
                fprintf(rep, "  LARGE ENV, a frame without force (lazy strips): %.1f us, %llu texts\n",
                        (double)(clock() - c0) / CLOCKS_PER_SEC / (N * 4) * 1e6, (unsigned long long)(n_text / (N * 4)));
            }
            large_on = 0;
        }
    }
    al_off = 0;
    al_keycaps();
    align_sweeps();
    al_table();
    if (al_rep) fclose(al_rep);
    fprintf(rep, "\nalignment: %u measurements of %u places, %u off by 1 px or more (OUTDIR/align.txt)\n", al_count, al_nst - 1u, al_fail);
    if (audf) fclose(audf);
    fprintf(rep, "\n%u lint findings, %u inks on their own colour, %u ellipsised free texts, %u GREY / MONO pixels off gray / "
            "neutral; %u column values swept; %u FM6 charts linted; %u cards linted with MOTION's icon; "
            "%u sweep values in text_audit.tsv (%u of them RATE labels, rate_value / rate_px / rate_elided)\n",
            nfind, nink, nfree, mono_bad, nsweep, fmp_charts, nmotion, nvalue_audit, nrate_audit);
    if (!nmotion) { fprintf(stderr, "ui_render: the MOTION sweep marked no card\n"); nfind++; }
    fclose(rep);
    printf("ui_render: %u screens x %u palettes + the page/value sweep; %u lint findings, %u ellipsised free texts (%u distinct), "
           "%u inks on their own colour, %u GREY / MONO pixels off gray / neutral; report %s\n",
           (unsigned)(S_COUNT - (FELUCCA_FM4 ? 0 : 1 + S_OP_LEVEL - S_ALG1 + 1)), (unsigned)NPALETTES, nfind, nfree, nfree_seen, nink,
           mono_bad, path);
    printf("ui_render: alignment: %u measurements of %u places, %u off by 1 px or more%s\n", al_count, al_nst - 1u, al_fail,
           al_fail ? " (see align.txt)" : "");
    return nfind || nink || mono_bad || al_fail ? 1 : 0;
}
