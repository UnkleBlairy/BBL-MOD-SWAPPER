Skiff Atlatl 1.2.5 for the BBL Mod Swapper

Original by LIkst4: https://github.com/LIkst4/skiff-atlatl
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: ATLATL-source.zip on the ports page.
