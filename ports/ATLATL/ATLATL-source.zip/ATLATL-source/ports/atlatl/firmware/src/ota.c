/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* M-UPGRADE entry: "step 1 lite".
 *
 * The updater talks SysEx (F0 pack7(00 59 cmd len24 body chk) F7):
 *   cmd 0x11  handshake -> we answer our package identity (FELUCCA_ID)
 *   F0 22 24 35 7F F7  upgrade -> ota_session(): pull parts of the package
 *     with cmd 0x30 read requests, check them, stage the package's update
 *     loader at 0xE0000 (outside Felucca's store), ask 0xE0000000 ("success"),
 *     then write the UPDATA_PARM record (flash 0xE4F00 + RAM 0x01C7FD88) and
 *     reset. The SPL runs the loader, which installs the package.
 * Nothing is committed before the host's "success"; a failure after the
 * staging began erases the staging area, and Felucca carries on. A package
 * whose flash.bin is not exactly this board's size (OTA_FL_LEN: another
 * board's package; (2.0.2, #64) on the FM-1 also M-VAVE's V16, OTA_FL_V16,
 * with the official loader only) is refused in step 1 or 2, before anything
 * is erased.
 *
 * Portable core: the firmware (felucca.c) and the Mac test (ota_test.c)
 * supply these hooks:
 *   ota_wire_send(p, n)        one complete F0..F7 message to the host
 *   ota_frame_get(&p, &n)      next received SysEx (7-bit bytes between F0/F7), 0 if none
 *   ota_frame_done()           release it
 *   ota_now_ms(), ota_idle()   time; called while waiting (watchdog, USB)
 *   ota_erase(off) ota_prog(off, p, n) ota_fread(off, p, n)   flash, 0 = ok
 *   ota_show(step, code)       progress / result for the screen
 *   ota_commit(parm)           write RAM record + reset (never returns on hardware)
 */
#if BOARD_SMK37
/* SMK-37 Pro (after genkigenki's SMK-37 layer): the last 5 sectors of the stock VM (0xBB000..0xBFFFF, FL_OTA in
 * fm1_flash_map.h), below BTIF / USRTRIM 0xC0000..0xC1FFF; the update loader drops records only below 0xC0000 */
#define OTA_AREA 0x000BB000u                     /* staged loader, 5 x 4 KiB */
#define OTA_AREA_LEN 0x5000u
#define OTA_RES (OTA_AREA + OTA_AREA_LEN - 0x100u)  /* 0xBFF00 = 4K boundary - 256: SPL scan */
#define OTA_FL_LEN 0x9D000u                      /* flash.bin = [0, the PRCT end): the head and the SMK's app area
                                                  * (ldr_core.c LDR_APP_HI): an FM-1 package is refused, and back */
#ifndef SMK_MODEL
#define SMK_MODEL "SMK-37 Pro"                   /* (fm1_cc.h) */
#endif
#define OTA_PARM_ID "ota-" SMK_MODEL "_016"       /* the stock app's record identity (Pro 18 B, Elite 20 B) */
#define OTA_FL_V16 OTA_FL_LEN                    /* (no other official size here) */
_Static_assert(OTA_AREA + OTA_AREA_LEN <= 0xC0000u && OTA_AREA >= 0x9D000u, "SMK: OTA area outside the VM");
#else
#define OTA_AREA 0x000E0000u                     /* staged loader, 5 x 4 KiB */
#define OTA_AREA_LEN 0x5000u
#define OTA_RES (OTA_AREA + OTA_AREA_LEN - 0x100u)  /* 0xE4F00 = 4K boundary - 256: SPL scan */
#define OTA_FL_LEN 0x93000u                      /* flash.bin = [0, the PRCT end): the head and this board's app area,
                                                  * the size the update loader writes (ldr_core.c LDR_APP_HI) */
#define OTA_PARM_ID "ota-FM-1_015"
#define OTA_FL_V16 0xA9000u                      /* ((2.0.2, #64) M-VAVE's V16, FM-1_016: its PRCT reaches 0xA9000 (DX7.bin
                                                  * in it); the same official loader as V15's writes it */
#endif
#define OTA_LDR_HCRC 0xEBAAu                     /* official update loader (usb_hid_ota.bin) */
#define OTA_LDR_DCRC 0x5881u
#define OTA_LDR_LEN 0x4DE1u
#define OTA_FRAME_MAX 640u                       /* 512-B response = 605 wire bytes */
#if !BOARD_SMK37 && !defined(FELUCCA_LOADER)
/* (Skiff) the way back to V15. Skiff's pattern pool (bank.c bk_sector: 0xE7000..0xE8FFF, 0xEA000..0xFBFFF) is V15's
 * USR region: its factory DX7 voices from 0xEA000 (A/B), its run-time records from 0xF2000, its factory table at
 * 0xFA000, all from the package's USR entry (type 50, 73,226 bytes for 0xEA000), and its system record at 0xE8000.
 * Nothing on the way back rewrites that region, so V15 found Skiff's leftovers there (seen on a unit: most voices mono
 * and legato after Skiff, through every reinstall, until 0xF2000..0xFBFFF was reset from the package). For V15's
 * package the app writes the USR entry back over the pool, and erases a pool sector at 0xE7000 / 0xE8000 that holds a
 * pattern chunk (V15 rebuilds its system record when it finds it erased), before the host's confirmation. */
#define OTA_USR 1
#define OTA_USR_TYPE 50u
#define OTA_USR_LO 0xEA000u                      /* the USR entry's place (fm1_flash_map.h FL_USR) */
#define OTA_USR_HI 0xFC000u
#define OTA_USR_KEY 0x980Fu                      /* its cipher: JieLi ENC, key ^ (image offset >> 2) per 32-byte block */
#define OTA_POOL_LO 0xE7000u                     /* the pool's two sectors below BTIF (FL_BANK) */
#define OTA_POOL_HI 0xE9000u
static uint32_t ota_usr_off, ota_usr_len, ota_usr_crc;   /* (ota_ufw) the USR entry; len 0: none */
#else
#define OTA_USR 0
#endif

static int ota_wire_send(const uint8_t *p, uint32_t n);
static int ota_frame_get(const uint8_t **p, uint32_t *n);
static void ota_frame_done(void);
static uint32_t ota_now_ms(void);
static void ota_idle(void);
static int ota_erase(uint32_t off);
static int ota_prog(uint32_t off, const void *p, uint32_t n);
static int ota_fread(uint32_t off, void *p, uint32_t n);
static void ota_show(uint32_t step, int32_t code);
static void ota_commit(const uint8_t *parm);

static uint32_t ota_rd16(const uint8_t *p) { return (uint32_t)p[0] | (uint32_t)p[1] << 8; }
static uint32_t ota_rd24(const uint8_t *p) { return ota_rd16(p) | (uint32_t)p[2] << 16; }
static uint32_t ota_rd32(const uint8_t *p) { return ota_rd24(p) | (uint32_t)p[3] << 24; }
static void ota_wr16(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void ota_wr32(uint8_t *p, uint32_t v) { ota_wr16(p, v); ota_wr16(p + 2, v >> 16); }

static uint32_t ota_crc16(const uint8_t *p, uint32_t n, uint32_t c)   /* poly 0x1021, init 0 */
{
    uint32_t i;
    while (n--) {
        c ^= (uint32_t)*p++ << 8;
        for (i = 0; i < 8u; i++)
            c = c & 0x8000u ? (c << 1) ^ 0x1021u : c << 1;
        c &= 0xFFFFu;
    }
    return c;
}

static void ota_jl_enc(uint8_t *p, uint32_t n)   /* UFW header cipher, key 0xFFFF */
{
    uint32_t k = 0xFFFFu;
    while (n--) {
        *p++ ^= (uint8_t)k;
        k = ((k << 1) ^ (k & 0x8000u ? 0x1021u : 0u)) & 0xFFFFu;
    }
}

/* 8-to-7, LSB first */
static uint32_t ota_pack7(const uint8_t *in, uint32_t n, uint8_t *out)
{
    uint32_t acc = 0, nb = 0, o = 0;
    while (n--) {
        acc |= (uint32_t)*in++ << nb;
        nb += 8u;
        while (nb >= 7u) {
            out[o++] = (uint8_t)(acc & 0x7Fu);
            acc >>= 7;
            nb -= 7u;
        }
    }
    if (nb)
        out[o++] = (uint8_t)(acc & 0x7Fu);
    return o;
}

static uint32_t ota_unpack7(const uint8_t *in, uint32_t n, uint8_t *out, uint32_t max)
{
    uint32_t acc = 0, nb = 0, o = 0;
    while (n--) {
        acc |= (uint32_t)(*in++ & 0x7Fu) << nb;
        nb += 7u;
        if (nb >= 8u) {
            if (o < max)
                out[o] = (uint8_t)acc;
            o++;
            acc >>= 8;
            nb -= 8u;
        }
    }
    return o;
}

static uint8_t ota_msg[8 + 32], ota_wire[2 + 48];
static uint8_t ota_dec[OTA_FRAME_MAX];           /* decoded host message */

static int ota_send_msg(uint32_t cmd, const uint8_t *body, uint32_t n)   /* n <= 32 */
{
    uint32_t i, s = 0, w;
    ota_msg[0] = 0;
    ota_msg[1] = 0x59;
    ota_msg[2] = (uint8_t)cmd;
    ota_msg[3] = (uint8_t)n;
    ota_msg[4] = 0;
    ota_msg[5] = 0;
    for (i = 0; i < n; i++) {
        ota_msg[6 + i] = body[i];
        s += body[i];
    }
    ota_msg[6 + n] = (uint8_t)~s;
    ota_wire[0] = 0xF0;
    w = 1u + ota_pack7(ota_msg, 7u + n, ota_wire + 1);
    ota_wire[w++] = 0xF7;
    return ota_wire_send(ota_wire, w);
}

static void ota_reply_identity(void)
{
    static const char ID[] = FELUCCA_ID;         /* == the package marker string */
    uint8_t id[27];
    uint32_t i;
    for (i = 0; i < sizeof id; i++)
        id[i] = i < sizeof ID - 1u ? (uint8_t)ID[i] : 0;
    ota_send_msg(0x11, id, sizeof id);
}

/* decode the pending frame; returns its decoded length (0 = not ours) */
static uint32_t ota_take(void)
{
    const uint8_t *p;
    uint32_t n, d, s = 0, i;
    if (!ota_frame_get(&p, &n))
        return 0;
    d = ota_unpack7(p, n, ota_dec, sizeof ota_dec);
    ota_frame_done();
    if (d < 7u || d > sizeof ota_dec || ota_dec[0] != 0 || ota_dec[1] != 0x59 || ota_rd24(ota_dec + 3) + 7u != d)
        return 0;
    for (i = 6; i + 1u < d; i++)
        s += ota_dec[i];
    if ((uint8_t)~s != ota_dec[d - 1u])
        return 0;
    return d;
}

/* main loop, outside a session: answer handshakes */
#if BOARD_SMK37 && defined(FELUCCA_LOADER)
static void ota_reply_info(void);                /* (SMK loader, loader.c) 0x7B its start record, 0x7C the clocks */
static void ota_reply_clocks(void);
#endif
static void ota_service(void)
{
    uint32_t d = ota_take();
    if (d == 7u && ota_dec[2] == 0x11)
        ota_reply_identity();
#if BOARD_SMK37 && defined(FELUCCA_LOADER)
    else if (d == 7u && ota_dec[2] == 0x7Bu)
        ota_reply_info();
    else if (d == 7u && ota_dec[2] == 0x7Cu)
        ota_reply_clocks();
#endif
}

/* one read request (3 tries x 5 s); data -> dst */
static uint32_t ota_deadline;                    /* 0 = none; else ota_now_ms() limit of the session */

static int ota_read(uint32_t addr, uint8_t *dst, uint32_t len)
{
    uint8_t q[8];
    uint32_t tries, t, d, i;
    if (ota_deadline && (int32_t)(ota_now_ms() - ota_deadline) > 0)
        return -1;                                  /* the whole session took too long: give up */
    q[0] = 0;
    ota_wr32(q + 1, addr);
    q[5] = (uint8_t)len;
    q[6] = (uint8_t)(len >> 8);
    q[7] = 0;
    for (tries = 0; tries < 3u; tries++) {
        if (ota_send_msg(0x30, q, 8))
            return -1;
        for (t = ota_now_ms(); ota_now_ms() - t < 5000u;) {
            ota_idle();
            d = ota_take();
            if (!d)
                continue;
            if (d == 7u && ota_dec[2] == 0x11) {
                ota_reply_identity();
                continue;
            }
            if (d == len + 15u && ota_dec[2] == 0x30 && ota_rd24(ota_dec + 3) == len + 8u &&
                ota_rd32(ota_dec + 7) == addr && ota_rd24(ota_dec + 11) == len) {
                for (i = 0; i < len; i++)
                    dst[i] = ota_dec[14 + i];
                return 0;
            }
        }
    }
    return -1;
}

static int ota_memeq(const uint8_t *a, const uint8_t *b, uint32_t n)
{
    while (n--)
        if (*a++ != *b++)
            return 0;
    return 1;
}

/* JLFS head "LOADER.BIN" in front of the staged loader (vm_update_defrag), written last */
static int ota_stage_head(uint32_t len)
{
    static const char NAME[16] = "LOADER.BIN";
    uint8_t h[32];
    uint32_t i;
    for (i = 0; i < 32u; i++)
        h[i] = 0;
    ota_wr16(h + 2, 0xFFFFu);
    ota_wr32(h + 4, OTA_AREA);
    ota_wr32(h + 8, len + 32u);
    h[12] = 0x41u;
    h[13] = 0xFFu;
    ota_wr16(h + 14, 0xFFFFu);
    for (i = 0; i < 16u; i++)
        h[16 + i] = (uint8_t)NAME[i];
    ota_wr16(h, ota_crc16(h + 2, 30, 0));
    return ota_prog(OTA_AREA, h, 32);
}

/* UFW header + entry list (hdr: 1 KiB) from the host -> offset / length of
 * flash.bin (entry type 0) and ota.bin (type 100), 0 if absent; -1 read, -2 CRC */
static int ota_ufw(uint8_t *hdr, uint32_t *fl_off, uint32_t *fl_len, uint32_t *ota_off, uint32_t *ota_len)
{
    uint32_t i, nent;
    *fl_off = *fl_len = *ota_off = *ota_len = 0;
#if OTA_USR
    ota_usr_off = ota_usr_len = ota_usr_crc = 0;
#endif
    if (ota_read(0, hdr, 512) || ota_read(512, hdr + 512, 512))
        return -1;
    ota_jl_enc(hdr, 0x40);
    nent = ota_rd16(hdr + 8);
    if (ota_crc16(hdr + 2, 0x3E, 0) != ota_rd16(hdr) || nent == 0 || nent > 11u ||
        ota_crc16(hdr + 0x40, nent * 0x50u, 0) != ota_rd16(hdr + 2))
        return -2;
    for (i = 0; i < nent; i++) {
        uint8_t *e = hdr + 0x40 + i * 0x50u;
        ota_jl_enc(e, 0x50);
        if (ota_rd16(e) == 0) {                             /* flash.bin */
            *fl_off = ota_rd32(e + 8);
            *fl_len = ota_rd32(e + 12);
        }
        if (ota_rd16(e) == 100) {                           /* ota.bin */
            *ota_off = ota_rd32(e + 8);
            *ota_len = ota_rd32(e + 12);
        }
#if OTA_USR
        if (ota_rd16(e) == OTA_USR_TYPE) {                 /* (Skiff) V15's USR image; its CRC16 is the plaintext's */
            ota_usr_off = ota_rd32(e + 8);
            ota_usr_len = ota_rd32(e + 12);
            ota_usr_crc = ota_rd16(e + 4);
        }
#endif
    }
    return 0;
}

#if OTA_USR
/* (Skiff) 512 bytes of the USR image from at, decrypted; 0xFF past its end */
static int ota_usr_get(uint32_t at, uint8_t *p)
{
    uint32_t i, k = 0, pos = ota_usr_off + at, n = at >= ota_usr_len ? 0u : ota_usr_len - at;
    if (n > 512u)
        n = 512u;
    if (n && ota_read(pos, p, n))
        return -1;
    for (i = 0; i < n; i++) {
        if (!(i & 31u))
            k = (OTA_USR_KEY ^ ((pos + i) >> 2)) & 0xFFFFu;
        p[i] ^= (uint8_t)k;
        k = ((k << 1) ^ (k & 0x8000u ? 0x1021u : 0u)) & 0xFFFFu;
    }
    for (i = n; i < 512u; i++)
        p[i] = 0xFFu;
    return 0;
}

/* (Skiff) V15's USR region from its package, sector by sector over the pool: a sector already equal is left, one that
 * differs is erased, written and read back (a sector that comes in different the second time is written again); then
 * the whole image's CRC16 must be its entry's. -16 on any failure: the app stays on Skiff (it reads the pool's sectors
 * without its commit records as empty), so a bad image never reaches V15 */
static int ota_usr_restore(uint8_t *b, uint8_t *mine)
{
    uint32_t s, i, at, crc = 0, want, got, dirty, tries;
    if (ota_usr_len > OTA_USR_HI - OTA_USR_LO || (ota_usr_off & 31u))
        return -16;
    for (s = OTA_USR_LO; s < OTA_USR_HI; s += 0x1000u) {
        for (i = 0, want = 0, dirty = 0; i < 0x1000u; i += 512u) {
            at = s - OTA_USR_LO + i;
            if (ota_usr_get(at, b) || ota_fread(s + i, mine, 512))
                return -16;
            if (at < ota_usr_len)
                crc = ota_crc16(b, ota_usr_len - at > 512u ? 512u : ota_usr_len - at, crc);
            want = ota_crc16(b, 512, want);
            dirty |= !ota_memeq(b, mine, 512);
        }
        for (tries = 0; dirty && tries < 2u; tries++) {
            if (ota_erase(s))
                return -16;
            for (i = 0, got = 0, dirty = 0; i < 0x1000u; i += 512u) {
                if (ota_usr_get(s - OTA_USR_LO + i, b) || ota_prog(s + i, b, 512) || ota_fread(s + i, mine, 512))
                    return -16;
                got = ota_crc16(b, 512, got);
                dirty |= !ota_memeq(b, mine, 512);
            }
            dirty |= got != want;
        }
        if (dirty)
            return -16;
    }
    if (crc != ota_usr_crc)
        return -16;
    for (s = OTA_POOL_LO; s < OTA_POOL_HI; s += 0x1000u)   /* a pattern chunk's commit record ("SKB1", bank.c) */
        if (ota_fread(s, b, 4) || (ota_memeq(b, (const uint8_t *)"SKB1", 4) && ota_erase(s)))
            return -16;
    return 0;
}
#endif

#if BOARD_SMK37 && !defined(FELUCCA_LOADER)
/* (SMK-37 Pro) for M-VAVE's own package the app stages ITS OWN loader, not the package's: M-VAVE's loader, staged by
 * Skiff, erased BTIF and USRTRIM (the key calibration) on the unit (SMK37.md). Ours writes the official flash.bin's app
 * area as it writes Skiff's (0x4000..0x9CFFF, the head checked equal here first, header last, FL_GUARD) and ignores
 * the package's other entries (its USR image for 0xF4000 is not written). The record keeps OTA_PARM_ID */
#define OTA_OWN_LDR 1
#ifndef OTA_LDR_HOST
#include "smk_ldr.h"                             /* build/gen (build.py): SMK_LDR, this build's ota.bin */
#endif
static uint8_t ota_emb;                          /* 1: this session stages SMK_LDR */
static int ota_ldr_read(uint32_t pkg_off, uint32_t off, uint8_t *dst, uint32_t n)   /* the loader being staged */
{
    uint32_t i;
    if (!ota_emb)
        return ota_read(pkg_off + off, dst, n);
    if (off + n > SMK_LDR_LEN)
        return -1;
    for (i = 0; i < n; i++)
        dst[i] = SMK_LDR[off + i];
    return 0;
}
#else
#define OTA_OWN_LDR 0
#endif

/* ota_stage's failures from step 4's first erase on (-8 .. -13, (Skiff) -16; the steps before: -1 .. -7 and -15,
 * nothing written) */
#define OTA_STAGED_RC(rc) (((rc) <= -8 && (rc) >= -13) || (rc) == -16)
static int ota_stage(void)                       /* steps 1..6; 0 = host said success */
{
    static uint8_t hdr[0x400], b[512], mine[512];
    uint32_t i, n, ota_off, ota_len, fl_off, fl_len, c, len, own, official;
    int rc;
#if OTA_OWN_LDR
    ota_emb = 0;
#endif
    /* 1. UFW header + entry list */
    ota_show(1, 0);
    if ((rc = ota_ufw(hdr, &fl_off, &fl_len, &ota_off, &ota_len)) != 0)
        return rc;
    if (!fl_off || !ota_off)
        return -3;
    if (fl_len != OTA_FL_LEN && fl_len != OTA_FL_V16)
        return -15;                                         /* another board's package: nothing staged, nothing erased
                                                             * ((2.0.2) after the header's 2 reads: web/fm1ota.js
                                                             * stockRefusal tells a Skiff too old for V16 by it) */
    /* 2. which loader: the official one (known CRCs; it rewrites the whole flash.bin
     *    including the head) or Felucca's own (app area only, checks the chip key) */
    if (ota_read(ota_off, b, 512))
        return -6;
    len = ota_rd32(b + 8);
    if (ota_crc16(b + 2, 30, 0) != ota_rd16(b) || ota_rd32(b + 4) != 0x20u || b[12] != 0x41u ||
        ota_len != len + 0x20u || len > OTA_AREA_LEN - 0x200u || ota_crc16(b + 0x22, 30, 0) != ota_rd16(b + 0x20) ||
        ota_rd32(b + 0x20 + 8) != 0x01C0A800u)
        return -7;
    official = ota_rd16(b) == OTA_LDR_HCRC && ota_rd16(b + 2) == OTA_LDR_DCRC && len == OTA_LDR_LEN;
    for (i = 0x48, own = 0; i + 16u <= 0x48u + 64u && !own; i++)    /* first LZ4 literals: crt0_ldr.S */
        own = ota_memeq(b + i, (const uint8_t *)"FELUCCA-LOADER-1", 16) && ota_rd32(b + 0x20 + 4) <= 0x14000u;
    if (!official && !own)
        return -7;
    if (!official && fl_len != OTA_FL_LEN)
        return -15;                                         /* ((2.0.2) V16's size: M-VAVE's loader's alone) */
    if (official) {                    /* the official loader writes the head: it must equal ours */
        ota_show(2, 0);
        for (i = 0; i < 0x4000u; i += 512u) {
            if (ota_read(fl_off + i, b, 512) || ota_fread(i, mine, 512))
                return -4;
            if (!ota_memeq(b, mine, 512))
                return -5;                                  /* ((2.0.2, #64) V15's on a unit V16 started, or back:
                                                             * within the head's 32 reads after the 3 before them,
                                                             * web/fm1ota.js stockRefusal names the other version) */
        }
#if OTA_OWN_LDR
        ota_emb = 1;                                       /* (ours in its place: its own length) */
        len = ota_rd32(SMK_LDR + 8);
#endif
    }
    /* 4. stage the package's loader: erase, body, verify, head last */
    ota_show(3, 0);
#if OTA_OWN_LDR
    if (ota_ldr_read(ota_off, 0, b, 512))
#else
    if (ota_read(ota_off, b, 512))
#endif
        return -6;
    c = ota_rd16(b + 2);                                    /* outer dcrc of the body */
    for (i = 0; i < OTA_AREA_LEN; i += 0x1000u)
        if (ota_erase(OTA_AREA + i))
            return -8;
    {
        uint32_t crc = 0;
        for (i = 0; i < len; i += n) {
            n = len - i > 512u ? 512u : len - i;
#if OTA_OWN_LDR
            if (ota_ldr_read(ota_off, 0x20u + i, b, n))
#else
            if (ota_read(ota_off + 0x20u + i, b, n))
#endif
                return -9;
            crc = ota_crc16(b, n, crc);
            if (ota_prog(OTA_AREA + 32u + i, b, n))
                return -10;
        }
        if (crc != c)
            return -11;
        for (i = 0, crc = 0; i < len; i += n) {             /* read back from flash */
            n = len - i > 512u ? 512u : len - i;
            if (ota_fread(OTA_AREA + 32u + i, b, n))
                return -11;
            crc = ota_crc16(b, n, crc);
        }
        if (crc != c)
            return -11;
    }
    if (ota_stage_head(len))
        return -12;
#if OTA_USR
    /* 4b. (Skiff) V15's package (flash.bin V15's size, a USR entry): its USR region back over the pool */
    if (official && fl_len == OTA_FL_LEN && ota_usr_len && (rc = ota_usr_restore(b, mine)) != 0)
        return rc;
#endif
    /* 6. the host confirms: nothing is committed without it */
    ota_show(4, 0);
    for (i = 0; i < 4u; i++)
        if (!ota_read(0xE0000000u, b, 8) && ota_memeq(b, (const uint8_t *)"success", 8))
            return 0;
    return -13;
}

static void ota_unstage(void)
{
    uint32_t i;
    for (i = 0; i < OTA_AREA_LEN; i += 0x1000u)
        ota_erase(OTA_AREA + i);
}

/* returns only when nothing was committed (refused, failed, or dry run) */
static int ota_session(void)
{
    static uint8_t parm[112];
    uint8_t back[112];
    uint32_t i;
    int rc;
    ota_deadline = ota_now_ms() + 120000u;          /* step 1 normally takes ~5 s; a stalled host gives up after 2 min */
    rc = ota_stage();
    if (rc) {
        if (OTA_STAGED_RC(rc))                          /* (refused before staging: nothing to erase) */
            ota_unstage();
        ota_show(9, rc);
        return rc;
    }
    /* 5./7. UPDATA_PARM (update_mode_api_v2 layout), flash copy first */
    for (i = 0; i < sizeof parm; i++)
        parm[i] = 0;
    ota_wr16(parm + 2, 0x5A0Du);
    ota_wr16(parm + 4, 0x5A01u);
    ota_wr16(parm + 6, 0x5441u);
    for (i = 0; i < sizeof OTA_PARM_ID - 1u; i++)    /* FM-1 12 B, SMK 18 / 20 B; zero up to +0x27 */
        parm[8 + i] = (uint8_t)OTA_PARM_ID[i];    /* the loader's own USB identity */
    ota_wr32(parm + 72, OTA_AREA);
    ota_wr16(parm, ota_crc16(parm + 2, 78, 0));
#if FELUCCA_OTA_DRYRUN
    ota_unstage();
    ota_show(9, 1);                                 /* 1 = dry run complete */
    return 1;
#endif
#ifndef FELUCCA_OTA_RAMONLY
#define FELUCCA_OTA_RAMONLY 0                       /* 1: RAM record only, no power-loss resume (a power
                                                     * cycle leaves a broken loader behind) */
#endif
    if (!FELUCCA_OTA_RAMONLY && (ota_prog(OTA_RES, parm, sizeof parm) || ota_fread(OTA_RES, back, sizeof back) ||
        !ota_memeq(back, parm, sizeof parm))) {
        ota_unstage();
        ota_show(9, -14);
        return -14;
    }
    ota_show(5, 0);
    ota_commit(parm);
    return 0;
}

/* boot: a staging area left over (we are running, so the update finished or
 * never started): erase it so the SPL does not re-enter the loader */
static int ota_boot_cleanup(void)
{
    uint8_t a[4], r[8];
    uint32_t i, used = 0;
    if (ota_fread(OTA_AREA, a, 4) || ota_fread(OTA_RES, r, 8))
        return -1;
    for (i = 0; i < 4u; i++)
        used |= a[i] != 0xFFu;
    for (i = 0; i < 8u; i++)
        used |= r[i] != 0xFFu;
    if (used)
        ota_unstage();
    return (int)used;
}
