Scintilla 0.3.2 for the BBL Mod Swapper

Original by joakimeriksson: https://github.com/joakimeriksson/scintilla-fm1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: SCINTILL-source.zip on the ports page.
