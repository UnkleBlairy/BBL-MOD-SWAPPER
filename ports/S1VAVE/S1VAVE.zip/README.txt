S1Vave 2.0.1 for the BBL Mod Swapper

Original by AndrewGG88: https://github.com/AndrewGG88/S1Vave
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: S1VAVE-source.zip on the ports page.
