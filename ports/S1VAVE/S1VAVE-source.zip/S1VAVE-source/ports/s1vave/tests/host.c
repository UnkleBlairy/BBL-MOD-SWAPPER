/* SPDX-License-Identifier: GPL-3.0-only */
/* A fake FM-1 on a computer: the app (firmware/src/s1vave.c) runs unchanged on it. platform.c includes
 * this file instead of the hardware when OBV_HOST is set. A script presses keys over time; out come
 * the screen (PPM, at the times SHOT asks) and the sound (WAV, as the FM-1 sends it over USB).
 *
 *   mkdir -p build/host
 *   cc -O2 -Wall -DOBV_HOST -Ifirmware/src -Ifirmware/gen -o build/host/s1vave firmware/src/s1vave.c
 *   build/host/s1vave build/host/s1vave        (-> build/host/s1vave.wav, build/host/s1vave-<ms>.ppm)
 *   build/host/s1vave OUT script.txt [FPS]    (your own script; with FPS: OUT-NNNNN.ppm, a frame every 1/FPS s:
 *                                             a film of your firmware, e.g. ffmpeg -r 30 -i OUT-%05d.ppm ...)
 *
 * Change SCRIPT below to try your own app. */
#include <stdint.h>
#ifndef OBV_WASM                                /* (OBV_WASM: the browser simulator, web/sim/sim.c, brings its own few) */
#endif
#ifdef __linux__
#endif

#ifndef APP_NAME
#define APP_NAME "S1VAVE"
#endif
#ifndef APP_VER
#define APP_VER "0.0"
#endif
#define FS 44100u
#define HALF_FRAMES 256u

static volatile uint32_t fm1_ms;
#if BOARD_SMK37
/* the SMK-37 (hal/smk_input.h's API, as obv_smk.h uses it): keys with velocity, pads as events, 4 faders, 2 wheels,
 * the outer keys, the pad LEDs; 8 encoders (K1 = MASTER) */
#define FM1_NKEY 37u
#define SMK_KEY_F3 5u
#define HOST_NENC 8
static struct {
    uint32_t notes, buttons, frames, adc_ok, adc_miss;
    uint64_t keys;
    uint8_t key_vel[FM1_NKEY], fader[4];
    uint16_t wheel[2], batt, pad_raw[16], pad_base[16];
} fm1_in = {.wheel = {535, 620}};               /* (the wheels at rest, as a unit reads them) */
static uint8_t smk_store_cleared, smk_trim_ok;
static uint32_t smk_jedec;
static uint8_t smk_pad_events;
static int32_t smk_master = 724;
static int32_t host_q[2][64];                   /* 0: pad events, 1: outer keys (key << 8 | velocity, 0 = release) */
static uint32_t host_qw[2], host_qr[2];
static void host_qput(int i, int32_t v) { host_q[i][host_qw[i]++ % 64u] = v; }
static int32_t host_qtake(int i) { return host_qr[i] == host_qw[i] ? -1 : host_q[i][host_qr[i]++ % 64u]; }
static int32_t smk_pad_take(void) { return host_qtake(0); }
static int32_t smk_extkey_take(void) { return host_qtake(1); }
static uint32_t padled_rgb[16];                 /* as lcd.c: g << 16 | r << 8 | b */
static void padled_set(uint32_t pad, uint8_t r, uint8_t g, uint8_t b) { if (pad < 16u) padled_rgb[pad] = (uint32_t)g << 16 | (uint32_t)r << 8 | b; }
static void padled_flush(void) {}
static void host_dump(void);                    /* (obv_smk.h) */
#else
#define HOST_NENC 7
static struct { uint32_t notes, buttons; } fm1_in;
#endif

/* teensy-fm1: the panel and the screen are the Teensy's */
static uint32_t din_press, din_rel, din_nedge, din_px;
static int32_t din_enc[8];
static uint8_t din_led[64], din_glow[64];
static uint32_t fm1_input_edges(uint32_t *released) { uint32_t b = din_press; din_press = 0; if (released) *released = din_rel; din_rel = 0; return b; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = din_nedge; din_nedge = 0; return e; }
static int32_t fm1_enc_take(uint32_t e) { int32_t v = din_enc[e & 7u]; din_enc[e & 7u] = 0; return v; }
static void fm1_led_key(uint32_t id, int on) { din_led[id & 63u] = (uint8_t)!!on; }
static void fm1_led_key_glow(uint32_t id, int on) { din_glow[id & 63u] = (uint8_t)!!on; }
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            sh_put(j * 240u + i, sh_be16(c));
    din_px += w * h;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            sh_put((y + j) * 240u + x + i, px[j * w + i]);      /* (gfx.c's pixels are high byte first already) */
    din_px += w * h;
}
static uint32_t host_edges, host_rel, host_rel_next;   /* press edges, release edges (a tap's release: the call after) */

   /* (the script sets fm1_in.notes) */
static int32_t host_enc[HOST_NENC], host_enc_pos[HOST_NENC];   /* detents owed to the app; the position so far (the film's log) */

static uint64_t host_leds;                      /* bit id: LED id lit (0..13 buttons, 14..40 keys) */

static uint64_t host_glow;                      /* the dim layer (not in the film log) */

static inline int32_t platform_battery_bars(void) { return 4; }

/* the screen: 240 x 240 RGB565, as the ST7789 gets it (gfx.c sends the bytes swapped) */
#define fb shl_fb



#define CV_MAX (240u * 120u)
#include "gfx.c"

#define SETTINGS_MAX (4096u - 12u)
static uint8_t host_store[SETTINGS_MAX + 4];
static int settings_load(void *p, uint32_t n)
{
    static int v2_done;
#ifndef OBV_WASM
    if (!v2_done && getenv("OBV_V2")) {         /* (test: a 1.4 store: program 4 the user's, "MMMMMMMMMM") */
        v2_done = 1;
        host_store[0] = 1;
        host_store[4] = 2; host_store[5] = 3; host_store[6] = 100;   /* version 2, program 4, 100 BPM */
        host_store[4 + 8] = 1u << 3;            /* used: bit 3 */
        memset(host_store + 4 + 12 + 3 * 80, 'M', 80);
    }
#endif
    if (host_store[0] != 1 || n > SETTINGS_MAX) return -1;
    memcpy(p, host_store + 4, n);
    return 0;
}
static int settings_save(const void *p, uint32_t n)
{
    if (n > sizeof host_store - 4u) return -1;   /* teensy-fm1 */
    host_store[0] = 1;
    memcpy(host_store + 4, p, n);
    printf("%6u ms  settings saved (%u B)\n", fm1_ms, n);
    return 0;
}
#define NBLOB 8u
static uint8_t host_blob[NBLOB][SETTINGS_MAX + 4];
static int blob_load(uint32_t i, void *p, uint32_t n)
{
    if (i >= NBLOB || host_blob[i][0] != 1 || n > SETTINGS_MAX) return -1;
    memcpy(p, host_blob[i] + 4, n);
    return 0;
}
static int blob_save(uint32_t i, const void *p, uint32_t n)
{
    if (i >= NBLOB || n > SETTINGS_MAX) return -1;
    host_blob[i][0] = 1;
    memcpy(host_blob[i] + 4, p, n);
    printf("%6u ms  blob %u saved (%u B)\n", fm1_ms, i, n);
    return 0;
}
#define NPSECT 2u
static uint8_t host_psect[NPSECT][SETTINGS_MAX + 4];
static int psect_load(uint32_t i, void *p, uint32_t n)
{
    if (i >= NPSECT || host_psect[i][0] != 1 || n > SETTINGS_MAX) return -1;
    memcpy(p, host_psect[i] + 4, n);
    return 0;
}
static int psect_save(uint32_t i, const void *p, uint32_t n)
{
    if (i >= NPSECT || n > SETTINGS_MAX) return -1;
    host_psect[i][0] = 1;
    memcpy(host_psect[i] + 4, p, n);
    printf("%6u ms  programs %u saved (%u B)\n", fm1_ms, i, n);
    return 0;
}

static uint8_t mq[64][3];
static uint32_t mq_w, mq_r;
static int midi_get(uint8_t *st, uint8_t *d1, uint8_t *d2)
{
    if (mq_r == mq_w) return 0;
    *st = mq[mq_r % 64u][0]; *d1 = mq[mq_r % 64u][1]; *d2 = mq[mq_r % 64u][2];
    mq_r++;
    return 1;
}
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2) { printf("%6u ms  MIDI out %02X %u %u\n", fm1_ms, st, d1, d2); }

static void app_audio(int32_t *out, uint32_t n);
static void app_main(void);
