# Credits

## Felucca

Rainbow mode is built on [Felucca](https://github.com/hugelton/Felucca), the multi-engine synthesizer firmware for the M-VAVE FM-1 by
Leo Kuroshita and Hügelton Instruments (GPL-3.0). Every sound, the sequencer, the screen and the web installer are Felucca's.

## Ideas from the community

Thank you to the people who suggested these on r/MVaveFM1:

| Who | What they suggested | What it became |
| --- | --- | --- |
| u/veecheech | A T-Rex with a growly bass | **T-REX** (a saw bass driven hard through DIST, ROCK beat) |
| u/veecheech | A skeleton with a wide-vibrato, theremin-like spooky sound | **SKELETON** (a sine with a wide vibrato that slides between notes, SPOOKY beat) |
| u/veecheech | Western friends with a twangy guitar pluck | **RANCHER** and **RODEO** (twangy plucks, and a new beat for them: HOEDOWN) |
| u/veecheech | A vacuum with a "hoover" bass, a joke for the adults | **VACUUM** (ANALOG RAVE, the rave hoover) |
| u/veecheech | A space ranger with a buzzy, spacey synth | **SPACE HERO** (TRIO SAW3: three buzzy saws that swoop into each note and shimmer, STARS sky, DISCO beat) |
| u/lastapoc | "Mario Paint music mode" | **WRITE** (SAVE): write a song on a big staff, each note a friend, and plays it back |
| u/veecheech | Omnichord strumming with chords (as dxsloop's arp mode does it) | **STRUM** (ALGORITHM): black keys pick a chord, white keys strum it |
| u/nutty_cartoon | Show chords, not only the last key | Keys held together show their letters and the chord's name |
| u/nutty_cartoon | An ear game: a note plays, find the key | **GUESS** (ALGORITHM), gentle: TRY AGAIN with no sound of its own |
| u/nutty_cartoon | Simple songs to learn by following lit keys | **FOLLOW** (ALGORITHM): old songs to learn (34 now), the next key lit |
| u/theskyisfalling1 | Show the note value on the staff by how long a key is held, so kids learn rhythm too | The staff writes sixteenths, eighths, quarters, halves and wholes, and a held note grows while the key is down |
| u/Yablan | Learning really basic lofi chords | **CHORDS** (ALGORITHM): lessons from first chords to lofi, the chord's keys lit and named, and a slow, swung LOFI beat to practice over |
| u/litomanu | 303-style acid sounds | **SCIENTIST**, **FLYTRAP** and **SUNFLOWER** on ANALOG's ACID (the Scientist set like a TD-3), and the **ACID** beat with a 303-style line |
| u/ReallyLongLake | A secret setting that turns off the characters based on TV and film ones | **LOOK-ALIKES** (HOME held 1 s, then PRESETS left / right): swaps them for original stand-ins with the same sounds (a spider, a fox, a bat, an alien and more), kept over power-off |
| u/Competitive_Tank_150 | Note names as Do Re Mi, the way they are taught in Brazil | **NOTE NAMES**: HOME held 1 s, then KNOB 2 |
| u/jrej | A picture for each song, for a child who can't read yet, and SEQ lit where it picks the song | **FOLLOW**: each song's friend picture in the band; SEQ lit in FOLLOW and CHORDS |
| @eyeball226 (YouTube) | CHORDS should sound the chords: on a one-note friend it played a single note | **CHORDS** now plays every chord in full on every friend that plays notes. One-note leads and basses get their voices there, as in 3 FRIENDS, and the sub octave steps aside so the chord keeps all its notes over the LOFI beat |
| u/Quaglek's daughter | A peacock | **PEACOCK**: its tail fanned out, with a shimmer that runs across it, and a harp in a great hall |
| u/Competitive_Tank_150 | Brazilian songs | **Rainbow mode in Portuguese** (its own firmware, on the site at /pt/): Do Re Mi from the start and 15 Brazilian children's songs in FOLLOW |

The characters are original drawings in the spirit of the suggestions, not copies. They are credited on the website and on the
installer page too.

## The Brazilian songs

The 15 Brazilian songs in the Portuguese version's FOLLOW are copied note for note from the recorder pages of
[Cifra Visual](https://www.cifravisual.com.br/flauta-doce), which marks each one as public domain (domínio público).

## Japanese

The Japanese version's kana are from the Misaki Gothic 2nd font by Num Kadoma (<https://littlelimit.net/misaki.htm>),
which is free to use, change and pass on (`LICENSES/Misaki.txt`). Its FOLLOW songs are read from the scores in Japanese
Wikipedia's articles on them (and German Wikipedia's for ちょうちょう, かっこう and きよしこのよる).

## The songs in the other languages

The German, French, Spanish, Italian, Dutch, Swedish, Norwegian and Danish versions' FOLLOW songs are read note for note from
the scores in Wikipedia's articles on them (named in each `tools/lang/LL.py`). The tunes are traditional or long out of
copyright: the newest are Carl Nielsen's (died 1931) and Ole Jacobsen's (died 1921) Danish ones.

## Melodee

The eight Prophet-style friends (Elephant to Camel) were nudged by [Melodee](https://github.com/keremimo/melodee), Kerem Kilic's
Felucca fork with a PROPHET engine for Sequential Prophet-5 programs. No Melodee code and none of Sequential's programs are used:
the sounds are Felucca's own engines, tweaked toward the Prophet's classic patches.

## Also

- The treble clef: from the FreeSerif font (GNU FreeFont, GPL-3.0 or later), scaled down to a bitmap.
- Everything else: original work in this repository, GPL-3.0.
