Felucca Rainbow 1.1.5 for the BBL Mod Swapper

Original by joshbartlettband-web: https://github.com/joshbartlettband-web/felucca-rainbow
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: RAINBOW-source.zip on the ports page.
