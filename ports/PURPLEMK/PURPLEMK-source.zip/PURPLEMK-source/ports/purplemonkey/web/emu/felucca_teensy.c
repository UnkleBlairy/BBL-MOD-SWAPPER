/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: PurpleMonkey 0.12 (https://github.com/Quixotic7/PurpleMonkeyFM1) on the Teensy 4.1: its own browser build (tools/emu/web/emu_web.c) inside ports/common's shell */
#include "../../../common/shell_pre.h"
#include <stdlib.h>
#include <time.h>
#ifndef CLOCK_MONOTONIC
#define CLOCK_MONOTONIC 1
static int clock_gettime(int c, struct timespec *t) { (void)c; t->tv_sec = 0; t->tv_nsec = 0; return 0; }
#endif
#define getenv(n) ((char *)0)
#include <stdio.h>
#ifdef __arm__
#include <pthread.h>
#define pthread_equal(a, b) 1
#define pthread_self() ((pthread_t)1)
#undef PTHREAD_MUTEX_INITIALIZER
#undef PTHREAD_COND_INITIALIZER
#define PTHREAD_MUTEX_INITIALIZER 0
#define PTHREAD_COND_INITIALIZER 0
#define pthread_mutex_lock(m) ((void)(m))
#define pthread_mutex_unlock(m) ((void)(m))
#define pthread_cond_wait(c, m) ((void)(c))
#define pthread_cond_broadcast(c) ((void)(c))
#define pthread_cond_signal(c) ((void)(c))
#define pthread_create(t, a, f, x) ((void)(f), -1)
#define pthread_detach(t) ((void)0)
#define pthread_join(t, r) ((void)0)
static int teensy_noprint(const char *f, ...) { (void)f; return 0; }
#define printf teensy_noprint
#define fprintf(...) ((void)0)
#define puts(s) ((void)(s))
#define putchar(c) ((void)(c))
#define fflush(f) ((void)(f), 0)
#define exit(n) do { for (;;) ; } while (0)
#define atexit(f) ((void)0)
#define fwrite(a, b, c, d) ((size_t)0)
#define fopen(a, b) ((FILE *)0)
#define fread(a, b, c, d) ((size_t)0)
#define fseek(a, b, c) (0)
#define fclose(f) ((void)0)
#endif
#define web_boot o_web_boot
#define web_out_l o_web_out_l
#define web_out_r o_web_out_r
#define web_render o_web_render
#define web_buttons o_web_buttons
#define web_keys o_web_keys
#define web_enc o_web_enc
#define web_master o_web_master
#define web_nor_erase o_web_nor_erase
#define web_ms o_web_ms
#define web_frame o_web_frame
#include "../../tools/emu/web/emu_web.c"
#undef __attribute__
#undef EXPORT
#undef memset
#undef memcpy
#undef memcmp
#undef memmove
#undef web_boot
#undef web_out_l
#undef web_out_r
#undef web_render
#undef web_buttons
#undef web_keys
#undef web_enc
#undef web_master
#undef web_nor_erase
#undef web_ms
#undef web_frame
#define SH_FLOAT
#define SH_OUT_L o_web_out_l
#define SH_OUT_R o_web_out_r
#define SH_RENDERF(n) o_web_render(n)
#define SH_ADC(m) o_web_master((int32_t)m)
static void SH_BOOT(void) { o_web_boot(); }
static void SH_FRAME(uint32_t ms)
{ (void)ms; }
static int sh_role(uint32_t hw) { static const uint8_t R[7] = {0, 1, 3, 4, 5, 6, 2}; return R[hw]; }
#define SH_ENC(e, n) o_web_enc(sh_role(e), (n))
static uint32_t sh_labels;
static uint32_t sh_label(uint32_t raw) { return raw < 2u ? raw + 12u : raw - 2u; }
#define SH_BTN(i, d) (sh_labels = (sh_labels & ~(1u << sh_label(i))) | (uint32_t)(d) << sh_label(i), o_web_buttons(sh_labels))
static uint32_t sh_keys_m;
#define SH_KEY(k, d) (sh_keys_m = (sh_keys_m & ~(1u << (k))) | (uint32_t)(d) << (k), o_web_keys(sh_keys_m))
static int sh_q(int v) { return !v ? 0 : v == 1 || v == 4 ? 1 : 2; }
#define SH_KEY_LED(k) sh_q(web_leds()[k])
#define SH_BTN_LED(i) sh_q(web_leds()[27u + sh_label(i)])
#include "../../../common/shell_post.h"
