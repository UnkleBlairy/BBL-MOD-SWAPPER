Araminta 4.8 for the BBL Mod Swapper

Original by Wulgaren: https://github.com/Wulgaren/Araminta
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: ARAMINTA-source.zip on the ports page.
