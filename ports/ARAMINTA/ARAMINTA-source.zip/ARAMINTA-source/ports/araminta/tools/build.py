#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
# Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
"""Build Felucca: the app, the update loader and an installable .fwsc package.

  tools/build.py [--release X.Y[-suffix]] [--gen-only]

Outputs in build/: felucca.bin (app), loader/ota.bin (update loader),
felucca.fwsc (package). A release build (--release X.Y) writes felucca-X.Y.fwsc and a folder
release-X.Y/ with the package, the app, SHA256SUMS, the sample attribution and the licence files.
See BUILDING.md for the toolchain and the SDK.

JIELI_TOOLCHAIN points at the JieLi toolchain, native on Windows or Linux x86-64;
on macOS (or with JIELI_DOCKER=1) each tool runs in a linux/amd64 container.
"""
import argparse
import atexit
import hashlib
import os
import platform
import re
import shutil
import signal
import struct
import subprocess
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
FW = SRC / "firmware"
OUT = (SRC / os.environ.get("FELUCCA_OUT", "build")).resolve()   # tests/layout_sweep.sh: one per layout, in parallel
if not OUT.is_relative_to(SRC):     # the toolchain container mounts SRC and takes paths relative to it
    raise SystemExit(f"FELUCCA_OUT={os.environ['FELUCCA_OUT']}: must be inside {SRC}")
GEN = OUT / "gen"
LDR = OUT / "loader"
sys.path.insert(0, str(SRC / "tools"))
import fm1pkg_make  # noqa: E402
import lz4blk  # noqa: E402

APP_XIP = 0x02000120                # app.bin offset 0 in the XIP map; the SPL jumps here
APP_SLOT = fm1pkg_make.APP_SLOT
# JieLi's clang 4.0.1 (CI) makes RAM code and the flash image bigger than the open toolchain does for the same
# source. Measured on 3fa0d7a / 67e552d: RAMTEXT 26,904 vs 24,300 B (x1.107), image 581,976 vs 568,744 B
# (x1.023). Re-checked on 1e2999a: open 31,616 B -> JieLi 33,936 B (x1.073). 1.08 clears that tree's open
# estimate with a little margin; 1.12 false-failed it. An open-toolchain build fails when the scaled size
# would not fit, so a CI overflow shows up locally. Re-checked on the BEND tree (2026-11-20): open
# 570,196 B -> JieLi 583,920 B (x1.02407); 1.025 false-failed it by 434 B, 1.0241 keeps ~80 B of margin.
JIELI_RAMTEXT_GROWTH = 1.08
JIELI_IMAGE_GROWTH = 1.0241
LOADER_LOAD = 0x01C0A800
LOADER_NAME = b"usb_hid_ota.bin"    # the file name the SPL looks for
DOCKER_IMAGE = os.environ.get("JIELI_DOCKER_IMAGE", "debian:bookworm-slim")
# the open LLVM toolchain (tools/get_open_toolchain.sh, a local macOS build path) leaves these helpers out of
# line where JieLi's inliner takes them in. A .hot_text function runs in RAM at 0x01C00000, 4 MB under the
# flash where a call.l reaches, so they go first in the flash hot block, the only part of .text in reach.
# A source change that adds one shows up as "out of range ... references 'x'": add x here.
OPEN_HOT_HELPERS = ["fm6_env_get", "fm6_env_key", "fm6_penv_get", "fm6_penv_key", "rng"]
WINDOWS_TOOLS = {
    "pi32v2/bin/clang": "pi32/bin/clang.exe",
    "pi32v2/bin/ld": "pi32/bin/pi32v2-ld.exe",
    "common/bin/objcopy": "pi32/bin/llvm-objcopy.exe",
    "common/bin/objdump": "pi32/bin/llvm-objdump.exe",
}
CFLAGS = ["-Os", "-ffunction-sections", "-fno-builtin", "-Wall", "-Wno-unused-function"]
LINE = re.compile(r"^\s*([0-9a-f]+):\s+((?:[0-9a-f]{2} )+)\s*\t(.*)$")

# SDK files of AC79NN_SDK_V1.2.1_2023-12-13 (the tested version)
SDK_SHA256 = {
    "uboot.boot": "4e3b4c220dc96641cb5a723f41e68ce41d5261ae9434bb33fbd7f2c59976ded4",
    "cfg_tool.bin": "276579954f076886a6a7694f65dc71c034a63a2c204b76749065c0ac7b010d1b",
    "cfg/eq_cfg_hw.bin": "41167491bffed4651750719c973d2758adeb9021a5670d02d6a53c85ed80ea7d",
}

PRODUCT = "FM-1_900"                # package identity; release builds are FM-1_42XY
VERSION = None                      # FELUCCA_VERSION for release builds (default: firmware/src/felucca.c)


def compiler_rel():
    """the clang inside the toolchain: pi32/bin on Windows, pi32v2/bin elsewhere"""
    if platform.system() == "Windows" and not use_docker():
        return WINDOWS_TOOLS["pi32v2/bin/clang"]
    return "pi32v2/bin/clang"


def toolchain():
    tc = os.environ.get("JIELI_TOOLCHAIN")
    compiler = compiler_rel()
    if not tc or not (Path(tc) / compiler).is_file():
        raise SystemExit(f"JIELI_TOOLCHAIN must point at the JieLi toolchain directory containing {compiler} "
                         "(see BUILDING.md)")
    return Path(tc).resolve()


def use_docker():
    native = platform.system() == "Windows" or (
        platform.system() == "Linux" and platform.machine() in ("x86_64", "AMD64")
    )
    return os.environ.get("JIELI_DOCKER", "0" if native else "1") == "1"


def open_toolchain():
    """JIELI_TOOLCHAIN is the open LLVM toolchain (tools/get_open_toolchain.sh), which marks itself"""
    tc_env = os.environ.get("JIELI_TOOLCHAIN")
    return bool(tc_env) and (Path(tc_env) / "OPEN_TOOLCHAIN").is_file()


def app_linker_script():
    """firmware/app.ld; for the open toolchain, its out-of-line helpers are moved into the flash hot block"""
    if not open_toolchain():
        return FW / "app.ld"
    script = (FW / "app.ld").read_text()
    anchor = "        . = ALIGN(64); _flash_hot_start = .;\n"
    if anchor not in script:
        raise SystemExit("build: firmware/app.ld has no _flash_hot_start the open toolchain's helpers can follow")
    script = script.replace(anchor, anchor + "".join(f"        *(.text.{n})\n" for n in OPEN_HOT_HELPERS), 1)
    out = OUT / "app-open.ld"
    out.write_text(script)
    return out


class ToolContainer:
    """one container for every toolchain call: `docker run` costs ~0.18 s, `docker exec` ~0.07 s"""
    def __init__(self):
        self.name = f"felucca-build-{os.getpid()}"
        self.lock = threading.Lock()
        self.running = False

    def start(self):
        if self.running:
            return
        with self.lock:
            if self.running:
                return
            subprocess.run(["docker", "rm", "-f", self.name], capture_output=True)   # stale from a killed build
            r = subprocess.run(["docker", "run", "-d", "--rm", "--name", self.name, "--platform", "linux/amd64",
                                "-v", f"{SRC}:/work", "-v", f"{toolchain()}:/opt/jieli:ro", "-w", "/work",
                                DOCKER_IMAGE, "sleep", "infinity"], capture_output=True, text=True)
            if r.returncode:
                sys.stderr.write(r.stdout + r.stderr)
                raise SystemExit("build: could not start the toolchain container")
            self.running = True
            atexit.register(self.stop)

    def run(self, tool, args):
        self.start()
        return subprocess.run(["docker", "exec", self.name, f"/opt/jieli/{tool}", *args],
                              capture_output=True, text=True)

    def stop(self):
        with self.lock:
            if self.running:
                subprocess.run(["docker", "rm", "-f", self.name], capture_output=True)
                self.running = False


CONTAINER = ToolContainer()


def tc(tool, *args):
    """run a toolchain binary (pi32v2/bin/..., common/bin/...) with cwd SRC; paths relative to SRC"""
    rel = [str(Path(a).resolve().relative_to(SRC)) if isinstance(a, Path) else a for a in args]
    if tool == "cc":                # the toolchain's cc wrapper needs python3; call clang directly
        tool, rel = "pi32v2/bin/clang", ["-target", "pi32v2", *rel]
    if use_docker():
        r = CONTAINER.run(tool, rel)
    else:
        if platform.system() == "Windows":
            tool = WINDOWS_TOOLS[tool]
        r = subprocess.run([str(toolchain() / tool), *rel], cwd=SRC, capture_output=True, text=True)
    if r.returncode:
        sys.stderr.write(r.stdout + r.stderr)
        raise SystemExit(f"build: {tool} failed")
    if r.stderr.strip():
        sys.stderr.write(r.stderr)
    return r.stdout


def tc_all(*cmds):
    with ThreadPoolExecutor(len(cmds)) as ex:
        return list(ex.map(lambda c: tc(*c), cmds))


def generate():
    """generated headers (UI fonts, icons, keycaps, palettes, tables, samples, splash logo)"""
    GEN.mkdir(parents=True, exist_ok=True)
    tools = SRC / "tools"
    cmds = [[tools / "gen_aa_font.py", GEN / "ui_fonts.h", "--preset", "terminus"],
            [tools / "gen_aa_icons.py", GEN / "ui_icons.h"],
            [tools / "gen_aa_keycaps.py", GEN / "ui_keycaps.h"],
            [tools / "gen_ui_palettes.py", GEN / "ui_palettes.h"],
            [tools / "gen_tables.py", GEN / "felucca_tables.h"],
            [tools / "gen_fm6_patches.py", GEN / "felucca_fm6.h"],
            [tools / "gen_samples.py", GEN / "felucca_samples.h"],
            [tools / "gen_wavetables.py", GEN / "felucca_wt.h"]]
    procs = [subprocess.Popen([sys.executable, *map(str, c)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              text=True) for c in cmds]
    failed, missing = [], []
    for c, p in zip(cmds, procs):
        sys.stdout.write(p.communicate()[0])
        if p.returncode:
            failed.append(c[0].name)
        elif not c[1].exists():       # a generator that exits 0 without writing its header
            missing.append(c[1].name)
    if failed:
        raise SystemExit(f"build: {', '.join(failed)} failed")
    if missing:
        raise SystemExit(f"build: nothing written to {', '.join(missing)}")


# ---- update loader

def crc16(d, c=0):
    for b in d:
        c ^= b << 8
        for _ in range(8):
            c = ((c << 1) ^ 0x1021) if c & 0x8000 else c << 1
        c &= 0xFFFF
    return c


def ldr_head(dcrc, a, b, attr, name):
    body = struct.pack("<HIIBBH16s", dcrc, a, b, attr, 0, 0, name)
    return struct.pack("<H", crc16(body)) + body


def ldr_wrap(image):
    """ota.bin = outer JLFS head (32 B) + inner head (32 B, load address) +
    blocks [clen u32][dlen u32][LZ4 block], dlen 4096 except the last"""
    blocks = bytearray()
    for i in range(0, len(image), 4096):
        raw = image[i:i + 4096]
        c = lz4blk.compress(raw)
        if len(c) > 4096 or lz4blk.decompress(c) != raw:
            raise SystemExit(f"loader: block {i // 4096} does not compress below 4096 B")
        blocks += struct.pack("<II", len(c), len(raw)) + c
    inner = ldr_head(crc16(image), len(image), LOADER_LOAD, 0, LOADER_NAME)
    body = inner + bytes(blocks)
    return ldr_head(crc16(body), 0x20, len(body), 0x41, LOADER_NAME) + body


def build_loader():
    LDR.mkdir(parents=True, exist_ok=True)
    src = FW / "loader"
    flags = [*CFLAGS, "-Ifirmware/hal", "-Ifirmware/src"]
    tc_all(("cc", "-c", src / "crt0_ldr.S", "-o", LDR / "crt0_ldr.o"),
           ("cc", *flags, "-c", src / "loader.c", "-o", LDR / "loader.o"))
    elf = LDR / "loader.elf"
    tc("pi32v2/bin/ld", "--gc-sections", "-e", "_start", "-T", src / "loader.ld",
       LDR / "crt0_ldr.o", LDR / "loader.o", "-o", elf)
    _, dis, hdr, syms = tc_all(("common/bin/objcopy", "-O", "binary", "-j", ".text", elf, LDR / "loader.bin"),
                               ("common/bin/objdump", "-d", elf),
                               ("common/bin/objdump", "-h", elf),
                               ("common/bin/objdump", "-t", elf))
    (LDR / "loader.dis").write_text(dis)
    for ln in hdr.splitlines():     # the loader rewrites the flash: nothing may run from XIP
        p = ln.split()
        if len(p) > 4 and p[1].startswith(".") and int(p[3], 16) >= 0x02000000 and int(p[2], 16):
            raise SystemExit(f"loader: section {p[1]} at {p[3]} is outside RAM")
    image = (LDR / "loader.bin").read_bytes()
    if not image or len(image) > 0x14000:
        raise SystemExit("loader: image empty or too big")
    ota = ldr_wrap(image)
    (LDR / "ota.bin").write_bytes(ota)
    bss = [int(ln.split()[0], 16) for ln in syms.splitlines() if ln.rstrip().endswith("_bss_end")]
    print(f"loader: image {len(image)} B at {LOADER_LOAD:#x}" + (f", bss end {bss[0]:#x}" if bss else ""))
    print(f"loader: ota.bin {len(ota)} B")
    return ota


# ---- app

def ld_regions():
    """firmware/app.ld's MEMORY regions: name -> (origin, length)"""
    regs = {}
    for m in re.finditer(r"^\s*(\w+)\s*\([rwx]+\)\s*:\s*ORIGIN\s*=\s*(\w+),\s*LENGTH\s*=\s*(\w+)",
                         (FW / "app.ld").read_text(), re.M):
        n = m.group(3)
        regs[m.group(1)] = (int(m.group(2), 0), int(n[:-1], 0) * 1024 if n.endswith("K") else int(n, 0))
    return regs


def cc_binary():
    return toolchain() / compiler_rel()


def app_cache_key(flags, size):
    """everything felucca.o is made from: sources, headers, generated headers, flags, compiler (build/gen must
    exist, so this runs after generate())"""
    h = hashlib.sha256()
    for d in (FW / "src", FW / "hal", GEN):
        for p in sorted(d.rglob("*")):
            if p.is_file():
                h.update(str(p.relative_to(SRC)).encode() + b"\0" + p.read_bytes() + b"\0")
    compiler = cc_binary()
    st = compiler.stat()
    h.update(f"{compiler}:{st.st_size}:{st.st_mtime_ns}\0".encode())
    h.update((SRC / "tools" / "size_fns.py").read_bytes() + b"\0")
    h.update(f"{DOCKER_IMAGE if use_docker() else 'native'}\0size={size}\0".encode())
    h.update("\0".join(flags).encode())
    return h.hexdigest()


def build_app():
    flags = [*CFLAGS, "-Ifirmware/hal", "-Ifirmware/src", f"-I{GEN.relative_to(SRC)}"]
    for flag in ("FELUCCA_FLASH", "FELUCCA_OTA", "FELUCCA_OTA_DRYRUN", "FELUCCA_OTA_RAMONLY", "FELUCCA_CDC",
                 "FELUCCA_UART", "FELUCCA_UAC", "FELUCCA_UAC_TONE", "FELUCCA_UAC_48K", "FELUCCA_ICONS", "FELUCCA_SLICE",
                 "FELUCCA_CDC_DEFAULT", "FELUCCA_UAC_AS_FIRST"):
        v = os.environ.get(flag)    # unset: the default in firmware/src/felucca.c
        if v in ("0", "1"):
            flags.append(f"-D{flag}={v}")
    v = os.environ.get("FELUCCA_USB_LAYOUT")   # firmware/src/usb.c: how the USB composite presents itself (#67), 0..3
    if v in ("0", "1", "2", "3"):
        flags.append(f"-DFELUCCA_USB_LAYOUT={v}")
    v = os.environ.get("FELUCCA_LAYOUT_PAD")   # tests/layout_sweep.sh: 8 x v unused stores move the flash layout, 1..7
    if v in ("1", "2", "3", "4", "5", "6", "7"):
        flags.append(f"-DFELUCCA_LAYOUT_PAD={v}")
    flags.append(f'-DFELUCCA_ID="{PRODUCT}"')
    if VERSION:
        flags.append(f'-DFELUCCA_VERSION="{VERSION}"')
    # felucca.c goes to LLVM IR without the optimizer, the main-loop functions (UI, stores, editor) are
    # marked minsize (tools/size_fns.py), then the IR is compiled at -Os. FELUCCA_SIZE=0: -Os everywhere.
    # That compile is most of the build, so felucca.o is kept while its inputs (sources, generated headers,
    # flags, compiler) do not change. FELUCCA_NO_CACHE=1: always recompile.
    size = os.environ.get("FELUCCA_SIZE") != "0"
    cmain = (("cc", *flags, "-S", "-emit-llvm", "-Xclang", "-disable-llvm-optzns", "-c",
              FW / "src" / "felucca.c", "-o", OUT / "felucca.ll") if size else
             ("cc", *flags, "-c", FW / "src" / "felucca.c", "-o", OUT / "felucca.o"))
    asm = [("cc", "-c", FW / "crt0.S", "-o", OUT / "crt0.o"),
           ("cc", "-c", FW / "hal" / "fm1_vec.S", "-o", OUT / "fm1_vec.o"),
           ("cc", "-c", FW / "hal" / "fm1_isr.S", "-o", OUT / "fm1_isr.o"),
           ("cc", "-c", FW / "hal" / "fm1_cpu1.S", "-o", OUT / "fm1_cpu1.o")]
    obj, key_file = OUT / "felucca.o", OUT / "felucca.o.key"
    key = app_cache_key(flags, size)
    cached = (os.environ.get("FELUCCA_NO_CACHE") != "1"
              and obj.is_file() and key_file.is_file() and key_file.read_text().strip() == key)
    tc_all(*(asm if cached else [*asm, cmain]))
    if cached:
        print("  ok    felucca.o unchanged: not recompiled")
    else:
        if size:
            subprocess.run([sys.executable, SRC / "tools" / "size_fns.py", OUT / "felucca.ll", OUT / "felucca_size.ll"],
                           check=True)
            tc("cc", *[f for f in flags if not f.startswith(("-I", "-D", "-W"))], "-c",
               OUT / "felucca_size.ll", "-o", OUT / "felucca.o")
        key_file.write_text(key + "\n")
    elf = OUT / "felucca.elf"
    tc("pi32v2/bin/ld", "-T", app_linker_script(), OUT / "crt0.o", OUT / "fm1_vec.o", OUT / "fm1_isr.o",
       OUT / "fm1_cpu1.o", OUT / "felucca.o", "-o", elf)
    for sect in ("text.bin", "data.bin", "ramtext.bin", "c1text.bin", "hottext.bin"):
        (OUT / sect).unlink(missing_ok=True)
    *_, syms, dis, rt = tc_all(("common/bin/objcopy", "-O", "binary", "-j", ".text", elf, OUT / "text.bin"),
                               ("common/bin/objcopy", "-O", "binary", "-j", ".data", elf, OUT / "data.bin"),
                               ("common/bin/objcopy", "-O", "binary", "-j", ".ram_text", elf, OUT / "ramtext.bin"),
                               ("common/bin/objcopy", "-O", "binary", "-j", ".c1_text", elf, OUT / "c1text.bin"),
                               ("common/bin/objcopy", "-O", "binary", "-j", ".hot_text", elf, OUT / "hottext.bin"),
                               ("common/bin/objdump", "-t", elf),
                               ("common/bin/objdump", "-d", elf),
                               ("common/bin/objdump", "-d", "-j", ".ram_text", "-j", ".c1_text", elf))
    (OUT / "felucca.dis").write_text(dis)

    def symv(name):
        return int(re.search(r"^([0-9a-f]+) .*\s" + name + r"$", syms, re.M).group(1), 16)
    img = bytearray((OUT / "text.bin").read_bytes())
    # .ram_text, .c1_text, .hot_text and .data follow .text at their load addresses; crt0 / main copy them by words
    for sect, lname in (("ramtext.bin", "_rt_load"), ("c1text.bin", "_c1_load"), ("hottext.bin", "_hot_load"),
                        ("data.bin", "_data_load")):
        load = symv(lname)
        if load % 4:
            raise SystemExit(f"{lname} {load:#x} is not word aligned")
        blob = (OUT / sect).read_bytes() if (OUT / sect).exists() else b""
        if blob:
            if load - APP_XIP < len(img):
                raise SystemExit(f"{lname} overlaps the image")
            img += b"\xff" * (load - APP_XIP - len(img))
            img += blob
    img += b"\xff" * (-len(img) % 4)
    (OUT / "felucca.bin").write_bytes(img)
    return bytes(img), syms, dis, rt


def flash_hot_check(syms):
    """app.ld's flash-hot block names its functions by their -ffunction-sections section. A renamed function, or
    one the compiler inlined into its caller, leaves a pattern that matches nothing, so the entry drifts out of
    the fixed block (emu_test --footprint, docs/fm1-emu-test.md) without a sign: fail the build instead."""
    block = re.search(r"_flash_hot_start = \.;(.*?)_flash_hot_end", (FW / "app.ld").read_text(), re.S)
    if not block:
        return ["app.ld: no _flash_hot_start / _flash_hot_end block"]

    def sym(name):
        m = re.search(r"^([0-9a-f]+) .*\s" + re.escape(name) + r"$", syms, re.M)
        return int(m.group(1), 16) if m else None

    start, end = sym("_flash_hot_start"), sym("_flash_hot_end")
    if start is None or end is None or end <= start:
        return ["app.ld: _flash_hot_start / _flash_hot_end missing or empty"]
    errors = []
    for name in re.findall(r"\*\(\.text\.(\w+)\)", block.group(1)):
        at = sym(name)
        if at is None:
            if os.environ.get("FELUCCA_UAC") == "0" and name in ("uac_service", "uac_render_start"):
                continue  # USB audio functions are not compiled when UAC is disabled.
            errors.append(f"app.ld: .flash_hot lists {name}, which is missing (renamed or inlined away)")
        elif not start <= at < end:
            errors.append(f"app.ld: .flash_hot lists {name} at {at:#x}, outside {start:#x}..{end:#x}")
    return errors


def check(img, syms, dis, rt):
    errors, notes = [], []
    errors += flash_hot_check(syms)
    m = re.search(r"^([0-9a-f]+) .*\s_start$", syms, re.M)
    if not m or int(m.group(1), 16) != APP_XIP:
        errors.append(f"_start is not at {APP_XIP:#x}")
    if img[:4] != bytes.fromhex("04818000"):
        errors.append(f"image starts with {img[:4].hex()}, not the entry stub")
    # RAM code runs with the flash off: no calls into XIP. The second core's waiting loop (.c1_text) calls only
    # its job, through the pointer core 0 handed it (a register: "call rN")
    sect, rt_calls, c1_calls, c1_insns, rt_insns = None, [], [], 0, 0
    for ln in rt.splitlines():
        mm = re.match(r"^Disassembly of section (\S+):", ln)
        if mm:
            sect = mm.group(1)
            continue
        if not LINE.match(ln):
            continue
        if sect == ".c1_text":
            c1_insns += 1
            if re.search(r"\bcall\b", ln) and not re.search(r"\bcall\s+r\d+\b", ln):
                c1_calls.append(ln.strip())
        else:
            rt_insns += 1
            if re.search(r"\bcall\b", ln):
                rt_calls.append(ln.strip())
    if rt_calls:
        errors.append(f".ram_text contains calls: {rt_calls[:3]}")
    else:
        notes.append(f".ram_text: {rt_insns} insns, no calls")
    if c1_calls:
        errors.append(f".c1_text calls other than its job: {c1_calls[:3]}")
    elif not c1_insns:
        errors.append(".c1_text: the second core's waiting loop is missing (firmware/hal/fm1_cpu1.h fm1_c1_main)")
    else:
        notes.append(f".c1_text: {c1_insns} insns, only its job called")
    for ln in dis.splitlines():     # nothing may call or load an address in the chip ROM
        mm = LINE.match(ln)
        if not mm:
            continue
        for v in re.findall(r"= (-?\d+) <|call -?\d+ <[^:>]*: ([0-9a-f]+) >", mm.group(3)):
            val = (int(v[0]) & 0xFFFFFFFF) if v[0] else int(v[1], 16) & 0xFFFFFFFF
            if 0xFFC00000 <= val < 0xFFD00000:
                errors.append(f"reference to ROM address {val:#010x}")
    if len(img) > APP_SLOT:
        errors.append(f"image {len(img)} B exceeds the app slot")

    def sym(name):
        mm = re.search(r"^([0-9a-f]+) .*\s" + name + r"$", syms, re.M)
        return int(mm.group(1), 16) if mm else 0
    region = ld_regions()
    ram_org, ram_len = region["RAM"]
    pool_len = region["POOL"][1]
    bss = sym("_bss_end") - ram_org
    pool = sym("_pool_end") - sym("_pool_start")
    notes.append(f"image {len(img)} B; RAM .data+.bss {bss} B of {ram_len}; pool {pool} B of {pool_len}")
    if region["RAM"][0] + ram_len != region["POOL"][0]:
        errors.append("app.ld: POOL does not start where RAM ends")
    if ram_len - bss < 4096:                      # keep >= 4 KiB of .bss spare (state the audio side touches)
        errors.append(f"RAM headroom {ram_len - bss} B < 4096 B")
    if pool_len - pool < 8192:                    # keep >= 8 KiB of the pool spare
        errors.append(f"pool headroom {pool_len - pool} B < 8192 B")
    if open_toolchain():
        if sym("_hot_end") == 0:
            errors.append("app.ld: _hot_end missing")
        else:
            ramtext_org, ramtext_len = region["RAMTEXT"]
            # .ram_text, .c1_text, .hot_text sit back to back from RAMTEXT's origin (app.ld)
            ramtext = sym("_hot_end") - ramtext_org
            est = int(ramtext * JIELI_RAMTEXT_GROWTH)
            notes.append(f"RAMTEXT {ramtext} B of {ramtext_len}; with JieLi's compiler ~{est} B")
            if est > ramtext_len:
                errors.append(f"RAMTEXT: {ramtext} B here is ~{est} B with JieLi's compiler (CI), "
                              f"{est - ramtext_len} B over {ramtext_len}")
        est = int(len(img) * JIELI_IMAGE_GROWTH)
        notes.append(f"image with JieLi's compiler ~{est} B of {APP_SLOT}")
        if est > APP_SLOT:
            errors.append(f"image: {len(img)} B here is ~{est} B with JieLi's compiler (CI), "
                          f"{est - APP_SLOT} B over the app slot {APP_SLOT}")
    return errors, notes


# Every hardware register access lives in hal/. In src/ and loader/ (comments stripped):
#  - no volatile pointer cast, except of a C object's address (`*(volatile T *)&x`: a read-once
#    of a RAM flag shared with an ISR, e.g. usb.c ota_wire_send);
#  - no literal in a register or reserved window (core SFRs 0x10000-0x13FFF, SFC 0x40000-0x43FFF,
#    GPIO/IOMAP 0x50000-0x51FFF, CPU 0x1EE0000-0x1EEFFFF, RAM top 0x01C7F000- (boot info,
#    mailbox, vectors), XIP 0x02000000-0x020FFFFF);
#  - no inline asm, except the empty compiler barrier RING_PUBLISH() (emits no instruction);
#  - no HAL register macro (a hal/ #define that is, or expands to, a volatile access).
# Linker symbols (_bss_start[], _rt_load[], ...) are plain C objects and pass.
MMIO_LIT = re.compile(r"\b0x0*(1[0-3][0-9a-f]{3}|4[0-3][0-9a-f]{3}|5[01][0-9a-f]{3}|1ee[0-9a-f]{4}|"
                      r"1c7f[0-9a-f]{3}|20[0-9a-f]{5})u?l?\b", re.I)
MMIO_CAST = re.compile(r"\(\s*(?:const\s+)?volatile\b[^()]*\*\s*\)(?!\s*&)")
MMIO_ASM = re.compile(r"\b(?:__asm__|asm)\b(?!\s+volatile\s*\(\s*\"\"\s*:::\s*\"memory\"\s*\))")


def mmio_check():
    def strip(s):
        s = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), s, flags=re.S)
        return re.sub(r"//[^\n]*", "", s)
    defs = {}
    for h in sorted((FW / "hal").glob("*.h")):
        for m in re.finditer(r"^#define\s+(\w+)(?:\([^)]*\))?\s+(.*)$", strip(h.read_text()), re.M):
            defs[m.group(1)] = m.group(2)
    regs = {n for n, b in defs.items() if re.search(r"\bvolatile\b", b)}
    while True:                                   # macros built on register macros (FM1_WR_LIMIT_H -> FM1_X2)
        more = {n for n, b in defs.items() if n not in regs and set(re.findall(r"\w+", b)) & regs}
        if not more:
            break
        regs |= more
    errors = []
    for f in sorted([*(FW / "src").glob("*.[ch]"), *(FW / "loader").glob("*.c")]):
        for no, ln in enumerate(strip(f.read_text()).splitlines(), 1):
            where = f"{f.relative_to(FW)}:{no}"
            for rx, what in ((MMIO_LIT, "register/window address"), (MMIO_CAST, "volatile pointer cast"),
                             (MMIO_ASM, "inline asm")):
                m = rx.search(ln)
                if m:
                    errors.append(f"{where}: {what} outside hal/ ({m.group(0).strip()}); add a hal/ helper")
            used = set(re.findall(r"\b[A-Z_][A-Z0-9_]*\b", ln)) & regs
            if used:
                errors.append(f"{where}: HAL register macro {sorted(used)[0]} outside hal/; use a hal/ helper")
    return errors


def main():
    global PRODUCT, VERSION
    ap = argparse.ArgumentParser()
    ap.add_argument("--release", metavar="X.Y", help="release build: identity FM-1_42XY, version string vX.Y")
    ap.add_argument("--sdk", type=Path, help="three-file JieLi AC79 SDK mirror (default: $AC79_SDK)")
    ap.add_argument("--gen-only", action="store_true",
                    help="write build/gen and stop: the browser emulator needs it, not the toolchain or the SDK")
    a = ap.parse_args()
    if a.gen_only:                  # before anything reads the SDK or the toolchain
        generate()
        return 0
    name = "felucca.fwsc"
    if a.release:                   # one digit each: the identity has room for two (X.Y.Z and X.Y.Z.W keep X.Y's)
        m = re.fullmatch(r"(\d)\.(\d)(?:\.\d){0,2}(-[A-Za-z0-9]+)?", a.release)
        if not m:
            raise SystemExit(f"--release {a.release}: use X.Y, X.Y.Z, X.Y.Z.W or X.Y-suffix, one digit each")
        PRODUCT = "FM-1_42" + m[1] + m[2]
        VERSION = "v" + a.release.lower()      # e.g. v1.0, v1.1-rc1
        name = f"felucca-{a.release}.fwsc"
    fm1pkg_make.SDK = a.sdk
    for rel, sha in SDK_SHA256.items():          # fail early without the SDK
        if hashlib.sha256(fm1pkg_make.sdk_file(rel)).hexdigest() != sha:
            print(f"warning: SDK {rel} differs from AC79NN_SDK_V1.2.1; the package will not match the reference")
    OUT.mkdir(parents=True, exist_ok=True)
    marker = OUT / "OPEN_TOOLCHAIN"      # tests/run_tests.sh: the target budgets are JieLi's compiler's numbers
    if open_toolchain():            # a local build: CI ships what JieLi's toolchain makes (BUILDING.md)
        marker.write_text((Path(os.environ["JIELI_TOOLCHAIN"]) / "OPEN_TOOLCHAIN").read_text())
        print("open toolchain: local build, not the package CI ships")
    else:
        marker.unlink(missing_ok=True)
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(143))     # atexit removes the toolchain container
    with ThreadPoolExecutor(3) as ex:
        gen, ldr = ex.submit(generate), ex.submit(build_loader)
        gen.result()                # the app needs build/gen; the loader does not
        img, syms, dis, rt = ex.submit(build_app).result()
        ota = ldr.result()
    errors, notes = check(img, syms, dis, rt)
    hal_err = mmio_check()
    errors += hal_err
    if not hal_err:
        notes.append("register access: hal/ only (src/, loader/ clean)")
    for n in notes:
        print("  ok   ", n)
    for e in errors:
        print("  FAIL ", e)
    if errors:
        raise SystemExit("build: checks failed")
    pkg = fm1pkg_make.ufw(fm1pkg_make.flash_image(img, fm1pkg_make.KEY), ota, PRODUCT)
    (OUT / name).write_bytes(pkg)
    att = SRC / "assets" / "samples-cc0" / "ATTRIBUTION.txt"
    if att.exists():
        shutil.copy(att, OUT / "ATTRIBUTION.txt")
    print(f"app      {OUT / 'felucca.bin'}  {len(img)} B")
    print(f"loader   {LDR / 'ota.bin'}  {len(ota)} B")
    print(f"package  {OUT / name}  {len(pkg)} B, identity {PRODUCT}")
    if a.release:                   # what a release carries: the package, the app and every licence they need
        rel = OUT / f"release-{a.release}"
        shutil.rmtree(rel, ignore_errors=True)
        (rel / "LICENSES").mkdir(parents=True)
        app = f"felucca-{a.release}-app.bin"
        (rel / name).write_bytes(pkg)
        (rel / app).write_bytes(img)
        (rel / "SHA256SUMS").write_text("".join(f"{hashlib.sha256(b).hexdigest()}  {n}\n"
                                                for n, b in ((name, pkg), (app, bytes(img)))))
        for f in sorted((SRC / "LICENSES").glob("*.txt")):
            shutil.copy(f, rel / "LICENSES" / f.name)
        for doc in ("LICENSE", "LICENSING.md"):
            shutil.copy(SRC / doc, rel / doc)
        if att.exists():
            shutil.copy(att, rel / "ATTRIBUTION.txt")
        print(f"release  {rel}/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
