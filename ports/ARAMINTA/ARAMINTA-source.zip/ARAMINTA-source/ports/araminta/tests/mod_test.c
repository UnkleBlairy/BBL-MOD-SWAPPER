/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Host test of the modulation matrix (firmware/src/mod.c), same sources as the firmware (through hostsim.c):
 *   build/host/mod_test [DEMO_DIR]      (run_tests.sh builds and runs it; demos in build/mod_demo/)
 * 1. off: slots that do nothing (SRC, DST or AMT at 0) render bit-identically to no matrix at all; the
 *    stored parameters are never left modulated after a block.
 * 2. the math: every source on each kind of destination (per voice: PITCH CUT SHP AMP; per block: PAN, the
 *    sends, RATE, VIB, an engine parameter), bipolar sources and amounts, sums, clamping to the ranges,
 *    per-voice sources on per-block destinations (the latest note-on), RAND without the shared rng.
 * 3. MIDI: CC1 / CC11 / CC121 and channel aftertouch over USB (packets) and TRS (bytes, running status) reach
 *    the matrix of the channel's track (ch 1..4 the parts, others ignored with ROUT CH1-4; with ROUT SEL every
 *    channel the selected track).
 * 4. cost: instructions per sample (kernel-counted) of the heaviest PHYS preset and of a 4-part mix with every
 *    slot of every part active, against the same with the matrix off; fails above MOD_COST_MAX.
 * 5. demos: LFO -> CUT, VEL -> AMP, MODW -> VIB, LFO -> TRIO PW, AT -> WHEEL DRV as WAVs in DEMO_DIR. */
#define main hostsim_main
#include "hostsim.c"
#undef main
#ifdef __APPLE__
#include <libproc.h>
#include <sys/resource.h>
#endif

#define MOD_COST_MAX 6.5          /* % more instructions / sample with every slot active (SEND/FX shared paths).
                                   * 5.5 until WAVETABLE's tables shifted the test binary's layout (5.3-5.7 % measured;
                                   * the matrix's own work is unchanged) */

static int bad;
static void check(const char *what, int ok)
{
    printf("mod: %-74s %s\n", what, ok ? "ok" : "FAIL");
    bad += !ok;
}

static int32_t out_buf[2 * CTL];
static uint64_t hash;
static void blocks(uint32_t n)
{
    uint32_t i, k;
    while (n--) {
        mix_block(out_buf, CTL);
        for (i = 0; i < 2u * CTL; i++)
            for (k = 0; k < 4u; k++) {
                hash ^= ((uint32_t)out_buf[i] >> (8u * k)) & 0xFFu;
                hash *= 0x100000001B3ull;
            }
    }
}

static void slot(track_t *t, uint32_t k, int32_t s, int32_t d, int32_t a)
{
    MOD_ROW(t, k)[MF_SRC] = (int16_t)s;
    MOD_ROW(t, k)[MF_DST] = (int16_t)d;
    MOD_ROW(t, k)[MF_AMT] = (int16_t)a;
}

static uint32_t eng_by_name(const char *n)
{
    uint32_t e;
    for (e = 0; e < NENGINES; e++)
        if (str_eq(ENGINES[e]->name, n))
            return e;
    return 0;
}
static uint32_t edit_by_label(uint32_t e, const char *l, uint32_t fallback)   /* E index 0..7 */
{
    uint32_t k;
    for (k = 0; k < 8u; k++)
        if (str_eq(ENGINES[e]->edit[k].label, l))
            return k;
    return fallback;
}
static uint32_t preset_by_name(uint32_t e, const char *n)
{
    uint32_t k;
    for (k = 0; k < ENGINES[e]->npresets; k++)
        if (str_eq(ENGINES[e]->presets[k].name, n))
            return k;
    return 0;
}

static void fresh(uint32_t e, uint32_t pi)        /* the boot state (no FX tails), track 1 = engine e preset pi */
{
    uint32_t k;
    memset(dly_buf, 0, sizeof dly_buf);
    memset(rev_tank, 0, sizeof rev_tank);
    R = &rev_tank[0];
    memset(&fx, 0, sizeof fx);
    lim_env = LIM_T;
    memset(trk, 0, sizeof trk);
    MOD_W_CLEAR();
    host_tracks_init();
    song.g[G_ROUTE] = 0;                          /* CH1-4: these cases route CC1 / CC11 / AT by channel */
    for (k = 0; k < NPART; k++)
        host_preset(&trk[k], k ? 0u : e, k ? 0u : pi);
    song.sel = 0;
    hash = 0xCBF29CE484222325ull;
}

/* a phrase on track 1: a chord, a note, releases; the hash of the output */
static uint64_t phrase(void)
{
    track_t *t = &trk[0];
    trk_note_on(t, 60, 100);
    trk_note_on(t, 64, 70);
    trk_note_on(t, 67, 120);
    blocks(FS / 2u / CTL);
    trk_note_on(t, 72, 90);
    blocks(FS / 4u / CTL);
    trk_note_off(t, 60);
    trk_note_off(t, 64);
    trk_note_off(t, 67);
    trk_note_off(t, 72);
    blocks(FS / CTL);
    return hash;
}

/* ------------------------------------------------------------------ 1 --- */
/* the phrase's hash in a fork()ed child (the seeds as they were: the same in each); setup k:
 * 0 no matrix, 1 slots that do nothing, 2 an active matrix. The child answers 0 when p[] was left changed */
static uint64_t phrase_child(uint32_t k)
{
    int fd[2];
    uint64_t h = 0;
    pid_t pid;
    if (pipe(fd))
        return 0;
    fflush(stdout);
    if (!(pid = fork())) {
        int16_t keep[P_COUNT];
        fresh(0, 0);
        if (k == 1u) {
            slot(&trk[0], 0, MS_LFO, MD_CUT, 0);   /* AMT 0 */
            slot(&trk[0], 1, MS_OFF, MD_PAN, 40);  /* SRC OFF */
            slot(&trk[0], 2, MS_VEL, MD_OFF, -30); /* DST OFF */
        } else if (k == 2u) {
            slot(&trk[0], 0, MS_LFO, MD_CUT, 40);
            slot(&trk[0], 1, MS_MODW, MD_PAN, 63);
            slot(&trk[0], 2, MS_LFO, MD_E1 + 4, -50);
            slot(&trk[0], 3, MS_ENV, MD_REV, 30);
            trk[0].mw = 100;
        }
        memcpy(keep, trk[0].p, sizeof keep);
        h = phrase();
        if (memcmp(keep, trk[0].p, sizeof keep) || MOD(&trk[0]).on)
            h = 0;
        if (write(fd[1], &h, sizeof h) != sizeof h)
            _exit(1);
        _exit(0);
    }
    close(fd[1]);
    if (read(fd[0], &h, sizeof h) != sizeof h)
        h = 0;
    close(fd[0]);
    waitpid(pid, 0, 0);
    return h;
}

static void test_off(void)
{
    uint64_t h0 = phrase_child(0), h1 = phrase_child(1), h2 = phrase_child(2);
    check("slots that do nothing: bit-identical to the matrix off", h0 && h0 == h1);
    check("an active matrix changes the sound, and leaves no modulated value in p[]", h2 && h2 != h0);
}

/* FM6 with (1) or without the matrix's MRAT slot: the phrase's hash */
static uint64_t mrat_child(uint32_t on)
{
    int fd[2];
    uint64_t h = 0;
    pid_t pid;
    if (pipe(fd))
        return 0;
    fflush(stdout);
    if (!(pid = fork())) {
        fresh(ENGI_FM6, 0);
        if (on) {
            slot(&trk[0], 0, MS_MODW, MD_E1 + 3, 63);    /* E4 = MRAT */
            trk[0].mw = 127;
        }
        h = phrase();
        if (write(fd[1], &h, sizeof h) != sizeof h)
            _exit(1);
        _exit(0);
    }
    close(fd[1]);
    if (read(fd[0], &h, sizeof h) != sizeof h)
        h = 0;
    close(fd[0]);
    waitpid(pid, 0, 0);
    return h;
}

/* ------------------------------------------------------------------ 2 --- */
static void lfo_at(track_t *t, int32_t v)          /* the LFO value the next block's matrix sees */
{
    t->lfo_val = v;
    t->lfo_fade = 32767;
}

static void test_math(void)
{
    track_t *t = &trk[0];
    int32_t lfo;
    vmod_t m;
    voice_t *v;
    uint32_t e_trio, k_pw;

    /* per-track sources on per-voice destinations */
    fresh(0, 0);
    lfo_at(t, 32767);
    lfo = mulq15(32767, 32767);
    slot(t, 0, MS_LFO, MD_CUT, 63);
    mod_begin(t);
    check("LFO -> CUT +63: +63 steps at the top of the LFO (as ENV DEST)", MOD(t).on && MOD(t).cut == (lfo * 63) >> 7 && MOD(t).cut / 256 == 62);
    mod_end(t);
    slot(t, 0, MS_LFO, MD_PITCH, 63);
    mod_begin(t);
    check("LFO -> PITCH +63: +11.8 semitones (as LFO DEST PIT)", MOD(t).pit == (lfo * 63 * 3) >> 15 && MOD(t).pit == 188);
    mod_end(t);
    slot(t, 0, MS_OFF, MD_OFF, 0);
    slot(t, 5, MS_LFO, MD_CUT, 63);                     /* slots 5..8 live outside p[] (track_t.mx) */
    mod_begin(t);
    check("slot 6 LFO -> CUT +63: as slot 1 (+62 steps)", MOD(t).on && MOD(t).cut / 256 == 62);
    mod_end(t);
    slot(t, 7, MS_LFO, MD_PITCH, 63);
    mod_begin(t);
    check("slots 6 and 8 add up: CUT +62, PITCH +188", MOD(t).cut / 256 == 62 && MOD(t).pit == 188);
    mod_end(t);
    slot(t, 5, MS_OFF, MD_OFF, 0);
    slot(t, 6, MS_MODW, MD_DEPTH, 64);
    t->mw = 0;
    mod_begin(t);
    check("slot 7 MODW -> DEPTH +64, wheel down: no LFO left (slot 8's PITCH 0)", MOD(t).ldep == 0 && MOD(t).pit == 0);
    mod_end(t);
    slot(t, 6, MS_OFF, MD_OFF, 0);
    slot(t, 7, MS_OFF, MD_OFF, 0);
    lfo_at(t, -32768);
    slot(t, 0, MS_LFO, MD_SHP, 63);
    mod_begin(t);
    check("LFO bipolar: the bottom of the LFO pulls SHP down", MOD(t).shp < -16000);
    mod_end(t);
    slot(t, 0, MS_LFO, MD_SHP, -64);
    mod_begin(t);
    check("a negative AMT inverts it", MOD(t).shp > 16000);
    mod_end(t);
    lfo_at(t, 0);
    slot(t, 0, MS_MODW, MD_AMP, 64 - 1);
    t->mw = 0;
    mod_begin(t);
    check("MODW -> AMP +63: the wheel down closes the amp (gain 1.6 %)", MOD(t).amp && MOD(t).gain >= 500 && MOD(t).gain <= 512);
    mod_end(t);
    t->mw = 127;
    mod_begin(t);
    check("MODW -> AMP +63: the wheel up opens it fully", MOD(t).gain >= 32760);
    mod_end(t);
    slot(t, 0, MS_AT, MD_AMP, -64);
    t->at = 127;
    mod_begin(t);
    check("AT -> AMP -64: full pressure closes it", MOD(t).gain < 200);
    mod_end(t);
    slot(t, 0, MS_EXPR, MD_AMP, 63);
    mod_begin(t);
    check("EXPR before any CC11 is full (the MIDI default): AMP open", MOD(t).gain >= 32760);
    mod_end(t);
    slot(t, 0, MS_LFO, MD_AMP, 64 - 1);
    mod_begin(t);
    check("LFO -> AMP: bipolar as 0..1 (half way at an LFO of 0)", MOD(t).gain > 16000 && MOD(t).gain < 17000);
    mod_end(t);

    /* per-voice sources on per-voice destinations (mod_voice) */
    fresh(0, 0);
    t->p[P_VOICE] = V_POLY;
    slot(t, 0, MS_KEY, MD_CUT, 63);
    slot(t, 1, MS_VEL, MD_AMP, 63);
    slot(t, 2, MS_ENV, MD_SHP, 40);
    slot(t, 3, MS_RAND, MD_PITCH, 20);
    {
        uint32_t rs = rng_state;
        trk_note_on(t, 72, 127);
        trk_note_on(t, 48, 1);
        check("RAND per note-on: its own generator (the shared rng untouched)", rng_state == rs && t->v[0].mrnd != t->v[1].mrnd);
    }
    mod_begin(t);
    memset(&m, 0, sizeof m);
    m.envq15 = 16384;
    m.shape = 64 << 8;
    m.pitch16 = 1000;
    m.inc = pitch_inc(1000);
    m.amp1 = 20000;
    v = &t->v[0];
    mod_voice(t, v, &m, 0);
    check("KEY -> CUT +63: an octave above C4 = +12 steps (key tracking 1:1)", m.cutoff == (12 * 512 * 63) >> 7 && m.cutoff / 256 == 11);
    check("VEL -> AMP +63: velocity 127 keeps the amplitude", m.amp1 == mulq15(20000, mulq15(32767, mod_gain(MS_VEL, 127 * 258, 63))) && m.amp1 > 19900 && v->env_out == m.amp1);
    check("ENV -> SHP +40: half the envelope = +20 steps", m.shape == (64 << 8) + ((16384 * 40) >> 7));
    check("RAND -> PITCH: the voice's own random offset", m.pitch16 == 1000 + ((v->mrnd * 20 * 3) >> 15) && m.inc == pitch_inc(m.pitch16));
    memset(&m, 0, sizeof m);
    m.amp1 = 20000;
    mod_voice(t, &t->v[1], &m, 0);
    check("KEY below C4 negative, VEL 1 -> AMP almost closed", m.cutoff == -((12 * 512 * 63) >> 7) && m.amp1 < 600);
    mod_end(t);

    /* the VEL destination: the note's velocity scaled once at note-on (mod_vel) */
    fresh(0, 0);
    t->p[P_VOICE] = V_POLY;
    lfo_at(t, 32767);
    slot(t, 0, MS_LFO, MD_VEL, 63);
    trk_note_on(t, 60, 100);
    check("LFO -> VEL: the top of the LFO leaves the velocity alone (100)", t->v[0].vel == 100u && t->m_vel == 100u);
    lfo_at(t, -32768);
    trk_note_on(t, 62, 100);
    check("LFO -> VEL: its bottom thins the note out (2)", t->v[1].vel == 2u);
    slot(t, 0, MS_VEL, MD_VEL, -64);
    trk_note_on(t, 64, 127);
    check("VEL -> VEL -64: a full velocity closes the note", t->v[2].vel == 0u);
    slot(t, 0, MS_MODW, MD_VEL, 63);
    t->mw = 127;
    trk_note_on(t, 65, 100);
    check("MODW -> VEL: the wheel up leaves it", t->v[3].vel == 100u);

    /* an engine macro as a per-block destination: MRAT moves the modulators' ratios on a sounding note */
    {
        uint64_t h0 = mrat_child(0), h1 = mrat_child(1);
        check("MODW -> MRAT: the FM6 sound follows the macro", h0 && h1 && h0 != h1);
    }

    /* clamping of the per-voice sums */
    fresh(0, 0);
    lfo_at(t, 32767);
    for (k_pw = 0; k_pw < 4u; k_pw++)
        slot(t, k_pw, MS_LFO, k_pw < 2u ? MD_CUT : MD_PITCH, 63);
    trk_note_on(t, 120, 100);
    lfo_at(t, 32767);                              /* (a note-on restarts the LFO and its FADE) */
    mod_begin(t);
    memset(&m, 0, sizeof m);
    m.cutoff = 100 << 8;
    m.pitch16 = 1920;
    mod_voice(t, &t->v[0], &m, 0);
    check("CUT sums clamp to what the fixed routings reach (+150), PITCH to 2047", m.cutoff == 150 * 256 && m.pitch16 == 2047);
    mod_end(t);

    /* per-block destinations: AMT 64 = the whole range, clamped, restored */
    fresh(0, 0);
    t->p[P_PAN] = 0;
    t->mw = 127;
    slot(t, 0, MS_MODW, MD_PAN, 16);
    mod_begin(t);
    check("MODW -> PAN +16: a quarter of the range (+31)", t->p[P_PAN] == ((((127 * 258) * 16) >> 6) * 127 >> 15) && t->p[P_PAN] == 31);
    mod_end(t);
    check("PAN restored after the block", t->p[P_PAN] == 0);
    slot(t, 1, MS_MODW, MD_PAN, 16);
    mod_begin(t);
    check("two slots on PAN add up (+62)", t->p[P_PAN] == 62);
    mod_end(t);
    slot(t, 1, MS_MODW, MD_PAN, 63);
    mod_begin(t);
    check("PAN clamps to +63", t->p[P_PAN] == 63);
    mod_end(t);
    slot(t, 1, MS_OFF, MD_OFF, 0);
    slot(t, 6, MS_MODW, MD_PAN, 16);
    mod_begin(t);
    check("slot 7 on PAN adds to slot 1 (+62), restored after", t->p[P_PAN] == 62);
    mod_end(t);
    check("slot 7: PAN restored after the block", t->p[P_PAN] == 0);
    slot(t, 6, MS_OFF, MD_OFF, 0);
    slot(t, 0, MS_AT, MD_REV, -64);
    t->at = 127;
    t->p[P_REV] = 50;
    mod_begin(t);
    check("AT -> REV -64: the send down to 0 (clamped)", t->p[P_REV] == 0);
    mod_end(t);
    lfo_at(t, -32768);
    slot(t, 0, MS_LFO, MD_DIST, 32);
    slot(t, 1, MS_LFO, MD_CHO, -32);
    slot(t, 2, MS_LFO, MD_RATE, 32);
    slot(t, 3, MS_LFO, MD_VIB, 32);
    t->p[P_DIST] = t->p[P_IHMIX] = 64;
    t->p[P_LRATE] = 100;
    t->p[P_LD_PIT] = 0;
    lfo = mulq15(-32768, 32767);
    mod_begin(t);
    {
        int32_t up = (((lfo * 32) >> 6) * 127) >> 15, dn = (((lfo * -32) >> 6) * 127) >> 15;
        check("LFO -> DIST / CHO (+-32), RATE, VIB: bipolar, half the range each",
              up < -30 && dn > 30 && t->p[P_DIST] == 64 + up && t->p[P_IHMIX] == 64 + dn && t->p[P_LRATE] == 100 + up &&
              t->p[P_LD_PIT] == up);
    }
    mod_end(t);
    check("every per-block value restored", t->p[P_DIST] == 64 && t->p[P_IHMIX] == 64 && t->p[P_LRATE] == 100 && t->p[P_LD_PIT] == 0);

    /* an engine parameter: its descriptor's range */
    e_trio = eng_by_name("TRIO");
    k_pw = edit_by_label(e_trio, "PW", 7);
    fresh(e_trio, 0);
    lfo_at(t, 32767);
    t->p[P_E0 + k_pw] = 100;
    slot(t, 0, MS_LFO, MD_E1 + (int32_t)k_pw, 40);
    mod_begin(t);
    check("LFO -> TRIO PW: clamped to its range (0..127)", t->p[P_E0 + k_pw] == 127);
    mod_end(t);
    t->p[P_E0 + 1] = 0;                            /* INT2: -24..24 */
    slot(t, 0, MS_MODW, MD_E1 + 1, -32);
    t->mw = 127;
    mod_begin(t);
    check("MODW -> E2 -32: half its range down (TRIO INT2 -24..24: -24)",
          t->p[P_E0 + 1] == (((((127 * 258) * -32) >> 6) * (ENGINES[e_trio]->edit[1].max - ENGINES[e_trio]->edit[1].min)) >> 15) &&
          t->p[P_E0 + 1] < -10);
    mod_end(t);
    check("the engine parameters restored", t->p[P_E0 + k_pw] == 100 && t->p[P_E0 + 1] == 0);
    check("DST names: E1..E8 by the engine's labels", str_eq(mod_dst_name(t, MD_E1 + (int32_t)k_pw), "PW") &&
                                                          str_eq(mod_dst_name(t, MD_CUT), "CUT"));

    /* per-voice sources on a per-block destination: the latest note-on */
    fresh(0, 0);
    slot(t, 0, MS_VEL, MD_PAN, 63);
    trk_note_on(t, 60, 20);
    mod_begin(t);
    {
        int32_t p1 = t->p[P_PAN];
        mod_end(t);
        trk_note_on(t, 64, 127);
        mod_begin(t);
        check("VEL -> PAN: the latest note-on's velocity", p1 == ((((20 * 258) * 63) >> 6) * 127 >> 15) && t->p[P_PAN] == 63);
        mod_end(t);
    }
    slot(t, 0, MS_KEY, MD_DLY, 63);
    t->p[P_DLY] = 64;
    mod_begin(t);
    check("KEY -> DLY: the latest note (E4: +4 semitones)", t->p[P_DLY] == 64 + ((((4 * 512) * 63) >> 6) * 127 >> 15));
    mod_end(t);
    slot(t, 0, MS_ENV, MD_PAN, 63);
    blocks(FS / 10u / CTL);
    mod_begin(t);
    check("ENV -> PAN: the latest note's envelope (sounding: > 0)", t->p[P_PAN] > 20 && t->m_env > 0);
    mod_end(t);

    /* #222: SLICER pattern / rate / depth as per-block destinations */
    fresh(0, 0);
    t->p[P_SLPAT] = 8;
    t->p[P_SLRATE] = 1;
    fx_bus_trk.p[P_SLPAT] = 8;
    fx_bus_trk.p[P_SLRATE] = 1;
    t->p[P_SLDEPTH] = 64;
    t->mw = 127;
    slot(t, 0, MS_MODW, MD_SLPAT, 63);
    slot(t, 1, MS_MODW, MD_SLRATE, 63);
    slot(t, 2, MS_MODW, MD_SLDEPTH, 63);
    mod_begin(t);
    check("#222 MODW -> SLICER PAT / RATE / DEPTH: whole range at AMT 63",
          *mod_target_ptr(t, P_SLPAT) == TP[P_SLPAT].max && *mod_target_ptr(t, P_SLRATE) == TP[P_SLRATE].max &&
          t->p[P_SLDEPTH] == 127);
    mod_end(t);
    check("#222 SLICER params restored after the block",
          t->p[P_SLPAT] == 8 && t->p[P_SLRATE] == 1 && t->p[P_SLDEPTH] == 64);
    check("#222 DST names: PAT / SRATE / SDEP",
          str_eq(mod_dst_name(t, MD_SLPAT), "PAT") && str_eq(mod_dst_name(t, MD_SLRATE), "SRATE") &&
          str_eq(mod_dst_name(t, MD_SLDEPTH), "SDEP"));

    /* CHRD / VOIC as per-block destinations (append after SLICER) */
    fresh(0, 0);
    t->p[P_CHRD] = CH_OFF;
    t->p[P_VOIC] = VC_CLOSE;
    t->mw = 127;
    slot(t, 0, MS_MODW, MD_CHRD, 63);
    slot(t, 1, MS_MODW, MD_VOIC, 63);
    mod_begin(t);
    {
        int32_t ch = ((((127 * 258) * 63) >> 6) * (TP[P_CHRD].max - TP[P_CHRD].min)) >> 15;
        int32_t vc = ((((127 * 258) * 63) >> 6) * (TP[P_VOIC].max - TP[P_VOIC].min)) >> 15;
        check("MODW -> CHRD / VOIC: per-block enum scale at AMT 63",
              t->p[P_CHRD] == ch && t->p[P_VOIC] == vc && ch > 0 && vc > 0);
    }
    mod_end(t);
    check("CHRD / VOIC restored after the block", t->p[P_CHRD] == CH_OFF && t->p[P_VOIC] == VC_CLOSE);
    check("DST names: CHRD / VOIC",
          str_eq(mod_dst_name(t, MD_CHRD), "CHRD") && str_eq(mod_dst_name(t, MD_VOIC), "VOIC"));

    /* insert continuous knobs + MIX (append after CHORD; CHOR MIX is CHO) */
    fresh(0, 0);
    t->p[P_ED_FX] = 0;
    t->p[P_IDMIX] = 40;
    t->p[P_IFCUT] = 64;
    t->p[P_IFMIX] = 40;
    t->p[P_ICBITS] = 64;
    t->p[P_ICMIX] = 40;
    t->p[P_IPRATE] = 64;
    t->p[P_ILDEP] = 64;
    t->p[P_ILMIX] = 40;
    t->p[P_IHDEP] = 64;
    t->mw = 127;
    slot(t, 0, MS_MODW, MD_TONE, 63);
    slot(t, 1, MS_MODW, MD_DMIX, 63);
    slot(t, 2, MS_MODW, MD_FCUT, 63);
    slot(t, 3, MS_MODW, MD_FMIX, 63);
    mod_begin(t);
    check("MODW -> TONE / DMIX / FCUT / FMIX: whole range at AMT 63",
          t->p[P_ED_FX] == TP[P_ED_FX].max && t->p[P_IDMIX] == TP[P_IDMIX].max &&
          t->p[P_IFCUT] == TP[P_IFCUT].max && t->p[P_IFMIX] == TP[P_IFMIX].max);
    mod_end(t);
    slot(t, 0, MS_MODW, MD_BITS, 63);
    slot(t, 1, MS_MODW, MD_CMIX, 63);
    slot(t, 2, MS_MODW, MD_LMIX, 63);
    slot(t, 3, MS_MODW, MD_HDEP, 63);
    mod_begin(t);
    check("MODW -> CRUSH BITS/CMIX, FLANG LMIX, CHOR HDEP",
          t->p[P_ICBITS] == TP[P_ICBITS].max && t->p[P_ICMIX] == TP[P_ICMIX].max &&
          t->p[P_ILMIX] == TP[P_ILMIX].max && t->p[P_IHDEP] == TP[P_IHDEP].max);
    mod_end(t);
    check("insert knobs restored after the block",
          t->p[P_ED_FX] == 0 && t->p[P_IDMIX] == 40 && t->p[P_IFCUT] == 64 && t->p[P_IFMIX] == 40 &&
          t->p[P_ICBITS] == 64 && t->p[P_ICMIX] == 40 && t->p[P_ILMIX] == 40 && t->p[P_IHDEP] == 64);
    check("DST names: TONE / DMIX / HDEP; CHO is CHOR MIX; DLY/REV amounts stay; TAPE SPEED/FLUTR",
          str_eq(mod_dst_name(t, MD_TONE), "TONE") && str_eq(mod_dst_name(t, MD_DMIX), "DMIX") &&
          str_eq(mod_dst_name(t, MD_HDEP), "HDEP") && mod_param(MD_CHO) == P_IHMIX &&
          mod_param(MD_DLY) == P_DLY && mod_param(MD_REV) == P_REV && MD_TONE == 26 &&
          mod_param(MD_TSPEED) == MFX_TSPEED && mod_param(MD_TWOW) == MFX_TWOW &&
          str_eq(mod_dst_name(t, MD_TSPEED), "TSPEED") && str_eq(mod_dst_name(t, MD_TWOW), "TWOW") &&
          MD_TSPEED == 49 && MD_TWOW == 50 && MD_VEL == 51 && MD_N == 52 && str_eq(mod_dst_name(t, MD_VEL), "VEL"));

    /* DIST on SEND lives in fx_bus_trk; LFO must move the bus, not track p[] */
    fresh(0, 0);
    ins_send_set(t, INS_DIST, 1);
    fx_bus_trk.p[P_DIST] = 64;
    t->p[P_DIST] = 20;
    lfo_at(t, 32767);
    slot(t, 0, MS_LFO, MD_DIST, 63);
    slot(t, 1, MS_OFF, MD_OFF, 0);
    slot(t, 2, MS_OFF, MD_OFF, 0);
    slot(t, 3, MS_OFF, MD_OFF, 0);
    mod_begin(t);
    check("LFO -> DIST SEND: modulates the bus knobs, leaves track p[] alone",
          *mod_target_ptr(t, P_DIST) == TP[P_DIST].max && t->p[P_DIST] == 20);
    mod_end(t);
    check("LFO -> DIST SEND: the real bus knobs hold the stored value (the copy is the render's view)",
          fx_bus_trk.p[P_DIST] == 64 && t->p[P_DIST] == 20);
}

/* ------------------------------------------------------------------ 3 --- */
static void pkt(uint32_t st, uint32_t d1, uint32_t d2)
{
    midi_in_q[mi_w++ % MQ] = (st >> 4) | st << 8 | d1 << 16 | d2 << 24;
}
/* fn() in a fork()ed child (the tests' state stays as it was); its result */
static int in_child(int (*fn)(void))
{
    int st = 0;
    pid_t pid;
    fflush(stdout);
    if (!(pid = fork()))
        _exit(fn() ? 0 : 1);
    waitpid(pid, &st, 0);
    return WIFEXITED(st) && WEXITSTATUS(st) == 0;
}
static int pan_e2e(void)                       /* MODW -> PAN moves the pan the mix uses */
{
    int64_t l = 0, r = 0;
    uint32_t i, k;
    fresh(0, 0);
    slot(&trk[0], 0, MS_MODW, MD_PAN, 63);
    trk[0].p[P_DLY] = trk[0].p[P_REV] = 0;   /* (the buses are in the middle) */
    pkt(0xB0, 1, 127);
    trk_note_on(&trk[0], 60, 100);
    blocks(FS / 10u / CTL);
    for (k = 0; k < FS / 10u / CTL; k++) {
        blocks(1);
        for (i = 0; i < CTL; i++) {
            l += labs(out_buf[2u * i]);
            r += labs(out_buf[2u * i + 1u]);
        }
    }
    return r > 20 * l && l > 0 && trk[0].p[P_PAN] == 0;
}

static void test_midi(void)
{
    static const uint8_t TRS[] = {0xB0, 1, 0x40, 1, 0x7F, 0xF8, 11, 0x20, 0xD2, 0x33, 0x34, 0x90, 60, 0, 0xB4, 1, 9};
    uint32_t i;
    fresh(0, 0);
    song.sel = 1;
    pkt(0xB0, 1, 100);                           /* ch 1 CC1 */
    pkt(0xB2, 11, 40);                           /* ch 3 CC11 */
    pkt(0xD3, 77, 0);                            /* ch 4 aftertouch */
    pkt(0xB6, 1, 55);                            /* ch 7: ignored with ROUT CH1-4 (#68) */
    pkt(0xB0, 7, 10);                            /* other CCs: ignored */
    blocks(1);
    check("USB: CC1 ch 1 -> part 1, CC11 ch 3 -> part 3, AT ch 4 -> part 4",
          trk[0].mw == 100 && trk[2].ex_off == 127 - 40 && trk[3].at == 77 && trk[0].at == 0 && trk[0].ex_off == 0);
    check("USB: ROUT CH1-4: CC1 on ch 7 reaches no track", trk[1].mw == 0 && trk[2].mw == 0);
    song.g[G_ROUTE] = 1;
    pkt(0xB6, 1, 55);                            /* ROUT SEL: ch 7 -> the selected track (2) */
    blocks(1);
    check("USB: ROUT SEL: CC1 on ch 7 -> the selected track (2)", trk[1].mw == 55 && trk[2].mw == 0);
    song.g[G_ROUTE] = 0;
    pkt(0xB0, 121, 0);                           /* reset all controllers */
    blocks(1);
    check("CC121 resets MODW / AT / EXPR of the channel's track", trk[0].mw == 0 && trk[1].mw == 55);
    fresh(0, 0);
    song.sel = 1;
    for (i = 0; i < sizeof TRS; i++)
        um_byte(TRS[i]);
    blocks(1);
    check("TRS: CC1, running status, realtime between, CC11, AT (1 data byte, running status) -> parts",
          trk[0].mw == 0x7F && trk[0].ex_off == 127 - 0x20 && trk[2].at == 0x34 && trk[0].at == 0);
    check("TRS: ROUT CH1-4: ch 5 is ignored", trk[1].mw == 0);
    song.g[G_ROUTE] = 1;
    for (i = 14; i < sizeof TRS; i++)           /* the ch 5 CC1 again with ROUT SEL */
        um_byte(TRS[i]);
    blocks(1);
    song.g[G_ROUTE] = 0;
    check("TRS: ROUT SEL: ch 5 -> the selected track (2)", trk[1].mw == 9);
    check("MODW -> PAN +63 through MIDI: the part is on the right (fresh FX)", in_child(pan_e2e));
}
/* ------------------------------------------------------------------ 4 --- */
static uint64_t instr_now(void)
{
#ifdef __APPLE__
    struct rusage_info_v4 ri;
    if (!proc_pid_rusage(getpid(), RUSAGE_INFO_V4, (rusage_info_t *)&ri))
        return ri.ri_instructions;
#endif
    return 0;
}

/* instructions per sample: parts[k] = {engine, preset, notes}; on: every slot of every sounding part active
 * (LFO -> CUT, VEL -> AMP, MODW -> VIB, LFO -> E3: per voice and per block) */
static double cost(const uint8_t parts[NPART][3], int on)
{
    static const uint8_t NOTES[8] = {48, 52, 55, 59, 60, 64, 67, 71};
    uint32_t p, i, rep;
    double best = 1e30;
    fresh(0, 0);
    for (p = 0; p < NPART; p++) {
        track_t *t = &trk[p];
        host_preset(t, parts[p][0], parts[p][1]);
        t->p[P_VOICE] = V_POLY;
        t->p[P_SUS] = 127;
        t->p[P_AMODE] = 0;
        t->mw = 90;
        if (on && parts[p][2]) {
            slot(t, 0, MS_LFO, MD_CUT, 30);
            slot(t, 1, MS_VEL, MD_AMP, 40);
            slot(t, 2, MS_MODW, MD_VIB, 8);
            slot(t, 3, MS_LFO, MD_E1 + 2, 20);
        }
        for (i = 0; i < parts[p][2]; i++)
            trk_note_on(t, NOTES[i] + 12u * p, 100);
    }
    blocks(FS / 2u / CTL);
    for (rep = 0; rep < 3u; rep++) {
        uint64_t i0 = instr_now();
        double ipc;
        blocks(FS / CTL);
        ipc = (double)(instr_now() - i0) / FS;
        best = ipc < best ? ipc : best;
    }
    return best;
}

static void test_cost(void)
{
    uint32_t e_phys = eng_by_name("PHYS"), pp = preset_by_name(e_phys, "BOWED METAL");
    uint8_t phys[NPART][3] = {{(uint8_t)e_phys, (uint8_t)pp, 8}}, idle[NPART][3] = {{0}};
    uint8_t mix[NPART][3] = {{1, 0, 8}, {2, 0, 8}, {(uint8_t)e_phys, (uint8_t)pp, 4}, {6, 0, 4}};
    double c_idle, c0, c1, m0, m1;
    if (!instr_now()) {
        printf("mod: cost: no instruction counter on this host (proc_pid_rusage), skipped\n");
        return;
    }
    c_idle = cost(idle, 0);
    c0 = cost(phys, 0);
    c1 = cost(phys, 1);
    m0 = cost(mix, 0);
    m1 = cost(mix, 1);
    printf("mod: cost: PHYS %s (plays 4 voices): %.0f -> %.0f instructions / sample with 4 slots (+%.0f, +%.1f %% of "
           "the part over the idle mix %.0f)\n", ENGINES[e_phys]->presets[pp].name, c0, c1, c1 - c0,
           (c1 - c0) * 100 / (c0 - c_idle), c_idle);
    printf("mod: cost: 4 parts (DIGITAL / its FM6 conversion 8 + PHASE 8 + PHYS 4 + TRIO 4 asked, the budget plays 8), every slot of "
           "every part active: %.0f -> %.0f (+%.1f %%)\n", m0, m1, (m1 - m0) * 100 / m0);
    check("cost: 4 active slots add at most a few percent (PHYS part, the 4-part mix)",
          (c1 - c0) * 100 / (c0 - c_idle) <= MOD_COST_MAX && (m1 - m0) * 100 / m0 <= MOD_COST_MAX);
}

/* ------------------------------------------------------------------ 5 --- */
static FILE *demo_open(const char *dir, const char *name, uint32_t frames)
{
    char path[512];
    FILE *f;
    snprintf(path, sizeof path, "%s/%s.wav", dir, name);
    f = fopen(path, "wb");
    if (f)
        wav_hdr(f, frames);
    return f;
}
static void demo_blocks(FILE *f, uint32_t n)
{
    uint32_t i;
    while (n--) {
        blocks(1);
        for (i = 0; i < CTL; i++)
            wav_put(f, out_buf[2u * i], out_buf[2u * i + 1u]);
    }
}

static int demos(const char *dir)
{
    uint32_t e, k, n = 0;
    FILE *f;
    track_t *t = &trk[0];
    /* LFO -> CUT: ANALOG SAW LEAD, a held chord, a slow sine LFO opens and closes the filter */
    fresh(0, 0);
    t->p[P_LRATE] = 30;
    slot(t, 0, MS_LFO, MD_CUT, 48);
    if ((f = demo_open(dir, "lfo_cut", 6u * FS / CTL * CTL))) {
        trk_note_on(t, 48, 100);
        trk_note_on(t, 55, 100);
        trk_note_on(t, 60, 100);
        demo_blocks(f, 5u * FS / CTL);
        trk_note_off(t, 48);
        trk_note_off(t, 55);
        trk_note_off(t, 60);
        demo_blocks(f, FS / CTL);
        fclose(f);
        n++;
    }
    /* VEL -> AMP: DIGITAL E.PIANO (converted to FM6), the same note at velocities 10 .. 127, twice as much dynamics */
    fresh(1, 0);
    slot(t, 0, MS_VEL, MD_AMP, 63);
    slot(t, 1, MS_VEL, MD_CUT, 30);
    if ((f = demo_open(dir, "vel_amp", 16u * (FS / 4u / CTL) * CTL + FS / CTL * CTL))) {
        for (k = 0; k < 16u; k++) {
            trk_note_on(t, 60u + (k & 3u) * 4u, 10u + k * 117u / 15u);
            demo_blocks(f, FS / 4u / CTL);
            trk_note_off(t, 60u + (k & 3u) * 4u);
        }
        demo_blocks(f, FS / CTL);
        fclose(f);
        n++;
    }
    /* MODW -> VIB: LOFI WAVE LEAD, the mod wheel (CC1) rises over 4 s: vibrato from none to deep */
    e = eng_by_name("LOFI");
    fresh(e, preset_by_name(e, "WAVE LEAD"));
    t->p[P_LRATE] = 70;
    t->p[P_LD_PIT] = 0;
    t->p[P_LFADE] = 0;
    slot(t, 0, MS_MODW, MD_VIB, 12);
    if ((f = demo_open(dir, "modw_vib", 5u * FS / CTL * CTL))) {
        trk_note_on(t, 69, 100);
        for (k = 0; k < 4u * FS / CTL; k++) {
            if (k % 32u == 0u)
                pkt(0xB0, 1, k * 127u / (4u * FS / CTL));
            demo_blocks(f, 1);
        }
        trk_note_off(t, 69);
        demo_blocks(f, FS / CTL);
        fclose(f);
        n++;
    }
    /* LFO -> TRIO PW: TRIO ARP LEAD's pulse width swept by a triangle LFO */
    e = eng_by_name("TRIO");
    fresh(e, preset_by_name(e, "ARP LEAD"));
    t->p[P_LRATE] = 45;
    t->p[P_LWAVE] = 1;
    t->p[P_AMODE] = 0;
    t->p[P_VOICE] = V_POLY;
    slot(t, 0, MS_LFO, MD_E1 + (int32_t)edit_by_label(e, "PW", 7), 40);
    if ((f = demo_open(dir, "lfo_trio_pw", 5u * FS / CTL * CTL))) {
        trk_note_on(t, 57, 100);
        demo_blocks(f, 4u * FS / CTL);
        trk_note_off(t, 57);
        demo_blocks(f, FS / CTL);
        fclose(f);
        n++;
    }
    /* AT -> WHEEL DRV: an organ chord, channel aftertouch pushes the drive up and down */
    e = eng_by_name("WHEEL");
    fresh(e, 0);
    slot(t, 0, MS_AT, MD_E1 + (int32_t)edit_by_label(e, "DRV", 6), 63);
    slot(t, 1, MS_AT, MD_CUT, 20);
    if ((f = demo_open(dir, "at_wheel_drv", 6u * FS / CTL * CTL))) {
        trk_note_on(t, 48, 100);
        trk_note_on(t, 55, 100);
        trk_note_on(t, 64, 100);
        for (k = 0; k < 5u * FS / CTL; k++) {
            uint32_t ph = k * 254u / (5u * FS / CTL);
            if (k % 16u == 0u)
                pkt(0xD0, ph < 127u ? ph : 254u - ph, 0);
            demo_blocks(f, 1);
        }
        trk_note_off(t, 48);
        trk_note_off(t, 55);
        trk_note_off(t, 64);
        demo_blocks(f, FS / CTL);
        fclose(f);
        n++;
    }
    printf("mod: %u demos in %s (lfo_cut, vel_amp, modw_vib, lfo_trio_pw, at_wheel_drv)\n", n, dir);
    return n == 5u;
}

static void test_fx_controls(void)
{
    static const uint8_t GLOBAL[] = {G_DTIME, G_DFDBK, G_DCOLOR, G_RSIZE, G_RDAMP};
    static const int16_t BASE[] = {564, 40, 30, 20, 10};
    static const int16_t TOP[] = {1550, 120, 127, 127, 127};
    uint32_t chain, k;
    for (chain = 0; chain < 2; chain++) {
        host_tracks_init();
        song.g[G_REVOWN] = chain ? 1 : 0;
        song.g[G_CRSIZE] = 25;
        song.g[G_CRDAMP] = 15;
        for (k = 0; k < 5; k++) {
            track_t *t = &trk[0];
            uint32_t g = GLOBAL[k];
            int16_t base = BASE[k];
            song.g[g] = base;
            if (chain && k >= 3) {
                g = k == 3 ? G_CRSIZE : G_CRDAMP;
                base = song.g[g];
            }
            memset(t->p + P_M1SRC, 0, 12 * sizeof t->p[0]);
            slot(t, 0, MS_MODW, 44 + k, 63);
            t->mw = 127;
            bus_knobs_g(t);                             /* (the block's start does this in fx.c mix_block) */
            mod_begin(t);
            if (chain && k >= 3) {
                int32_t keep[5];
                bus_g_put(t, 3, 5, keep, 0);                /* fx.c: the CHAIN run takes the part's copy */
                check("continuous FX target reaches the selected bank", song.g[g] == TOP[k]);
                bus_g_put(t, 3, 5, keep, 1);
                check("CHAIN modulation leaves SEND reverb settings alone", song.g[GLOBAL[k]] == BASE[k]);
            }
            mod_end(t);
            if (!(chain && k >= 3)) {
                mod_bus_begin();                            /* fx.c fx_buses: the SEND buses take the held values */
                check("continuous FX target reaches the selected bank", song.g[g] == TOP[k]);
                mod_bus_end();
            }
            check("continuous FX target restores its base", song.g[g] == base);
        }
    }
}

static void test_all_shared_controls(void)
{
    static const uint8_t DEST[] = {MD_DTIME, MD_DFB, MD_DCOLOR, MD_RSIZE, MD_RDAMP, MD_TSPEED, MD_TWOW};
    static const uint8_t GLOBAL[] = {G_DTIME, G_DFDBK, G_DCOLOR, G_RSIZE, G_RDAMP, G_TSPEED, G_TWOW};
    static const int16_t BASE[] = {564, 40, 30, 20, 10, 100, 0};
    static const int16_t TOP[] = {1550, 120, 127, 127, 127, 400, 125};
    uint32_t i, k;
    host_tracks_init();
    song.g[G_TAPEMODE] = TAPE_MASTER;
    for (i = 0; i < NELEM(DEST); i++) {
        track_t *t = &trk[i / NMSLOT];
        song.g[GLOBAL[i]] = BASE[i];
        t->mw = 127;
        slot(t, i % NMSLOT, MS_MODW, DEST[i], 63);
    }
    for (k = 0; k < 2; k++) {
        bus_knobs_g(&trk[k]);
        mod_begin(&trk[k]);
        mod_end(&trk[k]);
    }
    mod_bus_begin();
    for (i = 0; i < NELEM(DEST); i++)
        check("all seven shared controls reach the bus in the same block", song.g[GLOBAL[i]] == TOP[i]);
    mod_bus_end();
    for (i = 0; i < NELEM(DEST); i++)
        check("all seven shared controls restore their stored values", song.g[GLOBAL[i]] == BASE[i]);
}

/* ------------------------------------------------ every destination in the sound --- */
/* A rig where each destination can reach the output: ANALOG PWM (SHP is read), OSC B mixed in (DTN / INT),
 * the six inserts at MIX 64, DLY / REV sends, the slicer and TAPE in CHAIN on track 1 (TEMPO off), the LFO in
 * the amp and the pitch, a 1/32 delay (feedback and colour land inside the render), and a DIA3 chord so VOIC
 * has something to voice. THE test: a slot on any destination must change the rendered hash. */
static uint32_t dst_preset(const char *n)
{
    uint32_t i;
    for (i = 0; i < ENGINES[ENGI_ANALOG]->npresets; i++)
        if (!strcmp(ENGINES[ENGI_ANALOG]->presets[i].name, n))
            return i;
    return 0;
}

static void dst_rig(void)
{
    track_t *t = &trk[0];
    uint32_t s, k;
    memset(dly_buf, 0, sizeof dly_buf);
    memset(rev_tank, 0, sizeof rev_tank);
    R = &rev_tank[0];
    memset(&fx, 0, sizeof fx);
    lim_env = LIM_T;
    memset(trk, 0, sizeof trk);
    MOD_W_CLEAR();
    host_tracks_init();
    for (k = 0; k < NPART; k++)
        host_preset(&trk[k], k ? 0u : ENGI_ANALOG, k ? 0u : dst_preset("SOFT PAD"));
    song.sel = 0;
    t->p[P_VOICE] = V_POLY;
    t->p[P_E0] = 4;                              /* PWM: SHP is audible */
    t->p[P_E0 + 2] = 64;                         /* OSC B in the mix: DTN / INT are audible */
    t->p[P_LD_AMP] = 50;                         /* the LFO routed: RATE / VIB / DEPTH are audible */
    t->p[P_LD_PIT] = 30;
    t->p[P_LRATE] = 64;
    for (s = 0; s < INS_N; s++)
        ins_send_set(t, s, 0);                   /* the six inserts in CHAIN */
    ins_send_set(t, INS_SLCR, 0);                /* the slicer on this track */
    t->p[P_ED_FX] = 20;
    t->p[P_IDMIX] = 64;
    t->p[P_IFMIX] = 64;
    t->p[P_ICMIX] = 64;
    t->p[P_IPMIX] = 64;
    t->p[P_ILMIX] = 64;
    t->p[P_IHMIX] = 64;
    t->p[P_DLY] = 80;
    t->p[P_REV] = 80;
    t->p[P_SLCR] = SL_GATE;
    t->p[P_SLPAT] = 5;
    t->p[P_SLDEPTH] = 64;
    song.g[G_SLOWN] = 1;
    song.g[G_TAPEMODE] = TAPE_CH1;
    song.g[G_TMIX] = 127;
    song.g[G_TTEMPO] = 0;
    song.g[G_TSPEED] = 100;
    song.g[G_TWOW] = 50;
    song.g[G_DTIME] = 3;                         /* 1/32 */
    slicer_start();
    t->p[P_CHRD] = CH_DIA3;
    t->p[P_VOIC] = VC_CLOSE;
}

static uint64_t dst_render(int dst)
{
    track_t *t = &trk[0];
    uint8_t notes[CHORD_MAX];
    uint32_t b, i, n, k;
    uint64_t h = 0xCBF29CE484222325ull;
    dst_rig();
    if (dst >= 0) {
        int gain = dst == MD_AMP || dst == MD_VEL;      /* a full source leaves a gain unchanged */
        t->p[P_M1SRC] = (int16_t)(gain ? MS_KEY : MS_MODW);
        t->p[P_M1DST] = (int16_t)dst;
        t->p[P_M1AMT] = (int16_t)(dst == MD_CHRD ? 20 : 63);
        t->mw = 127;
    }
    n = chord_build(t, 60, notes);                      /* CHRD / VOIC are read here (mod.c mod_value) */
    for (i = 0; i < n; i++)
        trk_note_on(t, notes[i], 100);
    for (b = 0; b < 400u; b++) {
        mix_block(out_buf, CTL);
        for (k = 0; k < 2u * CTL; k++) {
            h ^= (uint32_t)out_buf[k];
            h *= 0x100000001B3ull;
        }
    }
    return h;
}

static uint64_t dst_child(int dst)
{
    int fd[2];
    uint64_t h = 0;
    pid_t pid;
    if (pipe(fd))
        return 0;
    fflush(stdout);
    if (!(pid = fork())) {
        h = dst_render(dst);
        if (write(fd[1], &h, sizeof h) != sizeof h)
            _exit(1);
        _exit(0);
    }
    close(fd[1]);
    if (read(fd[0], &h, sizeof h) != sizeof h)
        h = 0;
    close(fd[0]);
    waitpid(pid, 0, 0);
    return h;
}

static void test_dst_audio(void)
{
    uint64_t base = dst_child(-1);
    char same[192] = "";
    int d, n = 0;
    for (d = 1; d < MD_N; d++)
        if (dst_child(d) == base) {                  /* (a child renders it; the parent stays clean) */
            if (n++ < 12)
                snprintf(same + strlen(same), sizeof same - strlen(same), " %s", N_MDST[d]);
        }
    if (n)
        snprintf(same + strlen(same), sizeof same - strlen(same), "%s%u same", n <= 12 ? "" : " ...", n);
    check("every MOD destination changes the rendered sound (a slot on each, one child each)", base && !n);
    if (n)
        printf("mod:   same with the slot on:%s\n", same);
}

int main(int argc, char **argv)
{
    test_off();
    test_math();
    test_dst_audio();
    test_fx_controls();
    test_all_shared_controls();
    test_midi();
    test_cost();
    if (argc > 1)
        check("demos written", demos(argv[1]));
    printf("%s\n", bad ? "MOD MATRIX TEST FAILED" : "mod matrix test passed");
    return bad != 0;
}
