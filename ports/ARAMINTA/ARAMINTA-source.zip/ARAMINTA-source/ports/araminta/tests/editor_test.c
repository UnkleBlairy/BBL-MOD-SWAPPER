/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* The firmware editor handler, USB framing and UART recovery against RAM flash.
 * Build with the generated tables and the same flags as hostsim.c. */
static unsigned char host_samples[3][0x14000];
#define SMP_USER_XIP(k) host_samples[k]
#define FELUCCA_OTA 1
#define FELUCCA_FLASH 0
#define FELUCCA_VERSION "TEST"
#define FELUCCA_CDC 1                                    /* (as the firmware: MENU > USB SERIAL switches the console) */
#define main hostsim_main
#include "hostsim.c"
#undef main

static uint32_t host_progress = 1, host_erases, host_writes;
static uint8_t host_wire[4096];
static uint32_t host_wire_n;
static void host_drain(void)
{
    while (so_r != so_w) {
        uint32_t p = sx_out_q[so_r++ % SXQ], cin = p & 15u, i;
        uint32_t n = cin == 4u || cin == 7u ? 3u : cin == 6u ? 2u : 1u;
        for (i = 0; i < n && host_wire_n < sizeof host_wire; i++)
            host_wire[host_wire_n++] = (uint8_t)(p >> (8u * (i + 1u)));
    }
}
static uint32_t ota_now_ms(void) { return fm1_ms; }
static void ota_idle(void) { host_drain(); fm1_ms++; }
static void fm1_wdt_feed(void)
{
    fm1_ms++;
    if (host_progress && transport_req == 2u) { seq_stop(); transport_req = 0; }
}
static void fm1_irq_off(void) {}
static void fm1_irq_on(void) {}
static int32_t fm1_enc_take(uint32_t e) { (void)e; return 0; }
static void lcd_sync(void) {}
static void lcd_power(uint32_t s) { (void)s; }   /* (MENU > SCREEN OFF: lcd.c) */
static void lcd_wake_now(void) {}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *p)
{ (void)x; (void)y; (void)w; (void)h; (void)p; }
#include "../firmware/src/gfx.c"
#include "../firmware/src/panel.c"
#include "../firmware/src/ui.c"
#include "../firmware/src/menu_items.c"
static void panel_setup(void) {}
#include "../firmware/src/upreset.c"
#include "../firmware/src/project.c"
/* 3.10: FELUCCA_FLASH 0 keeps a test-only wire image per slot (project.c extern). */
project_store_t proj_slot[4];

static uint32_t flash_ok = 1;
static void audio_silence(void) {}
static void fl_inval(uint32_t off, uint32_t n) { (void)off; (void)n; }
static uint8_t *host_flash_ptr(uint32_t off) { return &host_samples[0][0] + off - SMP_USER_BASE; }
static int fl_erase4k(uint32_t off, uint32_t *took)
{
    memset(host_flash_ptr(off), 0xFF, 4096); *took = 0; host_erases++; return 0;
}
static int fl_write(uint32_t off, const void *p, uint32_t n)
{
    memcpy(host_flash_ptr(off), p, n); host_writes++; return 0;
}
static int st_read(uint32_t off, void *p, uint32_t n) { (void)off; (void)p; (void)n; return -1; }
static int st_prog(uint32_t off, const void *p, uint32_t n) { (void)off; (void)p; (void)n; return -1; }
static int st_erase(uint32_t off) { (void)off; return -1; }
#include "../firmware/src/storage.c"
#include "../firmware/src/editor.c"

static int check(const char *what, int ok)
{
    printf("editor: %-70s %s\n", what, ok ? "ok" : "FAIL");
    return !ok;
}
static void reset(void)
{
    uint32_t t, i;
    memset(&song, 0, sizeof song); memset(trk, 0, sizeof trk);
    memset(&chain, 0, sizeof chain); chain_defaults(&chain_config);
    memset(&ed_w, 0, sizeof ed_w); memset(&ui, 0, sizeof ui);
    memset(&favorites, 0, sizeof favorites); memset(&settings, 0, sizeof settings); settings_init();
    memset(proj_slot, 0, sizeof proj_slot); memset(up_bank, 0, sizeof up_bank);
    memset(&um, 0, sizeof um); memset(usr_nz, 0, sizeof usr_nz); memset(usr_drum, 0, sizeof usr_drum);
    host_progress = 1; host_erases = host_writes = host_wire_n = 0;
    transport_req = panic_req = 0; sx_ready = sx_collect = sx_busy = 0;
    so_r = so_w = mi_r = mi_w = 0; midi_in_overflow = 0; usb.config = 1;
    for (i = 0; i < G_COUNT; i++) song.g[i] = GP[i].def;
    for (t = 0; t < NTRK; t++) {
        track_defaults(&trk[t]); set_engine_of(&trk[t], 0); apply_preset_to(&trk[t], 0);
        trk[t].engine = trk[t].eng_req; track_defaults_steps(&trk[t]);
    }
}
static uint32_t request(uint32_t cmd, const uint8_t *a, uint32_t n)
{
    uint32_t i;
    host_wire_n = 0; ota_frame_done();
    sysex_byte(0xF0); sysex_byte(ED_HDR0); sysex_byte(ED_HDR1); sysex_byte(ED_HDR2); sysex_byte((uint8_t)cmd);
    for (i = 0; i < n; i++) sysex_byte(a[i]);
    sysex_byte(0xF7); ed_service(); host_drain();
    return host_wire_n;
}
static int matrix_edits_preserve_fx_locks(void)
{
    int bad = 0;
    const uint32_t commands[] = {ED_SET, ED_TRACK_PARAM};
    const int16_t edits[] = {3, MD_PAN, 32, 1, MD_PAN};
    const uint32_t globals[] = {G_DTIME, G_DFDBK, G_DCOLOR, G_RSIZE, G_RDAMP};
    for (uint32_t c = 0; c < 2; c++) {
        for (uint32_t record = 0; record < 2; record++) {
            reset();
            for (uint32_t k = 0; k < NTRK; k++) motion_clear(&trk[k]);
            song.g[G_DTIME] = 1;
            int16_t base[5];
            for (uint32_t i = 0; i < 5; i++) {
                base[i] = song.g[globals[i]];
                motion_set_lock(&trk[0], 0, MFX_TIME + i, i ? 100 : 1550);
            }
            seq_start(); motion_step(&trk[0], 0, &motion, 1); song.rec = (uint8_t)record;
            motion_store_t saved = motion;
            int ok = 1;
            for (uint32_t i = 0; i < 5; i++) {
                uint16_t raw = (uint16_t)(edits[i] + 8192);
                uint8_t args[] = {0, (uint8_t)(P_M1SRC + i), (uint8_t)(raw & 127u), (uint8_t)(raw >> 7)};
                request(commands[c], args, sizeof args);
                ok &= trk[0].p[P_M1SRC + i] == edits[i];
            }
            for (uint32_t i = 0; i < 5; i++) ok &= motion_fx_base(&song.g[globals[i]]) == base[i];
            ok &= !memcmp(&saved, &motion, sizeof saved);
            bad += check(commands[c] == ED_SET ? "SET matrix fields preserves active FX lock bases and records" :
                         "TRACK_PARAM matrix fields preserves active FX lock bases and records", ok);
            seq_stop();
        }
    }
    return bad;
}
/* Editor ORDER and FXPOS edits must reach the running chain without moving TAPE. */
static int editor_fx_order(void)
{
    int bad = 0;
    const uint32_t commands[] = {ED_SET, ED_TRACK_PARAM};
    const uint8_t initial[FX_LIST_N] = {INS_DIST, INS_TAPE, INS_CRUSH, INS_FILTER,
        INS_PHASR, INS_FLANG, INS_CHOR, INS_DLY, INS_REV, INS_SLCR};
    const uint8_t ordered[FX_LIST_N] = {INS_DIST, INS_TAPE, INS_FILTER, INS_CRUSH,
        INS_PHASR, INS_FLANG, INS_CHOR, INS_DLY, INS_REV, INS_SLCR};
    const uint8_t positioned[FX_LIST_N] = {INS_DLY, INS_TAPE, INS_DIST, INS_FILTER,
        INS_CRUSH, INS_PHASR, INS_FLANG, INS_CHOR, INS_REV, INS_SLCR};
    for (uint32_t c = 0; c < 2; c++) {
        uint8_t got[FX_LIST_N];
        static project_t saved;
        uint8_t args[] = {0, P_IORD, 0, 64};             /* ORDER 0 */
        reset();
        fx_list_set(&trk[0], initial);
        ins_send_set(&trk[0], INS_FLANG, 1);
        fx_list_get(&trk[0], got);                       /* initialize before the editor writes */
        request(commands[c], args, sizeof args);
        project_capture(&saved);
        bad += check("saving immediately after ORDER stores the edited chain",
            !memcmp(saved.t[0].fx_order, ordered, sizeof got));
        fx_list_get(&trk[0], got);
        bad += check(c ? "TRACK_PARAM ORDER reaches chain and preserves TAPE/send" :
                         "SET ORDER reaches chain and preserves TAPE/send",
            !memcmp(got, ordered, sizeof got) && ins_is_send(&trk[0], INS_FLANG));
        args[1] = P_CHOR; args[2] = 120;                /* FXPOS: DLY 0, REV 7 */
        request(commands[c], args, sizeof args);
        fx_list_get(&trk[0], got);
        bad += check(c ? "TRACK_PARAM FXPOS reaches chain and preserves TAPE" :
                         "SET FXPOS reaches chain and preserves TAPE",
            !memcmp(got, positioned, sizeof got));
        apply_preset_to(&trk[0], 0);
        fx_list_get(&trk[0], got);
        bad += check("preset restores legacy chain order and preserves TAPE slot",
            !memcmp(got, initial, sizeof got));
    }
    {
        static project_t saved;
        uint8_t got[FX_LIST_N];
        reset();
        project_capture(&saved);
        memcpy(saved.t[0].fx_order, initial, sizeof initial);
        saved.t[0].p[P_IORD] = 0;                      /* older saves can have stale legacy fields */
        saved.t[0].p[P_CHOR] = 64;
        saved.t[0].fx_sl_pos = 8;
        saved.sum = proj_sum(&saved);
        int restored = !project_restore_runtime(&saved);
        fx_list_get(&trk[0], got);
        bad += check("loading keeps the saved ten-stage chain despite stale legacy fields",
            restored && !memcmp(got, initial, sizeof got));
    }
    {
        static project_t saved, loaded;
        static project_store_t wire;
        reset();
        fx_list_set(&trk[0], initial);
        fx_list_set(&trk[1], positioned);
        fx_master_set(INS_DIST, 0);
        fx_master_set(INS_DLY, 1);
        project_capture(&saved);
        int restored = proj_pack(&wire, &saved) && proj_import(&loaded, &wire, sizeof wire) &&
            !project_restore_runtime(&loaded);
        bad += check("saving and loading preserves the selected MASTER ordering track",
            restored && fx_master_order_tr == 1);
    }
    return bad;
}
static uint32_t pack7(const uint8_t *p, uint32_t n, uint8_t *a)
{
    uint32_t o = 0, i;
    while (n) {
        uint32_t k = n > 7u ? 7u : n, m = o++;
        a[m] = 0;
        for (i = 0; i < k; i++, n--) { a[m] |= (*p >> 7) << i; a[o++] = *p++ & 127u; }
    }
    return o;
}

/* 1.1 parameter locks over MOTION (64): ops 5 (set a lock), 6 (clear a step's locks, 127 every step's), 7 (the query
 * with the kinds); the query and ops 1..4 reply as before (a lock's id without bit 7) */
static int motion_locks(void)
{
    int bad = 0;
    uint32_t n;
    uint8_t a[8];
    reset();
    motion_clear(&trk[1]);
    a[0] = 1; a[1] = 3; a[2] = 2; a[3] = P_REV; a[4] = (uint8_t)((60 + 8192) & 127); a[5] = (uint8_t)((60 + 8192) >> 7);
    request(ED_MOTION, a, 6);                                           /* an automation event, step 2 */
    a[1] = 5; a[2] = 5; a[4] = (uint8_t)((100 + 8192) & 127); a[5] = (uint8_t)((100 + 8192) >> 7);
    n = request(ED_MOTION, a, 6);                                       /* a lock, step 5 */
    bad += check("MOTION op 5 sets a lock: rc 0, two records, then their kinds 0 1",
        host_wire[6] == 0 && host_wire[8] == 2 && host_wire[10] == 2 && host_wire[11] == P_REV &&
        host_wire[14] == 5 && host_wire[15] == P_REV && n == 5u + 5u + 2u * 4u + 2u + 1u &&
        host_wire[18] == 0 && host_wire[19] == 1 && motion_lock_count(&trk[1]) == 1u);
    n = request(ED_MOTION, a, 1);
    bad += check("MOTION query as before 1.1: no kinds, the lock's id without bit 7", n == 5u + 5u + 2u * 4u + 1u &&
        host_wire[15] == P_REV);
    a[1] = 7; n = request(ED_MOTION, a, 2);
    bad += check("MOTION op 7: the query with the kinds", n == 5u + 5u + 2u * 4u + 2u + 1u && host_wire[19] == 1);
    a[1] = 5; a[2] = 64; n = request(ED_MOTION, a, 6);
    bad += check("MOTION op 5 refuses step 64 (rc 1)", host_wire[6] == 1);
    a[1] = 6; a[2] = 2; request(ED_MOTION, a, 3);
    bad += check("MOTION op 6 on step 2: its automation event stays", host_wire[6] == 0 && host_wire[8] == 2);
    a[2] = 127; request(ED_MOTION, a, 3);
    bad += check("MOTION op 6, 127: every lock goes, the automation stays", host_wire[6] == 0 && host_wire[8] == 1 &&
        host_wire[14] == 0 && !motion_lock_count(&trk[1]));
    motion_clear(&trk[1]);
    /* 1.2 (INFO 41 01 00 01): 128 records; ops 1..7 reply as before (max 64, at most 64 records), op 8 all of them */
    {
        uint32_t i, ok = 1;
        for (i = 0; i < MOTION_MAX - 1u; i++)            /* 254 on track 2: four ids over the steps */
            ok &= !motion_set_event(&trk[1], i % NSTEP, i < NSTEP ? P_REV : i < 2u * NSTEP ? P_DLY :
                                    i < 3u * NSTEP ? P_LEVEL : P_DIST, (int16_t)(i % 100u));
        a[1] = 5; a[2] = 63; a[3] = P_PAN; a[4] = (uint8_t)((-3 + 8192) & 127); a[5] = (uint8_t)((-3 + 8192) >> 7);
        n = request(ED_MOTION, a, 6);                   /* the 255th: a lock of PAN -3 */
        ok &= host_wire[6] == 0 && motion.count == MOTION_MAX && host_wire[8] == 64 && host_wire[9] == 64 &&
              n == 5u + 5u + 64u * 4u + 64u + 1u;
        bad += check("MOTION: 255 records on one track; op 5's reply as before: max 64, its first 64 listed", ok);
        a[1] = 3; a[2] = 0; a[3] = P_CHOR; a[4] = 0; a[5] = 64;
        n = request(ED_MOTION, a, 6);
        bad += check("  the 256th: rc 2 (full)", host_wire[6] == 2 && motion.count == MOTION_MAX);
        a[1] = 8; n = request(ED_MOTION, a, 2);
        ok = n == 5u + 7u + (uint32_t)MOTION_MAX * 4u + MOTION_MAX + 1u && host_wire[8] == 127 && host_wire[9] == 1 &&
             host_wire[10] == 127 && host_wire[11] == 1 &&
             host_wire[12 + (MOTION_MAX - 1u) * 4u] == 63 && host_wire[13 + (MOTION_MAX - 1u) * 4u] == P_PAN &&
             ed_rv(&host_wire[14 + (MOTION_MAX - 1u) * 4u]) == -3 &&
             host_wire[12 + MOTION_MAX * 4u + MOTION_MAX - 1u] == 1 && host_wire[12 + MOTION_MAX * 4u] == 0 &&
             n <= sizeof ed_out;
        bad += check("  op 8: count and max as two 7-bit bytes (255), all 255 records, then their kinds", ok);
        a[1] = 8; a[2] = 0;
        bad += check("  op 8 with a further byte: no reply", !request(ED_MOTION, a, 3));
        motion_clear(&trk[1]);
    }
    return bad;
}

/* DUMP: P_IORD carries the chain order in bits 0..9 and the SEND flags above: the wire gives the order only,
 * as TRACK_DUMP / GET / SET / CHANGED do (core.h iord_perm_of) */
static int dump_order(void)
{
    int bad = 0;
    int16_t saved;
    reset();
    saved = TSEL->p[P_IORD];
    TSEL->p[P_IORD] = (int16_t)(24 | (1 << 10));      /* DIST as SEND, chain order 24 */
    uint32_t n = request(ED_DUMP, 0, 0);
    bad += check("DUMP: P_IORD gives the 0..719 order, the SEND bits stay on the device",
        n == 5u + 2u + 2u * (uint32_t)(P_COUNT + G_COUNT) + 1u && host_wire[4] == ED_DUMP &&
        ed_rv(&host_wire[7u + 2u * P_IORD]) == 24 && (TSEL->p[P_IORD] & (1 << 10)) != 0);
    TSEL->p[P_IORD] = saved;
    return bad;
}

/* G_SLOWN: 0 and 5..15 are the mask (0 = all SEND); 1..4 remain accepted legacy owner values */
static int slown_descriptor(void)
{
    int bad = 0, ok;
    uint8_t a[4] = {1, G_SLOWN, 0, 0};
    reset();
    (void)request(ED_DESC, a, 2);
    ok = host_wire[4] == ED_DESC && host_wire[5] == 1 && host_wire[6] == G_SLOWN && host_wire[7] == F_INT &&
         !strncmp((const char *)&host_wire[14], "SLOWN", 6) &&
         ed_rv(&host_wire[8]) == 0 && ed_rv(&host_wire[10]) == 15 && ed_rv(&host_wire[12]) == 0;
    a[2] = (uint8_t)((15 + 8192) & 127); a[3] = (uint8_t)((15 + 8192) >> 7);
    (void)request(ED_SET, a, 4);
    ok &= ed_rv(&host_wire[7]) == 15 && song.g[G_SLOWN] == 15;
    (void)request(ED_GET, a, 2);
    ok &= ed_rv(&host_wire[7]) == 15;
    a[2] = (uint8_t)((3 + 8192) & 127); a[3] = (uint8_t)((3 + 8192) >> 7);
    (void)request(ED_SET, a, 4);
    ok &= ed_rv(&host_wire[7]) == 3 && song.g[G_SLOWN] == 3;
    (void)request(ED_GET, a, 2);
    ok &= ed_rv(&host_wire[7]) == 3;
    bad += check("G_SLOWN: DESC max 15; SET/GET 15; SET/GET 3 keeps the legacy owner value", ok);
    song.g[G_SLOWN] = GP[G_SLOWN].def;
    return bad;
}

/* PITCH (MSEQ_PITCH) is lock-only: a normal track (ANALOG here) takes -24..24 over MOTION op 5, op 6 clears it,
 * op 7 lists it with kind 1; it does not depend on the kit change (DRUM tracks ignore PITCH) */
static int pitch_locks(void)
{
    int bad = 0, ok = 1;
    static const int32_t values[] = {24, -24, 25, -25};
    uint8_t a[6] = {1, 5, 3, MSEQ_PITCH, 0, 0};
    uint32_t n;
    reset();
    motion_clear(&trk[1]);
    for (uint32_t i = 0; i < 4u; i++) {
        uint32_t u = (uint32_t)(values[i] + 8192);
        a[4] = (uint8_t)(u & 127u); a[5] = (uint8_t)(u >> 7);
        n = request(ED_MOTION, a, 6);
        ok &= n > 6u && host_wire[4] == ED_MOTION && host_wire[5] == 1 && host_wire[6] == (i < 2u ? 0u : 1u);
    }
    bad += check("PITCH (MSEQ_PITCH) locks -24..24: 24 and -24 accepted, 25 and -25 rc 1", ok);
    a[1] = 6; a[2] = 3;
    (void)request(ED_MOTION, a, 3);
    bad += check("MOTION op 6 clears a PITCH lock", host_wire[6] == 0 && !motion_lock_count(&trk[1]));
    a[1] = 5; a[2] = 4;
    a[4] = (uint8_t)((24 + 8192) & 127); a[5] = (uint8_t)((24 + 8192) >> 7);
    (void)request(ED_MOTION, a, 6);
    a[1] = 7;
    n = request(ED_MOTION, a, 2);
    bad += check("MOTION op 7 lists a PITCH lock with kind 1",
        n == 5u + 5u + 4u + 1u + 1u && host_wire[5] == 1 && host_wire[6] == 0 && host_wire[8] == 1 &&
        host_wire[10] == 4 && host_wire[11] == MSEQ_PITCH && ed_rv(&host_wire[12]) == 24 && host_wire[14] == 1);
    motion_clear(&trk[1]);
    return bad;
}

/* BEND (MFX_BEND) is automation only: MOTION op 3 takes -32..32 (1/16 semitones), op 5 (a lock) rc 1, op 4
 * deletes it, op 8 lists it with kind 0 */
static int bend_automation(void)
{
    int bad = 0, ok = 1;
    static const int32_t values[] = {32, -32, 33, -33};
    uint8_t a[6] = {1, 3, 4, MFX_BEND, 0, 0};
    uint32_t i, n;
    reset();
    motion_clear(&trk[1]);
    for (i = 0; i < 4u; i++) {
        uint32_t u = (uint32_t)(values[i] + 8192);
        a[4] = (uint8_t)(u & 127u); a[5] = (uint8_t)(u >> 7);
        n = request(ED_MOTION, a, 6);
        ok &= n > 6u && host_wire[4] == ED_MOTION && host_wire[5] == 1 && host_wire[6] == (i < 2u ? 0u : 1u);
    }
    bad += check("BEND (MFX_BEND) automation -32..32: 32 and -32 accepted, 33 and -33 rc 1", ok);
    a[1] = 5;
    a[4] = (uint8_t)((1 + 8192) & 127); a[5] = (uint8_t)((1 + 8192) >> 7);
    (void)request(ED_MOTION, a, 6);
    bad += check("MOTION op 5 refuses a BEND lock", host_wire[6] == 1 && motion.count == 1);
    a[1] = 8;
    n = request(ED_MOTION, a, 2);
    bad += check("MOTION op 8 lists the BEND record with kind 0",
        n == 5u + 7u + 4u + 1u + 1u && host_wire[8] == 1 && host_wire[9] == 0 &&
        host_wire[10] == (MOTION_MAX & 127) && host_wire[11] == (MOTION_MAX >> 7) &&
        host_wire[12] == 4 && host_wire[13] == MFX_BEND &&
        ed_rv(&host_wire[14]) == -32 && host_wire[16] == 0);
    a[1] = 4;
    (void)request(ED_MOTION, a, 4);
    bad += check("MOTION op 4 deletes the BEND record", host_wire[6] == 0 && !motion.count);
    motion_clear(&trk[1]);
    return bad;
}

static int preferences(void)
{
    int bad = 0;
    uint8_t a[4] = {0, 7, 0, 0};
    reset();
    uint32_t n = request(ED_INFO, a, 0);
    bad += check("INFO explicitly tags display capabilities after SONG without changing command 33",
        ED_SONG == 33 && ED_UI_STATE == 34 && ED_FAV_SET == 38 &&
        host_wire[n - 51] == CHAIN_ROWS && host_wire[n - 50] == 0x55 &&
        host_wire[n - 49] == 1 && host_wire[n - 48] == 9 &&
        host_wire[n - 47] == 0x4d && host_wire[n - 46] == 1 &&
        host_wire[n - 45] == 64u && host_wire[n - 44] == 1 &&   /* (64 kept: 41 01 says 128) */
        host_wire[n - 43] == 0x42 && host_wire[n - 42] == 1 && host_wire[n - 41] == 3 &&
        host_wire[n - 40] == 0x46 && host_wire[n - 39] == 1 && host_wire[n - 38] == FM6_NFACTORY &&
        host_wire[n - 37] == 0 &&                        /* (no bank since 1.0.3) */
        host_wire[n - 36] == 0x53 && host_wire[n - 35] == 1 && host_wire[n - 34] == 3 &&
        host_wire[n - 33] == 0x50 && host_wire[n - 32] == 1 && host_wire[n - 31] == 3 &&   /* FM6 v2: no bank, preset patches */
        host_wire[n - 30] == 0x4E && host_wire[n - 29] == 1 && host_wire[n - 28] == 25 &&   /* MENU settings: 25 items */
        host_wire[n - 27] == 0x52 && host_wire[n - 26] == 1 && host_wire[n - 25] == 4 &&   /* RATCH */
        host_wire[n - 24] == 0x4C && host_wire[n - 23] == 1 && host_wire[n - 22] == 1 &&   /* 1.1 parameter locks */
        host_wire[n - 21] == 0x41 && host_wire[n - 20] == 1 && host_wire[n - 19] == 127 && host_wire[n - 18] == 1 &&   /* 255 */
        host_wire[n - 17] == 0x54 && host_wire[n - 16] == 1 && host_wire[n - 15] == NUDGE_DIV &&   /* 1.2: NUDGE */
        host_wire[n - 14] == 0x57 && host_wire[n - 13] == 1 && host_wire[n - 12] == NTRK &&   /* 1.2: SONG lanes */
        host_wire[n - 11] == 0x56 && host_wire[n - 10] == 1 && host_wire[n - 9] == 0 &&
        host_wire[n - 8] == 1 &&   /* 128 voices: two 7-bit bytes 00 01 */
        host_wire[n - 7] == 0x58 && host_wire[n - 6] == 1 && host_wire[n - 5] == NMSLOT &&   /* 4.2: MATRIX */
        host_wire[n - 4] == 0x59 && host_wire[n - 3] == 1 && host_wire[n - 2] == 1);   /* BEND: motion id 61 */
    request(ED_UI_SET, a, 2);
    bad += check("UI_SET updates the actual palette and reports RAM-only saving",
        host_wire[5] == 3 && settings.palette == 7 && T_BG == UI_PALETTES[7].bg);
    a[1] = NPALETTES; request(ED_UI_SET, a, 2);
    bad += check("out-of-range palette leaves the display unchanged", host_wire[5] == 1 && settings.palette == 7);
    a[0] = 1; a[1] = 1; request(ED_UI_SET, a, 2);
    bad += check("the retired font weight is not supported (rc 2), UI_STATE says 127",
        host_wire[5] == 2 && host_wire[8] == 9 && host_wire[10] == 127);
    a[0] = 2; request(ED_UI_SET, a, 2);
    bad += check("unsupported preference is reported without applying it", host_wire[5] == 2);
    a[0] = ENGI_DRUM; a[1] = 0; a[2] = 64; a[3] = 1;
    request(ED_FAV_SET, a, 4);
    bad += check("FAV_SET marks DRUM as a normal engine", host_wire[5] == 3 && favorite_has(ENGI_DRUM, 0));
    request(ED_FAV_GET, a, 4);
    bad += check("FAV_GET reads the bounded favorite range", host_wire[5] == 0 && host_wire[10] == 1);
    a[0] = NENGINES; a[1] = 31; request(ED_FAV_SET, a, 4);
    bad += check("empty user slot cannot be starred", host_wire[5] == 1 && !favorite_has(NENGINES, 31));
    up_store(31, "Saved"); request(ED_FAV_SET, a, 4);
    bad += check("saved user slot can be starred without changing its sound", host_wire[5] == 3 && favorite_has(NENGINES, 31));
    a[1] = (uint8_t)(UP_SLOTS - 1u); a[2] = 0; a[3] = 2; request(ED_FAV_GET, a, 4);
    bad += check("favorite range cannot cross the end of user slots", host_wire[5] == 1);
    request(ED_FAV_SET, a, 3);
    bad += check("short favorite writes return an error without reading absent bytes", host_wire[5] == 1);
    bad += check("UI_STATE rejects unexpected request bytes", request(ED_UI_STATE, a, 1) == 0);
    a[0] = 0; request(ED_SONG, a, 1);
    bad += check("SONG still responds through its original command", host_wire_n > 6 && host_wire[4] == 33 && host_wire[5] == 0);
    return bad;
}

static int framing(void)
{
    uint32_t i, bad = 0;
    static const uint8_t rt[] = {0xF0, 0x7D, 0xF8, 0x46, 0xFE, 0x4C, ED_PING, 0xFF, 0xF7};
    static const uint8_t aborted[] = {0xF0, 0x7D, 0x46, 0x4C, ED_SET, 0, P_LEVEL, 0x90, 0, 64, 0xF7};
    reset();
    for (i = 0; i < sizeof rt; i++) sysex_byte(rt[i]);
    ed_service(); host_drain();
    bad += check("realtime bytes interleaved in SysEx do not enter the editor frame",
                 host_wire_n == 7u && host_wire[4] == ED_PING && host_wire[5] == 0);
    ota_frame_done(); host_wire_n = 0;
    for (i = 0; i < sizeof aborted; i++) sysex_byte(aborted[i]);
    ed_service(); host_drain();
    bad += check("a non-realtime status aborts SysEx without changing parameters",
                 !sx_ready && !host_wire_n && TSEL->p[P_LEVEL] == TP[P_LEVEL].def);
    bad += check("a valid request works after an aborted frame", request(ED_PING, 0, 0) == 7u);
    ota_frame_done();
    midi_in_event(0x467DF004u);                          /* F0 7D 46 */
    midi_in_event(0x00004C04u);                          /* unfinished SysEx */
    midi_in_event(0x643C9009u);
    sysex_byte(0xF7);
    bad += check("a channel event in another USB packet aborts an unfinished SysEx",
                 !sx_ready && mi_w == 1u && midi_in_q[0] == 0x643C9009u);
    midi_in_event(0x643C8009u);                          /* wrong CIN */
    midi_in_event(0x643CFF09u);                          /* wrong status */
    midi_in_event(0xFF3C9009u);                          /* not a seven-bit velocity */
    midi_in_event(0x64FF9009u);                          /* not a seven-bit note */
    bad += check("USB channel packets reject mismatched CIN and high data bits", mi_w == 1u);
    midi_in_event(0xFF05C00Cu);                          /* one-byte status: padding is ignored */
    midi_in_event(0xFF07D00Du);
    bad += check("USB program and channel pressure keep their one-byte payload", mi_w == 3u);
    mi_w = UINT32_MAX - 5u; mi_r = mi_w;
    for (i = 0; i < MQ + 8u; i++) midi_in_event(0x643C9009u);
    bad += check("USB MIDI ring stops at capacity across counter wrap", mi_w - mi_r == MQ && midi_in_overflow);
    mi_r = mi_w; midi_in_event(0x643C9009u);
    bad += check("USB rejects new messages until the audio consumer clears overflow", mi_w == mi_r);
    midi_in_overflow = 0; midi_in_event(0x643C9009u);
    bad += check("USB resumes after the audio consumer clears overflow", mi_w - mi_r == 1u);
    return bad;
}

/* main.c polls ota_service() only when ed_service() reports a held non-editor frame: an
 * editor request arriving after the empty check then waits for the next pass instead of
 * being consumed (and dropped) by the OTA decode. */
static int dispatch(void)
{
    static const uint8_t ota[] = {0xF0, 0x00, 0x59, 0x11, 0x00, 0xF7};
    static const uint8_t info[] = {0xF0, ED_HDR0, ED_HDR1, ED_HDR2, ED_INFO, 0xF7};
    uint32_t i;
    int bad = 0;
    reset();
    host_wire_n = 0;
    bad += check("dispatch: no frame leaves nothing for OTA", !ed_service() && !sx_ready && !host_wire_n);
    for (i = 0; i < sizeof ota; i++) sysex_byte(ota[i]);
    bad += check("dispatch: a non-editor frame is held for OTA, not answered",
                 ed_service() == 1 && sx_ready && !host_wire_n);
    bad += check("dispatch: .. and stays held on the next pass", ed_service() == 1 && sx_ready);
    ota_frame_done();
    for (i = 0; i < sizeof info; i++) sysex_byte(info[i]);
    bad += check("dispatch: an editor request frees its own frame",
                 ed_service() == 0 && !sx_ready);
    host_wire_n = 0;
    host_drain();
    bad += check("dispatch: .. and is answered, nothing held for OTA", host_wire_n > 7u && host_wire[4] == ED_INFO);
    host_wire_n = 0;
    bad += check("dispatch: an empty pass reports nothing for OTA", ed_service() == 0);
    for (i = 0; i < sizeof info; i++) sysex_byte(info[i]);
    bad += check("dispatch: a request arriving after the empty pass is handled next",
                 ed_service() == 0 && !sx_ready);
    host_drain();
    bad += check("dispatch: .. and answered", host_wire_n > 7u && host_wire[4] == ED_INFO);
    return bad;
}

static int uart_recovery(void)
{
    uint32_t i;
    int bad = 0;
    reset();
    um_byte(0x90); um_byte(50);
    for (i = 0; i < UM_RING; i++) um_ring[i] = 0;
    um_ring[126] = 0x90; um_ring[127] = 72; um_ring[0] = 99;
    uart_midi_take(UM_RING + 1u);
    bad += check("UART DMA overrun never combines a stale partial note with new data",
                 !mi_w && midi_in_overflow && um.drops == 2u && um.bytes == UM_RING && !um.pend);
    midi_in_overflow = 0; um_byte(0x90); um_byte(72); um_byte(99);
    bad += check("UART receives a complete fresh note after DMA recovery",
                 mi_w == 1u && midi_in_q[0] == 0x63489009u);
    reset();
    um_byte(0x90); um_byte(50);
    for (i = 0; i < UM_RING; i++) um_ring[i] = 60;
    uart_midi_take(UM_RING + 2u);
    bad += check("UART discards running-status data after lost bytes until a new status",
                 !mi_w && midi_in_overflow && um.drops == 2u && !um.st && !um.got);
    midi_in_overflow = 0;
    um_byte(0x91); um_byte(70); um_byte(100);
    bad += check("UART recovers immediately on a complete channel message", mi_w == 1u && midi_in_q[0] == 0x64469109u);
    reset(); mi_w = MQ;
    um_byte(0x90); um_byte(60); um_byte(100);
    bad += check("UART queue overflow latches the same recovery flag as USB", midi_in_overflow && um.drops == 1u && mi_w == MQ);
    mi_r = mi_w; um_byte(61); um_byte(101);
    bad += check("UART rejects a new stream until audio clears overflow", mi_w == mi_r && um.drops == 2u);
    midi_in_overflow = 0; um_byte(62); um_byte(102);
    bad += check("UART resumes valid running status after audio clears overflow",
                 mi_w - mi_r == 1u && midi_in_q[mi_r % MQ] == 0x663E9009u);
    return bad;
}

static int steps(void)
{
    uint8_t a[80] = {0, 1, 60, 0, 0, 0, ST_NOTE, SF_ACCENT, 100, 0x12, 0x02, 1};
    step_t before;
    uint32_t n, ok = 1;
    int bad = 0;
    reset();
    TSEL->step[0].hit = TSEL->step[0].acc = 0x80;
    bad += check("legacy 8-byte step writes preserve lane data",
                 request(ED_STEP_SET, a, 9) == 21u && step_note(&TSEL->step[0], 0) == 60 &&
                 TSEL->step[0].hit == 0x80 && TSEL->step[0].acc == 0x80);
    bad += check("full grid step writes preserve high lane bits and constrain accents",
                 request(ED_STEP_SET, a, 12) == 21u && TSEL->step[0].hit == 0x92 && TSEL->step[0].acc == 2);
    before = TSEL->step[0]; a[2] = 71;
    for (n = 2; n <= sizeof a; n++) {
        if (n == 9u || n == 12u || n == 13u) continue;   /* (14: a[13], the ratchet, 0 is refused) */
        ok &= !request(ED_STEP_SET, a, n) && !memcmp(&before, &TSEL->step[0], sizeof before);
    }
    bad += check("partial or oversized step payloads never mutate a valid step", ok);
    a[0] = 1; a[1] = 0; memcpy(a + 2, (const uint8_t[]){1,64,0,0,0,ST_NOTE,0,99}, 8);
    bad += check("TRACK_STEP accepts its legacy payload on an unselected track",
                 request(ED_TRACK_STEP, a, 10) == 22u && step_note(&trk[1].step[0], 0) == 64 && song.sel == 0);
    before = trk[1].step[0]; a[3] = 65;
    bad += check("TRACK_STEP rejects an incomplete grid extension",
                 !request(ED_TRACK_STEP, a, 11) && !memcmp(&before, &trk[1].step[0], sizeof before));
    /* RATCH (INFO 52 01 04): the hits 1..4 after the chance; the flags byte stays accent | slide both ways */
    memcpy(a, (const uint8_t[]){0, 1, 60, 0, 0, 0, ST_NOTE, SF_ACCENT, 100, 0, 0, 0, 80, 3}, 14);
    n = request(ED_STEP_SET, a, 14);
    bad += check("STEP_SET with the ratchet: x3 kept, replied after the chance, flags without it",
                 n == 21u && step_ratchet(&TSEL->step[0]) == 3u && step_chance(&TSEL->step[0]) == 80u &&
                 host_wire[n - 3] == 3 && host_wire[n - 4] == 80 && host_wire[n - 2] == 8 && host_wire[12] == SF_ACCENT);
    a[7] = SF_SLIDE; n = request(ED_STEP_SET, a, 13);
    ok = n == 21u && step_ratchet(&TSEL->step[0]) == 3u && step_fl(&TSEL->step[0]) == SF_SLIDE &&
         step_nudge(&TSEL->step[0]) == 0;
    n = request(ED_STEP_SET, a, 9);
    bad += check("STEP_SET without the ratchet (an older editor) keeps the step's own",
                 ok && n == 21u && step_ratchet(&TSEL->step[0]) == 3u);
    before = TSEL->step[0]; ok = 1;
    for (n = 0; n < 8u; n++) {
        a[13] = (uint8_t)(n < 4u ? 0u : 5u + n);
        ok &= !request(ED_STEP_SET, a, 14) && !memcmp(&before, &TSEL->step[0], sizeof before);
    }
    bad += check("STEP_SET refuses a ratchet outside 1..4 and leaves the step", ok);
    memcpy(a, (const uint8_t[]){1, 2, 1, 64, 0, 0, 0, ST_NOTE, 0, 99, 0, 0, 0, 100, 4}, 15);
    n = request(ED_TRACK_STEP, a, 15);
    ok = n == 22u && step_ratchet(&trk[1].step[2]) == 4u && host_wire[n - 3] == 4;
    a[14] = 1; n = request(ED_TRACK_STEP, a, 15);
    bad += check("TRACK_STEP sets the ratchet of any track (x4, then back to x1)",
                 ok && n == 22u && step_ratchet(&trk[1].step[2]) == 1u);
    /* NUDGE (1.2, INFO 54 01 16): the nudge + 8 after the ratchet, both ways; a write without it keeps the step's */
    memcpy(a, (const uint8_t[]){0, 1, 60, 0, 0, 0, ST_NOTE, SF_ACCENT, 100, 0, 0, 0, 80, 1, 8 - 5}, 15);
    n = request(ED_STEP_SET, a, 15);
    ok = n == 21u && step_nudge(&TSEL->step[0]) == -5 && host_wire[n - 2] == 3 && host_wire[12] == SF_ACCENT &&
         step_fl(&TSEL->step[0]) == SF_ACCENT;
    a[7] = SF_SLIDE; n = request(ED_STEP_SET, a, 14);
    ok &= n == 21u && step_nudge(&TSEL->step[0]) == -5 && host_wire[12] == SF_SLIDE;
    n = request(ED_STEP_SET, a, 9);
    ok &= step_nudge(&TSEL->step[0]) == -5;
    bad += check("STEP_SET with the nudge (-5): kept, replied + 8 after the ratchet; a write without it keeps it", ok);
    before = TSEL->step[0];
    a[14] = 16;
    bad += check("STEP_SET refuses a nudge byte above 15 and leaves the step",
                 !request(ED_STEP_SET, a, 15) && !memcmp(&before, &TSEL->step[0], sizeof before));
    memcpy(a, (const uint8_t[]){2, 7, 1, 64, 0, 0, 0, ST_NOTE, 0, 99, 0, 0, 0, 100, 1, 15}, 16);
    n = request(ED_TRACK_STEP, a, 16);
    bad += check("TRACK_STEP sets the nudge of any track (+7)", n == 22u && step_nudge(&trk[2].step[7]) == 7 &&
                 host_wire[n - 2] == 15);
    return bad;
}

static int samples(void)
{
    uint8_t a[640] = {0}, data[257], short_group[] = {0, 0, 4, 0, 1};
    uint32_t n, i;
    int bad = 0;
    smp_user_hdr_t h;
    reset(); memset(host_samples, 0, sizeof host_samples);
    for (i = 0; i < sizeof data; i++) data[i] = (uint8_t)(i * 37u);
    song.playing = 1; host_progress = 0;
    bad += check("sample erase waits for STOP and refuses a stalled audio ISR",
                 request(ED_SMP_BEGIN, a, 1) == 8u && host_wire[6] != 0 && !host_erases && song.playing);
    host_progress = 1;
    bad += check("sample erase stops transport before touching flash",
                 request(ED_SMP_BEGIN, a, 1) == 8u && !host_wire[6] && host_erases == 1 && !song.playing);
    a[0] = 0; a[1] = 0; a[2] = 4; a[3] = 0;
    n = pack7(data, 257, a + 4) + 4u;
    bad += check("257 decoded sample bytes are rejected without a truncated write",
                 request(ED_SMP_WRITE, a, n) == 11u && host_wire[9] == 1 && !host_writes);
    bad += check("a dangling packed-data mask is rejected",
                 request(ED_SMP_WRITE, short_group, sizeof short_group) == 11u && host_wire[9] == 1 && !host_writes);
    n = pack7(data, 256, a + 4) + 4u;
    transport_req = 1;
    bad += check("sample writes cancel a pending PLAY before flash access",
                 request(ED_SMP_WRITE, a, n) == 11u && !host_wire[9] && transport_req != 1u && host_writes == 1);
    memset(&h, 0, sizeof h); h.magic = SMP_USER_MAGIC; h.version = 1; h.nz = 1;
    h.data_len = 256; h.crc = st_crc32(data, 256); h.zone[0].n = 512; h.zone[0].le = 511;
    h.zone[0].rate = 65536; h.zone[0].hi = 127;
    a[0] = 0; n = pack7((const uint8_t *)&h, sizeof h, a + 1) + 1u;
    a[n] = 0; a[n + 1u] = 0;
    bad += check("an oversized sample header is rejected without programming flash",
                 request(ED_SMP_END, a, n + 2u) == 8u && host_wire[6] == 1 && host_writes == 1);
    bad += check("complete sample header and CRC publish a valid slot",
                 request(ED_SMP_END, a, n) == 8u && !host_wire[6] && usr_nz[0] == 1 && host_writes == 2);
    bad += check("repeated END of the same published header does not rewrite live zones",
                 request(ED_SMP_END, a, n) == 8u && !host_wire[6] && host_writes == 2);
    h.zone[0].rate = 131072;
    n = pack7((const uint8_t *)&h, sizeof h, a + 1) + 1u;
    bad += check("END cannot change published sample zones without BEGIN",
                 request(ED_SMP_END, a, n) == 8u && host_wire[6] == 2 && host_writes == 2 &&
                 usr_nz[0] != 0);
    song.playing = 1; host_progress = 0; a[0] = 0; a[1] = 0;
    bad += check("user-preset STORE does not mutate RAM when audio cannot stop",
                 request(ED_UP_STORE, a, 2) == 8u && host_wire[6] == 2 && !up_used(0));
    bad += check("user-preset ERASE reports failure when audio cannot stop",
                 request(ED_UP_ERASE, a, 1) == 8u && host_wire[6] == 2);
    return bad;
}

/* a wavetable upload shares the sample protocol and slot: FWT1 header, PCM data, CRC, header last */
static int wavetable_slot(void)
{
    enum { WD = 8160 };                                 /* 2 frames x 1024 (+ mips) */
    uint8_t a[640], hdr[480], data[WD];
    smp_wt_hdr_t w;
    uint32_t i, n, off, len;
    int bad = 0, ok;
    reset();
    memset(host_samples, 0, sizeof host_samples);
    for (i = 0; i < 3u; i++)
        smp_user_scan(i);
    memset(&w, 0, sizeof w);
    w.magic = SMP_WT_MAGIC; w.version = SMP_WT_VERSION; w.frames = 2u;
    w.base_log2 = SMP_WT_BASE_LOG2; w.mip_last_log2 = SMP_WT_MIP_LAST_LOG2;
    memcpy(w.name, "WTEST", 5);
    w.data_len = w.frames * smp_wt_stride(&w) * 2u;
    for (i = 0; i < w.data_len; i++) data[i] = (uint8_t)(i * 13u + 7u);
    w.crc = st_crc32(data, w.data_len);
    a[0] = 1u;
    bad += check("wavetable: BEGIN erases the slot", request(ED_SMP_BEGIN, a, 1) == 8u && !host_wire[6]);
    for (off = 0; off < w.data_len; off += 256u) {
        len = w.data_len - off > 256u ? 256u : w.data_len - off;
        a[0] = 1u;                                                     /* slot 1: USR2 */
        a[1] = (uint8_t)((off + 512u) & 127u);
        a[2] = (uint8_t)(((off + 512u) >> 7) & 127u);
        a[3] = (uint8_t)(((off + 512u) >> 14) & 127u);
        n = pack7(data + off, len, a + 4) + 4u;
        if (request(ED_SMP_WRITE, a, n) != 11u) break;
        if (host_wire[9]) break;
    }
    bad += check("wavetable: PCM writes pass", off >= w.data_len);
    memset(hdr, 0, sizeof hdr);
    memcpy(hdr, &w, sizeof w);
    a[0] = 1u;
    n = pack7(hdr, sizeof hdr, a + 1) + 1u;
    bad += check("wavetable: END validates the data CRC and publishes FWT1",
                 request(ED_SMP_END, a, n) == 8u && !host_wire[6] &&
                 smp_wt_ok((const smp_wt_hdr_t *)host_samples[1]) && !usr_nz[1]);
    /* SMP_INFO: slot 1 is a wavetable (bit 5), named WTEST, 8 KiB; its low bits are not a zone count */
    request(ED_SMP_INFO, 0, 0);
    ok = host_wire[5] == 3u;
    i = 7;
    for (int k = 0; k < 3; k++) {
        uint8_t z = host_wire[i++];
        char nm[9] = {0};
        int j;
        for (j = 0; j < 8 && host_wire[i]; j++) nm[j] = (char)host_wire[i++];
        i++;                                                           /* the terminating 0 */
        if (k == 1u)
            ok &= z == SMP_USR_WT && !strcmp(nm, "WTEST") && host_wire[i] == 8u;
        else
            ok &= z == 0u && host_wire[i] == 0u;
        i++;
    }
    bad += check("wavetable: SMP_INFO reports bit 5, the name, 8 KiB (not sample zones)", ok);
    bad += check("wavetable: repeated identical END does not rewrite",
                 request(ED_SMP_END, a, n) == 8u && !host_wire[6]);
    hdr[12] = 'X';
    n = pack7(hdr, sizeof hdr, a + 1) + 1u;
    bad += check("wavetable: a published table needs BEGIN before a different header",
                 request(ED_SMP_END, a, n) == 8u && host_wire[6] == 2u && usr_nz[1] == 0);
    {   /* a write to a published wavetable is refused like a published sample */
        uint8_t one[8];
        one[0] = 1u; one[1] = 0u; one[2] = 4u; one[3] = 0u;
        n = pack7((const uint8_t *)"Z", 1, one + 4) + 4u;
        bad += check("wavetable: SMP_WRITE refuses a published slot (rc 4)",
                     request(ED_SMP_WRITE, one, n) == 11u && host_wire[9] == 4u);
    }
    {   /* an FSMP header cannot replace a wavetable without BEGIN */
        smp_user_hdr_t h;
        memset(&h, 0, sizeof h);
        h.magic = SMP_USER_MAGIC; h.version = 1; h.nz = 1;
        memset(hdr, 0, sizeof hdr);
        memcpy(hdr, &h, sizeof h);
        a[0] = 1u;
        n = pack7(hdr, sizeof hdr, a + 1) + 1u;
        bad += check("wavetable: a sample header cannot overwrite it without BEGIN",
                     request(ED_SMP_END, a, n) == 8u && host_wire[6] == 2u);
    }
    {   /* the geometry the format allows: 40 x 512 also fits one slot */
        smp_wt_hdr_t t;
        memset(&t, 0, sizeof t);
        t.magic = SMP_WT_MAGIC; t.version = SMP_WT_VERSION; t.frames = 40u;
        t.base_log2 = 9u; t.mip_last_log2 = 3u;
        t.data_len = t.frames * smp_wt_stride(&t) * 2u;
        bad += check("wavetable: a 40 x 512 header fits (81,280 B); a bad length or frame count does not",
                     smp_wt_ok(&t) && (t.data_len++, !smp_wt_ok(&t)) && (t.data_len--, t.frames = 65, !smp_wt_ok(&t)));
    }
    {   /* wrong CRC: BEGIN + data, then END refuses and nothing is published */
        w.data_len = 2u * smp_wt_stride(&w) * 2u;
        a[0] = 1u;
        request(ED_SMP_BEGIN, a, 1);
        for (off = 0; off < w.data_len; off += 256u) {
            len = w.data_len - off > 256u ? 256u : w.data_len - off;
            a[0] = 1u; a[1] = (uint8_t)((off + 512u) & 127u);
            a[2] = (uint8_t)(((off + 512u) >> 7) & 127u); a[3] = (uint8_t)(((off + 512u) >> 14) & 127u);
            n = pack7(data + off, len, a + 4) + 4u;
            request(ED_SMP_WRITE, a, n);
        }
        memset(hdr, 0, sizeof hdr);
        memcpy(hdr, &w, sizeof w);
        hdr[24] ^= 1u;                                                 /* crc */
        a[0] = 1u;
        n = pack7(hdr, sizeof hdr, a + 1) + 1u;
        bad += check("wavetable: a bad data CRC leaves the slot empty",
                     request(ED_SMP_END, a, n) == 8u && host_wire[6] == 3u &&
                     !smp_wt_ok((const smp_wt_hdr_t *)host_samples[1]));
    }
    return bad;
}

static int song_protocol(void)
{
    uint8_t a[] = {1, 1, 0, 2};
    chain_config_t before;
    int bad = 0;
    reset();
    bad += check("SONG sets and queries the complete chain without changing selection",
                 request(ED_SONG, a, sizeof a) == 14u && !host_wire[6] && chain_config.count == 1 && song.sel == 0);
    before = chain_config; a[3] = 0;
    bad += check("SONG invalid repeats leave the chain unchanged",
                 request(ED_SONG, a, sizeof a) == 14u && host_wire[6] == 1 && !memcmp(&before, &chain_config, sizeof before));
    a[3] = 2; chain.armed = 1;
    bad += check("SONG cannot replace a chain while its start is pending",
                 request(ED_SONG, a, sizeof a) == 14u && host_wire[6] == 2 && !memcmp(&before, &chain_config, sizeof before));
    chain.armed = 0; a[0] = 2;
    bad += check("SONG PLAY refuses extra argument bytes", !request(ED_SONG, a, 2) && !transport_req);
    {   /* 1.2 (`57 01 04`): sections with a slot per track, ops 4..7; the v6 ops see each section's clock lane */
        static const uint8_t set[] = {5, 2, 0, 1, CHAIN_SILENT, 0, 3, CHAIN_SILENT, CHAIN_SILENT, CHAIN_SILENT, CHAIN_SILENT, 1};
        static const uint8_t q4[] = {4}, q0[] = {0}, bad5[] = {5, 1, 0, 0, 5, 0, 1}, old4[] = {1, 1, CHAIN_SILENT, 1};
        static const uint8_t info[] = {0};
        uint32_t n, i, tag = 0;
        reset();
        n = request(ED_SONG, set, sizeof set);
        bad += check("SONG op 5 sets sections (T1 A, T2 B, T3 -, T4 A x3; all - x1), the reply in lanes",
                     n == 5u + 6u + 2u * 5u + 1u && host_wire[5] == 5 && !host_wire[6] && host_wire[7] == 2 &&
                     !memcmp(host_wire + 11, set + 2, 10) && chain_config.count == 2 &&
                     !memcmp(&chain_config.row[0], &(chain_row_t){{0, 1, CHAIN_SILENT, 0}, 3}, sizeof(chain_row_t)) &&
                     chain_config.row[1].slot[0] == CHAIN_SILENT && chain_config.row[1].repeat == 1);
        n = request(ED_SONG, q4, 1);
        bad += check("SONG op 4 queries them as set", n == 22u && host_wire[5] == 4 && !memcmp(host_wire + 11, set + 2, 10));
        n = request(ED_SONG, q0, 1);
        bad += check("SONG op 0 (v6 editors): a row per section, its clock lane's slot (T1 A; all - : A)",
                     n == 16u && host_wire[11] == 0 && host_wire[12] == 3 && host_wire[13] == 0 && host_wire[14] == 1);
        bad += check("SONG op 5: a slot past - (5) refused, the sections kept",
                     request(ED_SONG, bad5, sizeof bad5) == 22u && host_wire[6] == 1 && chain_config.count == 2);
        bad += check("SONG op 1 (v6): no - in a row of one slot", request(ED_SONG, old4, sizeof old4) == 16u &&
                     host_wire[6] == 1 && chain_config.count == 2);
        chain.armed = 1;
        bad += check("SONG op 5 waits for a pending start (rc 2)", request(ED_SONG, set, sizeof set) == 22u && host_wire[6] == 2);
        chain.armed = 0;
        n = request(ED_INFO, info, 0);
        for (i = 5; i + 2u < n; i++)
            if (host_wire[i] == 0x57 && host_wire[i + 1u] == 1 && host_wire[i + 2u] == NTRK) tag = 1;
        bad += check("INFO says the lanes: 57 01 04", tag);
        {
            uint8_t q[4] = {0, P_SQNT, 0, 0};
            trk[0].p[P_SQNT] = 1; chain.running = 1;
            request(ED_SET, q, 4);
            chain.running = 0;
            bad += check("SET of QUANTIZE waits while a song plays (its slots set it)", trk[0].p[P_SQNT] == 1);
        }
    }
    return bad;
}

static int malformed_saves(void)
{
    static const uint8_t slot[] = {1, 4}, name[] = {0, 'X', 0, 'Y'};
    const uint8_t save[] = {1, 0};
    project_store_t old;
    int bad = 0;
    reset();
    bad += check("PROJECT refuses an invalid slot instead of wrapping to slot 0",
                 !request(ED_PROJECT, slot, sizeof slot) && !project_used(0));
    bad += check("UP_STORE rejects bytes after its name terminator without saving",
                 request(ED_UP_STORE, name, sizeof name) == 8u && host_wire[6] == 1 && !up_used(0));
    bad += check("a successful PROJECT save confirms its slot", request(ED_PROJECT, save, sizeof save) == 9u && project_used(0));
    old = proj_slot[0];
    TSEL->p[P_LEVEL] = 21; song.playing = 1; host_progress = 0;
    bad += check("PROJECT never confirms an old used slot when STOP timed out",
                 !request(ED_PROJECT, save, sizeof save) && !memcmp(&old, &proj_slot[0], sizeof old));
    return bad;
}

/* FM6 patches (cmds 68..71): a track's own patch, the retired bank ("no bank"), the factory patches, the user presets'
 * patches (target 3), malformed frames */
static int fm6_patches(void)
{
    int bad = 0;
    uint8_t a[2 + FM6_PACKED], pk[FM6_PACKED];
    uint32_t n, i;
    reset();
    upf_empty();
    a[0] = ED_FM6_FACTORY; a[1] = 3;
    n = request(ED_FM6_GET, a, 2);
    bad += check("FM6_GET factory 4: the packed record", n == 5u + 3u + FM6_PACKED + 1u && host_wire[7] == 0 &&
                 !memcmp(host_wire + 8, FM6_FACTORY[3], FM6_PACKED));
    memcpy(pk, FM6_FACTORY[3], FM6_PACKED);
    memcpy(pk + 118, "MY PATCH  ", 10);
    trk[2].eng_req = ENGI_FM6;
    trk[2].p[P_E7] = 3;
    a[0] = ED_FM6_TRACK; a[1] = 2; memcpy(a + 2, pk, FM6_PACKED);
    n = request(ED_FM6_PUT, a, sizeof a);
    bad += check("FM6_PUT track 3: rc 0, the track's patch, SLOT OWN (not F4: the name differs)", n == 9u &&
                 host_wire[7] == 0 && !memcmp(fm6_patch[2] + FP_NAME, "MY PATCH  ", 10) &&
                 trk[2].p[P_E7] == FM6_OWN && fm6_slot[2] == FM6_OWN);
    fm6_poll();
    bad += check("  .. the main loop keeps it", !memcmp(fm6_patch[2] + FP_NAME, "MY PATCH  ", 10));
    a[1] = 2;
    n = request(ED_FM6_GET, a, 2);
    bad += check("FM6_GET track 3: as sent", host_wire[7] == 0 && !memcmp(host_wire + 8, pk, FM6_PACKED));
    a[0] = ED_FM6_TRACK; a[1] = 2; memcpy(a + 2, FM6_FACTORY[5], FM6_PACKED);
    request(ED_FM6_PUT, a, sizeof a);
    bad += check("FM6_PUT of a factory patch unchanged: SLOT shows it (F6)", trk[2].p[P_E7] == 5 && fm6_slot[2] == 5u);
    trk[2].p[P_E7] = FM6_OWN;                            /* (back to MY PATCH for the SLOT trip below) */
    a[0] = ED_FM6_TRACK; a[1] = 2; memcpy(a + 2, pk, FM6_PACKED);
    request(ED_FM6_PUT, a, sizeof a);
    trk[2].p[P_E7] = 1;
    fm6_poll();
    bad += check("SLOT OWN -> F2 loads the factory patch", !memcmp(fm6_patch[2] + FP_NAME, FM6_FACTORY[1] + 118, 10));
    trk[2].p[P_E7] = 6;
    fm6_poll();
    trk[2].p[P_E7] = FM6_OWN;
    fm6_poll();
    bad += check("  .. and back to OWN brings the own patch back", !memcmp(fm6_patch[2] + FP_NAME, "MY PATCH  ", 10) &&
                 fm6_slot[2] == FM6_OWN);
    trk[2].p[P_E7] = 20;                                 /* (a 1.0.2 B slot that escaped a clamp) */
    fm6_poll();
    bad += check("a SLOT past OWN is OWN: the patch stays, nothing reloads", trk[2].p[P_E7] == FM6_OWN &&
                 !memcmp(fm6_patch[2] + FP_NAME, "MY PATCH  ", 10));
    for (i = 0; i < 3u; i++) {                           /* the bank: GET, PUT, ERASE answer "no bank" (3) */
        a[0] = ED_FM6_BANK; a[1] = 4; memcpy(a + 2, pk, FM6_PACKED);
        if (i < 2u)
            request(i ? ED_FM6_PUT : ED_FM6_GET, a, i ? sizeof a : 2u);
        else {
            a[0] = 4;
            request(ED_FM6_ERASE, a, 1);
        }
        bad += check(i == 0u ? "FM6_GET of the bank: rc 3, no bank" : i == 1u ? "FM6_PUT to the bank: rc 3, no bank" :
                               "FM6_ERASE: rc 3, no bank", host_wire[i == 2u ? 6 : 7] == 3u);
    }
    n = request(ED_FM6_LIST, a, 0);
    {   /* factory 8, bank 0, then used + name per factory slot */
        uint32_t p = 7, k, ok = host_wire[5] == FM6_NFACTORY && host_wire[6] == 0;
        for (k = 0; k < FM6_NFACTORY && p < n; k++) {
            ok &= host_wire[p++] == 1u;
            while (host_wire[p]) p++;
            p++;
        }
        bad += check("FM6_LIST: FM6_NFACTORY factory names, nbank 0", ok && k == FM6_NFACTORY && p == n - 1u);
    }
    /* target 3: an FM6 user preset's patch */
    song.sel = 2;
    up_store(5, "MINE");                                 /* track 3 (MY PATCH, OWN) -> slot 6 */
    a[0] = ED_FM6_USER; a[1] = 5;
    request(ED_FM6_GET, a, 2);
    bad += check("UP_STORE of an FM6 track: FM6_GET user 6 gives its patch", host_wire[7] == 0 &&
                 !memcmp(host_wire + 8 + 118, "MY PATCH  ", 10));
    memcpy(a + 2, pk, FM6_PACKED);
    memcpy(a + 2 + 118, "EDITOR    ", 10);
    a[2 + 14] = 120;                                     /* OP6 output level 120: stored as 99 */
    request(ED_FM6_PUT, a, sizeof a);
    i = host_wire[7];
    request(ED_FM6_GET, a, 2);
    bad += check("FM6_PUT user 6, then GET: stored in range (a level of 120 -> 99)", i == 0u && host_wire[7] == 0 &&
                 host_wire[8 + 14] == 99 && !memcmp(host_wire + 8 + 118, "EDITOR    ", 10));
    fm6_load_slot(2, 0);
    up_load(5);
    bad += check("  .. UP_LOAD 6 plays it, SLOT OWN", !memcmp(fm6_patch[2] + FP_NAME, "EDITOR    ", 10) &&
                 trk[2].p[P_E7] == FM6_OWN);
    up_rename(5, "RENAMED");
    a[0] = ED_FM6_USER; a[1] = 5;
    request(ED_FM6_GET, a, 2);
    bad += check("  .. a rename keeps it", host_wire[7] == 0 && !memcmp(host_wire + 8 + 118, "EDITOR    ", 10));
    trk[0].eng_req = ENGI_DRUM;
    song.sel = 0;
    up_store(6, "KIT");
    a[0] = ED_FM6_USER; a[1] = 6; memcpy(a + 2, pk, FM6_PACKED);
    request(ED_FM6_GET, a, 2);
    i = host_wire[7];
    request(ED_FM6_PUT, a, sizeof a);
    bad += check("a DRUM user preset has no patch: GET rc 2, PUT rc 1", i == 2u && host_wire[7] == 1u);
    a[1] = 9;                                            /* an empty slot */
    request(ED_FM6_PUT, a, sizeof a);
    i = host_wire[7];
    a[1] = UP_SLOTS;
    request(ED_FM6_GET, a, 2);
    bad += check("an empty user slot: PUT rc 1; past the slots: GET rc 1", i == 1u && host_wire[7] == 1u);
    up_put(5, 0);
    a[1] = 5;
    request(ED_FM6_GET, a, 2);
    bad += check("an erased preset's patch is gone (GET rc 2)", host_wire[7] == 2u);
    a[0] = ED_FM6_TRACK; a[1] = 4;
    request(ED_FM6_PUT, a, sizeof a);
    i = host_wire[7];
    request(ED_FM6_PUT, a, 20);
    bad += check("FM6_PUT: a fifth track or a short record: rc 1", i == 1u && host_wire[7] == 1u);
    a[0] = 4; a[1] = 0;
    request(ED_FM6_GET, a, 2);
    bad += check("FM6_GET of an unknown target: rc 1", host_wire[7] == 1u);
    return bad;
}

/* UP_PUT -> UP_GET: every value round-trips through the v4 record (a byte each), negative ones too */
static int user_preset_roundtrip(void)
{
    static uint8_t a[16 + 2u * P_COUNT + 32u + 18u];
    int16_t want[P_COUNT], got[P_COUNT];
    uint32_t k = 0, i, p, ok, n;
    int bad = 0;
    reset();
    a[k++] = 3; a[k++] = 0;                                /* slot U04, ANALOG */
    memcpy(a + k, "ROUND", 5); k += 5; a[k++] = 0;
    for (i = 0; i < P_COUNT; i++) {
        const param_desc_t *d = param_desc_of(0, i);
        int16_t v = d->def;
        uint32_t u;
        if (i == P_LEVEL) v = 90;
        if (i == P_PAN) v = -20;
        if (i == P_ED_FLT) v = -40;
        if (i == P_LD_FLT) v = d->min;
        if (i == P_E1) v = d->max;
        want[i] = v; u = (uint32_t)(v + 8192);
        a[k++] = u & 127u; a[k++] = (u >> 7) & 127u;
    }
    for (i = 0; i < 16u; i++) { a[k++] = i & 1u ? 0u : (uint8_t)(48u + i); a[k++] = 0; }
    request(ED_UP_PUT, a, k);
    bad += check("UP_PUT stores a v4 record (no flash here: kept in RAM)",
                 host_wire[6] != 1u && up_used(3) && up_rec(3)->ver == UP_VER);
    up_values(up_rec(3), got);
    for (i = 0, ok = 1; i < P_COUNT; i++) ok &= got[i] == want[i];
    bad += check("UP_PUT keeps every value (PAN -20, FLT -40, min and max)", ok);
    a[0] = 3;
    request(ED_UP_GET, a, 1);
    ok = host_wire[5] == 3 && host_wire[6] == 1 && host_wire[7] == 0 && !memcmp(host_wire + 8, "ROUND", 6);
    for (i = 0, p = 14; i < P_COUNT; i++, p += 2u)
        ok &= (int32_t)(host_wire[p] | host_wire[p + 1] << 7) - 8192 == want[i];
    for (i = 0; i < 16u; i++, p += 2u)
        ok &= host_wire[p] == 0u && host_wire[p + 1u] == 0u;
    bad += check("UP_GET returns the values; the pattern bytes are reserved (zero)", ok);
    bad += check("  .. then kind 0, (1.2) the category: none sent, ANALOG's (OTHER), then slots 5..8 (off)",
                 host_wire[p] == 0u && host_wire[p + 1u] == CAT_OTHER && host_wire[p + 14u] == 0xF7);
    {   /* 3.5: an older record's E8 was KTR and its FM3 slots the OP3 envelope */
        up_rec_t *r = up_rec(3);
        int16_t v[P_COUNT];
        r->packed[UP_CAT_AT] &= 0x7Fu;                 /* no OSC 2 marker */
        up_set_value(r, P_E7, 64);
        up_set_value(r, P_MORPH, 10);
        up_set_value(r, P_DRIFT, 90);
        up_values(r, v);
        bad += check("an older ANALOG preset loads INT / MORPH / DRIFT 0, WAVE2 on OSC A's wave",
                     v[P_E7] == 0 && v[P_MORPH] == 0 && v[P_DRIFT] == 0 && v[P_WAVE2] == 0);
        up_mark_osc2(r);
        up_set_value(r, P_E7, -12);
        up_set_value(r, P_MORPH, 30);
        up_set_value(r, P_DRIFT, 40);
        up_values(r, v);
        bad += check("a marked ANALOG preset keeps INT / MORPH / DRIFT",
                     v[P_E7] == -12 && v[P_MORPH] == 30 && v[P_DRIFT] == 40);
    }
    {   /* 1.2 (Discussion #90): UP_PUT's category after the kind's 16 bytes; UP_LIST lists the categories after the slots */
        uint32_t k0 = k;
        a[k++] = 0;
        for (i = 0; i < 16u; i++) a[k++] = 0;
        a[k++] = CAT_PAD;
        a[0] = 3;
        request(ED_UP_PUT, a, k);
        ok = host_wire[6] != 1u && up_cat(3) == CAT_PAD;
        a[k - 1u] = CAT_N;
        request(ED_UP_PUT, a, k);
        ok &= host_wire[6] == 1u && up_cat(3) == CAT_PAD;
        a[0] = 3;
        request(ED_UP_GET, a, 1);
        ok &= host_wire[p] == 0u && host_wire[p + 1u] == CAT_PAD;
        a[0] = 2; a[1] = 2;
        n = request(ED_UP_LIST, a, 2);
        ok &= host_wire[5] == 2u && host_wire[6] == 2u && host_wire[n - 3u] == 0u && host_wire[n - 2u] == CAT_PAD;
        bad += check("UP_PUT with a category (after the kind's 16 bytes; past the last: rc 1), UP_GET and UP_LIST give it", ok);
        k = k0;
    }
    return bad;
}

/* the frames of cmd in host_wire: how many, and the args of the last (into *args) */
static uint32_t wire_frames(uint32_t cmd, const uint8_t **args)
{
    uint32_t i, k = 0;
    for (i = 0; i + 5u < host_wire_n; i++)
        if (host_wire[i] == 0xF0 && host_wire[i + 1] == ED_HDR0 && host_wire[i + 4] == cmd) {
            k++;
            if (args) *args = host_wire + i + 5;
        }
    return k;
}
static uint32_t sync_pass(void)                          /* one main-loop pass of the pushes */
{
    host_wire_n = 0;
    fm1_ms += 30u;
    ed_sync();
    host_drain();
    return host_wire_n;
}

/* MATRIX (cmd 103, INFO 58 01 8): the eight slots of a track, slots 1..4 the parameters 49..60, 5..8 track_t.mx;
 * a set clamps to the ranges of 1..4; WATCH pushes a device edit of any slot, not the editor's own; UP_PUT / UP_GET
 * carry slots 5..8 after the category */
static int matrix_protocol(void)
{
    uint8_t a[16 + 2u * P_COUNT + 32u + 30u];
    const uint8_t *x = 0;
    uint32_t i, k = 0, n, ok;
    int bad = 0;
    reset();
    n = request(ED_INFO, a, 0);
    for (i = 5, ok = 0; i + 2u < n; i++)
        ok |= host_wire[i] == 0x58 && host_wire[i + 1u] == 1u && host_wire[i + 2u] == NMSLOT;
    bad += check("INFO: 58 01 8 (MATRIX, eight slots)", ok);
    a[0] = 2;
    request(ED_MATRIX, a, 1);
    ok = host_wire[4] == ED_MATRIX && host_wire[5] == 2u && host_wire[6u + 3u * NMSLOT] == 0xF7;
    for (i = 0; i < NMSLOT; i++)
        ok &= host_wire[6u + 3u * i] == 0u && host_wire[7u + 3u * i] == 0u && host_wire[8u + 3u * i] == 64u;
    bad += check("MATRIX get: track 3, eight slots off (AMT byte 64 = 0)", ok);
    a[0] = 2; a[1] = 5; a[2] = MS_LFO; a[3] = MD_CUT; a[4] = 64 + 40;
    request(ED_MATRIX, a, 5);
    ok = trk[2].mx[1][MF_SRC] == MS_LFO && trk[2].mx[1][MF_DST] == MD_CUT && trk[2].mx[1][MF_AMT] == 40 &&
         host_wire[6u + 15u] == MS_LFO && host_wire[7u + 15u] == MD_CUT && host_wire[8u + 15u] == 104u;
    a[1] = 1; a[2] = MS_MODW; a[3] = MD_PAN; a[4] = 0;
    request(ED_MATRIX, a, 5);
    ok &= trk[2].p[P_M2SRC] == MS_MODW && trk[2].p[P_M2DST] == MD_PAN && trk[2].p[P_M2AMT] == -64;
    bad += check("MATRIX set: slot 6 into mx, slot 2 into P_M2SRC.., the reply as stored", ok);
    a[1] = 7; a[2] = 127; a[3] = 127; a[4] = 127;
    request(ED_MATRIX, a, 5);
    bad += check("MATRIX set clamps: SRC, DST to their last, AMT to 63",
                 trk[2].mx[3][MF_SRC] == MS_N - 1 && trk[2].mx[3][MF_DST] == MD_N - 1 && trk[2].mx[3][MF_AMT] == 63);
    a[1] = 8;
    bad += check("MATRIX: slot 9 or track 5: no reply", !request(ED_MATRIX, a, 5) && (a[0] = 4, !request(ED_MATRIX, a, 1)));
    reset();
    a[0] = 1; request(ED_WATCH, a, 1);
    sync_pass();
    TSEL->mx[0][MF_SRC] = MS_ENV; TSEL->mx[0][MF_DST] = MD_AMP; TSEL->mx[0][MF_AMT] = -3;   /* a device edit */
    sync_pass();
    bad += check("WATCH: a device edit of slot 5 pushes MATRIX",
                 wire_frames(ED_MATRIX, &x) == 1u && x[0] == song.sel && x[13] == MS_ENV && x[14] == MD_AMP && x[15] == 61u);
    bad += check("  .. once", !sync_pass());
    a[0] = (uint8_t)song.sel; a[1] = 6; a[2] = MS_KEY; a[3] = MD_SHP; a[4] = 70;
    request(ED_MATRIX, a, 5);
    bad += check("  .. the editor's own set: no push", !sync_pass());
    a[0] = 0; a[1] = P_M1AMT; a[2] = (8192 + 20) & 127; a[3] = (8192 + 20) >> 7;
    request(ED_SET, a, 4);
    bad += check("  .. the editor's SET of AMT1: no MATRIX echo", TSEL->p[P_M1AMT] == 20 && !sync_pass());
    a[0] = (uint8_t)song.sel; a[1] = P_M1SRC; a[2] = (8192 + MS_LFO) & 127; a[3] = (8192 + MS_LFO) >> 7;
    request(ED_TRACK_PARAM, a, 4);
    bad += check("  .. the editor's TRACK_PARAM of SRC1: no MATRIX echo", TSEL->p[P_M1SRC] == MS_LFO && !sync_pass());
    a[0] = (uint8_t)ed_eng(TSEL); a[1] = 1;
    request(ED_PRESET, a, 2);
    bad += check("  .. the editor's PRESET (slots 5 and 7 off): no MATRIX echo",
                 !TSEL->mx[0][MF_SRC] && !TSEL->mx[2][MF_SRC] && !sync_pass());
    /* UP_PUT with slots 5..8 after the category; UP_GET gives them back */
    reset();
    a[k++] = 4; a[k++] = 0;
    memcpy(a + k, "MX", 2); k += 2; a[k++] = 0;
    for (i = 0; i < P_COUNT; i++) {
        uint32_t u = (uint32_t)(param_desc_of(0, i)->def + 8192);
        a[k++] = u & 127u; a[k++] = (u >> 7) & 127u;
    }
    for (i = 0; i < 32u; i++) a[k++] = 0;
    a[k++] = 0;
    for (i = 0; i < 16u; i++) a[k++] = 0;
    a[k++] = CAT_PAD;
    for (i = 0; i < 12u; i++) a[k++] = (uint8_t)(i % 3u == 2u ? 64u + i : i % 3u == 0u ? 1u + i / 3u : 2u + i);
    request(ED_UP_PUT, a, k);
    a[0] = 4;
    n = request(ED_UP_GET, a, 1);
    ok = up_used(4) && n >= 13u && host_wire[n - 1u] == 0xF7 && host_wire[n - 14u] == CAT_PAD;
    for (i = 0; i < 12u; i++)
        ok &= host_wire[n - 13u + i] == (i % 3u == 2u ? 64u + i : i % 3u == 0u ? 1u + i / 3u : 2u + i);
    bad += check("UP_PUT / UP_GET: slots 5..8 after the category, as sent", ok);
    return bad;
}

/* #65: WATCH while watching keeps what is not pushed yet; the editor's own sound load is not echoed as RELOAD */
static int live_sync(void)
{
    int bad = 0;
    uint8_t a[4] = {1, 0, 0, 0};
    uint32_t i, other = 0;
    const uint8_t *x = 0;
    reset();
    usb.resets = 0;
    request(ED_WATCH, a, 1);
    bad += check("WATCH 1 starts watching", host_wire[5] == 1 && ed_w.on && !sync_pass());
    TSEL->p[P_LEVEL] = 77;                               /* a device change, not pushed yet */
    request(ED_WATCH, a, 1);
    bad += check("WATCH 1 while watching keeps a pending change: CHANGED still goes out",
                 sync_pass() && wire_frames(ED_CHANGED, &x) == 1u && x[1] == P_LEVEL && ed_rv(x + 2) == 77);
    TSEL->p[P_LEVEL] = 66;
    a[0] = 0; request(ED_WATCH, a, 1);
    a[0] = 1; request(ED_WATCH, a, 1);
    bad += check("WATCH 0 then WATCH 1 starts from the values as they are (no push)", !sync_pass());
    TSEL->p[P_LEVEL] = 55; trk[1].p[P_PAN] = 3;
    a[0] = 3; request(ED_WATCH, a, 1);
    sync_pass();
    bad += check("WATCH 3 while watching: CHANGED kept, TRACK_CHANGED from the mix as it is",
                 host_wire_n && wire_frames(ED_CHANGED, 0) == 1u && !wire_frames(ED_TRACK_CHANGED, 0) && ed_w.v4);
    usb.resets++;
    TSEL->p[P_LEVEL] = 44;
    request(ED_WATCH, a, 1);
    bad += check("WATCH after a USB reset starts over", !sync_pass());

    /* PRESET */
    TSEL->p[P_LEVEL] = 33;                               /* pending; a sound load keeps P_LEVEL */
    a[0] = 0; a[1] = 2;
    request(ED_PRESET, a, 2);
    sync_pass();
    bad += check("the editor's own PRESET: no RELOAD, no CHANGED for what it loaded, a pending CHANGED stays",
                 TSEL->preset == 2 && !wire_frames(ED_RELOAD, 0) && wire_frames(ED_CHANGED, &x) == 1u &&
                 x[1] == P_LEVEL && !sync_pass());
    for (i = 0; i < 3u; i++) {                           /* any preset of any engine */
        a[0] = (uint8_t)(i ? 12u : 4u); a[1] = (uint8_t)i;
        request(ED_PRESET, a, 2);
        other += sync_pass() != 0;
    }
    bad += check("PRESET of other engines: no push at all", !other && ed_w.eng == ed_eng(TSEL));
    a[0] = 1; a[1] = G_ENGSEL; a[2] = (8192 + 5) & 127; a[3] = (8192 + 5) >> 7;
    request(ED_SET, a, 4);
    bad += check("SET of G_ENGSEL: no RELOAD", ed_eng(TSEL) == 5u && !sync_pass());
    sync_reload = 1;                                     /* a load on the device, not pushed yet */
    a[0] = 0; a[1] = 1;
    request(ED_PRESET, a, 2);
    sync_pass();
    bad += check("a RELOAD due before the editor's PRESET still goes out", wire_frames(ED_RELOAD, 0) == 1u);
    a[0] = 0; request(ED_WATCH, a, 1);
    sync_reload = 0;
    a[0] = 0; a[1] = 3;
    request(ED_PRESET, a, 2);
    a[0] = 1; request(ED_WATCH, a, 1);
    bad += check("not watching: PRESET as before, WATCH then starts from it", !sync_pass() && TSEL->preset == 3);
    return bad;
}

/* #64: SysEx through the USB packet path (ep1_take) at full speed: a 256-byte BACKUP_PUT piece (293 pack7 bytes, 101
 * event packets, 7 USB packets) arrives whole; one request at a time always works, a frame sent before the reply
 * to the one before is dropped whole (no reply; never a partial frame) */
static uint32_t usb_frame(const uint8_t *f, uint32_t n, uint8_t *usbp)   /* F0..F7 -> USB-MIDI event packets */
{
    uint32_t i = 0, o = 0;
    while (i < n) {
        uint32_t k = n - i >= 3u ? 3u : n - i, cin = k == 3u && i + 3u < n ? 4u : k == 3u ? 7u : 4u + k;
        usbp[o++] = (uint8_t)cin;
        usbp[o++] = f[i];
        usbp[o++] = k > 1u ? f[i + 1] : 0;
        usbp[o++] = k > 2u ? f[i + 2] : 0;
        i += k;
    }
    return o;
}
static uint32_t usb_feed(const uint8_t *p, uint32_t n)   /* whole 64-byte USB packets, as the host sends them */
{
    uint32_t o, refused = 0;
    for (o = 0; o < n; o += 64u)
        while (!ep1_take(p + o, n - o > 64u ? 64u : n - o))
            refused++;                                  /* NAK: the host sends it again */
    return refused;
}
static uint32_t put_frame(uint8_t *f, uint32_t op, uint32_t off, uint32_t count)
{
    static const uint8_t zero[256];
    uint32_t n = 0, i;
    f[n++] = 0xF0; f[n++] = ED_HDR0; f[n++] = ED_HDR1; f[n++] = ED_HDR2; f[n++] = ED_BACKUP_PUT;
    f[n++] = (uint8_t)op; f[n++] = 2;
    if (op == 0u) {
        for (i = 0; i < 5u; i++) f[n++] = (uint8_t)((sizeof(project_store_t) >> (7u * i)) & (i == 4u ? 15u : 127u));
        for (i = 0; i < 5u; i++) f[n++] = 0;
    } else if (op == 1u) {
        for (i = 0; i < 5u; i++) f[n++] = (uint8_t)((off >> (7u * i)) & (i == 4u ? 15u : 127u));
        n += pack7(zero, count, f + n);
    }
    f[n++] = 0xF7;
    return n;
}
static int usb_burst(void)
{
    static uint8_t f[700], u[1000], u2[2000];
    uint32_t off, n, k, ok = 1, max = 0;
    const uint8_t *x = 0;
    int bad = 0;
    reset();
    usb.rx_pend = 0;
    n = put_frame(f, 0, 0, 0);
    usb_feed(u, usb_frame(f, n, u)); host_wire_n = 0; ed_service(); host_drain();
    bad += check("BACKUP_PUT begin through ep1_take", wire_frames(ED_BACKUP_PUT, &x) == 1u && !x[2]);
    for (off = 0; off < sizeof(project_store_t); off += 256u) {
        uint32_t c = sizeof(project_store_t) - off > 256u ? 256u : sizeof(project_store_t) - off;
        n = put_frame(f, 1, off, c);
        if (n > max) max = n;
        k = usb_frame(f, n, u);
        usb_feed(u, k);
        host_wire_n = 0; ed_service(); host_drain();
        ok &= wire_frames(ED_BACKUP_PUT, &x) == 1u && !x[2] && sx_ready == 0;
    }
    bad += check("256-byte pieces in 64-byte USB packets at full speed: every piece taken (rc 0)",
                 ok && ed_bk_pos == sizeof(project_store_t) && max == 4u + 1u + 7u + 293u + 1u && max <= sizeof sx_frame);
    n = put_frame(f, 3, 0, 0);
    usb_feed(u, usb_frame(f, n, u)); host_wire_n = 0; ed_service(); host_drain();
    bad += check("abort through ep1_take", wire_frames(ED_BACKUP_PUT, &x) == 1u && !x[2] && !ed_bk_put);

    /* two frames back to back, before the reply: the second is dropped whole, the first answered intact */
    n = put_frame(f, 0, 0, 0);
    usb_feed(u, usb_frame(f, n, u)); host_wire_n = 0; ed_service(); host_drain();
    k = usb_frame(f, put_frame(f, 1, 0, 256), u2);
    k += usb_frame(f, put_frame(f, 1, 256, 256), u2 + k);
    usb_feed(u2, k);
    host_wire_n = 0; ed_service(); ed_service(); host_drain();
    bad += check("pipelined: the first piece is taken, the second (sent before its reply) dropped whole",
                 wire_frames(ED_BACKUP_PUT, &x) == 1u && !x[2] && ed_bk_pos == 256u && !sx_ready);
    n = put_frame(f, 1, 512, 256);
    usb_feed(u, usb_frame(f, n, u)); host_wire_n = 0; ed_service(); host_drain();
    bad += check("... so the next piece is refused (rc 1, offset), as a host that waits never sees",
                 wire_frames(ED_BACKUP_PUT, &x) == 1u && x[2] == 1u && ed_bk_pos == 256u);
    request(ED_BACKUP_PUT, (const uint8_t[]){3, 2}, 2);
    return bad;
}

/* ---- MENU_DESC / MENU_SET (72, 73): the menu's settings over the editor ---- */
typedef struct { uint32_t index, id, kind, nnames, tab, rest; int32_t value, min, max; char name[16], names[12][12], tabname[16], unit[16]; } menu_item_t;
static uint32_t menu_desc(uint32_t index, menu_item_t *it)   /* the reply's payload length; it parsed */
{
    uint8_t a[1] = {(uint8_t)index};
    uint32_t n = request(ED_MENU_DESC, a, 1), p = 14, k;
    memset(it, 0, sizeof *it);
    if (n < 8u || host_wire[4] != ED_MENU_DESC || host_wire[n - 1] != 0xF7) return 0;
    it->index = host_wire[5]; it->id = host_wire[6];
    if (n < 15u) return n - 6u;
    it->kind = host_wire[7];
    it->value = ed_rv(host_wire + 8); it->min = ed_rv(host_wire + 10); it->max = ed_rv(host_wire + 12);
    for (k = 0; p < n - 1u && host_wire[p] && k < 15u; ) it->name[k++] = (char)host_wire[p++];
    p++;
    if (it->kind == 1u) {                                   /* (a number: its unit, then the tab) */
        for (k = 0; p < n - 1u && host_wire[p] && k < 15u; ) it->unit[k++] = (char)host_wire[p++];
        p++;
    }
    while (it->kind == 0u && p < n - 1u && it->nnames < 12u && (int32_t)it->nnames < it->max - it->min + 1) {   /* (kind 0: max - min + 1) */
        for (k = 0; p < n - 1u && host_wire[p] && k < 11u; ) it->names[it->nnames][k++] = (char)host_wire[p++];
        p++; it->nnames++;
    }
    it->tab = 127;                                          /* 1.0.5: then the row's tab, index and name */
    if (p < n - 1u) {
        it->tab = host_wire[p++];
        for (k = 0; p < n - 1u && host_wire[p] && k < 15u; ) it->tabname[k++] = (char)host_wire[p++];
        p++;
    }
    it->rest = p < n - 1u ? n - 1u - p : 0u;                /* (bytes left over: none) */
    return n - 6u;
}
static uint32_t menu_set(uint32_t id, int32_t v)            /* -> rc; host_wire[6], [7..8]: id, value */
{
    uint8_t a[3] = {(uint8_t)id, (uint8_t)((v + 8192) & 127), (uint8_t)(((v + 8192) >> 7) & 127)};
    uint32_t n = request(ED_MENU_SET, a, 3);
    return n == 10u && host_wire[4] == ED_MENU_SET ? host_wire[5] : 99u;
}
static int menu_protocol(void)
{
    static const char *const WANT[25][2] = {
        {"COLOR", 0}, {"STYLE", "FLAT,LINE"}, {"LARGE", "OFF,ON"}, {"ANIM", "ON,OFF,IDLE"}, {"LEDS", "OFF,DIM LO,DIM HI,INV"},
        {"HOLD", "0.3 s,0.4 s,0.5 s,0.6 s"}, {"KNOB ACCEL", "OFF,ON"}, {"FX LATCH", "OFF,ON"}, {"BPM LOCK", "OFF,ON"},
        {"SPEAKER EQ", "FLAT,LOWCUT,BASS+"}, {"USB LEVEL", "MASTER,FIXED"}, {"USB SERIAL", "ON,OFF"},
        {"CLICK", "OFF,REC,ON"}, {"CLICK LEVEL", "LOW,MID,HIGH"}, {"COUNT-IN", "OFF,1 BAR,2 BARS"},   /* (1.1: appended) */
        {"BOOT RESTORE", "ON,OFF"}, {"SCALE LEDS", "OFF,ON"},                                        /* (1.2/3.10) */
        {"SCREEN OFF", "NEVER,5 MIN,15 MIN,30 MIN,60 MIN"},
        {"SCOPE", "OUT,MIX"}, {"STEP PREVIEW", "OFF,ON"}, {"CHORD ENTRY", "HOLD,ADD"},                  /* (1.2) */
        {"MIDI IN", "CH1-4,SEL,CH5-8,CH9-12,CH13-16"}, {"TUNE", 0},   /* (1.2: the project's ROUT and TUNE; TUNE a number) */
        {"HOME", "SCOPE,TRACKS,LEVELS"},                                                       /* (1.3; 1.5: LEVELS) */
        {"HELP", "OFF,ON"}};                                                                         /* (1.5) */
    static const int32_t DEF[25] = {-1, 0, 0, 1, 2, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0};   /* (MIDI IN 1: SEL) */   /* (COLOR: the default palette; ANIM retired: OFF; KNOB ACCEL retired: ON) */
    static const uint8_t TAB[25] = {0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 4, 2, 2, 2, 4, 1, 0, 0, 1, 1, 3, 2, 0, 4};   /* DISPLAY CONTROL AUDIO
                                                                                                         * MIDI SYSTEM (1.2) */
    static const char *const TABN[5] = {"DISPLAY", "CONTROL", "AUDIO", "MIDI", "SYSTEM"};
    int bad = 0, ok = 1;
    uint32_t i, k, n;
    menu_item_t it;
    char joined[96];
    const char *json = getenv("MENU_JSON");
    FILE *jf = json ? fopen(json, "w") : 0;
    reset();
    if (jf) fprintf(jf, "[");
    for (i = 0; i < 25u; i++) {
        n = menu_desc(i, &it);
        joined[0] = 0;
        for (k = 0; k < it.nnames; k++) { if (k) strcat(joined, ","); strcat(joined, it.names[k]); }
        ok &= i == 22u ? n > 10u && it.index == i && it.id == i && it.kind == 1 && it.min == -50 && it.max == 50 &&
                         !it.nnames && !strcmp(it.unit, "ct") && !strcmp(it.name, "TUNE")     /* (a number: cents) */
                       : n > 10u && it.index == i && it.id == i && it.kind == 0 && it.min == 0 && !it.unit[0] &&
                         it.max + 1 == (int32_t)it.nnames && !strcmp(it.name, WANT[i][0]) &&
                         (WANT[i][1] ? !strcmp(joined, WANT[i][1]) : it.nnames == NPALETTES);
        ok &= it.value == (DEF[i] < 0 ? (int32_t)settings.palette : DEF[i]) &&
              it.tab == TAB[i] && !strcmp(it.tabname, TABN[TAB[i]]) && !it.rest;
        if (i == 0)
            for (k = 0; k < NPALETTES; k++) ok &= !strcmp(it.names[k], UI_PALETTES[k].name);
        if (!ok) { printf("  MENU_DESC %u: %s [%s] value %d max %d tab %u %s\n", i, it.name, joined, it.value, it.max, it.tab, it.tabname); break; }
        if (jf) {
            fprintf(jf, "%s\n {\"id\":%u,\"kind\":%u,\"min\":%d,\"max\":%d,\"value\":%d,\"name\":\"%s\",\"names\":[", i ? "," : "",
                    it.id, it.kind, it.min, it.max, it.value, it.name);
            for (k = 0; k < it.nnames; k++) fprintf(jf, "%s\"%s\"", k ? "," : "", it.names[k]);
            fprintf(jf, "],\"unit\":\"%s\",\"tab\":%u,\"tabName\":\"%s\"}", it.unit, it.tab, it.tabname);
        }
    }
    if (jf) { fprintf(jf, "]\n"); fclose(jf); }
    bad += check("MENU_DESC: 25 items (1.0.4's 12 in the menu's order, then 1.1's CLICK, CLICK LEVEL, COUNT-IN, 1.2's BOOT RESTORE, SCALE LEDS, SCREEN OFF, 1.2's SCOPE, STEP PREVIEW, CHORD ENTRY, MIDI IN, TUNE, 1.3's HOME, 1.5's HELP), ids 0..24, names, defaults; TUNE a number -50..50 ct", ok);
    bad += check("MENU_DESC (1.0.5): after the names (TUNE: the unit) each item's tab, index and name (DISPLAY CONTROL AUDIO MIDI SYSTEM)", ok);
    {   /* an older editor reads the names and stops: the tab is past them, nothing it reads moved */
        uint32_t m = menu_desc(4, &it), p = 14, q;
        for (q = 0; q < 1u + it.nnames; q++) { while (host_wire[p]) p++; p++; }   /* name, the names */
        ok = m > 10u && host_wire[p] == 0 && !strcmp((const char *)host_wire + p + 1, "DISPLAY") &&
             p + 1u + 8u == m + 6u - 1u;
        bad += check("MENU_DESC: the tab comes after every byte of the 1.0.4 reply (older editors ignore it)", ok);
    }
    ok = 1;
    for (i = 0; i < 25u; i++) {
        menu_desc(i, &it);
        ok &= strcmp(it.name, "CALIBRATION") && strcmp(it.name, "ABOUT") && strcmp(it.name, "INFO");
    }
    n = menu_desc(25, &it);
    ok &= n == 2u && it.index == 25 && it.id == 127;
    n = menu_desc(127, &it);
    bad += check("MENU_DESC: no CALIBRATION / INFO / ABOUT; an index past the list answers index, 127 (no item)",
                 ok && n == 2u && it.index == 127 && it.id == 127);
    {
        uint8_t a[3] = {0, 0, 0};
        ok = request(ED_MENU_DESC, a, 0) == 0 && request(ED_MENU_DESC, a, 2) == 0 && request(ED_MENU_SET, a, 2) == 0 &&
             request(ED_MENU_SET, a, 1) == 0;
        bad += check("MENU_DESC / MENU_SET with the wrong length: no reply", ok);
    }

    /* MENU_SET: each setting, applied as the menu applies it; RAM only here (no flash: rc 3) */
    reset();
    ui.force = 0;
    ok = menu_set(0, 2) == 3 && host_wire[6] == 0 && ed_rv(host_wire + 7) == 2 && settings.palette == 2u &&
         T_BG == UI_PALETTES[2].bg && ui.force;
    ok &= menu_set(1, 1) == 3 && ui_style == ST_FLAT && menu_get(MI_STYLE) == 0u;   /* STYLE retired: always FLAT */
    ok &= menu_set(2, 1) == 3 && (ui_prefs & PREF_LARGE);
    ok &= menu_set(3, 0) == 3 && menu_get(MI_ANIM) == 1u;   /* ANIM retired: always OFF (MENU_SET ignored) */
    ok &= menu_set(3, 2) == 3 && menu_get(MI_ANIM) == 1u && ed_rv(host_wire + 7) == 1;
    ok &= menu_set(4, 0) == 3 && settings_leds == LEDS_OFF && menu_set(4, 1) == 3 && settings_leds == LEDS_DIM_LO;
    ok &= menu_set(5, 3) == 3 && settings_hold == 3u;
    ok &= menu_set(6, 0) == 3 && menu_get(MI_ACCEL) == 1u;   /* KNOB ACCEL retired: always ON (MENU_SET ignored) */
    ok &= menu_set(6, 1) == 3 && menu_get(MI_ACCEL) == 1u && ed_rv(host_wire + 7) == 1;
    ok &= menu_set(7, 1) == 3 && (ui_prefs & PREF_LATCH);
    ok &= menu_set(8, 1) == 3 && (ui_prefs & PREF_BPM_LOCK);
    ok &= menu_set(9, 2) == 3 && settings.lowcut == 2u && fx_lowcut == 2u;
    ok &= menu_set(10, 1) == 3 && (ui_prefs & PREF_USB_FIXED) && fx_usb_fixed;
    ok &= menu_set(12, 1) == 3 && click_mode == CLICK_REC && menu_set(12, 2) == 3 && click_mode == CLICK_ON;
    ok &= menu_set(13, 0) == 3 && click_lvl == 0u;
    ok &= menu_set(14, 2) == 3 && cin_bars == 2u;
    ok &= menu_set(15, 1) == 3 && (ui_prefs & PREF_RESTORE_OFF);
    ok &= menu_set(16, 1) == 3 && (ui_rec_prefs & 0x40u) && click_mode == CLICK_ON && cin_bars == 2u;   /* (its own bit) */
    ok &= menu_set(17, 0) == 3 && scr_get() == 0u && menu_set(17, 9) == 3 && scr_get() == 4u &&   /* (clamped) */
          menu_set(17, 2) == 3 && scr_get() == 2u && ui_scr == 1u;
    ok &= menu_set(18, 1) == 3 && ui_prefs2 == 1u && scope_mix;                                    /* (1.2: their own byte) */
    ok &= menu_set(19, 1) == 3 && ui_prefs2 == 3u && menu_set(20, 1) == 3 && ui_prefs2 == 7u;
    ok &= menu_set(21, 2) == 0 && song.g[G_ROUTE] == 2 && menu_set(22, -13) == 0 && song.g[G_TUNE] == -13;   /* (1.2: the
                                                         * project's, rc 0: in the music, no settings record) */
    ok &= menu_set(23, 1) == 3 && ui_home_view == HV_TRACKS && ui_prefs2 == 7u && ui_scr == 1u;   /* (1.3: its own byte) */
    ok &= menu_set(24, 1) == 3 && ui_prefs2 == 15u;                                  /* (1.5: HELP retired, bit kept) */
    for (i = 0; i < 25u; i++) {                         /* MENU_DESC reads them back */
        static const int32_t SET[25] = {2, 0, 1, 1, 1, 3, 1, 1, 1, 2, 1, 0, 2, 0, 2, 1, 1, 2, 1, 1, 1, 2, -13, 1, 1};
        menu_desc(i, &it);                              /* STYLE forced FLAT (0); ANIM forced OFF (1) */
        ok &= it.value == SET[i];
    }
    bad += check("MENU_SET: every setting applied as the menu does (palette, EQ, USB LEVEL, CLICK, COUNT-IN at once, BOOT RESTORE, SCALE LEDS, SCREEN OFF, SCOPE, STEP PREVIEW, CHORD ENTRY, HOME; STYLE/ANIM/KNOB ACCEL retired fixed), read back", ok);
    ok = menu_set(3, 0) == 3 && menu_get(MI_ANIM) == 1u && (ui_prefs & PREF_LARGE) && menu_set(10, 0) == 3 &&
         !fx_usb_fixed && menu_set(1, 1) == 3 && ui_style == ST_FLAT && menu_get(MI_STYLE) == 0u &&
         menu_get(MI_ACCEL) == 1u;
    bad += check("MENU_SET: a flag back to its default leaves the other flags (STYLE/ANIM/ACCEL stay FLAT/OFF/ON)", ok);

    /* clamping: the reply carries the device's value */
    ok = menu_set(0, 50) == 3 && ed_rv(host_wire + 7) == (int32_t)NPALETTES - 1 && settings.palette == NPALETTES - 1u;
    ok &= menu_set(0, -5) == 3 && ed_rv(host_wire + 7) == 0 && settings.palette == 0u;
    ok &= menu_set(4, 99) == 3 && ed_rv(host_wire + 7) == 3 && settings_leds == LEDS_INV;
    ok &= menu_set(5, 8191) == 3 && ed_rv(host_wire + 7) == 3 && settings_hold == 3u;
    ok &= menu_set(2, 7) == 3 && ed_rv(host_wire + 7) == 1 && (ui_prefs & PREF_LARGE);
    ok &= menu_set(14, 9) == 3 && ed_rv(host_wire + 7) == 2 && cin_bars == 2u;
    ok &= menu_set(12, -1) == 3 && ed_rv(host_wire + 7) == 0 && click_mode == CLICK_OFF;
    ok &= menu_set(21, 9) == 0 && ed_rv(host_wire + 7) == 4 && song.g[G_ROUTE] == 4;
    ok &= menu_set(22, -99) == 0 && ed_rv(host_wire + 7) == -50 && song.g[G_TUNE] == -50;
    ok &= menu_set(22, 51) == 0 && ed_rv(host_wire + 7) == 50 && song.g[G_TUNE] == 50;
    bad += check("MENU_SET: out-of-range values clamped, the reply says the value the device took (TUNE -50..50)", ok);

    /* an id nobody has */
    {
        static uint8_t fav0[sizeof favorites], set0[sizeof settings];
        uint8_t hold0 = settings_hold, leds0 = settings_leds;
        memcpy(fav0, &favorites, sizeof favorites); memcpy(set0, &settings, sizeof settings);
        ok = menu_set(25, 1) == 1 && host_wire[6] == 25 && ed_rv(host_wire + 7) == 1;
        ok &= menu_set(126, -3) == 1 && host_wire[6] == 126 && ed_rv(host_wire + 7) == -3;
        ok &= menu_set(127, 0) == 1 && host_wire[6] == 127;
        ok &= !memcmp(fav0, &favorites, sizeof favorites) && !memcmp(set0, &settings, sizeof settings) &&
              hold0 == settings_hold && leds0 == settings_leds;
        bad += check("MENU_SET: an unknown id answers rc 1, id and value echoed, nothing changed", ok);
    }

    /* the MENU page shown: the editor's change redraws it */
    ui.menu = 1; ui.force = 0;
    menu_set(7, 0);
    bad += check("MENU_SET while the MENU page is shown: the page redraws (ui.force)", ui.force && ui.menu == 1);
    ui.menu = 0;

    /* USB SERIAL: the reply first, the re-enumeration 200 ms later (usb_serial_apply, called every frame). (usb.up
     * stays 0 here: the host has no USB registers; usb.config 0 = the device off the bus, enumerated afresh) */
    {
        uint32_t t0;
        reset();
        usb_cdc_on = 1;
        usb_serial_apply();
        ok = usb_cdc_on && usb.config;
        ok &= menu_set(11, 1) == 3 && host_wire[6] == 11 && ed_rv(host_wire + 7) == 1 && (ui_prefs & PREF_SERIAL_OFF);
        t0 = fm1_ms;
        usb_serial_apply();
        ok &= usb_cdc_on && usb.config;                 /* the reply has left; USB as it was */
        fm1_ms = t0 + 150u; usb_serial_apply();
        ok &= usb_cdc_on && usb.config;
        fm1_ms = t0 + 201u; usb_serial_apply();
        ok &= !usb_cdc_on && !usb.config;               /* off the bus: usb_retry attaches again without the console */
        bad += check("MENU_SET USB SERIAL OFF: reply first, applied ~200 ms later (the device re-enumerates)", ok);
        usb.config = 1;
        ok = menu_set(11, 0) == 3 && !(ui_prefs & PREF_SERIAL_OFF);
        t0 = fm1_ms;
        ui.menu = 1;                                    /* the MENU shown: applied when it closes, as the menu's own */
        fm1_ms = t0 + 500u;                             /* (ui_input calls usb_serial_apply only with the menu closed) */
        ok &= !usb_cdc_on && usb.config;
        ui.menu = 0; usb_serial_apply();
        ok &= usb_cdc_on && !usb.config;
        usb.config = 1;
        ok &= menu_set(11, 0) == 3;                     /* unchanged: no re-enumeration */
        fm1_ms += 300u; usb_serial_apply();
        ok &= usb_cdc_on && usb.config;
        bad += check("MENU_SET USB SERIAL ON: applied later (with the MENU open: when it closes); unchanged: no drop", ok);
    }
    reset();
    return bad;
}

/* DRUM-X: P_E0 is MRPH 0..127 (Felucca KIT enum retired). DESC is F_PCT; SET clamps; old KIT bytes load as MRPH. */
static int drum_kit_retired(void)
{
    static uint8_t a[16 + 2u * P_COUNT + 32u];
    int16_t got[P_COUNT];
    uint32_t r, i, k = 0, ok = 1;
    int bad = 0;
    reset();
    a[0] = 1; a[1] = G_ENGSEL; a[2] = (8192 + ENGI_DRUM) & 127; a[3] = (8192 + ENGI_DRUM) >> 7;
    request(ED_SET, a, 4);
    a[0] = 0; a[1] = P_E0;
    request(ED_DESC, a, 2);
    {   /* scope, id, fmt, min, max, def (v14 each), "MRPH", unit */
        const uint8_t *b = host_wire + 5;
        ok &= b[0] == 0 && b[1] == P_E0 && b[2] == F_PCT;
        ok &= ((int32_t)(b[3] | b[4] << 7) - 8192) == 0;
        ok &= ((int32_t)(b[5] | b[6] << 7) - 8192) == 127;
        ok &= ((int32_t)(b[7] | b[8] << 7) - 8192) == 64;
        ok &= !strcmp((const char *)(b + 9), "MRPH");
    }
    bad += check("DESC of DRUM-X MRPH: F_PCT 0..127 def 64", ok);
    for (r = 0, ok = ed_eng(TSEL) == ENGI_DRUM; r <= 127u; r += 32u) {
        uint32_t u = r + 8192u;
        a[0] = 0; a[1] = P_E0; a[2] = u & 127u; a[3] = u >> 7;
        request(ED_SET, a, 4);
        ok &= TSEL->p[P_E0] == (int16_t)r && (int32_t)(host_wire[7] | host_wire[8] << 7) - 8192 == (int32_t)r;
    }
    bad += check("SET of DRUM-X MRPH lands on 0..127 (and replies it)", ok);
    a[k++] = 5; a[k++] = ENGI_DRUM;                        /* slot U06, DRUM, MRPH 3 (old KIT byte) */
    memcpy(a + k, "OLDKIT", 6); k += 6; a[k++] = 0;
    for (i = 0; i < P_COUNT; i++) {
        uint32_t u = (uint32_t)((i == P_E0 ? 3 : param_desc_of(ENGI_DRUM, i)->def) + 8192);
        a[k++] = u & 127u; a[k++] = (u >> 7) & 127u;
    }
    for (i = 0; i < 16u; i++) { a[k++] = 0; a[k++] = 0; }
    request(ED_UP_PUT, a, k);
    up_values(up_rec(5), got);
    bad += check("a user preset with old KIT byte 3 loads as MRPH 3", up_used(5) && got[P_E0] == 3);
    {   /* a project whose DRUM tracks hold 0..3: load/bound keep them as MRPH */
        static project_t p;
        for (r = 0; r < NTRK; r++) {
            set_engine_of(&trk[r], ENGI_DRUM); apply_preset_to(&trk[r], 0);
            trk[r].engine = trk[r].eng_req;
        }
        project_capture(&p);
        for (r = 0; r < NTRK; r++) p.t[r].p[P_E0] = (int16_t)r;
        p.sum = proj_sum(&p);
        ok = !project_restore_runtime(&p);
        for (r = 0; r < NTRK; r++) ok &= trk[r].p[P_E0] == (int16_t)r;
        for (r = 0; r < NTRK; r++) p.t[r].p[P_E0] = (int16_t)r;
        proj_bound(&p);
        for (r = 0; r < NTRK; r++) ok &= p.t[r].p[P_E0] == (int16_t)r;
        bad += check("a project of DRUM MRPH 0..3 loads as those values", ok);
    }
    return bad;
}

/* ED_SET / ED_TRACK_PARAM of P_ALLOC (SWEEP 0..22) must keep PIT GLD (CGLD_BIT), as STRUM/STROKE do on the device. */
static int alloc_preserves_cgld(void)
{
    int bad = 0;
    const uint32_t commands[] = {ED_SET, ED_TRACK_PARAM};
    for (uint32_t c = 0; c < 2; c++) {
        uint16_t raw = (uint16_t)(5 + 8192);              /* SWEEP 5 = 1/16 DOWN (rate 2, stroke 0) */
        uint8_t a[] = {0, P_ALLOC, (uint8_t)(raw & 127u), (uint8_t)(raw >> 7)};
        int ok;
        reset();
        trk[0].p[P_ALLOC] = (int16_t)(sweep_pack(3, 1) | (int16_t)CGLD_BIT);
        request(commands[c], a, sizeof a);
        ok = cgld_on(&trk[0]) && sweep_rate(&trk[0]) == 2u && sweep_stroke(&trk[0]) == 0u;
        bad += check(commands[c] == ED_SET ? "SET of SWEEP keeps PIT GLD (CGLD_BIT)" :
                                             "TRACK_PARAM of SWEEP keeps PIT GLD (CGLD_BIT)",
                     ok);
    }
    return bad;
}

#ifndef EDITOR_TEST_NO_MAIN                              /* (robust_test.c, fuzz_*.c: this file is their base) */
int main(void)
{
    int bad = preferences() + motion_locks() + dump_order() + slown_descriptor() + pitch_locks() + bend_automation() +
              matrix_edits_preserve_fx_locks() + editor_fx_order() + framing() + dispatch() + uart_recovery() + steps() + samples() + wavetable_slot() + song_protocol() + malformed_saves() +
              fm6_patches() + user_preset_roundtrip() + matrix_protocol() + live_sync() + usb_burst() + menu_protocol() + drum_kit_retired() +
              alloc_preserves_cgld();
    printf("%s\n", bad ? "EDITOR TEST FAILED" : "editor test passed");
    return bad != 0;
}
#endif
