/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
 * Real UI/motion/project sources: the ids outside a track's p[] and their contract.
 *   PITCH      motion-only, lock-only, 127, never p[]
 *   MFX_*      FX targets aliasing matrix ids, motion locks through fx_target_ptr
 *   EV_*       AUTOMATION's own step rows, not motion ids
 *   PG_*       CHORD's sweep cards, not motion ids
 *   P_ALLOC    the packed sweep (rate / stroke), legacy OFF
 *   MOTION_ID  bit 7 is MOTION_LOCK, never part of the id */
#define UI_TEST_NO_MAIN 1
#include "ui_test.c"

static int id_classification(void)
{
    int bad = 0, ok;
    uint32_t id;
    ui_power_on();
    ok = 1;
    for (id = 0; id < P_COUNT; id++)
        ok &= param_real(id) && param_id_known(id) && !param_lock_only(id);
    bad += check("every P_* id is real and known, none lock-only", ok);
    bad += check("PITCH (127) is lock-only, not real, and known", !param_real(MSEQ_PITCH) &&
        param_lock_only(MSEQ_PITCH) && param_id_known(MSEQ_PITCH));
    bad += check("an id past PITCH is unknown", !param_real(MSEQ_PITCH + 1u) &&
        !param_lock_only(MSEQ_PITCH + 1u) && !param_id_known(MSEQ_PITCH + 1u));
    return bad;
}

static int pitch_contract(void)
{
    int bad = 0, ok;
    track_t *t;
    motion_store_t m = {0};
    project_t before, after;
    project_store_t st;
    uint32_t i, nr, row = 0, found = 0, sel = 0, prow = 0;
    uint16_t rw[EV_ROWS];

    ui_power_on();
    t = &trk[0];
    bad += check("PITCH is a motion target", motion_param(MSEQ_PITCH));
    bad += check("PITCH refuses an automation event", motion_set_event(t, 2, MSEQ_PITCH, 7) == 1 && !motion.count);
    bad += check("PITCH accepts a lock, stored with MOTION_LOCK", !motion_set_lock(t, 2, MSEQ_PITCH, 7) &&
        motion.count == 1u && motion.event[0].param == (MSEQ_PITCH | MOTION_LOCK) && motion.event[0].value == 7);
    m.count = 1; m.on = 1;
    m.event[0] = (motion_event_t){0, MSEQ_PITCH, 0};
    ok = !motion_valid(&m);
    m.event[0].param = (uint8_t)(MSEQ_PITCH | MOTION_LOCK);
    m.event[0].value = 25;
    ok &= !motion_valid(&m);
    m.event[0].value = 7;
    ok &= motion_valid(&m);
    bad += check("a stored PITCH record must be a lock in -24..24", ok);
    project_capture(&before);
    ok = proj_pack(&st, &before) && proj_import(&after, &st, sizeof st) && after.motion.count == 1u &&
         after.motion.event[0].param == (MSEQ_PITCH | MOTION_LOCK) && after.motion.event[0].value == 7;
    bad += check("a PITCH lock round-trips through a project (127 + bit 7)", ok);

    i = pk_build_auto(t, MSEQ_PITCH, NSTEP, &sel);
    for (nr = 0, row = 0; nr < i; nr++)
        if (pk_rows[nr].id == MSEQ_PITCH)
            row = nr;
    bad += check("+ ADD lists PITCH and selects it for a PITCH id",
        i && row < i && pk_rows[row].id == MSEQ_PITCH && sel == row);

    motion_clear(t);
    motion_set_lock(t, 0, P_REV, 50);
    i = pk_build_auto(t, P_REV, 0, &sel);
    for (nr = 0, found = 0; nr < i; nr++)
        if (pk_rows[nr].id == MSEQ_PITCH)
            found = 1;
    bad += check("a record's list still offers PITCH and selects the record's id",
        found && sel < i && pk_rows[sel].id == P_REV);

    go_auto_top();
    frame();
    nr = ev_list(rw);
    for (i = 0, found = 0; i < nr; i++)
        if ((rw[i] >> 8) == EVK_REC && MOTION_ID(&motion.event[rw[i] & 0xFFu]) == P_REV) {
            row = i;
            found = 1;
        }
    if (found) {
        ui.ev_row = (uint16_t)row;
        pk_open(PK_AUTO);
        for (i = 0; i < pk_n; i++)
            if (pk_rows[i].id == MSEQ_PITCH)
                prow = i;
        pk_cur = (uint8_t)prow;
        pk_apply();
    }
    bad += check("K3 PARAM: selecting PITCH really changes the record",
        found && motion_find(t, 0, MSEQ_PITCH) >= 0 && motion_find(t, 0, P_REV) < 0 &&
        MOTION_ID(&motion.event[0]) == MSEQ_PITCH && (motion.event[0].param & MOTION_LOCK));

    i = pk_build_auto(t, MSEQ_PITCH, 0, &sel);
    bad += check("a PITCH record's list selects its own row",
        sel < i && pk_rows[sel].id == MSEQ_PITCH);
    return bad;
}

/* PITCH is ignored on kit tracks: the same key map that skips TRN. No new records, capture or move; stored
 * records still load (motion_valid is store-level) and the UI knob maps to no lock. */
static int pitch_kit_contract(void)
{
    int bad = 0, ok;
    track_t *t;
    int16_t v;
    motion_store_t m = {0};

    ui_power_on();
    song.sel = 0;
    t = &trk[0];
    set_engine_of(t, ENGI_DRUM);
    bad += check("PITCH: DRUM is a kit track (the engine's own key map)", kit_track(t));
    ok = motion_set_lock(t, 2, MSEQ_PITCH, 5) == 1 && !motion.count && !motion.on &&
         !motion_lock_get(t, 2, MSEQ_PITCH, &v);
    bad += check("  motion_set_lock refuses PITCH on a kit and writes nothing", ok);
    song.rec = 1;
    seq_start(); seq_tick(t, CTL);
    t->p[P_TRANS] = 4;
    ok = !motion_capture(t, P_TRANS, 4) && !motion.count && t->p[P_TRANS] == 4;
    bad += check("  motion_capture of TRN on a kit writes no PITCH lock", ok);
    song.rec = 0;
    seq_stop();
    motion_clear(t);
    motion_set_lock(t, 1, P_REV, 50);
    ok = motion.count == 1u && motion_move(t, 0, 1, MSEQ_PITCH, 5) == 1 &&
         motion_find(t, 1, MSEQ_PITCH) < 0 && motion_find(t, 1, P_REV) >= 0;
    bad += check("  motion_move cannot move a record onto PITCH on a kit", ok);
    m.count = 1;
    m.on = 1;
    m.event[0] = (motion_event_t){2, (uint8_t)(MSEQ_PITCH | MOTION_LOCK), 5};
    bad += check("  a stored PITCH lock on a kit still validates (loading)", motion_valid(&m));
    ui_power_on();
    song.sel = 0;
    set_engine_of(TSEL, ENGI_DRUM);
    go_title("SCL");
    go_seq_step();
    frame();
    bad += check("SCL K4 on a kit track maps to no lock (0xFF)", lock_id(3) == 0xFFu);
    ui_power_on();
    go_title("SCL");
    go_seq_step();
    frame();
    bad += check("  the same knob on a synth track maps to PITCH", lock_id(3) == MSEQ_PITCH);
    return bad;
}

static int mfx_contract(void)
{
    int bad = 0, ok;
    track_t *t;
    project_t before, after;
    project_store_t st;
    int16_t value[MFX_DAMP - MFX_TIME + 1u];
    uint32_t id, i;

    ui_power_on();
    t = &trk[0];
    ok = 1;
    for (id = MFX_TIME; id <= MFX_DAMP; id++) {
        const param_desc_t *d = motion_target_desc(t, id);
        ok &= motion_param(id) && d && d->label && d->label[0] && d->max > d->min;
        value[id - MFX_TIME] = d ? d->min : 0;
        ok &= !motion_set_lock(t, id - MFX_TIME, id, value[id - MFX_TIME]);
    }
    bad += check("every MFX target is a motion parameter with a descriptor and range", ok);
    bad += check("all five MFX locks validate", motion_valid(&motion) && motion.count == 5u);
    project_capture(&before);
    ok = proj_pack(&st, &before) && proj_import(&after, &st, sizeof st) && after.motion.count == 5u;
    for (i = 0; ok && i < 5u; i++)
        ok &= after.motion.event[i].param == (uint8_t)((MFX_TIME + i) | MOTION_LOCK) &&
              after.motion.event[i].value == value[i];
    bad += check("MFX locks round-trip through a project", ok);
    return bad;
}

static int ev_contract(void)
{
    static const uint32_t EV[] = {EV_VEL, EV_NUDGE, EV_CHANCE, EV_RATCH};
    int bad = 0, ok;
    char nm[16];
    uint32_t i, j;
    track_t *t;

    ui_power_on();
    t = &trk[0];
    ok = 1;
    for (i = 0; i < NELEM(EV); i++) {
        ev_name(t, EV[i], nm);
        ok &= ev_id_ok(t, EV[i]) && nm[0] && ev_id_at(ev_id_pos(EV[i])) == EV[i] && !param_id_known(EV[i]);
        for (j = 0; j < i; j++)
            ok &= ev_id_pos(EV[i]) != ev_id_pos(EV[j]);
    }
    bad += check("AUTOMATION's four step rows are named UI ids, not motion ids", ok);
    ok = 1;
    for (i = 0; i < NELEM(EV); i++)
        ok &= ev_id_ok(t, ev_id_step(t, 0, EV[i], 1)) && ev_id_ok(t, ev_id_step(t, 0, EV[i], -1));
    bad += check("ev_id_step from every step row lands on a valid id", ok);
    bad += check("ev_id_step from VEL goes on to the first real parameter", ev_id_step(t, 0, EV_VEL, 1) == 0u);
    bad += check("PITCH's AUTOMATION position maps back to PITCH", ev_id_at(ev_id_pos(MSEQ_PITCH)) == MSEQ_PITCH);
    bad += check("the parameter walk runs last real id -> PITCH -> last real id",
        ev_id_step(t, NSTEP, P_COUNT - 1u, 1) == MSEQ_PITCH &&
        ev_id_step(t, NSTEP, MSEQ_PITCH, -1) == P_COUNT - 1u);
    return bad;
}

static int pg_contract(void)
{
    int bad = 0, ok;
    const page_t *pg = 0;
    const param_desc_t *d;
    int16_t *vp;
    uint32_t i;

    ui_power_on();
    for (i = 0; i < NPAGES; i++)
        if (str_eq(PAGES[i].title, "CHORD")) {
            pg = &PAGES[i];
            break;
        }
    bad += check("CHORD's K3/K4 cards are the sweep's STRUM / STROKE",
        pg && pg->id[2] == PG_STRUM && pg->id[3] == PG_STROKE);
    ok = 0;
    if (pg) {
        d = page_desc(pg, 2, &vp);
        ok = d && vp && str_eq(d->label, "STRUM") && d->max > d->min;
        d = page_desc(pg, 3, &vp);
        ok &= d && vp && str_eq(d->label, "STROKE") && d->max > d->min;
    }
    bad += check("page_desc returns the STRUM / STROKE descriptors", ok);
    bad += check("the CHORD cards are UI-only, not motion ids", !motion_param(PG_STRUM) &&
        !motion_param(PG_STROKE) && !param_id_known(PG_STRUM) && !param_id_known(PG_STROKE));
    return bad;
}

static int bend_contract(void)
{
    int bad = 0, ok;
    const page_t *vox = 0, *vox2 = 0;
    const param_desc_t *d;
    int16_t *vp;
    uint32_t i;

    ui_power_on();
    for (i = 0; i < NPAGES; i++)
        if (str_eq(PAGES[i].title, "VOICE") && PAGES[i].fam == FAM_EDIT) {
            vox = &PAGES[i];
            if (i + 1u < NPAGES && PAGES[i + 1u].id[0] == PG_BEND)
                vox2 = &PAGES[i + 1u];
        }
    ok = vox && vox2 && vox->sec == EDIT_SEC_VOX && vox2->sec == EDIT_SEC_VOX &&
         vox2->fam == FAM_EDIT && PG_BEND == 250u && PG_CGLD == 251u;
    ok &= !param_id_known(PG_BEND) && !motion_param(PG_BEND) && !param_real(PG_BEND);
    ok &= !param_id_known(PG_CGLD) && !motion_param(PG_CGLD) && !param_real(PG_CGLD);
    bad += check("PITCH is the page after VOICE; PG_BEND 250 / PG_CGLD 251 are UI-only, not motion / real ids", ok);
    ok = 0;
    if (vox && vox2) {
        TSEL->p[P_VOICE] = (int16_t)V_POLY;
        d = page_desc(vox, 2, &vp);
        ok = d && vp && str_eq(d->label, "PIT GLD") && d->fmt == F_ONOFF &&
             page_desc(vox, 3, &vp) != 0 && str_eq(page_desc(vox, 3, &vp)->label, "SPRD") &&
             page_visible((uint32_t)(vox2 - PAGES));      /* the PITCH page in every mode */
        d = page_desc(vox2, 0, &vp);
        ok &= d && vp && str_eq(d->label, "PITCH") && d->fmt == F_CENT && d->min == -200 && d->max == 200;
        TSEL->p[P_VOICE] = (int16_t)V_MONO;
        ok &= page_desc(vox, 2, &vp) == 0 && page_desc(vox, 3, &vp) == 0 &&
              page_visible((uint32_t)(vox2 - PAGES)) && page_desc(vox2, 0, &vp) != 0;
        TSEL->p[P_VOICE] = (int16_t)V_UNISON;
        d = page_desc(vox, 3, &vp);
        ok &= d && str_eq(d->label, "UNI DTN");
        ok &= page_desc(vox, 2, &vp) == 0;                /* PIT GLD is POLY only */
        TSEL->p[P_VOICE] = (int16_t)V_POLY;
    }
    bad += check("VOICE: PIT GLD then SPRD (POLY), UNI DTN (UNISON); PITCH page in every mode", ok);
    if (vox) {
        ui.plk_src = (uint8_t)(vox - PAGES + 1u);
        TSEL->p[P_VOICE] = (int16_t)V_POLY;
        ok = lock_id(3) == P_SPRD;
        TSEL->p[P_VOICE] = (int16_t)V_UNISON;
        ok &= lock_id(3) == P_DETUNE;
        TSEL->p[P_VOICE] = (int16_t)V_MONO;
        ok &= lock_id(3) == 0xFFu;
        TSEL->p[P_VOICE] = (int16_t)V_POLY;
        ui.plk_src = 0;
        bad += check("VOICE K4: a held step locks SPRD (POLY), UNI DTN (UNISON), nothing in MONO", ok);
    }
    return bad;
}

static int sweep_contract(void)
{
    int bad = 0, ok;
    track_t *t;
    uint32_t rate, stroke;

    ui_power_on();
    t = &trk[0];
    ok = 1;
    for (rate = 1; rate <= 7u; rate++)
        for (stroke = 0; stroke <= 2u; stroke++) {
            t->p[P_ALLOC] = sweep_pack(rate, stroke);
            ok &= sweep_rate(t) == rate && sweep_stroke(t) == stroke;
        }
    bad += check("P_ALLOC round-trips every rate 1..7 and stroke 0..2", ok);
    ok = 1;
    for (stroke = 0; stroke <= 2u; stroke++)
        ok &= sweep_pack(0, stroke) == 0;
    t->p[P_ALLOC] = 0;
    ok &= !sweep_rate(t) && !sweep_stroke(t);
    t->p[P_ALLOC] = 1;
    ok &= !sweep_rate(t) && !sweep_stroke(t);
    bad += check("sweep OFF and the legacy ROT / REUSE aliases read as OFF", ok);
    t->p[P_ALLOC] = (int16_t)(sweep_pack(3, 2) | (int16_t)CGLD_BIT);
    bad += check("PIT GLD (P_ALLOC bit 5) leaves STRUM / STROKE untouched",
                 cgld_on(t) && sweep_rate(t) == 3u && sweep_stroke(t) == 2u);
    {
        project_t q;
        project_store_t st;
        project_capture(&q);
        bad += check("PIT GLD survives a project round trip",
                     proj_pack(&st, &q) && proj_import(&q, &st, sizeof st) &&
                     cgld_on((const track_t *)&q.t[0]) && sweep_rate((const track_t *)&q.t[0]) == 3u &&
                     sweep_stroke((const track_t *)&q.t[0]) == 2u);
    }
    cgld_set(t, 0);
    bad += check("clearing PIT GLD keeps STRUM / STROKE", !cgld_on(t) && sweep_rate(t) == 3u && sweep_stroke(t) == 2u);
    return bad;
}

static int motion_id_contract(void)
{
    int bad = 0, ok;
    motion_event_t e;
    uint32_t i;

    ui_power_on();
    e = (motion_event_t){0, (uint8_t)(MSEQ_PITCH | MOTION_LOCK), 3};
    bad += check("MOTION_ID strips bit 7 from a PITCH record", MOTION_ID(&e) == MSEQ_PITCH &&
        (e.param & MOTION_LOCK));
    e = (motion_event_t){1, (uint8_t)(P_REV | MOTION_LOCK), 40};
    bad += check("MOTION_ID strips bit 7 from an ordinary lock", MOTION_ID(&e) == P_REV &&
        (e.param & MOTION_LOCK));
    motion_set_lock(&trk[0], 0, MSEQ_PITCH, 1);
    motion_set_lock(&trk[0], 1, P_REV, 2);
    ok = motion.count == 2u;
    for (i = 0; i < motion.count; i++)
        ok &= MOTION_ID(&motion.event[i]) != MSEQ_PITCH || (motion.event[i].param & MOTION_LOCK);
    bad += check("every stored PITCH record carries MOTION_LOCK", ok);
    return bad;
}

static int tape_contract(void)
{
    int bad = 0, ok;
    track_t *t;
    project_t before, after;
    project_store_t st;
    uint32_t i, seen = 0;

    ui_power_on();
    t = &trk[0];
    song.g[G_TAPEMODE] = TAPE_MASTER;                 /* any track may lock SPEED / FLUTR */
    ok = motion_param(MFX_TSPEED) && motion_param(MFX_TWOW) &&
         motion_target_desc(t, MFX_TSPEED)->min == 25 && motion_target_desc(t, MFX_TSPEED)->max == 400 &&
         motion_target_desc(t, MFX_TWOW)->min == 0 && motion_target_desc(t, MFX_TWOW)->max == 127 &&
         fx_target_ptr(t, MFX_TSPEED) == &song.g[G_TSPEED] &&
         fx_target_ptr(t, MFX_TWOW) == &song.g[G_TWOW];
    ok &= !motion_set_lock(t, 0, MFX_TSPEED, 100) && !motion_set_lock(t, 1, MFX_TWOW, 42) &&
          !motion_set_lock(t, 2, MFX_TSPEED, 400) && !motion_set_lock(t, 3, MFX_TSPEED, 25);
    bad += check("TAPE SPEED / FLUTR are motion targets with their global descriptors and ranges", ok);
    project_capture(&before);
    ok = proj_pack(&st, &before) && proj_import(&after, &st, sizeof st) && after.motion.count == 4u;
    for (i = 0; ok && i < after.motion.count; i++) {
        const motion_event_t *e = &after.motion.event[i];
        uint32_t id = MOTION_ID(e);
        if (id == MFX_TWOW && e->place == 1u) {
            ok &= e->value == 42 && (e->param & MOTION_LOCK);
            seen |= 1u;
        } else if (id == MFX_TSPEED && e->place == 0u) {
            ok &= e->value == 100 && (e->param & MOTION_LOCK);
            seen |= 2u;
        } else if (id == MFX_TSPEED && e->place == 2u) {
            ok &= e->value == 400;
            seen |= 4u;
        } else if (id == MFX_TSPEED && e->place == 3u) {
            ok &= e->value == 25;
            seen |= 8u;
        } else
            ok = 0;
    }
    bad += check("TAPE SPEED / FLUTR locks round-trip through a project (100 / 400 / 25 exact)", ok && seen == 15u);
    return bad;
}

static int bend_lane_contract(void)
{
    int bad = 0;
    track_t *t;
    const param_desc_t *d;

    ui_power_on();
    t = &trk[0];
    bad += check("BEND is automation-only and a motion target",
                 param_auto_only(MFX_BEND) && !param_lock_only(MFX_BEND) && motion_param(MFX_BEND) &&
                 !param_auto_only(MSEQ_PITCH) && !param_auto_only(P_REV));
    d = motion_target_desc(t, MFX_BEND);
    bad += check("BEND's descriptor is BEND, -32..32",
                 d && str_eq(d->label, "BEND") && d->min == -32 && d->max == 32);
    bad += check("BEND cannot be a lock", motion_set_lock(t, 2, MFX_BEND, 1) == 1 && !motion.count);
    bad += check("BEND accepts an automation event in range",
                 !motion_set_event(t, 2, MFX_BEND, 32) && motion_find(t, 2, MFX_BEND) >= 0);
    return bad;
}

static int dead_engine_contract(void)
{
    int bad = 0, ok;
    track_t *t;
    uint32_t i, j, sel, page = NPAGES;

    ui_power_on();
    t = &trk[0];
    set_engine_of(t, 2);                             /* PHASE: E8 is its empty "-" card */
    t->engine = t->eng_req;
    track_defaults_steps(t);

    pk_build_mdst(t, MD_OFF, &sel);
    ok = 1;
    for (i = 0; i < pk_n; i++)
        ok &= pk_rows[i].id != MD_E1 + 7;
    for (i = 0; i < 7u; i++) {
        uint32_t found = 0;
        for (j = 0; j < pk_n; j++)
            found |= pk_rows[j].id == MD_E1 + i;
        ok &= found;
    }
    bad += check("MOD DST hides a dead engine slot (PHASE E8) and keeps E1..E7", ok);

    pk_build_auto(t, MSEQ_PITCH, NSTEP, &sel);
    ok = 1;
    for (i = 0; i < pk_n; i++)
        ok &= pk_rows[i].id != P_E7;
    for (i = 0; i < 7u; i++) {
        uint32_t found = 0;
        for (j = 0; j < pk_n; j++)
            found |= pk_rows[j].id == P_E0 + i;
        ok &= found;
    }
    bad += check("AUTOMATION hides a dead engine parameter (PHASE E8) and keeps E1..E7", ok);

    for (i = 0; i < NPAGES; i++)
        if (PAGES[i].scope == SC_ENGINE && PAGES[i].id[0] == P_E4 && PAGES[i].id[3] == P_E7) {
            page = i;
            break;
        }
    ui.plk_src = (uint8_t)(page + 1u);
    bad += check("a held step locks no dead engine parameter (PHASE EDIT 2 KNOB 4)",
                 page < NPAGES && lock_id(3) == 0xFFu && lock_id(0) == P_E4);
    ui.plk_src = 0;
    return bad;
}

int main(void)
{
    int bad;
    ui_power_on();
    bad = id_classification() + pitch_contract() + pitch_kit_contract() + mfx_contract() + tape_contract() +
          ev_contract() + pg_contract() + bend_contract() + bend_lane_contract() + sweep_contract() +
          motion_id_contract() + dead_engine_contract();
    printf("%s\n", bad ? "PARAM CONTRACT TEST FAILED" : "PITCH / special-id parameter contract tests passed");
    return bad;
}
