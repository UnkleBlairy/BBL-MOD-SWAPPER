/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
 * Real sequencer/project/UI sources: motion lifecycle and compact migration. */
#define UI_TEST_NO_MAIN 1
#include "ui_test.c"

static int motion_recording(void)
{
    int bad = 0; ui_power_on(); track_t *t = &trk[0];
    t->p[P_REV] = 23; song.sel = 0; song.rec = 1;
    seq_start(); seq_tick(t, CTL); /* first real step */
    t->p[P_REV] = 92;
    bad += check("motion records the selected armed track at its current step", !motion_capture(t, P_REV, 92) &&
        motion.count == 1u && motion.event[0].place == 0u && motion.event[0].value == 92);
    t->p[P_REV] = 110; motion_capture(t, P_REV, 110);
    bad += check("same step/parameter overwrites rather than consuming capacity", motion.count == 1u && motion.event[0].value == 110);
    bad += check("sounding values never replace the original patch base", t->p[P_REV] == 110 && motion_base_value(t, P_REV) == 23);
    project_t q; project_store_t packed;
    project_capture(&q);
    bad += check("project snapshot saves base + independent events while sounding", q.t[0].p[P_REV] == 23 && q.motion.event[0].value == 110 &&
        proj_pack(&packed, &q) && sizeof packed == 4864u);  /* FUN21: project grew */
    seq_stop();
    bad += check("stop before another step restores the original parameter", t->p[P_REV] == 23);
    seq_start(); seq_tick(t, CTL);
    bad += check("recorded motion plays back at step zero", t->p[P_REV] == 110);
    motion_set_enabled(t, 0);
    bad += check("bypass restores base without deleting automation", t->p[P_REV] == 23 && motion_count(t) == 1u && !motion_enabled(t));
    motion_set_enabled(t, 1); motion_step(t, 0, &motion, 1);
    song.rec = 0; t->p[P_REV] = 37; motion_capture(t, P_REV, 37); seq_stop();
    bad += check("manual edits outside recording become the new base", t->p[P_REV] == 37);
    song.rec = 3; seq_start(); seq_tick(t, CTL);
    trk[1].p[P_REV] = 45; motion_capture(&trk[1], P_REV, 45);
    bad += check("only the selected track captures knob motion", motion_count(&trk[1]) == 0u);
    bad += check("transport and engine-switch parameters cannot be captured", !motion_param(P_SLEN) && !motion_param(P_AMODE) &&
        motion_set_event(t, 0, P_SLEN, 8) == 1);
    bad += check("#222 SLICER pattern / rate / depth are automatable (not MODE)",
        motion_param(P_SLPAT) && motion_param(P_SLRATE) && motion_param(P_SLDEPTH) && !motion_param(P_SLCR));
    bad += check("CHRD / VOIC are automatable",
        motion_param(P_CHRD) && motion_param(P_VOIC) && motion_set_event(t, 1, P_CHRD, CH_DIA3) == 0 &&
        motion_set_event(t, 1, P_VOIC, VC_OPEN) == 0);
    bad += check("insert continuous + MIX lockable (ORDER not)",
        motion_param(P_ED_FX) && motion_param(P_DIST) &&
        motion_param(P_IDMIX) && motion_param(P_IFCUT) && motion_param(P_IFRES) && motion_param(P_IFMIX) &&
        motion_param(P_ICBITS) && motion_param(P_ICRATE) && motion_param(P_ICLPF) && motion_param(P_ICMIX) &&
        motion_param(P_IPRATE) && motion_param(P_IPDEP) && motion_param(P_IPFBK) && motion_param(P_IPMIX) &&
        motion_param(P_ILRATE) && motion_param(P_ILDEP) && motion_param(P_ILMIX) &&
        motion_param(P_IHRATE) && motion_param(P_IHDEP) && motion_param(P_IHMIX) &&
        !motion_param(P_IORD));
    seq_stop(); motion_clear(t);
    t->p[P_REV] = 42; song.rec = 1; seq_start(); seq_tick(t, CTL);
    motion_clear(t); t->p[P_REV] = 70; motion_capture(t, P_REV, 70); seq_stop();
    bad += check("clearing then recording mid-play keeps the correct new base", t->p[P_REV] == 42);
    return bad;
}
static int motion_capacity(void)
{
    int bad = 0; ui_power_on();
    for (uint32_t i = 0; i < MOTION_MAX; i++)          /* (255: four ids over the 64 steps) */
        bad += motion_set_event(&trk[0], i % NSTEP, i < NSTEP ? P_REV : i < 2u * NSTEP ? P_DLY :
                                i < 3u * NSTEP ? P_PAN : P_LEVEL, (int16_t)(i % NSTEP));
    motion_store_t saved = motion;
    bad += check("full event pool refuses append without overwriting earlier events", motion_set_event(&trk[1], 0, P_REV, 90) == 2 &&
        !memcmp(&motion, &saved, sizeof saved));
    bad += check("full pool still permits a targeted overwrite", !motion_set_event(&trk[0], 12, P_REV, 100) && motion.count == MOTION_MAX);
    motion_delete_event(&trk[0], 12, P_REV);
    bad += check("deleting one event releases one slot", motion.count == MOTION_MAX - 1u && !motion_set_event(&trk[1], 0, P_REV, 90));
    saved = motion; motion_store_t invalid = motion; invalid.on = 1u << NTRK;   /* (a track that is not there) */
    bad += check("invalid restore leaves the pool intact", motion_replace_track(&trk[0], &invalid) != 0 && !memcmp(&motion, &saved, sizeof saved));
    motion_clear(&trk[0]);
    bad += check("track clear keeps every other track's events", motion.count == 1u && motion.event[0].place >> 6 == 1u);
    return bad;
}
static int probability_playback(void)
{
    int bad = 0; ui_power_on(); track_t *t = &trk[0];
    step_t s = {{60, 64, 0, 0}, 2, ST_NOTE, 0, 90, 1u << DV_KICK, 0, 0};
    bad += check("zero-initialized probability remains legacy 100 percent", step_chance(&s) == 100u);
    step_set_chance(&s, 0); seq_step(t, &s, 0, div_samples(2), 0);
    bad += check("zero percent suppresses the whole chord and drum hits", step_chance(&s) == 0u && !t->seq_n);
    step_set_chance(&s, 100); seq_step(t, &s, 0, div_samples(2), 0);
    bad += check("100 percent plays all chord notes and drum hits", t->seq_n == 3u);
    seq_release(t); step_set_chance(&s, 50); uint32_t heard = 0;
    for (uint32_t i = 0; i < 1000u; i++) { seq_step(t, &s, 0, div_samples(2), 0); heard += t->seq_n != 0; seq_release(t); }
    bad += check("chance is evaluated each repeat with one decision per step", heard > 350u && heard < 650u);
    return bad;
}
static int compact_project(void)
{
    int bad = 0; ui_power_on(); track_t *t = &trk[0];
    t->step[3] = (step_t){{60, 67}, 2, ST_NOTE, SF_ACCENT, 110, 0x81, 0x80, 0};
    step_set_chance(&t->step[3], 25); t->p[P_FM1_LEVEL] = 80; t->p[P_ED_FLT] = -50;
    motion_set_event(t, 3, P_REV, 110);
    project_t before, after; project_store_t packed, corrupt, again;
    project_capture(&before);
    /* FUN21: project grew from 4096 to 4864 bytes */
    bad += check("FUN21 fits the retained and flash extent", sizeof(proj_slot) == 4u * 4864u && proj_pack(&packed, &before));
    bad += check("FUN10 round trip preserves signed values/FM params/probability/motion", proj_import(&after, &packed, sizeof packed) &&
        proj_pack(&again, &after) && !memcmp(&packed, &again, sizeof packed) &&
        after.t[0].p[P_ED_FLT] == -50 && after.t[0].p[P_FM1_LEVEL] == 80 &&
        step_chance(&after.t[0].step[3]) == 25u && after.motion.count == 1u && after.motion.event[0].value == 110);
    corrupt = packed; corrupt.raw[112] ^= 1u;
    bad += check("FUN7 torn or corrupted payload is refused", !proj_import(&after, &corrupt, sizeof corrupt));
    corrupt = packed; corrupt.raw[68] = 255; uint32_t sum = proj_hash(corrupt.raw, sizeof corrupt - 4u);
    memcpy(corrupt.raw + sizeof corrupt - 4u, &sum, 4);
    bad += check("compact parameter range is validated even with a correct hash", !proj_import(&after, &corrupt, sizeof corrupt));
    corrupt = packed; uint32_t probability_byte = 68u + P_COUNT + 1u + 2u + 8u; corrupt.raw[probability_byte] = 127;
    sum = proj_hash(corrupt.raw, sizeof corrupt - 4u); memcpy(corrupt.raw + sizeof corrupt - 4u, &sum, 4);
    bad += check("invalid probability is refused even with a correct hash", !proj_import(&after, &corrupt, sizeof corrupt));
    project_save(1); motion_clear(t); t->p[P_FM1_LEVEL] = 127; step_set_chance(&t->step[3], 100);
    project_load(1);
    bad += check("actual project save/load restores motion, chance and operator settings", motion_count(t) == 1u &&
        step_chance(&t->step[3]) == 25u && t->p[P_FM1_LEVEL] == 80);
    return bad;
}
/* a project of 89 parameters (before the chord keys P_CHRD / P_VOIC; today's FUN9 frame): the engine's values at
 * 81..88, motion ids from 81 on for E0..E7 (m: its events as that firmware numbered them) */
static void pack_fun7_89(project_store_t *out, const project_t *q, const motion_store_t *m)
{
    /* create an old-format (3840 B) FUN10 project with 89 parameters */
    uint8_t *b = out->raw; uint32_t pos = 68u, t, i, magic = PROJ_MAGIC_V10, size = PROJ_STORE_OLD, sum;
    memset(out, 0, sizeof *out); memcpy(b, &magic, 4); memcpy(b + 4, &size, 4);
    memcpy(b + 8, q->g, sizeof q->g); b[62] = q->sel; b[63] = q->parts; b[64] = q->phys; b[66] = 89;
    for (t = 0; t < NTRK; t++) {
        for (i = 0; i < 89u; i++) b[pos++] = (uint8_t)(q->t[t].p[i < 81u ? i : P_E0 + i - 81u] + 64);
        b[pos++] = q->t[t].engine; b[pos++] = q->t[t].preset;
        for (i = 0; i < NSTEP; i++) {
            const step_t *s = &q->t[t].step[i];
            for (uint32_t j = 0; j < 4u; j++) b[pos++] = (uint8_t)(step_note(s, j) & 127u);
            b[pos++] = (uint8_t)(s->n | s->time << 3 | step_fl(s) << 5);
            b[pos++] = s->vel; b[pos++] = s->hit; b[pos++] = s->acc; b[pos++] = s->probability;
        }
    }
    memcpy(b + pos, &q->chain, sizeof q->chain); pos += sizeof q->chain;
    b[pos] = m->count; b[pos + 1u] = m->on;
    for (i = 0; i < m->count; i++) {
        b[pos + 4u + 3u * i] = m->event[i].place;
        b[pos + 5u + 3u * i] = m->event[i].param;
        b[pos + 6u + 3u * i] = (uint8_t)m->event[i].value;
    }
    sum = proj_hash(b, PROJ_STORE_OLD - 4u); memcpy(b + PROJ_STORE_OLD - 4u, &sum, 4);
}
static int fun7_89(void)
{
    int bad = 0, ok; ui_power_on(); track_t *t = &trk[0];
    project_t before, after; project_store_t old, again; motion_store_t m;
    uint32_t i, k;
    for (k = 0; k < NTRK; k++)
        for (i = 0; i < 8u; i++) trk[k].p[P_E0 + i] = (int16_t)(ENGINES[trk[k].eng_req]->edit[i].min + (int16_t)(k + i) %
            (ENGINES[trk[k].eng_req]->edit[i].max - ENGINES[trk[k].eng_req]->edit[i].min + 1));
    t->p[P_FM1_ATK] = 33; t->p[P_REV] = 20;
    memset(&t->step[2], 0, sizeof t->step[2]);
    t->step[2] = (step_t){{60, 64, 67}, 3, ST_NOTE, 0, 100};
    step_set_ratchet(&t->step[2], 1u);   /* clear padding bit left by bitfield assignment */
    project_capture(&before);
    for (k = 0; k < NTRK; k++)
        if (before.t[k].engine == ENGI_ANALOG) {         /* 3.5: E8 / FM3 are INT / MORPH / DRIFT, 0 before */
            before.t[k].p[P_E7] = 0;
            before.t[k].p[P_MORPH] = 0;
            before.t[k].p[P_DRIFT] = 0;
            before.t[k].p[P_WAVE2] = 0;      /* SAME */
        }
    memset(&m, 0, sizeof m);                                       /* as the 89-parameter firmware numbered them */
    m.count = 3; m.on = 1;
    m.event[0] = (motion_event_t){3, P_REV, 90};
    m.event[1] = (motion_event_t){5, 81, 40};                      /* its P_E0 (81) */
    m.event[2] = (motion_event_t){6, 61, 20};                      /* FM OP1 ATK: 61 then and now */
    pack_fun7_89(&old, &before, &m);
    ok = proj_import(&after, &old, PROJ_STORE_OLD);  /* old 3840-byte format */
    for (k = 0; ok && k < NTRK; k++) {
        for (i = 0; i < 8u; i++) {
            int16_t want = before.t[k].p[P_E0 + i];
            if (i == 5u && ENGINES[after.t[k].engine] == &ENG_FM6)
                want = 0;                              /* 3.6: old VMOD moved into the patch */
            ok &= after.t[k].p[P_E0 + i] == want;
        }
        for (i = 0; i < 81u; i++)
            ok &= after.t[k].p[i] == (i == P_CHOR ? (int16_t)(64 + 6 + (7 << 3)) : before.t[k].p[i]);
        ok &= after.t[k].p[P_CHRD] == 0 && after.t[k].p[P_VOIC] == 0;
        for (i = P_LN0; i <= P_LN7; i++) ok &= after.t[k].p[i] == 127;
    }
    /* DEBUG removed */
    bad += check("89 parameters: E0..E7 at P_E0.., the chord keys OFF / CLOSE, lanes 100 %, the rest in place", ok &&
        after.t[0].p[P_FM1_ATK] == 33 && !memcmp(after.t[0].step, before.t[0].step, sizeof before.t[0].step));
    bad += check("  its motion: E0 (81) -> P_E0, REV kept; old id 61 (FM OP1 ATK) dropped, no BEND marker",
        after.motion.count == 2u && after.motion.event[0].param == P_REV && after.motion.event[1].param == P_E0 &&
        after.motion.event[1].value == 40);
    bad += check("  written again (P_COUNT parameters): the same project", proj_pack(&old, &after) && old.raw[66] == P_COUNT &&
        proj_import(&before, &old, sizeof old) && proj_pack(&again, &before) && !memcmp(&old, &again, sizeof old));
    pack_fun7_89(&old, &before, &m);                                /* SONG: a slot of the old firmware */
    memcpy(&proj_slot[2], &old, sizeof old);
    proj_fetch(2);                                                  /* 3.10: refresh summary / used bit from the slot */
    chain_config.count = 1; chain_config.row[0] = chain_row_of(2, 1);
    ok = chain_prepare() == 0;
    bad += check("  SONG: an 89-parameter slot's motion plays at today's ids (E0 at P_E0)", ok &&
        chain.source[2].motion.count == 2u && chain.source[2].motion.event[1].param == P_E0);
    seq_stop(); chain_config.count = 0; chain.armed = 0;
    m.event[1].param = 82;                                          /* (any id P_E0 .. P_E7 of then moves up) */
    pack_fun7_89(&old, &before, &m);
    bad += check("  E1 (82) -> P_E1", proj_import(&after, &old, PROJ_STORE_OLD) && after.motion.event[1].param == P_E1);
    return bad;
}
static int loads_and_song(void)
{
    int bad = 0; ui_power_on(); track_t *t = &trk[0];
    int16_t v;
    uint32_t e0 = t->eng_req, e1 = e0 == ENGI_DRUM ? ENGI_FM6 : ENGI_DRUM;
    t->p[P_REV] = 21; motion_set_event(t, 0, P_REV, 100); t->step[0] = (step_t){{60}, 1, ST_NOTE, 0, 100};
    motion_set_lock(t, 1, P_E0, motion_base_value(t, P_E0));
    apply_preset_to(t, 1);
    bad += check("1.1.5: a sound load of the same engine keeps the motion (both kinds, the engine's own E1 too), the pattern",
                 motion_count(t) == 2u && motion_lock_get(t, 1, P_E0, &v) && motion_enabled(t) && step_note(&t->step[0], 0) == 60);
    undo_swap();                                   /* (back to the sound before it: REV 21) */
    set_engine_of(t, e1);
    bad += check("  another engine: the motion on the common parameters (REV) stays, the engine's own (E1) goes, PLAY ON",
                 motion_count(t) == 1u && !motion_lock_get(t, 1, P_E0, &v) && motion_enabled(t) && step_note(&t->step[0], 0) == 60);
    undo_swap(); bad += check("sound undo restores the original motion pool and base", motion_count(t) == 2u && t->p[P_REV] == 21 &&
                              t->eng_req == e0);
    undo_swap(); bad += check("sound redo restores the loaded motion state", motion_count(t) == 1u && t->eng_req == e1);
    undo_swap(); project_save(0);
    t->p[P_REV] = 43; step_set_note(&t->step[0], 0, 72); chain_config.count = 1; chain_config.row[0] = chain_row_of(0, 1);
    bad += check("song preparation imports saved motion alongside steps", chain_prepare() == 0 && chain.source[0].motion.count == 2u);
    seq_start(); seq_tick(t, CTL);
    bad += check("song plays saved automation with current instruments", chain.running && t->p[P_REV] == 100 && step_note(&t->step[0], 0) == 72);
    seq_stop(); bad += check("song stop restores current base and editable pattern", t->p[P_REV] == 43 && step_note(&t->step[0], 0) == 72);
    return bad;
}
static int repeat_mode(void)
{
    int bad = 0; ui_power_on(); track_t *t = &trk[0];
    t->p[P_AMODE] = 6; t->p[P_AOCT] = 4; t->p[P_APROB] = 127;
    arp_add(t, 72); arp_add(t, 60);
    arp_tick(t, CTL);
    bad += check("REPEAT retriggers the last played note without octave traversal", t->arp_note == 60);
    t->arp_pos = 0xFFFFFFF; arp_tick(t, CTL);
    bad += check("REPEAT remains on the same note on the next pulse", t->arp_note == 60);
    arp_remove(t, 60); arp_remove(t, 72); arp_tick(t, CTL);
    bad += check("REPEAT releases after the last held key is released", !t->nheld && !t->arp_note);
    t->p[P_AHOLD] = 1; arp_add(t, 65); arp_remove(t, 65); t->arp_pos = 0xFFFFFFF; arp_tick(t, CTL);
    bad += check("REPEAT supports ARP HOLD", t->nheld == 1u && t->arp_note == 65);
    return bad;
}

/* 1.2 (Discussion #95): the ARP modes appended after REPEAT (seq.c AM_*), each over a 3- and a 4-note chord, OCT,
 * ORD PLAY, HOLD, REPEAT switched in and out, WALK's random steps the same from the same seed */
static void arp_fresh(track_t *t, int32_t mode, int32_t oct, const uint8_t *notes, uint32_t n)
{
    uint32_t i;
    if (t->arp_note)
        arp_off(t);
    t->nheld = 0; t->arp_phys = 0;
    t->p[P_AMODE] = (int16_t)mode; t->p[P_AOCT] = (int16_t)oct; t->p[P_APROB] = 127;
    for (i = 0; i < n; i++)
        arp_add(t, notes[i]);
}

/* PLAY / Start snaps the arp to the seq: mid-cycle free-run then seq_start → first note again */
static int arp_play_sync(void)
{
    static const uint8_t CEG[3] = {60, 64, 67};
    int bad = 0; ui_power_on(); track_t *t = &trk[0];
    arp_fresh(t, AM_UP, 1, CEG, 3);
    t->arp_pos = 0xFFFFFFF; arp_tick(t, CTL);          /* C */
    t->arp_pos = 0xFFFFFFF; arp_tick(t, CTL);          /* E — mid cycle */
    bad += check("arp free-runs past the first note before PLAY", t->arp_note == 64 && t->arp_idx != 0xFFFFFFFFu);
    seq_start();
    bad += check("seq_start resets arp phase with the seq", t->arp_pos == 0xFFFFFFF && t->arp_idx == 0xFFFFFFFFu);
    arp_tick(t, CTL);
    bad += check("first arp pulse after PLAY is the pattern's first note", t->arp_note == 60);
    seq_stop();
    return bad;
}
static int arp_plays(track_t *t, const uint8_t *want, uint32_t n)   /* the next n steps play these notes */
{
    uint32_t i;
    int ok = 1;
    for (i = 0; i < n; i++) {
        t->arp_pos = 0xFFFFFFF;
        arp_tick(t, CTL);
        ok &= t->arp_note == want[i] && !t->arp_ch[0];
        if (t->arp_note != want[i])
            printf("    step %u: %u, not %u\n", (unsigned)i, (unsigned)t->arp_note, (unsigned)want[i]);
    }
    return ok;
}
static int arp_new_modes(void)
{
    static const uint8_t CEG[3] = {60, 64, 67}, CEGB[4] = {60, 64, 67, 71}, GCE[3] = {67, 60, 64};
    static const uint8_t FIVE[5] = {60, 64, 67, 71, 74};
    int bad = 0, ok;
    uint32_t i, k;
    uint8_t a[32], b[32];
    track_t *t;
    ui_power_on();
    t = &trk[0];
    ok = TP[P_AMODE].max == 15 && str_eq(TP[P_AMODE].names[6], "REPEAT") && str_eq(TP[P_AMODE].names[7], "DNUP") &&
         str_eq(TP[P_AMODE].names[8], "UP+8") && str_eq(TP[P_AMODE].names[9], "CONV") &&
         str_eq(TP[P_AMODE].names[10], "DIVG") && str_eq(TP[P_AMODE].names[11], "PINKY") &&
         str_eq(TP[P_AMODE].names[12], "THUMB") && str_eq(TP[P_AMODE].names[13], "WALK") &&
         str_eq(TP[P_AMODE].names[14], "CHORD") && str_eq(TP[P_AMODE].names[15], "DRONE");
    for (i = 0; i <= 15u; i++)
        ok &= strlen(TP[P_AMODE].names[i]) <= 6u;
    bad += check("ARP modes: OFF..REPEAT keep their numbers, DNUP..CHORD..DRONE appended (<= 6 chars)", ok);
    /* the modes before 1.2 play as they did */
    arp_fresh(t, AM_UP, 1, CEG, 3);   ok = arp_plays(t, (const uint8_t[]){60, 64, 67, 60}, 4);
    arp_fresh(t, AM_DN, 1, CEG, 3);   ok &= arp_plays(t, (const uint8_t[]){67, 64, 60, 67}, 4);
    arp_fresh(t, AM_UPDN, 1, CEG, 3); ok &= arp_plays(t, (const uint8_t[]){60, 64, 67, 64, 60}, 5);
    bad += check("ARP UP, DN, UPDN as before", ok);
    /* 1.2: ORD plays the notes in the order pressed (it played as UP before), across OCT, ARP 2's ORD NOTE or PLAY */
    arp_fresh(t, AM_ORD, 1, GCE, 3);  ok = arp_plays(t, (const uint8_t[]){67, 60, 64, 67}, 4);
    arp_fresh(t, AM_ORD, 2, GCE, 3);  ok &= arp_plays(t, (const uint8_t[]){67, 60, 64, 79, 72, 76, 67}, 7);
    arp_fresh(t, AM_ORD, 1, CEG, 3);  ok &= arp_plays(t, (const uint8_t[]){60, 64, 67, 60}, 3);
    t->p[P_AORDER] = 1;
    arp_fresh(t, AM_ORD, 1, GCE, 3);  ok &= arp_plays(t, (const uint8_t[]){67, 60, 64}, 3);
    t->p[P_AORDER] = 0;
    arp_fresh(t, AM_ORD, 1, GCE, 3);  arp_remove(t, 60); arp_add(t, 62);   /* C let go, D pressed: G E D */
    ok &= arp_plays(t, (const uint8_t[]){67, 64, 62, 67}, 4);
    bad += check("ARP ORD (1.2): G C E pressed play G C E (not C E G), across OCT 2, either ORD switch; a new note last", ok);
    arp_fresh(t, AM_DNUP, 1, CEG, 3);  ok = arp_plays(t, (const uint8_t[]){67, 64, 60, 64, 67, 64}, 6);
    arp_fresh(t, AM_DNUP, 1, CEGB, 4); ok &= arp_plays(t, (const uint8_t[]){71, 67, 64, 60, 64, 67, 71}, 7);
    arp_fresh(t, AM_DNUP, 2, CEG, 3);  ok &= arp_plays(t, (const uint8_t[]){79, 76, 72, 67, 64, 60, 64, 67, 72, 76, 79}, 11);
    bad += check("ARP DNUP: G E C E; B G E C E G for 4; across OCT 2", ok);
    arp_fresh(t, AM_UP8, 1, CEG, 3);  ok = arp_plays(t, (const uint8_t[]){60, 64, 67, 72, 60}, 5);
    arp_fresh(t, AM_UP8, 1, CEGB, 4); ok &= arp_plays(t, (const uint8_t[]){60, 64, 67, 71, 72, 60}, 6);
    arp_fresh(t, AM_UP8, 2, CEG, 3);  ok &= arp_plays(t, (const uint8_t[]){60, 64, 67, 72, 76, 79, 84, 60}, 8);
    t->p[P_AORDER] = 1;                               /* ORD PLAY: as played, G C E, then G an octave up */
    arp_fresh(t, AM_UP8, 1, GCE, 3);  ok &= arp_plays(t, (const uint8_t[]){67, 60, 64, 79, 67}, 5);
    t->p[P_AORDER] = 0;
    bad += check("ARP UP+8: C E G C'; C E G B C'; OCT 2 ends on C''; ORD PLAY: the first played an octave over the top", ok);
    arp_fresh(t, AM_CONV, 1, CEG, 3);  ok = arp_plays(t, (const uint8_t[]){60, 67, 64, 60}, 4);
    arp_fresh(t, AM_CONV, 1, CEGB, 4); ok &= arp_plays(t, (const uint8_t[]){60, 71, 64, 67, 60}, 5);
    arp_fresh(t, AM_CONV, 2, CEG, 3);  ok &= arp_plays(t, (const uint8_t[]){60, 79, 64, 76, 67, 72, 60}, 7);
    arp_fresh(t, AM_DIVG, 1, CEG, 3);  ok &= arp_plays(t, (const uint8_t[]){64, 67, 60, 64}, 4);
    arp_fresh(t, AM_DIVG, 1, CEGB, 4); ok &= arp_plays(t, (const uint8_t[]){67, 64, 71, 60, 67}, 5);
    bad += check("ARP CONV: C G E, C B E G (outside in), OCT 2; DIVG: E G C, G E B C (inside out)", ok);
    arp_fresh(t, AM_PINKY, 1, CEG, 3);  ok = arp_plays(t, (const uint8_t[]){60, 67, 64, 67, 60}, 5);
    arp_fresh(t, AM_PINKY, 1, CEGB, 4); ok &= arp_plays(t, (const uint8_t[]){60, 71, 64, 71, 67, 71, 60}, 7);
    arp_fresh(t, AM_PINKY, 2, CEG, 3);  ok &= arp_plays(t, (const uint8_t[]){60, 79, 64, 79, 67, 79, 72, 79, 76, 79, 60}, 11);
    arp_fresh(t, AM_THUMB, 1, CEG, 3);  ok &= arp_plays(t, (const uint8_t[]){60, 64, 60, 67, 60}, 5);
    arp_fresh(t, AM_THUMB, 1, CEGB, 4); ok &= arp_plays(t, (const uint8_t[]){60, 64, 60, 67, 60, 71, 60}, 7);
    arp_fresh(t, AM_THUMB, 1, CEG, 1);  ok &= arp_plays(t, (const uint8_t[]){60, 60, 60}, 3);   /* (one note) */
    bad += check("ARP PINKY: C G E G, C B E B G B, the OCT 2 top; THUMB: C E C G, C E C G C B; one note", ok);
    /* CHORD: the held notes together, an octave up each step through OCT; the first 4 of more */
    arp_fresh(t, AM_CHORD, 2, CEG, 3);
    ok = 1;
    for (i = 0; i < 4u; i++) {
        uint32_t o = 12u * (i & 1u);
        t->arp_pos = 0xFFFFFFF;
        arp_tick(t, CTL);
        ok &= t->arp_note == 60u + o && t->arp_ch[0] == 64u + o && t->arp_ch[1] == 67u + o && !t->arp_ch[2];
    }
    arp_fresh(t, AM_CHORD, 1, FIVE, 5);
    t->arp_pos = 0xFFFFFFF;
    arp_tick(t, CTL);
    ok &= t->arp_note == 60u && t->arp_ch[0] == 64u && t->arp_ch[1] == 67u && t->arp_ch[2] == 71u;
    t->arp_off = 1;                                    /* its gate ends: all four end */
    arp_tick(t, 2);
    ok &= !t->arp_note && !t->arp_ch[0] && !t->arp_ch[1] && !t->arp_ch[2];
    arp_fresh(t, AM_CHORD, 1, CEG, 3);
    t->arp_pos = 0xFFFFFFF;
    arp_tick(t, CTL);
    arp_remove(t, 60); arp_remove(t, 64); arp_remove(t, 67);
    arp_tick(t, CTL);                                  /* let go: the chord ends */
    ok &= !t->nheld && !t->arp_note && !t->arp_ch[0] && !t->arp_ch[1];
    bad += check("ARP CHORD: C E G together, then an octave up (OCT 2); 5 held: the first 4; the gate and a release end them all", ok);
    /* WALK: from the bottom, one place up or down each step, inside the list; the same from the same seed */
    ok = 1;
    for (k = 0; k < 2u; k++) {
        rng_state = 0x2468ACEu;
        arp_fresh(t, AM_WALK, 2, CEGB, 4);             /* the list: C E G B C' E' G' B' */
        for (i = 0; i < 32u; i++) {
            t->arp_pos = 0xFFFFFFF;
            arp_tick(t, CTL);
            (k ? b : a)[i] = t->arp_note;
        }
    }
    ok &= a[0] == 60u && !memcmp(a, b, sizeof a);
    {
        static const uint8_t L[8] = {60, 64, 67, 71, 72, 76, 79, 83};
        uint32_t pos[32], up = 0, dn = 0;
        for (i = 0; i < 32u; i++) {
            for (pos[i] = 0; pos[i] < 8u && L[pos[i]] != a[i]; pos[i]++)
                ;
            ok &= pos[i] < 8u;
            if (i) {
                ok &= pos[i] == pos[i - 1u] + 1u || pos[i] + 1u == pos[i - 1u];
                up += pos[i] > pos[i - 1u];
                dn += pos[i] < pos[i - 1u];
            }
        }
        ok &= up > 4u && dn > 4u;
    }
    rng_state = 0x13579BDu;
    arp_fresh(t, AM_WALK, 2, CEGB, 4);
    for (i = 0; i < 32u; i++) {
        t->arp_pos = 0xFFFFFFF;
        arp_tick(t, CTL);
        b[i] = t->arp_note;
    }
    ok &= memcmp(a, b, sizeof a) != 0;
    arp_remove(t, 71); arp_remove(t, 67);              /* notes let go: back inside the shorter list */
    for (i = 0; i < 8u; i++) {
        t->arp_pos = 0xFFFFFFF;
        arp_tick(t, CTL);
        ok &= t->arp_note == 60 || t->arp_note == 64 || t->arp_note == 72 || t->arp_note == 76;
    }
    bad += check("ARP WALK: from the bottom, a step up or down each time inside the list; the same seed the same walk", ok);
    /* HOLD: the latched chord keeps its mode; a new chord replaces it */
    t->p[P_AHOLD] = 1;
    arp_fresh(t, AM_PINKY, 1, CEG, 3);
    arp_remove(t, 60); arp_remove(t, 64); arp_remove(t, 67);
    ok = t->nheld == 3u && arp_plays(t, (const uint8_t[]){60, 67, 64, 67}, 4);
    arp_add(t, 62); arp_add(t, 65); arp_add(t, 69);   /* D F A: replaces it, from the top of the pattern */
    ok &= t->nheld == 3u && arp_plays(t, (const uint8_t[]){62, 69, 65, 69}, 4);
    arp_remove(t, 62); arp_remove(t, 65); arp_remove(t, 69);
    t->p[P_AHOLD] = 0;
    bad += check("ARP HOLD: PINKY keeps playing the latched C E G; D F A replaces it", ok);
    /* REPEAT in and out: the last played note alone, then the new mode over the whole chord again */
    arp_fresh(t, AM_REPEAT, 2, CEG, 3);
    ok = arp_plays(t, (const uint8_t[]){67, 67}, 2);
    t->p[P_AMODE] = AM_THUMB;                          /* (its step count goes on: step 2 of C E C G C' ..) */
    ok &= arp_plays(t, (const uint8_t[]){60, 67, 60, 72}, 4);
    t->p[P_AMODE] = AM_REPEAT;
    ok &= arp_plays(t, (const uint8_t[]){67, 67}, 2);
    t->p[P_AMODE] = AM_CHORD;
    t->arp_pos = 0xFFFFFFF;
    arp_tick(t, CTL);
    ok &= t->arp_ch[0] && t->arp_ch[1];
    t->p[P_AMODE] = AM_REPEAT;
    ok &= arp_plays(t, (const uint8_t[]){67}, 1);      /* (CHORD's other notes ended) */
    bad += check("ARP REPEAT switched to THUMB and back, CHORD to REPEAT: each plays its own", ok);
    /* recording: CHORD writes its notes into one step, as the keys' chords (POLY) */
    song.sel = 0; song.rec = 1;
    t->p[P_VOICE] = V_POLY;
    for (i = 0; i < NSTEP; i++)
        t->step[i] = (step_t){0};
    seq_start();
    seq_tick(t, CTL);
    arp_fresh(t, AM_CHORD, 1, CEG, 3);
    t->arp_pos = 0xFFFFFFF;
    arp_tick(t, CTL);
    for (i = 0, k = 0; i < NSTEP; i++)
        k += t->step[i].n == 3u && step_note(&t->step[i], 0) == 60 && step_note(&t->step[i], 1) == 64 && step_note(&t->step[i], 2) == 67;
    seq_stop();
    song.rec = 0;
    bad += check("ARP CHORD recorded: C E G into one step", k == 1u);
    arp_fresh(t, AM_OFF, 1, CEG, 0);
    return bad;
}

/* DRONE: sustain all held notes (no RATE retrigger); OCT = fixed transpose; HOLD forced on + restored */
static int drone_sounds(const track_t *t, const uint8_t *want, uint32_t n)
{
    uint32_t i;
    if (!n)
        return !t->arp_note;
    if (t->arp_note != want[0])
        return 0;
    for (i = 1; i < n; i++)
        if (t->arp_ch[i - 1u] != want[i])
            return 0;
    for (; i < 16u; i++)
        if (t->arp_ch[i - 1u])
            return 0;
    return 1;
}
static int arp_drone_mode(void)
{
    static const uint8_t CEG[3] = {60, 64, 67};
    static const uint8_t SIX[6] = {60, 62, 64, 65, 67, 69};
    int bad = 0, ok;
    uint32_t i;
    track_t *t;
    ui_power_on();
    t = &trk[0];
    ok = TP[P_AMODE].max == 15 && str_eq(TP[P_AMODE].names[14], "CHORD") && str_eq(TP[P_AMODE].names[15], "DRONE") &&
         str_eq(TP[P_AMODE].names[6], "REPEAT") && param_turn(&TP[P_AMODE], 5, 1) == 7 &&
         param_turn(&TP[P_AMODE], 7, -1) == 5;
    bad += check("ARP DRONE appended; REPEAT kept at 6 but MODE knob skips it", ok);

    arp_fresh(t, AM_DRONE, 1, CEG, 3);
    arp_tick(t, CTL);
    ok = drone_sounds(t, CEG, 3);
    t->arp_off = 1;
    for (i = 0; i < 8u; i++)
        arp_tick(t, CTL);                              /* RATE / GATE would have retriggered or released */
    ok &= drone_sounds(t, CEG, 3);
    bad += check("ARP DRONE sustains C E G with no RATE retrigger or GATE release", ok);

    arp_fresh(t, AM_DRONE, 2, CEG, 3);
    arp_tick(t, CTL);
    ok = drone_sounds(t, (const uint8_t[]){72, 76, 79}, 3);
    bad += check("ARP DRONE OCT 2 is a fixed +12, not an octave walk", ok);

    arp_fresh(t, AM_DRONE, 1, SIX, 6);
    arp_tick(t, CTL);
    ok = drone_sounds(t, SIX, 6);
    bad += check("ARP DRONE sounds more than CHORD's 4 notes", ok);

    t->p[P_AHOLD] = 0;
    t->armp = AM_UP;
    t->aholdp = 0;
    t->p[P_AMODE] = AM_DRONE;
    events_block(CTL);
    ok = t->p[P_AHOLD] == 1;
    t->p[P_AMODE] = AM_UP;
    events_block(CTL);
    ok &= t->p[P_AHOLD] == 0;
    t->p[P_AHOLD] = 1;
    t->armp = AM_UP;
    t->aholdp = 1;
    t->p[P_AMODE] = AM_DRONE;
    events_block(CTL);
    t->p[P_AMODE] = AM_CHORD;
    events_block(CTL);
    ok &= t->p[P_AHOLD] == 1;
    bad += check("ARP DRONE forces HOLD on and restores the prior HOLD on leave", ok);

    /* key-up must not kill latched drone voices (input_off used to trk_note_off while HOLD kept held[]) */
    {
        uint32_t i, gated = 0;
        arp_fresh(t, AM_OFF, 1, CEG, 0);
        t->p[P_VOICE] = V_POLY;
        t->p[P_AMODE] = AM_DRONE;
        t->p[P_AHOLD] = 1;
        t->p[P_AOCT] = 1;
        t->p[P_APROB] = 127;
        input_on(t, 60, 100);
        input_on(t, 64, 100);
        arp_tick(t, CTL);
        input_off(t, 60);
        input_off(t, 64);
        arp_tick(t, CTL);
        ok = drone_sounds(t, (const uint8_t[]){60, 64}, 2) && t->nheld == 2u;
        for (i = 0; i < NVOICE; i++)
            gated += t->v[i].gate && (t->v[i].note == 60 || t->v[i].note == 64);
        ok &= gated >= 2u;
        bad += check("ARP DRONE keeps sounding after both keys are released (HOLD latch)", ok);
    }

    arp_fresh(t, AM_OFF, 1, CEG, 0);
    return bad;
}
/* ------------------------------------------------ 1.1 parameter locks --- */
/* the transport on to the next step of t (its seq_idx changes) */
static void lock_next(track_t *t)
{
    uint32_t i = t->seq_idx, n = 0;
    while (t->seq_idx == i && n++ < 100000u)
        seq_tick(t, CTL);
}
/* track 1 alone: 8 NOTE steps, REV 20, swing sw */
static track_t *lock_track(int32_t sw)
{
    track_t *t;
    uint32_t i;
    ui_power_on();
    t = &trk[0];
    track_defaults_steps(t);
    t->p[P_SLEN] = 8;
    t->p[P_SSWING] = (int16_t)sw;
    song.g[G_SWING] = 0;
    t->p[P_REV] = 20;
    for (i = 0; i < 8u; i++)
        t->step[i] = (step_t){{60}, 1, ST_NOTE, 0, 100};
    return t;
}
/* two passes from step 0: REV at each step's start as want[]; 1 = all as wanted */
static int lock_passes(track_t *t, const int16_t *want)
{
    uint32_t i, pass;
    seq_start();
    seq_tick(t, CTL);
    for (pass = 0; pass < 2u; pass++)
        for (i = 0; i < 8u; i++) {
            if (pass || i)
                lock_next(t);
            if (t->seq_idx != i || t->p[P_REV] != want[i]) {
                printf("motion:   pass %u step %u: REV %d, wanted %d\n", pass, i, t->p[P_REV], want[i]);
                return 0;
            }
        }
    return 1;
}
static int lock_playback(void)
{
    static const int16_t want[8] = {20, 20, 100, 20, 60, 60, 90, 60};   /* locks on 2, 6; automation on 4 */
    int bad = 0, ok;
    uint32_t n;
    track_t *t = lock_track(0);
    project_t q;
    ok = !motion_set_lock(t, 2, P_REV, 100) && !motion_set_event(t, 4, P_REV, 60) && !motion_set_lock(t, 6, P_REV, 90);
    bad += check("a lock is one of the shared 64 records, bit 7 of its id (MOTION_LOCK)", ok && motion.count == 3u &&
        motion.event[0].param == (P_REV | MOTION_LOCK) && motion.event[1].param == P_REV && motion_lock_count(t) == 2u &&
        motion_count(t) == 3u && motion_lock_steps(0) == ((1u << 2) | (1u << 6)));
    bad += check("lock: its value on its step only, back after it (the sound's own, or the automation held)",
        lock_passes(t, want));
    lock_next(t); lock_next(t); lock_next(t);
    project_capture(&q);
    bad += check("  a lock sounding: the sound's own value is the base, a project saves that", t->seq_idx == 2u &&
        t->p[P_REV] == 100 && motion_base_value(t, P_REV) == 20 && q.t[0].p[P_REV] == 20);
    motion_set_enabled(t, 0);
    bad += check("  AUTOMATION PLAY OFF: the sound's own value at once, the locks kept", t->p[P_REV] == 20 &&
        motion_lock_count(t) == 2u);
    motion_set_enabled(t, 1);
    lock_next(t); lock_next(t); lock_next(t); lock_next(t);
    seq_stop();
    bad += check("  STOP while a lock sounds puts the sound's own value back", t->p[P_REV] == 20);
    t = lock_track(100);
    motion_set_lock(t, 2, P_REV, 100); motion_set_event(t, 4, P_REV, 60); motion_set_lock(t, 6, P_REV, 90);
    bad += check("  with SWING 100: the same values step by step", lock_passes(t, want));
    seq_stop();
    t = lock_track(0);                                   /* the chance: a step that does not play applies no lock */
    motion_set_lock(t, 2, P_REV, 100);
    step_set_chance(&t->step[2], 0);
    {
        static const int16_t w0[8] = {20, 20, 20, 20, 20, 20, 20, 20};
        bad += check("  CHANCE 0 %: the step does not play, nor its lock", lock_passes(t, w0));
    }
    seq_stop();
    step_set_chance(&t->step[2], 100);
    {
        static const int16_t w1[8] = {20, 20, 100, 20, 20, 20, 20, 20};
        bad += check("  CHANCE 100 %: its lock", lock_passes(t, w1));
    }
    seq_stop();
    step_set_chance(&t->step[2], 50);                    /* the one roll: the lock with the notes, or neither */
    seq_start(); seq_tick(t, CTL);
    for (n = 0, ok = 1; n < 400u; n++) {
        lock_next(t);
        if (t->seq_idx == 2u)
            ok &= (t->p[P_REV] == 100) == (t->seq_n != 0u);
    }
    bad += check("  CHANCE 50 %: the lock applies exactly when the step's notes play", ok);
    seq_stop();
    t = lock_track(0);                                   /* RATCH x3: the lock over all its parts */
    motion_set_lock(t, 2, P_REV, 100);
    step_set_ratchet(&t->step[2], 3);
    seq_start(); seq_tick(t, CTL);
    lock_next(t); lock_next(t);
    {
        uint32_t v0 = vage;
        for (ok = t->seq_idx == 2u; t->seq_idx == 2u;) {
            ok &= t->p[P_REV] == 100;
            seq_tick(t, CTL);
        }
        bad += check("  RATCH x3: its 3 parts all with the lock, back at the next step", ok && vage - v0 >= 3u &&
            t->p[P_REV] == 20);
    }
    seq_stop();
    t = lock_track(0);                                   /* an engine parameter, read by the note-on */
    t->p[P_E4] = 10;
    motion_set_lock(t, 1, P_E4, 90);
    motion_set_lock(t, 1, P_E4, 300);                    /* (out of its range: refused, the lock as it was) */
    seq_start(); seq_tick(t, CTL); lock_next(t);
    bad += check("  an engine parameter: set at the step's start (before its notes), in its range", t->p[P_E4] == 90 &&
        t->seq_n == 1u);
    lock_next(t);
    bad += check("  .. and back at the next step", t->p[P_E4] == 10);
    seq_stop();
    return bad;
}
static int lock_edit(void)
{
    int bad = 0;
    int16_t v;
    track_t *t = lock_track(0);
    motion_set_event(t, 3, P_REV, 50);
    bad += check("a lock replaces an automation event of its step and id (one record, either kind)",
        !motion_set_lock(t, 3, P_REV, 70) && motion.count == 1u && motion_lock_get(t, 3, P_REV, &v) && v == 70);
    motion_set_event(t, 3, P_REV, 40);
    bad += check("  .. and back (an automation event over a lock)", motion.count == 1u && !motion_lock_count(t));
    motion_set_lock(t, 3, P_ATK, 9); motion_set_lock(t, 5, P_ATK, 9); motion_set_lock(&trk[1], 3, P_REV, 1);
    bad += check("clear a step's locks: its automation and the other steps' and tracks' stay",
        motion_clear_locks(t, 3) == 1u && motion.count == 3u && motion_lock_count(t) == 1u && motion_lock_count(&trk[1]) == 1u);
    bad += check("clear every step's locks (NSTEP)", motion_clear_locks(t, NSTEP) == 1u && !motion_lock_count(t) &&
        motion_count(t) == 1u);
    motion_delete_event(&trk[1], 3, P_REV);
    bad += check("delete an event deletes a lock too (either kind)", !motion_count(&trk[1]));
    return bad;
}
/* PITCH lock (3.2, MSEQ_PITCH): a chromatic semitone offset after the scale snap */
static int lock_pitch(void)
{
    int bad = 0, ok;
    track_t *t = lock_track(0);
    project_t before, after;
    project_store_t a;
    uint32_t n;
    t->p[P_QUANT] = QN_SEQ;                              /* ALL's quantising */
    t->p[P_SCALE] = 0;
    t->p[P_ROOT] = 0;
    motion_set_lock(t, 2, MSEQ_PITCH, 2);
    motion_set_lock(t, 4, MSEQ_PITCH, 7);
    motion_set_lock(t, 6, MSEQ_PITCH, -2);
    ok = motion.count == 3u && motion.event[0].param == (MSEQ_PITCH | MOTION_LOCK);
    seq_start();
    seq_tick(t, CTL);
    ok &= t->seq_notes[0] == 60u && !t->plk_pit;
    bad += check("PITCH lock: a lock-only id, stored in the shared records", ok);
    for (n = 0; n < 100000u && t->seq_idx != 2u; n++) lock_next(t);
    bad += check("  +2 semitones on C4 plays D4", t->plk_pit == 2 && t->seq_notes[0] == 62u);
    for (n = 0; n < 100000u && t->seq_idx != 4u; n++) lock_next(t);
    bad += check("  +7 semitones plays G4", t->plk_pit == 7 && t->seq_notes[0] == 67u);
    for (n = 0; n < 100000u && t->seq_idx != 6u; n++) lock_next(t);
    bad += check("  -2 semitones plays A#3", t->plk_pit == -2 && t->seq_notes[0] == 58u);
    seq_stop();
    t->p[P_QUANT] = QN_OFF;                              /* MAP OFF: the same chromatic offset */
    motion_set_lock(t, 2, MSEQ_PITCH, 3);
    seq_start();
    for (n = 0; n < 100000u && t->seq_idx != 2u; n++) lock_next(t);
    bad += check("  MAP OFF: +3 is three semitones (D#4)", t->seq_notes[0] == 63u);
    seq_stop();
    project_capture(&before);
    ok = proj_pack(&a, &before) && proj_import(&after, &a, sizeof a) &&
         after.motion.event[0].param == (MSEQ_PITCH | MOTION_LOCK) && after.motion.event[0].value == 3;
    bad += check("  the lock survives the project round trip (FUN16, id 127)", ok);
    return bad;
}

static int pitch_lock_only(void)
{
    int bad = 0;
    track_t *t = lock_track(0);
    motion_store_t invalid;
    int16_t value;
    bad += check("PITCH cannot be written as automation", motion_set_event(t, 2, MSEQ_PITCH, 7) == 1 && !motion.count);
    motion_clear(t);
    motion_set_event(t, 2, P_REV, 50);
    bad += check("changing an automation row to PITCH makes it a lock",
                 !motion_move(t, 0, 2, MSEQ_PITCH, 7) && motion_lock_get(t, 2, MSEQ_PITCH, &value) && value == 7);
    invalid = motion;
    invalid.event[0].param = MSEQ_PITCH;
    bad += check("stored PITCH automation is rejected", !motion_valid(&invalid));
    motion_clear(t);
    motion_set_lock(t, 2, MSEQ_PITCH, 7);
    ev_follow(EVC(EVK_REC, 0));
    ev_oct();
    bad += check("OCT+ keeps PITCH as a lock", motion_lock_get(t, 2, MSEQ_PITCH, &value) && value == 7);
    return bad;
}

/* 3.2: TRN recorded with REC is stored as the step's fitted semitone PITCH lock, never as P_TRANS automation */
static int record_trn(void)
{
    int bad = 0, ok;
    track_t *t = lock_track(0);
    project_t before, after;
    project_store_t disk;
    uint32_t i, sel, found;
    int16_t v;
    t->p[P_QUANT] = QN_SEQ; t->p[P_SCALE] = 0; t->p[P_ROOT] = 0; t->p[P_TRANS] = 0;
    bad += check("SCL TRN is not ordinary automation: PITCH (127) is its only record",
                 !motion_param(P_TRANS) && !ev_id_ok(t, P_TRANS));
    song.sel = 0; song.rec = 1;
    seq_start(); seq_tick(t, CTL);                   /* step 0: C4; the motion base is captured */
    t->p[P_TRANS] = 1;
    ok = !motion_capture(t, P_TRANS, 1) && motion.count == 1u &&
         motion.event[0].param == (MSEQ_PITCH | MOTION_LOCK) && motion.event[0].value == 0 &&
         motion.event[0].place == 0u && t->p[P_TRANS] == 1;   /* the knob keeps moving: no reset */
    bad += check("  REC +1 TRN on C4 in C major stores the fitted 0 ST (C4, not C#4); TRN keeps its value", ok);
    song.rec = 0; seq_stop();
    seq_start(); seq_tick(t, CTL);
    bad += check("  playback at that step is what was heard (C4)", t->plk_fit == 1u && t->plk_pit == 0 &&
                 t->seq_notes[0] == 60u);
    {   /* opening AUTOMATION with a fitted PITCH record (AUTO kind) must render, not loop */
        uint16_t rw[EV_ROWS];
        uint32_t r, nr, row = 0;
        go_auto_top();
        frame();
        nr = ev_list(rw);
        for (r = 0; r < nr; r++)
            if ((rw[r] >> 8) == EVK_REC && MOTION_ID(&motion.event[rw[r] & 0xFFu]) == MSEQ_PITCH)
                row = r;
        ui.ev_row = (uint16_t)row;
        frame();
        turn(EN_K4, 1);
        {
            uint32_t n2, c2 = ev_cur(ev_rw, &n2);
            bad += check("  AUTOMATION opens on a fitted PITCH record, and it stays selected after an edit",
                         row && motion.count == 1u && motion_find(t, 0, MSEQ_PITCH) >= 0 &&
                         (motion.event[0].param & MOTION_LOCK) && (c2 >> 8) == EVK_REC &&
                         MOTION_ID(&motion.event[c2 & 0xFFu]) == MSEQ_PITCH);
        }
    }
    seq_stop();
    motion_set_lock(t, 2, MSEQ_PITCH, 1);
    seq_start(); seq_tick(t, CTL);
    for (i = 0; i < 100000u && t->seq_idx != 2u; i++)
        lock_next(t);
    bad += check("  a manual PITCH +1 plays C#4 (chromatic, after the scale snap)",
                 t->plk_fit == 1u && t->plk_pit == 1 && t->seq_notes[0] == 61u);
    seq_stop();
    ok = motion.count == 2u;
    for (i = 0; i < motion.count; i++)
        ok &= MOTION_ID(&motion.event[i]) != P_TRANS;
    bad += check("  no P_TRANS automation event exists", ok);
    motion_set_lock(t, 4, MSEQ_PITCH, -2);
    ok = motion.count == 3u && !motion_capture(t, MSEQ_PITCH, 7) && motion.count == 3u;
    bad += check("  PITCH (127) stays lock-only: REC captures nothing for it", ok);
    project_capture(&before);
    ok = proj_pack(&disk, &before) && proj_import(&after, &disk, sizeof disk) && after.motion.count == 3u &&
         after.motion.event[0].param == (MSEQ_PITCH | MOTION_LOCK) && after.motion.event[1].param == (MSEQ_PITCH | MOTION_LOCK) &&
         after.motion.event[1].value == 1 && after.motion.event[2].value == -2;
    bad += check("  the fitted TRN record and the PITCH locks survive a FUN16 project", ok);
    sel = found = 0;
    pk_build_auto(t, MSEQ_PITCH, NSTEP, &sel);
    for (i = 0; i < pk_n; i++)
        if (pk_rows[i].id == MSEQ_PITCH && str_eq(pk_label(&pk_rows[i]), "PITCH") && str_eq(pk_tag(&pk_rows[i]), "SEQ"))
            found = 1;
    bad += check("  PITCH locks still appear in AUTOMATION", found && motion_lock_get(t, 4, MSEQ_PITCH, &v) && v == -2);
    {   /* K3 PARAM on a row changed away from PITCH still offers PITCH when the step has no PITCH record */
        uint32_t j, hit = 0;
        motion_clear_locks(t, 0);
        motion_set_lock(t, 0, P_REV, 50);
        pk_build_auto(t, P_REV, 0, &sel);
        for (j = 0; j < pk_n; j++)
            if (pk_rows[j].id == MSEQ_PITCH && str_eq(pk_label(&pk_rows[j]), "PITCH"))
                hit = 1;
        bad += check("  K3 PARAM still offers PITCH after the row was changed to another parameter", hit);
        {   /* selecting PITCH in that list actually changes the record (it is id 127, not in p[]) */
            uint32_t r, nr, prow = 0;
            uint16_t rw[EV_ROWS];
            nr = ev_list(rw);
            for (r = 0; r < nr; r++)
                if ((rw[r] >> 8) == EVK_REC && motion.event[rw[r] & 0xFFu].place == 0 &&
                    MOTION_ID(&motion.event[rw[r] & 0xFFu]) == P_REV)
                    ui.ev_row = (uint16_t)r;
            pk_open(PK_AUTO);
            for (r = 0; r < pk_n; r++)
                if (pk_rows[r].id == MSEQ_PITCH)
                    prow = r;
            pk_cur = (uint8_t)prow;
            pk_apply();
            bad += check("  K3 PARAM: selecting PITCH changes the record to PITCH",
                         motion_find(t, 0, MSEQ_PITCH) >= 0 && motion_find(t, 0, P_REV) < 0);
        }
    }
    return bad;
}

/* ----------------------------------------------- PITCH and kit tracks --- */
/* the transport on to step idx (from wherever it is now, around the loop) */
static void pitch_to(track_t *t, uint32_t idx)
{
    uint32_t n;
    for (n = 0; n < 100000u && t->seq_idx != idx; n++)
        lock_next(t);
}
/* REC TRN +1 on a C4 step in C major: the stored PITCH (raw OFF/KBD, fitted SEQ/ALL/CURR); at playback it
 * replaces the TRN there and stays chromatic (no re-snap) */
static int pitch_capture_mode(uint32_t qn)
{
    track_t *t = lock_track(0);
    int16_t want = (qn == QN_OFF || qn == QN_KBD) ? 1 : 0;
    int ok;
    t->p[P_QUANT] = (int16_t)qn;
    t->p[P_SCALE] = 0;
    t->p[P_ROOT] = 0;
    t->p[P_TRANS] = 0;
    song.sel = 0;
    song.rec = 1;
    seq_start(); seq_tick(t, CTL);                   /* step 0: C4 */
    t->p[P_TRANS] = 1;
    ok = !motion_capture(t, P_TRANS, 1) && motion.count == 1u && motion.event[0].place == 0u &&
         motion.event[0].param == (MSEQ_PITCH | MOTION_LOCK) && motion.event[0].value == want;
    song.rec = 0;
    seq_stop();
    t->p[P_TRANS] = 7;                               /* the lock replaces the TRN on its step */
    t->p[P_QUANT] = QN_SEQ;                          /* and plays chromatically: no re-snap */
    seq_start(); seq_tick(t, CTL);
    ok &= t->plk_fit == 1u && t->plk_pit == want && t->seq_notes[0] == (uint32_t)(60 + want);
    seq_stop();
    return ok;
}
static int pitch_matrix(void)
{
    static const uint32_t QN[5] = {QN_OFF, QN_SEQ, QN_ALL, QN_KBD, QN_CURR};
    static const char *const NAME[5] = {"MAP OFF", "SEQ", "ALL", "KBD", "CURR"};
    int bad = 0;
    uint32_t i;
    char what[96];
    track_t *t;
    for (i = 0; i < 5u; i++) {
        snprintf(what, sizeof what, "PITCH: %s REC TRN +1 on C4 stores %s and plays it", NAME[i],
                 i == 0u || i == 3u ? "raw +1" : "the fitted 0");
        bad += check(what, pitch_capture_mode(QN[i]));
    }
    t = lock_track(0);                               /* a chord: the first note fits the offset */
    t->p[P_QUANT] = QN_SEQ;
    t->p[P_SCALE] = 0;
    t->p[P_ROOT] = 0;
    t->p[P_TRANS] = 0;
    t->step[0] = (step_t){{60, 64, 67}, 3, ST_NOTE, 0, 100};
    song.sel = 0;
    song.rec = 1;
    seq_start(); seq_tick(t, CTL);
    t->p[P_TRANS] = 2;
    bad += check("PITCH: a chord captures against its first note (+2 -> D4 in C major)",
                 !motion_capture(t, P_TRANS, 2) && motion.count == 1u && motion.event[0].value == 2);
    song.rec = 0;
    seq_stop();
    t->p[P_TRANS] = 0;
    seq_start(); seq_tick(t, CTL);
    bad += check("  then the one lock transposes all three notes (D4 F#4 A4, not re-snapped)",
                 t->plk_fit == 1u && t->plk_pit == 2 && t->seq_n == 3u &&
                 t->seq_notes[0] == 62u && t->seq_notes[1] == 66u && t->seq_notes[2] == 69u);
    seq_stop();
    return bad;
}
/* PITCH applies only to a step that plays, on every part of it, and never past it */
static int pitch_gate(void)
{
    int bad = 0, ok;
    track_t *t;
    uint32_t v0;
    t = lock_track(0);
    motion_set_lock(t, 2, MSEQ_PITCH, 2);
    step_set_chance(&t->step[2], 0);
    seq_start(); seq_tick(t, CTL);
    pitch_to(t, 2);
    bad += check("PITCH: CHANCE 0 %: the step plays nothing, so no PITCH",
                 t->seq_idx == 2u && !t->plk_fit && !t->seq_n);
    seq_stop();
    step_set_chance(&t->step[2], 100);
    seq_start(); seq_tick(t, CTL);
    pitch_to(t, 2);
    bad += check("  CHANCE 100 %: PITCH +2 on its step", t->seq_idx == 2u && t->plk_fit == 1u && t->seq_notes[0] == 62u);
    seq_stop();
    t = lock_track(0);
    motion_set_lock(t, 2, MSEQ_PITCH, 2);
    step_set_ratchet(&t->step[2], 3);
    seq_start(); seq_tick(t, CTL);
    pitch_to(t, 2);
    v0 = vage;
    for (ok = t->seq_idx == 2u; t->seq_idx == 2u;) {
        if (t->seq_n)
            ok &= t->plk_fit == 1u && t->seq_notes[0] == 62u;
        seq_tick(t, CTL);
    }
    bad += check("  RATCH x3: PITCH on every part, none at the next step", ok && vage - v0 >= 3u && !t->plk_fit);
    seq_stop();
    t = lock_track(100);
    motion_set_lock(t, 2, MSEQ_PITCH, 2);
    seq_start(); seq_tick(t, CTL);
    pitch_to(t, 2);
    bad += check("  SWING 100: PITCH +2 on its step", t->seq_idx == 2u && t->plk_fit == 1u && t->seq_notes[0] == 62u);
    seq_stop();
    t = lock_track(0);
    t->p[P_TRANS] = 5;
    motion_set_lock(t, 2, MSEQ_PITCH, 2);
    seq_start(); seq_tick(t, CTL);
    ok = !t->plk_fit && t->seq_notes[0] == 65u;
    pitch_to(t, 2);
    ok &= t->plk_fit == 1u && t->seq_notes[0] == 62u;
    pitch_to(t, 3);
    ok &= !t->plk_fit && t->seq_notes[0] == 65u;
    bad += check("PITCH: its step only; TRN sounds on the others (PITCH replaces it there)", ok);
    seq_stop();
    ok = !t->plk_fit;
    seq_start(); seq_tick(t, CTL);
    ok &= !t->plk_fit && t->seq_notes[0] == 65u;
    pitch_to(t, 2);
    ok &= t->plk_fit == 1u && t->seq_notes[0] == 62u;
    pitch_to(t, 0);                                  /* around the loop */
    ok &= !t->plk_fit && t->seq_notes[0] == 65u;
    bad += check("  STOP and the loop's restart: no PITCH left over", ok);
    seq_stop();
    return bad;
}
/* a kit (DRUM, any engine with its own key map) ignores PITCH: no new records, stored ones inert */
static int pitch_kit(void)
{
    int bad = 0, ok;
    track_t *t = lock_track(0);
    set_engine_of(t, ENGI_DRUM);
    t->engine = t->eng_req;
    bad += check("PITCH: DRUM is a kit track (its own key map)", kit_track(t));
    ok = motion_set_lock(t, 2, MSEQ_PITCH, 5) == 1 && !motion.count && !motion.on;
    bad += check("  motion_set_lock refuses PITCH on a kit: nothing written", ok);
    song.sel = 0;
    song.rec = 1;
    seq_start(); seq_tick(t, CTL);
    t->p[P_TRANS] = 1;
    ok = !motion_capture(t, P_TRANS, 1) && !motion.count && t->p[P_TRANS] == 1;
    bad += check("  REC TRN on a kit stores no PITCH lock (the knob keeps its value)", ok);
    song.rec = 0;
    seq_stop();
    motion_clear(t);
    motion_set_lock(t, 1, P_REV, 50);
    ok = motion.count == 1u && motion_move(t, 0, 1, MSEQ_PITCH, 5) == 1 &&
         motion_find(t, 1, MSEQ_PITCH) < 0 && motion_find(t, 1, P_REV) >= 0;
    bad += check("  a record cannot move onto PITCH on a kit", ok);
    /* a stored record (a project from before this rule) loads, stays stored and does nothing */
    motion_clear(t);
    motion.count = 1;
    motion.on = 1;
    motion.event[0] = (motion_event_t){(uint8_t)2, (uint8_t)(MSEQ_PITCH | MOTION_LOCK), 5};
    t->step[2] = (step_t){{60}, 1, ST_NOTE, 0, 100};
    t->p[P_TRANS] = 7;
    seq_start(); seq_tick(t, CTL);
    pitch_to(t, 2);
    bad += check("  a stored PITCH record on a kit: inert (no plk_fit, no PITCH, no TRN)",
                 !t->plk_fit && t->seq_n == 1u && t->seq_notes[0] == 60u && motion.count == 1u);
    seq_stop();
    t->step[2].n = 0;
    t->step[2].hit = 1u << DV_KICK;
    seq_start(); seq_tick(t, CTL);
    pitch_to(t, 2);
    bad += check("  a hit-only step on a kit is inert too", !t->plk_fit && t->seq_n == 1u &&
                 t->seq_notes[0] == DRUM_LANE_NOTE[DV_KICK]);
    seq_stop();
    return bad;
}

/* ----------------------------------------------- BEND lane (the PITCH page) --- */
static int bend_lane(void)
{
    int bad = 0, ok;
    track_t *t;
    project_t before, after;
    project_store_t st;
    uint32_t half, i, seen;

    ui_power_on();
    t = &trk[0];
    track_defaults_steps(t);
    t->p[P_SLEN] = 8;
    song.sel = 0;
    song.rec = 0;
    seq_start(); seq_tick(t, CTL);
    bad += check("BEND: not recording, the PITCH card adds nothing", !motion_capture_bend(t, 200) && !motion.count);

    song.rec = 1;
    ok = !motion_capture_bend(t, 200) && motion.count == 1u && motion.event[0].place == 0u &&
         MOTION_ID(&motion.event[0]) == MFX_BEND && !(motion.event[0].param & MOTION_LOCK) &&
         motion.event[0].value == 32;
    bad += check("BEND: REC on step 0 stores 200 cents as +32, automation (no lock)", ok);
    bad += check("BEND: -200 cents -> -32", !motion_capture_bend(t, -200) && motion.event[0].value == -32);
    bad += check("BEND: 100 cents -> +16", !motion_capture_bend(t, 100) && motion.event[0].value == 16);
    bad += check("BEND: 1 cent rounds to 0", !motion_capture_bend(t, 1) && motion.event[0].value == 0);

    motion_clear(t);
    seq_start(); seq_tick(t, CTL);
    half = step_samples(t, div_samples((uint32_t)t->p[P_SDIV]), t->seq_idx);
    while (t->seq_idx == 0u && t->seq_pos <= half / 2u)
        seq_tick(t, 1);
    ok = t->seq_idx == 0u && !motion_capture_bend(t, 100) && motion.count == 1u &&
         motion.event[0].place == 1u && motion.event[0].value == 16;
    bad += check("BEND: after the step's midpoint the record lands on the next step", ok);
    song.rec = 0;
    seq_stop();

    t = lock_track(0);
    bad += check("BEND: cannot be a lock", motion_set_lock(t, 2, MFX_BEND, 1) == 1 && !motion.count);
    bad += check("BEND: values outside -32..32 are refused",
                 motion_set_event(t, 0, MFX_BEND, -33) == 1 && motion_set_event(t, 0, MFX_BEND, 33) == 1 && !motion.count);

    t = lock_track(0);
    set_engine_of(t, ENGI_DRUM);
    t->engine = t->eng_req;
    song.sel = 0;
    song.rec = 1;
    seq_start(); seq_tick(t, CTL);
    bad += check("BEND: a drum track records nothing",
                 drum_track(t) && !motion_capture_bend(t, 200) && !motion.count);
    song.rec = 0;
    seq_stop();

    t = lock_track(0);
    motion_set_event(t, 2, MFX_BEND, 8);
    seq_start(); seq_tick(t, CTL);
    pitch_to(t, 2);
    bad += check("BEND: playback sets bend_auto / bend_fit", t->seq_idx == 2u && t->bend_fit == 1u && t->bend_auto == 8);
    motion_restore(t);
    bad += check("BEND: restore clears both", !t->bend_fit && !t->bend_auto);
    seq_stop();

    t = lock_track(0);
    motion_set_event(t, 0, MFX_BEND, 12);
    t->bend_auto = 5;
    t->bend_fit = 1;
    ok = motion_find(t, 0, MFX_BEND) >= 0;
    motion_sound_loaded(t, 0, ENGI_DRUM);
    bad += check("BEND: a different engine keeps the record, clears the sounding value",
                 ok && motion_find(t, 0, MFX_BEND) >= 0 && !t->bend_fit && !t->bend_auto);
    motion_clear(t);

    t = lock_track(0);
    motion_set_event(t, 3, MFX_BEND, -12);
    project_capture(&before);
    ok = motion_valid(&before.motion) && proj_pack(&st, &before) && proj_import(&after, &st, sizeof st);
    seen = 0;
    for (i = 0; ok && i < after.motion.count; i++)
        if (MOTION_ID(&after.motion.event[i]) == MFX_BEND && after.motion.event[i].place == 3u) {
            ok &= after.motion.event[i].value == -12 && !(after.motion.event[i].param & MOTION_LOCK);
            seen = 1;
        }
    bad += check("BEND: the record round-trips through a project and validates", ok && seen && motion_valid(&after.motion));
    return bad;
}

static int lock_project(void)
{
    int bad = 0;
    track_t *t = lock_track(0);
    project_t before, after;
    project_store_t a, b;
    uint32_t i, ok = 1;
    motion_set_event(t, 1, P_REV, 33);                   /* no lock: as every project before 1.1 */
    project_capture(&before);
    ok = proj_pack(&a, &before) && proj_import(&after, &a, sizeof a) && proj_pack(&b, &after) && !memcmp(&a, &b, sizeof a);
    for (i = 0; i < before.motion.count; i++)
        ok &= before.motion.event[i].param < 128u && !(before.motion.event[i].param & MOTION_LOCK);
    bad += check("a project without locks: the bytes as before (ids < 128), the same round trip", ok);
    motion_set_lock(t, 2, P_REV, 101); motion_set_lock(t, 7, P_E4, 77);
    project_capture(&before);
    ok = proj_pack(&a, &before) && proj_import(&after, &a, sizeof a) && proj_pack(&b, &after) &&
         !memcmp(&a, &b, sizeof a);            /* (the packed bytes: a struct also holds bit-field padding) */
    bad += check("FUN9 round trip keeps the locks (bit 7 of the id byte), their values and steps", ok &&
        after.motion.event[0].value == 33 && after.motion.event[1].param == (P_REV | MOTION_LOCK) &&
        after.motion.event[2].value == 77);
    project_save(2);
    motion_clear(t);
    project_load(2);
    bad += check("  saved and loaded: the locks play again", motion_lock_count(t) == 2u && lock_passes(t,
        (const int16_t[8]){20, 33, 101, 33, 33, 33, 33, 33}));
    seq_stop();
    {   /* a lock on an engine id of a store of fewer parameters (a FUN7 of 89, before the chord keys; a FUN8 of 91,
         * before the DRUM lane levels, as a 1.1 development build wrote it): moves with its id, keeps bit 7 */
        static const uint32_t np[2] = {89u, 91u};
        for (uint32_t n = 0; n < 2u; n++) {
            motion_store_t m = before.motion;
            for (i = 0; i < m.count; i++)
                if ((m.event[i].param & 0x7Fu) == P_E4)
                    m.event[i].param = (uint8_t)((P_E4 - (P_COUNT - np[n])) | MOTION_LOCK);
            ok = proj_motion_ids(&m, np[n]);
            bad += check(n ? "  FUN8 of 91: a lock's id moves up with P_E0 (87 -> P_E4), still a lock"
                           : "  FUN7 of 89: a lock's id moves up with P_E0 (85 -> P_E4), still a lock",
                ok && m.event[2].param == (P_E4 | MOTION_LOCK) && m.event[1].param == (P_REV | MOTION_LOCK) &&
                m.event[0].param == P_REV);
            m = before.motion;
            m.event[2].param = (uint8_t)(np[n] | MOTION_LOCK);
            bad += check("    an id that store could not name (np): refused", !proj_motion_ids(&m, np[n]));
        }
    }
    chain_config.count = 1; chain_config.row[0] = chain_row_of(2, 1);
    motion_clear(t); t->p[P_REV] = 20;
    bad += check("SONG: a slot's locks come with its motion", chain_prepare() == 0 && chain.source[2].motion.count == 3u);
    seq_start(); seq_tick(t, CTL);
    lock_next(t); lock_next(t);
    ok = chain.running && t->seq_idx == 2u && t->p[P_REV] == 101;
    lock_next(t);
    bad += check("  a song plays them on their step, back after it", ok && t->p[P_REV] == 33);
    seq_stop(); chain_config.count = 0; chain.armed = 0;
    return bad;
}
/* the UI: hold a step, turn a knob (ui_input.c lock_*) */
static void lk_down(uint32_t k) { fm1_in.notes |= 1u << k; host_notes |= 1u << k; frame(); }
static void lk_up(uint32_t k) { fm1_in.notes &= ~(1u << k); frame(); }
static int lock_ui(void)
{
    int bad = 0, ok;
    int16_t v;
    track_t *t;
    uint32_t k0, k4, kn;
    ui_power_on();
    song.sel = 3;                                        /* track 4: DRUM, the grid */
    t = &trk[3];
    track_defaults_steps(t);
    t->p[P_SLEN] = 16;
    go_home();
    go_seq_step();                                       /* SEQ button opens PATTERN; STEP for the grid */
    frame();
    k0 = key_at(0, 0); k4 = key_at(0, 4);
    grid_hit(t, 0, 0, 1);                                /* a KICK on step 1 */
    bad += check("the grid on SEQ > STEP; the locks' knobs: HOME's (DRUM: E1..E4)", grid_on() && lock_id(0) == P_E0 &&
        lock_id(3) == P_E3);
    lk_down(k4);
    bad += check("a step key down: its step held (an empty one gets its hit at once)", lock_held() == (1u << 4) &&
        (t->step[4].hit & 1u));
    turn(EN_K1, 3);
    ok = motion_lock_get(t, 4, P_E0, &v) && v == motion_base_value(t, P_E0) + 3;
    turn(EN_K1, 2);
    bad += check("  KNOB 1 turned: step 5 gets a lock of E1 (MORPH), from the sound's own value", ok &&
        motion_lock_get(t, 4, P_E0, &v) && v == motion_base_value(t, P_E0) + 5 && t->p[P_E0] == motion_base_value(t, P_E0));
    lk_up(k4);
    bad += check("  let go: the hit stays, the lock is there, the sound unchanged", (t->step[4].hit & 1u) &&
        motion_lock_count(t) == 1u && !lock_held());
    lk_down(k0);
    turn(EN_K2, -4);
    lk_up(k0);
    bad += check("a key pressed on a hit and held for a lock: the hit stays", (t->step[0].hit & 1u) &&
        motion_lock_get(t, 0, P_E1, &v));
    tap_key(k0);
    bad += check("  tapped alone: the hit goes (when let go), its lock stays", !(t->step[0].hit & 1u) &&
        motion_lock_count(t) == 2u);
    fm1_in.notes |= 1u << k0 | 1u << k4; host_notes |= 1u << k0 | 1u << k4; frame();
    turn(EN_K4, 1);
    fm1_in.notes = 0; frame();
    bad += check("two step keys held: both get the lock", motion_lock_get(t, 0, P_E3, &v) && motion_lock_get(t, 4, P_E3, &v) &&
        motion_lock_count(t) == 4u);
    lk_down(k4);
    press(B_EDIT);
    lk_up(k4);
    bad += check("a step held + [EDIT]: its locks go, the step and the others' locks stay", motion_lock_count(t) == 2u &&
        !motion_lock_get(t, 4, P_E0, &v) && motion_lock_get(t, 0, P_E3, &v) && (t->step[4].hit & 1u) &&
        str_eq(ui.msg, "LOCKS CLEARED"));
    bad += check("the steps with a lock (the grid marks them): step 1", motion_lock_steps(3) == 1u);
    go_title("EFFECTS");
    ui.ior_sel = 0;                                      /* K4 edits the chosen stage's mix (DIST) */
    go_seq_step();                                       /* STEP keeps EFFECTS plk_src (STEP is not lock_page_ok) */
    frame();
    bad += check("from EFFECTS: K4 locks the chosen stage's mix", lock_id(3) == P_IDMIX && lock_id(0) == 0xFFu);
    lk_down(k4); turn(EN_K4, 5); lk_up(k4);              /* K4 = that mix */
    bad += check("  step 5 gets a MIX lock", motion_lock_get(t, 4, P_IDMIX, &v) && v == t->p[P_IDMIX] + 5);
    go_auto_top();
    frame();
    bad += check("AUTOMATION: EVENT 0, LOCK 3", motion_count(t) - motion_lock_count(t) == 0u && motion_lock_count(t) == 3u);
    /* the roll: the step being entered is the one held */
    ui_power_on();
    t = &trk[0];
    track_defaults_steps(t);
    go_home();
    go_seq_step();
    frame();
    for (kn = 0; kn < 27u && kb_map(t, kn) > 127u; kn++)
        ;
    lk_down(kn);                                         /* (1.2, #133: not armed, a key only plays: no step held) */
    ok = !ui.entry_open && !lock_held() && !t->step[0].n;
    turn(EN_K3, 4);
    lk_up(kn);
    bad += check("the roll, not armed: a key held writes no step and holds none; KNOB 3 locks nothing",
                 ok && !motion_lock_count(t) && !t->step[0].n && ui.cursor == 0u);
    song.rec = 1;                                        /* armed, stopped: step recording */
    lk_down(kn);
    ok = ui.entry_open && lock_held() == 1u && t->step[0].n == 1u;
    turn(EN_K3, 4);                                      /* ANALOG's HOME: E5 E6 ATK REL */
    bad += check("the roll, armed (step recording): a note key held (the entry) is the step held; KNOB 3 locks ATK, TIME untouched", ok &&
        motion_lock_get(t, 0, P_ATK, &v) && v == t->p[P_ATK] + 4 && t->step[0].time == ST_NOTE);
    lk_up(kn);
    bad += check("  let go: the note and the lock on step 1, the cursor on", ui.cursor == 1u && t->step[0].n == 1u &&
        motion_lock_count(t) == 1u && motion_lock_steps(0) == 1u);
    cursor_set(0);
    press(B_EDIT);
    bad += check("  [EDIT] alone leaves the note and its lock; it opens EDIT",
                 t->step[0].n == 1u && motion_lock_count(t) == 1u && cur_page()->fam == FAM_EDIT);
    go_seq_step();
    ui.cursor = 0;
    frame();
    turn(EN_K3, -1);                                     /* LEN 1 -> 0: the note and its locks; cursor on */
    bad += check("  KNOB 3 to LEN 0 clears the note and its locks; the cursor moves on",
                 !t->step[0].n && t->step[0].time == ST_REST && !motion_lock_count(t) && msg_is("NOTE CLEARED") &&
                 ui.cursor == 1u);
    song.playing = 1; chain.running = 1;
    lk_down(kn); turn(EN_K3, 1); lk_up(kn);
    bad += check("  a song playing: STOP TO EDIT, no lock", !motion_lock_count(t) && msg_is("STOP TO EDIT"));
    song.playing = 0; chain.running = 0; song.rec = 0;
    {   /* SCL KNOB 4 on a held step: the PITCH lock (MSEQ_PITCH), not a refused TRN lock */
        ui_power_on();
        t = &trk[0];
        track_defaults_steps(t);
        go_title("SCL");
        go_seq_step();
        frame();
        for (kn = 0; kn < 27u && kb_map(t, kn) > 127u; kn++)
            ;
        song.rec = 1;
        lk_down(kn);
        turn(EN_K4, 2);
        lk_up(kn);
        bad += check("SCL K4 on a held step: a PITCH lock (+2), not a refused TRN lock",
                     motion_lock_get(t, 0, MSEQ_PITCH, &v) && v == 2 && motion_lock_count(t) == 1u);
        {   /* AUTOMATION lists it, and + ADD can create one */
            uint32_t sel = 0, j, found = 0;
            pk_build_auto(t, MSEQ_PITCH, 0, &sel);
            for (j = 0; j < pk_n; j++)
                if (pk_rows[j].id == MSEQ_PITCH && str_eq(pk_label(&pk_rows[j]), "PITCH"))
                    found = 1;
            ok = found;
            found = 0;
            pk_build_auto(t, 0, NSTEP, &sel);
            for (j = 0; j < pk_n; j++)
                if (pk_rows[j].id == MSEQ_PITCH && str_eq(pk_label(&pk_rows[j]), "PITCH"))
                    found = 1;
            bad += check("AUTOMATION lists the PITCH lock, and + ADD offers it", ok && found);
        }
        song.rec = 0;
    }
    return bad;
}
/* 1.1.5: lock edits by hand are one undo (SAVE held), redo too */
static int lock_undo(void)
{
    int bad = 0;
    int16_t v;
    track_t *t;
    uint32_t k4;
    ui_power_on();
    song.sel = 3;
    t = &trk[3];
    track_defaults_steps(t);
    t->p[P_SLEN] = 16;
    go_home();
    go_seq_step();
    frame();
    k4 = key_at(0, 4);
    lk_down(k4);
    turn(EN_K1, 3);
    turn(EN_K1, 2);
    lk_up(k4);
    bad += check("lock undo: a step held, KNOB 1 turned twice: one lock", motion_lock_get(t, 4, P_E0, &v) &&
        v == motion_base_value(t, P_E0) + 5);
    hold(B_SAVE);
    bad += check("  SAVE held: the lock is gone (one undo for the whole turn), the step's hit stays",
        !motion_lock_count(t) && (t->step[4].hit & 1u));
    hold(B_SAVE);
    bad += check("  held again (redo): the lock is back at its value", motion_lock_get(t, 4, P_E0, &v) &&
        v == motion_base_value(t, P_E0) + 5);
    frames(2000);
    lk_down(k4);
    press(B_EDIT);
    lk_up(k4);
    bad += check("  a step held + [EDIT] clears it", !motion_lock_count(t) && str_eq(ui.msg, "LOCKS CLEARED"));
    hold(B_SAVE);
    bad += check("  SAVE held brings it back", motion_lock_get(t, 4, P_E0, &v) && v == motion_base_value(t, P_E0) + 5);
    frames(2000);
    lk_down(k4);
    press(B_EDIT);
    lk_up(k4);
    lk_down(k4);
    press(B_EDIT);                                       /* (no lock there now: NO LOCKS, the undo copy kept) */
    lk_up(k4);
    hold(B_SAVE);
    bad += check("  [EDIT] on a step without locks takes no undo copy (the clear before stays undoable)",
        motion_lock_count(t) == 1u);
    return bad;
}
/* 1.1.5: SEQ > AUTO LIST (ui_events.c); 1.2: the AUTOMATION page, its rows: QUANTIZE, ENABLED, the records (and CHANCE / RATCH / NUDGE), + ADD */
static uint32_t rows_n(void) { uint16_t rw[EV_ROWS]; return ev_list(rw); }   /* QUANTIZE, ENABLED and + ADD included */
static uint32_t row_at(uint32_t r) { uint16_t rw[EV_ROWS]; return r < ev_list(rw) ? rw[r] : 0xFFFFu; }
static int auto_list(void)
{
    int bad = 0, ok;
    int16_t v;
    track_t *t;
    uint32_t id0, id1, i;
    ui_power_on();
    song.sel = 0;
    t = &trk[0];
    track_defaults_steps(t);
    t->p[P_SLEN] = 16;
    go_home();
    cursor_set(4);
    go_page(GR_EVENTS);
    frame();
    id0 = ui.ev_id;
    ok = auto_cur() == EVC(EVK_QNT, 0) && str_eq(act_name(4), "--") && !act_ready();
    turn(EN_K1, 2);                                      /* (past ENABLED) */
    bad += check("AUTOMATION: empty, QUANTIZE then + ADD LOCK (on the SEQ cursor's step, the first knob of the sound page)",
        ok && cur_page()->graph == GR_EVENTS && rows_n() == 3u && auto_cur() == EVC(EVK_ADD, 0) && ui.ev_step == 4u &&
        id0 == lock_id(0) && str_eq(act_name(4), "ADD") && act_ready());
    press(B_OCTUP);
    bad += check("  OCT+: a lock on step 5 at the sound's own value, its row selected",
        motion_lock_get(t, 4, id0, &v) && v == motion_base_value(t, id0) && ui.ev_row == 2u && auto_cur() >> 8 == EVK_REC &&
        str_eq(ui.msg, "LOCK ADDED") && motion_enabled(t));
    turn(EN_K4, 3);
    bad += check("  KNOB 4: its value", motion_lock_get(t, 4, id0, &v) && v == motion_base_value(t, id0) + 3);
    turn(EN_K2, 2);
    bad += check("  KNOB 2: its step (5 -> 7), the value kept", !motion_lock_get(t, 4, id0, &v) &&
        motion_lock_get(t, 6, id0, &v) && v == motion_base_value(t, id0) + 3);
    turn(EN_K3, 1);
    id1 = MOTION_ID(&motion.event[0]);
    bad += check("  KNOB 3: the next parameter, from the sound's own value", id1 > id0 && ev_id_ok(t, id1) &&
        motion_lock_get(t, 6, id1, &v) && v == motion_base_value(t, id1) && motion_count(t) == 1u);
    press(B_OCTUP);
    bad += check("  OCT+ on the row: LOCK -> AUTO", motion_count(t) == 1u && !motion_lock_count(t) &&
        str_eq(act_name(4), "LOCK"));
    press(B_OCTUP);
    ok = motion_lock_count(t) == 1u;
    press(B_OCTUP);
    bad += check("  and back (AUTO -> LOCK -> AUTO)", ok && !motion_lock_count(t));
    turn(EN_K1, 1);
    turn(EN_K2, -2);
    bad += check("  KNOB 1: + ADD LOCK; KNOB 2 there: its step", auto_cur() == EVC(EVK_ADD, 0) && ui.ev_step == 2u);
    press(B_OCTUP);
    bad += check("  OCT+: a second lock on step 3, first in the list (by step)", motion_count(t) == 2u &&
        motion_lock_get(t, 2, ui.ev_id, &v) && rows_n() == 5u && ui.ev_row == 2u &&
        (motion.event[row_at(2) & 0xFFu].place & 63u) == 2u);
    turn(EN_K1, 5);
    press(B_OCTUP);
    bad += check("  OCT+ on + ADD LOCK where one is: ALREADY LISTED, that row selected", motion_count(t) == 2u &&
        str_eq(ui.msg, "ALREADY LISTED") && ui.ev_row == 2u);
    press(B_EDIT);
    bad += check("  EDIT opens the EDIT page (the row's record stays)", motion_count(t) == 2u &&
        motion_lock_get(t, 2, ui.ev_id, &v) && cur_page()->fam == FAM_EDIT);
    go_auto_top(); frame();
    turn(EN_K1, 1);                                      /* row 2: the first record */
    press(B_OCTDN);
    bad += check("  OCT-: the row's record goes", motion_count(t) == 1u && !motion_lock_get(t, 2, ui.ev_id, &v) &&
        str_eq(ui.msg, "DELETED"));
    hold(B_SAVE);
    bad += check("  SAVE held: it is back", motion_count(t) == 2u);
    hold(B_SAVE);
    bad += check("  held again: gone again", motion_count(t) == 1u);
    frames(2000);
    turn(EN_K1, -5);
    turn(EN_K1, 2);                                      /* (the first record: the row after QUANTIZE and ENABLED) */
    {
        uint16_t c = auto_cur();
        v = motion.event[c & 0xFFu].value;
        turn(EN_K4, 2); frames(100); turn(EN_K4, 2); frames(100); turn(EN_K4, 2);  /* > ACC_GAP per detent: no accel */
        ok = motion.event[c & 0xFFu].value == v + 6;
        hold(B_SAVE);
        bad += check("  KNOB 4 turned on (three turns): one undo", ok && motion.event[c & 0xFFu].value == v);
        chain.running = 1;
        turn(EN_K4, 1);
        bad += check("  a song playing: STOP TO EDIT", motion.event[c & 0xFFu].value == v && str_eq(ui.msg, "STOP TO EDIT"));
        chain.running = 0;
    }
    for (i = 0; motion.count < MOTION_MAX; i++)          /* the 255 used (track 2: four ids over the steps) */
        motion_set_event(&trk[1], i % NSTEP, i < NSTEP ? P_REV : i < 2u * NSTEP ? P_DLY : i < 3u * NSTEP ? P_PAN : P_LEVEL,
                         10);
    turn(EN_K1, 5);
    press(B_OCTUP);
    bad += check("  the 255 used: OCT+ adds nothing, AUTOMATION FULL", motion_count(t) == 1u &&
        str_eq(ui.msg, "AUTOMATION FULL") && !act_ready());
    motion_clear(&trk[1]);
    for (i = 0; i < P_COUNT; i++)                        /* names: an id each, none of DIGITAL's, lanes on DRUM only
                                                          * (BEND reuses FM1 ATK and is automation-only: listed) */
        if (ev_id_ok(t, i) && i != MFX_BEND &&
            ((i >= P_FM1_ATK && i <= P_FM4_LEVEL) || (i >= P_LN0 && i <= P_LN7) || !motion_param(i)))
            break;
    bad += check("  KNOB 3's list: what motion records and the sound has (no OP ENV, no DRUM lanes off DRUM)", i == P_COUNT &&
        ev_id_ok(&trk[3], P_LN0));
    {
        char a[12], b[12], c[12];
        ev_name(t, P_ED_FLT, a); ev_name(t, P_LD_FLT, b); ev_name(t, P_SLRATE, c);
        bad += check("  names: ENV FLT / LFO FLT / SL RATE",
            str_eq(a, "ENV FLT") && str_eq(b, "LFO FLT") && str_eq(c, "SL RATE"));
    }
    ui_prefs |= PREF_LARGE;
    bad += check("  MENU > LARGE: the list layout with labels in M (as the other lists)", large_kind() == LK_LABEL);
    ui_prefs &= ~PREF_LARGE;
    /* #223: PARAM / MOD DST are flat tag+name lists. ENV DEST / LFO DEST are knob pages.
     * Shared SEND controls stay visible until another track reserves them. */
    song.g[G_SLOWN] = 1;                                 /* track 0 owns SLICER CHAIN */
    song.g[G_DLYOWN] = 1;
    song.g[G_REVOWN] = 1;
    {
        uint32_t st;
        for (st = 0; st < INS_N; st++)
            ins_send_set(TSEL, st, 0);
    }
    ui.ev_row = 0xFFFFu;                                 /* + ADD */
    ui.ev_id = (uint8_t)P_LEVEL;
    ui.ev_step = 0;
    turn(EN_K3, 1);
    bad += check("#223 AUTOMATION PARAM: pick list opens", ui.pick == PK_AUTO && pk_n > 8u &&
        pk_cur < pk_n);
    {
        uint32_t i, found = 0, dly = 0, rev = 0, send = 0, chor_mix_last = 1;
        int32_t i_dist = -1, i_filt = -1, i_crush = -1, i_phas = -1, i_flang = -1, i_chor = -1;
        int32_t i_dly = -1, i_rev = -1, i_sl = -1, i_hrat = -1, i_hdep = -1;
        for (i = 0; i < pk_n; i++) {
            if (pk_rows[i].id == P_SLRATE && str_eq(pk_tag(&pk_rows[i]), "SLICER") &&
                str_eq(pk_label(&pk_rows[i]), "RATE"))
                found = 1, i_sl = (int32_t)i;
            if (pk_rows[i].id == P_DIST && str_eq(pk_tag(&pk_rows[i]), "DISTORT"))
                i_dist = (int32_t)i;
            if (pk_rows[i].id == P_IFCUT && str_eq(pk_tag(&pk_rows[i]), "FILTER"))
                i_filt = (int32_t)i;
            if (pk_rows[i].id == P_ICMIX && str_eq(pk_tag(&pk_rows[i]), "CRUSH"))
                i_crush = (int32_t)i;
            if (pk_rows[i].id == P_IPMIX && str_eq(pk_tag(&pk_rows[i]), "PHASER"))
                i_phas = (int32_t)i;
            if (pk_rows[i].id == P_ILMIX && str_eq(pk_tag(&pk_rows[i]), "FLANGER"))
                i_flang = (int32_t)i;
            if (pk_rows[i].id == P_IHRATE && str_eq(pk_tag(&pk_rows[i]), "CHORUS"))
                i_hrat = (int32_t)i;
            if (pk_rows[i].id == P_IHDEP && str_eq(pk_tag(&pk_rows[i]), "CHORUS"))
                i_hdep = (int32_t)i;
            if (pk_rows[i].id == P_IHMIX && str_eq(pk_tag(&pk_rows[i]), "CHORUS"))
                i_chor = (int32_t)i;
            if (pk_rows[i].id == P_DLY && str_eq(pk_tag(&pk_rows[i]), "DELAY") &&
                str_eq(pk_label(&pk_rows[i]), "MIX"))
                dly = 1, i_dly = (int32_t)i;
            if (pk_rows[i].id == P_REV && str_eq(pk_tag(&pk_rows[i]), "REVERB") &&
                str_eq(pk_label(&pk_rows[i]), "MIX"))
                rev = 1, i_rev = (int32_t)i;
            if (str_eq(pk_tag(&pk_rows[i]), "SEND"))
                send = 1;
        }
        if (i_chor >= 0 && ((i_hrat >= 0 && i_chor < i_hrat) || (i_hdep >= 0 && i_chor < i_hdep)))
            chor_mix_last = 0;
        bad += check("#223 AUTOMATION PARAM: SLICER / RATE", found);
        bad += check("AUTOMATION PARAM: no SEND; DELAY / REVERB tags", dly && rev && !send);
        bad += check("AUTOMATION PARAM: FX stages in EFFECTS order",
                     i_dist >= 0 && i_crush > i_dist && i_filt > i_crush && i_phas > i_filt &&
                     i_flang > i_phas && i_chor > i_flang && i_dly > i_chor && i_rev > i_dly &&
                     i_sl > i_rev);
        bad += check("AUTOMATION PARAM: Chorus MIX last in CHORUS", chor_mix_last && i_chor >= 0);
    }
    turn(EN_K1, -1);
    bad += check("#223 leaving the row closes the pick list", !ui.pick);
    go_title("MOD");
    frame();
    turn(EN_K3, 1);
    bad += check("#223 MOD DST: pick list opens", ui.pick == PK_MDST && pk_n > 8u && pk_cur < pk_n);
    {
        uint32_t i, dist = 0, spat = 0, fcut = 0, cho = 0, dly = 0, rev = 0, send = 0, pan = 0, chor_mix_last = 1;
        int32_t i_dist = -1, i_filt = -1, i_crush = -1, i_phas = -1, i_flang = -1, i_chor = -1;
        int32_t i_dly = -1, i_rev = -1, i_sl = -1, i_hrat = -1, i_hdep = -1;
        for (i = 0; i < pk_n; i++) {
            if (pk_rows[i].id == MD_DIST && str_eq(pk_tag(&pk_rows[i]), "DISTORT") &&
                str_eq(pk_label(&pk_rows[i]), "DISTORT"))
                dist = 1, i_dist = (int32_t)i;
            if (pk_rows[i].id == MD_SLPAT && str_eq(pk_tag(&pk_rows[i]), "SLICER") &&
                str_eq(pk_label(&pk_rows[i]), "PATTERN"))
                spat = 1, i_sl = (int32_t)i;
            if (pk_rows[i].id == MD_FCUT && str_eq(pk_tag(&pk_rows[i]), "FILTER") &&
                str_eq(pk_label(&pk_rows[i]), "CUTOFF"))
                fcut = 1, i_filt = (int32_t)i;
            if (pk_rows[i].id == MD_CMIX && str_eq(pk_tag(&pk_rows[i]), "CRUSH"))
                i_crush = (int32_t)i;
            if (pk_rows[i].id == MD_PMIX && str_eq(pk_tag(&pk_rows[i]), "PHASER"))
                i_phas = (int32_t)i;
            if (pk_rows[i].id == MD_LMIX && str_eq(pk_tag(&pk_rows[i]), "FLANGER"))
                i_flang = (int32_t)i;
            if (pk_rows[i].id == MD_HRAT && str_eq(pk_tag(&pk_rows[i]), "CHORUS"))
                i_hrat = (int32_t)i;
            if (pk_rows[i].id == MD_HDEP && str_eq(pk_tag(&pk_rows[i]), "CHORUS"))
                i_hdep = (int32_t)i;
            if (pk_rows[i].id == MD_CHO && str_eq(pk_tag(&pk_rows[i]), "CHORUS") &&
                str_eq(pk_label(&pk_rows[i]), "MIX"))
                cho = 1, i_chor = (int32_t)i;
            if (pk_rows[i].id == MD_DLY && str_eq(pk_tag(&pk_rows[i]), "DELAY"))
                dly = 1, i_dly = (int32_t)i;
            if (pk_rows[i].id == MD_REV && str_eq(pk_tag(&pk_rows[i]), "REVERB"))
                rev = 1, i_rev = (int32_t)i;
            if (pk_rows[i].id == MD_PAN && str_eq(pk_tag(&pk_rows[i]), "MIX"))
                pan = 1;
            if (str_eq(pk_tag(&pk_rows[i]), "SEND"))
                send = 1;
        }
        if (i_chor >= 0 && ((i_hrat >= 0 && i_chor < i_hrat) || (i_hdep >= 0 && i_chor < i_hdep)))
            chor_mix_last = 0;
        bad += check("#223 MOD DST: DISTORT / SLICER / FILTER / CHORUS; no SEND",
                     dist && spat && fcut && cho && !send);
        bad += check("MOD DST: PAN is MIX; DELAY / REVERB tags", pan && dly && rev);
        bad += check("MOD DST: FX stages in EFFECTS order",
                     i_dist >= 0 && i_crush > i_dist && i_filt > i_crush && i_phas > i_filt &&
                     i_flang > i_phas && i_chor > i_flang && i_dly > i_chor && i_rev > i_dly &&
                     i_sl > i_rev);
        bad += check("MOD DST: Chorus MIX last in CHORUS", chor_mix_last && i_chor >= 0);
    }
    /* An unreserved SEND FILTER exposes its shared continuous controls. */
    {
        uint32_t i, cut = 0, mix = 0;
        ins_send_set(TSEL, INS_FILTER, 1);
        pk_open(PK_MDST);
        for (i = 0; i < pk_n; i++) {
            if (pk_rows[i].id == MD_FCUT) cut = 1;
            if (pk_rows[i].id == MD_FMIX) mix = 1;
        }
        bad += check("MOD DST SEND FILTER: unreserved CUT and MIX visible", mix && cut);
        ins_send_set(TSEL, INS_FILTER, 0);
        pk_open(PK_MDST);
        cut = mix = 0;
        for (i = 0; i < pk_n; i++) {
            if (pk_rows[i].id == MD_FCUT) cut = 1;
            if (pk_rows[i].id == MD_FMIX) mix = 1;
        }
        bad += check("MOD DST CHAIN FILTER: CUT and MIX visible", cut && mix);
        pk_close();
    }
    /* SLICER SEND: PAT/RATE/MIX all listed (bus knobs + per-track MIX). */
    {
        uint32_t i, spat = 0, srate = 0, smix = 0;
        song.g[G_SLOWN] = 0;
        pk_open(PK_MDST);
        for (i = 0; i < pk_n; i++) {
            if (pk_rows[i].id == MD_SLPAT) spat = 1;
            if (pk_rows[i].id == MD_SLRATE) srate = 1;
            if (pk_rows[i].id == MD_SLDEPTH) smix = 1;
        }
        bad += check("MOD DST SEND SLICER: PATTERN / RATE / MIX visible", spat && srate && smix);
        pk_close();
        song.g[G_SLOWN] = 1;
    }
    {
        uint32_t i, n = 0;
        for (i = 0; i < NPAGES; i++)
            if (str_eq(PAGES[i].title, "ENV DEST") || str_eq(PAGES[i].title, "LFO DEST")) {
                bad += check(PAGES[i].title, PAGES[i].graph == GR_NONE);
                n++;
            }
        bad += check("ENV DEST and LFO DEST are knob pages (scope), not a pick list", n == 2u);
    }
    return bad;
}
static int fx_lock_time(void)
{
    int bad = 0; ui_power_on(); track_t *t = &trk[0];
    song.g[G_DTIME] = 1;
    bad += check("delay TIME lock accepts an exact 1486 ms value", !motion_set_lock(t, 0, 49u, 1550));
    seq_start(); motion_step(t, 0, &motion, 1);
    bad += check("delay TIME lock changes the shared delay without changing matrix SRC", song.g[G_DTIME] == 1550 && t->p[P_M1SRC] == 0);
    bad += check("TIME lock defaults preserve the underlying 250 ms division", motion_target_base_value(t, MFX_TIME) == 314);
    project_t q, restored; project_store_t disk;
    project_capture(&q);
    bad += check("delay TIME project saves the base division and exact lock", q.g[G_DTIME] == 1 && proj_pack(&disk, &q) &&
        proj_import(&restored, &disk, sizeof disk) && restored.motion.count == 1 && restored.motion.event[0].value == 1550);
    motion_step(t, 1, &motion, 1);
    bad += check("delay TIME lock restores its original division on the next step", song.g[G_DTIME] == 1);
    seq_stop();
    return bad;
}
static int fx_lock_banks_and_capacity(void)
{
    int bad = 0; ui_power_on(); track_t *t = &trk[0];
    song.g[G_RSIZE] = 24; song.g[G_RDAMP] = 35;
    song.g[G_CRSIZE] = 46; song.g[G_CRDAMP] = 57;
    bad += check("continuous SEND controls accept independent locks", !motion_set_lock(t, 0, MFX_FB, 100) &&
        !motion_set_lock(t, 0, MFX_COLOR, 17) && !motion_set_lock(t, 0, MFX_SIZE, 88) && !motion_set_lock(t, 0, MFX_DAMP, 99));
    bad += check("a SEND lock reserves its control until removed", !fx_target_available(&trk[1], MFX_SIZE));
    seq_start(); motion_step(t, 0, &motion, 1);
    bad += check("SEND reverb locks leave the CHAIN bank alone", song.g[G_RSIZE] == 88 && song.g[G_RDAMP] == 99 &&
        song.g[G_CRSIZE] == 46 && song.g[G_CRDAMP] == 57);
    motion_step(t, 1, &motion, 1);
    bad += check("FX locks restore their continuous base values", song.g[G_DFDBK] == GP[G_DFDBK].def &&
        song.g[G_DCOLOR] == GP[G_DCOLOR].def && song.g[G_RSIZE] == 24 && song.g[G_RDAMP] == 35);
    seq_stop(); motion_clear(t);
    bad += check("removing SEND locks frees those settings", fx_target_available(&trk[1], MFX_SIZE));
    song.g[G_REVOWN] = 1;
    motion_set_lock(t, 0, MFX_SIZE, 103); motion_set_lock(t, 0, MFX_DAMP, 104);
    seq_start(); motion_step(t, 0, &motion, 1);
    bad += check("CHAIN reverb locks use the selected track bank", song.g[G_CRSIZE] == 103 && song.g[G_CRDAMP] == 104 &&
        song.g[G_RSIZE] == 24 && song.g[G_RDAMP] == 35 && fx_target_available(&trk[1], MFX_SIZE));
    seq_stop(); motion_clear(t);
    bad += check("stopping restores CHAIN reverb bases", song.g[G_CRSIZE] == 46 && song.g[G_CRDAMP] == 57);
    for (uint32_t i = 0; i < MOTION_MAX; i++)
        bad += motion_set_lock(t, i % NSTEP, i < NSTEP ? MFX_TIME : i < 2u * NSTEP ? MFX_FB :
                               i < 3u * NSTEP ? MFX_COLOR : MFX_DAMP, i < NSTEP ? 1550 : i < 2u * NSTEP ? 110 : 25);
    bad += check("FX locks retain all 255 RAM entries and overwrite at capacity", motion.count == MOTION_MAX &&
        motion_set_lock(t, 0, MFX_SIZE, 33) == 2 && !motion_set_lock(t, 0, MFX_TIME, 65));
    project_t q, loaded; project_store_t st;
    project_capture(&q);
    /* FUN21: project is 4864 bytes; MOTION_FILE_MAX is every record RAM holds (255) */
    bad += check("FX locks retain MOTION_FILE_MAX saved entries with exact TIME values",
                 proj_pack(&st, &q) && sizeof st == 4864 &&
                 proj_import(&loaded, &st, sizeof st) && loaded.motion.count == MOTION_FILE_MAX &&
                 loaded.motion.event[0].value == 65 && loaded.motion.event[63].value == 1550 &&
                 loaded.motion.event[71].value == 110);
    return bad;
}
static voice_t *cvoice(track_t *t, uint32_t note)
{
    uint32_t i;
    for (i = 0; i < NVOICE; i++)
        if (t->v[i].active && t->v[i].note == note)
            return &t->v[i];
    return 0;
}
/* PIT GLD: POLY chords pair their notes, keep the envelopes and glide; added notes fade in, removed ones glide out */
static int pit_gld_seq(void)
{
    int bad = 0, ok;
    track_t *t = lock_track(0);
    voice_t *v, *w;
    int32_t out[CTL];
    uint32_t i, a0;
    t->p[P_VOICE] = V_POLY;
    t->p[P_GLIDE] = 100;
    cgld_set(t, 1);
    t->step[0] = (step_t){{60, 64, 67}, 3, ST_NOTE, 0, 100};
    t->step[1] = (step_t){{62, 65, 69}, 3, ST_NOTE, 0, 100};
    seq_step(t, &t->step[0], 0, div_samples(2), 0);
    ok = t->seq_n == 3u && t->seq_hold;                 /* PIT GLD holds the chord to the next NOTE */
    v = cvoice(t, 60);
    a0 = v ? v->age : 0;
    seq_step(t, &t->step[1], 1, div_samples(2), 0);
    v = cvoice(t, 62);
    ok &= t->seq_n == 3u && t->seq_notes[0] == 62u && t->seq_notes[1] == 65u && t->seq_notes[2] == 69u;
    ok &= v && v->gate && v->age == a0 && v->stage != 0;   /* the same voice: no retrigger */
    ok &= v && v->pitch_cur == 60 * 16 && v->pitch16 == 62 * 16 && v->gq8 && v->gstep > 0;
    track_render(t, out, CTL);
    ok &= v && v->pitch_cur == 60 * 16;                 /* the first tick is a fraction of a 1/16 st, not a jump */
    for (i = 0; i < 2000u; i++)
        track_render(t, out, CTL);
    ok &= v && v->pitch_cur == v->pitch16;              /* it arrives */
    bad += check("PIT GLD: a POLY chord glides into the next, each note to its partner, no retrigger", ok);

    /* 3 -> 4: the added note starts at the nearest old pitch and fades in */
    t->step[0] = (step_t){{60, 64, 67}, 3, ST_NOTE, 0, 100};
    t->step[1] = (step_t){{62, 65, 69, 72}, 4, ST_NOTE, 0, 100};
    seq_release(t);
    seq_step(t, &t->step[0], 0, div_samples(2), 0);
    a0 = vage;
    seq_step(t, &t->step[1], 1, div_samples(2), 0);
    w = 0;
    for (i = 0; i < NVOICE; i++)
        if (t->v[i].active && t->v[i].age == a0 + 1u)
            w = &t->v[i];
    bad += check("PIT GLD 3 -> 4: the new note fades in from the nearest old pitch",
                 w && w->note == 72u && w->pitch_cur == 67 * 16 && w->fin_d == 5 * 16 && w->gq8);
    seq_release(t);

    /* 1 -> 2 where the old note is also the first new one: the added note still starts from it */
    t->step[0] = (step_t){{60}, 1, ST_NOTE, 0, 100};
    t->step[1] = (step_t){{60, 64}, 2, ST_NOTE, 0, 100};
    seq_step(t, &t->step[0], 0, div_samples(2), 0);
    a0 = vage;
    seq_step(t, &t->step[1], 1, div_samples(2), 0);
    w = 0;
    for (i = 0; i < NVOICE; i++)
        if (t->v[i].active && t->v[i].age == a0 + 1u)
            w = &t->v[i];
    bad += check("PIT GLD 1 -> 2: the added note starts at the only old note, not at C-1",
                 w && w->note == 64u && w->pitch_cur == 60 * 16 && w->fin_d == 4 * 16);
    seq_release(t);

    /* 4 -> 3: the extra old note glides to the nearest new one and releases */
    t->step[0] = (step_t){{60, 64, 67, 72}, 4, ST_NOTE, 0, 100};
    t->step[1] = (step_t){{62, 65, 69}, 3, ST_NOTE, 0, 100};
    seq_step(t, &t->step[0], 0, div_samples(2), 0);
    v = cvoice(t, 72);
    seq_step(t, &t->step[1], 1, div_samples(2), 0);
    bad += check("PIT GLD 4 -> 3: the extra note glides to the nearest new one and releases",
                 v && !v->gate && v->pitch16 == 69 * 16 && v->gq8);
    seq_release(t);

    /* plucky: the held chord's envelope dies, the next chord attacks again while it glides */
    t->p[P_SUS] = 0;
    t->p[P_DEC] = 20;
    t->p[P_REL] = 20;
    t->step[0] = (step_t){{60, 64, 67}, 3, ST_NOTE, 0, 100};
    t->step[1] = (step_t){{62, 65, 69}, 3, ST_NOTE, 0, 100};
    seq_release(t);
    seq_step(t, &t->step[0], 0, div_samples(2), 0);
    for (i = 0; i < 2000u; i++)
        track_render(t, out, CTL);
    v = cvoice(t, 60);
    ok = v && v->gate && v->stage == 2u && v->env < (1 << 12);
    seq_step(t, &t->step[1], 1, div_samples(2), 0);
    v = cvoice(t, 62);
    ok &= v && v->stage == 1u && v->gq8 && v->pitch_cur == 60 * 16;
    track_render(t, out, CTL);
    ok &= v && v->env > (1 << 12);
    bad += check("PIT GLD plucky: a dead held envelope attacks again at the new chord", ok);
    seq_release(t);
    t->p[P_SUS] = 120;
    t->p[P_DEC] = 70;
    t->p[P_REL] = 60;

    /* off: the same steps retrigger, nothing is held */
    t->step[0] = (step_t){{60, 64, 67, 72}, 4, ST_NOTE, 0, 100};
    t->step[1] = (step_t){{62, 65, 69}, 3, ST_NOTE, 0, 100};
    cgld_set(t, 0);
    seq_step(t, &t->step[0], 0, div_samples(2), 0);
    ok = !t->seq_hold && t->seq_n == 4u;
    seq_step(t, &t->step[1], 1, div_samples(2), 0);
    bad += check("PIT GLD off: POLY chords behave as before (no hold, no pairing)", ok && !t->seq_hold);
    seq_release(t);
    return bad;
}
/* PIT GLD live: notes in one block form a chord; a released chord keeps its voices for one 1/8 so the next pairs */
static int pit_gld_live(void)
{
    int bad = 0, ok;
    track_t *t;
    voice_t *v;
    uint32_t a0;
    ui_power_on();
    t = &trk[0];
    t->p[P_VOICE] = V_POLY;
    t->p[P_GLIDE] = 100;
    cgld_set(t, 1);
    t->engine = t->eng_req = 0;
    input_on(t, 60, 100);
    input_on(t, 64, 100);
    input_on(t, 67, 100);
    ok = !cvoice(t, 60);                                /* collected, started at the end of the block */
    chord_live_flush(t);
    ok &= t->lc_n == 3u && cvoice(t, 60) && cvoice(t, 64) && cvoice(t, 67);
    bad += check("PIT GLD live: note-ons in one block start as one chord", ok);
    input_off(t, 60);
    input_off(t, 64);
    input_off(t, 67);
    ok = cvoice(t, 60) && cvoice(t, 64) && cvoice(t, 67) && t->lc_off > 0;
    bad += check("PIT GLD live: a released chord keeps sounding for one 1/8", ok);
    a0 = cvoice(t, 60)->age;
    input_on(t, 62, 100);
    input_on(t, 65, 100);
    input_on(t, 69, 100);
    chord_live_flush(t);
    v = cvoice(t, 62);
    bad += check("PIT GLD live: the next chord glides into it, same voices, no retrigger",
                 v && v->age == a0 && v->pitch_cur == 60 * 16 && v->pitch16 == 62 * 16 && v->gq8 && t->lc_off == 0);
    input_off(t, 62);
    input_off(t, 65);
    input_off(t, 69);
    ok = cvoice(t, 62) && t->lc_off > 0;
    chord_live_tick(t, t->lc_off / 2u);
    ok &= cvoice(t, 62) != 0;
    chord_live_tick(t, t->lc_off);
    v = cvoice(t, 62);
    ok &= !v || !v->gate;
    bad += check("PIT GLD live: after the 1/8 the released notes let go", ok);
    return bad;
}

/* the same through the real transport: seq_tick advances the steps, the chord holds, the next step glides */
static int pit_gld_play(void)
{
    int bad = 0, ok;
    track_t *t;
    voice_t *v;
    int32_t out[CTL];
    uint32_t i, guard;
    ui_power_on();
    t = &trk[0];
    track_defaults_steps(t);
    t->p[P_SLEN] = 4;
    t->p[P_SSWING] = 0;
    t->p[P_VOICE] = V_POLY;
    t->p[P_GLIDE] = 127;
    t->p[P_SGATE] = 120;
    t->p[P_SUS] = 120;
    t->p[P_REL] = 100;
    cgld_set(t, 1);
    for (i = 0; i < 4u; i++)
        t->step[i] = (step_t){{}, 0, ST_REST, 0, 0};
    t->step[0] = (step_t){{60, 64, 67}, 3, ST_NOTE, 0, 100};
    t->step[1] = (step_t){{62, 65, 69}, 3, ST_NOTE, 0, 100};
    seq_start();
    for (guard = 0; guard < 10000u && t->seq_idx != 1u; guard++)
        events_block(CTL);
    ok = t->seq_idx == 1u && t->seq_n == 3u && cvoice(t, 62) && cvoice(t, 65) && cvoice(t, 69);
    v = cvoice(t, 62);
    ok &= v && v->gate && v->pitch_cur == 60 * 16 && v->pitch16 == 62 * 16 && v->gq8 && v->gstep > 0;
    if (v) {
        int32_t p0 = v->pitch_cur;
        for (i = 0; i < 2000u; i++)
            track_render(t, out, CTL);
        ok &= v->pitch_cur == v->pitch16 && v->pitch_cur != p0;
    }
    bad += check("PIT GLD through the transport: step 0 holds, step 1 glides each voice", ok);
    seq_stop();
    return bad;
}
int main(void)
{
    int bad = motion_recording() + motion_capacity() + probability_playback() + compact_project() + fun7_89() + loads_and_song() + repeat_mode();
    bad += arp_play_sync();
    bad += arp_new_modes();
    bad += arp_drone_mode();
    bad += lock_playback() + lock_edit() + lock_pitch() + pitch_lock_only() + record_trn() + pitch_matrix() + pitch_gate() + pitch_kit() + bend_lane() + lock_project() + lock_ui() + lock_undo() + auto_list();
    bad += fx_lock_time();
    bad += fx_lock_banks_and_capacity();
    bad += pit_gld_seq();
    bad += pit_gld_live();
    bad += pit_gld_play();
    printf("%s\n", bad ? "MOTION TEST FAILED" : "motion/chance/compact storage tests passed"); return bad != 0;
}
