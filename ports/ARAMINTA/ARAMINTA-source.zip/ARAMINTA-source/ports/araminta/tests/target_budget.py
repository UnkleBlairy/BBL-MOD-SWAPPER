#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
# Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
"""Target-side cost estimate of the hot DSP code, from the pi32v2 objdump listing tools/build.py writes
(build/felucca.dis). For each engine's render function and the audio ISR: the instructions
inside loops (every address range closed by a backward branch: the per-sample loops and what they
contain), and the hardware divides and calls in them. cost = the loop instructions, each weighted 4 per
level of nesting (an inner loop runs several times per sample) and 1 + 8 for a divide (many cycles). A static count, not a cycle count: it changes only when the compiled code changes,
so it is exact run to run, and it catches a render loop that grew (more work per sample, a new divide,
something not inlined any more). Compared with tests/target_budget.txt at +10 %. The host
CPU check (regress.c) is the primary one; this one sees the target compiler's code.
Over budget, a FUNCS name missing from DIS, a budget line with no function, and a budgeted function
with no loop instructions left are all failures: the gate cannot lose a function to a refactor silently.
  tests/target_budget.py [--require] [DIS [BUDGET]]
    BUDGET_UPDATE=1 rewrites BUDGET. --require fails when DIS is missing (the host gate); without it a
    missing DIS skips, for a manual run before ./build.sh."""
import os
import re
import sys

FUNCS = ["analog_render",                             # ANALOG's dispatcher: the loops are in the four below
         "analog_render_x", "analog_osc", "ana_shape", "ana_morph",
         "phase_render", "lofi_render", "formant_render",
         "trio_render", "trio_pass", "wheel_render", "wheel_block",
         "phys_render", "drum_render", "fm6_render", "fm6_core_render", "wt_render", "wt_read", "wt_mip_level",
         "px_modal_block", "px_modal_run", "px_memb_block",
         "px_string_excite", "px_string_run", "px_symp_run",
         "dx_run",                                            # DRUM-X voice (drumx_voice.c); its per-sample loops
         "dx_layer", "dx_shell", "dx_metal", "dx_teeth", "dx_click",   # out of line: FM / LAYER and the MODELs' voices
         "slicer_track",                                      # track FX slicer (SAMPLE/GRAIN/SLICE engines retired)
         "fm1_alnk0_irq", "fm1_timer5_irq",               # the audio ISR; TIMER5: the key / LED scan (hal/fm1_input.h)
         "uac_tap48",                                       # the USB audio input at 48 kHz: the 44.1 -> 48 resampler (usb.c)
         "click_render",                                    # the metronome's click (click.c), while it sounds
         "mod_begin", "mod_end",                              # the modulation matrix (mod.c), called when active
         "track_render_audio",                              # the voice loop (voice.c), mod_voice inlined in it
         "perf_begin", "perf_mute", "perf_pre", "perf_block", "perf_take", "perf_out",   # the FX layer (perform.c / fx.c), when busy
         "perf_flanger", "perf_phaser",                     # .. FLANGER, PHASER (1.2), while held or fading
         "perf_throw",                                      # .. REV / ECHO THROW (1.5.1): per part, while held or gliding
         "rev_room", "rev_spring", "rev_hall", "rev_shimmer", "rev_cloud", "rev_side_mix",  # reverb bus (fx.c)
         "track_insert", "ins_run_dist", "ins_run_swept",
         "ins_run_ott"]   # insert chain (fx.c): DIST (incl. its OTT mode) / swept stages while MIX > 0
# The DIGITAL engine and its conversion (fm4_convert.c) were removed in 3.6. Any old budget lines for
# its render loops are gone.
OPTIONAL = {"uac_tap48": 504}   # (absent from a FELUCCA_UAC_48K=0 or FELUCCA_UAC=0 build)
TOL = 0.10                      # exact (no noise): small edits pass, a grown render loop does not
DIV_W = 8                       # a divide weighs 1 + 8 instructions
NEST = 4                        # an instruction in a loop inside a loop weighs 4, two deep 16, ...
MAXD = 4

ARGS = [a for a in sys.argv[1:] if a != "--require"]
REQUIRE = "--require" in sys.argv[1:]
dis = ARGS[0] if len(ARGS) > 0 else "build/felucca.dis"
budget = ARGS[1] if len(ARGS) > 1 else "tests/target_budget.txt"
LABEL = re.compile(r"^([A-Za-z_][A-Za-z_0-9.]*):$")
INSN = re.compile(r"^\s*([0-9a-f]+):\s+((?:[0-9a-f]{2} )+)\s*(.*)$")
TARGET = re.compile(r"goto -?\d+ <[^>]*: ([0-9a-f]+) >")


def functions(path):
    """{name: [(addr, text)]}: a function runs to the next label not starting with '.' (the compiler's
    jump-table labels are inside functions); jump-table data ('< n : 0x.. >') is left out"""
    out, cur = {}, None
    with open(path) as f:
        for line in f:
            m = LABEL.match(line.strip())
            if m:
                name = m.group(1)
                if not name.startswith("."):
                    cur = out.setdefault(name, []) if name in FUNCS else None
                continue
            m = INSN.match(line)
            if cur is not None and m and not m.group(3).lstrip().startswith("<"):
                cur.append((int(m.group(1), 16), m.group(3).strip()))
    return out


def cost(insns):
    """loops: one span per loop head (the farthest backward branch to it); an instruction inside d
    spans weighs NEST ** (d - 1) (an inner loop runs several times per pass of the outer one)"""
    lo = insns[0][0]
    heads = {}
    for a, t in insns:
        m = TARGET.search(t)
        if m and lo <= int(m.group(1), 16) < a:
            h = int(m.group(1), 16)
            heads[h] = max(heads.get(h, a), a)
    n = divs = calls = 0
    w = 0
    for a, t in insns:
        d = min(sum(1 for h, e in heads.items() if h <= a <= e), MAXD)
        if not d:
            continue
        k = NEST ** (d - 1)
        n += 1
        if re.search(r"= r\d+ / r\d+", t):
            divs += 1
            k *= 1 + DIV_W
        calls += t.startswith("call")
        w += k
    return {"insns": len(insns), "loop": n, "div": divs, "call": calls, "cost": w}


def main():
    if not os.path.exists(dis):
        print(f"target: {'FAIL' if REQUIRE else 'skip'} ({dis} missing: run ./build.sh)")
        return 1 if REQUIRE else 0
    update = bool(os.environ.get("BUDGET_UPDATE"))
    fns = functions(dis)
    res = {n: cost(fns[n]) for n in FUNCS if fns.get(n)}
    missing = [n for n in FUNCS if n not in res and n not in OPTIONAL]
    base = {}
    if os.path.exists(budget):
        for line in open(budget):
            p = line.split()
            if len(p) >= 2 and not line.startswith("#"):
                base[p[0]] = int(p[1])
    if update:
        with open(budget, "w") as f:
            f.write("# FELUCCA target cost budget (tests/target_budget.py): instructions in the loops of each\n"
                    f"# function in build/felucca.dis, x{NEST} per nesting level, divides x{1 + DIV_W}. The check allows "
                    f"+{TOL * 100:.0f} %.\n# Rewritten by BUDGET_UPDATE=1.\n")
            for n, r in res.items():
                if n not in OPTIONAL:
                    f.write(f"{n} {r['cost']}\n")
        print(f"target: budget {budget} rewritten ({len(res)} functions)")
    fail = 0
    for n in missing:
        print(f"target: FAIL {n} not found in {dis} (renamed? inlined? update FUNCS)")
        fail += 1
    if not update:
        for n in base:
            if n not in res and n not in OPTIONAL:      # a budget line nothing measures any more
                print(f"target: FAIL {n} has a budget in {budget} but no function in {dis} "
                      f"(renamed? remove the line or update FUNCS)")
                fail += 1
    for n, r in res.items():
        b = base.get(n, OPTIONAL.get(n))
        state = "no budget (BUDGET_UPDATE=1 adds it)" if b is None else "ok"
        if b is not None and not update:
            if b > 0 and not r["loop"]:                 # a function that had loops has none: coverage is gone
                state = "FAIL: no loop instructions (moved into a callee? update FUNCS / budget)"
                fail += 1
            elif r["cost"] > b * (1 + TOL):
                state = ("OVER BUDGET (0: no loops expected here)" if b == 0 else
                         f"OVER BUDGET (+{(r['cost'] / b - 1) * 100:.0f} %, limit +{TOL * 100:.0f} %)")
                fail += 1
            elif r["cost"] < b * (1 - TOL):
                state = f"note: {(r['cost'] / b - 1) * 100:.0f} % (BUDGET_UPDATE=1 to keep it)"
        print(f"target: {n:15s} {r['insns']:5d} instructions, {r['loop']:4d} in loops, {r['div']} divides, "
              f"{r['call']:2d} calls there: cost {r['cost']:5d} (budget {b if b is not None else '-'}) {state}")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
