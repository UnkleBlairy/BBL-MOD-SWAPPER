/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Projects: four slots. The slots live in .noinit RAM: they
 * survive resets and UBOOT entry. With FELUCCA_FLASH (default) every save
 * also goes to flash through storage.c, and an
 * empty RAM slot is filled from flash on load.
 *
 * Format 7 ("FUN7", written) stores P_COUNT (byte 66) and maps an older count as user presets do: FUN7 of
 * 89 parameters (before the chord keys P_CHRD / P_VOIC) loads its engine values at today's P_E0..P_E7,
 * the chord keys OFF / CLOSE, and its motion events' ids from its P_E0 on move up with them (proj_motion_ids).
 * 68 + 4 x (91 + 2 + 64 x 9) + chain + motion = 3040 of the 3372 bytes before the name: 332 spare, room for
 * 83 more track parameters (4 bytes each).
 * Formats 1..6 (Felucca 0.x .. the 1.0 development builds) are not read since 3.6: their readers cost more than
 * the slot had, and their content can be converted in the web editor before uploading. A slot that holds one is
 * refused (EMPTY), as one of another firmware's format would be.
 *
 * Track 4 was the GM drum part until 1.0 (no engine: its byte 0; its level and reverb send in the
 * globals G_DRLVL / G_DRREV, which are inert now). A project says which it has in `parts`: NPART
 * when written since, 0 before (a reserved byte, always written 0: the format and its size did not
 * change). proj_drums_to_part turns such a track 4 into a DRUM part with its default kit (the GM map, so
 * its drum steps still play drums; until 1.0.2 it was the SAMPLE engine's PERC set), keeping its steps, its
 * pattern and mix parameters (LEN DIV SWING GATE, PAN MUTE), its SLICER, and the drum level and reverb send
 * as LEVEL and REV.
 *
 * The byte `phys` (reserved, always 0, before 1.0) says what a PHYS track's MODEL means: 0 MODEL 2 was
 * DUST (dropped: it loads as MODAL bowed, eng_phys.c phys_legacy); 1 MODEL 4 was DRUM (the kit is the DRUM
 * engine since: such a track loads as DRUM, core.h drum_from_phys); 2 (PROJ_PHYS) as today. proj_phys.
 *
 * Format 8 ("FUN8", written since 1.0) = FUN7 with each track's FM6 patch (eng_fm6.c, the 128-byte packed
 * record, 4 x 128 bytes just before the name): a project is self-contained. On load an FM6 track's SLOT shows F n
 * when its patch is that factory one, else OWN (eng_fm6.c fm6_adopt; a stored 9..40, the B slots of the patch bank
 * before 1.0.3 or of 1.4.1's voice bank, is OWN too: the project has the patch).
 * It is 3584 bytes (FUN7: 3388); FUN7 is read (its tracks get the init patch). Since 3.10 no wire image is
 * kept in RAM: a slot load reads flash once and the slot list draws from a small summary (proj_sum), filled
 * at boot and updated on a save or a restore.
 *
 * Format 9 ("FUN9", written since 1.1) = FUN8 with 64 more bytes: the DRUM lane levels (P_LN0..P_LN7, #97) made
 * P_COUNT 99 (P_E0 91), and 68 + 4 x (99 + 2 + 576) + chain + motion = 3072 no longer fit before FUN8's patches
 * (3056). 3648 bytes, the patches at PROJ_FM6_OFF (3120): 48 spare, room for 12 more track parameters. FUN8 (3584,
 * its 91 parameters mapped by count: the lane levels 100 %) and FUN7 are read; the retained cache grew again (its
 * slot 1 still starts with the older record, read as above).
 *
 * Format 10 ("FUNA", written since 1.2; FUN10 in the docs; read only since FUN11) = FUN9 laid out the same way, 3840
 * bytes (a whole storage object, storage.c ST_PAYLOAD_MAX), for four changes made together:
 *   - P_COUNT 104 (P_E0 96): LFO 2's SYNC TRIG POL, QUANTIZE and SPREAD (P_LSYNC .. P_SPRD) before the engine
 *     values. SPREAD (#148) came before FUN10's release, into the spare bytes below: a FUN10 of a 1.2 build before
 *     it holds 103 (byte 66) and loads by count (SPREAD 0, its engine values and their motion moved up by one);
 *   - 128 motion records (core.h MOTION_MAX, 64 before), 3 bytes each (place, id, the value as an int8_t: the values
 *     were always -64..127): the block is 4 + 384 = 388 bytes (FUN9's 260 held 64 of 4 bytes);
 *   - each step's NUDGE (core.h step_nudge, -8..+7) in bit 7 of its four note bytes (bit j in note j), bits every
 *     earlier format wrote 0: the step stays 9 bytes;
 *   - the song's sections (core.h chain_row_t): a slot per track (A..D or "-") and the repeats, 5 bytes a row: the
 *     chain is 4 + 16 x 5 = 84 bytes (FUN6..FUN9: 36, rows {slot, repeat}, chain_v9_t; they load as sections with the
 *     four tracks on the row's slot, song_chain.c chain_from_v9: the same song).
 * 68 + 4 x (104 + 2 + 576) + chain + motion = 3268; the patches at PROJ_FM6_OFF (3312): 44 spare, room for 11 more
 * track parameters. 1.5 took seven of them (no format change, FUN10 as it was): the INSERT (P_ITYPE .. P_IMIX, 96..100),
 * ANALOG's filter TYPE (P_FTYPE, 101) and ENV SYNC (P_ESYNC, 102), before the engine values (P_COUNT 111, P_E0 103; 16
 * spare, room for 4). A FUN10 of 1.2 .. 1.4 (104) loads by count: the INSERT OFF, TYPE LP, ENV SYNC OFF (as they
 * played), its engine values and their motion moved up by seven.
 * Firmware 1.2 .. 1.4 refuses a FUN10 of more parameters than its own (np > P_COUNT): a 1.5 project shows EMPTY there. FUN9 / FUN8 / FUN7 load as before (their 64 records of 4 bytes read by proj_motion_v9, every
 * step's nudge 0: the timing they always had; parameters mapped by count, the four new ones at their defaults:
 * SYNC OFF, TRIG NOTE, POL BI, QUANTIZE ON, SPREAD 0, which play as before 1.2), and so do FUN6..FUN1. Firmware before 1.2
 * refuses a FUN10 everywhere (its size and magic are no format it knows): a slot holding one shows EMPTY there (the
 * flash copy stays until that slot is saved over), a backup PUT of one is refused (rc 1), the retained RAM copy of
 * one fails its checks.
 *
 * Parameter locks (1.1, core.h MOTION_LOCK) are motion records with bit 7 of their id byte set (P_COUNT 99 < 128:
 * the bit is free): no byte moved for them, and every project before 1.1 has none. FUN9 holds them. A FUN8 / FUN7
 * record of a 1.1 development build may hold some: on load their ids move to today's positions as the others do,
 * the lock bit kept (proj_motion_ids). Firmware before 1.1 refuses a project that holds a lock (an id out of its
 * range), as with RATCH below; FUN9 it refuses anyway (a newer format).
 *
 * A step's RATCH (core.h SF_RATCH, the hits - 1, 0..3) is in bit 7 of its velocity byte (bit 0) and of its chance
 * byte (bit 1) of FUN7 / FUN8: bits every firmware before wrote 0, so every older project loads with its steps x1,
 * and no format or size changed. Firmware before RATCH refuses a project that holds a ratchet (those bytes out
 * of their range), as it would a newer format. FUN6..FUN1 have none (x1).
 *
 * DIGITAL (engine 1) was retired in 1.0; since 3.6 there is no conversion: a track of it loads on its silent stub.
 * (Convert such a project in the web editor before uploading if its sounds matter.)
 *
 * SAMPLE's SET 4, PERC (the GM drum kit), was retired after 1.0.2: a SAMPLE track that selects it, in any
 * format, loads as the DRUM engine with its default kit (core.h drum_from_perc: the same GM key map, its steps
 * as they are, the rest of its sound kept; proj_perc, on every import). Its motion events on the
 * EDIT values are dropped (SAMPLE's meanings, not DRUM's).
 *
 * SLICE (engine 13) stays retired (eng_retire.c): a SLICE track loads as DRUM's kit. Motion on EDIT values is
 * dropped. SAMPLE / GRAIN / NOISE are live again; SAMPLE PERC still becomes DRUM via proj_perc first.
 * Idempotent (proj_retire).
 *
 * Format 11 ("FUNB", FUN11 in the docs; read only since FUN12) = FUN10 with the DRUM-X kit (drumx_voice.c
 * dx_lane_t[8], 88 bytes, then mute lo/hi, a marker byte, X-MOD dx_mot[4]: 96 bytes at PROJ_DX_OFF just before the
 * FM6 patches), as JIANT's FUNA did. Still 3840 bytes: the motion disk block shrinks from 110 to 78 records
 * (MOTION_FILE_MAX_V11; RAM still holds 128) so the kit fits. FUN10 loads with the factory kit (DX_KIT_DEF).
 * JIANT's kits (after 3.10): each sound's LAYER (0..15) in bit 7 of its A PITCH PMOD DECAY NOISE and its MODEL (0..4)
 * in bit 7 of its B PITCH PMOD DECAY (drumx_voice.c dx_kit_pack; always 0 before, so an older kit loads with no LAYER,
 * CLASSIC) and the filter GR in the mode's filter field. The
 * place and size are FUN11's; firmware of 3.10 and before refuses a kit with either.
 *
 * Format 12 ("FUNC", FUN12 in the docs; read only since FUN13) = FUN11 with SCALE LOCK + ROOT/SCL/MAP stash
 * (16 bytes at PROJ_SCL_OFF before CRV). Motion on disk shrinks to 72 records (MOTION_FILE_MAX). FUN11 loads with
 * LOCK=SCALE and no stash. Firmware that only knows FUN11 refuses a FUN12 (magic): its slot shows EMPTY until
 * saved over.
 *
 * Format 13 ("FUND", written now; FUN13 in the docs) = FUN12 layout with CHR removed from SCL (15 scales: MAJ..DIMWH).
 * FUN12 and older: SCL index 0 was CHR -> MAJ; 1..15 -> 0..14 (stash too). Firmware that only knows FUN12 refuses
 * a FUN13 (magic): its slot shows EMPTY until saved over.
 * Format 14 ("FUNE", read only) = FUN13 wire with SCALE LOCK lock-only, X-MOD dropped,
 * SEND bus knobs in those bytes, and each track's EFFECTS SLICER slot (fx_sl_pos) in the two pad bytes.
 * Lock byte: bits 0..3 lock, bits 4..6 legacy G_SLOWN owner (0..4), bit 7 = bus+slcr layout mark.
 * Per-track SLICER SEND mask (bits 0..3 of G_SLOWN) is in the DX pad byte with mark 0x10.
 * FUN13 ("FUND") still loads: its pad mark at +17 means bus knobs without SLCR slots (fx_sl_pos defaults to 8).
 * Format 15 ("FUNF", read only since FUN16) retains FUN14's extent and 72 three-byte motion records. Motion-only
 * FX target ids reuse excluded matrix-assignment ids. TIME's low byte is the value; codes 54..59 carry
 * high bytes 1..6, so exact milliseconds need one record. Old motion layouts decode separately.
 *
 * Format 16 ("FUNG", read only since FUN17; FUN16 in the docs) = FUN15 with the song's chain packed: a section is
 * 2 bytes (4 slots x 3 bits, repeats - 1 x 4 bits) after the 4-byte header, 36 bytes instead of 84, which pays for
 * 88 motion records (4 + 88 x 3 = 268) instead of 72. Everything from PROJ_SCL_OFF on stays where it was. FUN15
 * and older load; firmware that only knows FUN15 refuses a FUN16 (magic): its slot shows EMPTY until saved over.
 *
 * Format 17 ("FUNH", read only since FUN18; FUN17 in the docs) = FUN16 with each track's ten-slot EFFECTS order (six inserts
 * + DLY + REV + SLCR + TAPE) in the unused high bits of its FM6 patch bytes, after the six generation controls.
 * The object and every offset are unchanged; FUN16 and older rebuild the order from P_IORD / P_CHOR / fx_sl_pos
 * and load with TAPE off (their TAPE fields' ids meant other things). Firmware that only knows FUN16 refuses a FUN17 (magic), as before.
 * Format 18 ("FUNI", read only since FUN19; FUN18 in the docs) = FUN17 with the MASTER owner of each EFFECTS stage in the
 * chain header's spare bytes 1..3 and the motion header's spare byte 3 (ten 3-bit owners). Older firmware refuses
 * a FUN18 (magic); FUN17 and older load with no MASTER owners. Three spare FM6 high bits after the EFFECTS
 * order hold its MASTER ordering track plus one; zero retains the legacy first-owner ordering.
 * Format 19 ("FUNJ", written now; FUN19 in the docs) = FUN18 with the TAPE's TEMPO switch in header byte 67 bit 7
 * (bit 0 still marks the CHAIN tank bytes). Older firmware refuses a FUN19 (magic); FUN18 and older load with
 * TEMPO ON. The stored bit keeps its value across this meaning swap, and ON now means the transport keeps time.
 *
 * 3.5 (ANALOG's OSC A / OSC B): P_E7 is INT now (OSC B's interval, -24..24), where it was KTR, and the FM
 * slots keep MORPH / DRIFT / WAVE2 (core.h P_MORPH / P_DRIFT / P_WAVE2), not the OP envelopes, on an ANALOG
 * track. Header byte 67 bit 1 (free before: 1.5 wrote 0 there) says a project is read that way; a FUN19
 * without it loads its ANALOG tracks with INT / MORPH / DRIFT 0, WAVE2 SAME, and drops their
 * E8 / OP events. The magic and size are FUN19's; older firmware ignores the bit.
 *
 * 3.6 (FM6's VIB): P_E5 is VIB, not VMOD. Header byte 67 bit 2 says a project is read that way; without it,
 * proj_fm6m moves each FM6 track's E5 into the patch's modulator velocity sensitivity and drops its E5
 * events. The magic and size stay FUN19's; older firmware ignores the bit.
 *
 * 4.3 (LFO SYNC ON / OFF): P_LSYNC is ON / OFF and RATE holds the note value while it is on; before, P_LSYNC held the
 * note value (OFF, 4BAR .. 1/32) and RATE did nothing. Header byte 67 bit 3 says a project is read that way; without
 * it, proj_lsync makes each synced track SYNC ON with RATE on its note value and drops that track's RATE events. The
 * magic and size stay; older firmware ignores the bit (and reads SYNC ON as 4BAR).
 *
 * Format 21 ("FUNL", 4.3; FUN21 in the docs) = FUN20 (4096 B, "FUNK", read only) grown to 4864 B. Bytes 0..4079 keep
 * FUN20's places (the 40 B of its 5-bit lane at 3944 stay 0); from 4080 the tail: the punch-in lane as 64 effect
 * masks (PROJ_LANE_OFF, any effects a step) and motion records 149..255 (PROJ_MOTION_TAIL_OFF), so a save keeps
 * every record RAM holds; the name and the hash end the file as before. A FUN20 loads with its lane's one effect a
 * step as a mask (proj_lane20). Older firmware refuses a FUN21 (magic).
 *
 * Built on the Mac too (tests/project_test.c, -DPROJ_HOST): the part above the #ifndef
 * PROJ_HOST needs core.h, params.c (TP) and engines.c. */
#define PROJ_MAGIC 0x4C4E5546u                 /* "FUNL" (FUN21): FUN20 + the tail: lane masks, records 149..255 */
#define PROJ_MAGIC_V20 0x4B4E5546u             /* "FUNK" (FUN20): FUN19 + 4 KiB store, append motion + lane */
#define PROJ_MAGIC_V19 0x4A4E5546u             /* "FUNJ" (FUN19): FUN18 + TAPE TEMPO; 3840 B in the field */
#define PROJ_MAGIC_V18 0x494E5546u             /* "FUNI" (FUN18): FUN17 + MASTER owners */
#define PROJ_MAGIC_V17 0x484E5546u             /* "FUNH" (FUN17): FUN16 + the EFFECTS order (10 stages) in the
                                                * FM6 high bits */
#define PROJ_MAGIC_V16 0x474E5546u             /* "FUNG" (FUN16): packed song chain (2 bytes a row), 88 motion records */
#define PROJ_MAGIC_V15 0x46554E46u             /* "FUNF" (FUN15): read only; 72 motion records, 5-byte chain rows */
#define PROJ_MAGIC_V14 0x46554E45u             /* "FUNE" (FUN14): read only; SLCR list slots */
#define PROJ_MAGIC_V13 0x46554E44u             /* "FUND" (FUN13): read only; bus knobs, no SLCR slots */
#define PROJ_MAGIC_V12 0x46554E43u             /* "FUNC" (FUN12): read only; SCALE LOCK/stash, CHR at SCL 0 */
#define PROJ_MAGIC_V11 0x46554E42u             /* "FUNB" (FUN11): read only; kit, 78 motion records */
#define PROJ_MAGIC_V10 0x46554E41u             /* "FUNA" (FUN10): read only; no kit, 110 motion records on disk */
#define PROJ_MAGIC_V9 0x46554E39u              /* "FUN9": FUN8, 64 bytes longer (the DRUM lane levels, 99 parameters) */
#define PROJ_MAGIC_V8 0x46554E38u              /* "FUN8": FUN7 + the tracks' FM6 patches */
#define PROJ_MAGIC_V7 0x46554E37u              /* "FUN7": serialized (byte params, packed steps), chain, motion */
#define PROJ_NG_V2 27u                         /* wire header globals (FUN1..FUN11 at b+8); G_COUNT may be larger */
#define PROJ_NG_WIRE PROJ_NG_V2
#define PROJ_CRV_OFF 3214u                     /* FUN11+: CRSIZE, CRDAMP (CRTYPE in b[65]; b[67]=1 marks present) */
#define PROJ_SCL_SIZE 16u                      /* region before CRV pad: lock + SEND bus (or old stash) */
#define PROJ_SCL_OFF (PROJ_CRV_OFF - 18u)      /* 16 scl + 2 pad before CRV; motion ends here */
#define PROJ_SCL_MARK_OFF (PROJ_SCL_OFF + PROJ_SCL_SIZE + 1u) /* FUN13 pad after G_SLOWN: 1 = bus layout */
#define PROJ_FXBUS_SCL_N 15u                   /* first 15 SEND knobs after the lock byte */
#define PROJ_DX_MOT_OFF (PROJ_DX_OFF + 88u + 2u + 1u) /* was X-MOD; last 4 SEND knobs */
#define PROJ_SLPOS_OFF (PROJ_SCL_OFF + PROJ_SCL_SIZE) /* FUN14: 4 x nibble fx_sl_pos in 2 pad bytes */
#define PROJ_PHYS 2u                           /* project_t.phys: PHYS without DUST and DRUM (see the top) */
#define PROJ_NAME_LEN 12u                      /* the name: FUN7 bytes PROJ_NAME_OFF.. (the reserved tail's end) */
#define PROJ_GENERATION_MARK 0x47u             /* motion-header spare byte 2 marks FM6 high-bit controls */
/* A project's motion record is three bytes: SPEED 25..400 would not fit its signed value, so FUN18 stores
 * it in one byte, exact at 25 / 100 / 400 (the useful centre) and within ~2 % elsewhere. */
static uint8_t proj_tspeed_put(int32_t v)
{
    v = clamp(v, 25, 400);
    return (uint8_t)(v <= 100 ? ((v - 25) * 64 + 37) / 75 : 64 + ((v - 100) * 63 + 150) / 300);
}
static int16_t proj_tspeed_get(uint32_t raw)
{
    raw &= 127u;
    return (int16_t)(raw <= 64u ? 25 + (raw * 75 + 32) / 64 : 100 + ((raw - 64u) * 300 + 31) / 63);
}
typedef struct {                               /* one track */
    int16_t p[P_COUNT];
    uint8_t engine, preset;
    step_t step[NSTEP];
    int16_t scl_stash[3];                      /* FUN12+: MAP = ALL's ROOT/SCL stash */
    uint8_t scl_stash_ok;
    uint8_t fx_sl_pos;                         /* EFFECTS SLICER list slot 0..8; FUN14 wire */
    uint8_t fx_order[FX_LIST_N];               /* EFFECTS list order; FUN17 wire in the FM6 high bits */
    generation_t generation;
    int16_t mx[4][3];                          /* matrix slots 5..8 (core.h track_t.mx); FUN20 tail, PROJ_MX_OFF */
} proj_trk_t;
typedef struct {
    uint32_t magic, size;
    int16_t g[G_COUNT];
    uint8_t sel;                               /* the selected track */
    uint8_t parts;                             /* NPART; 0: track 4 is the old GM drum part (see the top) */
    uint8_t phys;                              /* PROJ_PHYS: PHYS MODEL values as today; 1: MODEL 4 was DRUM;
                                                * 0 (a reserved byte before 1.0): MODEL 2 was DUST */
    uint8_t rsv;
    uint8_t fm6_vib;                           /* header bit 2: P_E5 is VIB (else pre-VIB VMOD, proj_fm6m) */
    uint8_t lfo_sync;                          /* header bit 3: LFO SYNC is ON / OFF (else 1.2's note value, proj_lsync) */
    proj_trk_t t[NTRK];
    chain_config_t chain;
    motion_store_t motion;
    uint8_t fm6[NTRK][FM6_PACKED];             /* each track's FM6 patch, packed (eng_fm6.c) */
    dx_lane_t dx[8];                           /* the DRUM-X kit (drumx_voice.c; packed, LAYER and MODEL in its spare bits: dx_kit_pack); FUN11 */
    uint16_t dx_mute;                          /* group + lane mutes (eng_drum.c dx_mute) */
    uint8_t dx_mot[4];                         /* X-MOD (retired, eng_drum.c): always 0, the layout kept */
    uint8_t fx_bus[FX_BUS_N];                  /* SEND insert+slicer knobs (wire in reclaimed SCL/X-MOD bytes) */
    uint8_t fx_master[FX_LIST_N];              /* MASTER owner per EFFECTS stage; FUN18 wire */
    uint8_t fx_master_order;                   /* ordering track + 1; zero: legacy first owner */
    uint32_t lane[64];                         /* punch-in lane: each 1/16 step's effects (pfx_lane); FUN21 tail */
    uint8_t lane_tgt;                          /* tracks the lane acts on (pfx_ltgt); FUN20 append mark+1 */
    char name[PROJ_NAME_LEN];                  /* the project's name: upper-case ASCII 32..126, 0-padded; "" = none */
    uint32_t sum;
} project_t;
#define PROJ_LANE_NFX 27u                      /* perform.c PF_NFX: the effects a lane step holds (bits 0..26) */
#define PROJ_LANE_FX ((1u << PROJ_LANE_NFX) - 1u)
#define PROJ_LANE20_OCTD 14u                   /* perform.c PF_OCTD: the effect of a FUN20 lane's value 1 */
/* FUN20's lane (40 bytes at PROJ_LANE20_OFF): 64 steps x 5 bits, one effect a step (0 none; 1..11 OCT- .. x2,
 * 12 GLITCH, 13 REPEAT 1/12, 14..27 REPEAT 1/8 .. ECHO THROW: the PF_* from PF_OCTD on, wrapping) -> step s's mask */
static uint32_t proj_lane20(const uint8_t *l, uint32_t s)
{
    uint32_t bit = s * 5u, i = bit >> 3, w = l[i] | (uint32_t)l[(i + 1u) % 40u] << 8, v = (w >> (bit & 7u)) & 31u;
    return v && v <= PROJ_LANE_NFX ? 1u << ((v - 1u + PROJ_LANE20_OCTD) % PROJ_LANE_NFX) : 0u;
}
/* Serialized FUN7 keeps the retained cache's exact extent. Params are biased
 * bytes, steps pack n/time/flags. Reserved tail is zero and covered by hash.
 * The tail's last 12 bytes (PROJ_NAME_OFF, just before the hash) are the project's name since 1.0:
 * ASCII 32..126 (upper case), 0-padded, all 0 = no name ("PROJECT A"). Firmware before wrote them 0 and
 * never reads them, so every FUN7 file stays valid both ways; FUN6..FUN1 imports get no name.
 * FUN8: the same, 3584 bytes, the four packed FM6 patches at PROJ_FM6_OFF (before the name); 16 bytes of the
 * reserved tail were left for parameters added later. FUN9: the same, 3648 bytes (see the top). */
#define PROJ_STORE_SIZE 4864u                  /* FUN21 (4.3): of two sectors of one storage object (storage.c st_pmax);
                                                * the rest of them is room to grow */
#define PROJ_STORE_V20 4096u                   /* FUN20 (3.10 .. 4.2), still read */
#define PROJ_STORE_OLD 3840u                   /* FUN10..FUN19 in the field: one sector's payload, still read */
#define PROJ_STORE_V9 3648u                    /* FUN9 */
#define PROJ_MOTION_V9 260u                    /* the motion block of FUN7..FUN9: 64 x (place, id, i16 value) */
#define PROJ_STORE_V8 3584u                    /* FUN8 */
#define PROJ_STORE_V7 3388u                    /* FUN7 */
/* 3.10 Route 1: frozen offsets. DX and FM6 stay where they were (3216, 3312); FUN20's name was at 4080.
 * The 256 B append area (3824..4079) holds the extra motion records (120 B) and FUN20's lane (40 B). FUN21's tail
 * starts where FUN20's name was: the lane (64 masks), records 149..255, room, then the name and the hash. */
#define PROJ_TAIL_OFF 4080u
#define PROJ_LANE_OFF PROJ_TAIL_OFF                                       /* 4080: 64 x u32 (little-endian) */
#define PROJ_LANE_SIZE 256u
#define PROJ_MOTION_TAIL_OFF (PROJ_LANE_OFF + PROJ_LANE_SIZE)              /* 4336: records 149..255 */
#define PROJ_NAME_OFF (PROJ_STORE_SIZE - 4u - PROJ_NAME_LEN)              /* 4848 */
#define PROJ_DX_SIZE 96u                       /* kit 88 + mute 2 + marker 1 + X-MOD 4 + 1 pad (JIANT FUNA) */
#define PROJ_DX_OFF 3216u                      /* frozen: same as FUN11..FUN19 */
#define PROJ_FM6_OFF 3312u                     /* frozen: same as FUN10..FUN19 (NTRK * FM6_PACKED after DX) */
#define PROJ_APPEND_OFF (PROJ_FM6_OFF + NTRK * FM6_PACKED)   /* 3824: start of the 256 B append */
#define PROJ_MOTION_APPEND_OFF PROJ_APPEND_OFF               /* 120 B: motion records 88..127 */
#define PROJ_LANE20_OFF (PROJ_MOTION_APPEND_OFF + MOTION_FILE_APPEND_SIZE)  /* 3944: FUN20's 40 B lane (0 in FUN21) */
#define PROJ_APPEND_MARK_OFF (PROJ_LANE20_OFF + 40u) /* 3984 */
#define PROJ_APPEND_MARK 0x4Cu                 /* 'L': the lane (and lane_tgt after the mark) present */
#define PROJ_MOTION_SPARE_OFF (PROJ_APPEND_MARK_OFF + 2u)    /* after mark + lane_tgt: records 129..148 */
/* The matrix's slots 5..8 (4.2): after the spare motion, to FUN20's name (FUN21's tail). Per track four slots of 17
 * bits, SRC (4 bits), DST (6), AMT + 64 (7), slot 5 of track 1 first, LSB first. A FUN20 file of 4.1 holds 0 there
 * (off) unless it saved more than 148 records, whose records 149..155 lie there: such a file has no slots
 * (proj_unpack tells by its count) */
#define PROJ_MX_OFF (PROJ_MOTION_SPARE_OFF + MOTION_FILE_SPARE_SIZE)     /* 4046 */
#define PROJ_MX_SIZE 34u                                                 /* 4 tracks x 4 slots x 17 bits */
#define PROJ_SL_SEND_OFF (PROJ_DX_OFF + PROJ_DX_SIZE - 1u) /* SLICER SEND mask | 0x10 mark */
typedef union { uint32_t align; uint8_t raw[PROJ_STORE_SIZE]; } project_store_t;
_Static_assert(PROJ_NG_WIRE == 27u && G_COUNT >= PROJ_NG_WIRE, "FUN7 wire globals keep IDs 0..26");
_Static_assert(G_COUNT == 32u, "CHAIN reverb + G_SLOWN + TAPE TEMPO appended");
_Static_assert(sizeof(project_store_t) == 4864u && PROJ_STORE_V7 == 3388u, "FUN21 / FUN7 sizes");
_Static_assert(PROJ_CRV_OFF + 2u <= PROJ_DX_OFF, "CHAIN reverb bytes before DX kit");
_Static_assert(sizeof(dx_lane_t[8]) == 88u && PROJ_DX_OFF == 3216u, "FUN11 kit place, frozen in 3.10");
_Static_assert(PROJ_FM6_OFF == 3312u && PROJ_FM6_OFF == PROJ_DX_OFF + PROJ_DX_SIZE, "FM6 after DX kit, frozen");
/* 3.10: the object grew to two sectors; the append area (3824..4079) sits after FM6 and before the tail:
 * overflow motion (120 B), FUN20's lane (40 B), mark+lane_tgt, then spare motion and the matrix's slots 5..8. */
_Static_assert(PROJ_TAIL_OFF - PROJ_APPEND_OFF == 256u, "the 256 B append area");
_Static_assert(PROJ_LANE20_OFF == 3944u && PROJ_APPEND_MARK_OFF == 3984u, "append lane placement");
_Static_assert(sizeof(((project_t *)0)->lane) == PROJ_LANE_SIZE && PROJ_MOTION_TAIL_OFF + MOTION_FILE_TAIL_SIZE <=
               PROJ_NAME_OFF && PROJ_NAME_OFF == 4848u, "FUN21 tail: lane, records 149..255, before the name");
_Static_assert(PROJ_MOTION_SPARE_OFF == 3986u, "spare motion after mark + lane_tgt");
_Static_assert(PROJ_MOTION_SPARE_OFF + MOTION_FILE_SPARE_SIZE_V20 <= PROJ_TAIL_OFF,
               "spare motion fits before the name");
_Static_assert(PROJ_MX_OFF == 4046u && PROJ_MX_OFF + PROJ_MX_SIZE == PROJ_TAIL_OFF && NTRK * 4u * 17u <= PROJ_MX_SIZE * 8u,
               "matrix slots 5..8 from the spare motion's end to the name");
_Static_assert(MS_N <= 16u && MD_N <= 64u, "matrix slots 5..8: SRC in 4 bits, DST in 6 on disk");
_Static_assert(PROJ_APPEND_MARK_OFF + 2u <= PROJ_TAIL_OFF, "append motion + lane + mark fit before the tail");
_Static_assert(MOTION_FILE_SIZE_V11 + PROJ_DX_SIZE == MOTION_FILE_SIZE_V10, "kit takes FUN10's motion spare");
_Static_assert(PROJ_SCL_OFF + PROJ_SCL_SIZE + 2u == PROJ_CRV_OFF, "FUN12 SCALE LOCK before CRV");
_Static_assert(68u + NTRK * (P_COUNT + 1u + 2u + NSTEP * 9u) + CHAIN_WIRE16_SIZE + MOTION_FILE_SIZE ==
               PROJ_SCL_OFF, "FUN16/17 motion ends at SCALE LOCK");
/* FUN17: each track's ten-slot EFFECTS order in the FM6 patch bytes' unused high bits (after generation's 48). */
#define PROJ_FXORDER_OFF 48u                    /* after generation's 6 x 8 high bits */
#define PROJ_MASTER_ORDER_OFF (PROJ_FXORDER_OFF + FX_LIST_N * 4u)
_Static_assert(PROJ_MASTER_ORDER_OFF + 3u <= FM6_PACKED, "EFFECTS and MASTER order in the FM6 high bits");
static int proj_order_ok(const uint8_t ord[FX_LIST_N])
{
    uint32_t i, seen = 0;
    for (i = 0; i < FX_LIST_N; i++) {
        if (ord[i] >= FX_LIST_N || (seen & (1u << ord[i])))
            return 0;
        seen |= 1u << ord[i];
    }
    return 1;
}
static void proj_fx_order_pack(uint8_t *b, uint32_t t, const uint8_t ord[FX_LIST_N])
{
    uint32_t k, j;
    for (k = 0; k < FX_LIST_N; k++)
        for (j = 0; j < 4u; j++)
            b[PROJ_FM6_OFF + t * FM6_PACKED + PROJ_FXORDER_OFF + k * 4u + j] |=
                (uint8_t)(((ord[k] >> j) & 1u) << 7);
}
static void proj_fx_order_get(const uint8_t *b, uint32_t t, uint8_t ord[FX_LIST_N])
{
    uint32_t k, j;
    for (k = 0; k < FX_LIST_N; k++) {
        uint8_t v = 0;
        for (j = 0; j < 4u; j++)
            v |= (uint8_t)(((b[PROJ_FM6_OFF + t * FM6_PACKED + PROJ_FXORDER_OFF + k * 4u + j] >> 7) & 1u) << j);
        ord[k] = v;
    }
}
_Static_assert(68u + NTRK * (P_COUNT + 1u + 2u + NSTEP * 9u) + CHAIN_WIRE15_SIZE + MOTION_FILE_SIZE_V15 ==
               PROJ_SCL_OFF, "FUN15 lied in the same 3840 bytes");
#define PROJ_DEF_SOUND 0xFFu                   /* preset byte: the track's power-on sound, no steps */
#define PROJ_DEF_KEEP 0xFEu                    /* .. DRUM's kit (once SAMPLE PERC), steps and the rest kept */
/* Per-slot summary, so drawing the slot list never reads flash (3.10). Four slots: the name, whether the
 * slot holds a project, and what SONG draws of it (each track's length in 1/48s and its pattern picture).
 * Filled at boot with one flash read per slot, then updated from the project already in RAM on a save or
 * a backup restore. The 4 KiB wire images are no longer retained: a slot load reads flash once. */
typedef struct {
    char name[PROJ_NAME_LEN + 1u];
    uint16_t len48[NTRK];
    uint32_t den[NTRK];
    uint8_t cell[NTRK];
} proj_sum_t;
static proj_sum_t proj_slot_sum[4] __attribute__((unused));
static uint8_t proj_slot_used;                  /* bit k: slot k holds a project */
_Static_assert(sizeof(proj_sum_t) == 44u, "the slot summary");

#if !FELUCCA_FLASH
/* test-only: the harness provides this array for project storage when there's no flash */
extern project_store_t proj_slot[4];
#endif

/* G_RTYPE (id 24) was G_DRCH, the GM drum part's MIDI channel (0..16, 10 by default) until 1.0: a FUN7 may
 * hold any channel there; ROOM, the only reverb it knew */
static void proj_rtype_room(int16_t *g) { g[G_RTYPE] = 0; }

static uint32_t proj_hash(const void *p, uint32_t n)   /* FNV-1a over n bytes */
{
    const uint8_t *b = (const uint8_t *)p;
    uint32_t i, s = 0x811C9DC5u;
    for (i = 0; i < n; i++)
        s = (s ^ b[i]) * 16777619u;
    return s;
}
static uint32_t proj_sum(const project_t *p) { return proj_hash(p, sizeof *p - 4u); }
static int proj_ok(const project_t *q) { return q->magic == PROJ_MAGIC && q->size == sizeof *q &&
    q->sum == proj_sum(q) && chain_valid(&q->chain) && motion_valid(&q->motion); }

/* G_RTYPE (id 24) was G_DRCH, the GM drum part's MIDI channel (0..16, 10 by default) until 1.0: a project of a
 * format before FUN7 may hold any channel there. FUN7 came after it was inert (always 0), so only those imports
 * set it: ROOM, the only reverb they knew */
/* a project written with the GM drum part as track 4 (parts 0) -> track 4 a part (see the top);
 * project_load gives it DRUM's kit (PROJ_DEF_KEEP; the SAMPLE PERC sound until 1.0.2). Idempotent */
static void proj_drums_to_part(project_t *q)
{
    proj_trk_t *d = &q->t[NTRK - 1u];
    if (q->parts == NPART)
        return;
    d->engine = ENGI_DRUM;                      /* DRUM's first kit: independent of today's power-on drum sound */
    d->preset = PROJ_DEF_KEEP;
    d->p[P_LEVEL] = (int16_t)clamp(q->g[G_DRLVL], 0, 127);   /* the drum part's level and reverb send */
    d->p[P_REV] = (int16_t)clamp(q->g[G_DRREV], 0, 127);
    q->g[G_DRLVL] = q->g[G_DRREV] = 0;          /* (their ids are PUNCH and DUCK now: off) */
    q->parts = NPART;
    q->sum = proj_sum(q);
}

/* PHYS tracks of a project written before PROJ_PHYS (see the top) -> today's: DUST as MODAL bowed, MODEL
 * DRUM as the DRUM engine (its E values moved, the preset its first). Idempotent */
static void proj_phys(project_t *q)
{
    uint32_t k;
    if (q->phys >= PROJ_PHYS)
        return;
    for (k = 0; k < NTRK; k++) {
        proj_trk_t *d = &q->t[k];
        if (d->engine != ENGI_PHYS)
            continue;
        if (!q->phys)
            phys_legacy(&d->p[P_E0]);
        if (drum_from_phys(d->engine, &d->p[P_E0])) {
            d->engine = ENGI_DRUM;
            d->preset = 0;
        }
    }
    q->phys = PROJ_PHYS;
    q->sum = proj_sum(q);
}

/* the motion events of the tracks in hit whose id is what (0: any edit id, P_E0 and up) go from q; the rest
 * compact in place and the project's sum follows. The migrations below differ in what they drop only */
static void proj_motion_edit(project_t *q, uint32_t hit, uint32_t what)
{
    uint32_t i, n;
    for (i = n = 0; i < q->motion.count && i < MOTION_MAX; i++) {
        const motion_event_t *e = &q->motion.event[i];
        if (((hit >> (e->place >> 6)) & 1u) && (what ? MOTION_ID(e) == what : MOTION_ID(e) >= P_E0))
            continue;
        q->motion.event[n++] = *e;
    }
    for (i = n; i < q->motion.count && i < MOTION_MAX; i++)
        memset(&q->motion.event[i], 0, sizeof q->motion.event[i]);
    q->motion.count = (uint8_t)n;
    q->sum = proj_sum(q);
}

/* MFX_BEND reuses the inert FM1 ATK id. A file from before the BEND-aware build (header bit 4 clear) may hold
 * old DIGITAL automation there, indistinguishable by value alone: drop every id-61 record. A BEND-aware file
 * keeps a valid automation event and drops only a lock or a value outside the bend's -32..32 range. */
static void proj_motion_bend_fix(project_t *q, uint32_t bend_ok)
{
    uint32_t i, n = 0;
    for (i = 0; i < q->motion.count && i < MOTION_MAX; i++) {
        const motion_event_t *e = &q->motion.event[i];
        if (MOTION_ID(e) == MFX_BEND &&
            (!bend_ok || (e->param & MOTION_LOCK) || e->value < -32 || e->value > 32))
            continue;
        q->motion.event[n++] = *e;
    }
    for (i = n; i < q->motion.count && i < MOTION_MAX; i++)
        memset(&q->motion.event[i], 0, sizeof q->motion.event[i]);
    q->motion.count = (uint8_t)n;
    q->sum = proj_sum(q);
}

/* FM6 tracks of a project from before VIB (header bit 2 clear): P_E5 was VMOD. Move it into the
 * patch's modulator operators (fm6_old_vmod) and clear P_E5; the track's VMOD automation has no
 * patch target, so drop its E5 events. Idempotent: a VIB project returns at once. */
static void proj_fm6m(project_t *q)
{
    uint32_t k, hit = 0;
    if (q->fm6_vib)
        return;
    for (k = 0; k < NTRK; k++) {
        if (q->t[k].engine != ENGI_FM6)
            continue;
        hit |= 1u << k;
        if (q->t[k].p[P_E5]) {
            uint8_t v[FP_SIZE + 1u];
            fm6_unpack(q->fm6[k], v);
            fm6_old_vmod(v, q->t[k].p);
            fm6_pack(v, q->fm6[k]);
            q->t[k].p[P_E5] = 0;
        }
    }
    q->fm6_vib = 1;
    if (!hit) {
        q->sum = proj_sum(q);
        return;
    }
    proj_motion_edit(q, hit, P_E5);
}

/* Tracks of a project from before 4.3 (header bit 3 clear): LFO SYNC held the note value (1..10). It becomes SYNC ON
 * with RATE on that note value (params.c lsync_legacy); RATE's automation and locks on such a track did nothing while
 * synced and would now move the note value, so they go. Idempotent: a 4.3 project returns at once. */
static void proj_lsync(project_t *q)
{
    uint32_t k, hit = 0;
    if (q->lfo_sync)
        return;
    for (k = 0; k < NTRK; k++)
        if (lsync_legacy(q->t[k].p))
            hit |= 1u << k;
    q->lfo_sync = 1;
    proj_motion_edit(q, hit, P_LRATE);
}

/* SAMPLE tracks of the retired PERC set (SET 4) -> DRUM with its default kit (see the top; core.h drum_from_perc,
 * whatever format the project is: on every load, the stored record keeps what it holds until it is saved again).
 * Their motion events on the EDIT values go. Idempotent */
static void proj_perc(project_t *q)
{
    uint32_t k, hit = 0;
    for (k = 0; k < NTRK; k++) {
        proj_trk_t *d = &q->t[k];
        if (!drum_from_perc(d->engine, &d->p[P_E0]))
            continue;
        d->engine = ENGI_DRUM;
        if (d->preset < PROJ_DEF_KEEP)
            d->preset = 0;
        hit |= 1u << k;
    }
    if (!hit)
        return;
    proj_motion_edit(q, hit, 0);
}

/* SLICE and DRUMS tracks -> DRUM (see the top; eng_retire.c). After proj_perc. DRUMS: the project's kit its KIT's
 * (the first DRUMS track's; eng_drum.c drums_kit) and its lane LEVELs scaled by the saved levels, unless a DRUM-X track
 * was there (one kit a project: theirs stays). EDIT motion on those tracks is dropped. Idempotent */
static void proj_retire(project_t *q)
{
    uint32_t k, i, hit = 0, drums = 0, drumx = 0, kit = 9u;
    dx_lane_t dk[8];
    uint8_t lay[8], mdl[8];
    int16_t ln[8];
    for (k = 0; k < NTRK; k++)
        drumx |= q->t[k].engine == ENGI_DRUM;
    for (k = 0; k < NTRK; k++) {
        proj_trk_t *d = &q->t[k];
        uint32_t was = d->engine, to;
        if (!eng_retired(was))
            continue;
        if (was == ENGI_DRUMS) {
            drums |= 1u << k;
            if (kit > 8u)
                kit = (uint32_t)clamp(d->p[P_E0], 0, 8);
        }
        to = retire_remap_params(was, d->p);
        d->engine = (uint8_t)to;
        if (d->preset < PROJ_DEF_KEEP)
            d->preset = 0;
        hit |= 1u << k;
    }
    if (!hit)
        return;
    if (kit <= 8u && !drumx) {
        drums_kit(kit, dk, lay, mdl, ln);
        dx_kit_pack(q->dx, dk, lay, mdl);
        for (k = 0; k < NTRK; k++)
            if ((drums >> k) & 1u)
                for (i = 0; i < 8u; i++)
                    q->t[k].p[P_LN0 + i] = (int16_t)(clamp(q->t[k].p[P_LN0 + i], 0, 127) * ln[i] / 127);
    }
    proj_motion_edit(q, hit, 0);
}

/* n bytes of a stored project (any format) -> slot q as format 6; 0 = not a project */
static int proj_unpack(project_t *q, const uint8_t *b, uint32_t size);
static int proj_import_any(project_t *q, const void *b, int n);
/* every track's engine one this firmware has (DIGITAL, 1, is one: it converts): a project of another number
 * is not one (it never was: no engine number past the last was ever stored) */
static int proj_engines_ok(const project_t *q)
{
    uint32_t t;
    for (t = 0; t < NTRK; t++)
        if (q->t[t].engine >= NENGINES)
            return 0;
    return 1;
}
/* FUN12 and older: SCL 0 was CHR (removed); 1..15 -> 0..14. FUN13 wire already uses the new indices. */
static int16_t scl_from_v12(int16_t sc)
{
    if (sc <= 0) return 0;                              /* CHR -> MAJ */
    if (sc > 15) return 0;
    return (int16_t)(sc - 1);
}

/* n bytes of a stored project (any format) -> q as today's, SAMPLE PERC / retired engines remapped; 0 = not a
 * project */
static int proj_import(project_t *q, const void *b, int n)
{
    if (!proj_import_any(q, b, n) || !proj_engines_ok(q))
        return 0;
    proj_fm6m(q);
    proj_lsync(q);
    proj_perc(q);
    proj_retire(q);
    return 1;
}
static int proj_import_any(project_t *q, const void *b, int n)
{
    {   /* FUN21 at 4864; the FUN10..FUN20 wire formats at either size: a field file is 3840 (PROJ_STORE_OLD), a
         * saved one 4096 (PROJ_STORE_V20). proj_unpack derives its name / FM6 offsets from the size it is given. */
        uint32_t m = ((const uint32_t *)b)[0];
        /* 3.10: a retained slot may hold an older, shorter record: use its own size from the header.
         * This must happen BEFORE the FUN10+ magic check so old-format data in a new-size slot works. */
        if (n == (int)PROJ_STORE_SIZE && ((const uint32_t *)b)[1] >= 8u && ((const uint32_t *)b)[1] < PROJ_STORE_SIZE)
            n = (int)((const uint32_t *)b)[1];
        if ((n == (int)PROJ_STORE_SIZE || n == (int)PROJ_STORE_OLD) && m == PROJ_MAGIC)
            return proj_unpack(q, b, n);
        if (n == (int)PROJ_STORE_V20 || n == (int)PROJ_STORE_OLD) {
            if (m == PROJ_MAGIC_V20 || m == PROJ_MAGIC_V19 || m == PROJ_MAGIC_V18 || m == PROJ_MAGIC_V17 ||
                m == PROJ_MAGIC_V16 || m == PROJ_MAGIC_V15 ||
                m == PROJ_MAGIC_V14 || m == PROJ_MAGIC_V13 || m == PROJ_MAGIC_V12 || m == PROJ_MAGIC_V11 ||
                m == PROJ_MAGIC_V10)
                return proj_unpack(q, b, n);
        }
    }
    if (n == (int)PROJ_STORE_V9 && ((const uint32_t *)b)[0] == PROJ_MAGIC_V9)
        return proj_unpack(q, b, PROJ_STORE_V9);
    if (n == (int)PROJ_STORE_V8 && ((const uint32_t *)b)[0] == PROJ_MAGIC_V8)
        return proj_unpack(q, b, PROJ_STORE_V8);
    if (n == (int)PROJ_STORE_V7 && ((const uint32_t *)b)[0] == PROJ_MAGIC_V7)
        return proj_unpack(q, b, PROJ_STORE_V7);
    if (n == (int)sizeof *q && proj_ok((const project_t *)b)) {
        memcpy(q, b, sizeof *q);
        proj_drums_to_part(q);
        proj_phys(q);
        return 1;
    }
    return 0;                                          /* FUN6..FUN1: no reader since 3.6 */
}
/* 12 stored name bytes -> d (PROJ_NAME_LEN + 1): up to the first 0, upper case; a byte outside 32..126 makes it
 * no name (a damaged tail never refuses the project) */
static uint32_t proj_name_get(char *d, const uint8_t *s)   /* its length */
{
    uint32_t i;
    for (i = 0; i < PROJ_NAME_LEN && s[i]; i++) {
        if (s[i] < 32u || s[i] > 126u) { i = 0; break; }
        d[i] = (char)(s[i] >= 'a' && s[i] <= 'z' ? s[i] - 32u : s[i]);
    }
    d[i] = 0;
    return i;
}

/* A stable serialized schema: first header retains FUN6's fields; at byte66
 * np, format flags, then four byte-param tracks and nine-byte steps; FUN8: the patches at PROJ_FM6_OFF. */
/* the matrix's slots 5..8 of every track to / from the store at PROJ_MX_OFF (see there): 17 bits a slot, AMT as 7-bit
 * two's complement so that 0 bytes are slots at 0 (off). put: 0 when a value does not fit those bits */
static int proj_mx_put(uint8_t *b, const project_t *q)
{
    uint32_t t, k, j, bit = 0;
    for (t = 0; t < NTRK; t++)
        for (k = 0; k < 4u; k++) {
            const int16_t *r = q->t[t].mx[k];
            uint32_t w;
            if (r[MF_SRC] < 0 || r[MF_SRC] > 15 || r[MF_DST] < 0 || r[MF_DST] > 63 || r[MF_AMT] < -64 || r[MF_AMT] > 63)
                return 0;
            w = (uint32_t)r[MF_SRC] | (uint32_t)r[MF_DST] << 4 | ((uint32_t)r[MF_AMT] & 127u) << 10;
            for (j = 0; j < 17u; j++, bit++)
                b[PROJ_MX_OFF + bit / 8u] |= (uint8_t)(((w >> j) & 1u) << (bit % 8u));
        }
    return 1;
}
static void proj_mx_get(const uint8_t *b, project_t *q)
{
    uint32_t t, k, j, bit = 0;
    for (t = 0; t < NTRK; t++)
        for (k = 0; k < 4u; k++) {
            int16_t *r = q->t[t].mx[k];
            uint32_t w = 0;
            for (j = 0; j < 17u; j++, bit++)
                w |= (uint32_t)((b[PROJ_MX_OFF + bit / 8u] >> (bit % 8u)) & 1u) << j;
            r[MF_SRC] = (int16_t)(w & 15u);
            r[MF_DST] = (int16_t)((w >> 4) & 63u);
            r[MF_AMT] = (int16_t)(((w >> 10) & 127u) ^ 64u) - 64;   /* (sign-extended) */
        }
}

/* where motion record i lies in a stored FUN20 / FUN21 (pos: the motion block's header): the body's 88, the append's
 * 40, the spare's `spare` (20; 27 in a FUN20 of 4.1), then FUN21's tail */
static uint32_t proj_mot_off(uint32_t pos, uint32_t i, uint32_t spare)
{
    if (i < MOTION_FILE_MAX_BODY)
        return pos + 4u + 3u * i;
    i -= MOTION_FILE_MAX_BODY;
    if (i < MOTION_FILE_APPEND_MAX)
        return PROJ_MOTION_APPEND_OFF + 3u * i;
    i -= MOTION_FILE_APPEND_MAX;
    return i < spare ? PROJ_MOTION_SPARE_OFF + 3u * i : PROJ_MOTION_TAIL_OFF + 3u * (i - spare);
}

/* Pack at `st` bytes. FUN21 projects and the autosave use PROJ_STORE_SIZE (4864). PROJ_STORE_OLD (3840) remains
 * for host tests that build FUN10..FUN19 field images. */
static int proj_pack_st(project_store_t *out, const project_t *q, uint32_t st)
{
    uint8_t *b = out->raw; uint32_t pos = 68u, t, i; uint32_t magic = PROJ_MAGIC, size = st, sum;
    uint32_t name_off = st - 4u - PROJ_NAME_LEN, full = st == PROJ_STORE_SIZE;
    if (st != PROJ_STORE_SIZE && st != PROJ_STORE_OLD)
        return 0;
    for (t = 0; t < NTRK; t++)
        for (i = 0; i < FM6_PACKED; i++)
            if (q->fm6[t][i] > 127u) return 0;
    if (!chain_valid(&q->chain) || !motion_valid(&q->motion) || P_COUNT > 127u || !dx_kit_ok(q->dx)) return 0;
    memset(out, 0, sizeof *out); memcpy(b, &magic, 4); memcpy(b + 4, &size, 4);
    memcpy(b + 8, q->g, PROJ_NG_WIRE * sizeof(int16_t));
    b[62] = q->sel; b[63] = q->parts; b[64] = q->phys; b[66] = P_COUNT;
    b[65] = (uint8_t)clamp(q->g[G_CRTYPE], 0, 4);       /* CHAIN tank TYPE/SIZE/DAMP (spare; not in wire g[]) */
    b[67] = (uint8_t)(1u | (clamp(q->g[G_TTEMPO], 0, 1) << 7) | 2u | 4u | 8u | 16u);   /* bit 0: CHAIN tanks;
                                                            * bit 1: OSC 2 (INT / MORPH / DRIFT); bit 2: VIB;
                                                            * bit 3: LFO SYNC ON / OFF; bit 4: written by a
                                                            * BEND-aware build (id 61 is a bend, not FM ATK);
                                                            * bit 7: TAPE TEMPO */
    b[PROJ_CRV_OFF] = (uint8_t)clamp(q->g[G_CRSIZE], 0, 127);
    b[PROJ_CRV_OFF + 1u] = (uint8_t)clamp(q->g[G_CRDAMP], 0, 127);
    for (t = 0; t < NTRK; t++) {
        for (i = 0; i < P_COUNT; i++) {
            uint32_t k;
            if (i == P_IORD) {                          /* order in bits 0..9; send flags in 10..15 */
                k = (uint32_t)wire_iord_put(b + pos, b + pos + 1u, (uint16_t)q->t[t].p[i]);
            } else {
                int16_t pv = q->t[t].p[i];
                if (i == P_QUANT && pv == QN_CURR)
                    pv = QN_ALL;                    /* CURR is written as ALL + the lock bit: v3.1-readable */
                k = (uint32_t)wire_val_put(b + pos, pv);
            }
            if (!k)
                return 0;
            pos += k;
        }
        b[pos++] = q->t[t].engine; b[pos++] = q->t[t].preset;
        for (i = 0; i < NSTEP; i++) {
            const step_t *s = &q->t[t].step[i];
            uint32_t r = step_ratchet(s) - 1u;          /* RATCH: bit 7 of the velocity and chance bytes (see the top) */
            uint32_t nd = (uint32_t)step_nudge(s) & 15u;   /* NUDGE (FUN10): bit j in bit 7 of note j */
            if (s->n > 4u || s->time > ST_REST || s->probability > 101u)
                return 0;
            for (uint32_t j = 0; j < 4u; j++)           /* what proj_unpack checks, so a saved project always loads: */
                b[pos++] = (uint8_t)((step_note(s, j) > 127u ? 127u : step_note(s, j)) | (nd >> j & 1u) << 7);   /* notes and
                                                         * velocity 0..127, accents */
            b[pos++] = (uint8_t)(s->n | s->time << 3 | step_fl(s) << 5);   /* only on hits */
            b[pos++] = (uint8_t)((s->vel > 127u ? 127u : s->vel) | (r & 1u) << 7); b[pos++] = s->hit;
            b[pos++] = s->acc & s->hit;
            b[pos++] = (uint8_t)(s->probability | (r >> 1) << 7);
        }
    }
    if (pos + CHAIN_WIRE16_SIZE + MOTION_FILE_SIZE > PROJ_SCL_OFF) return 0;
    if (q->chain.count > CHAIN_ROWS) return 0;
    for (i = 0; i < q->chain.count; i++) {              /* (an invalid section never reaches the wire; rows past
                                                         * count are not part of the song and go out as zero) */
        if (q->chain.row[i].repeat < 1u || q->chain.row[i].repeat > 16u) return 0;
        for (t = 0; t < NTRK; t++)
            if (q->chain.row[i].slot[t] > CHAIN_SILENT) return 0;
    }
    {   /* FUN18 chain: a row is 2 bytes (4 slots x 3 bits, repeat - 1 x 4 bits); header byte 0 count,
         * bytes 1..3 the first eight MASTER owners (FUN16/17 wrote zeros there). */
        uint32_t mb = 0;
        b[pos++] = q->chain.count;
        for (t = 0; t < 8u; t++)
            mb |= (uint32_t)(q->fx_master[t] & 7u) << (3u * t);
        b[pos++] = (uint8_t)mb;
        b[pos++] = (uint8_t)(mb >> 8);
        b[pos++] = (uint8_t)(mb >> 16);
        for (i = 0; i < CHAIN_ROWS; i++) {
            uint32_t rp = q->chain.row[i].repeat, w;
            w = (rp ? rp - 1u : 0u) << 12;               /* (rows past count: chain_defaults' repeat 1) */
            for (t = 0; t < NTRK; t++)
                w |= (uint32_t)q->chain.row[i].slot[t] << (3u * t);
            b[pos++] = (uint8_t)w;
            b[pos++] = (uint8_t)(w >> 8);
        }
    }
    {   /* FUN21: every record (88 body + 40 append + 20 spare + the tail); a 3840 field image keeps 88 in the body */
        uint32_t cap = full ? MOTION_FILE_MAX : MOTION_FILE_MAX_BODY;
        uint32_t nmot = q->motion.count > cap ? cap : q->motion.count;
        b[pos] = (uint8_t)nmot;
        b[pos + 1u] = q->motion.on;
        b[pos + 2u] = PROJ_GENERATION_MARK;
        b[pos + 3u] = (uint8_t)((q->fx_master[8] & 7u) | ((q->fx_master[9] & 7u) << 3));
        for (i = 0; i < nmot; i++) {
            const motion_event_t *e = &q->motion.event[i];
            uint32_t id = MOTION_ID(e);
            uint8_t *wire = b + proj_mot_off(pos, i, MOTION_FILE_SPARE_MAX);
            wire[0] = e->place;
            if (id == MFX_TIME && e->value >= 256)
                id = MFX_DAMP + ((uint16_t)e->value >> 8); /* 54..59 carry TIME's high byte; no extra record */
            wire[1] = (uint8_t)(id | (e->param & MOTION_LOCK));
            if (id == MFX_TSPEED)                   /* 25..400 in one byte: exact at 25 / 100 / 400 */
                wire[2] = proj_tspeed_put(e->value);
            else
                wire[2] = (uint8_t)e->value;
        }
    }
    {   /* SCALE LOCK + G_SLOWN + SEND bus + SLCR slots; stash / dx_mot stay RAM-only */
        uint8_t locks = 0;
        uint16_t slpos = 0;
        for (t = 0; t < NTRK; t++) {
            uint8_t sp = q->t[t].fx_sl_pos < FX_LIST_N ? q->t[t].fx_sl_pos : 8u;
            if (q->t[t].p[P_QUANT] == QN_CURR)
                locks |= (uint8_t)(1u << t);
            slpos |= (uint16_t)((sp & 15u) << (t * 4u));
        }
        {   /* write SEND mask to DX pad; lock bits 4..6 keep a legacy owner when possible */
            uint32_t raw = (uint32_t)q->g[G_SLOWN], mask, ch, leg = 0;
            if (raw <= NTRK) {                       /* still legacy 0..4 in the project_t */
                leg = raw;
                mask = raw == 0u ? (1u << NTRK) - 1u : ((1u << NTRK) - 1u) ^ (1u << (raw - 1u));
            } else {
                mask = raw & ((1u << NTRK) - 1u);
                ch = (~mask) & ((1u << NTRK) - 1u);
                if (ch && !(ch & (ch - 1u))) {
                    while (!(ch & 1u)) {
                        ch >>= 1;
                        leg++;
                    }
                    leg++;
                }
            }
            b[PROJ_SCL_OFF] = (uint8_t)(0x80u | (leg << 4) | locks);
            b[PROJ_SL_SEND_OFF] = (uint8_t)(mask | 0x10u);
        }
        memcpy(b + PROJ_SCL_OFF + 1u, q->fx_bus, PROJ_FXBUS_SCL_N);
        memcpy(b + PROJ_DX_MOT_OFF, q->fx_bus + PROJ_FXBUS_SCL_N, FX_BUS_N - PROJ_FXBUS_SCL_N);
        b[PROJ_SLPOS_OFF] = (uint8_t)(slpos & 255u);
        b[PROJ_SLPOS_OFF + 1u] = (uint8_t)(slpos >> 8);
    }
    memcpy(b + PROJ_DX_OFF, q->dx, sizeof q->dx);
    b[PROJ_DX_OFF + sizeof q->dx] = (uint8_t)(q->dx_mute & DXG_ALL);
    b[PROJ_DX_OFF + sizeof q->dx + 1u] = (uint8_t)(q->dx_mute >> 8);
    b[PROJ_DX_OFF + sizeof q->dx + 2u] = 1u;            /* marker: kit layout as today */
    memcpy(b + PROJ_FM6_OFF, q->fm6, sizeof q->fm6);
    /* FM6 packed bytes are seven-bit SysEx data. Their unused high bits hold six controls per track;
     * original readers mask those bits, leaving the patch and the 72 motion slots intact. */
    for (t = 0; t < NTRK; t++) {
        const generation_t *g = &q->t[t].generation;
        const uint8_t *controls = (const uint8_t *)g;
        uint8_t ord[FX_LIST_N];
        if (g->density[0] > 100u || g->density[1] > 100u || g->density[2] > 100u || g->chaos > 100u)
            return 0;
        for (i = 0; i < sizeof *g; i++)
            for (uint32_t bit = 0; bit < 8u; bit++)
                b[PROJ_FM6_OFF + t * FM6_PACKED + i * 8u + bit] |= (uint8_t)(((controls[i] >> bit) & 1u) << 7);
        if (proj_order_ok(q->t[t].fx_order))
            memcpy(ord, q->t[t].fx_order, FX_LIST_N);
        else
            fx_order_default((uint16_t)q->t[t].p[P_IORD], q->t[t].p[P_CHOR], q->t[t].fx_sl_pos, ord);
        proj_fx_order_pack(b, t, ord);
    }
    if (q->fx_master_order > NTRK)
        return 0;
    for (i = 0; i < 3u; i++)
        b[PROJ_FM6_OFF + PROJ_MASTER_ORDER_OFF + i] |= (uint8_t)(((q->fx_master_order >> i) & 1u) << 7);
    if (full) {   /* the lane in the tail, its mark and tracks in the append (the motion was written above) */
        for (i = 0; i < 64u; i++)
            if (q->lane[i] & ~PROJ_LANE_FX)
                return 0;
        memcpy(b + PROJ_LANE_OFF, q->lane, PROJ_LANE_SIZE);
        b[PROJ_APPEND_MARK_OFF] = PROJ_APPEND_MARK;
        b[PROJ_APPEND_MARK_OFF + 1u] = q->lane_tgt;
        if (!proj_mx_put(b, q))                         /* the matrix's slots 5..8 */
            return 0;
    }
    {   /* the name (0-padded; stops at the first 0); offset follows `st` */
        char n[PROJ_NAME_LEN + 1u];
        memcpy(b + name_off, n, proj_name_get(n, (const uint8_t *)q->name));
    }
    sum = proj_hash(b, st - 4u); memcpy(b + st - 4u, &sum, 4);
    return 1;
}
static int proj_pack(project_store_t *out, const project_t *q) { return proj_pack_st(out, q, PROJ_STORE_SIZE); }
/* the motion of a FUN7 / FUN8 written with np parameters (np < P_COUNT: a FUN7 of 89 before the chord keys, every
 * FUN8 of 91 before the DRUM lane levels) -> today's ids: an event names a parameter id, and the ids from that
 * store's P_E0 (np - 8) on moved up with P_E0, as its values did (params_by_count); the ones below kept theirs. A
 * lock's bit 7 (MOTION_LOCK) stays: the id moves under it (a FUN8 / FUN7 of a 1.1 development build may hold
 * locks). 0: an id that store could not have named (np or more) */
static int proj_motion_ids(motion_store_t *m, uint32_t np)
{
    uint32_t i;
    for (i = 0; i < m->count && i < MOTION_MAX; i++) {
        uint32_t id = MOTION_ID(&m->event[i]);
        if (param_lock_only(id)) continue;            /* 3.2: not a p[] id; both formats of this build know it */
        if (id >= np) return 0;
        if (np < P_COUNT && id >= np - 8u)
            m->event[i].param = (uint8_t)((m->event[i].param & MOTION_LOCK) | (id + P_COUNT - np));
    }
    return 1;
}
/* 3.5: an ANALOG track's E8 (P_E7) was KTR (0..127) and is INT (-24..24), and its FM slots were
 * OP ENV, not MORPH / DRIFT / WAVE2: an older record's events there would change the sound, so they go
 * (with their locks) */
static void proj_ktr_motion(motion_store_t *m, const proj_trk_t *t)
{
    uint32_t i, n = 0;
    for (i = 0; i < m->count && i < MOTION_MAX; i++) {
        motion_event_t *e = &m->event[i];
        uint32_t tr = e->place >> 6, id = MOTION_ID(e);
        if (tr < NTRK && t[tr].engine == ENGI_ANALOG &&
            (id == P_E7 || id == P_MORPH || id == P_DRIFT || id == P_WAVE2))
            continue;
        m->event[n++] = *e;
    }
    m->count = (uint8_t)n;
}
/* the motion block of a FUN7 / FUN8 / FUN9 (PROJ_MOTION_V9 bytes at b: count, on, 2 reserved, 64 x (place, id, i16
 * value LE)) -> m: its records as they are (values -64..127, as motion_valid wanted then), the rest 0. 0: not one */
static int proj_motion_v9(motion_store_t *m, const uint8_t *b)
{
    uint32_t i;
    memset(m, 0, sizeof *m);
    if (b[0] > 64u)
        return 0;
    m->count = b[0];
    m->on = b[1];
    for (i = 0; i < m->count; i++) {
        const uint8_t *e = b + 4u + 4u * i;
        int32_t v = (int16_t)(e[2] | e[3] << 8);
        if (v < -64 || v > 127 || MFX_PARAM(e[1] & 127u))
            return 0;
        m->event[i].place = e[0];
        m->event[i].param = e[1];
        m->event[i].value = (int16_t)v;
    }
    return 1;
}

/* a stored FUN21 (st = PROJ_STORE_SIZE), FUN20..FUN10 (PROJ_STORE_V20, or PROJ_STORE_OLD), FUN9 (PROJ_STORE_V9: 64 motion records of 4 bytes, no nudges), FUN8
 * (PROJ_STORE_V8: FUN9 with its tail 64 bytes shorter) or FUN7 (PROJ_STORE_V7: no patches, the init one) */
static int proj_unpack(project_t *q, const uint8_t *b, uint32_t st)
{
    uint32_t pos = 68u, t, i, magic, size, sum, np = b[66], v7 = st == PROJ_STORE_V7, v10 = (st == PROJ_STORE_SIZE || st == PROJ_STORE_V20 || st == PROJ_STORE_OLD);
    uint32_t name_off = st - 4u - PROJ_NAME_LEN;
    uint32_t end = v10 ? PROJ_FM6_OFF : v7 ? name_off : (name_off - NTRK * FM6_PACKED);  /* v8/v9 derive; v10+ frozen */
    uint32_t v11 = 0, v12 = 0, v13 = 0, v14, v15 = 0, v16 = 0, v17 = 0, v18 = 0, v19 = 0, v20 = 0, v21, app, data_end = end;
    /* np>111: insert chain; FUN16: packed chain + MOTION_FILE_SIZE; FUN12..FUN15: 5-byte chain rows +
     * MOTION_FILE_SIZE_V15 + SCALE LOCK; FUN11: MOTION_FILE_SIZE_V11 + kit; FUN10: MOTION_FILE_SIZE_V10;
     * np<=111 (1.5): full 128-record block (no insert chain yet) */
    uint32_t mot, chn = v10 ? CHAIN_WIRE15_SIZE : sizeof(chain_v9_t);
    uint32_t iord2 = np > 111u ? 1u : 0u;               /* +1 byte per track for P_IORD high */
    uint32_t mot_max, osc2, bend_ok;
    memcpy(&magic, b, 4); memcpy(&size, b + 4, 4); memcpy(&sum, b + st - 4u, 4);
    v21 = magic == PROJ_MAGIC;                          /* FUN21: 4864 B, the tail */
    v20 = magic == PROJ_MAGIC_V20 || v21;               /* FUN20+: 4096 B, append motion + lane */
    app = v20 && st != PROJ_STORE_OLD;                  /* the append area (and FUN21's tail) on disk */
    v19 = magic == PROJ_MAGIC_V19 || v20;                /* FUN19+: OSC 2 / VIB / TAPE TEMPO bits */
    osc2 = v19 && (b[67] & 2u) != 0;                    /* OSC 2's INT / MORPH / DRIFT (see the top) */
    bend_ok = (b[67] & 16u) != 0u;                       /* written by a BEND-aware build (see proj_motion_bend_fix) */
    v18 = magic == PROJ_MAGIC_V18 || v19;
    v17 = magic == PROJ_MAGIC_V17 || v18;
    v16 = magic == PROJ_MAGIC_V16;
    v15 = magic == PROJ_MAGIC_V15;
    v14 = v16 || v17 || v15 || magic == PROJ_MAGIC_V14;
    if ((v16 || v17) && v10)
        chn = CHAIN_WIRE16_SIZE;
    if (v10) {
        if (v14)
            v11 = v12 = v13 = 1u;                    /* FUN14/15/16: bus knobs + SLCR slots */
        else if (magic == PROJ_MAGIC_V13)
            v11 = v12 = v13 = 1u;                    /* FUN13: bus knobs, no SLCR slots */
        else if (magic == PROJ_MAGIC_V12)
            v11 = v12 = 1u;                         /* FUN12: migrate SCL (CHR removed) after unpack */
        else if (magic == PROJ_MAGIC_V11)
            v11 = 1u;
        else if (magic != PROJ_MAGIC_V10)
            return 0;
    } else if (magic != (v7 ? PROJ_MAGIC_V7 : st == PROJ_STORE_V8 ? PROJ_MAGIC_V8 : PROJ_MAGIC_V9))
        return 0;
    if (v12) {
        mot = np > 111u ? ((v16 || v17) ? MOTION_FILE_SIZE : MOTION_FILE_SIZE_V15) : MOTION_FILE_SIZE_128;
        data_end = PROJ_DX_OFF;
        /* FUN21: 255 records; FUN20: 155 (148 since the matrix's slots 5..8); a 3840 B field image keeps 88 in the body */
        mot_max = (v16 || v17) ? (!app ? MOTION_FILE_MAX_BODY : v21 ? MOTION_FILE_MAX : MOTION_FILE_MAX_V20)
                               : MOTION_FILE_MAX_V15;
    } else if (v11) {
        mot = np > 111u ? MOTION_FILE_SIZE_V11 : MOTION_FILE_SIZE_128;
        data_end = PROJ_DX_OFF;
        mot_max = MOTION_FILE_MAX_V11;
    } else if (v10) {
        mot = np > 111u ? MOTION_FILE_SIZE_V10 : MOTION_FILE_SIZE_128;
        mot_max = MOTION_FILE_MAX_V10;
    } else {
        mot = PROJ_MOTION_V9;
        mot_max = 64u;
    }
    if (size != st || sum != proj_hash(b, st - 4u) ||
        np < 8u || np > P_COUNT || 68u + NTRK * (np + iord2 + 2u + NSTEP * 9u) + chn + mot > data_end)
        return 0;
    memset(q, 0, sizeof *q); q->magic = PROJ_MAGIC; q->size = sizeof *q;
    q->fm6_vib = (uint8_t)(v19 && (b[67] & 4u) != 0);
    q->lfo_sync = (uint8_t)(v19 && (b[67] & 8u) != 0);
    memcpy(q->g, b + 8, PROJ_NG_WIRE * sizeof(int16_t));
    for (i = PROJ_NG_WIRE; i < G_COUNT; i++)
        q->g[i] = GP[i].def;
    if (!v17) {                                      /* the ids were G_DMIX / G_MIDI / G_INFO / G_CLRSEQ / G_INITSND */
        q->g[G_TSPEED] = GP[G_TSPEED].def;
        q->g[G_TWOW] = GP[G_TWOW].def;
        q->g[G_TDROP] = GP[G_TDROP].def;
        q->g[G_TMIX] = 0;                            /* a project before TAPE loads with TAPE off, as it played (the
                                                      * web converter writes the same); a new one gets the defaults */
        q->g[G_TAPEMODE] = TAPE_SEND;
    }
    q->sel = b[62]; q->parts = b[63]; q->phys = b[64];
    if (q->g[G_DLYOWN] < 0 || q->g[G_DLYOWN] > (int16_t)NTRK)   /* was bus chorus CRT/CDP */
        q->g[G_DLYOWN] = 0;
    if (q->g[G_REVOWN] < 0 || q->g[G_REVOWN] > (int16_t)NTRK)
        q->g[G_REVOWN] = 0;
    /* G_SLOWN: DX pad mask|0x10 (per-track SEND), else FUN14 lock bits 4..6 / FUN13 pad / 0 */
    if (v14 && (b[PROJ_SCL_OFF] & 0x80u) && (b[PROJ_SL_SEND_OFF] & 0x10u)) {
        uint8_t mask = (uint8_t)(b[PROJ_SL_SEND_OFF] & ((1u << NTRK) - 1u));
        q->g[G_SLOWN] = mask == (uint8_t)((1u << NTRK) - 1u) ? 0 : (int16_t)mask; /* 0 = all SEND */
    } else if (v14 && (b[PROJ_SCL_OFF] & 0x80u)) {
        uint8_t so = (b[PROJ_SCL_OFF] >> 4) & 7u;
        q->g[G_SLOWN] = so <= 4u ? (int16_t)so : 0;
    } else if (v12 || v13) {
        uint8_t so = b[PROJ_SCL_OFF + PROJ_SCL_SIZE];
        q->g[G_SLOWN] = so <= 4u ? (int16_t)so : 0;
    } else {
        q->g[G_SLOWN] = 0;
    }
    if (v7 && (q->g[G_RTYPE] < 0 || q->g[G_RTYPE] > 1))   /* a FUN7 may still hold the old drum channel there */
        proj_rtype_room(q->g);
    if (v11 && (b[67] & 1u)) {                            /* CHAIN tank params in FUN11 spare */
        q->g[G_CRTYPE] = b[65] <= 4u ? (int16_t)b[65] : 0;
        q->g[G_CRSIZE] = (int16_t)b[PROJ_CRV_OFF];
        q->g[G_CRDAMP] = (int16_t)b[PROJ_CRV_OFF + 1u];
    } else {
        q->g[G_CRTYPE] = q->g[G_RTYPE];                   /* older projects: CHAIN matches SEND */
        q->g[G_CRSIZE] = q->g[G_RSIZE];
        q->g[G_CRDAMP] = q->g[G_RDAMP];
    }
    if (v19)                                              /* FUN19: TEMPO bit; older formats keep the ON default */
        q->g[G_TTEMPO] = (b[67] & 0x80u) ? 1 : 0;
    for (t = 0; t < NTRK; t++) {
        int16_t values[P_COUNT], def[P_COUNT];
        q->t[t].generation = GENERATION_DEFAULT;
        for (i = 0; i < np; i++) {
            if (iord2 && i == P_IORD) {                  /* two bytes LE: order 0..719, send flags above it */
                uint16_t raw;
                if (!wire_iord_get(b + pos, b + pos + 1u, &raw))
                    return 0;
                pos += 2u;
                values[i] = (int16_t)raw;
                continue;
            }
            if (!wire_val_get(b + pos, &values[i]))
                return 0;
            pos++;
        }
        q->t[t].engine = b[pos++]; q->t[t].preset = b[pos++];
        if (q->t[t].engine >= NENGINES) return 0;
        for (i = 0; i < P_COUNT; i++) def[i] = param_desc_of(q->t[t].engine, i)->def;
        params_by_count(q->t[t].p, values, np, def);
        ins_migrate(q->t[t].p, np);
        if (!osc2 && q->t[t].engine == ENGI_ANALOG) {   /* KTR -> INT; the FM slots were OP ENV */
            q->t[t].p[P_E7] = 0;
            q->t[t].p[P_MORPH] = 0;
            q->t[t].p[P_DRIFT] = 0;
            q->t[t].p[P_WAVE2] = 0;                    /* SAME */
        }
        if (!v13)
            q->t[t].p[P_SCALE] = scl_from_v12(q->t[t].p[P_SCALE]);
        for (i = 0; i < NSTEP; i++) {
            step_t *s = &q->t[t].step[i]; uint32_t meta, nd = 0;
            for (uint32_t j = 0; j < 4u; j++) {         /* (FUN10: bit 7 of note j is bit j of the nudge) */
                if (b[pos] > 127u && !v10) return 0;
                nd |= (uint32_t)(b[pos] >> 7) << j;
                step_set_note(s, j, b[pos++] & 127u);
            }
            meta = b[pos++];
            s->n = meta & 7u; s->time = (meta >> 3) & 3u; step_set_fl(s, (meta >> 5) & 3u);
            step_set_vel(s, b[pos] & 127u); meta |= (b[pos++] & 128u) << 1;      /* (RATCH bit 0 at bit 8 of meta) */
            s->hit = b[pos++]; s->acc = b[pos++];
            step_set_prob_raw(s, b[pos] & 127u); meta |= (b[pos++] & 128u) << 2;   /* (bit 1 at bit 9) */
            if (s->n > 4u || s->time > ST_REST || s->probability > 101u) return 0;
            if (s->acc & ~s->hit) return 0;
            step_set_ratchet(s, (meta >> 8) + 1u);
            step_set_nudge(s, (int32_t)(nd ^ 8u) - 8);
        }
    }
    if (v16 || v17) {                                   /* FUN16/17/18: 4 header bytes, then 16 rows of 2 */
        q->chain.count = b[pos];
        if (q->chain.count > CHAIN_ROWS || (b[pos + 1u] && !v18) || (b[pos + 2u] && !v18) ||
            (b[pos + 3u] && !v18)) return 0;
        if (v18) {
            uint32_t mb = (uint32_t)b[pos + 1u] | (uint32_t)b[pos + 2u] << 8 | (uint32_t)b[pos + 3u] << 16;
            for (t = 0; t < 8u; t++)
                q->fx_master[t] = (uint8_t)((mb >> (3u * t)) & 7u);
        } else
            memset(q->fx_master, 0, sizeof q->fx_master);
        for (i = 0; i < CHAIN_ROWS; i++) {              /* (rows past count round trip too: repeat 1) */
            uint32_t w = (uint32_t)b[pos + 4u + i * 2u] | (uint32_t)b[pos + 5u + i * 2u] << 8;
            q->chain.row[i].repeat = (uint8_t)((w >> 12) + 1u);
            for (t = 0; t < NTRK; t++)
                q->chain.row[i].slot[t] = (uint8_t)((w >> (3u * t)) & 7u);
        }
    } else if (v10)                                     /* (FUN10..FUN15: sections, a slot per track; before: rows) */
        memcpy(&q->chain, b + pos, sizeof q->chain);
    else {
        chain_v9_t c9;
        memcpy(&c9, b + pos, sizeof c9);
        if (!chain_from_v9(&q->chain, &c9)) return 0;
    }
    pos += chn;
    if ((v15 || v16 || v17) && b[pos + 2u] == PROJ_GENERATION_MARK) {
        for (t = 0; t < NTRK; t++) {
            generation_t *g = &q->t[t].generation;
            uint8_t *controls = (uint8_t *)g;
            memset(g, 0, sizeof *g);
            for (i = 0; i < sizeof *g; i++)
                for (uint32_t bit = 0; bit < 8u; bit++)
                    controls[i] |= (uint8_t)((b[PROJ_FM6_OFF + t * FM6_PACKED + i * 8u + bit] >> 7) << bit);
            if (g->density[0] > 100u || g->density[1] > 100u || g->density[2] > 100u || g->chaos > 100u)
                return 0;
        }
    }
    if (v10) {
        memset(&q->motion, 0, sizeof q->motion);
        q->motion.count = b[pos]; q->motion.on = b[pos + 1u];
        if (v18) {
            uint32_t mb = b[pos + 3u];
            q->fx_master[8] = (uint8_t)(mb & 7u);
            q->fx_master[9] = (uint8_t)((mb >> 3) & 7u);
        }
        if (q->motion.count > (np > 111u ? mot_max : MOTION_FILE_MAX_128))
            return 0;
        /* FUN20 / FUN21: past the body's 88 in the append, the spare and FUN21's tail (proj_mot_off); older formats
         * keep every record in the body (FUN10: 110, pre-release np<=111: 128). mot_max above is the only cap. */
        for (i = 0; i < q->motion.count; i++) {
            const uint8_t *wire = b + (app ? proj_mot_off(pos, i, v21 ? MOTION_FILE_SPARE_MAX : MOTION_FILE_SPARE_MAX_V20)
                                           : pos + 4u + 3u * i);
            motion_event_t *e = &q->motion.event[i];
            uint32_t id = wire[1] & 127u;
            e->place = wire[0]; e->param = wire[1];
            if ((v15 || v16 || v17) && (id == MFX_TIME || (id > MFX_DAMP && id <= MFX_DAMP + 6u))) {
                uint32_t hi = id == MFX_TIME ? 0u : id - MFX_DAMP;
                e->param = (uint8_t)(MFX_TIME | (wire[1] & MOTION_LOCK));
                e->value = (int16_t)(hi << 8 | wire[2]);
            } else {
                if (!(v15 || v16 || v17) && MFX_ALL(id)) return 0;
                e->value = id == MFX_TSPEED ? proj_tspeed_get(wire[2])
                                            : (int8_t)wire[2];
            }
        }
    } else if (!proj_motion_v9(&q->motion, b + pos))
        return 0;
    if (!proj_motion_ids(&q->motion, np)) return 0;
    if (!osc2)
        proj_ktr_motion(&q->motion, q->t);
    proj_motion_bend_fix(q, bend_ok);
    if (!chain_valid(&q->chain) || !motion_valid(&q->motion)) return 0;
    /* Old CHO send locks (P_CHOR 0..63) -> CHORUS MIX. FXPOS values (64+) stay. */
    if (!v14) {
        for (i = 0; i < q->motion.count && i < MOTION_MAX; i++) {
            motion_event_t *e = &q->motion.event[i];
            if (MOTION_ID(e) == P_CHOR && e->value >= 0 && e->value < (int8_t)FX_POS_MARK)
                e->param = (uint8_t)((e->param & MOTION_LOCK) | P_IHMIX);
        }
    }
    {
        int fun14 = v14 && (b[PROJ_SCL_OFF] & 0x80u);
        int bus_layout = fun14 || (v13 && magic == PROJ_MAGIC_V13 && b[PROJ_SCL_MARK_OFF] == 1u);
        for (t = 0; t < NTRK; t++) {
            if (v12 && bus_layout) {
                if ((b[PROJ_SCL_OFF] & (1u << t)) && q->t[t].p[P_QUANT] == QN_ALL)
                    q->t[t].p[P_QUANT] = QN_CURR;   /* locked + ALL is v3.2's CURR; other MAPs stay unlinked */
                q->t[t].scl_stash_ok = 0;
                q->t[t].scl_stash[0] = q->t[t].scl_stash[1] = q->t[t].scl_stash[2] = 0;
                if (fun14) {
                    uint8_t sp = (b[PROJ_SLPOS_OFF + t / 2u] >> ((t & 1u) * 4u)) & 15u;
                    q->t[t].fx_sl_pos = sp < FX_LIST_N ? sp : 8u;
                } else {
                    q->t[t].fx_sl_pos = 8u;
                }
            } else if (v12) {
                const uint8_t *s = b + PROJ_SCL_OFF + t * 4u;
                if ((s[0] & 1u) && q->t[t].p[P_QUANT] == QN_ALL)
                    q->t[t].p[P_QUANT] = QN_CURR;
                q->t[t].scl_stash_ok = (s[0] & 0x80u) ? 1u : 0u;
                q->t[t].scl_stash[0] = (int16_t)(s[1] <= 11u ? s[1] : 0u);
                q->t[t].scl_stash[1] = (int16_t)(s[2] <= (v13 ? 14u : 15u) ? s[2] : 0u);
                q->t[t].scl_stash[2] = (int16_t)(s[3] <= 3u ? s[3] : 0u);
                if (!v13)
                    q->t[t].scl_stash[1] = scl_from_v12(q->t[t].scl_stash[1]);
                q->t[t].fx_sl_pos = 8u;
            } else {
                q->t[t].scl_stash_ok = 0;           /* pre-FUN12: no lock bit; MAP stays as stored */
                q->t[t].scl_stash[0] = q->t[t].scl_stash[1] = q->t[t].scl_stash[2] = 0;
                q->t[t].fx_sl_pos = 8u;
            }
        }
        if (bus_layout) {
            memcpy(q->fx_bus, b + PROJ_SCL_OFF + 1u, PROJ_FXBUS_SCL_N);
            memcpy(q->fx_bus + PROJ_FXBUS_SCL_N, b + PROJ_DX_MOT_OFF, FX_BUS_N - PROJ_FXBUS_SCL_N);
        } else {
            fx_bus_wire_def(q->fx_bus);
        }
    }
    for (t = 0; t < NTRK; t++) {
        if (v7)
            memcpy(q->fm6[t], FM6_INIT, FM6_PACKED);
        else
            for (i = 0; i < FM6_PACKED; i++)
                q->fm6[t][i] = b[end + t * FM6_PACKED + i] & 0x7Fu;
        if (v17) {
            proj_fx_order_get(b, t, q->t[t].fx_order);
            if (!proj_order_ok(q->t[t].fx_order))
                return 0;
        } else {
            fx_order_default((uint16_t)q->t[t].p[P_IORD], q->t[t].p[P_CHOR], q->t[t].fx_sl_pos, q->t[t].fx_order);
            q->t[t].p[P_TAPEMIX] = 0;                /* the id was GLMOD: never read */
        }
    }
    if (v18) {
        for (i = 0; i < 3u; i++)
            q->fx_master_order |= (uint8_t)(((b[PROJ_FM6_OFF + PROJ_MASTER_ORDER_OFF + i] >> 7) & 1u) << i);
        if (q->fx_master_order > NTRK)
            return 0;
    }
    if (v11) {                                          /* DRUM-X kit (a broken one: not a project) */
        memcpy(q->dx, b + PROJ_DX_OFF, sizeof q->dx);
        if (!dx_kit_ok(q->dx)) return 0;
        q->dx_mute = (uint16_t)((b[PROJ_DX_OFF + sizeof q->dx] & DXG_ALL) |
                                (uint32_t)b[PROJ_DX_OFF + sizeof q->dx + 1u] << 8);
        memset(q->dx_mot, 0, sizeof q->dx_mot);         /* (X-MOD retired: an older layout's bytes ignored) */
    } else {
        dx_kit_pack(q->dx, DX_KIT_DEF, DX_LAY_DEF, DX_MDL_DEF);
        q->dx_mute = 0;
        memset(q->dx_mot, 0, sizeof q->dx_mot);
    }
    if (app && b[PROJ_APPEND_MARK_OFF] == PROJ_APPEND_MARK) {
        q->lane_tgt = b[PROJ_APPEND_MARK_OFF + 1u];
        if (v21)
            memcpy(q->lane, b + PROJ_LANE_OFF, PROJ_LANE_SIZE);
        for (i = 0; i < 64u; i++) {
            if (!v21)
                q->lane[i] = proj_lane20(b + PROJ_LANE20_OFF, i);
            if (q->lane[i] & ~PROJ_LANE_FX)             /* (a step of no effect we know: not a project) */
                return 0;
        }
    }
    if (app && (v21 || q->motion.count <= MOTION_FILE_MAX_BODY + MOTION_FILE_APPEND_MAX + MOTION_FILE_SPARE_MAX))
        proj_mx_get(b, q);                              /* (a FUN20 of more records: of 4.1, its 149..155 there) */
    {
        char n[PROJ_NAME_LEN + 1u];
        memcpy(q->name, n, proj_name_get(n, b + name_off));
    }
    q->sum = proj_sum(q); proj_drums_to_part(q); proj_phys(q);
    return 1;
}

#ifndef PROJ_HOST
_Static_assert(PF_NFX == PROJ_LANE_NFX && PF_OCTD == PROJ_LANE20_OCTD && sizeof pfx_lane == PROJ_LANE_SIZE,
               "the lane's effects as perform.c numbers them (proj_lane20, PROJ_LANE_FX)");
/* the GM drum part of a project of before 1.0 (proj_drums_to_part): DRUM's first kit, as a preset load sets it
 * (until 1.0.2 the SAMPLE engine's PERC set, retired since) */
static void proj_legacy_drums(track_t *t)
{
    static const uint8_t FX_DEF[4] = {0, 24, 28, 36};
    const preset_t *pr = &ENGINES[ENGI_DRUM]->presets[0];
    uint32_t i;
    t->eng_req = ENGI_DRUM;
    t->preset = 0;
    for (i = 0; i < P_E0; i++)
        if (!param_kept(i))
            t->p[i] = TP[i].def;
    memset(t->mx, 0, sizeof t->mx);                 /* matrix slots 5..8 OFF */
    for (i = 0; i < 8u; i++)
        t->p[P_E0 + i] = pr->e[i];
    t->p[P_ATK] = pr->env[0];
    t->p[P_DEC] = pr->env[1];
    t->p[P_SUS] = pr->env[2];
    t->p[P_REL] = pr->env[3];
    t->p[P_ED_FLT] = pr->fenv;
    t->p[P_VOICE] = pr->mono ? V_LEGATO : V_POLY;
    for (i = 0; i < 4u; i++)
        t->p[P_DIST + i] = (int16_t)(pr->fx[i] ? pr->fx[i] - 1 : FX_DEF[i]);
}

static project_t proj_scratch               /* decoded main-loop work, never audio ISR */
    __attribute__((unused));
static char proj_name[PROJ_NAME_LEN + 1u]    /* the name of the music as it is now (loaded, saved, the editor's */
    __attribute__((unused));       /* runtime restore); "" = none. A save takes it unless one is given */
#define PROJ_NO_SLOT 0xFFu
static uint8_t proj_cur = PROJ_NO_SLOT;      /* the slot the music was loaded from or last saved to (a rename of it
                                              * renames the music too); PROJ_NO_SLOT none (the editor's restore) */
static union {                               /* serialized main-loop work; no retained expansion */
    project_store_t s;
    uint8_t raw[PROJ_STORE_SIZE];              /* backup staging (editor_backup.c ED_BK_MAX); 3.10: 4096 */
} proj_wire_u __attribute__((unused));
#define proj_wire (proj_wire_u.s)
static uint8_t proj_wire_gen;                /* +1 whenever proj_wire is rewritten (a backup's runtime copy lives there) */

static void proj_steps(step_t *s)            /* a loaded sequence stays inside its fixed fields */
{
    uint32_t i, j;
    for (i = 0; i < NSTEP; i++) {
        if (s[i].n > 4u) s[i].n = 4;
        if (s[i].time > ST_REST) s[i].time = ST_REST;
        for (j = 0; j < 4u; j++) step_set_note(&s[i], j, step_note(&s[i], j) & 127u);
        s[i].acc &= s[i].hit;
    }
}

/* an imported older format may hold values FUN7 cannot pack: keep them inside the fields and ranges */
static void proj_bound(project_t *q)
{
    uint32_t t, i;
    for (t = 0; t < NTRK; t++) {
        proj_steps(q->t[t].step);
        for (i = 0; i < NSTEP; i++) {
            step_t *s = &q->t[t].step[i];
            if (s->probability > 101u) step_set_prob_raw(s, 0);
        }
        for (i = 0; i < P_COUNT; i++) {
            const param_desc_t *d = param_desc_of(q->t[t].engine % NENGINES, i);
            q->t[t].p[i] = (int16_t)param_fit(d, q->t[t].p[i]);   /* (a retired KIT: the kit it plays) */
        }
    }
    q->sum = proj_sum(q);
}

static uint32_t len48_of(int32_t len, int32_t div);
static uint32_t proj_density(const proj_trk_t *t, uint8_t *n);

/* one slot from flash into proj_scratch (format 7, or format 6 / 5 / 4 / 3 / 2 / 1 converted), and its
 * summary refreshed. 0 = the slot does not hold a loadable project. Event paths only: a slot load, SONG's
 * chain prepare, a backup restore, boot. */
static int proj_fetch(uint32_t slot)
{
    uint32_t k = slot & 3u;
    int n;
    proj_slot_used &= (uint8_t)~(1u << k);
    memset(&proj_slot_sum[k], 0, sizeof proj_slot_sum[k]);
#if FELUCCA_FLASH
    if (!flash_ok)
        return 0;
    proj_wire_gen++;
    n = st_load(OBJ_PROJECT0 + k, &proj_wire, sizeof proj_wire);
    if (!proj_import(&proj_scratch, &proj_wire, n))
        return 0;
#else
    /* test-only path: read from proj_slot (provided by the test harness) */
    if (!proj_import(&proj_scratch, &proj_slot[k], sizeof proj_slot[k]))
        return 0;
#endif
    proj_bound(&proj_scratch);
    proj_slot_used |= (uint8_t)(1u << k);
    proj_name_get(proj_slot_sum[k].name, (const uint8_t *)proj_scratch.name);
    for (n = 0; n < (int)NTRK; n++) {
        proj_slot_sum[k].len48[n] = (uint16_t)len48_of(proj_scratch.t[n].p[P_SLEN], proj_scratch.t[n].p[P_SDIV]);
        proj_slot_sum[k].den[n] = proj_density(&proj_scratch.t[n], &proj_slot_sum[k].cell[n]);
    }
    return 1;
}

/* the same summary from a project already in RAM (a save, a restore): no flash read */
static void proj_sum_set(uint32_t slot, const project_t *p)
{
    uint32_t k = slot & 3u, n;
    proj_slot_used |= (uint8_t)(1u << k);
    proj_name_get(proj_slot_sum[k].name, (const uint8_t *)p->name);
    for (n = 0; n < NTRK; n++) {
        proj_slot_sum[k].len48[n] = (uint16_t)len48_of(p->t[n].p[P_SLEN], p->t[n].p[P_SDIV]);
        proj_slot_sum[k].den[n] = proj_density(&p->t[n], &proj_slot_sum[k].cell[n]);
    }
}

/* 3.10 single-copy: a torn write erases the only image; drop the summary so menus do not claim a live slot */
static void proj_sum_clear(uint32_t slot)
{
    uint32_t k = slot & 3u;
    proj_slot_used &= (uint8_t)~(1u << k);
    memset(&proj_slot_sum[k], 0, sizeof proj_slot_sum[k]);
}

static void project_capture(project_t *p)
{
    uint32_t i;
    uint32_t f = motion_guard();
    memset(p, 0, sizeof *p);
    p->magic = PROJ_MAGIC;
    p->size = sizeof *p;
    for (i = 0; i < G_COUNT; i++)
        p->g[i] = motion_fx_base(&song.g[i]);
    p->sel = song.sel;
    p->parts = NPART;
    p->phys = PROJ_PHYS;
    p->fm6_vib = 1;
    p->lfo_sync = 1;
    p->chain = chain_config;
    for (i = 0; i < NTRK; i++) {
        for (uint32_t j = 0; j < P_COUNT; j++) p->t[i].p[j] = motion_base_value(&trk[i], j);
        p->t[i].engine = trk[i].eng_req;
        p->t[i].preset = trk[i].preset;
        memcpy(p->t[i].step, trk[i].step, sizeof trk[i].step);
        p->t[i].scl_stash_ok = trk[i].scl_stash_ok ? 1u : 0u;
        p->t[i].scl_stash[0] = trk[i].scl_stash[0];
        p->t[i].scl_stash[1] = trk[i].scl_stash[1];
        p->t[i].scl_stash[2] = trk[i].scl_stash[2];
        p->t[i].fx_sl_pos = trk[i].fx_sl_pos < FX_LIST_N ? trk[i].fx_sl_pos : 8u;
        fx_list_get(&trk[i], p->t[i].fx_order);
        p->t[i].generation = trk[i].generation;
        memcpy(p->t[i].mx, trk[i].mx, sizeof trk[i].mx);
        fm6_pack(fm6_patch[i], p->fm6[i]);
    }
    memcpy(p->fx_master, fx_master_tr, FX_LIST_N);
    if (song.g[G_TAPEMODE] != TAPE_MASTER)
        p->fx_master[INS_TAPE] = 0;
    else if (!p->fx_master[INS_TAPE])
        p->fx_master[INS_TAPE] = (uint8_t)((song.sel < NTRK ? song.sel : 0u) + 1u);
    for (i = 0; i < FX_LIST_N; i++)
        if (p->fx_master[i]) {
            p->fx_master_order = (uint8_t)(fx_master_order_tr + 1u);
            break;
        }
    p->motion = motion;
    dx_kit_pack(p->dx, dx_kit, dx_lay, dx_mdl);         /* (each sound's LAYER and MODEL in the kit's spare bits) */
    p->dx_mute = dx_mute;
    fx_bus_to_wire(p->fx_bus);
    for (i = 0; i < FX_BUS_N; i++)
        p->fx_bus[i] = (uint8_t)clamp(motion_fx_base(&fx_bus_trk.p[FX_BUS_PID[i]]), 0, 127);
    memcpy(p->lane, pfx_lane, PROJ_LANE_SIZE);
    p->lane_tgt = pfx_ltgt;
    motion_unguard(f);
    memcpy(p->name, proj_name, str_len(proj_name));
    p->sum = proj_sum(p);
}

static int autosave_write_wire(void);                   /* OBJ_AUTOSAVE <- proj_wire; defined with the autosave */
static int autosave_force(void);                        /* capture live music into OBJ_AUTOSAVE now */
static void autosave_catch_up(void);                    /* as.saved/seen = autosave_sig() after a name change */

/* the music as it is now -> slot, named `name` (0: the current name; "" none); 0 saved, nonzero refused or failed.
 * The current name becomes the saved one. Policy 2A: force-write OBJ_AUTOSAVE with this image first so a torn
 * single-copy slot write can recover from a fresh autosave; if that fails, leave the slot alone. */
static int project_save_as(uint32_t slot, const char *name)
{
    project_t *p = &proj_scratch;
    if (transport_busy()) {                            /* a flash erase silences the audio and stalls the */
        ui_message("STOP TO SAVE");                     /* sequencer (storage_hw.c): only while stopped */
        return 1;
    }
    project_capture(p);
    if (name) {
        memset(p->name, 0, sizeof p->name);
        memcpy(p->name, name, str_len(name) < PROJ_NAME_LEN ? str_len(name) : PROJ_NAME_LEN);
    }
    proj_wire_gen++;
    if (!proj_pack(&proj_wire, p)) { ui_message("SAVE FORMAT ERROR"); return 2; }

#if FELUCCA_FLASH
    if (!flash_ok) {
        ui_message("SAVE ERROR");
        return 2;
    }
    if (autosave_write_wire()) {                /* before the slot erase: fail loud, slot untouched */
        ui_message("SAVE ERROR");
        return 2;
    }
    if (st_save(OBJ_PROJECT0 + (slot & 3u), &proj_wire, sizeof proj_wire) == 0) {
        proj_sum_set(slot, p);                             /* the summary from RAM: no flash read */
        proj_name_get(proj_name, (const uint8_t *)p->name);
        proj_cur = (uint8_t)(slot & 3u);
        step_from_set((slot & 3u) + 1u);
        autosave_catch_up();                               /* name may have changed; keep poll in sync */
        ui_message("SAVED");
        return 0;
    }
    proj_sum_clear(slot);               /* the only copy was erased; autosave already holds this image */
    ui_message("SAVE ERROR");       /* 3.10: a project lives in flash; there is no RAM-only slot */
    return 2;
#else
    /* test-only path: write to proj_slot (provided by the test harness) */
    memcpy(&proj_slot[slot & 3u], &proj_wire, sizeof proj_wire);
    proj_sum_set(slot, p);
    proj_name_get(proj_name, (const uint8_t *)p->name);
    proj_cur = (uint8_t)(slot & 3u);
    step_from_set((slot & 3u) + 1u);
    ui_message("SAVED (RAM)");
    return 0;
#endif
}
static int project_save(uint32_t slot) { return project_save_as(slot, 0); }
static void project_cur_name(char *b) { str_cpy(b, proj_name, PROJ_NAME_LEN + 1u); }   /* b: 13 bytes */

/* slot's name -> b (PROJ_NAME_LEN + 1 bytes); 0 = an empty slot (b ""). Uses proj_scratch */
static int project_name(uint32_t slot, char *b) { return project_info(slot, b, 0, 0, 0); }
/* .. and, len48 not 0, the length of each track's pattern as SONG plays it (song_chain.c chain_tick: the clock track's
 * LEN steps of its DIV, clamped as chain_prepare does) in 1/48 quarter notes (a 4/4 bar: 192; 0 = an empty slot):
 * len48[0..NTRK-1] */
static uint32_t len48_of(int32_t len, int32_t div)
{
    uint32_t n = (uint32_t)clamp(len, TP[P_SLEN].min, TP[P_SLEN].max), d = (uint32_t)clamp(div, TP[P_SDIV].min, TP[P_SDIV].max);
    return n * (d < 6u ? 48u / DIV_DEN[d] : d < 10u ? 48u << (d - 5u) : 48u / DIV_DEN[d % 6u]);   /* (fx.c div_samples) */
}
/* SONG's picture of a pattern (ui_graph.c graph_song): its LEN steps in n = min(LEN, 16) cells (a cell: steps
 * c * LEN / n .. (c + 1) * LEN / n - 1), 2 bits a cell, cell c at bits 2c: a step weighs 0 (rest, empty, CHANCE 0),
 * 1 (a tie), 2 (a note or hit), 3 (accented); a cell's level is its steps' mean, rounded up (0..3) */
static uint32_t proj_density(const proj_trk_t *t, uint8_t *n)
{
    uint32_t len = (uint32_t)clamp(t->p[P_SLEN], 1, NSTEP), nc = len < 16u ? len : 16u, c, i, d = 0;
    for (c = 0; c < nc; c++) {
        uint32_t i0 = c * len / nc, i1 = (c + 1u) * len / nc, w = 0;
        for (i = i0; i < i1; i++) {
            const step_t *s = &t->step[i];
            if (s->time == ST_TIE)
                w += 1u;
            else if (s->time == ST_NOTE && (s->n || s->hit) && step_chance(s))
                w += (step_fl(s) & SF_ACCENT) || s->acc ? 3u : 2u;
        }
        w = (w + (i1 - i0) - 1u) / (i1 - i0);
        d |= (w < 3u ? w : 3u) << (2u * c);
    }
    *n = (uint8_t)nc;
    return d;
}
/* .. and, den not 0, each track's picture (proj_density: den[k], its cells n[k]; 0 for an empty slot) */
static int project_info(uint32_t slot, char *b, uint16_t *len48, uint32_t *den, uint8_t *n)
{
    uint32_t k = slot & 3u;
    b[0] = 0;
    if (len48)
        memset(len48, 0, NTRK * sizeof *len48);
    if (den) {
        memset(den, 0, NTRK * sizeof *den);
        memset(n, 0, NTRK);
    }
    if (!((proj_slot_used >> k) & 1u))                 /* no flash: the summary is kept by proj_fetch / proj_sum_set */
        return 0;
    memcpy(b, proj_slot_sum[k].name, sizeof proj_slot_sum[k].name);
    for (k = 0; len48 && k < NTRK; k++)
        len48[k] = proj_slot_sum[slot & 3u].len48[k];
    for (k = 0; den && k < NTRK; k++) {
        den[k] = proj_slot_sum[slot & 3u].den[k];
        n[k] = proj_slot_sum[slot & 3u].cell[k];
    }
    return 1;
}

/* a stored project renamed in place (nothing else of it changes; the music playing is not touched, but the slot
 * it was loaded from / saved to: its name is the new one, the next SAVE's prefill): 0 done, 1 refused (playing,
 * an empty slot), 2 failed (the slot as it was). Force-autosave the live music first (same as Save) so a tear
 * still has a current recovery image; if that fails, leave the slot alone. */
static int project_rename(uint32_t slot, const char *name)
{
    project_t *p = &proj_scratch;
    if (transport_busy()) {
        ui_message("STOP TO SAVE");
        return 1;
    }
    if (!project_used(slot)) {
        ui_message("EMPTY SLOT");
        return 1;
    }
#if FELUCCA_FLASH
    if (autosave_force()) {                     /* before the slot erase: fail loud, slot untouched */
        ui_message("SAVE ERROR");
        return 2;
    }
#endif
    if (!proj_fetch(slot)) {
        ui_message("EMPTY SLOT");
        return 1;
    }
    memset(p->name, 0, sizeof p->name);
    memcpy(p->name, name, str_len(name) < PROJ_NAME_LEN ? str_len(name) : PROJ_NAME_LEN);
    proj_wire_gen++;
    if (!proj_pack(&proj_wire, p)) { ui_message("SAVE FORMAT ERROR"); return 2; }
#if FELUCCA_FLASH
    if (!flash_ok || st_save(OBJ_PROJECT0 + (slot & 3u), &proj_wire, sizeof proj_wire)) {
        proj_sum_clear(slot);           /* single-copy rename tears the only image the same way a save does */
        ui_message("SAVE ERROR");
        return 2;
    }
    proj_sum_set(slot, p);
    if (proj_cur == (slot & 3u)) {
        proj_name_get(proj_name, (const uint8_t *)p->name);
        autosave_catch_up();
    }
    ui_message("RENAMED");
    return 0;
#else
    /* test-only path: write to proj_slot */
    memcpy(&proj_slot[slot & 3u], &proj_wire, sizeof proj_wire);
    proj_sum_set(slot, p);
    if (proj_cur == (slot & 3u))
        proj_name_get(proj_name, (const uint8_t *)p->name);
    ui_message("RENAMED (RAM)");
    return 0;
#endif
}

static int project_restore_runtime(const project_t *input)
{
    project_t *p = &proj_scratch;
    uint32_t i, k;
    if (!proj_ok(input) || !proj_engines_ok(input)) return 1;
    mom_back(0);                                  /* (ui_input.c MOMENTARY: the values as they were, then the load) */
    memset(drum_mute, 0, sizeof drum_mute);       /* (1.4.1: the DRUM lanes' mutes, performance state) */
    if (p != input) memcpy(p, input, sizeof *p);
    if (dx_kit_ok(p->dx))                               /* FUN11 kit (FUN10: factory), its LAYERs (none before) */
        dx_kit_unpack(dx_kit, dx_lay, dx_mdl, p->dx);
    else
        dx_kit_load(0);
    fx_bus_from_wire(p->fx_bus);
    dx_mute_set(p->dx_mute);
    proj_drums_to_part(p);                              /* a RAM slot of firmware before 1.0 */
    proj_phys(p);                                       /* .. before PHYS lost DUST and DRUM */
    proj_fm6m(p);                                       /* .. or a pre-VIB VMOD value */
    proj_lsync(p);                                      /* .. or 1.2's LFO SYNC note value */
    proj_perc(p);                                       /* .. or SAMPLE PERC tracks */
    proj_retire(p);                                     /* .. or SAMPLE / GRAIN / NOISE / SLICE */
    transport_req = 2;
    panic_req = (1u << NTRK) - 1u;
    fm1_irq_off();                                      /* the audio ISR must not see half a project */
    seq_stop();
    transport_req = 0;
    chain_config = p->chain;
    motion = p->motion;
    memset(motion_active, 0, sizeof motion_active);
    motion_base_valid = 0;
    ui.song_row = 0;
    for (i = 0; i < G_COUNT; i++)
        if (i != G_SLOT && i != G_LOAD && i != G_SAVE)
            song.g[i] = i == G_DTIME ? dtime_load(p->g[i])
                                     : (int16_t)clamp(p->g[i], GP[i].min, GP[i].max);
    for (k = 0; k < NTRK; k++) {
        track_t *t = &trk[k];
        const proj_trk_t *s = &p->t[k];
        uint32_t e = s->engine;                         /* (< NENGINES: proj_engines_ok) */
        t->eng_req = (uint8_t)e;
        t->user = 0;                                    /* (no user preset slot is saved) */
        for (i = 0; i < P_COUNT; i++) {                 /* every value back inside its range (param_fit) */
            const param_desc_t *d = param_desc_of(e, i);
            t->p[i] = (int16_t)param_fit(d, s->p[i]);
        }
        t->preset = (uint8_t)(ENGINES[e]->npresets ? (s->preset >= PROJ_DEF_KEEP ? 0u : s->preset) % ENGINES[e]->npresets : 0u);
        memcpy(t->step, s->step, sizeof t->step);
        proj_steps(t->step);
        t->scl_stash_ok = s->scl_stash_ok ? 1u : 0u;
        t->scl_stash[0] = s->scl_stash[0];
        t->scl_stash[1] = s->scl_stash[1];
        t->scl_stash[2] = s->scl_stash[2];
        t->fx_sl_pos = s->fx_sl_pos < FX_LIST_N ? s->fx_sl_pos : 8u;
        memcpy(fx_order_tbl[k], s->fx_order, FX_LIST_N);
        if (!proj_order_ok(fx_order_tbl[k]))
            fx_order_default((uint16_t)t->p[P_IORD], t->p[P_CHOR], t->fx_sl_pos, fx_order_tbl[k]);
        fx_order_accept(t);
        t->generation = s->generation;
        for (i = 0; i < 12u; i++)                       /* the matrix's slots 5..8 */
            t->mx[i / 3u][i % 3u] = mod_fit(i % 3u, s->mx[i / 3u][i % 3u]);
        {   /* the project's own FM6 patch, never reloaded from SLOT: F n if it is that factory patch, else OWN */
            uint8_t v[FP_SIZE + 1u];
            fm6_unpack(p->fm6[k], v);
            fm6_set_patch(k, v);
            fm6_adopt(k);
        }
    }
    song.sel = (uint8_t)(p->sel < NTRK ? p->sel : 0u);
    memcpy(fx_master_tr, p->fx_master, FX_LIST_N);
    fx_master_sanitize();
    if (p->fx_master_order && p->fx_master_order <= NTRK)
        fx_master_order_tr = (uint8_t)(p->fx_master_order - 1u);
    for (i = 0; i < FX_LIST_N; i++)
        if (fx_master_tr[i])
            fx_master_reset_stage(i);
    memcpy(pfx_lane, p->lane, PROJ_LANE_SIZE);
    pfx_ltgt = p->lane_tgt;
    fm1_irq_on();
    proj_name_get(proj_name, (const uint8_t *)p->name);
    proj_cur = PROJ_NO_SLOT;                            /* (project_load: its slot) */
    step_from_set(0);                                    /* (project_load: its slot; the header's letter) */
    undo.trk = 0;                                       /* (ui.c) the undo copy belongs to the old project */
    undo_depth++;                                       /* and these loads take none */
    for (k = 0; k < NTRK; k++) {                        /* the power-on sounds: format 1 (tracks 2..4), old drums */
        track_t *t = &trk[k];
        int16_t keep[P_COUNT];
        if (p->t[k].preset == PROJ_DEF_SOUND) {
            apply_preset_to(t, TRK_DEF[k][1]);
            track_defaults_steps(t);
        } else if (p->t[k].preset == PROJ_DEF_KEEP) {   /* the steps, LEVEL PAN MUTE, LEN DIV SWING GATE kept */
            memcpy(keep, t->p, sizeof keep);
            fm1_irq_off();                           /* publish the legacy sound as one bounded parameter batch */
            proj_legacy_drums(t);                     /* (keeps the SLICER: param_kept) */
            t->p[P_REV] = keep[P_REV];                  /* and the drums' reverb send */
            for (i = P_AMODE; i <= P_TRANS; i++)        /* the drum part had no arp or scale */
                t->p[i] = TP[i].def;
            fm1_irq_on();
        }
    }
    undo_depth--;
    sync_reload = 1;
    ui.force = 1;
    ui_message("LOADED");
    memset(snd_said, 0, sizeof snd_said);               /* a missing sample is said again, after LOADED */
    return 0;
}
static void project_load(uint32_t slot)
{
    if (!proj_fetch(slot)) { ui_message("EMPTY SLOT"); return; }
    proj_bound(&proj_scratch);                          /* a retained RAM slot of an older format: as from flash */
    if (!project_restore_runtime(&proj_scratch)) {
        proj_cur = (uint8_t)(slot & 3u);
        step_from_set((slot & 3u) + 1u);
    }
}

/* settings + learned panel table: one flash object. The flash copy wins at
 * boot (the .noinit copies are garbage after a power-off). */
#include "settings_persist.c"
#if FELUCCA_FLASH
static persist_t persist_saved __attribute__((unused));
static uint8_t persist_pending;                 /* 1 requested, 2 waiting after a flash error */
static uint32_t persist_retry_ms;
#endif

static void persist_boot(void)                    /* before settings_init / panel_init */
{
#if FELUCCA_FLASH
    persist_t p;
    uint32_t f = irq_save();
    uint32_t jid = FL_FAR(fl_jedec_ram)();
    flash_ok = (jid == 0x856014u || jid == 0xB36014u);    /* the expected 1 MiB parts (0x85 Puya, 0xB3 UCUN), else stay RAM-only */
    irq_restore(f);
    if (!flash_ok)
        return;
    fl_plain_window_init();                        /* flash above 0x93000 reads as plaintext through XIP
                                                    * (user sample slots for editor / backup) */
    {
        uint32_t k;
        for (k = 0; k < SMP_USER_SLOTS; k++)
            smp_user_scan(k);
    }
    {
        int n = st_load(OBJ_SETTINGS, &p, sizeof p);
        if (settings_import(&p, n))
            persist_saved = p;
    }
    {   /* projects: one flash read a slot, so the slot list is right from power-on and never reads
         * flash while drawing afterwards */
        uint32_t i;
        for (i = 0; i < 4u; i++)
            proj_fetch(i);
    }
    up_boot();                                     /* user presets (fvb_boot finishes a staged FM6 bank first) */
    st_autosave_migrate();                         /* old one-sector B at 0xE6000 -> gap, before A can erase it */
#endif
}

static int project_used(uint32_t slot) { return (int)((proj_slot_used >> (slot & 3u)) & 1u); }

/* Main loop only: no flash access or copies when the ISR changes rows. */
static uint32_t chain_prepare(void)
{
    uint32_t i, k, j, used = 0;
    if (transport_busy())
        return 2;
    if (!chain_valid(&chain_config) || !chain_config.count)
        return 1;
    for (i = 0; i < chain_config.count; i++)            /* the slots the lanes play (not the silent ones) */
        for (k = 0; k < NTRK; k++) {
            uint32_t s = chain_config.row[i].slot[k];
            if (s >= 4u || ((used >> s) & 1u))
                continue;
            if (!project_used(s))
                return 3u + s;
            used |= 1u << s;
        }
    chain.config = chain_config;
    for (i = 0; i < 4u; i++)
        if ((used >> i) & 1u) {
            project_t *p = &proj_scratch;
            if (!proj_fetch(i)) return 3u + i;
            chain.source[i].motion = p->motion;
            /* A song keeps its current instruments. Engine-specific motion from
             * another instrument would change a kit/wave/algorithm unexpectedly. */
            {
                motion_store_t *m = &chain.source[i].motion; uint32_t n = 0;
                for (uint32_t e = 0; e < m->count; e++) {
                    const motion_event_t *v = &m->event[e]; uint32_t owner = v->place >> 6;
                    uint32_t mid = MOTION_ID(v);
                    if (mid != MFX_BEND && mid >= P_FM1_ATK && p->t[owner].engine != trk[owner].eng_req) continue;
                    m->event[n++] = *v;
                }
                m->count = (uint8_t)n;
            }
            for (k = 0; k < NTRK; k++) {
                memcpy(chain.source[i].step[k], p->t[k].step, sizeof p->t[k].step);
                proj_steps(chain.source[i].step[k]);
                chain.source[i].qnt[k] = p->t[k].p[P_SQNT] != 0;
                for (j = 0; j < 4u; j++)
                    chain.source[i].timing[k][j] = (int16_t)clamp(p->t[k].p[P_SLEN + j],
                        TP[P_SLEN + j].min, TP[P_SLEN + j].max);
            }
        }
    RING_PUBLISH();
    chain.armed = 1;
    transport_req = 1;
    return 0;
}

static void settings_poll(void)
{
#if FELUCCA_FLASH
    persist_t p;
    if (!persist_pending || !flash_ok || transport_busy() ||
        (persist_pending == 2u && (uint32_t)(fm1_ms - persist_retry_ms) < 1000u))
        return;
    p = persist_saved;
    settings_export(&p);
    if (!memcmp(&p, &persist_saved, sizeof p)) {
        persist_pending = 0;
        return;                                    /* unchanged: no erase cycle */
    }
    if (st_save(OBJ_SETTINGS, &p, sizeof p) == 0) {
        persist_saved = p;
        persist_pending = 0;
    } else {
        persist_pending = 2;
        persist_retry_ms = fm1_ms;
    }
#endif
}

static void settings_save(void)
{
#if FELUCCA_FLASH
    persist_pending = 1;
#endif
    settings_poll();
}

/* The autosave (1.2, Discussion #130; 3.10 always-writes + split placement): the music as it is (what a project
 * holds: every track's sound, steps, LEN DIV SWING GATE, mix, the song, the automation and locks, the FM6 patches,
 * the name) kept in its own storage object (OBJ_AUTOSAVE, A at 0xE5000..0xE6FFF / B at 0x93000..0x94FFF, two sectors
 * a copy so the full 4096 B FUN20 wire including lane and motion 89..127 fits), and put back at power-on
 * (autosave_boot) with MENU > SYSTEM > BOOT RESTORE ON (the default). Flash wear: two 4 KiB erases per write, the
 * two copies taking turns, so a write only when
 *   - something a project holds changed since the last one (autosave_sig: a hash of those values, no copy; not the
 *     selected track, nor the PROJECT page's own controls),
 *   - and it has stayed the same for AS_IDLE_MS (10 s) with the transport stopped, no key or button down, no voice
 *     sounding and no editor transfer (a backup or a sample: autosave_hold); an erase stops the audio for its
 *     ~40 ms, as every save does, so it never happens while anything plays,
 *   - and at least AS_GAP_MS (60 s) after the one before (AS_RETRY_MS after a failed write).
 * So at most one write a minute while editing, none while playing or idle: about 100,000 erase cycles per sector
 * give over 200,000 writes, a write a minute for 8 hours a day for over a year, far more with real pauses.
 * BOOT RESTORE OFF skips power-on restore only; the autosave still writes (single-copy projects need that safety
 * net). Never restore after a crash, a hang or a failed boot (main.c): the music that was playing then could be what
 * crashed. Checked every AS_POLL_MS; the main loop only (never the audio ISR) */
#define AS_POLL_MS 250u
#define AS_IDLE_MS 10000u
#define AS_GAP_MS 60000u
#define AS_RETRY_MS 30000u
static struct {
    uint32_t saved, seen;                        /* the signature written last (or loaded at power-on), seen last */
    uint32_t t, last, poll;                      /* fm1_ms: seen changed / busy, the last write, the last check */
    uint32_t writes;                             /* (written since power-on: the host tests count them) */
    uint8_t wrote, err;                          /* a write since power-on (last is valid); the last one failed */
} as __attribute__((unused));

static uint32_t as_mix(uint32_t h, const void *p, uint32_t n)   /* FNV-1a, continued */
{
    const uint8_t *b = p;
    while (n--) {
        h ^= *b++;
        h *= 16777619u;
    }
    return h;
}

/* what an autosave would hold, hashed (no copy, no RAM): project_capture's values */
static uint32_t autosave_sig(void)
{
    uint32_t h = 2166136261u, i, j;
    for (i = 0; i < NTRK; i++) {
        const track_t *t = &trk[i];
        for (j = 0; j < P_COUNT; j++) {
            int16_t v = motion_base_value(t, j);
            h = as_mix(h, &v, sizeof v);
        }
        h = as_mix(h, &t->eng_req, 1);
        h = as_mix(h, &t->preset, 1);
        h = as_mix(h, t->step, sizeof t->step);
        h = as_mix(h, fx_order_tbl[t - trk], FX_LIST_N);
        h = as_mix(h, &t->generation, sizeof t->generation);
        h = as_mix(h, fm6_patch[i], sizeof fm6_patch[i]);
    }
    for (i = 0; i < G_COUNT; i++)
        if (i != G_SLOT && i != G_NAME && i != G_LOAD && i != G_SAVE) {
            int16_t v = motion_fx_base(&song.g[i]);
            h = as_mix(h, &v, sizeof v);
        }
    h = as_mix(h, fx_master_tr, sizeof fx_master_tr);
    h = as_mix(h, &fx_master_order_tr, sizeof fx_master_order_tr);
    h = as_mix(h, &motion, sizeof motion);
    h = as_mix(h, &chain_config, sizeof chain_config);
    return as_mix(h, proj_name, sizeof proj_name);
}

/* nothing going on that an erase (the audio stopped ~40 ms) would be heard in, or would race */
static int autosave_quiet(void)
{
    uint32_t k, i;
    if (transport_busy() || fm1_in.notes || fm1_in.buttons)
        return 0;
    for (k = 0; k < NTRK; k++)
        for (i = 0; i < NVOICE; i++)
            if (trk[k].v[i].active)
                return 0;
    return 1;
}

static void autosave_hold(void) { as.t = fm1_ms; }   /* the editor's transfers: their staging RAM is proj_wire */

static void autosave_catch_up(void)
{
    as.saved = as.seen = autosave_sig();
}

/* OBJ_AUTOSAVE <- proj_wire (already packed). No idle/gap. Updates as.* so poll does not immediately rewrite. */
static int autosave_write_wire(void)
{
#if FELUCCA_FLASH
    if (!flash_ok || st_save(OBJ_AUTOSAVE, &proj_wire, sizeof proj_wire) != 0)
        return 1;
    as.t = as.last = fm1_ms;
    as.wrote = 1;
    as.err = 0;
    as.writes++;
    autosave_catch_up();
    return 0;
#else
    return 0;
#endif
}

/* Capture the live music into OBJ_AUTOSAVE now (no idle / gap). 0 ok. */
static int autosave_force(void)
{
#if FELUCCA_FLASH
    project_capture(&proj_scratch);
    proj_wire_gen++;
    if (!proj_pack(&proj_wire, &proj_scratch))
        return 1;
    return autosave_write_wire();
#else
    return 0;
#endif
}

/* main loop, every pass (after settings_poll) */
static void autosave_poll(void)
{
#if FELUCCA_FLASH
    uint32_t sig;
    if (!flash_ok || fm1_ms - as.poll < AS_POLL_MS)
        return;
    as.poll = fm1_ms;
    sig = autosave_sig();
    if (sig != as.seen || !autosave_quiet()) {
        as.seen = sig;
        as.t = fm1_ms;
        return;
    }
    if (sig == as.saved || fm1_ms - as.t < AS_IDLE_MS ||
        (as.wrote && fm1_ms - as.last < (as.err ? AS_RETRY_MS : AS_GAP_MS)))
        return;
    as.last = fm1_ms;
    as.wrote = 1;
    project_capture(&proj_scratch);
    proj_wire_gen++;
    as.err = !proj_pack(&proj_wire, &proj_scratch) ||
             st_save(OBJ_AUTOSAVE, &proj_wire, sizeof proj_wire) != 0;
    if (!as.err) {
        as.saved = sig;
        as.writes++;
    }
#endif
}

/* power-on, after the defaults (main.c): the autosave becomes the music when `allowed` (no crash, hang or failed boot
 * before) and BOOT RESTORE is ON; an autosave that does not load (none, torn, damaged, another format) is ignored.
 * The music now (restored or not) is what is saved: nothing is written until it changes. 1 = restored */
static int autosave_boot(int allowed)
{
    int rc = 0;
#if FELUCCA_FLASH
    if (flash_ok && allowed && !(ui_prefs & PREF_RESTORE_OFF)) {
        int n;
        proj_wire_gen++;
        n = st_load(OBJ_AUTOSAVE, &proj_wire, sizeof proj_wire);
        if (n > 0 && proj_import(&proj_scratch, &proj_wire, n)) {
            proj_bound(&proj_scratch);
            if (!project_restore_runtime(&proj_scratch)) {
                ui_message("RESTORED");
                rc = 1;
            }
        }
    }
#else
    (void)allowed;
#endif
    as.saved = as.seen = autosave_sig();
    as.t = fm1_ms;
    return rc;
}

#if FELUCCA_FLASH
_Static_assert(sizeof(project_store_t) <= ST_PAYLOAD_MAX, "project does not fit one flash sector");
_Static_assert(sizeof(persist_t) <= ST_PAYLOAD_MAX, "settings do not fit one flash sector");
#endif
#endif /* PROJ_HOST */
