/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* I2S output (ALNK0 -> external codec) and the
 * audio ISR: per half buffer, blocks of CTL samples: mix_block (fx.c: events ->
 * each synth part -> dist -> level / pan -> sends -> buses -> master) -> USB audio (uac_tap) -> the metronome's
 * click (click.c, the DAC only) -> 24-bit stereo. */
/* registers: hal/fm1_audio.h */
#define HALF_WORDS (HALF_FRAMES * 2u)
#define DAC_TICKS 544u            /* TIMER4 ticks per I2S frame (24 MHz / 44,117.6 Hz) */
#define CPU_AVG (4096u / HALF_FRAMES)   /* halves the load meter averages: ~93 ms whatever the half */
#define OUT_SHIFT 7               /* Q15 -> 24-bit, -6 dBFS ceiling (M0f ran clean at -18 dBFS) */

static int32_t abuf[2u * HALF_WORDS] __attribute__((aligned(4)));

/* diagnostics, kept across resets and UBOOT entry: read with `fm1t memr` */
#define DBG_MAGIC 0x44424731u                       /* "DBG1" */
struct felucca_dbg {
    uint32_t magic, halves, max_us, nested, in_audio, late, timer_irqs, ui_frames;
    uint32_t last_us, cpu_q8, boots;
    uint32_t stage, page, home;           /* where the main loop is (breadcrumbs) */
    uint32_t prev_stage, prev_page, prev_home, prev_rst, prev_frames;   /* as found at boot */
    uint32_t late_over, late_t5, late_oth;/* late, by whose fault it seems (audio render / nested T5 / entry blocked) */
    uint32_t wall_max;                    /* worst half's wall time, us (audio + all nested, incl. outside the ISR) */
    uint32_t entry_gap;                   /* us since the previous half's ISR entry, worst seen */
    uint32_t cpu1_q8;                     /* the second core's load, 1/256 of a half (its jobs' TIMER4 ticks, fx.c) */
} felucca_dbg __attribute__((unused));
static volatile uint32_t audio_halves, audio_max_us;
static uint32_t dbg_last_entry;                        /* the ISR entry before this one (TICKS): the gap between halves */
static uint8_t dbg_entry_armed;                        /* first half's entry: no gap to trust */
static volatile uint32_t t5_nested_ticks;              /* TIMER4 ticks TIMER5 spent nested in this ISR (main.c) */
static uint32_t audio_cpu_rem;                         /* keep the fractional IIR step: no low-load bias */
static uint32_t audio_c1_rem;                          /* .. for the second core's load */

static void audio_block(int32_t *out, uint32_t n)       /* mix (fx.c), then Q15 -> 24 bit */
{
    uint32_t i;
    mix_block(out, n);
#if FELUCCA_UAC
    uac_tap(out, n);                                    /* the USB audio input: the same master output */
#endif
    if (fx_usb_fixed)                                   /* USB LEVEL FIXED: USB took the full level, the DAC */
        usb_fixed_dac(out, n);                          /* (speaker, headphones) gets MASTER's (fx.c) */
    if (!scope_mix)                                     /* the HOME scope (SCOPE OUT): the music, before the click */
        for (i = 1; i < n; i += 2u)                     /* (MIX: fx.c mix_block took it) */
            scope_buf[scope_w++ & (SCOPE_N - 1u)] = (int16_t)out[2u * i];
    click_render(out, n);                               /* the metronome (click.c): the DAC only, not USB */
    if (boot_fade < 32768u) {                           /* power-on soft start (fx.c fx_boot / audio_amp_on) */
        uint16_t g = boot_fade;
        for (i = 0; i < n; i++) {
            out[2u * i] = (out[2u * i] * g) >> 15;
            out[2u * i + 1u] = (out[2u * i + 1u] * g) >> 15;
            if (boot_fade_run) {
                uint32_t ng = (uint32_t)g + BOOT_FADE_STEP;
                g = ng > 32768u ? 32768u : (uint16_t)ng;
            }
        }
        boot_fade = g;
    }
    for (i = 0; i < n; i++) {
        out[2u * i] *= 1 << OUT_SHIFT;
        out[2u * i + 1u] *= 1 << OUT_SHIFT;
    }
}

/* Overload: two halves in a row above 85 % (the render plus TIMER5 nested in it), or a single half above 92 %
 * (a bursty load that sits well under 85 % between its spikes never built the pair: the one hot half alone sheds
 * now), fade one voice over the next block; a half that blows past the deadline (~110 % bursts leave one voice's
 * share short) asks for two at once, its next half late anyway. One more each half while it lasts. Keep each
 * part's lowest POLY note and MONO / LEGATO / UNISON lead, as the shared budget does. */
static volatile uint8_t shed_req;                      /* voices to kill at the next half's start (1, or 2 on a burst) */
static uint8_t shed_over;                              /* bit k: the half k halves ago was over 85 % */
#define SHED_TICKS ((HALF_FRAMES * 1000000u / FS) * 85u / 100u * FM1_TICKS_PER_US)   /* 85 % of a half */
#define SHED_TICKS_1 ((HALF_FRAMES * 1000000u / FS) * 92u / 100u * FM1_TICKS_PER_US) /* 92 %: this half alone sheds */
#define SHED_TICKS_2 ((HALF_FRAMES * 1000000u / FS) * 100u / 100u * FM1_TICKS_PER_US)/* 100 %: it needs two voices */
static uint32_t shed_count;

/* end of a half: all = its ticks, TIMER5 nested in it included -> the render alone in us. The deadline sees
 * both; shed after 2 overloaded halves in a row, or one at 92 % (out of line: keeps the ISR's render loops as they
 * were); past the deadline the burst is bigger than one voice's share, so two */
static __attribute__((noinline)) uint32_t shed_check(uint32_t all)
{
    shed_over = (uint8_t)(shed_over << 1 | (all > SHED_TICKS));
    if ((shed_over & 3u) == 3u || all > SHED_TICKS_1)
        shed_req = 1;
    if (all > SHED_TICKS_2)
        shed_req = 2;
    return (all - t5_nested_ticks) / FM1_TICKS_PER_US;
}

static void shed_voice(void)
{
    uint32_t p, i;
    voice_t *best = 0;
    for (p = 0; p < NPART; p++)
        for (i = 0; i < NVOICE; i++) {
            voice_t *v = &trk[p].v[i];
            if (v->active && !v->gate && v->stage != 4u && (!best || v->env < best->env))
                best = v;
        }
    if (best) {
        voice_kill(best);
        shed_count++;
        return;
    }
    for (p = 0; p < NPART; p++) {
        const track_t *t = &trk[p];
        uint32_t mode = trk_vmode(t), low = mode == V_POLY ? lowest_held(t) : 0u;
        for (i = 0; i < NVOICE; i++) {
            voice_t *v = &trk[p].v[i];
            if (v->active && v->gate && v->stage != 4u &&
                ((mode == V_POLY && i != low) || (mode != V_POLY && i > 0u))) {
                if (!best || v->age < best->age)
                    best = v;
            }
        }
    }
    if (best) {
        voice_kill(best);
        shed_count++;
    }
}

void fm1_alnk0_irq(void)                       /* via isr_alnk0 (hal/fm1_isr.S) */
{
    uint8_t p;
    uint32_t t0, wall_us, nested_us;
    felucca_dbg.in_audio = 1;                   /* first: TIMER5 nests from here on (main.c) */
    p = fm1_audio_pending();
    t0 = fm1_ticks();
    t5_nested_ticks = 0;
    fm1_audio_ack_aux(p);
    if (p & FM1_AUDIO_HALF) {
        uint32_t half = fm1_audio_free_half(), b, us;
        uint32_t gap_us;
        int32_t *o = &abuf[half * HALF_WORDS];
        gap_us = (t0 - dbg_last_entry) / FM1_TICKS_PER_US;
        dbg_last_entry = t0;
        if (shed_req) {
            uint8_t req = shed_req;
            shed_req = 0;
            while (req--)
                shed_voice();
        }
#if FELUCCA_UAC
        uac_render_start();
#endif
        for (b = 0; b < HALF_FRAMES; b += CTL) {
#ifdef FM1_INPUT_LAT
            kb_out_tick = t0 + (HALF_FRAMES + b) * DAC_TICKS;   /* when this block plays (seq.c kb_lat) */
#endif
            audio_block(o + 2u * b, CTL);
        }
        fm1_audio_ack_half();
        audio_halves++;
        us = shed_check(fm1_ticks() - t0);
        if (us > audio_max_us)
            audio_max_us = us;
        {
            uint32_t load = song.cpu_q8 * (CPU_AVG - 1u) + (us * 256u) / (HALF_FRAMES * 1000000u / FS) + audio_cpu_rem;
            song.cpu_q8 = load / CPU_AVG;
            audio_cpu_rem = load % CPU_AVG;
        }
        {   /* the second core: its jobs' TIMER4 ticks (fx.c c1_job_ticks) over the half, smoothed as cpu_q8 */
            uint32_t load = felucca_dbg.cpu1_q8 * (CPU_AVG - 1u) +
                            (c1_job_ticks * 256u) / ((HALF_FRAMES * 1000000u / FS) * FM1_TICKS_PER_US) + audio_c1_rem;
            c1_job_ticks = 0;
            felucca_dbg.cpu1_q8 = load / CPU_AVG;
            audio_c1_rem = load % CPU_AVG;
        }
        if (fm1_audio_free_half() != half)
            felucca_dbg.late++;                         /* the DMA moved on while we rendered */
        {   /* [DEBUG-late] whose fault the late half was: the render itself, TIMER5 nested in it, or the */
            uint32_t hz = HALF_FRAMES * 1000000u / FS;  /* entry arriving late (blocked by code outside us) */
            wall_us = (fm1_ticks() - t0) / FM1_TICKS_PER_US;
            nested_us = t5_nested_ticks / FM1_TICKS_PER_US;
            if (fm1_audio_free_half() != half) {
                if (us > hz * 9u / 10u)
                    felucca_dbg.late_over++;            /* the render alone nearly filled the half */
                else if (nested_us > hz / 8u)
                    felucca_dbg.late_t5++;              /* TIMER5 nested in the ISR ate the runway */
                else
                    felucca_dbg.late_oth++;             /* blocked before or by something else */
            }
            if (wall_us > felucca_dbg.wall_max)
                felucca_dbg.wall_max = wall_us;
            if (dbg_entry_armed && gap_us > felucca_dbg.entry_gap)
                felucca_dbg.entry_gap = gap_us;
            dbg_entry_armed = 1;
        }
        felucca_dbg.halves++;
        felucca_dbg.last_us = us;
        if (us > felucca_dbg.max_us)
            felucca_dbg.max_us = us;
        felucca_dbg.cpu_q8 = song.cpu_q8;
    }
    felucca_dbg.in_audio = 0;
}
extern void isr_alnk0(void);

static void audio_init(void)                   /* codec and ALNK0 bring-up (fm1_audio.h); amp stays muted */
{
    uint32_t i;
    for (i = 0; i < 2u * HALF_WORDS; i++)
        abuf[i] = 0;
    fx_boot();                                 /* FX lines silent, soft-start held at 0 until audio_amp_on */
    fm1_audio_init(abuf, HALF_WORDS, isr_alnk0, 3);
}

/* main.c: after IRQs, DMA has been streaming zeros with the amp off; unmute and start the soft-start ramp */
static void audio_amp_on(void)
{
    fm1_audio_amp(1);
    boot_fade_run = 1;
}
