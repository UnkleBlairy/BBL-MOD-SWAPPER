/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
 * Portions: JIANT (github.com/juanjiant-bit/JIANT) 0.9.9-snd2 / 0.9.18, GLITCH */
/* PERFORM: the effects of the FX hold layer, on the master. A key pressed while FX is held belongs to the
 * layer (seq.c keyboard_block): it plays no note, sends no MIDI, records no note (with REC its effect goes into the
 * punch-in lane, pfx.c), and holds its effect until
 * it is let go (ui_input.c opens the layer and shows the map). The 16 white keys (F3 .. G5) hold the effect the map
 * gives them. Two PUNCH-IN pages in the FX section, each a fixed map — no reassignment: the defaults
 * (PF_DEF, JIANT; PF2_DEF the audio effects they did not fit):
 *   PUNCH-IN 1/2: REPEAT 1/8 1/12 1/16 1/32, LPF, HPF, OCT-, OCT+, DEC±, stutter 1/8 1/16, ATK+, ARP,
 *   RANDOM
 *   PUNCH-IN 2/2: REVERSE, TAPE STOP, FREEZE, PITCH UP / DN, FLANGER, PHASER, REV THROW, ECHO THROW (G4),
 *   /2 (A4), *2 (B4), GLITCH (C5); D5 .. F5 none
 *   both: G5 is CLR (latched effects and FILTER/CRUSH/THROW/DEPTH off); black keys 1..4 mute
 *   tracks 1..4; A#4 steps the MIDI effects' tracks (ALL / SYN / DRM).
 * REV THROW / ECHO THROW (1.5.1): while held every track's reverb / delay send is full (as REV / DLY 127; perf_throw),
 * ECHO THROW also lifts the delay's feedback to 0.7 if it is lower (fx.c fx_buses); both glide in and out over 11.6 ms
 * (THR_SLOPE). Let go, the sends are the tracks' own again and what the buses hold rings out. The buses are the song's
 * (no RAM of their own); the tracks' REV / DLY / FDBK values are never touched (nothing saved, nothing recorded).
 * REPEAT and REVERSE start on the next 1/16 (at once while stopped); the others at once; all end when let go,
 * with a 2.9 ms ramp. Effects of different kinds stack; of the buffer ones (REPEAT, REVERSE, TAPE STOP,
 * FREEZE, OCT UP, OCT DN) the last pressed plays, and letting it go returns to the one held before.
 * OCT UP / OCT DN: a harmonizer, the mix an octave up / down beside itself (after the author's earlier
 * fxHarmonizer, the classic rotating-delay shifter): two read taps of a delay sweep 128 .. 2176 samples, half a sweep apart, at the
 * speed that makes the pitch 2x / 0.5x; a raised-cosine cross-fade (the sine table) hides each tap's jump
 * back; reads between samples, linear. Left and right apart, at 44.1 kHz in the loop's frames (4096 of
 * them). Out: 0.56 the live mix + 0.7 the shifted one (its 0.55, 0.7). While it plays, DEPTH (KNOB 4) is its
 * SHIMMER instead of the level: the shifted sound fed back into its own delay (0 .. 0.82, through the soft
 * clip): with OCT UP each pass climbs another octave.
 * FLANGER (1.2): left and right each through a short delay swept 0.5 .. 8 ms (a squared triangle: longer near the
 * short end, where the comb sweeps fastest), a bar a sweep in time with the transport (the 1/16 clock), the right a
 * quarter of it behind the left; feedback 0.5 (through the soft clip); out (x + delayed) / 2 * 0.85: the comb's peaks
 * and DC +2 dB, its notches -17 dB, white noise -4 dB. Its own line (fl_buf, 356 frames: 1.4 KB; the loop's buffer is the buffer
 * effects', which it stacks with); heard once the line holds 8 ms (8 ms after the press).
 * PHASER (1.2): four first-order all-pass stages a side (the classic four-stage pedal), their break swept 150 Hz ..
 * 4.8 kHz (log; a triangle of half a bar, the right a quarter of it behind; the coefficients a block at a time), the
 * last stage's output fed back (0.4) into the first; out (x + all-passed) / 2 * 0.9: two notches moving, the peaks
 * +1.6 dB, white noise -1 .. -3.5 dB. KNOB 4 DEPTH is the FLANGER's and the PHASER's level too (OCT UP /
 * DN playing: full, KNOB 4 its shimmer).
 * The buffer: the SLICER's recordings (sl_buf, 32 KB) borrowed as one stereo loop of 8192 frames at 22.05 kHz
 * (371 ms). While borrowed, STUT tracks and MASTER STUT play live; their recordings are dropped afterwards
 * (slicer_drop_all). A REPEAT 1/8 or
 * REVERSE longer than the loop at the tempo (below 81 BPM) does nothing (the map shows it dimmed).
 * KNOB 1..4 with FX: the macros FILTER (the LPF / HPF), CRUSH, THROW (the dry mix into the delay and reverb
 * sends), DEPTH (the buffer effects' level, FLANGER's and PHASER's; OCT UP / DN: the shimmer).
 * MENU > FX LATCH ON (#40, a hand that cannot hold FX, a key and a knob together): a key pressed with FX turns its
 * effect on, the next press turns it off (perf_latched; letting the key or FX go does nothing), the macros keep
 * their values when FX is let go; G5 CLR turns everything off with or without LATCH, so does the menu or a dialog.
 * OCT± shift octave.
 * Chain: [REPEAT / REVERSE / TAPE / FREEZE] -> LPF -> HPF -> CRUSH -> FLANGER -> PHASER, after the master level and
 * before master_out (the limiter); THROW and the mutes act before the buses (fx.c mix_block / mix_part).
 * The layer runs one block late (fx.c perf_take / perf_layer / perf_out): the whole output is a constant 0.73 ms
 * (one CTL block) late, which lets the layer run on the second core, beside this core's serial tail.
 * Idle (no key, no knob, no ramp left) every stage is skipped: the output is bit-identical. */
/* the effects (their numbers are stored only in code: the maps are the pages', append-only, before PF_M1), then the
 * mutes of the black keys */
enum { PF_R8, PF_R16, PF_R32, PF_REV, PF_LPF, PF_HPF, PF_TAPE, PF_FRZ, PF_OUP, PF_ODN, PF_FLG, PF_PHS,
       PF_RTHR, PF_ETHR,                      /* 1.5.1: REV THROW, ECHO THROW */
       PF_OCTD, PF_OCTU, PF_HALF, PF_DSHT, PF_DLNG, PF_S8, PF_S16, PF_ATK, PF_ARP, PF_RND,   /* MIDI: pfx.c */
       PF_X2, PF_GLT,                        /* 3.2: x2 TEMPO (MIDI), GLITCH (audio buffer) */
       PF_R12,                               /* 3.2: REPEAT 1/12 (append-only: PF_M1 stays 27) */
       PF_M1, PF_N = PF_M1 + NTRK, PF_TGT = PF_N + 1,   /* A#4: MIDI effects' tracks (pfx_tgt) */
       PF_CLR = PF_N + 2 };                              /* G5 CLR: all latched effects + macros off */
_Static_assert(PF_N <= 32u, "PF mask: widen perf_held / perf_latched / pf.act to 64 bits");
#define PF_NFX PF_M1                          /* the effects a white key can hold */
#define PF_KEYS 16u                           /* the white keys F3 .. G5 */
#define PF_BIT(e) (1u << (e))
#define PF_REPEAT (0x7u | PF_BIT(PF_R12))                      /* the four REPEAT rates */
#define PF_Q (PF_REPEAT | PF_BIT(PF_REV))                      /* start on the 1/16 */
#define PF_HARM (PF_BIT(PF_OUP) | PF_BIT(PF_ODN))
#define PF_BUF (PF_REPEAT | PF_BIT(PF_REV) | PF_BIT(PF_TAPE) | PF_BIT(PF_FRZ) | PF_HARM | PF_BIT(PF_GLT))
#define PF_MUTE (((1u << NTRK) - 1u) << PF_M1)
#define PF_MOD (PF_BIT(PF_FLG) | PF_BIT(PF_PHS))   /* FLANGER, PHASER: their own stages after CRUSH */
#define PF_MIDI (((1u << (PF_X2 + 1)) - 1u) & ~((1u << PF_OCTD) - 1u))   /* PF_OCTD .. PF_X2 (pfx.c) */
#define PB_FRAMES (NTRK * SL_LEN / 2u)        /* stereo frames in sl_buf: 8192, 371 ms at 22.05 kHz */
#define PB_MAX (2u * PB_FRAMES)               /* the longest loop, 44.1 kHz samples */
#define PB_TAPE 32000u                        /* TAPE STOP takes 1 beat, at most this (it lags a quarter of it) */
#define PB_FREC 4096u                         /* FREEZE: frames it records (186 ms) */
#define PB_GRAIN 2048u                        /* .. its two overlapping grains, samples (46 ms) */
#define GL_SPAN 7680u                         /* GLITCH: the longest slice it reads back (the loop holds two and a margin) */
enum { GA_PASS, GA_RPT, GA_REV, GA_UP, GA_DN, GA_GATE, GA_SKIP, GA_CRU };
enum { GX_DENS = 50 };                        /* GLITCH's fixed density (no knob page) */
static const uint8_t GA_OF[16] = {GA_RPT, GA_RPT, GA_RPT, GA_RPT, GA_RPT, GA_RPT, GA_REV, GA_REV, GA_UP, GA_DN,
                                  GA_GATE, GA_GATE, GA_SKIP, GA_SKIP, GA_CRU, GA_CRU};
#define HB_MASK 4095u                         /* OCT UP / DN: the delay's frames (of the loop's 8192) */
#define HB_BASE 128u                          /* .. the taps' shortest delay, samples; the sweep: 2048 */
#define HB_FB 269                             /* .. KNOB 4 (0 .. 100) -> the shimmer, Q15: 0 .. 0.82 */
#define PF_TOP (63 << 8)                      /* filter cutoff index, Q8 (PF_SVF): the LPF's open end */
#define PF_LOW (14 << 8)                      /* .. the LPF sweep's end, the HPF sweep's (and K1's) top */
enum { BM_NONE, BM_LOOP, BM_TAPE, BM_FRZ, BM_HARM, BM_GLT };
#define FL_LEN 356u                           /* FLANGER: its line's frames (8.1 ms: FL_MAX + 2) */
#define FL_MIN 22u                            /* .. the delay's sweep, samples: 0.5 .. 8 ms */
#define FL_MAX 353u
#define FL_FB 16384                           /* .. the feedback, Q15: 0.5 */
#define PH_ST 4u                              /* PHASER: all-pass stages a side (two notches, the classic pedal's) */
#define PH_FB 13107                           /* .. the feedback, Q15: 0.4 */
#define THR_SLOPE 64                          /* REV / ECHO THROW: the sends' glide a sample, Q15 (11.6 ms end to end) */
#define THR_FB 22938                          /* ECHO THROW: the delay's feedback while held at least this, Q15 (0.7) */

/* the white keys' effects by default (JIANT: REPEAT, then LPF/HPF/OCT together; /2 beside *2 on 2/2; G5 CLR with
 * LATCH); the 2/2 page the audio effects the first one's keys do not hold (perform.c head) */
static const uint8_t PF_DEF[PF_KEYS] = {PF_R8, PF_R12, PF_R16, PF_R32, PF_LPF, PF_HPF, PF_OCTD, PF_OCTU, PF_DSHT,
                                        PF_DLNG, PF_S8, PF_S16, PF_ATK, PF_ARP, PF_RND, PF_N};
static const uint8_t PF2_DEF[PF_KEYS] = {PF_REV, PF_TAPE, PF_FRZ, PF_OUP, PF_ODN, PF_FLG, PF_PHS, PF_RTHR, PF_ETHR,
                                         PF_HALF, PF_X2, PF_GLT, PF_N, PF_N, PF_N, PF_N};
static volatile uint8_t perf_page2;   /* main: the punch page shown (ui.c page_entered): 0 = 1/2, 1 = 2/2 — the map
                                       * the FX layer's white keys hold (seq.c perf_key, ui_layer.c layer_fx) */
#define perf_map_now() (perf_page2 ? PF2_DEF : PF_DEF)
/* the page's map for the layer's white keys; nothing held can follow: the map only changes through the pages
 * (SELECT on the sticky map), and no key is the layer's between a walk (ui_input.c turns SELECT with FX up) */
void perf_page(uint32_t punch2) { perf_page2 = (uint8_t)(punch2 != 0u); }

static volatile uint32_t perf_mask;   /* main: the FX button's bit while its layer may own keys, 0 = none */
static volatile uint32_t kb_mask;     /* main: the button bits whose hold makes keys a layer's (ui_layer.c), 0 = none */
static volatile uint8_t kb_lock;      /* main: a layer locked open (#83, no button held): 1 keys are the layer's, 2 FX's */
static volatile uint8_t perf_solo;    /* main: tracks soloed while GLO's white keys are held (the others muted as by a black key) */
/* GLO's held solos, plus any track whose PLAY is SOLO. A set bit sounds; the rest are muted. */
static uint32_t solo_mask(void)
{
    uint32_t m = perf_solo, k;
    for (k = 0; k < NTRK; k++)
        if (trk[k].p[P_MUTE] == PLAY_SOLO)
            m |= 1u << k;
    return m;
}
/* the tracks whose PLAY is OFF: muted as by a black key, so a note still sounding ramps out (perf_mute) */
static uint32_t off_mask(void)
{
    _Static_assert(NTRK == 4, "off_mask is unrolled for four tracks");
    return (uint32_t)(trk[0].p[P_MUTE] == PLAY_OFF) |
           (uint32_t)(trk[1].p[P_MUTE] == PLAY_OFF) << 1 |
           (uint32_t)(trk[2].p[P_MUTE] == PLAY_OFF) << 2 |
           (uint32_t)(trk[3].p[P_MUTE] == PLAY_OFF) << 3;
}
/* 1 when track k is heard: PLAY is not OFF, and it is not left out by a solo */
static int trk_heard(uint32_t k)
{
    uint32_t s = solo_mask();
    return trk[k].p[P_MUTE] != PLAY_OFF && (!s || ((s >> k) & 1u));
}
static volatile uint8_t perf_kill;    /* main: every effect off (the menu, a dialog, UBOOT) */
static volatile int8_t perf_k[4];     /* main: the knob macros, 0 = untouched: FILTER -100..100 (- LPF, + HPF),
                                       * CRUSH 0..100, THROW 0..100, DEPTH cut 0..100 (the buffer effects' level) */
static volatile uint32_t kb_layer;    /* ISR: the keys held that are the layer's, a bit per key */
static volatile uint32_t perf_held;   /* ISR: the effects held (PF_*) */
static volatile uint8_t perf_latch_on;   /* main: MENU > FX LATCH ON (#40): a key with FX toggles its effect */
static volatile uint32_t perf_latched;   /* ISR: the effects latched (FX LATCH; CLR / menu clear it) */
static volatile uint32_t perf_act;    /* ISR: .. running (a 1/16 one from its start on) */
static uint32_t perf_ord[PF_N], perf_seq;   /* press order: the last pressed buffer effect plays */

/* the ZDF state-variable filter at cutoff index i (30 Hz * 2^(i / 7), 0..63: up to 15.4 kHz), k = 1:
 * a1 a2 a3 in Q14 (tools: g = tan(pi fc / fs), a1 = 1 / (1 + g (g + k)), a2 = g a1, a3 = g a2) */
static const int16_t PF_SVF[64][3] = {
    {16349, 35, 0}, {16345, 39, 0}, {16341, 43, 0}, {16337, 47, 0}, {16332, 52, 0}, {16327, 57, 0}, {16321, 63, 0},
    {16314, 70, 0}, {16307, 77, 0}, {16299, 85, 0}, {16290, 94, 1}, {16280, 103, 1}, {16269, 114, 1},
    {16257, 126, 1}, {16244, 139, 1}, {16229, 153, 1}, {16213, 169, 2}, {16196, 186, 2}, {16176, 205, 3},
    {16154, 227, 3}, {16130, 250, 4}, {16104, 275, 5}, {16075, 303, 6}, {16043, 334, 7}, {16007, 368, 8},
    {15968, 406, 10}, {15925, 447, 13}, {15877, 492, 15}, {15824, 541, 19}, {15766, 596, 22}, {15702, 655, 27},
    {15631, 720, 33}, {15553, 791, 40}, {15467, 869, 49}, {15372, 953, 59}, {15267, 1046, 72}, {15151, 1146, 87},
    {15024, 1255, 105}, {14883, 1374, 127}, {14729, 1502, 153}, {14559, 1640, 185}, {14372, 1790, 223},
    {14166, 1950, 268}, {13940, 2121, 323}, {13692, 2304, 388}, {13420, 2499, 465}, {13122, 2704, 557},
    {12797, 2921, 667}, {12441, 3147, 796}, {12053, 3382, 949}, {11631, 3624, 1129}, {11173, 3870, 1341},
    {10677, 4119, 1589}, {10140, 4365, 1879}, {9562, 4605, 2218}, {8940, 4832, 2612}, {8274, 5040, 3070},
    {7563, 5219, 3602}, {6807, 5359, 4219}, {6006, 5444, 4934}, {5163, 5456, 5766}, {4282, 5369, 6733},
    {3372, 5149, 7863}, {2449, 4745, 9190},
};

static struct {
    uint32_t ph, P, split;             /* samples since play; the 1/16; this block: where a 1/16 starts */
    uint32_t act, act0;                /* running after / before split */
    uint8_t busy, sync, mute;          /* sync: a 1/16 starts with the next block; mute: tracks to ramp */
    /* the buffer */
    uint8_t mode, src, next, rev;      /* BM_*, the effect it plays (PF_N none), one waiting for the fade, REVERSE */
    uint8_t state, odd, xrev;          /* LOOP: 0 recording, 1 playing; the sample of a pair; the old loop's */
    uint32_t len, wr, rp;              /* loop length (samples), frames written, read (samples into the loop) */
    uint32_t xrp, xlen, xn;            /* the loop it switched from, faded over xn samples */
    uint32_t tv, dv, tpos;             /* TAPE: speed Q16, its step, read position Q16 frames */
    uint32_t gp[2], gs[2];             /* FREEZE: grain positions (samples), starts (frames) */
    uint32_t hph, hinc;                /* OCT UP / DN: tap A's place in the sweep (Q32), its step a sample */
    int32_t hfb;                       /* .. the shimmer now, Q15 (glides to KNOB 4's a block at a time) */
    int32_t w, tw, hl, hr;             /* the buffer's share and its target, Q15; the first of a pair */
    uint32_t glgs, glph;               /* GLITCH: the transport's 1/16 (a count), samples into it */
    int32_t gl_yl, gl_yr;              /* .. what it plays this sample */
    struct {                           /* GLITCH (JIANT 0.9.9-snd2 / 0.9.18): action, crush count/hold/shift; segment
                                        * length, samples into it, segments past; loop sample at its start; the span;
                                        * read place (Q16) and rate (Q16, signed); the crushed sample */
        uint8_t a, n, h, sh;
        uint32_t l, u, k, g0, sp, src;
        int32_t rate, cl, cr;
    } gl;
    /* the filters, CRUSH, THROW, mutes */
    int32_t lc, hc, la, ha;            /* cutoffs (Q8 index) and shares (Q15) of LPF and HPF */
    int32_t lz[4], hz[4];              /* their states: L ic1 ic2, R ic1 ic2 */
    int16_t lk[3], hk[3];              /* their coefficients this block */
    uint32_t lt, ht;                   /* samples the LPF / HPF key has been held */
    int32_t cw, cc, chl, chr;          /* CRUSH share, amount, held sample */
    uint32_t cn;
    int32_t td;                        /* THROW: the share of the dry mix sent, Q15 */
    int32_t rw, ew, rw1, ew1;          /* REV / ECHO THROW: their shares (Q15) at this block's start and end */
    uint8_t thr;                       /* .. either at work this block (mix_part: perf_throw) */
    int32_t mg[NTRK];                  /* mute gains, Q15 (32768 = open) */
    /* FLANGER, PHASER */
    int32_t fw, pw;                    /* their shares, Q15 */
    uint32_t fwp, fn;                  /* FLANGER: the frame written next; frames written since it started */
    int32_t px[2][PH_ST], py[2][PH_ST], pfb[2];   /* PHASER: each stage's last input and output, L and R; the fed back */
} pf = {.src = PF_N, .next = PF_N, .lc = PF_TOP, .mg = {32768, 32768, 32768, 32768}};

/* the control values perf_begin leaves for a block (fx.c perf_take copies them into the layer's slot): the layer runs
 * a block late, after core 0's perf_begin has moved on, so perf_block reads this copy, not pf or perf_k. Everything
 * else perf_block touches is the layer's own state and stays with the job */
typedef struct {
    uint32_t act, act0, split, ph, P;   /* the effects running, the 1/16 (samples), the sweep's phase and cycle */
    int32_t lc, hc;                      /* the filters' cutoffs, Q8 index */
    int16_t lk[3], hk[3];                /* their coefficients this block */
    int8_t k[4];                         /* the knob macros (perf_k) this block */
    uint8_t pick0, pick;                 /* the buffer effect to play from act0 / act (perf_pick: perf_ord, the press
                                          * order, moves on with core 0's next keys) */
} perf_blk_t;
static perf_blk_t perf_ctl;
static volatile int8_t perf_k4;          /* KNOB 4 of the block perf_block runs (its perf_blk_t's k[3]), for the buffer
                                            * effect's level. The layer's own; volatile as perf_k was, so the per-sample
                                            * loop keeps its code layout (target_budget) */
static volatile uint8_t perf_layer_busy;   /* the layer's own stages still have work (its end; a block behind in the
                                            * pipeline). THROW, the mutes and the knobs are core 0's: perf_begin */
static int perf_pipe_pending(void);        /* fx.c: the layer's job for the block before has work */

static int16_t fl_buf[FL_LEN][2];      /* FLANGER's line: L R, at half the level (headroom) */

/* the loop length of a REPEAT / REVERSE at the tempo, 44.1 kHz samples; 0 = not one.
 * 1/12 is a third of a beat (the 8T rate), so it does not fit PF_DEN's power-of-two table */
static const uint8_t PF_DEN[PF_REV + 1] = {2, 4, 8, 2};
static int perf_loop(uint32_t e) { return e <= PF_REV || e == PF_R12; }
static uint32_t perf_den(uint32_t e) { return e == PF_R12 ? 3u : PF_DEN[e]; }
static uint32_t perf_len(uint32_t e) { return perf_loop(e) ? beat_samples() / perf_den(e) : 0u; }
/* the effects that can run at the tempo: a REPEAT / REVERSE longer than the loop cannot */
static __attribute__((noinline)) uint32_t perf_avail(void)
{
    uint32_t a = PF_Q, e, m = ~0u, b = AUDIO_FAR(beat_samples)();
    while (a) {
        e = (uint32_t)__builtin_ctz(a);
        a &= a - 1u;
        if (b > PB_MAX * perf_den(e))
            m &= ~PF_BIT(e);
    }
    return m;
}

/* seq.c keyboard_block: a layer key down / up (e: PF_*, PF_N = no effect) */
static volatile uint8_t pfx_tgt;      /* main / keys: MIDI effects' tracks, 0 ALL, 1 SYN, 2 DRM (pfx.c) */
static volatile uint8_t pfx_clr;      /* keys: G5 CLR held (map highlight); down clears latched FX and macros */
static volatile uint8_t perf_clr_say; /* ISR: CLR just cleared; UI shows "FX ALL OFF" */
static uint32_t pfx_lph;              /* samples into the punch-in lane (pfx.c) */
static uint8_t pfx_adv;               /* pfx_block advanced pfx_lph this block (a transport started after it did
                                       * not: an external MIDI Start is handled later, in seq.c events_rest) */
static uint32_t pfx_lane[64];         /* the transport's punch-in lane (pfx.c): each 1/16 step's effects (PF_BIT) */
static uint8_t pfx_ltgt;              /* .. the tracks its MIDI effects act on */
static void perf_press(uint32_t e, int down)
{
    if (e == PF_TGT && down)
        pfx_tgt = (uint8_t)((pfx_tgt + 1u) % 3u);
    if (e == PF_CLR) {
        pfx_clr = (uint8_t)(down ? 1u : 0u);
        if (down) {                               /* latched punch-ins + FILTER/CRUSH/THROW/DEPTH */
            perf_latched = 0;
            perf_k[0] = perf_k[1] = perf_k[2] = perf_k[3] = 0;
            perf_clr_say = 1;
        }
        return;
    }
    if (e >= PF_N)
        return;
    if (perf_latch_on) {                  /* FX LATCH: a press turns it on or off, letting go only clears a held bit */
        if (down) {
            perf_latched ^= PF_BIT(e);
            perf_ord[e] = ++perf_seq;
        } else
            perf_held &= ~PF_BIT(e);      /* a key held before the latch came on: no stuck effect */
        return;
    }
    if (down) {
        perf_held |= PF_BIT(e);
        perf_ord[e] = ++perf_seq;
    } else {
        perf_held &= ~PF_BIT(e);
    }
}

static void perf_start(void) { pf.ph = 0; pf.sync = 1; pfx_lph = 0; pfx_adv = 0; }   /* seq_start: a 1/16 with the
                                                                                      * transport */

/* the SLICER's recordings dropped (when the buffer is taken and given back): the tracks' and MASTER's */
static void perf_drop_slicer(void) { AUDIO_FAR(slicer_drop_all)(); }

/* the buffer effect to play: the last pressed of those running (out of line: the scan is shared with the UI) */
static __attribute__((noinline)) uint32_t perf_pick(uint32_t a)
{
    uint32_t e, best = PF_N;
    a &= PF_BUF;
    while (a) {                              /* the bits set only, low to high: the order the scan had */
        e = (uint32_t)__builtin_ctz(a);
        a &= a - 1u;
        if (best == PF_N || perf_ord[e] - perf_ord[best] < 0x80000000u)
            best = e;
    }
    return best;
}

/* perf_begin's snapshot: the buffer effect its act0 / act pick. In RAM, called once a block: inlined into perf_begin
 * (flash) the scans moved the flash code behind it, and the stack scenario lost ~8 % to cache misses
 * (docs/fm1-emu-test.md: placement). perf_pick stays out of line, shared with the UI (perf_harm_on) */
static AUDIO_RAM __attribute__((noinline)) void perf_ctl_picks(perf_blk_t *c)
{
    c->pick0 = (uint8_t)AUDIO_FAR(perf_pick)(c->act0);
    c->pick = (uint8_t)AUDIO_FAR(perf_pick)(c->act);
}

#ifdef FELUCCA_LAYOUT_PAD
/* tests/layout_sweep.sh only: 8 x FELUCCA_LAYOUT_PAD stores that never run. They move the flash code behind them, and
 * with it which hot lines share a cache set, so a change can be judged over several layouts (docs/fm1-emu-test.md) */
#define LAYOUT_PAD_1(i) p[i] = (i) * 7u + 1u;
#define LAYOUT_PAD_8(b) LAYOUT_PAD_1(b) LAYOUT_PAD_1(b + 1) LAYOUT_PAD_1(b + 2) LAYOUT_PAD_1(b + 3) \
                        LAYOUT_PAD_1(b + 4) LAYOUT_PAD_1(b + 5) LAYOUT_PAD_1(b + 6) LAYOUT_PAD_1(b + 7)
__attribute__((used, noinline)) static void layout_pad(volatile uint32_t *p)
{
    LAYOUT_PAD_8(0)
#if FELUCCA_LAYOUT_PAD > 1
    LAYOUT_PAD_8(8)
#endif
#if FELUCCA_LAYOUT_PAD > 2
    LAYOUT_PAD_8(16)
#endif
#if FELUCCA_LAYOUT_PAD > 3
    LAYOUT_PAD_8(24)
#endif
#if FELUCCA_LAYOUT_PAD > 4
    LAYOUT_PAD_8(32)
#endif
#if FELUCCA_LAYOUT_PAD > 5
    LAYOUT_PAD_8(40)
#endif
#if FELUCCA_LAYOUT_PAD > 6
    LAYOUT_PAD_8(48)
#endif
}
#endif

static void perf_glt_step(void);

static void perf_buf_start(uint32_t e)
{
    pf.src = (uint8_t)e;                    /* (sl_buf is borrowed by perf_begin, before the parts) */
    pf.next = PF_N;
    pf.wr = pf.rp = 0;
    pf.odd = 0;
    pf.xn = 0;
    if (e == PF_GLT) {                     /* its first 1/16: the transport's (this block's split starts the next) */
        uint32_t s16 = beat_samples() >> 2;
        pf.mode = BM_GLT;
        memset(&pf.gl, 0, sizeof pf.gl);
        memset(&sl_buf[0][0] + 2u * (PB_FRAMES - 2u), 0, 4u * sizeof(int16_t));   /* reads before the start: quiet */
        pf.glgs = song.playing && clk_pos != CLK_START && s16 ? pfx_lph / s16 + (pf.split ? 1u : 0u) : 0u;
        perf_glt_step();
    } else if (e == PF_TAPE) {
        uint32_t t = beat_samples();
        pf.mode = BM_TAPE;
        if (t > PB_TAPE)
            t = PB_TAPE;
        pf.tv = 65536;
        pf.dv = 65536u / t + 1u;
        pf.tpos = 0;
    } else if (e == PF_OUP || e == PF_ODN) {    /* (wr: the frame written next, len: frames written) */
        pf.mode = BM_HARM;
        pf.len = 0;
        pf.hph = 0;
        pf.hinc = e == PF_OUP ? 0u - (1u << 21) : 1u << 20;   /* the delay: -1 / +0.5 sample a sample */
        pf.hfb = 0;
    } else if (e == PF_FRZ) {
        pf.mode = BM_FRZ;
        pf.gp[0] = 0;
        pf.gp[1] = PB_GRAIN / 2u;
        pf.gs[0] = pf.gs[1] = 0;
    } else {
        pf.mode = BM_LOOP;
        pf.state = 0;
        pf.len = perf_len(e);
        pf.rev = e == PF_REV;
    }
}

/* the buffer effect to play becomes e (at a 1/16 for REPEAT / REVERSE): a shorter REPEAT of what is
 * recorded switches with a cross-fade, anything else fades the old one out first */
static void perf_buf_select(uint32_t e)
{
    if (e == pf.src && pf.next == PF_N)
        return;
    if (e != PF_N && pf.mode == BM_LOOP && pf.state && perf_loop(e) && pf.src != PF_N &&
        perf_len(e) <= 2u * pf.wr) {
        pf.xrp = pf.rp;
        pf.xlen = pf.len;
        pf.xrev = pf.rev;
        pf.xn = SL_RAMP;
        pf.src = (uint8_t)e;
        pf.next = PF_N;
        pf.len = perf_len(e);
        pf.rev = e == PF_REV;
        pf.rp = 0;
        return;
    }
    if (pf.mode == BM_NONE || !pf.w) {
        if (e == PF_N) {
            pf.src = PF_N;
            pf.next = PF_N;
        } else {
            perf_buf_start(e);
        }
        return;
    }
    pf.src = PF_N;                                  /* fade out, then the next one (perf_seg) */
    pf.next = (uint8_t)e;
}

/* each block, after the keys (seq.c) and before the parts: what runs, the 1/16, the filters, the mutes; also the
 * SLICER's buffer, which the buffer effects borrow. Returns 1 when a stage has something to do, and leaves perf_ctl:
 * the copy the layer reads a block late (it runs beside this core's tail, on either core) */
static AUDIO_RAM __attribute__((noinline)) int perf_begin(uint32_t n)
{
    uint32_t solo = solo_mask(), off = off_mask(), s16 = AUDIO_FAR(beat_samples)() >> 2, lane = 0, held, mute, q, k, ph0, bnd;
    if (song.playing && s16) {                         /* the punch-in lane's step at this block's end (pfx_lph,
                                                         * pfx_block's retimed clock) */
        if (!pfx_adv)                                   /* a transport started this block, after pfx_block: its
                                                         * clock from 0 and this block's n still to add */
            pfx_lph += n;
        lane = pfx_lane[((pfx_lph - 1u) / s16) & 63u];
    }
    held = ((perf_kill ? 0u : perf_held | perf_latched | (solo ? (~solo & 15u) << PF_M1 : 0u)) | lane) & AUDIO_FAR(perf_avail)() & ~PF_MIDI;
    /* mix_part's mutes: a black key, a ramp still running, or PLAY OFF (GLO) — the OFF ones are not the layer's,
     * so a sounding note ramps out in mix_part while perf_begin may stay idle */
    pf.mute = 0;
    for (k = 0; k < NTRK; k++)
        if (((held >> (PF_M1 + k)) & 1u) || pf.mg[k] != 32768)
            pf.mute |= (uint8_t)(1u << k);
    pf.mute |= (uint8_t)off;                        /* (PLAY OFF: mix_part ramps a sounding note, not the layer) */
    mute = pf.mute & ~off;
    int32_t m;
    /* the buffer effects borrow sl_buf from the SLICER: taken and given back here, on core 0, before the parts render, so
     * the layer (a block late, on either core) never drops the slicer's state under them */
    if (held & PF_BUF) {
        if (!sl_lent) {
            sl_lent = 1;
            perf_drop_slicer();
        }
    } else if (sl_lent && pf.mode == BM_NONE && !perf_pipe_pending()) {
        perf_drop_slicer();                     /* (the store after the call: its cold path is not the take's) */
        sl_lent = 0;
    }
    /* idle: the clock only. THROW's glide, the mutes and the knobs are this core's; the layer's own stages report
     * through perf_layer_busy. (One OR, no branch per term: a cold branch here reads as a loop to target_budget) */
    if (!(held | perf_layer_busy | (uint32_t)(perf_k[0] | perf_k[1] | perf_k[2]) | (uint32_t)pf.td | pf.thr |
          mute)) {
        pf.ph += n;
        pf.sync = 0;
        perf_act = 0;
        return 0;
    }
    pf.P = s16;
    if (pf.sync) {
        pf.ph = 0;
        pf.sync = 0;
    }
    {   /* the 1/16 in this block (n: none), on the retimed lane clock while playing: pfx_lph is this block's end */
        uint32_t lane0 = song.playing && s16 ? pfx_lph - n : pf.ph;
        ph0 = lane0 % pf.P;
        bnd = ph0 ? (pf.P - ph0 < n ? pf.P - ph0 : n) : 0u;
    }
    pf.ph += n;
    pf.act &= held;                                 /* let go: at once */
    pf.act |= held & ~PF_Q;
    pf.act0 = pf.act;
    q = held & PF_Q & ~pf.act;
    pf.split = n;
    if (q && (!song.playing || bnd < n)) {
        pf.split = song.playing ? bnd : 0u;
        pf.act |= q;
    }
    perf_act = pf.act;
    /* the filters: LPF from open down over a bar while its key is held, KNOB 1 left; HPF up, KNOB 1 right */
    m = perf_k[0];
    {
        uint32_t bar = 16u * pf.P, t;
        int32_t lt = PF_TOP, ht = 0;
        pf.lt = (pf.act & PF_BIT(PF_LPF)) ? pf.lt + n : 0u;
        pf.ht = (pf.act & PF_BIT(PF_HPF)) ? pf.ht + n : 0u;
        if (pf.lt) {
            t = pf.lt < bar ? pf.lt : bar;
            lt = PF_TOP - (int32_t)((uint32_t)(PF_TOP - PF_LOW) / 64u * (t * 64u / bar));
        }
        if (m < 0 && PF_TOP + m * (PF_TOP - PF_LOW) / 100 < lt)
            lt = PF_TOP + m * (PF_TOP - PF_LOW) / 100;
        if (pf.ht) {
            t = pf.ht < bar ? pf.ht : bar;
            ht = (int32_t)((uint32_t)(PF_TOP - PF_LOW) / 64u * (t * 64u / bar));
        }
        if (m > 0 && m * (PF_TOP - PF_LOW) / 100 > ht)
            ht = m * (PF_TOP - PF_LOW) / 100;
        pf.lc += clamp(lt - pf.lc, -192, 192);      /* ~45 ms over the range */
        pf.hc += clamp(ht - pf.hc, -192, 192);
        for (k = 0; k < 3u; k++) {                  /* the coefficients, between two table rows */
            int32_t i = pf.lc >> 8, f = pf.lc & 255, j = pf.hc >> 8, g = pf.hc & 255;
            pf.lk[k] = (int16_t)(PF_SVF[i][k] + (((PF_SVF[i < 63 ? i + 1 : 63][k] - PF_SVF[i][k]) * f) >> 8));
            pf.hk[k] = (int16_t)(PF_SVF[j][k] + (((PF_SVF[j < 63 ? j + 1 : 63][k] - PF_SVF[j][k]) * g) >> 8));
        }
    }
    {   /* REV / ECHO THROW: their shares glide (THR_SLOPE a sample) to full while held, back to 0 when let go */
        int32_t s = THR_SLOPE * (int32_t)n;
        pf.rw = pf.rw1;
        pf.ew = pf.ew1;
        pf.rw1 += clamp((pf.act & PF_BIT(PF_RTHR) ? 32768 : 0) - pf.rw1, -s, s);
        pf.ew1 += clamp((pf.act & PF_BIT(PF_ETHR) ? 32768 : 0) - pf.ew1, -s, s);
        pf.thr = (pf.rw | pf.rw1 | pf.ew | pf.ew1) != 0;
    }
    perf_ctl.act = pf.act;
    perf_ctl.act0 = pf.act0;
    perf_ctl.split = pf.split;
    perf_ctl.ph = pf.ph;
    perf_ctl.P = pf.P;
    perf_ctl.lc = pf.lc;
    perf_ctl.hc = pf.hc;
    perf_ctl.lk[0] = pf.lk[0];
    perf_ctl.lk[1] = pf.lk[1];
    perf_ctl.lk[2] = pf.lk[2];
    perf_ctl.hk[0] = pf.hk[0];
    perf_ctl.hk[1] = pf.hk[1];
    perf_ctl.hk[2] = pf.hk[2];
    perf_ctl.k[0] = perf_k[0];
    perf_ctl.k[1] = perf_k[1];
    perf_ctl.k[2] = perf_k[2];
    perf_ctl.k[3] = perf_k[3];
    AUDIO_FAR(perf_ctl_picks)(&perf_ctl);
    return 1;
}

/* perf_mute with SPREAD's side signal sd (fx.c mix_spread): the same ramp on both; sd 0: the mono mix
 * (fx.c mix_part). PLAY OFF reaches here without the layer (perf_begin's mute mask), so its own target is 0 */
static __attribute__((noinline)) void perf_mute_sd(uint32_t k, int32_t *b, int32_t *sd, uint32_t n)
{
    uint32_t i;
    int32_t g = pf.mg[k], t = (((pf.act >> (PF_M1 + k)) & 1u) || trk[k].p[P_MUTE] == PLAY_OFF) ? 0 : 32768;
    if (g == 32768 && t == 32768)
        return;
    for (i = 0; i < n; i++) {
        if (t != g)
            g += clamp(t - g, -SL_SLOPE, SL_SLOPE);
        b[i] = mulq16(b[i], (uint32_t)g << 1);
        if (sd)
            sd[i] = mulq16(sd[i], (uint32_t)g << 1);
    }
    pf.mg[k] = g;
}
/* a track muted by its black key, or PLAY OFF (GLO): its signal, still sounding notes too, ramps to 0 and back
 * (fx.c mix_part, after the SLICER) */
static __attribute__((noinline)) void perf_mute(uint32_t k, int32_t *b, uint32_t n) { perf_mute_sd(k, b, 0, n); }

/* before the buses: THROW (KNOB 3) adds the dry mix to the delay and reverb sends */
static __attribute__((noinline)) void perf_pre(const int32_t *ml, const int32_t *mr, int32_t *sd, int32_t *sr,
                                               uint32_t n)
{
    uint32_t i;
    int32_t m = perf_k[2] * 327;
    if (!m && !pf.td)                        /* THROW off and the glide down finished: nothing to add */
        return;
    for (i = 0; i < n; i++) {
        if (m != pf.td)
            pf.td += clamp(m - pf.td, -SL_SLOPE, SL_SLOPE);
        if (pf.td) {
            int32_t x = mulq16((ml[i] + mr[i]) >> 1, (uint32_t)pf.td << 1);
            sd[i] += x;
            sr[i] += x;
        }
    }
}

/* REV THROW / ECHO THROW (1.5.1): track t's reverb / delay send towards full (127) while held, b its signal as its sends
 * take it (fx.c mix_part, after the mute key; t's values as the matrix has them this block). What the full send adds to
 * the track's own (REV / DLY) goes in at the share rw / ew, which glides from the block's start to its end a sample at
 * a time (THR_SLOPE: no click; every track the same glide). The track's REV / DLY are never changed: nothing is saved
 * or recorded, and when the key is let go the share glides back to 0 and the buses ring out as they are */
static __attribute__((noinline)) void perf_throw(const track_t *t, const int32_t *b, int32_t *sd, int32_t *sr, uint32_t n)
{
    uint32_t i;
    int32_t lvl = LEVEL_Q12[t->p[P_LEVEL] & 127];
    int32_t rg = 32766 - t->p[P_REV] * 258, dg = 32766 - t->p[P_DLY] * 258;   /* full (127 * 258) less its own */
    int32_t rw = pf.rw, ew = pf.ew, r1 = pf.rw1, e1 = pf.ew1;
    i = 0;
    while (i < n && (rw != r1 || ew != e1)) {      /* the glide: at most 512 samples end to end */
        int32_t x = clamp(((b[i] >> 2) * lvl) >> 10, -65536, 65536);   /* (mix_part's xs at a full send) */
        rw += clamp(r1 - rw, -THR_SLOPE, THR_SLOPE);
        ew += clamp(e1 - ew, -THR_SLOPE, THR_SLOPE);
        sr[i] += mulq15(x, mulq16(rg, (uint32_t)rw << 1));
        sd[i] += mulq15(x, mulq16(dg, (uint32_t)ew << 1));
        i++;
    }
    if (rw == r1 && ew == e1) {                    /* both settled: the gains are constant for the rest */
        int32_t rgw = mulq16(rg, (uint32_t)rw << 1), dgw = mulq16(dg, (uint32_t)ew << 1);
        for (; i < n; i++) {
            int32_t x = clamp(((b[i] >> 2) * lvl) >> 10, -65536, 65536);
            sr[i] += mulq15(x, rgw);
            sd[i] += mulq15(x, dgw);
        }
    }
}

/* x towards y by w (Q15, 32768 = y) */
static inline int32_t pf_mix(int32_t x, int32_t y, int32_t w)
{
    return w == 32768 ? y : x + mulq16(y - x, (uint32_t)w << 1);
}

/* the loop: frame f of it, both channels (Q15) */
static inline void pb_put(uint32_t f, int32_t l, int32_t r)
{
    int16_t *p = &sl_buf[0][0] + 2u * (f & (PB_FRAMES - 1u));
    p[0] = (int16_t)clamp(l, -32768, 32767);
    p[1] = (int16_t)clamp(r, -32768, 32767);
}
/* sample s of the frames recorded from 0 (n of them): between two frames on an odd one */
static inline void pb_at(uint32_t s, uint32_t n, int32_t *l, int32_t *r)
{
    uint32_t f = s >> 1 < n ? s >> 1 : n - 1u;    /* (an odd loop's last sample: the frame before) */
    const int16_t *p = &sl_buf[0][0] + 2u * (f & (PB_FRAMES - 1u));
    const int16_t *q;                               /* a frame is the mean of samples 2f, 2f + 1: sample s */
    if (s & 1u)                                     /* lies a quarter frame from it, towards f + 1 or f - 1 */
        q = f + 1u < n ? p + 2 : p;
    else
        q = f ? p - 2 : p;
    *l = (3 * p[0] + q[0]) >> 1;
    *r = (3 * p[1] + q[1]) >> 1;
}
/* REPEAT / REVERSE at sample rp of a loop of len, windowed at both ends */
static inline void pb_loop(uint32_t rp, uint32_t len, int rev, uint32_t n, int32_t *l, int32_t *r)
{
    uint32_t e = len - 1u - rp;
    pb_at(rev ? e : rp, n, l, r);
    if (rp < e)
        e = rp;
    if (e < (uint32_t)SL_RAMP) {
        *l = (*l * (int32_t)e) >> SL_RAMP_LOG2;
        *r = (*r * (int32_t)e) >> SL_RAMP_LOG2;
    }
}

/* record the pair into frame f (the mean, >> 1: headroom) */
static inline uint32_t pb_rec(uint32_t f, int32_t l, int32_t r)
{
    if (!pf.odd) {
        pf.hl = l;
        pf.hr = r;
        pf.odd = 1;
        return f;
    }
    pf.odd = 0;
    pb_put(f, (pf.hl + l) >> 2, (pf.hr + r) >> 2);
    return f + 1u;
}

/* --------------------------------------------------------------- GLITCH --- */
/* (JIANT 0.9.9-snd2, ported from 0.9.18) the master cut on the transport's 1/16s: each one, by a hash of its place in
 * a 2-bar cycle (the same every time, so it grooves; half glitched, the beats a quarter), played live, or the last L
 * repeated, the last 1/16 reversed, an octave up or down, gated, SKIP (a CD skipping: tiny fragments), or CRUSH (live,
 * 6..9 bits off, held 1..6 samples). Every slice windowed (SL_RAMP). Below ~82 BPM only gates, crushes and live slices
 * play (the loop holds 371 ms). Knobs fixed: DENS 50 / PITCH 0 / SIZE 0 / VARI 1. */
static __attribute__((noinline)) void pb_ring_f(uint32_t s, int32_t *l, int32_t *r)
{
    uint32_t f = s >> 17;
    int32_t fr = (int32_t)((s >> 2) & 0x7FFFu);
    const int16_t *p = &sl_buf[0][0] + 2u * (f & (PB_FRAMES - 1u));
    const int16_t *q = &sl_buf[0][0] + 2u * ((f + 1u) & (PB_FRAMES - 1u));
    *l = 2 * (p[0] + (((q[0] - p[0]) * fr) >> 15));
    *r = 2 * (p[1] + (((q[1] - p[1]) * fr) >> 15));
}
/* a slice's place in its 2-bar cycle (and its variation) to 32 random bits */
static uint32_t pf_hash(uint32_t h)
{
    h *= 0x9E3779B1u;
    h = (h ^ (h >> 15)) * 0x2C1B3C6Du;
    return h ^ (h >> 13);
}
/* a segment's start: where it reads (Q16) and how fast (SKIP: a place in the 1/16, two segments at each) */
static __attribute__((noinline)) void perf_glt_seg(void)
{
    uint32_t a = pf.gl.a, L = pf.gl.l, g0 = pf.gl.g0, s = g0 - L;
    pf.gl.rate = 65536;
    if (a == GA_REV) {
        s = g0 - 1u;
        pf.gl.rate = -65536;
    } else if (a == GA_UP) {
        s = g0 - 2u * L;
        pf.gl.rate = 131072;
    } else if (a == GA_DN) {
        pf.gl.rate = 32768;
    } else if (a == GA_SKIP) {
        s = g0 - pf.gl.sp + pf_hash(pf.glgs * 64u + (pf.gl.k >> 1)) % (pf.gl.sp - L + 1u);
    }
    pf.gl.src = (s & (PB_MAX - 1u)) << 16;          /* Q16 samples; each stored frame holds two samples */
}
/* the next 1/16's slice */
static __attribute__((noinline)) void perf_glt_step(void)
{
    uint32_t h = pf_hash((pf.glgs & 31u) + 0x51u), s16 = pf.P ? pf.P : 1u,
             sp = s16 < GL_SPAN ? s16 : GL_SPAN, j = (h >> 12) % 3u, a, L;
    a = ((h >> 24) * 100u >> 8) < (pf.glgs & 3u ? GX_DENS : GX_DENS * GX_DENS / 100u) ? GA_OF[(h >> 8) & 15u] : GA_PASS;
    pf.gl.g0 = 2u * pf.wr + pf.odd;                 /* the loop's sample now */
    if ((s16 + sp > PB_MAX - 512u || pf.gl.g0 < sp) && a != GA_GATE && a != GA_CRU)
        a = GA_PASS;                                /* too slow (what it would read is gone) or not recorded yet */
    L = a == GA_RPT ? sp >> j : a == GA_GATE ? (s16 / 2u) >> (j % 2u)
      : a == GA_SKIP ? sp >> (3u + j % 2u) : a == GA_UP ? sp / 2u : a == GA_CRU ? s16 : sp;
    pf.gl.a = (uint8_t)a;
    pf.gl.l = L < 2u * SL_RAMP ? 2u * SL_RAMP : L;
    pf.gl.sp = sp;
    pf.gl.h = (uint8_t)(1u + (h >> 14) % 6u);
    pf.gl.sh = (uint8_t)(6u + j + (h >> 20) % 2u);
    pf.gl.n = 255u;
    pf.gl.u = pf.gl.k = pf.glph = 0;
    AUDIO_FAR(perf_glt_seg)();
}
/* GLITCH on one sample: 1 = it plays (gl_yl / gl_yr), 0 = live */
static __attribute__((noinline)) int perf_glt(int32_t l, int32_t r)
{
    uint32_t u = pf.gl.u, L = pf.gl.l, a = pf.gl.a, e = L - 1u - u < u ? L - 1u - u : u, g = 32768u;
    pf.wr = pb_rec(pf.wr, l, r);
    if (a != GA_PASS) {
        if (a == GA_SKIP) {
            if (e < SL_RAMP / 4u)
                g = e << (17 - SL_RAMP_LOG2);
        } else if (e < (uint32_t)SL_RAMP)
            g = e << (15 - SL_RAMP_LOG2);
        if (a == GA_GATE) {
            g = pf.gl.k & 1u ? 0u : g;
            pf.gl_yl = mulq16(l, g << 1);
            pf.gl_yr = mulq16(r, g << 1);
        } else if (a == GA_CRU) {
            if (++pf.gl.n >= pf.gl.h) {
                int32_t b = 1 << (pf.gl.sh - 1u);
                pf.gl.n = 0;
                pf.gl.cl = shl((l + b) >> pf.gl.sh, pf.gl.sh);
                pf.gl.cr = shl((r + b) >> pf.gl.sh, pf.gl.sh);
            }
            pf.gl_yl = mulq16(pf.gl.cl, g << 1);
            pf.gl_yr = mulq16(pf.gl.cr, g << 1);
        } else {
            pb_ring_f(pf.gl.src + (uint32_t)((int32_t)u * (pf.gl.rate >> 2)) * 4u, &pf.gl_yl, &pf.gl_yr);
            pf.gl_yl = mulq16(pf.gl_yl, g << 1);
            pf.gl_yr = mulq16(pf.gl_yr, g << 1);
        }
    }
    if (++pf.gl.u >= L) {
        pf.gl.u = 0;
        pf.gl.k++;
        perf_glt_seg();
    }
    if (++pf.glph >= pf.P) {
        pf.glgs++;
        AUDIO_FAR(perf_glt_step)();
    }
    return a != GA_PASS;
}

/* FREEZE: grain g's sample, by its triangle window, added to yl / yr; a new start at each pass */
static inline void perf_grain(uint32_t g, int32_t *yl, int32_t *yr)
{
    uint32_t p = pf.gp[g], tri = p < PB_GRAIN / 2u ? p : PB_GRAIN - p;
    int32_t a, b;
    if (!p)
        pf.gs[g] = ((rng() >> 16) * (pf.wr - PB_GRAIN / 2u + 1u)) >> 16;
    pb_at(2u * pf.gs[g] + p, pf.wr, &a, &b);
    *yl += a * (int32_t)tri;
    *yr += b * (int32_t)tri;
    pf.gp[g] = p + 1u < PB_GRAIN ? p + 1u : 0u;
}

/* OCT UP / DN: the tap at sweep place ph, both channels (as stored: half the level); silence before the
 * delay has that much in it */
static inline void hb_tap(uint32_t ph, int32_t *l, int32_t *r)
{
    uint32_t d = (HB_BASE << 16) + (ph >> 5), di = d >> 16;   /* the delay, Q16: 128 .. 2176 samples */
    int32_t f = (int32_t)((d >> 1) & 0x7FFFu);
    const int16_t *p, *q;
    if (di + 1u > pf.len) {
        *l = *r = 0;
        return;
    }
    p = &sl_buf[0][0] + 2u * ((pf.wr - di) & HB_MASK);
    q = &sl_buf[0][0] + 2u * ((pf.wr - di - 1u) & HB_MASK);
    *l = p[0] + (((q[0] - p[0]) * f) >> 15);
    *r = p[1] + (((q[1] - p[1]) * f) >> 15);
}
/* OCT UP / DN on one sample: yl / yr the harmonized mix (see the top). noinline: perf_block's loop keeps its
 * code layout (target_budget.py: a block placed out of line looks like a loop round the per-sample code) */
static __attribute__((noinline)) void perf_harm(int32_t l, int32_t r, int32_t *yl, int32_t *yr)
{
    int32_t wa = (32768 - osc_sine(pf.hph + 0x40000000u)) >> 1, al, ar, bl, br, sl_, sr_;   /* A's share, Q15 */
    hb_tap(pf.hph, &al, &ar);
    hb_tap(pf.hph + 0x80000000u, &bl, &br);
    sl_ = (al * wa + bl * (32768 - wa)) >> 15;
    sr_ = (ar * wa + br * (32768 - wa)) >> 15;
    l >>= 1;                                        /* (stored at half: headroom, as the loop's frames) */
    r >>= 1;
    {
        int32_t xl = l, xr = r;
        if (pf.hfb) {                               /* the shimmer: back into the delay, soft-clipped */
            xl += softclip(mulq15(sl_, pf.hfb));
            xr += softclip(mulq15(sr_, pf.hfb));
        }
        if (pf.len < (uint32_t)SL_RAMP) {           /* the recording fades in (2.9 ms): no step where it */
            xl = (xl * (int32_t)pf.len) >> SL_RAMP_LOG2;   /* begins, for a tap to read across */
            xr = (xr * (int32_t)pf.len) >> SL_RAMP_LOG2;
        }
        pb_put(pf.wr & HB_MASK, xl, xr);
    }
    pf.wr++;
    if (pf.len <= HB_MASK)
        pf.len++;
    pf.hph += pf.hinc;
    *yl = l + (l >> 3) + ((sl_ * 45875) >> 15);     /* 0.56 live + 0.7 shifted (x2: stored at half) */
    *yr = r + (r >> 3) + ((sr_ * 45875) >> 15);
}

/* the buffer effect faded out: the next one, or the buffer back. Once per effect, out of the per-sample loop
 * (noinline: its calls stay out of perf_block's loop code). The buffer goes back at the next perf_begin: the job may
 * run on core 1 while the parts use the slicer */
static __attribute__((noinline)) void perf_buf_done(void)
{
    if (pf.next != PF_N) {
        perf_buf_start(pf.next);
    } else {
        pf.mode = BM_NONE;
    }
}

/* the buffer effect on one sample: the share pf.w of what it plays, the rest live */
static inline void perf_buf(int32_t *pl, int32_t *pr)
{
    int32_t l = *pl, r = *pr, yl = 0, yr = 0, on = 0;
    if (pf.mode == BM_LOOP) {
        if (!pf.state) {
            pf.wr = pb_rec(pf.wr, l, r);
            if (++pf.rp >= pf.len) {                /* (rp: samples recorded) */
                pf.state = 1;
                pf.rp = 0;
            }
        } else {
            pb_loop(pf.rp, pf.len, pf.rev, pf.wr, &yl, &yr);
            if (pf.xn) {                            /* the loop it switched from, fading out */
                int32_t ol, orr, g = (int32_t)pf.xn;
                pb_loop(pf.xrp, pf.xlen, pf.xrev, pf.wr, &ol, &orr);
                yl += (ol * g) >> SL_RAMP_LOG2;
                yr += (orr * g) >> SL_RAMP_LOG2;
                pf.xn--;
                if (++pf.xrp >= pf.xlen)
                    pf.xrp = 0;
            }
            if (++pf.rp >= pf.len)
                pf.rp = 0;
            on = 1;
        }
    } else if (pf.mode == BM_GLT) {
        if ((on = AUDIO_FAR(perf_glt)(l, r)) != 0) {           /* GLITCH: a slice, or live */
            yl = pf.gl_yl;
            yr = pf.gl_yr;
        }
    } else if (pf.mode == BM_TAPE) {
        pf.wr = pb_rec(pf.wr, l, r);
        if (pf.wr >= 2u) {                          /* read behind the writing, slower and slower */
            uint32_t f = pf.tpos >> 16;
            int32_t fr = (int32_t)((pf.tpos >> 1) & 0x7FFFu), a, b, env;
            const int16_t *p = &sl_buf[0][0] + 2u * (f & (PB_FRAMES - 1u));
            const int16_t *s = &sl_buf[0][0] + 2u * ((f + 1u) & (PB_FRAMES - 1u));
            a = p[0];
            b = s[0];
            yl = shl(a + (((b - a) * fr) >> 15), 1);
            a = p[1];
            b = s[1];
            yr = shl(a + (((b - a) * fr) >> 15), 1);
            env = pf.tv >= 8192u ? 32768 : (int32_t)(pf.tv << 2);   /* the last eighth fades to silence */
            yl = mulq16(yl, (uint32_t)env << 1);
            yr = mulq16(yr, (uint32_t)env << 1);
            pf.tpos += pf.tv >> 1;
            pf.tv = pf.tv > pf.dv ? pf.tv - pf.dv : 0u;
            on = 1;
        }
    } else if (pf.mode == BM_FRZ) {
        if (pf.wr < PB_FREC)
            pf.wr = pb_rec(pf.wr, l, r);
        if (pf.wr >= PB_GRAIN / 2u) {               /* two grains of what it caught, triangle windows */
            perf_grain(0, &yl, &yr);
            perf_grain(1, &yl, &yr);
            yl >>= 10;                              /* (the windows sum to PB_GRAIN / 2) */
            yr >>= 10;
            on = 1;
        }
    } else if (pf.mode == BM_HARM) {
        AUDIO_FAR(perf_harm)(l, r, &yl, &yr);
        on = 2;                                     /* (KNOB 4 is the shimmer: the level stays full) */
    }
    pf.tw = on && pf.src != PF_N ? on == 2 ? 32768 : 32768 - perf_k4 * 327 : 0;
    pf.w += clamp(pf.tw - pf.w, -SL_SLOPE, SL_SLOPE);
    if (pf.w) {
        *pl = pf_mix(l, yl, pf.w);
        *pr = pf_mix(r, yr, pf.w);
    } else if (pf.src == PF_N) {                    /* faded out: the next one, or the buffer back */
        AUDIO_FAR(perf_buf_done)();
    }
}

/* one channel of a state-variable filter (k = 1): x in Q15 >> 2 */
static inline int32_t pf_svf(int32_t x, int32_t *z, const int16_t *c, int hp)
{
    int32_t v3 = x - z[1], v1 = (c[0] * z[0] + c[1] * v3) >> 14, v2 = z[1] + ((c[1] * z[0] + c[2] * v3) >> 14);
    z[0] = 2 * v1 - z[0];
    z[1] = 2 * v2 - z[1];
    return hp ? x - v1 - v2 : v2;
}

/* the buffer effect to play becomes e (a perf_blk_t's pick), out of perf_block's loop code */
static __attribute__((noinline)) void perf_switch(uint32_t e) { perf_buf_select(e); }

/* the UI: OCT UP / DN is the buffer effect playing (KNOB 4 is its shimmer, the card says so) */
static int perf_harm_on(void) { return (PF_HARM >> perf_pick(perf_act)) & 1u; }

/* FLANGER / PHASER: the sweep's place at this block's first sample, a cycle every `s` 1/16s of the transport's clock
 * (c->ph: in time with the bars while playing), and its step a sample (*inc) */
static uint32_t perf_lfo(const perf_blk_t *c, uint32_t s, uint32_t n, uint32_t *inc)
{
    uint32_t per = s * c->P;
    *inc = 0xFFFFFFFFu / per;
    return ((c->ph - n) % per) * *inc;
}
/* a triangle of the sweep's place q, 0 .. 65534 (Q16) */
static inline uint32_t pf_tri(uint32_t q)
{
    uint32_t t = q >> 16;
    return t < 32768u ? t << 1 : (65535u - t) << 1;
}
/* the share a FLANGER / PHASER fades to: KNOB 4 DEPTH (its shimmer while OCT UP / DN plays: full) */
static int32_t perf_mod_depth(const perf_blk_t *c)
{
    return (PF_HARM >> c->pick) & 1u ? 32768 : 32768 - c->k[3] * 327;
}

/* FLANGER on one side c: x in, the line read at the sweep's place q (see the top) */
static inline int32_t fl_side(uint32_t c, int32_t x, uint32_t q)
{
    uint32_t t = pf_tri(q), d = (FL_MIN << 16) + (FL_MAX - FL_MIN) * ((t * t) >> 16);   /* the delay, Q16 samples */
    int32_t r0 = (int32_t)pf.fwp - (int32_t)(d >> 16), r1, a, v, fr = (int32_t)((d >> 1) & 0x7FFFu);
    if (r0 < 0)
        r0 += (int32_t)FL_LEN;
    r1 = r0 ? r0 - 1 : (int32_t)FL_LEN - 1;
    a = fl_buf[r0][c];
    v = a + (((fl_buf[r1][c] - a) * fr) >> 15);
    fl_buf[pf.fwp][c] = (int16_t)clamp((x >> 1) + softclip(mulq15(v, FL_FB)), -32767, 32767);
    return pf_mix(x, mulq16((x >> 1) + v, 55706u), pf.fw);   /* (x + delayed) / 2 * 0.85 (v: stored at half) */
}
/* after CRUSH, while held or fading: FLANGER (noinline, its own loop: the audio ISR's code stays as it was) */
static __attribute__((noinline)) void perf_flanger(int32_t *bl, int32_t *br, uint32_t n,
                                                             const perf_blk_t *c)
{
    uint32_t i, c_, inc, q = perf_lfo(c, 16u, n, &inc);
    int32_t tw = c->act & PF_BIT(PF_FLG) ? perf_mod_depth(c) : 0, *const b[2] = {bl, br};
    if (!pf.fw && !(c->act & PF_BIT(PF_FLG))) {        /* let go and faded: off, the line empty next time */
        pf.fn = 0;
        return;
    }
    if (!pf.fn)                                         /* (starting: the line empty) */
        memset(fl_buf, 0, sizeof fl_buf);
    for (i = 0; i < n; i++, q += inc) {
        pf.fw += clamp((pf.fn > FL_MAX + 1u ? tw : 0) - pf.fw, -SL_SLOPE, SL_SLOPE);   /* (heard once it holds 8 ms) */
        for (c_ = 0; c_ < 2u; c_++)                    /* (one call: inlined; the right a quarter of the sweep behind) */
            b[c_][i] = fl_side(c_, b[c_][i], q - (c_ << 30));
        if (++pf.fwp >= FL_LEN)
            pf.fwp = 0;
        if (pf.fn <= FL_MAX + 1u)
            pf.fn++;
    }
}

/* PHASER: the stages' coefficient a (Q14) for a break of 150 Hz * 2^(5 i / 32): a = (g - 1) / (g + 1), g = tan(pi f / fs) */
static const int16_t PH_A[33] = {
    -16038, -15998, -15955, -15906, -15853, -15793, -15727, -15653, -15572, -15481, -15381, -15270, -15147, -15012,
    -14862, -14696, -14514, -14313, -14092, -13849, -13582, -13290, -12970, -12621, -12240, -11825, -11375, -10886,
    -10356, -9784, -9166, -8500, -7783,
};
/* PHASER: the stages' coefficient at the sweep's place q (Q14) */
static int32_t ph_coef(uint32_t q)
{
    uint32_t t = pf_tri(q), i = t >> 11;
    return PH_A[i] + (((PH_A[i + 1u] - PH_A[i]) * (int32_t)(t & 2047u)) >> 11);
}
/* PHASER on one side c: x in, the stages' coefficient a (rounded: no DC creeping in through the low breaks) */
static inline int32_t ph_side(uint32_t c, int32_t x, int32_t a)
{
    int32_t xs = clamp((x + 2) >> 2, -16383, 16383), u = xs + ((pf.pfb[c] * PH_FB + 16384) >> 15), y = u;
    uint32_t s;
    for (s = 0; s < PH_ST; s++) {                       /* y = a (u - y1) + u1 */
        y = clamp(pf.px[c][s] + ((a * (u - pf.py[c][s]) + 8192) >> 14), -65535, 65535);
        pf.px[c][s] = u;
        pf.py[c][s] = y;
        u = y;
    }
    pf.pfb[c] = clamp(y, -32767, 32767);
    u = xs + y;                                         /* (x + y) / 2 * 0.9, x 4 (>> 2 above): (x + y) * 1.8 */
    return pf_mix(x, u + mulq16(u, 52429u), pf.pw);
}
/* after FLANGER, while held or fading: PHASER (noinline, as FLANGER). The coefficients a block at a time (at its
 * middle: 2.9 ms at most, the sweep moves 1 % in frequency meanwhile) */
static __attribute__((noinline)) void perf_phaser(int32_t *bl, int32_t *br, uint32_t n,
                                                            const perf_blk_t *c)
{
    uint32_t i, ch, inc, q = perf_lfo(c, 8u, n, &inc) + (n >> 1) * inc;
    int32_t tw = c->act & PF_BIT(PF_PHS) ? perf_mod_depth(c) : 0, *const b[2] = {bl, br};
    int32_t a[2] = {ph_coef(q), ph_coef(q - 0x40000000u)};   /* (the right a quarter of the sweep behind) */
    if (!pf.pw) {                                       /* starting: the stages from rest */
        memset(pf.px, 0, sizeof pf.px);
        memset(pf.py, 0, sizeof pf.py);
        pf.pfb[0] = pf.pfb[1] = 0;
    }
    for (i = 0; i < n; i++) {
        pf.pw += clamp(tw - pf.pw, -SL_SLOPE, SL_SLOPE);
        for (ch = 0; ch < 2u; ch++)
            b[ch][i] = ph_side(ch, b[ch][i], a[ch]);
    }
}

/* the effect set changes with this sample (perf_block's split point): out of line, so the per-sample loop keeps its
 * code layout (a block placed inside it can look like a loop round the per-sample code: target_budget.py) */
static __attribute__((noinline)) void perf_split(const perf_blk_t *c, int32_t k0, uint32_t *a, int32_t *lt,
                                                 int32_t *ht)
{
    *a = c->act;
    perf_switch(c->pick);
    *lt = (int32_t)((*a & PF_BIT(PF_LPF)) || k0 < 0 || c->lc < PF_TOP) << 15;
    *ht = (int32_t)((*a & PF_BIT(PF_HPF)) || k0 > 0 || c->hc > 0) << 15;
}

/* after the master level: the buffer effect, LPF, HPF, CRUSH on l / r (stereo, Q15). c: the controls of the block it
 * processes (perf_ctl, a block late); the rest of pf is the layer's own */
static AUDIO_RAM __attribute__((noinline)) void perf_block(int32_t *bl, int32_t *br, uint32_t n, const perf_blk_t *c)
{
    uint32_t i, a = c->act0, sh, hold;
    int32_t kc = c->k[1], lt, ht, ct;
    int32_t k0 = c->k[0];                  /* the FILTER macro: a block's value (the knob glides anyway) */
    if (kc)
        pf.cc = kc;
    ct = kc ? 32768 : 0;
    sh = 4u + (uint32_t)pf.cc * 7u / 100u;
    hold = sh - 3u;
    if (c->split)
        AUDIO_FAR(perf_switch)(c->pick0);
    pf.hfb += clamp(c->k[3] * HB_FB - pf.hfb, -512, 512);   /* OCT UP / DN's shimmer glides (~40 ms) */
    perf_k4 = c->k[3];
    lt = (int32_t)((a & PF_BIT(PF_LPF)) || k0 < 0 || c->lc < PF_TOP) << 15;
    ht = (int32_t)((a & PF_BIT(PF_HPF)) || k0 > 0 || c->hc > 0) << 15;
    for (i = 0; i < n; i++) {
        int32_t l = bl[i], r = br[i];
        if (i == c->split)                /* the effect set changed with this sample: re-read the target */
            AUDIO_FAR(perf_split)(c, k0, &a, &lt, &ht);
        if (pf.mode != BM_NONE)
            perf_buf(&l, &r);
        if (lt != pf.la)                  /* settled: the clamp adds nothing */
            pf.la += clamp(lt - pf.la, -SL_SLOPE, SL_SLOPE);
        if (pf.la) {
            int32_t fl = shl(pf_svf(clamp(l >> 2, -32767, 32767), &pf.lz[0], c->lk, 0), 2);
            int32_t fr = shl(pf_svf(clamp(r >> 2, -32767, 32767), &pf.lz[2], c->lk, 0), 2);
            l = pf_mix(l, fl, pf.la);
            r = pf_mix(r, fr, pf.la);
        } else if (pf.lz[0] | pf.lz[1] | pf.lz[2] | pf.lz[3]) {
            pf.lz[0] = pf.lz[1] = pf.lz[2] = pf.lz[3] = 0;
        }
        if (ht != pf.ha)
            pf.ha += clamp(ht - pf.ha, -SL_SLOPE, SL_SLOPE);
        if (pf.ha) {
            int32_t fl = shl(pf_svf(clamp(l >> 2, -32767, 32767), &pf.hz[0], c->hk, 1), 2);
            int32_t fr = shl(pf_svf(clamp(r >> 2, -32767, 32767), &pf.hz[2], c->hk, 1), 2);
            l = pf_mix(l, fl, pf.ha);
            r = pf_mix(r, fr, pf.ha);
        } else if (pf.hz[0] | pf.hz[1] | pf.hz[2] | pf.hz[3]) {
            pf.hz[0] = pf.hz[1] = pf.hz[2] = pf.hz[3] = 0;
        }
        {   /* CRUSH: fewer bits, a held sample (KNOB 2) */
            if (ct != pf.cw)
                pf.cw += clamp(ct - pf.cw, -SL_SLOPE, SL_SLOPE);
            if (pf.cw) {
                if (++pf.cn >= hold) {
                    pf.cn = 0;
                    pf.chl = shl(l >> sh, sh) + (1 << (sh - 1u));
                    pf.chr = shl(r >> sh, sh) + (1 << (sh - 1u));
                }
                l = pf_mix(l, pf.chl, pf.cw);
                r = pf_mix(r, pf.chr, pf.cw);
            }
        }
        bl[i] = l;
        br[i] = r;
    }
    if ((c->act & PF_BIT(PF_FLG)) || pf.fw || pf.fn)
        AUDIO_FAR(perf_flanger)(bl, br, n, c);
    if ((c->act & PF_BIT(PF_PHS)) || pf.pw)
        AUDIO_FAR(perf_phaser)(bl, br, n, c);
    pf.busy = perf_layer_busy = (uint8_t)(c->act || pf.mode != BM_NONE || pf.w || pf.la || pf.ha || pf.cw || pf.fw ||
                                         pf.pw || pf.fn);
}
