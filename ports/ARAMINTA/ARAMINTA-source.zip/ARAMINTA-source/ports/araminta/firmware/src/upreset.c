/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* User presets (editor protocol v2, cmds 16-21; the SAVE > USER page): 96
 * slots in six storage.c objects (OBJ_UPRESET0/1 at 0xDC000..0xDFFFF, OBJ_UPRESET2..4
 * single-copy at 0xF5000 / 0xF6000 / 0xF7000, OBJ_UPRESET5 A/B at 0x95000 / 0x96000 in the
 * gap), 16 records each, mirrored in RAM so browsing never reads flash. A record: engine,
 * name, the instrument parameters, and 32 bytes once a 16-step pattern (reserved since SAVE >
 * PHRASES went: written zero, never read). An FM6 sound's patch is kept beside the record
 * (up_fm6.c, since 1.0.3: the record itself is unchanged). Loading one loads the sound only.
 * The format is unchanged.
 *
 * Versions: a bank whose magic, record size or slot count differ reads as
 * empty; so does a record with another layout version. A record keeps np =
 * the P_COUNT it was stored with; when that differs from today's it is
 * mapped by count: its last 8 values are P_E0..P_E7, the first np - 8 are
 * P_LEVEL.. in order, and parameters it does not have take their defaults.
 * That holds as long as common parameters are only ever added just before
 * P_E0 (else bump UP_VER and translate). Version 1 (before 1.0) has the
 * same layout; only its PHYS MODEL 2 meant DUST, which up_values loads as
 * MODAL bowed (eng_phys.c phys_legacy). A record of PHYS MODEL 4 (DRUM, version 2
 * until the kit became the DRUM engine) is that engine: up_migrate rewrites it
 * in the RAM mirror when a bank is read and when UP_PUT sends one (core.h
 * drum_from_phys); flash keeps the old record until its bank is written again,
 * which stores the new one. No version bump: today's PHYS has no MODEL 4, so
 * such a record cannot be anything else, and older firmware keeps reading the bank.
 * A record of SAMPLE SET 4 (PERC, the GM kit, retired after 1.0.2) is migrated the same way to the DRUM engine
 * with its default kit (core.h drum_from_perc: its E values the kit's, the rest of the sound and its pattern as
 * stored; the GM notes play the same drums).
 * Version 3 (UP_VER_GRID, the DRUM grid) and later records hold 32 pattern bytes: note[i] a step's lane hits
 * (bit l = lane l), flags[i] their accents (version 5), or a note pattern with 1 accent, 2 slide, 4 tie and
 * SF_RATCH in the flags. Since SAVE > PHRASES went they are reserved: up_put writes zeros and nothing reads
 * them, so older firmware that still shows them lists no pattern.
 * 1.2 (P_COUNT 103: LFO 2's SYNC TRIG POL, QUANTIZE): no version bump, records map by count as above (one of 99
 * gets the four at their defaults, which play as before); firmware before reads a record of 103 by count too (its
 * 91 parameters before P_E0 and the engine's 8: the four new ones are left out). A pattern keeps no step's NUDGE (core.h
 * SF_NUDGE: its bit 4 would read as the tie here): the step on its start.
 * SPREAD (P_SPRD, #148, before 1.2's release) made it P_COUNT 104 the same way: a record of 103 gets SPREAD 0.
 * 1.5: the INSERT (P_ITYPE .. P_IMIX), ANALOG's filter TYPE and ENV SYNC (P_FTYPE, P_ESYNC) made it 111 the same way:
 * a record of 104 gets the INSERT OFF, LP and OFF; 1.2 .. 1.4 read a record of 111 by count (the seven left out).
 * A record of engine 1 (DIGITAL, retired in 1.0, no conversion since 3.6) stays as stored and is refused on load;
 * lists show it as its silent stub (-).
 * A record of SLICE (retired) stays as stored too: every load remaps to DRUM (eng_retire.c); lists use eng_play_as.
 * SAMPLE / GRAIN / NOISE load as themselves again.
 *
 * With -DUP_HOST (host test) only the part above #ifndef UP_HOST is built;
 * it needs nothing but core.h. */
#define UP_PER_BANK 16u
#define UP_PMAX 72u                              /* room for P_COUNT to grow */
#define UP_USED 0xA5u
#define UP_VER 4u                                /* 2 since 1.0; 1 is read too (PHYS MODEL 2 was DUST) */
#define UP_VER_GRID 5u                           /* 3 with a drum grid, 5 since 1.0.4: read, never written now */
#define UP_BANK_MAGIC 0x31425055u                /* "UPB1" */
typedef struct {
    uint8_t used, ver, engine, np;               /* UP_USED, UP_VER, engine, P_COUNT when stored */
    char name[12];                               /* ASCII 32..126, 0-padded (no 0 when 12 long) */
    union { int16_t p[UP_PMAX]; uint8_t packed[UP_PMAX * 2u]; };
    uint8_t note[16], flags[16];                 /* reserved (a 16-step pattern before 4.6): written zero */
} up_rec_t;
typedef struct {
    uint32_t magic;
    uint16_t rsize, nslot;
    up_rec_t r[UP_PER_BANK];
} up_bank_t;
_Static_assert(sizeof(up_rec_t) == 192, "user preset record layout");
_Static_assert(P_COUNT <= UP_PMAX * 2u && P_COUNT < 128, "user preset record: P_COUNT");
_Static_assert(UP_SLOTS / UP_PER_BANK == 6u, "six user-preset banks");
static up_bank_t up_bank[UP_SLOTS / UP_PER_BANK] __attribute__((unused));   /* (main loop only) */

static up_rec_t *up_rec(uint32_t k) { return &up_bank[k / UP_PER_BANK].r[k % UP_PER_BANK]; }
#if FELUCCA_FLASH
/* bank index 0..5 -> storage object (OBJ_UPRESET0/1, then OBJ_UPRESET2..5 after AUTOSAVE) */
static uint32_t up_obj(uint32_t b)
{
    if (b < 2u)
        return OBJ_UPRESET0 + b;
    if (b == 2u)
        return OBJ_UPRESET2;
    if (b == 3u)
        return OBJ_UPRESET3;
    if (b == 4u)
        return OBJ_UPRESET4;
    return OBJ_UPRESET5;
}
#endif

/* 1.2 (Discussion #90): the sound's category (category.c CAT_*) in the record's last byte, packed[UP_CAT_AT]: a
 * version 4 / 5 record's values take np = P_COUNT (< 128) of its 144 bytes and nothing reads the others (up_valid
 * neither), so every record of before holds 0 there (CAT_NONE: listed by its engine, cat_of_engine) and firmware
 * before keeps the byte (a bank is written whole) without reading it: no format change, no version bump. A record of
 * versions 1..3 (a 16-bit value in every pair) has none; giving it one (a rename) rewrites it as version 4 / 5 when its
 * values fit a byte (up_to_v4; not a version 1 PHYS sound, whose MODEL 2 means DUST)
 * 3.5: bit 7 of that byte marks ANALOG's OSC A / OSC B semantics (E8 is INT; the FM slots are MORPH / DRIFT /
 * OSC B's WAVE; core.h). Older firmware ignores it. A record without it loads an ANALOG sound with the first
 * three at 0, OSC B's WAVE SAME, and drops its E8 / OP automation (up_params); 1.5's records are those.
 * 3.6: packed[UP_VIB_AT] bit 0 marks P_E5 as VIB (else VMOD; up_fm6.c fm6_old_vmod on load).
 * 4.3: its bit 1 marks LFO SYNC as ON / OFF with RATE the note value (else 1.2's note value in SYNC; core.h
 * lsync_legacy in up_params). */
#define UP_CAT_AT (UP_PMAX * 2u - 1u)
#define UP_OSC2 0x80u                            /* bit 7 of the category byte: 3.5's INT / MORPH / DRIFT */
#define UP_VIB_AT 142u                           /* (never a value byte: np <= P_COUNT < 128) */
#define UP_VIB 0x01u                             /* UP_VIB_AT bit 0: P_E5 is VIB, not the old VMOD */
#define UP_LSYNC 0x02u                           /* UP_VIB_AT bit 1: LFO SYNC ON / OFF, not the old note value */
/* matrix slots 5..8 (core.h track_t.mx): SRC DST AMT of each, one signed byte per value, at packed[UP_MX_AT..]: after
 * the values (np <= P_COUNT) and P_IORD's high byte (packed[np]), before UP_VIB_AT. Every record of before holds 0
 * there (OFF) and firmware before keeps the bytes without reading them, as with UP_CAT_AT: no version bump. A record
 * of more values (np >= UP_MX_AT, a later firmware's) has none */
#define UP_MX_AT 128u
_Static_assert(P_COUNT < UP_MX_AT && UP_MX_AT + 12u <= UP_VIB_AT, "user preset record: matrix slots 5..8");
/* value i (slot 5 + i / 3; SRC DST AMT by i % 3) of the matrix's slots 5..8 in record r, 0 when it has none */
static int32_t up_mx_value(const up_rec_t *r, uint32_t i)
{
    return r->ver >= 4u && r->np < UP_MX_AT ? (int8_t)r->packed[UP_MX_AT + i] : 0;
}
#include "category.c"
static uint32_t up_cat_of(const up_rec_t *r)
{
    uint32_t c = r->ver >= 4u && r->np <= UP_CAT_AT ? (r->packed[UP_CAT_AT] & 0x7Fu) : 0u;
    return c && c < CAT_N ? c : cat_of_engine(r->engine);
}
/* 1: the record's ANALOG OSC 2 semantics (INT / MORPH / DRIFT); older firmware wrote bit 7 0 */
static int up_osc2(const up_rec_t *r)
{
    return r->ver >= 4u && (r->packed[UP_CAT_AT] & UP_OSC2) != 0;
}
static void up_mark_osc2(up_rec_t *r) { if (r->ver >= 4u) r->packed[UP_CAT_AT] |= UP_OSC2; }
static void up_mark_vib(up_rec_t *r) { if (r->ver >= 4u) r->packed[UP_VIB_AT] |= UP_VIB; }
static void up_mark_lsync(up_rec_t *r) { if (r->ver >= 4u) r->packed[UP_VIB_AT] |= UP_LSYNC; }
static int up_lsync(const up_rec_t *r) { return r->ver >= 4u && (r->packed[UP_VIB_AT] & UP_LSYNC); }
static int up_to_v4(up_rec_t *r)                 /* 1 = r is version 4 / 5 (now) */
{
    int16_t v[UP_PMAX];
    uint32_t i;
    if (r->ver >= 4u)
        return 1;
    if (r->ver == 1u && r->engine == ENGI_PHYS)
        return 0;
    /* ver < 4: np <= UP_PMAX (72). P_IORD (96) cannot appear; its 2-byte pack is only for ver >= 4. */
    for (i = 0; i < r->np; i++)
        if ((v[i] = r->p[i]) < -64 || v[i] > 127)
            return 0;
    memset(r->packed, 0, sizeof r->packed);
    r->ver = r->ver == 3u ? UP_VER_GRID : UP_VER;
    for (i = 0; i < r->np; i++)
        r->packed[i] = (uint8_t)(uint32_t)(v[i] + 64);
    return 1;
}
static void up_set_cat(up_rec_t *r, uint32_t c)  /* c CAT_BASS..CAT_OTHER; 0 keeps the record's */
{
    if (up_to_v4(r)) {
        uint8_t old = r->packed[UP_CAT_AT];
        uint32_t keep = c && c < CAT_N ? c : (old & 0x7Fu);
        r->packed[UP_CAT_AT] = (uint8_t)((old & UP_OSC2) | keep);
    }
}

static int up_valid(const up_rec_t *r)
{
    if (!(r->used == UP_USED && r->ver >= 1u && r->ver <= UP_VER_GRID && r->engine < NENGINES &&
          /* v4 / v5: UP_CAT_AT (143) is the last index a packed record may name: the category byte
           * lives there, and a 2-byte P_IORD's high byte lives at packed[np] (up_iord2, below) */
          r->np >= 8u && r->np <= (r->ver >= 4u ? UP_CAT_AT : UP_PMAX) && r->name[0])) return 0;
    if (r->ver >= 4u)
        for (uint32_t i = 0; i < r->np; i++)
            /* P_IORD's low byte only: high byte lives at packed[np] when np > 111 (insert chain) */
            if (!(i == P_IORD && r->np > 111u) && r->packed[i] > 191u) return 0;
    return 1;
}

static int up_used(uint32_t k) { return k < UP_SLOTS && up_valid(up_rec(k)); }
/* slot k: a record with VIB (new) rather than the old VMOD (fm6_old_vmod on load) */
static int up_vib(uint32_t k) { return up_used(k) && up_rec(k)->ver >= 4u && (up_rec(k)->packed[UP_VIB_AT] & UP_VIB); }

/* Insert-chain records (np > 111): P_IORD is two bytes (low at packed[P_IORD], high at packed[np]).
 * Felucca 1.5 (np 111): index 96 is INSERT TYPE, one biased byte — same rule as project.c iord2.
 * The wire form is the same as a project's (params.c wire_val_* / wire_iord_*), which this file
 * cannot share: its host test builds upreset.c on its own, without params.c. Keep the two in step. */
static int up_iord2(const up_rec_t *r) { return r->ver >= 4u && r->np > 111u; }
static int16_t up_value(const up_rec_t *r, uint32_t k)
{
    if (up_iord2(r) && k == P_IORD) {
        /* low byte + the next byte: bits 0..9 the order, bits 10..15 the send flags.
         * Firmware that masks the high byte with 3 keeps the order and drops the flags. */
        uint32_t o = r->packed[k] | (uint32_t)r->packed[r->np] << 8;
        uint32_t perm = o & 1023u;
        if (perm > 719u)
            perm = 0u;
        return (int16_t)(uint16_t)((o & ~1023u) | perm);
    }
    return r->ver >= 4u ? (int16_t)r->packed[k] - 64 : r->p[k];
}
static void up_set_value(up_rec_t *r, uint32_t k, int16_t v)
{
    if (up_iord2(r) && k == P_IORD) {
        uint16_t raw = (uint16_t)v;
        uint32_t perm = raw & 1023u;
        if (perm > 719u)
            perm = 719u;
        raw = (uint16_t)((raw & (uint16_t)~1023u) | (uint16_t)perm);
        r->packed[k] = (uint8_t)(raw & 255u);
        r->packed[r->np] = (uint8_t)(raw >> 8);
    } else if (r->ver >= 4u)
        r->packed[k] = (uint8_t)(v + 64);
    else
        r->p[k] = v;
}
/* Legacy PHYS drums map through decoded parameters, not their disk representation. */
static void up_migrate(up_rec_t *r)
{
    int16_t e[8]; uint32_t k;
    if (!up_valid(r)) return;
    for (k = 0; k < 8u; k++) e[k] = up_value(r, r->np - 8u + k);
    if (drum_from_phys(r->engine, e) || drum_from_perc(r->engine, e)) {   /* (SAMPLE PERC: see the top) */
        r->engine = ENGI_DRUM;
        for (k = 0; k < 8u; k++) up_set_value(r, r->np - 8u + k, e[k]);
    }
}

/* after loading bank b (len bytes, -1 = none): wrong shape -> empty; each record migrated (flash or a restored
 * backup may hold anything there) */
static void up_bank_check(uint32_t b, int len)
{
    up_bank_t *bk = &up_bank[b];
    uint32_t i;
    if (len != (int)sizeof *bk || bk->magic != UP_BANK_MAGIC || bk->rsize != sizeof(up_rec_t) ||
        bk->nslot != UP_PER_BANK)
        memset(bk, 0, sizeof *bk);
    for (i = 0; i < UP_PER_BANK; i++) {
        up_rec_t *r = &bk->r[i];
        if (!up_valid(r))
            continue;
        up_migrate(r);
        memset(r->note, 0, sizeof r->note + sizeof r->flags);   /* the 32 pattern bytes: reserved */
    }
}

/* the record's values in today's P_* order (mapped by count, see above); def = the defaults */
static void up_params(const up_rec_t *r, int16_t *out, const int16_t *def)
{
    int16_t values[UP_PMAX * 2u];
    for (uint32_t i = 0; i < r->np && i < NELEM(values); i++) values[i] = up_value(r, i);
    params_by_count(out, values, r->np, def);
    ins_migrate(out, r->np);
    if (!up_osc2(r) && r->engine == ENGI_ANALOG) {   /* KTR -> INT; the FM slots were OP ENV */
        out[P_E7] = 0;
        out[P_MORPH] = 0;
        out[P_DRIFT] = 0;
        out[P_WAVE2] = 0;                            /* SAME: OSC B follows OSC A */
    }
    if (!up_lsync(r))
        lsync_legacy(out);
}

static int up_name_ok(const uint8_t *s, uint32_t n)   /* 1..12 printable ASCII */
{
    uint32_t i;
    if (!n || n > 12u)
        return 0;
    for (i = 0; i < n; i++)
        if (s[i] < 32u || s[i] > 126u)
            return 0;
    return 1;
}

static void up_name(uint32_t k, char *b)       /* upper case, 0-terminated: b holds 13 */
{
    const up_rec_t *r = up_rec(k);
    uint32_t i;
    for (i = 0; i < 12u && r->name[i]; i++)
        b[i] = r->name[i] >= 'a' && r->name[i] <= 'z' ? (char)(r->name[i] - 32) : r->name[i];
    b[i] = 0;
}

/* UP_PUT arguments: slot, engine, name, P_COUNT x v14, 16 x (note, flags) [, kind, 16 x hi [, category [, 12 x slot]]]
 * -> *r (values not yet clamped); 0 ok, 1 bad arguments. *slot gets the slot byte when there is one. kind 1 (and its 16
 * bytes): a drum grid, the pairs the low 7 bits of each step's hits and accents, hi bit 0 / 1 their bit 7 (lane 8).
 * category (1.2, category.c CAT_*, 0 none): after the kind's 16 bytes (kind 0 sends them too, ignored). 12 x slot (4.2):
 * the matrix's slots 5..8 as SRC, DST, AMT + 64 (UP_MX_AT; clamped when loaded) */
static int up_parse(const uint8_t *a, uint32_t na, up_rec_t *r, uint32_t *slot)
{
    uint32_t i, n, k, end;
    if (na < 3u)
        return 1;
    *slot = a[0];
    for (n = 0; 2u + n < na && a[2 + n]; n++)
        ;
    k = 3u + n;                                  /* after the name's 0 */
    end = k + 2u * P_COUNT + 32u;
    if (a[0] >= UP_SLOTS || a[1] >= NENGINES || 2u + n >= na || !up_name_ok(a + 2, n) ||
        (na != end && ((na != end + 17u && na != end + 18u && na != end + 30u) || a[end] > 1u)) ||
        (na >= end + 18u && a[end + 17u] >= CAT_N))
        return 1;
    up_rec_t staged, *target = r;
    r = &staged;
    memset(r, 0, sizeof *r);
    r->used = UP_USED;
    r->ver = UP_VER;
    r->engine = a[1];
    r->np = P_COUNT;
    for (i = 0; i < n; i++)
        r->name[i] = (char)a[2 + i];
    for (i = 0; na == end + 30u && i < 12u; i++)       /* the matrix's slots 5..8 */
        r->packed[UP_MX_AT + i] = (uint8_t)(int8_t)((int32_t)a[end + 18u + i] - (i % 3u == 2u ? 64 : 0));
    for (i = 0; i < P_COUNT; i++, k += 2u)
        {
            int32_t value = (int32_t)((a[k] & 127u) | (a[k + 1] & 127u) << 7) - 8192;
            if (i == P_IORD) {
                if (value < 0 || value > 719) return 1;   /* order fits the 14-bit field (0..719) */
            } else if (value < -64 || value > 127)
                return 1;
            up_set_value(r, i, (int16_t)value);
        }
    if (na >= end + 18u)                             /* (the 32 pattern bytes and the kind are ignored) */
        up_set_cat(r, a[end + 17u]);
    up_migrate(r);                               /* (an editor of before the DRUM engine) */
    up_mark_osc2(r);                             /* the editor sends today's values */
    up_mark_vib(r);
    up_mark_lsync(r);
    *target = *r;
    return 0;
}

#ifndef UP_HOST
static void up_values(const up_rec_t *r, int16_t *v)   /* mapped and clamped for its engine */
{
    int16_t def[P_COUNT];
    uint32_t i;
    for (i = 0; i < P_COUNT; i++)
        def[i] = param_desc_of(r->engine, i)->def;
    up_params(r, v, def);
    if (r->ver == 1u && ENGINES[r->engine] == &ENG_PHYS)   /* (before 1.0: MODEL 2 was DUST) */
        phys_legacy(&v[P_E0]);
    for (i = 0; i < P_COUNT; i++)
        v[i] = (int16_t)param_fit(param_desc_of(r->engine, i), v[i]);   /* (a retired KIT: the kit it plays) */
}

#include "up_fm6.c"                            /* the FM6 user presets' patches: the same kind of store */
#include "fm6_vbank.c"                         /* FM6's voice bank (SLOT B1..B32, 1.4.1) */

static void up_boot(void)                      /* persist_boot: the banks from flash */
{
#if FELUCCA_FLASH
    uint32_t b;
    for (b = 0; b < UP_SLOTS / UP_PER_BANK; b++)
        up_bank_check(b, flash_ok ? st_load(up_obj(b), &up_bank[b], sizeof up_bank[b]) : -1);
#endif
    upf_boot();                                  /* (after the banks: it may move the retired FM6 bank's patches) */
    fvb_boot();                                  /* FM6's voice bank: a staged one finished, its voices */
#ifdef FELUCCA_FAVORITES
    for (uint32_t k = 0; k < UP_SLOTS; k++)
        if (!up_used(k)) favorite_set(NENGINES, k, 0);
#endif
}

/* record k = *r (0: erase), then the bank to flash: 0 ok, 1 bad slot, 2 flash error or the transport runs (nothing
 * written), 3 no flash (kept in RAM) */
static int up_put(uint32_t k, const up_rec_t *r)
{
    up_bank_t *bk;
#if FELUCCA_FLASH
    up_rec_t old;
    uint32_t magic;
    uint16_t rsize, nslot;
#endif
    if (k >= UP_SLOTS)
        return 1;
    if (transport_busy()) {                            /* no flash erase while playing (project_save) */
        ui_message("STOP TO SAVE");
        return 2;
    }
    bk = &up_bank[k / UP_PER_BANK];
#if FELUCCA_FLASH
    old = *up_rec(k);
    magic = bk->magic;
    rsize = bk->rsize;
    nslot = bk->nslot;
#endif
    bk->magic = UP_BANK_MAGIC;
    bk->rsize = sizeof(up_rec_t);
    bk->nslot = UP_PER_BANK;
    if (r) {
        *up_rec(k) = *r;
        memset(up_rec(k)->note, 0, sizeof up_rec(k)->note + sizeof up_rec(k)->flags);   /* reserved */
    } else
        memset(up_rec(k), 0, sizeof(up_rec_t));
#if FELUCCA_FLASH
    if (flash_ok && st_save(up_obj(k / UP_PER_BANK), bk, sizeof *bk)) {
        *up_rec(k) = old;
        bk->magic = magic;
        bk->rsize = rsize;
        bk->nslot = nslot;
        return 2;
    }
#endif
    if (!r) {
#ifdef FELUCCA_FAVORITES
        if (favorite_set(NENGINES, k, 0)) settings_save();
#endif
        uint32_t i;
        for (i = 0; i < NTRK; i++)
            if (trk[i].user == k + 1u)
                trk[i].user = 0;
        if (upf_bit(k)) {                              /* reclaim the FM6 patch entry for another preset */
            upf_clear(k);
            upf_save();
        }
    } else if (r->engine != ENGI_FM6 && upf_bit(k)) {
        upf_clear(k);
        upf_save();
    }
    up_gen++;
#if FELUCCA_FLASH
    if (flash_ok)
        return 0;
#endif
    return 3;
}

static void up_slot_label(char *b, uint32_t k)  /* "U07" */
{
    b[0] = 'U';
    b[1] = (char)('0' + (k + 1u) / 10u);
    b[2] = (char)('0' + (k + 1u) % 10u);
    b[3] = 0;
}

/* the automatic name of engine e's sound in slot k: engine name + slot number ("ANALOG 07"); b holds 13 */
static void up_auto_name(char *b, uint32_t e, uint32_t k)
{
    char l[4];
    e %= NENGINES;
    str_cpy(b, ENGINES[eng_play_as(e)]->name, 9);   /* (retired / DIGITAL: the engine it plays as) */
    up_slot_label(l, k);
    str_cpy(b + str_len(b), " ", 2);
    str_cpy(b + str_len(b), l + 1, 3);
}

/* the record's name = name (at most 12), 0 or "": the automatic one */
static void up_set_name(up_rec_t *r, uint32_t k, const char *name)
{
    char b[16];
    uint32_t i;
    if (!name || !name[0]) {
        up_auto_name(b, r->engine, k);
        name = b;
    }
    memset(r->name, 0, sizeof r->name);
    for (i = 0; i < 12u && name[i]; i++)
        r->name[i] = name[i];
}

static uint32_t up_cat(uint32_t k) { return up_cat_of(up_rec(k % UP_SLOTS)); }   /* a used slot's category */
static uint32_t track_cat(const track_t *t);     /* (ui.c: the category of the sound a track plays) */

/* the selected part's sound -> slot k; name 0 or "": the automatic name (up_auto_name); cat its category (CAT_*), 0:
 * the one of the sound it came from (track_cat); up_put's result */
static int up_store_cat(uint32_t k, const char *name, uint32_t cat)
{
    up_rec_t r;
    uint32_t i;
    memset(&r, 0, sizeof r);
    r.used = UP_USED;
    r.ver = UP_VER;
    r.engine = TSEL->eng_req;
    r.np = P_COUNT;
    up_set_name(&r, k, name);
    for (i = 0; i < P_COUNT; i++) {
        int16_t v = motion_base_value(TSEL, i);
        if (i == P_QUANT && v == QN_CURR)
            v = QN_ALL;                                 /* a preset carries no link bit: CURR saves as ALL */
        up_set_value(&r, i, v);
    }
    up_set_cat(&r, cat ? cat : track_cat(TSEL));
    for (i = 0; i < 12u; i++)                           /* matrix slots 5..8 */
        r.packed[UP_MX_AT + i] = (uint8_t)(int8_t)TSEL->mx[i / 3u][i % 3u];
    up_mark_osc2(&r);                                   /* a new sound: INT / MORPH / DRIFT as stored */
    up_mark_vib(&r);                                    /* P_E5 is VIB */
    up_mark_lsync(&r);                                  /* LFO SYNC ON / OFF */
    {
        int rc;
        if (r.engine == ENGI_FM6 && !upf_room(k))       /* fail before the record: no silent success without a patch */
            return 2;
        rc = up_put(k, &r);                             /* the record first, then its FM6 patch (up_fm6.c) */
        if ((rc == 0 || rc == 3) && r.engine == ENGI_FM6) {
            int u = upf_store(k, (uint32_t)(TSEL - trk));
            if (u == 2)
                rc = 2;
        }
        return rc;
    }
}

static int up_store(uint32_t k, const char *name) { return up_store_cat(k, name, 0); }

/* slot k renamed (name 0 or "": the automatic one) and given category cat (0: kept), the sound as it is;
 * up_put's result, 1 for an empty slot */
static int up_rename_cat(uint32_t k, const char *name, uint32_t cat)
{
    up_rec_t r;
    if (!up_used(k))
        return 1;
    r = *up_rec(k);
    up_set_name(&r, k, name);
    up_set_cat(&r, cat);
    return up_put(k, &r);
}
static int up_rename(uint32_t k, const char *name) { return up_rename_cat(k, name, 0); }

/* matrix slots 5..8 of record r into t->mx (UP_MX_AT; OFF when r has none), clamped as slots 1..4 */
static void up_mx_load(const up_rec_t *r, track_t *t)
{
    uint32_t i;
    for (i = 0; i < 12u; i++)
        t->mx[i / 3u][i % 3u] = mod_fit(i % 3u, up_mx_value(r, i));
}

/* slot k -> the selected part's sound: engine and every parameter except the track's own (param_kept:
 * the mix, ARP, SCL, the sequence parameters, the SLICER). The steps stay. 0 ok, 1 empty */
static int up_load(uint32_t k)
{
    const up_rec_t *r;
    int16_t v[P_COUNT];
    uint32_t i;
    track_t *t = TSEL;
    if (!up_used(k))
        return 1;
    r = up_rec(k);
    up_values(r, v);
    if (v[P_QUANT] == QN_CURR)
        v[P_QUANT] = QN_ALL;                            /* no link bit in a preset: CURR loads as ALL */
    if (r->engine == ENGI_DIGITAL)                      /* DIGITAL (retired): no conversion, refused */
        return 1;
    load_begin(t, UNDO_SOUND);                          /* (ui.c: the copy for SAVE held = undo) */
    panic_req |= (uint8_t)(1u << song.sel);
    if (eng_retired(r->engine)) {                       /* SLICE / DRUMS: DRUM-X */
        int16_t p[P_COUNT];
        uint32_t to;
        for (i = 0; i < P_COUNT; i++)
            p[i] = param_kept(i) ? t->p[i] : v[i];
        to = retire_remap_params(r->engine, p);
        fm1_irq_off();
        t->eng_req = (uint8_t)to;
        memcpy(t->p, p, sizeof t->p);
        up_mx_load(r, t);
        t->preset = 0;
        if (r->engine == ENGI_DRUMS && !drum_elsewhere(t)) {
            int16_t ln[8];
            drums_kit((uint32_t)clamp(v[P_E0], 0, 8), dx_kit, dx_lay, dx_mdl, ln);
            for (i = 0; i < 8u; i++)
                t->p[P_LN0 + i] = (int16_t)(t->p[P_LN0 + i] * ln[i] / 127);
            undo.what |= UNDO_KIT;
        }
        fm1_irq_on();
    } else {
        fm1_irq_off();                                  /* the audio ISR must not see half a sound */
        t->eng_req = r->engine;
        for (i = 0; i < P_COUNT; i++)
            if (!param_kept(i))
                t->p[i] = v[i];
        up_mx_load(r, t);
        t->preset = 0;
        fm1_irq_on();
        upf_track_load(t, k);                           /* FM6: the preset's own patch (up_fm6.c) */
    }
    t->user = (uint8_t)(k + 1u);
    load_end(t);
    sync_reload = 1;
    ui.force = 1;
    return 0;
}

/* the engine a used slot's sound plays on (a retired record: its stub or DRUM) */
static uint32_t up_engine(uint32_t k) { return eng_play_as(up_rec(k)->engine); }

static uint32_t up_count(void)                 /* used slots */
{
    uint32_t k, n = 0;
    for (k = 0; k < UP_SLOTS; k++)
        n += (uint32_t)up_used(k);
    return n;
}

static uint32_t up_nth(uint32_t n)             /* slot of the n-th used one (n < up_count()) */
{
    uint32_t k;
    for (k = 0; k < UP_SLOTS; k++)
        if (up_used(k) && !n--)
            return k;
    return 0;
}

static uint32_t up_rank(uint32_t slot)         /* used slots before it */
{
    uint32_t k, n = 0;
    for (k = 0; k < slot && k < UP_SLOTS; k++)
        n += (uint32_t)up_used(k);
    return n;
}

/* SAVE > USER page actions, with the message in the top bar. name: the save's or the rename's (0 or "": automatic);
 * cat: its category (0: the sound's, a rename keeps it) */
static void up_ui_named(uint32_t op, uint32_t k, const char *name, uint32_t cat)   /* 0 load, 1 erase, 2 save, 3 rename */
{
    char l[4];
    int rc;
    up_slot_label(l, k);
    if ((op < 2u || op == 3u) && !up_used(k)) {
        ui_message("EMPTY SLOT");
        return;
    }
    if (op && (song.playing || chain_busy() || transport_req == 1u)) {    /* (up_put refuses too) */
        ui_message("STOP TO SAVE");
        return;
    }
    if (op == 0u) {
        up_load(k);
        ui_say("LOADED ", l);
        return;
    }
    rc = op == 1u ? up_put(k, 0) : op == 3u ? up_rename_cat(k, name, cat) : up_store_cat(k, name, cat);
    if (rc == 3)
        ui_message(op == 1u ? "ERASED (RAM)" : op == 3u ? "RENAMED (RAM)" : "SAVED (RAM)");
    else if (rc)
        ui_message(op == 1u ? "ERASE ERROR" : "SAVE ERROR");
    else
        ui_say(op == 1u ? "ERASED " : op == 3u ? "RENAMED " : "SAVED ", l);
    ui.force = 1;
}
static void up_ui(uint32_t op, uint32_t k) { up_ui_named(op, k, 0, 0); }
#endif
