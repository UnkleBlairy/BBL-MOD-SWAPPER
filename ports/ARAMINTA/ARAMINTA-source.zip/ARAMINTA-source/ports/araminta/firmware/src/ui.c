/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* FELUCCA user interface.
 * Flat: no raised SURF (SURF = BG on every palette), no rule dividers, one type family (Terminus, three sizes), tracks
 * named by their numbers 1..4 on a cushion (icons.c trk_icon). Four columns <-> KNOB 1..4. Rendering is lazy:
 * every element remembers what it last drew and is redrawn only on change. */
static int project_save(uint32_t slot);
static void panel_setup(void);
static void project_load(uint32_t slot);
static int project_used(uint32_t slot);
static uint32_t chain_prepare(void);
static int up_used(uint32_t k);              /* user presets: upreset.c */
static int up_load(uint32_t k);
static uint32_t up_count(void);
static uint32_t up_nth(uint32_t n);
static uint32_t up_rank(uint32_t slot);
static uint32_t up_engine(uint32_t k);
static void up_name(uint32_t k, char *b);
static void up_slot_label(char *b, uint32_t k);
static void up_ui(uint32_t op, uint32_t k);
static void up_auto_name(char *b, uint32_t e, uint32_t k);   /* naming (ui_name.c) */
static void up_ui_named(uint32_t op, uint32_t k, const char *name, uint32_t cat);
static uint32_t up_cat(uint32_t k);
static int project_save_as(uint32_t slot, const char *name);
static int project_name(uint32_t slot, char *b);
static int project_info(uint32_t slot, char *b, uint16_t *len48, uint32_t *den, uint8_t *n);
static int project_rename(uint32_t slot, const char *name);
static void project_cur_name(char *b);
static uint32_t user_of(const track_t *t)    /* user preset slot its sound came from, UP_SLOTS = none */
{
    return t->user && up_used(t->user - 1u) ? t->user - 1u : UP_SLOTS;
}
static uint32_t up_gen;                      /* bumped on every user bank change (redraws) */
#include "favorites.c"
#include "category.c"                   /* sound categories (Discussion #90): PRESETS > LIST */
/* MENU's two-valued settings (ui_menu.c MENU_FLAGS), a bit each in a byte no engine uses (as ui_layer.c layer_seen):
 * saved with the settings; 0 in older ones = every setting's default (append-only: a new setting takes a new bit,
 * its default is 0) */
#define ui_prefs (favorites.factory[15][30])
#define PREF_LATCH 1u                          /* MENU > FX LATCH ON (#40) */
#define PREF_ANIM_OFF 2u                       /* ANIM retired: always set (no rolling digits, glide, LED sweep) */
#define PREF_ACCEL 4u                          /* retired: KNOB ACCEL always on (#52); bit unused */
#define PREF_USB_FIXED 8u                      /* MENU > USB LEVEL FIXED: USB audio at the full level, MASTER after */
#define PREF_BPM_LOCK 16u                      /* MENU > BPM LOCK ON: lock icon by the BPM (tempo is GLO+SELECT / CLOCK) */
#define PREF_LARGE 32u                         /* MENU > LARGE ON (#15, Discussion #80): big knob labels and values
                                                * (ui_draw.c large_kind); clear in every older setting = OFF */
#define PREF_SERIAL_OFF 64u                    /* MENU > USB SERIAL OFF (#67): no serial console, the device enumerates as
                                                * audio + MIDI only (usb.c usb_cdc_switch); clear in every older setting = ON */
#define PREF_RESTORE_OFF 128u                  /* MENU > BOOT RESTORE OFF (was RESTORE LAST; 1.2, Discussion #130):
                                                * no restore at power-on (project.c). Autosave still writes. Clear in
                                                * every older setting = ON */
#define fx_latch ui_prefs
/* MENU > AUDIO CLICK, CLICK LEVEL, COUNT-IN (1.1, Discussion #131; click.c, seq.c): two bits each in another byte no
 * engine uses, saved with the settings: bits 0-1 CLICK (OFF REC ON), 2-3 CLICK LEVEL (stored 0 MID, 1 LOW, 2 HIGH),
 * 4-5 COUNT-IN (OFF, 1 BAR, 2 BARS); 0 in older settings = OFF / MID / OFF, so nothing clicks or counts in that did
 * not; 3 (unknown) reads as 0 (settings_persist.c puts it back). Bit 6 (1.2): MENU > SCALE LEDS ON (Discussion #127,
 * ui_input.c scale_leds; 0 in older settings = OFF). Bit 7 free (append-only) */
#define ui_rec_prefs (favorites.factory[15][28])
#define PREF_REC 0xFF00u                       /* (menu_items.c MENU_FLAGS: a bit of ui_rec_prefs, << 8) */
#define PREF_SCALE_LEDS (0x40u << 8)
/* 1.2: three more two-valued MENU settings, bits of another byte no engine uses, saved with the settings; 0 in older
 * settings = today's behaviour (append-only, as ui_prefs): bit 0 DISPLAY > SCOPE MIX (Discussion #165, fx.c scope_mix),
 * bit 1 CONTROL > STEP PREVIEW ON (Discussion #169, ui_input.c step_preview), bit 2 CONTROL > CHORD ENTRY ADD (#155,
 * ui_input.c seq_entry). 1.5: bit 3 retired (HELP; kept for the editor's id). Bits 4-7 free */
#define ui_prefs2 (favorites.factory[15][24])
#define PREF_X 0xFF0000u                       /* (menu_items.c MENU_FLAGS: a bit of ui_prefs2, << 16) */
#define PREF_SCOPE_MIX (0x01u << 16)
#define PREF_PREVIEW (0x02u << 16)
#define PREF_CHORD_ADD (0x04u << 16)
#define PREF_HELP (0x08u << 16)               /* retired: HELP's bit, kept for the editor's id 24 */
/* 1.3 (Discussions #112, #134): MENU > DISPLAY > HOME, what the HOME page shows under its four cards: 0 SCOPE (the
 * oscilloscope, as before), 1 TRACKS (the four tracks as rows: ui_graph.c draw_home_tracks), 2 LEVELS (1.5, #134: the
 * rows of TRACKS, and KNOB 1..4 the LEVEL of T1..T4 in place of the engine's four: home_param). A byte of its own no
 * engine uses, saved with the settings; 0 in older settings = SCOPE; an unknown value (a later firmware's view) reads as
 * SCOPE and is kept as saved (1.3 / 1.4 read LEVELS so) */
#define ui_home_view (favorites.factory[15][26])
enum { HV_SCOPE, HV_TRACKS, HV_LEVELS, HV_COUNT };
static int home_tracks(void) { return ui_home_view == HV_TRACKS || ui_home_view == HV_LEVELS; }
static int home_levels(void) { return ui_home_view == HV_LEVELS; }
enum { RP_CLICK, RP_LEVEL, RP_COUNTIN };
static uint32_t rp_get(uint32_t f)                     /* a field as the MENU steps it: 0..2 */
{
    uint32_t v = (ui_rec_prefs >> (2u * f)) & 3u;
    v = v == 3u ? 0u : v;
    return f == RP_LEVEL ? (v == 0u ? 1u : v == 1u ? 0u : 2u) : v;   /* (LEVEL: LOW MID HIGH, MID stored as 0) */
}
static void rp_apply(void)                             /* the settings into click.c / seq.c (every frame: ui_input) */
{
    click_mode = (uint8_t)rp_get(RP_CLICK);
    click_lvl = (uint8_t)rp_get(RP_LEVEL);
    cin_bars = (uint8_t)rp_get(RP_COUNTIN);
}
static void rp_put(uint32_t f, uint32_t v)
{
    uint32_t st = f == RP_LEVEL ? (v == 1u ? 0u : v == 0u ? 1u : 2u) : v % 3u;
    ui_rec_prefs = (uint8_t)((ui_rec_prefs & ~(3u << (2u * f))) | st << (2u * f));
    rp_apply();
}
/* STYLE retired: always FLAT (ui_draw.c style_apply). Byte kept in the settings record; LINE / PIXEL ignored */
#define ui_style (favorites.factory[15][29])
static void draw_gaps(uint32_t y, uint32_t h);        /* (ui_draw.c) */

static uint8_t sync_reload;                  /* engine / preset / project / user preset loaded: editor RELOAD push */

#define ACC T_THEME                /* values, curves */
#define VAL(c) ((c) == ui.hot_col && ui.hot_t ? T_ACCENT : T_THEME)   /* the knob just turned: accent */
#define RATIO(d, v) ((d)->max > (d)->min ? ((int32_t)(v) - (d)->min) * 1000 / ((d)->max - (d)->min) : -1)
/* layout: header 0..24, four cards 28..72 (57 px at x 3 + 59 c),
 * the panel 76..198 (a SURF area; the graphs live in it), footer 202..240; BG between them */
#define Y_HEAD 0
#define H_HEAD 24
#define Y_LABEL 28                    /* the cards */
#define Y_SEP_END 72
#define CARD_W 57
#define CARD_H 44
#define CARD_X(c) (3 + 59 * (int32_t)(c))
#define Y_GRAPH 76                    /* the panel */
#define H_GRAPH 122
#define Y_FOOT 202
#define H_FOOT 38
/* MENU > LARGE (large_kind below): on the value pages the cards are tall (28..132) and the panel a strip
 * (136..198); elsewhere (lists, rolls, layers) the compact layout (card labels in M when they fit) */
#define LG_CARD_H 104
#define LG_Y_GRAPH 136
#define LG_H_GRAPH 62

static struct {
    uint8_t home;
    uint8_t page;                /* index into PAGES */
    uint8_t fam_last[FAM_COUNT]; /* last page per family (layer NV snapshot; re-enter uses page_first) */
    uint8_t bank;                /* SEQ: 16-step bank (follows the cursor) */
    uint8_t cursor;              /* SEQ: step being edited (STEP page KNOB 1 moves it) */
    uint8_t seq_follow_t;        /* SEQ follow pause: frames until cursor snaps to seq_idx again (0 = follow) */
    uint8_t entry_open;          /* SEQ: keys held since the first press of this entry */
    uint8_t lane;                /* SEQ > STEP on a DRUM track (the grid): the lane the keys and KNOB 3 / 4 edit */
    uint8_t plk_src;             /* parameter locks (ui_input.c lock_*): the sound page whose KNOB 1..4 a step held
                                  * locks, PAGES index + 1; 0 = HOME's four */
    uint8_t plk_lane, plk_trk;   /* .. the grid: the lane and the track of the hits plk_rm takes away */
    uint64_t plk_rm, plk_acc;    /* .. the grid's step keys pressed on a hit (bit = step): it goes when the key is let
                                  * go, unless the key was held for a lock (its accent: plk_acc) */
    uint8_t hot_col, hot_t;      /* column whose knob was just turned (drawn white) */
    uint8_t ior_sel;             /* EFFECTS page: highlighted list slot 0..FX_LIST_N-1 */
    uint8_t menu;                /* 0 off, 1 list, 2 about + credits, 3 info (1.2) (HOME held) */
    uint8_t menu_sel;            /* MENU: the row (menu_items.c MI_*; its tab MI_TAB), kept while the device runs */
    uint8_t menu_row[5];         /* MENU: the row last picked in each tab, from its first (SELECT comes back to it) */
    uint16_t menu_scroll;        /* continuous ABOUT + CREDITS position, pixels */
    uint32_t menu_sig, home_t0;  /* HOME press time (btn_hold) */
    uint8_t force;               /* full redraw pending */
    uint8_t msg_t;               /* transient message frames */
    uint8_t bpm_t;               /* frames the BPM stays highlighted after a SELECT turn */
    uint8_t act;                 /* action pages: the column whose action OCT+ does, + 1; 0 = none (act_col) */
    uint32_t rec_t0;             /* REC press time: a tap arms (btn_hold, no hold: held, REC opens its layer) */
    uint32_t save_t0;           /* SAVE press time (btn_hold: held = UNDO) */
    uint8_t confirm;             /* the OCT- / OCT+ dialog: CF_*, 0 = none */
    uint8_t confirm_trk;         /* the track it clears, the slot it overwrites */
    uint8_t uslot;               /* SAVE > USER: the selected user preset slot */
    uint8_t song_row;            /* SONG: the section selected, count selects + ADD */
    uint8_t song_trk;            /* SONG: the lane (track) selected, 0..NTRK-1 */
    uint16_t ev_row;             /* SEQ > AUTOMATION (ui_events.c ev_*): the row selected (0 QUANTIZE, 1 ENABLED / CLEAR, the
                                  * last + ADD; 1.2: up to EV_ROWS, past 255) */
    uint8_t ev_step, ev_id;      /* .. + ADD: the step and the parameter (or EV_CHANCE, EV_RATCH, EV_NUDGE, EV_VEL) it
                                  * adds on */
    uint16_t ev_keep;            /* .. the CHANCE / RATCH / NUDGE row being edited (its EVC code, 0 none): listed at its default */
    uint8_t ev_vel;              /* .. 1.5: the VEL rows shown (+ ADD VEL's SHOW / HIDE; off when the page is entered) */
    uint8_t pick;                /* #223: flat full-screen param / dest list (PK_*), 0 = off */
    uint8_t uboot;               /* main.c: seconds left before UPDATE MODE (OCT- + OCT+ held), 0 = none */
    uint32_t ly_t0;              /* the layer button's press time | 1, LY_* bits (ui_layer.c layer_gesture) */
    uint8_t ly;                  /* the layer whose button is down (LAYER_*), 0 = none */
    uint8_t layer;               /* the layer whose map is shown (LAYER_*), 0 = none */
    uint8_t lock;                /* #83: the layer locked open by a double tap (LAYER_*), 0 = none (ui_layer.c) */
    uint16_t pg_down;            /* page buttons down (panel ids) that act when let go */
    uint32_t layer_sig;          /* drawn-state cache of the map */
    char msg[24];
    char msg2[24];               /* a second message, shown when the first is over */
    uint32_t enc_t[NE];
    /* drawn-state cache */
    char col[4][32];
    uint32_t graph_sig, head_sig, foot_sig, frame;
    /* rolling digits (ui_draw.c roll_*): the four card values and the header BPM */
    struct {
        char from[7];            /* the value rolling out; "" = idle */
        uint8_t t0;              /* (ui.frame) of the value's last change */
        int8_t dir;              /* +1: it went up (the old digit leaves upward), -1: down */
        uint8_t sig;             /* a card: what its value is of (label, unit, track, engine, palette) */
    } roll[5];
    int16_t roll_bpm;            /* the BPM last drawn */
    volatile uint8_t mpc[NTRK];  /* MIDI Program Change per track, 0x80 | program, 0 none (midi_control.c mpc_io: here
                                  * so the audio ISR's data keeps its layout and its cost, tests/target_budget.py;
                                  * midi_pc_poll) */
    volatile int8_t cc_step[7];  /* CC 71..77's detents since the main loop last read them (midi_control.c cc_step:
                                  * the page's four knobs, then SELECT / ALGORITHM / PRESETS; cc_knob_poll) */
} ui;

enum { CF_NONE, CF_CLEAR_SEQ, CF_CLEAR_TRK, CF_OVR_PROJ, CF_OVR_USER,
       CF_DEL_ROW, CF_CLEAR_SONG, CF_INIT_SOUND, CF_CLEAR_MOTION, CF_ERASE_USER,
       CF_CLEAR_ALL_SEQ, CF_INIT_ALL_SOUND, CF_CLEAR_ALL_MOTION,
       CF_CLEAR_TRACK_ALL, CF_CLEAR_EVERY_TRACK_ALL, CF_CLEAR_FX, CF_CLEAR_ALL_FX, CF_CLEAR_LANE };
                                   /* ui.confirm: CLEAR map; SAVE over a used slot; a pattern over the user's steps;
                                    * USER ERASE */

/* MENU > DISPLAY > SCREEN OFF (1.1.5): after a while with no input on the panel the screen goes dark (the backlight
 * stays on: lcd.c lcd_power)
 * (a picture held for hours can stay faintly on the panel); the sound, the sequencer, MIDI and USB go on, the LEDs
 * stay as they are. NEVER (the default since 1.1.5.1), 5, 15, 30, 60 minutes, kept in a byte no engine uses, saved
 * with the settings (SCR_CODE). 1.1.5 stored value ^ 3, 0 (its default and every older setting) being 30 MIN; 1.1.5.1
 * reads that 0 as NEVER (the new default: the panel went dark for good on 1.1.5, see lcd.c lcd_power) and keeps the
 * other codes, 30 MIN now 4. Unknown codes read as NEVER.
 * Input is the panel's only: a button or key held or pressed, a knob turned (not MIDI, the editor or MASTER, an
 * analogue pot). The press, key or turn that wakes it is swallowed: no note (seq.c kb_asleep), no button, no
 * value, until everything is let go and the knobs rest for SCR_EAT_MS. A dialog, the count-in and the UPDATE MODE
 * countdown keep it on (and wake it); the crash screen, UPDATE and UBOOT wake it at once (lcd_wake_now).
 * Off: lcd_power(0) (DISPOFF, SLPIN) and nothing is drawn. Waking, a frame at a time (never a wait in
 * the loop): 120 ms after the SLPIN, SLPOUT (lcd_power(1)); 120 ms after that one frame redraws everything
 * (ui.force), then DISPON (lcd_power(2)) */
#define ui_scr (favorites.factory[15][27])
/* MENU > ANIM IDLE (1.2, Discussion #135; menu_items.c, ui_input.c idle_leds): bit 0, the LEDs' idle animation, in a
 * byte no engine uses, kept with the settings; 0 in every older setting = off. The other bits: 0 (room for a delay) */
#define ui_idle (favorites.factory[15][10])
#define SCR_DEF 0u                                     /* NEVER (1.1.5.1; 1.1.5: 30 MIN) */
static const uint8_t SCR_CODE[5] = {0, 2, 1, 4, 7};    /* the stored byte of NEVER 5 15 30 60 MIN (1.1.5: 3 2 1 0 7) */
static const uint8_t SCR_DEC[8] = {0, 2, 1, 0, 3, 0, 0, 4};   /* .. and back (3: 1.1.5's NEVER; 5, 6 unknown) */
#define SCR_EAT_MS 300u
static const uint8_t SCR_MIN[5] = {0, 5, 15, 30, 60};  /* NEVER, minutes */
enum { SCR_ON, SCR_OFF, SCR_WAKE, SCR_SLPOUT, SCR_SHOW };
static struct {
    uint8_t st;                  /* SCR_*: SCR_WAKE asked, SCR_SLPOUT sent, SCR_SHOW the frame that redraws */
    uint8_t eat;                 /* the wake gesture: panel input swallowed (ui_input) */
    uint32_t idle;               /* fm1_ms of the last panel input (or blocker) */
    uint32_t t;                  /* fm1_ms of the last panel command (SLPIN, SLPOUT) */
    uint32_t eat_t;              /* fm1_ms of the last swallowed knob detent */
} scrn;
static uint32_t scr_get(void)                          /* the MENU's value: 0 NEVER .. 4 60 MIN */
{
    return ui_scr < NELEM(SCR_DEC) ? SCR_DEC[ui_scr] : SCR_DEF;
}
static void scr_put(uint32_t v)                        /* (the time counts from the change: the editor's too) */
{
    ui_scr = SCR_CODE[v < NELEM(SCR_MIN) ? v : SCR_DEF];
    scrn.idle = fm1_ms;
}
static void scr_wake(void)
{
    if (scrn.st == SCR_OFF)
        scrn.st = SCR_WAKE;
    scrn.eat = 1;
}
static void scr_wake_now(void)                         /* main.c: the crash screen, UPDATE, UBOOT */
{
    if (scrn.st != SCR_ON)
        lcd_wake_now();
    scrn.st = SCR_ON;
    scrn.idle = fm1_ms;
}
/* ui_input, every pass: 1 = the pass is swallowed (the screen dark or waking, or the wake gesture going on) */
static int scr_input(uint32_t pressed, uint32_t notes)
{
    uint32_t held = fm1_in.buttons | fm1_in.notes, k;
    int32_t moved = 0;
    if (pressed | notes | held | panel_moved)
        scrn.idle = fm1_ms;
    panel_moved = 0;
    if (scrn.st == SCR_ON && !scrn.eat)
        return 0;
    for (k = 0; k < NE; k++)                           /* (every knob's turns go) */
        moved |= panel_enc(k);
    panel_moved = 0;
    if (moved)
        scrn.eat_t = scrn.idle = fm1_ms;
    if (pressed | notes | held | (uint32_t)moved)
        scr_wake();
    if (scrn.st != SCR_ON || held || (int32_t)(fm1_ms - scrn.eat_t) < (int32_t)SCR_EAT_MS)
        return 1;
    scrn.eat = 0;                                       /* all let go, the knobs at rest: input again */
    kb_asleep = 0;
    return 0;
}
/* ui_draw, every frame: 1 = draw it */
static int scr_frame(void)
{
    uint32_t lim = SCR_MIN[scr_get()] * 60000u;
    if (ui.confirm || ui.uboot || seq_counting()) {    /* (never dark under these) */
        scrn.idle = fm1_ms;
        if (scrn.st == SCR_OFF)
            scr_wake();
    }
    switch (scrn.st) {
    case SCR_ON:
        if (!lim || (int32_t)(fm1_ms - scrn.idle) < (int32_t)lim)   /* (signed: robust to a wrap) */
            return 1;
        lcd_power(0);
        scrn.st = SCR_OFF;
        scrn.t = fm1_ms;
        scrn.eat = 1;
        kb_asleep = 1;
        break;
    case SCR_WAKE:
        if (fm1_ms - scrn.t >= 120u) {
            lcd_power(1);
            scrn.st = SCR_SLPOUT;
            scrn.t = fm1_ms;
        }
        break;
    case SCR_SLPOUT:
        if (fm1_ms - scrn.t >= 120u) {
            scrn.st = SCR_SHOW;
            ui.force = 1;
            return 1;
        }
        break;
    case SCR_SHOW:
        return 1;
    }
    ui.msg_t = 0;                                      /* (dark: what would have shown is over; a clean page back) */
    ui.msg2[0] = 0;
    ui.hot_t = ui.bpm_t = 0;
    return 0;
}
static void scr_shown(void)                            /* after the frame: the redrawn page on */
{
    if (scrn.st != SCR_SHOW)
        return;
    lcd_power(2);
    scrn.st = SCR_ON;
    scrn.idle = fm1_ms;
}

static const page_t *page_over;   /* a quick layer's own four knobs (ui_layer.c), while it edits or draws them */
static const page_t *cur_page(void) { return page_over ? page_over : &PAGES[ui.page]; }
#include "generation.c"                      /* original Grids rhythm map; the UI writes normal steps */
static const char *const GENERATION_MAP_LABELS[4] = {"MAP", "MAP X", "MAP Y", "CHAOS"};
static int generation_page2(void) { return str_eq(cur_page()->title, "GENERATION 2"); }
static int generation_map_on(void)
{
    return !ui.home && !ui.layer && cur_page()->graph == GR_GENERATION && generation_page2() && ui.hot_t && ui.hot_col < 3u;
}

/* MENU > LARGE (#15, Discussion #80: what KNOB 1..4 do, in bigger type). Per page type:
 *   LK_TALL  HOME and the value pages (EDIT ENV LFO MOD FX SLICER SCL CHORD ARP VOICE, MIXER, CLOCK,
 *            TOOLS): tall cards (a K1..K4 keycap, the icon, the label in M, the value in L,
 *            in M or S when L is too wide or lacks a glyph, the unit under it, the gauge), the panel a strip: HOME's
 *            scope, ENV's ADSR, LFO's wave, MIXER's four tracks (name, state, meter) small; the
 *            page's title and number in L on the others (their charts cannot be read that small);
 *   LK_LABEL the list and graph pages (PRESETS, USER, PROJECT, SONG, the piano roll and the drum grid,
 *            AUTOMATION, SLICES), HOME with MENU > HOME TRACKS (1.3) and the quick layers' maps: the layout as it
 *            is (card labels are M on every compact card when they fit; draw_column);
 *   LK_OFF   LARGE off; the menu (its own LARGE: ui_menu.c), the dialogs and NAME keep their own layout in every case. */
enum { LK_OFF, LK_LABEL, LK_TALL };
static uint32_t large_kind(void)
{
    uint32_t g;
    if (!(ui_prefs & PREF_LARGE))
        return LK_OFF;
    if (ui.layer)
        return LK_LABEL;
    if (ui.home)                                        /* (HOME > TRACKS: its rows need the panel, the cards as on */
        return home_tracks() ? LK_LABEL : LK_TALL;      /* a list page; the rows' names in M: draw_home_tracks) */
    g = cur_page()->graph;
    return g == GR_BROWSE || g == GR_SLOTS || g == GR_USER || g == GR_SONG || g == GR_ROLL ||
           g == GR_EVENTS || g == GR_GENERATION || (ui.pick && g == GR_MOD) ? LK_LABEL : LK_TALL;
}
/* the geometry of the page shown: the cards' height, the panel's top and height */
static uint32_t card_h(void) { return large_kind() == LK_TALL ? LG_CARD_H : CARD_H; }
static uint32_t graph_y(void) { return large_kind() == LK_TALL ? LG_Y_GRAPH : Y_GRAPH; }
static uint32_t graph_h(void) { return large_kind() == LK_TALL ? LG_H_GRAPH : H_GRAPH; }
static int large_face_has(const char *s)                /* every glyph of s in the sparse L face */
{
    for (; *s; s++)
        if (glyph_at(&AF_L, fold(&AF_L, (uint8_t)*s)) < 0)
            return 0;
    return 1;
}
static int32_t ink_w(const aafont_t *f, const char *s)
{
    int32_t b[4];
    text_ink(f, s, b);
    return b[2] > b[0] ? b[2] - b[0] : 0;
}

/* the quick layers (ui_layer.c): a button held, the keys and KNOB 1..4 are its shortcuts, its map over the page */
enum { LAYER_NONE, LAYER_FX, LAYER_GLO, LAYER_SCL, LAYER_EDIT, LAYER_SEQ, LAYER_CLR, LAYER_N };
static void draw_layer(void);
static const char *layer_head(void);
static int layer_locked(void);
static uint32_t layer_leds(uint32_t *br);
static uint32_t layer_btn(void);

/* OP ENV / OP LEVEL pages are gone with DIGITAL; OPERATOR and OP ENV are FM6's (ui_fm6op.c).
 * The MIXER's two lane pages (GR_LANES) a DRUM-X track's, on its selected track only; SOUND / TONE / MOVEMENT
 * (GR_DXSND) a DRUM track's; OSC A / OSC B / FILTER an ANALOG track's (EDIT 1 / 2 are the other engines' sound
 * pages; ANALOG uses its own three instead); OPERATOR, OP ENV an FM6 track's (its patch's operators, ui_fm6op.c).
 * VOICE is hidden on DRUM (PAN/MUTE on MIXER). */
static int page_visible(uint32_t i)
{
    int analog = ENGINES[TSEL->eng_req % NENGINES] == &ENG_ANALOG;
    int drum = TSEL->eng_req % NENGINES == ENGI_DRUM;
    if (PAGES[i].graph == GR_GENERATION)
        return drum_track(TSEL);                      /* every drum kit: DRUM-X, CR78, USR drum kit */
    if (PAGES[i].graph == GR_DXSND)                   /* EDIT > Kit: DRUM-X SOUND / TONE / MOVEMENT */
        return drum;
    if (PAGES[i].fam == FAM_EDIT && PAGES[i].sec == EDIT_SEC_VOX && drum)   /* Voice hidden on DRUM */
        return 0;
    if (PAGES[i].scope == SC_TRACK && PAGES[i].id[0] >= P_LN0 && PAGES[i].id[0] <= P_LN7)
        return drum;
    if (PAGES[i].scope == SC_ENGINE && (PAGES[i].id[0] == P_E0 || PAGES[i].id[0] == P_E4))   /* EDIT 1 / 2 */
        return !analog;
    if (PAGES[i].id[0] == P_FTYPE)                    /* FILTER (1.5, #104): ANALOG's */
        return analog;
    if (PAGES[i].fam == FAM_EDIT && ((PAGES[i].id[0] == P_E0 && PAGES[i].id[1] == P_MORPH) ||
                                     (PAGES[i].id[0] == P_WAVE2 && PAGES[i].id[1] == P_E7)))
        return analog;                                /* OSC A / OSC B */
    if (PAGES[i].graph == GR_FMOP || PAGES[i].graph == GR_FMENV)
        return TSEL->eng_req % NENGINES == ENGI_FM6;
    /* DELAY / SLICER: hide when this track is USED (another track owns CHAIN). EFFECTS list
     * still shows the USED row; knobs would be misleading (delay globals / ignored slicer). */
    if (PAGES[i].fam == FAM_FX && PAGES[i].id[0] == G_DTIME && fx_list_mode(TSEL, INS_DLY)[0] == 'U')
        return 0;
    if (PAGES[i].fam == FAM_FX && PAGES[i].graph == GR_SLCR && sl_trk_used(TSEL))
        return 0;
    return 1;
}

static uint32_t fam_nsec(uint32_t fam)
{
    return fam == FAM_FX ? FX_NSEC : fam == FAM_SEQ ? SEQ_NSEC : fam == FAM_EDIT ? EDIT_NSEC :
           fam == FAM_GLO ? GLO_NSEC : fam == FAM_SAVE ? SAVE_NSEC : fam == FAM_LFO ? LFO_NSEC : 1u;
}

static uint32_t page_first_sec(uint32_t fam, uint32_t sec)
{
    uint32_t i;
    for (i = 0; i < NPAGES; i++)
        if (PAGES[i].fam == fam && PAGES[i].sec == sec && page_visible(i))
            return i;
    for (i = 0; i < NPAGES; i++)
        if (PAGES[i].fam == fam && page_visible(i))
            return i;
    return 0;
}

static uint32_t page_first(uint32_t fam) { return page_first_sec(fam, 0); }

/* section sticky maps: Punch-in / SEQ tools / SAVE Clear (ui.lock; no hold or double-tap) */
static uint32_t section_map_layer(void)
{
    const page_t *pg;
    if (ui.home)
        return 0;
    pg = &PAGES[ui.page % NPAGES];
    if (pg->fam == FAM_FX && pg->graph == GR_PUNCH)
        return LAYER_FX;
    if (pg->fam == FAM_SEQ && pg->graph == GR_STEPS)   /* SEQ TOOLS: not the GENERATION pages beside it */
        return LAYER_SEQ;
    if (pg->fam == FAM_SAVE && pg->sec == SAVE_SEC_CLEAR)
        return LAYER_CLR;
    return 0;
}

static void section_apply(void);

/* transient message in the top bar, right of the transport and the BPM: a + b */
static void ui_say(const char *a, const char *b)
{
    uint32_t n;
    str_cpy(ui.msg, a, sizeof ui.msg);
    n = str_len(ui.msg);
    str_cpy(ui.msg + n, b, sizeof ui.msg - n);
    ui.msg_t = 40;
    ui.msg2[0] = 0;
}

static void ui_message(const char *s) { ui_say(s, ""); }
/* a message led by an icon: its first byte (ui_draw.c draw_head draws the icon, then the words) */
#define MSG_NOFILE "\x01"                      /* the no-file icon (ICON_X_NOFILE) */
/* a missing sample (ui_input.c sample_notice): NO SAMPLE (SAMPLE NOT FOUND, the SLICES page's, is 4 px too wide
 * for the header's 130 px after the icon) */
#define MSG_NO_SAMPLE MSG_NOFILE "NO SAMPLE"

static int chain_busy(void) { return chain.running || chain.armed; }
/* Main loop only, with interrupts enabled. PLAY may be consumed between reads;
 * take one coherent snapshot before a flash operation or song preparation. */
static int transport_busy(void)
{
    int busy;
    fm1_irq_off();
    busy = song.playing || chain_busy() || transport_req == 1u || seq_counting();   /* (a count-in: as playing) */
    fm1_irq_on();
    return busy;
}
static void chain_play_ui(void)
{
    uint32_t rc = chain_prepare();
    if (!rc) {
        ui.force = 1;
    } else if (rc >= 3u) {
        char b[8] = "A EMPTY";
        b[0] = (char)('A' + rc - 3u);
        ui_say("PATTERN ", b);
    } else {
        ui_message(rc == 1u ? "ADD A SECTION" : "STOP FIRST");
    }
}


/* EFFECTS KNOB 4: the chosen stage's mix (dry/wet in the chain, or the send amount). */
/* DLY: knob 1 is G_DTIME (a division, or free ms above it). Knob 4 is not a parameter (ui_input.c) */
static int dly_page(const page_t *pg)
{
    return pg->scope == SC_GLOBAL && pg->id[0] == G_DTIME;
}
static uint32_t ior_pct_id(void)
{
    static const uint8_t MIX[INS_N] = {P_IDMIX, P_IFMIX, P_ICMIX, P_IPMIX, P_ILMIX, P_IHMIX};
    uint8_t ord[FX_LIST_N];
    uint32_t st;
    fx_list_get(TSEL, ord);
    st = ord[ui.ior_sel < FX_LIST_N ? ui.ior_sel : 0u];
    if (st == INS_DLY)
        return P_DLY;
    if (st == INS_REV)
        return P_REV;
    if (st == INS_SLCR)
        return P_SLDEPTH;
    if (st == INS_TAPE)
        return P_TAPEMIX;
    return MIX[st < INS_N ? st : 0u];
}

/* parameter locks: a page whose KNOB 1..4 can lock (a track's sound: one of its parameters can be motion; not MOD's
 * slots), the parameter KNOB k locks (ui.plk_src's page, HOME's four), 0xFF = none */
static int lock_page_ok(uint32_t i)
{
    uint32_t k;
    if (i < NPAGES && PAGES[i].scope == SC_GLOBAL &&
        (PAGES[i].id[0] == G_DTIME || PAGES[i].id[0] == G_RTYPE || PAGES[i].id[0] == G_TSPEED))
        return 1;
    if (i < NPAGES && PAGES[i].graph == GR_IORD)
        return 1;                                     /* KNOB 4 locks the chosen stage's mix */
    if (i < NPAGES && PAGES[i].graph == GR_SCALE)
        return 1;                                     /* SCL KNOB 4 locks a step's PITCH (MSEQ_PITCH) */
    if (i >= NPAGES || (PAGES[i].scope != SC_TRACK && PAGES[i].scope != SC_ENGINE) || PAGES[i].graph == GR_MOD)
        return 0;
    for (k = 0; k < 4u; k++)
        if (PAGES[i].id[k] != 0xFFu && !MFX_ALL(PAGES[i].id[k]) && motion_param(PAGES[i].id[k]))
            return 1;
    return 0;
}
static uint32_t lock_id(uint32_t k)
{
    uint32_t id;
    if (ui.plk_src && lock_page_ok(ui.plk_src - 1u) && PAGES[ui.plk_src - 1u].scope == SC_GLOBAL) {
        const page_t *pg = &PAGES[ui.plk_src - 1u];
        id = pg->id[0] == G_DTIME ? (k < 3u ? MFX_TIME + k : 0xFFu)
                                 : pg->id[0] == G_TSPEED ? (k == 0u ? MFX_TSPEED : k == 1u ? MFX_TWOW : 0xFFu)
                                 : (k == 1u || k == 2u ? MFX_SIZE + k - 1u : 0xFFu);
        return id != 0xFFu && fx_target_available(TSEL, id) ? id : 0xFFu;
    }
    if (ui.plk_src && lock_page_ok(ui.plk_src - 1u) && PAGES[ui.plk_src - 1u].graph == GR_IORD) {
        id = k == 3u ? ior_pct_id() : 0xFFu;
        if (id == P_TAPEMIX)                          /* TAPE's one global amount does not lock */
            return 0xFFu;
    } else
        id = ui.plk_src && lock_page_ok(ui.plk_src - 1u) ? PAGES[ui.plk_src - 1u].id[k & 3u]
                                                          : ENGINES[TSEL->eng_req % NENGINES]->knob[k & 3u];
    if (id == P_TRANS && ui.plk_src && lock_page_ok(ui.plk_src - 1u) &&
        PAGES[ui.plk_src - 1u].graph == GR_SCALE)
        id = MSEQ_PITCH;                         /* SCL KNOB 4 on a held step: the PITCH lock */
    if (id == MSEQ_PITCH && kit_track(TSEL))
        return 0xFFu;                            /* PITCH is inert on a kit track: the knob creates no lock */
    if (id == P_DETUNE) {                        /* VOICE K4: SPRD in POLY, UNI DTN in UNISON */
        if (TSEL->p[P_VOICE] == V_POLY)
            id = P_SPRD;
        else if (TSEL->p[P_VOICE] != V_UNISON)
            return 0xFFu;
    }
    return param_id_known(id) && !MFX_ALL(id) && motion_param(id) &&
           fx_target_available(TSEL, id) && param_live(motion_target_desc(TSEL, id)) ? id : 0xFFu;
}

static void ev_enter(void);
static void layer_opened(uint32_t l);            /* ui_layer.c: sticky section maps call it */
static void section_apply(void)
{
    uint32_t want = section_map_layer();
    if (want) {
        if (ui.lock != want) {
            ui.lock = (uint8_t)want;
            layer_opened(want);
            ui.force = 1;
        }
    } else if (ui.lock && !ui.ly) {
        ui.lock = 0;
        ui.force = 1;
    }
}

static void page_entered(void)
{
    const page_t *pg = cur_page();
    ui.pick = 0;                                 /* #223: leave any PARAM / DST list */
    if (!ui.home && pg->graph == GR_EVENTS)      /* AUTOMATION: + ADD on the SEQ cursor's step */
        ev_enter();
    if (!ui.home && lock_page_ok(ui.page))
        ui.plk_src = (uint8_t)(ui.page + 1u);
    song.seq_mode = !ui.home && pg->fam == FAM_SEQ;
    {   /* the punch page shown: the section's 2/2 page (two PUNCH-IN titles, the count tells them apart) */
        uint32_t i = NPAGES;
        while (i > 0 && !(PAGES[i - 1].fam == FAM_FX && PAGES[i - 1].graph == GR_PUNCH))
            i--;                                        /* (the last PUNCH-IN page in the table: the 2/2) */
        perf_page(!ui.home && pg == &PAGES[i - 1]);
    }
    ui.entry_open = 0;
    ui.hot_t = 0;                                /* clear the previous page's emphasis */
    ui.act = pg->graph == GR_USER ? 4u : 0u;     /* the save screen is ready for OCT+ */
    ui.force = 1;
    section_apply();
}

static int step_on(const step_t *st) { return st->time == ST_NOTE && (st->n || st->hit); }
/* 1.5.1 (#199): a step whose CHANCE, RATCH or NUDGE is off its default: marked on the roll and the grid (ui_graph.c).
 * Not VEL: every recorded step has one */
static int step_detailed(const step_t *st)
{
    return step_chance(st) < 100u || step_ratchet(st) > 1u || step_nudge(st) != 0;
}

static void step_clear(step_t *st)
{
    st->n = 0;
    st->time = ST_REST;
    step_set_fl(st, 0);
    step_set_ratchet(st, 1u);
    step_set_nudge(st, 0);
    step_set_vel(st, 0);
    st->hit = st->acc = 0;
    step_set_prob_raw(st, 0);
}

/* LEN (1.5, Discussions #178, #173): a NOTE step's length on the piano roll is the step and the TIE steps after it
 * (inside LEN, no wrap); SEQ > STEP's KNOB 3 on a note sets it (ui_input.c step_edit). Longer: the steps after it
 * become clean TIEs (a REST or an empty step; it stops at the next step holding notes or hits, a REST's kept ones too,
 * which stays, and at LEN);
 * shorter: its last TIEs become RESTs (step_clear). The steps' locks stay. 0 clears the note and those TIEs (a real
 * rest: the note bytes go too). Returns the length it got (0: the note is gone) */
static uint32_t note_len(const track_t *t, uint32_t i)
{
    uint32_t len = (uint32_t)clamp(t->p[P_SLEN], 1, NSTEP), n = 1;
    while (i + n < len && t->step[i + n].time == ST_TIE)
        n++;
    return n;
}
static uint32_t note_set_len(track_t *t, uint32_t i, uint32_t want)
{
    uint32_t len = (uint32_t)clamp(t->p[P_SLEN], 1, NSTEP), n = note_len(t, i), k;
    if (!want) {
        for (k = 0; k < n && i + k < NSTEP; k++) {
            memset(&t->step[i + k], 0, sizeof t->step[i + k]);
            t->step[i + k].time = ST_REST;
        }
        return 0;
    }
    for (; n > want && n > 1u; n--)
        step_clear(&t->step[i + n - 1u]);
    for (; n < want && i + n < len && !t->step[i + n].n && !t->step[i + n].hit; n++) {
        step_clear(&t->step[i + n]);
        t->step[i + n].time = ST_TIE;
    }
    return n;
}

/* ------------------------------------------------------- the DRUM grid --- */
/* SEQ > STEP on a DRUM track is the grid: 8 lanes x the 16 steps of a page. The white keys are the
 * steps of the page shown (a tap toggles the selected lane there), black keys 1..8 select the lane (and play
 * it), black key 9 held is ACC (white keys toggle accents, their LEDs show them), black keys 10 / 11 the page
 * down / up. KNOB 1 STEP, 2 LANE, 3 HIT, 4 ACC edit the cursor step. A sound load never converts the
 * steps: the grid shows a step's notes on their lanes (eng_drum.c step_lanes) and an edit makes the lane its
 * own (grid_own). Live recording on a DRUM track writes hits (seq.c rec_note) */
static int grid_on(void) { return !ui.home && !ui.menu && !ui.confirm && cur_page()->graph == GR_ROLL && drum_track(TSEL); }
/* SEQ > DETAIL (1.5.1, Discussion #199; params.c, between STEP and AUTOMATION): a step page as STEP (the cursor, the
 * roll's keys, the grid's lane and page keys), its knobs the cursor step's CHANCE RATCH NUDGE VEL (ui_input.c sd_turn),
 * its panel their lanes (ui_graph.c graph_detail). No state of its own: the page is what says so */
static int detail_on(void)
{
    return !ui.home && !ui.menu && !ui.confirm && cur_page()->scope == SC_STEP && str_eq(cur_page()->title, "DETAIL");
}
/* GLO > SONG (1.2): the white keys A B C D (A3 B3 C4 D4, white places 2..5: seq.c song_key) set the selected cell's slot;
 * they do not sound there, the other keys play as anywhere (seq.c keyboard_block: song.grid 3) */
static int song_keys_on(void) { return !ui.home && !ui.menu && !ui.confirm && !ui.layer && cur_page()->graph == GR_SONG; }
/* a DRUM-X track's EDIT pages, the ones that draw its A---B bar (EDIT 1 / 2, SOUND / TONE / MOVEMENT: ui_graph.c
 * graph_colony): black keys 1..3 audition the kit's A, its MRPH as stored, or its B (F# G# A#, kit_audition,
 * ui_input.c) and glow (ui_leds); the white keys still play the lanes */
static int dx_keys_on(void)
{
    const page_t *pg = cur_page();
    return !ui.home && !ui.menu && !ui.confirm && !ui.layer && TSEL->eng_req % NENGINES == ENGI_DRUM &&
           (pg->graph == GR_DXSND || pg->scope == SC_ENGINE);
}

/* black key place p (seq.c key_place) held, 0 = not */
static int black_held(uint32_t p)
{
    uint32_t k;
    for (k = 0; k < 27u; k++)
        if (key_black(k) && key_place(k) == p)
            return (int)(((fm1_in.notes & ~kb_layer) >> k) & 1u);
    return 0;
}

/* lane l of step s from now on is its hit alone: the step's lane notes become hits (nothing sounds different),
 * a note of another pitch on the lane (a low tom 41) becomes the lane's own */
static void grid_own(step_t *s, uint32_t l)
{
    uint32_t k, j = 0;
    step_to_grid(s);
    for (k = 0; k < s->n; k++)
        if (drum_lane(step_note(s, k)) == l)
            s->hit |= (uint8_t)(1u << l);
        else
            step_set_note(s, j++, step_note(s, k));
    for (k = j; k < 4u; k++)
        step_set_note(s, k, 0);
    s->n = (uint8_t)j;
}

/* lane l of step i: on 1, off 0, toggled 2 */
static void grid_hit(track_t *t, uint32_t i, uint32_t l, uint32_t on)
{
    step_t *s = &t->step[i % NSTEP];
    uint32_t b = 1u << (l % NLANE);
    if (on == 2u)
        on = !(step_lanes(s) & b);
    if (s->time != ST_NOTE) {                    /* a REST or a TIE: an empty step (nothing to turn off) */
        if (!on)
            return;
        step_clear(s);
        s->time = ST_NOTE;
    }
    grid_own(s, l % NLANE);
    if (on) {
        s->hit |= (uint8_t)b;
    } else {
        s->hit &= (uint8_t)~b;
        s->acc &= (uint8_t)~b;
        if (!s->n && !s->hit)
            step_clear(s);
    }
}

/* the accent of lane l at step i (on 1, off 0, toggled 2); an accent on an empty lane adds the hit */
static void grid_acc(track_t *t, uint32_t i, uint32_t l, uint32_t on)
{
    step_t *s = &t->step[i % NSTEP];
    uint32_t b = 1u << (l % NLANE);
    if (on == 2u)
        on = !(step_accents(s) & b);
    if (on)
        grid_hit(t, i, l, 1);
    if (!(step_lanes(s) & b))
        return;
    grid_own(s, l % NLANE);
    if (step_fl(s) & SF_ACCENT) {                /* a step accent: each hit's own from now on */
        s->acc |= s->hit;
        step_set_fl(s, step_fl(s) & ~SF_ACCENT);
    }
    s->acc = (uint8_t)(on ? s->acc | b : s->acc & ~b);
}

/* SEQ cursor: wraps inside the pattern length, the bank follows, a step entry ends */
static void cursor_set(int32_t c)
{
    int32_t len = TSEL->p[P_SLEN] > 0 ? TSEL->p[P_SLEN] : 1;
    ui.cursor = (uint8_t)((c % len + len) % len);
    ui.bank = (uint8_t)(ui.cursor / 16u);
    ui.entry_open = 0;
}

static void cursor_fix(void)                           /* LEN got shorter: onto the last step */
{
    if (ui.cursor >= (uint32_t)TSEL->p[P_SLEN])
        cursor_set(TSEL->p[P_SLEN] - 1);
}

/* SEQ follow: while playing on STEP/DETAIL, the cursor tracks seq_idx unless paused (~3 s) */
#define SEQ_FOLLOW_FRAMES 180u
static int seq_step_sec(void)
{
    const page_t *pg = cur_page();
    return !ui.home && pg->fam == FAM_SEQ && pg->sec == SEQ_SEC_STEP && pg->graph != GR_EVENTS;
}
static void seq_follow_bump(void)
{
    if (seq_step_sec())
        ui.seq_follow_t = (uint8_t)SEQ_FOLLOW_FRAMES;
}
static void seq_follow_tick(void)
{
    if (!song.playing || !seq_step_sec()) {
        ui.seq_follow_t = 0;
        return;
    }
    if (ui.seq_follow_t)
        ui.seq_follow_t--;
    else
        cursor_set((int32_t)TSEL->seq_idx);
}

static void note_name(char *b, uint32_t n)
{
    str_cpy(b, N_NOTE[n % 12u], 4);
    fmt_int(b + str_len(b), (int32_t)(n / 12u) - 1);
}

/* page button: cycle sections (wrap). One-section families: enter only (no cycle). SELECT walks pages
 * inside the section and stops at the ends. Entering from elsewhere always opens the family's first
 * section/first page (FX Effects not Punch-in; ENV not ENV DEST; SAVE PRESETS). */
static int page_sec_any(uint32_t fam, uint32_t sec)
{
    uint32_t i;
    for (i = 0; i < NPAGES; i++)
        if (PAGES[i].fam == fam && PAGES[i].sec == sec && page_visible(i))
            return 1;
    return 0;
}

static void open_family(uint32_t fam)
{
    uint32_t nsec = fam_nsec(fam), sec, i;
    if (!ui.home && cur_page()->fam == fam) {
        if (nsec <= 1u)
            return;                                   /* single section: press does not invent pages */
        sec = (cur_page()->sec + 1u) % nsec;
        for (i = 0; i < nsec; i++) {                  /* skip sections with no visible pages (Kit/Lanes on synth) */
            if (page_sec_any(fam, sec)) {
                ui.page = (uint8_t)page_first_sec(fam, sec);
                break;
            }
            sec = (sec + 1u) % nsec;
        }
    } else {
        ui.page = (uint8_t)page_first(fam);
    }
    ui.fam_last[fam] = ui.page;
    ui.home = 0;
    page_entered();
}

static void go_home(void)
{
    ui.home = 1;
    ui.plk_src = 0;                              /* (parameter locks: HOME's four) */
    ui.entry_open = 0;
    ui.hot_t = 0;
    song.seq_mode = 0;
    ui.force = 1;
    section_apply();                             /* leave sticky maps */
}

/* HOME: Home ↔ Mixer. Held: MENU */
static void home_tap(void)
{
    if (ui.home) {
        ui.page = (uint8_t)page_first_sec(FAM_TRK, TRK_SEC_MIX);
        ui.fam_last[FAM_TRK] = ui.page;
        ui.home = 0;
        page_entered();
    } else {
        go_home();
    }
}

/* Visible pages of fam+sec in SELECT order. EFFECTS: list page, then stages in fx_list order. */
static uint32_t sec_page_list(uint32_t fam, uint32_t sec, uint32_t idx[NPAGES])
{
    uint32_t n = 0, i;
    if (fam == FAM_FX && sec == FX_SEC_INS) {
        uint8_t ord[FX_LIST_N];
        for (i = 0; i < NPAGES; i++)
            if (PAGES[i].fam == fam && PAGES[i].sec == sec && PAGES[i].graph == GR_IORD &&
                page_visible(i))
                idx[n++] = i;
        fx_list_get(TSEL, ord);
        for (i = 0; i < FX_LIST_N; i++) {
            uint32_t st = ord[i], j;
            for (j = 0; j < NPAGES; j++)
                if (PAGES[j].fam == fam && PAGES[j].sec == sec && page_visible(j) &&
                    str_eq(PAGES[j].title, N_ISTAGE[st])) {
                    idx[n++] = j;
                    break;
                }
        }
        return n;
    }
    for (i = 0; i < NPAGES; i++)
        if (PAGES[i].fam == fam && PAGES[i].sec == sec && page_visible(i))
            idx[n++] = i;
    return n;
}

/* SELECT: pages that share fam+sec; stops at the first / last (no wrap). Tempo: OCT++SELECT */
static void select_page_step(int32_t dir)
{
    uint32_t fam, sec, i, idx[NPAGES], n, cur = 0;
    if (dir == 0 || ui.home)
        return;                                        /* Home is its own section; no pages to walk */
    fam = cur_page()->fam;
    sec = cur_page()->sec;
    n = sec_page_list(fam, sec, idx);
    for (i = 0; i < n; i++)
        if (idx[i] == ui.page)
            cur = i;
    if (n == 0)
        return;
    if (dir > 0) {
        if (cur + 1u >= n)
            return;
        cur++;
    } else {
        if (!cur)
            return;
        cur--;
    }
    ui.page = (uint8_t)idx[cur];
    ui.fam_last[fam] = ui.page;
    page_entered();
}

/* ------------------------------------------------------- track setup --- */
static int seq_is_empty(const track_t *t)
{
    uint32_t i;
    for (i = 0; i < NSTEP; i++)
        if (t->step[i].n || t->step[i].hit)
            return 0;
    return 1;
}

/* One-step UNDO of a load. A sound load (a factory or user preset, an engine jump, CLEAR INIT, the
 * editor's PRESET / G_ENGSEL / UP_LOAD) changes the sound only; a step load (the editor's restore, a
 * step tool) changes the steps and their parameters only. Each first copies the track as it was; SAVE held 0.7 s
 * swaps back what the loads changed (held again: the loads again), so steps recorded after a sound
 * load, or a sound edited after a steps load, stay as they are. One copy for all tracks: the last
 * load wins. Loads in a row on one track with nothing changed in between (the PRESETS knob through the
 * list, one pattern after the other, an editor audition) keep the copy from before the first, so the
 * undo goes back past the whole browse. Not snapshotted: power-on, projects.
 * 1.1.5: a lock or automation edit by hand (a step held and a knob turned, a step's locks cleared, SEQ > AUTOMATION)
 * takes the copy too (UNDO_MOT: SAVE held puts the track's motion back, the sound and the steps stay; motion_undo_take).
 * A sound load keeps the track's motion on the parameters every engine has (load_end, motion.c motion_sound_loaded);
 * a steps load drops it all (the steps it was on are gone).
 * SAVE > CLEAR > ALL / ALL4 clears the mix and the arp too (UNDO_MIX: those come back with the sound and steps).
 * PUNCH LANE's edits copy the punch-in lane instead (UNDO_LANE alone: every track's, the swap touches no track) */
enum { UNDO_SOUND = 1, UNDO_STEPS = 2, UNDO_MOT = 4, UNDO_MIX = 8, UNDO_KIT = 16, UNDO_LANE = 32 };
static struct {
    uint8_t trk;                 /* track + 1, 0 = nothing to undo */
    uint8_t keep;                /* the track is as the last load left it (undo.after): a next load keeps the copy */
    uint8_t what;                /* UNDO_SOUND | UNDO_STEPS: what the loads since the copy changed (undo_swap) */
    uint8_t eng, preset, user;
    uint8_t fm6_slot;            /* the track's FM6 patch and its SLOT (eng_fm6.c): an edited or a project's */
    uint8_t fm6[FP_SIZE + 1u];   /* patch is the track's own, not a factory one */
    dx_lane_t dx[8];            /* packed kit before a load; swapped only when the load replaces it (UNDO_KIT) */
    int16_t p[P_COUNT];
    int16_t mx[4][3];            /* matrix slots 5..8 (track_t.mx): part of the sound */
    step_t step[NSTEP];
    generation_t generation;
    motion_store_t motion_backup; /* one track only, swaps with the shared event pool on undo */
    uint32_t after;              /* track_sig right after the last load */
    uint32_t from_h;             /* step_from_h[], step_from[] of the copy (the header's slot letter) */
    uint8_t from;
    uint32_t t_ms;               /* time of the last load (the editor's SETs after it belong to it) */
    uint32_t lane[64];           /* UNDO_LANE: pfx_lane and pfx_ltgt (pfx.c) */
    uint8_t ltgt;
} undo;                       /* (main loop only, but in .bss since FUN21: the pool's headroom took its 255 records) */
static uint8_t undo_depth;       /* loads nest (an engine jump loads its first preset): the outer one counts;
                                  * felucca_init / project_load raise it to take no copy at all */
/* the header's slot letter (ui_draw.c head_slot): the PROJECT slot each track's working pattern came from (the last
 * PROJECT load or save: 1..4 = A..D; 0 none: power-on, the editor's restore) and step_from_sig() of
 * it then: an edit since shows the letter with a mark */
static uint8_t step_from[NTRK];
static uint32_t step_from_h[NTRK];
static uint8_t load_from;        /* a sound load (the outer one): the engine before it (load_end) */
static uint8_t load_mo;          /* .. the track's motion paused while the sound changes: bit 0 set, bit 1 it was ON */

static uint32_t fnv(uint32_t h, const void *p, uint32_t n)
{
    const uint8_t *b = (const uint8_t *)p;
    while (n--)
        h = (h ^ *b++) * 16777619u;
    return h;
}
static uint32_t steps_sig(const track_t *t) { return fnv(2166136261u, t->step, sizeof t->step); }
static uint32_t track_sig(const track_t *t)      /* the sound, its FM6 patch or shared DRUM-X kit, and the steps */
{
    uint8_t id[3] = {t->eng_req, t->preset, t->user};
    uint32_t h = fnv(fnv(fnv(steps_sig(t), t->p, sizeof t->p), t->mx, sizeof t->mx), id, 3), k = trk_index(t);
    h = fnv(h, fm6_patch[k], sizeof fm6_patch[k]); /* (a patch the editor sent between two loads) */
    if (t->eng_req % NENGINES == ENGI_DRUM) {
        h = fnv(h, dx_kit, sizeof dx_kit);
        h = fnv(h, dx_lay, sizeof dx_lay);
        h = fnv(h, dx_mdl, sizeof dx_mdl);
    }
    for (uint32_t j = 0; j < motion.count; j++)
        if ((motion.event[j].place >> 6) == k) h = fnv(h, &motion.event[j], sizeof motion.event[j]);
    return h ^ ((motion.on >> k) & 1u);
}
static uint32_t motion_sig(const track_t *t)     /* the track's motion only (the sound moves while it plays) */
{
    uint32_t h = 2166136261u, k = trk_index(t);
    for (uint32_t j = 0; j < motion.count; j++)
        if ((motion.event[j].place >> 6) == k) h = fnv(h, &motion.event[j], sizeof motion.event[j]);
    return h ^ ((motion.on >> k) & 1u);
}
/* the track's pattern as a song plays it from a slot: the steps, LEN DIV SWING GATE, QUANTIZE, the automation (the
 * editable ones: while a song plays the header shows the section's slot instead) */
static uint32_t step_from_sig(const track_t *t)
{
    int16_t q = t->p[P_SQNT];
    uint32_t h = fnv(fnv(steps_sig(t), &t->p[P_SLEN], 4u * sizeof t->p[0]), &q, sizeof q);
    return h ^ motion_sig(t);
}
static void step_from_set(uint32_t slot)             /* every track's sequence is slot's now (1..4), 0 none */
{
    for (uint32_t k = 0; k < NTRK; k++) {
        step_from[k] = (uint8_t)slot;
        step_from_h[k] = step_from_sig(&trk[k]);
    }
}

/* load_begin, the copy taken: a steps load drops the track's motion (its steps go); a sound load pauses it (PLAY
 * OFF while the sound changes under it) and load_end keeps what still means the same (motion_sound_loaded) */
static void load_motion_hold(track_t *t, uint32_t what)
{
    if (what & UNDO_STEPS) {
        motion_reset(t);
        load_mo = 0;
        return;
    }
    load_from = t->eng_req;
    load_mo = (uint8_t)(1u | (motion_enabled(t) ? 2u : 0u));
    motion_set_enabled(t, 0);
}

/* MOMENTARY (ui_input.c mom_turn: LFO held, the knobs' changes go back when it is let go): the values turned, where
 * they are (a track's p[], song.g[]) and what they were. In the main loop's pool (no .bss) */
#define MOM_N 8u
static struct {
    uint8_t n;                                    /* values held, 0 = none */
    int16_t *vp[MOM_N];
    int16_t v[MOM_N];
} mom __attribute__((unused));
static void mom_restore(void)                     /* LFO let go: every value back */
{
    while (mom.n) {
        mom.n--;
        *mom.vp[mom.n] = mom.v[mom.n];
    }
}
static void mom_back(const track_t *t)            /* a sound load into t (0: a project): its values back first */
{
    uint32_t i, k = 0;
    for (i = 0; i < mom.n; i++)
        if (!t || (mom.vp[i] >= t->p && mom.vp[i] < t->p + P_COUNT) ||
            (mom.vp[i] >= song.g && mom.vp[i] < song.g + G_COUNT) ||
            (mom.vp[i] >= fx_bus_trk.p && mom.vp[i] < fx_bus_trk.p + P_COUNT)) {
            *mom.vp[i] = mom.v[i];                /* (a global: back too, before the load's undo copy) */
        } else {
            mom.vp[k] = mom.vp[i];
            mom.v[k++] = mom.v[i];
        }
    mom.n = (uint8_t)k;
}
/* the undo copy of t as it is now: its sound, matrix slots, steps, kit and motion (load_begin, edit_undo_take,
 * ui_tools.c tl_undo_take: each keeps what its own action adds — load_motion_hold / undo.keep / t_ms) */
static void undo_take(track_t *t, uint32_t what)
{
    uint32_t i = trk_index(t);
    undo.trk = (uint8_t)(i + 1u);
    undo.what = (uint8_t)what;
    undo.eng = t->eng_req;
    undo.preset = t->preset;
    undo.user = t->user;
    memcpy(undo.p, t->p, sizeof undo.p);
    memcpy(undo.mx, t->mx, sizeof undo.mx);
    undo.generation = t->generation;
    memcpy(undo.step, t->step, sizeof undo.step);
    memcpy(undo.fm6, fm6_patch[i], FP_SIZE);
    undo.fm6_slot = fm6_slot[i];
    dx_kit_pack(undo.dx, dx_kit, dx_lay, dx_mdl);
    undo.from = step_from[i];
    undo.from_h = step_from_h[i];
    motion_snapshot_track(t, &undo.motion_backup);
}

static void load_begin(track_t *t, uint32_t what)
{
    uint32_t i = trk_index(t);
    if (what & UNDO_SOUND) {
        mom_back(t);                              /* (MOMENTARY: the sound as it was, then the load) */
        drum_mute[i] = 0;                         /* (1.4.1: the lanes' mutes go with the sound) */
    }
    if (undo_depth++)
        return;
    motion_restore(t);
    if (undo.keep && undo.trk == i + 1u && !(undo.what & UNDO_MOT) && track_sig(t) == undo.after) {
        undo.what |= (uint8_t)what;               /* browsing on: the copy from before the first load stays */
        load_motion_hold(t, what);
        return;
    }
    undo_take(t, what);
    load_motion_hold(t, what);
}

static void load_end(track_t *t)
{
    if (--undo_depth)
        return;
    if (load_mo & 1u) {                           /* a sound load: the motion on the common parameters stays */
        (void)motion_sound_loaded(t, load_from, t->eng_req);
        if ((load_mo & 2u) && motion_count(t))
            motion_set_enabled(t, 1);
        load_mo = 0;
    }
    motion_rebase(t);
    undo.after = track_sig(t);
    undo.keep = 1;
    undo.t_ms = fm1_ms;
}

/* the editor's SET right after a load on the selected track (an audition: G_ENGSEL, then the patch's
 * values): part of that load, the copy from before it stays */
static void load_extend(track_t *t)
{
    if (undo.keep && undo.trk == trk_index(t) + 1u && !(undo.what & UNDO_MOT) && fm1_ms - undo.t_ms < 1500u) {
        undo.after = track_sig(t);
        undo.t_ms = fm1_ms;
    }
}

/* 1.1.5: a lock / automation edit by hand on track t is about to happen: the undo copy of the track as it is (as
 * ui_tools.c tl_undo_take, UNDO_MOT: the swap puts back its motion only). A knob turned on (the same tag, not 0:
 * the same knob of the same gesture), on the same track, nothing else changed and less than 1.5 s apart, shares the
 * copy from before its first detent; tag 0 (an add, a delete, a clear, a kind) always takes its own.
 * motion_undo_done after each */
static uint32_t undo_mot_tag;
/* What an edit's copy compares: motion, plus steps and generator controls for a pattern edit. */
static uint32_t edit_sig(const track_t *t)
{
    uint32_t h = motion_sig(t);
    return undo.what & UNDO_STEPS ? fnv(h ^ steps_sig(t), &t->generation, sizeof t->generation) : h;
}
static void edit_undo_take(track_t *t, uint32_t tag, uint32_t what)
{
    uint32_t i = trk_index(t);
    if (tag && tag == undo_mot_tag && undo.keep && undo.trk == i + 1u && undo.what == what &&
        edit_sig(t) == undo.after && fm1_ms - undo.t_ms < 1500u)
        return;
    undo_mot_tag = tag;
    undo_take(t, what);
    undo.keep = 0;
}
static void motion_undo_take(track_t *t, uint32_t tag) { edit_undo_take(t, tag, UNDO_MOT); }
/* 1.2: a step's CHANCE / RATCH edited on SEQ > AUTOMATION (ui_events.c): the swap puts back the steps (and LEN DIV
 * SWING GATE, as copied) and the motion, the sound stays. motion_undo_done after each, as for a lock */
static void step_undo_take(track_t *t, uint32_t tag) { edit_undo_take(t, tag, UNDO_MOT | UNDO_STEPS); }
static void motion_undo_done(track_t *t)
{
    undo.after = edit_sig(t);
    undo.keep = 1;
    undo.t_ms = fm1_ms;
}
/* the lane undo's copy: lane l and its tracks g (UNDO_LANE; the swap touches no track) */
static void lane_undo_set(const uint32_t *l, uint32_t g)
{
    undo.trk = (uint8_t)(song.sel + 1u);         /* (something to undo) */
    undo.what = UNDO_LANE;
    memcpy(undo.lane, l, sizeof undo.lane);
    undo.ltgt = (uint8_t)g;
    undo.keep = 0;
}
/* PUNCH LANE (ui_events.c): the lane is about to be edited: its copy. A knob turned on shares the copy as
 * motion_undo_take does; lane_undo_done after each */
static void lane_undo_take(uint32_t tag)
{
    if (tag && tag == undo_mot_tag && undo.keep && undo.what == UNDO_LANE &&
        fnv(2166136261u, pfx_lane, sizeof pfx_lane) == undo.after && fm1_ms - undo.t_ms < 1500u)
        return;
    undo_mot_tag = tag;
    lane_undo_set(pfx_lane, pfx_ltgt);
}
static void lane_undo_done(void)
{
    undo.after = fnv(2166136261u, pfx_lane, sizeof pfx_lane);
    undo.keep = 1;
    undo.t_ms = fm1_ms;
}
/* A REC pass that changes the lane (punch-ins, CLR: pfx.c, in the ISR) is one lane undo: the lane as the pass found it
 * becomes the copy when the pass ends; a pass that leaves the lane as it was takes none. Each frame (ui_input) */
static uint32_t lane_pre[64];                     /* the lane as the pass found it */
static uint8_t lane_pre_tgt, lane_pass;
static void lane_rec_watch(void)
{
    uint32_t on = (uint32_t)pfx_rec_ok();
    if (on && !lane_pass) {
        memcpy(lane_pre, pfx_lane, sizeof lane_pre);
        lane_pre_tgt = pfx_ltgt;
    } else if (!on && lane_pass && memcmp(lane_pre, pfx_lane, sizeof lane_pre)) {
        undo_mot_tag = 0;
        lane_undo_set(lane_pre, lane_pre_tgt);
        lane_undo_done();
    }
    lane_pass = (uint8_t)on;
}

static int param_kept(uint32_t i);

/* SAVE held: what the loads changed (undo.what) and the copy change places, so held again = the loads
 * again. The sound: engine, preset, its parameters (not param_kept), and any replaced kit. The pattern: steps, LEN
 * DIV SWING GATE and generator controls. The mix (LEVEL PAN MUTE) stays: no load changes it */
static void undo_swap(void)
{
    track_t *t;
    uint32_t i;
    char b[4] = {'T', 0, 0, 0};
    if (!undo.trk) {
        ui_message("NOTHING TO UNDO");
        return;
    }
    if (undo.what == UNDO_LANE) {                 /* the punch-in lane and the copy change places */
        uint32_t v;
        for (i = 0; i < 64u; i++) {
            v = pfx_lane[i];
            pfx_lane[i] = undo.lane[i];
            undo.lane[i] = v;
        }
        v = pfx_ltgt;
        pfx_ltgt = undo.ltgt;
        undo.ltgt = (uint8_t)v;
        undo.keep = 0;
        ui_message("UNDO/REDO LANE");
        ui.force = 1;
        return;
    }
    t = &trk[(undo.trk - 1u) % NTRK];
    motion_restore(t);
    motion_store_t current_motion;
    motion_snapshot_track(t, &current_motion);
    if (motion_replace_track(t, &undo.motion_backup) != 0) {
        ui_message("AUTOMATION FULL");
        return;
    }
    undo.motion_backup = current_motion;
    fm1_irq_off();                                /* the audio ISR must not see half a sound */
    if (undo.what & UNDO_SOUND) {
        uint8_t e = t->eng_req, pr = t->preset, u = t->user;
        panic_req |= (uint8_t)(1u << trk_index(t));
        t->eng_req = undo.eng;
        t->preset = undo.preset;
        t->user = undo.user;
        undo.eng = e;
        undo.preset = pr;
        undo.user = u;
        for (i = 0; i < P_COUNT; i++)
            if (!param_kept(i)) {
                int16_t v = t->p[i];
                t->p[i] = undo.p[i];
                undo.p[i] = v;
            }
        {
            int16_t mx[4][3];
            memcpy(mx, t->mx, sizeof mx);
            memcpy(t->mx, undo.mx, sizeof mx);
            memcpy(undo.mx, mx, sizeof mx);
        }
    }
    if (undo.what & UNDO_KIT) {
        dx_lane_t current[8];
        dx_kit_pack(current, dx_kit, dx_lay, dx_mdl);
        dx_kit_unpack(dx_kit, dx_lay, dx_mdl, undo.dx);
        memcpy(undo.dx, current, sizeof undo.dx);
    }
    if (undo.what & UNDO_STEPS) {
        generation_t gen = t->generation;
        t->generation = undo.generation;
        undo.generation = gen;
        uint8_t pn = step_from[trk_index(t)];
        uint32_t ps = step_from_h[trk_index(t)];
        step_from[trk_index(t)] = undo.from;
        step_from_h[trk_index(t)] = undo.from_h;
        undo.from = pn;
        undo.from_h = ps;
        for (i = P_SLEN; i <= P_SGATE; i++) {
            int16_t v = t->p[i];
            t->p[i] = undo.p[i];
            undo.p[i] = v;
        }
        {   /* NOTE EDITS > HUMAN switches QUANTIZE off so its nudges play: undo puts it back */
            int16_t v = t->p[P_SQNT];
            t->p[P_SQNT] = undo.p[P_SQNT];
            undo.p[P_SQNT] = v;
        }
        for (i = 0; i < NSTEP; i++) {
            step_t s = t->step[i];
            t->step[i] = undo.step[i];
            undo.step[i] = s;
        }
    }
    if (undo.what & UNDO_MIX) {                   /* a preset load keeps these (param_kept): the clear changed them */
        static const uint8_t MIX[3] = {P_LEVEL, P_PAN, P_MUTE};
        int16_t v;
        uint32_t j;
        for (j = 0; j < 3u; j++) {
            v = t->p[MIX[j]];
            t->p[MIX[j]] = undo.p[MIX[j]];
            undo.p[MIX[j]] = v;
        }
        for (i = P_AMODE; i <= P_AORDER; i++) {
            v = t->p[i];
            t->p[i] = undo.p[i];
            undo.p[i] = v;
        }
        t->ahold_sv = t->p[P_AHOLD];               /* DRONE's forced HOLD: the value it restores */
    }
    fm1_irq_on();
    if (undo.what & UNDO_SOUND) {                 /* FM6: the track's patch as it was (edited, a project's, a
                                                   * converted DIGITAL sound), not a factory one */
        uint32_t tr = trk_index(t);
        uint8_t v[FP_SIZE + 1u], sl = fm6_slot[tr];
        memcpy(v, fm6_patch[tr], FP_SIZE);
        fm6_set_patch(tr, undo.fm6);
        fm6_slot[tr] = undo.fm6_slot;             /* (fm6_poll: the patch stays) */
        fm6_own_ok &= (uint8_t)~(1u << tr);
        memcpy(undo.fm6, v, FP_SIZE);
        undo.fm6_slot = sl;
    }
    undo.keep = 0;                                /* the next load copies the track as it is now */
    if (t == TSEL)
        sync_reload = 1;
    b[1] = (char)('1' + trk_index(t));
    ui_say("UNDO/REDO ", b);
    ui.force = 1;
}

static void track_defaults_steps(track_t *t)
{
    uint32_t i;
    motion_reset(t);
    for (i = 0; i < NSTEP; i++)
        step_clear(&t->step[i]);
}

/* the track's settings, not the sound's: what a sound load (factory or user preset, an engine jump,
 * CLEAR INIT) leaves alone. The mix (LEVEL, PAN, MUTE: the TRACKS faders), the arpeggiator (ARP, ARP 2),
 * the scale and key map (SCL), the sequence parameters (LEN, DIV, SWING, GATE; 1.2: QUANTIZE) and the SLICER
 * insert, which chops whatever the track plays in time with its sequencer */
static int param_kept(uint32_t i)
{
    return i == P_LEVEL || i == P_PAN || i == P_MUTE || (i >= P_AMODE && i <= P_SGATE) ||
           (i >= P_SLCR && i <= P_SLDEPTH) || i == P_CHRD || i == P_VOIC || i == P_SQNT;
}

/* browsing: SAMPLE aliases (TRANH, PERC) are skipped; they still load as their original (SMP_SET_ORIG) */
static uint32_t preset_orig(const engine_t *e, uint32_t k)
{
    return e->presets == SMP_PRESET_TABLE && k < SMP_NSETS ? SMP_SET_ORIG[k] : k;
}
/* the presets of engine e that browsing shows before preset k (k = npresets: all of them) */
static uint32_t preset_rank(const engine_t *e, uint32_t k)
{
    uint32_t i, n = 0;
    if (e->presets != SMP_PRESET_TABLE)
        return k;
    for (i = 0; i < k && i < e->npresets; i++)
        n += preset_orig(e, i) == i;
    return n;
}
#define preset_shown(e) (ENGINES[e]->npresets - (ENGINES[e]->presets == SMP_PRESET_TABLE ? SMP_NALIAS : 0u))
/* the index of engine e's n-th preset that browsing shows (n < preset_shown(e)), the aliases skipped */
static uint32_t preset_nth(uint32_t e, uint32_t n)
{
    uint32_t k;
    for (k = 0; preset_orig(ENGINES[e], k) != k || n--; k++)
        ;
    return k;
}

static void set_engine_of(track_t *t, uint32_t ei);
/* preset pi of the engine the track asked for: the sound only (not the steps, not param_kept) */
static void apply_preset_to(track_t *t, uint32_t pi)
{
    const engine_t *e = ENGINES[t->eng_req % NENGINES];
    uint32_t i;
    /* SAMPLE preset 4 was PERC (GM kit): load as DRUM (core.h drum_from_perc), not PIANO */
    if (t->eng_req % NENGINES == ENGI_SAMPLE && pi % (e->npresets ? e->npresets : 1u) == SMP_SET_PERC) {
        set_engine_of(t, ENGI_DRUM);
        return;
    }
    if (eng_retired(t->eng_req % NENGINES)) {
        set_engine_of(t, eng_play_as(t->eng_req % NENGINES));
        return;
    }
    load_begin(t, UNDO_SOUND);
    panic_req |= (uint8_t)(1u << trk_index(t));       /* MONO/POLY may change: release what sounds */
    t->user = 0;
    if (t == TSEL)
        sync_reload = 1;
    if (!e->npresets) {
        load_end(t);
        return;
    }
    pi = preset_orig(e, pi % e->npresets);
    t->preset = (uint8_t)pi;
    for (i = 0; i < P_E0; i++)                        /* the rest of the sound to its defaults: a preset */
        if (!param_kept(i))                           /* sounds the same after any edit */
            t->p[i] = TP[i].def;
    memset(t->mx, 0, sizeof t->mx);                   /* (matrix slots 5..8: OFF, as the defaults of 1..4) */
    if (t->eng_req % NENGINES == ENGI_ANALOG) {       /* OSC 2: the FM3 slots are MORPH / DRIFT, 0 at preset */
        t->p[P_MORPH] = 0;
        t->p[P_DRIFT] = 0;
    }
    for (i = 0; i < 8u; i++)
        t->p[P_E0 + i] = (int16_t)e->presets[pi].e[i];
    t->p[P_ATK] = e->presets[pi].env[0];
    t->p[P_DEC] = e->presets[pi].env[1];
    t->p[P_SUS] = e->presets[pi].env[2];
    t->p[P_REL] = e->presets[pi].env[3];
    t->p[P_ED_FLT] = e->presets[pi].fenv;
    t->p[P_VOICE] = e->presets[pi].mono ? V_LEGATO : V_POLY;   /* mono presets keep the legato feel */
    {   /* Keep the default DIST drive; the old FX() DIST amount is not a stage mix. */
        static const uint8_t FX_DEF[4] = {0, 24, 28, 36};
        const preset_t *pr = &e->presets[pi];
        for (i = 1; i < 4u; i++)
            t->p[P_DIST + i] = (int16_t)(pr->fx[i] ? pr->fx[i] - 1 : FX_DEF[i]);
        preset_mods(t, preset_mod(e, pi));            /* (JIANT V10.6i) its movement: LFO, MOD */
    }
    fm6_track_loaded(t);                              /* FM6: the preset's patch (its SLOT) */
    load_end(t);
}

/* the engine's defaults and its first preset. With the audio IRQ off: the ISR sees the old engine with
 * its values or the new one with its own (voice.c engine_block), never one with the other's */
static void set_engine_of(track_t *t, uint32_t ei)
{
    const engine_t *e = ENGINES[ei % NENGINES];
    uint32_t i;
    if (eng_retired(ei % NENGINES)) {               /* SLICE (retired): DRUM */
        set_engine_of(t, eng_play_as(ei % NENGINES));
        return;
    }
    if (!eng_ok(ei % NENGINES))                     /* DIGITAL: reserved, no conversion (silent stub) */
        return;
    load_begin(t, UNDO_SOUND);
    fm1_irq_off();
    t->eng_req = (uint8_t)(ei % NENGINES);
    for (i = 0; i < 8u; i++)
        t->p[P_E0 + i] = e->edit[i].def;
    apply_preset_to(t, 0);
    fm1_irq_on();
    load_end(t);
}

/* (JIANT 0.8.1) another track playing DRUM-X (1 + its index; 0 none): the project has one kit, theirs */
static uint32_t drum_elsewhere(const track_t *t)
{
    uint32_t k;
    for (k = 0; k < NTRK; k++)
        if (&trk[k] != t && trk[k].eng_req % NENGINES == ENGI_DRUM)
            return k + 1u;
    return 0;
}
static void apply_preset(uint32_t pi)                 /* the selected track's sound (browsing, the editor) */
{
    load_begin(TSEL, UNDO_SOUND);
    apply_preset_to(TSEL, pi);
    if (TSEL->eng_req % NENGINES == ENGI_DRUM) {      /* (JIANT 0.7.2) DRUM-X: the preset is a factory kit, into the
                                                       * project's kit (drumx_voice.c DX_KITS; a project load or an
                                                       * engine switch keeps the kit: apply_preset_to alone) */
        uint32_t o = drum_elsewhere(TSEL);
        if (!o) {
            fm1_irq_off();                            /* (the ISR reads the kit: one whole kit or the other) */
            dx_kit_load(pi % ENG_DRUM.npresets);
            undo.what |= UNDO_KIT;
            fm1_irq_on();
        } else {                                      /* the kit is shared: another track's stays as it is */
            static char m[16] = "KIT OF T? KEPT";
            m[8] = (char)('0' + o);
            ui_message(m);
        }
    }
    load_end(TSEL);
}
static void set_engine(uint32_t ei) { set_engine_of(TSEL, ei); }

/* MIDI Program Change (1.5.1, #179 by renebohne): program n on track t, as the PRESETS list numbers the engine's sounds
 * from 0: its n-th preset, the aliases skipped (preset_orig), loaded as from there (the track's own settings kept, one
 * undo for a run of them). DRUM-X: its factory presets (the knobs; the kit stays, as in JIANT: browsing loads kits). FM6: its presets
 * (F1..F15), then the voice bank's B1..B32 through SLOT as the knob loads them (fm6_poll; the rest of the sound stays),
 * an empty one ignored. A program past the last is ignored, not wrapped: a number is always the same sound */
static volatile uint8_t *const mpc_io = ui.mpc;
static volatile int8_t *const cc_step = ui.cc_step;   /* midi_control.c cc_step: CC 71..74's detents */
static void midi_pc_load(track_t *t, uint32_t n)
{
    uint32_t e = t->eng_req % NENGINES;
    if (n >= preset_shown(e)) {
        int32_t s = (int32_t)(FM6_OWN + 1u + n - preset_shown(e));
        if (e == ENGI_FM6 && fm6_bank_slot(s) >= 0 && fm6_slot_ok(s))
            t->p[P_E7] = (int16_t)s;
        return;
    }
    apply_preset_to(t, preset_nth(e, n));
}
static void midi_pc_poll(void)                       /* main loop (ui_input) */
{
    uint32_t k, v;
    for (k = 0; k < NTRK; k++) {
        if (!ui.mpc[k])
            continue;
        fm1_irq_off();                               /* (the ISR may note another meanwhile) */
        v = ui.mpc[k];
        ui.mpc[k] = 0;
        fm1_irq_on();
        midi_pc_load(&trk[k], v & 127u);
        ui.force = 1;
    }
}

static void track_defaults(track_t *t)
{
    uint32_t i;
    for (i = 0; i < P_E0; i++)
        t->p[i] = TP[i].def;
    memset(t->mx, 0, sizeof t->mx);               /* matrix slots 5..8 OFF */
    t->scl_stash_ok = 0;                          /* MAP defaults OFF: no link, no stash */
    t->fx_sl_pos = 8;                            /* EFFECTS: SLICER last until moved */
    t->generation = GENERATION_DEFAULT;
    track_defaults_steps(t);
}

/* SAVE > CLEAR > FX: a track's inserts, order, sends and slicer to their defaults (sound and steps stay) */
static void clear_fx_track(track_t *t)
{
    uint32_t i;
    for (i = P_DIST; i <= P_REV; i++)
        t->p[i] = TP[i].def;
    for (i = P_SLCR; i <= P_SLDEPTH; i++)
        t->p[i] = TP[i].def;
    for (i = P_IORD; i <= P_IHMIX; i++)
        t->p[i] = TP[i].def;
    t->p[P_ED_FX] = TP[P_ED_FX].def;                /* DIST TONE, an edit parameter on the DISTORT page */
    t->fx_sl_pos = 8;
    memset(fx_order_tbl[t - trk], 0, FX_LIST_N);
}
/* SAVE > CLEAR > ALL / ALL4: the mix (LEVEL PAN PLAY) and the arp (MODE .. ORD) to their defaults, so a cleared
 * track sounds at its own level, unmuted, and no latched HOLD chord keeps playing. A preset load keeps both
 * (param_kept): this is the clear asking for them back */
static void clear_mix_arp(track_t *t)
{
    uint32_t i;
    t->p[P_LEVEL] = TP[P_LEVEL].def;
    t->p[P_PAN] = TP[P_PAN].def;
    t->p[P_MUTE] = TP[P_MUTE].def;
    for (i = P_AMODE; i <= P_AORDER; i++)
        t->p[i] = TP[i].def;
    t->ahold_sv = t->p[P_AHOLD];                /* DRONE forces HOLD on: it restores this on the way out */
}

/* SAVE > CLEAR > FX ALL: every track's FX, MASTER, the shared SEND knobs and the global FX settings */
static void clear_fx_all(void)
{
    uint32_t i, k;
    for (i = G_DTIME; i <= G_DREL; i++)
        song.g[i] = GP[i].def;
    song.g[G_TDROP] = GP[G_TDROP].def;
    for (i = G_CLIP; i <= G_TTEMPO; i++)
        song.g[i] = GP[i].def;
    for (k = 0; k < NTRK; k++)
        clear_fx_track(&trk[k]);
    memset(fx_master_tr, 0, sizeof fx_master_tr);
    fx_master_order_tr = 0;
    fx_master_sanitize();
    for (i = 0; i < FX_LIST_N; i++)
        fx_master_reset_stage(i);
    fx_bus_init();
}

/* RAM as a clean boot (BOOT RESTORE off): default globals, sounds, empty (or factory) steps, song chain.
 * Flash, user bank and autosave stay. Power-on / main.c felucca_init. */
static void session_defaults(void)
{
    uint32_t i;
    chain_defaults(&chain_config);
    for (i = 0; i < G_COUNT; i++)
        song.g[i] = GP[i].def;
    undo_depth++;
    fm6_init();
    for (i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        track_defaults(t);
        set_engine_of(t, TRK_DEF[i][0]);
        apply_preset_to(t, TRK_DEF[i][1]);
        t->engine = t->eng_req;
        eng_mem_claim(t);
        track_defaults_steps(t);
        t->nheld = 0;
        t->arp_phys = 0;
    }
    undo_depth--;
    undo.trk = 0;
    song.sel = 0;
    ui.song_row = 0;
    ui.force = 1;
}

/* switch engine (its defaults + first preset) and say so */
static void select_engine(uint32_t e)
{
    set_engine(e);
    ui_say("ENGINE ", ENGINES[TSEL->eng_req]->name);
    ui.force = 1;
}

/* the presets of every engine (in ENGINE_ORDER), then the used user presets, as one list (the PRESETS knob and
 * the PRESETS page browse it) */
static uint32_t preset_all_pos(uint32_t *total)          /* list index of the selected track's preset */
{
    uint32_t n = 0, cur = 0, e, r;
    for (r = 0; r < NENG_SHOWN; r++) {                  /* (engines.c ENGINE_ORDER) */
        const engine_t *en = ENGINES[e = eng_vis(r)];
        if (e == TSEL->eng_req && !TSEL->user)
            cur = n + preset_rank(en, preset_orig(en, TSEL->preset % (en->npresets ? en->npresets : 1u)));
        n += preset_shown(e);
    }
    if (user_of(TSEL) < UP_SLOTS)
        cur = n + up_rank(user_of(TSEL));
    *total = n + up_count();
    return cur;
}

/* list index n (< total) -> engine, *k its preset; NENGINES = user preset, *k its slot */
static uint32_t preset_all_at(uint32_t n, uint32_t *k)
{
    uint32_t e = 0, r;
    for (r = 0; r < NENG_SHOWN && n >= preset_shown(eng_vis(r)); r++)
        n -= preset_shown(eng_vis(r));
    if (r < NENG_SHOWN) {
        e = eng_vis(r);
        *k = preset_nth(e, n);
        return e;
    }
    *k = up_nth(n);
    return NENGINES;
}

/* PRESETS > LIST (KNOB 4): ALL, FAV (favorites.filter, as up to 1.1.5), or one category (1.2, Discussion #90: BASS ..
 * OTHER, category.c): the list mode 0 ALL, 1 FAV, 1 + CAT_* a category. The category is kept with the settings in a
 * byte no engine uses (ui_lcat: 0 = none; firmware before reads ALL there, and favorites.filter stays 0 / 1 for it, the
 * editor and backups); the PRESETS knob and page browse that list */
#define ui_lcat (favorites.factory[15][11])
#define LIST_N (1u + CAT_N)                              /* ALL FAV BASS LEAD PAD PLUCK KEYS DRUM FX OTHER */
static uint32_t list_mode(void) { return favorites.filter ? 1u : ui_lcat && ui_lcat < CAT_N ? 1u + ui_lcat : 0u; }
static void list_set(uint32_t m)
{
    favorites.filter = m == 1u;
    ui_lcat = (uint8_t)(m >= 2u && m < LIST_N ? m - 1u : 0u);
}
static const char *list_name(uint32_t m) { return m == 0u ? "ALL" : m == 1u ? "FAV" : CAT_NAME[(m - 1u) % CAT_N]; }
/* the category of list entry e, k (preset_all_at: NENGINES = user preset k) */
static uint32_t sound_cat(uint32_t e, uint32_t k)
{
    return e == NENGINES ? up_cat(k) : preset_cat(e, k);
}
static int list_keep(uint32_t e, uint32_t k)
{
    uint32_t m = list_mode();
    return m == 1u ? favorite_has(e, k) : m ? sound_cat(e, k) == m - 1u : 1;
}
/* the category of the sound track t plays: its user preset's, else its factory preset's (the NAME screen's default) */
static uint32_t track_cat(const track_t *t)
{
    uint32_t u = user_of(t);
    return u < UP_SLOTS ? up_cat(u) : preset_cat(t->eng_req % NENGINES, t->preset);
}

static uint32_t preset_pos(uint32_t *total)
{
    uint32_t all, current = preset_all_pos(&all), n = 0, pos = 0xFFFFFFFFu;
    if (!list_mode()) { *total = all; return current; }
    for (uint32_t i = 0; i < all; i++) {
        uint32_t k, e = preset_all_at(i, &k);
        if (!list_keep(e, k)) continue;
        if (i == current) pos = n;
        n++;
    }
    *total = n;
    return pos == 0xFFFFFFFFu ? n : pos; /* current sound need not be in the list */
}
static uint32_t preset_at(uint32_t n, uint32_t *k)
{
    uint32_t all;
    if (!list_mode()) return preset_all_at(n, k);
    preset_all_pos(&all);
    for (uint32_t i = 0; i < all; i++) {
        uint32_t e = preset_all_at(i, k);
        if (list_keep(e, *k) && !n--) return e;
    }
    *k = UP_SLOTS;
    return NENGINES;
}
static int preset_favorite(void)
{
    uint32_t k = user_of(TSEL);
    return favorite_has(k < UP_SLOTS ? NENGINES : TSEL->eng_req,
                                        k < UP_SLOTS ? k : TSEL->preset);
}
/* #197: a settings change made by a knob (PRESETS > LIST, the FAV mark on PRESETS and in the EDIT layer) is written
 * later, as MENU's are when it closes: a write erases a flash sector with the interrupts off (~40 ms), which stops the
 * LED scan (every LED but one column's goes dark: a flash of the whole panel) and the audio. Written once the view it
 * was made in is left (another page, HOME, a layer opened or let go, the MENU) or after SET_LATER_MS without panel
 * input (ui.c scrn.idle; the autosave's wait), never on every detent; settings_poll still waits for the transport */
#define SET_LATER_MS 10000u
static struct { uint8_t on, page, home, layer; } set_later __attribute__((unused));   /* (.bss as before) */
static void settings_later(void)
{
    set_later.on = 1;
    set_later.page = ui.page;
    set_later.home = ui.home;
    set_later.layer = ui.layer;
}
static void settings_later_poll(void)                  /* ui_input, every pass */
{
    if (set_later.on && (set_later.page != ui.page || set_later.home != ui.home || set_later.layer != ui.layer ||
                         ui.menu || fm1_ms - scrn.idle >= SET_LATER_MS)) {
        set_later.on = 0;
        settings_save();
    }
}
static void preset_mark(int on)
{
    uint32_t k = user_of(TSEL);
    if (favorite_set(k < UP_SLOTS ? NENGINES : TSEL->eng_req, k < UP_SLOTS ? k : TSEL->preset, on)) {
        ui.force = 1;
        settings_later();
    }
}

static void preset_go(uint32_t n)                    /* load list index n into the selected track (the sound only) */
{
    uint32_t k, e = preset_at(n, &k);
    if (e == NENGINES) {
        up_load(k);
    } else {
        if (e != TSEL->eng_req)
            select_engine(e);
        apply_preset(k);
    }
}

/* the EDIT layer's KNOB 2 (ui_layer.c): the selected track's engine only: its factory presets, then the used user presets
 * made with it (slot order). List index of the current sound; *total the length */
static uint32_t eng_list_pos(uint32_t *total)
{
    const engine_t *en = ENGINES[TSEL->eng_req % NENGINES];
    uint32_t e = TSEL->eng_req % NENGINES, np = preset_shown(e), u = user_of(TSEL), k, n = 0;
    uint32_t cur = np ? preset_rank(en, preset_orig(en, TSEL->preset % en->npresets)) : 0u;   /* (#124: the aliases
                                        * skipped, as on PRESETS: SAMPLE 1 loads as 0, so counting it stuck KNOB 2) */
    for (k = 0; k < UP_SLOTS; k++)
        if (up_used(k) && up_engine(k) == e) {
            if (k == u)
                cur = np + n;
            n++;
        }
    *total = np + n;
    return cur;
}

static void eng_list_step(int32_t direction)         /* the next / previous sound of the engine (wraps) */
{
    uint32_t total, cur = eng_list_pos(&total), e = TSEL->eng_req % NENGINES, np = preset_shown(e), k, n;
    if (total < 2u)
        return;
    n = (cur + (direction > 0 ? 1u : total - 1u)) % total;
    if (n < np) {
        apply_preset(preset_nth(e, n));
    } else {
        n -= np;
        for (k = 0; k < UP_SLOTS; k++)
            if (up_used(k) && up_engine(k) == e && !n--) {
                up_load(k);
                break;
            }
    }
}

static void preset_step(int32_t direction)
{
    uint32_t total, cur = preset_pos(&total);
    if (!total) { ui_message(list_mode() == 1u ? "NO FAVORITES" : "NO SOUNDS IN LIST"); return; }
    preset_go(cur >= total ? (direction > 0 ? 0 : total - 1) :
              (cur + (direction > 0 ? 1u : total - 1u)) % total);
}

/* Seven display rows. FAV and a category use a bounded window, not a repeating carousel.
 * Return total for an empty row; a current sound not in the list shows the start. */
static uint32_t preset_visible(uint32_t cur, uint32_t total, uint32_t row)
{
    uint32_t first, last;
    if (!total || row >= 7u) return total;
    if (!list_mode())
        return (cur + total * 4u + row - 3u) % total;
    first = cur < total && cur > 3u ? cur - 3u : 0u;
    last = total > 7u ? total - 7u : 0u;
    if (first > last) first = last;
    return first + row < total ? first + row : total;
}

/* HOME: the track KNOB k edits (MENU > HOME LEVELS, 1.5: track k; else the selected one) and what: the engine's four
 * main parameters, or (LEVELS) the track's LEVEL, as the GLO layer's knobs */
static track_t *home_trk(uint32_t k) { return home_levels() ? &trk[k & 3u] : TSEL; }
static const param_desc_t *home_param(uint32_t k, int16_t **vp)
{
    uint32_t id = home_levels() ? (uint32_t)P_LEVEL : ENGINES[TSEL->eng_req % NENGINES]->knob[k & 3u];
    *vp = &home_trk(k)->p[id];
    return track_desc(home_trk(k), id);
}

/* select track i (KNOB 1 on TRACKS, the editor): its sound, pages and pattern from now on */
static void track_select(uint32_t i)
{
    if (i >= NTRK || i == song.sel)
        return;
    midi_bend_card_track(i);                     /* (the old channel's card bend goes back to centre) */
    song.sel = (uint8_t)i;
    ui.entry_open = 0;
    ui.hot_t = 0;
    ui.ev_keep = 0;                              /* (AUTOMATION: a row kept at its default was the other track's) */
    ui.cursor = 0;
    ui.bank = 0;
    sync_reload = 1;
    ui.force = 1;
}

#include "ui_events.c"                            /* SEQ > AUTOMATION: locks, events, CHANCE, RATCH as a list (an action page) */
/* EDIT > SOUND / TONE / MOVEMENT (ui_dx.c, included by ui_input.c): the DRUM-X sound edited and its patch */
static uint8_t dx_ui_lane, dx_ui_side;
static uint32_t dx_pagen(const page_t *pg)            /* "SOUND" -> 1; "TONE" -> 2; "MOVEMENT" -> 3 */
{
    return str_eq(pg->title, "TONE") ? 2u : str_eq(pg->title, "MOVEMENT") ? 3u : 1u;
}
static void dx_knob(const page_t *pg, uint32_t k, int32_t s);
static void dx_cards(const page_t *pg);
static uint32_t dx_sig(void);
/* ---------------------------------------------------- action pages --- */
/* Pages whose purpose is an action (SAVE > USER, PROJECT, SEQ > AUTOMATION): the knobs pick,
 * OCT+ does it, OCT- cancels the picked action or goes HOME (ui_input.c). There OCT- / OCT+ do not
 * shift the octave */
static int go_id(uint32_t id) { return id == G_LOAD || id == G_SAVE; }

static uint32_t act_cols(void)                   /* the columns that are actions, a bit each; 0 = not such a page */
{
    const page_t *pg = cur_page();
    uint32_t c, m = 0;
    if (ui.home)
        return 0;
    if (pg->graph == GR_EVENTS) return 16u;     /* AUTOMATION: no knob is an action; OCT+ by the row (ev_oct) */
    if (pg->graph == GR_SONG)
        return 1u;                               /* PLAY / STOP (also the PLAY button) */
    if (pg->graph == GR_USER)
        return 14u;                              /* LOAD ERASE SAVE */
    if (pg->scope == SC_GLOBAL)
        for (c = 0; c < 4u; c++)
            if (go_id(pg->id[c]))
                m |= 1u << c;
    return m;
}

/* the action OCT+ does: its column + 1, 0 = none picked yet */
static uint32_t act_col(void)
{
    if (!ui.home && cur_page()->graph == GR_SONG) return 1u;
    if (!ui.home && cur_page()->graph == GR_EVENTS) return 5u;
    return ui.act;
}

static const char *act_name(uint32_t c)          /* column c's action (the footer hint) */
{
    static const char *const UP_GO[3] = {"LOAD", "ERASE", "SAVE"};
    uint32_t id = cur_page()->id[c & 3u];
    if (cur_page()->graph == GR_EVENTS) return ev_act_name();
    if (cur_page()->graph == GR_SONG)
        return song.playing || chain_busy() ? "STOP" : "PLAY";
    if (cur_page()->graph == GR_USER)
        return UP_GO[(c + 2u) % 3u];
    return id == G_LOAD ? "LOAD" : "SAVE";
}

/* the picked action would do something now (OCT+ breathes): a used slot, stopped for
 * a flash write, steps to clear */
static int act_ready(void)
{
    uint32_t c = act_col(), id;
    if (!c--)
        return 0;
    if (cur_page()->graph == GR_EVENTS) return ev_act_ready();
    if (cur_page()->graph == GR_SONG)
        return song.playing || chain_busy() || chain_config.count;
    if (cur_page()->graph == GR_USER)
        return c == 3u ? !song.playing : up_used(ui.uslot) && (c == 1u || !song.playing);
    id = cur_page()->id[c & 3u];
    if (id == G_LOAD)
        return project_used((uint32_t)song.g[G_SLOT] - 1u);
    if (id == G_SAVE)
        return !song.playing;
    return 1;
}
