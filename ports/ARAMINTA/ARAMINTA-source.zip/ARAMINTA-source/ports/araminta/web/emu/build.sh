#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
# Felucca in the browser: the firmware's sources as the host tests build them (web/emu/felucca_web.c), compiled
# to WebAssembly with Emscripten, plus the page. After X0X's web/emu/build.sh (charlesvestal/fm1-x0x, GPL-3.0).
#   web/emu/build.sh   ->  build/emu/{index.html, worklet.js, saves.js, fm1backup.js, projconv.js, version.json,
#                              felucca.wasm, fonts/}
#   A preview build sets EMU_BUILD / EMU_SHA (the site's dev preview uses "dev"): the page then names the build,
#   warns that it shares the live emulator's saves and keeps a copy before its firmware can migrate them
#   (web/emu/saves.js).
#   build/emu/worklet.js is web/emu/store.js + web/emu/rec.js (each "export " stripped) in front of web/emu/worklet.js:
#   the browser loads it with AudioWorklet.addModule, which compiles a classic script, so it may not contain a
#   top-level "export". store.js / rec.js are the modules the tests and web/emu/replay.mjs import; edit them there.
# Run after one ./build.sh (build/gen: the tables, the fonts, the CC0 samples).
# -ffp-contract=off: no fused multiply-adds, as the host build. EMU_OPT replaces -O2, EMU_CFLAGS adds flags
# (EMU_CFLAGS=-msimd128: let the compiler vectorise; every browser with AudioWorklet has wasm SIMD).
# The page shows the version (FELUCCA_VERSION) marked "(preview)" before its release; EMU_PREVIEW=0 drops the mark.
# Reruns skip what has not changed: the wasm (firmware sources, build/gen, felucca_web.c, flags, emcc; key in
# build/emu/.wasm-key) and the page files (index.html, store.js, rec.js, worklet.js, fonts; build/emu/.page-key), so
# editing the page does not recompile the wasm.
set -e
cd "$(dirname "$0")/../.."
[ -f build/gen/felucca_tables.h ] || { echo "emu: run ./build.sh once first (build/gen)"; exit 1; }
command -v emcc >/dev/null 2>&1 || { echo "emu: no emcc (Emscripten)"; exit 1; }
VERSION=$(sed -n 's/^#define FELUCCA_VERSION "\([^"]*\)".*/\1/p' firmware/src/felucca.c)
EMU_BUILD="${EMU_BUILD:-}"
EMU_SHA="${EMU_SHA:-}"
mkdir -p build/emu/fonts

hash_inputs() { # hash_inputs <meta> <file or dir>...: sha256 of the meta and every file under the paths
    h_meta=$1
    shift
    EMU_META=$h_meta python3 - "$@" <<'EOF'
import hashlib, os, pathlib, sys
h = hashlib.sha256(os.environ["EMU_META"].encode() + b"\0")
for arg in sys.argv[1:]:
    p = pathlib.Path(arg)
    for f in sorted([p] if p.is_file() else [q for q in p.rglob("*") if q.is_file()]):
        h.update(str(f).encode() + b"\0" + f.read_bytes() + b"\0")
print(h.hexdigest())
EOF
}

WASM_KEY=$(hash_inputs "$(emcc --version | head -1)|${EMU_OPT:--O2}|${EMU_CFLAGS:-}|$VERSION" \
    firmware/src firmware/hal build/gen web/emu/felucca_web.c web/emu/build.sh)
# the page bakes HASH, which covers the wasm too: a firmware-only change must still rewrite the page, or its asset
# URLs keep pointing at the previous build
PAGE_KEY=$(hash_inputs "$VERSION|${EMU_PREVIEW:-1}|$EMU_BUILD|$EMU_SHA|$WASM_KEY" \
    web/emu/index.html web/emu/saves.js web/emu/store.js web/emu/rec.js web/emu/worklet.js web/fm1backup.js web/projconv.js \
    web/emu/fonts)
# asset URLs carry this: a rebuilt page asks for a different felucca.wasm / worklet.js / saves.js / font, so a cached
# copy cannot outlive the build that made it (GitHub Pages serves max-age=600; a hard reload alone did not always win).
HASH=$(python3 -c 'import hashlib,sys; print(hashlib.sha256(sys.argv[1].encode()).hexdigest()[:8])' "$WASM_KEY|$PAGE_KEY")
printf '{"hash":"%s","version":"%s"}\n' "$HASH" "$VERSION" > build/emu/version.json

WASM_OK=0
[ -f build/emu/.wasm-key ] && [ "$(cat build/emu/.wasm-key)" = "$WASM_KEY" ] && [ -f build/emu/felucca.wasm ] && WASM_OK=1
PAGE_OK=0
if [ -f build/emu/.page-key ] && [ "$(cat build/emu/.page-key)" = "$PAGE_KEY" ] &&
   [ -f build/emu/index.html ] && [ -f build/emu/worklet.js ] && [ -f build/emu/saves.js ] &&
   [ -f build/emu/fm1backup.js ] && [ -f build/emu/projconv.js ] &&
   [ -f build/emu/fonts/DotGothic16-subset.woff ] &&
   [ -f build/emu/fonts/OFL.txt ]; then
    PAGE_OK=1
fi
if [ "$WASM_OK" = 1 ] && [ "$PAGE_OK" = 1 ]; then
    echo "emu: build/emu unchanged ($VERSION, $(wc -c < build/emu/felucca.wasm | tr -d ' ') B wasm)"
    exit 0
fi

if [ "$WASM_OK" = 0 ]; then
    # shellcheck disable=SC2086
    emcc ${EMU_OPT:--O2} -ffp-contract=off -std=gnu99 -w ${EMU_CFLAGS:-} \
        "-DFELUCCA_VERSION=\"$VERSION\"" -Ibuild/gen -Ifirmware/src \
        --no-entry -sSTANDALONE_WASM -sSTACK_SIZE=1048576 -sINITIAL_MEMORY=33554432 -sFILESYSTEM=0 \
        -o build/emu/felucca.wasm web/emu/felucca_web.c
    echo "$WASM_KEY" > build/emu/.wasm-key
fi

if [ "$PAGE_OK" = 0 ]; then
    if [ "${EMU_PREVIEW:-1}" = 0 ]; then PREVIEW=''
    elif [ -n "$EMU_BUILD" ]; then PREVIEW=" (preview · $EMU_BUILD${EMU_SHA:+, $EMU_SHA})"
    else PREVIEW=' (preview)'
    fi
    sed -e "s/@VERSION@/$VERSION/g" -e "s/@PREVIEW@/$PREVIEW/g" \
        -e "s/@BUILD@/$EMU_BUILD/g" -e "s/@SHA@/$EMU_SHA/g" -e "s/@HASH@/$HASH/g" \
        web/emu/index.html > build/emu/index.html
    { sed 's/^export //' web/emu/store.js; echo; sed 's/^export //' web/emu/rec.js; echo; cat web/emu/worklet.js; } > build/emu/worklet.js
    cp web/emu/saves.js build/emu/saves.js
    sed "s#\"./projconv.js\"#\"./projconv.js?v=$HASH\"#" web/fm1backup.js > build/emu/fm1backup.js
    cp web/projconv.js build/emu/projconv.js
    cp web/emu/fonts/DotGothic16-subset.woff web/emu/fonts/OFL.txt build/emu/fonts/
    echo "$PAGE_KEY" > build/emu/.page-key
fi
echo "emu: build/emu ($(wc -c < build/emu/felucca.wasm | tr -d ' ') B wasm, $VERSION)"