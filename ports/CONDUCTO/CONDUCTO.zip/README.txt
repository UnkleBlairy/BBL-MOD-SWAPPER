CONDUCTOR 1.0 for the BBL Mod Swapper

Original by MammothCheese: https://github.com/MammothCheese/conductor
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: CONDUCTO-source.zip on the ports page.
