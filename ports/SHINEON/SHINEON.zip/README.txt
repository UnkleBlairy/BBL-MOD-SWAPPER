Shine On 3.5 for the BBL Mod Swapper

Original by zvenson: https://github.com/zvenson/shineon
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: SHINEON-source.zip on the ports page.
