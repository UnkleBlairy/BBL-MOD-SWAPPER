Frodhes 0.9.14 for the BBL Mod Swapper

Original by leonardoMirabal: https://github.com/leonardoMirabal/frodhes
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: FRODHES-source.zip on the ports page.
