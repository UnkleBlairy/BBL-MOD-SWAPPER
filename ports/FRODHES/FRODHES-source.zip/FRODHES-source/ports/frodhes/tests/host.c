/* SPDX-License-Identifier: GPL-3.0-only */
/* A fake FM-1 (or SMK-37) on a computer: the app (firmware/src/frodhes.c) runs unchanged on it. platform.c includes
 * this file instead of the hardware when DINGHY_HOST is set. A script presses keys over time; out come
 * the screen (PPM, at the times SHOT asks) and the sound (WAV, as the FM-1 sends it over USB).
 *
 *   mkdir -p build/host
 *   cc -O2 -Wall -DDINGHY_HOST -Ifirmware/src -Ifirmware/gen -o build/host/frodhes firmware/src/frodhes.c -lm
 *   build/host/frodhes build/host/frodhes      (-> build/host/frodhes.wav, build/host/frodhes-<ms>.ppm)
 *   build/host/frodhes OUT script.txt [FPS]   (your own script; with FPS: OUT-NNNNN.ppm, a frame every 1/FPS s:
 *                                             a film of your firmware, e.g. ffmpeg -r 30 -i OUT-%05d.ppm ...)
 *   -DBOARD_SMK37=1 -DFR_VOICES=7u (BOARD=smk37 tests/run_host.sh, make test-smk): the SMK-37 build: its keys with
 *                                             velocity, the outer keys, pads, faders, wheels, the pedal
 *
 * Change SCRIPT below to try your own app. */
#include <stdint.h>
#include <math.h>

#ifndef APP_NAME
#define APP_NAME "DINGHY"
#endif
#ifndef APP_VER
#define APP_VER "0.0"
#endif
#define FS 44100u
#ifndef HALF_FRAMES
#define HALF_FRAMES 256u                        /* (the app may set it: frodhes.c FR_LAT_HALF) */
#endif

static volatile uint32_t fm1_ms;
#if BOARD_SMK37
/* the SMK-37 (hal/smk_input.h's API, the part the app may use): the 37 keys with velocity (keys 5..31 are the FM-1's
 * 27 note keys: fm1_in.notes), the outer keys (0..4, 32..36) and the pads as events, 4 faders, 2 wheels, the pedal;
 * 18 buttons, 8 encoders (K1 = MASTER, smk_master); the pad LEDs (lcd.c padled_*). What smk_input.h does not have
 * (the FM-1's TRS flag, its LED duty and groups) the app gives itself (frodhes_smk.h), so it is not here */
#define FM1_NKEY 37u
#define FM1_NBTN 18u
#define FM1_NENC 8u
#define SMK_NPAD 16u
#define SMK_KEY_F3 5u
static struct {
    uint32_t notes, buttons, frames, adc_ok, adc_miss;
    uint64_t keys;
    uint8_t key_vel[FM1_NKEY], fader[4], pad_press[SMK_NPAD];
    uint16_t wheel[2], pedal, batt, pad_raw[SMK_NPAD], pad_base[SMK_NPAD];
} fm1_in = {.wheel = {535, 620}, .pedal = 985};   /* (the wheels at rest, no pedal: as a unit reads them) */
static uint8_t smk_pad_events, smk_pad_piano, smk_pad_grid;   /* (smk_input.h: the pads as events / layouts) */
static uint16_t smk_pad_pick;
static int32_t smk_master = 724;               /* (smk_input.h: K1 as the MASTER pot) */
static int32_t host_q[2][64];                   /* 0: pad events, 1: outer keys (key << 8 | velocity, 0 = release) */
static uint32_t host_qw[2], host_qr[2];
static void host_qput(int i, int32_t v) { host_q[i][host_qw[i]++ % 64u] = v; }
static int32_t host_qtake(int i) { return host_qr[i] == host_qw[i] ? -1 : host_q[i][host_qr[i]++ % 64u]; }
static int32_t smk_pad_take(void) { return host_qtake(0); }
static int32_t smk_extkey_take(void) { return host_qtake(1); }
static uint32_t host_pick;
static uint32_t smk_pick_take(void) { uint32_t h = host_pick; host_pick = 0; return h; }
/* a pad hit (v) or let go (0), as smk_input.h smk__padq: an event when the app takes the pads (smk_pad_events), a pick
 * (smk_pad_pick), else a note key: the white keys F3..G5 (low row 8..15 = F3..E4), or the piano layout */
static const uint8_t HOST_WHITE[SMK_NPAD] = {0, 2, 4, 6, 7, 9, 11, 12, 14, 16, 18, 19, 21, 23, 24, 26};
static const int8_t HOST_PIANO[SMK_NPAD] = {7, 9, 11, 12, 14, 16, 18, 19, 8, 10, -1, 13, 15, 17, -1, 20};
static uint8_t host_pad_note[SMK_NPAD];
static void host_pad(uint32_t p, uint32_t v)
{
    int32_t n;
    p &= 15u;
    if (smk_pad_events) { host_qput(0, (int32_t)(p << 8 | v)); return; }
    if (v && (smk_pad_pick >> p & 1u)) { host_pick |= 1u << p; return; }
    if (v) {
        n = smk_pad_piano ? HOST_PIANO[p] : (int32_t)HOST_WHITE[smk_pad_grid ? p : p < 8u ? p + 8u : p - 8u];
        if (n < 0) return;
        host_pad_note[p] = (uint8_t)(n + 1);
        fm1_in.key_vel[SMK_KEY_F3 + (uint32_t)n] = (uint8_t)v;
        fm1_in.notes |= 1u << n;
    } else if (host_pad_note[p]) {
        fm1_in.notes &= ~(1u << (host_pad_note[p] - 1u));
        host_pad_note[p] = 0;
    }
}
static uint32_t padled_rgb[SMK_NPAD];           /* as lcd.c: g << 16 | r << 8 | b */
static void padled_set(uint32_t pad, uint8_t r, uint8_t g, uint8_t b) { if (pad < SMK_NPAD) padled_rgb[pad] = (uint32_t)g << 16 | (uint32_t)r << 8 | b; }
static void padled_flush(void) {}
static volatile uint8_t smk_led_dark;           /* (smk_input.h: the button LEDs' brightness) */
static uint8_t smk_store_cleared, smk_trim_ok = 1;   /* (platform.c: what the panel check shows) */
static uint32_t smk_jedec = 0x204016u;
static const char *host_xlat(const char *s);    /* frodhes_smk.h: an FM-1 text in the SMK's words (ui.c ui_text) */
#else
static struct { uint32_t notes, buttons; } fm1_in;
#endif

/* teensy-fm1: the panel and the screen are the Teensy's */
static uint32_t din_press, din_rel, din_nedge, din_px;
static int32_t din_enc[8];
static uint8_t din_led[64], din_glow[64];
static uint32_t fm1_input_edges(uint32_t *released) { uint32_t b = din_press; din_press = 0; if (released) *released = din_rel; din_rel = 0; return b; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = din_nedge; din_nedge = 0; return e; }
static int32_t fm1_enc_take(uint32_t e) { int32_t v = din_enc[e & 7u]; din_enc[e & 7u] = 0; return v; }
static void fm1_led_key(uint32_t id, int on) { din_led[id & 63u] = (uint8_t)!!on; }
static void fm1_led_key_glow(uint32_t id, int on) { din_glow[id & 63u] = (uint8_t)!!on; }
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            sh_put(j * 240u + i, sh_be16(c));
    din_px += w * h;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            sh_put((y + j) * 240u + x + i, px[j * w + i]);      /* (gfx.c's pixels are high byte first already) */
    din_px += w * h;
}
static uint32_t host_edges, host_released;
static int32_t host_enc[8];
static uint8_t host_led[64];                    /* the last state each LED id was set to */

   /* (the script sets fm1_in.notes) */


static volatile uint8_t usb_pre_master;          /* platform.c: USB audio before MASTER (no USB here) */
#if !BOARD_SMK37
static volatile uint8_t uart_midi_on = 1;        /* midi_uart.c: the TRS input ("T trs ...": dropped while 0) */
static uint8_t fm1_led_duty[2] = {16u, 16u};   /* hal/fm1_input.h: the lit duty of the keys and the buttons, /16 (DISPLAY BRIGHTNESS) */
static void fm1_led_group_ids(uint32_t id0, uint32_t id1) { (void)id0; (void)id1; }   /* (which LEDs are the keys: the hardware's) */
static void fm1_led_build(void) {}               /* (the scan ISR's tables: the hardware's) */
#endif
static uint8_t host_glow[64];                   /* the dim layer (fm1_led_key_glow) */


/* the screen: 240 x 240 RGB565, as the ST7789 gets it (gfx.c sends the bytes swapped) */
#define fb shl_fb
static void host_ms(void);
/* FRODHES_LCDMS=N: each lcd_sync lasts N ms (the FM-1 waits there for a strip's DMA, up to ~20 ms at 12 MHz): the
 * clock, the script and the audio run on meanwhile, and the app's LCD_IDLE (frodhes.c app_idle) once a millisecond */



#define CV_MAX (240u * 64u)
#include "gfx.c"

/* Every erase and write the firmware makes (the record here, the pattern in seq.c)
 * goes through host_fl_check first: the place must pass the firmware's own allow-list (FL_GUARD: store.h with
 * frodhes_store.h's APP_FL_RANGE, hal/fm1_flash_map.h) and lie in the board's store (frodhes_store.h: the record
 * A / B and the pattern, in no stock region), else a FAIL line, the call fails as on the device, and the run fails.
 * So every script checks the flash safety of a board we cannot try (BOARD=smk37); FRODHES_FLASHLOG=1 prints every
 * call. */
#define HOST_FL_CHECK 1
#include "store.h"
static uint32_t host_fails, host_fl_calls;
static int host_fl_check(const char *what, uint32_t at, uint32_t n)
{
    int in_store = FL_IN(at, n, SETTINGS_AT, SQ_B + 0x1000u);   /* (frodhes_store.h: the record A / B, the pattern) */
    host_fl_calls++;
    if (!FL_GUARD(at, n) || !in_store) {
        printf("%6u ms  FAIL flash %s 0x%05X + %u: %s\n", fm1_ms, what, at, n,
               !FL_GUARD(at, n) ? "refused by the allow-list (FL_GUARD)" : "outside the store");
        host_fails++;
        return -1;
    }
    if (getenv("FRODHES_FLASHLOG")) printf("%6u ms  flash %s 0x%05X + %u ok\n", fm1_ms, what, at, n);
    return 0;
}

static uint8_t host_usb_link = 1;                /* "T usblink 0": the USB cable out (frodhes.c usb_link) */
static uint8_t host_usb_rec;                    /* "T usbrec 1": a computer reads the USB audio (nothing reads it since the split flash erase) */
/* The flash (1 MiB, erased): the firmware's own store code runs on it (set_store.c: the record, the settings then the
 * user presets, in two sectors written in turn; seq.c's pattern; presets.c and the migration read the places before
 * 0.9.6, frodhes_store.h OLD_*). Every erase and program passes host_fl_check. An erase takes HOST_SAVE_MS - 10 ms
 * of the part's time (the main loop going on), a page program the next pass: a record's save ~100 ms, as on the
 * FM-1 (a split erase of ~85 ms and its page programs). settings_save (the held one: a preset save, the migration)
 * lets the milliseconds go by (the audio ISR, the script's MIDI into the queue) without the app's loop, so a note
 * sent meanwhile is taken late, as on the device. */
#define HOST_SAVE_MS 100u
static uint8_t host_mem[0x100000];
static uint8_t flash_ok = 1;
static uint8_t host_old_ours = 1;               /* (SMK: the owner tag before 0.9.6 is Frodhes'; FRODHES_SMK_STOCK=1: not) */
static __attribute__((unused)) int smk_old_ours(void) { return host_old_ours; }
static void fm1_wdt_feed(void) {}
static uint32_t crc32(const uint8_t *p, uint32_t n);   /* presets.c (host) */
#ifdef FL_XIP_OFF_WAIT                          /* (frodhes.c FR_LAT_TAIL: the flash leaves XIP only with the tail done) */
static void host_xip_check(void);
static void host_ms(void);
static void host_xip_isr(void)                  /* FRODHES_ISR_AT_FLASH=1: the FM-1's audio interrupt may come just
                                                 * before any flash call (the host renders only between main-loop
                                                 * passes otherwise): a millisecond here, its half buffers rendered */
{
    static int on = -1, in;
    if (on < 0) on = getenv("FRODHES_ISR_AT_FLASH") && atoi(getenv("FRODHES_ISR_AT_FLASH"));
    if (on && !in) { in = 1; host_ms(); in = 0; }
}
#ifdef HOST_XIP_NOWAIT                          /* (tests/py/test_latency.py: the check without the wait: it fires) */
#define HOST_XIP() do { host_xip_isr(); host_xip_check(); } while (0)
#else
#define HOST_XIP() do { host_xip_isr(); FL_XIP_OFF_WAIT(); host_xip_check(); } while (0)
#endif
#else
#define HOST_XIP() ((void)0)
#endif
static int st_read(uint32_t off, void *dst, uint32_t n)
{
    HOST_XIP();
    if (off >= sizeof host_mem || n > sizeof host_mem - off) return -1;
    memcpy(dst, host_mem + off, n);
    return 0;
}
static uint32_t host_op_t, host_op_ms;
static int fl_op_start(uint32_t off, const uint8_t *src, uint32_t n)   /* src: a page program, 0: an erase */
{
    uint32_t i;
    HOST_XIP();
    if (host_fl_check(src ? "write settings" : "erase settings", off, src ? n : 0x1000u)) return -1;
    if (src) for (i = 0; i < n; i++) host_mem[off + i] &= src[i];   /* (NOR: a program clears bits only) */
    else memset(host_mem + off, 0xFF, 0x1000u);
    host_op_t = fm1_ms; host_op_ms = src ? 0u : HOST_SAVE_MS - 10u;
    return 1;
}
static int fl_op_poll(void) { HOST_XIP(); return fm1_ms - host_op_t < host_op_ms ? 1 : 0; }
static void platform_poll(void);
#define ST_SAVED() printf("%6u ms  settings saved (%u B)\n", fm1_ms, 256u)
#define ST_WAIT() platform_poll()               /* (a held save: one millisecond a step) */
static int area_load(uint32_t at, uint32_t max, uint32_t magic, void *p, uint32_t n)   /* (platform.c's) */
{
    uint32_t h[3];
    if (!flash_ok || n > max || st_read(at, h, sizeof h) || h[0] != magic || h[1] != n || st_read(at + sizeof h, p, n))
        return -1;
    return crc32(p, n) == h[2] ? 0 : -1;
}
#define SET_SS_BSS
#include "set_store.c"

/* The flash across power cycles: with FRODHES_FLASH=FILE the run starts from FILE's flash (if it exists) and writes
 * the flash back at its end, so a second run is the unit switched on again. Only what the firmware saved is there.
 * FILE is the store's 4 KiB sectors in this order (HOST_SECS; each as the flash holds it, platform.c's formats):
 *   [0] the settings before 0.9.6 (256 B; on the FM-1 the record's A: the same sector), [1] [2] the preset bank A / B
 *   before 0.9.6 (presets.c), [3] [4] the pattern A / B before 0.9.6 (seq.c), then the record's B (FM-1; SMK: A, B)
 *   and the pattern (FM-1: one sector; SMK: A, B).
 * A shorter file (0.9.5's five sectors) leaves the rest erased: 0.9.5's flash, which the first boot migrates. */
#if BOARD_SMK37
static const uint32_t HOST_SECS[] = {OLD_SET_A, OLD_PR_A, OLD_PR_B, OLD_SQ_A, OLD_SQ_B, SETTINGS_AT, SETTINGS_B, SQ_A, SQ_B};
#else
static const uint32_t HOST_SECS[] = {OLD_SET_A, OLD_PR_A, OLD_PR_B, OLD_SQ_A, OLD_SQ_B, SETTINGS_B, SQ_A};
_Static_assert(OLD_SET_A == SETTINGS_AT && OLD_SET_B == SETTINGS_B && SQ_A == SQ_B, "host: the FM-1's flash file");
#endif
#define HOST_NSEC (sizeof HOST_SECS / sizeof HOST_SECS[0])
static void host_flash_load(const char *path)
{
    static uint8_t img[HOST_NSEC][4096];
    size_t got;
    uint32_t i;
    FILE *f = fopen(path, "rb");
    if (!f) return;                             /* no file: a new unit (nothing saved) */
    memset(img, 0xFF, sizeof img);
    got = fread(img, 1, sizeof img, f);
    fclose(f);
    if (got % 4096u || got < 5u * 4096u) { fprintf(stderr, "%s: flash image of %u B\n", path, (unsigned)got); exit(2); }
    for (i = 0; i < HOST_NSEC; i++) memcpy(host_mem + HOST_SECS[i], img[i], 4096);
}
static void host_flash_save(const char *path)
{
    static uint8_t img[HOST_NSEC][4096];
    uint32_t i;
    FILE *f;
    for (i = 0; i < HOST_NSEC; i++) memcpy(img[i], host_mem + HOST_SECS[i], 4096);
    if (!(f = fopen(path, "wb")) || fwrite(img, 1, sizeof img, f) != sizeof img) { perror(path); exit(2); }
    fclose(f);
}

static uint8_t mq[64][4];                       /* status, data 1, data 2, source (1 USB, 2 TRS) */
static uint32_t mq_w, mq_r;
static int midi_get(uint8_t *st, uint8_t *d1, uint8_t *d2)   /* 1 (USB) or 2 (TRS), as platform.c's; 0: none */
{
    int src;
    if (mq_r == mq_w) return 0;
    *st = mq[mq_r % 64u][0]; *d1 = mq[mq_r % 64u][1]; *d2 = mq[mq_r % 64u][2]; src = mq[mq_r % 64u][3];
    mq_r++;
    return src;
}
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2) { printf("%6u ms  MIDI out %02X %u %u\n", fm1_ms, st, d1, d2); }

static void app_audio(int32_t *out, uint32_t n);
static void app_main(void);
