# Frodhes

**An electric piano, vibraphone and marimba, computed live, for the M-VAVE FM-1, the Ableton Move, the Akai MPC and your
computer.**

No samples: every note is calculated as you play it, from how the real instrument works. A hammer strikes a tine
and a pickup turns its motion into sound; a mallet strikes a bar and its tube rings along. Play softly and it is
warm; play hard and it barks or rings.

Frodhes is free. If you enjoy it, you can [buy me a coffee](https://ko-fi.com/leomirabal).

<table align="center">
  <tr>
    <td align="center" width="50%"><img src="docs/manual/img/piano.png?v=d6338298" width="100%" alt="Frodhes on the FM-1: the FRODHES page, four cards for the four knobs"><br><b>On the M-VAVE FM-1</b>: colour screen, four knobs</td>
    <td align="center" width="50%"><img src="docs/manual/img/move/move-frodhes.png?v=630fd25b" width="100%" alt="Frodhes on the Move: the first page, eight cards for the eight knobs"><br><b>On the Ableton Move</b>: its own screen, eight knobs</td>
  </tr>
  <tr>
    <td align="center" width="50%"><img src="docs/manual/img/plugin/plugin-main.png?v=a6729600" width="100%" alt="The desktop plugin's window: the VOICE knobs, two effect sections and a keyboard"><br><b>On your computer</b>: a plugin with its own window</td>
    <td align="center" width="50%"><img src="docs/manual/img/mpc/mpc-voice.png?v=ab028bbc" width="100%" alt="Frodhes on the Akai MPC: the VOICE page, two panels of four knobs"><br><b>On the Akai MPC</b>: its own pages, the Q-Links</td>
  </tr>
</table>

**[Try it in your browser](https://leonardomirabal.github.io/frodhes/)** before you install: the same firmware, with
the FM-1's screen, knobs and keys. Play it from your computer keyboard or a MIDI keyboard.

## What you get

- **Seven instruments**: five electric pianos (STAGE 77, SUITCASE, EARLY FELT, BELL DYNO and WHURLI, a reed piano with
  a growl on hard strikes), a vibraphone with its motor (VIBES) and a marimba (MARIMBA).
- **Effects**: compressor, 3-band EQ, drive with five overdrive types, resonant filter with its own LFO, tremolo /
  pan / wah, phaser, chorus, delay (digital, analog, tape) and reverb (hall, plate, infinite).
- **For playing**: sustain pedal, velocity from the FM-1's own keys, chords, scales, arpeggiator, a pattern recorder
  (1-16 bars, overdub, undo, a chance per step), tap tempo or MIDI clock.
- **Connections**: MIDI over USB and the TRS input, pitch bend, audio over USB (to a computer, phone or tablet) as well as the headphone jack.
- **Presets**: 23 factory sounds and 16 slots for your own.
- **A screen you can read**: one page at a time, one card per knob.

What is new in each version: [the release notes](https://github.com/leonardoMirabal/frodhes/releases).

## Install on the FM-1

1. Download [`frodhes.fwsc`](https://github.com/leonardoMirabal/frodhes/releases/latest/download/frodhes.fwsc).
   This link always gives the newest version.
2. Connect the FM-1 with USB and install it from the browser (Chrome or Edge): open the
   [emulator page](https://leonardomirabal.github.io/frodhes/#install) and use **Install on your FM-1 or SMK-37**.
   Or from a terminal, in a copy of this repository:
   ```sh
   pip install mido python-rtmidi
   python3 tools/fm1_install.py frodhes.fwsc
   ```
3. If something goes wrong, switch the FM-1 off, hold **OCT−** and switch it on. This starts the USB rescue, and
   you can install again from there.

**Both cores.** Frodhes runs the voices on one of the FM-1's two processor cores and the effects on the other:
14 voices on every instrument, the reverb at the full sample rate, and a quick answer to a note (about 6.5 ms from
MIDI to the headphone jack). `frodhes.fwsc` is the FM-1's only package; installing it over the one-core package of
0.9.10 or 0.9.11 keeps your settings, presets and pattern.

Your settings and presets stay when you update. 0.9.10 changes the factory presets and some of their program numbers
(four new, four gone, SUIT TREM now F08), and the WHURLI presets came in as F20-F23, with your own U01-U16 after
them: [the list](docs/MANUAL.md#6-presets). You can always go back to M-VAVE's own
firmware:
[how](docs/MANUAL.md#going-back-to-the-original-firmware).

## Where to find Frodhes

| Where | What it is |
|---|---|
| [The Firmware Hub](https://thefirmwarehub.com/#fw-frodhes) | The FM-1's firmware catalogue: install and update from one place |
| [mutant.cloud](https://mutant.cloud/#/p/frodhes) | Install over USB-MIDI in the browser, no account needed |
| [fm1-editor.com](https://fm1-editor.com/firmware/#frodhes) | The community's firmware list with pictures |
| altstrument: [FM-1 and SMK-37](https://altstrument.org/firmware/m-vave-fm-1/frodhes), [Move](https://altstrument.org/firmware/ableton-move/frodhes) | The community catalogue of alternative firmware and modules, with every Frodhes version |
| [Schwung catalog](https://schwung.dev/catalog.html?filter=sound_generator) | The Move's module catalog: install and update Frodhes on the Move with Schwung Manager |
| [Open MPC](https://open-mpc.github.io/#q=frodhes) | The community's Akai MPC plugin catalogue: install and update Frodhes on the MPC with its Plugin Manager |
| [Web emulator](https://leonardomirabal.github.io/frodhes/) | Play Frodhes in the browser before you install it |

Questions, bugs or ideas: [issues](https://github.com/leonardoMirabal/frodhes/issues). The community's own place is
[r/MVaveFM1](https://www.reddit.com/r/MVaveFM1/).

## On the Ableton Move

Frodhes runs on the Move as a sound generator in Schwung, the community module host for the Move.

- The same instruments and effects, with 16 voices on every instrument and the higher-quality version of each.
- The reverb runs at the full sample rate, so its tails keep their top octave.
- Its own screen: the eight knobs as eight cards, a page at a time.
- 61 factory presets (the FM-1's 23 plus 38 more, the Move's variants) and 16 slots for your own.
- The Move's sequencer, scales and tempo drive it. The arpeggiator is Frodhes' own.
- One Frodhes on each track, up to four, each with its own sound. Three play without dropouts.

Install it with Schwung Manager in a web browser: **Install Custom Module > From GitHub URL**, then
`leonardoMirabal/frodhes`, or the downloaded `frodhes-module.tar.gz` under **From Tarball**. Frodhes is also in
[Schwung's module catalog](https://schwung.dev/catalog.html?filter=sound_generator), so you can install and update it from there. The steps, and every page:
[docs/MOVE.md](docs/MOVE.md).

<p align="center">
  <img src="docs/manual/img/move/move-drive-filter.png?v=18fa53cf" width="384" alt="The DRIVE/FILTER page on the Move: eight cards, each with its name, its value and a bar">
  <img src="docs/manual/img/move/move-pages.png?v=7f4bde0a" width="384" alt="The list of pages on the Move">
</p>

## On your computer: the desktop plugin

Frodhes also runs in your music software as an instrument plugin: CLAP and VST3 on macOS, Windows and Linux, and an
Audio Unit on macOS.

- The same instruments, effects and factory sounds, computed by the same engine. It plays the higher-quality
  version of every instrument and effect, with 24 voices. The drive's first type is **WARM**, the plugin's own
  overdrive, in place of the FM-1's FDRV.
- Its own window: the FM-1's pages as cards with knobs, resizable. Presets, MIDI learn, the effects' bypass and the
  sustain latch are in it, and everything is saved with your project.
- The host's tempo drives the synced effects. Any sample rate. Up to 16 instances in one project.
- When a newer Frodhes is out, it downloads your system's package into Downloads, checks its SHA-256, and shows an
  INSTALL key on the window that opens it (macOS: Installer; Windows / Linux: the zip's folder). Close your music
  software, then install. It asks GitHub at most once a day while its window is open and installs nothing itself;
  SETTINGS > UPDATES OFF turns it off ([details](docs/PLUGIN.md#check-for-updates)).
- macOS 11 or newer (Apple silicon or Intel), Windows x64, Linux x86_64 or aarch64 (glibc 2.31 or newer). Nothing
  else to install.

**macOS.** Download
[`frodhes-plugin-macos.pkg`](https://github.com/leonardoMirabal/frodhes/releases/latest/download/frodhes-plugin-macos.pkg)
and open it: it installs the three formats into your own Library. The plugin is not signed by Apple yet, so macOS
refuses it the first time: right-click the file and choose **Open** (or System Settings > Privacy & Security >
**Open Anyway**). Or download
[`frodhes-plugin-macos.zip`](https://github.com/leonardoMirabal/frodhes/releases/latest/download/frodhes-plugin-macos.zip)
and copy the format your host uses into its folder (create the folder if it is not there; in the Finder,
**Go > Go to Folder...** and paste the path):

| Format | File | Folder |
| --- | --- | --- |
| CLAP | `Frodhes.clap` | `~/Library/Audio/Plug-Ins/CLAP/` |
| VST3 | `Frodhes.vst3` | `~/Library/Audio/Plug-Ins/VST3/` |
| Audio Unit | `Frodhes.component` | `~/Library/Audio/Plug-Ins/Components/` |

Then clear the download flag once, in Terminal:

```sh
xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/*/Frodhes.*
```

**Windows.** Download
[`frodhes-plugin-windows.zip`](https://github.com/leonardoMirabal/frodhes/releases/latest/download/frodhes-plugin-windows.zip).
It is not signed yet: before you extract it, right-click it, **Properties**, tick **Unblock**. Copy `Frodhes.clap`
into `C:\Program Files\Common Files\CLAP\` and `Frodhes.vst3` into `C:\Program Files\Common Files\VST3\`.

**Linux.** Download
[`frodhes-plugin-linux-x86_64.zip`](https://github.com/leonardoMirabal/frodhes/releases/latest/download/frodhes-plugin-linux-x86_64.zip)
(or `-aarch64`) and copy `Frodhes.clap` into `~/.clap/` and `Frodhes.vst3` into `~/.vst3/`.

Then restart your music software, or let it rescan its plugins: it appears as **Frodhes**, an instrument. For the
Audio Unit, `killall -9 AudioComponentRegistrar` in Terminal (or a restart of the Mac) makes macOS see it at once.
To remove it, delete the `Frodhes.*` files again. More:
[the manual](docs/MANUAL.md#17-appendix-the-desktop-plugin).

<p align="center">
  <img src="docs/manual/img/plugin/plugin-presets.png?v=6d4d2636" width="384" alt="The plugin's PRESETS list: every factory and user sound, grouped by instrument">
  <img src="docs/manual/img/plugin/plugin-effects.png?v=0564369e" width="384" alt="The plugin playing: the compressor and the tape delay on, their knobs and meters live">
</p>

## On the Akai MPC

Frodhes runs on Akai MPC standalone hardware as a plugin (checked by a tester on an MPC): the desktop plugin's engine,
16 voices on every instrument, the factory presets as programs, and the plugin's look on the MPC's screen: eight
pages of large knobs in panels of four, one Q-Link group each. It needs MPC OS 3.10.1 or later with External Plugin
Support on. Download [`frodhes-mpc.zip`](https://github.com/leonardoMirabal/frodhes/releases/latest/download/frodhes-mpc.zip) (or build it with `make mpc`), or install it from the [Open MPC catalogue](https://open-mpc.github.io/#q=frodhes) with its Plugin
Manager; how to install it and what to report:
[docs/MPC.md](docs/MPC.md).

<p align="center">
  <img src="docs/manual/img/mpc/mpc-voice.png?v=ab028bbc" width="384" alt="Frodhes on the MPC: the VOICE page">
  <img src="docs/manual/img/mpc/mpc-delay.png?v=7bc9cbad" width="384" alt="Frodhes on the MPC: the chorus and the delay">
</p>

## Manual

**[The user manual](docs/MANUAL.md)**: every page, knob and button, the presets, the effects and the MIDI map.

![The PERFORM, VOICE, PHASER and COMPRESSOR pages on the FM-1](docs/manual/img/overview.png?v=2dd409b4)

## Other keyboards

Frodhes also runs on the SMK-37 Pro, SMK-37 Elite and MKE-P37, with 10 voices on one processor core. Read
[docs/SMK37.md](docs/SMK37.md) before you install one.

The files on the [release page](https://github.com/leonardoMirabal/frodhes/releases/latest):

| Device | File |
| --- | --- |
| M-VAVE FM-1 | `frodhes.fwsc` |
| Ableton Move | `frodhes-module.tar.gz` |
| SMK-37 Pro | `frodhes-smk37-pro.fwsc` |
| SMK-37 Elite | `frodhes-smk37-elite.fwsc` |
| MKE-P37 | `frodhes-mke-p37.fwsc` |
| Desktop plugin, macOS | `frodhes-plugin-macos.pkg` or `frodhes-plugin-macos.zip` |
| Desktop plugin, Windows | `frodhes-plugin-windows.zip` |
| Desktop plugin, Linux | `frodhes-plugin-linux-x86_64.zip`, `frodhes-plugin-linux-aarch64.zip` |

## Credits

Frodhes is built on [Dinghy](https://github.com/zvenson/dinghy) by zvenson, which uses the platform of
[Felucca](https://github.com/hugelton/Felucca) by Leo Kuroshita (Hügelton Instruments) as
[SLOOP](https://github.com/isod89/sloop-fm1) by isod89 carries it. That platform handles updates, the USB rescue,
USB MIDI and audio, the panel, the screen and the settings. MIDI pitch bend is genkigenki's work
([PR #3](https://github.com/leonardoMirabal/frodhes/pull/3)). Key velocity on the FM-1's keys follows Charles
Vestal's [fm1-velocity](https://github.com/charlesvestal/fm1-velocity).

## For developers

How to build, test and contribute: [docs/BUILD.md](docs/BUILD.md) and [CONTRIBUTING.md](CONTRIBUTING.md).

The desktop plugin is built with `FR_OWN=1` (`make plugin`): it compiles only Frodhes' own code plus the pinned libraries ([docs/PLUGIN.md](docs/PLUGIN.md#build)).

## Support

Frodhes is free. If you enjoy it, you can [buy me a coffee](https://ko-fi.com/leomirabal).

## License and disclaimer

GPL-3.0-only, the same as Dinghy, Felucca and SLOOP ([LICENSING.md](LICENSING.md)). The licence covers the code,
not the Frodhes name and logo: a changed version you share needs its own name and logo
([LICENSING.md](LICENSING.md#the-frodhes-name-and-logo)).

Frodhes is an independent open-source project, not affiliated with or endorsed by M-VAVE,
Ableton, the Rhodes or Fender trademark owners or any instrument maker. It comes with no warranty: install it at your own risk.

You can also try Frodhes in the browser, no flashing needed, in the free community [FM-1 Emulator](https://fm1-emulator.atst.tools/).
