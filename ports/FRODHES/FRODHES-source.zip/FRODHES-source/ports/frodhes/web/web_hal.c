/* SPDX-License-Identifier: GPL-3.0-only */
/* The FM-1 in a web browser: platform.c includes this file instead of the hardware when DINGHY_WEB is set (with
 * DINGHY_HOST, so the rest of the code takes its host paths). The app (frodhes.c) runs unchanged, compiled to
 * WebAssembly with Emscripten (web/build.sh):
 *
 *   app_main()      runs as ever; platform_poll() hands the browser a turn (Asyncify: emscripten_sleep), so the
 *                   page stays alive and the clock (fm1_ms) follows the real time
 *   web_audio(n)    the audio ISR: JavaScript's audio callback asks for n blocks of 256 frames, each played as the
 *                   FM-1's I2S interrupts do (one of 256 frames, or two of 128 on the two-core image); the result is
 *                   in web_out (float, L R L R), MASTER applied
 *   web_btn / web_keys / web_enc / web_midi / web_master   the panel and USB-MIDI, from the page
 *   web_fb / web_leds / web_store                          the screen (RGB565), the LEDs, the settings record
 *
 * The settings and the user presets live in web_store (the page keeps it in the browser's localStorage); the
 * pattern stays in memory for the session. */
#include <stdint.h>

#ifndef APP_NAME
#define APP_NAME "DINGHY"
#endif
#ifndef APP_VER
#define APP_VER "web"
#endif
#define FS 44100u
#ifndef HALF_FRAMES                             /* (Frodhes: the app may set it, frodhes.c FR_LAT_HALF) */
#define HALF_FRAMES 256u
#endif

static volatile uint32_t fm1_ms;
static struct { uint32_t notes, buttons; } fm1_in;
/* teensy-fm1: the panel and the screen are the Teensy's */
static uint32_t din_press, din_rel, din_nedge, din_px;
static int32_t din_enc[8];
static uint8_t din_led[64], din_glow[64];
static uint32_t fm1_input_edges(uint32_t *released) { uint32_t b = din_press; din_press = 0; if (released) *released = din_rel; din_rel = 0; return b; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = din_nedge; din_nedge = 0; return e; }
static int32_t fm1_enc_take(uint32_t e) { int32_t v = din_enc[e & 7u]; din_enc[e & 7u] = 0; return v; }
static void fm1_led_key(uint32_t id, int on) { din_led[id & 63u] = (uint8_t)!!on; }
static void fm1_led_key_glow(uint32_t id, int on) { din_glow[id & 63u] = (uint8_t)!!on; }
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            sh_put(j * 240u + i, sh_be16(c));
    din_px += w * h;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            sh_put((y + j) * 240u + x + i, px[j * w + i]);      /* (gfx.c's pixels are high byte first already) */
    din_px += w * h;
}

static uint32_t host_edges, host_released;
static int32_t host_enc[8];
static uint8_t host_led[64];




static volatile uint8_t uart_midi_on = 1;        /* midi_uart.c: the TRS input (none here) */
static volatile uint8_t usb_pre_master;          /* platform.c: USB audio before MASTER (no USB here) */
static uint8_t fm1_led_duty[2] = {16u, 16u};   /* hal/fm1_input.h: the lit duty of the keys and the buttons, /16 (DISPLAY BRIGHTNESS) */
static void fm1_led_group_ids(uint32_t id0, uint32_t id1) { (void)id0; (void)id1; }   /* (which LEDs are the keys: the hardware's) */
static void fm1_led_build(void) {}               /* (the scan ISR's tables: the hardware's) */
static uint8_t host_glow[64];                   /* the dim layer (fm1_led_key_glow) */


/* the screen: 240 x 240 RGB565 (gfx.c sends the bytes swapped, as the ST7789 wants them) */
#define fb shl_fb



#define CV_MAX (240u * 64u)
#include "gfx.c"

/* the store (0.9.6): one record, the settings and the user presets (st_tail: presets.c pr_user), kept by the page
 * in localStorage. [0] 1 = saved, [1] 2 = 0.9.6's record (an older page's entry: the settings alone, 256 bytes, read
 * once by the migration, frodhes.c). The rest of the flash (the pattern; the places before 0.9.6, which stay empty
 * here) is in memory for the session (host_mem: seq.c and presets.c read it through st_read) */
#define HOST_SAVE_MS 100u                      /* (seq.c: the pattern's erase time, as tests/host.c) */
static uint8_t host_win[0x2000];   /* teensy-fm1: the pattern's two sectors, 0x99000 */
#define host_mem (host_win - 0x99000)
static uint8_t flash_ok = 1;
static int st_read(uint32_t off, void *dst, uint32_t n)
{
    if (off < 0x99000u || off + n > 0x9B000u) { memset(dst, 0xFF, n); return 0; }
    memcpy(dst, host_mem + off, n);
    return 0;
}
static uint8_t *st_tail;
static uint8_t web_store_buf[4 + 256 + ST_TAIL_N];
static uint8_t web_store_dirty;
static int settings_load(void *p, uint32_t n)
{
    if (web_store_buf[0] != 1 || web_store_buf[1] != 2 || n != 256u) return -1;
    memcpy(p, web_store_buf + 4, n);
    memcpy(st_tail, web_store_buf + 4 + 256, ST_TAIL_N);
    return 0;
}
static __attribute__((unused)) int settings_load_old(void *p, uint32_t n)
{
    if (web_store_buf[0] != 1 || web_store_buf[1] == 2 || n != 256u) return -1;
    memcpy(p, web_store_buf + 4, n);
    return 0;
}
static __attribute__((unused)) int smk_old_ours(void) { return 1; }
/* the ids of what is at the places before 0.9.6 (frodhes.c st_old_scan, set_store.c): the page has none there, so
 * every id is 0 and a record never takes anything again; set_at / set_seq only for the boot's re-take (never here) */
static __attribute__((unused)) uint32_t set_at, set_seq;
static __attribute__((unused)) uint32_t st_id(uint32_t crc, uint32_t seq)
{
    uint32_t v = crc ^ (seq * 0x9E3779B1u);
    return v ? v : 1u;
}
static __attribute__((unused)) uint32_t settings_old_id(void) { return 0; }
static int settings_save(const void *p, uint32_t n)
{
    if (n != 256u) return -1;
    web_store_buf[0] = 1; web_store_buf[1] = 2;
    memcpy(web_store_buf + 4, p, n);
    memcpy(web_store_buf + 4 + 256, st_tail, ST_TAIL_N);
    web_store_dirty = 1;
    return 0;
}
static int settings_save_start(const void *p, uint32_t n) { return settings_save(p, n); }   /* (at once: 0 done) */
static int settings_save_poll(void) { return 0; }
static __attribute__((unused)) int settings_check(void) { return 0; }

/* USB-MIDI in (Web MIDI or the page); MIDI out is dropped */
static uint8_t mq[64][3];
static uint32_t mq_w, mq_r;
#ifdef DINGHY_PLUGIN
/* the desktop plugin (plugin/src/slot_bridge.h): each message's place in the 256-frame block it lands in, in 1/256
 * of a sample (web_midi takes web_ofs_next; midi_get hands it on in fr_ev_ofs, 0 once the ring is empty, so the
 * events the main loop posts on its own, the arpeggiator's, the sequencer's, start at the block's start) */
static uint16_t mq_ofs[64];
static uint16_t web_ofs_next, fr_ev_ofs;
#endif
static int midi_get(uint8_t *st, uint8_t *d1, uint8_t *d2)
{
#ifdef DINGHY_PLUGIN
    if (mq_r == mq_w) { fr_ev_ofs = 0; return 0; }
    fr_ev_ofs = mq_ofs[mq_r % 64u];
#else
    if (mq_r == mq_w) return 0;
#endif
    *st = mq[mq_r % 64u][0]; *d1 = mq[mq_r % 64u][1]; *d2 = mq[mq_r % 64u][2];
    mq_r++;
    return 1;
}
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2) { (void)st; (void)d1; (void)d2; }

static void app_audio(int32_t *out, uint32_t n);
static void app_main(void);
