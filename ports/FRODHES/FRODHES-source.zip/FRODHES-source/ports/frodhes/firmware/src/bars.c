/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef FR_RAM
#define FR_RAM                                  /* (frodhes.c: the audio hot loops in RAM) */
#define FR_FAR(fn) fn
#endif
#ifndef FR_RAM2
#define FR_RAM2                                 /* (frodhes.c: more of them, the one-core FM-1 image) */
#define FR_FAR2(fn) fn
#endif
/* Frodhes bar engine: the code (its types, tables and state are in bars.h, included by engine.c). frodhes.c
 * includes this file last, after every other part of the app, so adding or growing an engine never moves or
 * re-inlines the Rhodes and effects code (measured: +150 us on the Rhodes worst case when bars.c sat before it). */

static int32_t bar_sat(int32_t v)
{
#ifdef DINGHY_HOST
    if (v > (1 << 28) - 1 || v < -((1 << 28) - 1)) bar_h_sat++;
#endif
    return sat28i(v);                               /* sat28's bounds, 32-bit compares (rhodes.c) */
}

/* ---- log2 in Q8 (a linear mantissa: within 0.09, 0.5 dB) and back; 32-bit shifts only */
static int32_t bar_log2_32(uint32_t v)
{
    int32_t p = 0;
    uint32_t t = v;
    if (!v) return BAR_LZERO;
    if (t >> 16) { t >>= 16; p += 16; }
    if (t >> 8) { t >>= 8; p += 8; }
    if (t >> 4) { t >>= 4; p += 4; }
    if (t >> 2) { t >>= 2; p += 2; }
    if (t >> 1) p += 1;
    return p * 256 + (int32_t)((p >= 8 ? v >> (p - 8) : v << (8 - p)) & 255u);
}
static int32_t bar_log2_64(uint64_t q)
{
    uint32_t hi = (uint32_t)(q >> 32), lo = (uint32_t)q;
    int32_t p, s;
    if (!hi) return bar_log2_32(lo);
    p = (bar_log2_32(hi) >> 8) + 32;
    s = p - 8;                                      /* >= 24 */
    return p * 256 + (int32_t)((s >= 32 ? hi >> (s - 32) : (hi << (32 - s)) | (lo >> s)) & 255u);
}
static int32_t bar_exp2(int32_t l)                  /* 2^(l / 256); 0 under 1 */
{
    int32_t i = l >> 8;
    uint32_t m = 256u + (uint32_t)(l & 255);
    if (l < 0) return 0;
    if (i >= 30) return 0x7FFFFFFF;
    return (int32_t)(i >= 8 ? m << (i - 8) : m >> (8 - i));
}

/* k p / 2^32 for a Q32 coefficient 0 <= k < 2^31 and |p| < 2^57, without losing p's low bits when p is small (the
 * products stay under 2^63) */
static int64_t bar_q32mul(int32_t k, int64_t p)
{
    int64_t a = p < 0 ? -p : p;
    if (a < (1ll << 31)) return ((int64_t)k * p) >> 32;
    if (a < (1ll << 47)) return ((int64_t)k * (p >> 16)) >> 16;
    return ((int64_t)k * (p >> 24)) >> 8;
}

/* a slot's log2 amplitude (Q8, Q25 units) from x[n], x[n-1]: x1^2 - a1 x1 x2 + a2 x2^2 (= (x1 - x2)^2 + c1 x1 x2 -
 * c2 x2^2) = A^2 sin^2(theta) for a damped sinusoid. Q32 form: the c terms on the products x1 x2 and x2^2 (rounding
 * c1 x1 first lost them on the low modes near the end: c1 x1 >> 32 is 0 for a 65 Hz mode under ~8 LSB out, and the
 * level read near 0 cut the voice at up to 7 LSB) */
static int32_t bar_lamp(const bar_ms_t *s)
{
    int64_t q;
    if (s->lo) {
        int32_t d = s->x1 - s->x2;
        q = (int64_t)d * d + bar_q32mul(s->k1, (int64_t)s->x1 * s->x2) - bar_q32mul(s->k2, (int64_t)s->x2 * s->x2);
    } else {
        int32_t c = (int32_t)(((int64_t)s->k1 * s->x2) >> 30), d = (int32_t)(((int64_t)s->k2 * s->x2) >> 30);
        q = (int64_t)s->x1 * (s->x1 - c) + (int64_t)s->x2 * d;
    }
    if (q <= 0) return BAR_LZERO;
    return (bar_log2_64((uint64_t)q) >> 1) - s->lsin;
}

static int32_t bar_sat31(int64_t v)
{
#ifdef DINGHY_HOST
    if (v > 0x7FFFFFFF || v < -0x7FFFFFFF) bar_h_sat++;
#endif
    return v > 0x7FFFFFFF ? 0x7FFFFFFF : v < -0x7FFFFFFF ? -0x7FFFFFFF : (int32_t)v;
}

/* (e, eps) -> the two-multiply form's coefficients and the force gain. A mode under ~4.9 kHz (c1 < 1/2) runs in Q32:
 * x' = 2x - xp + hi(err - c1 x + c2 xp), err = lo (the pole 4x finer than Q30, no shifts); above, in Q30:
 * x' = (err + a1 x - a2 xp) >> 30. The force: F << 12 times be = b e >> 30 (Q32) or >> 32 (Q30). */
static void bar_coefs(bar_ms_t *s)
{
    int64_t c1 = ((int64_t)s->eps << 2) + ((((int64_t)s->e * s->e) + (1 << 27)) >> 28);
    uint8_t lo = c1 < 0x7FFFFFFF;
    if (lo != s->lo) s->err = lo ? (int32_t)((uint32_t)s->err << 2) : (int32_t)((uint32_t)s->err >> 2);   /* rescale */
    s->lo = lo;
    if (lo) {
        s->k1 = (int32_t)c1;
        s->k2 = s->eps << 2;
        s->be = bar_sat31(((int64_t)s->b * s->e) >> 30);
    } else {
        s->k1 = (int32_t)(((int64_t)2 << 30) - s->eps - ((((int64_t)s->e * s->e) + (1 << 29)) >> 30));
        s->k2 = (1 << 30) - s->eps;
        s->be = bar_sat31(((int64_t)s->b * s->e) >> 32);
    }
}

/* log2 sin(theta), Q8, from the coefficients: sin^2 = 1 - a1^2 / (4 a2) */
static int32_t bar_lsin(const bar_ms_t *s)
{
    int64_t num;
    if (s->lo) {                                    /* (c1 - c2 - c1^2 / 4) / (1 - c2), in Q32 */
        num = (int64_t)s->k1 - s->k2 - (((int64_t)s->k1 * s->k1) >> 34);
        return num > 0 ? (bar_log2_64((uint64_t)num) - bar_log2_64((1ull << 32) - (uint32_t)s->k2)) >> 1 : 0;
    }
    num = ((int64_t)s->k2 << 32) - (int64_t)s->k1 * s->k1;
    return num > 0 ? (bar_log2_64((uint64_t)num) - bar_log2_32((uint32_t)s->k2) - 32 * 256) >> 1 : 0;
}

/* the bars' level into the mix (0.9.13, SND3; BAR_MIX_G: bars.h): one gain on the Q20 mix before the dithered cut
 * (bar_render), so the tone and the floor stay */
#define BAR_MIX(x) ((int32_t)(((int64_t)(x) * BAR_MIX_G + 16384) >> 15))
#define BAR_PZI(pb, f, l) (((pb) * BAR_NFAM + (f)) * BAR_NLAYER + (l))
static void bar_load_pulse(bar_voice_t *v, uint32_t vel)
{
    uint32_t ty = bar_sub < BAR_NTYPE ? bar_sub : 0u;   /* constant while the voice lives (engine.c C1) */
    uint32_t key = (uint32_t)(v->k - BAR_KP[ty]), fam = (uint32_t)bar_fam, f = fam >> 8, f2, l, l2, i;
    uint32_t pb = BAR_PBAND[v->k->band];               /* the key's pulse band (shared bank) */
    int32_t a = (int32_t)(fam & 255u), w, pa, pa2, pr, pr2;
    uint32_t vi = RH_VPOS_I[vel], vf = RH_VPOS_F[vel];
    if (f > BAR_NFAM - 1u) { f = BAR_NFAM - 1u; a = 0; }
    f2 = f + 1u < BAR_NFAM ? f + 1u : f;
    l = RH_VLAY_I[vel]; l2 = l + 1u < BAR_NLAYER ? l + 1u : l; w = RH_VLAY_W[vel];
    FR_FAR2(rh_pz)(v->pbuf, &BAR_PZB, BAR_PZI(pb, f, l));             /* hardness x velocity: one shape, once (the packed bank, rhodes.c
                                                     * rh_pz: the table's integers, so the same shape as before) */
    if (w) FR_FAR2(rh_pz_mix)(v->pbuf, &BAR_PZB, BAR_PZI(pb, f, l2), w);   /* A = p11 + ((p12 - p11) w >> 15): an int16 */
    if (a) {                                        /* B likewise, then A + ((B - A) a >> 8) (a 0: A) */
        int16_t b[BAR_PLEN + 2];
        FR_FAR2(rh_pz)(b, &BAR_PZB, BAR_PZI(pb, f2, l));
        if (w) FR_FAR2(rh_pz_mix)(b, &BAR_PZB, BAR_PZI(pb, f2, l2), w);
        for (i = 0; i < BAR_PLEN + 2u; i++) v->pbuf[i] = (int16_t)(v->pbuf[i] + (((b[i] - v->pbuf[i]) * a) >> 8));
    }
    {
        const uint16_t (*PA)[RH_NANCH] = BAR_PAMP[ty][key];
        const uint16_t *PR0 = BAR_PRU[BAR_PRATE_I[ty][key][f]], *PR1 = BAR_PRU[BAR_PRATE_I[ty][key][f2]];   /* (the distinct rows) */
        pa = (int32_t)PA[f][vi] + ((((int32_t)PA[f][vi + 1] - (int32_t)PA[f][vi]) * (int32_t)vf) >> 8);
        pa2 = (int32_t)PA[f2][vi] + ((((int32_t)PA[f2][vi + 1] - (int32_t)PA[f2][vi]) * (int32_t)vf) >> 8);
        pr = (int32_t)PR0[vi] + ((((int32_t)PR0[vi + 1] - (int32_t)PR0[vi]) * (int32_t)vf) >> 8);
        pr2 = (int32_t)PR1[vi] + ((((int32_t)PR1[vi + 1] - (int32_t)PR1[vi]) * (int32_t)vf) >> 8);
    }
    pa += ((pa2 - pa) * a) >> 8;
    pr += (int32_t)(((int64_t)(pr2 - pr) * a) >> 8);
    v->prate = (uint32_t)(((uint64_t)((uint32_t)pr << 4) * (uint32_t)bar_mass) >> 12);   /* Q12 -> Q16, x mass */
    if (!v->prate) v->prate = 1u;
    pa = (int32_t)(((int64_t)pa * bar_massi) >> 12);
    v->pamp = pa > 32767 ? 32767 : pa < 0 ? 0 : pa;
    v->ptab = v->pbuf;
    v->ppos = 0;
    v->pred = 0;                                    /* the slots' strike levels: predicted only if the budget asks */
}

/* the strike's level in each slot, before it sounds (for the mode budget): the mode's amplitude after a short force
 * pulse is |u(theta)| / cos(theta / 2), u the pulse's spectrum at the mode (u = F b >> 20 a sample). The table's 66
 * points are played Delta = 2^16 / prate samples apart, so |u| = |b| / 2^20 x pamp / 2^15 x Delta x |P(theta Delta)|,
 * P the table's spectrum (Goertzel, 66 MACs). A mode over half the table's point rate gets nothing. */
static void bar_predict(bar_voice_t *v)
{
    uint32_t m, dq = 0xFFFFFFFFu / v->prate;        /* Delta, Q16 */
    int32_t lp = bar_log2_32((uint32_t)v->pamp) + bar_log2_32(dq) - (16 + 35) * 256;
    v->pred = 1;
    for (m = 0; m < BAR_NM; m++) {
        bar_ms_t *s = &v->m[m];
        const rh_mode_t *km = BAR_KM(v->k, m);
        uint64_t tpe;
        uint32_t ph, i, k;
        int32_t c, s1 = 0, s2 = 0, l;
        int64_t q;
        s->lpred = BAR_LZERO;
        if (!s->live || !s->b || m == 1u) continue;
        /* turns per sample (Q32) = theta / 2 pi = th 4 / pi (th = theta / 2, Q30), then per table point */
        tpe = ((((uint64_t)(uint32_t)km->th * 1367130551u) >> 30) * dq) >> 16;
        if (tpe >= 0x80000000u) continue;           /* over half the point rate: nothing to speak of */
        ph = (uint32_t)tpe;
        i = ph >> 22;                               /* 2 pi ph in 512 steps over [0, pi) */
        c = i < 256u ? BAR_MOT_COS[i] : -BAR_MOT_COS[512u - i];   /* cos, Q15 = 2 cos in Q14 */
        for (k = 0; k < BAR_PLEN + 2u; k++) {
            int32_t s0 = v->pbuf[k] + (int32_t)(((int64_t)c * s1) >> 14) - s2;
            s2 = s1; s1 = s0;
        }
        q = (int64_t)s1 * s1 + (int64_t)s2 * s2 - (((int64_t)c * s1) >> 14) * s2;
        if (q <= 0) continue;
        l = (bar_log2_64((uint64_t)q) >> 1) + bar_log2_32((uint32_t)(s->b < 0 ? -s->b : s->b)) + lp
          - (bar_log2_32((uint32_t)km->ch) - 30 * 256);
        s->lpred = (int16_t)(l < -32767 ? -32767 : l > 32767 ? 32767 : l);
    }
#ifdef DINGHY_HOST
    if (bar_h_pred) for (m = 0; m < BAR_NM; m++) v->m[m].fresh |= 2u;   /* report it after the first block */
#endif
}

/* a card's level compensation (BAR_POSG / BAR_TUBEG of one band, Q14): the 17 points at q = raw 4096 / 127 for
 * the family fm and the next, blended by the MALLET fraction fa (Q8), as the pulse */
static int32_t bar_card_gain(const uint8_t *ix, uint32_t fm, int32_t fa, uint32_t q)   /* ix: the band's row index per family */
{
    uint32_t i = q >> 8, f2 = fm + 1u < BAR_NFAM ? fm + 1u : fm;
    const uint16_t *t0 = BAR_GROW[ix[fm]], *t1 = BAR_GROW[ix[f2]];   /* (the distinct rows: bars_pack.h) */
    int32_t fr = (int32_t)(q & 255u), g0, g1;
    if (i >= BAR_NPOS - 1u) { g0 = t0[BAR_NPOS - 1u]; g1 = t1[BAR_NPOS - 1u]; }
    else {
        g0 = t0[i] + ((((int32_t)t0[i + 1u] - (int32_t)t0[i]) * fr) >> 8);
        g1 = t1[i] + ((((int32_t)t1[i + 1u] - (int32_t)t1[i]) * fr) >> 8);
    }
    return g0 + (((g1 - g0) * fa) >> 8);
}

/* the contact noise's level for this mallet (Q15): BAR_FAM_NZ blended by the MALLET fraction, as the pulse */
static int32_t bar_fam_nz(void)
{
    uint32_t f = (uint32_t)bar_fam >> 8, f2;
    int32_t a = (int32_t)((uint32_t)bar_fam & 255u);
    if (f > BAR_NFAM - 1u) { f = BAR_NFAM - 1u; a = 0; }
    f2 = f + 1u < BAR_NFAM ? f + 1u : f;
    return BAR_FAM_NZ[f] + (((BAR_FAM_NZ[f2] - BAR_FAM_NZ[f]) * a) >> 8);
}

#ifdef FR_HQ
#include "hq/bars_hq.c"                            /* the HQ bars (the Move only) */
#endif

/* RESPONSE on the bars (0.9.10, the coordinator: no knob that does nothing): a level map. A (FULL, rh_touch_mode 0)
 * leaves the strike as it was, byte-identical; B (LIGHT) lifts every strike under v127 by BAR_LT_DB a velocity step
 * (0.07 dB; 7 and below as 7): +8.4 dB at v7, 0 at v127, so the span is 8.4 dB less and the level still rises with the
 * velocity. 0.9.10 to 0.9.12 lifted the soft end by the electric piano's old FULL soft end instead (+9 dB at v20,
 * 0 from v60), which fell faster than the bars' own level rises (A: 0.08..0.2 dB a step, every key, MALLET, WEIGHT,
 * TUBE, NOISE): VIBES came out up to 1.3 dB softer from v24 to v40. The strike's force pulse and its contact noise
 * only: the modes are linear, so the note is the same note at another level (the same tone); read at each strike */
#define BAR_LT_UP 33033u                            /* Q15: 10^(0.07 / 20), one velocity step's lift (BAR_LT_DB) */
#define BAR_LT_VLO 7u                               /* (the lift stops rising under this velocity) */
static uint32_t bar_lt_g(uint32_t vel)              /* Q15, >= 32768 (<= 86k, at v7) */
{
    uint32_t g = 32768u, n;
    if (!rh_touch_mode || vel >= 127u) return g;
    for (n = 127u - (vel > BAR_LT_VLO ? vel : BAR_LT_VLO); n; n--) g = (g * BAR_LT_UP + 16384u) >> 15;
    return g;
}
static void bar_lt_pulse(bar_voice_t *v, uint32_t vel)
{
    uint32_t g = bar_lt_g(vel);
    uint64_t p;
    if (g == 32768u) return;
    p = ((uint64_t)(uint32_t)v->pamp * g + 16384u) >> 15;
#ifdef FR_HQ
    v->pamp = p > 65535u ? 65535 : (int32_t)p;     /* (HQ's live contact may leave it over 32767: bars_hq.c) */
#else
    v->pamp = p > 32767u ? 32767 : (int32_t)p;     /* (bar_load_pulse's own cap) */
#endif
}
static int32_t bar_nz_strike(uint32_t vel)          /* the contact noise a strike adds (bar_nz_e) */
{
    int64_t e = ((int64_t)bar_nz * bar_fam_nz() * vel) >> 22;
    uint32_t g = bar_lt_g(vel);
    return g == 32768u ? (int32_t)e : (int32_t)((e * g) >> 15);
}

/* ---- the strike coefficient cache (0.9.10, BAR_CC): a burst of notes started every voice's two rh_coef calls per mode in
 * one block's eng_begin, before core 0's first chunk (the program change + 26-note burst row: the whole block late).
 * The main loop (eng_post, at the note-on's queueing) computes them for the note into the queue entry's slot with
 * rh_coef itself, stamped with every input (the type, the key, TUNE, RING, DAMPER); bar_init takes a slot only when
 * its stamp is this strike's inputs, else rh_coef as before: the same integers either way (a knob moved between the
 * queueing and the strike, or a steal's start later: rh_coef in the ISR). The slot index is the queue's: a slot is
 * rewritten only after its event was taken; the ISR preempts the main loop, never the reverse (ok 0 while it writes).
 * 32 x 144 B: the pool (FR_C1: .ramx). Off on the desktop plugin and the HQ builds (their own threads): bars.h */
#if BAR_CC
#ifndef BAR_CC_SEC
#define BAR_CC_SEC ".pool.bar_cc"                       /* (FR_C1 builds, frodhes.c: .ramx) */
#endif
typedef struct {
    volatile uint8_t ok;                                /* 1: the stamp and the pairs below are whole */
    uint8_t n, ty;                                      /* the key (n - BAR_KEY_LO, clamped as bar_init does), the type */
    int32_t t, kd, kr;                                  /* rh_tune_t, bar_k_decay, bar_k_rel */
    int32_t c[BAR_NM][4];                               /* each mode's e0, eps0, e1, eps1 (modes without th: unused) */
} bar_cc_t;
static bar_cc_t bar_cc[32] RH_OWN_SECTION(BAR_CC_SEC);
#if defined(DINGHY_HOST) && !defined(DINGHY_WEB)
static uint32_t bar_cc_hit, bar_cc_miss;                /* (host: the fallback's test, FRODHES_BARCC_STAT) */
__attribute__((destructor)) static void bar_cc_stat(void)
{
    if (getenv("FRODHES_BARCC_STAT")) fprintf(stderr, "bar_cc hit %u miss %u\n", bar_cc_hit, bar_cc_miss);
}
#endif
static void bar_cc_fill(uint32_t slot, uint32_t note)  /* main loop (eng_post): before the event is published */
{
    bar_cc_t *c = &bar_cc[slot & 31u];
    uint32_t tyi = eng_want_sub < BAR_NTYPE ? eng_want_sub : 0u, m;
    uint32_t n = note < BAR_KEY_LO ? BAR_KEY_LO : note > BAR_KEY_LO + BAR_NKEY - 1u ? BAR_KEY_LO + BAR_NKEY - 1u : note;
    const bar_type_t *ty = &BAR_TYPE[tyi];
    const bar_key_t *k = &BAR_KP[tyi][n - BAR_KEY_LO];
    int32_t t = rh_tune_t, kd = bar_k_decay, kr = bar_k_rel;
    c->ok = 0;
    RING_PUBLISH();
    for (m = 0; m < BAR_NM; m++) {
        const rh_mode_t *km = BAR_KM(k, m);
        if (!km->th) continue;
        rh_coef(km, km->d, t, m == 1u && !(k->flags & 8u) ? 65536 : kd, &c->c[m][0], &c->c[m][1]);
        rh_coef(km, km->drel, t, m == 1u || !(ty->flags & 2u) ? 65536 : kr, &c->c[m][2], &c->c[m][3]);
    }
    c->n = (uint8_t)(n - BAR_KEY_LO); c->ty = (uint8_t)tyi; c->t = t; c->kd = kd; c->kr = kr;
    RING_PUBLISH();
    c->ok = 1;
}
static const bar_cc_t *bar_cc_find(uint32_t n, uint32_t tyi)   /* ISR: a slot stamped with this strike's inputs */
{
    uint32_t i;
    int32_t t = rh_tune_t, kd = bar_k_decay, kr = bar_k_rel;
    for (i = 0; i < 32u; i++) {
        const bar_cc_t *c = &bar_cc[i];
        if (c->ok && c->n == n && c->ty == tyi && c->t == t && c->kd == kd && c->kr == kr) {
#if defined(DINGHY_HOST) && !defined(DINGHY_WEB)
            bar_cc_hit++;
#endif
            return c;
        }
    }
#if defined(DINGHY_HOST) && !defined(DINGHY_WEB)
    bar_cc_miss++;
#endif
    return 0;
}
#endif
static void bar_init(bar_voice_t *v, uint32_t note, uint32_t vel)
{
    uint32_t tyi = bar_sub < BAR_NTYPE ? bar_sub : 0u;
    const bar_type_t *ty = &BAR_TYPE[tyi];
    uint32_t m, n = note < BAR_KEY_LO ? BAR_KEY_LO : note > BAR_KEY_LO + BAR_NKEY - 1u ? BAR_KEY_LO + BAR_NKEY - 1u : note;
    const bar_key_t *k = &BAR_KP[tyi][n - BAR_KEY_LO];
    int32_t tone = bar_pos, s = bar_tube;
    uint32_t q = (uint32_t)tone * (16u * 256u) / 127u, pi = q >> 8, pf = q & 255u;
    const int16_t (*pos)[BAR_NPC] = BAR_PS[k->band];
    v->k = k;
#if BAR_CC
    const bar_cc_t *cc = bar_cc_find(n - BAR_KEY_LO, tyi);
#endif
    for (m = 0; m < BAR_NM; m++) {
        bar_ms_t *ms = &v->m[m];
        const rh_mode_t *km = BAR_KM(k, m);
        int64_t b;
        int32_t w, lf;
        ms->x1 = ms->x2 = ms->err = 0;
        ms->amp = 0;
        ms->live = 0;
        ms->fresh = 1;
        ms->b = 0;
        ms->lpred = BAR_LZERO;
        ms->lo = 1;
        if (!km->th) { ms->e = ms->eps = 0; ms->k1 = ms->k2 = ms->be = 0; ms->lsin = 0; ms->bin = 0; continue; }
#if BAR_CC
        if (cc) { ms->e0 = cc->c[m][0]; ms->eps0 = cc->c[m][1]; ms->e1 = cc->c[m][2]; ms->eps1 = cc->c[m][3]; }
        else
#endif
        {
            rh_coef(km, km->d, rh_tune_t, m == 1u && !(k->flags & 8u) ? 65536 : bar_k_decay, &ms->e0, &ms->eps0);   /* key
                                                         * flag bit3 (MARIMBA below C4, never VIBES): RING scales the
                                                         * strongly coupled tube too (tools/gen_bars.py, the pins' grid) */
            rh_coef(km, km->drel, rh_tune_t, m == 1u || !(ty->flags & 2u) ? 65536 : bar_k_rel, &ms->e1, &ms->eps1);   /* no
                                                         * damper: drel is the hand mute, never scaled by RELEASE (C5) */
        }
        ms->e = ms->es = ms->e0; ms->eps = ms->epss = ms->eps0;
        if (m == 1u || m == 7u) w = 0;              /* (TUBE, X: b is 0 in every key, BAR_PS keeps no column for them) */
        else {
            uint32_t pc = m - (m > 1u);
            w = pi < BAR_NPOS - 1u ? pos[pi][pc] + (((pos[pi + 1u][pc] - pos[pi][pc]) * (int32_t)pf) >> 8) : pos[BAR_NPOS - 1u][pc];
        }
        b = ((int64_t)km->b * w) >> 14;
        if (m == 5u || m == 6u) b = tone > 64 ? (b * ty->tors_db) >> 15 : 0;   /* torsion: off the centreline only */
        ms->b = b > 0x7FFFFFFF ? 0x7FFFFFFF : b < -0x7FFFFFFF ? -0x7FFFFFFF : (int32_t)b;
        bar_coefs(ms);
        ms->lsin = (int16_t)bar_lsin(ms);
        lf = bar_log2_32((uint32_t)km->th) - 20 * 256;              /* 1/3-octave bands from about 14 Hz */
        ms->bin = (uint8_t)(lf <= 0 ? 0 : (lf * 3) >> 8 > 35 ? 35 : (lf * 3) >> 8);
        if (m == 0u) ms->live = 1;
        else if (m == 1u) ms->live = s != 0;                       /* BELL 0: no tube at all */
        else ms->live = ms->b != 0;                 /* bar_budget() trims, before the slot ever sounds */
    }
#ifdef FR_HQ
    hqb_init(v, n - BAR_KEY_LO, tyi, tone, pi, pf);     /* HQ (hq_mode): the extra slots; else they stay off */
#endif
    v->note = (uint8_t)note; v->vel = (uint8_t)vel;
    {   /* the key's gain x the band's level compensation at this TONE and BELL for this mallet (Q14, vibes.json
         * card_level: the strike position holds the level, the tube's own gain is scaled to its allowed span) */
        uint32_t qb = (uint32_t)bar_bell * (16u * 256u) / 127u, fm = (uint32_t)bar_fam >> 8;
        int32_t fa = (int32_t)((uint32_t)bar_fam & 255u), gt, gb;
        int64_t g;
        if (fm > BAR_NFAM - 1u) { fm = BAR_NFAM - 1u; fa = 0; }
        gt = bar_card_gain(BAR_POSG_I[k->band], fm, fa, q);
        gb = bar_card_gain(BAR_TUBEG_I[k->band], fm, fa, qb);
        g = ((((int64_t)k->gain * gt) >> 14) * gb) >> 14;
#ifdef BAR_RINGG_ROWS
        if (k->flags & 16u) {                       /* key flag bit4 (MARIMBA, never VIBES): the single-strike ceiling
                                                     * over RING, BAR_RINGG[key] at the RING card's value */
            const uint16_t *r = BAR_RINGG[n - BAR_KEY_LO];
            uint32_t qr = (uint32_t)bar_ring << 5, ri = qr >> 8;   /* point p = RING 8p: point 8 is exactly 64 */
            int32_t gr = r[ri] + ((((int32_t)r[ri + 1u] - (int32_t)r[ri]) * (int32_t)(qr & 255u)) >> 8);
            g = (g * gr) >> 14;
        }
#endif
        v->gain = g > 0x7FFFFFFF ? 0x7FFFFFFF : (int32_t)g;
    }
    v->kill1 = (int32_t)((1u << 29) / (uint32_t)(k->gain > 0 ? k->gain : 1));   /* 1 LSB out, in Q25 units */
    if (v->kill1 < 1) v->kill1 = 1;
    v->kbt = (int32_t)(((int64_t)k->k_bt * s) >> 15);
    v->ktb = (int32_t)(((int64_t)k->k_tb * s) >> 15);
    v->wt = (int32_t)(((int64_t)k->wt * s) >> 15);
    v->alive = 1; v->held = 1; v->ramp = 0; v->w_tgt = 0; v->struck = 1;
    v->fade = 32768; v->pend = 0; v->felt_n = 0; v->felt_lp = 0; v->lvl = v->lvl0 = 0;
    v->age = ++bar_ages;
    v->life = k->life;
    v->pthump = BAR_THUMP[BAR_PBAND[k->band]];     /* the felt's knock: SOFT, the softest layer (pulse_pz.h) */
    v->prate_thump = (uint32_t)BAR_PRU[BAR_PRATE_I[tyi][n - BAR_KEY_LO][0]][1] << 4;
    bar_load_pulse(v, vel);
#if defined(FR_HQ) && HQB_CONTACT
    hqb_pulse(v, vel, 0);                           /* HQ: MARIMBA's top keys from the live contact */
#endif
    bar_lt_pulse(v, vel);                           /* RESPONSE (B: the light touch's soft end) */
#ifdef DINGHY_PLUGIN
    fr_ofs_apply(&v->ppos, &v->pdly, v->prate, bar_ofs_in);   /* the plugin: from the note's own sample (engine.c) */
#endif
    /* contact noise: filtered noise, louder for harder mallets and faster strikes, decaying (tau ~ 23 ms) */
    bar_nz_e += bar_nz_strike(vel);
}

static void bar_set_damper(bar_voice_t *v, int32_t w)
{
    uint32_t m;
    if (w == v->w_tgt) return;
#ifdef FR_HQ
    for (m = 0; m < BAR_NMV(v); m++) { v->m[m].es = v->m[m].e; v->m[m].epss = v->m[m].eps; }
#else
    for (m = 0; m < BAR_NM; m++) { v->m[m].es = v->m[m].e; v->m[m].epss = v->m[m].eps; }
#endif
    v->w_tgt = w;
    v->ramp = BAR_RAMP_SUB;
}

/* ---- events (engine.c, ISR, before bar_render) */
static uint32_t bar_level_sum(const bar_voice_t *v)
{
    uint32_t m, sum = 0;
#ifdef FR_HQ
    for (m = 0; m < BAR_NMV(v); m++) sum += (uint32_t)v->m[m].amp >> 4;
#else
    for (m = 0; m < BAR_NM; m++) sum += (uint32_t)v->m[m].amp >> 4;
#endif
    return sum;
}

/* At most BAR_NV note starts a block (0.9.8, monkey seed 3037 on the FM-1: 4460-4692 us): a burst of more note-ons than
 * voices in one block (a sequencer step, a DAW's chord) on idle voices struck every free voice (bar_init: 16
 * coefficient sets, the pulse) and then stole those same voices for the next notes, whose bar_init ran again at the
 * block's end: twice BAR_NV starts in one block. With voices ringing the steals alone fill it (every voice waits:
 * BAR_NV starts, as before). The note past the limit waits for the next block, in order, as the waiting notes always
 * did; a block of BAR_NV starts or fewer is the same as before, sample for sample */
#ifndef BAR_NA
#define BAR_NA BAR_NV                               /* the voices a strike may take (FR_C1 builds, frodhes.c: fewer once
                                                     * core 1 is held: the one-core fallback) */
#endif
#ifndef BAR_START_MAX
#define BAR_START_MAX BAR_NA                        /* the note starts a block (frodhes.c FR_LAT_HALF: fewer, the block's
                                                     * starts all fall in its first interrupt) */
#endif
static int bar_strike(uint32_t note, uint32_t vel)  /* 0: every voice already waits for a note, or this block started
                                                     * BAR_NV notes; try next block */
{
    uint32_t i, pick = BAR_NV, best = 0xFFFFFFFFu;
    if (bar_starts >= BAR_START_MAX) return 0;
    for (i = 0; i < BAR_NA && bv[i].pend; i++) ;
    if (i == BAR_NA) return 0;                      /* (more than BAR_NV steals in one block: BUGHUNT #21) */
    bar_starts++;
#ifdef DINGHY_HOST
    if (bar_starts > bar_h_max_starts) bar_h_max_starts = bar_starts;
#endif
    for (i = 0; i < BAR_NV; i++)                    /* the same note still ringing: strike it again, superposed */
        if (bv[i].alive && !bv[i].pend && bv[i].note == note && bv[i].fade == 32768) {
            bar_voice_t *v = &bv[i];
            uint32_t m;
#ifdef FR_HQ
            for (m = BAR_UP0; m < BAR_NMV(v); m++)   /* relight (a fading slot keeps its state); bar_budget() trims */
#else
            for (m = BAR_UP0; m < BAR_NM; m++)       /* relight (a fading slot keeps its state); bar_budget() trims */
#endif
                if (v->m[m].b) { if (!v->m[m].live) { v->m[m].amp = 0; v->m[m].x1 = v->m[m].x2 = v->m[m].err = 0; }
                                 v->m[m].live = 1; v->m[m].fresh = 1; }
            v->m[0].fresh = 1;
            v->lvl0 = v->lvl;                        /* (the key-up's cap from this strike on) */
            v->vel = (uint8_t)vel; v->held = 1; v->age = ++bar_ages; v->life = v->k->life; v->struck = 1;
            bar_set_damper(v, 0);
            bar_load_pulse(v, vel);
#if defined(FR_HQ) && HQB_CONTACT
            hqb_pulse(v, vel, 1);                   /* HQ: the mallet meets the ringing bar (the live contact) */
#endif
            bar_lt_pulse(v, vel);                   /* RESPONSE (B: the light touch's soft end) */
#ifdef DINGHY_PLUGIN
            fr_ofs_apply(&v->ppos, &v->pdly, v->prate, bar_ofs_in);   /* the plugin: from the note's own sample */
#endif
            bar_nz_e += bar_nz_strike(vel);
            return 1;
        }
    for (i = 0; i < BAR_NA; i++)
        if (!bv[i].alive) { bar_init(&bv[i], note, vel); return 1; }
    for (i = 0; i < BAR_NA; i++) {                  /* steal: the quietest released voice, else the oldest */
        uint32_t sum, score;
        if (bv[i].pend) continue;
        sum = bar_level_sum(&bv[i]);
        score = bv[i].held ? 0x80000000u + (bv[i].age & 0x7FFFFFFFu) : (sum > 0x7FFFFFFFu ? 0x7FFFFFFFu : sum);
        if (score < best) { best = score; pick = i; }
    }
    bv[pick].pend = 1; bv[pick].pend_note = (uint8_t)note; bv[pick].pend_vel = (uint8_t)vel;
    if (bv[pick].fade == 32768) bv[pick].fade = 32767;
    return 1;
}

/* the damper weight a key-up gives at this pedal weight w: a type with a damper (VIBES) w itself; a type without one
 * (MARIMBA) w x MUTE (Q15: 0 = rings out, 127 = the full hand mute in drel; the pedal still holds: w 0) (C6, C7) */
static int bar_has_damper(void) { return (BAR_TYPE[bar_sub < BAR_NTYPE ? bar_sub : 0u].flags & 2u) != 0u; }
static int32_t bar_mute_w(int32_t w)
{
    return bar_has_damper() ? w : (int32_t)(((int64_t)w * bar_mute) >> 15);
}
static void bar_start_pend(bar_voice_t *v)          /* a stolen voice is gone: start the note waiting for it */
{
    uint32_t rel = v->pend;                         /* 1 held, 2 let go, 3 let go by an all-off (bar_all_off) */
    bar_init(v, v->pend_note, v->pend_vel);
    if (rel >= 2u) { v->held = 0; bar_set_damper(v, rel == 3u ? 32768 : bar_mute_w(bar_pedal_w)); }
}

/* the key-up never louder than the note it ends (as rhodes.c RH_THUMP_CAP / RH_FELT_FULL, 2026-10-25): the felt's
 * knock is capped at BAR_THUMP_CAP x the strike's force x the level left, the felt noise in full down to a note left
 * at BAR_FELT_FULL of the full force. tests/py/test_release_never_louder.py */
#ifndef BAR_THUMP_CAP
#define BAR_THUMP_CAP 819                       /* 0.025 */
#endif
#ifndef BAR_FELT_FULL
#define BAR_FELT_FULL 32768
#endif
static int32_t bar_left(const bar_voice_t *v)   /* the level now in strike-force units (Q15); 32-bit, no 64-bit divide */
{
    int32_t f = v->pamp, l = v->lvl, l0 = v->lvl0;
    if (l0 <= 0 || l >= l0) return f;
    if (l < 0) l = 0;
    while (l0 > 0x7FFF) { l0 >>= 1; l >>= 1; }
    return f * l / l0;
}

/* the knock's reach re the strike's (Q15, at most 32768) at the bar's fundamental: the SOFT pulse it plays against the
 * strike's own, each pulse's spectrum there (Goertzel over its table, as bar_predict) times its point spacing
 * (2^16 / prate samples): the mode's amplitude per unit of force. A harder mallet's strike is a shorter pulse that
 * gives the fundamental less for the same force, and the soft knock, capped by the force left alone, came out over the
 * note it ended (VIBES BARK 96 .. 127: +0.4 .. +0.8 dB in the key-up's block, a 16-note chord, 2026-11-10). The upper
 * modes the hard strike adds only make the note louder than its fundamental: never louder.
 * tests/py/test_bars_knock_mallet.py */
static int32_t bar_pulse_at(const int16_t *t, uint32_t prate, uint32_t th, int32_t *l)   /* log2 |P| Delta, Q8 */
{
    uint32_t dq = 0xFFFFFFFFu / prate, ph, i, k;
    uint64_t tpe = ((((uint64_t)th * 1367130551u) >> 30) * dq) >> 16;
    int32_t c, s1 = 0, s2 = 0;
    int64_t q;
    if (tpe >= 0x80000000u) return 0;
    ph = (uint32_t)tpe;
    i = ph >> 22;
    c = i < 256u ? BAR_MOT_COS[i] : -BAR_MOT_COS[512u - i];
    for (k = 0; k < BAR_PLEN + 2u; k++) {
        int32_t s0 = t[k] + (int32_t)(((int64_t)c * s1) >> 14) - s2;
        s2 = s1; s1 = s0;
    }
    q = (int64_t)s1 * s1 + (int64_t)s2 * s2 - (((int64_t)c * s1) >> 14) * s2;
    if (q <= 0) return 0;
    *l = (bar_log2_64((uint64_t)q) >> 1) + bar_log2_32(dq);
    return 1;
}
static int32_t bar_knock_reach(const bar_voice_t *v)
{
    uint32_t th = (uint32_t)v->k->m[0].th;
    int32_t ls, lt, l;
    if (!bar_pulse_at(v->pbuf, v->prate, th, &ls) || !bar_pulse_at(v->pthump, v->prate_thump, th, &lt)) return 32768;
    l = ls - lt;
    return l >= 0 ? 32768 : bar_exp2(15 * 256 + l);
}

static void bar_note_off(uint32_t note)
{
    uint32_t i;
    for (i = 0; i < BAR_NV; i++)
        if (bv[i].alive && bv[i].note == note && bv[i].held) {
            bar_voice_t *v = &bv[i];
            int kn = 0;                                     /* (the knock below set the pamp bar_left reads) */
            v->held = 0;
            bar_set_damper(v, bar_mute_w(bar_pedal_w));
            if (!bar_has_damper()) continue;                 /* no felt: no knock, no felt noise (C6) */
            if (bar_pedal_w && bar_thump && !v->ptab) {      /* the felt lands on the bar: a soft knock */
                int32_t cap = (int32_t)(((uint32_t)bar_left(v) * BAR_THUMP_CAP) >> 15);
                cap = (int32_t)(((int64_t)cap * bar_knock_reach(v)) >> 15);   /* (the strike's mallet) */
                v->ptab = v->pthump;
                v->pamp = bar_thump > 32767 ? 32767 : bar_thump;
                if (v->pamp > cap) v->pamp = cap;
                if (bar_pedal_w < 32768) v->pamp = (v->pamp * bar_pedal_w) >> 15;   /* a half pedal: the felt lands as
                                                     * lightly as it damps (0.9.13, x0.6 .. 0.9; up: as before) */
#ifdef DINGHY_HOST
                rh_h_kth = v->pamp;
#endif
                kn = 1;
                v->prate = v->prate_thump;
                v->ppos = 0;
#ifdef DINGHY_PLUGIN
                v->pdly = 0;
#endif
            }
            if (bar_pedal_w && bar_felt) {                   /* 8 ms of felt noise */
                int32_t g = bar_left(v) * (int32_t)(32768u / BAR_FELT_FULL);
                if (g > 32768) g = 32768;
                if (bar_pedal_w < 32768 && !kn) g = (g * bar_pedal_w) >> 15;   /* a half pedal: lighter, as the
                                                     * knock (after one, bar_left reads its pamp: scaled once) */
#ifdef DINGHY_HOST
                rh_h_kfelt = g;
#endif
                v->felt_n = 353; v->felt_g = (uint16_t)g;
            }
        }
    for (i = 0; i < BAR_NV; i++)                    /* a note let go while it waits for a steal's fade: it starts let go
                                                     * (it was held for good: fuzz, a fast arpeggio over 8 voices) */
        if (bv[i].alive && bv[i].pend == 1u && bv[i].pend_note == note) bv[i].pend = 2;
}

static void bar_pedal(uint32_t cc)
{
    uint32_t i;
    bar_pedal_w = PEDAL_W[cc > 127u ? 127u : cc];
    for (i = 0; i < BAR_NV; i++)
        if (bv[i].alive && !bv[i].held) bar_set_damper(&bv[i], bar_mute_w(bar_pedal_w));   /* (C7) */
}

static void bar_all_off(void)
{
    uint32_t i;
    for (i = 0; i < BAR_NV; i++)
        if (bv[i].alive) {
            bv[i].held = 0; bar_set_damper(&bv[i], 32768);
            if (bv[i].pend) bv[i].pend = 3;         /* a note waiting for a steal's fade starts let go and damped, as
                                                     * the struck ones (it was held for good: fuzz seed 780, a note-on
                                                     * on 9 busy voices, then CC 123 within the 1.5 ms fade) */
        }
}

static void bar_shed(void)                          /* overload: fade the quietest voice, released first */
{
    uint32_t i, pick = BAR_NV, best = 0xFFFFFFFFu;
    for (i = 0; i < BAR_NV; i++) {
        uint32_t sum, score;
        if (!bv[i].alive || bv[i].fade != 32768) continue;
        sum = bar_level_sum(&bv[i]);
        score = (bv[i].held ? 0x40000000u : 0u) + (sum > 0x3FFFFFFFu ? 0x3FFFFFFFu : sum);
        if (score < best) { best = score; pick = i; }
    }
    if (pick < BAR_NV) { bv[pick].fade = 32767; bv[pick].pend = 0; bar_shed_count++; }
}

/* the engine stops at once (engine.c, after its output fade at a TYPE change) */
static void bar_kill_all(void)
{
    uint32_t i, sb;
    for (i = 0; i < BAR_NV; i++) { bv[i].alive = 0; bv[i].pend = 0; }
    for (sb = 0; sb < 2u; sb++) bar_bd_m[sb][0] = bar_bd_m[sb][1] = bar_bd_o[sb][0] = bar_bd_o[sb][1] = bar_bd_e[sb] = 0;
    bar_active_bits = bar_held_bits = 0;
    bar_starts = 0;
    bar_nz_e = 0;
    bar_nz_s[0] = bar_nz_s[1] = bar_nz_s[2] = bar_nz_s[3] = 0;
}

static int bar_quiet(void) { return bar_active_bits == 0 && bar_quiet_blocks >= 2u; }

/* ---- the motor: the discs' opening per sub-block edge, once per block (the MOTOR page through eng_bar_knob). The
 * discs gate the tube's radiation only (bar_voice_block), x the make-up that keeps its mean power; the bar <-> tube
 * coupling stays the discs-open one. Until 2026-10-18 they scaled the coupling too: with the motor on the tube drained
 * the bar less, the bar rang about twice as long (C3 G3 C4 E4: -9.5 dB/s open, -5.0 with the motor; real discs
 * closed do sustain longer), so the motor drifted +4.4 dB/s above the dry level along a held chord and switching it
 * off jumped +4.7 LU (FM-1 vibes_jump, USB and the jack alike). The user's rule wins: the motor is a tremolo at the
 * same level and decay as the discs open (tests/py/test_vibes_motor_level.py). */
#define BAR_MOT_SLEW 512                            /* the depth's slew, Q15 a sub-block: off <-> full in 64 sub-blocks
                                                     * (46 ms), so switching the motor or turning DEPTH never clicks */
static int32_t bar_mot_d;                           /* the discs' depth as it plays, Q15 (DEPTH x ON, slewed) */
static uint8_t bar_mot_park = 1;                    /* this block: the discs parked open (bar_mot_g all x 1) */
static uint32_t bar_isqrt(uint32_t x)               /* floor(sqrt(x)), 32-bit */
{
    uint32_t r = 0, b = 1u << 30;
    while (b > x) b >>= 2;
    while (b) {
        if (x >= r + b) { x -= r + b; r = (r >> 1) + b; } else r >>= 1;
        b >>= 2;
    }
    return r;
}
/* the make-up of the tube's radiation for a disc law g = gmin + (1 - gmin) op (Q15), op = (1 - a) o + a o^2 (SHAPE a),
 * o = 1 - |cos|: 1 / sqrt(mean g^2) over a turn, so the tube's mean power stays what it is with the discs open (the
 * loudness matched at any DEPTH and SHAPE, and along the whole decay). The moments of o over a turn, Q15: E[o] = 1 -
 * 2/pi, E[o^2], E[o^3], E[o^4]. Q15 out (x 1 .. x 2.4) */
#define BAR_MOT_E1 11907
#define BAR_MOT_E2 7430
#define BAR_MOT_E3 5431
#define BAR_MOT_E4 4288
static int32_t bar_mot_mk(int32_t gmin, int32_t shape)
{
    int32_t a = (shape << 15) / 127, b = 32768 - a, h = 32768 - gmin;
    int32_t e1 = (b * BAR_MOT_E1 + a * BAR_MOT_E2) >> 15;                       /* E[op] */
    int32_t e2 = (int32_t)(((int64_t)b * b * BAR_MOT_E2 + 2 * (int64_t)a * b * BAR_MOT_E3
                            + (int64_t)a * a * BAR_MOT_E4) >> 30);              /* E[op^2] */
    int32_t m2 = ((gmin * gmin) >> 15) + (int32_t)((2 * (int64_t)gmin * h * e1) >> 30)
               + (int32_t)(((int64_t)h * h * e2) >> 30);                        /* E[g^2], Q15 */
    uint32_t r = bar_isqrt((uint32_t)m2 << 15);                                 /* sqrt, Q15 */
    return r ? (int32_t)((1u << 30) / r) : 32768;
}
static void bar_motor_block(void)
{
    uint32_t i, inc = bar_mot_inc;
    int32_t depth = bar_mot_depth > 127u ? 127 : bar_mot_depth, shape = bar_mot_shape > 127u ? 127 : bar_mot_shape;
    const bar_type_t *ty = &BAR_TYPE[bar_sub < BAR_NTYPE ? bar_sub : 0u];
    int32_t gc = ty->mot_gc;
    int32_t tgt = bar_mot_on && (ty->flags & 1u) ? (depth << 15) / 127 : 0, d0 = bar_mot_d;   /* no motor: parked (C8) */
    bar_mot_g[0] = bar_mot_g[8];                    /* the last block's end: continuous */
    bar_mot_park = !tgt && !d0;
    if (bar_mot_park) {                             /* off: the discs parked open */
        for (i = 0; i < 9u; i++) bar_mot_g[i] = 32768;
        bar_mot_ph += 256u * inc;
        return;
    }
    for (i = 1; i < 9u; i++) {                      /* each sub-block's end (its start is the one before) */
        /* |cos phi|, phi = pi t / 512, t = ph >> 23 folded on the quarter-turn table: one AM period per 2^32 phase
         * cycle (bit-exact to tools/bartube.py mot_rad at a steady depth: mot_block x mot_mk) */
        uint32_t ph = bar_mot_ph + i * 32u * inc, t = ph >> 23, fr = (ph >> 15) & 255u, t1 = (t + 1u) & 511u;
        int32_t c0 = t < 256u ? BAR_MOT_COS[t] : BAR_MOT_COS[512u - t];
        int32_t c1 = t1 < 256u ? BAR_MOT_COS[t1] : BAR_MOT_COS[512u - t1];
        int32_t c = c0 + (((c1 - c0) * (int32_t)fr) >> 8);
        int32_t o = 32768 - c, op = o, gmin, dd = tgt - bar_mot_d;
        bar_mot_d += dd > BAR_MOT_SLEW ? BAR_MOT_SLEW : dd < -BAR_MOT_SLEW ? -BAR_MOT_SLEW : dd;   /* DEPTH x ON, slewed */
        gmin = bar_mot_d == tgt ? 32768 - (depth * (32768 - gc)) / 127 * (tgt != 0)   /* steady: DEPTH exactly */
                                : 32768 - (int32_t)(((int64_t)bar_mot_d * (32768 - gc)) >> 15);
        if (shape) op = o + (((((o * o) >> 15) - o) * shape) / 127);   /* p = 1 + SHAPE/127: a narrower open window */
        bar_mot_g[i] = (int32_t)(((int64_t)(gmin + (((32768 - gmin) * op) >> 15)) * bar_mot_mk(gmin, shape)) >> 15);
    }
    bar_mot_ph += 256u * inc;
}

/* ---- the CPU cost model: ns on the FM-1 per 256-frame block. Derived from the measured costs of the previous kernels
 * (tools/hil_cpu.py 2026-10-17: an upper slot 40 us a block for 44 instructions a sample = 3.6 ns an instruction in
 * register-bound loops; the pair + pulse + output 1.46 us a voice-sample for ~248 = 5.9 ns where the loop spills)
 * applied to the instruction counts of these loops in build/frodhes.dis, then x 1.25 (x 1.3 for the slots) so each
 * is an upper bound. tools/hil_cpu.py --calib and --fx-each measure the real ones: replace these with them. The cap
 * is the gate minus a margin minus everything that is not an upper mode, in units of one upper mode for one
 * sub-block (a fading slot is one unit). Loop sizes until bars-10 (build/frodhes.dis, instructions a sample): upper
 * slot 9 (Q32) / 8 (Q30), with the force 13 / 20; the pair 29, with the force 35; the radiation 9 (the motor's 7); the
 * gain 8; the slow output (steal fade, felt) 46; the pulse 25; the contact noise 48. Since bars-10 (tools/build.py
 * BAR_LOOPS checks them): upper slot 7.75 / 7.5, with the force 10 / 10; the pair 28.5 / 34.5; the output 11 with the
 * radiation fused (7 without it, + the motor's 7); the steal fade 10 more than the output; the felt noise 15 (its own
 * pass, felt_n samples); the pulse 16. Each constant below is its old value scaled by its loops' new count over the
 * old one (the same ns per instruction, the same x 1.25 / x 1.3): VOICE's loops (83 % of it, the rest the levels and
 * set-up, kept) 46 -> 42.5 (the motor's case, the larger), FORCE 31 -> 22 (the pulse + the pair's force), UNIT 9 ->
 * 7.75, UNITF 12 -> 2.5 (the force's extra, the Q30 slot's), SLOW 38 more than the gain -> FADE 10 + FELT 15. */
#define BAR_NS_GATE 4800000u      /* the worst block allowed; the shedder is at 5000 us */
#define BAR_NS_MARGIN 150000u     /* the model's own error */
#define BAR_NS_BASE 312000u       /* idle, no effects: the platform, the master, an empty render (measured) */
#define BAR_NS_VOICE 94000u       /* a sounding voice: the pair, the radiation (motor), the gain, the levels, setup
                                   * (100000 before bars-10: 17000 + 83000 x 42.5 / 46) */
#define BAR_NS_FORCE 35500u       /* a voice whose pulse runs this block (the pulse, the pair's force), whole block
                                   * (50000: x 22 / 31) */
#define BAR_NS_STRIKE 40000u      /* a note-on: 16 coefficient sets, the pulse blend, the slots' set-up */
#define BAR_NS_FADE 12000u        /* a voice fading (steal): the fade's loop (SLOW 45000 for fade or felt: x 10 / 38) */
#define BAR_NS_FELT 18000u        /* a voice with felt noise: its pass (x 15 / 38) */
#define BAR_NS_NOISE 65000u       /* the contact noise (one for all voices) */
#define BAR_NS_RANK 70000u        /* the budget's ranking (only when over) */
#define BAR_NS_PRED 3000u         /* one slot's strike prediction (only when over) */
#define BAR_NS_UNIT 1210u         /* one upper mode for one sub-block (1400: x 7.75 / 9) */
#define BAR_NS_UNITF 320u         /* ... more while any voice's pulse runs (the force MAC; counted for every slot)
                                   * (1500: x 2.5 / 12) */

#ifndef FX_COST_C0
#define FX_COST_C0() fx_cost_us()                   /* the effects' time on this core (FR_C1 builds, frodhes.c: core 1
                                                     * runs them; core 0 pays the hand-off) */
#endif
static uint32_t bar_upper_units(void)               /* live upper slots over the alive voices, in sub-block units */
{
    uint32_t i, m, c = 0;
    for (i = 0; i < BAR_NV; i++)
        if (bv[i].alive)
            for (m = BAR_UP0; m < BAR_NM; m++) c += bv[i].m[m].live == 1u ? BAR_NSUB : bv[i].m[m].live ? 1u : 0u;
    return c;
}

/* everything this block will do except the upper modes (ns); *unit = one unit's ns */
static uint32_t bar_cost_fixed(uint32_t *unit)
{
    uint32_t i, ns = BAR_NS_BASE + 1000u * FX_COST_C0(), f = 0;
#ifdef DINGHY_HOST
    if (bar_h_fxus >= 0) ns = BAR_NS_BASE + 1000u * (uint32_t)bar_h_fxus;
#endif
    for (i = 0; i < BAR_NV; i++) {
        const bar_voice_t *v = &bv[i];
        if (!v->alive) continue;
        ns += BAR_NS_VOICE;
        if (v->ptab) { ns += BAR_NS_FORCE; f = 1; }
        if (v->struck) ns += BAR_NS_STRIKE;
        if (v->fade != 32768) ns += BAR_NS_FADE;
        if (v->felt_n) ns += BAR_NS_FELT;
        if (v->pend && v->fade != 32768) ns += BAR_NS_STRIKE;       /* the waiting note starts at this block's end */
    }
    if (bar_nz_e) ns += BAR_NS_NOISE;
    *unit = BAR_NS_UNIT + (f ? BAR_NS_UNITF : 0u);
    return ns;
}

/* ---- the mode budget, at block start (after this block's strikes): while the live upper modes cost more than the
 * block can take, the least audible go. Audibility: a partial's output level re the loudest fundamental (V1) in the
 * mix, and under the masking of the loudest other partials in its own and the three neighbouring third-octave bands
 * (12 dB under a masker in the same band, 8 dB more per band above it, 15 dB more per band below it). A strike's
 * slots that have not sounded are ranked by their predicted level (bar_predict). Ringing slots fade out over a
 * sub-block (live 2); slots that never sounded just stay silent. */
#define BAR_DB(x) ((int32_t)(x) * 5442 / 128)       /* dB -> log2 Q8 (256 / 6.0206 = 42.52) */
#define BAR_NBIN 36u
#define BAR_FLOOR_DB 70                             /* the audibility floor under the loudest V1 */
#define BAR_MOFF_DB 12                              /* masking: 12 dB under a partial in the same band */
#define BAR_MUP_DB 8                                /* + 8 dB per band above the masker */
#define BAR_MDN_DB 15                               /* + 15 dB per band below it */
#define BAR_MCAP_DB 6                               /* the most masking can take off (it breaks near ties: S12
                                                     * measured an uncapped credit dropping louder partials first) */
typedef struct { int16_t l; uint8_t v, m; } bar_lv_t;
static bar_lv_t bar_lv[BAR_NV * BAR_NM];
static int16_t bar_top[BAR_NBIN][2];
static uint8_t bar_topi[BAR_NBIN][2];

static uint32_t bar_budget_run(void);
static void bar_budget(void)
{
    uint32_t unit, ns = bar_cost_fixed(&unit) + bar_budget_run();
    bar_plan_us = (ns + unit * bar_upper_units() + 999u) / 1000u;
}
static uint32_t bar_budget_run(void)                /* returns the ranking's own cost (ns) */
{
    uint32_t i, m, n = 0, nc = 0, used = bar_upper_units(), unit, cap, rank = 0;
    uint32_t fixed = bar_cost_fixed(&unit);
    int32_t lref = BAR_LZERO;
    uint8_t cand[BAR_NV * BAR_NUP];
    int16_t aud[BAR_NV * BAR_NUP];
    for (;;) {                                      /* the cap, in units: (gate - margin - the rest) / unit */
        uint32_t lim = BAR_NS_GATE - BAR_NS_MARGIN, cost = fixed + rank;
        cap = cost < lim ? (lim - cost) / unit : 0u;
        if (used <= cap || rank) break;
        rank = BAR_NS_RANK;                         /* over: the ranking itself costs, take it from the cap */
        for (i = 0; i < BAR_NV; i++)
            if (bv[i].alive && !bv[i].pred && bv[i].ptab == bv[i].pbuf)
                for (m = 0; m < BAR_NM; m++) rank += bv[i].m[m].fresh & 1u ? BAR_NS_PRED : 0u;
    }
#ifdef DINGHY_HOST
    if (bar_h_pred)
        for (i = 0; i < BAR_NV; i++) if (bv[i].alive && bv[i].ptab == bv[i].pbuf && !bv[i].pred) bar_predict(&bv[i]);
#endif
    {   /* the type's own cap (BAR_TYPE.budget, upper modes; 48 = all) can only lower it */
        uint32_t tcap = (uint32_t)BAR_TYPE[bar_sub < BAR_NTYPE ? bar_sub : 0u].budget * BAR_NSUB;
        if (tcap < cap) cap = tcap;
    }
#ifdef FR_HQ
    cap = 0xFFFFu; rank = 0;                        /* the Move (FR_HQ builds): no FM-1-time cost model and no type
                                                     * cap (48 upper modes in all, both TYPEs: under 16 voices x 6).
                                                     * 16 voices with every upper mode fit its callback (private plan
                                                     * 05 M3-03). CC 9 still applies */
#endif
    if (bar_budget_force) cap = bar_budget_force >= 50u ? 0xFFFFu : (uint32_t)(bar_budget_force - 1u) * BAR_NSUB;
#ifdef DINGHY_HOST
    if (bar_h_nobudget) cap = 0xFFFFu;
#endif
    if (cap / BAR_NSUB < bar_prof_cap) bar_prof_cap = cap / BAR_NSUB;
    if (used <= cap) { if ((used + 7u) / 8u > bar_prof_used) bar_prof_used = (used + 7u) / 8u; return rank; }
    /* every partial's output level, log2 Q8 in Q15 output units (gain Q16: amp gain / 2^29) */
    for (i = 0; i < BAR_NV; i++) {
        bar_voice_t *v = &bv[i];
        int32_t lg;
        if (!v->alive) continue;
        if (v->ptab == v->pbuf && !v->pred) bar_predict(v);
        lg = bar_log2_32((uint32_t)v->gain) - 29 * 256;
        for (m = 0; m < BAR_NM; m++) {
            const bar_ms_t *s = &v->m[m];
            int32_t l;
            if (s->live != 1u) continue;
            l = s->amp ? bar_log2_32((uint32_t)s->amp) : BAR_LZERO;
            if ((s->fresh & 1u) && v->ptab == v->pbuf && s->lpred > l) l = s->lpred;   /* struck now: predicted */
            if (l == BAR_LZERO) { if (m < BAR_UP0) continue; l = -32767 - lg; }   /* nothing to go on: goes first */
            l += lg;
            if (m == 1u) l += bar_log2_32((uint32_t)(v->wt < 0 ? -v->wt : v->wt)) - 28 * 256;
            if (m == 0u && l > lref) lref = l;
            bar_lv[n].l = (int16_t)(l < -32767 ? -32767 : l > 32767 ? 32767 : l);
            bar_lv[n].v = (uint8_t)i; bar_lv[n].m = (uint8_t)m;
            n++;
        }
    }
    for (i = 0; i < BAR_NBIN; i++) { bar_top[i][0] = bar_top[i][1] = -32767; bar_topi[i][0] = bar_topi[i][1] = 0xFF; }
    for (i = 0; i < n; i++) {                       /* the two loudest partials in every band */
        uint32_t b = bv[bar_lv[i].v].m[bar_lv[i].m].bin;
        int16_t l = bar_lv[i].l;
        if (l > bar_top[b][0]) { bar_top[b][1] = bar_top[b][0]; bar_topi[b][1] = bar_topi[b][0]; bar_top[b][0] = l; bar_topi[b][0] = (uint8_t)i; }
        else if (l > bar_top[b][1]) { bar_top[b][1] = l; bar_topi[b][1] = (uint8_t)i; }
    }
    for (i = 0; i < n; i++) {                       /* the candidates' audibility: level - max(floor, masking) */
        const bar_voice_t *v = &bv[bar_lv[i].v];
        int32_t b = v->m[bar_lv[i].m].bin, t = lref - BAR_DB(BAR_FLOOR_DB), d, a;
        uint32_t j;
        if (bar_lv[i].m < BAR_UP0) continue;
        for (d = -3; d <= 3; d++) {
            int32_t bb = b + d, mk;
            if (bb < 0 || bb >= (int32_t)BAR_NBIN) continue;
            j = bar_topi[bb][0] == i ? 1u : 0u;     /* not masked by itself */
            if (bar_topi[bb][j] == 0xFF) continue;
            mk = bar_top[bb][j] - BAR_DB(BAR_MOFF_DB) - (d < 0 ? BAR_DB(BAR_MUP_DB) * -d : BAR_DB(BAR_MDN_DB) * d);
            if (mk > t) t = mk;
        }
        {   /* masking only breaks near ties: its credit is capped */
            int32_t fl = lref - BAR_DB(BAR_FLOOR_DB), cr = t - fl;
            if (cr > BAR_DB(BAR_MCAP_DB)) cr = BAR_DB(BAR_MCAP_DB);
            a = bar_lv[i].l - fl - cr;
        }
        a -= (bar_log2_32((uint32_t)v->m[bar_lv[i].m].eps) - 16 * 256) >> 1;   /* short-lived partials count less:
                                                     * energy ~ A^2 tau, tau ~ 1 / eps (half a log2 per octave of eps) */
        if (v->fade != 32768) a -= BAR_DB(200);     /* a stolen voice's partials go first: it fades out anyway */
        aud[nc] = (int16_t)(a < -32767 ? -32767 : a > 32767 ? 32767 : a);
        cand[nc++] = (uint8_t)i;
    }
    for (i = 1; i < nc; i++) {                      /* least audible first (insertion sort, <= 48) */
        int16_t a = aud[i];
        uint8_t c = cand[i];
        uint32_t j = i;
        while (j && aud[j - 1u] > a) { aud[j] = aud[j - 1u]; cand[j] = cand[j - 1u]; j--; }
        aud[j] = a; cand[j] = c;
    }
    for (i = 0; i < nc && used > cap; i++) {
        bar_ms_t *s = &bv[bar_lv[cand[i]].v].m[bar_lv[cand[i]].m];
        if (s->amp) { s->live = 2; used -= BAR_NSUB - 1u; }                       /* faded over its next sub-block */
        else { s->live = 0; s->x1 = s->x2 = s->err = 0; used -= BAR_NSUB; }      /* never sounded: nothing to fade */
    }
    if (used > cap) {                               /* still over (should not happen): every unranked upper slot goes */
        for (i = 0; i < BAR_NV; i++)
            for (m = BAR_UP0; m < BAR_NM && used > cap; m++)
                if (bv[i].alive && bv[i].m[m].live == 1u) { bv[i].m[m].live = 2; used -= BAR_NSUB - 1u; }
    }
    if ((used + 7u) / 8u > bar_prof_used) bar_prof_used = (used + 7u) / 8u;
    return rank;
}

/* ---- the kernels: two samples a turn (x[n] and x[n-1] swap roles), first-order error feedback. 2 multiplies a
 * sample (3 while the force runs): Q32 for the modes under ~4.9 kHz, Q30 above (bar_coefs). */
#define BAR_LO(XN, XO, F) do { int64_t a_ = (int64_t)(uint32_t)err - (int64_t)k1 * (XN) + (int64_t)k2 * (XO) F; \
        (XO) = 2 * (XN) - (XO) + (int32_t)(a_ >> 32); err = (int32_t)a_; } while (0)
#define BAR_HI(XN, XO, F) do { int64_t a_ = (int64_t)(uint32_t)err + (int64_t)k1 * (XN) - (int64_t)k2 * (XO) F; \
        (XO) = (int32_t)(a_ >> 30); err = (int32_t)a_ & BAR_EFM; } while (0)
#define BAR_KERNEL(NAME, STEP, FRC) \
FR_RAM __attribute__((noinline)) static void NAME(bar_ms_t *s, int32_t *p, uint32_t n) \
{ \
    int32_t x1 = s->x1, x2 = s->x2, err = s->err, k1 = s->k1, k2 = s->k2, be = s->be; \
    int32_t *e = p + 3u * n; \
    (void)be; \
    for (; p < e; p += 12) { \
        STEP(x1, x2, FRC(2)); p[0] += x2; \
        STEP(x2, x1, FRC(5)); p[3] += x1; \
        STEP(x1, x2, FRC(8)); p[6] += x2; \
        STEP(x2, x1, FRC(11)); p[9] += x1; \
    } \
    s->x1 = x1; s->x2 = x2; s->err = err; \
}
#define BAR_NOF(I)
#define BAR_F_(I) + (int64_t)p[I] * be
BAR_KERNEL(bar_run_lo, BAR_LO, BAR_NOF)
BAR_KERNEL(bar_run_lo_f, BAR_LO, BAR_F_)
BAR_KERNEL(bar_run_hi, BAR_HI, BAR_NOF)
BAR_KERNEL(bar_run_hi_f, BAR_HI, BAR_F_)

static void bar_run(bar_ms_t *s, int32_t *p, int frc, uint32_t n)   /* an upper slot over p = BAR_XT(o), n a multiple of 4 */
{
    if (s->lo) { if (frc) FR_FAR(bar_run_lo_f)(s, p, n); else FR_FAR(bar_run_lo)(s, p, n); }
    else { if (frc) FR_FAR(bar_run_hi_f)(s, p, n); else FR_FAR(bar_run_hi)(s, p, n); }
}

static void bar_run_fade(bar_ms_t *s, int32_t *p, int frc)   /* one sub-block, faded out, then asleep */
{
    int32_t t[3u * BAR_SUB], j;
    for (j = 0; j < (int32_t)BAR_SUB; j++) { t[3 * j] = 0; t[3 * j + 2] = frc ? p[3 * j + 2] : 0; }
    bar_run(s, t, frc, BAR_SUB);
    for (j = 0; j < (int32_t)BAR_SUB; j++) p[3 * j] += (int32_t)(((int64_t)t[3 * j] * (1024 * ((int32_t)BAR_SUB - j))) >> 15);
    s->live = 0; s->x1 = s->x2 = s->err = 0; s->amp = 0;
}

/* V1 <-> TUBE for one sub-block, sample-inner, Q32 form (both modes under ~4.9 kHz: every key but MARIMBA's 108, whose
 * tube, damped 15 % at 4.3 kHz, takes the Q30 form: bar_pair_*h below): bx = x0, tb = the
 * tube's x1 (its radiation weight is the output loop's). The tube's pressure on the bar (ktb x1 into y0) enters x0 as
 * e0 ktb x1, likewise e1 kbt x0 into x1: ktbe = ktb e0 >> 16 then >> 12 (the product keeps 12 more bits: ktb e0 is
 * 2^33 .. 2^46 over the keys), kbte = kbt e1 >> 28. The motor does not touch the coupling (bar_motor_block): the pair,
 * and so the bar's decay, is the same with the motor on or off. */
#define BAR_PSTEP(X0N, X0O, X1N, X1O, FRC, I) do { \
        int64_t a_ = (int64_t)(uint32_t)e0r - (int64_t)c10 * (X0N) + (int64_t)c20 * (X0O) \
                   + (((int64_t)ktbe * (X1N)) >> 12); \
        if (FRC) a_ += (int64_t)p[3 * (I) + 2] * be0; \
        (X0O) = 2 * (X0N) - (X0O) + (int32_t)(a_ >> 32); e0r = (int32_t)a_; \
        a_ = (int64_t)(uint32_t)e1r - (int64_t)c11 * (X1N) + (int64_t)c21 * (X1O) + (int64_t)kbte * (X0O); \
        (X1O) = 2 * (X1N) - (X1O) + (int32_t)(a_ >> 32); e1r = (int32_t)a_; \
        p[3 * (I)] = (X0O); p[3 * (I) + 1] = (X1O); \
    } while (0)
/* the same with the tube in the Q30 form (its c1 >= 1/2: a heavily damped tube near the top, MARIMBA's key 108 only;
 * VIBES never: every VIBES tube is in Q32): x1' = (err + a1 x1 - a2 x1p + kbte x0) >> 30, kbte = kbt e1 >> 30 */
#define BAR_PSTEP_H(X0N, X0O, X1N, X1O, FRC, I) do { \
        int64_t a_ = (int64_t)(uint32_t)e0r - (int64_t)c10 * (X0N) + (int64_t)c20 * (X0O) \
                   + (((int64_t)ktbe * (X1N)) >> 12); \
        if (FRC) a_ += (int64_t)p[3 * (I) + 2] * be0; \
        (X0O) = 2 * (X0N) - (X0O) + (int32_t)(a_ >> 32); e0r = (int32_t)a_; \
        a_ = (int64_t)(uint32_t)e1r + (int64_t)c11 * (X1N) - (int64_t)c21 * (X1O) + (int64_t)kbte * (X0O); \
        (X1O) = (int32_t)(a_ >> 30); e1r = (int32_t)a_ & BAR_EFM; \
        p[3 * (I)] = (X0O); p[3 * (I) + 1] = (X1O); \
    } while (0)
/* p = BAR_XT(o): the bar's x0 to p[3j], the tube's x1 to p[3j + 1], the force from p[3j + 2] (bars.h bar_xt: one
 * pointer for all three), out of line, so the loop keeps its state in registers */
#define BAR_PAIR(NAME, STEP, FRC) \
FR_RAM __attribute__((noinline)) static void NAME(bar_ms_t *s0, bar_ms_t *s1, int32_t *p, int32_t ktbe, int32_t kbte) \
{ \
    int32_t x0 = s0->x1, x0p = s0->x2, e0r = s0->err, c10 = s0->k1, c20 = s0->k2, be0 = s0->be; \
    int32_t x1 = s1->x1, x1p = s1->x2, e1r = s1->err, c11 = s1->k1, c21 = s1->k2; \
    int32_t *e = p + 3u * BAR_SUB; \
    (void)be0; \
    for (; p < e; p += 6) { STEP(x0, x0p, x1, x1p, FRC, 0); STEP(x0p, x0, x1p, x1, FRC, 1); } \
    s0->x1 = x0; s0->x2 = x0p; s0->err = e0r; s1->x1 = x1; s1->x2 = x1p; s1->err = e1r; \
}
BAR_PAIR(bar_pair_0, BAR_PSTEP, 0)
BAR_PAIR(bar_pair_1, BAR_PSTEP, 1)
BAR_PAIR(bar_pair_0h, BAR_PSTEP_H, 0)
BAR_PAIR(bar_pair_1h, BAR_PSTEP_H, 1)

static bar_ms_t bar_notube;                         /* BELL 0: a silent tube (the same work, so the same cost) */
FR_RAM __attribute__((noinline)) static void bar_pair(bar_voice_t *v, uint32_t o, uint32_t o1, uint32_t nf)
{                                                   /* the sub-blocks from sample o to o1 (the force in those before
                                                     * nf), the coefficients fixed over them (RAM: 0.9.7) */
    bar_ms_t *s0 = &v->m[0], *s1 = v->m[1].live ? &v->m[1] : &bar_notube;
    int32_t ktbe = 0, kbte = 0, hi = 0;
    if (v->m[1].live) {
        ktbe = FR_FAR(bar_sat31)((int64_t)v->ktb * s0->e >> 16);
        hi = !s1->lo;                               /* the tube in Q30 (MARIMBA key 108; never VIBES): its own path */
        kbte = FR_FAR(bar_sat31)(hi ? (int64_t)v->kbt * s1->e >> 30 : (int64_t)v->kbt * s1->e >> 28);
    }
    for (; o < o1; o += BAR_SUB) {
        int32_t *p = BAR_XT(o);
        if (hi) { if (o < nf) FR_FAR(bar_pair_1h)(s0, s1, p, ktbe, kbte); else FR_FAR(bar_pair_0h)(s0, s1, p, ktbe, kbte); }
        else if (o < nf) FR_FAR(bar_pair_1)(s0, s1, p, ktbe, kbte); else FR_FAR(bar_pair_0)(s0, s1, p, ktbe, kbte);
    }
}

#if !FR_CHUNK
/* the pulse into the force slots BAR_XT(0 .. nF)[2] as F << 12, F exactly the Q15 force of before (the kernels' be scales it) */
FR_RAM __attribute__((noinline)) static uint32_t bar_force(bar_voice_t *v)
{
    const int16_t *t = v->ptab;
    uint32_t pos = v->ppos, rate = v->prate, j, n, L = (uint32_t)BAR_PLEN << 16;
    int32_t amp = v->pamp, *q = bar_xt + 2, *qe;
    if (!t) return 0;
#ifdef DINGHY_PLUGIN
    {   /* the plugin: zeros until the note's own sample (rhodes.c fr_ofs_apply), then the pulse */
        uint32_t d = v->pdly < BAR_N ? v->pdly : BAR_N;
        for (qe = q + 3u * d; q < qe; q += 3) *q = 0;
        v->pdly = (uint16_t)(v->pdly - d);
        n = pos >= L ? 1u : (L - pos + rate - 1u) / rate;
        if (n > BAR_N - d) n = BAR_N - d;
        else v->ptab = 0;
        for (qe = q + 3u * n; q < qe; q += 3) {
            uint32_t i = pos >> 16;
            int32_t f = (int32_t)((pos >> 1) & 0x7FFFu), a = t[i], dd = t[i + 1u] - a;
            *q = (((a + ((dd * f) >> 15)) * amp) >> 15) << 12;
            pos += rate;
        }
        j = d + n;
    }
#else
    n = pos >= L ? 1u : (L - pos + rate - 1u) / rate;   /* the samples to the pulse's end (the last one included) */
    if (n > BAR_N) n = BAR_N;
    else v->ptab = 0;                               /* it ends in this block */
    for (qe = q + 3u * n; q < qe; q += 3) {
        uint32_t i = pos >> 16;
        int32_t f = (int32_t)((pos >> 1) & 0x7FFFu), a = t[i], d = t[i + 1u] - a;
        *q = (((a + ((d * f) >> 15)) * amp) >> 15) << 12;
        pos += rate;
    }
    j = n;
#endif
    v->ppos = pos;
    {   /* zeros to the end of the sub-block (the kernels run 4 samples a turn, the pair per sub-block) */
        uint32_t z, e = (j + BAR_SUB) & ~(BAR_SUB - 1u);
        for (z = j; z < e && z < BAR_N + 2u; z++) BAR_XT(z)[2] = 0;
    }
    return j;
}

#endif

/* damper crossfade: E and eps together, 7 sub-blocks */
static void bar_damper_step(bar_voice_t *v)
{
    uint32_t m;
    int32_t f;
    v->ramp--;
    f = (int32_t)(BAR_RAMP_SUB - v->ramp) * 4681;
    if (f > 32768 || !v->ramp) f = 32768;
#ifdef FR_HQ
    for (m = 0; m < BAR_NMV(v); m++) {
#else
    for (m = 0; m < BAR_NM; m++) {
#endif
        bar_ms_t *s = &v->m[m];
        int32_t et, pt;
        if (!s->live) continue;
        et = s->e0 + (int32_t)(((int64_t)(s->e1 - s->e0) * v->w_tgt) >> 15);
        pt = s->eps0 + (int32_t)(((int64_t)(s->eps1 - s->eps0) * v->w_tgt) >> 15);
        s->e = s->es + (int32_t)(((int64_t)(et - s->es) * f) >> 15);
        s->eps = s->epss + (int32_t)(((int64_t)(pt - s->epss) * f) >> 15);
        bar_coefs(s);
    }
}

#if !FR_CHUNK
/* ---- the output loops (out of line, pointer form): the voice's gain into the mix, = for the block's first voice (no
 * zero pass), += for the others; _rad: + the tube's radiation wt x1 >> 28 (the discs parked open), as bar_x += it
 * before the gain; bar_fade*: the steal fade (Q15, BAR_FADE_STEP a sample, to 0), returns where it ends */
#define BAR_OUT(NAME, OP, RAD) \
__attribute__((noinline)) static void NAME(int32_t *mix, const int32_t *x, int32_t wt, int32_t gain) \
{ \
    int32_t *e = mix + BAR_N; \
    (void)wt; \
    for (; mix < e; mix++, x += 3) { \
        int32_t y = RAD ? x[0] + (int32_t)(((int64_t)wt * x[1]) >> 28) : x[0]; \
        *mix OP (int32_t)(((int64_t)y * gain) >> 24); \
    } \
}
#define BAR_FADE(NAME, OP, RAD) \
__attribute__((noinline)) static int32_t NAME(int32_t *mix, const int32_t *x, int32_t wt, int32_t gain, int32_t f) \
{ \
    int32_t *e = mix + BAR_N; \
    (void)wt; \
    for (; mix < e; mix++, x += 3) { \
        int32_t y = RAD ? x[0] + (int32_t)(((int64_t)wt * x[1]) >> 28) : x[0]; \
        int32_t o = (int32_t)(((int64_t)y * gain) >> 24); \
        o = (int32_t)(((int64_t)o * f) >> 15); \
        f -= BAR_FADE_STEP; \
        if (f < 0) f = 0; \
        *mix OP o; \
    } \
    return f; \
}
BAR_OUT(bar_out_w, =, 0)
BAR_OUT(bar_out_rad_w, =, 1)
BAR_FADE(bar_fade_w, =, 0)
BAR_FADE(bar_fade_rad_w, =, 1)
BAR_OUT(bar_out, +=, 0)
BAR_OUT(bar_out_rad, +=, 1)
BAR_FADE(bar_fade, +=, 0)
BAR_FADE(bar_fade_rad, +=, 1)
/* the output with the motor's radiation fused in (0.9.7, the discs turning: was its own pass over bar_xt, x0 += w x1
 * >> 27, then bar_out): wd = each sub-block's w and its step, the same integers as the two passes */
#ifdef HAL_KEEP_REG
#define BAR_KEEP(p) HAL_KEEP_REG(p)                 /* (hal/fm1_keep.h: no instruction; the pointer kept as it steps,
                                                     * so the loop does not index from a counter: 11, not 13) */
#else
#define BAR_KEEP(p) ((void)0)
#endif
#define BAR_OUTM(NAME, OP) \
FR_RAM __attribute__((noinline)) static void NAME(int32_t *mix, const int32_t *x, const int32_t *wd, int32_t gain) \
{ \
    int32_t *e = mix + BAR_N; \
    while (mix < e) { \
        int32_t w = *wd++, dw = *wd++, *se = mix + BAR_SUB; \
        while (mix < se) { \
            int32_t y = x[0] + (int32_t)(((int64_t)w * x[1]) >> 27); \
            w += dw; x += 3; BAR_KEEP(x); \
            *mix OP (int32_t)(((int64_t)y * gain) >> 24); \
            mix++; BAR_KEEP(mix); \
        } \
    } \
}
BAR_OUTM(bar_outm_w, =)
BAR_OUTM(bar_outm, +=)

/* the felt noise after a key-up (LFSR, one-pole ~2 kHz, as the Rhodes), added over its first felt_n samples */
FR_RAM __attribute__((noinline)) static void bar_felt_pass(bar_voice_t *v, int32_t *mix)
{
    uint32_t n = v->felt_n < BAR_N ? v->felt_n : BAR_N, r = bar_lfsr;
    int32_t lp = v->felt_lp, g = (int32_t)(((uint32_t)bar_felt * v->felt_g) >> 15), *e = mix + n;
    for (; mix < e; mix++) {
        int32_t nz;
        r = (r >> 1) ^ (-(r & 1u) & 0xB400u);
        nz = (int32_t)(r & 0xFFFFu) - 32768;
        lp += (nz - lp) >> 3;
        *mix += (int32_t)(((int64_t)lp * g) >> 10);
    }
    bar_lfsr = r; v->felt_lp = lp; v->felt_n = (uint16_t)(v->felt_n - n);
}

/* one voice, one block, into mix[0 .. 256): = if first (the block's first voice), else += */
static void bar_voice_block(bar_voice_t *v, int32_t *mix, int first)
{
    const bar_type_t *ty = &BAR_TYPE[bar_sub < BAR_NTYPE ? bar_sub : 0u];
    uint32_t j, m, sb, nf = FR_FAR(bar_force)(v), nf4 = (nf + 3u) & ~3u, nlive = 0, fade0 = 0, stuck = 0;
#ifdef FR_HQ
    int32_t gain = v->gain, ref, sum, la[BAR_NM + HQB_NX];
#else
    int32_t gain = v->gain, ref, sum, la[BAR_NM];
#endif
    if (v->ramp) {                                  /* the damper moves: every slot's coefficients per sub-block */
        for (sb = 0; sb < BAR_NSUB; sb++) {
            uint32_t o = sb * BAR_SUB;
            int frc = o < nf;
            if (v->ramp) bar_damper_step(v);
            FR_FAR(bar_pair)(v, o, o + BAR_SUB, nf);
#ifdef FR_HQ
            if (v->hq) { hqb_upper(v, o, BAR_SUB, nf); continue; }   /* the HQ voice: its slots in float */
#endif
            for (m = BAR_UP0; m < BAR_NM; m++) {
                bar_ms_t *s = &v->m[m];
                if (!s->live) continue;
                if (s->live == 2u) { bar_run_fade(s, BAR_XT(o), frc); fade0++; continue; }
                bar_run(s, BAR_XT(o), frc, BAR_SUB);
            }
        }
    } else {
        FR_FAR(bar_pair)(v, 0, BAR_N, nf);
#ifdef FR_HQ
        if (v->hq) hqb_upper(v, 0, BAR_N, nf); else   /* the HQ voice: its slots in float */
#endif
        for (m = BAR_UP0; m < BAR_NM; m++) {        /* the upper modes: the whole block at once */
            bar_ms_t *s = &v->m[m];
            uint32_t o = 0;
            if (!s->live) continue;
            if (s->live == 2u) { bar_run_fade(s, bar_xt, nf != 0); fade0++; continue; }
            if (nf4) { bar_run(s, bar_xt, 1, nf4); o = nf4; }   /* (the force is 0 from nf on) */
            if (o < BAR_N) bar_run(s, BAR_XT(o), 0, BAR_N - o);
        }
    }
    {   /* + the tube's radiation, the gain into the mix (the steal fade's own loop; the felt noise a pass of its own) */
        int32_t wt = 0, rad = v->m[1].live && bar_mot_park, mot = v->m[1].live && !bar_mot_park, wd[2u * BAR_NSUB];
        if (rad) wt = v->wt;                        /* the discs parked open: the radiation in the output loop */
        else if (mot)
            for (sb = 0; sb < BAR_NSUB; sb++) {     /* ... its weight ramped by the motor (x its make-up: up to x 2.4,
                                                     * so Q27: |wt| <= 5.8 x 2.4 / 2 < 2^31 / 2^28) */
                int32_t w = bar_sat31(((int64_t)v->wt * bar_mot_g[sb]) >> 16);
                int32_t dw = (bar_sat31(((int64_t)v->wt * bar_mot_g[sb + 1u]) >> 16) - w) >> 5;
                int32_t *x = BAR_XT(sb * BAR_SUB);
                wd[2u * sb] = w; wd[2u * sb + 1u] = dw;
                if (v->fade != 32768)               /* (the steal fade: its own pass first, as before) */
                    for (j = 0; j < BAR_SUB; j++) { x[3u * j] += (int32_t)(((int64_t)w * x[3u * j + 1u]) >> 27); w += dw; }
            }
        if (v->fade == 32768) {
            if (rad) { if (first) bar_out_rad_w(mix, bar_xt, wt, gain); else bar_out_rad(mix, bar_xt, wt, gain); }
            else if (mot) { if (first) FR_FAR(bar_outm_w)(mix, bar_xt, wd, gain); else FR_FAR(bar_outm)(mix, bar_xt, wd, gain); }
            else { if (first) bar_out_w(mix, bar_xt, 0, gain); else bar_out(mix, bar_xt, 0, gain); }
        } else if (rad) v->fade = first ? bar_fade_rad_w(mix, bar_xt, wt, gain, v->fade) : bar_fade_rad(mix, bar_xt, wt, gain, v->fade);
        else v->fade = first ? bar_fade_w(mix, bar_xt, 0, gain, v->fade) : bar_fade(mix, bar_xt, 0, gain, v->fade);
        if (v->felt_n) FR_FAR(bar_felt_pass)(v, mix);
    }
    /* the levels, once a block: each live slot's amplitude, the voice's output, then the end and the sleep */
    sum = 0;
#ifdef FR_HQ
    if (v->hq) hqb_sync(v);                         /* the lanes' x into the slots, for the levels */
    for (m = 0; m < BAR_NMV(v); m++) {
#else
    for (m = 0; m < BAR_NM; m++) {
#endif
        bar_ms_t *s = &v->m[m];
        la[m] = BAR_LZERO;
        if (!s->live) continue;
        s->x1 = bar_sat(s->x1); s->x2 = bar_sat(s->x2);
        la[m] = bar_lamp(s);
        ref = s->amp;                               /* (the last block's) */
        s->amp = bar_exp2(la[m]);
        if (v->w_tgt && s->amp >= ref && s->amp < (v->kill1 << 1)) stuck |= 1u << m;   /* damped, not falling,
                                                     * under 2 LSB out: an upper slot here is in its rounding's limit
                                                     * cycle (below) */
#ifdef DINGHY_HOST
        if (getenv("BAR_DBG")) fprintf(stderr, "m%u la %d amp %d x1 %d x2 %d lsin %d live %u\n", (unsigned)m, (int)la[m], (int)s->amp, (int)s->x1, (int)s->x2, (int)s->lsin, (unsigned)s->live);
#endif
#ifdef DINGHY_HOST
        if ((s->fresh & 2u) && bar_h_pred && m != 1u)
            fprintf(bar_h_pred, "%u %u %d %d\n", (unsigned)v->note, (unsigned)m, (int)s->lpred, (int)la[m]);
        s->fresh &= 1u;
#endif
        if (!v->ptab) s->fresh = 0;                 /* measured from here on */
        sum += m == 1u ? (int32_t)(((int64_t)s->amp * iabs(v->wt)) >> 28) : s->amp;
        nlive += m == 1u ? 0u : m == 0u ? 3u : 1u;  /* the pair: about three modes' work (P0) */
    }
#ifdef DINGHY_HOST
    bar_h_blk_ms += nlive * BAR_N + fade0 * BAR_SUB;
    bar_h_blk_mul += (2u * nlive + 1u) * BAR_N;
#endif
    v->struck = 0;
    if (v->fade == 0) {                             /* a steal finished fading: start the waiting note */
        v->alive = 0;
        if (v->pend) bar_start_pend(v);
        return;
    }
    v->lvl = sum; if (sum > v->lvl0) v->lvl0 = sum;
#ifdef BAR_LVL_LOG
    {   /* (tests/py/test_bar_kill.py: each live voice's level once a block) */
        static uint32_t blk, lastv = 99u;
        if ((uint32_t)(v - bv) <= lastv) blk++;
        lastv = (uint32_t)(v - bv);
        fprintf(stderr, "bl %u %u %u %u %d %d %u", (unsigned)blk, (unsigned)(v - bv), (unsigned)v->note, (unsigned)v->held,
                (int)sum, (int)v->kill1, (unsigned)v->life);
        for (m = 0; m < BAR_NM; m++) fprintf(stderr, " %d", v->m[m].live ? (int)v->m[m].amp : -1);
        fprintf(stderr, "\n");
    }
#endif
    if (!v->ptab && !v->felt_n && sum < v->kill1) { /* under 1 LSB out: the voice ends; a stolen one dying in its
                                                     * fade still starts the note waiting for it (BUGHUNT #21) */
        v->alive = 0;
        if (v->pend) bar_start_pend(v);
        return;
    }
    if (!v->ptab BAR_SLEEP_ON) {                    /* upper modes: absolute and relative sleep, faded out over the
                                                     * next sub-block (live = 2); they never wake on their own. And
                                                     * the stuck ones: with no force and the damper on, a free
                                                     * mode's level falls every block; at a few hundred LSB of x the
                                                     * integer recursion's rounding can hold it in a limit cycle
                                                     * instead (a V4 at ~1 LSB out for 15 s: the voice never fell
                                                     * under kill1, kept its slot and changed the stealing). Damped,
                                                     * under 2 LSB out and not falling: asleep. (Undamped, under the
                                                     * pedal, a slow decay reads flat for blocks: not touched. The HQ
                                                     * voice's upper slots are float: not theirs.) */
        ref = v->m[0].amp + (int32_t)(((int64_t)v->m[1].amp * iabs(v->wt)) >> 28);
        ref >>= ty->sleep_rel;
        if (ref < (v->kill1 >> 4)) ref = v->kill1 >> 4;
#ifdef FR_HQ
        for (m = BAR_UP0; m < BAR_NMV(v); m++) {
#else
        for (m = BAR_UP0; m < BAR_NM; m++) {
#endif
            bar_ms_t *s = &v->m[m];
            if (s->live == 1u && (s->amp < ref || (stuck >> m & 1u BAR_STUCK_ON(v)))) s->live = 2;
        }
    }
}

#define BAR_DITH0 0x6A09E667u
static uint32_t bar_dith = BAR_DITH0;              /* the cut to Q15's TPDF dither (its own generator) */
__attribute__((noinline)) static void bar_render(int32_t *mono_out, uint32_t n)   /* kept out of app_audio */
{
    uint32_t i, sb, j, act = 0, held = 0, ty = bar_sub < BAR_NTYPE ? bar_sub : 0u, nb = BAR_TYPE[ty].nbody, r;
    int32_t mx = 0, first = 1, hi = 0, lo = 0, dm, a, b;
#if defined(FR_HQ) && HQB_CONTACT
    hqb_ck_n = 0;                                   /* (this block's strikes are in: the next block's count anew) */
#endif
    bar_motor_block();
    bar_budget();
#ifdef DINGHY_HOST
    bar_h_blk_ns = 1000u * bar_plan_us;             /* the cost model's time for this block, effects included */
#endif
    for (i = 0; i < BAR_NV; i++) {
        bar_voice_t *v = &bv[i];
        if (!v->alive) continue;
        bar_voice_block(v, bar_mono, first);        /* the first voice writes bar_mono, the others add */
        first = 0;
        if (v->alive && v->life && --v->life == 0 && !v->pend) v->alive = 0;   /* (a stolen voice: its fade ends it,
                                                     * then starts the waiting note: BUGHUNT #21) */
    }
    for (sb = 0, a = 0; sb < 2u; sb++) a |= bar_bd_m[sb][0] | bar_bd_m[sb][1] | bar_bd_o[sb][0] | bar_bd_o[sb][1] | bar_bd_e[sb];
    dm = first && !bar_nz_e && !a ? 0 : -1;         /* (silent: no voice, no noise, the EQ at rest: no dither, the
                                                     * output stays exact 0, at boot too) */
    if (first) for (i = 0; i < BAR_N; i++) bar_mono[i] = 0;   /* no voice: silence (+ the contact noise's tail) */
    if (bar_nz_e) {                                 /* contact noise: LFSR -> two biquads (Q14, transposed DF2) x the
                                                     * envelope (tau ~ 23 ms); off, and exactly silent, under 1/2 LSB */
        int32_t e = bar_nz_e, s0 = bar_nz_s[0], s1 = bar_nz_s[1], s2 = bar_nz_s[2], s3 = bar_nz_s[3];
        uint32_t r = bar_lfsr;
        for (j = 0; j < n; j++) {
            int32_t nz, y;
            r = (r >> 1) ^ (-(r & 1u) & 0xB400u);
            nz = ((int32_t)(r & 0xFFFFu) - 32768) >> 2;
            y = ((NZ_BQ[0][0] * nz) >> 14) + s0;
            s0 = (int32_t)(((int64_t)NZ_BQ[0][1] * nz - (int64_t)NZ_BQ[0][3] * y) >> 14) + s1;
            s1 = (int32_t)(((int64_t)NZ_BQ[0][2] * nz - (int64_t)NZ_BQ[0][4] * y) >> 14);
            nz = y;
            y = (int32_t)(((int64_t)NZ_BQ[1][0] * nz) >> 14) + s2;
            s2 = (int32_t)(((int64_t)NZ_BQ[1][1] * nz - (int64_t)NZ_BQ[1][3] * y) >> 14) + s3;
            s3 = (int32_t)(((int64_t)NZ_BQ[1][2] * nz - (int64_t)NZ_BQ[1][4] * y) >> 14);
            bar_mono[j] += (int32_t)(((int64_t)y * e) >> 13);
            e -= (e + 1023) >> 10;                  /* reaches 0: no floor at 1023 */
        }
        bar_lfsr = r;
        if (e < 16) e = s0 = s1 = s2 = s3 = 0;
        bar_nz_e = e; bar_nz_s[0] = s0; bar_nz_s[1] = s1; bar_nz_s[2] = s2; bar_nz_s[3] = s3;
#ifdef DINGHY_HOST
        bar_h_blk_mul += 11u * n;
#endif
    }
    r = dm ? bar_dith : BAR_DITH0;                  /* (silent: the dither starts over, a take from silence is
                                                     * the same integers every time) */
    for (j = 0; j < n; j++) {                       /* the type's room / mic EQ (Q28 DF1, 0..2 biquads); Q20 -> Q15,
                                                     * TPDF dithered (rhodes.c RH_DITH, GitHub #16) */
        int32_t o = bar_mono[j];
        for (sb = 0; sb < nb; sb++) {
            const int32_t *b = BAR_BODY[ty][sb];
            int64_t a2 = (int64_t)b[0] * o + (int64_t)b[1] * bar_bd_m[sb][0] + (int64_t)b[2] * bar_bd_m[sb][1]
                       - (int64_t)b[3] * bar_bd_o[sb][0] - (int64_t)b[4] * bar_bd_o[sb][1] + bar_bd_e[sb];
            int32_t y = (int32_t)(a2 >> 28);
            bar_bd_e[sb] = (int32_t)(a2 & 0xFFFFFFF);
            bar_bd_m[sb][1] = bar_bd_m[sb][0]; bar_bd_m[sb][0] = o; bar_bd_o[sb][1] = bar_bd_o[sb][0]; bar_bd_o[sb][0] = y;
            o = y;
        }
        o = BAR_MIX(o);
        if (o > hi) hi = o;
        if (o < lo) lo = o;
        { int32_t d = RH_DITH(r); mono_out[j] = (o + 16 + ((d - 16) & dm)) >> 5; }
    }
    bar_dith = dm ? r : BAR_DITH0;
    a = (hi + 16) >> 5; b = (15 - lo) >> 5;         /* max |round(x)|, undithered: the silence test as before */
    mx = a > b ? a : b;
    for (i = 0; i < BAR_NV; i++)
        if (bv[i].alive) { act |= 1u << i; bar_notes[i] = bv[i].note; if (bv[i].held) held |= 1u << i; }
    if (!act && mx < 2) {
        for (sb = 0; sb < 2u; sb++) bar_bd_m[sb][0] = bar_bd_m[sb][1] = bar_bd_o[sb][0] = bar_bd_o[sb][1] = bar_bd_e[sb] = 0;
        if (bar_quiet_blocks < 0xFFFFu) bar_quiet_blocks++;
    } else
        bar_quiet_blocks = 0;
    bar_held_bits = held;
    bar_active_bits = act;
    bar_starts = 0;                                 /* (the next block's strikes count anew) */
#ifdef DINGHY_HOST
    bar_h_ms += bar_h_blk_ms; bar_h_mul += bar_h_blk_mul;
#endif
}
#else
/* ---- FR_C1 (two cores): the block in chunks. engine.c calls bar_begin(n) once a block (after the events), then
 * bar_chunk(mono_out, o, e) for each chunk [o, e) in order (o, e multiples of BAR_SUB), then bar_end(). The chunks
 * render bar_render's one-block integers exactly, for any chunk size (tests/py/test_c1_bars.py: 32, 64, 256):
 *  - the per-block work stays in bar_begin: the motor, the budget, the pulse's length (bar_force's division) and its end
 *    (v->ptab), the damper's path (v->ramp at the block's start), the voices alive (they end only at the block's end:
 *    a steal's fade, BAR_FADE_STEP x 256 >= 32767, always ends in the block it started);
 *  - every recursion runs sample by sample, its state carried from chunk to chunk (the kernels split at multiples of 4,
 *    the pair and the damper per sub-block, the output loops count-bounded copies of the one-block ones);
 *  - the one LFSR keeps its order: each felt voice's start is the state after the felt voices before it (bar_lfsr_skip),
 *    the contact noise starts after the last one;
 *  - the contact noise's level: the steals' notes start at the block's end (bar_end, in voice order, as before) and
 *    each adds its strike to bar_nz_e before the noise ran; bar_begin adds those increments up front (the same integers,
 *    bar_fam / bar_nz do not change inside the ISR), so the noise of the first chunk already plays the block's level;
 *  - the levels, the ends, the steals' notes, the sleep and life: bar_end, voice by voice, in voice order.
 * bar_render (one core: CC 10's block, core 1 held) is bar_begin + one chunk + bar_end. */
_Static_assert(BAR_FADE_STEP * BAR_N >= 32767u, "FR_C1: a steal's fade must end in the block it starts");
typedef struct {
    const int16_t *t;                               /* the pulse table this block (v->ptab at the block's start) */
    uint32_t pos, nf;                               /* its position at the block's start, its samples this block */
    uint32_t fr;                                    /* the felt noise's LFSR state, as it plays */
    uint16_t fn;                                    /* the felt noise's samples this block */
    uint8_t ramp;                                   /* the damper moves this block (per sub-block coefficients) */
} bar_c1v_t;
static bar_c1v_t bar_c1v[BAR_NV];
static uint32_t bar_c1_act;                         /* the voices alive at the block's start (they render every chunk) */
static uint32_t bar_c1_r, bar_c1_nzr;               /* the dither generator; the LFSR (felt end, then the noise) */
static int32_t bar_c1_dm, bar_c1_hi, bar_c1_lo, bar_c1_nze, bar_c1_nzp;
static uint8_t bar_c1_nzon;

static uint32_t bar_lfsr_skip(uint32_t r, uint32_t k)   /* k steps of bar_lfsr's generator */
{
    while (k--) r = (r >> 1) ^ (-(r & 1u) & 0xB400u);
    return r;
}

/* the pulse into the force slots of samples [o, e) (as F << 12, bar_force's integers), and the zeros after its end to
 * the end of that sub-block */
FR_RAM __attribute__((noinline)) static void bar_force(const bar_voice_t *v, const bar_c1v_t *c, uint32_t o, uint32_t e)
{
    const int16_t *t = c->t;
    uint32_t nf = c->nf, rate = v->prate, pos = c->pos + o * rate, z = (nf + BAR_SUB) & ~(BAR_SUB - 1u), s1;
    int32_t amp = v->pamp, *q = BAR_XT(o) + 2, *qe;
    if (!nf) return;
    s1 = e < nf ? e : nf;
    for (qe = q + 3u * (s1 > o ? s1 - o : 0u); q < qe; q += 3) {
        uint32_t i = pos >> 16;
        int32_t f = (int32_t)((pos >> 1) & 0x7FFFu), a = t[i], d = t[i + 1u] - a;
        *q = (((a + ((d * f) >> 15)) * amp) >> 15) << 12;
        pos += rate;
    }
    if (z > e) z = e;
    for (s1 = o > nf ? o : nf; s1 < z; s1++) BAR_XT(s1)[2] = 0;
}

/* the output loops, count-bounded (n samples from mix; bar_render's BAR_OUT / BAR_FADE / BAR_OUTM otherwise) */
#define BAR_OUT(NAME, OP, RAD) \
__attribute__((noinline)) static void NAME(int32_t *mix, const int32_t *x, int32_t wt, int32_t gain, uint32_t n) \
{ \
    int32_t *e = mix + n; \
    (void)wt; \
    for (; mix < e; mix++, x += 3) { \
        int32_t y = RAD ? x[0] + (int32_t)(((int64_t)wt * x[1]) >> 28) : x[0]; \
        *mix OP (int32_t)(((int64_t)y * gain) >> 24); \
    } \
}
#define BAR_FADE(NAME, OP, RAD) \
__attribute__((noinline)) static int32_t NAME(int32_t *mix, const int32_t *x, int32_t wt, int32_t gain, int32_t f, uint32_t n) \
{ \
    int32_t *e = mix + n; \
    (void)wt; \
    for (; mix < e; mix++, x += 3) { \
        int32_t y = RAD ? x[0] + (int32_t)(((int64_t)wt * x[1]) >> 28) : x[0]; \
        int32_t o = (int32_t)(((int64_t)y * gain) >> 24); \
        o = (int32_t)(((int64_t)o * f) >> 15); \
        f -= BAR_FADE_STEP; \
        if (f < 0) f = 0; \
        *mix OP o; \
    } \
    return f; \
}
BAR_OUT(bar_out_w, =, 0)
BAR_OUT(bar_out_rad_w, =, 1)
BAR_FADE(bar_fade_w, =, 0)
BAR_FADE(bar_fade_rad_w, =, 1)
BAR_OUT(bar_out, +=, 0)
BAR_OUT(bar_out_rad, +=, 1)
BAR_FADE(bar_fade, +=, 0)
BAR_FADE(bar_fade_rad, +=, 1)
#ifdef HAL_KEEP_REG
#define BAR_KEEP(p) HAL_KEEP_REG(p)
#else
#define BAR_KEEP(p) ((void)0)
#endif
#define BAR_OUTM(NAME, OP) \
FR_RAM __attribute__((noinline)) static void NAME(int32_t *mix, const int32_t *x, const int32_t *wd, int32_t gain, uint32_t n) \
{ \
    int32_t *e = mix + n; \
    while (mix < e) { \
        int32_t w = *wd++, dw = *wd++, *se = mix + BAR_SUB; \
        while (mix < se) { \
            int32_t y = x[0] + (int32_t)(((int64_t)w * x[1]) >> 27); \
            w += dw; x += 3; BAR_KEEP(x); \
            *mix OP (int32_t)(((int64_t)y * gain) >> 24); \
            mix++; BAR_KEEP(mix); \
        } \
    } \
}
BAR_OUTM(bar_outm_w, =)
BAR_OUTM(bar_outm, +=)

/* the felt noise over samples [o, e) of its c->fn this block */
FR_RAM __attribute__((noinline)) static void bar_felt_pass(bar_voice_t *v, bar_c1v_t *c, int32_t *mix, uint32_t o, uint32_t e)
{
    uint32_t n = (c->fn < e ? c->fn : e) - o, r = c->fr;
    int32_t lp = v->felt_lp, g = (int32_t)(((uint32_t)bar_felt * v->felt_g) >> 15), *me = mix + n;
    for (; mix < me; mix++) {
        int32_t nz;
        r = (r >> 1) ^ (-(r & 1u) & 0xB400u);
        nz = (int32_t)(r & 0xFFFFu) - 32768;
        lp += (nz - lp) >> 3;
        *mix += (int32_t)(((int64_t)lp * g) >> 10);
    }
    c->fr = r; v->felt_lp = lp; v->felt_n = (uint16_t)(v->felt_n - n);
}

/* one voice, samples [o, e), into mix = bar_mono + o: = if first (the chunk's first voice), else += */
static void bar_voice_chunk(bar_voice_t *v, bar_c1v_t *c, int32_t *mix, uint32_t o, uint32_t e, int first)
{
    uint32_t m, sb, j, nf = c->nf, n = e - o;
    int32_t gain = v->gain;
    FR_FAR(bar_force)(v, c, o, e);
    if (c->ramp) {                                  /* the damper moves: every slot's coefficients per sub-block */
        for (sb = o; sb < e; sb += BAR_SUB) {
            int frc = sb < nf;
            if (v->ramp) bar_damper_step(v);
            FR_FAR(bar_pair)(v, sb, sb + BAR_SUB, nf);
            for (m = BAR_UP0; m < BAR_NM; m++) {
                bar_ms_t *s = &v->m[m];
                if (!s->live) continue;
                if (s->live == 2u) {
                    bar_run_fade(s, BAR_XT(sb), frc);
#ifdef DINGHY_HOST
                    bar_h_blk_ms += BAR_SUB;
#endif
                    continue;
                }
                bar_run(s, BAR_XT(sb), frc, BAR_SUB);
            }
        }
    } else {
        uint32_t nf4 = (nf + 3u) & ~3u, f1 = nf4 < e ? nf4 : e;
        FR_FAR(bar_pair)(v, o, e, nf);
        for (m = BAR_UP0; m < BAR_NM; m++) {        /* the upper modes: the whole chunk at once */
            bar_ms_t *s = &v->m[m];
            uint32_t a = o;
            if (!s->live) continue;
            if (s->live == 2u) {                    /* (live 2 only at the block's start: o is 0) */
                bar_run_fade(s, BAR_XT(o), nf != 0);
#ifdef DINGHY_HOST
                bar_h_blk_ms += BAR_SUB;
#endif
                continue;
            }
            if (f1 > a) { bar_run(s, BAR_XT(a), 1, f1 - a); a = f1; }   /* (the force is 0 from nf on) */
            if (a < e) bar_run(s, BAR_XT(a), 0, e - a);
        }
    }
    {   /* + the tube's radiation, the gain into the mix (the steal fade's own loop; the felt noise a pass of its own) */
        int32_t wt = 0, rad = v->m[1].live && bar_mot_park, mot = v->m[1].live && !bar_mot_park, wd[2u * BAR_NSUB];
        const int32_t *x = BAR_XT(o);
        if (rad) wt = v->wt;
        else if (mot)
            for (sb = o / BAR_SUB, j = 0; sb < e / BAR_SUB; sb++, j += 2u) {
                int32_t w = bar_sat31(((int64_t)v->wt * bar_mot_g[sb]) >> 16);
                int32_t dw = (bar_sat31(((int64_t)v->wt * bar_mot_g[sb + 1u]) >> 16) - w) >> 5;
                int32_t *xs = BAR_XT(sb * BAR_SUB);
                uint32_t k;
                wd[j] = w; wd[j + 1u] = dw;
                if (v->fade != 32768)
                    for (k = 0; k < BAR_SUB; k++) { xs[3u * k] += (int32_t)(((int64_t)w * xs[3u * k + 1u]) >> 27); w += dw; }
            }
        if (v->fade == 32768) {
            if (rad) { if (first) bar_out_rad_w(mix, x, wt, gain, n); else bar_out_rad(mix, x, wt, gain, n); }
            else if (mot) { if (first) FR_FAR(bar_outm_w)(mix, x, wd, gain, n); else FR_FAR(bar_outm)(mix, x, wd, gain, n); }
            else { if (first) bar_out_w(mix, x, 0, gain, n); else bar_out(mix, x, 0, gain, n); }
        } else if (rad) v->fade = first ? bar_fade_rad_w(mix, x, wt, gain, v->fade, n) : bar_fade_rad(mix, x, wt, gain, v->fade, n);
        else v->fade = first ? bar_fade_w(mix, x, 0, gain, v->fade, n) : bar_fade(mix, x, 0, gain, v->fade, n);
        if (c->fn > o) FR_FAR(bar_felt_pass)(v, c, mix, o, e);
    }
}

/* one voice's end of block (bar_render's bar_voice_block tail): the levels, the end and the steal's note, the sleep */
static void bar_voice_tail(bar_voice_t *v)
{
    const bar_type_t *ty = &BAR_TYPE[bar_sub < BAR_NTYPE ? bar_sub : 0u];
    uint32_t m, nlive = 0, stuck = 0;
    int32_t ref, sum, la[BAR_NM];
    sum = 0;
    for (m = 0; m < BAR_NM; m++) {
        bar_ms_t *s = &v->m[m];
        la[m] = BAR_LZERO;
        if (!s->live) continue;
        s->x1 = bar_sat(s->x1); s->x2 = bar_sat(s->x2);
        la[m] = bar_lamp(s);
        ref = s->amp;                               /* (the last block's) */
        s->amp = bar_exp2(la[m]);
        if (v->w_tgt && s->amp >= ref && s->amp < (v->kill1 << 1)) stuck |= 1u << m;
#ifdef DINGHY_HOST
        if (getenv("BAR_DBG")) fprintf(stderr, "m%u la %d amp %d x1 %d x2 %d lsin %d live %u\n", (unsigned)m, (int)la[m], (int)s->amp, (int)s->x1, (int)s->x2, (int)s->lsin, (unsigned)s->live);
#endif
#ifdef DINGHY_HOST
        if ((s->fresh & 2u) && bar_h_pred && m != 1u)
            fprintf(bar_h_pred, "%u %u %d %d\n", (unsigned)v->note, (unsigned)m, (int)s->lpred, (int)la[m]);
        s->fresh &= 1u;
#endif
        if (!v->ptab) s->fresh = 0;
        sum += m == 1u ? (int32_t)(((int64_t)s->amp * iabs(v->wt)) >> 28) : s->amp;
        nlive += m == 1u ? 0u : m == 0u ? 3u : 1u;
    }
#ifdef DINGHY_HOST
    bar_h_blk_ms += nlive * BAR_N;
    bar_h_blk_mul += (2u * nlive + 1u) * BAR_N;
#endif
    v->struck = 0;
    if (v->fade == 0) {                             /* a steal finished fading: start the waiting note */
        v->alive = 0;
        if (v->pend) bar_start_pend(v);
        return;
    }
    v->lvl = sum; if (sum > v->lvl0) v->lvl0 = sum;
#ifdef BAR_LVL_LOG
    {
        static uint32_t blk, lastv = 99u;
        if ((uint32_t)(v - bv) <= lastv) blk++;
        lastv = (uint32_t)(v - bv);
        fprintf(stderr, "bl %u %u %u %u %d %d %u", (unsigned)blk, (unsigned)(v - bv), (unsigned)v->note, (unsigned)v->held,
                (int)sum, (int)v->kill1, (unsigned)v->life);
        for (m = 0; m < BAR_NM; m++) fprintf(stderr, " %d", v->m[m].live ? (int)v->m[m].amp : -1);
        fprintf(stderr, "\n");
    }
#endif
    if (!v->ptab && !v->felt_n && sum < v->kill1) {
        v->alive = 0;
        if (v->pend) bar_start_pend(v);
        return;
    }
    if (!v->ptab BAR_SLEEP_ON) {
        ref = v->m[0].amp + (int32_t)(((int64_t)v->m[1].amp * iabs(v->wt)) >> 28);
        ref >>= ty->sleep_rel;
        if (ref < (v->kill1 >> 4)) ref = v->kill1 >> 4;
        for (m = BAR_UP0; m < BAR_NM; m++) {
            bar_ms_t *s = &v->m[m];
            if (s->live == 1u && (s->amp < ref || (stuck >> m & 1u BAR_STUCK_ON(v)))) s->live = 2;
        }
    }
}

#define BAR_DITH0 0x6A09E667u
static uint32_t bar_dith = BAR_DITH0;              /* the cut to Q15's TPDF dither (its own generator) */
static void bar_begin(uint32_t n)
{
    uint32_t i, sb, act = 0, r = bar_lfsr, L = (uint32_t)BAR_PLEN << 16;
    int32_t a, nz = bar_nz_e;
    (void)n;
    bar_motor_block();
    bar_budget();
#ifdef DINGHY_HOST
    bar_h_blk_ns = 1000u * bar_plan_us;
#endif
    for (i = 0; i < BAR_NV; i++) {
        bar_voice_t *v = &bv[i];
        bar_c1v_t *c = &bar_c1v[i];
        if (!v->alive) continue;
        act |= 1u << i;
        c->t = v->ptab; c->pos = v->ppos; c->nf = 0;
        if (v->ptab) {                              /* bar_force's length; the pulse's end */
            uint32_t pos = v->ppos, rate = v->prate, k = pos >= L ? 1u : (L - pos + rate - 1u) / rate;
            if (k > BAR_N) k = BAR_N;
            else v->ptab = 0;
            c->nf = k; v->ppos = pos + k * rate;
        }
        c->ramp = v->ramp != 0;
        c->fn = (uint16_t)(v->felt_n < BAR_N ? v->felt_n : BAR_N);
        if (c->fn) { c->fr = r; r = bar_lfsr_skip(r, c->fn); }
        if (v->pend && v->fade != 32768)            /* its note starts at the block's end (bar_init's noise strike) */
            nz += bar_nz_strike(v->pend_vel);   /* (as bar_init: RESPONSE B included) */
    }
    bar_c1_act = act;
    bar_c1_nzr = r;
    bar_c1_nzp = bar_c1_nze = nz;
    bar_c1_nzon = nz != 0;
    for (sb = 0, a = 0; sb < 2u; sb++) a |= bar_bd_m[sb][0] | bar_bd_m[sb][1] | bar_bd_o[sb][0] | bar_bd_o[sb][1] | bar_bd_e[sb];
    bar_c1_dm = !act && !nz && !a ? 0 : -1;
    bar_c1_r = bar_c1_dm ? bar_dith : BAR_DITH0;
    bar_c1_hi = bar_c1_lo = 0;
}

#if FR_LAT_EV
/* FR_LAT_EV (frodhes.c FR_LAT_HALF): a note-on the block's start left waiting (BAR_START_MAX) starts at a later
 * interrupt of the block, from its first frame o, on a free voice: bar_init now, the voice planned as bar_begin
 * plans it but from frame o (the pulse's samples from o, its contact noise from o on, the dither on from o). A note
 * still ringing (a re-strike) or no free voice (a steal: its fade is the block's) waits for the block's start. The
 * starts an interrupt stay within BAR_START_MAX, the steals' notes that start at this block's end (bar_end) counted
 * (the block's last interrupt). The felt noise's LFSR is untouched (a new voice has none) */
static uint32_t bar_mid_o;                          /* the interrupt's first frame (bar_mid) */
static void bar_mid(uint32_t o, int last)
{
    uint32_t i, k = 0;
    bar_mid_o = o;
    if (last)
        for (i = 0; i < BAR_NV; i++) if (bv[i].alive && bv[i].pend) k++;
    bar_starts = k;
}
static int bar_mid_one(uint32_t note, uint32_t vel)
{
    uint32_t i, o = bar_mid_o, L = (uint32_t)BAR_PLEN << 16;
    int32_t nz0 = bar_nz_e, d;
    bar_voice_t *v;
    bar_c1v_t *c;
    if (bar_starts >= BAR_START_MAX || !o || o >= BAR_N) return 0;
    for (i = 0; i < BAR_NV; i++)
        if (bv[i].alive && bv[i].note == note) return 0;   /* (a re-strike, or a steal's note: the block's start) */
    for (i = 0; i < BAR_NA && (bv[i].alive || bv[i].pend); i++) ;
    if (i == BAR_NA) return 0;
    v = &bv[i]; c = &bar_c1v[i];
    bar_starts++;
    bar_init(v, note, vel);
    c->t = v->ptab; c->nf = 0;
    if (v->ptab) {                                  /* (bar_begin's plan, the block's frames from o on) */
        uint32_t pos = v->ppos, rate = v->prate, kk = pos >= L ? 1u : (L - pos + rate - 1u) / rate;
        if (kk > BAR_N - o) kk = BAR_N - o;
        else v->ptab = 0;
        c->pos = pos - o * rate;                    /* (bar_force reads pos + j x rate from the block's frame j) */
        c->nf = o + kk; v->ppos = pos + kk * rate;
    } else
        c->pos = v->ppos - o * v->prate;
    c->ramp = v->ramp != 0;
    c->fn = 0;
    d = bar_nz_e - nz0;                             /* (bar_init's contact noise: from frame o on) */
    bar_c1_nze += d; bar_c1_nzp += d;
    if (bar_c1_nze) bar_c1_nzon = 1;
    bar_c1_dm = -1;
    bar_c1_act |= 1u << i;
#ifdef DINGHY_HOST
    if (v->felt_n) { fprintf(stderr, "bars FR_LAT_EV: a new voice with felt noise\n"); abort(); }
    bar_h_mid++;
#endif
    return 1;
}
#endif
__attribute__((noinline)) static void bar_chunk(int32_t *mono_out, uint32_t o, uint32_t e)
{
    uint32_t i, sb, j, act = bar_c1_act, ty = bar_sub < BAR_NTYPE ? bar_sub : 0u, nb = BAR_TYPE[ty].nbody, r;
    int32_t first = 1, hi = bar_c1_hi, lo = bar_c1_lo, dm = bar_c1_dm;
    for (i = 0; act; i++, act >>= 1)
        if (act & 1u) { bar_voice_chunk(&bv[i], &bar_c1v[i], bar_mono + o, o, e, first); first = 0; }
    if (first) for (j = o; j < e; j++) bar_mono[j] = 0;
    if (bar_c1_nzon) {                              /* contact noise (bar_render's loop on [o, e)) */
        int32_t ev = bar_c1_nze, s0 = bar_nz_s[0], s1 = bar_nz_s[1], s2 = bar_nz_s[2], s3 = bar_nz_s[3];
        r = bar_c1_nzr;
        for (j = o; j < e; j++) {
            int32_t nz, y;
            r = (r >> 1) ^ (-(r & 1u) & 0xB400u);
            nz = ((int32_t)(r & 0xFFFFu) - 32768) >> 2;
            y = ((NZ_BQ[0][0] * nz) >> 14) + s0;
            s0 = (int32_t)(((int64_t)NZ_BQ[0][1] * nz - (int64_t)NZ_BQ[0][3] * y) >> 14) + s1;
            s1 = (int32_t)(((int64_t)NZ_BQ[0][2] * nz - (int64_t)NZ_BQ[0][4] * y) >> 14);
            nz = y;
            y = (int32_t)(((int64_t)NZ_BQ[1][0] * nz) >> 14) + s2;
            s2 = (int32_t)(((int64_t)NZ_BQ[1][1] * nz - (int64_t)NZ_BQ[1][3] * y) >> 14) + s3;
            s3 = (int32_t)(((int64_t)NZ_BQ[1][2] * nz - (int64_t)NZ_BQ[1][4] * y) >> 14);
            bar_mono[j] += (int32_t)(((int64_t)y * ev) >> 13);
            ev -= (ev + 1023) >> 10;
        }
        bar_c1_nzr = r;
        bar_c1_nze = ev; bar_nz_s[0] = s0; bar_nz_s[1] = s1; bar_nz_s[2] = s2; bar_nz_s[3] = s3;
#ifdef DINGHY_HOST
        bar_h_blk_mul += 11u * (e - o);
#endif
    }
    r = bar_c1_r;
    for (j = o; j < e; j++) {                       /* the type's room / mic EQ; Q20 -> Q15, TPDF dithered */
        int32_t ov = bar_mono[j];
        for (sb = 0; sb < nb; sb++) {
            const int32_t *b = BAR_BODY[ty][sb];
            int64_t a2 = (int64_t)b[0] * ov + (int64_t)b[1] * bar_bd_m[sb][0] + (int64_t)b[2] * bar_bd_m[sb][1]
                       - (int64_t)b[3] * bar_bd_o[sb][0] - (int64_t)b[4] * bar_bd_o[sb][1] + bar_bd_e[sb];
            int32_t y = (int32_t)(a2 >> 28);
            bar_bd_e[sb] = (int32_t)(a2 & 0xFFFFFFF);
            bar_bd_m[sb][1] = bar_bd_m[sb][0]; bar_bd_m[sb][0] = ov; bar_bd_o[sb][1] = bar_bd_o[sb][0]; bar_bd_o[sb][0] = y;
            ov = y;
        }
        ov = BAR_MIX(ov);
        if (ov > hi) hi = ov;
        if (ov < lo) lo = ov;
        { int32_t d = RH_DITH(r); mono_out[j] = (ov + 16 + ((d - 16) & dm)) >> 5; }
    }
    bar_c1_r = r; bar_c1_hi = hi; bar_c1_lo = lo;
}

static void bar_end(void)
{
    uint32_t i, sb, act = 0, held = 0;
    int32_t mx, a, b;
#ifdef DINGHY_HOST
    {   /* (host: each felt voice used exactly its share of the LFSR, the noise started where the last one ended) */
        uint32_t r = bar_lfsr;
        for (i = 0; i < BAR_NV; i++)
            if (bar_c1_act >> i & 1u && bar_c1v[i].fn) {
                r = bar_lfsr_skip(r, bar_c1v[i].fn);
                if (bar_c1v[i].fr != r) { fprintf(stderr, "bars FR_C1: voice %u felt LFSR off\n", (unsigned)i); abort(); }
            }
    }
#endif
    for (i = 0; i < BAR_NV; i++) {
        bar_voice_t *v = &bv[i];
        if (!(bar_c1_act >> i & 1u)) continue;
        bar_voice_tail(v);
        if (v->alive && v->life && --v->life == 0 && !v->pend) v->alive = 0;
    }
#ifdef DINGHY_HOST
    if (bar_nz_e != bar_c1_nzp) { fprintf(stderr, "bars FR_C1: noise level %d, predicted %d\n", (int)bar_nz_e, (int)bar_c1_nzp); abort(); }
#endif
    if (bar_c1_nzon) {
        int32_t e = bar_c1_nze;
        if (e < 16) e = bar_nz_s[0] = bar_nz_s[1] = bar_nz_s[2] = bar_nz_s[3] = 0;
        bar_nz_e = e;
    }
    bar_lfsr = bar_c1_nzr;
    bar_dith = bar_c1_dm ? bar_c1_r : BAR_DITH0;
    a = (bar_c1_hi + 16) >> 5; b = (15 - bar_c1_lo) >> 5;
    mx = a > b ? a : b;
    for (i = 0; i < BAR_NV; i++)
        if (bv[i].alive) { act |= 1u << i; bar_notes[i] = bv[i].note; if (bv[i].held) held |= 1u << i; }
    if (!act && mx < 2) {
        for (sb = 0; sb < 2u; sb++) bar_bd_m[sb][0] = bar_bd_m[sb][1] = bar_bd_o[sb][0] = bar_bd_o[sb][1] = bar_bd_e[sb] = 0;
        if (bar_quiet_blocks < 0xFFFFu) bar_quiet_blocks++;
    } else
        bar_quiet_blocks = 0;
    bar_held_bits = held;
    bar_active_bits = act;
    bar_starts = 0;
#ifdef DINGHY_HOST
    bar_h_ms += bar_h_blk_ms; bar_h_mul += bar_h_blk_mul;
#endif
}

#ifndef BAR_C1_RSUB
#define BAR_C1_RSUB 1u                              /* (host tests: bar_render's block in this many chunks) */
#endif
__attribute__((noinline)) static void bar_render(int32_t *mono_out, uint32_t n)   /* one core: the block as one chunk */
{
    uint32_t o, k = n / BAR_C1_RSUB;
    bar_begin(n);
    for (o = 0; o < n; o += k) bar_chunk(mono_out, o, o + k);
    bar_end();
}
#endif
