/* SPDX-License-Identifier: GPL-3.0-only */
/* REVERB TYPE PLATE at the full rate (FR_REV_HQ; rev_hq.c, a copy of rev_plate.c at 44.1 kHz, 32 samples a call:
 * the half-rate plate stays rev_plate.c): the figure-8 plate tank of J. Dattorro, "Effect Design, Part 1: Reverberator and Other Filters"
 * (J. Audio Eng. Soc. 45(9), 1997), written here from the paper's figure and tables (integer, half rate).
 *
 * Included by rev_types.c (the framework), after fx.c: it uses fx.c's sh_tz, hl_c16, clampi, exp2_neg, osc_sine,
 * CTL, FS and RQ_NC. Runs at the half rate (22.05 kHz), one control block = RQ_NC = 16 samples a call:
 *   in -> bandwidth one-pole -> 4 input allpasses (142 / 107 / 379 / 277, g 0.75 / 0.625) -> the tank, two halves
 *   fed crosswise, each: + the other half's end x decay -> modulated allpass (672 / 908, g -0.7) -> delay (4453 /
 *   4217) -> damping one-pole -> x decay -> allpass (1800 / 2656, g = decay + 0.15 in 0.25 .. 0.5) -> delay (3720 /
 *   3163); 7 taps a side (the paper's table 2) -> mid / side.
 * The paper's lengths are at 29.76 kHz: x 0.7409 here (PL_R), and x 0.5 .. x 1 by SIZE.
 *
 * Memory: the tank's 8 lines share one ring of PL_N int16 (each line its own segment, all moving with one write
 * index: a line writes at w + its top and reads w + its top - its delay; PL_GAP samples between segments keep a
 * block's 16 writes out of a neighbour's reads); the 4 input allpasses share a small one the same way (PL_IN).
 * Every read is at least one block (16 samples) back, so a block runs stage by stage, each stage over its 16 samples,
 * with plain pointers: the rings carry PL_G guard samples after their end, a copy of their first PL_G (made at the
 * start of each block: a read sees only older blocks' writes), and a write that runs past the end lands in the guard
 * and is copied back to the front at the end of the block (pl_ptr, pl_wptr, pl_fix).
 * Start is O(1) (the ring is not cleared): while all of a read site's 16 reads are older than the start they come from
 * a block of zeros; in the block where they cross the start they reach back at most PL_G writes before it, and the
 * start zeroed those (each line's PL_G positions below its top: 8 x 17), so stale content (the other type's) reads
 * as 0, exactly as from a cleared ring (tests/py/test_rev_plate.py: started over garbage = started over zeros).
 * Every product in the loop is truncated toward zero (sh_tz) and the one-poles decay toward their input, so with no
 * input the tail ends in exact zeros; rev_plate_active() is 0 once the input and every line write have been 0 for
 * longer than the whole ring.
 *
 * Knobs (rev_ctl_t, per control block): DECAY 0..127 = T60 0.8 .. 6 s (exponential; per round of the tank the gain
 * is decay^4); TONE (damp 0..150, 60 = the default) = the in-loop damping and the input bandwidth; SIZE 0..127 = the
 * lengths x 0.5 .. x 1 (glides one step a block); MOD 0..127 = the modulated allpasses' excursion, 0 .. +-11.9
 * samples (64 = +-6, the paper's +-8 at 29.76 kHz), a 1 Hz sine, the two halves in quadrature.
 *
 * Cost (REV_US_PLATE): see the table at its #define (compiled pi32v2 -Os, loop counts from build/frodhes.dis). */

/* The cost, instructions per control block (16 half-rate samples; compiled pi32v2 -Os, build/frodhes.dis, every
 * instruction outside the loops counted as run once: an upper bound):
 *   pl_in        67 x 16 (+ 25)           1097   the bandwidth one-pole + the 4 input allpasses (62 before 0.9.6's
 *                                                 64-bit one-pole, BUGHUNT #22: + 80)
 *   pl_half x 2  (38 + 32) x 16 (+ 43)    2326   the tank's two halves
 *   pl_taps      16 x 16 (+ 10)            266   the 7 left taps
 *   pl_taps_ms   34 x 16 (+ 17)            561   the 7 right taps, mid / side (31 before rev-upsample's mid / side
 *                                                 history ahead of the block: +48, ~2 us, inside REV_US_PLATE)
 *   rev_plate_run: the pointers 25 x 4 + 10 x 22 + 11 x 8, the guard copies 2 x 27, the rest 317     779
 *   = 4981 at rest; at worst + a SIZE step's 3 delays 87 + the decay gain 40 + the warm-up's checked reads (the
 *   first 0.15 s after a start) 132 + a wrapped write's copy 81 = 5321.
 * A SIZE fade (0.9.6, BUGHUNT #19; 1 s after a turn under a ringing tail, PL_XS), on top: one site's blend (pl_xblend,
 *   11 a sample, ~190) + its pointers ~40 + the gains anew ~140: ~+370. (All 22 sites at once cost ~+3190 from flash,
 *   measured +210 us on the FM-1 under the VIBES worst case, 4296 us; ~+2780 from RAM still 4272 us.)
 * HALL (fx.c rev_hall, its own decimator and DC blocker included), counted the same way: 5644 at rest, 5864 with its
 * gains made anew (DECAY moving); PLATE + the framework's decimator (rev_dec, ~372): 5353 at rest, 5693 at worst,
 * 3-6 % under HALL. In us: HALL's kernel share is REV_US_HALL (210, from the FM-1's measured 260 for the whole
 * reverb); PLATE + rev_dec at 5693 / 5864 of it = 204 -> REV_US_PLATE 194 -> 200 (+ REV_US_DEC 10). (The rule of
 * thumb, 0.8 us per instruction per half-rate sample, reads both ~1.3x high against the FM-1: 262 us for 5241.) */
#ifndef FR_RAM
#define FR_RAM                                  /* (frodhes.c: the audio hot loops in RAM) */
#define FR_FAR(fn) fn
#endif
#ifndef FX_RAM                                  /* (frodhes.c: FR_RAM, or flash in FR_C1 builds: core 1 runs the effects from XIP) */
#define FX_RAM FR_RAM
#endif
#define REV_US_PLATE 350u                              /* (full rate: rev_hq.c's cost comment) */

#define PL_R(n) (((n) * 14818u + 5000u) / 10000u)      /* the paper's 29.76 kHz lengths at 44.1 kHz */
#define PL_N 32768u                                    /* the tank's ring (int16) */
#define PL_M (PL_N - 1u)
#define PL_IN 2048u                                    /* the input allpasses' ring */
#define PL_G 33u                                       /* the guard: a block's 16 samples + the interpolation's next */
#define PL_GAP 32u                                     /* between segments: >= one block */
#define PL_MSL 26u                                     /* the modulated lines' room: excursion (23.8) + interpolation */
/* the tank's 8 segments: the longest delay each holds (SIZE 127: x 255 / 256), their tops */
#define PL_LM0 (PL_R(672u) + PL_MSL)                    /* left: modulated allpass */
#define PL_LM1 PL_R(4453u)                              /* left: delay 1 */
#define PL_LM2 PL_R(1800u)                              /* left: allpass 2 */
#define PL_LM3 PL_R(3720u)                              /* left: delay 2 */
#define PL_LM4 (PL_R(908u) + PL_MSL)                    /* right: modulated allpass */
#define PL_LM5 PL_R(4217u)
#define PL_LM6 PL_R(2656u)
#define PL_LM7 PL_R(3163u)
#define PL_O0 PL_LM0
#define PL_O1 (PL_O0 + PL_GAP + PL_LM1)
#define PL_O2 (PL_O1 + PL_GAP + PL_LM2)
#define PL_O3 (PL_O2 + PL_GAP + PL_LM3)
#define PL_O4 (PL_O3 + PL_GAP + PL_LM4)
#define PL_O5 (PL_O4 + PL_GAP + PL_LM5)
#define PL_O6 (PL_O5 + PL_GAP + PL_LM6)
#define PL_O7 (PL_O6 + PL_GAP + PL_LM7)
_Static_assert(PL_O7 + PL_GAP <= PL_N, "the plate's 8 segments must fit its ring");
/* the input allpasses' segments (fixed lengths) */
#define PL_IL0 PL_R(142u)
#define PL_IL1 PL_R(107u)
#define PL_IL2 PL_R(379u)
#define PL_IL3 PL_R(277u)
#define PL_IO0 PL_IL0
#define PL_IO1 (PL_IO0 + PL_GAP + PL_IL1)
#define PL_IO2 (PL_IO1 + PL_GAP + PL_IL2)
#define PL_IO3 (PL_IO2 + PL_GAP + PL_IL3)
_Static_assert(PL_IO3 + PL_GAP <= PL_IN && PL_IL1 >= RQ_NC, "the input allpasses must fit their ring");
#define PL_WARM (PL_LM1 + RQ_NC)                        /* from here on no read is older than the start */
#define PL_LFO ((uint32_t)(1.0 * CTL / FS * 4294967296.0))   /* 1 Hz, per control block */
/* the output: the taps' 0.6 / 2 x 1.9 (Q12; / 1.5 for the lines' 1.5x level, pl_in) at SIZE <= 40, rising 0.067 dB a
 * SIZE step to +5 dB at 115 (pl_ctl): HALL's level at the same MIX (HALL grows with MIX's size, a plate thins out as its
 * tank grows) */
#define PL_OUT 2302                                    /* (rev_hq_plate.c: the half-rate plate's Bark loudness, Rhodes + VIBES phrases) */
#define PL_MKG 1037u                                  /* the output gain's make-up (Q10): pl_ctl */
#define PL_LIM 262143                                  /* |mid|, |side| <= 2^18 (the framework's exact return) */
_Static_assert(14 * 32768 * 2 * PL_OUT <= 2147483647, "the output product");
/* the read sites: 0..7 the segments' own delays (0 / 4: the modulated ones, without the excursion), 8..21 the taps */
enum { PL_S_N = 22 };

typedef struct {
    int16_t ring[PL_N + PL_G + 1u];                  /* (+ 1: whole words for pl_cpy) */
    int16_t id[PL_IN + PL_G + 1u];
    int16_t zero[2u * RQ_NC];       /* what a read of content older than the start sees */
    uint32_t w, e;                  /* the rings' write index (one a sample), samples since the start (to PL_WARM) */
    uint32_t ph;                    /* the LFO */
    uint32_t quiet;                 /* samples with no input and no line write (to PL_N) */
    int32_t bw, dl, dr;             /* the bandwidth and the two damping one-poles */
    int32_t g, g2, pdm, pbw;        /* decay, allpass 2's gain, the damping / bandwidth poles (Q15): g g2 pdm in
                                     * this order (pl_half's k[]) */
    int32_t sz, szo, xw;            /* the size that runs (-1 at the start); a SIZE fade (0.9.6, BUGHUNT #19): the size
                                     * it fades from, the new reads' weight at this block's start (Q14) */
    uint8_t xf, xk;                 /* a SIZE fade runs; the read site in its fade (0..21, one after the other) */
    int32_t cdec, cdamp;            /* the settings the gains were made for */
    int32_t ko;                     /* the output gain (Q12) */
    uint32_t fix;                   /* this block: a write ran into the guard (ring 1, input 2) */
    uint16_t d[PL_S_N];             /* the delays at this size */
    uint16_t tk[PL_S_N];            /* the reads: their segment's top - their delay */
    uint16_t to[PL_S_N];            /* a SIZE fade: the reads in use (the old ones, each site's new one once faded) */
    int32_t x[RQ_NC];
} rev_plate_t;

/* the paper's delays at 29.76 kHz: the segments, then the taps (left: 48_54 266, 48_54 2974, 55_59 1913, 59_63 1996,
 * 24_30 1990, 31_33 187, 33_39 1066; right: 24_30 353, 24_30 3627, 31_33 1228, 33_39 2673, 48_54 2111, 55_59 335,
 * 59_63 121) and the segment each one reads */
static const uint16_t PL_D0[PL_S_N] = {672, 4453, 1800, 3720, 908, 4217, 2656, 3163,
                                       266, 2974, 1913, 1996, 1990, 187, 1066,
                                       353, 3627, 1228, 2673, 2111, 335, 121};
static const uint8_t PL_SEG[PL_S_N] = {0, 1, 2, 3, 4, 5, 6, 7, 5, 5, 6, 7, 1, 2, 3, 1, 1, 2, 3, 5, 6, 7};
static const uint16_t PL_TOP[8] = {PL_O0, PL_O1, PL_O2, PL_O3, PL_O4, PL_O5, PL_O6, PL_O7};
static const uint16_t PL_ITOP[4] = {PL_IO0, PL_IO1, PL_IO2, PL_IO3};
static const uint16_t PL_IL[4] = {PL_IL0, PL_IL1, PL_IL2, PL_IL3};

/* sqrt(p / 32768) x 32768 (p Q15, 0 .. 32767): a one-pole's pole at twice the rate with the same time constant */
static FX_RAM int32_t rq_sqrt15(int32_t p)
{
    uint32_t x = (uint32_t)p << 15, r = 0, b = 1u << 30;
    while (b > x) b >>= 2;
    while (b) {
        if (x >= r + b) { x -= r + b; r = (r >> 1) + b; }
        else r >>= 1;
        b >>= 2;
    }
    return (int32_t)r;
}
static void rev_plate_start(rev_plate_t *s)
{
    uint32_t k, i;
    for (i = 0; i < 2u * RQ_NC; i++)
        s->zero[i] = 0;
    s->w = s->e = s->ph = s->quiet = 0;
    for (k = 0; k < 8u; k++)                           /* each line's last PL_G writes before the start */
        for (i = PL_TOP[k] - PL_G; i < PL_TOP[k]; i++)
            s->ring[i] = 0;
    for (k = 0; k < 4u; k++)
        for (i = PL_ITOP[k] - PL_G; i < PL_ITOP[k]; i++)
            s->id[i] = 0;
    s->bw = s->dl = s->dr = 0;
    s->cdec = s->cdamp = -1;
    s->sz = -1;
    s->xf = 0;                                          /* (no SIZE fade: the pool may hold another TYPE's state) */
}
static int rev_plate_active(const rev_plate_t *s) { return s->quiet < PL_N; }

/* the gains and lengths for these settings. A new SIZE (0.9.6, BUGHUNT #19: it glided one step at a time, 13 samples
 * a delay, a bend and a click per step under a ringing tail): all 22 delays at once, the reads cross-fading from the
 * old ones one site after the other, 2048 samples each (22 x 46 ms = 1.0 s, PL_XS; one site at a time: the cost of one
 * blend, not 22; one fade at a time: a SIZE turned on during it waits for its end); the decay and output gains follow
 * the lengths and the size between as it fades. From silence, at once */
#define PL_XS 8                                        /* a site's fade's step a sample (Q14): 2048 samples (46 ms) a
                                                         * site, 1.0 s for the 22, as rev_plate.c's (64, the half rate's
                                                         * time: zipper 2.6x on a SIZE turn; 0.9.10, with the modulated
                                                         * reads mended: at 32 the sweep's wet bent 7.9 cents p90, its
                                                         * level stepped 3.3 dB; at 16 the wet's zipper 2.25; at 8 1.3
                                                         * cents, 0.7 dB, zipper 1.57; equal power at 8: 3.6 cents) */
_Static_assert(16384 % (RQ_NC * PL_XS) == 0, "a site's fade ends on a block (pl_xw past 16384 would go negative)");
static void pl_dset(rev_plate_t *s, uint32_t k, int32_t sz)
{
    uint32_t d = (PL_R(PL_D0[k]) * (uint32_t)(128 + sz)) >> 8;
    s->d[k] = (uint16_t)d;
    s->tk[k] = (uint16_t)((PL_TOP[PL_SEG[k]] + PL_N - d) & PL_M);
}
static void pl_ctl(rev_plate_t *s, const rev_ctl_t *c)
{
    uint32_t k, ls = 0, q, e;
    int32_t sz;
    int new = c->decay != s->cdec || s->xf;
    if (!s->xf && s->sz != c->size) {
        if (s->sz >= 0 && rev_plate_active(s) && s->e >= PL_WARM) {   /* ringing: the fade */
            for (k = 0; k < PL_S_N; k++)
                s->to[k] = s->tk[k];
            s->szo = s->sz, s->xf = 1, s->xk = 0, s->xw = 0;
        }
        s->sz = c->size;                                /* (the start, silence: at once) */
        for (k = 0; k < PL_S_N; k++)
            pl_dset(s, k, s->sz);
        new = 1;
    }
    if (new) {
        for (k = 0; k < 8u; k++)
            ls += s->d[k];
        sz = s->sz;
        if (s->xf) {                                    /* (the fade: the lengths in use, the size between) */
            uint32_t lo = 0, xk = s->xk;
            for (k = 0; k < 8u; k++)
                lo += (PL_TOP[k] + PL_N - s->to[k]) & PL_M;
            if (xk < 8u) {                              /* (the segment in its fade: its length between) */
                int32_t dk = (int32_t)((PL_TOP[xk] + PL_N - s->to[xk]) & PL_M);
                lo = (uint32_t)((int32_t)lo + ((((int32_t)s->d[xk] - dk) * s->xw) >> 14));
            }
            ls = lo;
            sz = s->szo + (((s->sz - s->szo) * (int32_t)((xk * 16384u + (uint32_t)s->xw) / PL_S_N)) >> 14);
        }
        /* g^4 per round of ls samples, 60 dB in T60 = 0.8 s x 7.5^(decay / 127): g = 2^-e, e = 9.2566 ls / 2^(2.907
         * decay / 127) (Q16), 2.907 / 127 = 1500 / 65536; + 104 a step (x 1.15 at 127) makes up the damping's,
         * the modulation's and the truncation's losses at the defaults (measured: tests/py/test_rev_plate.py) */
        q = exp2_neg((uint32_t)c->decay * 1841u);
        e = (uint32_t)(((uint64_t)(ls * q) * 9592u) >> 26);   /* (ls at 44.1 kHz: twice the samples) */
        e = e * (1270u + (uint32_t)sz) / 1270u;         /* (a bigger tank damps less a second: + 10 % at 127) */
        s->g = (int32_t)exp2_neg(e);
        s->g2 = clampi(s->g + 4915, 8192, 16384);
        /* (x PL_MKG / 1024: +0.11 dB, 0.9.10, the wet's level as before the modulated reads were mended: their
         * 2-sample jumps had added that much noise power, so the chord's wet fell 0.11 dB without it) */
        s->ko = (int32_t)((4u * PL_OUT / 3u * PL_MKG / 1024u
                           * exp2_neg(65536u - (uint32_t)clampi((sz - 40) * 729, 0, 54427))) >> 15);
        s->cdec = c->decay;
    }
    if (c->damp != s->cdamp) {
        /* the half rate's poles at 44.1 kHz: the same time constant, sqrt(p) (Q15) */
        s->pdm = FR_FAR(rq_sqrt15)(clampi(c->damp * 350, 0, 31000));
        s->pbw = FR_FAR(rq_sqrt15)(clampi(c->damp * 240, 0, 26000));
        s->cdamp = c->damp;
    }
}
/* a SIZE fade: n samples of the old reads (q) x a plus the new (p) x b (Q14), into t; the weights move sample by sample
 * from this block's start (a, b) toward the next block's (a1, b1), 1/RQ_NC of the way a sample (0.9.10: held for the
 * block, the fade was a staircase, a step every control block: rev_plate.c's d2 spikes under a SIZE sweep). Sample 0
 * has the block's own weights, as before */
_Static_assert(RQ_NC == 32u, "pl_xblend's steps: 1/32 a sample");
static FX_RAM __attribute__((noinline)) void pl_xblend(int16_t *t, const int16_t *q, const int16_t *p, uint32_t n,
                                                       int32_t a, int32_t b, int32_t a1, int32_t b1)
{
    uint32_t i;
    int32_t da = a1 - a, db = b1 - b;
    a <<= 5, b <<= 5;
    for (i = 0; i < n; i++, a += da, b += db)
        t[i] = (int16_t)hl_c16((q[i] * (a >> 5) + p[i] * (b >> 5)) >> 14);
}
/* the fade's two weights at w (Q14, the new's share): (1 - w, w) x (1 + 0.375 w (1 - w)), +0.8 dB at the middle: the
 * old and new reads are alike after a small SIZE step, unrelated after a big one (a plain 1 - w, w sank the tail
 * 6.8 dB in the middle of SIZE 127 -> 0: the dip goes round the loop; +1.5 dB stepped the level of a SIZE sweep's
 * chained fades 2.5 dB; equal power would lift a small step 3 dB) */
static inline __attribute__((always_inline)) void pl_xw(int32_t w, int32_t *a, int32_t *b)
{
    int32_t g = 16384 + ((3 * ((w * (16384 - w)) >> 14)) >> 3);
    *a = ((16384 - w) * g) >> 14;
    *b = (w * g) >> 14;
}
static int16_t pl_xt[RQ_NC + 2u];                       /* the fading site's blended reads (16 + the interpolation's next) */

/* a read site in the tank: P[j] (j = 0 .. 16) is the sample of delay hi - j at the block's sample 0 (the block's
 * sample i reads P[i] for delay hi, P[i + 1] for hi - 1). While every read of the block is older than the start: the
 * zeros. The block where the reads cross the start reads write-times from -17 on (a delay grows at most 13 a block,
 * e 16): those were zeroed by the start */
static inline const int16_t *pl_ptr(const rev_plate_t *s, uint32_t top, uint32_t hi, uint32_t lo)
{
    if (s->e + RQ_NC <= lo) return s->zero;
    return s->ring + ((s->w + top - hi) & PL_M);
}
/* a write site: 16 samples from the top; one that runs past the ring's end writes the guard (pl_fix copies it) */
static inline int16_t *pl_wptr(rev_plate_t *s, int16_t *b, uint32_t n, uint32_t at, uint32_t bit)
{
    at &= n - 1u;
    if (at > n - RQ_NC) s->fix |= bit;
    return b + at;
}
static void pl_cpy(int16_t *d, const int16_t *q)     /* PL_G + 1 int16 (both 4-byte aligned) */
{
    uint32_t *a = (uint32_t *)(void *)d, i;
    const uint32_t *c = (const uint32_t *)(const void *)q;
    for (i = 0; i < (PL_G + 1u) / 2u; i++)
        a[i] = c[i];
}

/* the input, one block: the bandwidth one-pole (toward its input: it ends at 0), then the 4 allpasses in a row, each
 * v = x - g d into its write, y = d + g v (plain shifts: with g > 0 and no input the stored value changes sign every
 * pass and never grows, so it dies out). Returns the OR of the input */
#define PL_AP(k, g) d = r##k[i], v = hl_c16(y - ((d * (g)) >> 15)), o##k[i] = (int16_t)v, y = d + ((v * (g)) >> 15)
static FX_RAM __attribute__((noinline)) int32_t pl_in(const int16_t *const *r, int16_t *const *o, const int32_t *in,
                                                      int32_t *x, int32_t *bw, int32_t pb)   /* (RAM: 0.9.7) */
{
    const int16_t *r0 = r[0], *r1 = r[1], *r2 = r[2], *r3 = r[3];
    int16_t *o0 = o[0], *o1 = o[1], *o2 = o[2], *o3 = o[3];
    uint32_t i;
    int32_t b = *bw, act = 0;
    for (i = 0; i < RQ_NC; i++) {
        int32_t y, d, v, u = in[i] + (in[i] >> 1);  /* the lines 1.5x hot: 3.5 dB less rounding noise */
        {   /* (64-bit, 0.9.6, BUGHUNT #22: (b - u) * pb passed 2^31 from |b - u| 82595, an input over ~1.2x full scale
             * with COMP's make-up; the same integers as sh_tz below that) */
            int64_t p = (int64_t)(b - u) * pb;
            b = u + (int32_t)((p + (p < 0 ? 32767 : 0)) >> 15);
        }
        act |= u;
        y = b;
        PL_AP(0, 24576);
        PL_AP(1, 24576);
        PL_AP(2, 20480);
        PL_AP(3, 20480);
        x[i] = y;
    }
    *bw = b;
    return act;
}

/* one half of the tank, one block, its segments' reads r[] and writes o[]. Truncated toward zero: the two decay
 * products, the damping one-pole (a plain shift there held a dark one-pole at up to -18 for ever: a DC loop) and the
 * allpasses' stored values, so without input the loop's content can only shrink; the allpasses' outputs use plain
 * shifts. a = x + g f (f = the other half's end); the modulated allpass (read q, the interpolation fm, gain -0.7,
 * write wm) into delay 1 (w1); delay 1's end (r1), damped (lp), x g, through allpass 2 (read r2, gain g2, write w2)
 * into delay 2 (w3). Returns the OR of the writes */
static FX_RAM __attribute__((noinline)) int32_t pl_half(const int32_t *x, const int16_t *f, const int16_t *const *r,
                                                 int32_t fm, int16_t *const *o, int32_t *lp, const int32_t *k)
{
    const int16_t *q = r[0], *r1 = r[1], *r2 = r[2];
    int16_t *wm = o[0], *w1 = o[1], *w2 = o[2], *w3 = o[3];
    uint32_t i;
    int32_t g = k[0], g2 = k[1], p = k[2], l = *lp, act = 0;
    for (i = 0; i < RQ_NC; i++) {
        int32_t a = x[i] + sh_tz(f[i] * g, 15), q0 = q[i];
        int32_t d = q0 + (((q[i + 1] - q0) * fm) >> 8), v = hl_c16(a + sh_tz(d * 22938, 15));
        wm[i] = (int16_t)v;
        v = hl_c16(d - ((v * 22938) >> 15));
        w1[i] = (int16_t)v;
        act |= v;
    }
    for (i = 0; i < RQ_NC; i++) {
        int32_t u = r1[i], d = r2[i], v;
        l = u + sh_tz((l - u) * p, 15);
        u = sh_tz(l * g, 15);
        v = hl_c16(u - sh_tz(d * g2, 15));
        w2[i] = (int16_t)v;
        v = hl_c16(d + ((v * g2) >> 15));
        w3[i] = (int16_t)v;
        act |= v;
    }
    *lp = l;
    return act;
}

/* the 7 taps of a side (+ + - + - - -), one block: the left into mid[]; then the right, and mid / side */
static FX_RAM __attribute__((noinline)) void pl_taps(const int16_t *const *t, int32_t *o)
{
    const int16_t *a0 = t[0], *a1 = t[1], *a2 = t[2], *a3 = t[3], *a4 = t[4], *a5 = t[5], *a6 = t[6];
    uint32_t i;
    for (i = 0; i < RQ_NC; i++)
        o[i] = a0[i] + a1[i] - a2[i] + a3[i] - a4[i] - a5[i] - a6[i];
}
static FX_RAM __attribute__((noinline)) void pl_taps_ms(const int16_t *const *t, int32_t *mid, int32_t *side, int32_t k)
{
    const int16_t *a0 = t[0], *a1 = t[1], *a2 = t[2], *a3 = t[3], *a4 = t[4], *a5 = t[5], *a6 = t[6];
    uint32_t i;
    for (i = 0; i < RQ_NC; i++) {
        int32_t r = a0[i] + a1[i] - a2[i] + a3[i] - a4[i] - a5[i] - a6[i], l = mid[i];
        int32_t m = ((l + r) * k) >> 12, d = ((l - r) * k) >> 12;
        m = m > -PL_LIM ? m : -PL_LIM, d = d > -PL_LIM ? d : -PL_LIM;     /* (smax / smin) */
        mid[i] = m < PL_LIM ? m : PL_LIM;
        side[i] = d < PL_LIM ? d : PL_LIM;
    }
}

static __attribute__((noinline)) void rev_plate_run(rev_plate_t *s, const int32_t *in, int32_t *mid, int32_t *side,
                                                    const rev_ctl_t *c)
{
    int16_t *b = s->ring, *ib = s->id, *o[8];
    const int16_t *t[PL_S_N];
    uint32_t k, w, ex, dm0, dm1;
    int32_t act;
    const uint16_t *rk;
    uint32_t d0, d4;
    pl_ctl(s, c);
    rk = s->tk, d0 = s->d[0], d4 = s->d[4];
    if (s->xf) {                                        /* a SIZE fade: the reads in use (to) */
        rk = s->to;
        d0 = (PL_TOP[0] + PL_N - s->to[0]) & PL_M, d4 = (PL_TOP[4] + PL_N - s->to[4]) & PL_M;
    }
    ex = (uint32_t)c->mod * 3u;                        /* MOD 127 (x 16): 6096 = 23.8 samples (Q8): the half rate's time */
    s->ph += PL_LFO;
    dm0 = (d0 << 8) + (uint32_t)((osc_sine(s->ph) * (int32_t)ex) >> 15);
    dm1 = (d4 << 8) + (uint32_t)((osc_sine(s->ph + 0x40000000u) * (int32_t)ex) >> 15);
    w = s->w;
    s->fix = 0;
    /* the bandwidth one-pole and the input allpasses (their ring: the guard is the front's copy) */
    pl_cpy(ib + PL_IN, ib);
    for (k = 0; k < 4u; k++) {
        t[k] = s->e + RQ_NC <= PL_IL[k] ? s->zero : ib + ((w + PL_ITOP[k] - PL_IL[k]) & (PL_IN - 1u));
        o[k] = pl_wptr(s, ib, PL_IN, w + PL_ITOP[k], 2u);
    }
    act = FR_FAR(pl_in)(t, o, in, s->x, &s->bw, s->pbw);
    /* the tank: every read site's pointer (the zeros while it reads before the start), the guard copy, the halves */
    if (s->e >= PL_WARM)
        for (k = 0; k < PL_S_N; k++)
            t[k] = b + ((w + rk[k]) & PL_M);
    else
        for (k = 0; k < PL_S_N; k++)
            t[k] = pl_ptr(s, PL_TOP[PL_SEG[k]], s->d[k], s->d[k]);
    /* the modulated reads at dm / 256 samples: a site reads delay hi (P[i]) blended toward hi - 1 (P[i + 1]) by
     * fm / 256, so hi = ceil(dm / 256) and fm = hi x 256 - dm, below as (dm + 255) >> 8 and 255 - ((dm + 255) & 255)
     * (0.9.10: hi = floor, fm = dm & 255 read hi - frac, the delay jumping 2 samples at each whole sample of the
     * excursion: the MOD's sweep crossed one ~20 times a second, d2 bursts 3x a still plate's, a grain) */
    dm0 += 255u, dm1 += 255u;
    t[0] = pl_ptr(s, PL_O0, dm0 >> 8, (dm0 >> 8) - 1u);
    t[4] = pl_ptr(s, PL_O4, dm1 >> 8, (dm1 >> 8) - 1u);
    pl_cpy(b + PL_N, b);
    if (s->xf) {                                        /* a SIZE fade: the one site in its fade, its old read (t)
                                                         * and its new blended (a segment before the halves write:
                                                         * every delay >= 45 > a block) */
        uint32_t xk = s->xk, n = RQ_NC;
        int32_t xa, xb, xa1, xb1;
        const int16_t *p = b + ((w + s->tk[xk]) & PL_M);
        if (!(xk & 3u) && xk < 8u) {                    /* (0 / 4: modulated, the excursion on the new delay too) */
            uint32_t dm = xk ? dm1 : dm0, dc = xk ? d4 : d0;
            p = b + ((w + PL_TOP[xk] - ((dm >> 8) - dc + s->d[xk])) & PL_M), n = RQ_NC + 1u;
        }
        pl_xw(s->xw, &xa, &xb);
        pl_xw(s->xw + (int32_t)RQ_NC * PL_XS, &xa1, &xb1);   /* (the next block's: 16384 at the site's end) */
        FR_FAR(pl_xblend)(pl_xt, t[xk], p, n, xa, xb, xa1, xb1);
        t[xk] = pl_xt;
    }
    for (k = 0; k < 8u; k++)
        o[k] = pl_wptr(s, b, PL_N, w + PL_TOP[k], 1u);
    {
        /* (volatile: read once; as a constant the compiler rebuilt the address in the loop, 4 instructions a sample) */
        const int32_t *volatile xv = s->x;
        act |= FR_FAR(pl_half)(xv, t[7], t, (int32_t)(255u - (dm0 & 255u)), o, &s->dl, &s->g);
        act |= FR_FAR(pl_half)(xv, t[3], t + 4, (int32_t)(255u - (dm1 & 255u)), o + 4, &s->dr, &s->g);
    }
    FR_FAR(pl_taps)(t + 8, mid);
    FR_FAR(pl_taps_ms)(t + 15, mid, side, s->ko);
    if (s->fix & 1u) pl_cpy(b, b + PL_N);            /* (the guard past the wrapped write: the front's own copy) */
    if (s->fix & 2u) pl_cpy(ib, ib + PL_IN);
    s->w = w + RQ_NC;
    if (s->xf && (s->xw += (int32_t)RQ_NC * PL_XS) >= 16384) {   /* a site faded: the next; the end: the gains anew */
        s->to[s->xk] = s->tk[s->xk], s->xw = 0;
        if (++s->xk == PL_S_N) s->xf = 0, s->cdec = -1;
    }
    if (s->e < PL_WARM) s->e += RQ_NC;
    s->quiet = act ? 0u : s->quiet < PL_N ? s->quiet + RQ_NC : PL_N;
}
