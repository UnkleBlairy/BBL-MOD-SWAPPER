/* SPDX-License-Identifier: GPL-3.0-only */
/* Frodhes bar engine, its types, constants and state (bars.h); the code is bars.c. The engine: struck metal bars over tuned tubes (VIBES; marimba / xylophone later as data only).
 *
 * Per voice: a mallet force pulse (the BARK family x velocity shapes blended once at note-on) drives up to 8 modes
 * of one bar: V1 TUBE V2 V3 V4 T1 T2 X. V1 and the tube's fundamental are a two-way coupled pair (stiffness
 * coupling, the tube's pressure acts on the bar and the bar drives the tube); the motor's discs scale the coupling
 * and the tube's radiation per sub-block, ramped per sample. Every mode is the exact-pole MC3 resonator of the Rhodes
 * modes, run in its equivalent two-multiply form: x[n+1] = a1 x[n] - a2 x[n-1] + e u[n] with a1 = 2 - eps - e^2,
 * a2 = 1 - eps (the same poles and the same force-to-x transfer as MC3's x += e y, y += -eps y - e x, y += u), with
 * first-order error feedback (noise floor < -100 dBFS on every key and mode). Output = bar displacement + the tube's
 * radiation, times the key's gain: no pickup.
 *
 * Levels: each mode's amplitude comes once per block from its last two samples (x1^2 - a1 x1 x2 + a2 x2^2 =
 * A^2 sin^2 theta), in log2. A voice ends when its output falls under 1 LSB; upper modes sleep 54 dB under the
 * fundamental (faded over a sub-block).
 *
 * CPU, by construction: every block, a cost model of this block's work (voices, pulses, noise, the effects that
 * are on) gives the number of upper modes that fit under the 4800 us gate; when more are live, the least audible
 * go (their level re the loudest fundamental in the mix, less where a louder partial nearby masks them; a strike's
 * modes before they sound are ranked by their predicted level), faded over a sub-block, never cut.
 *
 * Its own voices, constants, summaries and render: nothing here changes the Rhodes engine (rhodes.c). It reuses the
 * Rhodes run-time coefficient path rh_coef() unchanged, the velocity layer tables and the main-loop voicing values
 * shared by both engines (DECAY, RELEASE, TUNE, the damper knock and felt noise levels). engine.c calls it.
 * Tables: firmware/gen/bars_tables.h (tools/gen_bars.py; the format of the plan's section 4.4). */

/* the bars' level into the mix (0.9.13, SND3): RESPONSE FULL's convex curve plays the electric piano 2.6-3.0 dB
 * quieter at middle velocities, so VIBES and MARIMBA come down with it to 0.9.9's balance (MARIMBA re ST77 at v100,
 * the presets re F01). A level rebalance only: the effects that read the absolute level (the compressor's detector,
 * DRIVE's input, every TYPE, the touch wah's envelope, the tape delay's soft clip) read the bars 3 dB up again
 * (BAR_FX_K, BAR_FX_DT: engine.c FX_ENG_K / FX_ENG_DT, fx.c) and give their output back 3 dB down, so they respond as
 * on 0.9.11 at the new level (T2 0.9.12: on the bars alone the wah opened less, the drive drove less, the compressor
 * held less) */
#ifndef BAR_MIX_G
#define BAR_MIX_G 23197                             /* Q15: -3.0 dB */
#endif
#define BAR_FX_K ((int32_t)((1073741824 + BAR_MIX_G / 2) / BAR_MIX_G))   /* 32768 / BAR_MIX_G in Q15: 46288 */
#define BAR_FX_DT 2041                              /* log2(32768 / BAR_MIX_G) in Q12 (4096 x 0.49833) */

/* the generated table's layout (bars_tables.h BAR_KEYS, 8 mode slots): not linked; the firmware reads BAR_KP (bars_pack.h) */
typedef struct {
    rh_mode_t m[8];             /* V1 TUBE V2 V3 V4 T1 T2 X; m[1] (TUBE): b = 0, drel = d */
    int32_t k_bt, k_tb;         /* Q30 coupling at BELL 64, discs open (same sign: a symmetric stiffness coupling) */
    int32_t wt;                 /* Q28 tube radiation weight (|wt| <= 4.0) */
    int32_t gain;               /* Q16 per-key output gain */
    int32_t kill;               /* Q25 */
    uint16_t life;              /* blocks */
    uint8_t band, flags;        /* flags bit0: outside the authentic range; bit1: T1/T2 present; bit2: sigma clamped;
                                 * bit3 (MARIMBA below C4): RING (bar_k_decay) scales the tube slot too;
                                 * bit4 (MARIMBA): BAR_RINGG[key] at RING scales the gain (the ceiling) */
} bar_key8_t;
typedef struct {
    rh_mode_t m[7];             /* V1 TUBE V2 V3 V4 T1 T2; m[1] (TUBE): b = 0, drel = d. The 8th slot (X) is all zero in
                                 * every key: not stored (BAR_NMK, BAR_KM; tools/gen_bars_pack.py) */
    int32_t k_bt, k_tb;         /* Q30 coupling at BELL 64, discs open (same sign: a symmetric stiffness coupling) */
    int32_t wt;                 /* Q28 tube radiation weight (|wt| <= 4.0) */
    int32_t gain;               /* Q16 per-key output gain */
    int32_t kill;               /* Q25 */
    uint16_t life;              /* blocks */
    uint8_t band, flags;        /* flags bit0: outside the authentic range; bit1: T1/T2 present; bit2: sigma clamped;
                                 * bit3 (MARIMBA below C4): RING (bar_k_decay) scales the tube slot too;
                                 * bit4 (MARIMBA): BAR_RINGG[key] at RING scales the gain (the ceiling) */
} bar_key_t;
typedef struct {
    int16_t tube_cents;         /* the type's global tube offset (per-key values are already in m[1]) */
    int16_t mot_gc;             /* Q15 closed-disc residual g_c */
    int16_t tors_db;            /* Q15 torsion scale on b at the edge */
    uint8_t nbody, drive_row, sleep_rel, budget;
    uint8_t flags;              /* bit0 has_motor, bit1 has_damper (VIBES 3; params.c TYPE_FLAGS says the same) */
    uint8_t kn_tube_top;        /* KN_TUBE[t][127] in 1/100 (informational) */
} bar_type_t;
#define BAR_MOT_COS BAR_MOT_COS_GEN                 /* (0.9.5, the flash: the generated quarter cosine is not used, */
#define bar_key_t bar_key8_t                        /* (BAR_KEYS in it is the contract, not linked: BAR_KP below is) */
#include "bars_tables.h"
#undef bar_key_t
#undef BAR_MOT_COS                                  /* so not linked: |cos(pi i / 512)| for i 0..256 is fx_tables.h */
#define BAR_MOT_COS (FX_SINE + 256)                 /* FX_SINE[256 + i], the same numbers: test_fx_tables_derived.py */
#include "bars_pack.h"                              /* BAR_KP (the keys, 7 mode slots), BAR_GROW (the gain rows), their indexes */
static const rh_mode_t bar_zm;                      /* the 8th slot, all zero in every key (BAR_NMK) */
#define BAR_KM(k, i) ((i) < BAR_NMK ? &(k)->m[i] : &bar_zm)   /* mode slot i of a key, 0 .. BAR_NM - 1 */
_Static_assert(BAR_NM == 8, "bars.c: 8 mode slots");

#define BAR_NV BAR_VOICES                           /* voices: rhodes.c BAR_VOICES (10 by default, as the Rhodes) */
#define BAR_N 256u                                  /* the block */
#define BAR_SUB 32u
#define BAR_NSUB (BAR_N / BAR_SUB)
#define BAR_RAMP_SUB 7u
#define BAR_UP0 2u                                  /* first upper slot (V2) */
#define BAR_NUP (BAR_NM - BAR_UP0)
#define BAR_LZERO (-32768)                          /* log2 of nothing */
#define BAR_EFM 0x3FFFFFFF                          /* the error-feedback remainder (30 bits) */
_Static_assert(BAR_NV <= 32u, "summaries are 32-bit masks");

typedef struct {
    int32_t x1, x2, err;                            /* x[n], x[n-1] (Q25); the error-feedback remainder */
    int32_t k1, k2;                                 /* lo: c1 = eps + e^2, c2 = eps (Q32); hi: a1 = 2 - c1, a2 = 1 - eps (Q30) */
    int32_t e, eps, e0, eps0, e1, eps1, es, epss;   /* live, held pair, felt pair, crossfade start (Q30) */
    int32_t b, be;                                  /* Q30 force -> y, strike-position weighted; be = b e >> 30 */
    int32_t amp;                                    /* Q25 amplitude at the last block's end */
    int16_t lsin;                                   /* log2 sin(theta), Q8 (<= 0) */
    int16_t lpred;                                  /* the strike's predicted log2 amplitude (Q8), BAR_LZERO = none */
    uint8_t live, bin, fresh, lo;                   /* live 1, 2 = fades out over the next sub-block; 1/3-octave band;
                                                     * fresh: struck this block, its level not measured yet; lo: the
                                                     * Q32 form (c1 < 1/2: every mode under ~4.9 kHz, V1 and the tube
                                                     * always), else the Q30 form */
} bar_ms_t;

#ifdef FR_HQ
#define HQB_NX 5u                                   /* the HQ bars' extra slots (the Move only: hq/bars_hq.h): V5 V6 V7
                                                     * T3 T4 at m[8 ..12] */
typedef struct {
    bar_ms_t m[BAR_NM + HQB_NX];
    uint8_t hq;                                     /* latched at the note-on: the HQ bar voice (hq/bars_hq.c) */
#else
typedef struct {
    bar_ms_t m[BAR_NM];
#endif
    const bar_key_t *k;
    uint8_t note, vel, alive, held, ramp, pend, pend_note, pend_vel, struck, pred;
    int32_t w_tgt, fade;
    uint32_t age, life;
    int32_t gain, kbt, ktb, wt, kill1;              /* BELL-scaled coupling and radiation, discs open; kill1: 1 LSB */
    uint32_t ppos, prate;
    int32_t pamp;
    const int16_t *ptab;                            /* pbuf (the strike) or pthump (the damper's knock) */
    const int16_t *pthump;
    uint32_t prate_thump;
    int16_t pbuf[BAR_PLEN + 2];
#ifdef DINGHY_PLUGIN
    uint16_t pdly;                                  /* the plugin: samples before the pulse starts (rhodes.c fr_ofs_apply) */
#endif
    uint16_t felt_n;
    int32_t felt_lp;
    int32_t lvl, lvl0;                          /* the block's mode sum, the highest since the strike (bar_left) */
    uint16_t felt_g;                            /* Q15: the key-up felt noise's gain (bar_left) */
} bar_voice_t;

static bar_voice_t bv[BAR_NV];
static int32_t bar_mono[BAR_N];
static int32_t bar_xt[3u * (BAR_N + 2u)];          /* the work buffer, interleaved: sample j's bar x (+ the upper
                                                     * modes, the radiation) at [3j], the tube's x1 at [3j + 1], the
                                                     * force << 12 at [3j + 2]: one pointer reaches all three */
#define BAR_XT(j) (bar_xt + 3u * (j))
static int32_t bar_nz_e, bar_nz_s[4];               /* contact noise: one envelope for every voice (one decay) */
static uint32_t bar_ages, bar_lfsr = 0x1D872u;
static int32_t bar_pedal_w = 32768;
static int32_t bar_bd_m[2][2], bar_bd_o[2][2], bar_bd_e[2];
static uint8_t bar_sub;                             /* the bar TYPE (index into BAR_TYPE): written only by engine.c
                                                     * eng_switch (ISR), so it never changes while a bar voice lives */
/* voicing written by the main loop (params.c), read at note-on */
static volatile int32_t bar_pos = 64;               /* TONE raw 0..127: strike position (64 = 0) */
static volatile int32_t bar_fam = 1 << 8;           /* KN_FAM[BARK]: family << 8 | Q8 fraction */
static volatile int32_t bar_tube = 32768;           /* KN_TUBE[BELL], Q15 */
static volatile int32_t bar_bell = 64;              /* BELL raw 0..127 (its level compensation, BAR_TUBEG) */
static volatile int32_t bar_mass = 4096, bar_massi = 4096;   /* KN_MASS / KN_MASSI[HAMMER], Q12 */
static volatile int32_t bar_nz;                     /* KN_NZ[NOISE], Q15 */
static volatile int32_t bar_k_decay = 65536, bar_k_rel = 65536;   /* DECAY_K[RING], DECAY_K[DAMPER], Q16 */
/* BAR_CC (bars.c bar_cc_fill): the strike coefficients computed at the note-on's queueing (main loop); off on the desktop
 * plugin and the HQ builds (the notes come from another thread there) */
#ifndef BAR_CC
#if defined(DINGHY_PLUGIN) || defined(FR_HQ)
#define BAR_CC 0
#else
#define BAR_CC 1
#endif
#endif
#if BAR_CC
static void bar_cc_fill(uint32_t slot, uint32_t note);
#endif
static volatile int32_t bar_ring = 64;              /* RING raw 0..127 (BAR_RINGG: the keys with flag bit4) */
static volatile int32_t bar_thump, bar_felt;        /* KN_THUMP / KN_FELT[NOISE]: the damper's knock and felt noise */
static volatile int32_t bar_mute = 0;               /* MUTE (P_RELEASE, RELEASE * 258), Q15: on a type without a damper
                                                     * the key-up damper weight's scale (0 = rings out): bar_mute_w */
static volatile uint8_t bar_mot_on, bar_mot_depth, bar_mot_shape;   /* TREM/WAH = MOTOR, DEPTH, SHAPE (0..127) */
static volatile uint32_t bar_mot_inc;               /* Q32 phase step per sample (the AM rate, or TREM SYNC's) */
static volatile uint8_t bar_budget_force;           /* developer (MIDI CC 9): 0 = the cost model, 1..49 = 0..48 upper
                                                     * modes, 50.. = no cap (CPU calibration on the FM-1) */
/* the motor: one global phase, gains per sub-block edge (ISR) */
static uint32_t bar_mot_ph;
static int32_t bar_mot_g[9] = {32768, 32768, 32768, 32768, 32768, 32768, 32768, 32768, 32768};
static const int32_t BAR_FAM_NZ[BAR_NFAM] = {2048, 8192, 14336, 22528, 32767};   /* Q15 per family (SOFT, YARN, the default,
                                                     * CORD, RUBBER), blended as the pulse: harder mallets click more,
                                                     * soft yarn hardly at all (the default's 14336 as before) */
/* ISR-written summaries */
static volatile uint32_t bar_active_bits, bar_held_bits, bar_quiet_blocks;
static volatile uint8_t bar_notes[BAR_NV];
static volatile uint32_t bar_shed_count;
static uint32_t bar_plan_us;                        /* the cost model's time for this block (bar_budget) */
static uint8_t bar_starts;                          /* ISR: the notes bar_strike started this block (a free voice, a
                                                     * re-strike, a steal's waiting note); BAR_NV at most (bars.c) */
static volatile uint32_t bar_prof_cap = 0xFFFFu, bar_prof_used;   /* since the last profiler query (CC 116): the lowest
                                                     * cap and the most live upper modes, in modes (x 8 = units) */
#ifdef DINGHY_HOST
static uint64_t bar_h_sat, bar_h_ms, bar_h_mul;     /* host counters: sat28 hits, mode-samples, int64 multiplies */
static uint32_t bar_h_blk_ms, bar_h_blk_mul, bar_h_blk_ns;   /* this block's; ns: the cost model's FM-1 time */
static uint32_t bar_h_max_starts;                   /* the most note starts in one block (tests/py/test_bar_starts.py) */
static int bar_h_nobudget, bar_h_nosleep;           /* host tests (S12 transparency): FRODHES_NOBUDGET / NOSLEEP */
static int bar_h_fxus = -1;                         /* FRODHES_FXUS: the effects' cost the budget plans with (us; RAW
                                                     * renders that budget as if the effects ran) */
static FILE *bar_h_pred;                            /* FRODHES_PREDLOG: predicted vs measured strike levels */
#define BAR_SLEEP_ON && !bar_h_nosleep
#else
#define BAR_SLEEP_ON
#endif
#ifdef FR_HQ
#define BAR_STUCK_ON(v) && !(v)->hq                 /* (bars.c: the stuck-slot sleep, the classic voice's only) */
#else
#define BAR_STUCK_ON(v)
#endif
static uint32_t fx_cost_us(void);                   /* fx.c: the effects that run now, us per block */

/* the engine's functions (bars.c, compiled after every other file so the Rhodes and the effects keep their code
 * layout and their inlining: the FM-1 runs code from flash through a cache) */
static int bar_strike(uint32_t note, uint32_t vel);
static void bar_note_off(uint32_t note);
static void bar_pedal(uint32_t cc);
static void bar_all_off(void);
static void bar_shed(void);
static void bar_kill_all(void);
static int bar_quiet(void);
static uint32_t bar_cost_fixed(uint32_t *unit);
static void bar_render(int32_t *mono_out, uint32_t n);
#ifdef FR_HQ
#include "hq/bars_hq.h"                            /* the HQ bars (the Move only; never in the FM-1 / SMK builds) */
#endif
