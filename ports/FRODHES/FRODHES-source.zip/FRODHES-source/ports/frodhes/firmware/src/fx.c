/* SPDX-License-Identifier: GPL-3.0-only */
/* Frodhes effects: a vintage-style stage keyboard's effect columns (IMPLEMENTATION-v3 §9):
 *   COMP -> DRIVE -> FILTER -> TREMOLO/WAH (mono -> stereo) -> PHASER -> CHORUS -> D.DELAY/A.DELAY -> REVERB (HALL)
 *   -> master   (0.9.3: the FILTER, 12 / 18 dB, with its LFO; 0.9.5: DRIVE moved before it, the user)
 * (0.4: the combined CHO/PHA switch became two effects that can run together, and a compressor came first)
 * Mono int32 Q15 (with headroom) until the tremolo, stereo after. Every effect keeps its state while bypassed
 * (switching on never clicks); switching an effect off cuts its input and lets the tail ring.
 *
 * Authorship: this file is Frodhes' own (GPL-3.0-only, Leo Mirabal). The code ported from another GPL-3.0-only project
 * is only what the FM-1, SMK-37, Move, MPC and web builds need, and lives in fx_fel.c (included below, under !FR_OWN
 * or, for the classic HALL, !(FR_OWN && FR_REV_HQ): never in the plugin's own-code build).
 * Felucca's MIT helpers (softclip, osc_sine, ...) are not in its tree: rewritten here from generated tables.
 *
 * Main loop: fx_set(id, value 0..127). ISR: fx_process(mono, out, n) adds stereo Q15 into out. */
#ifndef FR_RAM
#define FR_RAM                                  /* (frodhes.c: the audio hot loops in RAM) */
#define FR_FAR(fn) fn
#endif
#ifndef FR_RAM2
#define FR_RAM2                                 /* (frodhes.c: more of them, the one-core FM-1 image) */
#define FR_FAR2(fn) fn
#endif
#ifndef FX_RAM                                  /* (frodhes.c: FR_RAM, or flash in FR_C1 builds: core 1 runs the effects from XIP) */
#define FX_RAM FR_RAM
#endif
#ifndef FX_ENG_K                                /* the engine's level as the level-reading effects see it (engine.c:
                                                 * the bars'); 1 without it */
#define FX_ENG_K 32768
#define FX_ENG_G 32768
#define FX_ENG_DT 0
#else
#define FX_ENG_LVL 1                            /* (engine.c's table, indexed by FX_ENG_I) */
#if FR_CHUNK
#define FX_ENG_I fxc_eng                        /* (FR_C1: latched at the block's first chunk, as fxc_side) */
#else
#define FX_ENG_I (eng_cur & 1u)
#endif
#endif
#ifndef FX_SIDE                                 /* the Rhodes' side signal the effects read (SPREAD): rhodes.c's own */
#define FX_SIDE rh_side
#define FX_SIDE_ON rh_side_on
#endif
#if FR_CHUNK
#define FX_SIDE_ONB fxc_side                    /* (FR_C1: latched at the block's first chunk, fx_process) */
#else
#define FX_SIDE_ONB FX_SIDE_ON
#endif
#ifndef FX_PROC_ATTR                            /* fx_process: inlined into app_audio; FR_C1 builds: one copy, called
                                                 * from core 1's job and from core 0's fallback */
#define FX_PROC_ATTR static inline __attribute__((always_inline))
#endif
#include "fx_tables.h"

#ifdef DINGHY_HOST
#define POOL
#else
#define POOL __attribute__((unused))
#endif

enum { FXP_DRIVE, FXP_TW_SW, FXP_TW_DEPTH, FXP_TW_RATE, FXP_TW_MODE, FXP_TW_SHAPE,
       FXP_CP_SW, FXP_CP_DEPTH, FXP_CP_SPEED, FXP_CP_FDBK,
       FXP_DL_SW, FXP_DL_DEPTH, FXP_DL_TIME, FXP_DL_FDBK, FXP_DL_SYNC,
       FXP_RV_DEPTH, FXP_DRIVE_ROW, FXP_RAW, FXP_DL_TONE,
       FXP_PH_SW, FXP_PH_DEPTH, FXP_PH_SPEED, FXP_PH_FDBK, FXP_CMP_SW, FXP_CMP_AMT, FXP_CMP_ATK, FXP_CMP_REL,
       FXP_LEVEL, FXP_CMP_RATIO, FXP_CMP_GAIN,
       FXP_FL_TYPE, FXP_FL_FREQ, FXP_FL_RESO, FXP_FL_LFO, FXP_LFO_SHAPE, FXP_LFO_RATE,
       FXP_DRV_TONE, FXP_DRV_MIX, FXP_DRV_SW, FXP_RV_DECAY, FXP_RV_TONE, FXP_RV_PREDLY,   /* 0.9.3: DRIVE / REVERB pages */
       FXP_RV_TYPE, FXP_RV_SIZE, FXP_RV_MOD, FXP_RV_LOCUT,  /* 0.9.5: the reverb's TYPE and REVERB 2 (rev_types.c) */
       FXP_EQ_LO, FXP_EQ_MID, FXP_EQ_FREQ, FXP_EQ_HI,       /* the EQ before the drive (fx_eq.c; 64: flat) */
       FXP_N };   /* FXP_RAW: developer bypass of the whole chain (tests) */
static volatile int32_t fx_p[FXP_N] = {[FXP_DL_FDBK] = 80, [FXP_DL_TONE] = 70, [FXP_LEVEL] = 64, [FXP_CMP_RATIO] = 3,
                                       [FXP_FL_FREQ] = 127, [FXP_LFO_RATE] = 40, [FXP_DRV_TONE] = 64,
                                       [FXP_DRV_MIX] = 127, [FXP_DRV_SW] = 1, [FXP_RV_DECAY] = 64, [FXP_RV_TONE] = 64,
                                       [FXP_RV_TYPE] = 1, [FXP_RV_MOD] = 64, [FXP_EQ_LO] = 64, [FXP_EQ_MID] = 64,
                                       [FXP_EQ_FREQ] = 64, [FXP_EQ_HI] = 64};
static volatile uint32_t fx_lfo_sync_inc;        /* main loop: a synced LFO rate (Q32 step), 0 = free */
static volatile uint8_t fx_lfo_retrig;           /* main loop: a note started and RETRIG is on: the LFO from 0 */
static volatile uint32_t fx_cp_sync_inc;         /* main loop: a synced chorus rate, 0 = free */
static volatile uint32_t fx_ph_sync_inc;         /* main loop: a synced phaser rate, 0 = free */
static volatile int32_t fx_cmp_gr;               /* ISR: the compressor's gain reduction now, log2 Q12 (>= 0) */
static volatile uint32_t fx_dly_sync_samples;    /* main loop (tempo.c): a synced delay time, 0 = free */
static volatile uint32_t fx_tw_sync_inc;         /* main loop: a synced tremolo rate (Q32 step), 0 = free */
static volatile uint8_t fx_bypass;              /* main loop (the FX button): all effects off, settings kept */
#ifndef FR_BYP_KEEP_CMP
#define FR_BYP_KEEP_CMP 1                       /* the bypass keeps the compressor (fx_process: dry_c) */
#endif
static volatile int32_t fx_peak;                 /* ISR: last block's max |out| */
static volatile uint32_t prof_us, prof_max_us;   /* ISR (frodhes.c app_audio): its own time, this block / maximum */
static uint32_t prof_over;
static volatile uint32_t fx_quiet_blocks;
static volatile int32_t fx_cmp_amk, fx_cmp_beta;        /* main loop (fx_set): the compressor's auto make-up (log2 Q12)
                                                         * and body lift (Q8), from THRESH and RATIO (cmp_auto) */
static void cmp_auto(void);
/* a Program Change's effect values, spread over the blocks after it (presets.c preset_load, fx_pend_poll): the
 * block that carries the change (a chord, the pedal, a reverb TYPE from a CC with it) takes none of them, the next
 * the delay's, then the front's (COMP, EQ, DRIVE, FILTER), then the modulation's and the rest, then the reverb's. Each starts its own glide or fade as a CC
 * does, one block apart, so their first blocks' work (the delay's time fade, the compressor's and the EQ's starts,
 * the reverb TYPE's fade) never stacks with the burst's on core 1 (the two-core storm soak, 2026-11-15). A CC to a
 * value still waiting takes it over (the CC is newer). Main loop only: the ISR never reads these */
#define FX_PEND_N 4u
/* (own section, out of the compiler's global merge: in it they moved the merged variables the audio code reads, so
 * that code grew 2..38 B (longer offsets) and moved in the flash cache; the two-core storm's KHLON thirds paid
 * ~+140 us of core-1 busy for it, 2026-11-15) */
#ifdef DINGHY_HOST
#define FX_PEND_SECTION
#define FX_PEND_TAB
#else
#define FX_PEND_SECTION __attribute__((unused))
#define FX_PEND_TAB __attribute__((section(".data.fx_pend")))
#endif
static uint8_t fx_hold FX_PEND_SECTION;         /* main loop: fx_set keeps the values (preset_load) */
static uint8_t fx_pv[FXP_N] FX_PEND_SECTION;    /* the kept values */
static uint32_t fx_pm[FX_PEND_N][(FXP_N + 31u) / 32u] FX_PEND_SECTION;   /* the kept ids, per step */
static uint8_t fx_ps FX_PEND_SECTION;           /* the next step to apply + 1, 0 = none waits */
static uint32_t fx_pb FX_PEND_SECTION;          /* the block count the last step saw (frodhes.c blk_n) */
/* each id's step, XOR 2 (0 = the default step 2): a table in RAM, in its own section, not a switch (its lookup
 * table went to the end of .rodata and moved the effects' small tables after it in the flash cache, 2026-11-15) */
#define FXP_S0(i) [i] = 0u ^ 2u
#define FXP_S1(i) [i] = 1u ^ 2u
#define FXP_S3(i) [i] = 3u ^ 2u
static uint8_t fx_pend_tab[FXP_N] FX_PEND_TAB = {
    FXP_S0(FXP_DL_SW), FXP_S0(FXP_DL_DEPTH), FXP_S0(FXP_DL_TIME), FXP_S0(FXP_DL_FDBK), FXP_S0(FXP_DL_SYNC),
    FXP_S0(FXP_DL_TONE),
    FXP_S1(FXP_DRIVE), FXP_S1(FXP_DRIVE_ROW), FXP_S1(FXP_DRV_TONE), FXP_S1(FXP_DRV_MIX), FXP_S1(FXP_DRV_SW),
    FXP_S1(FXP_CMP_SW), FXP_S1(FXP_CMP_AMT), FXP_S1(FXP_CMP_ATK), FXP_S1(FXP_CMP_REL), FXP_S1(FXP_CMP_RATIO),
    FXP_S1(FXP_CMP_GAIN), FXP_S1(FXP_EQ_LO), FXP_S1(FXP_EQ_MID), FXP_S1(FXP_EQ_FREQ), FXP_S1(FXP_EQ_HI),
    FXP_S1(FXP_FL_TYPE), FXP_S1(FXP_FL_FREQ), FXP_S1(FXP_FL_RESO), FXP_S1(FXP_FL_LFO),
    FXP_S3(FXP_RV_DEPTH), FXP_S3(FXP_RV_DECAY), FXP_S3(FXP_RV_TONE), FXP_S3(FXP_RV_PREDLY), FXP_S3(FXP_RV_TYPE),
    FXP_S3(FXP_RV_SIZE), FXP_S3(FXP_RV_MOD), FXP_S3(FXP_RV_LOCUT),
};
static uint32_t fx_pend_step(uint32_t id)       /* (id < FXP_N: fx_set's check) */
{
    return fx_pend_tab[id] ^ 2u;
}
static void fx_set(uint32_t id, int32_t v)
{
    uint32_t k;
    if (id >= FXP_N) return;
    v = v < 0 ? 0 : v > 127 ? 127 : v;
    if (fx_hold) {
        if (fx_p[id] == v && !(fx_pm[fx_pend_step(id)][id >> 5] >> (id & 31u) & 1u)) return;   /* (unchanged) */
        fx_pv[id] = (uint8_t)v; fx_pm[fx_pend_step(id)][id >> 5] |= 1u << (id & 31u);
        return;
    }
    for (k = 0; k < FX_PEND_N; k++) fx_pm[k][id >> 5] &= ~(1u << (id & 31u));   /* (a newer value than one kept) */
    fx_p[id] = v;
    if (id == FXP_CMP_AMT || id == FXP_CMP_RATIO) cmp_auto();
}
static void fx_pend_apply(uint32_t k)           /* step k's kept values into fx_p, as fx_set would */
{
    uint32_t w, b, ca = 0;
    for (w = 0; w < (FXP_N + 31u) / 32u; w++)
        while (fx_pm[k][w]) {
            b = (uint32_t)__builtin_ctz(fx_pm[k][w]); fx_pm[k][w] &= fx_pm[k][w] - 1u;
            fx_p[32u * w + b] = fx_pv[32u * w + b];
            ca |= 32u * w + b == FXP_CMP_AMT || 32u * w + b == FXP_CMP_RATIO;
        }
    if (ca) cmp_auto();
}
static volatile uint32_t fx_gz;                         /* blocks since the silence gate shut the output (0) */
/* 500 ms under -66 dBFS, or 500 ms with the gate shut (BUGHUNT #27: an idle residue between -66 and -60 dBFS, KHLON's
 * offset moved by TREM, kept fx_quiet_blocks at 0 behind a shut gate, and nothing was ever saved) */
static int fx_quiet(void) { return fx_quiet_blocks >= 86u || fx_gz >= 86u; }

/* FX_K32: a local multiplier that is constant over a loop and used in (int64_t)a * v, read from the stack where it is
 * used (volatile: one load, the same value). Kept in a register instead, the compiler widens it to 64 bits once before
 * the loop and then, inside it, no longer sees a 32 x 32 product: it multiplies 64 x 64 (four multiplies and the
 * carries) instead of one instruction. */
#define FX_K32 volatile int32_t
static inline __attribute__((always_inline)) int32_t clampi(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }
static volatile uint8_t eng_cur;   /* (a tentative definition, engine.c's type: its own when it is in the unit, else the C
                                    * harnesses', which have no engine: the output gate reads it) */
/* FX_HC(k, v, lo, hi): v, and on the host a count when a clamp to [lo, hi] would cut it (engine.c fx_h_clip: the
 * effects' headroom gate, tests/py/test_fx_pristine.py); the firmware: v (nothing) */
#if defined(DINGHY_HOST) && !defined(DINGHY_WEB)
static uint32_t fx_h_clip[5];   /* (a tentative definition: engine.c's own when it is in the unit, else the C harnesses') */
static inline int32_t fx_hc(int k, int32_t v, int32_t lo, int32_t hi) { if (v < lo || v > hi) fx_h_clip[k]++; return v; }
#define FX_HC(k, v, lo, hi) fx_hc(k, v, lo, hi)
#else
#define FX_HC(k, v, lo, hi) (v)
#endif
static inline __attribute__((always_inline)) int32_t mulq15(int32_t a, int32_t b) { return (a * b) >> 15; }        /* |a|,|b| small enough */
/* ---- the on / off crossfade (0.9.6, the bug hunt: switching an effect replaced the dry signal by the processed one,
 * or back, in one sample: up to 1700 LSB steps under a held chord). An effect switched on or off keeps running while
 * its wet share w (Q15) glides 0 <-> 32768 by XF_STEP a sample (46 ms, as the drive's ON / OFF), then rests: at rest
 * (w at 0 or 32768) nothing extra runs, and at 32768 the effect's output is what it always was, bit for bit. The dry
 * copy (xf_d) is taken before the effect runs, the blend after; the effects that use it run one after another */
#define XF_STEP 16
#ifndef FX_XFD_SEC
#define FX_XFD_SEC POOL                         /* (FR_C1 builds, frodhes.c: NOINIT's spare room; scratch, written
                                                 * before it is read) */
#endif
static int32_t xf_d[2][256] FX_XFD_SEC;
#ifndef XF_STEP_CP
#define XF_STEP_CP 8                            /* the chorus and the phaser: 92 ms (0.9.10: the phaser, trimmed to
                                                 * the chord's peak, sits up to 5 dB under the chorus on its swing;
                                                 * CHO/PHA chorus -> phaser in 46 ms dropped 2.8 dB in one 23 ms
                                                 * window: the control sweep's jump 1.59, now 0.93) */
#endif
static inline int32_t xf_next_s(int32_t w, int on, uint32_t n, int32_t st)   /* the share at this block's end */
{
    int32_t s = st * (int32_t)n;
    return on ? (w + s > 32768 ? 32768 : w + s) : (w - s < 0 ? 0 : w - s);
}
#define xf_next(w, on, n) xf_next_s(w, on, n, XF_STEP)
/* x = d + (x - d) w, w ramping from w0 to w1 over the n samples (n = 256: steps of 4096, exact ends) */
__attribute__((noinline)) static void xf_blend(int32_t *x, const int32_t *d, uint32_t n, int32_t w0, int32_t w1)
{
    int32_t w = w0, dw = (w1 - w0) / (int32_t)n;
    uint32_t i;
    for (i = 0; i < n; i++) {
        w += dw;
        x[i] = d[i] + (int32_t)(((int64_t)(x[i] - d[i]) * w) >> 15);
    }
}
/* one helper pair for every effect's on / off (shared code: the flash is tight). xf_pre: the share at this block's
 * end and, while it moves, the dry copy of L (and of R; R = 0: mono) into xf_d; xf_post: the blend, L (and R) against
 * dl (dr) */
__attribute__((noinline)) static int32_t xf_pre(int32_t w, int on, const int32_t *L, const int32_t *R, uint32_t n,
                                                int32_t st)
{
    int32_t w1 = xf_next_s(w, on, n, st);
    if (w != 32768 || w1 != 32768) { memcpy(xf_d[0], L, n * sizeof *L); if (R) memcpy(xf_d[1], R, n * sizeof *R); }
    return w1;
}
__attribute__((noinline)) static void xf_post(int32_t *L, int32_t *R, const int32_t *dl, const int32_t *dr, uint32_t n,
                                              int32_t w0, int32_t w1)
{
    if (w0 == 32768 && w1 == 32768) return;
    xf_blend(L, dl, n, w0, w1);
    if (R) xf_blend(R, dr, n, w0, w1);
}
#if FR_CHUNK
/* FR_C1's sub-blocks (frodhes.c app_audio): fx_process runs each block as chunks [fxc_o, fxc_e) of the fxc_n (256)
 * samples, one call each, in order, every buffer indexed from the block's start. An effect does its once-a-block work
 * at the first chunk (FXC_1: fxc_o 0) and at the last (FXC_Z: fxc_e fxc_n), keeps what its first chunk worked out in
 * statics until the last, and ramps from the block's start: the chunks render the whole block's integers
 * (tests/py/test_c1_subblock.py: the two-core build = the one-core 14-voice build, sample for sample). The block whole
 * (fxc_o 0, fxc_e fxc_n) is one chunk. Chunks are multiples of 32 samples: every effect's sub-block grid */
static uint32_t fxc_o, fxc_e = 256u, fxc_n = 256u;
#if FR_LAT
static volatile uint32_t fxc_ce = 256u;               /* FR_LAT_HALF (frodhes.c app_audio): this interrupt's last frame + 1 */
#endif
#ifdef C1_EST_LOG
static uint32_t c1_est_blk;                              /* (host diagnostics: the block count, fx_process) */
#endif
static uint8_t fxc_side;                                 /* FX_SIDE_ON, latched at the block's first chunk (fx_process) */
static uint8_t fxc_eng;                                  /* the engine (engc_fx), latched there too: FX_ENG_K / G / DT
                                                          * of the block core 1 processes, not of the one core 0 began */
static const int32_t *fxc_mono;                          /* the block's dry voices (fx_process's mono: whole at the last chunk) */
#define FXC_1 (fxc_o == 0u)
#define FXC_Z (fxc_e == fxc_n)
#ifndef C1_PRE_C0
#define C1_PRE_C0 0
#endif
#if C1_PRE_C0
/* C1_PRE_C0 (a build switch, off by default): the mono front of the chain (COMP, EQ, DRIVE, FILTER: fx_front) runs
 * chunk by chunk, each chunk's on either core, chosen per chunk (frodhes.c c1_front_take): core 0 right after the
 * chunk's voices, before it hands the chunk on, or core 1 in fx_process before TREM. The fronts run in order, one core
 * at a time: fxf_done (the frames whose front is done, written by the core that ran it) says which chunks are left;
 * core 0 takes chunk j only when fxf_done is j's start (core 1 has none left before it), core 1 only the chunks under
 * fxf_done's end that core 0 has handed on (c1_rdy). The front's code reads its own chunk (fxf_o / fxf_e / fxf_n,
 * fxf_mono) and its own crossfade helpers (xf_*_cf), so core 0 on chunk k + 1 and core 1 on chunk k share no range
 * variable; the buffers they share (m, dry_c, xf_d, drv_wet) are indexed from the block's start, each chunk's frames
 * apart; the filter's crossfade scratch is its own (fl_xs). Every frame goes through the same stages in the same
 * order, every front over one chunk whoever runs it: the same integers on any placement */
static uint32_t fxf_o, fxf_e = 256u, fxf_n = 256u;
static const int32_t *fxf_mono;
static volatile uint8_t fxc_front_whole;                 /* (the whole path's block: the front over fx_process's range) */
static volatile uint32_t fxf_done;                       /* (this block's frames with their front done) */
static uint32_t fxf_k = 32u;                             /* (the chunk: frodhes.c's n / C1_SUB, set with fxf_done) */
static uint32_t fxf_rd(void)                             /* (read twice: a word read wrong once is not believed) */
{
    uint32_t a, b;
    do { fr_c1_sync(); a = fxf_done; fr_c1_sync(); b = fxf_done; } while (a != b);
    return a;
}
#endif
/* xf_pre / xf_post for a chunk: the dry copy of the chunk, the blend's ramp from the block's start */
__attribute__((noinline)) static int32_t xf_pre_c(int32_t w, int on, const int32_t *L, const int32_t *R, uint32_t n,
                                                  int32_t st)
{
    int32_t w1 = xf_next_s(w, on, n, st);
    uint32_t o = fxc_o, k = (fxc_e - o) * sizeof *L;
    if (w != 32768 || w1 != 32768) { memcpy(xf_d[0] + o, L + o, k); if (R) memcpy(xf_d[1] + o, R + o, k); }
    return w1;
}
__attribute__((noinline)) static void xf_blend_c(int32_t *x, const int32_t *d, uint32_t n, int32_t w0, int32_t w1)
{
    int32_t dw = (w1 - w0) / (int32_t)n, w = w0 + dw * (int32_t)fxc_o;
    uint32_t i;
    for (i = fxc_o; i < fxc_e; i++) {
        w += dw;
        x[i] = d[i] + (int32_t)(((int64_t)(x[i] - d[i]) * w) >> 15);
    }
}
__attribute__((noinline)) static void xf_post_c(int32_t *L, int32_t *R, const int32_t *dl, const int32_t *dr, uint32_t n,
                                                int32_t w0, int32_t w1)
{
    if (w0 == 32768 && w1 == 32768) return;
    xf_blend_c(L, dl, n, w0, w1);
    if (R) xf_blend_c(R, dr, n, w0, w1);
}
#if C1_PRE_C0
/* the same three on the front's chunk (fxf_o / fxf_e) */
__attribute__((noinline)) static int32_t xf_pre_cf(int32_t w, int on, const int32_t *L, const int32_t *R, uint32_t n,
                                                   int32_t st)
{
    int32_t w1 = xf_next_s(w, on, n, st);
    uint32_t o = fxf_o, k = (fxf_e - o) * sizeof *L;
    if (w != 32768 || w1 != 32768) { memcpy(xf_d[0] + o, L + o, k); if (R) memcpy(xf_d[1] + o, R + o, k); }
    return w1;
}
__attribute__((noinline)) static void xf_blend_cf(int32_t *x, const int32_t *d, uint32_t n, int32_t w0, int32_t w1)
{
    int32_t dw = (w1 - w0) / (int32_t)n, w = w0 + dw * (int32_t)fxf_o;
    uint32_t i;
    for (i = fxf_o; i < fxf_e; i++) {
        w += dw;
        x[i] = d[i] + (int32_t)(((int64_t)(x[i] - d[i]) * w) >> 15);
    }
}
__attribute__((noinline)) static void xf_post_cf(int32_t *L, int32_t *R, const int32_t *dl, const int32_t *dr, uint32_t n,
                                                 int32_t w0, int32_t w1)
{
    if (w0 == 32768 && w1 == 32768) return;
    xf_blend_cf(L, dl, n, w0, w1);
    if (R) xf_blend_cf(R, dr, n, w0, w1);
}
#endif
#endif
static inline __attribute__((always_inline)) int32_t softclip(int32_t x)                 /* Q15 tanh: x in Q15, flat beyond +-4 */
{
    uint32_t i;
    int32_t f;
    x = clampi(x, -131072, 131071);
    i = (uint32_t)(x + 131072) >> 10;
    f = (x + 131072) & 1023;
    return FX_TANH[i] + (((FX_TANH[i + 1] - FX_TANH[i]) * f) >> 10);
}
/* softclip for the running engine's level (k = FX_ENG_K, g = FX_ENG_G, a block's): the bars read 3 dB up, the result 3
 * dB down (bars.h BAR_FX_K: their SND3 -3 dB a level); the Rhodes (k 32768): softclip itself */
__attribute__((noinline)) static int32_t fx_sck_k(int32_t x, int32_t k, int32_t g)   /* (the bars' path: flash, the
                                                 * RAM loops keep their size) */
{
    return (int32_t)(((int64_t)softclip((int32_t)(((int64_t)x * k + 16384) >> 15)) * g + 16384) >> 15);
}
static inline __attribute__((always_inline)) int32_t FX_SCK(int32_t x, int32_t k, int32_t g)
{
    return k == 32768 ? softclip(x) : fx_sck_k(x, k, g);
}
static inline __attribute__((always_inline)) int32_t osc_sine(uint32_t ph)   /* Q32 phase -> +-32767 */
{
    uint32_t i = ph >> 22;
    int32_t f = (int32_t)((ph >> 7) & 0x7FFFu);
    return FX_SINE[i] + (((FX_SINE[i + 1] - FX_SINE[i]) * f) >> 15);
}

#if C1_PRE_C0                                           /* (the front's code: its own chunk, fx_front) */
#define fxc_o fxf_o
#define fxc_e fxf_e
#define fxc_n fxf_n
#define fxc_mono fxf_mono
#define xf_pre_c xf_pre_cf
#define xf_blend_c xf_blend_cf
#define xf_post_c xf_post_cf
#endif
/* ---- the LFO (its page) and the FILTER: a TPT state-variable stage (stable at any setting). TYPE: OFF, LP12 LP18,
 * HP12 HP18, BP, NOTCH. 12 dB / octave = the resonant stage; 18 = it and a 6 dB one-pole (no 24: its second stage cost
 * ~190 us of the audio block at the worst case). FREQ 30 Hz .. 16 kHz (log), RESO Q 0.707 .. 20, LFO moves FREQ by up to
 * +-4 octaves. Coefficients every 8 samples (the cutoff smoothed every 32), 32-bit division only (two partial quotients). */
static uint32_t lfo_ph, lfo_rnd = 0x9E3779B9u;
static int32_t lfo_sh, fl_ic[2], fl_op, fl_pos = 127 * 516;
static uint8_t fl_was_on, fl_type;                 /* fl_type: the TYPE the filter runs (it glides to dry before
                                                     * it takes another one, or stops for OFF: the bug hunt, 2026-10-25,
                                                     * LP12 -> HP12 was -11 dB in one sample) */
static int32_t fl_ow = 32768, fl_dry[32];         /* the filter's wet share (0 = fully open: dry), a sub-block of dry */
static int32_t fl_kq;                              /* RESO's damping k as it glides (Q24): at most 1/128 of itself a
                                                    * sub-block (k stepped once a block: on the band-pass the output is
                                                    * k v1, a gain step, 34x a held one's d2 on F12 -> F01, the bug hunt) */
#define FL_JMP 910                                 /* the cutoff's largest step a sub-block, 1/8 octave (fl_pos: 516 a
                                                    * FREQ step, ~7280 an octave): a jump of FREQ or of an S&H / square
                                                    * LFO swept 9 octaves in ~3 ms, a click and a resonant burst on BP
                                                    * (#13); the knob's detents and the LFO's sines move far less */
#if FR_CHUNK
static int32_t lfo_shp;                                   /* LFO SHAPE, latched at the block's first chunk (fx_filter) */
#define LFO_SHP lfo_shp
#else
#define LFO_SHP fx_p[FXP_LFO_SHAPE]
#endif
static int32_t lfo_value(void)                            /* +-32767 */
{
    uint32_t ph = lfo_ph;
    switch (LFO_SHP) {
    case 1: return ph < 0x80000000u ? (int32_t)(ph >> 15) - 32768 : 98303 - (int32_t)(ph >> 15);   /* triangle */
    case 2: return (int32_t)(ph >> 16) - 32768;                                                     /* saw up */
    case 3: return 32767 - (int32_t)(ph >> 16);                                                     /* saw down */
    case 4: return ph < 0x80000000u ? 32767 : -32767;                                               /* square */
    case 5: return lfo_sh;                                                                          /* sample & hold */
    default: return osc_sine(ph);
    }
}
static int32_t recip27(uint32_t den)                      /* 2^43 / den (den Q16) = 1 / den in Q27, 32-bit only */
{
    uint32_t q = 0x80000000u / den, r = 0x80000000u - q * den;
    return (int32_t)((q << 12) + (r << 12) / den);
}
static int32_t log2_q12(uint32_t x);
static int32_t exp2_q16(int32_t g);
typedef struct { int32_t a1, a2, a3, k; } svf_t;
static void svf_coef(svf_t *c, int32_t g, int32_t k)      /* g, k in Q24 */
{
    c->a1 = recip27(65536u + (uint32_t)(((int64_t)g * (g + k)) >> 32));
    c->a2 = (int32_t)(((int64_t)g * c->a1) >> 24);
    c->a3 = (int32_t)(((int64_t)g * c->a2) >> 24);
    c->k = k;
}
/* clampi(v, -2^24, 2^24) as smax + smin (the same value) */
static inline int32_t fl_cl(int32_t v) { v = v > -(1 << 24) ? v : -(1 << 24); return v < (1 << 24) ? v : 1 << 24; }
static inline int32_t svf_tick(const svf_t *c, int32_t *ic, int32_t x, uint32_t mode)   /* 0 LP 1 HP 2 BP 3 NOTCH */
{
    int32_t v3 = x - ic[1], v1, v2, kv1;
    v1 = (int32_t)(((int64_t)c->a1 * ic[0] + (int64_t)c->a2 * v3 + (1 << 26)) >> 27);   /* rounded: no DC creep */
    v2 = ic[1] + (int32_t)(((int64_t)c->a2 * ic[0] + (int64_t)c->a3 * v3 + (1 << 26)) >> 27);
    ic[0] = fl_cl(2 * v1 - ic[0]);
    ic[1] = fl_cl(2 * v2 - ic[1]);
    kv1 = (int32_t)(((int64_t)c->k * v1 + (1 << 23)) >> 24);
    return mode == 0u ? v2 : mode == 1u ? x - kv1 - v2 : mode == 2u ? kv1 : x - kv1;
}
/* one sub-block of the filter; mode and p18 are constants after inlining (a version per TYPE), the state in locals */
/* RESO's gain compensation (2026-11-08): LP and HP lifted the sound by the resonance (a v127 chord +2.8 dB at LP18
 * FREQ 64 RESO 64, on the limiter; over FREQ 30..100 the peaks +5.5 dB on average at RESO 127, tools/fx_pristine.py);
 * their input now x (k / k0)^FL_RCA (k RESO's damping as it glides, k0 RESO 0's: x 1 there, bit for bit), the band-pass
 * (k v1, its peak already 1) and the notch as they were. fl_rc: Q12, with the coefficients */
#ifndef FL_RCA
#define FL_RCA 819                                         /* (Q12: 0.2; over FREQ 30..100 LP keeps its RMS within -0.8 .. +0.8 dB of RESO 0, the peaks +1.0 .. +1.6 dB on average re RESO 0 (0.25: the peaks +0.2 .. +0.6, the RMS down to -3 dB)) */
#endif
#define FL_NEAR 4096                                       /* (0.9.13: a state within this of 0 (512 LSB out) may be a
                                                            * stuck one, fx_filter) */
static int32_t fl_rc = 4096, fl_ri = 4096;              /* (fl_ri: 1 / fl_rc, Q12: BP / NOTCH restored at the output) */
static inline __attribute__((always_inline)) void fl_run(int32_t *m, uint32_t n, const svf_t *c, const uint32_t mode,
                                                         const int p18, int32_t gp)
{
    int32_t ic[2] = {fl_ic[0], fl_ic[1]}, op = fl_op, *e = m + n, rc = fl_rc, ri = fl_ri;
    for (; m < e; m++) {
        /* the input x rc on every mode, so the state is the same whichever TYPE reads it (a TYPE's crossfade runs two
         * from one state: scaled for LP / HP only, LP -> BP clicked, tools/control_sweep.py 180x); BP / NOTCH back x 1 / rc */
        int32_t x = (int32_t)(((int64_t)*m * rc) >> 9);                  /* 8x finer inside: a lower noise floor */
        x = svf_tick(c, ic, x, mode);
        if (mode >= 2u) x = (int32_t)(((int64_t)x * ri) >> 12);
        if (p18) {                                                       /* 18: + a 6 dB one-pole */
            int32_t v = (int32_t)(((int64_t)(x - op) * gp + (1 << 26)) >> 27), lp = v + op;
            op = fl_cl(lp + v);
            x = mode == 0u ? lp : x - lp;
        }
        *m = (x + 4) >> 3;
    }
    fl_ic[0] = ic[0]; fl_ic[1] = ic[1]; fl_op = op;
}
/* a TYPE -> another TYPE (0.9.6, the control sweep: through dry, HP12 -> HP18 at 1.5 kHz rose +21 dB for ~40 ms): one
 * state-variable stage gives LP, BP, HP and NOTCH at once, so the old TYPE's output crossfades into the new one's over
 * 46 ms (w: Q15, +16 a sample), each 18 dB TYPE with its own one-pole (op: the old one's, fl_op2: the new one's). Only
 * while it fades; at rest the loops above run as before */
static int32_t fl_op2, fl_xw;                              /* the new TYPE's one-pole, the crossfade (0: none) */
static svf_t fl_cc;                                         /* the last coefficients (fl_cps: at that cutoff, -1 none; */
static int32_t fl_cps = -1, fl_ckq, fl_cgq, fl_cgp;         /* fl_ckq: that RESO; fl_cgq: its g; fl_cgp: the one-pole's, */
static uint8_t fl_cgv;                                      /* valid when fl_cgv) */
static uint8_t fl_xt;                                       /* the TYPE it fades to */
/* one sub-block of the filter at a TYPE (1..6): one loop per (mode, poles), no tests per sample (noinline: the loops
 * get its registers, as they had in fx_filter; a TYPE change runs it twice) */
FR_RAM2 __attribute__((noinline)) static void fl_pass(int32_t *m, uint32_t n, const svf_t *c, uint32_t type, int32_t gp)
{
    switch (type) {
    case 1: fl_run(m, n, c, 0, 0, gp); break;
    case 2: fl_run(m, n, c, 0, 1, gp); break;
    case 3: fl_run(m, n, c, 1, 0, gp); break;
    case 4: fl_run(m, n, c, 1, 1, gp); break;
    case 5: fl_run(m, n, c, 2, 0, gp); break;
    default: fl_run(m, n, c, 3, 0, gp); break;
    }
}
/* the crossfade: the sub-block through the old TYPE (into m) and, from the same state, the new one (into xf_d[1], its
 * own one-pole fl_op2); the state goes on from either (the stage's update does not depend on the mode); then
 * m = old + (new - old) w, w from w0 by 16 a sample */
#if C1_PRE_C0
static int32_t fl_xs[32];                                /* fl_xrun's scratch (n <= 32): xf_d is core 1's meanwhile */
#define FL_XS fl_xs
#else
#define FL_XS xf_d[1]
#endif
__attribute__((noinline)) static void fl_xrun(int32_t *m, uint32_t n, const svf_t *c, uint32_t t0, uint32_t t1,
                                              int32_t gp, int32_t w0)
{
    int32_t ic0 = fl_ic[0], ic1 = fl_ic[1], op;
    memcpy(FL_XS, m, n * sizeof *m);
    FR_FAR2(fl_pass)(m, n, c, t0, gp);
    op = fl_op; fl_ic[0] = ic0; fl_ic[1] = ic1; fl_op = fl_op2;
    FR_FAR2(fl_pass)(FL_XS, n, c, t1, gp);
    fl_op2 = fl_op; fl_op = op;
    xf_blend(FL_XS, m, n, w0, w0 + 16 * (int32_t)n);
    memcpy(m, FL_XS, n * sizeof *m);
}
/* noinline (0.9.5): its six loops get their own registers (inlined into app_audio they reloaded the coefficients'
 * and the buffer's addresses per sample: 43-68 instructions a sample, 34-57 now) */
static __attribute__((noinline)) void fx_filter(int32_t *m, uint32_t n)
{
    static const uint8_t POLES[7] = {0, 2, 3, 2, 3, 2, 2};   /* TYPE -> poles; the mode (LP HP BP NOTCH) is in the switch below */
#if FR_CHUNK
    static uint32_t type, poles, want, inc;              /* (the block's, from its first chunk: the parameters too, */
    static int open, rest;                               /* fx_set may change fx_p between chunks; 0.9.13, the */
    static int32_t k, base, depth;                       /* audio review D6) */
    uint32_t sb, j;
    if (FXC_1) {
        inc = fx_lfo_sync_inc ? fx_lfo_sync_inc : FX_LFO_INC[fx_p[FXP_LFO_RATE]];
        k = (int32_t)FX_FL_K[fx_p[FXP_FL_RESO]]; base = fx_p[FXP_FL_FREQ] * 516; depth = fx_p[FXP_FL_LFO];
        lfo_shp = fx_p[FXP_LFO_SHAPE];
        type = fx_p[FXP_FL_TYPE]; rest = 0;
        if (fx_lfo_retrig) { fx_lfo_retrig = 0; lfo_ph = 0; }
        if (type > 6u) type = 0;
        if (!fl_was_on) {
            if (!type) { lfo_ph += inc * n; rest = 1; }
            else {
                memset(fl_ic, 0, sizeof fl_ic); fl_op = 0; fl_pos = base; fl_was_on = 1; fl_ow = 0; fl_type = (uint8_t)type;
                fl_cps = -1;
                fl_kq = k;
            }
        }
        if (!rest) {
            want = type; type = fl_type;
            poles = POLES[type];
            open = (type == 1u || type == 2u) && fx_p[FXP_FL_FREQ] >= 127 && !fx_p[FXP_FL_RESO] && !depth;
            if (want != type && want && fl_ow && !fl_xw) { fl_xt = (uint8_t)want; fl_xw = 1; fl_op2 = 0; }
            open |= want != type && !fl_xw;
        }
    }
    if (rest) return;
    for (sb = fxc_o; sb < fxc_e; sb += 32u) {
#else
    uint32_t type = fx_p[FXP_FL_TYPE], inc = fx_lfo_sync_inc ? fx_lfo_sync_inc : FX_LFO_INC[fx_p[FXP_LFO_RATE]], sb, j;
    int32_t k = (int32_t)FX_FL_K[fx_p[FXP_FL_RESO]], base = fx_p[FXP_FL_FREQ] * 516, depth = fx_p[FXP_FL_LFO];
    uint32_t poles, want;
    int open;
    if (fx_lfo_retrig) { fx_lfo_retrig = 0; lfo_ph = 0; }
    if (type > 6u) type = 0;
    if (!fl_was_on) {                                    /* off: the LFO keeps time, the filter rests */
        if (!type) { lfo_ph += inc * n; return; }
        memset(fl_ic, 0, sizeof fl_ic); fl_op = 0; fl_pos = base; fl_was_on = 1; fl_ow = 0; fl_type = (uint8_t)type;
        fl_cps = -1;
        fl_kq = k;
    }                                                    /* (switched on: from dry, the 46 ms glide in) */
    want = type; type = fl_type;
    poles = POLES[type];
    open = (type == 1u || type == 2u) && fx_p[FXP_FL_FREQ] >= 127 && !fx_p[FXP_FL_RESO] && !depth;   /* LP fully open:
                         * transparent (the default LP18 at 16 kHz trimmed the top: SNR -1 dB, TODO #5) */
    if (want != type && want && fl_ow && !fl_xw) { fl_xt = (uint8_t)want; fl_xw = 1; fl_op2 = 0; }   /* another TYPE:
                                                         * the crossfade (from dry, or open: it is taken at once below) */
    open |= want != type && !fl_xw;                      /* OFF: out to dry first, as when open */
    for (sb = 0; sb < n; sb += 32u) {
#endif
        uint32_t prev = lfo_ph, q;
        int32_t tgt, p0 = fl_pos;
        lfo_ph += inc * 32u;
        if (lfo_ph < prev) { lfo_rnd = lfo_rnd * 1664525u + 1013904223u; lfo_sh = (int32_t)(lfo_rnd >> 16) - 32768; }
        tgt = clampi(base + (int32_t)(((int64_t)lfo_value() * depth * 28932) >> 22), 0, 65535);   /* 4 octaves */
        fl_pos += clampi((tgt - fl_pos) >> 2, -FL_JMP, FL_JMP);
        if (fl_kq != k) fl_kq += clampi(k - fl_kq, -(fl_kq >> 7), fl_kq >> 7);
        j = sb + 32u < n ? sb + 32u : n;
        int32_t s0i = fl_ic[0], s1i = fl_ic[1], sop = fl_op, sx = m[sb] | m[j - 1u];   /* (the stuck state's check:
                                                         * a state near 0 and the ends of the input 0, then all of it) */
        int near = !sx && (uint32_t)(s0i + FL_NEAR) < 2u * FL_NEAR && (uint32_t)(s1i + FL_NEAR) < 2u * FL_NEAR
                   && (uint32_t)(sop + FL_NEAR) < 2u * FL_NEAR;
        if (near) for (q = sb; q < j; q++) sx |= m[q];
        if (fl_ow != 32768 || open) memcpy(fl_dry, m + sb, (j - sb) * sizeof *m);
        /* the coefficients every 8 samples (0.9.8 fxq-mod; they stepped every 32: a swept cutoff put images of a tone
         * at +-1378 Hz, -31 dB re a 2 kHz tone through LP12 under the fastest sine LFO, tools/fxq_metrics.py): the
         * cutoff (fl_pos, log) moves from the last sub-block's to this one's in four steps, the last one this
         * sub-block's own (held still, every quarter has the same coefficients: the same integers as before) */
        for (q = 0; q < 4u && sb + 8u * q < j; q++) {
            uint32_t s0 = sb + 8u * q, s1 = s0 + 8u < j ? s0 + 8u : j;
            int32_t ps = p0 + (((fl_pos - p0) * (int32_t)(q + 1u)) >> 2), gp = 0;
            if (ps != fl_cps || fl_kq != fl_ckq) {      /* (the cutoff or RESO moved: new coefficients; held, the
                                                         * last ones: a still filter computes fewer than before) */
                uint32_t i = (uint32_t)ps >> 8;
                int32_t f = ps & 255;
                fl_cgq = (int32_t)FX_FL_G[i] + ((((int32_t)FX_FL_G[i + 1] - (int32_t)FX_FL_G[i]) * f) >> 8);   /* Q24 */
                svf_coef(&fl_cc, fl_cgq, fl_kq);
                if (fl_kq != fl_ckq || fl_cps < 0) {
                    int32_t k0 = (int32_t)FX_FL_K[0];
                    fl_rc = fl_kq >= k0 ? 4096
                          : exp2_q16((int32_t)(((int64_t)(log2_q12((uint32_t)fl_kq) - log2_q12((uint32_t)k0)) * FL_RCA) >> 12)) >> 4;
                    fl_ri = (int32_t)((4096u << 12) / (uint32_t)fl_rc);
                }
                fl_cps = ps; fl_ckq = fl_kq; fl_cgv = 0;
            }
            if (poles == 3u || (fl_xw && POLES[fl_xt] == 3u)) {
                if (!fl_cgv) { fl_cgp = (1 << 27) - recip27(65536u + ((uint32_t)fl_cgq >> 8)); fl_cgv = 1; }   /* g/(1+g) */
                gp = fl_cgp;
            }
            if (fl_xw) fl_xrun(m + s0, s1 - s0, &fl_cc, type, fl_xt, gp, fl_xw - 1 + 16 * (int32_t)(s0 - sb));
            else FR_FAR2(fl_pass)(m + s0, s1 - s0, &fl_cc, type, gp);
        }
        if (near && !sx && !fl_xw && fl_ic[0] == s0i && fl_ic[1] == s1i && fl_op == sop && (s0i | s1i | sop)) {
            /* 0.9.13: exact silence in (the whole sub-block) and the state held still, near 0 but not at 0: the rounding's dead band (a low cutoff: a3 v3
             * rounds to 0, so ic[1] never moves; up to +-19 LSB of DC out, which TREM then moved at its rate, and
             * fx_quiet never came: no save). Each state 1 step toward 0 a sub-block (1/8 LSB out): out of the band
             * in at most ~0.1 s, then the filter's own decay. Any moving state or any input: untouched */
            fl_ic[0] -= (s0i > 0) - (s0i < 0);
            fl_ic[1] -= (s1i > 0) - (s1i < 0);
            fl_op -= (sop > 0) - (sop < 0);
        }
        if (fl_xw) {                                     /* TYPE -> TYPE: the crossfade, 46 ms */
            fl_xw += 16 * (int32_t)(j - sb);
            if (fl_xw > 32768) { fl_type = fl_xt; type = fl_xt; poles = POLES[type]; fl_op = fl_op2; fl_xw = 0; }
        }
        if (fl_ow != 32768 || open) {                    /* fully open: the sound passes untouched (the filter keeps
                                                         * running, its state current); in / out of it a 46 ms glide */
            int32_t w1 = open ? (fl_ow > 512 ? fl_ow - 512 : 0) : (fl_ow < 32256 ? fl_ow + 512 : 32768);
            uint32_t len = j - sb;
            if (!fl_ow && !w1) memcpy(m + sb, fl_dry, len * sizeof *m);   /* open: the dry block exactly */
            else xf_blend(m + sb, fl_dry, len, fl_ow, w1);  /* (+-16 per sample over a 32 sub-block) */
            fl_ow = w1;
        }
    }
#if FR_CHUNK
    if (FXC_Z && want != type && !fl_ow) {
#else
    if (want != type && !fl_ow) {                       /* dry now: take the new TYPE (it glides in), or rest */
#endif
        if (want) fl_type = (uint8_t)want; else fl_was_on = 0;
    }
}

#if !FR_OWN                                     /* the classic drive (FDRV): fx_fel.c part 4; its TYPE 1 in the plugin's own-code build is drv_own1.c (drive.c) */
#define FEL_PART 4
#include "fx_fel.c"
#undef FEL_PART
#endif  /* !FR_OWN */
#include "drive.c"                                      /* the drive's TYPEs and fx_drive */
#include "fx_eq.c"                                      /* the EQ before the drive (fx_eq) */

#if C1_PRE_C0                                           /* (the front's code ends) */
#undef fxc_o
#undef fxc_e
#undef fxc_n
#undef fxc_mono
#undef xf_pre_c
#undef xf_blend_c
#undef xf_post_c
#endif
/* ---- TREMOLO (autopan / amplitude) and touch WAH; mono in, stereo out */
static uint32_t tw_ph;
static int32_t tw_gl = 32768, tw_gr = 32768, wah_env;
static int32_t wah_ein, wah_eout, wah_g = 4096, wah_pi, wah_po;   /* the wah's make-up: loudness envelopes of the
                                                 * input and the output (pre-emphasised), the gain (Q12), last samples */
static int32_t wah_eslow, wah_g1 = 4096;        /* the input's slow envelope (onsets), the gain's first smoothing pole */
#ifndef WAH_PKH
#define WAH_PKH 8192                                        /* (Q12: the peak cap's headroom, x2) */
#endif
static int32_t wah_pki, wah_pko;                /* peak envelopes of the input and the wah at unity (the make-up's cap) */
/* v / 10, truncated as C's division, for every int32 v: a multiply and a shift instead of the core's divide in the wah's
 * sample loops (0.9.5 cpu-trim; checked exhaustively over all 2^32 values) */
/* the wah's input range (BUGHUNT #26): the SVF's resonant peak (bp, lp up to ~1/q x the input) and its products
 * (q x bp, f x hi) fit 32 bits up to here; a hot input (COMP's +24 dB make-up, the pedal: 0.9.5 overflowed at ~12x full
 * scale) is clipped to it, 2x full scale (every render below it: the gates' heaviest ~14000) */
#define WAH_XM 65535
#if defined(DINGHY_HOST) && !defined(DINGHY_WEB)
#define WAH_HC() (fx_h_clip[4]++)                       /* (the host: the input clip counted, engine.c fx_h_clip) */
#else
#define WAH_HC() ((void)0)
#endif
#define WAH_PEN 4                                       /* the envelopes' pre-emphasis, x - WAH_PEN / 8 x[-1] (below) */
static inline __attribute__((always_inline)) int32_t div10(int32_t v) { return (int32_t)(((int64_t)v * 1717986919) >> 34) + (int32_t)((uint32_t)v >> 31); }
/* the wah's filter (0.9.8 fxq-mod): the same state-variable (Chamberlin) filter, the same response, computed 64 times
 * finer inside (x 64) with 28-bit coefficients and rounded (it had 13-bit ones and truncated: a noise floor -25 dB under a
 * quiet note, a 1 kHz sine at -41 dBFS, tools/fxq_metrics.py, mostly the output rounded to the bus' grain before the
 * make-up gain raised it up to x32; and grit on loud notes). The make-up gain takes the finer output. (The FILTER's
 * TPT stage was tried: it has zeros at Nyquist, the wah 2 dB darker at 6-13 kHz and 7 dB at 13-20 kHz: not taken.)
 * The cutoff: 300 Hz .. 2.5 kHz, 64 log rows by the envelope, as before, now with a row of hysteresis: up at once, down
 * when the envelope is a whole row under (the envelope's ripple within a cycle toggled the row at a row's edge, each
 * toggle a step of the cutoff: harmonics at -60 dB on a 300 Hz sine). Rows interpolated measured worse (the ripple then
 * moves the cutoff all the time: -47 dB on a loud 1 kHz sine). The output law as before: 0.9 x the band-pass x 2q +
 * 0.4 x the low-pass. Its sub-block (k <= 32 samples) into out: the wah, its make-up gain ramped (wgq, wgs a sample),
 * the input clipped to WAH_XM */
static int32_t wah_bp, wah_lp, wah_cr = -1;     /* the stage's state (x 64), the cutoff's row (-1: none yet) */
#define WAH_CL(v) ((v) > (1 << 26) ? (1 << 26) : (v) < -(1 << 26) ? -(1 << 26) : (v))   /* (the resonant peak: ~7x
                                                 * 2^22; the output's sum < 2^31) */
FX_RAM __attribute__((noinline)) static void wah_sub(const int32_t *mp, uint32_t k, int32_t *out, int32_t wgq,
                                                     int32_t wgs, int32_t depth, int32_t q)
{
    int32_t env = wah_env, ei = wah_ein, eo = wah_eout, es = wah_eslow, xi = wah_pi, xo = wah_po;
    int32_t dk = (int32_t)(((depth + 16) * FX_ENG_K) >> 13);   /* (x 4: the bars' envelope read 3 dB up, bars.h
                                                 * BAR_FX_K, their SND3 -3 dB a level; the Rhodes 4 (depth + 16)) */
    int32_t et = (16777216 + dk - 1) / dk;      /* (env x dk) >> 18 reaches row 63 from env >= et: below it the
                                                 * product fits 32 bits */
    int32_t bp = wah_bp, lp = wah_lp, cr = wah_cr, f = cr < 0 ? 0 : (int32_t)FX_WAH_F[cr], mi = 0, mo = 0;
    int32_t wx[32];                             /* (the output on the bus' grain, x: pass 1 -> pass 2) */
    int32_t q18 = 18 * q;                       /* (q: 2464 .. 9830, fx_trem: 18 q fits 32 bits, 32 x 32 below) */
    uint32_t j;
    /* two passes, the same integers (0.9.10 c1-cpu: one loop held ~20 values live and spilled 37 stack accesses a
     * sample): (1) the cutoff, the filter and the output, (2) the envelopes and the peaks, which read only the input
     * and x and feed nothing back into (1) */
    for (j = 0; j < k; j++) {
        int32_t xin = mp[j], x, xf, a = xin < 0 ? -xin : xin;
        if (a > WAH_XM) { a = WAH_XM; xin = xin < 0 ? -WAH_XM : WAH_XM; WAH_HC(); }   /* (BUGHUNT #26: the stage's range) */
        if (a > env) env += (a - env) >> 3; else env -= (env >> 11) + 1;
        if (env < 0) env = 0;
        {                                       /* the cutoff's row, 0 .. 63: up at once, down a row late */
            int32_t row = env >= et ? 63 : (env * dk) >> 18;   /* env >= 0, dk > 0 */
            if (row > cr || row < cr - 1) { cr = row > cr ? row : row + 1; f = (int32_t)FX_WAH_F[cr]; }
        }
        {
            int32_t hi = (xin << 6) - lp - (int32_t)(((int64_t)q * bp + (1 << 13)) >> 14);
            bp = WAH_CL(bp + (int32_t)(((int64_t)f * hi + (1 << 27)) >> 28));
            lp = WAH_CL(lp + (int32_t)(((int64_t)f * bp + (1 << 27)) >> 28));
            xf = div10((int32_t)(((int64_t)q18 * bp + (1 << 13)) >> 14) + 4 * lp);   /* bp x 2q: the resonant
                                                 * peak's gain held, louder playing no longer gets louder (0.7); x 64 */
            x = (xf + 32) >> 6;                 /* (the bus' grain: for the output's envelope) */
        }
        wx[j] = x;
        wgq += wgs;
        out[j] = (int32_t)(((int64_t)xf * (wgq >> 5) + (1 << 17)) >> 18);   /* (x 64, the gain Q12) */
    }
    /* envelopes of the input and the filtered output, each pre-emphasised (x - 1/2 x[-1]: +9.5 dB from the bass
     * to the treble, roughly the ear's weighting) so a closed wah's rumble does not count as loudness. (It was
     * x - 3/4 x[-1], +12 dB: the 0.9.10 Rhodes C7 v40 under a closed resonant wah +1.16 LU; now +0.88, every
     * engine's wah within test_hil_limits' bounds, 2026-11-08) */
    for (j = 0; j < k; j++) {
        int32_t xin = mp[j], x = wx[j], a = xin < 0 ? -xin : xin, pi, po, vi, vo;
        if (a > WAH_XM) { a = WAH_XM; xin = xin < 0 ? -WAH_XM : WAH_XM; }
        pi = xin - ((WAH_PEN * xi) >> 3); po = x - ((WAH_PEN * xo) >> 3);
        vi = (pi < 0 ? -pi : pi) << 8; vo = (po < 0 ? -po : po) << 8;   /* x 2^8: a Q15 level's steps survive the >> */
        xi = xin; xo = x;
        po = x < 0 ? -x : x;                    /* (the sub-block's peaks) */
        mi = a > mi ? a : mi; mo = po > mo ? po : mo;
        ei += (vi - ei) >> (vi > ei ? 7 : 9);   /* 2.9 ms up, 11.6 ms down */
        eo += (vo - eo) >> (vo > eo ? 7 : 9);
        es += (vi - es) >> 11;
    }
    wah_env = env; wah_ein = ei; wah_eout = eo; wah_eslow = es; wah_pi = xi; wah_po = xo;
    wah_bp = bp; wah_lp = lp; wah_cr = cr;
    wah_pki -= wah_pki >> 5; wah_pki = mi > wah_pki ? mi : wah_pki;   /* (the peaks: at once up, ~23 ms down) */
    wah_pko -= wah_pko >> 5; wah_pko = mo > wah_pko ? mo : wah_pko;
}
/* the wah, the tremolo's gains settled at unity: L / R = the wah (onto the cleared fx_L / fx_R: the wah is their
 * only writer before this) */
FR_RAM2 static void fx_wah_unity(const int32_t *mp, const int32_t *me, int32_t *lo, int32_t *ro, int32_t wgq, int32_t wgs,
                         int32_t depth, int32_t q)
{
    uint32_t k = (uint32_t)(me - mp);
    FR_FAR(wah_sub)(mp, k, ro, wgq, wgs, depth, q);
    memcpy(lo, ro, k * sizeof *lo);
}
/* the amp law (SHAPE 65..127, 0.9.5): an amp's tremolo rather than a sine on the volume. Its amount a (0 at SHAPE 64,
 * 1 at 127) brings in, together: (1) the LFO's fall from the top to the dip takes 50 -> 65 % of the cycle, the rise
 * back the rest (a piecewise-linear phase warp of the sine: the dip is slower than the rise); (2) the gain moves evenly
 * in dB between unity and the dip's floor (FX_TREM_LT: the linear law's own floor, held at -30 dB, so a deep setting
 * breathes instead of chopping to silence), blended with the linear law by a, with FX_TREM_MK's make-up (the same
 * mean power: no level step when SHAPE moves into the region); (3) a touch of level-dependent depth: up to 25 % less
 * depth at full-scale output (the power stage compressing the swing), from the last blocks' peak (tw_lv, ~190 ms).
 * The squaring of SHAPE 0..64 eases back to the plain sine over the region. Everything is per sub-block (the samples'
 * loop and its gain ramp are as before), so nothing in it can alias; SHAPE 0..64 is bit for bit as before. */
static int32_t tw_lv, tw_amp, tw_dpt, tw_shp;
static uint32_t tw_fq, tw_r1, tw_r2;
/* TWP(id): a TREM/WAH parameter (FXP_TW_SW .. FXP_TW_SHAPE) and TW_SYNC the synced rate as the block uses them: FR_CHUNK
 * latches them at the block's first chunk (fx_trem; fx_set may change fx_p between chunks: 0.9.13, the audio review
 * D6), the one-block build reads them as before */
#if FR_CHUNK
static int32_t tw_lk[FXP_TW_SHAPE - FXP_TW_SW + 1];
static uint32_t tw_lsync;
#define TWP(id) tw_lk[(id) - FXP_TW_SW]
#define TW_SYNC tw_lsync
#else
#define TWP(id) fx_p[id]
#define TW_SYNC fx_tw_sync_inc
#endif
static int32_t tw_exp2n(int32_t y)                       /* 2^(-y / 4096) in Q15, y in 0 .. 5 x 4096 */
{
    int32_t k = y >> 12, e = 4096 - (y & 4095);          /* 2^(-k - fr) = 2^(1 - fr) / 2^(k + 1) */
    int32_t mq = e == 4096 ? 131072 : (int32_t)FX_EXP2F(e >> 4);   /* Q16 */
    return mq >> (k + 2);
}
static void tw_amp_block(int32_t shp, int32_t depth)   /* this block's warp and depth */
{
    int32_t pk = fx_peak > 32767 ? 32767 : fx_peak, a = (shp - 64) * 520;   /* a: Q15, 520 .. 32760 */
    tw_amp = a;
    tw_fq = 0x80000000u + (uint32_t)a * 19661u;      /* the fall's share of the cycle: 0.5 + 0.15 a (Q32) */
    tw_r1 = 0x80000000u / (tw_fq >> 15);             /* 0.5 / share, Q15 */
    tw_r2 = 0x80000000u / ((0u - tw_fq) >> 15);      /* 0.5 / (1 - share), Q15 */
    tw_lv += (pk - tw_lv) >> 5;
    tw_dpt = depth - ((((depth * tw_lv) >> 15) * a) >> 17);   /* up to depth / 4 less at full scale */
    tw_shp = ((127 - shp) * 65) >> 6;                /* the squaring eases back: 62 at 65 .. 0 at 127 */
}
static int32_t tw_amp_sub(uint32_t ph, int32_t *tr)   /* a sub-block's gains (AM, PAN) */
{
    uint32_t u = ph - (1u << 30);                    /* the warp: the top (phase 1/4) to the dip (3/4) over tw_fq */
    int32_t lfo, d = tw_dpt, g, ge;
    ph = u < tw_fq ? (1u << 30) + (u >> 15) * tw_r1 : 0xC0000000u + ((u - tw_fq) >> 15) * tw_r2;
    lfo = osc_sine(ph);
    lfo = clampi((int32_t)(((int64_t)lfo * (32768 + 7 * 258 * tw_shp)) >> 15), -32767, 32767);
    if (TWP(FXP_TW_MODE) == 0) {                     /* PAN: as in fx_trem, with the warp and the depth */
        uint32_t th = (1u << 29) + (uint32_t)((d * lfo) * 129);
        int32_t gl = (osc_sine(th + (1u << 30)) * 46341) >> 15;
        *tr = (osc_sine(th) * 46341) >> 15;
        return gl;
    }
    g = 32768 - (((d * 258) * ((32767 - lfo) >> 1)) >> 15);
    g = (g * (254 + d)) / 254;                       /* the linear law, as in fx_trem */
    ge = tw_exp2n((FX_TREM_LT[d] * ((32767 - lfo) >> 1)) >> 15);   /* even in dB, blended in by a */
    ge = (ge * FX_TREM_MK[d]) >> 12;
    return *tr = g + (int32_t)(((int64_t)(ge - g) * tw_amp) >> 15);
}
/* the tremolo with the amp law: fx_trem's sw == 1 path (its gain ramp and L / R sums, bit for bit) with these gains.
 * Its own function, so fx_trem's own loops compile as before */
__attribute__((noinline)) static void fx_trem_amp(const int32_t *m, int32_t *L, int32_t *R, uint32_t n, uint32_t inc)
{
    uint32_t sb;
#if FR_CHUNK
    if (FXC_1) tw_amp_block(TWP(FXP_TW_SHAPE), TWP(FXP_TW_DEPTH));
    for (sb = fxc_o; sb < fxc_e; sb += 32u) {
#else
    tw_amp_block(fx_p[FXP_TW_SHAPE], fx_p[FXP_TW_DEPTH]);
    for (sb = 0; sb < n; sb += 32u) {
#endif
        int32_t tr, tl = tw_amp_sub(tw_ph, &tr), gl = tw_gl, gr = tw_gr, dl = (tl - gl) >> 5, dr = (tr - gr) >> 5;
        const int32_t *mp = m + sb, *me = m + (sb + 32u < n ? sb + 32u : n);
        int32_t *lo = L + sb, *ro = R + sb;
        tw_ph += inc * 32u;
        while (mp < me) {
            int32_t x = *mp++;
            gl += dl; gr += dr;
            *lo++ += (int32_t)(((int64_t)x * gl) >> 15);
            *ro++ += (int32_t)(((int64_t)x * gr) >> 15);
        }
        tw_gl = tl; tw_gr = tr;
    }
}
/* noinline (0.9.5): with the filter out of app_audio and the drive / limiter loops slimmer, the allocator moved the
 * phaser's loop 77 -> 84 instructions a sample; the tremolo in its own function puts it at 78 (and the rest back) */
/* the wah's damping q (Q14: 9830 - RATE x 58, 0.6 .. 0.15), gliding (0.9.6, BUGHUNT #14: RATE 127 -> 0 under a chord
 * was a 203x click, the sweep a 2.1x zipper): 32 a sub-block (a detent, 58, in 2 sub-blocks; 0 -> 127 in 167 ms); the
 * wah silent (off, its blend at 0) or the output quiet for 2 blocks: RATE's own (the wah from off starts there) */
static int32_t wah_xw;                                   /* (below: the wah's blend) */
static int32_t wah_q RH_SP_SEC(".data.fx_wahq") = -1;
FR_RAM2 static __attribute__((noinline)) void fx_trem_k(const int32_t *m, int32_t *L, int32_t *R, uint32_t n, int32_t sw)
{
    int32_t depth = TWP(FXP_TW_DEPTH), rate = TWP(FXP_TW_RATE), qt = 9830 - rate * 58, wt[32];
    uint32_t inc = TW_SYNC ? TW_SYNC : FX_LFO_INC[rate], sb, j;
#if FR_CHUNK
    if (FXC_1 && sw == 2 && (wah_q < 0 || !wah_xw || fx_quiet_blocks >= 2u)) wah_q = qt;
    if (sw == 1 && TWP(FXP_TW_SHAPE) > 64) { FR_FAR2(fx_trem_amp)(m, L, R, n, inc); return; }
    for (sb = fxc_o; sb < fxc_e; sb += 32u) {
#else
    if (sw == 2 && (wah_q < 0 || !wah_xw || fx_quiet_blocks >= 2u)) wah_q = qt;
    if (sw == 1 && fx_p[FXP_TW_SHAPE] > 64) { FR_FAR2(fx_trem_amp)(m, L, R, n, inc); return; }   /* the amp law */
    for (sb = 0; sb < n; sb += 32u) {
#endif
        int32_t tl = 32768, tr = 32768, dl, dr, gl = tw_gl, gr = tw_gr, wgq = wah_g << 5, wgs = 0, wq = wah_q;
        if (sw == 1) {                                  /* tremolo: the LFO this sub-block */
            int32_t lfo = osc_sine(tw_ph), shp = TWP(FXP_TW_SHAPE);
            lfo = clampi((int32_t)(((int64_t)lfo * (32768 + 7 * 258 * shp)) >> 15), -32767, 32767);
            /* sine -> rounded square (x up to 8: 64-bit, 0.9.3: in 32 bits it overflowed above SHAPE 18) */
            if (TWP(FXP_TW_MODE) == 0) {                /* autopan: equal power around the centre */
                uint32_t th = (1u << 29) + (uint32_t)((depth * lfo) * 129);
                tl = (osc_sine(th + (1u << 30)) * 46341) >> 15;   /* sqrt2 cos(theta): unity at the centre */
                tr = (osc_sine(th) * 46341) >> 15;
                /* (2026-11-09: 0.9.9's equal-power law again. 2eba440e had capped each side at unity for a v127
                 * chord's +2.6 dB peak at DEPTH 127; with 0.9.10's output level the law's chord peak is +2.0 dB, the
                 * limiter idle (tools/fx_pristine.py pan 127), and the cap's corner at the centre had put the LFO's
                 * sidebands on every note: F05's off-harmonic energy +8 dB over 0.9.9's, tools/release_diff.py inh) */
            } else {                                     /* amplitude: down from full by depth */
                int32_t g = 32768 - (((depth * 258) * ((32767 - lfo) >> 1)) >> 15);
                tl = tr = (g * (254 + depth)) / 254;     /* the average dip, given back (0.6) */
            }
        }
        tw_ph += inc * 32u;
        if (sw == 2) {                                  /* the wah's make-up gain (0.9.3): the band-pass kept its peak,
                                                         * but where the chord sat against the band moved the level
                                                         * -14.6 .. +5.7 LU (high chords lost most); the output's slow
                                                         * envelope now follows the input's, so the wah only colours */
            /* 2026-10-24: the envelopes follow in 2.9 ms (up) / 11.6 ms (down) (they were 46 ms: a decaying high
             * note's level fell behind them, Rhodes C6 v60 RATE 127 -2.9 LU), the gain is smoothed by two poles of
             * 5.8 ms (2.9 ms at an onset: the input 4x over its 46 ms envelope) and ramped sample by sample (no
             * zipper), at most x32 (x8 cut a closed resonant wah on a high note: C7 RATE 127 -10 LU). Faster still
             * holds MARIMBA's top octave too, but only by boosting the strike (its peaks +7 dB) and pumping on low
             * chords: not taken. */
            int32_t ei = wah_ein, eo = wah_eout, tg = 4096, gs = wah_ein > 4 * wah_eslow ? 2 : 3;
            while (ei > 0x7FFFF || eo > 0x7FFFF) { ei >>= 1; eo >>= 1; }
            if (eo > 8) tg = clampi((ei << 12) / eo, 512, 131072);   /* x0.125 .. x32 */
            /* the make-up capped at twice the peaks' ratio (2026-11-08: a v127 note's attack +7 dB, a chord's +3.2 dB
             * on the limiter, tools/fx_pristine.py; now +1.6 at most). At x1 it held the peak but lost the level of a
             * soft high note under a closed resonant wah (C7 v40 RATE 127 -5.6 LU, tests/py/test_hil_limits.py); an
             * onset cap (no make-up while the input is 4x over its slow envelope) lost MARIMBA C5 -1.3: not kept */
            if (wah_pko > 8) { int32_t tp = (int32_t)(((int64_t)((wah_pki << 12) / wah_pko) * WAH_PKH) >> 12); tg = tg < tp ? tg : tp < 512 ? 512 : tp; }
            wah_g1 += (tg - wah_g1) >> gs;
            wah_g += (wah_g1 - wah_g) >> gs;
            wgs = wah_g - (wgq >> 5);                    /* the gain ramps over the sub-block: no zipper */
            if (wq != qt) wah_q = wq += clampi(qt - wq, -32, 32);
        }
        dl = (tl - gl) >> 5; dr = (tr - gr) >> 5;
        if (sw == 2 && gl == 32768 && gr == 32768) {    /* the wah, the tremolo's gains at unity (fx_wah_unity) */
            fx_wah_unity(m + sb, m + (sb + 32u < n ? sb + 32u : n), L + sb, R + sb, wgq, wgs, depth, wq);
            continue;                                    /* (tw_gl / tw_gr: 32768 already) */
        }
        if (sw == 0 && gl == 32768 && gr == 32768) {    /* TREM/WAH off, the gains settled: the loop below is
                                                         * L / R += x, bit for bit */
            const int32_t *mp = m + sb, *me = m + (sb + 32u < n ? sb + 32u : n);
            int32_t *lo = L + sb, *ro = R + sb;
            while (mp < me) { int32_t x = *mp++; *lo++ += x; *ro++ += x; }
            continue;
        }
        if (sw == 2) FR_FAR(wah_sub)(m + sb, (sb + 32u < n ? sb + 32u : n) - sb, wt, wgq, wgs, depth, wq);
        for (j = sb; j < sb + 32u && j < n; j++) {
            int32_t x = m[j];
            if (sw == 2) x = wt[j - sb];                 /* touch wah: envelope -> cutoff, RATE = resonance */
            gl += dl; gr += dr;
            L[j] += (int32_t)(((int64_t)x * gl) >> 15);
            R[j] += (int32_t)(((int64_t)x * gr) >> 15);
        }
        tw_gl = tl; tw_gr = tr;
    }
}
/* the wah switched on or off (0.9.6, the bug hunt: it switched from the plain signal to the filtered one in one sample,
 * with the filter's stale state): the wah runs while its share glides (xf_next), over the plain signal (the tremolo's
 * gains at unity, its output m); from rest it starts from a clean state and unity make-up. TREM <-> WAH (BUGHUNT #7's
 * other half: the tremolo's dip stepped out at once, 16.5x a held chord's d2): the other side of the blend is the
 * tremolo itself (tw_o, the last setting that was not the wah), into xf_d; the wah runs at unity gains (fx_wah_unity)
 * and its LFO phase is the tremolo's (the wah's pass does not move it) */
static int32_t wah_xw;
static uint8_t tw_o RH_SP_SEC(".bss.fx_two");
__attribute__((noinline)) static void fx_trem_x(const int32_t *m, int32_t *L, int32_t *R, uint32_t n, int32_t sw)
{
#if FR_CHUNK
    int32_t w1, gl = tw_gl, gr = tw_gr;                 /* (this chunk's start: the tremolo's gains and phase) */
    uint32_t ph = tw_ph;
    if (FXC_1 && !wah_xw) {
        wah_env = wah_bp = wah_lp = 0; wah_ein = wah_eout = wah_eslow = 0; wah_pi = wah_po = wah_pki = wah_pko = 0; wah_cr = -1;
        wah_g = wah_g1 = 4096;
    }
    w1 = xf_next(wah_xw, sw == 2, n);
    if (tw_o) tw_gl = tw_gr = 32768;
    FR_FAR2(fx_trem_k)(m, L, R, n, 2);
    if (!tw_o) xf_post_c(L, R, m, m, n, wah_xw, w1);
    else {
        memset(xf_d[0] + fxc_o, 0, (fxc_e - fxc_o) * sizeof xf_d[0][0]);
        memset(xf_d[1] + fxc_o, 0, (fxc_e - fxc_o) * sizeof xf_d[1][0]);
        tw_gl = gl; tw_gr = gr; tw_ph = ph;
        FR_FAR2(fx_trem_k)(m, xf_d[0], xf_d[1], n, 1);
        xf_post_c(L, R, xf_d[0], xf_d[1], n, wah_xw, w1);
        if (FXC_Z && w1 == 32768) tw_gl = tw_gr = 32768;
    }
    if (FXC_Z) wah_xw = w1;
#else
    int32_t w1, gl = tw_gl, gr = tw_gr;
    uint32_t ph = tw_ph;
    if (!wah_xw) {
        wah_env = wah_bp = wah_lp = 0; wah_ein = wah_eout = wah_eslow = 0; wah_pi = wah_po = wah_pki = wah_pko = 0; wah_cr = -1;
        wah_g = wah_g1 = 4096;
    }
    w1 = xf_next(wah_xw, sw == 2, n);   /* (never at rest here: the blend always runs) */
    if (tw_o) tw_gl = tw_gr = 32768;
    FR_FAR2(fx_trem_k)(m, L, R, n, 2);                           /* (L / R = the wah: fx_process clears them, the wah writes) */
    if (!tw_o) xf_post(L, R, m, m, n, wah_xw, w1);
    else {                                              /* the tremolo, from its own gains and phase */
        memset(xf_d, 0, sizeof xf_d);
        tw_gl = gl; tw_gr = gr; tw_ph = ph;
        FR_FAR2(fx_trem_k)(m, xf_d[0], xf_d[1], n, 1);
        xf_post(L, R, xf_d[0], xf_d[1], n, wah_xw, w1);
        if (w1 == 32768) tw_gl = tw_gr = 32768;         /* (the wah alone from here: its gains at unity) */
    }
    wah_xw = w1;
#endif
}
static void fx_trem(const int32_t *m, int32_t *L, int32_t *R, uint32_t n)
{
    int32_t sw;
#if FR_CHUNK
    if (FXC_1) {
        uint32_t i;
        for (i = 0; i < sizeof tw_lk / sizeof tw_lk[0]; i++) tw_lk[i] = fx_p[FXP_TW_SW + i];
        tw_lsync = fx_tw_sync_inc;
    }
#endif
    sw = TWP(FXP_TW_SW);
    if (sw != 2) tw_o = (uint8_t)(sw == 1);
    if (sw == 2 ? wah_xw == 32768 : !wah_xw) FR_FAR2(fx_trem_k)(m, L, R, n, sw);   /* at rest: as before */
    else fx_trem_x(m, L, R, n, sw);                     /* (the blend: out of app_audio) */
}

/* ---- PHASER: 4 first-order allpasses per side, the right one 30 degrees behind */
static uint32_t ph_ph;
static struct { int32_t x[2][4], y[2][4], fb[2], hp[2], ls[2]; } ph_st;   /* (one struct: one memset clears it) */
#define ph_x ph_st.x
#define ph_y ph_st.y
#define ph_fb ph_st.fb
#define ph_hp ph_st.hp
#define ph_ls ph_st.ls
static int32_t ph_cq = -1, ph_gq, ph_tq;                     /* the sweep's centre and the level, gliding (-1: not yet) */
static int32_t ph_dq, ph_fq;                            /* DEPTH's sweep width (Q8) and FDBK's gain, gliding (they
                                                         * stepped once a block: FDBK 0 <-> 127 13-20x a held one's d2,
                                                         * the bug hunt #16; F09 -> F01 12x) */
static int32_t ph_w;                                    /* the on / off crossfade's wet share (xf_next) */
static int32_t ph_ap[2];                                /* the sides' allpass coefficients the last sub-block ended on */
static uint8_t ph_apv;                                  /* (0: none yet, the phaser just started) */
static int32_t ph_coef(uint32_t ph, int32_t depth, int32_t c)
{
    int32_t q = (int32_t)(ph < 0x80000000u ? ph >> 16 : (0xFFFFFFFFu - ph) >> 16);   /* triangle 0..32767 */
    /* the sweep's centre: from DEPTH 64 up the middle of the range, as always; below 64 it moves up as the sweep
     * narrows, to the top at DEPTH 0 (the notches near 2 kHz and 11.6 kHz, above most of the Rhodes' body). Parked
     * in the middle, a narrow sweep was a fixed notch near 350 Hz and 2 kHz: the chord -4.3 LU, A4 -7.7 dB at DEPTH 0
     * (the parameter's default), the audit 2026-10-25 */
    int32_t qd = c + (((q - 16384) * depth) >> 15), i, f;   /* (depth: Q8) */
    qd = clampi(qd, 0, 32767);
    i = qd >> 10; f = qd & 1023;
    return FX_PH_A[i] + (((FX_PH_A[i + 1] - FX_PH_A[i]) * f) >> 10);
}
/* (0.9.5, the CPU: the same bits, fewer instructions; tools: an old / new harness over random settings and inputs)
 * PH_CL: clampi as max, then min (lo <= hi: the same value), two instructions (smax, smin) instead of a compare, a
 * branch and the bounds rebuilt in it. PH_AP: an allpass's (a * d + 8192) >> 14 as ((a * d >> 13) + 1) >> 1, the
 * same floor (|a| < 2^14, |d| < 2^22: a * d >> 13 fits int32), without the rounding constant's register pair.
 * FX_KEEP(v): v is "changed" here (an empty asm), so the compiler keeps it in a 32-bit register and multiplies
 * 32 x 32 -> 64 in one instruction (left alone, it widens a loop constant to 64 bits once: see FX_K32). */
static inline __attribute__((always_inline)) int32_t ph_cl(int32_t v, int32_t lo, int32_t hi) { v = v < lo ? lo : v; return v > hi ? hi : v; }
#define PH_CL(v, lo, hi) ph_cl(v, lo, hi)
#define PH_AP(a, d) (((int32_t)(((int64_t)(a) * (d)) >> 13) + 1) >> 1)
#ifdef DINGHY_HOST
#define FX_KEEP(v) ((void)(v))                          /* the host / the browser: no hint (the same bits) */
#else
#include "fm1_keep.h"                                   /* hal/: the empty asm (tools/build.py: no asm in src/) */
#define FX_KEEP(v) HAL_KEEP_REG(v)
#endif
/* one sub-block's settings: the centre and the level glide (a DEPTH step moved the centre a quarter of a table step
 * at once: a step in the allpasses' coefficient, 5x the LFO's own per sub-block, a zipper of 3.5x a static DEPTH's
 * largest jump): at most 32 (centre) and 4 (level, 0.1 %) a sub-block, the whole range in ~0.4 s; DEPTH's width and
 * FDBK too. Returns the mix gain; the shelf's depth into ksh, the sides' coefficients into a (out of fx_phaser:
 * one copy, less flash) */
__attribute__((noinline)) static int32_t ph_glide(int32_t ct, int32_t gt, int32_t dt, int32_t fbk, int32_t *ksh,
                                                  int32_t *a, int32_t *a0)
{
    ph_cq += PH_CL(ct - ph_cq, -32, 32);
    ph_gq += PH_CL(gt - ph_gq, -4, 4);
    ph_dq += PH_CL(dt - ph_dq, -64, 64);                /* (the whole range in ~0.37 s) */
    ph_fq += PH_CL(fbk - ph_fq, -64, 64);               /* (~0.26 s) */
    *ksh = 32768 - (23268 * 4096) / ph_gq;              /* the shelf: x 0.71 on the bass at the level 1 (9500) */
    a[0] = ph_coef(ph_ph, ph_dq, ph_cq);
    a[1] = ph_coef(ph_ph + 0x15555555u, ph_dq, ph_cq);  /* the right side 30 degrees behind (was 90: a mono sound
                                                         * turned very wide, heard as a jump in level, the user
                                                         * 2026-10-17) */
    /* the coefficients glide sample by sample from the last sub-block's (0.9.8 fxq-mod; they stepped every 32: images
     * of a tone at +-1378 Hz, -39 dB re a 3 kHz tone at SPEED 127, tools/fxq_metrics.py); held still, the same */
    a0[0] = ph_apv ? ph_ap[0] : a[0]; a0[1] = ph_apv ? ph_ap[1] : a[1];
    {   /* the peak trim (Q12, knots every 16 of DEPTH as PH_G, at the gliding DEPTH: no step): PH_G matches the chord's
         * loudness, but the comb's in-phase bands lifted the attack's peak +3.3 dB (a v127 chord on the limiter,
         * tools/fx_pristine.py, 2026-11-08); the trim holds a chord's peak at the phaser off's (+0.5 dB at most, a
         * single note's +2), DEPTH 0 by its RMS. In the gain, so the low shelf (ksh, from PH_G) keeps its shape: the
         * tone the same (here, once a sub-block: in fx_phaser it moved the sample loop's registers, +7 a sample) */
        static const int16_t PH_T[9] = {3814, 3907, 3567, 2659, 2940, 3008, 3058, 3024, 2952};
        int32_t di = ph_dq >> 12, df = ph_dq & 4095;
        int32_t tr = PH_T[di] + (((PH_T[di + 1 > 8 ? 8 : di + 1] - PH_T[di]) * df) >> 12);
        /* the trim glides 4 (0.008 dB) a sub-block, as the level: following DEPTH's glide it stepped up to 0.03 dB
         * every 32 samples, a zipper on a DEPTH sweep (tests/py/test_mix_levels.py, 2.1x the statics') */
        ph_tq = ph_apv ? ph_tq + PH_CL(tr - ph_tq, -4, 4) : tr;
        ph_ap[0] = a[0]; ph_ap[1] = a[1]; ph_apv = 1;
        return (int32_t)(((((int64_t)(22940 << 15) * ph_gq) >> 12) * ph_tq) >> 12);
    }
}
FX_RAM __attribute__((noinline)) static void fx_phaser(int32_t *L, int32_t *R, uint32_t n)   /* (in RAM, 0.9.6: the
                                                         * effects' block code out of the XIP cache, cpu_check) */
{
    int32_t depth = fx_p[FXP_PH_DEPTH], fbk = fx_p[FXP_PH_FDBK] * 180;
    /* the mix: 0.70 x (dry + allpasses): +3 dB at most where they are in phase, the notches cut (0.56, a cut-only
     * 50/50 mix, came out 2-5 LU quieter on the FM-1 and dropped the phaser presets). It was 0.707 x a depth law fitted on the FM-1 by LUFS (0.8): 0.81 at DEPTH 80, so a low note (the
     * notches above it) came out +4 LU, the bass +6 dB, and the feedback resonated on the bass: heard as a jump in
     * level when switched on (the user, 2026-10-17). The feedback now passes a DC block and the sides are 30 degrees
     * apart (they were 90: a mono sound turned very wide). */
    /* the level per DEPTH (Q12, knots every 16, the last at 127): the chord's loudness (LUFS) matched to the phaser
     * off at every DEPTH, within 0.1 LU (fitted on host renders; tests/py/test_mix_levels.py); the low shelf's depth follows it (ksh), so
     * the bass keeps its level too (C2 within +1.5 dB). The mix was a fixed 0.70: the chord -2.1 LU at DEPTH 64.
     * Refitted 2026-11-08 on the 0.9.10 Rhodes (with the centre law below): every knot within 0.11 LU */
    static const int16_t PH_G[9] = {2731, 2820, 3200, 5112, 5390, 4989, 4710, 4502, 4331};
    int32_t gt = PH_G[depth >> 4] + (((PH_G[(depth >> 4) + 1] - PH_G[depth >> 4]) * (depth & 15)) >> 4);
    /* the centre under DEPTH 64 rises 1.5x as fast as the sweep narrows, at the top from DEPTH 21 down (it was 1x, the
     * top at DEPTH 0: with the 0.9.10 Rhodes' brighter 1-3 kHz a high chord lost 3.3 dB at DEPTH 30, a low one gained
     * 0.9; now -0.8 / +0.8, test_manual_claims) */
    int32_t ct = depth < 64 ? 16384 + 384 * (64 - depth) : 16384;
    ct = ct > 32767 ? 32767 : ct;                       /* (DEPTH 0..21: 32767) */
    uint32_t inc = fx_ph_sync_inc ? fx_ph_sync_inc : FX_LFO_INC[fx_p[FXP_PH_SPEED]] >> 1, sb, s;
    int on = fx_p[FXP_PH_SW] != 0;
    int32_t w1;
#if FR_CHUNK
    if (!on && !ph_w) { if (FXC_1) { ph_cq = -1; ph_ph += inc * n; } return; }
    if (FXC_1) {
        if (!ph_w) FR_FAR(memset)(&ph_st, 0, sizeof ph_st);
        if (ph_cq < 0) { ph_cq = ct; ph_gq = gt; ph_dq = depth << 8; ph_fq = fbk; ph_apv = 0; }
    }
    w1 = FR_FAR(xf_pre_c)(ph_w, on, L, R, n, XF_STEP_CP);
    for (sb = fxc_o; sb < fxc_e; sb += 32u) {
#else
    if (!on && !ph_w) { ph_cq = -1; ph_ph += inc * n; return; }   /* off and faded out: the phaser rests, its LFO
                                                         * keeps time (as the filter's): switched on, it is where a phaser
                                                         * that ran all along is (it resumed where it stopped: chorus ->
                                                         * phaser +4.2 dB over both held renders, the control sweep) */
    if (!ph_w) {                                        /* switched on from rest: the allpasses start from 0 (their
                                                         * states were stale), under the fade in */
        FR_FAR(memset)(&ph_st, 0, sizeof ph_st);     /* (through a register: fx_phaser is in RAM, libc.c's memset
                                                         * in flash, beyond a call's reach when the compiler does not
                                                         * inline it: the one-core link failed so, 0.9.11) */
    }
    if (ph_cq < 0) { ph_cq = ct; ph_gq = gt; ph_dq = depth << 8; ph_fq = fbk; ph_apv = 0; }   /* (switched on: at once) */
    w1 = FR_FAR(xf_pre)(ph_w, on, L, R, n, XF_STEP_CP);
    for (sb = 0; sb < n; sb += 32u) {
#endif
        int32_t a[2], a0[2], ksh, pg = FR_FAR(ph_glide)(ct, gt, depth << 8, fbk, &ksh, a, a0);
        for (s = 0; s < 2u; s++) {                   /* the sides are independent: one at a time, the state in
                                                        * registers (the same arithmetic as per sample and side) */
            int32_t *io = s ? R : L, *pe, hp = ph_hp[s], g13 = pg >> 16, ls = ph_ls[s];
            int32_t kas, kq = a0[s] << 5, dk = a[s] - a0[s], kfb = ph_fq;
            int32_t x0 = ph_x[s][0], y0 = ph_y[s][0], y1 = ph_y[s][1], y2 = ph_y[s][2], y3 = ph_y[s][3];
            /* fewer registers (they spilled), the same values: an allpass's last input is the one before's last output
             * (x1 = y0, x2 = y1, x3 = y2, always: they start at 0 and take the same clamped value each sample), so
             * only x0 is kept; the feedback is clamp(y3 - hp) of the last sample, computed where it is used */
            pe = io + (sb + 32u < n ? sb + 32u : n);
            for (io += sb; io < pe; io++) {             /* at 4x the bus (it ran at a quarter: x >> 2 in, the allpasses'
                                                         * rounding x 4 out: a broadband floor ~55 dB under the note,
                                                         * heard as hiss / air and "more volume", TODO #7); the products
                                                         * 32 x 32 -> 64, one instruction each */
                int32_t x = *io, xs = PH_CL(x, -65535, 65535) << 2;   /* x 4 inside: 2 more bits */
                kq += dk; kas = kq >> 5;
                FX_KEEP(kfb);
                int32_t fb = PH_CL(y3 - (hp >> 6), -524287, 524287);  /* the feedback without its lows */
                int32_t u = xs + (int32_t)(((int64_t)fb * kfb) >> 15), t0, t1, t2, y;
                t0 = PH_CL(x0 + PH_AP(kas, u - y0), -1048575, 1048575); x0 = u;
                t1 = PH_CL(y0 + PH_AP(kas, t0 - y1), -1048575, 1048575); y0 = t0;
                t2 = PH_CL(y1 + PH_AP(kas, t1 - y2), -1048575, 1048575); y1 = t1;
                y = PH_CL(y2 + PH_AP(kas, t2 - y3), -1048575, 1048575); y2 = t2; y3 = y;
                hp += y - (hp >> 6);                    /* (~110 Hz: it resonated on the bass, C2 +4 LU with the
                                                         * phaser on; hp x 64, 0.9.8 fxq-mod: (y - hp) >> 6 rested up
                                                         * to 63 under y, a DC fed back that held the output off 0) */
                {   /* 0.70 x (dry + allpasses), / 4; then a low shelf: below ~150 Hz the allpasses are in phase
                     * with the dry, the sum +3 dB on the low notes (C2 / C3 heard ~25 % louder with the phaser on,
                     * Zwicker loudness, TODO #7): x 0.71 down there, the notches and the sweep above untouched */
                    int32_t o = (int32_t)(((int64_t)(xs + y) * g13) >> 16);
                    ls += (int32_t)(((int64_t)((o << 8) - ls) * 700) >> 15);   /* (ls x 256, 0.9.8 fxq-mod: kept at
                                                         * the bus' grain it rested up to 46 off o: 11 LSB of DC out after
                                                         * the sound stopped) */
                    *io = o - (int32_t)(((int64_t)ls * ksh + (1 << 22)) >> 23);
                }
            }
            ph_x[s][0] = x0; ph_x[s][1] = y0; ph_x[s][2] = y1; ph_x[s][3] = y2;
            ph_y[s][0] = y0; ph_y[s][1] = y1; ph_y[s][2] = y2; ph_y[s][3] = y3;
            ph_fb[s] = PH_CL(y3 - (hp >> 6), -524287, 524287); ph_hp[s] = hp; ph_ls[s] = ls;
        }
        ph_ph += inc * 32u;
    }
#if FR_CHUNK
    FR_FAR(xf_post_c)(L, R, xf_d[0], xf_d[1], n, ph_w, w1);
    if (FXC_Z) ph_w = w1;
#else
    FR_FAR(xf_post)(L, R, xf_d[0], xf_d[1], n, ph_w, w1);
    ph_w = w1;
#endif
}

/* ---- CHORUS: 7 ms +- 3.5 ms, two taps 90 degrees apart */
static uint32_t cp_ph;
/* the line, full precision (it was int16 of x / 2: a noise floor ~65 dB under the note, TODO #7), read through
 * cho_b = cho_buf + 1 with three guards for the 4-point reads: cho_b[-1] = cho_b[1023], cho_b[1024 .. 1025] =
 * cho_b[0 .. 1] (refreshed after each block's writes) */
static int32_t cho_buf[1027] POOL;
#define cho_b (cho_buf + 1)
static uint32_t cho_w;
#ifndef CHO_HPS
#define CHO_HPS 5                                       /* the wet's high-pass: a one-pole, 2^-5 a sample (~220 Hz) */
#endif
static int32_t cho_xw;                                  /* the on / off crossfade's wet share (xf_next) */
static uint8_t cho_fill, cho_run;                       /* blocks still to fill the line before the fade in; it runs */
static int32_t cho_swq;                                 /* the sweep's width x 256, gliding (CHO_SWS) */
static int32_t cho_ly[2];                               /* the output's low part per side (cho_tap_k) */
static int32_t cho_el = -1, cho_er, cho_km, cho_cg, cho_hl[2];   /* the taps' end positions (Q8; -1: none yet), the
                                                         * last sub-block's mix and make-up, the wet's high-pass */
#ifndef CHO_MKF
#define CHO_MKF 6600                                    /* the full mix's make-up above ~220 Hz, 1 + CHO_MKF / 32768
                                                         * (+1.6 dB; 2026-11-09: 3300 over the whole output, +0.83 dB, and
                                                         * a half-mix x 7 / 8, lifted the bass the comb never touches:
                                                         * C2 +0.7 .. +1.3 LUFS, +2.4 critical-band. Now on the comb's
                                                         * band only, refitted on the critical-band loudness: C2 within
                                                         * +-0.2 LUFS, the mean over engines, notes, velocities -0.2 .. -0.6 dB re the bypass;
                                                         * tools/fx_level_audit.py, tests/py/test_fx_ear_level.py; before:
                                                         * 1950, +0.50, the 0.9.10 Rhodes' chord -1.2 .. -1.5 LU) */
#endif
#ifndef CHO_HMK
#define CHO_HMK 10                                      /* the half-mix comb's make-up, x CHO_HMK / 8 (was 7) */
#endif
#define CHO_SWS 256                                     /* the sweep width's largest step a sub-block (fxq-mod: with
                                                         * the mix gliding, DEPTH 127 -> 0 moved the taps from 154
                                                         * samples out to the centre in 32 samples under a still-wet
                                                         * mix: a pitch dive, a click 17.3x the held renders'; now
                                                         * 1 sample a sub-block at most, ~3 % (the LFO's own at DEPTH
                                                         * 127 SPEED 64), the whole range in 112 ms) */
#define CHO_KMS 256                                     /* the mix's largest step a sub-block (0.9.8 fxq-mod: DEPTH
                                                         * 0 -> 127 faded the wet in over 32 samples, a click 7.9x the
                                                         * held renders'; now the whole range in ~46 ms) */
/* one side's settings for a sub-block: the tap's Q13 position v and its step e a sample, the mix (km) and the comb's
 * make-up (cg) at the sub-block's start and their steps (dk, dc: 0 = constant) */
typedef struct { uint32_t v, e; int32_t km, cg, dk, dc; } cho_k_t;
static cho_k_t cho_k[2][8];
/* the 4-point (cubic Hermite, Catmull-Rom) read between a[0] and a[1] (the next older sample), f the fraction in Q10
 * (0.9.8 fxq-mod; it was linear with an 8-bit fraction: as the taps swept, the wet's top end moved by up to 6.3 dB at
 * 15 kHz and the error put images of the tone at the fraction's rate, -20 dB re a 15 kHz tone at DEPTH 127). The
 * doubled coefficients keep the halves; |a| < 2^21: the products in 64 bits */
static inline __attribute__((always_inline)) int32_t cho_herm(const int32_t *a, int32_t f)
{
    int32_t c1 = a[1] - a[-1], c2 = 2 * a[-1] - 5 * a[0] + 4 * a[1] - a[2], c3 = a[2] - a[-1] + 3 * (a[0] - a[1]), t;
    t = c2 + (int32_t)(((int64_t)c3 * f) >> 10);
    t = c1 + (int32_t)(((int64_t)t * f) >> 10);
    return a[0] + (int32_t)(((int64_t)t * f + 1024) >> 11);
}
/* one side's tap over x[0 .. k): v the tap's Q13 position in the (backwards) line, stepping by e a sample; the mix
 * (km) and the comb's make-up (cg) step by dk / dc a sample in Q5 (ramp = 1: they move from the last sub-block's to
 * this one's over its 32 samples; 0: they are constant, the cheaper loop). Only the tap's part above ~220 Hz is mixed
 * in: (t - l) is high-passed (hl the low part), so the dry's bass is never cancelled by the 7 ms tap's comb (its first
 * notch sits near 71 Hz: C2 -10 dB at DEPTH 64, the audit 2026-10-25) */
static inline __attribute__((always_inline)) int32_t cho_tap_k(int32_t *x, uint32_t k, uint32_t v, uint32_t e,
                                                              int32_t km, int32_t cg, int32_t dk, int32_t dc,
                                                              int32_t hl, int32_t *lyp, const int ramp)
{
    int32_t *xe = x + k, ly = *lyp;
    if (ramp) { km <<= 5; cg <<= 5; }
    for (; x < xe; x++) {
        int32_t l = *x, t = cho_herm(cho_b + ((v >> 13) & 1023u), (int32_t)((v >> 3) & 1023u)), d;
        int32_t kq, cq;
        FX_KEEP(km);
        v += e;
        d = t - l;
        hl += d - (hl >> CHO_HPS);                      /* (|d| < 2^22: the low part x 2^CHO_HPS, its own state per
                                                         * side; 0.9.8 fxq-mod: kept at the bus' grain, (d - hl) >> 5
                                                         * rested up to 31 under d: 15 LSB of DC out after the sound) */
        if (ramp) { km += dk; cg += dc; kq = km >> 5; cq = cg >> 5; } else { kq = km; cq = cg; }
        l += (int32_t)(((int64_t)(d - (hl >> CHO_HPS)) * kq) >> 15);   /* (t - l) high-passed, x mix: 64-bit (it
                                                         * overflowed from |t - l| 131072) */
        ly += l - (ly >> CHO_HPS);                      /* (the output's part under ~220 Hz x 2^CHO_HPS: the make-up
                                                         * leaves it, 2026-11-09: the comb is only above, so the bass
                                                         * passed +0.7 .. +1.3 dB louder, C2 +2.4 critical-band) */
        *x = l + (int32_t)(((int64_t)(l - (ly >> CHO_HPS)) * cq) >> 15);   /* the comb's loss (above ~220 Hz) */
    }
    *lyp = ly;
    return hl;
}
/* one side over the block, its sub-blocks' settings in kb (in place; its own registers: inlined it spilled). Each side
 * reads only the line (written for the whole block first) and its own samples */
FR_RAM2 __attribute__((noinline)) static int32_t cho_side(int32_t *x, const cho_k_t *kb, uint32_t n, int32_t hl, int32_t *ly)
{
    uint32_t sb;
    for (sb = 0; sb < n; sb += 32u, kb++) {
        uint32_t k = n - sb < 32u ? n - sb : 32u;
        if (!kb->dk && !kb->dc) hl = cho_tap_k(x + sb, k, kb->v, kb->e, kb->km, kb->cg, 0, 0, hl, ly, 0);
        else hl = cho_tap_k(x + sb, k, kb->v, kb->e, kb->km, kb->cg, kb->dk, kb->dc, hl, ly, 1);   /* (DEPTH moving) */
    }
    return hl;
}
#if !FR_C1
/* the same with the mix and the make-up held over the whole block (DEPTH still: every block but a DEPTH move's), in
 * RAM (FX_RAM: a leaf); cho_side above, from flash, takes the blocks where they move (2026-11-09: the make-up's low
 * part, cho_ly, put .ram_text 28 B over with both loops in RAM) */
FX_RAM __attribute__((noinline)) static int32_t cho_side_k(int32_t *x, const cho_k_t *kb, uint32_t n, int32_t hl,
                                                           int32_t *ly)
{
    uint32_t sb;
    for (sb = 0; sb < n; sb += 32u, kb++)
        hl = cho_tap_k(x + sb, n - sb < 32u ? n - sb : 32u, kb->v, kb->e, kb->km, kb->cg, 0, 0, hl, ly, 0);
    return hl;
}
#endif
/* a tap's position (Q8) at the LFO's ph, swq the sweep's width x 256 (|osc x swq| < 2^31) */
__attribute__((noinline)) static int32_t cho_pos(uint32_t ph, int32_t swq)
{
    return 308 * 256 + ((osc_sine(ph) * swq) >> 15);
}
static void fx_chorus(int32_t *L, int32_t *R, uint32_t n)   /* (in fx_delay's function: see there) */
{
    int32_t depth = fx_p[FXP_CP_DEPTH], sw = 154 * depth / 127;
    uint32_t inc = fx_cp_sync_inc ? fx_cp_sync_inc : FX_LFO_INC[fx_p[FXP_CP_SPEED]] >> 1, sb;
    int on = fx_p[FXP_CP_SW] != 0;
    int32_t w1, mt = (16384 * (2 * depth > 127 ? 127 : 2 * depth)) / 127;
#if FR_CHUNK
    static int con;                                     /* (the block's: on, the line filled) */
    if (!on && !cho_xw) { cho_el = -1; cho_km = cho_cg = 0; cho_fill = 0; cho_run = 0; return; }
    if (FXC_1) {
        if (!cho_run) { memset(cho_buf, 0, sizeof cho_buf); cho_hl[0] = cho_hl[1] = cho_ly[0] = cho_ly[1] = 0; cho_fill = 2; cho_run = 1; cho_km = mt; }
        con = on && !cho_fill;
        if (cho_fill) cho_fill--;
        if (cho_el < 0) {
            cho_swq = sw << 8;
            cho_el = cho_pos(cp_ph, cho_swq); cho_er = cho_pos(cp_ph + 0x40000000u, cho_swq);
        }
    }
    w1 = xf_pre_c(cho_xw, con, L, R, n, XF_STEP_CP);
    {   /* the chunk's line first, then its taps (they read 153 .. 465 samples back: written in the chunks before) */
        uint32_t p = 0u - cho_w;
        const int32_t *l = L + fxc_o, *r = R + fxc_o, *le = L + fxc_e;
        for (; l < le; l++, r++) { cho_b[p & 1023u] = clampi(FX_HC(2, (*l + *r) >> 1, -1048575, 1048575), -1048575, 1048575); p--; }
        cho_w += fxc_e - fxc_o;
        cho_b[-1] = cho_b[1023]; cho_b[1024] = cho_b[0]; cho_b[1025] = cho_b[1];
    }
    for (sb = fxc_o; sb < fxc_e; sb += 32u) {
        int32_t el, er;
        cho_swq += clampi((sw << 8) - cho_swq, -CHO_SWS, CHO_SWS);
        el = cho_pos(cp_ph + inc * 32u, cho_swq); er = cho_pos(cp_ph + inc * 32u + 0x40000000u, cho_swq);
        int32_t sl = el - cho_el, sr = er - cho_er;
        int32_t mix = cho_km + clampi(mt - cho_km, -CHO_KMS, CHO_KMS), cg;
        cg = (mix * CHO_MKF >> 14) + (((mix * (16384 - mix)) >> 14) * CHO_HMK >> 3);   /* (as the one-chunk form: CHO_MKF) */
        uint32_t p = 0u - (cho_w - fxc_e + sb);
        cho_k_t *kl = &cho_k[0][sb >> 5], *kr = &cho_k[1][sb >> 5];
        kl->v = (p << 13) + ((uint32_t)cho_el << 5); kr->v = (p << 13) + ((uint32_t)cho_er << 5);
        kl->e = (uint32_t)sl - 8192u; kr->e = (uint32_t)sr - 8192u;
        kl->km = kr->km = cho_km; kl->cg = kr->cg = cho_cg;
        kl->dk = kr->dk = mix - cho_km; kl->dc = kr->dc = cg - cho_cg;
        cho_el = el; cho_er = er; cho_km = mix; cho_cg = cg;
        cp_ph += inc * 32u;
    }
    cho_hl[0] = FR_FAR(cho_side)(L + fxc_o, cho_k[0] + (fxc_o >> 5), fxc_e - fxc_o, cho_hl[0], &cho_ly[0]);
    cho_hl[1] = FR_FAR(cho_side)(R + fxc_o, cho_k[1] + (fxc_o >> 5), fxc_e - fxc_o, cho_hl[1], &cho_ly[1]);
    xf_post_c(L, R, xf_d[0], xf_d[1], n, cho_xw, w1);
    if (FXC_Z) cho_xw = w1;
#else
    if (!on && !cho_xw) { cho_el = -1; cho_km = cho_cg = 0; cho_fill = 0; cho_run = 0; return; }   /* off and faded out: rests (switched on
                                                         * again: the taps start where the LFO is, the mix from dry) */
    if (!cho_run) { memset(cho_buf, 0, sizeof cho_buf); cho_hl[0] = cho_hl[1] = cho_ly[0] = cho_ly[1] = 0; cho_fill = 2; cho_run = 1; cho_km = mt; }
                                                        /* (from rest: the line held what it held when it stopped;
                                                         * cleared, then two blocks dry while it fills: the taps read
                                                         * 153 .. 465 samples back; the mix at once: it is faded in) */
    w1 = xf_pre(cho_xw, on && !cho_fill, L, R, n, XF_STEP_CP);     /* (filling: cho_xw is 0, it stays 0) */
    if (cho_fill) cho_fill--;
    if (cho_el < 0) {                                   /* (the taps' start) */
        cho_swq = sw << 8;
        cho_el = cho_pos(cp_ph, cho_swq); cho_er = cho_pos(cp_ph + 0x40000000u, cho_swq);
    }
    {   /* the line for the whole block first (written backwards: sample w at -w), then each side's taps: a tap reads
         * 153 .. 465 samples back, all written by then and none overwritten (the ring holds 1024) */
        uint32_t p = 0u - cho_w;
        const int32_t *l = L, *r = R, *le = L + n;
        for (; l < le; l++, r++) { cho_b[p & 1023u] = clampi(FX_HC(2, (*l + *r) >> 1, -1048575, 1048575), -1048575, 1048575); p--; }
        cho_w += n;
        cho_b[-1] = cho_b[1023]; cho_b[1024] = cho_b[0]; cho_b[1025] = cho_b[1];
    }
    int32_t mv = 0;                                     /* (a sub-block's mix or make-up moves: cho_side) */
    for (sb = 0; sb < n; sb += 32u) {
        /* the taps glide sample by sample to the next sub-block's (they jumped once per 32 samples: a step in the
         * delay time, a zipper on the chorus' output of ~10x the signal's third difference, 2026-10-24); each sub-block
         * starts where the last one ended (it started from this DEPTH's position: each DEPTH step made the tap jump,
         * up to 1.2 samples, the audit 2026-10-25) */
        int32_t el, er;
        cho_swq += clampi((sw << 8) - cho_swq, -CHO_SWS, CHO_SWS);   /* (held: sw << 8, the same taps as before) */
        el = cho_pos(cp_ph + inc * 32u, cho_swq); er = cho_pos(cp_ph + inc * 32u + 0x40000000u, cho_swq);
        int32_t sl = el - cho_el, sr = er - cho_er;     /* per sample, in Q13 (x 32: the 32 steps add up exactly) */
        int32_t mix = cho_km + clampi(mt - cho_km, -CHO_KMS, CHO_KMS), cg;
        cg = (mix * CHO_MKF >> 14) + (((mix * (16384 - mix)) >> 14) * CHO_HMK >> 3);   /* + half-mix comb; the gain is
                                                         * 1 + cg / 32768 (cg < 7600: l * cg fits up to |l| 282000; l * the
                                                         * whole gain overflowed from |l| 61856: a hot chord, fuzz 2390;
                                                         * the largest, 7028 at mix 11472) */
        /* the tap I + F (Q13) behind the sub-block's first sample (w, at -w) sits at -w + I: one Q13 position per
         * tap, (-w << 13) + d, gives the index (its bits 13..22) and the fraction (bits 3..12) and steps by s - 8192
         * a sample */
        uint32_t p = 0u - (cho_w - n + sb);
        cho_k_t *kl = &cho_k[0][sb >> 5], *kr = &cho_k[1][sb >> 5];
        kl->v = (p << 13) + ((uint32_t)cho_el << 5); kr->v = (p << 13) + ((uint32_t)cho_er << 5);
        kl->e = (uint32_t)sl - 8192u; kr->e = (uint32_t)sr - 8192u;
        kl->km = kr->km = cho_km; kl->cg = kr->cg = cho_cg;
        kl->dk = kr->dk = mix - cho_km; kl->dc = kr->dc = cg - cho_cg;
        mv |= kl->dk | kl->dc;
        cho_el = el; cho_er = er; cho_km = mix; cho_cg = cg;
        cp_ph += inc * 32u;
    }
    if (mv) {                                           /* (DEPTH moving: the ramps, from flash) */
        cho_hl[0] = FR_FAR2(cho_side)(L, cho_k[0], n, cho_hl[0], &cho_ly[0]);
        cho_hl[1] = FR_FAR2(cho_side)(R, cho_k[1], n, cho_hl[1], &cho_ly[1]);
    } else {
        cho_hl[0] = FR_FAR(cho_side_k)(L, cho_k[0], n, cho_hl[0], &cho_ly[0]);
        cho_hl[1] = FR_FAR(cho_side_k)(R, cho_k[1], n, cho_hl[1], &cho_ly[1]);
    }
    xf_post(L, R, xf_d[0], xf_d[1], n, cho_xw, w1);
    cho_xw = w1;
#endif
}

#if C1_PRE_C0                                           /* (the front's code: its own chunk, fx_front) */
#define fxc_o fxf_o
#define fxc_e fxf_e
#define fxc_n fxf_n
#define fxc_mono fxf_mono
#define xf_pre_c xf_pre_cf
#define xf_blend_c xf_blend_cf
#define xf_post_c xf_post_cf
#endif
/* ---- COMPRESSOR (mono, before the drive): peak detector (ATTACK / RELEASE), soft knee of 6 dB, gain computed
 * in log2 (Q12) every 16 samples and ramped. AMOUNT moves the threshold -9 .. -39 dBFS and the ratio 1.5 .. 6
 * together; the make-up equals the reduction at a typical piano level (-26 dBFS): level-neutral. */
static int32_t cmp_env, cmp_g = 65536;
/* the detector's peak hold (2026-11-08): RELEASE starts CMP_HOLD samples after the last peak that reached the detector.
 * Released between a note's waveform peaks, the detector rippled at twice its f0 and the gain with it: an
 * intermodulation of v127 chords at -46 .. -56 dB under F01's compressor (the dry engine -76 .. -86; tools/dry_dist.py's
 * chords, tests/py/test_comp_clean.py); held 11.6 ms (a cycle down to 86 Hz; with the smoothing below the worst chord
 * -68.9 dB, SUIT's mid chord +12.2 over the dry engine's), the detector only rises within a note's cycle and the gain
 * moves at the hold's pace. The worst chord by the hold (2026-11-09): 256 -66.4, 384 -67.7, 448 -68.3, 512 -68.9,
 * 576 -69.4, 640 -68.9, 768 -66.9, 1024 -67.9 (512: the middle of the plateau); a longer hold holds a loud chord's
 * reduction longer: tools/quick.py's v127 chords 0.2 dB lower than at 256 (1024: 0.3). A faster RELEASE in its place
 * (x2: the level back) lost the cleanliness (-57.5) */
#ifndef CMP_HOLD
#define CMP_HOLD 512
#endif
static uint32_t cmp_ds = 0x9E3779B9u;                 /* the gain's dither (2026-11-09): the product cut to the
                                                        * output's LSB truncated, an error locked to the waveform: on a
                                                        * quiet high note (DYNO k93 v64, ~300 LSB) its 3rd / 5th
                                                        * harmonics, H3 -64.2 -> -59.2 dB re H1 with FX off (the bypass
                                                        * keeps the compressor). Now rounded over a uniform 1 LSB, the
                                                        * offsets from CMP_DTH (16 a sub-block from a random start: white,
                                                        * 1 load a sample): H3 -64.5. Only while the detector reads
                                                        * >= 128 LSB (-48 dBFS), else the cut as before, so tails reach
                                                        * exact zero as they did (release_diff's MARIMBA v40 key-up and
                                                        * decay cells; 32 left two moved). The gain loop 10 instructions a
                                                        * sample against 8 without (pi32v2, tools/drive_insns.py; a
                                                        * generator step a sample with a per-sample threshold was 18; one
                                                        * offset held over a sub-block, 9, put the noise low: FELT k33 v40
                                                        * inh over its ceiling on HQ) */
/* the compressor's dither values (uniform 0 .. 65535, a 1-LSB rounding offset in Q16): 80 from the generator
 * x = x * 1664525 + 1013904223 (x0 0x2545F491), its top 16 bits; each sub-block reads 16 of them from a random
 * offset 0..63 (fx_comp), white sample to sample and stationary across sub-blocks */
static const uint16_t CMP_DTH[80] = {
    58007, 36122, 7018, 39120, 23958, 24075, 19811, 56694, 23025, 38926, 58209, 26173,
    24440, 43151, 41004, 53198, 37105, 15033, 17105, 37310, 50309, 44380, 23346, 49682,
    2422, 38160, 15839, 61182, 53011, 61080, 27430, 21231, 8430, 58762, 64870, 59082,
    44109, 21294, 62122, 5748, 33504, 22949, 25971, 7058, 52914, 48972, 2262, 17043,
    60258, 61024, 31688, 40428, 39060, 48355, 18358, 60324, 14755, 24767, 40538, 45329,
    22170, 13354, 10954, 53474, 53858, 11851, 35283, 8030, 35390, 13339, 15749, 47340,
    21109, 42383, 12304, 7893, 33871, 51956, 6608, 24134};
static const uint16_t CMP_DTH0[16];                     /* (zeros: the sub-blocks under the threshold) */
static int32_t cmp_hd, cmp_gs;                         /* (cmp_gs: the reduction, its release smoothed, log2 Q12 x 16) */
#ifndef CMP_KRM
#define CMP_KRM 1
#endif
#ifndef CMP_GSH
#define CMP_GSH 8                                       /* the reduction's release: 2^-8 a 16-sample step (~93 ms) */
#endif
/* the reduction applied: more at once (ATTACK is the detector's), less through a one-pole (the detector's release
 * steps smoothed out of the gain). F01's v127 chords' intermodulation: -46 .. -56 dB before, -68 .. -79 now (the dry
 * engine -76 .. -86; with GSH 7 -63 .. -75, GSH 6 -57 .. -70) */
static int32_t cmp_gsh = CMP_GSH;                       /* (this block's shift: cmp_gsh_of) */
static inline int32_t cmp_gsm(int32_t gr)
{
    int32_t g16 = gr << 4;
    if (g16 >= cmp_gs) cmp_gs = g16; else cmp_gs += (g16 - cmp_gs) >> cmp_gsh;
    return cmp_gs >> 4;
}
/* the smoothing at most half the RELEASE's time constant (65536 / kr samples): a fast RELEASE stays fast (at a fixed
 * ~93 ms RELEASE 0 lagged a decaying note, its THRESH read 1.0 .. 1.5 dB low, tests/py/test_display_sound.py); the
 * presets' RELEASE 64 .. 80 keep CMP_GSH */
static int32_t cmp_gsh_of(int32_t kr)
{
    int32_t sh = CMP_GSH;
    while (sh > 0 && (kr << (sh + 5)) > 65536) sh--;
    return sh;
}
#define CMP_DET(a, hd) do { int32_t d_ = (a) - cmp_env;                                                           \
                            if (d_ >= 0) { cmp_env += (int32_t)(((int64_t)d_ * (d_ > (cmp_env >> CMP_SAT) ? ka   \
                                                     : kas)) >> 16); hd = CMP_HOLD; }                              \
                            else if (hd) hd--;                                                                     \
                            else cmp_env += (int32_t)(((int64_t)d_ * kr) >> 24); } while (0)   /* (kr: Q24) */
/* the program-dependent release (stage 2, 2026-11-10): the detector's release adapts to the playing. A release that
 * the next peak catches up again (the detector fell, then rose by less than 3.5 dB: a chord's beating, a low note's
 * cycle, a decay slower than RELEASE) halves the release speed, down to 1/8 of RELEASE's; a new strike (a rise of
 * more than 3.5 dB) gives RELEASE back at once, and without a catch the speed drifts back to RELEASE's (~90 ms). A
 * released detector caught again every few cycles was a gain sawtooth at the beat rate: COMP RAT 4:1 ATK 40 REL 48
 * (the default ATTACK and RELEASE) put the v127 mid chord's intermodulation at -43 dB (tools/dry_dist.py; the dry
 * engine -79). Per 16-sample sub-block, nothing per sample */
#ifndef CMP_PDR
#define CMP_PDR 3                                       /* the slowest release: RELEASE's speed / 2^3 */
#endif
#ifndef CMP_PDT
#define CMP_PDT 8                                       /* the drift back: 2^-8 a sub-block (~93 ms) */
#endif
#ifndef CMP_SAT
#define CMP_SAT 1                                       /* a rise of less than half the detector (+3.5 dB): ... */
#endif
#ifndef CMP_SAS
#define CMP_SAS 4                                       /* ... caught at ATTACK's speed / 16, when RELEASE is fast */
#endif
#ifndef CMP_SAK
#define CMP_SAK 10                                      /* (RELEASE's coefficient from here: 60 and under, <= 150 ms,
                                                         * fast enough to fall between a chord's beats; the presets'
                                                         * slower RELEASE (64 .. 80) catch as they did) */
#endif
static int32_t cmp_krq = -1;                            /* the release in use (Q24; < 0: RELEASE's, not adapted yet) */
static inline void cmp_adapt(int32_t kb, int32_t hd0, int32_t e0)
{                                                       /* (after a sub-block's detector: e0, hd0 its start) */
    int32_t k = cmp_krq;
    if (cmp_env - e0 > (e0 >> 1)) k = kb;               /* a new strike: RELEASE's own speed */
    else if (!hd0 && cmp_env > e0) { k -= k >> 1; if (k < (kb >> CMP_PDR)) k = kb >> CMP_PDR; }   /* caught again */
    else k += (kb - k) >> CMP_PDT;
    cmp_krq = k;
}
/* the body lift (stage 2): under steady compression the reduction relaxes by CMP_BETA of itself over ~190 ms
 * (cmp_bs follows the reduction up slowly, at once down): a strike gets the full ratio, the body that follows a
 * gentler one, so turning THRESH up brings the sustain up against the attack (fatness) instead of clamping it.
 * Smooth by construction (a one-pole on the reduction, per sub-block): no ripple, no new intermodulation; when the
 * reduction falls (a key-up, a decay) the relaxation follows it down at once, so a tail is never lifted over the
 * level it had */
#ifndef CMP_BETA
#define CMP_BETA 90                                     /* Q8: 0.35 of the steady reduction given back */
#endif
#ifndef CMP_BSH
#define CMP_BSH 9                                       /* 2^-9 a sub-block: ~186 ms */
#endif
static int32_t cmp_bs;                                  /* the steady reduction (log2 Q12 x 16) */
static inline int32_t cmp_body(int32_t gr, int32_t beta)
{
    int32_t g16 = gr << 4;
    if (g16 <= cmp_bs) cmp_bs = g16; else cmp_bs += (g16 - cmp_bs) >> CMP_BSH;
    return gr - (((cmp_bs >> 4) * beta) >> 8);
}
static int32_t cmp_amg;                                  /* the auto make-up as the gain uses it, Q4 log2 Q12 (cmp_give) */
static int32_t cmp_mk;                                   /* MAKEUP (log2 Q12) as the gain uses it: it glides to the
                                                          * knob's value, 1/16 of the way every 16 samples (5.8 ms),
                                                          * then exactly there; a step of the knob was a gain ramp of
                                                          * 16 samples (0 -> 127: +24 dB, the click 17x) */
static int32_t ilog2_q12(uint32_t x)                     /* log2(x), Q12; x > 0 (no clz: a binary search) */
{
    int32_t e = 0;
    if (x >= 1u << 16) { x >>= 16; e += 16; }
    if (x >= 1u << 8) { x >>= 8; e += 8; }
    if (x >= 1u << 4) { x >>= 4; e += 4; }
    if (x >= 1u << 2) { x >>= 2; e += 2; }
    if (x >= 1u << 1) { e += 1; }
    return e << 12;
}
static int32_t log2_q12(uint32_t x)
{
    int32_t e = ilog2_q12(x) >> 12;
    uint32_t m = e >= 8 ? x >> (e - 8) : x << (8 - e);      /* 256 .. 511 */
    return (e << 12) + FX_LOG2F[m & 255u];
}
static int32_t exp2_q16(int32_t g)                       /* 2^(g / 4096) in Q16; g in [-16, 4] octaves */
{
    int32_t ip = g >> 12, v = (int32_t)FX_EXP2F((g & 4095) >> 4);
    return ip >= 0 ? v << ip : ip > -16 ? v >> -ip : 0;
}
/* the compressor's own log2 / exp2, the tables interpolated (2026-11-08: log2_q12's 8-bit mantissa and exp2_q16's 256
 * steps an octave moved the gain in 0.023 dB steps as a note decayed, a staircase heard as intermodulation, ~-60 dB) */
static int32_t cmp_log2(uint32_t x)                      /* log2(x), Q12; x > 0 */
{
    int32_t e = ilog2_q12(x) >> 12;
    uint32_t mm = e >= 16 ? x >> (e - 16) : x << (16 - e), i = (mm >> 8) & 255u, f = mm & 255u;   /* 65536 .. 131071 */
    int32_t a = FX_LOG2F[i], b = i < 255u ? FX_LOG2F[i + 1u] : 4096;
    return (e << 12) + a + (((b - a) * (int32_t)f) >> 8);
}
static int32_t cmp_exp2(int32_t g)                       /* 2^(g / 4096) in Q16; g in [-16, 4] octaves */
{
    int32_t ip = g >> 12, i = (g & 4095) >> 4, f = g & 15;
    int32_t a = (int32_t)FX_EXP2F(i), b = i < 255 ? (int32_t)FX_EXP2F(i + 1) : 131072, v = a + (((b - a) * f) >> 4);
    return ip >= 0 ? v << ip : ip > -16 ? v >> -ip : 0;
}
static int32_t cmp_xw;                                   /* the on / off crossfade's wet share (xf_next) */
/* the gain reduction (log2 Q12) at the detector's level env: the soft knee of 6 dB around thr */
static int32_t cmp_gr_at(int32_t env, int32_t thr, int32_t slope)
{
    int32_t lvl = env > 256 ? cmp_log2((uint32_t)env) - 23 * 4096 : -16 * 4096;   /* re 32768 << 8 */
    int32_t over = lvl - thr;
    if (over <= -2048) return 0;                                    /* the knee: +-3 dB around the threshold */
    if (over < 2048) return (int32_t)(((int64_t)slope * (over + 2048) * (over + 2048)) >> 25);
    return (slope * over) >> 12;
}
__attribute__((noinline)) static void cmp_from(const int32_t *m, uint32_t n, int32_t mk, int32_t amk, int32_t thr,
                                               int32_t slope)
{                                                        /* the detector and the gain settled at this block's peak */
    int32_t pk = 0;
    uint32_t j;
    for (j = 0; j < n; j++) if (iabs(m[j]) > pk) pk = iabs(m[j]);
    cmp_env = pk << 8; cmp_hd = CMP_HOLD;
    cmp_mk = mk; cmp_amg = amk << 4;
    cmp_gs = cmp_gr_at(cmp_env, thr, slope) << 4;
    cmp_g = cmp_exp2(mk - (cmp_gs >> 4) + (amk < (cmp_gs >> 4) ? amk : (cmp_gs >> 4)));
    cmp_krq = -1; cmp_bs = 0;
}
/* the auto make-up (stage 2, 2026-11-10): THRESH and RATIO bring their own make-up, so turning THRESH up keeps the
 * level and adds density: the critical-band loudness (binaural, tools/cb_loud.py) of C2 / C4 / C6 at v40 / 80 / 127,
 * C5 v100 and three chords, averaged, with the compressor on equals the bypass' (build: the fit over THRESH 40 .. 127
 * x RATIO 2:1 / 4:1 / 20:1 x ATTACK 40 / 100 at MKUP 0; the reduction per unit of slope, log2 Q12, linear between
 * these THRESH values). None up to THRESH 56 (-17.6 dB), where every factory preset sits: their make-up as it was.
 * MAKEUP is a trim on top; the sum at most +24 dB */
static const int16_t CMP_SLOPE[8] = {1365, 2048, 2731, 3072, 3413, 3584, 3686, 3891};   /* 1 - 1/R, Q12 */
static void cmp_auto(void)                               /* (main loop: fx_set; the ISR reads fx_cmp_amk / fx_cmp_beta) */
{
    static const int16_t AT[6] = {56, 64, 80, 96, 112, 127}, AQ[6] = {0, 405, 1065, 2152, 3672, 5339};
    int32_t t = fx_p[FXP_CMP_AMT], i = 1, q = 0;
    if (t > 56) {
        while (t > AT[i]) i++;
        q = AQ[i - 1] + (AQ[i] - AQ[i - 1]) * (t - AT[i - 1]) / (AT[i] - AT[i - 1]);
    }
    fx_cmp_amk = (q * CMP_SLOPE[fx_p[FXP_CMP_RATIO] & 7]) >> 12;
    fx_cmp_beta = t <= 56 ? 0 : t >= 80 ? CMP_BETA : CMP_BETA * (t - 56) / 24;   /* the body lift fades in with it */
}
/* the auto make-up never past the reduction (stage 2, the coordinator 2026-11-10): it gives back at most what the
 * compressor takes at that moment, so the gain over MAKEUP is never above 1 and no peak rises over the bypass (a slow
 * ATTACK let a v127 chord's strike through under the full auto make-up: +3.0 dB at THRESH -40, 20:1, ATTACK 100).
 * What it gives back: min(auto make-up, reduction). The auto make-up itself follows THRESH / RATIO down at the
 * reduction's own smoothing (cmp_gsh), up at once: THRESH swept from -40 to 0 dB dropped it at once while the
 * reduction smoothed away, a 6.3 dB dip (tools/control_sweep.py comp THRESH) */
static inline int32_t cmp_give(int32_t amk, int32_t gr)
{
    int32_t a16 = amk << 4, a;
    if (a16 >= cmp_amg) cmp_amg = a16; else cmp_amg += (a16 - cmp_amg) >> cmp_gsh;
    a = cmp_amg >> 4;
    return a < gr ? a : gr;
}
static inline int32_t cmp_glide(int32_t mk)              /* cmp_mk one sub-block closer to mk */
{
    int32_t d = mk - cmp_mk;
    cmp_mk += (d > 15 || d < -15) ? d >> 4 : d;
    return cmp_mk;
}
#if FR_CHUNK
static int32_t cmp_pkc;                                  /* (fx_comp: a switch-on block's input peak so far) */
static uint8_t cmp_redo;                                 /* (fx_comp: a switch-on block's detector, again at its end) */
#endif
static void fx_comp(int32_t *m, uint32_t n)
{
    /* the four knobs (0.8): THRESHOLD 0 .. -40 dBFS, RATIO 1.5:1 .. 20:1, ATTACK, MAKEUP 0 .. +24 dB; RELEASE CC 109 */
    int32_t ka = (int32_t)FX_CMP_ATK[fx_p[FXP_CMP_ATK]], kr16 = (int32_t)FX_CMP_REL[fx_p[FXP_CMP_REL]] * CMP_KRM;
    int32_t kb = kr16 << 8, kr = kb;                                  /* RELEASE in Q24; kr: the detector's (adapted) */
    int32_t kas = kr16 >= CMP_SAK ? ka >> CMP_SAS : ka, beta = fx_cmp_beta;   /* kas: a small rise's attack */
    int32_t thr = -((fx_p[FXP_CMP_AMT] * 27434) >> 7) - FX_ENG_DT;   /* log2 Q12 re full scale: 0 .. -6.64 (-40 dB);
                                                        * the bars' detector reads them 3 dB up (bars.h BAR_FX_DT: their
                                                        * SND3 -3 dB is a level, THRESH acts as on 0.9.11) */
    int32_t slope = CMP_SLOPE[fx_p[FXP_CMP_RATIO] & 7];
    int32_t amk = fx_cmp_amk;
    int32_t mk = (fx_p[FXP_CMP_GAIN] * 16461) >> 7;                 /* MAKEUP, log2 Q12 (the auto make-up: cmp_give) */
    if (amk > 16461 - mk) amk = 16461 - mk;                         /* (MAKEUP + the auto make-up: at most +24 dB) */
    int on = fx_p[FXP_CMP_SW] != 0;
    cmp_gsh = cmp_gsh_of(kr16);
    int32_t w1;
    uint32_t sb, j;
#if FR_CHUNK
    if (!on && !cmp_xw) { fx_cmp_gr = 0; return; }
    if (!cmp_xw && FXC_1) {                           /* switched on from rest: the detector from the first chunk's
                                                       * peak (one core: the block's; its later samples are not
                                                       * rendered yet), run again over the whole block at its end
                                                       * (below); the block whole (one chunk): its own, as one core */
        cmp_redo = !FXC_Z;
        cmp_pkc = 0;
#ifdef C1_EST_LOG
        printf("C1EST cmp %u\n", c1_est_blk);
#endif
    }
    if (cmp_redo || (!cmp_xw && FXC_1)) {             /* (the switch-on block's input peak so far, before the gain) */
        int32_t p0 = cmp_pkc;
        for (j = fxc_o; j < fxc_e; j++) if (iabs(m[j]) > cmp_pkc) cmp_pkc = iabs(m[j]);
        if (FXC_1) {
            cmp_env = cmp_pkc << 8; cmp_hd = CMP_HOLD;
            cmp_krq = -1; cmp_bs = 0;
            cmp_mk = mk; cmp_amg = amk << 4;
            cmp_gs = cmp_gr_at(cmp_env, thr, slope) << 4;
            cmp_g = cmp_exp2(mk - (cmp_gs >> 4) + cmp_give(amk, cmp_gs >> 4));
        } else if (cmp_pkc > p0) {                    /* a higher peak in a later chunk: the detector run again from
                                                       * it over the block so far (closer to one core's start from the
                                                       * block's peak); the gain ramps to it over the next 16 samples */
            int32_t hd = CMP_HOLD;
            cmp_env = cmp_pkc << 8;
            for (j = 0; j < fxc_o; j++) CMP_DET(iabs(fxc_mono[j]) << 8, hd);
            cmp_hd = hd;
        }
    }
    if (cmp_krq < 0) cmp_krq = kb;                    /* (RELEASE's, from rest) */
    w1 = xf_pre_c(cmp_xw, on, m, 0, n, XF_STEP);
    for (sb = fxc_o; sb < fxc_e; sb += 16u) {
        int32_t g0 = cmp_g, g1, gr, step, hd = cmp_hd, e0 = cmp_env;
        const uint16_t *dt;
        kr = cmp_krq;
        for (j = sb; j < sb + 16u; j++) CMP_DET(iabs(m[j]) << 8, hd);
        cmp_adapt(kb, cmp_hd, e0);
        cmp_hd = hd;
        gr = cmp_body(cmp_gsm(cmp_gr_at(cmp_env, thr, slope)), beta);
        fx_cmp_gr = gr;
        g1 = cmp_exp2(cmp_glide(mk) - gr + cmp_give(amk, gr));
        cmp_ds = cmp_ds * 1664525u + 1013904223u;
        dt = cmp_env >= (128 << 8) ? CMP_DTH + (cmp_ds >> 26) : CMP_DTH0;
        step = (g1 - g0) / 16;
        for (j = sb; j < sb + 16u; j++) {
            g0 += step;
            m[j] = (int32_t)(((int64_t)m[j] * g0 + dt[j - sb]) >> 16);
        }
        cmp_g = g1;
    }
    xf_post_c(m, 0, xf_d[0], 0, n, cmp_xw, w1);
    if (FXC_Z && cmp_redo) {                          /* the switch-on block's end: the detector and the gain run again
                                                       * over the whole block's input (the dry voices: COMP is first)
                                                       * from its own peak, as one core ran them: from the next block's
                                                       * second sub-block on COMP is one core's again; the estimate is
                                                       * heard in this block alone, under the crossfade's first eighth
                                                       * (25 ms windows: build/c1sub/cmpwin.py, tests/py/test_c1_subblock.py) */
        int32_t pk = cmp_pkc, gr = 0, hd = CMP_HOLD;
        cmp_redo = 0;                                 /* (exact from the next block's second sub-block on) */
        cmp_env = pk << 8;
        kr = kb;
        for (sb = 0; sb < n; sb += 16u) {
            for (j = sb; j < sb + 16u; j++) CMP_DET(iabs(fxc_mono[j]) << 8, hd);
            gr = cmp_gr_at(cmp_env, thr, slope);
        }
        cmp_hd = hd;
        fx_cmp_gr = gr;                               /* (cmp_g kept: the next block's first 16 samples ramp from the
                                                       * gain this one ended on to one core's, then it is one core's) */
    }
    if (FXC_Z) { cmp_xw = w1; if (!w1) fx_cmp_gr = 0; }
#else
    if (!on && !cmp_xw) { fx_cmp_gr = 0; return; }
    if (!cmp_xw) {                                    /* switched on from rest: the detector from this block's peak,
                                                       * the gain settled there (they were whatever the last use left:
                                                       * the bug hunt, 2026-10-25), under the 46 ms crossfade */
        cmp_from(m, n, mk, amk, thr, slope);
    }
    if (cmp_krq < 0) cmp_krq = kb;                    /* (RELEASE's, from rest) */
    w1 = xf_pre(cmp_xw, on, m, 0, n, XF_STEP);               /* on / off: a crossfade, the compressor running (off was a
                                                       * gain step to unity in one sample, on one over 16 samples) */
    for (sb = 0; sb < n; sb += 16u) {
        int32_t g0 = cmp_g, g1, gr, step, hd = cmp_hd, e0 = cmp_env;
        const uint16_t *dt;
        kr = cmp_krq;
        for (j = sb; j < sb + 16u && j < n; j++) CMP_DET(iabs(m[j]) << 8, hd);   /* detector: |x| in Q8 */
        cmp_adapt(kb, cmp_hd, e0);
        cmp_hd = hd;
        gr = cmp_body(cmp_gsm(cmp_gr_at(cmp_env, thr, slope)), beta);
        fx_cmp_gr = gr;
        g1 = cmp_exp2(cmp_glide(mk) - gr + cmp_give(amk, gr));
        cmp_ds = cmp_ds * 1664525u + 1013904223u;
        dt = cmp_env >= (128 << 8) ? CMP_DTH + (cmp_ds >> 26) : CMP_DTH0;
        step = (g1 - g0) / 16;
        for (j = sb; j < sb + 16u && j < n; j++) {
            g0 += step;
            m[j] = (int32_t)(((int64_t)m[j] * g0 + dt[j - sb]) >> 16);
        }
        cmp_g = g1;
    }
    xf_post(m, 0, xf_d[0], 0, n, cmp_xw, w1);
    cmp_xw = w1;
    if (!w1) fx_cmp_gr = 0;
#endif
}

#if C1_PRE_C0                                           /* (the front's code ends) */
#undef fxc_o
#undef fxc_e
#undef fxc_n
#undef fxc_mono
#undef xf_pre_c
#undef xf_blend_c
#undef xf_post_c
#endif
/* ---- D.DELAY / A.DELAY: one line of 1.486 s (int16 at half level) */
#define DLY_LEN 65536u
static int16_t dly_buf[DLY_LEN] POOL;
static uint32_t dly_w, dly_wow, dly_flt;
static int32_t dly_d = 4410 << 8, dly_lp, dly_hp, dly_dg = 32768, dly_sg;   /* dly_sg: the send's stereo make-up, log2 Q12 */
/* the dry's glide to its target dgt (Q15): 1/512 a sample, as before, and the last 511 one LSB a sample: the old
 * (dgt - dg) >> 9 stopped up to 511 short rising (x 0.98441, -0.137 dB: DEPTH 0 under the bypass after any take, for
 * good; 2026-11-10, tests/py/test_dly_depth0.py); falling it reached dgt already (the shift rounds down) */
/* MIX's dry (0.9.13, as Textura's MIX): 0 .. 64 the dry whole (the echo rises: FX_DLY_WET), 64 .. 127 the dry falls to
 * nothing (the echo whole); Q15. It was 32768 - MIX^2 (-0.7 dB at 50, -5.9 dB at 127) */
#define DLY_DRY(v) ((v) <= 64 ? 32768 : ((127 - (v)) * 32768 + 31) / 63)
#define DLY_DG_STEP(dg, dgt) do { int32_t e_ = (dgt) - (dg); (dg) += (e_ >> 9) + (e_ > 0 && e_ < 512); } while (0)
static int32_t dly_sgk = 65536;                 /* the make-up (Q16) the last block ended on: each block ramps from it */
static int32_t dly_fbk = -1;                    /* FDBK's feedback gain the last block ended on (-1: none yet): DIG / ANA
                                                 * ramp from it over the block, as the echo's gain (a step once a block
                                                 * stepped the loop's gain: a zipper one delay time later, 2.4-3.1x) */
static int32_t dly_wk;                          /* the echo's gain (MIX: FX_DLY_WET) the last block ended on: each block
                                                 * ramps from it to the new one, sample by sample (a step once per
                                                 * block put a small step into the echoes at each MIX step; the
                                                 * audit, 2026-10-25: 1.9-3.3x a static MIX's largest jump) */
/* the delay's 4-point read (0.9.8 fxq-mod; ANA, TAPE and the crossfades, DIG's whole-sample taps as before): the cubic
 * Hermite (Catmull-Rom) between x0 (the tap) and x1 (the next older row), f the fraction (Q8), returned x 2 (the
 * line holds half level), rounded. Linear, the swept fraction (wow, flutter) put images of a tone at the fraction's
 * rate, -26 dB re a 10 kHz tone on ANA (tools/fxq_metrics.py), and dulled each repeat's top by up to 2.4 dB at 10 kHz.
 * At f = 0 it is 2 x0 exactly (the linear read's). 32-bit products: |x| <= 2^15 (an int16 line) */
/* (fxq-rev plans an int32 delay line: then these products need 64 bits, or the line's values a shift first; the
 * assert stops the build until that is decided at the merge) */
_Static_assert(sizeof dly_buf[0] == 2, "dly_h4: its 32-bit products hold for an int16 line only");
static inline __attribute__((always_inline)) int32_t dly_h4(int32_t xm1, int32_t x0, int32_t x1, int32_t x2, int32_t f)
{
    int32_t c1 = x1 - xm1, c2 = 2 * xm1 - 5 * x0 + 4 * x1 - x2, c3 = x2 - xm1 + 3 * (x0 - x1), t;
    t = c2 + ((c3 * f) >> 8);
    t = c1 + ((t * f) >> 8);
    return 2 * x0 + ((t * f + 128) >> 8);
}
#define DLY_AT(i, k) dly_buf[((i) + (uint32_t)(k)) & (DLY_LEN - 1u)]
/* the tap at row i (lookback lb = w - i) and fraction f: from the whole line, or (c <= DLY_LEN: the developer reset's
 * clean span) with the rows behind the clean span read as 0 (a row at lookback L is clean when L - 1 < c) */
#define DLY_H4(i, f) dly_h4(DLY_AT(i, 1), dly_buf[i], DLY_AT(i, -1), DLY_AT(i, -2), f)
#define DLY_CL(lb, k, c) ((((lb) + (uint32_t)(k) - 1u) & (DLY_LEN - 1u)) < (c))
#define DLY_H4C(i, lb, c, f) dly_h4(DLY_CL(lb, -1, c) ? DLY_AT(i, 1) : 0, DLY_CL(lb, 0, c) ? dly_buf[i] : 0,        \
                                    DLY_CL(lb, 1, c) ? DLY_AT(i, -1) : 0, DLY_CL(lb, 2, c) ? DLY_AT(i, -2) : 0, f)
/* the per-sample step (Q8) of a ramp from a to b over n samples: 0 when they are equal (the old gain, bit for bit) */
__attribute__((noinline)) static int32_t dly_wstep(int32_t a, int32_t b, uint32_t n)   /* (one copy: less flash) */
{
    return a == b || !n ? 0 : ((b - a) << 8) / (int32_t)n;
}
#define DLY_WSTEP(a, b, n) dly_wstep(a, b, n)
/* the send switched (0.9.5): a block with the send off ends with the make-up at 0, so the send's first block ramps it
 * up from 0, and the block after the EFFECT goes OFF runs the old EFFECT once more with the make-up ramped down to 0
 * (dly_son: the EFFECT the last block asked for). The send was cut at a block edge: its step came back one delay time
 * later as a kink in the echo (2.7x a steady echo's second difference on a TAPE -> OFF switch, under chords) */
static uint8_t dly_son;
/* the developer reset (CC 10) empties the line over ~16 blocks instead of one 128 KB memset in one block (that block took
 * ~5 ms of the 5.8: USB packets lost): while dly_rst, [dly_rb, dly_w) is clean (cleared or written since the reset), the
 * reads behind dly_rb return 0 (what the cleared line held), and each block clears DLY_CLR more below dly_rb */
#define DLY_CLR 4096u
/* (a section of their own, as engine.c's ring: kept out of the compiler's global merge) */
#ifdef DINGHY_HOST
#define FX_OWN_SECTION
#else
#define FX_OWN_SECTION __attribute__((unused))
#endif
static int32_t dly_dt[256] POOL;               /* the tape's delay time per sample of the block (Q8) */
static uint32_t dly_rb FX_OWN_SECTION;
static uint8_t dly_rst FX_OWN_SECTION;
/* the send per sample, (L + R) / 2 times the make-up: the make-up's energy pass keeps the sum, dly_ramp scales it (only
 * while the make-up moves or is not 1: with L == R it is exactly 1 and the pass is skipped), the sample loops read it
 * (0.9.5: the ramp and the sum were in every loop, every block). With the send off it is stale and masked to 0. */
static int32_t dly_m[256] POOL;
/* the make-up ramp over n sends, from the last block's dly_sgk to sg16 (Q24 steps, |sg16 - dly_sgk| <= 65536: << 8
 * fits): the arithmetic the sample loops had; x 65536 all along (dly_sgk = sg16 = 65536) is x 1, skipped */
FX_RAM __attribute__((noinline)) static void dly_ramp(int32_t *m, uint32_t n, int32_t sg16)
{
    int32_t kq = dly_sgk << 8, dk = n ? ((sg16 - dly_sgk) << 8) / (int32_t)n : 0;
    uint32_t j;
    if (kq == 65536 << 8 && !dk) return;
    for (j = 0; j < n; j++) {
        kq += dk;
        m[j] = (int32_t)(((int64_t)m[j] * (kq >> 8)) >> 16);
    }
}
#if FR_OWN                                      /* the plugin's own-code build: the delay's two sample loops (dly_loop, dly_loop_kb) from dly_own.c */
#define DLY_OWN_PART 1
#include "dly_own.c"
#undef DLY_OWN_PART
#else
#define FEL_PART 1
#include "fx_fel.c"
#undef FEL_PART
#endif
static uint32_t dly_clrn = DLY_CLR;            /* the clearing's share a block: DLY_CLR (CC 10), DLY_CLR / 4 (a tail's end) */
#if FR_OWN
static uint32_t dly_qz = 0u;                    /* with the send off: how many samples in a row the line took a value of -1, 0 or 1 */
#else
static uint32_t dly_qz;                         /* the send off: samples in a row the line was written within +-1 of 0 */
#endif
static uint8_t dly_lc = 1;                      /* the line is clean (all 0, or being cleared: dly_rst) */
static int32_t dly_xm RH_SP_SEC(".bss.fx_dlyxm");   /* ANA's share in that crossfade (Q15, dly_tape.c dly_fade) */
/* dly_xo: DIG <-> ANA with echoes ringing (0.9.6, BUGHUNT #17: the tone, the softclip and the wow switched in one
 * sample, ANA -> DIG 14x a ringing echo's d2): dly_fade crossfades the two (tape 2 / 3: what ANA adds glides in or out
 * over 46 ms); 1 while it runs. dly_sil: samples since the send last carried sound (up to DLY_LEN: the line holds none
 * of it): ANA's capped slew (#3) while the line holds sound */
static uint8_t dly_xo RH_SP_SEC(".bss.fx_dlyxo");
static uint32_t dly_sil RH_SP_SEC(".data.fx_dlysil") = DLY_LEN;
static uint8_t dly_ana;                         /* the old loops last ran ANA: its tail (OFF) runs ANA's loop (0.9.5: the
                                                 * DIG loop took over at OFF, its tone and the softclip changed at once:
                                                 * a kink in the echo one delay time later, 24x a steady one's) */
#if !FR_OWN
#define FEL_PART 2
#include "fx_fel.c"
#undef FEL_PART
#endif
__attribute__((noinline)) static void dly_clear_step(void)   /* one block's share of the reset's clearing */
{
    uint32_t c = dly_w - dly_rb, k, p;
    if (c >= DLY_LEN) { dly_rst = 0; return; }
    k = DLY_LEN - c < dly_clrn ? DLY_LEN - c : dly_clrn;
    p = (dly_rb - k) & (DLY_LEN - 1u);
    if (p + k <= DLY_LEN) memset(dly_buf + p, 0, k * sizeof dly_buf[0]);
    else { memset(dly_buf + p, 0, (DLY_LEN - p) * sizeof dly_buf[0]); memset(dly_buf, 0, (p + k - DLY_LEN) * sizeof dly_buf[0]); }
    dly_rb -= k;
    if (dly_w - dly_rb >= DLY_LEN) dly_rst = 0;
}
/* the tail (the send off) is over once the line was written ~0 over the whole delay and two blocks more: every read
 * from then on is ~0; the line's older part still holds what it held a ring (1.49 s) before, so the quiet path below
 * clears it (dly_lc, through dly_rst: the reads behind the cleared span return 0 at once). 0.9.5: the test was |lp| < 2
 * at a block's end, which a ringing tail crossing 0 there passed: the tail stopped there, its line was left as it was
 * and read again by the next switch on, a ring old: a step of up to ~10000 LSB (OFF -> DIG / ANA under chords) */
/* 0.9.13 (the audio review, C1): "~0" is the rows within a band of 2 x DLY_REST around a level within +-DLY_DC, over the
 * span of the delay itself (the target or where the time still is, whichever is longer) plus 1/16 for TAPE's wow and
 * flutter. The loop's truncating arithmetic has fixed points that are not 0: with the send silent the line settles on
 * a constant (DIG -6, ANA +2 .. -10: lp stops up to 32768 / col under its input, hp anywhere in its +-64 dead band) or
 * a small limit cycle (TAPE +-5); the old test (every row within +-1) never passed, so the tail never ended and
 * dly_lp / dly_hp never went back to 0 (ANA's TIME glided for ever after one note). A ringing echo passes only once
 * its swing is under +-DLY_REST (the line holds half level: 16 LSB out, -66 dBFS); the level is DC (dly_rest_chk
 * fades it out) */
#define DLY_REST 8
#define DLY_DC 64
static int32_t dly_qlo, dly_qhi;                /* the band the rows kept since dly_qz started counting */
__attribute__((noinline)) static int dly_tail_over(uint32_t n, int32_t target)
{
    uint32_t j, w = dly_w, s = (uint32_t)((target > dly_d ? target : dly_d) >> 8);
    int32_t lo = DLY_DC, hi = -DLY_DC;
    for (j = 1u; j <= n; j++) {
        int32_t v = dly_buf[(w - j) & (DLY_LEN - 1u)];
        if (v > DLY_DC || v < -DLY_DC) { dly_qz = 0; return 0; }
        if (v < lo) lo = v;
        if (v > hi) hi = v;
    }
    if (hi - lo > 2 * DLY_REST) { dly_qz = 0; return 0; }
    if (dly_qz && (lo < dly_qlo ? dly_qhi - lo : hi > dly_qhi ? hi - dly_qlo : 0) > 2 * DLY_REST) dly_qz = 0;
    if (!dly_qz) { dly_qlo = lo; dly_qhi = hi; }
    else { if (lo < dly_qlo) dly_qlo = lo; if (hi > dly_qhi) dly_qhi = hi; }
    dly_qz += n;
    return dly_qz >= s + (s >> 4) + 2u * n;
}
/* the line's activity (0.9.13, D4): 1 from a block whose send carried sound until the loop is at rest. The one measure
 * the routing reads (dly_type, DLY_SNAP, dly_routed, TAPE's switches, the quiet path, fx_cost_us); it was dly_lp ||
 * dly_hp, which the fixed points above kept non-zero for ever after the first note */
static uint8_t dly_ring;
static uint8_t dly_rf;                          /* the rest's fade runs: 1 DIG / ANA's (dly_xg), 2 TAPE's (tp_g) */
#include "dly_tape.c"                              /* EFFECT = TAPE (its own loop; DIG / ANA as they were) */
/* the rest (0.9.13, C1): at a block's end (one core; FR_C1 once its rows are in, dly_flush_c). snd: the block's send
 * carried sound; sw: the EFFECT that ran. With the send silent and the line in its rest band over the delay
 * (dly_tail_over), the loop sits on one of its fixed points (on or OFF): the echo fades out over 46 ms (dly_rf: DIG /
 * ANA's dly_xg, TAPE's tp_g, the fades the switches use, through tp_route), then the states go to 0 and the line is
 * cleared as at the tail's end (dly_rst: the reads behind the cleared span 0); 0 is silence's own fixed point, so it
 * stays there until the next sound. (Cleared at once, the echo's DC stepped to 0: a -73 dBFS edge above 1 kHz; faded,
 * what is left of the difference is the old tail's own residue, -79 dBFS.) Sound in the send during
 * the fade: it fades back in (the switches' fade-in). Not during a crossfade (DIG <-> ANA, a DIG time change, the
 * fades around TAPE); a change of the line's owner (TAPE <-> DIG / ANA) drops the fade and the count starts again */
__attribute__((noinline)) static void dly_rest_chk(uint32_t n, int32_t target, int32_t sw, int snd)
{
    if (snd) { dly_ring = 1; dly_qz = 0; dly_rf = 0; return; }
    if (!dly_ring) return;
    if (dly_rf && dly_rf != 1u + (dly_cur == 3)) dly_rf = 0;
    if (dly_rf) {
        if (dly_cur == 3 ? tp_g : dly_xg) return;     /* (still fading) */
        dly_lp = dly_hp = 0; dly_ring = 0; dly_qz = 0; dly_rf = 0;
        if (dly_cur != 3) dly_xg = 32768;               /* (the line is cleared: nothing to fade in) */
        else {                                          /* TAPE's playback head; after OFF its tail ends (as it did); on,
                                                         * it fades in again (tp_block) over the cleared line */
            tp_b1 = tp_b2 = tp_h1 = tp_h2 = 0;
            if (!sw) { tp_zero(); dly_cur = 0; dly_last = 0; }
        }
        if (!dly_lc) { dly_rb = dly_w; dly_rst = 1; dly_clrn = DLY_CLR / 4u; dly_lc = 1; }
        return;
    }
    if (dly_xo || dly_tx || dly_xg != 32768 || (dly_cur == 3 && (sw ? tp_g != 32768 : !tp_g))) { dly_qz = 0; return; }
    if (dly_tail_over(n, target)) { dly_rf = (uint8_t)(1u + (dly_cur == 3)); dly_qz = 0; }
}
/* fx_delay_t's per-block bookkeeping of 0.9.6, out of line (inlined, it moved the DIG / ANA loops' registers: ANA
 * 110 -> 118 instructions a sample). dly_type: DIG / ANA asked for (sw 1 / 2); a change with echoes ringing starts
 * #17's crossfade (dly_xo) */
__attribute__((noinline)) static void dly_type(int32_t sw)
{
    if (dly_ana != (sw == 2) && dly_ring && dly_cur != 3 && dly_xg == 32768) {
        if (!dly_xo) dly_xm = dly_ana ? 32768 : 0;      /* (from the type that ran; a turn back mid-way: from where it is) */
        dly_xo = 1;
    }
    dly_ana = sw == 2;
}
/* fx_delay's body. rst is always 1: the masked reads run in every block (outside a reset c is huge and every tap is
 * clean). A separate reset version (out of line, or inlined) moved the Rhodes loops' registers in app_audio, whatever
 * the arrangement tried (tools/build.py's hot-loop counts, 2026-10-18); this one leaves them as they were. */
/* ANA over a silent line takes its TIME at once (2026-11-08): its tape glide (dd += (target - dd) >> 12, ~93 ms) ran
 * from the boot's / the last TIME over an empty line, and a note played within ~0.5 s was written while the time still
 * moved: its repeats bunched up, the second echo +5 dB over DIG's, a v127 chord's peak +3.1 dB on the limiter
 * (tools/fx_pristine.py). With nothing in the line (no sound sent for a whole line, the loop's filters at rest) there is
 * nothing to bend: the time jumps (with sound in it, the glide as before) */
#define DLY_SNAP(sw, target) do { if ((sw) == 2 && dly_sil >= DLY_LEN && !dly_ring && dly_cur != 3 && !dly_xo) \
                                      dly_d = (target); } while (0)
#if FR_CHUNK
/* fx_delay_t for a chunk (dly_tape.c's FR_C1 part: the rows written by the last chunk). Once a block, at the first chunk:
 * the settings, the quiet path, the routing (the one-block code decides it from the whole block's send: ANA with a far
 * TIME change after a silent line routes only if the block carries sound; with the first chunk silent the decision waits
 * for the chunk that has some, below); at the last: the make-up, the rows, the tail's end */
static struct { int32_t sw, last, target, wet, fb, col, depth, ddr; uint8_t quiet, routed, amb, olast; uint32_t w0; int64_t e, m; } dly_c;
static struct { int32_t sg16; uint32_t n; uint8_t on; } dly_pd;   /* the last block's rows, not yet written */
static void fx_delay_t(int32_t *L, int32_t *R, uint32_t n, const int rst)
{
    uint32_t j, o = fxc_o, e = fxc_e;
    int64_t m0;
    (void)rst;
    if (FXC_1) {
        int32_t sw = fx_p[FXP_DL_SW], depth = fx_p[FXP_DL_DEPTH], last = !sw && dly_son;
        uint32_t sync = fx_dly_sync_samples;
        int32_t target = (int32_t)(sync ? sync : FX_DLY_T[fx_p[FXP_DL_TIME]]);
        int32_t wet = FX_DLY_WET[depth], fb = FX_DLY_FB[fx_p[FXP_DL_FDBK] & 127], col = 2000 + fx_p[FXP_DL_TONE] * 240;
        if (last) sw = dly_son;
        dly_son = (uint8_t)fx_p[FXP_DL_SW];
        if (sw == 1 || sw == 2) dly_type(sw);
        if (sw == 2 || (!sw && dly_ana)) col = (col * 19661) >> 15;
        while (target >= (int32_t)DLY_LEN - 2) target >>= 1;
        target <<= 8;
        if (sw != 2 && fb > 13926) fb = 13926;
        DLY_SNAP(sw, target);
        dly_c.quiet = !sw && !dly_ring && dly_cur != 3;
        if (dly_c.quiet) {
            dly_wk = wet; dly_fbk = fb;
            if (!dly_lc) { dly_rb = dly_w; dly_rst = 1; dly_clrn = DLY_CLR / 4u; dly_lc = 1; }
            if (dly_rst)
                for (j = 0; j < n; j++) dly_buf[(dly_w + j) & (DLY_LEN - 1u)] = 0;
            dly_w += n;
            dly_sgk = 0;
            return;
        }
        dly_lc = 0;
        dly_c.sw = sw; dly_c.last = last; dly_c.target = target; dly_c.wet = wet; dly_c.fb = fb; dly_c.col = col;
        dly_c.depth = depth; dly_c.w0 = dly_w; dly_c.e = dly_c.m = 0;
        dly_wm = 0;
    }
    if (dly_c.quiet) return;
    m0 = dly_c.m;
    if (dly_c.sw)                                       /* the send and the make-up's sums, this chunk */
        for (j = o; j < e; j++) {
            int32_t a = L[j], b = R[j], c = (a + b) >> 1;
            dly_m[j] = c;
            dly_c.e += (int64_t)a * a + (int64_t)b * b;
            dly_c.m += (int64_t)c * c;
        }
    if (FXC_1) {
        uint32_t sil = dly_sil;
        dly_sil = 0;                                    /* (the routing with sound in the block) */
        dly_c.amb = (uint8_t)dly_routed(dly_c.sw, dly_c.target);
        if (sil < DLY_LEN) dly_sil = sil + n; else dly_sil = sil;   /* (and with a silent block) */
        dly_c.amb = (uint8_t)(dly_c.amb && !dly_routed(dly_c.sw, dly_c.target));
        dly_sil = sil;
        if (dly_c.amb && dly_c.m > 0) dly_c.amb = 0;    /* (this first chunk has sound: decided) */
        if (dly_c.m > 0) dly_sil = 0; else if (dly_sil < DLY_LEN) dly_sil += n;   /* (the routing's view: see above) */
        dly_c.routed = (uint8_t)dly_routed(dly_c.sw, dly_c.target);
        dly_sil = sil;
        dly_c.olast = dly_last;
        if (dly_c.routed) tp_route_plan(dly_c.sw, dly_c.target, dly_c.depth);
        else dly_last = (uint8_t)dly_c.sw;
        if (dly_c.routed && !tp_rc.kind) dly_c.routed = 0;
        dly_c.ddr = dly_d;
    } else if (dly_c.amb && dly_c.m > m0) {             /* ANA's far TIME change over a silent line, and the first sound
                                                         * of the block in this chunk: the block is routed after all (the
                                                         * one-block code: its send decides). The chunks before ran the
                                                         * loop over silence: the same output, every read of the silent
                                                         * line 0, only the time's glide differs; it takes the routed
                                                         * glide's value (dly_fade's capped slew, replayed) */
        dly_d = dly_c.ddr; dly_xm = 32768; dly_last = dly_c.olast;
        tp_route_plan(dly_c.sw, dly_c.target, dly_c.depth);
        dly_c.routed = 1; dly_c.amb = 0;
    }
    if (dly_c.amb) {                                    /* (still undecided: the routed glide over this chunk) */
        int32_t dr = dly_c.ddr, t = dly_c.target;
        for (j = o; j < e; j++) dr += PH_CL((t - dr) >> 12, -16, 16);
        dly_c.ddr = dr;
    }
    if (dly_c.routed) tp_route_run(L, R, n, dly_c.target, dly_c.fb, dly_c.wet);
    else if (dly_c.sw == 2) dly_loop_ca(L, R, n, dly_c.target, dly_c.col, dly_c.fb, dly_c.wet, DLY_DRY(dly_c.depth));
    else if (dly_c.sw) dly_loop_cd(L, R, n, dly_c.target, dly_c.col, dly_c.fb, dly_c.wet, DLY_DRY(dly_c.depth));
    else dly_fade_c(L, R, n, dly_ana, 0, dly_c.target, dly_c.col, dly_c.fb, dly_c.wet, 32768, 0);
    if (FXC_Z) {
        int64_t ee = dly_c.e, m = dly_c.m;
        int32_t tg = 0, sg16;
        if (m > ((int64_t)n << 8) && (ee >> 1) != m) {
            while (ee >= ((int64_t)1 << 31)) { ee >>= 1; m >>= 1; }
            if (m > 0) tg = clampi((log2_q12((uint32_t)ee) - 4096 - log2_q12((uint32_t)m)) >> 1, 0, 4096);
        }
        if (m > 0) dly_sil = 0; else if (dly_sil < DLY_LEN) dly_sil += n;
        dly_sg += (tg - dly_sg) >> 2;
        if (tg == 0 && dly_sg < 4) dly_sg = 0;
        sg16 = dly_c.last ? 0 : exp2_q16(dly_sg);
        dly_wk = dly_c.wet; dly_fbk = dly_c.fb;         /* (every path's end of block, as fx_delay_t's one-chunk form) */
        dly_pd.sg16 = sg16; dly_pd.n = n; dly_pd.on = 1;   /* (the rows: the next block's first chunk, dly_flush_c) */
    }
}
/* the block's rows and the tail's end, once its last chunk is in: run at the next block's first chunk, before anything
 * else there (fx_process), off the last chunk (core 0 waits for it). Nothing reads the rows before that: every read is
 * at least 257 samples behind (dly_wr_c); dly_tail_over reads them, so it moves too. A chunk run again (a late job)
 * finds it done */
static void dly_flush_c(void)
{
    if (!dly_pd.on) return;
    if (dly_wm) dly_wr_c(dly_c.w0, dly_pd.n, dly_pd.sg16);
    if (dly_c.routed) tp_route_end();
    dly_rest_chk(dly_pd.n, dly_c.target, dly_c.sw, dly_c.m > 0);
    dly_pd.on = 0;
}
/* the block's start, before its first chunk (frodhes.c c1_pre_job: core 1 while core 0 renders chunk 0's voices; or
 * fx_process's first chunk itself): the block before's leftovers */
static void fx_pre_c(void)
{
    dly_flush_c();
}
#else
static inline __attribute__((always_inline)) void fx_delay_t(int32_t *L, int32_t *R, uint32_t n, const int rst)
{
    int32_t sw = fx_p[FXP_DL_SW], depth = fx_p[FXP_DL_DEPTH], last = !sw && dly_son;   /* last: the send's last block */
    uint32_t sync = fx_dly_sync_samples, j;
    int32_t target = (int32_t)(sync ? sync : FX_DLY_T[fx_p[FXP_DL_TIME]]), snd = 0;
    /* MIX (0.9.13, as Textura's): 0 the dry alone; to 64 the dry whole and the echo rising to whole (FX_DLY_WET); 64
     * both whole (the first echo as loud as the dry); past 64 the echo whole and the dry falling (DLY_DRY); 127 the
     * echoes alone */
    int32_t wet = FX_DLY_WET[depth], fb = FX_DLY_FB[fx_p[FXP_DL_FDBK] & 127], col = 2000 + fx_p[FXP_DL_TONE] * 240, sg16;
    if (last) sw = dly_son;                                 /* the old EFFECT once more, its send ramped to 0 (sg16) */
    dly_son = (uint8_t)fx_p[FXP_DL_SW];
    if (sw == 1 || sw == 2) dly_type(sw);
    if (sw == 2 || (!sw && dly_ana)) col = (col * 19661) >> 15;   /* tape: darker (ANA's tail too) */
    while (target >= (int32_t)DLY_LEN - 2) target >>= 1;
    target <<= 8;
    /* FDBK alone sets the regeneration (0.9.5; it was MIX x FDBK: at MIX 64 the repeats died fast): the loop gain is 2 fb
     * (the line holds half level), at most 0.85 up to FDBK 114, so the echoes always die (they grew forever over MIX x
     * FDBK ~ 11650: the audit, 2026-10-17); DIG and every tail (OFF) keep that cap at any FDBK. ANA from 115 goes above
     * 1 (1.03 .. 1.06, its tone and DC filters lose ~3 %): the repeats build up into oscillation, as an analog echo's
     * do, held by its softclip (where tanh's slope times the loop gain is 1); TAPE's own law: dly_tape.c tp_block */
    if (sw != 2 && fb > 13926) fb = 13926;
    DLY_SNAP(sw, target);
    if (!sw && !dly_ring && dly_cur != 3) {                 /* fully quiet and off: only keep time */
        dly_wk = wet; dly_fbk = fb;                         /* (nothing heard: no ramp to keep) */
        if (!dly_lc) { dly_rb = dly_w; dly_rst = 1; dly_clrn = DLY_CLR / 4u; dly_lc = 1; }   /* (the tail's line: cleared) */
        if (dly_rst)                                        /* (the skipped span is clean too: what the reset left) */
            for (j = 0; j < n; j++) dly_buf[(dly_w + j) & (DLY_LEN - 1u)] = 0;
        dly_w += n;
        dly_sgk = 0;                                        /* (the send off: its next block ramps up from 0) */
        return;
    }
    dly_lc = 0;
    {   /* the send is the mono sum (L + R) / 2; when the phaser / chorus / pan make L and R differ, the sum loses up to
         * 3-6 dB (the echoes "lost" under the chorus or phaser: the user, 2026-10-18). The send keeps the stereo
         * power instead: x sqrt(mean(L^2 + R^2) / 2 / mean(sum^2)), per block, gliding, at most +6 dB; exactly 1 when
         * L == R (the old send, sample for sample) */
        int64_t e = 0, m = 0;
        int32_t tg = 0;
        if (sw) for (j = 0; j < n; j++) {
            int32_t a = L[j], b = R[j], c = (a + b) >> 1;
            dly_m[j] = c;                                   /* (the send: dly_ramp, the sample loops) */
            e += (int64_t)a * a + (int64_t)b * b;
            m += (int64_t)c * c;
        }
        if (m > ((int64_t)n << 8) && (e >> 1) != m) {     /* (over -66 dBFS RMS: under it the measure is noise or
                                                             * a resting offset, e.g. L 8 / R 9 held: no make-up) */
            while (e >= ((int64_t)1 << 31)) { e >>= 1; m >>= 1; }
            if (m > 0) tg = clampi((log2_q12((uint32_t)e) - 4096 - log2_q12((uint32_t)m)) >> 1, 0, 4096);   /* (the
                                                     * fractional log2: 0.9.3 - 0.9.7 took the whole-number one, and
                                                     * the target switched 0 <-> +3 dB from block to block) */
        }
        if (m > 0) dly_sil = 0; else if (dly_sil < DLY_LEN) dly_sil += n;   /* (the line's newest sound: #3's ANA) */
        snd = m > 0;
        dly_sg += (tg - dly_sg) >> 2;
        if (tg == 0 && dly_sg < 4) dly_sg = 0;
#ifdef FX_DLY_SG_LOG
        if (sw) fprintf(stderr, "dly_sg %d %d\n", (int)tg, (int)dly_sg);   /* (tests/py/test_dly_send.py) */
#endif
    }
    sg16 = last ? 0 : exp2_q16(dly_sg);
    if (dly_routed(sw, target)) {                           /* TAPE, a switch to / from it, DIG <-> ANA, a time change */
        if (tp_route(L, R, n, sw, target, sg16, fb, wet, depth)) { dly_wk = wet; dly_fbk = fb; dly_rest_chk(n, target, sw, snd); return; }
    } else dly_last = (uint8_t)sw;                          /* (what a switch to TAPE fades out) */
    if (sw) FR_FAR(dly_ramp)(dly_m, n, sg16);                       /* (dly_loop sets dly_sgk to sg16) */
    /* the dry: whole to MIX 64, then falling to nothing at 127 (DLY_DRY) */
    if (sw == 2 && FX_ENG_K != 32768) FR_FAR(dly_loop_kb)(L, R, n, sg16, target, col, fb, wet, DLY_DRY(depth), rst);
    else if (sw == 2) dly_loop(L, R, n, 1, -1, sg16, target, col, fb, wet, DLY_DRY(depth), rst, 0);
    else if (sw) dly_loop(L, R, n, 0, -1, sg16, target, col, fb, wet, DLY_DRY(depth), rst, 0);   /* (the send's
                                                             * mask a constant: one register fewer in either loop) */
    else dly_fade(L, R, n, dly_ana, 0, sg16, target, col, fb, wet, 32768, 0);   /* the tail (OFF): DIG's or ANA's,
                                                             * dly_fade's loop at g 1 (the same integers as dly_loop's) */
    dly_wk = wet; dly_fbk = fb;                             /* (the tail's and TAPE's loops: FDBK as it is) */
    dly_rest_chk(n, target, sw, snd);
}
#endif
/* the chorus, then the delay, in their own function (0.9.5: the delay since e9eb294, so its loops do not move the
 * Rhodes pickup loops in app_audio; the chorus' three loops with it: the same app_audio as a separate chorus call) */
__attribute__((noinline)) static void fx_delay(int32_t *L, int32_t *R, uint32_t n)
{
    fx_chorus(L, R, n);
    fx_delay_t(L, R, n, 1);
}

/* ---- REVERB: Felucca's HALL (fx.c, GPL-3.0-only), unchanged except for its parameters' source and its internal
 * level: the int16 lines run 4x hotter (HL_IN) and the output gain is 4x lower (HL_OUT), the same reverb level
 * with 12 dB less rounding noise (at a piano's -9 dBFS the original level left the lines a few hundred LSB wide:
 * an audible hiss under every note, 0.4) */
#define CTL 32u
#define HL_NL 8u
#define HL_NAP 2u
#define HL_NC (CTL / 2u)
#define RV_DZ 10u                   /* rev_down's history: rv_in's 10 samples before the block */
/* the 8 lines share one ring of HL_N rows (0.9.5: the same delays, sample for sample, without the per-line write-back):
 * row t holds the 8 lines' samples written at one time, line k reads its row HL_LEN[k] back (+ its modulation); HL_N
 * is a multiple of HL_NC (a block's 16 rows never wrap) and >= the longest line; row HL_N repeats row 0 (the
 * interpolation's next sample) */
#ifndef FR_REV_HQ                   /* (the full-rate TYPEs, rev_hq.c: a build switch, off by default) */
#define FR_REV_HQ 0
#endif
#if FR_OWN                          /* the plugin's own-code build: the small helpers come from fx_own.h; with FR_REV_HQ (the
                                     * plugin's switch) the classic HALL below (rev_hall and its lines) is not compiled */
#include "fx_own.h"
#define HL_IN OWN_HL_IN
static inline __attribute__((always_inline)) int32_t sh_tz(int32_t m, uint32_t sh) { return own_div_pow2_tz(m, sh); }
static uint32_t exp2_neg(uint32_t x) { return own_exp2_neg(x); }
#if defined(DINGHY_HOST) && !defined(DINGHY_WEB)
/* (the host: every int16 ring write a clamp cuts counts as the reverb's, fx_h_clip[1]) */
static inline __attribute__((always_inline)) int32_t hl_c16(int32_t v)
{
    if (v < -32768 || v > 32767) fx_h_clip[1]++;
    return own_sat16(v);
}
#else
static inline __attribute__((always_inline)) int32_t hl_c16(int32_t v) { return own_sat16(v); }
#endif
#endif
#if !(FR_OWN && FR_REV_HQ)                 /* the classic HALL (rev_hall, its lines and helpers): fx_fel.c part 5; compiled in the FM-1,
                                                 * SMK-37, Move, MPC and web builds, never in the plugin (FR_REV_HQ) */
#define FEL_PART 5
#include "fx_fel.c"
#undef FEL_PART
#endif  /* !(FR_OWN && FR_REV_HQ) */
/* the REVERB page (0.9.3): MIX (the send, the size and the return as before), DECAY (moves the hall's size: 64 = as
 * before, 0 = about half the time, 127 = about twice: each step of the size is 2^(1/30) in T60), TONE (the lines' high
 * damping: 64 = as before (60), 0 = 150 dark, 127 = 0 bright) and PRE-DELAY (0 .. 80 ms before the hall; at 0 there is
 * no line at all). DECAY and TONE glide one step per 32 frames; a new pre-delay crossfades from the old tap (5.8 ms). */
#define PD_LEN 4096u                                    /* 92.9 ms: the pre-delay's line (int32: the send has headroom) */
#define FX_PDLY_SAMPLES(v) ((uint32_t)(v) * 3528u / 127u)   /* 0 .. 3528 samples = 80 ms (params.c shows it in ms) */
static int32_t pd_buf[PD_LEN] POOL;
#if FR_OWN
static uint32_t pd_w;                                   /* the write index */
static uint32_t pd_d;                                   /* the tap */
static uint32_t pd_d0;                                  /* the old tap */
static uint32_t pd_x;                                   /* the crossfade between them (0 = none) */
#else
static uint32_t pd_w, pd_d, pd_d0, pd_x;                /* write index, the tap, the old tap and the crossfade (0 = none) */
#endif
static uint8_t pd_on;
static uint32_t pd_fill FX_OWN_SECTION;                              /* writes since the line came on: a tap further back reads 0 */
static int32_t rv_inb[RV_DZ + CTL];                   /* the send: RV_DZ samples of history (rev_down), the block */
#define rv_in (rv_inb + RV_DZ)
static int32_t rv_off, rv_damp = 60;                   /* DECAY's size offset and TONE's damping, as they glide */
static int32_t rv_hsz RH_SP_SEC(".bss.fx_rvhsz");      /* HALL's size from SIZE / MIX (Q4) as it glides: 1/4 step a
                                                        * control block (a SIZE AUTO <-> 1 step moved it up to 35 steps
                                                        * at once, every line's gain with it: 2.1x a held tail's d2, the
                                                        * wet; 0.9.10); at rest SIZE's own (a SIZE that has not moved
                                                        * renders as before) */
static uint8_t rv_running;
/* REVERB MIX (0.9.13, as Textura's MIX): 0 the dry alone; to 64 the dry whole and the reverb rising to whole (the send,
 * RV_SEND: x MIX / 64, the return x0.5: MIX 127's level of 0.9.12's law); 64 both whole; past 64 the reverb whole and
 * the dry falling (RV_DRY, rv_dry); 127 the reverb alone. It was a send only, v 258 (254 - v) / 127, the dry always
 * whole. The send never exceeds 0.9.12's MIX 127 (32766): no line runs hotter than it could. INFINITE (rev_types.c)
 * keeps 0.9.12's line level at every MIX (its level guard and SUSTAIN level are line levels): the send v 258 at the
 * latched MIX vl, the return the rest, x RV_SEND(vl) / (2 x 258 vl) (rq / 2^15: x0.99 up to 64 .. x0.5 at 127) */
#define RV_SEND(v) ((v) >= 64 ? 32766 : (v) * 512)
#define RV_DRY(v) ((v) <= 64 ? 32768 : ((127 - (v)) * 32768 + 31) / 63)
#define RV_DRYT(v, t, d) ((t) && !((t) == RV_INF && (d) >= 127) ? RV_DRY(v) : 32768)   /* the dry's target: whole with the
                                                        * reverb OFF, and on INFINITE's FREEZE,
                                                        * which takes nothing in: what is played over it stays heard (TYPE RV_INF, DECAY 127) */
#define RV_DG_STEP 16                                   /* the dry's glide: 16 a sample, whole <-> nothing in 46 ms */
static int32_t rv_dg RH_SP_SEC(".data.fx_rvdg") = 32768;   /* the dry's gain (Q15) as it glides */
/* the dry x its gain over n samples, gliding toward t (32768 and there: nothing to do, the samples as they are) */
FR_RAM2 static __attribute__((noinline)) void rv_dry(int32_t *L, int32_t *R, uint32_t n, int32_t t)
{
    int32_t g = rv_dg;
    uint32_t j;
#if defined(DINGHY_HOST) && defined(RV_SCAN_WET)
    return;                                             /* (tests/c/rev_scan.c: the out is the input whole + the wet) */
#endif
    if (g == t) {                                       /* settled (MIX at rest): the loop without the glide's tests */
        if (g == 32768) return;
        if (!g) {                                       /* MIX 127: (x 0 + 16384) >> 15 is 0 for every x */
            for (j = 0; j < n; j++) L[j] = R[j] = 0;
            return;
        }
        for (j = 0; j < n; j++) {
            L[j] = (int32_t)(((int64_t)L[j] * g + 16384) >> 15);
            R[j] = (int32_t)(((int64_t)R[j] * g + 16384) >> 15);
        }
        return;
    }
    for (j = 0; j < n; j++) {
        if (g != t) g += g < t ? (t - g > RV_DG_STEP ? RV_DG_STEP : t - g) : -(g - t > RV_DG_STEP ? RV_DG_STEP : g - t);
        L[j] = (int32_t)(((int64_t)L[j] * g + 16384) >> 15);
        R[j] = (int32_t)(((int64_t)R[j] * g + 16384) >> 15);
    }
    rv_dg = g;
}
static void fx_predelay(int32_t *x, uint32_t tgt)      /* one control block: x[] delayed by the tap */
{
    uint32_t j;
    /* no old sound in it: the line reads as cleared until it has been written all through (a memset of 16 KB in the
     * audio block cost ~0.4 ms on the FM-1; this is the same sound) */
    if (!pd_on) { pd_fill = 0; pd_d = pd_d0 = pd_x = 0; pd_on = 1; }
#ifdef FX_RESET_ONE_BLOCK                               /* (the host test's reference: the old memsets, tests/py/test_reset_cc.py) */
    if (pd_fill == 0) memset(pd_buf, 0, sizeof pd_buf);
#endif
    if (!pd_x && tgt != pd_d) { pd_d0 = pd_d; pd_d = tgt; pd_x = 1; }
    if (!pd_x && pd_fill >= PD_LEN) {                   /* the line written all through, one tap (pd_d < PD_LEN):
                                                         * the loop below as it then runs (0.9.5: 42 -> 9 a sample) */
        uint32_t w = pd_w, d = pd_d;
        for (j = 0; j < CTL; j++, w++) {
            pd_buf[w & (PD_LEN - 1u)] = x[j];
            x[j] = pd_buf[(w - d) & (PD_LEN - 1u)];
        }
        pd_w = w;
        if (!pd_d && !tgt) pd_on = 0;                   /* back at 0: no line */
        return;
    }
    for (j = 0; j < CTL; j++) {
        int32_t a;
        pd_buf[pd_w & (PD_LEN - 1u)] = x[j];
        if (pd_fill < PD_LEN) pd_fill++;
        a = pd_d < pd_fill ? pd_buf[(pd_w - pd_d) & (PD_LEN - 1u)] : 0;
        if (pd_x) {                                     /* 256 samples from the old tap to the new one */
            int32_t b = pd_d0 < pd_fill ? pd_buf[(pd_w - pd_d0) & (PD_LEN - 1u)] : 0;
            a = b + (int32_t)(((int64_t)(a - b) * (int32_t)(pd_x << 7)) >> 15);
            if (++pd_x > 256u) pd_x = 0;
        }
        x[j] = a;
        pd_w++;
    }
    if (!pd_x && !pd_d && !tgt) pd_on = 0;              /* back at 0: no line */
}
/* the reverb's framework (rev_types.c, included after this file): the TYPE (OFF / HALL / PLATE / INFINITE), the send,
 * LOW CUT, the pre-delay, the dispatch to rev_hall or a kernel, the type-change fade and the return; its cost */
static void fx_reverb(int32_t *L, int32_t *R, uint32_t n);
static uint32_t rev_cost_us(void);
static void rev_reset_state(void);

/* ---- master: DC blocker, peak limiter (Felucca master_out; its soft clip never acted: gone, 0.9.5) */
#define LIM_T 24000                                     /* -2.7 dBFS: the look-ahead limiter's ceiling (0.8) */
static int32_t dc_l, dc_r, dce_l, dce_r;
/* look-ahead limiter (0.8): the output runs one 32-sample sub-block (0.73 ms) late; the gain ramps linearly over
 * each sub-block towards the lowest gain this one and the next need, so no sample ever passes LIM_T, nothing is
 * clipped, and the gain moves smoothly (big chords of 7-8 notes stay clean); release ~46 ms */
#define LK 32u
/* the limiter's gain ramp over a sub-block: a raised cosine (no slope step at the sub-block edges), Q15, ends on 1 */
static const uint16_t LK_S[LK] = {79,315,705,1247,1935,2761,3719,4799,5990,7282,8661,10114,11628,13188,14778,16384,17990,19580,21140,22654,24107,25486,26778,27969,29049,30007,30833,31521,32063,32453,32689,32768};
static int32_t lk_l[LK], lk_r[LK], lk_pk, lk_g = 32768;
static inline __attribute__((always_inline)) int32_t lk_need(int32_t pk) { return pk > LIM_T ? (int32_t)(((uint32_t)LIM_T << 15) / (uint32_t)pk) : 32768; }
#if FR_OWN
static inline __attribute__((always_inline)) int32_t dc_block(int32_t x, int32_t *dc, int32_t *err) { return own_dc_block(x, dc, err); }
#else
#define FEL_PART 3
#include "fx_fel.c"
#undef FEL_PART
#endif
static int32_t fx_L[256], fx_R[256];
#define GATE_LO 16                                      /* -66 dBFS (Q15; 32 in 0.9.8 .. 0.9.9, 16 before): 0.9.10, the user:
                                                         * RESPONSE FULL's soft end 3 dB deeper (rhodes.c rh_dyn) with no
                                                         * soft note faded sooner than 0.9.9's at 32; the reverbs' grain
                                                         * that 32 hid (the int16 tanks, the tail report) is the reverb's
                                                         * own fix (the MIX-tied tank gain). The electric piano only: */
#define GATE_LO_BARS 32                                 /* the bar engines (VIBES, MARIMBA: eng_cur 1) keep 0.9.9's -60 dBFS,
                                                         * byte-identical (their soft end did not go deeper) */
#define GATE_HI GATE_LO                                 /* (= GATE_LO: a note peaking between the two after the gate shut
                                                         * would not open it; the bars' likewise) */
#ifndef GATE_HOLD
#define GATE_HOLD 70u                                    /* blocks under GATE_LO before the fall: 406 ms (200 ms before
                                                         * 0.9.8: at 32 LSB VIBES' motor dipped under it for longer and the
                                                         * gate fell and opened again) */
#endif
/* the gate's fall and its product's rounding (0.9.8, the tail report; the user: on the FM-1 and the Move alike):
 * g -= (g >> 13) + 1 a sample, an exponential of ~190 ms that ends linear (~0.45 s in all: the note's own decay
 * steepening, not the 46 ms cut of before), and the product rounded (+16384): truncated, every negative sample stayed
 * at -1 to the end, a half-wave buzz of 1 LSB */
#define GATE_FALL(g) (((g) >> 13) + 1)
#define GATE_RND 16384
static int32_t gate_g = 32768, gate_tgt = 32768, fx_wet = 32768;
static uint32_t fx_lv_dith = 0x2545F491u;            /* fx_out's LEVEL dither (its generator) */
static uint32_t gate_quiet;
/* developer CC 10 (>= 64): every free-running part back to its boot state, for before / after recordings that must
 * compare sample for sample (the user, 2026-10-18): the effect LFOs, the tape's wow / flutter, the reverb's modulation,
 * the delay / chorus / pre-delay / reverb lines, the phaser's allpasses, the engines' noise generators and the motor.
 * At the next audio block: everything but the delay line at once (~16 KB of small lines), the delay line in chunks
 * over the next ~16 blocks while its reads behind the cleared span return 0 (dly_rst): the same sound, sample for
 * sample, as clearing it all at once (that one block took ~5 ms of the 5.8 on the FM-1); the pre-delay line is
 * cleared the same way at its next use (pd_on = 0). */
static volatile uint8_t fx_reset_req;
/* the dry width's state (fx_width, below) */
static int32_t wd_buf[512] POOL;                        /* the high-passed dry, WD_D back */
static uint32_t wd_w;
static int32_t wd_lp, wd_h2, wd_g;                      /* the band-pass' states (wd_lp Q8); the width's gain (Q15) */
static void fx_reset_state(void)
{
    lfo_ph = 0; lfo_rnd = 0x9E3779B9u; tw_ph = 0; ph_ph = 0; cp_ph = 0; dly_wow = 0; dly_flt = 0;
    ph_cq = -1; memset(&ph_st, 0, sizeof ph_st); ph_apv = 0; fx_lv_dith = 0x2545F491u;
    dly_rb = dly_w; dly_rst = 1; dly_lp = dly_hp = 0; dly_ring = 0; dly_qz = 0; dly_rf = 0;   /* the delay line: dly_clear_step(), the next blocks */
    dly_clrn = DLY_CLR; dly_lc = 1;
    tp_reset();                                         /* TAPE's filters, noise and transport */
    memset(cho_buf, 0, sizeof cho_buf); cho_el = -1; cho_hl[0] = cho_hl[1] = cho_ly[0] = cho_ly[1] = 0;   /* (the taps restart with cp_ph) */
#if !(FR_OWN && FR_REV_HQ)
    memset(rev_comb, 0, sizeof rev_comb); memset(rev_ap, 0, sizeof rev_ap); memset(&hl, 0, sizeof hl);
#endif
    pd_on = 0; rv_running = 0; rev_reset_state();       /* (the pre-delay line: at its next use; the TYPE's
                                                         * state: rev_types.c) */
    rv_dg = fx_p[FXP_RV_TYPE] ? RV_DRY(fx_p[FXP_RV_DEPTH]) : 32768;   /* (MIX's dry at once) */
    rh_lfsr = 0xACE1u; bar_lfsr = 0x1D872u; bar_mot_ph = 0;
    /* every voice ends and the shared pickup RLC / body states go to 0 (as at an engine change), and this block's
     * voice output is dropped (fx_process): the tails a take left under the gate's -60 dBFS rang on and the next take
     * met them (its level moved up to 5 LU with what was played before, on the FM-1: the presets suite) */
    eng_rh_kill_all(); bar_kill_all();
    lfo_sh = 0; fl_ic[0] = fl_ic[1] = 0; fl_op = 0;                 /* the filters, the smoothers, the master */
#if !FR_OWN
    dr_hp = dr_lp1 = dr_lp2 = dr_tlp = 0; dr_os_ok = 0;
#endif
    eq_reset(); wah_env = wah_bp = wah_lp = 0; wah_cr = -1; cmp_env = 0;
    cmp_g = 65536; cmp_ds = 0x9E3779B9u;                /* (the gain's dither: its boot seed) */
    dc_l = dc_r = dce_l = dce_r = 0; memset(lk_l, 0, sizeof lk_l); memset(lk_r, 0, sizeof lk_r); lk_pk = 0; lk_g = 32768;
    gate_g = gate_tgt = 32768; gate_quiet = 0;
    memset(wd_buf, 0, sizeof wd_buf); wd_lp = wd_h2 = 0;        /* (the dry width's reflection) */
#ifdef FX_RESET_ONE_BLOCK
    memset(dly_buf, 0, sizeof dly_buf); memset(pd_buf, 0, sizeof pd_buf); dly_rst = 0;
#endif
}

/* SPREAD (S13): the Rhodes' side signal (rhodes.c rh_side) joins after TREM / WAH, before the stereo effects, at the
 * level the mono stages (COMP, DRIVE, the FILTER, TREM / WAH) gave the mono sum: per 32-sample sub-block the gain
 * g = sum |L + R| / (2 sum |mono|), ramped over the sub-block (1 exactly while they are all transparent) */
static int32_t sp_g RH_SP_SEC(".data.fx_sp_g") = 32768;   /* Q15: the last sub-block's gain */
/* the side aligned to FDRV's 2x (0.9.9): the half-bands' up + down delay the driven mono by 1.84 samples (flat to 6 kHz,
 * 2.0 at 10 kHz); the side, not driven, was that much ahead, and the image narrowed (C7 at SPREAD 127, DRIVE 90: +7.2 dB
 * against +15.9 dry; tests/py/test_spread.py). The side takes z^-1 and a first-order allpass (SP_AP, Q15: within -32 dB
 * of the half-bands' response to 8 kHz) in FDRV's wet share (dr_sal, fx_drive), the share the mono has: L / R stay
 * M +- S at every MIX and through the drive's fades. Off (dr_sal 0 for two blocks): rh_side as before, bit for bit */
#define SP_AP 1710
static int32_t sp_aw RH_SP_SEC(".bss.fx_sp_aw"), sp_ad RH_SP_SEC(".bss.fx_sp_ad"), sp_ax RH_SP_SEC(".bss.fx_sp_ax"),
               sp_ay RH_SP_SEC(".bss.fx_sp_ay");        /* the last share; z^-1; the allpass' input and output */
FX_RAM __attribute__((noinline)) static void fx_spread(const int32_t *mono, int32_t *L, int32_t *R, uint32_t n)
{
#if FR_CHUNK
    uint32_t sb;
    const int32_t *side = FX_SIDE;
    static int32_t w0, w1;                              /* (the block's: from its first chunk) */
    if (FXC_1) { w1 = dr_sal; w0 = sp_aw; }
    if (w0 | w1) {
        int32_t d = sp_ad, xp = sp_ax, yp = sp_ay, dw = (w1 - w0) / (int32_t)n, w = w0 + dw * (int32_t)fxc_o;
        uint32_t i;
        if (!w0 && FXC_1) d = xp = yp = FX_SIDE[0];
        for (i = fxc_o; i < fxc_e; i++) {
            int32_t x = FX_SIDE[i], y = xp + (int32_t)(((int64_t)(d - yp) * SP_AP) >> 15);
            xp = d; d = x; yp = y;
            w += dw;
            drv_wet[i] = x + (int32_t)(((int64_t)(y - x) * (i + 1u == n ? w1 : w)) >> 15);
        }
        sp_ad = d; sp_ax = xp; sp_ay = yp;
        side = drv_wet;
    }
    if (FXC_Z) sp_aw = w1;
    for (sb = fxc_o; sb < fxc_e; sb += 32u) {
#else
    uint32_t sb;
    const int32_t *side = FX_SIDE;
    int32_t w1 = dr_sal, w0 = sp_aw;
    if (w0 | w1) {                                      /* FDRV runs: the side aligned in its wet share (drv_wet: free
                                                        * after the drive) */
        int32_t d = sp_ad, xp = sp_ax, yp = sp_ay, w = w0, dw = (w1 - w0) / (int32_t)n;
        uint32_t i;
        if (!w0) d = xp = yp = FX_SIDE[0];              /* (from rest: primed, the share starts at 0) */
        for (i = 0; i < n; i++) {
            int32_t x = FX_SIDE[i], y = xp + (int32_t)(((int64_t)(d - yp) * SP_AP) >> 15);
            xp = d; d = x; yp = y;
            w += dw;
            drv_wet[i] = x + (int32_t)(((int64_t)(y - x) * (i + 1u == n ? w1 : w)) >> 15);
        }
        sp_ad = d; sp_ax = xp; sp_ay = yp;
        side = drv_wet;
    }
    sp_aw = w1;
    for (sb = 0; sb < n; sb += 32u) {
#endif
        uint32_t e = sb + 32u < n ? sb + 32u : n;
        int32_t num = 0, den = 0, g = sp_g, dg;
        {   /* (pointers stepping: no index adds; the same sums) */
            const int32_t *l = L + sb, *r = R + sb, *mo = mono + sb, *le = L + e;
            while (l < le) { num += iabs(*l++ + *r++); den += iabs(*mo++); }
        }
        den *= 2;
        if (den > 0) {
            while (num >= (1 << 16) || den >= (1 << 16)) { num >>= 1; den >>= 1; }
            g = den ? (num << 15) / den : g;
            if (g > (4 << 15)) g = 4 << 15;
        }
        dg = (g - sp_g) / 32;
        {
            int32_t *l = L + sb, *r = R + sb, *le = L + e, k = sp_g;
            const int32_t *sd = side + sb;
            while (l < le) {
                int32_t s;
                k += dg;
                s = (int32_t)(((int64_t)*sd++ * k) >> 15);
                *l++ += s; *r++ -= s;
            }
        }
        sp_g = g;
    }
}

/* SPREAD's side for the bypass' sub-block (sd[j - sb]): rh_side + sb while it is on, else fx_zs (zeros: the plain
 * mono, the same integers; one loop each for both, less flash) */
static int32_t fx_zs[LK] RH_SP_SEC(".bss.fx_zs");
/* ---- the dry width (stage 2, 2026-11-10): the plain piano was a mono point on headphones (side / mid -25 dB with
 * F01's room, none dry), while CHORUS / PHASER on sounded bigger at the same loudness (their width alone). A side
 * wall's first reflection gives the dry a little width: the side S is the dry's band 570 Hz .. 4 kHz (one-pole high-
 * and low-pass: the bass stays mono as in a room, the wall takes the top) delayed by WD_D (10 ms, 3.4 m of extra
 * path) at WD_K; L = M + S, R = M - S. No modulation. The mono sum (L + R) / 2 is the dry exactly, the two ears'
 * critical-band loudness within 0.05 cb (the per-ear comb ripples opposite in L and R), and the reflection arrives
 * 10 ms after the strike: the v127 chords' peak +0.02 dB at most (tests/py/test_dry_width.py). The last stage before
 * the limiter (fx_out, per sub-block, after the bypass' mix, the DC blockers and LEVEL; the limiter's gain is the
 * same both sides and 1 unless limiting, so (L + R) / 2 stays the mono output exactly): M = (L + R) / 2, so FX on and off,
 * the crossfade and every effect (the FILTER, TREM, the delay) get the same one reflection of their own output. Off
 * while SPREAD's own side is on (wd_g glides it out / in over 16 blocks). Cost: one loop, ~18 instructions a sample */
#ifndef WD_D
#define WD_D 441                                        /* samples: 10 ms */
#endif
#ifndef WD_A
#define WD_A 2553                                       /* Q15: the high-pass' pole, 1 - exp(-2 pi 570 / 44100) */
#endif
#ifndef WD_B
#define WD_B 14260                                      /* Q15: the low-pass' pole, 1 - exp(-2 pi 4000 / 44100) */
#endif
#ifndef WD_K
#define WD_K (-6554)                                    /* Q15: -0.2, the reflection's level in its band; the sign
                                                         * puts it on the side of the hall's early part (with F01's
                                                         * room +0.6 dB of width more than + would) */
#endif
static __attribute__((noinline)) int32_t fx_width(uint32_t o, uint32_t e, int on)
{
    uint32_t j, w = wd_w;
    int32_t lp = wd_lp, h2 = wd_h2, g, kg, pk = 0, *pl = fx_L + o, *pr = fx_R + o;
    g = wd_g;
    if (o == 0u) {                                      /* (the block's first chunk: a step of the glide a block) */
        g = clampi(g + (on ? 2048 : -2048), 0, 32768); wd_g = g;   /* 16 blocks from 0 to 1 */
    }
    kg = (WD_K * g) >> 15;
    for (j = o; j < e; j++) {
        int32_t l = *pl, r = *pr, x = (l + r) >> 1, sd;
        lp += (int32_t)(((int64_t)((x << 8) - lp) * WD_A) >> 15);   /* (Q8: in whole LSBs the high-pass' state lagged
                                                         * a slow tail by up to 12, a side of -1 LSB for 90 ms after
                                                         * the note: test_every_control SUSTAIN) */
        h2 += (int32_t)(((int64_t)(x - (lp >> 8) - h2) * WD_B) >> 15);   /* (the wall's absorption: a low-pass) */
        sd = wd_buf[(w - WD_D) & 511u];
        wd_buf[w & 511u] = h2; w++;
        {                                               /* (64 bits: a hot chorus chord took |h2| past 2^18 and the
                                                         * 32-bit product overflowed, test_fuzz) toward zero, so the */
            int64_t t = (int64_t)sd * kg;               /* side ends in exact zeros (a floor left -1 LSB on L 40 ms */
            sd = (int32_t)((t + ((t >> 63) & 32767)) >> 15);   /* after the note: test_every_control DELAY-MIX) */
        }
        l += sd; r -= sd; *pl++ = l; *pr++ = r;
        l = iabs(l); r = iabs(r);
        if (l > pk) pk = l;
        if (r > pk) pk = r;
    }
    wd_w = w; wd_lp = lp; wd_h2 = h2;
    return pk;                                          /* (the sub-block's peak, for the limiter) */
}
/* the bypassed dry with SPREAD's side: L = M + S, R = M - S (out of line: fx_process's registers as without it) */
FX_RAM __attribute__((noinline)) static void fx_spread_dry(const int32_t *mono, const int32_t *sd, uint32_t sb)
{
    uint32_t j;
    for (j = sb; j < sb + LK; j++) { fx_L[j] = mono[j] + sd[j - sb]; fx_R[j] = mono[j] - sd[j - sb]; }
}

/* the bypass' crossfade with SPREAD on (0.9.6, BUGHUNT #25: it faded the wet toward the plain mono, but the bypassed
 * dry is M +- S: SPREAD's side stepped in at the fade's end, 18x on three notes): the same fade toward M + S / M - S;
 * the fade's gain (wet) out. Out of line: fx_out's loops as before */
/* the fade: 46 ms (FX_XF_STEP 16 a sample, 2048 samples), a smoothstep gain (0.9.10; was 5.8 ms, linear). Turning the
 * effects back on brings in what they hold at once: a delay echo mid-attack came in within 5.8 ms as a click (monkey
 * focus-xfade seed 99, the FX button: 10.7x differential, ring -44 dB; 0.9.9 6.3x); over 46 ms 4.3x, and no kink at
 * the fade's ends (the smoothstep's slope is 0 there) */
#ifndef FX_XF_STEP
#define FX_XF_STEP 16
#endif
FX_RAM __attribute__((noinline)) static int32_t fx_xf_side(const int32_t *mono, const int32_t *sd, uint32_t sb, int32_t wet,
                                                     int byp)
{
    uint32_t j;
    for (j = sb; j < sb + LK; j++) {
        if (byp ? wet > 0 : wet < 32768) wet += byp ? -FX_XF_STEP : FX_XF_STEP;
        if (wet != 32768) {
            int32_t dl = mono[j] + sd[j - sb], dr = mono[j] - sd[j - sb];
            int32_t g = (int32_t)(((uint32_t)(wet * wet) >> 15) * (uint32_t)(3 * 32768 - 2 * wet) >> 15);   /* smoothstep
                                         * (32-bit: w^2 >> 15 <= 2^15 times <= 3 * 2^15 < 2^32, as the 64-bit form) */
            fx_L[j] = (int32_t)(((int64_t)fx_L[j] * g + (int64_t)dl * (32768 - g)) >> 15);
            fx_R[j] = (int32_t)(((int64_t)fx_R[j] * g + (int64_t)dr * (32768 - g)) >> 15);
        }
    }
    return wet;
}

/* LEVEL moved (0.9.6, the bug hunt: each detent was a 0.19 dB step at a block's edge): the gain glides from the
 * last block's toward the new one (at most 512 in Q12 a block), sample by sample in the DC blocker's pass below (after
 * the blocker, as the settled gain: a ramp before it put the blocker's state into the other gain's domain, a step of
 * up to 11 % at the next block, the control sweep) */
static int32_t fx_lvk = -1;                              /* the LEVEL gain (Q12) the last block ended on */
/* this block's LEVEL: 4096 = unity (the plain loop), else the gain's ramp from *lq (Q20) by *ls a sample (0: settled
 * off unity, the same integers as a constant gain; one loop for both, less flash). still: bypassed or crossfading,
 * the step as before */
FX_RAM __attribute__((noinline)) static int32_t fx_lv_ramp(int32_t lvl, int still, uint32_t n, int32_t *lq, int32_t *ls)
{
    *lq = lvl << 8; *ls = 0;
    if (fx_lvk != lvl) {
        if (fx_lvk >= 0 && !still) {                     /* (at most 512 a block: a full swing in ~50 ms) */
            int32_t nx = fx_lvk + clampi(lvl - fx_lvk, -512, 512);
            *lq = fx_lvk << 8; *ls = ((nx - fx_lvk) << 8) / (int32_t)n; fx_lvk = nx;
            return -1;                                   /* (-1: the ramp) */
        }
        fx_lvk = lvl;
    }
    return lvl;
}
/* LEVEL off unity re-quantizes the engine's TPDF-dithered Q15 (rhodes.c RH_DITH, GitHub #16) by a gain under 1: the
 * dither shrinks under 1 LSB and the cut (it truncated) put the quiet tails' distortion back, harmonics 13-19 dB over
 * the unity path's at LEVEL 40 / 20 (and half an LSB of DC). Now a TPDF dither of +-1 LSB at that cut, rounded (0.9.8
 * fxq-mod; build/fxqm/dith.py: a -64 dBFS sine at LEVEL 40, the worst harmonic -42.5 -> -55.0 dB re the tone, the
 * floor +4 dB, at -98 dBFS). An exact 0 stays 0 (silence, the gate). Its own generator, fx_lv_dith */
/* the output stage: the bypass, the DC blocker, LEVEL, the look-ahead limiter, the gate (fx_process's end). Its own
 * function (0.9.6): inlined after the effects, their code moved its loops' registers (the limiter's copy 32 -> 36
 * instructions a sample, the DC blocker's a stack load more: cpu_check +36 us on VIBES with every effect) */
FX_RAM __attribute__((noinline)) static void fx_out(const int32_t *mono, int32_t *out, uint32_t n)   /* (RAM: 0.9.6) */
{
#if FR_CHUNK
    static int32_t lvl, lq, ls, pk, byp;                /* (the block's: from its first chunk) */
    uint32_t j, sb;
    int32_t wet = fx_wet, dl = dc_l, el = dce_l, dr = dc_r, er = dce_r;
    if (FXC_1) {
        lvl = (int32_t)FX_LVL[fx_p[FXP_LEVEL] & 127]; pk = 0; byp = fx_bypass; lq = 0; ls = 0;
        lvl = fx_lv_ramp(lvl, 0, n, &lq, &ls);
    }
    for (sb = fxc_o; sb < fxc_e; sb += LK) {
#else
    int32_t lvl = (int32_t)FX_LVL[fx_p[FXP_LEVEL] & 127];   /* the preset's volume trim, Q12 */
    uint32_t j, sb;
    int32_t pk = 0, wet = fx_wet, byp = fx_bypass, dl = dc_l, el = dce_l, dr = dc_r, er = dce_r, lq = 0, ls = 0;
    lvl = fx_lv_ramp(lvl, 0, n, &lq, &ls);             /* (bypassed too: 0.9.6, BUGHUNT #9's rest, it stepped there) */
    for (sb = 0; sb < n; sb += LK) {                   /* the look-ahead limiter, one sub-block late */
#endif
        int32_t pn = 0, tgt, g0 = lk_g, i, *po = out + 2u * sb;   /* (po: this sub-block's output, one late) */
        /* first the bypass, then the DC blocker and LEVEL (the limiter's peak scan of this sub-block is the only
         * reader): the bypass crossfades in 46 ms (fx_xf_side; the effects keep running, their tails stay current); (0.8: a +6 dB
         * push here put single notes on the limiter: everything squashed; the jack gain is APP_OUT_SHIFT). Each sample
         * goes through them independently, so a pass per stage is the one fused loop sample for sample (0.9.5: that
         * loop spilled, 88 instructions a sample with LEVEL off unity; the bypass pass, then 30 / 36 a sample) */
        if (byp && wet == 0)                           /* bypassed: the dry signal ((x 0 + dry x 32768) >> 15) */
            fx_spread_dry(mono, FX_SIDE_ONB ? FX_SIDE + sb : fx_zs, sb);
        else if (byp || wet != 32768)                  /* the crossfade (either way; toward SPREAD's M +- S: #25) */
            wet = fx_xf_side(mono, FX_SIDE_ONB ? FX_SIDE + sb : fx_zs, sb, wet, byp);
        if (lvl == 4096) {                             /* the usual case: LEVEL at unity */
            for (j = sb; j < sb + LK; j++) {
                int32_t l = dc_block(fx_L[j], &dl, &el), r = dc_block(fx_R[j], &dr, &er), al = iabs(l), ar = iabs(r);
                fx_L[j] = l; fx_R[j] = r;
                if (al > pn) pn = al;
                if (ar > pn) pn = ar;
            }
        } else {                                       /* LEVEL off unity, or moving: its ramp (lq, Q20) */
            uint32_t ds = fx_lv_dith;
            for (j = sb; j < sb + LK; j++) {
                int32_t l = dc_block(fx_L[j], &dl, &el), r = dc_block(fx_R[j], &dr, &er), al, ar, d;
                lq += ls;
                ds = ds * 1664525u + 1013904223u; d = (int32_t)((ds >> 8) & 4095u) + (int32_t)(ds >> 20) - 2048;
                l = l ? (int32_t)(((int64_t)l * (lq >> 8) + d) >> 12) : 0;   /* TPDF dithered (above fx_out; the same */
                r = r ? (int32_t)(((int64_t)r * (lq >> 8) + d) >> 12) : 0;   /* value both sides: mono stays L = R) */
                fx_L[j] = l; fx_R[j] = r;
                al = iabs(l); ar = iabs(r);
                if (al > pn) pn = al;
                if (ar > pn) pn = ar;
            }
            fx_lv_dith = ds;
        }
        pn = FR_FAR(fx_width)(sb, sb + LK, !FX_SIDE_ONB);   /* the dry width (stage 2): one wall reflection, after
                                                         * the DC blockers and LEVEL (per channel: their rounding of
                                                         * M + S and M - S left 1 LSB of noise in the mono sum, the
                                                         * v20 notes' inh +10 dB); its peak replaces pn */
        tgt = lk_g + ((32768 - lk_g) >> 6) + 1;        /* release */
        if (tgt > 32768) tgt = 32768;
        if (lk_need(lk_pk) < tgt) tgt = lk_need(lk_pk);
        if (lk_need(pn) < tgt) tgt = lk_need(pn);
        if (g0 == 32768 && tgt == 32768) {
            /* not limiting: the gain is 1 over the sub-block, and tgt = 32768 means the delayed sub-block's peak
             * lk_pk <= LIM_T: the output is lk_l / lk_r as they are, and its peak
             * is lk_pk (computed from those very values) */
            const int32_t *fl = fx_L + sb, *fr = fx_R + sb;
            for (i = 0; i < (int32_t)LK; i++) {
                int32_t xl = lk_l[i], xr = lk_r[i];
                lk_l[i] = fl[i]; lk_r[i] = fr[i];
                po[2 * i] = xl; po[2 * i + 1] = xr;
            }
            if (lk_pk > pk) pk = lk_pk;
        } else for (i = 0; i < (int32_t)LK; i++) {
            /* limiting: g0 (the last sub-block's tgt, <= lk_need of its pn, which is lk_pk now) and tgt are both
             * <= lk_need(lk_pk) and the ramp stays between them, so |x g >> 15| <= lk_pk lk_need(lk_pk) >> 15 <=
             * LIM_T (-2.7 dBFS): no clip after it (the master clip never acted and is gone, 0.9.5) */
            int32_t g = g0 + (int32_t)(((int64_t)(tgt - g0) * LK_S[i]) >> 15), xl = lk_l[i], xr = lk_r[i];
            lk_l[i] = fx_L[sb + (uint32_t)i]; lk_r[i] = fx_R[sb + (uint32_t)i];
            if (g != 32768) { xl = (int32_t)(((int64_t)xl * g) >> 15); xr = (int32_t)(((int64_t)xr * g) >> 15); }
            po[2 * i] = xl; po[2 * i + 1] = xr;          /* (no clip: <= LIM_T) */
#if defined(DINGHY_HOST) && !defined(DINGHY_WEB)
            if (iabs(xl) > LIM_T || iabs(xr) > LIM_T) __builtin_trap();   /* the host proves it on every render */
#endif
            if (iabs(xl) > pk) pk = iabs(xl);
            if (iabs(xr) > pk) pk = iabs(xr);
        }
        lk_pk = pn;
        lk_g = tgt;
#if defined(DINGHY_HOST) && !defined(DINGHY_WEB)
        if (tgt < 32768 || g0 < 32768) fx_h_clip[3]++;  /* (the limiter acted on this sub-block) */
#endif
    }
    fx_wet = wet; dc_l = dl; dce_l = el; dc_r = dr; dce_r = er;
#if FR_CHUNK && FR_LAT
    /* FR_LAT_HALF (frodhes.c): out holds only the frames this interrupt sends ([fxc_ce - FR_LAT_HALF, fxc_ce), FR_LAT_TAIL
     * frames later with the tail); the ones before are out of the DMA already. The gate runs at the frames sent's end
     * and at the block's end, over the frames not gated yet (gate_done ..): it opens on the block's peak so far (one
     * core: the whole block's), it counts and falls at the block's end. A change decided after the block's first frames
     * went out takes the gain where one core's ramp from the block's start has it (from gate_g0): the same integers from
     * there on; the frames before (all under -60 dBFS: that is what kept the gate as it was) had the old ramp. An
     * opening decided after frames went out (a note from silence whose first frames stayed under the threshold:
     * they went out muted) ramps up from the gain those frames had instead: taken from the block's start, the gain
     * jumped from 0 to full at the frames sent's end, a step of up to the threshold (0.9.11, tests/py/
     * test_lat_gate_onset.py); one core opens on the whole block's peak, from the block's start. The thresholds are
     * one core's (GATE_LO_BARS on the bar engines) */
    {
        static int32_t gate_g0;                        /* the gain at the block's first frame */
        static uint32_t gate_done;                     /* the block's frames gated */
        int32_t t0 = gate_tgt, glo = eng_cur ? GATE_LO_BARS : GATE_LO;
        uint32_t js;
        if (fxc_e != fxc_ce - FR_LAT_TAIL && !FXC_Z) return;
        if (!gate_done) gate_g0 = gate_g;
        if (pk >= glo) { gate_quiet = 0; gate_tgt = 32768; }
        else if (FXC_Z && ++gate_quiet >= GATE_HOLD) { gate_quiet = GATE_HOLD; gate_tgt = 0; }
        if (gate_tgt < t0 && gate_done) {
            int32_t g = gate_g0;
            for (j = 0; j < gate_done; j++) {
                if (g < gate_tgt) g = g + 512 > gate_tgt ? gate_tgt : g + 512;
                else if (g > gate_tgt) g = g - GATE_FALL(g) < gate_tgt ? gate_tgt : g - GATE_FALL(g);
            }
            gate_g = g;
        }
        js = gate_done;
#if FR_LAT_EV
        if (gate_tgt > t0 && eng_mid_at > gate_done && eng_mid_at < fxc_e && eng_mid_at == fxc_ce - FR_LAT_HALF) {
            /* a note started at this interrupt's first frame (engine.c eng_mid) opens the gate: it opens from that
             * frame, as one core's opens from the block's start for the note there. The frames before it (the last
             * interrupt's, under the threshold: they kept the gate as it was at their own run) keep its old course;
             * opened from them instead, a note from silence had its first frames unramped, by chance of its start */
            const uint32_t m = eng_mid_at;
            const int32_t rnd0 = t0 ? 0 : GATE_RND;
            if (gate_g != 32768 || t0 != 32768)
                for (j = gate_done; j < m; j++) {
                    if (gate_g < t0) gate_g = gate_g + 512 > t0 ? t0 : gate_g + 512;
                    else if (gate_g > t0) gate_g = gate_g - GATE_FALL(gate_g) < t0 ? t0 : gate_g - GATE_FALL(gate_g);
                    if (gate_g != 32768) {
                        out[2u * j] = (out[2u * j] * gate_g + rnd0) >> 15;
                        out[2u * j + 1u] = (out[2u * j + 1u] * gate_g + rnd0) >> 15;
                    }
                }
            js = m;
        }
#endif
        if (gate_g != 32768 || gate_tgt != 32768) {
            const int32_t rnd = gate_tgt ? 0 : GATE_RND;
            for (j = js; j < fxc_e; j++) {
                if (gate_g < gate_tgt) gate_g = gate_g + 512 > gate_tgt ? gate_tgt : gate_g + 512;
                else if (gate_g > gate_tgt) gate_g = gate_g - GATE_FALL(gate_g) < gate_tgt ? gate_tgt : gate_g - GATE_FALL(gate_g);
                if (gate_g != 32768) {
                    out[2u * j] = (out[2u * j] * gate_g + rnd) >> 15;
                    out[2u * j + 1u] = (out[2u * j + 1u] * gate_g + rnd) >> 15;
                }
            }
        }
        gate_done = FXC_Z ? 0u : fxc_e;
    }
    if (!FXC_Z) return;
    fx_peak = pk;
    if (pk < 16) { if (fx_quiet_blocks < 0xFFFFu) fx_quiet_blocks++; } else fx_quiet_blocks = 0;
    if (gate_g == 0) { if (fx_gz < 0xFFFFu) fx_gz++; } else fx_gz = 0;
    return;
#elif FR_CHUNK
    if (!FXC_Z) return;                                /* (the gate: once the block's peak is in, over all of out) */
#endif
    /* silence gate: the codec mutes itself on digital zero, but while anything at all comes out its analog hiss
     * is there; a held note's last -66 dBFS lie under that hiss anyway. So after 406 ms under GATE_LO the output
     * fades (~0.45 s: GATE_FALL) to exact zero, and it opens within 1.5 ms of the first block above GATE_HI (0.4) */
    {
        int32_t glo = eng_cur ? GATE_LO_BARS : GATE_LO;  /* (the running engine: engine.c, ISR) */
        if (pk >= glo) { gate_quiet = 0; gate_tgt = 32768; }
        else if (++gate_quiet >= GATE_HOLD) { gate_quiet = GATE_HOLD; gate_tgt = 0; }
    }
    /* (every sample of out written with "=" by the limiter above: platform.c does not clear it, APP_OUT_WRITTEN in
     * frodhes.c); 0.9.5: open and staying open this block, there is nothing left to do; it was a copy from fx_L /
     * fx_R, 7 instructions a sample */
    if (gate_g != 32768 || gate_tgt != 32768) {
        const int32_t rnd = gate_tgt ? 0 : GATE_RND;   /* (rounded while it falls; opening, truncated as it always was) */
        for (j = 0; j < n; j++) {
            if (gate_g < gate_tgt) gate_g = gate_g + 512 > gate_tgt ? gate_tgt : gate_g + 512;
            else if (gate_g > gate_tgt) gate_g = gate_g - GATE_FALL(gate_g) < gate_tgt ? gate_tgt : gate_g - GATE_FALL(gate_g);
            if (gate_g != 32768) {
                out[2u * j] = (out[2u * j] * gate_g + rnd) >> 15;
                out[2u * j + 1u] = (out[2u * j + 1u] * gate_g + rnd) >> 15;
            }
        }
    }
    fx_peak = pk;
    if (pk < 16) { if (fx_quiet_blocks < 0xFFFFu) fx_quiet_blocks++; } else fx_quiet_blocks = 0;
    if (gate_g == 0) { if (fx_gz < 0xFFFFu) fx_gz++; } else fx_gz = 0;
}
#if C1_PRE_C0
static int32_t fx_m[256], fx_dryc[256];                  /* (fx_process's m and dry_c: the front writes them) */
/* the front (COMP, the compressor's dry, EQ, DRIVE, FILTER) on the front's chunk fxf_o .. fxf_e: core 0 right after the
 * chunk's voices (frodhes.c app_audio), or fx_process on a block core 1 did not get. The same calls as fx_process's
 * (the stages' code compiled on fxf_*: the renames above) */
static void fx_front(const int32_t *mono, uint32_t n)
{
    uint32_t j;
#if defined(C1PF_ON)
    static uint32_t f_ps[4];
    uint32_t q0 = fm1_ticks(), q1, k_;
    if (fxf_o == 0u) for (k_ = 0; k_ < 4u; k_++) f_ps[k_] = 0;
#define C1PSF(k) do { q1 = fm1_ticks(); f_ps[k] += q1 - q0; q0 = q1; } while (0)
#else
#define C1PSF(k) ((void)0)
#endif
    if (fxf_o == 0u) fxf_mono = mono;
    if (fx_p[FXP_RAW]) return;                         /* (fx_process: the voices to the output, no effect) */
    for (j = fxf_o; j < fxf_e; j++) fx_m[j] = mono[j];
    fx_comp(fx_m, n);
    C1PSF(0);
#if FR_BYP_KEEP_CMP
    for (j = fxf_o; j < fxf_e; j++) fx_dryc[j] = fx_m[j];
#endif
    fx_eq(fx_m, n);
    C1PSF(1);
    fx_drive(fx_m, n);
    C1PSF(2);
    fx_filter(fx_m, n);
    C1PSF(3);
#if defined(C1PF_ON)
    if (fxf_e == fxf_n) for (k_ = 0; k_ < 4u; k_++) C1PF(26u + k_, f_ps[k_]);   /* (C1_PRE_C0: core 0's time) */
#endif
#undef C1PSF
}
static void fxf_chunk(const int32_t *mono, uint32_t o, uint32_t e, uint32_t n)   /* the front of one chunk, either core */
{
    fxf_o = o; fxf_e = e; fxf_n = n;
    fx_front(mono, n);
    fr_c1_sync();
    fxf_done = e;
    fr_c1_sync();
}
#endif
FX_PROC_ATTR void fx_process(const int32_t *mono, int32_t *out, uint32_t n)   /* (into app_audio, as it always was: the 0.9.3 delay fix took it over the inliner's limit, and the mode loop moved) */
{
#if C1_PRE_C0
    int32_t *const m = fx_m;
#else
    static int32_t m[256];
#endif
#if FR_CHUNK
    uint32_t j;
#ifdef C1_EST_LOG
    if (FXC_1) c1_est_blk++;
#endif
    if (FXC_1) {                                       /* (CC 10's block: one chunk, frodhes.c) */
        fx_pre_c();                                    /* (the block before's leftovers, if c1_pre_job did not) */
        if (fx_reset_req) {
            fx_reset_state(); memset((void *)mono, 0, n * sizeof mono[0]); fx_reset_req = 0;
            FX_SIDE_ON = 0; sp_g = 32768; sp_aw = 0;
        }
        else if (dly_rst) dly_clear_step();
        fxc_side = FX_SIDE_ON;                         /* (the engine decides it at its block's start, eng_begin) */
#ifdef FX_ENG_LVL
        fxc_eng = engc_fx;                             /* (the bars' level for the level-reading effects, the same:
                                                        * on a fade block the new engine's, as one core) */
#endif
        fxc_mono = mono;
    }
    if (fx_p[FXP_RAW]) {
        for (j = fxc_o; j < fxc_e; j++) { out[2u * j] = mono[j]; out[2u * j + 1u] = mono[j]; }
        return;
    }
#if C1_PRE_C0
    for (j = fxc_o; j < fxc_e; j++) fx_L[j] = fx_R[j] = 0;
    if (fxc_front_whole) { fxf_o = fxc_o; fxf_e = fxc_e; fxf_n = fxc_n; fx_front(mono, n); }   /* (the whole path) */
    else {                                             /* the chunks whose front core 0 did not run, one by one */
        uint32_t c, k = fxf_k;
        for (c = fxc_o; c < fxc_e; c += k)
            if (fxf_rd() <= c) fxf_chunk(mono, c, c + k, n);
    }
#else
    for (j = fxc_o; j < fxc_e; j++) { m[j] = mono[j]; fx_L[j] = fx_R[j] = 0; }
#endif
#else
    if (fx_reset_req) {                                /* (the voices' last block too: mono is frodhes.c's voice_mono) */
        fx_reset_state(); memset((void *)mono, 0, n * sizeof mono[0]); fx_reset_req = 0;
        FX_SIDE_ON = 0; sp_g = 32768; sp_aw = 0;       /* (SPREAD's side of that last block too) */
    }
    else if (dly_rst) dly_clear_step();
    uint32_t j;
    if (fx_p[FXP_RAW]) {                               /* developer: the voice engine's output untouched */
        for (j = 0; j < n; j++) { out[2u * j] = mono[j]; out[2u * j + 1u] = mono[j]; }   /* (every sample: "=") */
        return;
    }
    for (j = 0; j < n; j++) { m[j] = mono[j]; fx_L[j] = fx_R[j] = 0; }   /* (mono is the dry signal for the bypass) */
#endif
#if defined(C1PF_ON)
    static uint32_t c1_ps[9];
    uint32_t q0, q1, k_;
    if (FXC_1) for (k_ = 0; k_ < 9u; k_++) c1_ps[k_] = 0;
    q0 = fm1_ticks();
#define C1PS(k) do { q1 = fm1_ticks(); c1_ps[k] += q1 - q0; if (FXC_1 && !FXC_Z) C1PF(35u + (k), q1 - q0); q0 = q1; } while (0)
#endif
#if C1_PRE_C0
#if FR_BYP_KEEP_CMP
    int32_t *const dry_c = fx_dryc;
#endif
#else
    fx_comp(m, n);
#if defined(C1PF_ON)
    C1PS(0);
#endif
#if FR_BYP_KEEP_CMP
    /* FX bypasses every effect but the compressor, so its dry is the compressor's output (the Move, the user
     * 2026-10-28; every build from 0.9.10, the user 2026-11-08: "leave compressor aside of the efx off button, I don't
     * want to change the dynamic of the piano": the bypass had dropped the compressor's make-up, the effects-on sound
     * 1-2.6 dB over the bypass on the factory presets). -DFR_BYP_KEEP_CMP=0: the bypass without the compressor */
    static int32_t dry_c[256];
#if FR_CHUNK
    for (j = fxc_o; j < fxc_e; j++) dry_c[j] = m[j];   /* (this chunk's: the later chunks' m is not written yet) */
#else
    for (j = 0; j < n; j++) dry_c[j] = m[j];
#endif
#endif
    fx_eq(m, n);                                       /* the EQ before the drive (flat: m untouched, no loop) */
#if defined(C1PF_ON)
    C1PS(1);
#endif
    fx_drive(m, n);                                    /* (0.9.5, the user: DRIVE before the FILTER; both mono, on m
                                                        * in place) */
#if defined(C1PF_ON)
    C1PS(2);
#endif
    fx_filter(m, n);
#if defined(C1PF_ON)
    C1PS(3);
#endif
#endif
    fx_trem(m, fx_L, fx_R, n);
#if defined(C1PF_ON)
    C1PS(4);
#endif
    if (FX_SIDE_ONB) FR_FAR(fx_spread)(mono, fx_L, fx_R, n);   /* SPREAD: the side (S13) */
    FR_FAR(fx_phaser)(fx_L, fx_R, n);
#if defined(C1PF_ON)
    C1PS(5);
#endif
    fx_delay(fx_L, fx_R, n);                           /* (the chorus, then the delay) */
#if defined(C1PF_ON)
    C1PS(6);
#endif
    fx_reverb(fx_L, fx_R, n);
#if defined(C1PF_ON)
    C1PS(7);
#endif
#if FR_BYP_KEEP_CMP
    FR_FAR(fx_out)(dry_c, out, n);
#else
    FR_FAR(fx_out)(mono, out, n);
#endif
#if defined(C1PF_ON)
    C1PS(8);
#endif
#if defined(C1PF_ON)
    if (FXC_Z) for (k_ = 0; k_ < 9u; k_++) C1PF(26u + k_, c1_ps[k_]);
#undef C1PS
#endif
}

/* ---- what the effects that run now cost on the FM-1, us per block: the bar engine's CPU model (bars.c
 * bar_cost_fixed) takes it from its budget. An effect costs while it runs: the delay and the reverb also while their
 * tails ring after they are switched off; the bypass (FX) keeps everything running. PLACEHOLDERS: split by hand from
 * the measured total (every effect + the filter LP18 / LFO: 1388 - 312 = 1076 us, tools/hil_cpu.py 2026-10-16), each
 * rounded up; replace them with tools/hil_cpu.py --fx-each (idle, one effect at a time, minus idle without effects). */
#define FX_US_COMP 90u
#define FX_US_FILTER 150u      /* LP18 + the LFO, the heaviest type */
#define FX_US_DRIVE 248u      /* 0.9.9, the curve at 2x (drive.c dr_os2): 155 instructions a sample on the longest
                                * path (front 20, up 25, curve 2 x 23, down 34, TONE / MIX 30; tools/drive_insns.py), x 1.6;
                                * the defaults' path 139 (222 us). It was 80 (the 1x curve, 54, measured) */
#define FX_US_SPAL 20u        /* SPREAD's side aligned to FDRV's 2x (fx_spread: ~12 instructions a sample, x 1.6) */
#define FX_US_TREM 40u         /* tremolo / pan (sw 1) */
#define FX_US_WAH 90u          /* touch wah (sw 2) */
#define FX_US_PHASER 150u
#define FX_US_CHORUS 160u
#define FX_US_DELAY 150u
#define FX_US_REVERB 311u     /* 260 measured, + 51 estimated for 0.9.5's half-bands (rev_types.c) */
static uint32_t fx_cost_us(void)
{
    uint32_t us = 0, t = (uint32_t)fx_p[FXP_FL_TYPE];
    if (fx_p[FXP_RAW]) return 0;
    if (fx_p[FXP_CMP_SW]) us += FX_US_COMP;
    if (t && t <= 6u) us += FX_US_FILTER;
    us += eq_cost_us();
    if (fx_p[FXP_DRIVE] && (fx_p[FXP_DRV_SW] || dr_w)) {
        us += drv_cost_us(FX_US_DRIVE);
        if (FX_SIDE_ON && drv_on == 1u) us += FX_US_SPAL;   /* (SPREAD's side aligned to FDRV: fx_spread) */
    }
    if (fx_p[FXP_TW_SW] == 1) us += FX_US_TREM;
    else if (fx_p[FXP_TW_SW] == 2) us += FX_US_WAH;
    if (fx_p[FXP_PH_SW]) us += FX_US_PHASER;
    if (fx_p[FXP_CP_SW]) us += FX_US_CHORUS;
    if (fx_p[FXP_DL_SW] || dly_ring || dly_cur == 3) us += FX_US_DELAY;   /* (a resting tail: none, C1) */
    us += rev_cost_us();                               /* (rev_types.c: HALL FX_US_REVERB, as before) */
    return us;
}
