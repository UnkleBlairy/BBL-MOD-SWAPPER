MAKU 1.0 for the BBL Mod Swapper

Original by okumurari2: https://github.com/okumurari2/maku
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: MAKU-source.zip on the ports page.
