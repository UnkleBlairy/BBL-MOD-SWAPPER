Skiff 2.7.1 for the BBL Mod Swapper

Original by illuminus5: https://github.com/illuminus5/skiff
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: SKIFF-source.zip on the ports page.
