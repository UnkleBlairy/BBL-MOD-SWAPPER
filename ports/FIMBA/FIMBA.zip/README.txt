Fimba 0.7.0 for the BBL Mod Swapper

Original by jadamsowers: https://github.com/jadamsowers/fm1-fimba
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.
MIDI: yes. The Teensy's USB is a MIDI port (in and out). The FM-1's MIDI jack as MIDI in comes with release 1.2.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: FIMBA-source.zip on the ports page.
