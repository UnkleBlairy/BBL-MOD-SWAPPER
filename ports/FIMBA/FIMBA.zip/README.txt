Fimba 0.7.0 for the BBL Mod Swapper

Original by jadamsowers: https://github.com/jadamsowers/fm1-fimba
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: FIMBA-source.zip on the ports page.
