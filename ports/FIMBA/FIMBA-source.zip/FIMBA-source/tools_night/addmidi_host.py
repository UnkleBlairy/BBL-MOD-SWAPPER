#!/usr/bin/env python3
"""addmidi_host.py port... : MIDI hooks (docs/MIDI.md) for a host-simulator port (the X0X shape: web/emu/felucca_teensy.c
includes host/<name>_host.c, whose min_q / mi_w / mi_r is the firmware's MIDI in and plat_midi_out its MIDI out).

As ports/x0x: a small ring (tmo_q) filled by plat_midi_out through X0X_MIDI_PUT, drained by teensy_midi_out; MIDI in goes
into min_q as the host's own "midi" command does. Checked with a syntax-only compile, as addmidi.py; prints one line a port.
"""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from addmidi import ROOT, MARK, compiles

RING = """/* teensy-fm1: MIDI out to the Teensy's USB MIDI port (teensy_midi_out takes it; added by tools_night/addmidi_host.py) */
#define TMQ 64u
static uint32_t tmo_q[TMQ], tmo_w, tmo_r;
#define X0X_MIDI_PUT(p) do { if (tmo_w - tmo_r < TMQ) tmo_q[tmo_w++ % TMQ] = (p); } while (0)
"""
HOOK = """#ifdef X0X_MIDI_PUT
    X0X_MIDI_PUT(pkt);                               /* teensy-fm1: to the Teensy's USB MIDI */
#endif
"""


def block(stamp, clock_pkt, reset):
    return MARK + """
/* The runtime (src/main.rs) hands in whole messages from the FM-1's TRS jack and the Teensy's USB MIDI port, and takes
 * the firmware's MIDI out for USB. The host's in queue (min_q, as its "midi" command) stands in for usb.c's.
 * (added by tools_night/addmidi_host.py, docs/MIDI.md) */
EXPORT void teensy_midi_in(uint32_t st, uint32_t d1, uint32_t d2, uint32_t source)
{
    (void)source;
    if (st >= 0xF8u ? !(st == 0xF8u || st == 0xFAu || st == 0xFBu || st == 0xFCu) : (st < 0x80u || st >= 0xF0u))
        return;
    if (mi_w - mi_r >= MQ)
        return;
""" + stamp + """    min_q[mi_w++ % MQ] = """ + clock_pkt + """(st >= 0xF0u ? 0x0Fu : st >> 4) | st << 8 | (d1 & 127u) << 16 | (d2 & 127u) << 24;
}
EXPORT void teensy_midi_link(uint32_t on) { (void)on; }
EXPORT uint32_t teensy_midi_out(uint32_t *out, uint32_t cap)
{
    uint32_t n = 0;
    while (n < cap && tmo_r != tmo_w)
        out[n++] = tmo_q[tmo_r++ % TMQ];
""" + reset + """    return n;
}
"""


def add(p):
    d = os.path.join(ROOT, "ports", p)
    f = os.path.join(d, "web/emu/felucca_teensy.c")
    src = open(f).read()
    if "teensy_midi_in" in src:
        return "HAS"
    m = re.search(r'^#include "\.\./\.\./(host/[a-z0-9_]+\.c)"', src, re.M)
    if not m:
        return "LOOK (no host file)"
    hf = os.path.join(d, m.group(1))
    host = open(hf).read()
    if not re.search(r"static uint32_t min_q\[MQ\][^;]*\bmi_w, mi_r;", host):
        return "LOOK (no min_q)"
    # the out hook: after the host's own out-queue count if it has one (X0X), else first thing in plat_midi_out
    if "host_moq++;" in host and "X0X_MIDI_PUT" not in host:
        nh = host.replace("    host_moq++;\n", "    host_moq++;\n" + HOOK, 1)
        reset = "    host_moq = 0;                                   /* the computer took what was sent */\n"
    else:
        nh = re.sub(r"(\nvoid plat_midi_out\(uint32_t pkt\)\n\{\n(?:    uint32_t [^\n]*;\n)*)", lambda k: k.group(1) + HOOK, host, count=1)
        reset = ""
    if nh == host and "X0X_MIDI_PUT" not in host:
        return "LOOK (no plat_midi_out)"
    stamp, clock_pkt = "", ""
    if "min_t[MQ]" in host:                              # (Niagara) each message's time, in us
        stamp = "    min_t[mi_w % MQ] = plat_us();\n"
    if "0x1Fu | 0xF8u << 8" in host:                     # (Penumbra) clock pulses carry their time, as usb.c's midi_stamp
        clock_pkt = "st == 0xF8u ? 0x1Fu | 0xF8u << 8 | (((plat_ms() * 24000u) >> 12) & 0xFFFFu) << 16 : "
    nsrc = src.replace(m.group(0), RING + m.group(0), 1).rstrip("\n") + "\n\n" + block(stamp, clock_pkt, reset)
    open(hf, "w").write(nh)
    open(f, "w").write(nsrc)
    ok, err = compiles(p, f)
    if not ok:
        open(hf, "w").write(host)
        open(f, "w").write(src)
        return "LOOK (" + err.strip().splitlines()[-1][:140] + ")"
    return "HOST" + (" stamp" if stamp else "") + (" clockstamp" if clock_pkt else "") + (" moq" if reset else "")


if __name__ == "__main__":
    for p in sys.argv[1:]:
        print(p, add(p), flush=True)
