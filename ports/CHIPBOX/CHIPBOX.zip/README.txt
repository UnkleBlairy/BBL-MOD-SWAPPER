Chipbox 1.7.0-signatureshowcase for the BBL Mod Swapper

Original by pbarilla: https://github.com/pbarilla/chipbox
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: CHIPBOX-source.zip on the ports page.
