/* SPDX-License-Identifier: GPL-3.0-only */
/* Projects: 8 slots in flash, each with two banks. A save writes the bank that is not the newest and puts its header
 * (magic, number, length, crc) last, so a power cut mid-save leaves the old version whole. Included by chipbox.c.
 *   bank: [header 16 B][payload]; payload: version, tempo, pages, channels (kind and sound), then every note as one event
 * An erase stalls the sound (~50 ms a sector), so saves happen when stopped, or when you press SAVE. */
#define PROJ_MAGIC 0x32424A50u                  /* "PJB2" */
#define PROJ_HDR 16u
#define PROJ_INST 17u                           /* bytes of a channel's sound (version 2 had 14: no wave fold, crush, twist) */
#define PROJ_EV 6u                              /* bytes of a note: page, channel, step, note, velocity, length */

static uint8_t proj_buf[PROJ_BANK];
static uint8_t proj_cur;                        /* the open slot */
static uint32_t proj_dirty, proj_t_edit, proj_t_saved, proj_t_fail, proj_loaded;   /* proj_loaded: the open project came from flash */

static uint32_t proj_crc(const uint8_t *p, uint32_t n)
{
    uint32_t c = 0xFFFFFFFFu, k;
    while (n--) {
        c ^= *p++;
        for (k = 0; k < 8u; k++) c = c & 1u ? (c >> 1) ^ 0xEDB88320u : c >> 1;
    }
    return ~c;
}
static uint32_t undo_open, undo_t;               /* a group of edits is open: it closes after a quiet moment */
static void undo_push(void);
static uint32_t les_on, les_hide, les_kclk;               /* a lesson is running on a scratch project (lessons.c): nothing it does is an edit of the user's project */
static void proj_edited(void) { if (les_on) { if (!undo_open) undo_push(); undo_open = 1; undo_t = fm1_ms; return; } blk_gc(); if (!undo_open) undo_push(); undo_open = 1; undo_t = fm1_ms; proj_dirty = 1; proj_t_edit = fm1_ms; }

static uint32_t pack_evat;                      /* where the last pack put the note count: the undo compares the part before it and the part after it apart */
static uint32_t proj_pack(uint8_t *p)           /* the project to bytes: the length, or 0 when it does not fit a bank */
{
    uint32_t n = 0, pg, c, s, ev = 0, evat;
    p[n++] = 5;                                 /* version 5: after a channel's sound a length byte and that many extra bytes (0: the defaults; byte 0 the sidechain, then an FM chip's patch, bit packed: fm.c) */
    p[n++] = (uint8_t)seq_bpm; p[n++] = (uint8_t)(seq_bpm >> 8);
    p[n++] = (uint8_t)page_n; p[n++] = (uint8_t)chan_n;
    for (c = 0; c < chan_n; c++) {
        const inst_t *x = &chan[c].in;
        p[n++] = chan[c].kind;
        p[n++] = x->wave; p[n++] = x->duty; p[n++] = x->atk; p[n++] = x->dec; p[n++] = x->sus; p[n++] = x->rel;
        p[n++] = x->vib_spd; p[n++] = x->vib_dep; p[n++] = (uint8_t)x->sweep; p[n++] = x->pan; p[n++] = x->vol;
        p[n++] = x->arp; p[n++] = x->arp_rate; p[n++] = x->arp_dir;
        p[n++] = x->wf; p[n++] = x->wc; p[n++] = x->wt;
        {   const uint32_t fl = fm_plen(chan[c].kind);
            if (n + 2u + fl > PROJ_BANK - PROJ_HDR) return 0;
            if (fl) { p[n++] = (uint8_t)(1u + fl); p[n++] = x->duck; fm_pack(chan[c].kind, &chan[c].fm, p + n); n += fl; }
            else if (chan[c].wcus && wd_ok(chan[c].kind)) { const uint32_t wl = wd_plen(c); if (n + 2u + wl > PROJ_BANK - PROJ_HDR) return 0; p[n++] = (uint8_t)(1u + wl); p[n++] = x->duck; wd_pack(c, p + n); n += wl; }       /* a drawn wave, at the chip's depth */
            else if (x->duck) { p[n++] = 1; p[n++] = x->duck; } else p[n++] = 0;
        }
    }
    evat = n; pack_evat = n; n += 2;
    for (pg = 0; pg < page_n; pg++)
        for (c = 0; c < chan_n; c++)
            for (s = 0; s < SEQ_MAXLEN; s++) {
                const step_t *x = STEP_R(pg, c, s);
                if (!x->note && !(IS_DRUM(chan[c].kind) && (x->vel & 7u))) continue;
                if (n + PROJ_EV > PROJ_BANK - PROJ_HDR) return 0;
                p[n++] = (uint8_t)pg; p[n++] = (uint8_t)c; p[n++] = (uint8_t)s; p[n++] = x->note; p[n++] = x->vel; p[n++] = x->gate;
                ev++;
            }
    p[evat] = (uint8_t)ev; p[evat + 1u] = (uint8_t)(ev >> 8);
    if (n + 1u + song_len > PROJ_BANK - PROJ_HDR) return 0;
    p[n++] = (uint8_t)song_len;                 /* the song: a page for each slot */
    for (s = 0; s < song_len; s++) p[n++] = song[s];
    {   uint32_t any = 0, tmp = 0;              /* version 6: a byte for each page after the song, its meter, bars less one and glide (bit 7); version 7: and then a byte each for the page's own tempo (0: the song's).
                                                 * Only a project that uses them says so: every other project stays version 5 */
        for (pg = 0; pg < page_n; pg++) { any |= (uint32_t)(page_sig[pg] | page_xb[pg] | page_gl[pg]); tmp |= page_tmp[pg]; }
        if (any || tmp) {
            if (n + page_n * (tmp ? 2u : 1u) > PROJ_BANK - PROJ_HDR) return 0;
            p[0] = tmp ? 7 : 6;
            for (pg = 0; pg < page_n; pg++) p[n++] = (uint8_t)(page_sig[pg] | page_xb[pg] << 4 | (page_gl[pg] & 1u) << 7 | (page_gl[pg] >> 1 & 1u) << 3);       /* the glide: bit 7 straight, bit 3 ease in, both ease out */
            if (tmp) for (pg = 0; pg < page_n; pg++) p[n++] = page_tmp[pg];
        }
    }
    return n;
}
static uint32_t pack_evat_of(const uint8_t *p, uint32_t len)      /* where the note count sits in a payload this firmware packed */
{
    uint32_t n = 5u, c;
    for (c = 0; c < p[4] && n < len; c++) { n += 1u + PROJ_INST; if (p[0] >= 4u && n < len) n += 1u + p[n]; }
    return n;
}
static int proj_check(const uint8_t *p, uint32_t len)       /* 0: these bytes are a project this firmware can load */
{
    uint32_t n, i, c, ev, pages, chans, isz;
    if (len < 7u || p[0] < 2u || p[0] > 7u) return -1;
    isz = p[0] == 2u ? 14u : PROJ_INST;
    pages = p[3]; chans = p[4];
    if (pages < 1u || pages > SEQ_PAGES || chans > MAXCH) return -1;
    n = 5u;
    for (c = 0; c < chans; c++) {
        if (n + 1u + isz > len || p[n] >= KINDS) return -1;
        n += 1u + isz;
        if (p[0] >= 4u) { if (n >= len) return -1; n += 1u + p[n]; }
    }
    if (len < n + 2u) return -1;
    ev = (uint32_t)p[n] | (uint32_t)p[n + 1u] << 8;
    n += 2u;
    if (len < n + ev * PROJ_EV) return -1;
    for (i = 0; i < ev; i++) {
        const uint8_t *e = p + n + i * PROJ_EV;
        if (e[0] >= pages || e[1] >= chans || e[2] >= SEQ_MAXLEN) return -1;
    }
    {   static uint8_t seen[SEQ_PAGES * MAXCH * (SEQ_MAXLEN / SEQ_LEN) / 8u];      /* the blocks the steps need must fit */
        uint32_t nb = 0;
        memset(seen, 0, sizeof seen);
        for (i = 0; i < ev; i++) {
            const uint8_t *e = p + n + i * PROJ_EV;
            const uint32_t k = ((uint32_t)e[0] * MAXCH + e[1]) * (SEQ_MAXLEN / SEQ_LEN) + e[2] / SEQ_LEN;
            if (!(seen[k >> 3] >> (k & 7u) & 1u)) { seen[k >> 3] |= (uint8_t)(1u << (k & 7u)); nb++; }
        }
        if (nb > SEQ_NBLK) return -1;
    }
    if (p[0] >= 6u) {                                   /* version 6: the song, then a meter byte for each page */
        const uint32_t se = n + ev * PROJ_EV;
        if (se >= len || p[se] < 1u || p[se] > SONG_MAX || se + 1u + p[se] + pages > len) return -1;
        for (i = 0; i < pages; i++) {
            const uint32_t b = p[se + 1u + p[se] + i], sg = b & 7u, xb = b >> 4 & 7u;
            if (sg >= 6u || (xb + 1u) * METER_STEPS[sg] > SEQ_MAXLEN) return -1;
        }
        if (p[0] >= 7u) {                               /* version 7: then a tempo for each page */
            if (se + 1u + p[se] + pages * 2u > len) return -1;
            for (i = 0; i < pages; i++) { const uint32_t t = p[se + 1u + p[se] + pages + i]; if (t && (t < 40u || t > 240u)) return -1; }
        }
    }
    return 0;
}
static int proj_unpack(const uint8_t *p, uint32_t len)      /* 0: loaded; else nothing was changed */
{
    uint32_t n, i, c, ev, pages, chans, isz, q0;
    if (proj_check(p, len)) return -1;
    isz = p[0] == 2u ? 14u : PROJ_INST;
    pages = p[3]; chans = p[4];
    n = 5u;
    for (c = 0; c < chans; c++) { n += 1u + isz; if (p[0] >= 4u) n += 1u + p[n]; }
    ev = (uint32_t)p[n] | (uint32_t)p[n + 1u] << 8;
    n += 2u;
    seq_stop();
    seq_clear();                                /* (the voices are silent while this runs; a sound is read when a note starts) */
    seq_bpm = (uint32_t)p[1] | (uint32_t)p[2] << 8; seq_bpm_play = seq_bpm;
    page_n = pages;
    for (c = 0, q0 = 5u; c < chans; c++) {
        const uint8_t *q = p + q0;
        chan_t *x;
        chan_add(q[0]);
        x = &chan[c];
        x->in.wave = q[1]; x->in.duty = q[2]; x->in.atk = q[3]; x->in.dec = q[4]; x->in.sus = q[5]; x->in.rel = q[6];
        x->in.vib_spd = q[7]; x->in.vib_dep = q[8]; x->in.sweep = (int8_t)q[9]; x->in.pan = q[10]; x->in.vol = q[11];
        x->in.arp = q[12]; x->in.arp_rate = q[13]; x->in.arp_dir = q[14];
        if (isz == 14u) { static const uint8_t OLD[4] = {0, 5, 10, 15}; x->in.wave = OLD[q[1] & 3u]; }       /* version 2: wave was one of four presets */
        else { const uint32_t m = q[0] == KD_SID ? 255u : 15u; x->in.wf = q[15] & m; x->in.wc = q[16] & m; x->in.wt = q[17] & m; }       /* the SID packs two settings in a byte */
        q0 += 1u + isz;
        {   const uint32_t nx = p[0] >= 4u ? p[q0] : 0u, fl = fm_plen(q[0]);
            if (nx >= 1u) x->in.duck = p[q0 + 1u] & 15u;
            if (fl && p[0] >= 5u && nx == 1u + fl) fm_unpack(q[0], &x->fm, p + q0 + 2u);
            else if (fl) fm_from_classic(q[0], &x->in, &x->fm);              /* an older project: the old knobs become an operator patch */
            else if (wd_ok(q[0]) && p[0] >= 5u && nx == 1u + wd_plen(c)) wd_unpack(c, p + q0 + 2u);       /* a drawn wave (its length comes from the sound bytes read above) */
            if (p[0] >= 4u) q0 += 1u + nx;
        }
    }
    for (i = 0; i < ev; i++) {
        const uint8_t *e = p + n + i * PROJ_EV;
        step_t *x = STEP_W(e[0], e[1], e[2]);
        x->note = e[3]; x->vel = e[4]; x->gate = e[5];
    }
    n += ev * PROJ_EV;
    if (n < len && p[n] >= 1u && p[n] <= SONG_MAX && n + 1u + p[n] <= len) {       /* the song (older projects have none: the pages in order) */
        song_len = p[n];
        for (i = 0; i < song_len; i++) song[i] = p[n + 1u + i] < pages ? p[n + 1u + i] : (uint8_t)(pages - 1u);
        if (p[0] >= 6u) for (i = 0; i < pages; i++) { const uint32_t b = p[n + 1u + song_len + i]; page_sig[i] = (uint8_t)(b & 7u); page_xb[i] = (uint8_t)(b >> 4 & 7u); page_gl[i] = (uint8_t)((b >> 7 & 1u) | (b >> 3 & 1u) << 1); }
        if (p[0] >= 7u) for (i = 0; i < pages; i++) page_tmp[i] = p[n + 1u + song_len + pages + i];
    } else {
        song_len = pages < SONG_MAX ? pages : SONG_MAX;
        for (i = 0; i < song_len; i++) song[i] = (uint8_t)i;
    }
    return 0;
}
/* undo: LFO steps back one group of edits. `undo_base` is the project as bytes when the last group closed; each closed group leaves a reverse delta (what its edits
 * changed, as the old bytes) in `undo_ring`, the newest last. Two parts are compared apart, the head up to the note count (the sounds, tempo) and the rest (the notes, the
 * song, the meters), so an added note is a few bytes and not everything behind it. An open group has no delta yet: undo goes back to the base. */
#define UNDO_RING 16384u
#define UNDO_MAX 32u
static uint8_t undo_base[PROJ_BANK - PROJ_HDR] POOL, undo_ring[UNDO_RING] POOL;
static uint32_t undo_elen[UNDO_MAX], undo_cnt, undo_used, undo_base_len, undo_base_ok, undo_base_evat;
static void undo_push(void) { }                 /* (a group opens: the base already is how it was) */
static uint32_t undo_part(const uint8_t *o, uint32_t lo, const uint8_t *n, uint32_t ln, uint32_t *pre, uint32_t *suf)     /* the common start and end of two byte strings */
{
    uint32_t a = 0, z = 0;
    while (a < lo && a < ln && o[a] == n[a]) a++;
    while (z < lo - a && z < ln - a && o[lo - 1u - z] == n[ln - 1u - z]) z++;
    *pre = a; *suf = z;
    return (lo - a - z) + (ln - a - z);
}
static void undo_close(void)                    /* a quiet moment: the project as it is now; what changed since the base is one more step back */
{
    uint32_t ln = proj_pack(proj_buf), en = pack_evat, pa, za, pb, zb, oa, na, ob, nb, need, i;
    uint8_t *e;
    if (!ln) { undo_base_ok = 0; undo_cnt = 0; undo_used = 0; return; }
    {   const uint32_t eo = undo_base_evat + 2u, ee = en + 2u;
        undo_part(undo_base, eo, proj_buf, ee, &pa, &za);
        undo_part(undo_base + eo, undo_base_len - eo, proj_buf + ee, ln - ee, &pb, &zb);
        oa = eo - pa - za; na = ee - pa - za; ob = undo_base_len - eo - pb - zb; nb = ln - ee - pb - zb;
        if (!oa && !na && !ob && !nb) { return; }                          /* nothing differs */
        need = 12u + oa + ob;
        if (need <= UNDO_RING) {
            while (undo_cnt && (undo_used + need > UNDO_RING || undo_cnt >= UNDO_MAX)) {       /* the oldest steps make room */
                const uint32_t f = undo_elen[0];
                memmove(undo_ring, undo_ring + f, undo_used - f);
                memmove(undo_elen, undo_elen + 1u, (undo_cnt - 1u) * sizeof undo_elen[0]);
                undo_used -= f; undo_cnt--;
            }
            e = undo_ring + undo_used;
            e[0] = (uint8_t)pa; e[1] = (uint8_t)(pa >> 8); e[2] = (uint8_t)na; e[3] = (uint8_t)(na >> 8); e[4] = (uint8_t)oa; e[5] = (uint8_t)(oa >> 8);
            { const uint32_t o2 = ee + pb;                                      /* where the second part sits in the NEW bytes */
              e[6] = (uint8_t)o2; e[7] = (uint8_t)(o2 >> 8); e[8] = (uint8_t)nb; e[9] = (uint8_t)(nb >> 8); e[10] = (uint8_t)ob; e[11] = (uint8_t)(ob >> 8); }
            memcpy(e + 12, undo_base + pa, oa);
            memcpy(e + 12 + oa, undo_base + eo + pb, ob);
            undo_elen[undo_cnt++] = need; undo_used += need;
        } else { undo_cnt = 0; undo_used = 0; }                                  /* too big to keep: the older steps would not lead back any more */
    }
    (void)i;
    memcpy(undo_base, proj_buf, ln); undo_base_len = ln; undo_base_evat = en; undo_base_ok = 1;
}
static void undo_tick(void)                     /* main loop: a quiet moment closes the group */
{
    if (add_aud_c >= 0) return;                 /* the Add Channel audition has a channel on loan: not part of the project */
    if (!undo_base_ok) { undo_base_len = proj_pack(undo_base); undo_base_evat = pack_evat; undo_base_ok = undo_base_len != 0u; undo_open = 0; return; }
    if (undo_open && fm1_ms - undo_t > 600u) { undo_close(); undo_open = 0; }
}
static void undo_reset(void) { undo_cnt = 0; undo_used = 0; undo_base_ok = 0; undo_open = 0; }
static int undo_go(void)                        /* 0: stepped back one */
{
    if (!undo_base_ok) return -1;
    if (undo_open) {                            /* a group still open: back to how it was when it began */
        if (proj_unpack(undo_base, undo_base_len) != 0) return -1;
        undo_open = 0; proj_dirty = 1; proj_t_edit = fm1_ms;
        return 0;
    }
    if (!undo_cnt) return -1;
    {   const uint32_t f = undo_elen[undo_cnt - 1u], at = undo_used - f;
        const uint8_t *e = undo_ring + at;
        const uint32_t pa = e[0] | (uint32_t)e[1] << 8, na = e[2] | (uint32_t)e[3] << 8, oa = e[4] | (uint32_t)e[5] << 8;
        const uint32_t pb = e[6] | (uint32_t)e[7] << 8, nb = e[8] | (uint32_t)e[9] << 8, ob = e[10] | (uint32_t)e[11] << 8;
        uint32_t len = undo_base_len;
        memcpy(proj_buf, undo_base, len);
        if (pb + nb > len || pa + na > len || len - nb + ob > PROJ_BANK - PROJ_HDR || len - nb + ob - na + oa > PROJ_BANK - PROJ_HDR) return -1;
        memmove(proj_buf + pb + ob, proj_buf + pb + nb, len - pb - nb); memcpy(proj_buf + pb, e + 12 + oa, ob); len = len - nb + ob;       /* the later part first: the earlier one keeps its place */
        memmove(proj_buf + pa + oa, proj_buf + pa + na, len - pa - na); memcpy(proj_buf + pa, e + 12, oa); len = len - na + oa;
        if (proj_unpack(proj_buf, len) != 0) return -1;
        memcpy(undo_base, proj_buf, len); undo_base_len = len; undo_base_evat = pack_evat_of(proj_buf, len);
        undo_used = at; undo_cnt--; undo_open = 0;
    }
    proj_dirty = 1; proj_t_edit = fm1_ms;
    return 0;
}
static void proj_blank(void) { seq_stop(); chan_lock = 1; seq_clear(); chan_lock = 0; undo_reset(); }      /* an empty project: no channels yet */

/* ---- the banks */
static uint32_t proj_base(uint32_t slot, uint32_t bank) { return PROJ_AT + (slot * 2u + bank) * PROJ_BANK; }
typedef struct { uint32_t magic, seq, len, crc; } proj_hdr_t;
static int proj_header(uint32_t slot, uint32_t bank, proj_hdr_t *h)    /* 1: a bank that looks written */
{
    if (pf_read(proj_base(slot, bank), h, sizeof *h)) return 0;
    return h->magic == PROJ_MAGIC && h->len > 0u && h->len <= PROJ_BANK - PROJ_HDR;
}
static int proj_newest(uint32_t slot, proj_hdr_t *h)           /* the newer bank: 0 or 1, or -1 when the slot is empty */
{
    proj_hdr_t a, b;
    int ha = proj_header(slot, 0, &a), hb = proj_header(slot, 1, &b);
    if (ha && hb) { if ((int32_t)(b.seq - a.seq) > 0) { *h = b; return 1; } *h = a; return 0; }
    if (ha) { *h = a; return 0; }
    if (hb) { *h = b; return 1; }
    return -1;
}
static int proj_bank_ok(uint32_t slot, uint32_t bank, const proj_hdr_t *h)    /* the payload into proj_buf and its crc */
{
    if (pf_read(proj_base(slot, bank) + PROJ_HDR, proj_buf, h->len)) return 0;
    return proj_crc(proj_buf, h->len) == h->crc;
}
static int proj_exists(uint32_t slot) { proj_hdr_t h; return proj_newest(slot, &h) >= 0; }

static int proj_load(uint32_t slot)             /* 0: the slot's project is now the open one's data */
{
    proj_hdr_t h;
    int b = proj_newest(slot, &h);
    uint32_t tries;
    for (tries = 0; b >= 0 && tries < 2u; tries++, b ^= 1) {       /* the newer bank, then the older if that one is damaged */
        if (tries && !proj_header(slot, (uint32_t)b, &h)) continue;
        if (proj_bank_ok(slot, (uint32_t)b, &h) && proj_unpack(proj_buf, h.len) == 0) return 0;
    }
    return -1;
}
static uint32_t proj_mark;                      /* a demo's banks carry bit 30 in their number, so an older firmware's project in the slot can be told from it */
#define PROJ_DEMO_BIT 0x40000000u
#define PROJ_USER 0x20000000u                   /* a project the user saved into a demo's slot (the demo was trashed): the slot is theirs, the demo is never made over it */
/* The demo slots (0 and 1) hold a DEMO (locked), or were freed by trashing it: then the slot is an ordinary one. Freed + empty = a tombstone in the first bank's header
 * (a magic no project has); freed + used = a project whose number carries PROJ_USER. Another firmware's data over the slot wipes either mark: the demo is simply made again. */
#define PROJ_TOMB 0x424D4F54u                   /* "TOMB" */
enum { DS_DEMO, DS_EMPTY, DS_USED, DS_NONE };   /* a demo slot: the demo is there / freed and empty / freed and holds the user's project / nothing written yet */
static uint8_t demo_here[2];                    /* the demo is in slot 0 / 1 (kept in step with the flash: proj_demo_refresh) */
static uint8_t proj_lock;                       /* what is open is a locked demo that is not in its slot (the Brothers Link demo): never saved */
static uint32_t proj_slot_state(uint32_t slot)
{
    proj_hdr_t h;
    int b = proj_newest(slot, &h);
    if (b >= 0) return h.seq & PROJ_USER ? DS_USED : DS_DEMO;
    return !pf_read(proj_base(slot, 0), &h, sizeof h) && h.magic == PROJ_TOMB ? DS_EMPTY : DS_NONE;
}
static void proj_demo_refresh(void) { demo_here[0] = proj_slot_state(0) == DS_DEMO; demo_here[1] = proj_slot_state(1) == DS_DEMO; }
static int proj_is_demo(uint32_t slot) { return slot < PROJ_DEMOS && demo_here[slot]; }    /* the locked rules (never saved, no USB write ...) belong to the demo, not to the slot number */
static int proj_write_buf(uint32_t slot, uint32_t len)     /* proj_buf's first len bytes into the slot's older bank */
{
    proj_hdr_t h, nh;
    int b = proj_newest(slot, &h);
    uint32_t bank = b < 0 ? 0u : (uint32_t)(b ^ 1), i, sectors, base = proj_base(slot, bank);
    if (!len) return -1;                        /* too big for a bank */
    sectors = (PROJ_HDR + len + 0xFFFu) / 0x1000u;
    for (i = 0; i < sectors; i++) if (pf_erase(base + i * 0x1000u)) return -1;
    if (pf_write(base + PROJ_HDR, proj_buf, len)) return -1;
    nh.magic = PROJ_MAGIC; nh.seq = (b < 0 ? 1u : h.seq + 1u) | (proj_mark ? proj_mark : slot < PROJ_DEMOS ? PROJ_USER : 0u); nh.len = len; nh.crc = proj_crc(proj_buf, len);
    if (pf_write(base, &nh, sizeof nh)) return -1;
    return 0;
}
static int proj_save(uint32_t slot)             /* a demo is never saved over (and nothing is saved from a locked demo); a freed demo slot saves like any other */
{
    if (proj_is_demo(slot) || (proj_lock && slot == proj_cur)) return 0;
    return proj_write_buf(slot, proj_pack(proj_buf));
}
static void proj_open(uint32_t slot)            /* switch projects: stop, keep what is unsaved, load (or start blank) */
{
    seq_stop();
    if (proj_dirty && proj_save(proj_cur) == 0) proj_dirty = 0;
    proj_loaded = proj_load(slot) == 0;
    if (!proj_loaded) proj_blank();
    proj_cur = (uint8_t)slot; proj_dirty = 0; proj_lock = 0; undo_reset();
}
static void proj_clear(uint32_t slot)           /* an empty slot: both banks' first sector */
{
    pf_erase(proj_base(slot, 0));
    pf_erase(proj_base(slot, 1));
}

static void proj_trash(uint32_t slot)           /* a demo slot is freed: empty, with the tombstone (also what clearing the user's project in a freed slot does, so the demo does not come back) */
{
    proj_hdr_t h;
    proj_clear(slot);
    h.magic = PROJ_TOMB; h.seq = 0; h.len = 0; h.crc = 0;
    pf_write(proj_base(slot, 0), &h, sizeof h);
    proj_demo_refresh();
}
static void proj_free(uint32_t slot) { if (slot < PROJ_DEMOS) proj_trash(slot); else proj_clear(slot); }       /* clear a slot the way its kind needs */
static uint32_t proj_demos_free_empty(void) { return (uint32_t)(proj_slot_state(0) == DS_EMPTY) + (uint32_t)(proj_slot_state(1) == DS_EMPTY); }
static uint32_t proj_demos_free_used(void) { return (uint32_t)(proj_slot_state(0) == DS_USED) + (uint32_t)(proj_slot_state(1) == DS_USED); }

/* what a slot looks like in the picker: a row per channel (its chip), a bit per step of page 1 */
static void proj_preview(uint32_t slot, uint16_t *rows, uint8_t *chips, uint32_t *nch)
{
    uint32_t c, i, ev, n, isz;
    proj_hdr_t h;
    int b;
    *nch = 0;
    memset(rows, 0, MAXCH * sizeof rows[0]);
    if (slot == proj_cur) {                     /* the open one: what is in memory, saved or not */
        *nch = chan_n;
        for (c = 0; c < chan_n; c++) {
            chips[c] = KIND_CHIP[chan[c].kind];
            for (i = 0; i < SEQ_LEN; i++) if (STEP_R(0, c, i)->note) rows[c] |= (uint16_t)(1u << i);
        }
        return;
    }
    b = proj_newest(slot, &h);
    if (b < 0 || pf_read(proj_base(slot, (uint32_t)b) + PROJ_HDR, proj_buf, h.len)) return;
    if (h.len < 7u || proj_buf[0] < 2u || proj_buf[0] > 7u || proj_buf[4] > MAXCH) return;
    isz = proj_buf[0] == 2u ? 14u : PROJ_INST;
    *nch = proj_buf[4];
    for (c = 0, n = 5u; c < *nch; c++) {                    /* (version 4 and later: a length byte and extra bytes follow each channel's sound) */
        if (n + 1u + isz > h.len) { *nch = 0; return; }
        chips[c] = proj_buf[n] < KINDS ? KIND_CHIP[proj_buf[n]] : 0u;
        n += 1u + isz;
        if (proj_buf[0] >= 4u) { if (n >= h.len) { *nch = 0; return; } n += 1u + proj_buf[n]; }
    }
    if (h.len < n + 2u) { *nch = 0; return; }
    ev = (uint32_t)proj_buf[n] | (uint32_t)proj_buf[n + 1u] << 8;
    n += 2u;
    for (i = 0; i < ev && n + (i + 1u) * PROJ_EV <= h.len; i++) {
        const uint8_t *e = proj_buf + n + i * PROJ_EV;
        if (e[0] == 0u && e[1] < *nch && e[2] < SEQ_LEN) rows[e[1]] |= (uint16_t)(1u << e[2]);
    }
}

/* slots 0 and 1 are the demos (Korobeiniki, the console symphony): made again at every boot if they are not exactly what the firmware makes, so an update or a damaged slot never leaves two */
#include "demo2.h"
static int proj_copy(uint32_t from, uint32_t to);
static void seq_symphony(void) { proj_unpack(DEMO2, sizeof DEMO2); }
static void proj_demo_sync(void)
{
    proj_hdr_t h;
    uint32_t len, st, f;
    seq_stop();
    seq_tetris();                               /* what was in memory is gone: this runs before the first project is opened */
    len = proj_pack(proj_buf);
    st = proj_slot_state(0);
    if ((st == DS_DEMO || st == DS_NONE) && (proj_newest(0, &h) < 0 || h.len != len || h.crc != proj_crc(proj_buf, len))) { proj_mark = PROJ_DEMO_BIT; proj_write_buf(0, len); proj_mark = 0; }
    if (proj_slot_state(1) == DS_DEMO && proj_newest(1, &h) >= 0 && !(h.seq & PROJ_DEMO_BIT)) {         /* a project of an older firmware sits in slot 1: it moves to a free slot at the end */
        for (f = PROJ_SLOTS - 1u; f > 1u && proj_exists(f); f--) {}
        if (f > 1u) proj_copy(1, f);
    }
    seq_stop();
    seq_symphony();
    len = proj_pack(proj_buf);
    st = proj_slot_state(1);
    if ((st == DS_DEMO || st == DS_NONE) && !(st == DS_DEMO && proj_newest(1, &h) >= 0 && (h.seq & PROJ_DEMO_BIT) && h.len == len && h.crc == proj_crc(proj_buf, len))) {
        proj_mark = PROJ_DEMO_BIT; proj_write_buf(1, len); proj_mark = 0;
    }
    proj_demo_refresh();
}
static void proj_demos_restore(void)            /* a freed demo slot that is empty gets its demo back; one that holds the user's project is left alone (what is in memory is replaced: the caller reloads its project) */
{
    uint32_t s;
    for (s = 0; s < PROJ_DEMOS; s++) if (proj_slot_state(s) == DS_EMPTY) proj_clear(s);
    proj_demo_sync();
}
static void proj_demos_restore_all(void)        /* Factory Reset: the user's projects in freed demo slots go with the rest, then both demos are there */
{
    uint32_t s;
    for (s = 0; s < PROJ_DEMOS; s++) { const uint32_t st = proj_slot_state(s); if (st == DS_EMPTY || st == DS_USED) proj_clear(s); }
    proj_demo_sync();
}
static int proj_copy(uint32_t from, uint32_t to)    /* a project into another slot (the open one as it is in memory) */
{
    proj_hdr_t h;
    int b;
    uint32_t len;
    if (from == proj_cur && !proj_is_demo(from) && !proj_lock) { len = proj_pack(proj_buf); return proj_write_buf(to, len); }
    b = proj_newest(from, &h);
    if (b < 0 || !proj_bank_ok(from, (uint32_t)b, &h)) return -1;
    return proj_write_buf(to, h.len);
}
