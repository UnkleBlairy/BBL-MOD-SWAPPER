/* SPDX-License-Identifier: GPL-3.0-only */
/* Chipbox: sound chips for the FM-1: NES, Game Boy and Master System voices you add as channels, a rack of steps, projects in flash.
 *
 *   PRESETS          down the channels (in the rack the last row adds one: OCT+ on it)
 *   ALGORITHM        rack: the page (past the last makes a new one)     chip screen: the knobs' page (tone / envelope / arp)
 *   SELECT           rack: the cursor along the steps
 *   KNOBS 1..4       chip screen: the sound of the channel; rack: knob 1 is the tempo
 *   keys             play the selected channel (and, in the rack, write it on the step under the cursor; the same note again clears it)
 *   EDIT hold        rack: remove the channel (OCT+ yes, OCT- no)
 *   HOME             tap: the next view (rack, chip, song); hold: the projects
 *   PLAY             the rack and the chip: the page round and round; the song screen: the song, page after page
 *   PLAY / SAVE / GLO   play stop, save, help       OCT- OCT+   octave (on their LEDs)       MASTER   volume
 *   USB-MIDI         CC 102 = play (64 and up) or stop, CC 103 = tempo / 2, CC 104 = save, CC 105 = open a project (0..7), CC 106 / 107 = add a channel of kind d2 / remove the last;
 *                    MIDI channel n plays channel n; program change picks the channel; the device sends CC 100 = CPU %
 *                    (worst block since boot) and CC 101 = open project | 16 if unsaved | 32 if loaded from flash
 *
 * Integers only: no float, no 64-bit division. tests/host.c runs this file on a computer. */
#ifndef CHIPBOX_HOST
#define OTA_PROJ_IO
#endif
#include <stdint.h>
#ifdef FELUCCA_ID                                            /* firmware/ble/ble.c: the brothers' Bluetooth link, its own unit */
extern volatile uint8_t brothers_mode;                      /* 0 off, 1 lead, 2 follow */
extern void brothers_set(uint32_t mode);
extern void brothers_poll(void);
extern uint32_t brothers_link(void);
extern void brothers_lead_tick(uint32_t off, uint32_t per);
extern uint32_t brothers_bpm(void);
extern void brothers_lead_set(uint32_t pat, uint32_t kick, uint32_t fx, uint32_t scale, uint32_t swing);
extern uint32_t brothers_pat(void);
extern uint32_t brothers_fx(void);
extern uint32_t brothers_scale(void);
extern uint32_t brothers_detect(const uint8_t *notes, uint32_t n);
extern uint32_t brothers_snap(uint32_t note, uint32_t scale);
extern uint32_t brothers_duck(uint32_t depth);
extern void brothers_lead_run(uint32_t run);
#else
static uint8_t brothers_mode;
static void brothers_set(uint32_t mode) { brothers_mode = (uint8_t)mode; }
static void brothers_poll(void) {}
static uint32_t brothers_link(void) { return 0; }
static void brothers_lead_tick(uint32_t off, uint32_t per) { (void)off; (void)per; }
static uint32_t brothers_bpm(void) { return 0; }
static void brothers_lead_set(uint32_t pat, uint32_t kick, uint32_t fx, uint32_t scale, uint32_t swing) { (void)pat; (void)kick; (void)fx; (void)scale; (void)swing; }
static uint32_t brothers_pat(void) { return 0xFFu; }
static uint32_t brothers_fx(void) { return 0u; }
static uint32_t brothers_scale(void) { return 0u; }
static uint32_t brothers_detect(const uint8_t *notes, uint32_t n) { (void)notes; (void)n; return 0u; }
static uint32_t brothers_snap(uint32_t note, uint32_t scale) { (void)scale; return note; }
static uint32_t brothers_duck(uint32_t depth) { (void)depth; return 256u; }
static void brothers_lead_run(uint32_t run) { (void)run; }
#endif
static uint8_t btq[32];                                      /* the brothers' link's clock / start / stop, in order, for the main loop (as USB MIDI's) */
static volatile uint8_t btq_w, btq_r;
void bt_rt(uint32_t st) { if ((uint8_t)(btq_w - btq_r) < 32u) btq[btq_w++ & 31u] = (uint8_t)st; }
static int bt_get(uint8_t *st, uint8_t *d1, uint8_t *d2)
{
    if (btq_r == btq_w) return 0;
    *st = btq[btq_r++ & 31u]; *d1 = 0x55u; *d2 = 0;
    return 1;
}
#include "platform.c"
#ifdef CHIPBOX_HOST
#define FM1_TICKS_PER_US 24u
static uint32_t fm1_ticks(void) { return 0; }
#endif
#include "chips.c"
static uint32_t bt_fx_cur;                                   /* the leader's punch-in pads we hold for it */
/* the brothers' shared punch-in effects are pads 1-8, bit n = pad n + 1: stop, repeat, low-pass, high-pass, echo, reverb, crush, gate */
static uint32_t fx_to_shared(uint32_t m) { return m & 0xFFu; }
static uint32_t fx_from_shared(uint32_t s) { return s & 0xFFu; }
static uint32_t chg_kind;                       /* the console a channel waits to change to, while the window asks (rack_rm == 2) */
static uint32_t chg_ch = 255u;                  /* the channel whose console the Add list is changing (255: adding a new one) */
static int add_aud_c = -1;                      /* the Add Channel audition's channel on loan (addmenu.c); -1 none */
#include "proj.c"
#include "projio.c"

/* ---- one look per chip */
typedef struct {
    const char *name, *ch[4];
    uint16_t bg, bar, fg, acc, dim, key, lit;
} theme_t;
static const theme_t THEME[CHIPS] = {
    {"NES", {"PU1", "PU2", "TRI"},
     RGB(58, 58, 57), RGB(44, 44, 43), RGB(201, 199, 195), RGB(154, 42, 38), RGB(111, 100, 89), RGB(201, 199, 195), RGB(154, 42, 38)},       /* the console's own colours: charcoal, warm grey, brown-grey, red */
    {"GAME BOY", {"PU1", "PU2", "WAV"},
     RGB(15, 56, 15), RGB(48, 98, 48), RGB(155, 188, 15), RGB(155, 188, 15), RGB(110, 150, 30), RGB(139, 172, 15), RGB(15, 56, 15)},
    {"SMS", {"TN1", "TN2", "TN3"},
     RGB(8, 16, 60), RGB(22, 40, 110), RGB(240, 240, 255), RGB(70, 170, 255), RGB(70, 90, 150), RGB(220, 226, 245), RGB(70, 170, 255)},
    {"PC ENGINE", {"WV1", "WV2", "WV3"},                                          /* the console's white and the orange of its logo, on a warm dark */
     RGB(34, 28, 30), RGB(22, 18, 20), RGB(234, 228, 216), RGB(242, 132, 34), RGB(120, 104, 94), RGB(234, 228, 216), RGB(242, 132, 34)},
    {"ATARI", {"TIA", "TIA", "TIA"},                                              /* the 2600's woodgrain and cream, sand for the notes */
     RGB(38, 26, 18), RGB(26, 17, 11), RGB(244, 226, 196), RGB(214, 158, 88), RGB(128, 96, 66), RGB(244, 226, 196), RGB(214, 158, 88)},
    {"KONAMI", {"PU1", "PU2", "SAW"},                                             /* the Famicom's deep red and gold, on a dark plum */
     RGB(34, 18, 34), RGB(22, 11, 24), RGB(240, 232, 214), RGB(240, 200, 40), RGB(130, 100, 120), RGB(240, 232, 214), RGB(240, 200, 40)},
    {"AY-3-8910", {"AY1", "AY2", "AY3"},                                                 /* a Spectrum: black, a teal accent, the rainbow in the rule */
     RGB(12, 12, 14), RGB(4, 4, 6), RGB(236, 236, 236), RGB(40, 210, 190), RGB(90, 100, 100), RGB(236, 236, 236), RGB(40, 210, 190)},
    {"MEGA DRIVE", {"FM1", "FM2", "FM3"},                                         /* black, Sega blue, a violet for the notes */
     RGB(10, 10, 16), RGB(3, 3, 8), RGB(240, 240, 246), RGB(150, 112, 250), RGB(80, 74, 120), RGB(240, 240, 246), RGB(150, 112, 250)},
    {"VIRTUAL BOY", {"VB1", "VB2", "VB3"},                                        /* red on black, the only colour its screens had */
     RGB(6, 0, 0), RGB(0, 0, 0), RGB(255, 70, 60), RGB(255, 36, 30), RGB(120, 24, 22), RGB(255, 70, 60), RGB(255, 36, 30)},
    {"ATARI 8-BIT", {"PK1", "PK2", "PK3"},                                        /* the 800's plum-black, pink for the notes */
     RGB(30, 14, 26), RGB(18, 8, 16), RGB(240, 226, 232), RGB(236, 88, 140), RGB(124, 76, 100), RGB(240, 226, 232), RGB(236, 88, 140)},
    {"PC SPEAKER", {"SP1", "SP2", "SP3"},                                         /* the BIOS: DOS blue, white text */
     RGB(0, 0, 112), RGB(0, 0, 70), RGB(228, 228, 232), RGB(255, 255, 255), RGB(86, 86, 170), RGB(228, 228, 232), RGB(255, 255, 255)},
    {"ADLIB", {"OP1", "OP2", "OP3"},                                              /* a sound card: a dark green board, gold contacts */
     RGB(6, 26, 22), RGB(3, 16, 14), RGB(230, 236, 224), RGB(236, 184, 60), RGB(70, 110, 90), RGB(230, 236, 224), RGB(236, 184, 60)},
    {"NAMCO WSG", {"WS1", "WS2", "WS3"},                                          /* the arcade: black, the maze's blue bars, Pac-Man yellow */
     RGB(4, 4, 18), RGB(8, 8, 56), RGB(236, 236, 255), RGB(255, 226, 0), RGB(60, 70, 160), RGB(236, 236, 255), RGB(255, 226, 0)},
    {"NAMCO 163", {"N1", "N2", "N3"},                                             /* a cartridge: slate with coral */
     RGB(22, 26, 40), RGB(12, 15, 26), RGB(236, 238, 246), RGB(255, 112, 96), RGB(96, 104, 134), RGB(236, 238, 246), RGB(255, 112, 96)},
    {"SUNSOFT 5B", {"5B1", "5B2", "5B3"},                                         /* a cartridge: night blue, a sun */
     RGB(10, 14, 34), RGB(5, 8, 22), RGB(244, 240, 226), RGB(255, 196, 36), RGB(100, 96, 80), RGB(244, 240, 226), RGB(255, 196, 36)},
    {"NES MMC5", {"MP1", "MP2", "MP3"},                                           /* a cartridge: slate green, mint */
     RGB(18, 30, 30), RGB(10, 18, 18), RGB(222, 236, 230), RGB(96, 214, 168), RGB(84, 118, 108), RGB(222, 236, 230), RGB(96, 214, 168)},
    {"FAMICOM DISK", {"FD1", "FD2", "FD3"},                                       /* the disk drive: deep blue, orange */
     RGB(12, 20, 46), RGB(6, 11, 30), RGB(236, 238, 246), RGB(255, 142, 40), RGB(80, 94, 140), RGB(236, 238, 246), RGB(255, 142, 40)},
    {"MSX SCC", {"SC1", "SC2", "SC3"},                                            /* a game cartridge: near black, lime */
     RGB(10, 14, 22), RGB(5, 8, 14), RGB(232, 240, 226), RGB(190, 232, 48), RGB(86, 106, 70), RGB(232, 240, 226), RGB(190, 232, 48)},
    {"MSX MUSIC", {"FM1", "FM2", "FM3"},                                          /* the FM cartridge: ocean blue, cyan */
     RGB(8, 26, 40), RGB(4, 15, 26), RGB(228, 242, 248), RGB(78, 218, 255), RGB(70, 104, 124), RGB(228, 242, 248), RGB(78, 218, 255)},
    {"KONAMI VRC7", {"VR1", "VR2", "VR3"},                                        /* a cartridge: warm black, vermilion */
     RGB(28, 22, 22), RGB(17, 13, 13), RGB(240, 230, 226), RGB(255, 98, 66), RGB(120, 92, 88), RGB(240, 230, 226), RGB(255, 98, 66)},
    {"YM2151", {"OM1", "OM2", "OM3"},                                             /* the arcade board: black violet, magenta */
     RGB(30, 8, 32), RGB(18, 4, 20), RGB(244, 226, 244), RGB(255, 70, 210), RGB(124, 70, 120), RGB(244, 226, 244), RGB(255, 70, 210)},
    {"OPL3", {"O31", "O32", "O33"},                                               /* a sound card: royal blue board, silver */
     RGB(10, 26, 64), RGB(5, 15, 42), RGB(236, 240, 250), RGB(210, 226, 255), RGB(78, 100, 150), RGB(236, 240, 250), RGB(210, 226, 255)},
    {"WONDERSWAN", {"SW1", "SW2", "SW3"},                                         /* a handheld: indigo, lavender */
     RGB(22, 18, 62), RGB(12, 9, 42), RGB(236, 234, 250), RGB(150, 160, 255), RGB(96, 92, 150), RGB(236, 234, 250), RGB(150, 160, 255)},
    {"SAM COUPE", {"SA1", "SA2", "SA3"},                                          /* a home computer: warm black, yellow */
     RGB(24, 18, 8), RGB(14, 10, 4), RGB(250, 244, 226), RGB(255, 226, 60), RGB(120, 106, 70), RGB(250, 244, 226), RGB(255, 226, 60)},
    {"VIC-20", {"VI1", "VI2", "VI3"},                                             /* the blue screen, a pale cyan */
     RGB(30, 44, 120), RGB(16, 26, 84), RGB(236, 244, 255), RGB(160, 230, 255), RGB(90, 108, 176), RGB(236, 244, 255), RGB(160, 230, 255)},
    {"PLUS/4", {"TD1", "TD2", "TD3"},                                             /* a grey case, a light green */
     RGB(36, 36, 42), RGB(22, 22, 27), RGB(238, 240, 238), RGB(140, 255, 120), RGB(110, 112, 118), RGB(238, 240, 238), RGB(140, 255, 120)},
    {"ATARI LYNX", {"LY1", "LY2", "LY3"},                                         /* a black handheld, orange */
     RGB(10, 14, 12), RGB(4, 7, 6), RGB(238, 240, 236), RGB(255, 150, 30), RGB(110, 90, 60), RGB(238, 240, 236), RGB(255, 150, 30)},
    {"PC-98", {"PC1", "PC2", "PC3"},                                              /* a beige Japanese PC, peach */
     RGB(34, 24, 28), RGB(21, 14, 17), RGB(246, 238, 228), RGB(255, 170, 120), RGB(128, 98, 96), RGB(246, 238, 228), RGB(255, 170, 120)},
    {"NEO GEO", {"NG1", "NG2", "NG3"},                                            /* black and crimson, the MVS cabinet */
     RGB(24, 8, 10), RGB(13, 3, 5), RGB(246, 232, 232), RGB(255, 40, 70), RGB(128, 60, 70), RGB(246, 232, 232), RGB(255, 40, 70)},
    {"NEO GEO POCKET", {"NP1", "NP2", "NP3"},                                     /* a handheld: deep violet, hot pink */
     RGB(22, 16, 34), RGB(12, 8, 22), RGB(240, 234, 248), RGB(255, 110, 170), RGB(110, 90, 130), RGB(240, 234, 248), RGB(255, 110, 170)},
    {"MSX-AUDIO", {"MA1", "MA2", "MA3"},                                          /* a cartridge: dark green, light green */
     RGB(8, 34, 30), RGB(4, 21, 18), RGB(234, 246, 238), RGB(120, 230, 120), RGB(72, 112, 98), RGB(234, 246, 238), RGB(120, 230, 120)},
    {"TX81Z", {"TX1", "TX2", "TX3"},                                              /* a rack synth: charcoal, an LCD cream */
     RGB(30, 26, 22), RGB(18, 15, 12), RGB(246, 240, 224), RGB(255, 235, 170), RGB(120, 108, 88), RGB(246, 240, 224), RGB(255, 235, 170)},
    {"SN76477", {"S71", "S72", "S73"},                                            /* a vector arcade: black, cyan */
     RGB(4, 8, 16), RGB(1, 3, 9), RGB(226, 248, 252), RGB(60, 255, 255), RGB(50, 100, 112), RGB(226, 248, 252), RGB(60, 255, 255)},
    {"NAMCO SYSTEM 1", {"C31", "C32", "C33"},                                     /* a red cabinet, a gold marquee */
     RGB(36, 10, 12), RGB(22, 5, 7), RGB(252, 240, 224), RGB(255, 186, 60), RGB(136, 80, 70), RGB(252, 240, 224), RGB(255, 186, 60)},
    {"KORG POLY-800", {"OR1", "OR2", "OR3"},                                      /* a synth: charcoal, raspberry */
     RGB(24, 18, 26), RGB(14, 10, 16), RGB(246, 234, 240), RGB(255, 60, 120), RGB(122, 80, 98), RGB(246, 234, 240), RGB(255, 60, 120)},
    {"ZX SPECTRUM", {"ZX1", "ZX2", "ZX3"},                                        /* black, a Spectrum red, the rainbow in the rule */
     RGB(8, 8, 10), RGB(2, 2, 4), RGB(240, 240, 240), RGB(236, 60, 56), RGB(100, 100, 106), RGB(240, 240, 240), RGB(236, 60, 56)},
    {"YM2203", {"FM1", "FM2", "FM3"},                                             /* a PC-88's blue-grey case, a bright steel blue */
     RGB(26, 34, 46), RGB(16, 22, 32), RGB(226, 232, 240), RGB(96, 176, 255), RGB(96, 112, 134), RGB(226, 232, 240), RGB(96, 176, 255)},
    {"SID", {"SD1", "SD2", "SD3"},                                                /* the C64's blue and its light blue */
     RGB(53, 40, 121), RGB(40, 30, 96), RGB(214, 208, 255), RGB(120, 208, 222), RGB(112, 98, 176), RGB(214, 208, 255), RGB(120, 208, 222)},
};

static void text_on(uint32_t x, uint32_t y, uint32_t w, const felucca_font_t *f, const char *s, uint16_t c, uint16_t bg, int align)
{
    int32_t tw = text_w(f, s), tx = align == 1 ? ((int32_t)w - tw) / 2 : align == 2 ? (int32_t)w - tw : 0;
    cv_begin(w, f->h, bg);
    cv_text(tx, 0, f, s, c);
    cv_blit(x, y);
}

/* ---- the sound: the chips, timed so the budget shows */
static volatile uint32_t cpu_max;               /* worst audio block so far, in ticks */
static void app_audio(int32_t *out, uint32_t n)
{
    uint32_t t0 = fm1_ticks(), dt;
    chip_render(out, n);
    dt = (uint32_t)(fm1_ticks() - t0);
    if (dt > cpu_max) cpu_max = dt;
}
static int quiet(void)
{
    uint32_t c;
    for (c = 0; c < chan_n; c++)
        if (chip_level(c)) return 0;
    return 1;
}

/* ---- parameters under the knobs */
static uint32_t has_wave(uint32_t c) { return chan[c].kind == KD_GB_WAV || chan[c].kind == KD_PCE || chan[c].kind == KD_VB_WAV || chan[c].kind == KD_WSG || chan[c].kind == KD_N163 || chan[c].kind == KD_FDS || chan[c].kind == KD_SCC || chan[c].kind == KD_WS || chan[c].kind == KD_C30; }
static uint32_t has_fm(uint32_t c) { return chan[c].kind == KD_MD || chan[c].kind == KD_OPL || chan[c].kind == KD_OPM || chan[c].kind == KD_OPL3 || chan[c].kind == KD_PC98_FM || chan[c].kind == KD_NEO_FM || chan[c].kind == KD_OPL1 || chan[c].kind == KD_OPZ || chan[c].kind == KD_OPN_FM; }                              /* page 4 is its operators */
static uint32_t has_vol(uint32_t c) { return chan[c].kind != KD_NES_TRI && chan[c].kind != KD_SPK && chan[c].kind != KD_ZX; }                       /* the NES triangle has no level control */
static uint32_t has_duty(uint32_t c) { return chan[c].kind == KD_NES_PU || chan[c].kind == KD_GB_PU || chan[c].kind == KD_VRC6_PU || chan[c].kind == KD_MMC5 || chan[c].kind == KD_ZX; }
static uint32_t has_buzz(uint32_t c) { return chan[c].kind == KD_S5B || chan[c].kind == KD_FDS || chan[c].kind == KD_OPL3 || chan[c].kind == KD_OPZ || chan[c].kind == KD_SN77 || chan[c].kind == KD_MSM; }                        /* knob 4 on the tone page picks one of four (the 5B's buzz, the Disk System's modulator) */
#include "fmui.c"
static uint32_t dr_cur, dr_brush, dr_sym;                        /* DRAW: the sample under the cursor, the brush (1, 2, 4, 8 samples: 0..3), the mirror (0 off, 1 mirror, 2 flipped, 3 repeat) */
/* ---- extra pages: knobs a chip gained later, on inst_t fields an old project leaves at 0 (so the old sound is the knob's 0); label, field, largest value, how it is drawn */
enum { XF_WAVE, XF_DUTY, XF_WF, XF_WC, XF_WT, XF_PAN, XF_VSPD, XF_SWEEP, XF_NONE };
enum { XS_BAR, XS_SWEEP, XS_BOXES, XS_SWITCH, XS_LEN };             /* a bar; centred (the sweep); one of n + 1 boxes; off / on; the N163's length (duty 0 = 32) */
typedef struct { const char *lab; uint8_t f, mx, st; } xk_t;
typedef struct { xk_t k[4]; } xp_t;
#define XK(l, f, m, s) {l, f, m, s}
#define XNO {"", XF_NONE, 0, 0}
static const xp_t XP_AY[1] = {{{XK("PERIOD", XF_WF, 15, XS_BAR), XK("BUZZ", XF_WC, 7, XS_BOXES), XK("BRATIO", XF_WT, 15, XS_BAR), XNO}}};
static const xp_t XP_SAA[1] = {{{XK("ENV", XF_WF, 6, XS_BAR), XK("ERES", XF_WC, 1, XS_SWITCH), XK("NRATE", XF_WT, 3, XS_BOXES), XNO}}};
static const xp_t XP_POK[1] = {{{XK("HPF", XF_WF, 15, XS_BAR), XK("CLOCK", XF_WC, 2, XS_BOXES), XNO, XNO}}};
static const xp_t XP_LYN[1] = {{{XK("INTEG", XF_WF, 1, XS_SWITCH), XK("TAPS", XF_WC, 15, XS_BAR), XK("BAL", XF_WT, 9, XS_BAR), XNO}}};
static const xp_t XP_SN7[1] = {{{XK("FILTER", XF_WF, 15, XS_BAR), XK("RATE", XF_WC, 15, XS_BAR), XK("DEPTH", XF_WT, 15, XS_BAR), XK("DUTY", XF_DUTY, 15, XS_BAR)}}};
static const xp_t XP_N163[1] = {{{XK("LENGTH", XF_DUTY, 4, XS_LEN), XNO, XNO, XNO}}};
static const xp_t XP_SW[1] = {{{XK("SWEEP", XF_SWEEP, 16, XS_SWEEP), XNO, XNO, XNO}}};
static const xp_t *x_tab(uint32_t kind, uint32_t *n)
{
    *n = 1;
    switch (kind) {
    case KD_AY: case KD_PC98_SSG: case KD_NEO_SSG: case KD_OPN_SSG: return XP_AY;
    case KD_SAA: return XP_SAA;
    case KD_POKEY: return XP_POK;
    case KD_LYNX: return XP_LYN;
    case KD_SN77: return XP_SN7;
    case KD_N163: return XP_N163;
    case KD_GB_PU: case KD_GB_WAV: case KD_PCE: case KD_VB_WAV: case KD_NGP: return XP_SW;
    default: *n = 0; return 0;
    }
}
static uint32_t x_n(uint32_t kind) { uint32_t n; x_tab(kind, &n); return n; }
static const int8_t SWT[17] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20, 26, 34, 46, 64};      /* the sweep knob's steps: the old slope up to 8, then faster (a real 2A03 sweep moves several semitones a step) */
static uint32_t sw_real(uint32_t kind) { return kind == KD_NES_PU || kind == KD_GB_PU || kind == KD_GB_WAV || kind == KD_PCE || kind == KD_VB_WAV || kind == KD_NGP; }
static int32_t sw_pos(int32_t v)                    /* where on the knob a stored sweep sits: the nearest step */
{
    int32_t a = v < 0 ? -v : v, p = 0, i;
    for (i = 1; i < 17; i++) if ((SWT[i] > a ? SWT[i] - a : a - SWT[i]) < (SWT[p] > a ? SWT[p] - a : a - SWT[p])) p = i;
    return v < 0 ? -p : p;
}
static int8_t sw_step(int32_t v, int32_t d)
{
    int32_t p = sw_pos(v) + d;
    p = p < -16 ? -16 : p > 16 ? 16 : p;
    return (int8_t)(p < 0 ? -SWT[-p] : SWT[p]);
}
static uint8_t *xf_ptr(inst_t *in, uint32_t f)
{
    switch (f) {
    case XF_WAVE: return &in->wave; case XF_DUTY: return &in->duty; case XF_WF: return &in->wf; case XF_WC: return &in->wc;
    case XF_WT: return &in->wt; case XF_PAN: return &in->pan; case XF_VSPD: return &in->vib_spd; default: return (uint8_t *)&in->sweep;
    }
}
static int32_t x_val(const inst_t *in, const xk_t *x)          /* the knob's position */
{
    const uint8_t *p = xf_ptr((inst_t *)in, x->f);
    if (x->st == XS_SWEEP) return sw_pos(in->sweep);
    if (x->st == XS_LEN) return *p ? (int32_t)*p - 1 : 3;
    return *p;
}
static void x_knob(uint32_t c, uint32_t pg, uint32_t k, int32_t d)
{
    uint32_t n;
    const xk_t *x = &x_tab(chan[c].kind, &n)[pg < n ? pg : 0].k[k];
    uint8_t *p;
    int32_t v;
    if (x->f == XF_NONE) return;
    p = xf_ptr(&chan[c].in, x->f);
    if (chan[c].kind == KD_N163 && x->f == XF_DUTY) {                   /* LENGTH on a drawn wave: the samples are picked again */
        const uint32_t ol = wd_n(c);
        int32_t nv = x_val(&chan[c].in, x) + d;
        nv = nv < 0 ? 0 : nv > (int32_t)x->mx ? (int32_t)x->mx : nv;
        *p = (uint8_t)(nv + 1);
        wd_resize(c, ol, wd_n(c));
        return;
    }
    if (x->st == XS_SWEEP) { chan[c].in.sweep = sw_step(chan[c].in.sweep, d); return; }
    v = x_val(&chan[c].in, x) + d;
    v = v < 0 ? 0 : v > (int32_t)x->mx ? (int32_t)x->mx : v;
    *p = (uint8_t)(x->st == XS_LEN ? v + 1 : v);
}
static uint32_t base_pages(uint32_t c) { return IS_DRUM(chan[c].kind) ? 1u : chan[c].kind == KD_SID ? 5u : chan[c].kind == KD_FDS ? 5u : has_wave(c) || has_fm(c) || chan[c].kind == KD_S5B ? 4u : 3u; }       /* the SID has two more: pulse and sync, filter */                  /* pages of knobs */
static uint32_t wd_pg(uint32_t c) { return wd_ok(chan[c].kind) ? base_pages(c) + x_n(chan[c].kind) : 99u; }          /* the DRAW page: the last one, on a kind with a writable wave */
static uint32_t pages(uint32_t c) { return IS_FMK(chan[c].kind) ? fm_pages(c, fm_foc) : base_pages(c) + x_n(chan[c].kind) + (wd_ok(chan[c].kind) ? 1u : 0u); }
static uint32_t wd_cmax(uint32_t c) { return wd_n(c) - 1u; }
static uint32_t wd_dsteps(uint32_t kind) { return wd_top(kind) > 63u ? 4u : 1u; }               /* a click: one step, four on the 8 bit wave */
static uint32_t has_k1(uint32_t c)                                                               /* knob 1 does something on the tone page */
{
    return has_wave(c) || has_duty(c) || has_fm(c) || chan[c].kind == KD_SID || chan[c].kind == KD_TIA || chan[c].kind == KD_AY || chan[c].kind == KD_POKEY || chan[c].kind == KD_S5B || IS_OPLL(chan[c].kind) || chan[c].kind == KD_SAA || chan[c].kind == KD_TED || chan[c].kind == KD_VIC || chan[c].kind == KD_LYNX || chan[c].kind == KD_PC98_SSG || chan[c].kind == KD_NEO_SSG || chan[c].kind == KD_OPN_SSG || chan[c].kind == KD_SN77 || chan[c].kind == KD_MSM || chan[c].kind == KD_VRC6_SAW || chan[c].kind == KD_SMS || chan[c].kind == KD_NGP || IS_NZK(chan[c].kind);
}
static uint32_t has_pan(uint32_t c) { uint32_t ch = KIND_CHIP[chan[c].kind]; return (ch == CHIP_GB || ch == CHIP_PCE || ch == CHIP_MD || ch == CHIP_VB || ch == CHIP_OPM || ch == CHIP_WS || ch == CHIP_SAA || ch == CHIP_LYNX || ch == CHIP_PC98 || ch == CHIP_NEO || ch == CHIP_NGP || ch == CHIP_C30) && chan[c].kind != KD_PC98_SSG && chan[c].kind != KD_NEO_SSG && !IS_DRUM(chan[c].kind); }
static int8_t clamp_i(int32_t v, int32_t lo, int32_t hi) { return (int8_t)(v < lo ? lo : v > hi ? hi : v); }
static void wd_knob(uint32_t c, uint32_t k, int32_t d)         /* the DRAW page: LEVEL of the sample under the cursor, BRUSH, MIRROR */
{
    if (dr_cur > wd_cmax(c)) dr_cur = wd_cmax(c);
    if (k == 0u) wd_edit(c, dr_cur, d * (int32_t)wd_dsteps(chan[c].kind), 1u << dr_brush, dr_sym);
    else if (k == 1u) dr_brush = (uint32_t)clamp_i((int32_t)dr_brush + d, 0, 3);
    else if (k == 2u) dr_sym = (uint32_t)clamp_i((int32_t)dr_sym + d, 0, 3);
}
static void knob_set(uint32_t c, uint32_t page, uint32_t k, int32_t d)      /* knob k of a page of cards, on channel c */
{
    inst_t *in = &chan[c].in;
    if (IS_FMK(chan[c].kind)) { fm_knob(c, page, k, d); return; }
    if (page == wd_pg(c)) { wd_knob(c, k, d); return; }
    if (chan[c].wcus && wd_ok(chan[c].kind) && (page == 3u || (page == 0u && k == 0u))) chan[c].wcus = 0;       /* a knob of the generator: back to the generated wave (undo brings the drawing back) */
    if (page >= base_pages(c) && !IS_DRUM(chan[c].kind)) { x_knob(c, page - base_pages(c), k, d); return; }
    if (chan[c].kind == KD_SID && (page >= 3u || (page == 0u && (k == 0u || k == 3u)))) {       /* the SID: waveform and chip on the tone page, pulse and sync, filter */
        static const uint8_t SPN[3][4] = {{SP_WAVE, 0, 0, SP_MODEL}, {SP_PW, SP_PWM, SP_SYNC, SP_RING}, {SP_CUT, SP_RES, SP_MODE, SP_FENV}};
        static const uint8_t SMX[3][4] = {{7, 0, 0, 1}, {15, 15, 15, 15}, {15, 15, 7, 15}};
        const uint32_t n = SPN[page == 0u ? 0u : page - 2u][k];
        sid_put(in, n, (uint32_t)clamp_i((int32_t)sid_get(in, n) + d, 0, SMX[page == 0u ? 0u : page - 2u][k]));
        return;
    }
    if (page == 4u && chan[c].kind == KD_FDS) {                 /* the modulator: RATIO and SHAPE share duty, SWEEP is sweep (DEPTH is the tone page's last knob, pan) */
        if (k == 0u) in->duty = (uint8_t)((in->duty & 0xF0u) | (uint32_t)clamp_i((int32_t)(in->duty & 15u) + d, 0, 15));
        else if (k == 1u) in->sweep = clamp_i((int32_t)in->sweep + d, -16, 16);
        else if (k == 2u) in->duty = (uint8_t)((in->duty & 15u) | (uint32_t)clamp_i((int32_t)(in->duty >> 4) + d, 0, 15) << 4);
        return;
    }
    if (page == 3u && chan[c].kind == KD_S5B) {                 /* the noise: PERIOD alone (0 follows the note) */
        if (k == 0u) in->wf = (uint8_t)clamp_i((int32_t)in->wf + d, 0, 15);
        else if (k == 1u) in->wc = (uint8_t)clamp_i((int32_t)in->wc + d, 0, 15);          /* RATE: the envelope's speed against the note (0 = the note) */
        else if (k == 2u) in->wt = (uint8_t)clamp_i((int32_t)in->wt + d, 0, 1);           /* MIXENV: the tone together with the envelope */
        return;
    }
    if (page == 3u) {                                           /* the wave: shape, fold, crush, twist (the FM: ratio, index, feedback, decay) */
        uint8_t *p = k == 0u ? &in->wave : k == 1u ? &in->wf : k == 2u ? &in->wc : &in->wt;
        *p = (uint8_t)clamp_i((int32_t)*p + d, 0, 15);
    } else if (page == 1u) {                                    /* the envelope: attack, decay, sustain, release */
        uint8_t *p = k == 0u ? &in->atk : k == 1u ? &in->dec : k == 2u ? &in->sus : &in->rel;
        *p = (uint8_t)clamp_i((int32_t)*p + d, 0, 15);
    } else if (page == 2u) {                                    /* the arp: chord, speed, direction */
        if (k == 0u) in->arp = (uint8_t)clamp_i((int32_t)in->arp + d, 0, 8);
        else if (k == 1u) in->arp_rate = (uint8_t)clamp_i((int32_t)in->arp_rate + d, 0, 3);
        else if (k == 2u) in->arp_dir = (uint8_t)clamp_i((int32_t)in->arp_dir + d, 0, 2);
        else in->vib_spd = (uint8_t)clamp_i((int32_t)in->vib_spd + d, 0, 15);                  /* VSPD: how fast the vibrato goes */
    } else if (k == 0u) {                                       /* the tone: wave or duty, volume, vibrato, sweep or pan */
        int32_t v;
        if (has_wave(c)) { v = ((int32_t)in->wave + 2) / 5 + (d < 0 ? -1 : 1); in->wave = (uint8_t)((v < 0 ? 0 : v > 3 ? 3 : v) * 5); }       /* pulse, saw, triangle, sine */
        else if (chan[c].kind == KD_TIA) in->wave = (uint8_t)clamp_i((int32_t)in->wave + d, 0, 10);          /* the sound type */
        else if (chan[c].kind == KD_AY || chan[c].kind == KD_S5B || chan[c].kind == KD_SAA || chan[c].kind == KD_PC98_SSG || chan[c].kind == KD_NEO_SSG || chan[c].kind == KD_OPN_SSG) in->wave = (uint8_t)clamp_i((int32_t)in->wave + d, 0, 15);         /* the noise mix */
        else if (chan[c].kind == KD_TED || chan[c].kind == KD_VIC) in->wave = (uint8_t)clamp_i((int32_t)in->wave + d, 0, 1);
        else if (chan[c].kind == KD_MSM) in->wave = (uint8_t)clamp_i((int32_t)in->wave + d, 1, 15);          /* the footages, one bit each */
        else if (chan[c].kind == KD_SN77) in->wave = (uint8_t)clamp_i((int32_t)in->wave + d, 0, 3);          /* the mixer */          /* tone or noise */
        else if (chan[c].kind == KD_LYNX) in->wave = (uint8_t)clamp_i((int32_t)in->wave + d, 0, 7);         /* the sound */
        else if (chan[c].kind == KD_VRC6_SAW) in->duty = (uint8_t)clamp_i((int32_t)in->duty + d, 0, 15);    /* OVER: the saw's rate past its usual top */
        else if (chan[c].kind == KD_NES_NOI || chan[c].kind == KD_GB_NOI) in->duty = (uint8_t)clamp_i((int32_t)in->duty + d, 0, 1);        /* MODE / WIDTH: the long or the short register */
        else if (chan[c].kind == KD_PCE_NOI) in->duty = (uint8_t)clamp_i((int32_t)in->duty + d, 0, 31);      /* RATE (0 follows the note) */
        else if (chan[c].kind == KD_VB_NOI) in->duty = (uint8_t)clamp_i((int32_t)in->duty + d, 0, 7);        /* TAP */
        else if (chan[c].kind == KD_SMS || chan[c].kind == KD_NGP) in->wave = (uint8_t)clamp_i((int32_t)in->wave + d, 0, 8);       /* NOISE: tone, white or periodic on the note, three fixed rates of each */
        else if (chan[c].kind == KD_POKEY) in->wave = (uint8_t)clamp_i((int32_t)in->wave + d, 0, 7);        /* the distortion */
        else if (has_fm(c)) in->duty = (uint8_t)clamp_i((int32_t)in->duty + d, 0, chan[c].kind == KD_OPL1 ? 1 : chan[c].kind == KD_OPM || chan[c].kind == KD_PC98_FM || chan[c].kind == KD_NEO_FM || chan[c].kind == KD_OPN_FM || chan[c].kind == KD_OPZ || chan[c].kind == KD_MD ? 7 : 3);          /* the algorithm */
        else if (has_duty(c)) { v = (int32_t)in->duty + d; in->duty = (uint8_t)(v < 0 ? 0 : v > (chan[c].kind == KD_VRC6_PU || chan[c].kind == KD_ZX ? 7 : 3) ? (chan[c].kind == KD_VRC6_PU || chan[c].kind == KD_ZX ? 7 : 3) : v); }
    }
    else if (k == 1u) in->vol = (uint8_t)clamp_i((int32_t)in->vol + d, 0, 15);
    else if (k == 2u) in->vib_dep = (uint8_t)clamp_i((int32_t)in->vib_dep + d, 0, 15);
    else if (has_pan(c)) in->pan = (uint8_t)clamp_i((int32_t)in->pan + d, 0, 2);
    else if (has_buzz(c)) in->pan = (uint8_t)clamp_i((int32_t)in->pan + d, 0, chan[c].kind == KD_OPL3 || chan[c].kind == KD_OPZ || chan[c].kind == KD_S5B ? 7 : chan[c].kind == KD_FDS ? 15 : 3);          /* the buzz, the modulator */
    else if (chan[c].kind == KD_NES_NOI) in->wf = (uint8_t)clamp_i((int32_t)in->wf + d, 0, 15);          /* PERIOD (0 follows the note) */
    else if (chan[c].kind == KD_MMC5) {}                                  /* (the chip has no sweep) */
    else if (sw_real(chan[c].kind)) in->sweep = sw_step(in->sweep, d);
    else in->sweep = clamp_i((int32_t)in->sweep + d, -16, 16);
}

/* ---- the screen */
static const uint8_t AN_COUNT[CHIPS] = {3, 2, 1, 1, 1, 1, 1, 1, 1};
static void view_clear(uint16_t bg);
static void draw_header(const theme_t *t, uint32_t chip)
{
    (void)chip;
    view_clear(t->bg);                              /* (the top bar is header.c's) */
}
/* the waveform a channel plays, 2 periods in w x h */
enum { G_PULSE, G_TRI, G_SAW, G_SINE };
static void wave_glyph(uint32_t kind, uint32_t d8, int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c)
{
    static const int8_t SIN8[8] = {0, 71, 100, 71, 0, -71, -100, -71};
    int32_t p = w / 2, i, k, lo = y + h - 2, hi = lo - (h - 2), px = x, py = lo, nx, ny;
    for (k = 0; k < 2; k++) {
        int32_t x0 = x + k * p;
        if (kind == G_PULSE) {
            int32_t on = p * (int32_t)d8 / 8;
            cv_rect(x0, hi, 2, h, c); cv_rect(x0, hi, on, 2, c);
            cv_rect(x0 + on, hi, 2, h, c); cv_rect(x0 + on, lo, p - on, 2, c);
        } else {
            for (i = 0; i <= 8; i++) {
                nx = x0 + i * p / 8;
                ny = kind == G_TRI ? lo - (i <= 4 ? i : 8 - i) * (h - 2) / 4
                   : kind == G_SAW ? lo - (i == 8 ? 0 : i * (h - 2) / 8)
                   : y + h / 2 - SIN8[i & 7] * (h - 2) / 200;
                if (i) { cv_line(px, py, nx, ny, c); cv_line(px, py + 1, nx, ny + 1, c); }
                px = nx; py = ny;
            }
        }
    }
}
static void channel_glyph(uint32_t c, int32_t x, int32_t y, int32_t w, int32_t h, uint16_t col)
{
    static const uint8_t D8[4] = {1, 2, 4, 6};
    const inst_t *in = &chan[c].in;
    if (has_wave(c)) {
        uint8_t wv[32];
        int32_t i;
        wave_make(in, wv);                                      /* the wave itself, as it is now */
        for (i = 0; i < 32; i++) cv_rect(x + i * w / 32, y + h - 2 - wv[i] * (h - 2) / 15, w / 32 + 1, 2, col);
    } else if (chan[c].kind == KD_NES_TRI) wave_glyph(G_TRI, 0, x, y, w, h, col);
    else if (chan[c].kind == KD_VRC6_SAW) wave_glyph(G_SAW, 0, x, y, w, h, col);
    else if (has_fm(c) || IS_OPLL(chan[c].kind)) wave_glyph(G_SINE, 0, x, y, w, h, col);
    else if (chan[c].kind == KD_SPK) wave_glyph(G_PULSE, 4, x, y, w, h, col);
    else if (chan[c].kind == KD_POKEY) {                        /* the distortion's bits, as they run */
        uint32_t w7 = in->wave > 7u ? 7u : in->wave;
        int32_t i, n = w7 >= 4u ? 24 : POKEY_LEN[w7] < 24u ? (int32_t)POKEY_LEN[w7] : 24;
        for (i = 0; i < 24; i++) {
            uint32_t j = (uint32_t)i % (uint32_t)n;
            cv_rect(x + i * w / 24, (w7 >= 4u ? (uint32_t)((i * 0x5B ^ i * i * 3 >> 1) >> 2 & 1) : POKEY_BITS[w7][j >> 3] >> (j & 7u) & 1u) ? y : y + h - 2, w / 24 + 1, 2, col);
        }
    }
    else if (chan[c].kind == KD_TIA) {                          /* the sound type's bits, as they run */
        uint32_t w9 = in->wave > 10u ? 10u : in->wave;
        int32_t i, n = TIA_LEN[w9] < 24u ? (int32_t)TIA_LEN[w9] : 24;
        for (i = 0; i < 24; i++) {
            uint32_t j = (uint32_t)i % (uint32_t)n;
            cv_rect(x + i * w / 24, TIA_BITS[w9][j >> 3] >> (j & 7u) & 1u ? y : y + h - 2, w / 24 + 1, 2, col);
        }
    }
    else wave_glyph(G_PULSE, has_duty(c) ? (chan[c].kind == KD_VRC6_PU ? (uint32_t)(in->duty & 7u) / 2u + 1u : chan[c].kind == KD_ZX ? D8[(in->duty >> 1) & 3u] : D8[in->duty & 3u]) : 4u, x, y, w, h, col);
}
#define KEY0 53u                                /* key 0 = F3 */
static const int8_t BLK_IDX[27] = {-1, 0, -1, 1, -1, 2, -1, -1, 3, -1, 4, -1, -1, 5, -1, 6, -1, 7, -1, -1, 8, -1, 9, -1, -1, 10, -1};    /* a black key's number, 0 to 10 */
static const uint8_t BLK_KEY[11] = {1, 3, 5, 8, 10, 13, 15, 17, 20, 22, 25};        /* the key of each black key */
static void note_name(char *s, uint32_t note)   /* "C#4"; blank for none (0 or 255) */
{
    static const char *const NAME[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    s[0] = 0;
    if (note && note < 128u) {
        const char *p = NAME[note % 12u];
        uint32_t i = 0;
        while (*p) s[i++] = *p++;
        if (note >= 12u) s[i++] = (char)('0' + note / 12u - 1u);
        s[i] = 0;
    }
}
static void draw_note(const theme_t *t, uint32_t note)
{
    char s[8];
    note_name(s, note);
    text_on(160, 6, 72, &FONT_L, s, t->fg, t->bg, 2);
}
#include "rack.c"
#include "win.c"
#include "header.c"
#include "songview.c"
#include "stepview.c"
#include "fxview.c"
#include "flair.c"
#include "chipview.c"
#include "menu.c"
#include "addmenu.c"
#include "lessons.c"
#include "manual.c"
#include "tips.c"
#include "picker.c"

static int32_t enc_act(uint32_t e) { int32_t v = fm1_enc_take(e); if (v) { act_ms = fm1_ms; if (e >= ENC_KNOB1 && e <= ENC_KNOB1 + 3u) les_kclk += (uint32_t)(v < 0 ? -v : v); } return v; }       /* knobs count as being touched */
#define fm1_enc_take enc_act

#include "boot.c"
static uint8_t *inst_flag;                      /* set.demo, for app_install_mark (ota.c calls it when an install starts) */
static const void *inst_set;
static uint32_t inst_n;
static void app_install_mark(void)
{
    if (inst_flag) { *inst_flag |= QS_INSTALLED; settings_save(inst_set, inst_n); }
}
/* MIDI notes held, per MIDI channel: a chip channel is one voice, so the last key down sounds; letting it go brings the one before it back */
static uint8_t mk_n[16], mk_s[16][8];
static uint32_t mrec_t0[128];                   /* recording from the keyboard: when each note went down (0 = not recording it), and where it landed */
static uint8_t mrec_pg[128], mrec_st[128], mrec_ch[128];
static int32_t mpre, malg;                       /* the keyboard's main knob, as PRESETS in the rack and ALGORITHM on the chip screen (clicks waiting) */
static uint32_t midi_pad;                       /* the keyboard's 16 pads held (bit n = pad n): the FX pads, in the punch-in layer */
static void mk_on(uint32_t c, uint32_t note, uint32_t vel)
{
    uint32_t i, n = mk_n[c];
    for (i = 0; i < n; i++) if (mk_s[c][i] == note) { for (n--; i < n; i++) mk_s[c][i] = mk_s[c][i + 1u]; break; }
    if (n == 8u) { for (i = 1; i < 8u; i++) mk_s[c][i - 1u] = mk_s[c][i]; n = 7u; }
    mk_s[c][n] = (uint8_t)note;
    mk_n[c] = (uint8_t)(n + 1u);
    chip_note(c, note, vel);
}
static void mk_off(uint32_t c, uint32_t note)
{
    uint32_t i, n = mk_n[c], top;
    for (i = 0; i < n; i++) if (mk_s[c][i] == note) break;
    if (i == n) return;
    top = i + 1u == n;
    for (n--; i < n; i++) mk_s[c][i] = mk_s[c][i + 1u];
    mk_n[c] = (uint8_t)n;
    if (top) { if (n) chip_slide(c, mk_s[c][n - 1u]); else chip_off(c); }      /* it was the one sounding */
}
static void app_main(void)
{
    struct { int8_t oct; uint8_t an[3], proj, demo, unlocked, les[12]; } set = {0, {AN_HW, AN_HW, 0}, 0, 0, 0, {0}};      /* les: the lessons you finished (a settings blob of 7 or 15 bytes, from before, still loads) */
#define bt_pack() do { set.unlocked = (uint8_t)((clk_mode & 3u) | (brothers_mode & 3u) << 2 | bt_side << 4 | bt_patsync << 5 | bt_fxsync << 6 | bt_key << 7); dirty = 1; t_change = fm1_ms; } while (0)       /* the settings byte: MIDI clock, Bluetooth mode, sidechain, patterns */
    uint32_t prev = 0, k, t_change = 0, dirty = 0, note_drawn = ~0u, chip_drawn = ~0u;
    uint32_t last_note = 255u, view = 1, rack_force = 1, chip_page = 0, sel = 0;     /* view: 0 the chip, 1 the rack, 2 the song; sel: the channel (in the rack, one past the last is "add") */
    uint32_t home_was = 0, home_t0 = 0, home_used = 0, home_now, home_tap, edit_was = 0, edit_t0 = 0, edit_now, edit_used = 0, edit_rel, edit_clr = 255u;
    uint32_t fresh, start_pick = 0, btn_was = 0, crit_next = 0, crit_n = 0, sys_req = 0, play_t0 = 0, play_wait = 0, sel_was = 0, sel_t0 = 0, sel_used = 0, sel_now, dup_was = 0, dup_t0 = 0, dup_used = 0;
    int32_t ed_hold_k = -1;                             /* STEP: the key held now and where its note went: KNOB 2 sets that note's length */
    uint32_t ed_hold_step = 0;
    uint8_t held[27] = {0}, held_ch[27] = {0}, ch_drawn = 99;
    uint8_t rec_hold[27] = {0}, rec_pg[27] = {0}, rec_st[27] = {0}, rec_ch[27] = {0};     /* a recorded note still held: where it went, to set its length when the key comes up */
    uint32_t rec_t0[27] = {0};
    fresh = settings_load(&set, sizeof set) != 0;      /* a new device (or a wipe): no settings yet */
    if (fresh) { struct { int8_t oct; uint8_t an[3], proj, demo, unlocked, les[8]; } mid; if (settings_load(&mid, sizeof mid) == 0) { memcpy(&set, &mid, sizeof mid); fresh = 0; } }       /* (the settings with room for 64 lessons) */
    if (fresh) { struct { int8_t oct; uint8_t an[3], proj, demo, unlocked; } old; if (settings_load(&old, sizeof old) == 0) { memcpy(&set, &old, sizeof old); fresh = 0; } }       /* (the settings before the lessons list had no les bytes) */
    memcpy(les_done, set.les, sizeof les_done);
    if ((set.demo & 0xF0u) != QS_OK) set.demo = QS_OK;
    clk_mode = (set.unlocked & 3u) <= 2u ? (uint8_t)(set.unlocked & 3u) : 0u;       /* the settings byte `unlocked` (never used before): bits 0-1 the MIDI clock, 2-3 the Bluetooth sync mode, 4 sidechain, 5 follow patterns */
    bt_side = set.unlocked >> 4 & 1u; bt_patsync = set.unlocked >> 5 & 1u; bt_fxsync = set.unlocked >> 6 & 1u; bt_key = set.unlocked >> 7 & 1u;
    inst_flag = &set.demo; inst_set = &set; inst_n = sizeof set;                    /* set.demo: quick start on every start, project browser on every start */
    rack_tails = set.an[2] >> 7;                        /* set.an[2]: the boot screen in bits 0-4, no critters in bit 5, no battery in bit 6, note tails in bit 7 */
    opt_noanim = set.an[2] >> 5 & 1u; opt_nobat = set.an[2] >> 6 & 1u;
#if !defined(CHIPBOX_HOST) || defined(BOOT_DEMO)
    {                                                   /* the next power-on screen in the list; set.an[2] (unused) remembers the last */
        uint32_t last = (set.an[2] & 31u) < BOOT_N ? set.an[2] & 31u : 0u, n = (last + 1u) % BOOT_N;
#ifdef BOOT_DEMO
        n = BOOT_DEMO;
#endif
        boot_seed = fm1_ticks();
        set.an[2] = (uint8_t)(n | (set.an[2] & 0xE0u));
        settings_save(&set, sizeof set);                /* now, while it is silent: a quick power cycle must not show the same one */
        boot_screen(n);
    }
#endif
    proj_demo_sync();                                   /* project 1 is the demo: always there, always as shipped */
    act_ms = fm1_ms;
    proj_cur = set.proj < PROJ_SLOTS ? set.proj : 0;                  /* the project you left open; Korobeiniki on a new device */
    proj_loaded = proj_load(proj_cur) == 0;
    if (!proj_loaded) { if (proj_is_demo(proj_cur) && proj_cur == 0u) seq_tetris(); else if (proj_is_demo(proj_cur) && proj_cur == 1u) seq_symphony(); else proj_blank(); }
    if (set.oct < -2 || set.oct > 2) set.oct = 0;
    if (set.demo & QS_INSTALLED) { fresh = 1; set.demo &= (uint8_t)~QS_INSTALLED; dirty = 1; t_change = fm1_ms; }      /* an install started from Chipbox (an update, or another firmware and back) */
    for (k = PROJ_DEMOS; k < PROJ_SLOTS; k++) if (proj_exists(k)) fresh = 0;
    start_pick = set.demo & QS_PICK;
    if (fresh || (set.demo & QS_ALWAYS)) { man_open(MC_QUICK, 0); man_lock = 1; }          /* a new device starts on the quick start; the browser waits behind it */
    for (k = 0; k < 2u; k++)
        if (set.an[k] >= AN_COUNT[k]) set.an[k] = AN_COUNT[k] > 1u ? 1u : 0u;
    set.an[CHIP_NES] = set.an[CHIP_GB] = AN_HW;     /* always the analog stage */
    for (k = 0; k < 2u; k++) analog_mode[k] = set.an[k];

#define FACTORY_RESET() do {                                                            /* the menu's Factory Reset, and MIDI CC 109 (a test) */ \
    if (les_on) les_exit(); \
        seq_stop(); rec_on = 0; duck_ch = 255; \
        for (k = PROJ_DEMOS; k < PROJ_SLOTS; k++) proj_clear(k);               /* every project goes, the demos come back */ \
        if (proj_demos_free_empty() + proj_demos_free_used()) proj_demos_restore_all(); \
        set.oct = 0; \
        proj_cur = 0; proj_dirty = 0; proj_loaded = proj_load(0) == 0; undo_reset(); \
        set.proj = 0; dirty = 1; t_change = fm1_ms; \
        sel = 0; rack_rm = 0; last_note = 255u; view = 1; \
        menu_on = 0; rack_force = 1; chip_drawn = ~0u; anim_start(AN_OPEN, 0); \
        man_open(MC_QUICK, 0); man_lock = 1;                                    /* like a new device */ \
    } while (0)

    for (;;) {
        static uint32_t cc_ms;
        const theme_t *t;
        uint32_t keys, down, up, rel, b, lit = 0, base = (uint32_t)(KEY0 + 12 * set.oct), cpu, redraw = 0, in_menu = menu_on, nrows, ch_chip;
        uint8_t st, d1, d2;
        int32_t e;
        platform_poll();
#ifndef CHIPBOX_HOST
        if (px_open_req) {                              /* a project came in over USB: open it */
            uint32_t sl = px_open_req - 1u;
            px_open_req = 0;
            if (les_on) { les_exit(); proj_dirty = 0; }
            if (sl == proj_cur) proj_dirty = 0;         /* (the open one was just replaced: its unsaved copy is the old one) */
            proj_open(sl); set.proj = (uint8_t)proj_cur; dirty = 1; t_change = fm1_ms; rack_force = 1; chip_drawn = ~0u; sel = 0; rack_inval = 1; view = 1;
            pick_on = 0; menu_on = 0;
        }
#endif
        if (!chan_n && !view) { view = 1; rack_force = 1; chip_drawn = ~0u; }       /* no channels: only the rack makes sense */
        if (rec_on && (view == 2u || view == 3u || !seq_run || sel >= chan_n || pick_on)) { rec_on = 0; duck_ch = 255; }     /* recording stops with the playing, the song screen, the + row */
        {   const uint32_t plen = page_steps(seq_view);                    /* the page on show may be longer or shorter than 16 steps */
            if (ed_cur >= plen) ed_cur = plen - 1u;
            if (view == 3u) rack_cur = ed_cur;
            else if (!seq_run || seq_hold) rack_cur = seq_step < plen ? seq_step : 0u;                  /* stopped or paused: the playhead is the cursor */
            if (rack_cur >= plen) rack_cur = plen - 1u;
            vwin = view == 3u ? ed_cur / SEQ_LEN : seq_run && !seq_hold && seq_pat == seq_view && seq_step < plen ? seq_step / SEQ_LEN : rack_cur / SEQ_LEN;       /* the screen: the cursor's, or the playhead's while it plays */
        }
        les_tick(view, sel, chip_page);                 /* a lesson: has the step been done */
        if (les_req_view != ~0u) { view = les_req_view; les_req_view = ~0u; sel = 0; rack_force = 1; chip_drawn = ~0u; rack_inval = 1; hdr_force = 1; }       /* a masterclass wants the CHIP screen */
        if (les_req_page != ~0u) { chip_page = les_req_page; les_req_page = ~0u; redraw = 1; chip_drawn = ~0u; ch_drawn = 99; }       /* a masterclass patch: the CHIP screen on its first page */
        if (les_saved) { les_saved = 0; memcpy(set.les, les_done, sizeof set.les); dirty = 1; t_change = fm1_ms; }          /* a lesson finished: the settings keep it */
        nrows = chan_n + (view == 1u && chan_n < MAXCH ? 1u : 0u);
        if (sel >= nrows) sel = nrows ? nrows - 1u : 0u;
        fm_fix(sel);
        if (sel < chan_n && chip_page >= pages(sel)) { chip_page = 0; redraw = 1; }
        ch_chip = sel < chan_n ? KIND_CHIP[chan[sel].kind] : CHIP_NES;
        t = &THEME[ch_chip];

        keys = fm1_in.notes;
        if (keys != prev || fm1_in.buttons != btn_was) act_ms = fm1_ms;
        btn_was = fm1_in.buttons;
        down = keys & ~prev;
        up = prev & ~keys;
        prev = keys;
        if (start_pick && !menu_on && !pick_on) { start_pick = 0; pick_open(); }       /* the project browser at start: open one, or an empty one for new */
        if (fx_layer && (menu_on || pick_on)) fx_off();
        if (fx_layer) {                                 /* the punch-in layer: the white keys are the pads, held = on; they play nothing else */
            uint32_t mask = 0, p, now;
            if (!menu_on && !pick_on) {
                uint32_t edge;
                for (p = 0; p < FXN; p++) if ((keys >> FX_KEY[p] | midi_pad >> p) & 1u) mask |= FXB(p);
                edge = mask & ~fx_raw; fx_raw = mask;
                if (edge & FXB(FX_LATCH)) { fx_lat ^= 1u; if (!fx_lat) fx_tog = 0; }       /* LATCH: pads stay on when tapped, tap again to turn off */
                if (fx_lat) { fx_tog ^= edge & ~FXB(FX_LATCH); mask = fx_tog | FXB(FX_LATCH); }
                else mask &= ~FXB(FX_LATCH);
                now = mask & ~fx_held;
                for (p = 0; p < FXN; p++) if (now >> p & 1u) { if (p == FX_TAPE) anim_tape(); else anim_fx(p); }
                if (!mask && fx_held) { /* all let go: the animation finishes by itself */ }
                else if (mask && (fx_held & ~mask)) { for (p = 0; p < FXN; p++) if (mask >> p & 1u) { an_arg = p; break; } }
                fx_apply(mask | bt_fx_cur);
            }
            down = up = 0;
        }
        for (k = 0; k < 27u; k++) {
            if ((down >> k & 1u) && menu_on && (menu_kind == MK_ADD || menu_kind == MK_ADD2)) { held[k] = (uint8_t)(base + k); held_ch[k] = 255u; add_key_on(held[k]); }       /* the Add Channel list: the keys play the console on the bar */
            else if (down >> k & 1u) {
                held[k] = (uint8_t)(base + k); held_ch[k] = (uint8_t)sel;
                if (sel < chan_n) {
                    uint32_t dr = IS_DRUM(chan[sel].kind), bk = BLK_IDX[k] < 0 ? 99u : (uint32_t)BLK_IDX[k];      /* a drum channel: the black keys are the kit (BD SD CP TM CH OH CY CB) */
                    if (!dr) chip_note(sel, held[k], 127);
                    else if (bk < 11u) { if (view == 3u) ed_lane = bk; chip_note(sel, DR_LANE_TYPE[bk], 127); }
                    last_note = dr ? 255u : held[k]; midi_send(0x90 | (sel & 15u), held[k], 100);
                    if (!menu_on && !pick_on && !rack_rm) {
                        if (dr) {                                                  /* the lanes: the white keys are the 16 steps; the same hit again takes it away */
                            uint32_t p;
                            if (view == 3u) for (p = 0; p < FXN; p++) if (FX_KEY[p] == k && vwin * SEQ_LEN + p < page_steps(seq_view)) {
                                step_t *x = STEP_W(seq_view, sel, vwin * SEQ_LEN + p);
                                uint32_t h = dstep_hits(x), a = dstep_acc(x), bit = 1u << ed_lane, env = fm1_in.buttons >> BTN_ENV & 1u;
                                if (env) { if (h & bit && a & bit) a &= ~bit; else { h |= bit; a |= bit; } }          /* ENV held: an accented hit (on one already there: accent on, off) */
                                else if (h & bit) { h &= ~bit; a &= ~bit; }                                         /* the same hit again takes it away */
                                else h |= bit;
                                dstep_set(x, h, a); proj_edited();
                            }
                        }
                        else if (rec_on && seq_run && !seq_hold && view != 2u) {      /* recording: the note goes on the step nearest the playhead */
                            uint32_t a, sb, stp = 0, pg;
                            do { a = seq_step; sb = seq_sub; } while (a != seq_step);
                            stp = (a * SEQ_PPS + sb + SEQ_PPS / 2u) / SEQ_PPS % (seq_len ? seq_len : SEQ_LEN); pg = seq_pat;
                            {   step_t *x = STEP_W(pg, sel, stp);
                                x->note = held[k]; x->vel = 100; x->gate = 5; rec_hold[k] = 1; rec_t0[k] = seq_ticks; rec_pg[k] = (uint8_t)pg; rec_st[k] = (uint8_t)stp; rec_ch[k] = (uint8_t)sel;
                            }
                            rack_inval = 1; proj_edited();
                        } else if (view == 1u && (!seq_run || seq_hold)) { seq_toggle(sel, rack_cur, held[k]); rack_inval = 1; proj_edited(); }
                        else if (view == 3u) { step_t *x = STEP_W(seq_view, sel, ed_cur); x->note = held[k]; x->vel = 100; x->gate = 5; ed_hold_k = (int32_t)k; ed_hold_step = ed_cur; ed_cur = (ed_cur + 1u) % page_steps(seq_view); proj_edited(); }       /* STEP: the key sets the block and moves on */       /* stopped or paused: on the step the playhead is at */
                    }
                }
            }
            if ((up >> k & 1u) && held_ch[k] == 255u) { add_key_off(held[k]); held_ch[k] = 0; }
            else if (up >> k & 1u) {
                if ((int32_t)k == ed_hold_k) ed_hold_k = -1;
                if (held_ch[k] < chan_n && last_note == held[k]) chip_off(held_ch[k]);
                midi_send(0x80 | (held_ch[k] & 15u), held[k], 0);
                if (rec_hold[k]) {                      /* a recorded note: its length is how long the key was down */
                    step_t *x = STEP_W(rec_pg[k], rec_ch[k], rec_st[k]);
                    uint32_t g = seq_ticks - rec_t0[k];
                    if (x->note == held[k]) x->gate = (uint8_t)(g < 1u ? 1u : g > 96u ? 96u : g);
                    rec_hold[k] = 0; rack_inval = 1;
                }
            }
        }

        b = fm1_input_edges(&rel);
        home_now = fm1_in.buttons >> BTN_HOME & 1u;     /* HOME: a tap goes between the views, a hold opens the projects */
        if (home_now && !home_was) { home_t0 = fm1_ms; home_used = tip_on; }      /* HOME with a tip up only closes it */
        if (les_on && les_fin && !menu_on && !pick_on && (b & (1u << BTN_OCT_UP))) {      /* the last card of a lesson: OCT+ goes on to the next */
            b &= ~(1u << BTN_OCT_UP); les_enter((les_i + 1u) % LES_N); view = 1; sel = 0; chip_page = 0; seq_view = 0; rack_force = 1; chip_drawn = ~0u; rack_inval = 1; hdr_force = 1;
        } else if (les_on && les_fin && !menu_on && !pick_on && (b & (1u << BTN_OCT_DOWN))) {      /* ... and OCT- ends the lesson: the user's project comes back */
            b &= ~(1u << BTN_OCT_DOWN); les_exit(); view = 1; sel = 0; seq_view = 0; rack_force = 1; chip_drawn = ~0u; rack_inval = 1; hdr_force = 1;
        }
        if (les_reading() && !menu_on && !pick_on && (b & (1u << BTN_OCT_UP))) { b &= ~(1u << BTN_OCT_UP); les_read_next(view, sel, chip_page); }       /* a page to read: OCT+ goes on */
        sys_req = 0;                                    /* GLO + HOME, either one first: the menu */
        if (!pick_on && home_now && (((b & (1u << BTN_GLO)) != 0u) || (!home_was && (fm1_in.buttons >> BTN_GLO & 1u)))) { home_used = 1; sys_req = 1; b &= ~(1u << BTN_GLO); }
        if (home_now && !home_used && !menu_on && !pick_on && fm1_ms - home_t0 >= 600u) { if (les_on) { les_exit(); view = 1; sel = 0; rack_force = 1; chip_drawn = ~0u; rack_inval = 1; } pick_open(); home_used = 1; }
        home_tap = !home_now && home_was && !home_used;
        if (home_tap && rack_rm) { rack_rm = 0; rack_inval = 1; home_tap = 0; }          /* HOME closes the remove window */
        home_was = home_now;
        edit_now = fm1_in.buttons >> BTN_EDIT & 1u;
        edit_rel = !edit_now && edit_was;
        if (edit_now && !edit_was) { edit_t0 = fm1_ms; edit_used = 0; }
        edit_was = edit_now;
        if (pick_on) {                                  /* the projects: SELECT moves, OCT+ yes, OCT- no, hold EDIT to clear one */
            e = fm1_enc_take(ENC_SELECT);
            if (!e) e = fm1_enc_take(ENC_PRESETS);
            if (e) { pick_sel = e < 0 ? (pick_sel ? pick_sel - 1u : 0u) : (pick_sel + 1u < PROJ_SLOTS ? pick_sel + 1u : PROJ_SLOTS - 1u); pick_del = 0; pick_dirty = 1; }
            if (edit_now && fm1_ms - edit_t0 >= 600u && !pick_del && pick_have[pick_sel]) { pick_del = 1; pick_dirty = 1; }
            sel_now = fm1_in.buttons >> BTN_SEL & 1u;                                   /* hold SEL on a project: a copy in the first free slot */
            if (sel_now && !sel_was) { sel_t0 = fm1_ms; sel_used = 0; }
            if (sel_now && !sel_used && !pick_del && pick_have[pick_sel] && fm1_ms - sel_t0 >= 600u) {
                uint32_t f;
                sel_used = 1;
                for (f = PROJ_DEMOS; f < PROJ_SLOTS && pick_have[f]; f++) {}
                if (f < PROJ_SLOTS) { seq_stop(); if (proj_copy(pick_sel, f) == 0) { pick_scan(); pick_sel = f; pick_dirty = 1; } }
            }
            sel_was = sel_now;
            if ((b & (1u << BTN_OCT_UP)) || (home_tap && !pick_del)) {       /* OCT+ (yes) or a HOME tap opens the slot under the frame */
                if (pick_del) {
                    seq_stop(); proj_free(pick_sel);                    /* a demo too: its slot is an ordinary empty one from now on (Restore Demos puts the demo back if the slot is still empty) */
                    if (pick_sel == proj_cur) { proj_blank(); proj_dirty = 0; proj_lock = 0; sel = 0; rack_inval = 1; }
                    pick_del = 0; pick_scan(); pick_dirty = 1;
                } else {
                    if (pick_sel != proj_cur) {
                        proj_open(pick_sel); anim_start(AN_OPEN, pick_sel);
                        set.proj = (uint8_t)proj_cur; dirty = 1; t_change = fm1_ms; last_note = 255u; sel = 0; rack_rm = 0;
                    }
                    pick_on = 0; rack_force = 1; chip_drawn = ~0u;
                }
            } else if (b & (1u << BTN_OCT_DOWN)) {
                if (pick_del) { pick_del = 0; pick_dirty = 1; } else { pick_on = 0; rack_force = 1; chip_drawn = ~0u; }
            } else if (home_tap && pick_del) { pick_del = 0; pick_dirty = 1; }                /* HOME closes the delete window */
            else if ((b & (1u << BTN_GLO)) || home_tap) { pick_del = 0; pick_on = 0; rack_force = 1; chip_drawn = ~0u; }
            fm1_enc_take(ENC_PRESETS); fm1_enc_take(ENC_ALGORITHM);
            for (k = 0; k < 4u; k++) fm1_enc_take(ENC_KNOB1 + k);
        } else {
        if ((b & (1u << BTN_SEQ)) && !menu_on && !pick_on && !fx_layer) {      /* SEQ: step entry for the channel you are on, and back */
            if (view == 3u) { view = 1; anim_start(AN_VIEW, 1u); rack_force = 1; chip_drawn = ~0u; }
            else if (view != 2u && sel < chan_n) { chip_off(sel); view = 3; ed_cur = 0; anim_start(AN_VIEW, 4u); rack_force = 1; chip_drawn = ~0u; }
        }
        if (home_tap && les_reading() && !menu_on && !pick_on && !fx_layer) { les_hide = 1; home_tap = 0; rack_force = 1; chip_drawn = ~0u; rack_inval = 1; hdr_force = 1; }       /* a page to read: HOME puts it away (GLO brings it back) */
        if (sys_req) {                                  /* the menu (it replaces a help list that is open) */
            sys_group = 0; sys_open(set.demo, 1);
        } else if (b & (1u << BTN_GLO)) {               /* the manual, at the chapter for the view you are on; GLO again is the contents, HOME leaves */
            if (les_on && !menu_on && !fx_layer) { les_hide ^= 1u; rack_force = 1; chip_drawn = ~0u; rack_inval = 1; hdr_force = 1; }        /* a lesson: GLO hides the card and brings it back */
            else if (menu_on && menu_kind == MK_MANUAL) man_glo();
            else if (menu_on) { menu_on = 0; rack_force = 1; chip_drawn = ~0u; }
            else if (fx_layer) man_open(MC_FX, 0);
            else if (view == 2u) man_open(MC_SONG, seq_run ? 4u : 0u);                                  /* the page for what you are doing: playing, adding a channel, the knobs' second page ... */
            else if (view == 3u && sel < chan_n && IS_DRUM(chan[sel].kind)) man_open(MC_DRUM, 0);
            else if (view == 3u) man_open(MC_STEP, 0);
            else if (view) man_open(MC_RACK, rack_rm == 2u ? MRP_CHANGE : rack_rm ? MRP_REMOVE : sel >= chan_n ? MRP_ADD : rec_on ? MRP_REC : seq_run ? MRP_PLAY : MRP_PICK);
            else man_open_chip(sel, chip_page);
        } else if (home_tap) {
            if (menu_on) { if (man_lock && menu_kind == MK_MANUAL) { dirty = 1; t_change = fm1_ms; } menu_on = 0; }          /* HOME closes any menu (the Brothers Link page too); leaving the quick start saves the settings */
            else if (fx_layer) { fx_layer = 0; fx_off(); anim_start(AN_VIEW, view); }       /* HOME leaves the punch-in layer first */
            else if (view == 3u) { view = 1; anim_start(AN_VIEW, 1u); }
            else { view = view == 1u ? (chan_n ? 0u : 2u) : view == 0u ? 2u : 1u; anim_start(AN_VIEW, view); }       /* HOME: the rack, the chip, the song, the rack ... */
            rack_force = 1; chip_drawn = ~0u;
        }
        if (b & (1u << BTN_PLAY)) {                     /* PLAY: in the song, the song from the cursor; anywhere else, the page on show round and round */
            if (seq_run && seq_hold) { seq_rate = 2; seq_hold = 0; anim_start(AN_PLAY, 0); }                   /* paused on the tape: go on */
            else if (seq_run) { seq_stop(); rec_on = 0; duck_ch = 255; anim_start(AN_PAUSE, 0); }
            else if (view == 1u) { play_wait = 1; play_t0 = fm1_ms; }                                          /* the rack: a tap plays on from this page, a hold loops it */
            else { if (view == 2u) seq_play(song_cur < song_len ? song_cur : 0u, 0); else seq_play(0, 1); anim_start(AN_PLAY, 0); }
        }
        if (play_wait) {
            if (fm1_ms - play_t0 >= 350u && (fm1_in.buttons >> BTN_PLAY & 1u)) { play_wait = 0; seq_play(0, 1); anim_start(AN_PLAY, 0); }
            else if (rel & (1u << BTN_PLAY)) {
                uint32_t s = 0;
                play_wait = 0;
                while (s < song_len && song[s] != seq_view) s++;
                if (s < song_len) seq_play(s, 0); else seq_play(0, 1);
                anim_start(AN_PLAY, 0);
            }
        }
        if ((b & (1u << BTN_FX)) && !menu_on) {          /* FX: the punch-in layer on and off */
            fx_layer ^= 1u;
            anim_start(AN_VIEW, fx_layer ? 3u : view);
            if (fx_layer) { for (k = 0; k < 27u; k++) if (prev >> k & 1u && held_ch[k] < chan_n) chip_off(held_ch[k]); }
            else fx_off();
            rack_force = 1; chip_drawn = ~0u;
        }
        if ((b & (1u << BTN_REC)) && !menu_on && view != 2u && view != 3u && sel < chan_n && !IS_DRUM(chan[sel].kind)) {      /* REC: arm (and start the page round and round); again: disarm */
            if (rec_on) { rec_on = 0; duck_ch = 255; seq_stop(); anim_start(AN_REC, 1); }                  /* REC again: stop recording and the playing */
            else { rec_on = 1; duck_ch = (uint8_t)sel; if (!seq_run) seq_play(0, 1); anim_start(AN_REC, 0); }
        }
        if (!edit_now) edit_clr = 255u;
        if (rec_on && edit_now && seq_run && sel < chan_n) {      /* recording, EDIT held: the note at the playhead goes, and each one the playhead reaches while it is held */
            uint32_t cs = seq_step;
            if (cs != edit_clr) {
                step_t *x = STEP_W(seq_pat, sel, cs);
                edit_clr = cs;
                if (x->note) { x->note = 0; rack_inval = 1; proj_edited(); }
            }
        }
        {                                               /* hold SEL on a channel in the rack: a copy of it (its patch and its steps) at the end */
            uint32_t sn = fm1_in.buttons >> BTN_SEL & 1u;
            if (sn && !dup_was) { dup_t0 = fm1_ms; dup_used = 0; }
            dup_was = sn;
            if (sn && !dup_used && view == 1u && sel < chan_n && !menu_on && !pick_on && !fx_layer && !rack_rm && fm1_ms - dup_t0 >= 600u) {
                dup_used = 1;
                if (chan_n < MAXCH) { menu_open_pick(COPY_MENU, sizeof COPY_MENU / sizeof COPY_MENU[0]); menu_kind = MK_COPY; }       /* a window: patch only, patch and notes, cancel */
            }
        }
        if ((b & (1u << BTN_SEL)) && view == 0u && sel < chan_n && IS_FMK(chan[sel].kind) && !menu_on && !pick_on && !fx_layer) {      /* SEL on an FM chip's screen: the knobs edit the channel, then each operator in turn */
            fm_foc = (fm_foc + 1u) % fm_nfoc(sel);
            if (chip_page >= pages(sel)) chip_page = 0;
            redraw = 1;
        }
        if ((b & (1u << BTN_ARP)) && !menu_on && !pick_on) {          /* ARP: note tails on or off */
            rack_tails ^= 1u; set.an[2] = (uint8_t)((set.an[2] & 127u) | rack_tails << 7); dirty = 1; t_change = fm1_ms; rack_inval = 1;
        }
        if ((b & (1u << BTN_LFO)) && !menu_on && !pick_on) {          /* LFO: undo */
            uint32_t vv = seq_view, sc = song_cur;
            if (undo_go() == 0) {
                if (vv < page_n) seq_view = (uint8_t)vv;
                if (sc <= song_len) song_cur = sc;
                rack_inval = 1; rack_rm = 0; chip_drawn = ~0u; redraw = 1; anim_start(AN_UNDO, 1);
            } else anim_start(AN_UNDO, 0);
        }
        undo_tick();
        if ((b & (1u << BTN_SAVE)) && !proj_is_demo(proj_cur) && !proj_lock && !les_on) { add_aud_stop(); if (proj_save(proj_cur) == 0) { proj_dirty = 0; proj_t_saved = fm1_ms | 1u; anim_start(AN_SAVE, 0); } }
        if (in_menu) {                                  /* in a menu only SELECT does anything (and, in a pick list, OCT+ yes, OCT- no) */
            if (b & ((1u << BTN_OCT_UP) | (1u << BTN_OCT_DOWN))) add_aud_stop();          /* the audition's channel goes before anything is added */
            if (menu_on && menu_kind == MK_MANUAL) man_input(b);
            if (menu_on && menu_kind == MK_MANUAL && man_lock && (b & (1u << BTN_OCT_DOWN))) {              /* the quick start, OCT-: hide it (it will not come back by itself) */
                menu_on = 0; man_lock = 0; set.demo &= (uint8_t)~QS_ALWAYS; dirty = 1; t_change = fm1_ms; rack_force = 1; chip_drawn = ~0u; b &= ~(1u << BTN_OCT_DOWN);
            }
            if (menu_on && menu_kind == MK_ADD) {           /* the Add Channel list: KNOB1 groups, SEL opens the card, OCT- closes it first */
                e = fm1_enc_take(ENC_KNOB1);
                if (e) add_mode_step(e);
                if (b & (1u << BTN_SEL)) { add_card ^= 1u; add_touch(); menu_dirty = 1; }
                if (add_card && (b & (1u << BTN_OCT_DOWN))) { add_card = 0; menu_dirty = 1; b &= ~(1u << BTN_OCT_DOWN); }
            }
            if (menu_on && menu_kind == MK_LESSONS) {       /* the lessons list: SELECT or PRESETS moves, OCT+ starts, OCT- goes back to the menu */
                e = fm1_enc_take(ENC_SELECT) + fm1_enc_take(ENC_PRESETS);
                if (e) les_list_move(e);
                if (b & (1u << BTN_OCT_UP)) {
                    if (proj_dirty && !proj_is_demo(proj_cur) && !proj_lock && proj_save(proj_cur) == 0) proj_dirty = 0;
                    les_enter(les_pick);
                    menu_on = 0; view = 1; sel = 0; chip_page = 0; seq_view = 0; rack_force = 1; chip_drawn = ~0u; rack_inval = 1; hdr_force = 1;
                } else if (b & (1u << BTN_OCT_DOWN)) { sys_group = 0; sys_open(set.demo, 1); }
                b &= ~(1u << BTN_OCT_UP | 1u << BTN_OCT_DOWN);
            }
            e = fm1_enc_take(ENC_SELECT);
            if (e) { if (menu_kind == MK_ADD) add_scroll(e); else menu_scroll(e); }
            e = fm1_enc_take(ENC_PRESETS);
            if (e) { if (menu_kind == MK_ADD) add_scroll(e); else menu_scroll(e); }
            if (menu_on && (b & (1u << BTN_OCT_UP))) {
                if (menu_kind == MK_ADD) {                      /* a console: its channels */
                    add_console = add_chip(); add_card = 0;
                    menu_open_pick(ADD_SUB[add_console].l, ADD_SUB[add_console].n); menu_kind = MK_ADD2;
                } else if (menu_kind == MK_COPY) {
                    int c;
                    menu_on = 0; rack_force = 1; chip_drawn = ~0u;
                    if (menu_sel < 3u && sel < chan_n && chan_n < MAXCH && (c = chan_add(chan[sel].kind)) >= 0) {       /* 1 patch only, 2 patch and notes */
                        uint32_t p;
                        chan[c].in = chan[sel].in; chan[c].fm = chan[sel].fm; chan[c].wcus = chan[sel].wcus; memcpy(chan[c].user, chan[sel].user, sizeof chan[c].user);
                        if (menu_sel == 2u) for (p = 0; p < page_n; p++) seq_track_copy(p, c, sel);
                        sel = (uint32_t)c; proj_edited(); rack_inval = 1;
                        anim_start(AN_ADD, KIND_CHIP[chan[c].kind] | (uint32_t)c << 8);
                    }
                } else if (menu_kind == MK_ADD2 && chg_ch < chan_n) {                    /* change the channel's console: its notes stay */
                    uint32_t kind = ADD_SUB[add_console].kind[menu_sel - 1u], p, any = 0;
                    sel = chg_ch; chg_ch = 255u; menu_on = 0; rack_force = 1; chip_drawn = ~0u; rack_inval = 1;
                    if (IS_DRUM(kind) != IS_DRUM(chan[sel].kind))
                        for (p = 0; p < page_n; p++) { uint32_t s; for (s = 0; s < SEQ_MAXLEN; s++) if (STEP_R(p, sel, s)->note || STEP_R(p, sel, s)->vel) any = 1; }
                    if (any) { chg_kind = kind; rack_rm = 2; }                                  /* notes would go: ask first */
                    else { seq_stop(); chip_off(sel); chan_set_kind(sel, kind); proj_edited(); anim_start(AN_ADD, KIND_CHIP[kind] | sel << 8); }
                } else if (menu_kind == MK_ADD2) {
                    int c = chan_add(ADD_SUB[add_console].kind[menu_sel - 1u]);
                    if (c >= 0) { sel = (uint32_t)c; proj_edited(); anim_start(AN_ADD, KIND_CHIP[chan[c].kind] | (uint32_t)c << 8); }
                    menu_on = 0; rack_force = 1; chip_drawn = ~0u;
                } else if (menu_kind == MK_MENU) {
                    const uint32_t id = sys_id[menu_sel];
                    if (id == SI_LES) {                                                                                           /* the lessons list, or the running lesson ends */
                        if (les_on) { les_exit(); menu_on = 0; view = 1; sel = 0; seq_view = 0; rack_force = 1; chip_drawn = ~0u; rack_inval = 1; hdr_force = 1; }
                        else les_list_open();
                    }
                    else if (id == SI_SET || id == SI_SYNC || id == SI_RST) { sys_group = id - SI_SET + 1u; sys_open(set.demo, 1); }       /* a group */
                    else if (id == SI_BT) bt_open(1);                                                                             /* the Bluetooth page */
                    else if (id == SI_FACT) { menu_open(CONF_FACTORY, sizeof CONF_FACTORY / sizeof CONF_FACTORY[0]); menu_kind = MK_FACTORY; }
                    else if (id == SI_DEMO) {                                                                                   /* Restore Demos: the deleted ones are made again */
                        if (proj_demos_free_empty()) {
                            if (les_on) les_exit();
                            seq_stop(); rec_on = 0; duck_ch = 255;
                            if (proj_dirty && proj_save(proj_cur) == 0) proj_dirty = 0;
                            proj_demos_restore();
                            proj_loaded = proj_load(proj_cur) == 0;
                            if (!proj_loaded) { if (proj_is_demo(proj_cur) && proj_cur == 0u) seq_tetris(); else if (proj_is_demo(proj_cur) && proj_cur == 1u) seq_symphony(); else proj_blank(); }
                            undo_reset(); proj_dirty = 0; rack_inval = 1; rack_force = 1; chip_drawn = ~0u;
                        }
                        sys_open(set.demo, menu_sel);       /* (the last demo came back: the row is gone, the bar steps up) */
                    }
                    else if (id == SI_ANIM || id == SI_BAT) {                                                                         /* Dancing Animations, Show Battery: stored inverted in set.an[2] bits 5 and 6 */
                        if (id == SI_ANIM) opt_noanim ^= 1u; else opt_nobat ^= 1u;
                        set.an[2] = (uint8_t)((set.an[2] & 0x9Fu) | opt_noanim << 5 | opt_nobat << 6); dirty = 1; t_change = fm1_ms; sys_open(set.demo, menu_sel); hdr_force = 1;
                    }
                    else if (id == SI_CLK) { clk_mode = (uint8_t)((clk_mode + 1u) % 3u); bt_pack(); if (clk_mode != 2u) ext_on = 0; dirty = 1; t_change = fm1_ms; sys_open(set.demo, menu_sel); }       /* off, send, follow */
                    else { set.demo ^= (uint8_t)(id == SI_QS ? QS_ALWAYS : id == SI_PICK ? QS_PICK : QS_NOTIPS); dirty = 1; t_change = fm1_ms; sys_open(set.demo, menu_sel); }       /* a switch: the line says Yes or No */
                } else if (menu_kind == MK_BT) {                                    /* Sync, (Status), Sidechain, Patterns */
                    if (menu_sel == 1u) brothers_set(((uint32_t)brothers_mode + 1u) % 3u);
                    else if (menu_sel == 3u) bt_side ^= 1u;
                    else if (menu_sel == 4u) bt_patsync ^= 1u;
                    else if (menu_sel == 5u) bt_fxsync ^= 1u;
                    else if (menu_sel == 6u) bt_key ^= 1u;
                    if (menu_sel == 7u) {                                   /* Demo: the locked project (it is a demo slot: nothing is saved) */
                        seq_stop(); seq_bt_demo(); proj_lock = 1; if (proj_is_demo(0)) proj_cur = 0; proj_dirty = 0; rack_force = 1; chip_drawn = ~0u; sel = 0; rack_inval = 1; menu_on = 0;
                    } else { bt_pack(); bt_open(menu_sel); }
                } else if (menu_kind == MK_FACTORY) {
                    FACTORY_RESET();
                }
            } else if (menu_on && (b & (1u << BTN_OCT_DOWN)) && menu_kind == MK_ADD2) { add_open(add_console); }       /* back to the consoles */
            else if (menu_on && (b & (1u << BTN_OCT_DOWN)) && menu_kind == MK_MENU && sys_group) { const uint32_t g = sys_group; sys_group = 0; sys_open(set.demo, g + 1u); }       /* back up to the top */
            else if (menu_on && (b & (1u << BTN_OCT_DOWN)) && (menu_kind == MK_BT || menu_kind == MK_FACTORY)) { sys_group = menu_kind == MK_BT ? 2u : 3u; sys_open(set.demo, 99u); }       /* back to the group it came from */
            else if (menu_on && (b & (1u << BTN_OCT_DOWN)) && menu_kind != MK_MANUAL) { menu_on = 0; rack_force = 1; chip_drawn = ~0u; }
            fm1_enc_take(ENC_ALGORITHM);
            for (k = 0; k < 4u; k++) fm1_enc_take(ENC_KNOB1 + k);
        } else if (view == 2u) {                        /* the song: SELECT moves (and plays the page once), PRESETS changes the slot's page, OCT+ a new blank page, OCT- removes the slot, EDIT opens the page in the rack */
            if (song_cur > song_len) song_cur = song_len;
            e = fm1_enc_take(ENC_SELECT);
            if (e) {
                song_cur = (song_cur + (e < 0 ? song_len : 1u)) % (song_len + 1u); rack_inval = 1;
                if (song_cur < song_len) { seq_view = song[song_cur]; if (!seq_run || seq_loop == 2u) { seq_stop(); seq_play(0, 2); } }
            }
            e = fm1_enc_take(ENC_PRESETS);
            if (e && song_cur < song_len) {
                song_cycle(song_cur, e); rack_inval = 1; proj_edited();
                if (!seq_run || seq_loop == 2u) { seq_stop(); seq_play(0, 2); }
            }
            if (b & (1u << BTN_OCT_UP)) {               /* a new slot with a new blank page */
                uint32_t pn = page_n;
                song_insert_blank(song_cur);
                if (page_n != pn) { song_cur = song_cur < song_len ? (song_cur + 1u < song_len ? song_cur + 1u : song_len - 1u) : song_len - 1u; rack_inval = 1; proj_edited(); anim_start(AN_COPY, (uint32_t)seq_view + 1u); }
            }
            if ((b & (1u << BTN_OCT_DOWN)) && song_len > 1u && song_cur < song_len) {
                uint32_t was = song[song_cur];
                song_remove(song_cur); rack_inval = 1; proj_edited();
                if (song_cur >= song_len) song_cur = song_len - 1u;
                anim_start(AN_PAGE, was + 1u);
            }
            if (edit_now && !edit_used && song_cur < song_len && fm1_ms - edit_t0 >= 600u) {      /* hold EDIT: a copy of this slot's page, in this slot */
                int np = seq_dup_page(song[song_cur]);
                if (np >= 0) { song[song_cur] = (uint8_t)np; seq_view = (uint8_t)np; rack_inval = 1; proj_edited(); anim_start(AN_COPY, (uint32_t)np + 1u); }
                edit_used = 1;
            }
            if (edit_rel && !edit_used && song_cur < song_len) {                                  /* a tap on EDIT: this page, in the rack */
                seq_view = song[song_cur]; view = 1; rack_force = 1; chip_drawn = ~0u;
            }
            e = fm1_enc_take(ENC_KNOB1);                /* knob 1: the tempo */
            if (e) { tempo_knob(e, 0u); proj_edited(); anim_tempo(); }
            fm1_enc_take(ENC_ALGORITHM);
            for (k = 1; k < 4u; k++) fm1_enc_take(ENC_KNOB1 + k);
        } else if (view == 3u) {                        /* STEP: SELECT moves the cursor, PRESETS the channel, ALGORITHM the page, EDIT clears the block, the octave buttons as everywhere */
            uint32_t oct_was = (uint32_t)(set.oct + 2);
            e = fm1_enc_take(ENC_SELECT);
            if (e) { const uint32_t pl = page_steps(seq_view), by = sel < chan_n && IS_DRUM(chan[sel].kind) ? SEQ_LEN : 1u; ed_cur = (ed_cur + (e < 0 ? pl - (by < pl ? by : 1u) : (by < pl ? by : 1u))) % pl; }       /* (a drum channel has no cursor: SELECT turns the screens) */
            e = fm1_enc_take(ENC_PRESETS);
            if (e && chan_n) { chip_off(sel); sel = e < 0 ? (sel ? sel - 1u : 0u) : (sel + 1u < chan_n ? sel + 1u : chan_n - 1u); anim_start(AN_CHAN, sel | (uint32_t)KIND_CHIP[chan[sel].kind] << 8); }
            e = fm1_enc_take(ENC_ALGORITHM);
            if (e) seq_page(e);
            e = fm1_enc_take(ENC_KNOB1);
            if (e) { tempo_knob(e, 1u); proj_edited(); anim_tempo(); }
            e = fm1_enc_take(ENC_KNOB2);                /* KNOB 2: how long the note is, in steps: the one you are holding, or the one under the cursor */
            if (e && sel < chan_n) {
                uint32_t st = ed_hold_k >= 0 ? ed_hold_step : ed_cur;
                step_t *x = STEP_W(seq_view, sel, st);
                if (x->note) {
                    int32_t n = ((int32_t)x->gate + 1) / 6 + e, mx = (int32_t)(page_steps(seq_view) - st);
                    n = n < 1 ? 1 : n > mx ? mx : n;
                    x->gate = (uint8_t)(n * 6 - 1); proj_edited();
                }
            }
            e = fm1_enc_take(ENC_KNOB1 + 2);            /* KNOB 3: the page's meter (waits for the next wrap if it plays) */
            if (e) { page_meter_step(seq_view, e); mt_t = fm1_ms | 1u; rack_inval = 1; proj_edited(); }
            e = fm1_enc_take(ENC_KNOB1 + 3);            /* KNOB 4: the page's length in bars */
            if (e) { page_bars_step(seq_view, e); mt_t = fm1_ms | 1u; rack_inval = 1; proj_edited(); }
            if (b & (1u << BTN_SEL)) { page_gl[seq_view] = (uint8_t)((page_gl[seq_view] + 1u) & 3u); rack_inval = 1; proj_edited(); }        /* SEL: glide into the next page's tempo: straight, ease in, ease out, off (a little curve by the tempo) */
            if ((b & (1u << BTN_EDIT)) && sel < chan_n && IS_DRUM(chan[sel].kind)) {         /* drums: EDIT clears the picked drum on this page */
                uint32_t p, any = 0;
                for (p = 0; p < SEQ_MAXLEN; p++) { step_t *x = STEP_W(seq_view, sel, p); uint32_t h = dstep_hits(x); if (h >> ed_lane & 1u) { dstep_set(x, h & ~(1u << ed_lane), dstep_acc(x) & ~(1u << ed_lane)); any = 1; } }
                if (any) proj_edited();
            }
            else if ((b & (1u << BTN_EDIT)) && sel < chan_n) { step_t *x = STEP_W(seq_view, sel, ed_cur); if (x->note) { x->note = 0; proj_edited(); } }
            if (b & (1u << BTN_OCT_DOWN) && set.oct > -2) { set.oct--; dirty = 1; t_change = fm1_ms; }
            if (b & (1u << BTN_OCT_UP) && set.oct < 2) { set.oct++; dirty = 1; t_change = fm1_ms; }
            if ((uint32_t)(set.oct + 2) != oct_was) anim_cont(AN_OCT, oct_was << 4 | (uint32_t)(set.oct + 2), 900u);
        } else {
        if (view == 1u && sel == chan_n && chan_n < MAXCH && (b & (1u << BTN_OCT_UP))) {                 /* OCT+ (yes) on the "+" row: add a channel */
            chg_ch = 255u; add_open(CHIPS); add_console = 0;
        } else if (rack_rm) {                           /* removing a channel: OCT+ yes, OCT- no */
            if (rack_rm == 2u) {                        /* changing between notes and drums clears the track: OCT+ yes, OCT- no */
                if (b & (1u << BTN_OCT_UP)) { seq_stop(); chip_off(sel); chan_set_kind(sel, chg_kind); proj_edited(); rack_rm = 0; rack_inval = 1; anim_start(AN_ADD, KIND_CHIP[chg_kind] | sel << 8); }
                else if (b & (1u << BTN_OCT_DOWN)) { rack_rm = 0; rack_inval = 1; }
            }
            else if (b & (1u << BTN_OCT_UP)) { uint32_t gone = KIND_CHIP[chan[sel].kind]; seq_stop(); chan_remove(sel); proj_edited(); rack_rm = 0; rack_inval = 1; anim_start(AN_REMOVE, gone | (uint32_t)sel << 8); }
            else if (b & (1u << BTN_OCT_DOWN)) { rack_rm = 0; rack_inval = 1; }
        } else {
            uint32_t oct_was = (uint32_t)(set.oct + 2);
            if (b & (1u << BTN_OCT_DOWN) && set.oct > -2) { set.oct--; dirty = 1; t_change = fm1_ms; }
            if (b & (1u << BTN_OCT_UP) && set.oct < 2) { set.oct++; dirty = 1; t_change = fm1_ms; }
            if ((uint32_t)(set.oct + 2) != oct_was) anim_cont(AN_OCT, oct_was << 4 | (uint32_t)(set.oct + 2), 900u);
        }
        if (view == 1u && sel < chan_n && edit_rel && !edit_used && !rack_rm && !rec_on && !fx_layer && !pick_on && !menu_on && !in_menu && !tip_on) {          /* tap EDIT on a channel: change its console */
            add_aud_stop(); chg_ch = sel; add_open(KIND_CHIP[chan[sel].kind]); add_console = 0;
        }
        if (view == 1u && sel < chan_n && edit_now && !edit_used && !rack_rm && !rec_on && fm1_ms - edit_t0 >= 600u) { rack_rm = 1; rack_inval = 1; edit_used = 1; anim_start(AN_DELETE, 0); }     /* hold EDIT on a channel: remove it? */
        e = fm1_enc_take(ENC_PRESETS);                  /* always: down the list of channels */
        if (!e) e = mpre;
        mpre = 0;
        if (e && nrows) {
            if (sel < chan_n) chip_off(sel);
            sel = e < 0 ? (sel ? sel - 1u : 0u) : (sel + 1u < nrows ? sel + 1u : nrows - 1u);       /* no wrap: the last row is a turn away */
            rack_rm = 0; rack_inval = 1; redraw = 1; last_note = 255u;
            if (sel < chan_n && !fx_layer) anim_start(AN_CHAN, sel | (uint32_t)KIND_CHIP[chan[sel].kind] << 8);
            if (rec_on) duck_ch = (uint8_t)(sel < chan_n ? sel : 255u);
        }
        e = fm1_enc_take(ENC_ALGORITHM);                /* the rack: the page; the chip screen: the knobs' page */
        if (!e) e = malg;
        malg = 0;
        if (e) {
            if (view == 1u) {
                uint32_t pn = page_n, was = seq_view;
                seq_page(e); rack_inval = 1;
                if (page_n != pn) proj_edited();
                if (seq_view != was) anim_start(AN_PAGE, (was + 1u) | (e < 0 ? 256u : 0u));
            }
            else if (sel < chan_n) { uint32_t np = pages(sel); chip_page = (chip_page + (e < 0 ? np - 1u : 1u)) % np; redraw = 1; }
        }
        e = fm1_enc_take(ENC_SELECT);                   /* the tape dial: middle pauses, right goes on, left goes back; in the punch-in layer only while TAPE is held */
        if (e && view == 0u && !fx_layer && sel < chan_n && chip_page == wd_pg(sel)) {      /* on the DRAW page SELECT is the cursor along the samples (no wrap) */
            int32_t v = (int32_t)(dr_cur > wd_cmax(sel) ? wd_cmax(sel) : dr_cur) + e;
            dr_cur = (uint32_t)(v < 0 ? 0 : v > (int32_t)wd_cmax(sel) ? (int32_t)wd_cmax(sel) : v); redraw = 1;
        } else if (e && (!fx_layer || (fx_held & FXB(FX_TAPE)))) { seq_shuttle(e); anim_tape(); rack_inval = 1; }
        for (k = 0; k < 4u; k++) {
            e = fm1_enc_take(ENC_KNOB1 + k);
            if (!e) continue;
            if (view == 1u) {
                if (k == 0u) { tempo_knob(e, 0u); rack_inval = 1; proj_edited(); anim_tempo(); }     /* knob 1: the tempo */
                else if (sel < chan_n) {
                    inst_t *ri = &chan[sel].in;
                    if (k == 1u) { ri->vol = (uint8_t)clamp_i((int32_t)ri->vol + e, 0, 15); rack_bar_t = fm1_ms | 1u; rack_bar_row = sel; }                  /* knob 2: the channel's level */
                    else if (k == 2u) {                                                                    /* knob 3: slide the channel's steps along this page (round the ends) */
                        seq_slide(seq_view, sel, e);
                    } else if (!IS_DRUM(chan[sel].kind)) { ri->duck = (uint8_t)clamp_i((int32_t)ri->duck + e, 0, 15); rack_bar_t = fm1_ms | 1u; rack_bar_row = sel; }      /* knob 4: the sidechain, how far a kick pulls it down */
                    rack_inval = 1; proj_edited();
                }
            } else if (sel < chan_n) {
                knob_set(sel, chip_page, k, e); redraw = 1;
                if (chip_page != wd_pg(sel) || k == 0u) proj_edited();       /* (the brush and the mirror are not part of the song) */
                if (chip_page == 3u && has_wave(sel)) anim_cont(AN_WAVE, (uint32_t)sel, 1200u);
            }
        }
        }
        }
        if (ext_on && fm1_ms - ext_ms > 400u) ext_on = 0;                       /* the outside clock stopped */
        { static uint32_t paused;                                                                                                        /* the installer is talking: the Bluetooth radio goes quiet (it makes the FM-1 miss requests), and comes back 20 s after */
          if (ota_hit_ms && brothers_mode && !paused) { paused = brothers_mode; brothers_set(0); }
          if (paused && fm1_ms - ota_hit_ms > 20000u) { brothers_set(paused); paused = 0; ota_hit_ms = 0; } }
        if (ota_back) { ota_back = 0; rack_force = 1; chip_drawn = ~0u; rack_inval = 1; menu_dirty = 1; }          /* the installer gave up and left its message on the screen: paint it all again */
        brothers_poll();                                                        /* a follower: the leader's packets into clock ticks */
        if (brothers_mode == 1u) {                                              /* the leader: its pattern and where the kicks are (the drums' first lane) */
            uint32_t km = 0, s2, t2;
            if (seq_len == 16u)                                                 /* the followers' sidechain counts a 16 step bar: a page of another length sends no kicks */
                for (t2 = 0; t2 < chan_n; t2++) if (IS_DRUM(chan[t2].kind)) for (s2 = 0; s2 < 16u; s2++) if (dstep_hits(STEP_R(seq_pat, t2, s2)) & 1u) km |= 1u << s2;
            {                                                                   /* the key of what plays, every third of a second; the punch-in pads held, as the brothers' effects */
                static uint32_t sc_ms, sc_val;
                if (fm1_ms - sc_ms > 300u) {
                    uint8_t nt[64];
                    uint32_t nn = 0, t3, s3;
                    sc_ms = fm1_ms;
                    for (t3 = 0; t3 < chan_n; t3++) if (!IS_DRUM(chan[t3].kind)) for (s3 = 0; s3 < 16u && nn < 64u; s3++) if (STEP_R(seq_pat, t3, s3)->note) nt[nn++] = STEP_R(seq_pat, t3, s3)->note;
                    sc_val = brothers_detect(nt, nn);
                }
                brothers_lead_set(seq_pat < 16u ? seq_pat : 0xFFu, km, fx_to_shared(fx_held), sc_val, 0);       /* (the link's pattern number is 0..15) */
            }
        } else if (brothers_mode == 2u && bt_patsync && seq_run && seq_loop == 1u) {                   /* a follower: the leader's pattern, at the end of this one */
            uint32_t p = brothers_pat();
            if (p != 0xFFu && p != bt_last) { bt_last = (uint8_t)p; if (p < page_n && p != seq_pat && !page_empty(p)) { seq_next = (uint8_t)p; seq_view = (uint8_t)p; } }       /* (a page with nothing in it: stay where we are) */
        } else if (brothers_mode != 2u) bt_last = 0xFFu;
        bt_scale = (uint8_t)(brothers_mode == 2u && bt_key ? brothers_scale() : 0u);                    /* a follower with Key on: the leader's key */
        { uint32_t want = brothers_mode == 2u && bt_fxsync ? fx_from_shared(brothers_fx()) : 0u; bt_fx_cur = want; if (!fx_layer && fx_held != want) fx_apply(want); }       /* the leader's punch-in pads, held as ours */
        if (menu_on && menu_kind == MK_BT) { static uint32_t bt_ms; if (fm1_ms - bt_ms > 300u) { bt_ms = fm1_ms; bt_texts(); menu_dirty = 1; } }
        { static uint32_t mk_sel; if (sel != mk_sel) { mk_sel = sel; memset(mk_n, 0, sizeof mk_n); for (k = 0; k < MAXCH; k++) { live_bend[k] = 0; live_mod[k] = 0; } } }       /* another channel: the held keys are forgotten */
        while (midi_get(&st, &d1, &d2) || bt_get(&st, &d1, &d2)) {
            uint32_t mt = midi_src ? sel : st & 0xFu;        /* USB: MIDI channel n plays channel n; the TRS jack plays the selected channel */
            if (st >= 0xF8u) {                              /* real time: the clock and the transport (only when MIDI Clock is Follow; from the brothers' link, when it follows) */
                if (d1 == 0x55u ? brothers_mode != 2u : clk_mode != 2u) continue;
                if (st == 0xF8u) {
                    ext_ms = fm1_ms;
                    if (!ext_on) { ext_reset = 1; ext_n = 0; ext_t0 = fm1_ms; ext_on = 1; }
                    ext_in++;
                    if (d1 == 0x55u) { uint32_t nb = brothers_bpm(); if (nb >= 30u && nb <= 255u) seq_bpm = nb; }     /* the leader says its tempo exactly */
                    else if (++ext_n >= 24u) {                    /* a quarter note: the tempo, from the spacing of the ticks */
                        uint32_t dt = fm1_ms - ext_t0;
                        ext_n = 0; ext_t0 = fm1_ms;
                        if (dt >= 250u && dt <= 1500u) { uint32_t nb = 60000u / dt; seq_bpm = nb > seq_bpm + 4u || nb + 4u < seq_bpm ? nb : (seq_bpm * 3u + nb + 2u) / 4u; }      /* a new tempo at once, small drift smoothed */
                    }
                } else if (st == 0xFAu || (st == 0xFBu && !seq_run)) {             /* start, continue: as a tap on PLAY */
                    uint32_t s = 0;
                    if (seq_run) seq_stop();
                    while (s < song_len && song[s] != seq_view) s++;
                    if (d1 == 0x55u && bt_patsync) { uint32_t p = brothers_pat(); if (p != 0xFFu && p < page_n) seq_view = (uint8_t)p; seq_play(0, 1); }                       /* following the leader's patterns: round one page */
                    else if (view == 2u) seq_play(song_cur < song_len ? song_cur : 0u, 0); else if (s < song_len) seq_play(s, 0); else seq_play(0, 1);
                    anim_start(AN_PLAY, 0);
                } else if (st == 0xFCu && seq_run) { seq_stop(); rec_on = 0; duck_ch = 255; anim_start(AN_PAUSE, 0); }
                continue;
            }
            if ((st & 0xF0u) == 0xC0u) {                    /* program change: pick the channel */
                if (chan_n) { if (sel < chan_n) chip_off(sel); sel = d1 % chan_n; last_note = 255u; mk_n[sel] = 0; rack_inval = 1; }
                continue;
            }
            if ((st & 0xF0u) == 0xB0u && midi_src && d1 == 114u) {                      /* the keyboard's main knob (MiniLab 3, Relative): the channel in the rack (PRESETS), the knobs' page on the chip screen (ALGORITHM) */
                if (!menu_on && !pick_on && !fx_layer) { if (view == 1u) mpre += (int32_t)d2 - 64; else if (view == 0u) malg += (int32_t)d2 - 64; }
                continue;
            }
            if ((st & 0xF0u) == 0xB0u && midi_src && d1 >= 100u && d1 <= 119u) {       /* the test controls (CC 100-119) are for USB only: a keyboard's buttons send these numbers. The MiniLab's transport: 107 Play, 106 Stop, 108 Rec (127 down, 0 up) */
                if (d2 >= 64u && !menu_on && !pick_on) {
                    if (d1 == 107u) {                                              /* Play: as PLAY (paused on the tape: go on; already playing: nothing, Stop is the other button) */
                        if (seq_run && seq_hold) { seq_rate = 2; seq_hold = 0; anim_start(AN_PLAY, 0); }
                        else if (!seq_run) {
                            uint32_t s = 0;
                            while (s < song_len && song[s] != seq_view) s++;
                            if (view == 2u) seq_play(song_cur < song_len ? song_cur : 0u, 0); else if (view == 1u && s < song_len) seq_play(s, 0); else seq_play(0, 1);
                            anim_start(AN_PLAY, 0);
                        }
                    } else if (d1 == 106u) { if (seq_run) { seq_stop(); rec_on = 0; duck_ch = 255; anim_start(AN_PAUSE, 0); } }
                    else if (d1 == 108u && view != 2u && view != 3u && sel < chan_n && !IS_DRUM(chan[sel].kind)) {      /* Rec: as REC */
                        if (rec_on) { rec_on = 0; duck_ch = 255; seq_stop(); anim_start(AN_REC, 1); }
                        else { rec_on = 1; duck_ch = (uint8_t)sel; if (!seq_run) seq_play(0, 1); anim_start(AN_REC, 0); }
                    }
                }
                continue;
            }
            if ((st & 0xF0u) == 0xB0u && d1 == 102u) { if (d2 >= 64u) seq_play(0, 0); else if (seq_run) seq_stop(); continue; }
            if ((st & 0xF0u) == 0xB0u && d1 == 119u) { seq_stop(); seq_bt_demo(); proj_lock = 1; if (proj_is_demo(0)) proj_cur = 0; proj_dirty = 0; rack_force = 1; chip_drawn = ~0u; sel = 0; rack_inval = 1; menu_on = 0; continue; }       /* test: the Bluetooth demo */
            if ((st & 0xF0u) == 0xB0u && d1 == 103u) { seq_bpm = d2 * 2u; proj_edited(); continue; }
            if ((st & 0xF0u) == 0xB0u && d1 == 104u) { if (!proj_is_demo(proj_cur) && proj_save(proj_cur) == 0) { proj_dirty = 0; proj_t_saved = fm1_ms | 1u; } continue; }
            if ((st & 0xF0u) == 0xB0u && d1 == 108u) { fx_apply(d2 == 0u ? 0u : d2 <= FXN ? fx_held | FXB(d2 - 1u) : d2 <= 2u * FXN ? fx_held & ~FXB(d2 - 1u - FXN) : fx_held); if (d2 && d2 <= FXN) anim_fx(d2 - 1u); continue; }     /* test: pad d2-1 on; d2 17..32: pad off; 0: all off */
            if ((st & 0xF0u) == 0xB0u && d1 == 106u) { if (chan_add(d2) >= 0) proj_edited(); continue; }              /* test: add a channel of kind d2 */
            if ((st & 0xF0u) == 0xB0u && d1 == 109u) { static uint32_t arm; if (d2 == 127u) arm = fm1_ms | 1u; else if (d2 == 1u && arm && fm1_ms - arm < 3000u) { arm = 0; FACTORY_RESET(); } continue; }                   /* test: Factory Reset: CC 109 = 127, then CC 109 = 1 within 3 s (so a controller's stray CC cannot wipe projects) */
            if ((st & 0xF0u) == 0xB0u && d1 == 107u) { if (chan_n) { seq_stop(); chan_remove(chan_n - 1u); proj_edited(); } continue; }     /* test: remove the last channel */
            if ((st & 0xF0u) == 0xB0u && d1 == 105u && d2 < PROJ_SLOTS) { if (les_on) les_exit(); proj_open(d2); set.proj = (uint8_t)proj_cur; dirty = 1; t_change = fm1_ms; rack_force = 1; chip_drawn = ~0u; sel = 0; continue; }
            if ((st & 0xF0u) == 0xE0u) { if (mt < chan_n) live_bend[mt] = ((int32_t)(d1 | d2 << 7) - 8192) >> 4; continue; }       /* pitch wheel: +-2 semitones */
            {                                                /* the keyboard's pads (MiniLab 3, TRS): notes 36-51 on channel 10, or in its CC pad mode CC 56-63 (127 down, 0 up); the FX pads, and on a drum channel outside the layer the kit */
                static const uint8_t PC[8] = {0, 1, 2, 3, 6, 7, 4, 5};      /* CC 56..63 -> the pad's place in the bank */
                uint32_t pn = 99u, pon = 0u, pv = d2;
                if (midi_src && (st & 0xFu) == 9u && d1 >= 36u && d1 < 52u && ((st & 0xF0u) == 0x90u || (st & 0xF0u) == 0x80u)) { pn = d1 - 36u; pon = (st & 0xF0u) == 0x90u && d2; }
                else if (midi_src && (st & 0xF0u) == 0xB0u && d1 >= 56u && d1 <= 63u) { pn = PC[d1 - 56u]; pon = d2 >= 64u; pv = 127u; }
                if (pn < 16u) {
                    if (pon) {
                        midi_pad |= 1u << pn;
                        if (!fx_layer && !menu_on && !pick_on && sel < chan_n && IS_DRUM(chan[sel].kind) && pn < 11u) { if (view == 3u) ed_lane = pn; chip_note(sel, DR_LANE_TYPE[pn], pv); }
                    } else midi_pad &= ~(1u << pn);
                    continue;
                }
            }
            if ((st & 0xF0u) == 0xB0u && (d1 == 82u || d1 == 83u || d1 == 85u || d1 == 17u)) {       /* the keyboard's four faders (MiniLab 3, absolute 0-127): the level of channels 1 to 4. Pickup: a fader does nothing until it passes the channel's level, so it never jumps */
                static const uint8_t FC[4] = {82, 83, 85, 17};
                static uint8_t fl[4] = {255, 255, 255, 255}, fe[4], fs[4] = {255, 255, 255, 255};       /* last position, engaged, the level we set last */
                uint32_t j = 0, lv = d2 >> 3;
                while (FC[j] != d1) j++;
                if (j < chan_n) {
                    inst_t *fi = &chan[j].in;
                    if (fe[j] && fi->vol != fs[j]) fe[j] = 0;                                   /* the level was changed elsewhere: pick it up again */
                    if (!fe[j] && fl[j] != 255u && ((fl[j] <= fi->vol && fi->vol <= lv) || (lv <= fi->vol && fi->vol <= fl[j]))) fe[j] = 1;
                    if (!fe[j] && lv == fi->vol) fe[j] = 1;
                    if (fe[j] && fi->vol != lv) {
                        fi->vol = (uint8_t)lv; fs[j] = (uint8_t)lv;
                        live_dirty[j] = 1; rack_bar_t = fm1_ms | 1u; rack_bar_row = j; rack_inval = 1; redraw = 1; proj_edited();
                    } else if (fe[j]) fs[j] = fi->vol;
                }
                fl[j & 3u] = (uint8_t)lv;
                continue;
            }
            if ((st & 0xF0u) == 0xB0u) {                    /* the keyboard's eight knobs (MiniLab 3 set to Relative: 64 + clicks, 62 = two clicks down): the Chip view's page on screen, and the one after it */
                static const uint8_t KC[8] = {74, 71, 76, 77, 93, 18, 19, 16};
                static int32_t ka[8];
                uint32_t j = 0;
                while (j < 8u && KC[j] != d1) j++;
                if (j < 8u) {
                    if (view == 0u && !fx_layer && !menu_on && sel < chan_n) {
                        int32_t n;
                        ka[j] += (int32_t)d2 - 64;
                        n = ka[j] / 3;
                        if (n) {
                            int32_t sg = n < 0 ? -1 : 1;
                            uint32_t pg = chip_page + (j >> 2);
                            ka[j] -= n * 3;
                            if (pg < pages(sel) && pg != wd_pg(sel)) {
                                for (n = n < 0 ? -n : n; n > 0; n--) knob_set(sel, pg, j & 3u, sg);
                                live_dirty[sel] = 1; redraw = 1; proj_edited();
                                if (pg == 3u && has_wave(sel)) anim_cont(AN_WAVE, (uint32_t)sel, 1200u);
                            }
                        }
                    } else ka[j] = 0;
                    continue;
                }
            }
            if ((st & 0xF0u) == 0xB0u && d1 == 1u) { if (mt < chan_n) live_mod[mt] = d2; continue; }                      /* mod wheel: vibrato */
            if ((st & 0xF0u) == 0x90u && d2) {
                if (mt < chan_n) {
                    mk_on(mt, d1, d2);
                    if (rec_on && seq_run && !seq_hold && view < 2u && mt == sel && !IS_DRUM(chan[mt].kind)) {      /* recording: the note goes on the step nearest the playhead, at the key's velocity */
                        uint32_t a, sb, stp, pg;
                        do { a = seq_step; sb = seq_sub; } while (a != seq_step);
                        stp = (a * SEQ_PPS + sb + SEQ_PPS / 2u) / SEQ_PPS % (seq_len ? seq_len : SEQ_LEN); pg = seq_pat;
                        { step_t *x = STEP_W(pg, mt, stp); x->note = (uint8_t)d1; x->vel = (uint8_t)d2; x->gate = 5; }
                        mrec_t0[d1] = seq_ticks | 1u; mrec_pg[d1] = (uint8_t)pg; mrec_st[d1] = (uint8_t)stp; mrec_ch[d1] = (uint8_t)mt;
                        rack_inval = 1; proj_edited();
                    }
                }
            }
            else if ((st & 0xF0u) == 0x80u || (st & 0xF0u) == 0x90u) {
                if (mt < chan_n) mk_off(mt, d1);
                if (d1 < 128u && mrec_t0[d1]) {                    /* a recorded note: its length is how long the key was down */
                    step_t *x = STEP_W(mrec_pg[d1], mrec_ch[d1], mrec_st[d1]);
                    uint32_t g = seq_ticks - (mrec_t0[d1] & ~1u);
                    if (x->note == d1) x->gate = (uint8_t)(g < 1u ? 1u : g > 96u ? 96u : g);
                    mrec_t0[d1] = 0; rack_inval = 1;
                }
            }
        }

        for (k = 0; k < 27u; k++)
            if (prev >> k & 1u && last_note == held[k]) lit |= 1u << k;
        if (seq_run && sel < chan_n && vc[sel].on) {            /* playing: the key of the note the playhead has reached lights */
            int32_t ki = (int32_t)vc[sel].note - (int32_t)base;
            if (ki >= 0 && ki < 27) lit |= 1u << ki;
        }
        if (fx_layer) {                                 /* the pads' keys glow, the held ones are bright */
            uint32_t p;
            for (k = 0; k < 27u; k++) { fm1_led_key(KEY_LED(k), 0); fm1_led_glow(KEY_LED(k), 0); }
            for (p = 0; p < FXN; p++) { fm1_led_glow(KEY_LED(FX_KEY[p]), 1); if (fx_mask >> p & 1u) fm1_led_key(KEY_LED(FX_KEY[p]), 1); }
        } else {
            uint32_t dr = sel < chan_n && IS_DRUM(chan[sel].kind);
            if (dr && view == 3u) {                                                  /* the lanes: the picked drum's black key, and a white key for each of its steps */
                uint32_t p;
                lit = 1u << BLK_KEY[ed_lane];
                for (p = 0; p < FXN; p++) if (dstep_hits(STEP_R(seq_view, sel, vwin * SEQ_LEN + p)) >> ed_lane & 1u && vwin * SEQ_LEN + p < page_steps(seq_view)) lit |= 1u << FX_KEY[p];
            }
            for (k = 0; k < 27u; k++) { fm1_led_glow(KEY_LED(k), dr && BLK_IDX[k] >= 0); fm1_led_key(KEY_LED(k), lit >> k & 1u); }       /* a drum channel: the eight kit keys glow */
        }
        fx_solo_ch = (fx_held & FXB(FX_SOLO)) && sel < chan_n ? (uint8_t)sel : 255u;
        fm1_led_glow(BTN_LFO, undo_cnt > 0u || undo_open);
        fm1_led_key(BTN_ARP, rack_tails);
        fm1_led_key(BTN_SEL, (view == 0u && sel < chan_n && IS_FMK(chan[sel].kind) && fm_foc) || (view == 3u && page_gl[seq_view]));
        fm1_led_glow(BTN_ENV, view == 3u && sel < chan_n && IS_DRUM(chan[sel].kind));          /* drums: ENV is the accent */
        fm1_led_key(BTN_SEQ, view == 3u);
        fm1_led_key(BTN_FX, fx_layer);
        fm1_led_key(BTN_PLAY, seq_run);
        fm1_led_key(BTN_REC, rec_on);
        fm1_led_glow(BTN_SAVE, proj_dirty);             /* a dim light: edits not saved yet */
        fm1_led_key(BTN_SAVE, proj_t_saved && fm1_ms - proj_t_saved < 500u);
        fm1_led_key(BTN_OCT_DOWN, set.oct < -1);    /* octave: dim at +-1, bright at +-2 */
        fm1_led_glow(BTN_OCT_DOWN, set.oct == -1);
        fm1_led_key(BTN_OCT_UP, set.oct > 1);
        fm1_led_glow(BTN_OCT_UP, set.oct == 1);
        if ((pick_on && pick_del) || rack_rm) { fm1_led_key(BTN_OCT_DOWN, 1); fm1_led_key(BTN_OCT_UP, 1); }     /* yes or no */

        cpu = cpu_max / (58u * FM1_TICKS_PER_US);     /* percent of the 5.8 ms block */
        if (fm1_ms - cc_ms >= 500u) { cc_ms = fm1_ms; midi_send(0xB0, 100, cpu > 127u ? 127u : cpu); midi_send(0xB0, 101, proj_cur | (proj_dirty ? 0x10u : 0u) | (proj_loaded ? 0x20u : 0u) | (menu_on && menu_kind == MK_MANUAL && man_lock ? 0x40u : 0u)); }
        if (an_kind == AN_CRIT && act_ms >= an_t0) an_end = 0;           /* touched: the critter goes */
        if (!opt_noanim && !les_on && !anim_on() && !rec_on && !fx_layer && !menu_on && !pick_on && !tip_on && fm1_ms - act_ms > CRIT_MS && fm1_ms >= crit_next) {
            anim_start(AN_CRIT, crit_n++ % 6u); crit_next = fm1_ms + 15000u;
        }
        if (tip_on) {                                   /* a tip is up: a touch, a timeout, or anything starting closes it */
            if (act_ms >= tip_t0 || menu_on || pick_on || seq_run || fx_layer) { tip_on = 0; rack_force = 1; chip_drawn = ~0u; }
            else if (fm1_ms - tip_t0 >= TIP_EVERY) { tip_open(); tip_redo = 1; }          /* the next tip, in the same window */
        } else if (!(set.demo & QS_NOTIPS) && fm1_ms - act_ms > TIP_IDLE && !les_on && !seq_run && quiet() && !menu_on && !pick_on && !fx_layer && !rec_on && !rack_rm && !anim_on() && add_aud_c < 0 && !start_pick) tip_open();
        add_aud_tick(); add_info_tick();
        const uint32_t les_rdn = les_reading() && !pick_on && !menu_on, les_cov = (menu_on && menu_kind != MK_ADD && menu_kind != MK_ADD2 && menu_kind != MK_COPY) || pick_on || tip_on || les_rdn, les_str = view == 3u && mt_t && fm1_ms - mt_t < MT_MS;
        { static uint32_t rd_was; if (rd_was && !les_rdn) { rack_force = 1; chip_drawn = ~0u; rack_inval = 1; hdr_force = 1; redraw = 1; ch_drawn = 99; } rd_was = les_rdn; }       /* a page to read was put away: the screen under it is painted again */
        { const uint32_t top = les_wants_top(view); if (top != les_top) { les_top = top; les_anim_t = fm1_ms; les_moving = 1; les_drawn = ~0u; } }
        les_clip(les_cov, les_str);        /* the screen below never paints over the lesson card while it shows what it should */
        {   static uint32_t win_was;                    /* a window just closed: the view under it is painted again only where the window was */
            uint32_t wu = tip_on || les_rdn || (menu_on && menu_kind != MK_MANUAL && menu_kind != MK_ADD);
            win_restore = win_was && !wu; win_was = wu;
            view_sig = view | (uint32_t)fx_layer << 2 | (view == 0u ? sel << 4 | chip_page << 12 : 0u);
        }
        {   static uint32_t dim_done;                   /* a window is up: the view is painted once more, faded, then the window goes on top */
            if (tip_redo) { dim_done = 0; tip_redo = 0; }
            const uint32_t dimw = tip_on || les_rdn || (menu_on && (menu_kind == MK_MENU || menu_kind == MK_COPY || menu_kind == MK_FACTORY));
            const uint32_t m0 = menu_on, t0 = tip_on, dpass = dimw && !dim_done;
            uint32_t les_rd = les_rdn;                  /* a lesson's read page is up */
            uint32_t pass;
            if (!dimw) dim_done = 0;
        for (pass = dpass ? 0u : 1u; pass < 2u; pass++) {
        if (pass == 0u) { menu_on = 0; tip_on = 0; les_rd = 0; les_rdirty = 1; gfx_dim = 1; gfx_dim_bg = view == 0u && sel < chan_n ? t->bg : R_BG; rack_force = 1; chip_drawn = ~0u; redraw = 1; ch_drawn = 99; }
        else { menu_on = m0; tip_on = t0; les_rd = les_rdn; gfx_dim = 0; if (dpass) dim_done = 1; }
        if (pick_on) { if (pick_dirty) { pick_draw(); pick_dirty = 0; } }
        else if (menu_on) { if (menu_dirty) { menu_draw(t->acc); menu_dirty = 0; }      /* (the three bands cover the whole screen: no clear first, that was the flash) */ }
        else if (tip_on) { if (tip_dirty) { tip_draw(); tip_dirty = 0; } }          /* the window stays; the view under it waits */
        else if (les_rd) { if (les_rdirty) { les_read_draw(); les_rdirty = 0; } }       /* a lesson's page to read */
        else if (fx_layer) {
            if (rack_force) { fx_view_force = 1; hdr_force = 1; rack_force = 0; }
            fx_view_update(); hdr_update(view, sel, t, ch_chip, last_note);
        }
        else if (view == 3u && sel < chan_n) { if (IS_DRUM(chan[sel].kind)) drum_update(sel, rack_force); else ed_update(sel, base, rack_force); rack_force = 0; hdr_update(3, sel, t, ch_chip, last_note); }
        else if (view == 2u) { sg_update(rack_force); rack_force = 0; hdr_update(2, sel, t, ch_chip, last_note); }
        else if (view == 1u) { rack_update(sel, rack_force); rack_force = 0; hdr_update(1, sel, t, ch_chip, last_note); }
        else if (sel < chan_n) {
            if (chip_drawn != ch_chip) {
                chip_drawn = ch_chip; draw_header(t, ch_chip); hdr_force = 1;
                note_drawn = ~0u; ch_drawn = 99;
            }
            if (redraw || ch_drawn != sel) { chip_panels(t, sel, chip_page); ch_drawn = (uint8_t)sel; }
            hdr_update(0, sel, t, ch_chip, last_note);
        }
        }
        }

        les_card(les_cov, les_str);        /* the lesson's card */
        if (proj_dirty && !les_on && !proj_is_demo(proj_cur) && !proj_lock && !seq_run && !pick_on && add_aud_c < 0 && quiet() && fm1_ms - proj_t_edit > 2000u && (!proj_t_fail || fm1_ms - proj_t_fail > 10000u)) {   /* stopped and silent: save the project */
            if (proj_save(proj_cur) == 0) { proj_dirty = 0; proj_t_saved = fm1_ms | 1u; } else proj_t_fail = fm1_ms;
        }
        if (dirty && quiet() && fm1_ms - t_change > 2000u) {
            settings_save(&set, sizeof set);
            dirty = 0;
        }
    }
}
