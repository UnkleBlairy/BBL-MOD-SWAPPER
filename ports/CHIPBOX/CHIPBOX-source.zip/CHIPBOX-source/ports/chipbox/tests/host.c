/* SPDX-License-Identifier: GPL-3.0-only */
/* A fake FM-1 on a computer: the app (firmware/src/chipbox.c) runs unchanged on it. platform.c includes
 * this file instead of the hardware when CHIPBOX_HOST is set. A script presses keys over time; out come
 * the screen (PPM, at the times SHOT asks) and the sound (WAV, as the FM-1 sends it over USB).
 *
 *   mkdir -p build/host
 *   cc -O2 -Wall -DCHIPBOX_HOST -Ifirmware/src -Ifirmware/gen -o build/host/chipbox firmware/src/chipbox.c
 *   build/host/chipbox build/host/chipbox        (-> build/host/chipbox.wav, build/host/chipbox-<ms>.ppm)
 *   build/host/chipbox OUT script.txt [FPS]    (your own script; with FPS: OUT-NNNNN.ppm, a frame every 1/FPS s:
 *                                             a film of your firmware, e.g. ffmpeg -r 30 -i OUT-%05d.ppm ...)
 *
 * Change SCRIPT below to try your own app. */
#include <stdint.h>
#ifdef CHIPBOX_WEB
#endif

#ifndef APP_NAME
#define APP_NAME "CHIPBOX"
#endif
#ifndef APP_VER
#define APP_VER "0.0"
#endif
#define FS 44100u
#define HALF_FRAMES 256u

static volatile uint32_t fm1_ms;
static struct { uint32_t notes, buttons; } fm1_in;
/* teensy-fm1: the panel and the screen are the Teensy's */
static uint32_t din_press, din_rel, din_nedge, din_px;
static int32_t din_enc[8];
static uint8_t din_led[64], din_glow[64];
static uint32_t fm1_input_edges(uint32_t *released) { uint32_t b = din_press; din_press = 0; if (released) *released = din_rel; din_rel = 0; return b; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = din_nedge; din_nedge = 0; return e; }
static int32_t fm1_enc_take(uint32_t e) { int32_t v = din_enc[e & 7u]; din_enc[e & 7u] = 0; return v; }
static void fm1_led_key(uint32_t id, int on) { din_led[id & 63u] = (uint8_t)!!on; }
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            sh_put(j * 240u + i, sh_be16(c));
    din_px += w * h;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            sh_put((y + j) * 240u + x + i, px[j * w + i]);      /* (gfx.c's pixels are high byte first already) */
    din_px += w * h;
}

static uint32_t host_edges, host_rel;

   /* (the script sets fm1_in.notes) */
static int32_t enc_acc[8];

static uint8_t host_led[64];                    /* 0 off, 1 glow, 2 on: the browser page draws them */

static void fm1_led_glow(uint32_t id, int on) { if (id < 64u && host_led[id] != 2) host_led[id] = on ? 1 : 0; }

/* the screen: 240 x 240 RGB565, as the ST7789 gets it (gfx.c sends the bytes swapped) */
#define fb shl_fb

static int32_t lcd_wy0, lcd_wy1;                /* the lesson card's rectangle (lcd.c does the same) */
static void lcd_fill_raw(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
#ifdef LCD_TRACE
    if ((int32_t)y < 212 && (int32_t)(y + h) > 148) printf("LCDW fill %u %u %u %u\n", x, y, w, h);
#endif
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            fb[j * 240u + i] = c;
}
static void lcd_blit_raw(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
#ifdef LCD_TRACE
    if ((int32_t)y < 212 && (int32_t)(y + h) > 148) printf("LCDW blit %u %u %u %u\n", x, y, w, h);
#endif
    uint32_t i, j;
    for (j = 0; j < h; j++)
        for (i = 0; i < w; i++)
            if (x + i < 240u && y + j < 240u) {
                uint16_t c = px[j * w + i];
                fb[(y + j) * 240u + x + i] = (uint16_t)(c >> 8 | c << 8);
            }
}

/* A clip rectangle the lesson card keeps (lcd_wx0 .. lcd_wx1, lcd_wy0 .. lcd_wy1; empty when the two y are equal): nothing the screen paints touches it, so the card is never painted over
 * and painted again (that was the flash). The card itself paints with the rectangle off. */
static int32_t lcd_wx0, lcd_wx1;
static void lcd_blit_s(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px, uint32_t stride)       /* a piece of a blit: rows w apart in px, stride apart in the source */
{
    uint32_t j;
    if (!w || !h) return;
    if (stride == w) { lcd_blit_raw(x, y, w, h, px); return; }
    for (j = 0; j < h; j++) lcd_blit_raw(x, y + j, w, 1u, px + j * stride);
}


#define CV_MAX (240u * 96u)
#include "gfx.c"

/* the projects' flash: erase sets 1s, a write can only clear bits (as the real part: a missing erase shows up), kept in $HOST_FLASH between runs */
static uint8_t host_flash[PROJ_LEN];
static uint32_t host_gen;                       /* counts writes: the browser page saves the flash when it changes */
static int pf_read(uint32_t off, void *dst, uint32_t n)
{
    if (off < PROJ_AT || off + n > PROJ_AT + PROJ_LEN) return -1;
    memcpy(dst, host_flash + (off - PROJ_AT), n);
    return 0;
}
static int pf_erase(uint32_t off)
{
    if (off < PROJ_AT || off + 0x1000u > PROJ_AT + PROJ_LEN || (off & 0xFFFu)) return -1;
    memset(host_flash + (off - PROJ_AT), 0xFF, 0x1000u);
    host_gen++;
    return 0;
}
static int pf_write(uint32_t off, const void *p, uint32_t n)
{
    uint32_t i;
    if (off < PROJ_AT || off + n > PROJ_AT + PROJ_LEN) return -1;
    for (i = 0; i < n; i++) host_flash[off - PROJ_AT + i] &= ((const uint8_t *)p)[i];
    host_gen++;
    return 0;
}
static uint8_t host_store[256 + 4];
static void host_flash_io(int save)             /* the projects' flash and the settings, to and from $HOST_FLASH */
{
    const char *path = getenv("HOST_FLASH");
    FILE *f = path ? fopen(path, save ? "wb" : "rb") : 0;
    if (f && save) { fwrite(host_flash, 1, sizeof host_flash, f); fwrite(host_store, 1, sizeof host_store, f); }
    else if (!f || fread(host_flash, 1, sizeof host_flash, f) != sizeof host_flash || fread(host_store, 1, sizeof host_store, f) != sizeof host_store) {
        memset(host_flash, 0xFF, sizeof host_flash); memset(host_store, 0, sizeof host_store);
    }
    if (f) fclose(f);
}
static int settings_load(void *p, uint32_t n)
{
    if (host_store[0] != 1 || n > 256u) return -1;
    memcpy(p, host_store + 4, n);
    return 0;
}
static int settings_save(const void *p, uint32_t n)
{
    if (n > sizeof host_store - 4u) return -1;   /* teensy-fm1 */
    host_store[0] = 1;
    memcpy(host_store + 4, p, n);
    host_gen++;
#ifndef CHIPBOX_WEB
    printf("%6u ms  settings saved (%u B)\n", fm1_ms, n);
#endif
    return 0;
}

static uint8_t mq[64][3];
static uint32_t mq_w, mq_r;
static uint8_t midi_src;                         /* 1 = from the TRS jack (the device's platform.c sets it); a computer's MIDI acts like USB */
static int midi_get(uint8_t *st, uint8_t *d1, uint8_t *d2)
{
    if (mq_r == mq_w) return 0;
    *st = mq[mq_r % 64u][0]; *d1 = mq[mq_r % 64u][1]; *d2 = mq[mq_r % 64u][2];
    mq_r++;
    return 1;
}
#ifdef CHIPBOX_WEB
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2) { (void)st; (void)d1; (void)d2; }
static void midi_isr_send(uint32_t st, uint32_t d1, uint32_t d2) { (void)st; (void)d1; (void)d2; }
#else
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2) { printf("%6u ms  MIDI out %02X %u %u\n", fm1_ms, st, d1, d2); }
static void midi_isr_send(uint32_t st, uint32_t d1, uint32_t d2) { midi_send(st, d1, d2); }
#endif

static volatile uint32_t ota_hit_ms;
static volatile uint8_t ota_back;                                   /* (the device: an install session ended and left its message on the screen) */
static void app_audio(int32_t *out, uint32_t n);
static void app_main(void);
