CoralFlower 0.7.1 for the BBL Mod Swapper

Original by FicusFicusov: https://github.com/FicusFicusov/CoralFlower
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: CORALFLW-source.zip on the ports page.
