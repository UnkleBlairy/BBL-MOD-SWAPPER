/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: FM1 Quest 43 (https://github.com/hericdk/fm1-quest) on the Teensy 4.1: its own browser build (quest/src/fm1quest_wasm.c) inside ports/common's shell */
#include "../../../common/shell_pre.h"
#include <stdlib.h>
#include <time.h>
#ifndef CLOCK_MONOTONIC
#define CLOCK_MONOTONIC 1
static int clock_gettime(int c, struct timespec *t) { (void)c; t->tv_sec = 0; t->tv_nsec = 0; return 0; }
#endif
#define getenv(n) ((char *)0)
#define web_boot o_web_boot
#define web_out_l o_web_out_l
#define web_out_r o_web_out_r
#define web_render o_web_render
#define web_buttons o_web_buttons
#define web_keys o_web_keys
#define web_enc o_web_enc
#define web_master o_web_master
#define web_nor_erase o_web_nor_erase
#define web_ms o_web_ms
#define web_frame o_web_frame
#include "../../quest/src/fm1quest_wasm.c"
#undef __attribute__
#undef EXPORT
#undef memset
#undef memcpy
#undef memcmp
#undef memmove
#undef web_boot
#undef web_out_l
#undef web_out_r
#undef web_render
#undef web_buttons
#undef web_keys
#undef web_enc
#undef web_master
#undef web_nor_erase
#undef web_ms
#undef web_frame
#define SH_FLOAT
#define SH_OUT_L qq_lp
#define SH_OUT_R qq_rp
#define SH_RENDERF(n) q_render(n)
#define SH_ADC(m) emu_adc_set(FM1_ADC_MASTER, (int32_t)m)
static void q_boot(void);
static void q_frame(uint32_t);
static void SH_BOOT(void) { q_boot(); }
static void SH_FRAME(uint32_t ms)
{
    q_frame(ms);
    const uint16_t *p = (const uint16_t *)emu_fb;
    uint32_t i;
    (void)ms;
    if (0) for (i = 0; i < 57600u; i++) if (shl_fb[i] != p[i]) sh_put(i, p[i]);
}
static float q_l[1024], q_r[1024];
static float *qq_lp(void) { return q_l; }
static float *qq_rp(void) { return q_r; }
static void q_render(uint32_t n)
{
    static uint32_t at = CTL;
    uint32_t i;
    for (i = 0; i < n; i++) {
        if (at >= CTL) { emu_render(CTL); at = 0; }
        q_l[i] = emu_audio_f[2u * at]; q_r[i] = emu_audio_f[2u * at + 1u]; at++;
    }
}
static void q_boot(void)
{
#ifndef TEENSY_NOR_ADDR
    memset(emu_flash, 0xFF, EMU_FLASH_SIZE);
#endif
    emu_init();
}
static void q_frame(uint32_t ms)
{
    if (!emu_running && ms > 2500u) emu_start();
    emu_frame();
}
static uint32_t q_btn, q_key;
#define SH_ENC(e, n) emu_enc((e), (n))
#define SH_BTN(i, d) (q_btn = (q_btn & ~(1u << (i))) | (uint32_t)(d) << (i), emu_input(q_key, q_btn))
#define SH_KEY(k, d) (q_key = (q_key & ~(1u << (k))) | (uint32_t)(d) << (k), emu_input(q_key, q_btn))
static int q_led(uint32_t id)
{
    uint32_t p, r;
    for (p = 0; p < FM1_NCOL; p++)
        for (r = 1; r < 5u; r++)
            if (FM1_KEYMAP[r][p] == (int8_t)id) return fm1_led[p] >> r & 1u ? 2 : (fm1_led_dim[p] | fm1_led_bg[p]) >> r & 1u ? 1 : 0;
    return 0;
}
#define SH_KEY_LED(k) q_led(14u + (k))
#define SH_BTN_LED(i) q_led(i)
#include "../../../common/shell_post.h"

/* ---------------------------------------------------------------- MIDI (teensy-fm1) --- */
/* The runtime (src/main.rs) hands in whole messages from the FM-1's TRS jack and the Teensy's USB MIDI port, and takes
 * the firmware's MIDI out for USB. usb.config stands in for "a USB MIDI host is there", as on the FM-1 itself.
 * (added by tools_night/addmidi.py, docs/MIDI.md) */
EXPORT void teensy_midi_in(uint32_t st, uint32_t d1, uint32_t d2, uint32_t source)
{
    (void)source;
    if (st >= 0xF8u ? !(st == 0xF8u || st == 0xFAu || st == 0xFBu || st == 0xFCu) : (st < 0x80u || st >= 0xF0u))
        return;
    if (mi_w - mi_r >= MQ)                          /* as usb.c's midi_in_event, without its SysEx side */
        return;
    midi_in_q[mi_w % MQ] = (st >= 0xF8u ? 0x0Fu : st >> 4) | st << 8 | (d1 & 127u) << 16 | (d2 & 127u) << 24;
    RING_PUBLISH();
    mi_w++;
}
EXPORT void teensy_midi_link(uint32_t on) { usb.config = on ? 1u : 0u; }
EXPORT uint32_t teensy_midi_out(uint32_t *out, uint32_t cap)
{
    uint32_t n = 0;
    while (n < cap && mo_r != mo_w) {
        out[n++] = midi_out_q[mo_r % MQ];
        mo_r++;
    }
    return n;
}
