/* SPDX-License-Identifier: GPL-3.0-only */
/* Niagara Drift on the host (FoMni's simulator): the whole app (UI, project, engine) against a simulated FM-1 driven by a script.
 * Audio goes to a WAV, the screen to PNGs, the lights to text, MIDI out to a log. The device-only
 * parts (HAL, USB, OTA, flash driver) are replaced by plat.h implemented here. (From X0X's x0x_host.)
 *
 *   omni_host SCRIPT [OUTDIR]
 *
 * Script, one command per line (# comments):
 *   wait MS                      run the device for MS milliseconds
 *   press BTN | release BTN | tap BTN     (BTN: FX SEL ENV LFO EDIT GLO HOME SAVE ARP SEQ PLAY REC OCT- OCT+)
 *   key K down|up | tapkey K     (K: 0..26 = F3..G5, or w0..w15 white keys, b0..b10 black keys)
 *   strum A B [MS]               white keys A..B pressed in turn (down then up), MS apart (default 25)
 *   turn ENC N [MS]              (ENC: SELECT ALGO PRESET K1 K2 K3 K4; N detents, MS apart, default 80)
 *   spin ENC N                   N detents at once, exactly N (no acceleration)
 *   master N                     MASTER pot 0..4096
 *   midi B0 B1 B2                incoming USB MIDI message (hex bytes)
 *   wav FILE | wavstop           start / stop recording the output
 *   peakreset                    restart the output peak (expect peak_db_min / peak_db_max)
 *   shot FILE.png                save the screen
 *   leds                         print the lit buttons and keys
 *   expect WHAT VALUE            check state: exit 1 on mismatch; VALUE "<N" / ">N" is a bound
 *   reboot                       re-run boot from the simulated flash (persistence test)
 *   listen                       a screen reader starts listening (HELLO, again every 2 s): each SAY is printed
 *                                ("said: ..."; "said!:" cuts off what was being said)
 *   where                        the reader asks for everything on the screen
 *   said TEXT                    some SAY since the last "said" (or "listen") has TEXT in it (_ for a space): else a
 *                                failure
 *   speakdump                    every page, knob value and message as the reader gets them (fm1-reader's audit)
 * OMNI_SAID_LOG=FILE: a reader listens from boot, quietly, and every SAY is appended to FILE (the audit).
 * (The screen reader's hookup is FoMni's host's, Charles Vestal.)
 */
#define OM_HOST 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include <time.h>
#define __attribute__(x)

/* ------------------------------------------------------------ screen --- */
/* teensy-fm1: X0X_LCD_PUT(i, v) writes pixel i (the Teensy build marks what changed for its display link) */
#ifndef X0X_LCD_PUT
#define X0X_LCD_PUT(i, v) (fb[i] = (v))
#endif
static uint16_t fb[240 * 240];          /* RGB565, byte-swapped as the panel takes it (gfx.c) */
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    uint16_t sc = (uint16_t)(((c >> 8) & 0xFFu) | ((c & 0xFFu) << 8));
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            X0X_LCD_PUT(j * 240u + i, sc);
}
static uint32_t blits;
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    blits++;
    for (j = 0; j < h; j++)
        for (i = 0; i < w; i++)
            if (x + i < 240u && y + j < 240u)
                X0X_LCD_PUT((y + j) * 240u + x + i, px[j * w + i]);
}
#include "../firmware/src/gfx.c"


/* ---------------------------------------------------------- platform --- */
#include "../firmware/src/app/plat.h"

static uint32_t now_ms, held_btn, held_keys, master = 2048;
static int32_t enc_acc[NE];
static uint32_t lit_btn, lit_keys;

uint32_t plat_ms(void) { return now_ms; }
uint32_t plat_us(void) { return now_ms * 1000u; }
uint32_t plat_buttons(void) { return held_btn; }
#ifdef OM_WEB
static int phones = 1;                     /* the browser: a computer's output, no speaker cut */
#else
static int phones;                         /* the scenarios: the speaker, unless "phones 1" */
#endif
int plat_headphones(void) { return phones; }
uint32_t plat_keys(void) { return held_keys; }
int32_t plat_enc(int role)
{
    int32_t v = enc_acc[role];
    enc_acc[role] = 0;
    return v;
}
uint32_t plat_master(void) { return master; }
static uint8_t pressure_v[NKEYS];              /* the script's "pressure KEY V": the 20 lower keys sense it */
static int has_pressure;                       /* none until a script uses it (the emulator has none): 0.1's visit */
int plat_pressure(uint32_t k)
{
    if (k >= NKEYS || k >= 20u || !has_pressure)
        return -1;
    return (held_keys >> k & 1u) ? pressure_v[k] : 0;
}
static uint8_t lvl_btn[NB], lvl_keys[NKEYS];     /* the brightness 0..255; lit_* = at least half */
void plat_leds(const uint8_t *b, const uint8_t *k)
{
    uint32_t i;
    lit_btn = lit_keys = 0;
    for (i = 0; i < NB; i++) {
        lvl_btn[i] = b[i];
        lit_btn |= (uint32_t)(b[i] >= 128u) << i;
    }
    for (i = 0; i < NKEYS; i++) {
        lvl_keys[i] = k[i];
        lit_keys |= (uint32_t)(k[i] >= 128u) << i;
    }
}

#define MQ 256
static uint32_t min_q[MQ], min_t[MQ], mi_w, mi_r;
static double clk_bpm, clk_jit, clk_next_us;      /* the "clock" command: pulses at this tempo, jittered (ms) */
static double clk_true_beat;                      /* ... the true beat (no jitter), from the first pulse after a start */
static FILE *midi_log;
static uint32_t midi_out_count, clock_out_count;
int plat_midi_in(uint32_t *pkt, uint32_t *us)
{
    if (mi_r == mi_w)
        return 0;
    *us = min_t[mi_r % MQ];
    *pkt = min_q[mi_r++ % MQ];
    return 1;
}
void plat_midi_out(uint32_t pkt)
{
#ifdef X0X_MIDI_PUT
    X0X_MIDI_PUT(pkt);                               /* teensy-fm1: to the Teensy's USB MIDI */
#endif
    midi_out_count++;
    if (((pkt >> 8) & 0xFF) == 0xF8) {
        clock_out_count++;
        return;
    }
    if (midi_log)
        fprintf(midi_log, "%u ms: %02X %02X %02X\n", now_ms, (pkt >> 8) & 0xFF, (pkt >> 16) & 0xFF, (pkt >> 24) & 0xFF);
}

/* flash: one buffer per object, kept across a simulated reboot */
static uint8_t store[OBJ_NOBJ][PLAT_STORE_MAX];
static int store_len[OBJ_NOBJ] = {-1, -1, -1, -1, -1, -1, -1, -1};   /* -1: never written */
_Static_assert(OBJ_NOBJ == 8, "store_len: one -1 an object");
static uint32_t store_writes;
static int save_cut, save_cut_due;   /* "savecut 1": each save cuts the next audio block to silence, as the FM-1's erase
                                      * does (main.c audio_silence: the DMA buffer zeroed for a block, ~5.8 ms) */
int plat_store_load(uint32_t obj, void *dst, uint32_t max)
{
    int n;
    if (obj >= OBJ_NOBJ || (n = store_len[obj]) < 0)
        return -1;
    if ((uint32_t)n > max)
        n = (int)max;
    memcpy(dst, store[obj], (size_t)n);
    return n;
}
int plat_store_held(void) { return 0; }
int plat_store_save(uint32_t obj, const void *src, uint32_t len)
{
    if (obj >= OBJ_NOBJ || len > PLAT_STORE_MAX)
        return -1;
    memcpy(store[obj], src, len);
    store_len[obj] = (int)len;
    store_writes++;
    if (save_cut)
        save_cut_due = 1;
    return 0;
}

static uint32_t cpu_pct;
uint32_t plat_cpu_pct(void) { return cpu_pct; }
uint32_t plat_xruns(void) { return 0; }

/* -------------------------------------------------------------- app --- */
#include "../firmware/src/app/app.h"
#define ANN_NAME "Niagara Drift " OM_VERSION
#include "ann_words.h"                                  /* the words file's link (tools/gen_words.py) */
#include "../firmware/src/announce.c"
/* what the reader is told: every SAY to stdout with "said:" (listen), and kept for the "said" check */
static char said_last[ANN_MAX + 1], said_log[16384];   /* said_log: every SAY since the last "said" check */
static uint32_t said_len;
static int said_print = 1, sim_listen;
static FILE *said_log_f;                                /* OMNI_SAID_LOG=FILE: every SAY, for fm1-reader's audit */
#ifdef OM_WEB
static void web_said(const uint8_t *p, uint32_t n);
#endif
static int ann_wire_send(const uint8_t *p, uint32_t n)
{
#ifdef OM_WEB
    web_said(p, n);
#endif
    if (n >= 7u && p[4] == ANN_SAY) {
        uint32_t i, k = 0;
        for (i = 6; i + 1u < n && k < ANN_MAX; i++)
            said_last[k++] = (char)p[i];
        said_last[k] = 0;
        if (said_len + k + 2u < sizeof said_log) {
            memcpy(said_log + said_len, said_last, k);
            said_len += k;
            said_log[said_len++] = '\n';
            said_log[said_len] = 0;
        }
#ifndef OM_WEB
        if (said_print)
            printf("said%s: %s\n", (p[5] & ANN_NOW) ? "!" : "", said_last);
        if (said_log_f)
            fprintf(said_log_f, "%s\t%s\n", (p[5] & ANN_KEEP) ? "WARN" : "MSG", said_last);
#endif
    }
    return 0;
}
static const uint8_t ANN_HELLO_F[] = {ANN_H0, ANN_H1, ANN_H2, ANN_HELLO, ANN_VER};
#include "../firmware/src/app/project.c"
#include "../firmware/src/app/ui.c"

/* the keybed's white and black keys: WHITE_K and BLACK_K, in ui.c */

/* ---------------------------------------------------------- outputs --- */
static void png_write(const char *path)
{
    /* RGB PNG with stored (uncompressed) deflate blocks: no zlib needed */
    static uint8_t raw[240 * (1 + 240 * 3)];
    FILE *f = fopen(path, "wb");
    uint32_t crc_t[256], i, j, k, n = 0, a = 1, b = 0, pos, len = sizeof raw;
    uint8_t hdr[8] = {137, 80, 78, 71, 13, 10, 26, 10};
    if (!f) {
        fprintf(stderr, "cannot write %s\n", path);
        return;
    }
    for (i = 0; i < 256; i++) {
        uint32_t c = i;
        for (k = 0; k < 8; k++)
            c = c & 1 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
        crc_t[i] = c;
    }
    for (j = 0; j < 240; j++) {
        raw[n++] = 0;
        for (i = 0; i < 240; i++) {
            uint16_t p = fb[j * 240 + i];
            p = (uint16_t)((p >> 8) | (p << 8));
            raw[n++] = (uint8_t)(((p >> 11) & 31) * 255 / 31);
            raw[n++] = (uint8_t)(((p >> 5) & 63) * 255 / 63);
            raw[n++] = (uint8_t)((p & 31) * 255 / 31);
        }
    }
    for (i = 0; i < len; i++) {
        a = (a + raw[i]) % 65521;
        b = (b + a) % 65521;
    }
#define PUT32(v) do { uint8_t q_[4] = {(uint8_t)((v) >> 24), (uint8_t)((v) >> 16), (uint8_t)((v) >> 8), (uint8_t)(v)}; fwrite(q_, 1, 4, f); } while (0)
    fwrite(hdr, 1, 8, f);
    {
        uint8_t ih[17] = {'I', 'H', 'D', 'R', 0, 0, 0, 240, 0, 0, 0, 240, 8, 2, 0, 0, 0};
        uint32_t c = 0xFFFFFFFFu;
        PUT32(13u);
        fwrite(ih, 1, 17, f);
        for (i = 0; i < 17; i++)
            c = crc_t[(c ^ ih[i]) & 255] ^ (c >> 8);
        PUT32(~c);
    }
    {
        uint32_t nblk = (len + 65534) / 65535, zlen = 2 + len + nblk * 5 + 4, c = 0xFFFFFFFFu;
        uint8_t *z = malloc(zlen + 4), *q = z;
        memcpy(q, "IDAT", 4);
        q += 4;
        *q++ = 0x78;
        *q++ = 0x01;
        for (pos = 0; pos < len;) {
            uint32_t m = len - pos > 65535 ? 65535 : len - pos;
            *q++ = pos + m >= len ? 1 : 0;
            *q++ = (uint8_t)m;
            *q++ = (uint8_t)(m >> 8);
            *q++ = (uint8_t)~m;
            *q++ = (uint8_t)(~m >> 8);
            memcpy(q, raw + pos, m);
            q += m;
            pos += m;
        }
        *q++ = (uint8_t)(b >> 8);
        *q++ = (uint8_t)b;
        *q++ = (uint8_t)(a >> 8);
        *q++ = (uint8_t)a;
        PUT32(zlen);
        fwrite(z, 1, zlen + 4, f);
        for (i = 0; i < zlen + 4; i++)
            c = crc_t[(c ^ z[i]) & 255] ^ (c >> 8);
        PUT32(~c);
        free(z);
    }
    {
        uint8_t ie[4] = {'I', 'E', 'N', 'D'};
        uint32_t c = 0xFFFFFFFFu;
        PUT32(0u);
        fwrite(ie, 1, 4, f);
        for (i = 0; i < 4; i++)
            c = crc_t[(c ^ ie[i]) & 255] ^ (c >> 8);
        PUT32(~c);
    }
    fclose(f);
}

static FILE *wav;
static uint32_t wav_frames;
static float peak_out;
static void wav_open(const char *path)
{
    static const uint8_t h[44] = {0};
    wav = fopen(path, "wb");
    if (wav)
        fwrite(h, 1, 44, wav);
    wav_frames = 0;
}
static void wav_close(void)
{
    uint32_t bytes = wav_frames * 4, v;
    if (!wav)
        return;
    fseek(wav, 0, SEEK_SET);
    fwrite("RIFF", 1, 4, wav);
    v = 36 + bytes;
    fwrite(&v, 4, 1, wav);
    fwrite("WAVEfmt ", 1, 8, wav);
    v = 16;
    fwrite(&v, 4, 1, wav);
    {
        uint16_t fmt[2] = {1, 2};
        uint32_t r[2] = {44100, 44100 * 4};
        uint16_t al[2] = {4, 16};
        fwrite(fmt, 2, 2, wav);
        fwrite(r, 4, 2, wav);
        fwrite(al, 2, 2, wav);
    }
    fwrite("data", 1, 4, wav);
    fwrite(&bytes, 4, 1, wav);
    fclose(wav);
    wav = 0;
}

/* --------------------------------------------------------- the device --- */
static double audio_due_ms, render_ns_total, render_budget_ns_total;
static uint32_t ui_due;
static double now_ns(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (double)t.tv_sec * 1e9 + (double)t.tv_nsec;
}

static void boot(void)
{
    dr_init();
    project_load();
    project_apply();
    lcd_fill(0, 0, 240, 240, 0);
    ui_init();
}

/* the clock's jitter: the same numbers on every machine (libc's rand() differs between macOS and Linux) */
static double jit_rand(void)                      /* -1 .. 1 */
{
    static uint32_t x = 2463534242u;              /* xorshift32 */
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return (double)x / 2147483648.0 - 1.0;
}

static void run_ms(uint32_t ms)
{
    static int32_t blk[512];
    uint32_t i, k;
    for (i = 0; i < ms; i++) {
        now_ms++;
        if (sim_listen && now_ms % 2000u == 0)          /* the reader's HELLO, as it sends it */
            ann_frame(ANN_HELLO_F, sizeof ANN_HELLO_F, now_ms);
        while (clk_bpm > 0.0 && clk_next_us <= (double)now_ms * 1000.0) {   /* the "clock" command's pulses */
            double j = clk_jit > 0.0 ? clk_jit * 1000.0 * jit_rand() : 0.0;
            min_t[mi_w % MQ] = (uint32_t)(clk_next_us + j);
            min_q[mi_w++ % MQ] = 0x0F | 0xF8u << 8;
            clk_next_us += 60.0e6 / (clk_bpm * 24.0);
            clk_true_beat += 1.0 / 24.0;
        }
        while (audio_due_ms <= (double)now_ms) {      /* 256-frame blocks, as the device renders them */
            double t0 = now_ns(), dt;
            dr_render(blk, 256, master);
            if (save_cut_due) {                       /* the erase's cut (savecut 1) */
                memset(blk, 0, sizeof(int32_t) * 2u * 256u);
                save_cut_due = 0;
            }
#ifdef OM_WEB
            web_audio(blk, 256);
#endif
            dt = now_ns() - t0;
            render_ns_total += dt;
            render_budget_ns_total += 256.0 * 1e9 / 44100.0;
            cpu_pct = (uint32_t)(100.0 * dt / (256.0 * 1e9 / 44100.0));
            for (k = 0; k < 256; k++) {
                float l = (float)blk[2 * k] / 8388608.0f, r = (float)blk[2 * k + 1] / 8388608.0f;
                int16_t s[2];
                if (fabsf(l) > peak_out)
                    peak_out = fabsf(l);
                if (fabsf(r) > peak_out)
                    peak_out = fabsf(r);
                s[0] = (int16_t)(l * 32767.0f);
                s[1] = (int16_t)(r * 32767.0f);
                if (wav) {
                    fwrite(s, 2, 2, wav);
                    wav_frames++;
                }
            }
            audio_due_ms += 256.0 * 1000.0 / 44100.0;
        }
        if (now_ms >= ui_due) {
            ui_due = now_ms + 16;
            ui_frame();
        } else {
            ui_input_only();
        }
    }
}

/* ---------------------------------------------------------- script --- */
static const char *const BTN_N[NB] = {"FX", "SEL", "ENV", "LFO", "EDIT", "GLO", "HOME", "SAVE", "ARP", "SEQ",
                                      "PLAY", "REC", "OCT-", "OCT+"};
static const char *const ENC_N[NE] = {"SELECT", "ALGO", "PRESET", "K1", "K2", "K3", "K4"};

static int find_name(const char *const *t, int n, const char *s)
{
    int i;
    for (i = 0; i < n; i++)
        if (!strcmp(t[i], s))
            return i;
    return -1;
}

static int key_of(const char *s)
{
    if (s[0] == 'w')
        return WHITE_K[atoi(s + 1) & 15];
    if (s[0] == 'b')
        return BLACK_K[atoi(s + 1) % 11];
    return atoi(s);
}

static int expect(const char *what, const char *val)
{
    int got;
    if (!strcmp(what, "restore"))                  /* the restore's answer: 0 waiting, 1 yes, 2 no (then asks no more) */
        got = ui_restore_answer();
    else if (!strcmp(what, "playing"))
        got = ui.playing;
    else if (!strcmp(what, "fade"))                /* the PLAY fade x 100 */
        got = (int)(dr_fade * 100.0f + 0.5f);
    else if (!strcmp(what, "view"))
        got = ui.view;
    else if (!strcmp(what, "keymap"))             /* the black keys' map showing (SEL held) */
        got = keymap_on();
    else if (!strcmp(what, "mtime"))              /* Gesture time, 0..100 (PRESETS; 50 as set, higher slower) */
        got = proj.mtime;
    else if (!strcmp(what, "dirty"))
        got = ui.dirty;
    else if (!strcmp(what, "loop"))                /* the motion loop: 0 idle, 1 recording, 2 playing */
        got = ui.loop;
    else if (!strcmp(what, "scene_at"))            /* the scene the sound is (its key blinks), or -1 */
        got = ui.scene_at;
    else if (!strcmp(what, "scenes"))              /* the scene slots in use, as a bit mask */
        got = proj.scene_used;
    else if (!strcmp(what, "bank"))                /* the bank the scene keys play: 0 A, 1 B, 2 C, 3 Presets */
        got = proj.bank;
    else if (!strcmp(what, "bscenes")) {           /* the current bank's slots in use, as a bit mask */
        int n;
        got = 0;
        for (n = 0; n < NSCENES; n++)
            got |= (scene_has(proj.bank, n) != 0) << n;
    }
    else if (!strcmp(what, "lvl0") || !strcmp(what, "lvl1"))   /* a drone's level heard (dr_level), dB; -99 silent */
        got = dr_level[what[3] - '0'] > 1e-5f ? (int)(20.0f * log10f(dr_level[what[3] - '0'])) : -99;
    else if (!strcmp(what, "lfo0"))                /* the LFO's Wave I now, x 100 */
        got = (int)(dr_lfo[0] * 100.0f);
    else if (!strcmp(what, "phones"))             /* the engine told: headphones in (no Speaker cut) */
        got = (int)dr_phones;
    else if (!strcmp(what, "store_writes"))
        got = (int)store_writes;
    else if (!strncmp(what, "heard", 5))          /* heardN: parameter N as heard (with the macros) */
        got = dr_heard(atoi(what + 5));
    else if (!strncmp(what, "gsent", 5)) {       /* gsentN: gesture N as the engine has it (the hand's or the loop's), x 100 */
        int g = atoi(what + 5);
        got = g >= 0 && g < DR_NGEST ? (ui.g_sent[g] + 5) / 10 : -1;
    }
    else if (!strncmp(what, "klvl", 4))           /* klvlK: key K's light, 0..255 (w0..w15 white, b0..b10 black) */
        got = lvl_keys[key_of(what + 4)];
    else if (!strncmp(what, "gam", 3)) {         /* gamN: gesture N's amount now, x 100 (0-3 the top keys, 4-7 G4-C5) */
        int g = atoi(what + 3);
        got = g >= 0 && g < DR_NGEST ? (int)(ui.g_amt[g] * 100.0f + 0.5f) : -1;
    }
    else if (!strcmp(what, "swerr")) {            /* the Swell against the true beat (clock command): |error| in
                                                    * thousandths of a breath */
        static const double DIVB[DR_NDIV] = {128, 64, 32, 16, 8, 4, 2, 1};   /* drone.c's DIV_BEATS */
        double beats = DIVB[(unsigned)proj.par[P_PULSE_DIV] < DR_NDIV ? proj.par[P_PULSE_DIV] : 2];
        double tb = clk_true_beat + ((double)now_ms * 1000.0 - (clk_next_us - 60.0e6 / (clk_bpm * 24.0))) /
                                        (60.0e6 / clk_bpm);
        double x = fmod(tb / beats, 2.0), e = (double)dr_pulse_ph - x;
        e -= e >= 1.0 ? 2.0 : e < -1.0 ? -2.0 : 0.0;
        got = (int)(fabs(e) * 1000.0 + 0.5);
    }
    else if (!strcmp(what, "lfoerr")) {           /* the LFO against the true beat (clock command): |error| in
                                                    * thousandths of a cycle */
        static const double LD[DR_NLDIV] = {128, 64, 32, 16, 8, 4, 2, 1, 0.5, 0.25};   /* drone.c's LDIV_BEATS */
        double beats = LD[(unsigned)proj.par[P_LFO_DIV] < DR_NLDIV ? proj.par[P_LFO_DIV] : 3];
        double tb = clk_true_beat + ((double)now_ms * 1000.0 - (clk_next_us - 60.0e6 / (clk_bpm * 24.0))) /
                                        (60.0e6 / clk_bpm);
        double x = fmod(tb / beats, 1.0), e = (double)dr_lfo_ph - x;
        e -= e >= 0.5 ? 1.0 : e < -0.5 ? -1.0 : 0.0;
        got = (int)(fabs(e) * 1000.0 + 0.5);
    }
    else if (!strcmp(what, "morphms"))            /* the scene change going on: its length, ms */
        got = (int)ui.morph_ms;
    else if (!strcmp(what, "clkfollow"))          /* the engine on a clock's tempo (1) or free (0) */
        got = dr_ext_spb > 0.0f;
    else if (!strcmp(what, "clkbpm"))             /* the MIDI clock in: its tempo x 10 */
        got = (int)(clk.bpm * 10.0f + 0.5f);
    else if (!strcmp(what, "clkjit"))             /* ... its jitter (RMS), us */
        got = (int)(clk.jit * 1000.0f + 0.5f);
    else if (!strcmp(what, "clkmax"))             /* ... its largest, us */
        got = (int)(clk.jmax * 1000.0f + 0.5f);
    else if (!strcmp(what, "clkstarts"))          /* ... Starts, Continues, Stops received */
        got = (int)(clk.starts * 100u + clk.conts * 10u + clk.stops);
    else if (!strcmp(what, "wander"))             /* Wander's move of drone II now, |cents| */
        got = (int)(fm_fabsf(dr_wander()) * 100.0f + 0.5f);
    else if (!strncmp(what, "tunoff", 6))         /* tunoffN: SEL's fine tuning N (0 drone I, 1 II, 2 the link offset),
                                                   * cents */
        got = proj.tun_off[atoi(what + 6) % 3];
    else if (!strncmp(what, "mtime", 5))          /* Macro time (PRESETS), 0..100 */
        got = proj.mtime;
    else if (!strncmp(what, "par", 3))            /* parN: parameter N (drone.h) */
        got = proj.par[atoi(what + 3)];
    else if (!strncmp(what, "mpitch", 6))         /* mpitchG: group G's pitch move by the macros now, in cents */
        got = (int)(dr_mac_pitch(atoi(what + 6)) * 100.0f + (dr_mac_pitch(atoi(what + 6)) >= 0.0f ? 0.5f : -0.5f));
    else if (!strncmp(what, "pitch", 5))          /* pitchG: group G's pitch now (gliding), in cents */
        got = (int)(dr_pitch[atoi(what + 5)] * 100.0f + 0.5f);
    else if (!strcmp(what, "dlyt"))               /* the delay's time now, with its LFO, ms x 10 */
        got = (int)(dr_dly_ms * 10.0f + 0.5f);
    else if (!strncmp(what, "cut", 3))            /* cutG: group G's cutoff now (gliding), knob units x 100 */
        got = (int)(dr_cut[atoi(what + 3)] * 100.0f + 0.5f);
    else if (!strncmp(what, "level", 5))          /* levelG: group G's output level x 100 */
        got = (int)(dr_level[atoi(what + 5)] * 100.0f);
    else if (!strcmp(what, "peak_db_max") || !strcmp(what, "peak_db_min")) {
        double db = 20.0 * log10(peak_out > 1e-9f ? peak_out : 1e-9f);
        int bad = what[8] == 'm' && what[9] == 'a' ? db > atof(val) : db < atof(val);
        printf("%s peak %.1f dBFS (%s %s)\n", bad ? "FAIL" : "  ok", db, what + 8, val);
        return bad;
    } else {
        printf("FAIL unknown expect %s\n", what);
        return 1;
    }
    if (val[0] == '<' || val[0] == '>') {
        int lim = (int)strtol(val + 1, 0, 0);
        if (val[0] == '<' ? got >= lim : got <= lim) {
            printf("FAIL expect %s %s, got %d\n", what, val, got);
            return 1;
        }
        printf("  ok %s == %d (%s)\n", what, got, val);
        return 0;
    }
    if (got != (int)strtol(val, 0, 0)) {
        printf("FAIL expect %s == %s, got %d\n", what, val, got);
        return 1;
    }
    printf("  ok %s == %d\n", what, got);
    return 0;
}

#ifndef OM_WEB
int main(int argc, char **argv)
{
    FILE *sc;
    char line[512], out[400];
    const char *dir = argc > 2 ? argv[2] : ".";
    int lineno = 0, fails = 0;
    if (argc < 2) {
        fprintf(stderr, "usage: omni_host SCRIPT [OUTDIR]\n");
        return 2;
    }
    sc = fopen(argv[1], "r");
    if (!sc) {
        perror(argv[1]);
        return 2;
    }
    snprintf(out, sizeof out, "%s/midi_out.txt", dir);
    midi_log = fopen(out, "w");
    if (getenv("OMNI_SAID_LOG")) {                       /* a reader listens from the start, quietly: the log only */
        said_log_f = fopen(getenv("OMNI_SAID_LOG"), "a");
        sim_listen = 1;
        said_print = 0;
    }
    boot();
    if (sim_listen)
        ann_frame(ANN_HELLO_F, sizeof ANN_HELLO_F, now_ms);
    while (fgets(line, sizeof line, sc)) {
        char cmd[32] = {0}, a[256] = {0}, b[64] = {0}, c[64] = {0};
        lineno++;
        if (line[0] == '#' || sscanf(line, "%31s %255s %63s %63s", cmd, a, b, c) < 1)
            continue;
        if (!strcmp(cmd, "wait"))
            run_ms((uint32_t)atoi(a));
        else if (!strcmp(cmd, "press") || !strcmp(cmd, "release") || !strcmp(cmd, "tap")) {
            int i = find_name(BTN_N, NB, a);
            if (i < 0) {
                printf("line %d: no button %s\n", lineno, a);
                return 2;
            }
            if (cmd[0] != 'r')
                held_btn |= 1u << i;
            if (cmd[0] == 't')
                run_ms(40);
            if (cmd[0] != 'p')
                held_btn &= ~(1u << i);
            run_ms(cmd[0] == 't' ? 40 : 2);
        } else if (!strcmp(cmd, "key") || !strcmp(cmd, "tapkey")) {
            int k = key_of(a);
            if (cmd[0] == 't') {
                held_keys |= 1u << k;
                run_ms(60);
                held_keys &= ~(1u << k);
                run_ms(30);
            } else {
                if (!strcmp(b, "down"))
                    held_keys |= 1u << k;
                else
                    held_keys &= ~(1u << k);
                run_ms(2);
            }
        } else if (!strcmp(cmd, "pressure")) {      /* pressure KEY V: a held key pressed harder, 0..127 */
            int k = key_of(a), v = atoi(b);
            pressure_v[k] = (uint8_t)(v < 0 ? 0 : v > 127 ? 127 : v);
            has_pressure = 1;
            run_ms(2);
        } else if (!strcmp(cmd, "strum")) {          /* strum A B [MS]: a finger across the white keys */
            int x = atoi(a), y = atoi(b), gap = c[0] ? atoi(c) : 25, s = y >= x ? 1 : -1;
            for (;; x += s) {
                held_keys |= 1u << WHITE_K[x & 15];
                run_ms((uint32_t)gap);
                held_keys &= ~(1u << WHITE_K[x & 15]);
                if (x == y)
                    break;
            }
            run_ms(2);
        } else if (!strcmp(cmd, "turn")) {
            int e = find_name(ENC_N, NE, a), n = atoi(b), s = n > 0 ? 1 : -1;
            uint32_t gap = c[0] ? (uint32_t)atoi(c) : 80u;
            if (e < 0) {
                printf("line %d: no encoder %s\n", lineno, a);
                return 2;
            }
            for (; n; n -= s) {
                enc_acc[e] += s;
                run_ms(gap);
            }
        } else if (!strcmp(cmd, "page")) {          /* page V: page V at once, in no time (the pages moved in v0.3:
                                                    * the scripts kept their timing, sample for sample) */
            set_view(atoi(a));
        } else if (!strcmp(cmd, "spin")) {
            int e = find_name(ENC_N, NE, a);
            if (e < 0) {
                printf("line %d: no encoder %s\n", lineno, a);
                return 2;
            }
            enc_acc[e] += atoi(b);
            accel_off = 1;
            run_ms(1);
            accel_off = 0;
        } else if (!strcmp(cmd, "set")) {           /* set P V [MS]: parameter P to V, gliding over MS (sketches of
                                                    * macros not built yet: a sound moved by hand, in time) */
            int p = atoi(a), v = atoi(b), ms = atoi(c);
            if (p >= 0 && p < DR_NPARAMS) {
                proj.par[p] = (int16_t)v;
                if (ms > 0) {
                    if (p < P_XMOD && p % GP_N == GP_PITCH)
                        dr_slide(p / GP_N, ms);
                    else
                        dr_pslide(p, ms);
                }
                dr_set(p, v);
            }
            run_ms(1);
        } else if (!strcmp(cmd, "savecut")) {      /* savecut 1: a save cuts an audio block, as on the FM-1 */
            save_cut = atoi(a);
        } else if (!strcmp(cmd, "phones"))         /* phones 1: headphones in (the Speaker cut out) */
            phones = atoi(a);
        else if (!strcmp(cmd, "master"))
            master = (uint32_t)atoi(a);
        else if (!strcmp(cmd, "midi")) {
            uint32_t s = (uint32_t)strtoul(a, 0, 16), d1 = (uint32_t)strtoul(b, 0, 16), d2 = (uint32_t)strtoul(c, 0, 16);
            uint32_t cin = s >= 0xF0 ? 0x0F : s >> 4;
            min_t[mi_w % MQ] = now_ms * 1000u;
            min_q[mi_w++ % MQ] = cin | s << 8 | d1 << 16 | d2 << 24;
        } else if (!strcmp(cmd, "clock")) {          /* clock BPM [JITTER_MS]: MIDI clock in from now (0: stop) */
            clk_bpm = atof(a);
            clk_jit = b[0] ? atof(b) : 0.0;
            clk_next_us = (double)now_ms * 1000.0;
            clk_true_beat = -1.0 / 24.0;          /* the first pulse: beat 0 */
            min_t[mi_w % MQ] = now_ms * 1000u;    /* a Start first: the count from the top */
            min_q[mi_w++ % MQ] = 0x0F | 0xFAu << 8;
        } else if (!strcmp(cmd, "wav")) {
            snprintf(out, sizeof out, "%s/%s", dir, a);
            wav_open(out);
        } else if (!strcmp(cmd, "wavstop"))
            wav_close();
        else if (!strcmp(cmd, "restoreask"))       /* the safe restore's question, as a backup staged over USB asks it */
            ui_restore_ask();
        else if (!strcmp(cmd, "peakreset"))
            peak_out = 0.0f;
        else if (!strcmp(cmd, "shot")) {
            snprintf(out, sizeof out, "%s/%s", dir, a);
            png_write(out);
        } else if (!strcmp(cmd, "leds")) {
            int i;
            printf("  leds: buttons");                /* lit, or "(dim)" under half */
            for (i = 0; i < NB; i++)
                if (lvl_btn[i])
                    printf(lvl_btn[i] >= 128u ? " %s" : " (%s)", BTN_N[i]);
            printf(" | white ");                         /* # lit, - dim, . dark */
            for (i = 0; i < 16; i++)
                printf("%c", lvl_keys[WHITE_K[i]] >= 128u ? '#' : lvl_keys[WHITE_K[i]] ? '-' : '.');
            printf(" black ");
            for (i = 0; i < 11; i++)
                printf("%c", lvl_keys[BLACK_K[i]] >= 128u ? '#' : lvl_keys[BLACK_K[i]] ? '-' : '.');
            printf("\n");
        } else if (!strcmp(cmd, "expect"))
            fails += expect(a, b);
        else if (!strcmp(cmd, "listen")) {          /* a screen reader starts listening */
            sim_listen = 1;
            said_len = 0;
            said_log[0] = 0;
            ann_frame(ANN_HELLO_F, sizeof ANN_HELLO_F, now_ms);
        } else if (!strcmp(cmd, "where")) {
            static const uint8_t WHERE[] = {ANN_H0, ANN_H1, ANN_H2, ANN_WHERE};
            ann_frame(WHERE, sizeof WHERE, now_ms);
        } else if (!strcmp(cmd, "said")) {          /* TEXT in some SAY since the last check ("_" a space) */
            char *q;
            for (q = a; *q; q++)
                if (*q == '_')
                    *q = ' ';
            if (!strstr(said_log, a)) {
                printf("FAIL line %d: nothing said with \"%s\" (said:\n%s)\n", lineno, a, said_log);
                fails++;
            }
            said_len = 0;
            said_log[0] = 0;
        } else if (!strcmp(cmd, "speakdump"))
            speak_dump();
        else if (!strcmp(cmd, "notips"))            /* every one-time tip seen (the manual's pictures) */
            memset(proj.seen, 0xFF, sizeof proj.seen);
        else if (!strcmp(cmd, "classic")) {         /* the starting sound before 2026-10-17, for the scenarios made on
                                                    * it (they test the controls, not the starting sound) */
            static const int16_t OLD[][2] = {{DR_GP(0, GP_FLFO_DEPTH), 25}, {DR_GP(1, GP_FLFO_DEPTH), -25},
                {DR_GP(0, GP_RESO), 350}, {DR_GP(1, GP_RESO), 350}, {P_LFO_RATE, 98}, {P_LFO_W2, 1},
                {P_DLY_REPEATS, 35}, {P_DLY_MIX, 0}, {P_REV_MIX, 25}, {P_DLY_LFO_DEPTH, 0}, {P_PULSE, 0},
                {P_PULSE_RATE, 45}, {P_PULSE_DEPTH, 48},
                {P_GLIDE, 0}, {P_FADE, 25}, {P_MORPH, 21}, {P_SCENE_T, 48},   /* the times before 2026-11-07 */
                {DR_GP(0, GP_CUTOFF), 700}, {DR_GP(1, GP_CUTOFF), 680}, {DR_GP(0, GP_LEVEL), 75},
                {DR_GP(1, GP_LEVEL), 61}};   /* the cutoffs and levels before 2026-11-08 */
            uint32_t i;
            for (i = 0; i < sizeof OLD / sizeof OLD[0]; i++) {  /* only these (the engine's queue holds 64) */
                proj.par[OLD[i][0]] = OLD[i][1];
                dr_set(OLD[i][0], OLD[i][1]);
            }
            run_ms(50);
        } else if (!strcmp(cmd, "reboot")) {
            memset(&proj, 0, sizeof proj);
            boot();
        } else if (!strcmp(cmd, "echo"))
            printf("%s", line + 5);
        else {
            printf("line %d: unknown command %s\n", lineno, cmd);
            return 2;
        }
    }
    wav_close();
    if (midi_log)
        fclose(midi_log);
    printf("host: %u ms simulated, %u blits, render %.1f%% of real time (host CPU)%s\n", now_ms, blits,
           render_budget_ns_total > 0 ? 100.0 * render_ns_total / render_budget_ns_total : 0.0,
           fails ? ", EXPECTATIONS FAILED" : "");
    return fails ? 1 : 0;
}
#endif /* OM_WEB */
