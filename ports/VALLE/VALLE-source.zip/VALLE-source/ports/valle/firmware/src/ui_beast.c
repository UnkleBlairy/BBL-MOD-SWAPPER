/* SPDX-License-Identifier: GPL-3.0-only */
/* (Vallée) A creature for every sound, of its track's family (THE SPELL's elements, ui_world.c):
 *   1 green aliens  2 blue cryptids  3 yellow psi orbs  4 pink crystals  5 purple sigils  6 orange mythic herbs.
 * 12 x 12, put together from parts as an identikit is: each family four bodies (aliens: a grey's dome, a bulb in a
 * suit, a cone head, an egg on tentacles; cryptids: bigfoot, mothman, a wendigo, a yeti; orbs: a great orb, a ring, a
 * small one, one lit from above; crystals: a spire, a diamond, a cluster, a geode; sigils: the eye's triangle, a seal,
 * an ankh, a chaos star; herbs: a mandrake, a mushroom, a flower, a sprout), four eyes, four of what is over or round
 * it and four marks: 256 a family. The sound picks them (n: its engine and its place in that engine's list, or its
 * name's hash: xe_track_art), so the sounds next to each other in a list never share one (tests/ui_test.c). Left
 * halves of 6, mirrored, 3 bits a cell ((tools: ~/beasts/gen.py) 0 nothing (over the body: left as it is), 1 the body,
 * 2 an eye (lit), 3 dark, 4 a glint), a row in 3 bytes. Plain C: xe_beast_px fills the pixels, xe_beast_art packs them
 * as gen_sprites.py packs (3 bits, keys "#o.+"). Included by ui_xeno.c. */

#define XB_RGB(r, g, b) ((uint16_t)((((r) >> 3) << 11) | (((g) >> 2) << 5) | ((b) >> 3)))
/* (their colours: the THEME's tracks' (T_TRK): XENO's are the elements' green blue yellow pink purple orange; TEEN's
 * teenage engineering's primaries; CUSTOM's yours) */
static const uint8_t XB_B[NTRK][4][12][3] = {
    {{{0,0,0},{0,0,73},{0,18,73},{0,146,73},{0,146,73},{0,146,73},{0,18,73},{0,2,73},{0,0,73},{0,0,9},{0,0,73},{0,2,73}}, {{0,0,0},{0,2,73},{0,146,73},{0,146,73},{0,146,73},{0,146,73},{0,18,73},{0,2,73},{0,0,9},{0,2,73},{0,18,73},{0,16,9}}, {{0,0,1},{0,0,9},{0,0,73},{0,2,73},{0,18,73},{0,18,73},{0,2,73},{0,0,73},{0,0,9},{0,0,73},{0,2,9},{0,16,8}}, {{0,0,0},{0,0,73},{0,2,73},{0,18,73},{0,18,73},{0,146,73},{0,146,73},{0,18,73},{0,2,73},{0,0,73},{0,2,8},{0,16,8}}},
    {{{0,0,0},{0,0,9},{0,0,73},{0,0,73},{0,2,73},{0,18,73},{0,130,73},{0,130,73},{0,130,73},{0,0,72},{0,0,72},{0,2,72}}, {{0,0,0},{0,0,0},{0,0,9},{0,0,73},{0,128,73},{0,144,73},{0,146,73},{0,146,73},{0,18,73},{0,0,72},{0,0,64},{0,0,64}}, {{0,128,65},{0,18,8},{0,2,65},{0,0,73},{0,0,73},{0,0,73},{0,2,73},{0,16,73},{0,16,9},{0,0,8},{0,0,8},{0,0,72}}, {{0,0,0},{0,0,73},{0,2,73},{0,2,73},{0,18,73},{0,146,73},{0,146,73},{0,146,73},{0,146,73},{0,2,65},{0,2,65},{0,18,64}}},
    {{{0,0,0},{0,0,0},{0,0,9},{0,2,73},{0,18,73},{0,18,73},{0,18,73},{0,18,73},{0,2,73},{0,0,9},{0,0,0},{0,0,0}}, {{0,0,0},{0,0,0},{0,0,9},{0,2,91},{0,22,219},{0,22,219},{0,22,219},{0,22,219},{0,2,91},{0,0,9},{0,0,0},{0,0,0}}, {{0,0,0},{0,0,0},{0,0,0},{0,0,9},{0,0,73},{0,2,73},{0,2,73},{0,0,73},{0,0,9},{0,0,0},{0,0,0},{0,0,0}}, {{0,0,0},{0,0,0},{0,0,36},{0,9,9},{0,66,73},{0,66,73},{0,18,73},{0,18,73},{0,2,73},{0,0,9},{0,0,0},{0,0,0}}},
    {{{0,0,1},{0,0,9},{0,0,9},{0,0,73},{0,0,76},{0,0,76},{0,0,76},{0,0,76},{0,0,73},{0,0,73},{0,0,9},{0,0,1}}, {{0,0,0},{0,0,9},{0,0,73},{0,2,100},{0,18,73},{0,146,73},{0,18,91},{0,2,91},{0,0,91},{0,0,11},{0,0,1},{0,0,0}}, {{0,0,1},{0,16,1},{0,16,9},{0,144,9},{0,144,73},{0,144,73},{0,146,73},{0,146,73},{0,18,73},{0,2,73},{0,0,0},{0,0,0}}, {{0,0,0},{0,0,73},{0,2,73},{0,18,219},{0,23,28},{0,184,219},{0,183,27},{0,182,227},{0,22,219},{0,2,73},{0,0,73},{0,0,0}}},
    {{{0,0,0},{0,0,1},{0,0,8},{0,0,8},{0,0,64},{0,0,64},{0,2,0},{0,2,0},{0,16,0},{0,16,0},{0,146,73},{0,0,0}}, {{0,0,0},{0,0,73},{0,18,1},{0,16,1},{0,128,1},{0,128,1},{0,146,73},{0,128,1},{0,16,1},{0,18,1},{0,0,73},{0,0,0}}, {{0,0,9},{0,0,64},{0,0,64},{0,0,64},{0,0,9},{0,146,73},{0,0,1},{0,0,1},{0,0,1},{0,0,1},{0,0,1},{0,0,73}}, {{0,0,1},{0,128,1},{0,16,1},{0,2,9},{0,0,73},{0,146,73},{0,0,73},{0,2,9},{0,16,1},{0,128,1},{0,0,1},{0,0,0}}},
    {{{0,2,1},{0,0,65},{0,0,9},{0,0,73},{0,2,73},{0,2,73},{0,18,73},{0,130,73},{0,2,73},{0,0,73},{0,0,65},{0,2,0}}, {{0,0,0},{0,0,73},{0,18,73},{0,146,73},{0,146,73},{0,0,0},{0,0,9},{0,0,73},{0,0,73},{0,0,73},{0,2,73},{0,18,73}}, {{0,0,65},{0,2,73},{0,18,91},{0,18,91},{0,2,73},{0,0,65},{0,0,1},{0,18,1},{0,2,65},{0,0,1},{0,0,9},{0,2,73}}, {{0,0,1},{0,0,1},{0,144,1},{0,146,1},{0,18,65},{0,2,73},{0,0,9},{0,0,73},{0,2,73},{0,2,73},{0,0,73},{0,2,1}}},
};
static const uint8_t XB_O[NTRK][3][4][10] = {   /* eyes, extra, top: the first row, then three */
    {{{4,0,54,192,0,6,192,0,0,0}, {4,0,6,128,0,6,192,0,0,0}, {4,0,0,0,0,52,192,0,0,0}, {4,0,54,0,0,54,192,0,7,0}}, {{0,0,0,0,0,0,0,0,0,0}, {0,0,8,0,0,0,64,0,0,0}, {0,0,0,4,0,0,1,0,0,0}, {0,0,64,0,0,2,0,0,0,64}}, {{9,0,0,0,0,0,0,0,0,0}, {8,0,0,36,0,0,0,0,0,0}, {11,2,0,0,0,0,0,0,0,0}, {10,2,0,0,0,0,0,0,0,0}}},
    {{{3,0,0,16,0,0,0,0,0,0}, {3,0,0,128,0,0,0,0,0,0}, {4,0,0,16,0,0,0,0,0,0}, {3,0,0,144,0,0,0,0,0,0}}, {{0,0,0,0,0,0,0,0,0,0}, {1,0,8,0,0,0,0,0,0,0}, {4,0,0,0,0,0,0,0,0,24}, {10,2,0,0,0,0,0,0,0,0}}, {{5,0,0,0,0,0,0,0,0,0}, {6,0,1,0,0,0,0,0,0,0}, {11,0,128,0,0,0,0,0,0,0}, {7,0,0,32,0,0,0,0,0,0}}},
    {{{5,0,0,2,0,0,2,0,0,0}, {5,0,0,27,0,0,26,0,0,0}, {4,0,1,0,0,0,0,0,0,0}, {5,0,0,128,0,0,0,0,0,0}}, {{0,0,0,4,0,0,4,0,0,0}, {0,2,0,0,0,64,0,0,0,0}, {0,0,8,0,0,0,0,2,0,0}, {0,0,0,0,0,8,32,0,0,0}}, {{10,0,0,4,0,0,4,0,0,0}, {10,0,64,0,2,0,0,0,0,0}, {9,0,0,0,0,1,0,0,0,0}, {10,0,8,32,0,0,0,0,0,0}}},
    {{{5,0,0,16,0,0,0,0,0,0}, {5,0,0,26,0,0,0,0,0,0}, {6,0,0,128,0,0,0,0,0,0}, {5,0,0,0,0,0,0,0,0,0}}, {{10,0,0,0,0,54,219,1,182,219}, {9,0,0,0,0,0,0,0,8,4}, {0,2,0,0,0,0,0,0,0,0}, {10,0,0,0,0,0,219,0,0,0}}, {{2,0,0,0,0,0,0,0,0,0}, {2,0,8,0,0,0,0,0,0,0}, {3,2,0,0,0,0,0,0,0,0}, {1,0,64,0,0,0,0,0,0,0}}},
    {{{6,0,0,2,0,0,24,0,0,0}, {5,0,0,2,0,0,0,0,0,0}, {7,0,0,26,0,0,0,0,0,0}, {0,0,0,0,0,0,0,0,0,0}}, {{0,2,0,0,0,0,0,0,0,0}, {11,2,0,4,0,0,0,0,0,0}, {0,0,0,0,2,0,0,0,0,0}, {11,0,8,32,0,0,0,0,0,0}}, {{1,0,0,0,0,0,0,0,0,0}, {3,1,0,0,0,0,0,0,0,0}, {8,0,4,0,0,0,0,0,0,0}, {4,2,0,0,0,0,0,0,0,0}}},
    {{{6,0,0,192,0,0,0,0,0,0}, {8,0,0,24,0,0,0,0,0,0}, {3,0,0,26,0,0,0,0,0,0}, {7,0,0,192,0,1,0,0,0,0}}, {{0,0,0,0,0,0,0,0,0,0}, {2,0,0,0,0,65,0,0,0,0}, {0,0,64,0,0,0,0,0,0,0}, {3,0,8,32,0,0,0,0,0,0}}, {{11,0,0,0,0,0,0,0,0,0}, {10,0,0,0,2,0,0,0,0,0}, {11,0,128,0,0,0,0,0,0,0}, {9,2,0,0,0,0,0,0,0,0}}},
};
static const uint8_t XB_EON = 15u;   /* the families whose eyes land on the body alone (bit k) */

/* a half row (3 bytes) onto row y, mirrored; on: only where the body is */
static void xb_put(uint8_t px[12][12], int32_t y, const uint8_t *b, int on)
{
    uint32_t v = (uint32_t)b[0] << 16 | (uint32_t)b[1] << 8 | b[2], i, c;
    if (y < 0 || y > 11)
        return;
    for (i = 0; i < 6u; i++)
        if ((c = (v >> (15u - 3u * i)) & 7u) != 0u && (!on || px[y][i])) {
            px[y][i] = (uint8_t)c;
            px[y][11u - i] = (uint8_t)c;
        }
}
/* ((Vallée) track 5's family: sigils drawn as sigils, lines on a staff, no creature; never two triangles (no hexagram)) */
static void xb_ln(uint8_t px[12][12], int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint8_t v)
{
    int32_t dx = x1 > x0 ? x1 - x0 : x0 - x1, dy = y1 > y0 ? y0 - y1 : y1 - y0, sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    int32_t e = dx + dy, e2;
    for (;;) {
        if (x0 >= 0 && x0 < 12 && y0 >= 0 && y0 < 12)
            px[y0][x0] = v;
        if (x0 == x1 && y0 == y1)
            return;
        e2 = 2 * e;
        if (e2 >= dy) { e += dy; x0 += sx; }
        if (e2 <= dx) { e += dx; y0 += sy; }
    }
}
static void xb_arc(uint8_t px[12][12], int32_t cx, int32_t cy, int32_t r, uint32_t half, uint8_t v)   /* half: 1 top 2 bottom 3 all */
{
    int32_t x = r, y = 0, e = 1 - r;
    while (x >= y) {
        const int32_t P[8][2] = {{x, y}, {y, x}, {-y, x}, {-x, y}, {-x, -y}, {-y, -x}, {y, -x}, {x, -y}};
        uint32_t i;
        for (i = 0; i < 8u; i++) {
            int32_t u = cx + P[i][0], w = cy + P[i][1];
            if (((P[i][1] <= 0 && (half & 1u)) || (P[i][1] >= 0 && (half & 2u))) && u >= 0 && u < 12 && w >= 0 && w < 12)
                px[w][u] = v;
        }
        y++;
        if (e < 0) e += 2 * y + 1;
        else { x--; e += 2 * (y - x) + 1; }
    }
}
static void xb_sigil(uint32_t c, uint8_t px[12][12])
{
    switch (c & 3u) {                                   /* what holds it: nothing, a ring, a bowl, one triangle */
    case 1: xb_arc(px, 5, 6, 5, 3, 1); break;
    case 2: xb_arc(px, 5, 5, 5, 2, 1); break;
    case 3: xb_ln(px, 5, 0, 0, 10, 1); xb_ln(px, 5, 0, 10, 10, 1); xb_ln(px, 0, 10, 10, 10, 1); break;
    default: break;
    }
    xb_ln(px, 5, 2, 5, 10, 1);                          /* the staff */
    switch ((c >> 2) & 3u) {                            /* across it: a bar, two, a chevron, a cross */
    case 0: xb_ln(px, 2, 5, 8, 5, 1); break;
    case 1: xb_ln(px, 3, 4, 7, 4, 1); xb_ln(px, 2, 7, 8, 7, 1); break;
    case 2: xb_ln(px, 2, 4, 5, 7, 1); xb_ln(px, 8, 4, 5, 7, 1); break;
    default: xb_ln(px, 3, 5, 7, 9, 1); xb_ln(px, 7, 5, 3, 9, 1); break;
    }
    switch ((c >> 4) & 3u) {                            /* its head: a small ring, an arrow, horns, a fork */
    case 0: xb_arc(px, 5, 1, 1, 3, 4); break;
    case 1: xb_ln(px, 3, 3, 5, 1, 4); xb_ln(px, 7, 3, 5, 1, 4); xb_ln(px, 5, 1, 5, 2, 1); break;
    case 2: xb_arc(px, 5, 0, 2, 2, 4); break;
    default: xb_ln(px, 5, 3, 3, 1, 4); xb_ln(px, 5, 3, 7, 1, 4); break;
    }
    switch ((c >> 6) & 3u) {                            /* its marks: none, two points, a foot, a hook */
    case 1: px[8][2] = 4; px[8][8] = 4; break;
    case 2: xb_ln(px, 3, 9, 7, 9, 4); break;
    case 3: xb_ln(px, 5, 11, 8, 11, 1); xb_ln(px, 8, 11, 8, 9, 4); break;
    default: break;
    }
}

/* the creature of track k's family for sound n */
static void xe_beast_px(uint32_t k, uint32_t n, uint8_t px[12][12])
{
    uint32_t c = n % 256u, j, p;
    k %= NTRK;
    memset(px, 0, 144);
    if (k == 4u) {
        xb_sigil(c, px);
        return;
    }
    for (j = 0; j < 12u; j++)
        xb_put(px, (int32_t)j, XB_B[k][c % 4u][j], 0);
    for (p = 0; p < 3u; p++) {                      /* the eyes, what is round it, its mark */
        const uint8_t *o = XB_O[k][p][(c >> (2u + 2u * p)) % 4u];
        for (j = 0; j < 3u; j++)
            xb_put(px, (int32_t)o[0] + (int32_t)j, o + 1 + 3u * j, p == 0u && ((XB_EON >> k) & 1u));
    }
}
/* packed as a sprite (ui_sprite): w, h, 3 bits a pixel, a spare byte */
#define XB_ART_N (3u + (12u * 12u * 3u + 7u) / 8u + 1u)
static void xb_pack(const uint8_t px[12][12], uint8_t *out)   /* (as gen_sprites.py packs: 3 bits a cell) */
{
    uint32_t acc = 0, nb = 0, o = 3, j, i;
    out[0] = 12;
    out[1] = 12;
    out[2] = 3;
    for (j = 0; j < 12u; j++)
        for (i = 0; i < 12u; i++) {
            acc = acc << 3 | px[j][i];
            nb += 3u;
            if (nb >= 8u) {
                out[o++] = (uint8_t)(acc >> (nb - 8u));
                nb -= 8u;
            }
        }
    if (nb)
        out[o++] = (uint8_t)(acc << (8u - nb));
    out[o] = 0;
}
static void xe_beast_art(uint32_t k, uint32_t n, uint8_t *out)
{
    uint8_t px[12][12];
    xe_beast_px(k, n, px);
    xb_pack(px, out);
}
/* a name's number for a sound that is not a factory one */
static uint32_t xb_hash(const char *s)
{
    uint32_t h = 2166136261u;
    while (*s)
        h = (h ^ (uint8_t)*s++) * 16777619u;
    return 64u + h % 4093u;
}
