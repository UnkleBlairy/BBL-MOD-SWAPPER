Arcturus S6 1.7 for the BBL Mod Swapper

Original by zeptosecond-dsp: https://github.com/zeptosecond-dsp/Arcturus-S6
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: ARCTURUS-source.zip on the ports page.
