/* SPDX-License-Identifier: GPL-3.0-only */
/* The Jupiter-8 panel UI, after jupiter8_esp32/src/ui/ui.cpp, for the FM-1: a 240 x 240 screen, KNOB 1-4 as the four
 * Q-Link dials, and the page buttons. Pages: Q-LINK (four dials, eight groups), PANEL (every sound control),
 * PERFORMANCE (assign, keys, arpeggio, portamento, bender, master, MIDI), EFFECTS, PATCHES.
 *
 *   KNOB 1-4        the four dials of the Q-Link page; on the others KNOB 1 chooses, KNOB 2 sets, KNOB 3 jumps
 *                   a section, KNOB 4 steps the patch
 *   SELECT          the Q-Link group (and back to the Q-Link page)      PRESETS  the patch
 *   ALGORITHM       Upper / Lower part                                  MASTER   volume (the pot)
 *   HOME            Q-Link page (again: next group)    EDIT PANEL    GLO PERFORMANCE    FX EFFECTS    SAVE PATCHES
 *   ENV             ENV-1 / ENV-2      LFO  LFO group      SEQ  VCO group      SCL  PLAY group
 *   ARP             arpeggio on / off
 *   SEQ             the sequencer (again: its setup)    PLAY  start / stop (held: all notes off)
 *   REC             tapped: arm recording (step entry, or real time while playing); held + a knob: that dial back to the saved value
 *   OCT- / OCT+     octave of the keys (on the PATCHES page: back / load or write) */

/* panel palette: black panel, cream print, the Jupiter's band of bright button colours */
#define K_BG CV_RGB(10, 10, 12)
#define K_PANEL CV_RGB(22, 22, 25)
#define K_LINE CV_RGB(70, 70, 76)
#define K_TEXT CV_RGB(235, 230, 215)
#define K_DIM CV_RGB(135, 132, 124)
#define K_RED CV_RGB(226, 44, 38)
#define K_ORANGE CV_RGB(240, 124, 28)
#define K_YELLOW CV_RGB(244, 196, 48)
#define K_CREAM CV_RGB(232, 224, 196)
#define K_BLUE CV_RGB(50, 128, 208)
#define K_LEDON CV_RGB(255, 44, 30)
#define K_LEDOFF CV_RGB(52, 12, 10)
#define K_FOCUS CV_RGB(255, 196, 40)
#define K_FOCBG CV_RGB(52, 44, 18)

enum { PAGE_QLINK, PAGE_PANEL, PAGE_PERF, PAGE_FX, PAGE_PATCH, PAGE_SEQ, PAGE_PROJ, PAGE_COUNT };
enum { B_FX, B_SCL, B_ENV, B_LFO, B_EDIT, B_GLO, B_HOME, B_SAVE, B_ARP, B_SEQ, B_PLAY, B_REC, B_OCTDN, B_OCTUP, NB };
#define BTN(b) (1u << (b))

/* what the panel hands the UI each frame */
typedef struct {
    int knob[4];                     /* KNOB 1-4: detents since the last frame */
    int sel, algo, preset;           /* SELECT, ALGORITHM, PRESETS */
    uint32_t press;                  /* buttons pressed since the last frame (bit per B_*) */
    uint32_t held;                   /* buttons down */
    uint32_t released;               /* buttons let go since the last frame */
} ju_in_t;

static const int16_t kCos[33] = {-181, -206, -226, -241, -251, -256, -255, -248, -237, -220, -198, -172, -142, -109, -74, -38, 0, 38, 74, 109, 142, 172, 198, 220, 237, 248, 255, 256, 251, 241, 226, 206, 181};
static const int16_t kSin[33] = {181, 152, 121, 86, 50, 13, -25, -62, -98, -132, -162, -190, -213, -231, -245, -253, -256, -253, -245, -231, -213, -190, -162, -132, -98, -62, -25, 13, 50, 86, 121, 152, 181};

/* The EDIT and GLO (performance) pages are series of pages of 2-6 controls, big enough to read: KNOB 1 walks through the
 * controls (crossing into the next page), KNOB 3 jumps a page, EDIT / GLO again go to the next page. The focus is the
 * position in the flat list of all the pages' controls. */
typedef struct { const char *title; uint16_t color; int8_t n; int16_t ids[8]; } spage_t;
#define PG(x) (P_COUNT + (x))
static const spage_t kPanelPages[] = {
    {"LFO", K_RED, 3, {P_LFO_RATE, P_LFO_DELAY, P_LFO_WAVE}},
    {"VCO MOD", K_ORANGE, 5, {P_VM_LFO, P_VM_ENV, P_VM_DEST, P_VM_PW, P_VM_PWMODE}},
    {"VCO-1", K_YELLOW, 3, {P_V1_XMOD, P_V1_RANGE, P_V1_WAVE}},
    {"VCO-2", K_CREAM, 5, {P_V2_SYNC, P_V2_RANGE, P_V2_LOW, P_V2_TUNE, P_V2_WAVE}},
    {"MIX HPF VCA", K_BLUE, 4, {P_MIX, P_HPF, P_VCA_LEVEL, P_VCA_LFO}},
    {"VCF", K_RED, 4, {P_VCF_CUT, P_VCF_RES, P_VCF_ENV, P_VCF_KEY}},
    {"VCF 2", K_RED, 3, {P_VCF_SLOPE, P_VCF_ENVSEL, P_VCF_LFO}},
    {"ENV-1", K_YELLOW, 6, {P_E1_A, P_E1_D, P_E1_S, P_E1_R, P_E1_KEY, P_E1_POL}},
    {"ENV-2", K_CREAM, 5, {P_E2_A, P_E2_D, P_E2_S, P_E2_R, P_E2_KEY}},
};
static const spage_t kPerfPages[] = {
    {"ASSIGN", K_RED, 4, {P_ASSIGN, PG(G_HOLD_U), PG(G_HOLD_L), PG(G_VINTAGE)}},
    {"KEY MODE", K_ORANGE, 3, {PG(G_KEYMODE), PG(G_PANEL), PG(G_SPLIT)}},
    {"ARPEGGIO", K_YELLOW, 4, {PG(G_ARP_ON), PG(G_ARP_MODE), PG(G_ARP_RANGE), PG(G_ARP_RATE)}},
    {"PORTAMENTO", K_CREAM, 2, {PG(G_PORTA_MODE), PG(G_PORTA_TIME)}},
    {"BENDER", K_BLUE, 5, {PG(G_BEND_VCO), PG(G_BEND_V1), PG(G_BEND_V2), PG(G_BEND_VCF), PG(G_BEND_VCFSW)}},
    {"LFO MOD", K_RED, 5, {PG(G_MOD_RISE), PG(G_MOD_VCO), PG(G_MOD_VCOSW), PG(G_MOD_VCF), PG(G_MOD_VCFSW)}},
    {"MASTER", K_ORANGE, 4, {PG(G_VOLUME), PG(G_BAL_U), PG(G_BAL_L), PG(G_TUNE)}},
    {"MIDI", K_YELLOW, 3, {PG(G_CH_U), PG(G_CH_L), PG(G_MOUT)}},
    {"SEQUENCER", K_ORANGE, 6, {PG(G_SYNC), PG(G_TEMPO), PG(G_SEQKEYS), PG(G_SONG), PG(G_SONGLOOP), PG(G_SWING)}},
    {"RECORDING", K_YELLOW, 4, {PG(G_METRO), PG(G_COUNTIN), PG(G_CLICKVOL), PG(G_QUANT)}},
    {"STORAGE", K_BLUE, 1, {PG(G_AUTOSAVE)}},
};
#define NPANELPAGES ((int)(sizeof kPanelPages / sizeof kPanelPages[0]))
#define NPERFPAGES ((int)(sizeof kPerfPages / sizeof kPerfPages[0]))
static const spage_t *sp_tab(int page, int *np)
{
    if (page == PAGE_PERF) { *np = NPERFPAGES; return kPerfPages; }
    *np = NPANELPAGES;
    return kPanelPages;
}
static int sp_total(int page)
{
    int np, i, n = 0;
    const spage_t *t = sp_tab(page, &np);
    for (i = 0; i < np; i++) n += t[i].n;
    return n;
}
static int sp_locate(int page, int flat, int *k)               /* the page holding the flat position, and the control in it */
{
    int np, i;
    const spage_t *t = sp_tab(page, &np);
    for (i = 0; i < np; i++) {
        if (flat < t[i].n) { if (k) *k = flat; return i; }
        flat -= t[i].n;
    }
    if (k) *k = 0;
    return 0;
}
static int sp_first(int page, int pg)                          /* the flat position of a page's first control */
{
    int np, i, n = 0;
    const spage_t *t = sp_tab(page, &np);
    for (i = 0; i < pg; i++) n += t[i].n;
    return n;
}
static int sp_param(int page, int flat)
{
    int k, pg = sp_locate(page, flat, &k), np;
    return sp_tab(page, &np)[pg].ids[k];
}
/* a parameter's place (host tools and tests aim the focus with it) */
/* ---- the effects page: one scrolling list built from whichever effect types are selected */
typedef struct { uint8_t group, kind; int8_t idx; } fxrow_t;     /* kind 0 switch, 1 MFX type, 2 value, 3 tempo */
#define FX_MAXROWS 64
static int fx_rows(const ju_fxpatch_t *f, fxrow_t *r)
{
    int n = 0, i;
    r[n].group = 0; r[n].kind = 0; r[n++].idx = 0;
    r[n].group = 0; r[n].kind = 1; r[n++].idx = 0;
    for (i = 0; i < ju_mfx_nparams(f->mfxType); i++) { r[n].group = 0; r[n].kind = 2; r[n++].idx = (int8_t)i; }
    r[n].group = 1; r[n].kind = 0; r[n++].idx = 1;
    for (i = 0; i < DL_COUNT; i++) { r[n].group = 1; r[n].kind = 2; r[n++].idx = (int8_t)i; }
    r[n].group = 2; r[n].kind = 0; r[n++].idx = 2;
    r[n].group = 2; r[n].kind = 2; r[n++].idx = RV_SEND;
    r[n].group = 2; r[n].kind = 2; r[n++].idx = RV_MODE;
    if (f->r[RV_MODE] == RVM_SHIMMER) for (i = RS_LDAMP; i < RV_COUNT; i++) { r[n].group = 2; r[n].kind = 2; r[n++].idx = (int8_t)i; }
    else for (i = RV_TYPE; i <= RV_LEV; i++) { r[n].group = 2; r[n].kind = 2; r[n++].idx = (int8_t)i; }
    r[n].group = 3; r[n].kind = 3; r[n++].idx = 0;
    return n;
}
static const ju_fxparam_t *fx_row_def(const ju_fxpatch_t *f, const fxrow_t *r)
{
    if (r->group == 0) return ju_mfx_param(f->mfxType, r->idx);
    return r->group == 1 ? ju_delay_param(r->idx) : ju_reverb_param(r->idx);
}
static int16_t *fx_row_val(ju_fxpatch_t *f, const fxrow_t *r)
{
    return r->group == 0 ? &f->m[r->idx] : r->group == 1 ? &f->d[r->idx] : &f->r[r->idx];
}
/* The effects list in pages of up to FX_PER_PAGE rows at double size; a page never mixes the sections (CHORUS & MFX, delay,
 * reverb, tempo). starts[] gets the first row of every page; returns the number of pages. */
#define FX_PER_PAGE 5
#define FX_MAXPAGES 24
static int fx_paginate(const fxrow_t *rows, int n, int *starts)
{
    int i, np = 0, cnt = 0;
    for (i = 0; i < n; i++) {
        if (i == 0 || cnt == FX_PER_PAGE || rows[i].group != rows[i - 1].group) {
            if (np < FX_MAXPAGES - 1) starts[np++] = i;
            cnt = 0;
        }
        cnt++;
    }
    starts[np] = n;
    return np;
}
static int fx_page_of(const int *starts, int np, int row)
{
    int p;
    for (p = np - 1; p > 0; p--) if (row >= starts[p]) break;
    return p;
}

static const uint16_t kFxCols[4] = {K_RED, K_YELLOW, K_BLUE, K_ORANGE};
static const char *const kFxGroups[4] = {"CHORUS+MFX", "DELAY", "REVERB", "TEMPO"};
static const char *const kFxTags[4] = {"MFX", "DLY", "REV", "BPM"};

/* ---- the Q-Link groups */
enum { DK_PATCH, DK_GLOBAL, DK_REV_SEND, DK_DLY_SEND, DK_DLY_TIME, DK_DLY_FB, DK_BALANCE, DK_PORTA };
typedef struct { uint8_t kind, id; const char *name, *longName; } dial_t;
typedef struct { const char *name; uint16_t color; dial_t d[4]; } qgroup_t;
#define PD(id, n, l) {DK_PATCH, (uint8_t)(id), n, l}
#define GD(id, n, l) {DK_GLOBAL, (uint8_t)(id), n, l}
static const qgroup_t kQ[] = {
    {"FILTER", K_RED, {PD(P_VCF_CUT, "CUTOFF", "VCF CUTOFF"), PD(P_VCF_RES, "RESO", "VCF RESONANCE"), PD(P_VCF_ENV, "ENV", "VCF ENV DEPTH"), PD(P_VCF_KEY, "KEY", "VCF KEY FOLLOW")}},
    {"FILTER 2", K_RED, {PD(P_HPF, "HPF", "HIGH-PASS CUTOFF"), PD(P_VCF_LFO, "LFO", "VCF LFO DEPTH"), PD(P_VCF_ENVSEL, "ENV SEL", "VCF ENV SELECT"), PD(P_VCF_SLOPE, "SLOPE", "VCF SLOPE dB/OCT")}},
    {"ENV-1", K_YELLOW, {PD(P_E1_A, "ATTACK", "ENV-1 ATTACK"), PD(P_E1_D, "DECAY", "ENV-1 DECAY"), PD(P_E1_S, "SUSTAIN", "ENV-1 SUSTAIN"), PD(P_E1_R, "RELEASE", "ENV-1 RELEASE")}},
    {"ENV-2", K_CREAM, {PD(P_E2_A, "ATTACK", "ENV-2 ATTACK"), PD(P_E2_D, "DECAY", "ENV-2 DECAY"), PD(P_E2_S, "SUSTAIN", "ENV-2 SUSTAIN"), PD(P_E2_R, "RELEASE", "ENV-2 RELEASE")}},
    {"VCO", K_ORANGE, {PD(P_MIX, "MIX", "SOURCE MIX V1-V2"), PD(P_V2_TUNE, "FINE", "VCO-2 FINE TUNE"), PD(P_V1_XMOD, "XMOD", "CROSS MOD"), PD(P_VM_PW, "PW", "PULSE WIDTH MOD")}},
    {"LFO", K_RED, {PD(P_LFO_RATE, "RATE", "LFO RATE"), PD(P_LFO_DELAY, "DELAY", "LFO DELAY"), PD(P_VM_LFO, "VCO", "VCO LFO DEPTH"), PD(P_VCF_LFO, "VCF", "VCF LFO DEPTH")}},
    {"EFFECTS", K_BLUE, {{DK_REV_SEND, 0, "REVERB", "REVERB SEND"}, {DK_DLY_SEND, 0, "DELAY", "DELAY SEND"}, {DK_DLY_TIME, 0, "TIME", "DELAY TIME"}, {DK_DLY_FB, 0, "FDBACK", "DELAY FEEDBACK"}}},
    {"PLAY", K_ORANGE, {PD(P_VCA_LEVEL, "LEVEL", "VCA LEVEL"), {DK_PORTA, 0, "PORTA", "PORTAMENTO TIME"}, GD(G_ARP_RATE, "ARP", "ARP RATE"), {DK_BALANCE, 0, "BALANCE", "PART BALANCE"}}},
};
#define NQ ((int)(sizeof kQ / sizeof kQ[0]))
#define OVERVIEW_MS 1000u               /* how long the group overview stays after a group change */

typedef struct {
    int page, qgroup;
    int focus[PAGE_COUNT];
    int patch_idx[2];
    uint8_t write_mode, dirty;
    uint8_t saved_global[G_COUNT];
    int last_dial;
    uint32_t last_dial_at, now, overview_at, save_at;
    uint32_t last_turn[4];
    int turning_enc;
    uint8_t overview;
    uint8_t cpu;                        /* percent, for the header */
    uint8_t seq_sub;                    /* the SEQ page: 0 the roll, 1 the setup, 2 the song, 3 the step's velocity / probability / ratchet, 4 its chord and lane, 5 the edit tools */
    uint8_t tool_sel; int8_t tool_amt[2];  /* the tools page: the tool under the cursor; the amounts of TRANSPOSE and SHIFT */
    uint8_t rec_used, panic_done;       /* REC was used as a modifier; PLAY held long enough for all notes off */
    uint32_t play_down_at, seq_save_at, clear_at;
    uint8_t seq_lo;                     /* the lowest note the piano roll shows (it follows the cursor) */
    uint8_t song_cur;                   /* the song page's row (n: the empty row after the last) */
    int8_t proj_cur;                    /* the project open (last saved or loaded), -1: none */
    uint8_t proj_sel, proj_ask;         /* the project page's cursor; a confirmation asked: 0 none, 1 save, 2 load, 3 clear */
    uint8_t auto_seen, auto_chg;        /* the autosave option as last seen (2: not yet); it changed and must be written once */
    uint32_t busy_at;                   /* when something last sounded or the sequencer last ran (autosaves wait for quiet) */
    uint8_t sig_pend;                   /* a project was loaded: its signature is taken once the engine has its sounds */
    uint32_t proj_sig, work_sig, sig_at, proj_msg_at;   /* signature of the open project as saved; of the working copy; when taken; when the message was set */
    const char *proj_msg;               /* what the last save / load did, shown for a few seconds */
} ui_t;
static ui_t ui = {.tool_amt = {1, 1}, .page = PAGE_QLINK, .patch_idx = {8, 0}, .song_cur = 0, .last_dial = -1, .overview = 1, .proj_cur = -1, .auto_seen = 2};

static void ui_focus_on(int page, int id)
{
    int np, i, k;
    const spage_t *t = sp_tab(page, &np);
    for (i = 0; i < np; i++)
        for (k = 0; k < t[i].n; k++)
            if (t[i].ids[k] == id) { ui.focus[page] = sp_first(page, i) + k; return; }
}

static int cv_text_w_1(const char *x) { return cv_text_w(x, 1); }
static void ju_store_current(void);                       /* ju_store.c */
static int ju_store_seq(int part);
static int ju_store_song(void);
static int ju_store_patch(int idx);
static int ju_proj_flash_save(int slot);
static int ju_proj_flash_load(int slot);
static int ju_proj_flash_clear(int slot);

static int ui_layer(void) { return ju_global[G_PANEL] & 1; }
static int ui_focus_count(void)
{
    fxrow_t r[FX_MAXROWS];
    switch (ui.page) {
    case PAGE_QLINK: return 8;
    case PAGE_PANEL: case PAGE_PERF: return sp_total(ui.page);
    case PAGE_FX: return fx_rows(&ju_patch[0].fx, r);
    default: return 65;                                   /* 64 patches plus WRITE */
    }
}
static int ui_focus_param(void)
{
    switch (ui.page) {
    case PAGE_PANEL: case PAGE_PERF: return sp_param(ui.page, ui.focus[ui.page]);
    default: return -1;
    }
}
static uint8_t ui_get(int id) { return id < P_COUNT ? ju_patch[ui_layer()].v[id] : ju_global[id - P_COUNT]; }
static void ui_set(int id, uint8_t v)
{
    if (id < P_COUNT) ju_patch[ui_layer()].v[id] = v;
    else ju_global[id - P_COUNT] = v;
    ui.dirty = 1;
}

/* each knob keeps its own speed, so turning two at once does not disturb either */
static int ui_accel(int enc, uint32_t now, int range)
{
    uint32_t dt = now - ui.last_turn[enc & 3];
    int mul;
    ui.last_turn[enc & 3] = now;
    if (range < 30) return 1;
    mul = dt < 15 ? 8 : dt < 40 ? 4 : dt < 90 ? 2 : 1;
    if (range > 500) mul *= mul;
    return mul;
}

static void ui_adjust(int id, int delta, uint32_t now)
{
    int v, steps;
    if (id < 0 || delta == 0) return;
    steps = ju_psteps(id);
    v = ui_get(id);
    if (steps) {
        v += delta > 0 ? 1 : -1;
        if (v < 0) v = 0;
        if (v >= steps) v = steps - 1;
    } else {
        v += delta * ui_accel(ui.turning_enc, now, 255);
        v = v < 0 ? 0 : (v > 255 ? 255 : v);
    }
    ui_set(id, (uint8_t)v);
    if (id >= P_COUNT) ui.save_at = now + 2000u;
}

static void ui_adjust_fx(int row_idx, int delta, uint32_t now)
{
    ju_fxpatch_t *f = &ju_patch[0].fx;
    fxrow_t rows[FX_MAXROWS];
    const fxrow_t *r;
    int n = fx_rows(f, rows), dir = delta > 0 ? 1 : -1;
    if (delta == 0 || row_idx >= n) return;
    r = &rows[row_idx];
    switch (r->kind) {
    case 0: {
        uint8_t *sw = r->idx == 0 ? &f->mfxOn : r->idx == 1 ? &f->dlyOn : &f->revOn;
        *sw = dir > 0;
        break;
    }
    case 1: {
        int t = (int)f->mfxType + dir;
        if (t < 0) t = MFX_COUNT - 1;
        if (t >= MFX_COUNT) t = 0;
        ju_fx_load_mfx_defaults(f, t);
        break;
    }
    case 3:
        ui_adjust(P_COUNT + G_TEMPO, delta, now);
        return;
    default: {
        const ju_fxparam_t *d = fx_row_def(f, r);
        int16_t *v = fx_row_val(f, r);
        int nv = (int)*v + delta * ui_accel(ui.turning_enc, now, (int)d->hi - (int)d->lo);
        *v = (int16_t)(nv < d->lo ? d->lo : (nv > d->hi ? d->hi : nv));
        break;
    }
    }
    ui.dirty = 1;
    n = fx_rows(f, rows);
    if (ui.focus[PAGE_FX] >= n) ui.focus[PAGE_FX] = n - 1;
}

static void ui_move_focus(int d)
{
    int n = ui_focus_count(), f = ui.focus[ui.page] + d;
    while (f < 0) f += n;
    ui.focus[ui.page] = f % n;
}

static void ui_jump_section(int d)
{
    if (ui.page == PAGE_PANEL || ui.page == PAGE_PERF) {      /* a page forward or back */
        int np, pg;
        sp_tab(ui.page, &np);
        pg = sp_locate(ui.page, ui.focus[ui.page], 0);
        pg = (pg + (d > 0 ? 1 : np - 1)) % np;
        ui.focus[ui.page] = sp_first(ui.page, pg);
    } else if (ui.page == PAGE_FX) {
        fxrow_t rows[FX_MAXROWS];
        int starts[FX_MAXPAGES + 1];
        int n = fx_rows(&ju_patch[0].fx, rows), np = fx_paginate(rows, n, starts), f = ui.focus[PAGE_FX], pg;
        pg = fx_page_of(starts, np, f < n ? f : 0);
        pg = (pg + (d > 0 ? 1 : np - 1)) % np;
        ui.focus[PAGE_FX] = starts[pg];
    } else {
        ui_move_focus(d > 0 ? 8 : -8);
    }
}

/* a patch into a part: the audio applies it at its next block */
static void ui_load_patch(int layer, int index)
{
    if (index < 0 || index >= 64) return;
    ui.patch_idx[layer] = index;
    ju_load_req[layer] = (uint8_t)(index + 1);
}

static void ui_activate(void)                       /* PATCHES: load the patch under the cursor, or write to it */
{
    int f = ui.focus[PAGE_PATCH], l = ui_layer();
    if (f == 64) { ui.write_mode = !ui.write_mode; return; }
    if (ui.write_mode) {
        ju_bank[f] = ju_patch[l];
        ui.patch_idx[l] = f;
        (void)ju_store_patch(f);
        ui.write_mode = 0;
    } else {
        ui_load_patch(l, f);
        ju_store_current();
    }
}

/* ---- Q-Link dials */
static int balance_of(const uint8_t *g) { return g[G_BAL_L] < 255 ? 255 - g[G_BAL_L] : -(255 - g[G_BAL_U]); }   /* -255: part 2 only, +255: part 1 only */

static void q_turn(int di, int delta, uint32_t now)
{
    const dial_t *d = &kQ[ui.qgroup].d[di];
    ju_fxpatch_t *f = &ju_patch[0].fx;
    ui.last_dial = di;
    ui.last_dial_at = now;
    ui.turning_enc = di;
    switch (d->kind) {
    case DK_PATCH: ui_adjust(d->id, delta, now); break;
    case DK_GLOBAL: ui_adjust(P_COUNT + d->id, delta, now); break;
    case DK_REV_SEND:
    case DK_DLY_SEND: {                              /* a send of zero is the section switched off */
        int rev = d->kind == DK_REV_SEND;
        uint8_t *on = rev ? &f->revOn : &f->dlyOn;
        int16_t *send = rev ? &f->r[RV_SEND] : &f->d[DL_SEND];
        int v = *on ? *send : 0;
        v += delta * ui_accel(di, now, 127);
        v = v < 0 ? 0 : (v > 127 ? 127 : v);
        *send = (int16_t)v;
        *on = v > 0;
        break;
    }
    case DK_DLY_TIME:                                /* note values when synced, milliseconds otherwise */
        if (f->d[DL_SYNC]) {
            int v = f->d[DL_NOTE] + (delta > 0 ? 1 : -1);
            f->d[DL_NOTE] = (int16_t)(v < 0 ? 0 : (v > 21 ? 21 : v));
        } else {
            int v = f->d[DL_TIME] + delta * ui_accel(di, now, 1299);
            f->d[DL_TIME] = (int16_t)(v < 1 ? 1 : (v > 1300 ? 1300 : v));
        }
        break;
    case DK_DLY_FB: {
        int v = f->d[DL_FB] + delta * ui_accel(di, now, 196);
        f->d[DL_FB] = (int16_t)(v < -98 ? -98 : (v > 98 ? 98 : v));
        break;
    }
    case DK_BALANCE: {
        int v = balance_of(ju_global) + delta * ui_accel(di, now, 255);
        v = v < -255 ? -255 : (v > 255 ? 255 : v);
        ju_global[G_BAL_U] = (uint8_t)(v < 0 ? 255 + v : 255);
        ju_global[G_BAL_L] = (uint8_t)(v > 0 ? 255 - v : 255);
        ui.save_at = now + 2000u;
        break;
    }
    case DK_PORTA:
        ui_adjust(P_COUNT + G_PORTA_TIME, delta, now);
        if (ju_global[G_PORTA_TIME] == 0) ju_global[G_PORTA_MODE] = PM_OFF;       /* zero is off, turning it up is all it takes */
        else if (ju_global[G_PORTA_MODE] == PM_OFF) ju_global[G_PORTA_MODE] = PM_ON;
        break;
    }
}

static void q_restore(int di, uint32_t now)           /* the dial back to the saved patch's value */
{
    const dial_t *d = &kQ[ui.qgroup].d[di];
    ju_fxpatch_t *f = &ju_patch[0].fx;
    const ju_fxpatch_t *sf = &ju_bank[ui.patch_idx[0]].fx;
    ui.last_dial = di;
    ui.last_dial_at = now;
    switch (d->kind) {
    case DK_PATCH: ju_patch[ui_layer()].v[d->id] = ju_bank[ui.patch_idx[ui_layer()]].v[d->id]; break;
    case DK_GLOBAL: ju_global[d->id] = ui.saved_global[d->id]; break;
    case DK_REV_SEND: f->r[RV_SEND] = sf->r[RV_SEND]; f->revOn = sf->revOn; break;
    case DK_DLY_SEND: f->d[DL_SEND] = sf->d[DL_SEND]; f->dlyOn = sf->dlyOn; break;
    case DK_DLY_TIME: f->d[DL_TIME] = sf->d[DL_TIME]; f->d[DL_NOTE] = sf->d[DL_NOTE]; break;
    case DK_DLY_FB: f->d[DL_FB] = sf->d[DL_FB]; break;
    case DK_BALANCE: ju_global[G_BAL_U] = ui.saved_global[G_BAL_U]; ju_global[G_BAL_L] = ui.saved_global[G_BAL_L]; break;
    case DK_PORTA: ju_global[G_PORTA_TIME] = ui.saved_global[G_PORTA_TIME]; ju_global[G_PORTA_MODE] = ui.saved_global[G_PORTA_MODE]; break;
    }
}

static int q_edited(int di)
{
    const dial_t *d = &kQ[ui.qgroup].d[di];
    const ju_fxpatch_t *f = &ju_patch[0].fx, *sf = &ju_bank[ui.patch_idx[0]].fx;
    switch (d->kind) {
    case DK_PATCH: return ju_patch[ui_layer()].v[d->id] != ju_bank[ui.patch_idx[ui_layer()]].v[d->id];
    case DK_GLOBAL: return ju_global[d->id] != ui.saved_global[d->id];
    case DK_REV_SEND: return f->revOn != sf->revOn || (f->revOn && f->r[RV_SEND] != sf->r[RV_SEND]);
    case DK_DLY_SEND: return f->dlyOn != sf->dlyOn || (f->dlyOn && f->d[DL_SEND] != sf->d[DL_SEND]);
    case DK_DLY_TIME: return f->d[DL_TIME] != sf->d[DL_TIME] || f->d[DL_NOTE] != sf->d[DL_NOTE];
    case DK_DLY_FB: return f->d[DL_FB] != sf->d[DL_FB];
    case DK_BALANCE: return ju_global[G_BAL_U] != ui.saved_global[G_BAL_U] || ju_global[G_BAL_L] != ui.saved_global[G_BAL_L];
    case DK_PORTA: return ju_global[G_PORTA_TIME] != ui.saved_global[G_PORTA_TIME];
    }
    return 0;
}

static int q_norm(int di)                              /* the dial's position, 0..1000 */
{
    const dial_t *d = &kQ[ui.qgroup].d[di];
    const ju_fxpatch_t *f = &ju_patch[0].fx;
    switch (d->kind) {
    case DK_PATCH: {
        int steps = ju_psteps(d->id), v = ju_patch[ui_layer()].v[d->id];
        return steps ? v * 1000 / (steps - 1) : v * 1000 / 255;
    }
    case DK_GLOBAL: return ju_global[d->id] * 1000 / 255;
    case DK_REV_SEND: return f->revOn ? f->r[RV_SEND] * 1000 / 127 : 0;
    case DK_DLY_SEND: return f->dlyOn ? f->d[DL_SEND] * 1000 / 127 : 0;
    case DK_DLY_TIME: return f->d[DL_SYNC] ? f->d[DL_NOTE] * 1000 / 21 : f->d[DL_TIME] * 1000 / 1300;
    case DK_DLY_FB: return (f->d[DL_FB] + 98) * 1000 / 196;
    case DK_BALANCE: return (balance_of(ju_global) + 255) * 1000 / 510;
    case DK_PORTA: return ju_global[G_PORTA_TIME] * 1000 / 255;
    }
    return 0;
}

static void ui_strcat(char *d, int n, const char *s)
{
    int i = (int)str_len(d);
    while (*s && i < n - 1) d[i++] = *s++;
    d[i] = 0;
}
static void ui_num(char *d, int n, int v) { char t[12]; fmt_int(t, v); ui_strcat(d, n, t); }

static void seq_note_name(char *o, int n)                 /* "C#4" */
{
    static const char *const nm[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    o[0] = 0;
    ui_strcat(o, 8, nm[n % 12]);
    ui_num(o, 8, n / 12 - 1);
}


static void q_format(int di, char *out, int n)
{
    const dial_t *d = &kQ[ui.qgroup].d[di];
    const ju_fxpatch_t *f = &ju_patch[0].fx;
    out[0] = 0;
    switch (d->kind) {
    case DK_PATCH: ju_format_param(d->id, ju_patch[ui_layer()].v[d->id], out, n); break;
    case DK_GLOBAL: ju_format_param(P_COUNT + d->id, ju_global[d->id], out, n); break;
    case DK_REV_SEND: if (f->revOn) ui_num(out, n, f->r[RV_SEND]); else ui_strcat(out, n, "OFF"); break;
    case DK_DLY_SEND: if (f->dlyOn) ui_num(out, n, f->d[DL_SEND]); else ui_strcat(out, n, "OFF"); break;
    case DK_DLY_TIME:
        if (f->d[DL_SYNC]) ju_fx_format(ju_delay_param(DL_NOTE), f->d[DL_NOTE], out, n);
        else { ui_num(out, n, f->d[DL_TIME]); ui_strcat(out, n, " ms"); }
        break;
    case DK_DLY_FB: ui_num(out, n, f->d[DL_FB]); ui_strcat(out, n, " %"); break;
    case DK_BALANCE: {
        int b = balance_of(ju_global) * 100 / 255;
        if (b == 0) ui_strcat(out, n, "CENTRE");
        else { ui_strcat(out, n, b > 0 ? "P1 " : "P2 "); ui_num(out, n, 100 - (b > 0 ? b : -b)); ui_strcat(out, n, "%"); }
        break;
    }
    case DK_PORTA:
        if (ju_global[G_PORTA_TIME] == 0 || ju_global[G_PORTA_MODE] == PM_OFF) ui_strcat(out, n, "OFF");
        else ju_format_param(P_COUNT + G_PORTA_TIME, ju_global[G_PORTA_TIME], out, n);
        break;
    }
}

static void ui_group_to(int g)                         /* the Q-Link page on a group, with the overview up for a moment */
{
    ui.qgroup = ((g % NQ) + NQ) % NQ;
    ui.page = PAGE_QLINK;
    ui.last_dial = -1;
    ui.write_mode = 0;
    ui.overview = 1;
    ui.overview_at = ui.now;
}

/* ---- the sequencer page, a piano roll: KNOB 1 the step, 2 the pitch, 3 the length of the note, 4 the pattern
 * (setup: 1 the pattern's length, 2 the gate, 3 the tempo, 4 the pattern). A note is a NOTE step followed by the TIE steps it lasts
 * through; the length knob adds and takes away ties (up to the next note), and 0 deletes the note. */
#define ROLL_ROWS 22                                        /* semitones the roll shows */
static const uint8_t kSeqNext[6] = {3, 2, 5, 4, 1, 0};     /* SEQ again: the roll, the step page, the chord page, the setup, the song, the tools, the roll */
static ju_pat_t *ui_pat(void) { return &ju_pat[ui_layer()][ju_seq_cur[ui_layer()] % JU_SEQ_PATS]; }
static int seq_head(const ju_pat_t *t, int i)               /* the NOTE step a step belongs to (itself, or the one its ties hang on), -1 if none */
{
    int k = i;
    while (k > 0 && t->type[k] == SQ_TIE) k--;
    return t->type[k] == SQ_NOTE ? k : -1;
}
static int seq_chain(const ju_pat_t *t, int head)           /* the steps the note lasts: itself and its ties */
{
    int n = 1;
    while (head + n < t->len && t->type[head + n] == SQ_TIE) n++;
    return n;
}
static void seq_set_len(ju_pat_t *t, int head, int want)    /* 0 deletes; no longer than the free steps up to the next note */
{
    int have = seq_chain(t, head), room = 1, k;
    while (head + room < t->len && t->type[head + room] != SQ_NOTE) room++;
    if (want > room) want = room;
    if (want <= 0) { for (k = head; k < head + have; k++) t->type[k] = SQ_REST; return; }
    for (k = head + 1; k < head + want; k++) t->type[k] = SQ_TIE;
    for (k = head + want; k < head + have; k++) t->type[k] = SQ_REST;
}
static void ui_seq_clear(void)
{
    ju_pat_t *t = ui_pat();
    int i;
    for (i = 0; i < JU_SEQ_STEPS; i++) { t->type[i] = SQ_REST; t->note[i] = 60; }
    ju_seq_cursor[ui_layer()] = 0;
    ju_seq_dirty[ui_layer()] = 1;
}
static void ui_seq_view(void)                               /* the roll follows the note under the cursor, keeping two rows of margin */
{
    const ju_pat_t *t = ui_pat();
    int len = t->len ? t->len : 16, cur = ju_seq_cursor[ui_layer()] % len, h = seq_head(t, cur), n = t->note[h >= 0 ? h : cur], lo = ui.seq_lo;
    if (n < lo + 2) lo = n - 2;
    if (n > lo + ROLL_ROWS - 3) lo = n - (ROLL_ROWS - 3);
    ui.seq_lo = (uint8_t)(lo < 0 ? 0 : lo > 127 - ROLL_ROWS + 1 ? 127 - ROLL_ROWS + 1 : lo);
}
/* ---- the song page: rows of (upper pattern, lower pattern, repeats). KNOB 1 the row, 2 the upper pattern, 3 the lower pattern (--: none),
 * 4 the repeats. SCL deletes the row, OCT+ inserts a copy, OCT- song mode on / off. */
static void ui_song_insert(void)
{
    int i, c = ui.song_cur;
    if (ju_song.n >= JU_SONG_ROWS) return;
    if (c > ju_song.n) c = ju_song.n;
    for (i = ju_song.n; i > c; i--) ju_song.row[i] = ju_song.row[i - 1];
    if (c < ju_song.n) ju_song.row[c] = ju_song.row[c + 1];                  /* a copy of the row it goes before */
    else { ju_song.row[c].pat[0] = (uint8_t)ju_seq_cur[0]; ju_song.row[c].pat[1] = (uint8_t)ju_seq_cur[1]; ju_song.row[c].rep = 1; }
    ju_song.n++;
    ju_song_dirty = 1;
}
static void ui_song_input(const ju_in_t *in, uint32_t now)
{
    int d, f, i;
    (void)now;
    if (in->knob[0]) {
        d = ui.song_cur + in->knob[0];
        d = d < 0 ? 0 : d > ju_song.n ? ju_song.n : d;
        if (d > JU_SONG_ROWS - 1) d = JU_SONG_ROWS - 1;
        ui.song_cur = (uint8_t)d;
        ju_song_sel = (uint8_t)(ui.song_cur < ju_song.n ? ui.song_cur : (ju_song.n ? ju_song.n - 1 : 0));        /* PLAY starts from here */
    }
    for (f = 1; f <= 3; f++) {
        if (!in->knob[f]) continue;
        if (ui.song_cur >= ju_song.n) {                                      /* the empty row: a turn makes it a row */
            ju_srow_t *r;
            if (ju_song.n >= JU_SONG_ROWS) continue;
            r = &ju_song.row[ju_song.n];
            r->pat[0] = (uint8_t)ju_seq_cur[0]; r->pat[1] = (uint8_t)ju_seq_cur[1]; r->rep = 1;
            ui.song_cur = ju_song.n;
            ju_song.n++;
        }
        {
            ju_srow_t *r = &ju_song.row[ui.song_cur];
            if (f == 3) {
                d = (int)r->rep + in->knob[3];
                r->rep = (uint8_t)(d < 1 ? 1 : d > 16 ? 16 : d);
            } else {
                i = f - 1;
                d = (r->pat[i] >= JU_SEQ_PATS ? -1 : (int)r->pat[i]) + in->knob[f];
                d = d < -1 ? -1 : d > JU_SEQ_PATS - 1 ? JU_SEQ_PATS - 1 : d;
                r->pat[i] = d < 0 ? JU_SONG_NONE : (uint8_t)d;
            }
            ju_song_dirty = 1;
        }
    }
    if ((in->press & BTN(B_SCL)) && ui.song_cur < ju_song.n) {               /* delete the row */
        for (i = ui.song_cur; i + 1 < ju_song.n; i++) ju_song.row[i] = ju_song.row[i + 1];
        ju_song.n--;
        ju_song_dirty = 1;
        if (ui.song_cur > ju_song.n) ui.song_cur = ju_song.n;
        ju_song_sel = (uint8_t)(ui.song_cur < ju_song.n ? ui.song_cur : (ju_song.n ? ju_song.n - 1 : 0));
    }
}

/* ---- the edit tools (the last SEQ page): whole-pattern operations. KNOB 1 picks the tool, KNOB 2 sets the amount of TRANSPOSE and SHIFT, OCT+ does it.
 * The last tool's effect can be taken back (UNDO TOOL). They work on the pattern being edited, in the part being edited. */
enum { TL_COPY, TL_PASTE, TL_NEXT, TL_OTHER, TL_TRANSPOSE, TL_SHIFT, TL_DOUBLE, TL_HALVE, TL_UNDO, TL_COUNT };
static const char *const kTools[TL_COUNT] = {"COPY", "PASTE", "COPY TO NEXT", "TO OTHER PART", "TRANSPOSE", "SHIFT", "DOUBLE", "HALVE", "UNDO TOOL"};
static ju_pat_t ui_clip, ui_tool_undo;
static uint8_t ui_clip_ok, ui_undo_ok, ui_undo_part, ui_undo_pat;
static void ui_tool_msg(const char *m) { ui.proj_msg = m; ui.proj_msg_at = ui.now ? ui.now : 1u; }
static void ui_tool_remember(int part, int idx)          /* before a tool changes a pattern */
{
    ui_tool_undo = ju_pat[part][idx]; ui_undo_part = (uint8_t)part; ui_undo_pat = (uint8_t)idx; ui_undo_ok = 1;
}
static void ui_tool_apply(void)
{
    int p = ui_layer(), idx = ju_seq_cur[p] % JU_SEQ_PATS, i, n, len;
    ju_pat_t *t = &ju_pat[p][idx], tmp;
    len = t->len >= 1 && t->len <= JU_SEQ_STEPS ? t->len : 16;
    switch (ui.tool_sel) {
    case TL_COPY: ui_clip = *t; ui_clip_ok = 1; ui_tool_msg("COPIED"); return;
    case TL_PASTE:
        if (!ui_clip_ok) { ui_tool_msg("NOTHING COPIED YET"); return; }
        ui_tool_remember(p, idx); *t = ui_clip; ju_seq_dirty[p] = 1; ui_tool_msg("PASTED"); return;
    case TL_NEXT:                                        /* the pattern into the next one, and on to it: to build a variation */
        ui_tool_remember(p, (idx + 1) % JU_SEQ_PATS);
        ju_pat[p][(idx + 1) % JU_SEQ_PATS] = *t; ju_seq_cur[p] = (uint8_t)((idx + 1) % JU_SEQ_PATS); ju_seq_cursor[p] = 0;
        ju_seq_dirty[p] = 1; ui.save_at = ui.now + 2000u; ui_tool_msg("COPIED TO THE NEXT PATTERN"); return;
    case TL_OTHER:
        ui_tool_remember(1 - p, idx);
        ju_pat[1 - p][idx] = *t; ju_seq_dirty[1 - p] = 1; ui_tool_msg(p ? "COPIED TO THE UPPER PART" : "COPIED TO THE LOWER PART"); return;
    case TL_UNDO:
        if (!ui_undo_ok) { ui_tool_msg("NOTHING TO UNDO"); return; }
        tmp = ju_pat[ui_undo_part][ui_undo_pat]; ju_pat[ui_undo_part][ui_undo_pat] = ui_tool_undo; ui_tool_undo = tmp;      /* (undo again: redo) */
        ju_seq_dirty[ui_undo_part] = 1; ui_tool_msg("UNDONE"); return;
    default: break;
    }
    ui_tool_remember(p, idx);
    if (ui.tool_sel == TL_TRANSPOSE) {
        for (i = 0; i < JU_SEQ_STEPS; i++) { n = (int)t->note[i] + ui.tool_amt[0]; t->note[i] = (uint8_t)(n < 0 ? 0 : n > 127 ? 127 : n); }
        ui_tool_msg("TRANSPOSED");
    } else if (ui.tool_sel == TL_SHIFT) {
        int sh = ((ui.tool_amt[1] % len) + len) % len;
        tmp = *t;
        for (i = 0; i < len; i++) {
            int d = (i + sh) % len;
            t->note[d] = tmp.note[i]; t->type[d] = tmp.type[i]; t->flags[d] = tmp.flags[i]; t->chord[d][0] = tmp.chord[i][0]; t->chord[d][1] = tmp.chord[i][1]; t->lv[d] = tmp.lv[i];
        }
        ju_seq_cursor[p] = (uint8_t)((ju_seq_cursor[p] + sh) % len);
        ui_tool_msg("SHIFTED");
    } else if (ui.tool_sel == TL_DOUBLE) {
        if (len * 2 > JU_SEQ_STEPS) { ui_tool_msg("ALREADY AT 64 STEPS"); return; }
        for (i = 0; i < len; i++) {
            t->note[len + i] = t->note[i]; t->type[len + i] = t->type[i]; t->flags[len + i] = t->flags[i];
            t->chord[len + i][0] = t->chord[i][0]; t->chord[len + i][1] = t->chord[i][1]; t->lv[len + i] = t->lv[i];
        }
        t->len = (uint8_t)(len * 2); ui_tool_msg("DOUBLED");
    } else if (ui.tool_sel == TL_HALVE) {
        if (len < 2) { ui_tool_msg("ALREADY ONE STEP"); return; }
        t->len = (uint8_t)(len / 2);
        if (ju_seq_cursor[p] >= t->len) ju_seq_cursor[p] = (uint8_t)(t->len - 1);
        ui_tool_msg("HALVED");
    }
    ju_seq_dirty[p] = 1;
}
static void ui_tools_input(const ju_in_t *in)
{
    int d;
    ui.turning_enc = 1;
    if (in->knob[0]) { d = ui.tool_sel + in->knob[0]; ui.tool_sel = (uint8_t)(d < 0 ? 0 : d >= TL_COUNT ? TL_COUNT - 1 : d); }
    if (in->knob[1]) {
        if (ui.tool_sel == TL_TRANSPOSE) { d = ui.tool_amt[0] + in->knob[1]; ui.tool_amt[0] = (int8_t)(d < -24 ? -24 : d > 24 ? 24 : d); }
        else if (ui.tool_sel == TL_SHIFT) { d = ui.tool_amt[1] + in->knob[1]; ui.tool_amt[1] = (int8_t)(d < -32 ? -32 : d > 32 ? 32 : d); }
    }
    if (in->press & BTN(B_OCTUP)) ui_tool_apply();
}

/* ---- the step pages (SEQ again after the roll). Page 3: KNOB 2 the velocity, 3 the probability, 4 the ratchet of the step under the cursor.
 * Page 4: KNOB 2 the chord, 3 the lane's parameter (the pattern's), 4 the lane's value at this step. KNOB 1 moves the cursor on both. */
typedef struct { const char *name; uint8_t o[3]; } chord_t;
static const chord_t kChords[] = {{"NONE", {0, 0, 0}}, {"5TH", {7, 0, 0}}, {"OCT", {12, 0, 0}}, {"MAJ", {4, 7, 0}}, {"MIN", {3, 7, 0}}, {"SUS2", {2, 7, 0}},
    {"SUS4", {5, 7, 0}}, {"DIM", {3, 6, 0}}, {"AUG", {4, 8, 0}}, {"MAJ7", {4, 7, 11}}, {"MIN7", {3, 7, 10}}, {"DOM7", {4, 7, 10}}, {"MAJ6", {4, 7, 9}}, {"ADD9", {4, 7, 14}}};
#define NCHORDS ((int)(sizeof kChords / sizeof kChords[0]))
static int chord_of(const ju_pat_t *t, int s)           /* the preset a step's chord is, -1 if it is one of its own */
{
    int i;
    for (i = 0; i < NCHORDS; i++)
        if ((t->chord[s][0] & 15) == kChords[i].o[0] && (t->chord[s][0] >> 4) == kChords[i].o[1] && (t->chord[s][1] & 15) == kChords[i].o[2]) return i;
    return -1;
}
static const uint8_t kVelLevel[4] = {2, 3, 1, 0};        /* flag code (normal, accent, soft, ghost) -> its place from quiet to loud */
static const uint8_t kVelCode[4] = {3, 2, 0, 1};
static int lane_value_pct(int lv) { return (lv - 1) * 100 / 127; }
static void ui_step_input(const ju_in_t *in, uint32_t now, ju_pat_t *t, int p)
{
    int c = ju_seq_cursor[p], h = seq_head(t, c), n, f;
    if (in->knob[0]) ju_seq_cursor[p] = (uint8_t)(((int)ju_seq_cursor[p] + in->knob[0] % t->len + t->len) % t->len);
    if (ui.seq_sub == 3) {
        if (h < 0) return;                                  /* only a note has them */
        f = t->flags[h];
        if (in->knob[1]) { n = kVelLevel[SQF_VEL(f)] + in->knob[1]; n = n < 0 ? 0 : n > 3 ? 3 : n; f = SQF_MAKE(kVelCode[n], SQF_PROB(f), SQF_RAT(f)); }
        if (in->knob[2]) { n = 3 - SQF_PROB(f) + in->knob[2]; n = n < 0 ? 0 : n > 3 ? 3 : n; f = SQF_MAKE(SQF_VEL(f), 3 - n, SQF_RAT(f)); }
        if (in->knob[3]) { n = SQF_RAT(f) + in->knob[3]; n = n < 0 ? 0 : n > 3 ? 3 : n; f = SQF_MAKE(SQF_VEL(f), SQF_PROB(f), n); }
        if (f != t->flags[h]) { t->flags[h] = (uint8_t)f; ju_seq_dirty[p] = 1; }
        return;
    }
    if (in->knob[1]) {                                      /* the chord (a rest becomes a note) */
        int idx = h >= 0 ? h : c, cur = chord_of(t, idx);
        n = (cur < 0 ? 0 : cur) + in->knob[1];
        n = n < 0 ? 0 : n >= NCHORDS ? NCHORDS - 1 : n;
        if (t->type[idx] == SQ_REST && n > 0) t->type[idx] = SQ_NOTE;
        t->chord[idx][0] = (uint8_t)(kChords[n].o[0] | (kChords[n].o[1] << 4)); t->chord[idx][1] = kChords[n].o[2];
        ju_seq_dirty[p] = 1;
    }
    if (in->knob[2]) {                                      /* the lane's parameter: off, then the twelve */
        n = (int)t->lane + in->knob[2];
        t->lane = (uint8_t)(n < 0 ? 0 : n > JU_LANE_N ? JU_LANE_N : n);
        ju_seq_dirty[p] = 1;
    }
    if (in->knob[3] && t->lane) {                           /* the value at this step: from the sound's own value, up and down, below the bottom none */
        int lv = t->lv[c];
        if (!lv) { if (in->knob[3] > 0) lv = ju_patch[p].v[ju_lane_param[t->lane - 1]] * 127 / 255 + 1; }
        else lv += in->knob[3] * ui_accel(3, now, 8);
        t->lv[c] = (uint8_t)(lv < 1 ? 0 : lv > 128 ? 128 : lv);
        ju_seq_dirty[p] = 1;
    }
}

static void ui_seq_input(const ju_in_t *in, uint32_t now)
{
    int p = ui_layer(), n;
    ju_pat_t *t = ui_pat();
    uint8_t *cur = &ju_seq_cursor[p];
    ui.turning_enc = 1;
    if (ui.seq_sub == 2) { ui_song_input(in, now); return; }
    if (ui.seq_sub == 5) { ui_tools_input(in); return; }
    if (!t->len) t->len = 16;
    if (*cur >= t->len) *cur = (uint8_t)(t->len - 1);
    if (ui.seq_sub >= 3) {
        ui_step_input(in, now, t, p);
        if (in->press & BTN(B_SCL)) { ju_seq_op_part = (uint8_t)p; ju_seq_op_step = *cur; ju_seq_op = 2; }
    } else if (!ui.seq_sub) {
        int c = *cur, h = seq_head(t, c);
        if (in->knob[0]) *cur = (uint8_t)(((int)*cur + in->knob[0] % t->len + t->len) % t->len);
        if (in->knob[1]) {                                  /* the pitch of the note under the cursor (a rest becomes a note) */
            int idx = h >= 0 ? h : c;
            n = (int)t->note[idx] + in->knob[1];
            t->note[idx] = (uint8_t)(n < 0 ? 0 : n > 127 ? 127 : n);
            if (t->type[idx] == SQ_REST) t->type[idx] = SQ_NOTE;
            ju_seq_dirty[p] = 1;
        }
        if (in->knob[2]) {                                  /* the length of the note, in steps */
            if (h < 0) {
                if (in->knob[2] > 0) { t->type[c] = SQ_NOTE; seq_set_len(t, c, in->knob[2]); ju_seq_dirty[p] = 1; }
            } else {
                seq_set_len(t, h, seq_chain(t, h) + in->knob[2]);
                ju_seq_dirty[p] = 1;
            }
        }
        if (in->press & BTN(B_SCL)) { ju_seq_op_part = (uint8_t)p; ju_seq_op_step = *cur; ju_seq_op = 2; }   /* erase this step and the ties on it (undoable) */
    } else {
        if (in->knob[0]) {
            n = (int)t->len + in->knob[0] * ui_accel(0, now, 63);
            t->len = (uint8_t)(n < 1 ? 1 : n > JU_SEQ_STEPS ? JU_SEQ_STEPS : n);
            if (*cur >= t->len) *cur = (uint8_t)(t->len - 1);
            ju_seq_dirty[p] = 1;
        }
        if (in->knob[1]) { n = (int)t->gate + in->knob[1]; t->gate = (uint8_t)(n < 1 ? 1 : n > 6 ? 6 : n); ju_seq_dirty[p] = 1; }
        if (in->knob[2]) { ui.turning_enc = 2; ui_adjust(P_COUNT + G_TEMPO, in->knob[2], now); }
    }
    if (in->knob[3] && ui.seq_sub <= 1) {                   /* the pattern (the roll and the setup) */
        ju_seq_cur[p] = (uint8_t)(((int)ju_seq_cur[p] + (in->knob[3] > 0 ? 1 : JU_SEQ_PATS - 1)) % JU_SEQ_PATS);
        ju_seq_cursor[p] = 0;
        ui.save_at = now + 2000u;                           /* the selection is saved with the settings */
    }
    ui_seq_view();
}

/* ---- projects: 8 slots, saved and loaded only when asked. The working copy is autosaved in the settings as a safety net; the page
 * shows whether it still equals the open project. A save over another project, a load over unsaved work and a clear ask twice. */
static void ui_proj_msg(const char *m) { ui.proj_msg = m; ui.proj_msg_at = ui.now ? ui.now : 1u; }
static int ui_proj_modified(void) { return ui.proj_cur < 0 || ui.work_sig != ui.proj_sig; }
static void ui_proj_do(int op)                       /* 1 save, 2 load, 3 clear */
{
    int rcs, s = ui.proj_sel, ask = ui.proj_ask == op && ui.proj_msg_at && ui.now - ui.proj_msg_at < 3000u;
    ui.proj_ask = 0;
    if (ju_seq_run || ju_seq_rec) { ui_proj_msg("STOP THE SEQUENCER FIRST"); return; }
    if (op == 1) {
        if (ju_projinfo[s].valid && s != ui.proj_cur && !ask) { ui.proj_ask = 1; ui_proj_msg("OCT+ AGAIN: OVERWRITE THIS SLOT"); return; }
        ju_proj_pidx[0] = (uint8_t)ui.patch_idx[0]; ju_proj_pidx[1] = (uint8_t)ui.patch_idx[1];
        rcs = ju_proj_flash_save(s);
        if (rcs == 0) { ui.proj_cur = (int8_t)s; ui.proj_sig = ui.work_sig = ju_proj_sig(); ju_store_current(); ui_proj_msg("SAVED"); }
        else ui_proj_msg(rcs == -2 ? "PROJECT TOO BIG FOR A SLOT" : "SAVE FAILED");
    } else if (op == 2) {
        if (!ju_projinfo[s].valid) { ui_proj_msg("THIS SLOT IS EMPTY"); return; }
        if (ui_proj_modified() && !ask) { ui.proj_ask = 2; ui_proj_msg("UNSAVED WORK: OCT- AGAIN TO LOAD"); return; }
        if (ju_proj_flash_load(s) == 0) {
            ui.patch_idx[0] = ju_proj_pidx[0]; ui.patch_idx[1] = ju_proj_pidx[1];
            ui.proj_cur = (int8_t)s; ui.sig_pend = 1; ju_panic_req = 1;
            memcpy(ui.saved_global, ju_global, G_COUNT);
            ui.save_at = ui.now + 2000u;
            ui_proj_msg("LOADED");
        } else ui_proj_msg("LOAD FAILED");
    } else {
        if (!ju_projinfo[s].valid) { ui_proj_msg("THIS SLOT IS EMPTY"); return; }
        if (!ask) { ui.proj_ask = 3; ui_proj_msg("SCL AGAIN: CLEAR THIS SLOT"); return; }
        if (ju_proj_flash_clear(s) == 0) { if (s == ui.proj_cur) ui.proj_cur = -1; ui_proj_msg("CLEARED"); }
        else ui_proj_msg("CLEAR FAILED");
    }
}
/* every 250 ms: the working copy's signature (a change schedules the autosave); after a load, the project's own */
static void ui_proj_track(uint32_t now)
{
    if (ui.sig_pend) {
        if (ju_patch_stage_req) return;                 /* the engine has not taken the sounds yet */
        ui.sig_pend = 0; ui.proj_sig = ui.work_sig = ju_proj_sig(); ui.sig_at = now;
        return;
    }
    if (now - ui.sig_at < 250u) return;
    ui.sig_at = now;
    {
        uint32_t h = ju_proj_sig();
        if (h != ui.work_sig) { ui.work_sig = h; if (!ui.save_at) ui.save_at = now + 2000u; }
    }
}

/* one UI frame of input */
static void ui_update(const ju_in_t *in, uint32_t now)
{
    int i, l = ui_layer();
    ui.now = now;

    if (in->press & BTN(B_HOME)) { if (ui.page == PAGE_QLINK) ui_group_to(ui.qgroup + 1); else { ui.page = PAGE_QLINK; ui.write_mode = 0; } }
    if (in->press & BTN(B_EDIT)) {
        if (ui.page == PAGE_SEQ && !ui.seq_sub) ju_seq_op = 1;                              /* the sequencer's undo: the last recorded change */
        else { if (ui.page == PAGE_PANEL) ui_jump_section(1); ui.page = PAGE_PANEL; ui.write_mode = 0; }
    }
    if (in->press & BTN(B_GLO)) { if (ui.page == PAGE_PERF) ui_jump_section(1); ui.page = PAGE_PERF; ui.write_mode = 0; }
    if (in->press & BTN(B_FX)) { if (ui.page == PAGE_FX) ui_jump_section(1); ui.page = PAGE_FX; ui.write_mode = 0; }
    if (in->press & BTN(B_SAVE)) { ui.page = ui.page == PAGE_PATCH ? PAGE_PROJ : PAGE_PATCH; ui.write_mode = 0; ui.proj_ask = 0; }
    if (in->press & BTN(B_ENV)) ui_group_to(ui.page == PAGE_QLINK && ui.qgroup == 2 ? 3 : 2);
    if (in->press & BTN(B_LFO)) ui_group_to(5);
    if (in->press & BTN(B_SEQ)) { if (ui.page == PAGE_SEQ) ui.seq_sub = kSeqNext[ui.seq_sub % 6]; else { ui.page = PAGE_SEQ; ui.seq_sub = 0; } ui.write_mode = 0; }
    if ((in->press & BTN(B_SCL)) && ui.page == PAGE_PROJ) ui_proj_do(3);
    else if ((in->press & BTN(B_SCL)) && ui.page != PAGE_SEQ) ui_group_to(7);          /* (on the SEQ page SCL clears a step) */
    if (in->press & BTN(B_ARP)) { ju_global[G_ARP_ON] ^= 1; ui.save_at = now + 2000u; }
    /* PLAY: a tap starts / stops the sequencer, held for 0.6 s it is all notes off */
    if (in->press & BTN(B_PLAY)) { ui.play_down_at = now ? now : 1u; ui.panic_done = 0; }
    if ((in->held & BTN(B_PLAY)) && ui.play_down_at && !ui.panic_done && now - ui.play_down_at >= 600u) {
        ju_panic_req = 1; ju_seq_req = 2; ui.panic_done = 1;
    }
    if ((in->released & BTN(B_PLAY)) && ui.play_down_at) {
        if (!ui.panic_done) ju_seq_req = ju_seq_run ? 2 : 1;
        ui.play_down_at = 0;
    }
    /* REC: tapped, it arms recording; used with a knob (the dial restore) it does not */
    if (in->press & BTN(B_REC)) ui.rec_used = 0;
    if ((in->released & BTN(B_REC)) && !ui.rec_used) ju_seq_rec ^= 1;
    if (ui.page == PAGE_SEQ && ui.seq_sub == 2) {
        if (in->press & BTN(B_OCTUP)) ui_song_insert();                       /* a copy of the row, before it */
        if (in->press & BTN(B_OCTDN)) { ju_global[G_SONG] ^= 1; ui.save_at = now + 2000u; }          /* song mode on / off */
    } else if (ui.page == PAGE_SEQ && ui.seq_sub == 1) {
        if (in->press & BTN(B_OCTDN)) {                  /* OCT- twice within two seconds: the pattern is cleared */
            if (ui.clear_at && now - ui.clear_at < 2000u) { ui_seq_clear(); ui.clear_at = 0; } else ui.clear_at = now ? now : 1u;
        }
        if (ui.clear_at && now - ui.clear_at >= 2000u) ui.clear_at = 0;
    } else if (ui.page == PAGE_SEQ && ui.seq_sub >= 3) {
        /* the step pages and the tools: OCT+ is the tools' (handled with their knobs), OCT- does nothing here */
    } else if (ui.page == PAGE_PROJ) {
        if (in->press & BTN(B_OCTUP)) ui_proj_do(1);                          /* save into the slot */
        if (in->press & BTN(B_OCTDN)) ui_proj_do(2);                          /* load the slot */
    } else if (ui.page == PAGE_PATCH) {
        if (in->press & BTN(B_OCTUP)) ui_activate();
        if (in->press & BTN(B_OCTDN)) ui.write_mode = 0;
    } else {
        if (in->press & BTN(B_OCTUP)) { if (ju_octave < 3) ju_octave++; }
        if (in->press & BTN(B_OCTDN)) { if (ju_octave > -3) ju_octave--; }
        if ((in->held & BTN(B_OCTUP)) && (in->held & BTN(B_OCTDN))) ju_octave = 0;
    }

    if (in->sel) ui_group_to(ui.qgroup + (in->sel > 0 ? 1 : -1));
    if (in->algo) ju_global[G_PANEL] ^= 1;
    if (in->preset) ui_load_patch(l, (ui.patch_idx[l] + (in->preset > 0 ? 1 : 63)) % 64);

    if (ui.page == PAGE_QLINK) {
        for (i = 0; i < 4; i++) {
            if (!in->knob[i]) continue;
            ui.overview = 0;                           /* back to the dials; the move still counts */
            if (in->held & BTN(B_REC)) { q_restore(i, now); ui.rec_used = 1; }
            else q_turn(i, in->knob[i], now);
        }
    } else if (ui.page == PAGE_SEQ) {
        ui_seq_input(in, now);
    } else if (ui.page == PAGE_PROJ) {
        if (in->knob[0]) { int v = ui.proj_sel + in->knob[0]; ui.proj_sel = (uint8_t)(v < 0 ? 0 : v >= JU_NPROJ ? JU_NPROJ - 1 : v); ui.proj_ask = 0; }
    } else {
        ui.turning_enc = 1;
        if (in->knob[0]) ui_move_focus(in->knob[0]);
        if (ui.page == PAGE_PATCH) {
            if (in->knob[1]) ui_move_focus(in->knob[1] > 0 ? 8 : -8);
        } else if (in->knob[1]) {
            if (ui.page == PAGE_FX) ui_adjust_fx(ui.focus[PAGE_FX], in->knob[1], now);
            else ui_adjust(ui_focus_param(), in->knob[1], now);
        }
        if (in->knob[2]) ui_jump_section(in->knob[2]);
        if (in->knob[3]) ui_load_patch(l, (ui.patch_idx[l] + (in->knob[3] > 0 ? 1 : 63)) % 64);
    }
    if (ui.page == PAGE_SEQ) ui_seq_view();
    ui_proj_track(now);
    if (ui.overview && now - ui.overview_at >= OVERVIEW_MS) ui.overview = 0;

    if ((ju_seq_dirty[0] || ju_seq_dirty[1] || ju_song_dirty) && !ui.seq_save_at) ui.seq_save_at = now + 2000u;
    /* A flash write stalls the audio and the LEDs for tens of milliseconds, so every autosave waits for a quiet moment: nothing
     * sounding, the sequencer stopped and not recording, and 1.5 s since the last of those (a gap between two notes is not quiet). */
    {
        int busy = ju_seq_run || ju_seq_rec;
        for (i = 0; i < JU_NV && !busy; i++) busy = ju_voice_level(i) != 0;
        if (busy) ui.busy_at = now ? now : 1u;
        if (ju_global[G_AUTOSAVE] != ui.auto_seen) { ui.auto_chg = ui.auto_seen != 2; ui.auto_seen = ju_global[G_AUTOSAVE]; }
        if (!busy && now - ui.busy_at >= 1500u) {
            if (ui.auto_chg) {                           /* the option itself is kept, off or on */
                ui.auto_chg = 0; ui.save_at = 0;
                memcpy(ui.saved_global, ju_global, G_COUNT);
                ju_store_current();
            } else if (!ju_global[G_AUTOSAVE]) {
                /* autosave off: patterns, song and sounds are only kept by SAVE (patches, projects) */
            } else if (ui.seq_save_at && (int32_t)(now - ui.seq_save_at) > 0) {
                int part;
                ui.seq_save_at = 0; ui.save_at = 0;
                for (part = 0; part < 2; part++) if (ju_seq_dirty[part]) { ju_seq_dirty[part] = 0; (void)ju_store_seq(part); }
                if (ju_song_dirty) { ju_song_dirty = 0; (void)ju_store_song(); }
                memcpy(ui.saved_global, ju_global, G_COUNT);
                ju_store_current();
            } else if (ui.save_at && (int32_t)(now - ui.save_at) > 0) {
                ui.save_at = 0;
                memcpy(ui.saved_global, ju_global, G_COUNT);
                ju_store_current();
            }
        }
    }
}

/* ------------------------------------------------------------------ drawing */
static void d_header(void)
{
    int lay = ui_layer(), pi = ui.patch_idx[lay], i;
    char buf[16];
    cv_rect(0, 0, CV_W, 22, K_BG);
    cv_text(4, 4, "JUPITER", K_TEXT, 2);
    cv_text(88, 4, "-8", K_RED, 2);
    /* patch LEDs: bank and number, 11-88 */
    cv_rect(118, 1, 53, 21, CV_RGB(24, 4, 4));
    cv_seg7(122, 2, lay ? 'L' : 'U', K_LEDON, CV_RGB(36, 8, 6));
    cv_seg7(141, 2, (char)('1' + pi / 8), K_LEDON, CV_RGB(36, 8, 6));
    cv_seg7(156, 2, (char)('1' + pi % 8), K_LEDON, CV_RGB(36, 8, 6));
    /* voice LEDs, brightness from ENV-2 */
    for (i = 0; i < JU_NV; i++) {
        int32_t lv = ju_voice_level(i) >> 22;            /* 0..256 */
        int r = 40 + (lv > 255 ? 215 : lv * 215 / 255);
        cv_rect(174 + i * 8, 2, 6, 5, cv_rgb((uint32_t)r, (uint32_t)(r / 6), (uint32_t)(r / 8)));
    }
    buf[0] = 0;
    ui_strcat(buf, sizeof buf, "CPU ");
    ui_num(buf, sizeof buf, ui.cpu);
    cv_text(174, 12, buf, ui.cpu > 85 ? K_RED : K_DIM, 1);
    if (ju_seq_count_beats_left()) { char cb[8]; cb[0] = 0; ui_strcat(cb, sizeof cb, "IN "); ui_num(cb, sizeof cb, ju_seq_count_beats_left()); cv_text(214, 12, cb, K_RED, 1); }
    else if (ju_seq_rec) cv_text(214, 12, "REC", K_RED, 1);
    else if (ju_song_playing()) { char sb[8]; sb[0] = 0; ui_strcat(sb, sizeof sb, "SNG"); ui_num(sb, sizeof sb, ju_song_row + 1); cv_text(214, 12, sb, K_FOCUS, 1); }
    else if (ju_seq_run) cv_text(214, 12, "PLAY", K_FOCUS, 1);
    else if (ju_global[G_ARP_ON]) cv_text(214, 12, "ARP", K_YELLOW, 1);
    cv_rect(0, 22, CV_W, 1, K_LINE);
}

/* One control, large: a slider with a long track, or a selector with its values stacked, or a window for a long list. Names
 * and values at twice the normal size when they fit. (x, y, w, h) is the control's area. */
static void d_control(int id, int x, int y, int w, int h, int foc)
{
    int steps = ju_psteps(id), v = ui_get(id), nameS = 2;
    const char *nm = ju_pshort(id);
    const int labelH = 18;
    int top = y + 4, bot = y + h - labelH - 2;
    uint16_t ink = foc ? K_FOCUS : K_TEXT;
    if (foc) cv_rect(x + 1, y, w - 2, h, K_FOCBG);
    if (cv_text_w(nm, 2) > w - 2) nameS = 1;
    cv_text(x + (w - cv_text_w(nm, nameS)) / 2, y + h - (nameS == 2 ? 15 : 11), nm, ink, nameS);
    if (steps == 0) {                                   /* a slider: a track with its scale and a pale cap */
        int cx = x + w / 2, H = bot - top, t, fy, cw = w - 14 > 32 ? 32 : w - 14;
        cv_rect(cx - 1, top, 3, H, K_LINE);
        for (t = 0; t <= 10; t++) cv_rect(cx - 6, top + (H - 1) * t / 10, t % 5 ? 5 : 11, 1, CV_RGB(60, 60, 66));
        fy = bot - 8 - (H - 8) * v / 255;
        cv_rect(cx - cw / 2, fy, cw, 9, foc ? K_FOCUS : K_CREAM);
        cv_rect(cx - cw / 2, fy + 4, cw, 1, K_BG);
    } else if (steps > 6) {                             /* a MIDI channel: the current one in a window */
        const char *lab = ju_plabel(id, v < steps ? v : 0);
        int boxY = top + (bot - top) / 2 - 14, s2 = cv_text_w(lab, 2) <= w - 6 ? 2 : 1;
        cv_frame(x + 3, boxY, w - 6, 28, foc ? K_FOCUS : K_LINE);
        cv_text(x + (w - cv_text_w(lab, s2)) / 2, boxY + (s2 == 2 ? 7 : 10), lab, foc ? K_FOCUS : K_LEDON, s2);
    } else {                                            /* a selector: the values stacked, an LED beside the active one */
        int n = steps, rowH = (bot - top) / n, yy = top, i, s2 = 2;
        if (rowH > 30) rowH = 30;
        if (rowH < 15) s2 = 1;
        for (i = 0; i < n; i++) {                       /* the last value on top, as a switch reads (the first at the bottom) */
            int val = n - 1 - i, on = v == val;
            const char *lb = ju_plabel(id, val);
            int ls = (s2 == 2 && cv_text_w(lb, 2) + 12 <= w) ? 2 : 1;
            cv_rect(x + 3, yy + rowH / 2 - 3, 4, 7, on ? K_LEDON : K_LEDOFF);
            cv_text(x + 10, yy + (rowH - 7 * ls) / 2, lb, on ? ink : K_DIM, ls);
            yy += rowH;
        }
    }
}

/* a page of the EDIT or GLO series: a title bar with a dot for each page, and its controls across the width */
static void d_spage(int page)
{
    int np, k, pg = sp_locate(page, ui.focus[page], &k), i;
    const spage_t *t = sp_tab(page, &np), *p;
    p = &t[pg];
    cv_rect(0, 24, CV_W, 20, p->color);
    cv_text(6, 27, p->title, K_BG, 2);
    for (i = 0; i < np; i++) {                          /* where this page is among the others */
        int x = CV_W - 6 - (np - i) * 10;
        cv_rect(x, 30, 8, 8, i == pg ? K_BG : p->color);
        cv_frame(x, 30, 8, 8, K_BG);
    }
    if (!cv_sees(46, 152)) return;
    for (i = 0; i < p->n; i++) {
        int x0 = i * CV_W / p->n, x1 = (i + 1) * CV_W / p->n;
        d_control(p->ids[i], x0, 46, x1 - x0, 152, i == k);
    }
}
static void d_panel(void) { d_spage(PAGE_PANEL); }
static void d_perf(void) { d_spage(PAGE_PERF); }

static void d_patches(void)
{
    static const uint16_t cols[8] = {K_RED, K_RED, K_ORANGE, K_ORANGE, K_YELLOW, K_YELLOW, K_CREAM, K_BLUE};
    const int ox = 12, oy = 31, cw = 26, ch = 14;
    int i, cur = ui.patch_idx[ui_layer()], f = ui.focus[PAGE_PATCH];
    const ju_patch_t *hp = &ju_bank[f < 64 ? f : cur];
    for (i = 1; i <= 8; i++) {
        char b[2];
        b[0] = (char)('0' + i); b[1] = 0;
        cv_text(ox + 11 + (i - 1) * (cw + 1), 25, b, K_DIM, 1);
    }
    for (i = 0; i < 64; i++) {
        int bank = i / 8, num = i % 8, x = ox + num * (cw + 1), y = oy + bank * (ch + 1);
        char t[3];
        if (!cv_sees(y - 1, ch + 2)) continue;
        cv_rect(x, y, cw, ch, i == cur ? cols[num] : K_PANEL);
        cv_rect(x, y + ch - 2, cw, 2, cols[num]);
        t[0] = (char)('1' + bank); t[1] = (char)('1' + num); t[2] = 0;
        cv_text(x + 7, y + 3, t, i == cur ? K_BG : K_TEXT, 1);
        if (i == f) { cv_frame(x - 1, y - 1, cw + 2, ch + 2, K_FOCUS); cv_frame(x, y, cw, ch, K_FOCUS); }
    }
    cv_text(6, 158, hp->name, K_TEXT, 2);
    cv_text(6, 178, ui.write_mode ? "PICK A SLOT" : "OCT+ LOADS", ui.write_mode ? K_RED : K_DIM, 1);
    cv_text(6, 186, ui.write_mode ? "OCT+ WRITES  OCT- CANCELS" : "KNOB 1/2 MOVE", ui.write_mode ? K_RED : K_DIM, 1);
    cv_rect(160, 168, 70, 24, f == 64 ? K_FOCUS : (ui.write_mode ? K_RED : K_PANEL));
    cv_frame(160, 168, 70, 24, K_RED);
    cv_text(180, 177, "WRITE", f == 64 ? K_BG : K_TEXT, 1);
}

static void d_proj(void)
{
    int i;
    for (i = 0; i < JU_NPROJ; i++) {
        const ju_projinfo_t *pi = &ju_projinfo[i];
        int y = 26 + i * 18, open = i == ui.proj_cur, sel = i == ui.proj_sel;
        char t[4], b[28];
        if (!cv_sees(y - 1, 19)) continue;
        cv_rect(0, y, CV_W, 17, sel ? K_FOCBG : K_PANEL);
        if (sel) cv_frame(0, y, CV_W, 17, K_FOCUS);
        t[0] = 'P'; t[1] = (char)('0' + (i + 1) / 10); t[2] = (char)('0' + (i + 1) % 10); t[3] = 0;
        cv_text(6, y + 1, t, open ? K_LEDON : K_TEXT, 2);
        if (pi->valid) {
            b[0] = 0; ui_strcat(b, sizeof b, pi->n0); ui_strcat(b, sizeof b, " / "); ui_strcat(b, sizeof b, pi->n1);
            cv_text(44, y + 5, b, K_TEXT, 1);
            b[0] = 0; ui_num(b, sizeof b, 40 + pi->tempo);
            cv_text(CV_W - cv_text_w(b, 1) - 22, y + 5, b, K_DIM, 1);
        } else cv_text(44, y + 5, "EMPTY", K_DIM, 1);
        if (open) cv_text(CV_W - 14, y + 1, ui_proj_modified() ? "*" : " ", K_ORANGE, 2);
    }
}

static void d_fx(void)
{
    ju_fxpatch_t *f = &ju_patch[0].fx;
    fxrow_t rows[FX_MAXROWS];
    int starts[FX_MAXPAGES + 1];
    int n = fx_rows(f, rows), np = fx_paginate(rows, n, starts), fo = ui.focus[PAGE_FX], pg, k, i, g;
    const uint8_t on[4] = {f->mfxOn, f->dlyOn, f->revOn, 1};
    static const char *const title[4] = {"CHORUS", "DELAY", "REVERB", "TEMPO"};
    char val[24];
    if (fo >= n) fo = n - 1;
    pg = fx_page_of(starts, np, fo);
    g = rows[starts[pg]].group;
    cv_rect(0, 24, CV_W, 20, on[g] ? kFxCols[g] : K_PANEL);      /* the bar is lit while that effect is on */
    cv_text(6, 27, title[g], on[g] ? K_BG : K_DIM, 2);
    for (i = 0; i < np; i++) {                           /* a dot a page; the bar's own colour marks the others of this section */
        int x = CV_W - 4 - (np - i) * 9;
        cv_rect(x, 30, 7, 8, i == pg ? K_BG : (rows[starts[i]].group == g ? K_DIM : K_LINE));
        if (i == pg) cv_frame(x, 30, 7, 8, K_TEXT);
    }
    if (!cv_sees(46, 152)) return;
    for (k = starts[pg]; k < starts[pg + 1]; k++) {
        const fxrow_t *r = &rows[k];
        int y = 46 + (k - starts[pg]) * 30, foc = k == fo, cur = 0, lo = 0, hi = 1, nw, vw, vs = 2, ns;
        const char *name = "";
        cv_rect(0, y, CV_W, 29, foc ? K_FOCBG : K_PANEL);
        cv_rect(0, y, 3, 29, kFxCols[r->group]);
        val[0] = 0;
        switch (r->kind) {
        case 0: name = "SWITCH"; cur = on[r->idx]; ui_strcat(val, sizeof val, cur ? "ON" : "OFF"); break;
        case 1: name = "TYPE"; cur = f->mfxType; hi = MFX_COUNT - 1; ui_strcat(val, sizeof val, ju_mfx_name(f->mfxType)); break;
        case 3: name = "BPM"; cur = ju_global[G_TEMPO]; hi = 255; ui_num(val, sizeof val, 40 + cur); break;
        default: {
            const ju_fxparam_t *d = fx_row_def(f, r);
            name = d->name; cur = *fx_row_val(f, r); lo = d->lo; hi = d->hi;
            ju_fx_format(d, cur, val, sizeof val);
            break;
        }
        }
        nw = cv_text_w(name, 2);
        vw = cv_text_w(val, 2);
        ns = 2;
        if (8 + nw + 10 + vw > CV_W - 6) {                 /* too wide: the label small first, then the value small */
            ns = 1;
            if (8 + cv_text_w(name, 1) + 10 + vw > CV_W - 6) vs = 1;
        }
        cv_text(8, y + (ns == 2 ? 7 : 11), name, foc ? K_FOCUS : K_TEXT, ns);
        cv_text(CV_W - 6 - cv_text_w(val, vs), y + (vs == 2 ? 7 : 11), val, foc ? K_FOCUS : K_TEXT, vs);
        if (r->kind == 2 && hi > lo) cv_rect(8, y + 25, (cur - lo) * (CV_W - 16) / (hi - lo), 2, kFxCols[r->group]);
    }
}

/* all groups, one row each, with a square around the group the knobs control */
static void d_overview(void)
{
    const int y0 = 24, rowH = 19, nameW = 64, colW = (CV_W - nameW - 4) / 4;
    int r, i, y;
    for (r = 0; r < NQ; r++) {
        const qgroup_t *g = &kQ[r];
        int yy = y0 + r * rowH, ty = yy + 6, on = r == ui.qgroup;
        if (on) cv_rect(2, yy, CV_W - 4, rowH, K_PANEL);
        cv_rect(5, yy + 4, 3, rowH - 8, g->color);
        cv_text(11, ty, g->name, on ? K_TEXT : K_DIM, 1);
        for (i = 0; i < 4; i++) cv_text(nameW + i * colW + 2, ty, g->d[i].name, on ? K_TEXT : K_DIM, 1);
    }
    y = y0 + ui.qgroup * rowH;
    cv_frame(2, y, CV_W - 4, rowH, K_FOCUS);
    cv_frame(3, y + 1, CV_W - 6, rowH - 2, K_FOCUS);
    cv_rect(0, 176, CV_W, 1, K_LINE);
}

static void d_qlink(void)
{
    const qgroup_t *g = &kQ[ui.qgroup];
    int i, k;
    char val[24];
    int fresh = ui.now - ui.last_dial_at < 1200u;
    if (ui.overview) { d_overview(); return; }
    cv_rect(0, 24, CV_W, 26, K_PANEL);                  /* group bar: its name, and one lit tab per group */
    cv_rect(0, 24, 4, 26, g->color);
    cv_text(10, 31, g->name, K_TEXT, 2);
    for (i = 0; i < NQ; i++) {
        int x = CV_W - 8 - (NQ - i) * 15, on = i == ui.qgroup;
        cv_rect(x, 31, 12, 12, on ? kQ[i].color : K_BG);
        cv_frame(x, 31, 12, 12, on ? kQ[i].color : K_LINE);
    }
    for (i = 0; i < 4; i++) {                           /* four dials, in the order of the knobs below the screen */
        const int w = CV_W / 4, x0 = i * w, cx = x0 + w / 2, cy = 102, rad = 24;
        const int active = fresh && ui.last_dial == i;
        const dial_t *d = &g->d[i];
        int nw = cv_text_w(d->name, 1), lit = (q_norm(i) * 32 + 500) / 1000, vw, kk;
        if (active) cv_rect(x0 + 1, 52, w - 2, 124, K_FOCBG);
        cv_text(cx - nw / 2, 56, d->name, active ? K_FOCUS : K_TEXT, 1);
        for (k = 0; k < 33; k++) {                      /* 270 degrees of dots, 7 o'clock to 5 o'clock */
            int px = cx + (kCos[k] * rad) / 256, py = cy + (kSin[k] * rad) / 256, on = k <= lit, sz = on ? 3 : 2;
            cv_rect(px - sz / 2, py - sz / 2, sz, sz, on ? (active ? K_FOCUS : g->color) : K_LINE);
        }
        kk = lit > 32 ? 32 : lit;                       /* the pointer */
        for (k = 7; k < 19; k++) cv_rect(cx + (kCos[kk] * k) / 256 - 1, cy + (kSin[kk] * k) / 256 - 1, 2, 2, K_TEXT);
        q_format(i, val, sizeof val);
        vw = cv_text_w(val, 1);
        if (cv_text_w(val, 2) <= w - 2) cv_text(cx - cv_text_w(val, 2) / 2, 144, val, active ? K_FOCUS : K_TEXT, 2);
        else cv_text(cx - vw / 2, 148, val, active ? K_FOCUS : K_TEXT, 1);
        if (q_edited(i)) cv_rect(cx - 2, 162, 5, 3, K_LEDON);   /* a small mark: differs from the saved patch */
    }
    cv_rect(0, 176, CV_W, 1, K_LINE);
}

static void d_readout(void)
{
    const int y = 200;
    int id = ui_focus_param(), lay = ui_layer();
    char val[24], line[40];
    if (ui.page == PAGE_QLINK) {
        const int yy = 178;
        cv_rect(0, yy, CV_W, CV_H - yy, K_BG);
        line[0] = 0;
        ui_strcat(line, sizeof line, "PART ");
        ui_num(line, sizeof line, lay + 1);
        ui_strcat(line, sizeof line, "  CH ");
        ui_strcat(line, sizeof line, ju_plabel(P_COUNT + G_CH_U, ju_global[lay ? G_CH_L : G_CH_U] % 17));
        cv_text(6, yy + 4, line, K_DIM, 1);
        cv_text(6, yy + 14, ju_bank[ui.patch_idx[lay]].name, K_TEXT, 2);
        if (ui.now - ui.last_dial_at < 1200u && ui.last_dial >= 0) {
            const char *ln = kQ[ui.qgroup].d[ui.last_dial].longName;
            q_format(ui.last_dial, val, sizeof val);
            cv_text(CV_W - cv_text_w_1(ln) - 6, yy + 4, ln, K_DIM, 1);
            cv_text(CV_W - cv_text_w(val, 2) - 6, yy + 22, val, K_FOCUS, 2);
        }
        cv_text(6, yy + 40, "SELECT GROUP  ALGO PART  PRESETS PATCH", K_DIM, 1);
        cv_text(6, yy + 48, "REC + KNOB: SAVED VALUE", K_DIM, 1);
        return;
    }
    cv_rect(0, y, CV_W, CV_H - y, K_BG);
    cv_rect(0, y, CV_W, 1, K_LINE);
    if (ui.page == PAGE_FX) {
        ju_fxpatch_t *f = &ju_patch[0].fx;
        fxrow_t rows[FX_MAXROWS];
        int n = fx_rows(f, rows), fo = ui.focus[PAGE_FX], vw;
        const fxrow_t *r;
        const char *pname;
        char title[32];
        if (fo >= n) fo = n - 1;
        r = &rows[fo];
        pname = r->kind == 0 ? "SWITCH" : r->kind == 1 ? "EFFECT TYPE" : r->kind == 3 ? "BPM" : fx_row_def(f, r)->name;
        title[0] = 0;
        ui_strcat(title, sizeof title, kFxGroups[r->group]);
        ui_strcat(title, sizeof title, " ");
        ui_strcat(title, sizeof title, pname);
        val[0] = 0;
        if (r->kind == 2) ju_fx_format(fx_row_def(f, r), *fx_row_val(f, r), val, sizeof val);
        else if (r->kind == 1) ui_strcat(val, sizeof val, ju_mfx_name(f->mfxType));
        else if (r->kind == 3) { ui_num(val, sizeof val, 40 + ju_global[G_TEMPO]); ui_strcat(val, sizeof val, " BPM"); }
        else ui_strcat(val, sizeof val, (r->idx == 0 ? f->mfxOn : r->idx == 1 ? f->dlyOn : f->revOn) ? "ON" : "OFF");
        cv_text(6, y + 5, title, K_DIM, 1);
        vw = cv_text_w(val, 2);
        if (vw > CV_W - 12) cv_text(CV_W - cv_text_w(val, 1) - 6, y + 18, val, K_FOCUS, 1);
        else cv_text(CV_W - vw - 6, y + 16, val, K_FOCUS, 2);
        cv_text(6, y + 30, "SAVED WITH THE PATCH", K_DIM, 1);
        return;
    }
    if (ui.page == PAGE_SEQ) {
        if (ui.seq_sub == 2) {
            cv_text(6, y + 6, "1 ROW  2 UPPER  3 LOWER  4 REPEAT", K_DIM, 1);
            cv_text(6, y + 18, "SCL DELETE  OCT+ INSERT  OCT- ON/OFF", K_DIM, 1);
            cv_text(6, y + 30, ju_global[G_SONG] ? "SEQ AGAIN: THE ROLL" : "SONG IS OFF: OCT- TURNS IT ON", ju_global[G_SONG] ? K_DIM : K_RED, 1);
            return;
        }
        if (ui.seq_sub == 5) {
            int msg = ui.proj_msg && ui.proj_msg_at && ui.now - ui.proj_msg_at < 3000u;
            cv_text(6, y + 6, msg ? ui.proj_msg : "OCT+ DOES THE TOOL UNDER THE CURSOR", msg ? K_RED : K_DIM, 1);
            cv_text(6, y + 18, "KNOB 1 TOOL  KNOB 2 AMOUNT", K_DIM, 1);
            cv_text(6, y + 30, "SEQ AGAIN: THE ROLL", K_DIM, 1);
            return;
        }
        if (ui.seq_sub >= 3) {
            cv_text(6, y + 6, ui.seq_sub == 3 ? "2 VELOCITY  3 PROBABILITY  4 RATCHET" : "2 CHORD  3 LANE  4 LANE VALUE", K_DIM, 1);
            cv_text(6, y + 18, ui.seq_sub == 3 ? "1 MOVES THE STEP  SCL ERASES IT" : "REC + KEYS HELD TOGETHER: A CHORD", K_DIM, 1);
            cv_text(6, y + 30, "SEQ AGAIN: THE NEXT PAGE", K_DIM, 1);
            return;
        }
        if (ui.seq_sub) {
            cv_text(6, y + 6, ui.clear_at ? "PRESS OCT- AGAIN TO CLEAR THE PATTERN" : "THE FOUR KNOBS SET THE FOUR VALUES", ui.clear_at ? K_RED : K_DIM, 1);
            cv_text(6, y + 18, "OCT- TWICE CLEARS THE PATTERN", K_DIM, 1);
            cv_text(6, y + 30, "SEQ AGAIN: THE ROLL", K_DIM, 1);
            return;
        }
        {
            char u[40];
            cv_text(6, y + 6, ju_seq_count_beats_left() ? "COUNTING IN: GET READY" : ju_seq_rec ? (ju_seq_run ? "REC: PLAY THE KEYS, THEY ARE WRITTEN" : (ju_global[G_COUNTIN] ? "REC: PLAY STARTS AFTER THE COUNT-IN" : "REC: EACH KEY WRITES THE STEP")) : "REC ARMS RECORDING",
                    ju_seq_rec ? K_RED : K_DIM, 1);
            cv_text(6, y + 18, "1 STEP  2 PITCH  3 LENGTH  4 PATTERN", K_DIM, 1);
            u[0] = 0; ui_strcat(u, sizeof u, "EDIT UNDO ("); ui_num(u, sizeof u, ju_seq_undo_count()); ui_strcat(u, sizeof u, ")  SCL ERASE  SEQ SETUP");
            cv_text(6, y + 30, u, K_DIM, 1);
        }
        return;
    }
    if (ui.page == PAGE_PROJ) {
        int msg = ui.proj_msg && ui.proj_msg_at && ui.now - ui.proj_msg_at < 3000u;
        line[0] = 0;
        if (ui.proj_cur < 0) ui_strcat(line, sizeof line, "NO PROJECT OPEN: WORKING COPY");
        else {
            ui_strcat(line, sizeof line, "OPEN: P"); ui_num(line, sizeof line, ui.proj_cur + 1);
            ui_strcat(line, sizeof line, ui_proj_modified() ? "  CHANGED (*)" : "  UNCHANGED");
        }
        cv_text(6, y + 6, msg ? ui.proj_msg : line, msg ? K_RED : K_TEXT, 1);
        cv_text(6, y + 18, "KNOB 1 SLOT  OCT+ SAVE  OCT- LOAD", K_DIM, 1);
        cv_text(6, y + 30, "SCL CLEAR  SAVE: PATCHES", K_DIM, 1);
        return;
    }
    if (ui.page == PAGE_PATCH) {
        const ju_patch_t *p = &ju_patch[lay];
        cv_text(6, y + 6, p->name, K_TEXT, 2);
        line[0] = 0;
        ui_strcat(line, sizeof line, lay ? "PART 2 LOWER" : "PART 1 UPPER");
        ui_strcat(line, sizeof line, "  MIDI CH ");
        ui_strcat(line, sizeof line, ju_plabel(P_COUNT + G_CH_U, ju_global[lay ? G_CH_L : G_CH_U] % 17));
        cv_text(6, y + 26, line, K_DIM, 1);
        return;
    }
    if (id < 0) return;
    ju_format_param(id, ui_get(id), val, sizeof val);
    cv_text(6, y + 5, ju_plong(id), K_DIM, 1);
    cv_text(CV_W - cv_text_w(val, 2) - 6, y + 14, val, K_FOCUS, 2);
    cv_text(6, y + 20, ju_bank[ui.patch_idx[lay]].name, K_DIM, 1);
    cv_text(6, y + 30, "KNOB 1 MOVE  KNOB 2 VALUE  HOME DIALS", K_DIM, 1);
}

/* ---- the sequencer: the steps of a part's pattern, 16 at a time (4 x 4 at double size), and a setup page */
/* The sequencer as a piano roll (after Sloop's STEP page): pitch up, the steps along, a note a bar as long as it lasts. */
#define RL_X0 20                                            /* the keyboard strip ends here */
#define RL_Y0 60
#define RL_RH 6
#define RL_Y1 (RL_Y0 + ROLL_ROWS * RL_RH)                   /* 192 */
static int roll_x(int i) { return RL_X0 + i * (CV_W - RL_X0) / 16; }
static int roll_y(int note, int lo) { return RL_Y0 + (ROLL_ROWS - 1 - (note - lo)) * RL_RH; }
static int is_black(int n) { n %= 12; return n == 1 || n == 3 || n == 6 || n == 8 || n == 10; }

static void d_cell(int x, int w, const char *label, const char *val, uint16_t lc, uint16_t vc)
{
    cv_text(x + 4, 28, label, lc, 1);
    cv_text(x + 4, 40, val, vc, 2);
    if (x) cv_rect(x, 26, 1, 30, K_LINE);
}

static void d_seq_roll(int p, const ju_pat_t *t, int len, int cur, uint16_t col)
{
    int lo = ui.seq_lo, base = (cur / 16) * 16, i, r, k, hc = seq_head(t, cur), sw = roll_x(1) - roll_x(0);
    char b[12];
    for (r = 0; r < ROLL_ROWS; r++) {                       /* the rows: white keys lighter, a line under every C */
        int n = lo + ROLL_ROWS - 1 - r, y = RL_Y0 + r * RL_RH;
        cv_rect(RL_X0, y, CV_W - RL_X0, RL_RH, is_black(n) ? CV_RGB(13, 13, 16) : CV_RGB(22, 22, 26));
        cv_rect(0, y, RL_X0 - 1, RL_RH, is_black(n) ? CV_RGB(30, 30, 34) : CV_RGB(190, 186, 172));
        cv_rect(0, y + RL_RH - 1, RL_X0 - 1, 1, CV_RGB(60, 58, 54));
        if (n % 12 == 0) cv_rect(RL_X0, y + RL_RH - 1, CV_W - RL_X0, 1, K_LINE);
    }
    {   /* the cursor's row and column, a crosshair */
        int n = t->note[hc >= 0 ? hc : cur], cx = roll_x(cur - base);
        if (n >= lo && n < lo + ROLL_ROWS) cv_rect(RL_X0, roll_y(n, lo), CV_W - RL_X0, RL_RH, CV_RGB(34, 29, 12));
        cv_rect(cx, RL_Y0, sw, ROLL_ROWS * RL_RH, CV_RGB(34, 29, 12));
    }
    for (i = 4; i < 16; i += 4) cv_rect(roll_x(i), RL_Y0, 1, ROLL_ROWS * RL_RH, CV_RGB(48, 48, 54));    /* the beats */
    if (base + 16 > len) cv_rect(roll_x(len - base), RL_Y0, CV_W - roll_x(len - base), ROLL_ROWS * RL_RH, K_BG);   /* past the end of the pattern */
    for (i = 0; i < len; i++) {                             /* the notes: a bar from its step as far as its ties */
        int n, e, s0, e0, x0, x1, y, h, playing;
        uint16_t c;
        if (t->type[i] != SQ_NOTE) continue;
        n = seq_chain(t, i);
        e = i + n;
        s0 = i < base ? base : i;
        e0 = e > base + 16 ? base + 16 : e;
        if (e0 <= s0) continue;
        x0 = roll_x(s0 - base) + 1;
        x1 = roll_x(e0 - base) - 1;
        if (e == e0) x1 -= sw * (6 - (t->gate < 1 ? 1 : t->gate > 6 ? 6 : t->gate)) / 6;     /* the last step lasts the gate only */
        if (x1 < x0 + 2) x1 = x0 + 2;
        h = RL_RH - 1;
        if (t->note[i] < lo) y = RL_Y1 - 2; else if (t->note[i] >= lo + ROLL_ROWS) y = RL_Y0; else y = roll_y(t->note[i], lo) + 1;
        if (t->note[i] < lo || t->note[i] >= lo + ROLL_ROWS) h = 2;                           /* off the roll: a mark at its edge */
        playing = ju_seq_run && ju_seq_playing_pat(p) == ju_seq_cur[p] && ju_seq_pos[p] >= i && ju_seq_pos[p] < e;
        c = i == hc ? K_FOCUS : (playing ? K_TEXT : col);
        cv_rect(x0, y, x1 - x0, h, c);
        if (i >= base && x1 - x0 > 4) cv_rect(x0, y, 2, h, K_BG);                              /* a notch where it starts */
        if (t->chord[i][0] || t->chord[i][1]) {                                                 /* the rest of the chord */
            int cn[4], nc = ju_chord_notes(t, i, cn), j;
            for (j = 1; j < nc; j++)
                if (cn[j] >= lo && cn[j] < lo + ROLL_ROWS) cv_rect(x0, roll_y(cn[j], lo) + 1, x1 - x0, RL_RH - 1, i == hc ? K_FOCUS : K_DIM);
        }
    }
    if (ju_seq_run && ju_seq_playing_pat(p) == ju_seq_cur[p] && ju_seq_pos[p] >= base && ju_seq_pos[p] < base + 16)      /* the step playing */
        cv_rect(roll_x(ju_seq_pos[p] - base), RL_Y0, 2, ROLL_ROWS * RL_RH, K_LEDON);
    for (r = 0; r < ROLL_ROWS; r++) {                       /* the C labels, last: no row paints over them */
        int n = lo + ROLL_ROWS - 1 - r, y = RL_Y0 + r * RL_RH;
        if (n % 12 == 0 && cv_sees(y - 1, 9)) { b[0] = 0; ui_strcat(b, sizeof b, "C"); ui_num(b, sizeof b, n / 12 - 1); cv_text(2, y - 1, b, K_BG, 1); }
    }
    cv_rect(0, RL_Y1, CV_W, 8, K_BG);                       /* the ruler: a tick a step, longer on the beats, a marker at the cursor */
    for (k = 0; k <= 16; k++) cv_rect(roll_x(k), RL_Y1 + 1, 1, k % 4 ? 2 : 4, K_DIM);
    cv_rect(roll_x(cur - base) + sw / 2 - 2, RL_Y1 + 1, 5, 4, K_FOCUS);
    cv_rect(roll_x(cur - base) + sw / 2 - 1, RL_Y1 + 5, 3, 2, K_FOCUS);
    for (i = base; i < base + 16 && i < len; i++) {            /* under the roll: a mark for a step with a chance below 100 %, a ratchet, a lane value */
        int x = roll_x(i - base) + 1, f = t->flags[i];
        if (t->type[i] == SQ_NOTE && SQF_PROB(f)) cv_rect(x, RL_Y1 + 5, 3, 3, K_RED);
        if (t->type[i] == SQ_NOTE && SQF_RAT(f)) cv_rect(x + 4, RL_Y1 + 5, 3, 3, K_YELLOW);
        if (t->lane && t->lv[i]) cv_rect(x + 8, RL_Y1 + 5, 3, 3, K_BLUE);
    }
}

/* ---- the song page: a list of rows, five at a time at double size */
static void d_song(void)
{
    int n = ju_song.n, cur = ui.song_cur, top, k, last = n < JU_SONG_ROWS ? n : JU_SONG_ROWS - 1;
    char b[12];
    cv_rect(0, 24, CV_W, 20, K_YELLOW);
    cv_text(6, 27, "SONG", K_BG, 2);
    cv_text(CV_W - 6 - cv_text_w(ju_global[G_SONG] ? "ON" : "OFF", 2), 27, ju_global[G_SONG] ? "ON" : "OFF", K_BG, 2);
    if (ju_global[G_SONGLOOP]) cv_text(CV_W - 60 - cv_text_w("LOOP", 1), 31, "LOOP", K_BG, 1);
    cv_text(8, 47, "ROW", K_DIM, 1); cv_text(56, 47, "UPPER", K_ORANGE, 1); cv_text(110, 47, "LOWER", K_BLUE, 1); cv_text(164, 47, "REPEAT", K_DIM, 1);
    if (!cv_sees(56, 140)) return;
    top = cur < 2 ? 0 : cur - 2;
    if (top > last + 1 - 5) top = last + 1 - 5;
    if (top < 0) top = 0;
    for (k = 0; k < 5; k++) {
        int idx = top + k, y = 56 + k * 28, foc = idx == cur, playing = ju_song_playing() && idx == ju_song_row && idx < n;
        if (idx > last) break;
        cv_rect(0, y, CV_W, 27, foc ? K_FOCBG : K_PANEL);
        if (playing) cv_rect(0, y, 4, 27, K_LEDON);
        if (idx >= n) { cv_text(8, y + 7, "+ NEW ROW", foc ? K_FOCUS : K_DIM, 2); continue; }
        b[0] = 0; if (idx + 1 < 10) ui_strcat(b, sizeof b, "0"); ui_num(b, sizeof b, idx + 1);
        cv_text(8, y + 7, b, playing ? K_TEXT : (foc ? K_FOCUS : K_DIM), 2);
        for (int i = 0; i < 2; i++) {
            const ju_srow_t *r = &ju_song.row[idx];
            b[0] = 0;
            if (r->pat[i] >= JU_SEQ_PATS) ui_strcat(b, sizeof b, "--");
            else { if (r->pat[i] + 1 < 10) ui_strcat(b, sizeof b, "0"); ui_num(b, sizeof b, r->pat[i] + 1); }
            cv_text(56 + i * 54, y + 7, b, r->pat[i] >= JU_SEQ_PATS ? K_LINE : (i ? K_BLUE : K_ORANGE), 2);
        }
        b[0] = 0; ui_strcat(b, sizeof b, "x"); ui_num(b, sizeof b, ju_song.row[idx].rep);
        cv_text(164, y + 7, b, foc ? K_FOCUS : K_TEXT, 2);
    }
}

static void d_tools(int p, uint16_t col)
{
    int i;
    char b[16];
    cv_rect(0, 24, CV_W, 20, col);
    cv_text(6, 27, "TOOLS", K_BG, 2);
    cv_text(CV_W - 6 - cv_text_w(p ? "LOWER" : "UPPER", 1), 31, p ? "LOWER" : "UPPER", K_BG, 1);
    for (i = 0; i < TL_COUNT; i++) {
        int y = 46 + i * 17, foc = i == ui.tool_sel;
        if (!cv_sees(y - 1, 18)) continue;
        cv_rect(0, y, CV_W, 16, foc ? K_FOCBG : K_PANEL);
        if (foc) cv_frame(0, y, CV_W, 16, K_FOCUS);
        cv_text(8, y + 1, kTools[i], foc ? K_FOCUS : K_TEXT, 2);
        b[0] = 0;
        if (i == TL_TRANSPOSE || i == TL_SHIFT) {
            int a = ui.tool_amt[i == TL_SHIFT];
            ui_strcat(b, sizeof b, a > 0 ? "+" : ""); ui_num(b, sizeof b, a); ui_strcat(b, sizeof b, i == TL_SHIFT ? " STEPS" : " ST");
        } else if (i == TL_PASTE) ui_strcat(b, sizeof b, ui_clip_ok ? "READY" : "EMPTY");
        else if (i == TL_UNDO) ui_strcat(b, sizeof b, ui_undo_ok ? "READY" : "NONE");
        if (b[0]) cv_text(CV_W - 8 - cv_text_w(b, 1), y + 5, b, foc ? K_FOCUS : K_DIM, 1);
    }
}

static void d_step_cards(int p, const ju_pat_t *t, int len, int cur, int h, uint16_t col)
{
    static const char *const velname[4] = {"NORMAL", "ACCENT", "SOFT", "GHOST"};
    static const char *const pct[4] = {"100%", "75%", "50%", "25%"};
    static const char *const rname[4] = {"x1", "x2", "x3", "x4"};
    char nm[4][12], vl[4][14], un[4][14];
    int q, f = h >= 0 ? t->flags[h] : 0, idx = h >= 0 ? h : cur, size[4] = {3, 2, 3, 3}, ch = chord_of(t, idx);
    char b[16];
    for (q = 0; q < 4; q++) { nm[q][0] = 0; vl[q][0] = 0; un[q][0] = 0; }
    ui_strcat(nm[0], 12, "STEP");
    ui_num(vl[0], 14, cur + 1); ui_strcat(vl[0], 14, "/"); ui_num(vl[0], 14, len);
    if (h >= 0) seq_note_name(un[0], t->note[h]); else ui_strcat(un[0], 14, "NO NOTE");
    if (ui.seq_sub == 3) {
        ui_strcat(nm[1], 12, "VELOCITY"); ui_strcat(vl[1], 14, h >= 0 ? velname[SQF_VEL(f)] : "---");
        ui_strcat(nm[2], 12, "PROBABILITY"); ui_strcat(vl[2], 14, h >= 0 ? pct[SQF_PROB(f)] : "---"); ui_strcat(un[2], 14, "CHANCE");
        ui_strcat(nm[3], 12, "RATCHET"); ui_strcat(vl[3], 14, h >= 0 ? rname[SQF_RAT(f)] : "---"); ui_strcat(un[3], 14, "HITS");
        size[1] = 2;
    } else {
        ui_strcat(nm[1], 12, "CHORD"); ui_strcat(vl[1], 14, h < 0 && t->type[idx] != SQ_NOTE ? "---" : ch >= 0 ? kChords[ch].name : "CUSTOM");
        ui_strcat(nm[2], 12, "LANE"); ui_strcat(vl[2], 14, t->lane ? ju_pshort(ju_lane_param[t->lane - 1]) : "OFF");
        if (t->lane) ui_strcat(un[2], 14, ju_plong(ju_lane_param[t->lane - 1]));
        ui_strcat(nm[3], 12, "VALUE");
        if (!t->lane) ui_strcat(vl[3], 14, "---");
        else if (!t->lv[cur]) { ui_strcat(vl[3], 14, "NONE"); ui_strcat(un[3], 14, "THE SOUND'S OWN"); }
        else { ui_num(vl[3], 14, lane_value_pct(t->lv[cur])); ui_strcat(vl[3], 14, "%"); }
        size[1] = 2; size[2] = 3; size[3] = t->lane && t->lv[cur] ? 3 : 2;
    }
    for (q = 0; q < 4; q++) {
        int x = (q & 1) * 120, y = 26 + (q >> 1) * 86;
        cv_rect(x + 2, y, 116, 82, K_PANEL);
        cv_rect(x + 2, y, 116, 3, col);
        cv_text(x + 8, y + 9, nm[q], col, 1);
        cv_text(x + 8, y + 26, vl[q], K_TEXT, size[q]);
        { char u[16]; u[0] = 0; ui_strcat(u, sizeof u, un[q]); if (cv_text_w(u, 1) > 104) u[16 - 1] = 0; cv_text(x + 8, y + 62, u, K_DIM, 1); }
        b[0] = 0; ui_strcat(b, sizeof b, "KNOB "); ui_num(b, sizeof b, q + 1);
        cv_text(x + 110 - cv_text_w(b, 1), y + 70, b, K_LINE, 1);
    }
}

static void d_seq(void)
{
    int p = ui_layer();
    const ju_pat_t *t = &ju_pat[p][ju_seq_cur[p] % JU_SEQ_PATS];
    int len = t->len ? t->len : 16, cur = ju_seq_cursor[p] % len, h = seq_head(t, cur);
    char b[24], v[12];
    uint16_t col = p ? K_BLUE : K_ORANGE;
    if (ui.seq_sub == 2) { d_song(); return; }
    cv_rect(0, 24, CV_W, 34, K_BG);
    if (ui.seq_sub == 5) { d_tools(p, col); return; }
    if (ui.seq_sub >= 3) { d_step_cards(p, t, len, cur, h, col); return; }
    if (ui.seq_sub) {                                       /* the setup: four big values, as Sloop shows its settings */
        static const char *const nm[4] = {"LENGTH", "GATE", "TEMPO", "PATTERN"};
        static const char *const un[4] = {"STEPS", "OF STEP", 0, "OF 16"};
        int q;
        for (q = 0; q < 4; q++) {
            int x = (q & 1) * 120, y = 26 + (q >> 1) * 86;
            v[0] = 0;
            switch (q) {
            case 0: ui_num(v, sizeof v, len); break;
            case 1: ui_num(v, sizeof v, t->gate * 100 / 6); ui_strcat(v, sizeof v, "%"); break;
            case 2: ui_num(v, sizeof v, 40 + ju_global[G_TEMPO]); break;
            default: if (ju_seq_cur[p] < 9) ui_strcat(v, sizeof v, "0"); ui_num(v, sizeof v, ju_seq_cur[p] + 1); break;
            }
            cv_rect(x + 2, y, 116, 82, K_PANEL);
            cv_rect(x + 2, y, 116, 3, col);
            cv_text(x + 8, y + 9, nm[q], col, 2);
            cv_text(x + 8, y + 32, v, K_TEXT, 3);
            cv_text(x + 8, y + 62, q == 2 ? (ju_global[G_SYNC] ? "MIDI CLOCK" : "BPM") : un[q], K_DIM, 1);
            b[0] = 0; ui_strcat(b, sizeof b, "KNOB "); ui_num(b, sizeof b, q + 1);
            cv_text(x + 110 - cv_text_w(b, 1), y + 62, b, K_LINE, 1);
        }
        return;
    }
    /* the four values above the roll: STEP, NOTE, LEN, PATTERN */
    b[0] = 0; ui_strcat(b, sizeof b, "STEP /"); ui_num(b, sizeof b, len);
    v[0] = 0; ui_num(v, sizeof v, cur + 1);
    d_cell(0, 60, b, v, col, K_TEXT);
    if (h >= 0) seq_note_name(v, t->note[h]); else { v[0] = 0; ui_strcat(v, sizeof v, "---"); }
    d_cell(60, 60, "NOTE", v, col, h >= 0 ? K_TEXT : K_DIM);
    v[0] = 0;
    if (h >= 0) ui_num(v, sizeof v, seq_chain(t, h)); else ui_strcat(v, sizeof v, "-");
    d_cell(120, 60, "LEN", v, col, h >= 0 ? K_TEXT : K_DIM);
    v[0] = 0; ui_strcat(v, sizeof v, p ? "L" : "U"); if (ju_seq_cur[p] < 9) ui_strcat(v, sizeof v, "0"); ui_num(v, sizeof v, ju_seq_cur[p] + 1);
    d_cell(180, 60, "PATTERN", v, col, K_TEXT);
    if (!cv_sees(RL_Y0, RL_Y1 + 8 - RL_Y0)) return;
    d_seq_roll(p, t, len, cur, col);
}

static void ui_draw(void)
{
    d_header();
    switch (ui.page) {
    case PAGE_QLINK: d_qlink(); break;
    case PAGE_PANEL: d_panel(); break;
    case PAGE_PERF: d_perf(); break;
    case PAGE_FX: d_fx(); break;
    case PAGE_SEQ: d_seq(); break;
    case PAGE_PROJ: d_proj(); break;
    default: d_patches(); break;
    }
    d_readout();
}
