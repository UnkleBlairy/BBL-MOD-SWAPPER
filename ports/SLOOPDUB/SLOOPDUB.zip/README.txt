SLOOP DUB 1.8 for the BBL Mod Swapper

Original by altessproduction: https://github.com/altessproduction/sloop-dub-fm1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: SLOOPDUB-source.zip on the ports page.
