/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Host test of the per-track INSERT (1.5, Discussions #78 and #177; src/fx.c track_insert), on the real sources:
 *   build/host/insert_test [DEMO_DIR]      (run_tests.sh builds and runs it; demos in build/insert_demo/)
 * 1. bit for bit: TYPE OFF with any A B C MIX, and MIX 0 of every type, render the phrases the defaults render (POLY,
 *    SPREAD, the sends' tails); MIX 100 % of every type changes them.
 * 2. each TYPE on a chord and on 8 loud voices, A B C at their corners: no DC (its mean against the input's), bounded,
 *    MIX 0 = the input bit for bit (nothing runs), MIX 100 % = the wet: MIX 50 % is exactly halfway between the dry
 *    and it (the effect's state does not depend on MIX).
 * 3. MIX glides (2.9 ms both ways), a TYPE change fades out, switches, fades in; MIX and TYPE as automation and as a
 *    step's lock on a playing pattern.
 * 4. stored: a project round trip (FUN10, 111 parameters with 1.5's TYPE and ESYNC; 16 spare bytes left), a FUN10 of 104 (1.2 .. 1.4) loads the
 *    INSERT OFF; user presets of 111 and 104; the labels and values the pages show per TYPE; the page order.
 * 5. the cost per type and track (instructions / sample, host) against an 8-voice ANALOG part.
 * 6. demos (DEMO_DIR): each TYPE on a loop (acid line + drums), two bars dry, two bars with the INSERT.
 * Guru-600 1.1: the EQ (LOW MID HIGH): 0 dB bit for bit, each band where it acts, its page, picked at 0 dB. */
#define UI_TEST_NO_MAIN 1
#include "ui_test.c"
#ifdef __APPLE__
#include <libproc.h>
#include <sys/resource.h>
#endif

static int bad;
static void ck(const char *what, int ok)
{
    printf("insert: %-82s %s\n", what, ok ? "ok" : "FAIL");
    bad += !ok;
}

static int32_t out_buf[2 * CTL];
static uint64_t hash;
static void mixb(uint32_t n)
{
    uint32_t i, k;
    while (n--) {
        mix_block(out_buf, CTL);
        for (i = 0; i < 2u * CTL; i++)
            for (k = 0; k < 4u; k++) {
                hash ^= ((uint32_t)out_buf[i] >> (8u * k)) & 0xFFu;
                hash *= 0x100000001B3ull;
            }
    }
}

static uint32_t eng_by_name(const char *n)
{
    uint32_t e;
    for (e = 0; e < NENGINES; e++)
        if (str_eq(ENGINES[e]->name, n))
            return e;
    return 0;
}
static uint32_t preset_by_name(uint32_t e, const char *n)
{
    uint32_t k;
    for (k = 0; k < ENGINES[e]->npresets; k++)
        if (str_eq(ENGINES[e]->presets[k].name, n))
            return k;
    return 0;
}

static void fresh(uint32_t e, uint32_t pi)        /* the boot state (no FX tails), track 1 = engine e preset pi */
{
    uint32_t k;
    memset(dly_buf, 0, sizeof dly_buf);
    memset(cho_buf, 0, sizeof cho_buf);
    memset(rev_comb, 0, sizeof rev_comb);
    memset(rev_ap, 0, sizeof rev_ap);
    memset(&fx, 0, sizeof fx);
    memset(&pf, 0, sizeof pf);
    memset(ins, 0, sizeof ins);
    for (k = 0; k < NTRK; k++)
        pf.mg[k] = 32768;
    perf_held = perf_latched = 0;
    lim_env = LIM_T;
    dc_l = dc_r = dce_l = dce_r = 0;
    vage = 0;
    rng_state = 0x1234567u;
    mod_seed = 0x2545F491u;
    song.playing = 0;
    memset(trk, 0, sizeof trk);
    MOD_W_CLEAR();
    memset(sl, 0, sizeof sl);
    memset(&motion, 0, sizeof motion);
    host_tracks_init();
    for (k = 0; k < NPART; k++)
        host_preset(&trk[k], k ? 0u : e, k ? 0u : pi);
    song.sel = 0;
    hash = 0xCBF29CE484222325ull;
}

static void set_ins(track_t *t, int32_t ty, int32_t a, int32_t b, int32_t c, int32_t mix)
{
    t->p[P_ITYPE] = (int16_t)ty;
    t->p[P_IA] = (int16_t)a;
    t->p[P_IB] = (int16_t)b;
    t->p[P_IC] = (int16_t)c;
    t->p[P_IMIX] = (int16_t)mix;
}

/* ------------------------------------------------------------------ 1 --- */
static int32_t ph_ty = -1, ph_a, ph_b, ph_c, ph_mix, ph_sprd;
/* the hash of a phrase on track 1 (ANALOG SOFT PAD, POLY, the preset's sends) in a fork()ed child: the INSERT as ph_*
 * says (ph_ty -1: the defaults), SPREAD ph_sprd */
static uint64_t phrase(void)
{
    int fd[2];
    uint64_t h = 0;
    pid_t pid;
    if (pipe(fd))
        return 0;
    fflush(stdout);
    if (!(pid = fork())) {
        track_t *t = &trk[0];
        fresh(0, preset_by_name(0, "SOFT PAD"));
        t->p[P_VOICE] = V_POLY;
        t->p[P_SPRD] = (int16_t)ph_sprd;
        if (ph_ty >= 0)
            set_ins(t, ph_ty, ph_a, ph_b, ph_c, ph_mix);
        trk_note_on(t, 48, 100);
        trk_note_on(t, 55, 70);
        trk_note_on(t, 64, 120);
        mixb(FS / 2u / CTL);
        trk_note_on(t, 72, 90);
        mixb(FS / 4u / CTL);
        trk_note_off(t, 48);
        trk_note_off(t, 55);
        trk_note_off(t, 64);
        trk_note_off(t, 72);
        mixb(FS / CTL);
        h = hash;
        if (write(fd[1], &h, sizeof h) != sizeof h)
            _exit(1);
        _exit(0);
    }
    close(fd[1]);
    if (read(fd[0], &h, sizeof h) != sizeof h)
        h = 0;
    close(fd[0]);
    waitpid(pid, 0, 0);
    return h;
}
static void test_identity(void)
{
    uint64_t h0, h;
    int32_t ty, sp;
    int ok0 = 1, okw = 1;
    for (sp = 0; sp <= 64; sp += 64) {
        ph_sprd = sp;
        ph_ty = -1;
        h0 = phrase();
        ph_ty = IT_OFF; ph_a = 1; ph_b = 2; ph_c = 3; ph_mix = 50;
        ck(sp ? "SPREAD 64: TYPE OFF with A B C MIX set renders the defaults' phrase bit for bit"
              : "TYPE OFF with A B C MIX set renders the defaults' phrase bit for bit", phrase() == h0);
        for (ty = 1; ty < IT_N; ty++) {
            ph_ty = ty; ph_a = 127; ph_b = 127; ph_c = 127; ph_mix = 0;
            ok0 &= phrase() == h0;
            ph_mix = 127;
            h = phrase();
            okw &= h != h0 && h;
        }
    }
    ck("MIX 0 of every TYPE (POLY, SPREAD 64): bit for bit the defaults (nothing runs)", ok0);
    ck("MIX 100 % of every TYPE: the phrase changes", okw);
    ph_sprd = 0;
    {   /* review 1.5: TYPE OFF while the part is silent (its tail run out) leaves no INSERT state for the next note */
        track_t *t = &trk[0];
        fresh(0, preset_by_name(0, "SOFT PAD"));
        set_ins(t, IT_FLANGER, 64, 64, 64, 127);
        trk_note_on(t, 60, 100);
        mixb(FS / 4u / CTL);
        trk_note_off(t, 60);
        mixb(4u * FS / CTL);                          /* silent, the tail run out */
        int stale = ins[0][0].w != 0 && t->ins_run;
        t->p[P_ITYPE] = IT_OFF;
        mixb(1);
        ck("TYPE OFF while silent: the INSERT at rest at once (no stale fade on the next note)",
           stale && !ins[0][0].w && !t->ins_run);
    }
}

/* ------------------------------------------------------------------ 2 --- */
#define NS (2u * FS / CTL * CTL)                      /* two seconds, whole blocks: the last FS samples are 1 s */
static int32_t sig_in[NS], sig_a[NS], sig_b[NS];
static void make_sig(uint32_t voices)             /* saws, 24000 each (a voice's level), a chord's pitches */
{
    static const double HZ[8] = {110.0, 139.0, 165.0, 220.0, 277.0, 330.0, 440.0, 554.0};
    uint32_t i, v;
    for (i = 0; i < NS; i++) {
        double s = 0;
        for (v = 0; v < voices; v++) {
            double ph = fmod(i * HZ[v] / FS + v * 0.37, 1.0);
            s += (ph * 2.0 - 1.0) * 24000.0;
        }
        sig_in[i] = (int32_t)s;
    }
}
/* the input through track 1's INSERT from rest into out */
static void run_ins(int32_t ty, int32_t a, int32_t b, int32_t c, int32_t mix, int32_t *out)
{
    track_t *t = &trk[0];
    uint32_t i;
    memset(ins, 0, sizeof ins);
    set_ins(t, ty, a, b, c, mix);
    memcpy(out, sig_in, sizeof sig_in);
    for (i = 0; i < NS; i += CTL)
        track_insert(t, out + i, CTL);
}
static void test_types(void)
{
    static const int16_t COR[3] = {0, 64, 127};
    uint32_t nv, ty, ia, ib, ic, i;
    printf("insert: the types on 3 and 8 saws (peak in 72000 / 192000), A B C at 0 64 127 (27 settings), MIX 100 %%:\n");
    for (ty = 1; ty < IT_N; ty++) {
        int32_t pk[2] = {0, 0};
        double dc[2] = {0, 0};
        int same0 = 1, lin = 1, diff = 0;
        for (nv = 3; nv <= 8; nv += 5) {
            uint32_t s = nv == 8;
            make_sig(nv);
            for (ia = 0; ia < 3u; ia++)
                for (ib = 0; ib < 3u; ib++)
                    for (ic = 0; ic < 3u; ic++) {
                        double sy = 0, sx = 0;
                        /* (CRUSH: against the input held at its RATE, as it samples it: the mean of 689 samples a
                         * second of the saws is not theirs, the held one's is the reference) */
                        uint32_t hold = ty == IT_CRUSH ? INS_HOLD[COR[ib] >> 3] : 1u;
                        run_ins((int32_t)ty, COR[ia], COR[ib], COR[ic], 127, sig_a);
                        for (i = 0; i < NS; i++) {
                            int32_t m = sig_a[i] < 0 ? -sig_a[i] : sig_a[i];
                            pk[s] = m > pk[s] ? m : pk[s];
                            diff |= sig_a[i] != sig_in[i];
                            if (i >= NS - FS) {
                                sy += sig_a[i];
                                sx += sig_in[i / hold * hold];
                            }
                        }
                        sy = fabs((sy - sx) / FS);
                        if (ty != IT_CRUSH || ia || ib)         /* (1 bit at 689 Hz: 689 coarse errors a second do */
                            dc[s] = sy > dc[s] ? sy : dc[s];    /* not average out in 1 s; the odd check below) */
                        if (ia == 1 && ic != 1) {           /* MIX 50 % halfway, MIX 0 the input */
                            run_ins((int32_t)ty, COR[ia], COR[ib], COR[ic], 64, sig_b);
                            for (i = SL_RAMP; i < NS; i++) {
                                int32_t want = sig_in[i] + mulq16(sig_a[i] - sig_in[i], 64u * 258u * 2u);
                                lin &= abs(sig_b[i] - want) <= 1;
                            }
                            run_ins((int32_t)ty, COR[ia], COR[ib], COR[ic], 0, sig_b);
                            same0 &= !memcmp(sig_b, sig_in, sizeof sig_in) && !ins[0][0].w;
                        }
                    }
        }
        printf("insert:   %-5s peak 3 saws %6d, 8 saws %6d; worst DC (mean against the input's) %5.1f / %5.1f\n",
               N_ITYPE[ty], pk[0], pk[1], dc[0], dc[1]);
        {
            char w[96];
            snprintf(w, sizeof w, "%s: no DC (< 0.5 %% of a voice's full scale), bounded (< 1.5 x the input; EQ 8 x)",
                     N_ITYPE[ty]);
            ck(w, dc[0] < 164.0 && dc[1] < 164.0 && (ty == IT_EQ ? pk[0] < 72000 * 8 && pk[1] < 192000 * 8 :
                                                       pk[0] < 120000 && pk[1] < 288000));   /* (EQ: +15.5 dB a band) */
            snprintf(w, sizeof w, "%s: MIX 0 the input bit for bit, MIX 50 %% halfway to MIX 100 %% (the wet), it acts",
                     N_ITYPE[ty]);
            ck(w, same0 && lin && diff);
        }
    }
    {   /* CRUSH's steps are odd: -x gives minus what x gives (but at an exact half step, which rounds up), every BITS */
        int ok = 1;
        int32_t v, a;
        for (a = 0; a < 128; a += 8)
            for (v = -140000; v <= 140000; v += 7) {
                uint32_t sh = ins_bits_sh(a);
                int32_t half = sh && !((v + (1 << (sh - 1u))) & ((1 << sh) - 1));
                ok &= half || ins_shape(IT_CRUSH, -v, sh) == -ins_shape(IT_CRUSH, v, sh);
            }
        ck("CRUSH: its steps are odd (no offset) at every BITS", ok);
    }
}

/* ------------------------------------------------------------------ 3 --- */
static void test_glide(void)
{
    track_t *t = &trk[0];
    int32_t w1, w4, wm;
    uint32_t i;
    int ok;
    make_sig(3);
    fresh(0, 0);
    set_ins(t, IT_SOFT, 64, 96, 96, 127);
    memcpy(sig_a, sig_in, sizeof sig_in);
    track_insert(t, sig_a, CTL);
    w1 = ins[0][0].w;
    for (i = 1; i < 4u; i++)
        track_insert(t, sig_a + i * CTL, CTL);
    w4 = ins[0][0].w;
    ck("MIX 0 -> 100 %: the wet share glides in over 2.9 ms (128 samples)", w1 == CTL * SL_SLOPE && w4 == 32768);
    t->p[P_IMIX] = 0;
    track_insert(t, sig_a + 4u * CTL, CTL);
    wm = ins[0][0].w;
    for (i = 5; i < 9u; i++)
        track_insert(t, sig_a + i * CTL, CTL);
    ck("  and out again; then nothing runs (the input as it is)", wm == 32768 - CTL * SL_SLOPE && !ins[0][0].w &&
       !memcmp(sig_a + 8u * CTL, sig_in + 8u * CTL, CTL * sizeof(int32_t)));
    /* a TYPE change while it plays: SOFT fades out, FLANG fades in from rest */
    t->p[P_IMIX] = 127;
    for (i = 9; i < 16u; i++)
        track_insert(t, sig_a + i * CTL, CTL);
    t->p[P_ITYPE] = IT_FLANGER;
    ok = ins[0][0].type == IT_SOFT;
    for (i = 16; i < 20u; i++) {
        track_insert(t, sig_a + i * CTL, CTL);
        ok &= i < 19u ? ins[0][0].type == IT_SOFT && ins[0][0].w > 0 : 1;
    }
    track_insert(t, sig_a + 20u * CTL, CTL);
    ok &= ins[0][0].type == IT_FLANGER && ins[0][0].w == CTL * SL_SLOPE;
    for (i = 21; i < 24u; i++)
        track_insert(t, sig_a + i * CTL, CTL);
    {   /* no click: the largest step of the output over the change against the input's own */
        int32_t jmp = 0, jin = 0;
        for (i = 16u * CTL; i < 24u * CTL; i++) {
            if (i > 16u * CTL) {
                int32_t a = abs(sig_a[i] - sig_a[i - 1]), b = abs(sig_in[i] - sig_in[i - 1]);
                jmp = a > jmp ? a : jmp;
                jin = b > jin ? b : jin;
            }
        }
        ck("a TYPE change: the old one fades out, the new one starts from rest and fades in, no jump past the saws'",
           ok && jmp <= jin + jin / 4);
    }
}

/* MIX and TYPE on a playing pattern: MIX automation (0 at step 1, 100 % at step 9), a TYPE lock (CRUSH on step 5) */
static void test_motion(void)
{
    track_t *t = &trk[0];
    uint32_t i, k, step_s = 0;
    int ok_a = 1, ok_l = 1, seen_c = 0, seen_back = 0, seen_w = 0;
    static const uint8_t NOTE[1] = {48};
    fresh(0, preset_by_name(0, "SAW LEAD"));
    set_ins(t, IT_FOLD, 90, 96, 96, 0);
    for (i = 0; i < 16u; i++)
        put_step(t, i, 1, NOTE, ST_NOTE, 0);
    t->p[P_SLEN] = 16;
    t->seq_active = 1;
    ok_a &= !motion_set_event(t, 0, P_IMIX, 0) && !motion_set_event(t, 8, P_IMIX, 127);
    ok_l &= !motion_set_lock(t, 4, P_ITYPE, IT_CRUSH);
    seq_start();
    for (k = 0; k < 2750u; k++) {                       /* 16 steps of 172.3 blocks (1/16 at 120 BPM), not again */
        uint32_t idx;
        mixb(1);
        idx = t->seq_idx;
        if (idx < 8u)
            ok_a &= t->p[P_IMIX] == 0 && !ins[0][0].w;
        else if (idx < 16u && t->p[P_IMIX] == 127) {
            if (!step_s)
                step_s = k;
            if (k >= step_s + 4u)
                seen_w |= ins[0][0].w == 32768;
        }
        if (idx == 4u)
            seen_c |= t->p[P_ITYPE] == IT_CRUSH;
        if (idx == 5u)
            seen_back |= t->p[P_ITYPE] == IT_FOLD;
        ok_l &= idx == 4u || t->p[P_ITYPE] == IT_FOLD;
    }
    seq_stop();
    ck("MIX as automation: 0 on steps 1..8 (nothing runs), 100 % from step 9, the wet share there 4 blocks on",
       ok_a && step_s && seen_w);
    ck("TYPE as a step's lock: CRUSH on step 5 only, FOLD before and after", ok_l && seen_c && seen_back);
}

/* ------------------------------------------------------------------ 4 --- */
static void test_stored(void)
{
    static project_t a, b;
    static project_store_t st;
    up_rec_t r;
    int16_t v[P_COUNT], def[P_COUNT];
    uint32_t i, k;
    int ok;
    fresh(0, 0);
    for (k = 0; k < NTRK; k++)
        set_ins(&trk[k], (int32_t)(k * 2u + 1u), (int32_t)(10 + k), (int32_t)(20 + k), (int32_t)(30 + k), (int32_t)(100 + k));
    motion_set_event(&trk[1], 3, P_IMIX, 77);
    motion_set_lock(&trk[2], 5, P_IA, 9);
    project_capture(&a);
    ok = proj_pack(&st, &a) && st.raw[66] == PROJ_NP_KEPT && PROJ_NP_KEPT == 111u && proj_import(&b, &st, sizeof st) &&
         !memcmp(&a, &b, sizeof a);
    for (k = 0; k < NTRK; k++)
        ok &= b.t[k].p[P_ITYPE] == (int16_t)(k * 2u + 1u) && b.t[k].p[P_IMIX] == (int16_t)(100 + k) &&
              b.t[k].p[P_IC] == (int16_t)(30 + k);
    ok &= 68u + NTRK * (PROJ_NP_KEPT + 2u + NSTEP * 9u) + sizeof(chain_config_t) + sizeof(motion_store_t) + 16u == PROJ_FM6_OFF;
    ck("project: FUN10 round trip of the INSERT (111 parameters, its motion), 16 spare bytes before the patches", ok);
    /* user presets: a record of 111 keeps them; one of 104 (1.2 .. 1.4) gets the INSERT OFF */
    memset(&r, 0, sizeof r);
    r.used = UP_USED; r.ver = UP_VER; r.engine = 0; r.np = P_COUNT;
    for (i = 0; i < P_COUNT; i++) { up_set_value(&r, i, trk[3].p[i]); def[i] = TP[i].def; }
    up_params(&r, v, def);
    ok = v[P_ITYPE] == 7 && v[P_IA] == 13 && v[P_IMIX] == 103;
    r.np = 104;
    for (i = 0; i < 96u; i++) up_set_value(&r, i, trk[3].p[i]);
    for (i = 0; i < 8u; i++) up_set_value(&r, 96u + i, (int16_t)(40 + i));
    up_params(&r, v, def);
    ok &= v[P_ITYPE] == 0 && v[P_IA] == 64 && v[P_IB] == 96 && v[P_IC] == 96 && v[P_IMIX] == 127 && v[P_SPRD] == trk[3].p[P_SPRD] &&
          v[P_E0] == 40 && v[P_E7] == 47;
    ck("user presets: 111 parameters kept; one of 104 (1.2 .. 1.4): the INSERT OFF, its engine values in place", ok);
    /* the pages: INSERT and INSERT 2 after SLICER, the labels and values per TYPE */
    {
        uint32_t p, ps = 0, pi = 0, pi2 = 0, pd = 0, pj = 0, pj2 = 0;
        char val[16];
        const char *u;
        track_t *t = &trk[0];
        for (p = 0; p < NPAGES; p++) {
            if (str_eq(PAGES[p].title, "SLICER")) ps = p;
            if (str_eq(PAGES[p].title, "INSERT")) pi = p;
            if (str_eq(PAGES[p].title, "INSERT 2")) pi2 = p;
            if (str_eq(PAGES[p].title, "DLY")) pd = p;
            if (str_eq(PAGES[p].title, "INSERT B")) pj = p;      /* (Guru-600: INSERT 2's pages, after the first's) */
            if (str_eq(PAGES[p].title, "INSERT B 2")) pj2 = p;
        }
        ok = pi == ps + 1u && pi2 == pi + 1u && pj == pi2 + 1u && pj2 == pj + 1u && pd == pj2 + 1u && PAGES[pi].fam == FAM_FX &&
             PAGES[pi].id[0] == P_ITYPE && PAGES[pi2].id[0] == P_IMIX && PAGES[pj].id[0] == P_JTYPE && PAGES[pj2].id[0] == P_JMIX;
        set_ins(t, IT_CRUSH, 64, 96, 96, 127);
        ok &= str_eq(track_desc(t, P_IA)->label, "BITS") && str_eq(track_desc(t, P_IB)->label, "RATE") &&
              str_eq(track_desc(t, P_IC)->label, "LPF");
        param_format(track_desc(t, P_IA), 64, val, &u);
        ok &= str_eq(val, "9");
        param_format(track_desc(t, P_IB), 96, val, &u);
        ok &= str_eq(val, "11k") && str_eq(u, "Hz");
        param_format(track_desc(t, P_IB), 127, val, &u);
        ok &= str_eq(val, "44k");
        t->p[P_ITYPE] = IT_HARD;
        ok &= str_eq(track_desc(t, P_IA)->label, "DRIVE") && str_eq(track_desc(t, P_IB)->label, "TONE") &&
              str_eq(track_desc(t, P_IC)->label, "LEVEL");
        t->p[P_ITYPE] = IT_PHASER;
        ok &= str_eq(track_desc(t, P_IA)->label, "RATE") && str_eq(track_desc(t, P_IB)->label, "DEPTH") &&
              str_eq(track_desc(t, P_IC)->label, "FDBK");
        t->p[P_ITYPE] = IT_OFF;
        ok &= str_eq(track_desc(t, P_IA)->label, "INS A") && str_eq(param_desc_of(0, P_IB)->label, "INS B");
        for (i = P_ITYPE; i <= P_IMIX; i++)
            ok &= motion_param(i) && !param_kept(i) && motion_param(i - P_ITYPE + P_JTYPE) && !param_kept(i - P_ITYPE + P_JTYPE);
        t->p[P_JTYPE] = IT_CRUSH;
        ok &= str_eq(track_desc(t, P_JA)->label, "BITS") && str_eq(track_desc(t, P_JC)->label, "LPF");
        t->p[P_JTYPE] = IT_OFF;
        ck("pages: SLICER, INSERT (TYPE A B C), INSERT 2 (MIX), INSERT B, INSERT B 2, DLY; A B C named by TYPE; recordable; part of the sound", ok);
    }
}

/* ------------------------------------------------------------------ 5 --- */
static uint64_t instr_now(void)
{
#ifdef __APPLE__
    struct rusage_info_v4 ri;
    if (!proc_pid_rusage(getpid(), RUSAGE_INFO_V4, (rusage_info_t *)&ri))
        return ri.ri_instructions;
#endif
    return 0;
}
/* instructions per sample of ANALOG SOFT PAD POLY, 8 voices on track 1, with its INSERT ty (and MIX 50 %, mix) */
static double cost(int32_t ty, int32_t mix)
{
    static const uint8_t NOTES[8] = {48, 52, 55, 59, 60, 64, 67, 71};
    track_t *t = &trk[0];
    uint32_t i, rep;
    double best = 1e30;
    fresh(0, preset_by_name(0, "SOFT PAD"));
    t->p[P_VOICE] = V_POLY;
    t->p[P_SUS] = 127;
    set_ins(t, ty, 100, 100, 100, mix);
    for (i = 0; i < 8u; i++)
        trk_note_on(t, NOTES[i], 100);
    mixb(FS / 4u / CTL);
    for (rep = 0; rep < 3u; rep++) {
        uint64_t i0 = instr_now();
        double ipc;
        mixb(FS / 2u / CTL);
        ipc = (double)(instr_now() - i0) / (FS / 2u);
        best = ipc < best ? ipc : best;
    }
    return best;
}
static void test_cost(void)
{
    double c0, c, worst = 0;
    int32_t ty;
    if (!instr_now()) {
        printf("insert: cost: no instruction counter on this host (proc_pid_rusage), skipped\n");
        return;
    }
    c0 = cost(IT_OFF, 127);
    printf("insert: cost, ANALOG SOFT PAD 8 voices on track 1: OFF %.0f instructions / sample; the INSERT adds:\n", c0);
    for (ty = 1; ty < IT_N; ty++) {
        c = cost(ty, 127) - c0;
        printf("insert:   %-5s %+5.1f (%+.1f %%)", N_ITYPE[ty], c, c * 100 / c0);
        worst = c > worst ? c : worst;
        c = cost(ty, 64) - c0;
        printf(", MIX 50 %% %+5.1f\n", c);
        worst = c > worst ? c : worst;
    }
    c = cost(IT_PHASER, 0) - c0;
    printf("insert:   PHASR at MIX 0 %+5.1f (a test per block)\n", c);
    ck("cost: MIX 0 next to nothing; every TYPE a fixed cost per track below 10 % of an 8-voice part",
       worst < c0 * 0.10 && c < c0 * 0.005);
}

/* Guru-600 1.1: the EQ (fx.c ins_eq): every band at 0 dB the input bit for bit; each band cuts and boosts where it acts
 * and leaves the others' range alone; LOW MID HIGH and their dBs on the page; picking EQ sets them to 0 dB */
static double eq_db(double hz, int32_t a, int32_t b, int32_t c)
{
    uint32_t i;
    double so = 0, si = 0;
    for (i = 0; i < NS; i++)
        sig_in[i] = (int32_t)(24000.0 * sin(2.0 * M_PI * hz * i / FS));
    run_ins(IT_EQ, a, b, c, 127, sig_a);
    for (i = NS / 2u; i < NS; i++) {
        so += (double)sig_a[i] * sig_a[i];
        si += (double)sig_in[i] * sig_in[i];
    }
    return 10.0 * log10(so / si);
}
static void test_eq(void)
{
    static const double HZ[3] = {60.0, 800.0, 10000.0};
    double r[3][3], o[3];
    uint32_t k, j;
    int ok = 1, okc = 1, oko = 1, okb = 1;
    char val[12];
    const char *unit = 0;
    track_t *t = &trk[0];
    fresh(0, 0);                                         /* (no INSERT 2 left by test_ins2) */
    for (k = 3; k <= 8u; k += 5) {
        make_sig(k);
        run_ins(IT_EQ, 64, 64, 64, 127, sig_a);
        ok &= !memcmp(sig_a, sig_in, sizeof sig_in);
        run_ins(IT_EQ, 65, 65, 65, 127, sig_a);
        ok &= !memcmp(sig_a, sig_in, sizeof sig_in);
    }
    ck("EQ: LOW MID HIGH at 0 dB (64, 65): the input bit for bit (3 and 8 saws)", ok);
    for (k = 0; k < 3u; k++) {                            /* each band at -12 dB (16), then +12 dB (112) */
        int32_t q[3] = {64, 64, 64};
        q[k] = 16;
        for (j = 0; j < 3u; j++)
            r[k][j] = eq_db(HZ[j], q[0], q[1], q[2]);
        q[k] = 112;
        o[k] = eq_db(HZ[k], q[0], q[1], q[2]);
        printf("insert:   EQ %s -12 dB: %+5.1f dB at 60 Hz, %+5.1f at 800 Hz, %+5.1f at 10 kHz; +12 dB: %+5.1f where it acts\n",
               k == 0 ? "LOW " : k == 1 ? "MID " : "HIGH", r[k][0], r[k][1], r[k][2], o[k]);
    }
    okc = r[0][0] < -9.0 && r[2][2] < -9.0 && r[1][1] < -4.0 && r[0][2] > -0.5 && r[2][0] > -0.5 &&
          r[1][0] > -2.0 && r[1][2] > -2.0;
    oko = o[0] > 10.0 && o[2] > 10.0 && o[1] > 4.0;
    ck("EQ: LOW and HIGH -12 dB cut their end by more than 9 dB, MID its band by more than 4 dB; the far end kept",
       okc);
    ck("EQ: +12 dB boosts as much (LOW and HIGH > 10 dB, MID > 4 dB)", oko);
    make_sig(8);
    run_ins(IT_EQ, 0, 0, 0, 127, sig_a);                  /* every band -16 dB: the whole input down 16 dB */
    for (k = NS / 2u; k < NS; k += 97u)
        okb &= abs(sig_a[k] - mulq16(sig_in[k], 10380u)) < 600;
    ck("EQ: every band at -16 dB: the input 16 dB down (all bands sum back)", okb);
    set_ins(t, IT_EQ, 64, 64, 64, 127);
    ok = str_eq(track_desc(t, P_IA)->label, "LOW") && str_eq(track_desc(t, P_IB)->label, "MID") &&
         str_eq(track_desc(t, P_IC)->label, "HIGH") && str_eq(N_ITYPE[IT_EQ], "EQ");
    param_format(track_desc(t, P_IA), 64, val, &unit);
    ok &= str_eq(val, "0.0") && unit && str_eq(unit, "dB");
    param_format(track_desc(t, P_IA), 78, val, &unit);
    ok &= str_eq(val, "+3.5");
    param_format(track_desc(t, P_IA), 63, val, &unit);
    ok &= str_eq(val, "-0.5");
    param_format(track_desc(t, P_IA), 0, val, &unit);
    ok &= str_eq(val, "-16.0");
    param_format(track_desc(t, P_IA), 127, val, &unit);
    ok &= str_eq(val, "+15.5");
    fresh(0, 0);                                         /* KNOB 1 on INSERT (and INSERT B) from CHOR to EQ: 0 dB */
    ui_power_on();
    t = TSEL;
    set_ins(t, IT_CHORUS, 40, 96, 110, 127);
    t->p[P_JTYPE] = IT_CHORUS; t->p[P_JA] = 40; t->p[P_JB] = 96; t->p[P_JC] = 110;
    go_title("INSERT");
    turn(EN_K1, 1);
    okb = t->p[P_ITYPE] == IT_EQ && t->p[P_IA] == 64 && t->p[P_IB] == 64 && t->p[P_IC] == 64;
    turn(EN_K1, -1);
    t->p[P_IA] = 30;
    turn(EN_K1, 1);
    okb &= t->p[P_ITYPE] == IT_EQ && t->p[P_IA] == 64;
    go_title("INSERT B");
    turn(EN_K1, 1);
    okb &= t->p[P_JTYPE] == IT_EQ && t->p[P_JA] == 64 && t->p[P_JB] == 64 && t->p[P_JC] == 64 && t->p[P_IMIX] == 127;
    ck("EQ: picking it on INSERT or INSERT B (KNOB 1) sets LOW MID HIGH to 0 dB", okb);
    set_ins(t, IT_OFF, 64, 96, 96, 127);
    t->p[P_JTYPE] = IT_OFF;
    ck("EQ: the page shows LOW MID HIGH in dB (0.0 at 64, +3.5 at 78, -0.5 at 63, -16.0 .. +15.5)", ok);
}

/* ------------------------------------------------------------------ 6 --- */
static FILE *demo_open(const char *dir, const char *name, uint32_t frames)
{
    char path[512];
    FILE *f;
    snprintf(path, sizeof path, "%s/%s.wav", dir, name);
    f = fopen(path, "wb");
    if (f)
        wav_hdr(f, frames);
    return f;
}
/* the loop: track 1 an acid line (ANALOG ACID .. its first preset as the factory sets it), track 2 DRUM (kick, snare,
 * hats); the INSERT on both from bar 3 */
static int demos(const char *dir)
{
    static const uint8_t LINE[16] = {36, 36, 48, 36, 0, 39, 36, 46, 36, 0, 48, 43, 36, 39, 0, 41};
    static const uint8_t SET[IT_N][4] = {{0}, {100, 90, 96, 127}, {90, 100, 92, 127}, {70, 110, 100, 127},
                                         {110, 80, 106, 127}, {40, 72, 90, 127}, {50, 127, 100, 127},
                                         {40, 127, 110, 127}, {60, 110, 30, 127}, {80, 56, 40, 127}};
    uint32_t ty, i, n = 0, bars = 4u, frames = bars * 4u * FS / 2u / CTL * CTL;   /* 120 BPM: a bar 2 s */
    for (ty = 1; ty < IT_N; ty++) {
        char name[32];
        FILE *f;
        uint32_t k;
        fresh(0, 0);
        host_preset(&trk[1], ENGI_DRUM, 0);
        for (i = 0; i < 16u; i++) {
            uint8_t nt = LINE[i];
            put_step(&trk[0], i, nt ? 1u : 0u, &nt, nt ? ST_NOTE : ST_REST, (i % 4u) == 2u ? SF_ACCENT : 0u);
            put_step(&trk[1], i, 0, 0, ST_NOTE, 0);
            trk[1].step[i].hit = (uint8_t)((i % 4u == 0u ? 1u : 0u) | (i % 8u == 4u ? 2u : 0u) | (i % 2u == 0u ? 8u : 0u));
            trk[1].step[i].vel = 100;
        }
        trk[0].p[P_SLEN] = trk[1].p[P_SLEN] = 16;
        trk[0].seq_active = trk[1].seq_active = 1;
        trk[0].p[P_REV] = trk[1].p[P_REV] = 20;
        snprintf(name, sizeof name, "%d_%s", ty, N_ITYPE[ty]);
        for (k = 0; name[k]; k++)
            name[k] = (char)(name[k] >= 'A' && name[k] <= 'Z' ? name[k] + 32 : name[k]);
        if (!(f = demo_open(dir, name, frames)))
            continue;
        seq_start();
        for (k = 0; k < frames / CTL; k++) {
            if (k == frames / CTL / 2u)
                for (i = 0; i < 2u; i++)
                    set_ins(&trk[i], (int32_t)ty, SET[ty][0], SET[ty][1], SET[ty][2], SET[ty][3]);
            mixb(1);
            for (i = 0; i < CTL; i++)
                wav_put(f, out_buf[2u * i], out_buf[2u * i + 1u]);
        }
        seq_stop();
        fclose(f);
        n++;
    }
    return (int)n;
}

/* Guru-600 (10/11): INSERT 2, after the first, as it (P_JTYPE .. P_JMIX); in a project, bit 7 of steps 0..31's meta */
static void test_ins2(void)
{
    static int32_t o1[NS], o2[NS], o3[NS];
    static project_t a, b;
    static project_store_t st, st0;
    track_t *t = &trk[0];
    uint32_t ty, i, k;
    int ok = 1;
    fresh(0, 0);
    for (ty = 1; ty < IT_N; ty++) {                       /* alone, INSERT 2 sounds as INSERT 1 does, bit for bit */
        run_ins((int32_t)ty, 70, 90, 50, 100, o1);
        memset(ins, 0, sizeof ins);
        set_ins(t, 0, 64, 96, 96, 127);
        t->p[P_JTYPE] = (int16_t)ty; t->p[P_JA] = 70; t->p[P_JB] = 90; t->p[P_JC] = 50; t->p[P_JMIX] = 100;
        memcpy(o2, sig_in, sizeof sig_in);
        for (i = 0; i < NS; i += CTL)
            track_insert(t, o2 + i, CTL);
        ok &= !memcmp(o1, o2, sizeof o1);
        t->p[P_JTYPE] = 0;
    }
    ck("INSERT 2 alone: each TYPE the same output as INSERT 1 alone, bit for bit", ok);
    /* both: INSERT 2 takes INSERT 1's output (PHASR then FLANG = PHASR's output through FLANG) */
    run_ins(IT_PHASER, 64, 96, 60, 127, o1);
    memcpy(o3, o1, sizeof o1);
    memset(ins, 0, sizeof ins);
    set_ins(t, IT_FLANGER, 50, 80, 40, 127);
    for (i = 0; i < NS; i += CTL)
        track_insert(t, o3 + i, CTL);                     /* (INSERT 1 = FLANG alone on PHASR's output) */
    memset(ins, 0, sizeof ins);
    set_ins(t, IT_PHASER, 64, 96, 60, 127);
    t->p[P_JTYPE] = IT_FLANGER; t->p[P_JA] = 50; t->p[P_JB] = 80; t->p[P_JC] = 40; t->p[P_JMIX] = 127;
    memcpy(o2, sig_in, sizeof sig_in);
    for (i = 0; i < NS; i += CTL)
        track_insert(t, o2 + i, CTL);
    ck("INSERT 1 then INSERT 2: PHASR then FLANG, as FLANG on PHASR's output", !memcmp(o2, o3, sizeof o2));
    set_ins(t, 0, 64, 96, 96, 127);
    t->p[P_JTYPE] = 0; t->p[P_JA] = 64; t->p[P_JB] = 96; t->p[P_JC] = 96; t->p[P_JMIX] = 127;
    /* a project: INSERT 2 OFF packs as 1.5 did (every meta byte below 128); set, it comes back, its motion too */
    fresh(0, 0);
    project_capture(&a);
    ok = proj_pack(&st0, &a) && st0.raw[66] == 111u;
    for (k = 0; k < NTRK; k++)
        for (i = 0; i < NSTEP; i++)
            ok &= st0.raw[68u + k * (111u + 2u + NSTEP * 9u) + 111u + 2u + i * 9u + 4u] < 128u;
    ok &= proj_import(&b, &st0, sizeof st0) && !memcmp(&a, &b, sizeof a) && b.t[2].p[P_JTYPE] == 0 && b.t[2].p[P_JMIX] == 127;
    ck("project: INSERT 2 OFF packs as 1.5 did (111 values, every meta byte below 128), loads OFF", ok);
    for (k = 0; k < NTRK; k++) {
        trk[k].p[P_JTYPE] = (int16_t)(8u - k); trk[k].p[P_JA] = (int16_t)(k * 30u); trk[k].p[P_JB] = (int16_t)(127u - k);
        trk[k].p[P_JC] = (int16_t)(1u + k); trk[k].p[P_JMIX] = (int16_t)(50u + k);
    }
    motion_set_event(&trk[1], 4, P_JMIX, 33);
    motion_set_lock(&trk[3], 9, P_JA, 5);
    motion_set_event(&trk[2], 7, P_E2, 44);
    project_capture(&a);
    ok = proj_pack(&st, &a) && st.raw[66] == 111u && proj_import(&b, &st, sizeof st) && !memcmp(&a, &b, sizeof a);
    for (k = 0; k < NTRK; k++)
        ok &= b.t[k].p[P_JTYPE] == (int16_t)(8u - k) && b.t[k].p[P_JA] == (int16_t)(k * 30u) && b.t[k].p[P_JB] == (int16_t)(127u - k) &&
              b.t[k].p[P_JC] == (int16_t)(1u + k) && b.t[k].p[P_JMIX] == (int16_t)(50u + k);
    for (i = 0; i < b.motion.count; i++) {                /* (its motion with today's ids) */
        uint32_t id = MOTION_ID(&b.motion.event[i]), pl = b.motion.event[i].place;
        if (pl == (1u << 6 | 4u)) ok &= id == P_JMIX && b.motion.event[i].value == 33;
        if (pl == (3u << 6 | 9u)) ok &= id == P_JA && (b.motion.event[i].param & MOTION_LOCK);
        if (pl == (2u << 6 | 7u)) ok &= id == P_E2 && b.motion.event[i].value == 44;
    }
    ck("project: INSERT 2 round trip (in the steps' bit 7), its automation and lock, the engine values' motion in place", ok);
}
int main(int argc, char **argv)
{
    test_identity();
    test_types();
    test_glide();
    test_motion();
    test_stored();
    test_ins2();
    test_eq();
    test_cost();
    if (argc > 1)
        printf("insert: %d demos in %s (each TYPE on a loop: two bars dry, two with it)\n", demos(argv[1]), argv[1]);
    if (bad) {
        printf("INSERT TEST FAILED (%d)\n", bad);
        return 1;
    }
    printf("insert: all ok\n");
    return 0;
}
