/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Editor protocol: SysEx for the web editor (web/EDITOR_PROTOCOL.md; v2 = user presets + live sync,
 * v3 = four tracks: the v1 / v2 commands act on the selected track, cmds 27-30 reach any track;
 * v4 = TRACK_PARAM (31) and the TRACK_CHANGED push (32), enabled by WATCH bit 1).
 *   F0 7D 46 4C cmd args.. F7     (7D = non-commercial ID, "FL")
 * Values are 14 bit, two 7-bit bytes LSB first, offset by 8192 (so -8192..8191).
 * Every request gets a reply with the same cmd; 23/24/26 are also pushed
 * while watched. Frames arrive through sx_frame (usb.c), replies leave
 * through ota_wire_send(). */
#define ED_HDR0 0x7D
#define ED_HDR1 0x46
#define ED_HDR2 0x4C
enum { ED_INFO = 1, ED_GET, ED_SET, ED_DUMP, ED_DESC, ED_STEP_GET, ED_STEP_SET, ED_PRESET, ED_PROJECT, ED_NAMES,
       ED_SMP_BEGIN, ED_SMP_WRITE, ED_SMP_END, ED_SMP_ERASE, ED_SMP_INFO,
       ED_UP_LIST, ED_UP_GET, ED_UP_PUT, ED_UP_STORE, ED_UP_LOAD, ED_UP_ERASE,   /* v2: user presets */
       ED_WATCH, ED_CHANGED, ED_RELOAD, ED_PING, ED_STEP_CHANGED,              /* v2: live sync */
       ED_TRACK, ED_TRACK_MIX, ED_TRACK_DUMP, ED_TRACK_STEP,                    /* v3: tracks */
       ED_TRACK_PARAM, ED_TRACK_CHANGED, ED_SONG,
       ED_UI_STATE, ED_UI_SET, ED_UI_PALETTES, ED_FAV_GET, ED_FAV_SET,
       ED_MOTION = 64, ED_BACKUP_LIST, ED_BACKUP_GET, ED_BACKUP_PUT };                              /* v6: song chain */

static uint8_t ed_out[664] __attribute__((section(".pool")));   /* (MOTION op 8: 128 records and their kinds, 653 bytes) */
static uint32_t ed_n;

static void ed_begin(uint32_t cmd)
{
    ed_out[0] = 0xF0;
    ed_out[1] = ED_HDR0;
    ed_out[2] = ED_HDR1;
    ed_out[3] = ED_HDR2;
    ed_out[4] = (uint8_t)cmd;
    ed_n = 5;
}
static void ed_b(uint32_t v)
{
    if (ed_n < sizeof ed_out - 1u)
        ed_out[ed_n++] = (uint8_t)(v & 0x7Fu);
}
static void ed_v(int32_t v)
{
    uint32_t u = (uint32_t)(clamp(v, -8192, 8191) + 8192);
    ed_b(u);
    ed_b(u >> 7);
}
#include "guru_version.h"
static void ed_str(const char *s, uint32_t max)   /* ASCII, 0-terminated */
{
    uint32_t i;
    for (i = 0; s && s[i] && i < max; i++)
        ed_b((uint8_t)s[i] & 0x7Fu);
    ed_b(0);
}
static void ed_send(void)
{
    ed_out[ed_n++] = 0xF7;
    ota_wire_send(ed_out, ed_n);
}
static int32_t ed_rv(const uint8_t *p) { return (int32_t)(p[0] | p[1] << 7) - 8192; }

/* ---- user sample slots (eng_sample.c): flash SMP_USER_BASE + k * SMP_USER_SIZE ----
 * BEGIN erases the header sector (the slot is invalid from then on), WRITE fills the data
 * (offset >= 512, erasing each further sector when the write reaches its start), END sends
 * the header: the device checks the data CRC and writes the header last. */
static uint32_t ed_unpack7(const uint8_t *a, uint32_t na, uint8_t *out, uint32_t max)
{
    uint32_t n = 0;                                 /* groups: msb byte, then up to 7 bytes */
    while (na && n < max) {
        uint32_t m = *a++, j;
        na--;
        uint32_t k = na > 7u ? 7u : na;
        if (!k || n + k > max || (m >> k))
            return 0;                              /* incomplete group, overflow, or unused mask bits */
        for (j = 0; j < k; j++, na--)
            out[n++] = (uint8_t)(*a++ | ((m >> j) & 1u) << 7);
    }
    return na ? 0u : n;
}
static uint8_t ed_smp_buf[512] __attribute__((aligned(4), section(".pool")));
static uint32_t ed_smp_slot(uint32_t k) { return SMP_USER_BASE + k * SMP_USER_SIZE; }
static void ed_smp_inval(uint32_t k)
{
    fm1_irq_off();
    fl_inval(ed_smp_slot(k), SMP_USER_SIZE);
    fm1_irq_on();
}
static int ed_smp_erase(uint32_t k, uint32_t all)  /* header sector, or the whole slot */
{
    uint32_t i, took;
    int rc = 0;
    usr_nz[k] = 0;
    for (i = 0; i < 16u; i++)
        usr_zone[k][i].n = 0;                     /* a sounding voice ends instead of reading 0xFF */
    for (i = 0; i < (all ? SMP_USER_SIZE / 0x1000u : 1u) && !rc; i++) {
        if (SMP_SLOT_KEEP(k, i))
            continue;                                 /* (P600: its imported programs, eng_sample.c) */
        audio_silence();
        rc = fl_erase4k(ed_smp_slot(k) + i * 0x1000u, &took);
        fm1_wdt_feed();
    }
    ed_smp_inval(k);
    return rc;
}
static int ed_flash_stop(void);
static int ed_smp_end(uint32_t k, const uint8_t *a, uint32_t na)
{
    const smp_user_hdr_t *h = (const smp_user_hdr_t *)ed_smp_buf;
    if (ed_unpack7(a, na, ed_smp_buf, sizeof(smp_user_hdr_t)) != sizeof(smp_user_hdr_t))
        return 1;
    if (h->magic != SMP_USER_MAGIC || h->version != 1 || !h->nz || h->nz > 16u ||
        h->data_len > SMP_SLOT_END(k) - SMP_USER_DATA)
        return 2;
    if (usr_nz[k])                                     /* published zones may still be read by live voices */
        return memcmp(h, smp_user_xip(k), sizeof *h) ? 2 : 0;
    if (ed_flash_stop())                               /* (only a header that will be written stops the transport) */
        return 1;
    ed_smp_inval(k);
    if (st_crc32(smp_user_xip(k) + SMP_USER_DATA, h->data_len) != h->crc)
        return 3;
    if (fl_write(ed_smp_slot(k), ed_smp_buf, sizeof(smp_user_hdr_t)))
        return 4;
    ed_smp_inval(k);
    smp_user_scan(k);
    return usr_nz[k] ? 0 : 5;
}

/* the engine byte of DUMP / RELOAD / TRACK */
static uint32_t ed_eng(const track_t *t) { return t->eng_req % NENGINES; }

/* ---- live sync (v2): while the editor WATCHes, device-side changes are pushed.
 * Shadows of the selected track's p[] + song.g[] and of its steps are kept in step
 * with what the editor knows (its own SET / STEP_SET update them); the main loop
 * compares and pushes CHANGED / STEP_CHANGED, or RELOAD after a load or when another
 * track was selected (v3: RELOAD and STEP_CHANGED carry the selected track). Pushes
 * go out only into a half-empty SysEx ring, so they never wait. */
#define ED_PUSH_MAX 4u                                   /* frames per pass */
#define ED_NV (P_COUNT + G_COUNT)
/* v4: the parameters of the tracks that are not selected which TRACK_CHANGED follows (the mixer) */
static const uint8_t ED_TIDS[3] = {P_LEVEL, P_PAN, P_MUTE};
#define ED_NT (NTRK * 3u)
static struct {
    uint8_t on, eng, preset, sel;
    uint8_t v4;                                          /* WATCH bit 1: TRACK_CHANGED pushes too */
    uint32_t pos, last_ms, run_ms, resets;
    int16_t v[ED_NV];                                    /* TSEL->p[], then song.g[] */
    uint16_t t[ED_NV];                                   /* ms (low 16 bits) of the last push */
    uint32_t st[NSTEP];                                  /* step signatures */
    int16_t tv[ED_NT];                                   /* v4: trk[k].p[ED_TIDS[j]] at k * 3 + j */
    uint16_t tt[ED_NT];
    uint32_t tpos;
} ed_w;

static int16_t *ed_val(uint32_t i) { return i < P_COUNT ? &TSEL->p[i] : &song.g[i - P_COUNT]; }
static uint32_t ed_step_sig(const step_t *s)
{
    return ((uint32_t)s->note[0] | (uint32_t)s->note[1] << 7 | (uint32_t)s->note[2] << 14 | (uint32_t)s->note[3] << 21) ^
           ((uint32_t)s->n << 28) ^ ((uint32_t)s->time * 0x9E3779B1u) ^ ((uint32_t)s->flags * 0x85EBCA6Bu) ^
           ((uint32_t)s->vel * 0xC2B2AE35u) ^ ((uint32_t)(s->hit | s->acc << 8) * 0x27D4EB2Fu) ^ ((uint32_t)s->probability * 0x165667B1u);
}
static void ed_shadow(void)                              /* the editor is in sync */
{
    uint32_t i;
    for (i = 0; i < ED_NV; i++)
        ed_w.v[i] = *ed_val(i);
    for (i = 0; i < NSTEP; i++)
        ed_w.st[i] = ed_step_sig(&seq_steps(TSEL)[i]);
    for (i = 0; i < ED_NT; i++)
        ed_w.tv[i] = trk[i / 3u].p[ED_TIDS[i % 3u]];
    ed_w.eng = (uint8_t)ed_eng(TSEL);
    ed_w.preset = TSEL->preset;
    ed_w.sel = song.sel;
    sync_reload = 0;
}
/* the editor's own sound load on the selected track (PRESET, SET of G_ENGSEL): the editor re-reads DUMP after
 * the reply, so the shadow takes the load (engine, preset, the parameters it changed) and no RELOAD echoes back
 * (INFO 53 01 bit 1). A RELOAD already due before it (a load or selection on the device) still goes out. */
typedef struct { int16_t p[P_COUNT]; uint8_t eng, preset, due; } ed_load_t;
static void ed_load_before(ed_load_t *b)
{
    memcpy(b->p, TSEL->p, sizeof b->p);
    b->eng = (uint8_t)ed_eng(TSEL);
    b->preset = TSEL->preset;
    b->due = sync_reload || b->eng != ed_w.eng || b->preset != ed_w.preset || song.sel != ed_w.sel;
}
static void ed_load_after(const ed_load_t *b)
{
    uint32_t i;
    if (!ed_w.on || b->due)
        return;
    sync_reload = 0;
    ed_w.eng = (uint8_t)ed_eng(TSEL);
    ed_w.preset = TSEL->preset;
    for (i = 0; i < P_COUNT; i++)                        /* the load's values; a pending push of another stays */
        if (TSEL->p[i] != b->p[i])
            ed_w.v[i] = TSEL->p[i];
}
static int ed_room(void) { return so_w - so_r + 8u <= SXQ / 2u; }
static void ed_known(uint32_t k, uint32_t id)            /* the editor's own change of trk[k].p[id]: no push */
{
    uint32_t j;
    if (k == song.sel) {
        ed_w.v[id] = trk[k].p[id];
        return;
    }
    for (j = 0; j < 3u; j++)
        if (ED_TIDS[j] == id)
            ed_w.tv[k * 3u + j] = trk[k].p[id];
}

static void ed_sync(void)                                /* main loop */
{
    uint32_t i, n = 0, now = fm1_ms;
    if (!ed_w.on || now - ed_w.run_ms < 5u)
        return;
    ed_w.run_ms = now;
    if (!usb.config || usb.resets != ed_w.resets || now - ed_w.last_ms > 3000u) {
        ed_w.on = 0;                                     /* no host, USB reset, or 3 s without a request */
        return;
    }
    if (sync_reload || ed_eng(TSEL) != ed_w.eng || TSEL->preset != ed_w.preset || song.sel != ed_w.sel) {
        if (!ed_room())
            return;
        ed_shadow();
        ed_begin(ED_RELOAD);
        ed_b(ed_eng(TSEL));
        ed_b(TSEL->preset);
        ed_b(song.sel);
        ed_send();
        return;
    }
    for (i = 0; i < NSTEP && n < ED_PUSH_MAX; i++) {
        uint32_t h = ed_step_sig(&seq_steps(TSEL)[i]);
        if (h == ed_w.st[i])
            continue;
        if (!ed_room())
            return;
        ed_w.st[i] = h;
        ed_begin(ED_STEP_CHANGED);
        ed_b(i);
        ed_b(song.sel);
        ed_send();
        n++;
    }
    for (i = 0; i < ED_NV && n < ED_PUSH_MAX; i++) {    /* round robin: nothing starves */
        uint32_t k = (ed_w.pos + i) % ED_NV;
        int16_t v = *ed_val(k);
        if (v == ed_w.v[k] || (uint16_t)(now - ed_w.t[k]) < 20u)
            continue;                                    /* coalesced: the latest value goes out later */
        if (!ed_room())
            return;
        ed_w.v[k] = v;
        ed_w.t[k] = (uint16_t)now;
        ed_begin(ED_CHANGED);
        ed_b(k < P_COUNT ? 0u : 1u);
        ed_b(k < P_COUNT ? k : k - P_COUNT);
        ed_v(v);
        ed_send();
        n++;
        ed_w.pos = k + 1u;
    }
    for (i = 0; ed_w.v4 && i < ED_NT && n < ED_PUSH_MAX; i++) {   /* v4: the other tracks' mix */
        uint32_t k = (ed_w.tpos + i) % ED_NT, tr = k / 3u, id = ED_TIDS[k % 3u];
        int16_t v = trk[tr].p[id];
        if (tr == song.sel || v == ed_w.tv[k] || (uint16_t)(now - ed_w.tt[k]) < 20u)
            continue;                                    /* (the selected track: CHANGED above) */
        if (!ed_room())
            return;
        ed_w.tv[k] = v;
        ed_w.tt[k] = (uint16_t)now;
        ed_begin(ED_TRACK_CHANGED);
        ed_b(tr);
        ed_b(id);
        ed_v(v);
        ed_send();
        n++;
        ed_w.tpos = k + 1u;
    }
}

/* descriptor of parameter id of track t: the engine parameters of the engine it asked for
 * (t->engine follows in the audio ISR, after a short fade) */
static const param_desc_t *ed_tdesc(const track_t *t, uint32_t id) { return param_desc_of(t->eng_req % NENGINES, id); }
/* descriptor and value slot of (scope, id): scope 0 = the selected track, 1 = global */
static const param_desc_t *ed_desc(uint32_t scope, uint32_t id, int16_t **vp)
{
    if (scope == 0 && id < P_COUNT) {
        *vp = &TSEL->p[id];
        return ed_tdesc(TSEL, id);
    }
    if (scope == 1 && id < G_COUNT) {
        *vp = &song.g[id];
        return &GP[id];
    }
    return 0;
}

/* a step as STEP_SET / TRACK_STEP send it (na bytes): n, 4 notes, time, flags, vel, then (v5) the lane hits
 * and their accents: hit & 127, acc & 127, bit 7 of each (bit 0 hit, bit 1 acc), (v7) the chance, (RATCH, INFO
 * 52 01) the hits 1..4, (NUDGE, INFO 54 01, 1.2) the nudge + 8 (0..15: -8..+7 sixteenths of the step); each value
 * made valid. 8 bytes (an editor of before the grid): the hits stay; without the chance, the ratchet or the nudge
 * the step keeps its own (flags carry accent and slide only). 1.5.5 (#209, INFO 4B 01 0B): then the condition, 0 none,
 * 1..11 (core.h step_cond: it takes the chance's place). Without it a chance of 100 keeps the step's condition (an
 * editor that does not know them saw 100 there and writes it back); another chance replaces it */
static void ed_step_put(step_t *st, const uint8_t *a, uint32_t na)
{
    uint32_t i;
    st->n = (uint8_t)(a[0] > 4u ? 4u : a[0]);
    for (i = 0; i < 4u; i++)
        st->note[i] = a[1 + i] & 0x7Fu;
    st->time = (uint8_t)(a[5] > ST_REST ? ST_REST : a[5]);
    st->flags = (uint8_t)((a[6] & (SF_ACCENT | SF_SLIDE)) | (st->flags & (SF_RATCH | SF_NUDGE)));
    st->vel = a[7] & 0x7Fu;
    if (na >= 11u) {
        st->hit = (uint8_t)((a[8] & 0x7Fu) | (a[10] & 1u) << 7);
        st->acc = (uint8_t)(((a[9] & 0x7Fu) | (a[10] & 2u) << 6) & st->hit);
    }
    if (na >= 15u && a[14] && a[14] <= NCOND) step_set_chance_v(st, 100u + a[14]);
    else if (na >= 12u && (na >= 15u || a[11] < 100u || !step_cond(st))) step_set_chance(st, a[11] <= 100u ? a[11] : 100u);
    if (na >= 13u) step_set_ratchet(st, a[12]);
    if (na >= 14u) step_set_nudge(st, (int32_t)(a[13] & 15u) - 8);
    ui.force = 1;
}
static void ed_step_reply(const step_t *st)              /* the same 15 bytes */
{
    uint32_t i;
    ed_b(st->n);
    for (i = 0; i < 4u; i++)
        ed_b(st->note[i]);
    ed_b(st->time);
    ed_b(st->flags & (SF_ACCENT | SF_SLIDE));
    ed_b(st->vel);
    ed_b(st->hit & 0x7Fu);
    ed_b(st->acc & 0x7Fu);
    ed_b((uint32_t)(st->hit >> 7) | (uint32_t)(st->acc >> 7) << 1);
    ed_b(step_chance(st));
    ed_b(step_ratchet(st));
    ed_b((uint32_t)(step_nudge(st) + 8));
    ed_b(step_cond(st));                                 /* (1.5.5: the chance before it 100) */
}

/* a flash write from the editor while the transport runs: stop it first (the erase silences the audio and
 * stalls the sequencer; the device's own SAVE refuses with "STOP TO SAVE", the editor's confirmed save stops) */
static int ed_flash_stop(void)
{
    uint32_t t0 = fm1_ms;
    if (!transport_busy())
        return 0;
    transport_req = 2;
    while ((song.playing || chain_busy()) && fm1_ms - t0 < 100u)          /* the audio ISR stops it at its next block */
        fm1_wdt_feed();
    return song.playing || chain_busy();
}

#include "editor_preferences.c"
#include "editor_backup.c"
#include "editor_fm6.c"
#include "editor_menu.c"
#include "editor_learn.c"                    /* 1.5: MIDI LEARN's map (cmds 78, 79) */
#include "editor_palette.c"                  /* 1.6: CUSTOM, the user's palette (cmds 80, 81) */

/* MOTION's reply: the records of track k as (step, id, v14), a lock's id without its MOTION_LOCK bit (a 7-bit SysEx
 * byte); kinds (1.1: the ops 5..7): then one byte per record, in the same order, 0 automation, 1 lock. The query and
 * the ops 1..4 reply as before 1.1 (an editor of before reads a lock as an automation event).
 * 1.2 (128 records, INFO 41 01): the query and ops 1..7 reply as before, max 64 and at most the track's first 64
 * records (an editor of before keeps working while a track holds no more); op 8 (full) is the query with the kinds,
 * its count and max two 7-bit bytes each (LSB first): every record */
static void ed_motion_reply(uint32_t k, uint32_t rc, uint32_t kinds, uint32_t full)
{
    track_t *t = &trk[k];
    uint32_t i, n = motion_count(t), cap = full ? MOTION_MAX : 64u, j;
    n = n < cap ? n : cap;
    ed_b(k); ed_b(rc); ed_b(motion_enabled(t));
    if (full) {
        ed_b(n); ed_b(n >> 7); ed_b(MOTION_MAX); ed_b(MOTION_MAX >> 7);
    } else {
        ed_b(n); ed_b(64u);
    }
    for (i = j = 0; i < motion.count && j < n; i++) {
        const motion_event_t *e = &motion.event[i];
        if ((e->place >> 6) != k) continue;
        ed_b(e->place & 63u); ed_b(MOTION_ID(e)); ed_v(e->value);
        j++;
    }
    for (i = j = 0; kinds && i < motion.count && j < n; i++)
        if ((motion.event[i].place >> 6) == k) {
            ed_b((motion.event[i].param & MOTION_LOCK) != 0u);
            j++;
        }
}
static int ed_args_ok(uint32_t cmd, const uint8_t *a, uint32_t n)
{
    switch (cmd) {
    case ED_INFO: case ED_DUMP: case ED_SMP_INFO: case ED_PING:
    case ED_UI_STATE: case ED_UI_PALETTES: case ED_LEARN_GET: case ED_PALETTE_GET:
        return !n;
    case ED_GET: case ED_DESC: case ED_PRESET: case ED_PROJECT: case ED_UP_LIST:
    case ED_TRACK_PARAM:
        return n == 2u || (cmd == ED_TRACK_PARAM && n == 4u);
    case ED_SET:
        return n == 4u;
    case ED_STEP_GET: case ED_NAMES: case ED_SMP_BEGIN: case ED_SMP_ERASE:
    case ED_UP_GET: case ED_UP_LOAD: case ED_UP_ERASE: case ED_WATCH: case ED_TRACK_DUMP: case ED_MENU_DESC:
        return n == 1u;
    case ED_MENU_SET:
        return n == 3u;
    case ED_STEP_SET:
        return n == 9u || n == 12u || (n == 13u && a[12] <= 100u) ||               /* notes only, or the complete grid extension, */
               ((n == 14u || (n == 15u && a[14] <= 15u) || (n == 16u && a[14] <= 15u && a[15] <= NCOND)) &&
                a[12] <= 100u && a[13] >= 1u && a[13] <= 4u);   /* its chance, its ratchet, its nudge (1.2), its
                                                                 * condition (1.5.5) */
    case ED_TRACK:
        return n <= 1u;
    case ED_TRACK_MIX:
        return n == 1u || n == 4u;
    case ED_TRACK_STEP:
        return n == 2u || n == 10u || n == 13u || (n == 14u && a[13] <= 100u) ||
               ((n == 15u || (n == 16u && a[15] <= 15u) || (n == 17u && a[15] <= 15u && a[16] <= NCOND)) &&
                a[13] <= 100u && a[14] >= 1u && a[14] <= 4u);
    case ED_MOTION:
        return (n == 1u || (n == 2u && (a[1] == 2u || a[1] == 7u || a[1] == 8u)) || (n == 3u && a[1] == 1u && a[2] <= 1u) ||
                (n == 6u && (a[1] == 3u || a[1] == 5u)) || (n == 4u && a[1] == 4u) || (n == 3u && a[1] == 6u)) &&
               a[0] < NTRK;
    case ED_SONG:
        return n && (a[0] == 1u || a[0] == 5u || n == 1u);
    default:
        return 1;                                  /* variable payloads validate in their handler */
    }
}

static void ed_handle(const uint8_t *f, uint32_t n)   /* f: the bytes between F0 and F7 */
{
    if (n < 4u)
        return;
    uint32_t cmd = f[3], i;
    const uint8_t *a = f + 4;
    uint32_t na = n - 4u;
    int16_t *vp;
    const param_desc_t *d;
    if (!ed_args_ok(cmd, a, na))
        return;
    if ((cmd >= ED_SMP_BEGIN && cmd <= ED_SMP_INFO) || (cmd >= ED_BACKUP_LIST && cmd <= ED_BACKUP_PUT) ||
        (cmd >= ED_FM6B_BEGIN && cmd <= ED_FM6B_END))
        autosave_hold();                                /* (a transfer: no autosave meanwhile, project.c) */
    ed_begin(cmd);
    if (ed_ui_handle(cmd, a, na)) { ed_send(); return; }
    if (ed_backup_handle(cmd, a, na)) { ed_send(); return; }
    if (ed_fm6_handle(cmd, a, na)) { ed_send(); return; }
    if (ed_menu_handle(cmd, a, na)) { ed_send(); return; }
    if (ed_learn_handle(cmd, a, na)) { ed_send(); return; }
    if (ed_palette_handle(cmd, a, na)) { ed_send(); return; }
    switch (cmd) {
    case ED_MOTION: {
        track_t *t = &trk[a[0]]; uint32_t rc = 0;
        if (na > 1u && a[1] >= 7u) {
            /* (the query with the kinds; 8: all of them, 1.2) */
        } else if (na > 1u && chain_busy()) rc = 3;
        else if (na > 1u) {
            if (a[1] == 1u) motion_set_enabled(t, a[2]);
            else if (a[1] == 2u) { load_begin(t, UNDO_PAT); motion_clear(t); load_end(t); }
            else if (a[1] == 3u) rc = motion_set_event(t, a[2], a[3], (int16_t)ed_rv(a + 4));
            else if (a[1] == 4u && a[2] < NSTEP && motion_param(a[3])) motion_delete_event(t, a[2], a[3]);
            else if (a[1] == 5u) rc = motion_set_lock(t, a[2], a[3], (int16_t)ed_rv(a + 4));
            else if (a[1] == 6u && (a[2] < NSTEP || a[2] == 127u)) (void)motion_clear_locks(t, a[2]);
            else rc = 1;
            ui.force = 1;
        }
        ed_motion_reply(a[0], rc, na > 1u && a[1] >= 5u, na > 1u && a[1] == 8u);
        break;
    }
    case ED_INFO:
        ed_str("GURU-600 " GURU_VERSION " (" FELUCCA_VERSION ")", 24);   /* Guru-600 1.0.2: its own version first, for the
                                                                    * editor's update notice ("FELUCCA ..." before 1.0.2) */
        ed_b(NENGINES);
        ed_b(P_COUNT);
        ed_b(G_COUNT);
        ed_b(NSTEP);
        ed_b(P_E0);
        for (i = 0; i < NENGINES; i++)
            ed_str(ENGINES[i]->name, 8);
        ed_b(NTRK);                                       /* v3 */
        ed_b(CHAIN_ROWS);                                  /* v6 */
        ed_b(0x55); ed_b(1); ed_b(ed_ui_caps());             /* tagged preferences v1: commands 34..38 */
        ed_b(0x4d); ed_b(1); ed_b(64); ed_b(1);   /* motion + chance v1 (64: what it said before 1.2; 41 01 has the real count) */
        ed_b(0x42); ed_b(1); ed_b(3); /* bounded full-backup read + restore */
        ed_b(0x46); ed_b(1); ed_b(FM6_NFACTORY); ed_b(0);   /* FM6 patches: cmds 68..71 (no bank since 1.0.3) */
        ed_b(0x53); ed_b(1); ed_b(3);   /* live sync: bit 0 WATCH while on keeps the shadow, bit 1 no RELOAD echo */
        ed_b(0x50); ed_b(1); ed_b(3);   /* FM6 patches v2: bit 0 no bank (SLOT F1..F8, 8 OWN), bit 1 user preset
                                         * patches (FM6 target 3, backup id 9) */
        ed_b(0x4E); ed_b(1); ed_b(ED_MENU_N);   /* MENU settings: cmds 72, 73; the items MENU_DESC offers */
        ed_b(0x52); ed_b(1); ed_b(4);   /* RATCH: a step's ratchet (1..4 hits) after its chance */
        ed_b(0x4C); ed_b(1); ed_b(1);   /* 1.1 parameter locks: MOTION ops 5..7, the kinds after the records */
        ed_b(0x41); ed_b(1); ed_b(MOTION_MAX); ed_b(MOTION_MAX >> 7);   /* 1.2: 128 motion records, MOTION op 8 */
        ed_b(0x54); ed_b(1); ed_b(NUDGE_DIV);   /* 1.2: a step's nudge (1/16 step) after its ratchet; LFO 2, QNTZ */
        ed_b(0x57); ed_b(1); ed_b(NTRK);   /* 1.2: song sections with a slot per track (SONG ops 4..7) */
        ed_b(0x56); ed_b(1); ed_b(FM6_NBANK);   /* 1.4.1: FM6's voice bank (cmds 74..77; SLOT 9..40 = B1..B32) */
        ed_b(0x43); ed_b(1); ed_b(ML_N);   /* 1.5: MIDI LEARN's map (cmds 78, 79; editor_learn.c) */
        ed_b(0x4B); ed_b(1); ed_b(NCOND);   /* 1.5.5: a step's condition (1..11) after its nudge */
        ed_b(0x45); ed_b(1); ed_b(ED_PAL_N);   /* 1.6: CUSTOM, the user's palette: 5 colours (cmds 80, 81; editor_palette.c) */
        break;
    case ED_GET:
    case ED_SET:
        if (na < 2u || !(d = ed_desc(a[0], a[1], &vp)))
            return;
        if (cmd == ED_SET && na >= 4u && !(chain_busy() && !a[0] && chain_owns(a[1]))) {
            if (a[0] == 1 && a[1] == G_ENGSEL) {          /* engine change: the safe path (1 without FELUCCA_FM4:
                                                           * DIGITAL's first preset, as FM6) */
                ed_load_t b;
                ed_load_before(&b);
                set_engine((uint32_t)clamp(ed_rv(a + 2), 0, NENGINES - 1));
                ed_load_after(&b);
            } else if (d->max > d->min) {
                *vp = (int16_t)enum_orig(d, clamp(ed_rv(a + 2), d->min, d->max));
                if (a[0] == 0) {
                    (void)motion_capture(TSEL, a[1], *vp);
                    load_extend(TSEL);                      /* (ui.c undo: an audition's values after G_ENGSEL) */
                }
            }
            ui.force = 1;
            ed_w.v[a[0] ? P_COUNT + a[1] : a[1]] = *vp;   /* the editor's own change: no push */
        }
        ed_b(a[0]);
        ed_b(a[1]);
        ed_v(*vp);
        break;
    case ED_DUMP:
        for (i = 0; i < ED_NV; i++)                       /* the editor gets them all here */
            ed_w.v[i] = *ed_val(i);
        ed_b(ed_eng(TSEL));
        ed_b(TSEL->preset);
        for (i = 0; i < P_COUNT; i++)
            ed_v(motion_base_value(TSEL, i));
        for (i = 0; i < G_COUNT; i++)
            ed_v(song.g[i]);
        break;
    case ED_DESC:
        if (na < 2u || !(d = ed_desc(a[0], a[1], &vp)))
            return;
        ed_b(a[0]);
        ed_b(a[1]);
        ed_b(d->fmt);
        ed_v(d->min);
        ed_v(d->max);
        ed_v(d->def);
        ed_str(d->label, 8);
        ed_str(d->unit, 8);
        if (d->fmt == F_ENUM && d->names)                  /* up to 24 (the matrix DST has 20) */
            for (i = 0; i <= (uint32_t)(d->max - d->min) && i < 24u; i++)
                ed_str(d->names[i], 8);
        break;
    case ED_STEP_GET:
    case ED_STEP_SET: {
        step_t *st;
        if (na < 1u || a[0] >= NSTEP)
            return;
        st = &TSEL->step[a[0]];
        if (cmd == ED_STEP_SET && na >= 9u && !chain_busy()) {
            ed_step_put(st, a + 1, na - 1u);
        }
        ed_w.st[a[0]] = ed_step_sig(&seq_steps(TSEL)[a[0]]);
        ed_b(a[0]);
        ed_step_reply(&seq_steps(TSEL)[a[0]]);
        break;
    }
    case ED_PRESET: {                                      /* engine, preset */
        ed_load_t b;
        if (na < 2u || a[0] >= NENGINES)
            return;
        ed_load_before(&b);
#if !FELUCCA_FM4
        if (a[0] == ENGI_DIGITAL)                          /* a DIGITAL preset (retired): its sound, as FM6 */
            fm4_load_preset(TSEL, a[1]);
        else
#endif
        {
            if (a[0] != TSEL->eng_req)
                set_engine(a[0]);
            apply_preset(a[1]);
        }
        ed_load_after(&b);
        ui.force = 1;
        ed_b(ed_eng(TSEL));
        ed_b(TSEL->preset);
        break;
    }
    case ED_PROJECT:                                       /* 0 = load, 1 = save, 2 = query; slot 0..3 */
        if (na < 2u || a[0] > 2u || a[1] >= 4u)
            return;
        if (a[0] == 1u) {
            if (ed_flash_stop() || project_save(a[1]))
                return;                              /* the legacy reply has no failure bit: do not confirm a failed save */
        }
        else if (a[0] == 0u)
            project_load(a[1] & 3u);
        ed_b(a[0]);
        ed_b(a[1] & 3u);
        ed_b(project_used(a[1] & 3u));
        break;
    case ED_NAMES:                                         /* preset names of an engine */
        if (na < 1u || a[0] >= NENGINES)
            return;
        ed_b(a[0]);
        ed_b(ENGINES[a[0]]->npresets);
        for (i = 0; i < ENGINES[a[0]]->npresets; i++)
            ed_str(ENGINES[a[0]]->presets[i].name, 12);
        for (i = 0; i < 2u; i++)                           /* then the two edit-page titles */
            ed_str(ENGINES[a[0]]->page_title[i], 8);
        break;
    case ED_SMP_BEGIN:                                     /* slot -> slot, rc */
    case ED_SMP_ERASE:
        if (na < 1u || a[0] >= SMP_USER_SLOTS || !flash_ok)
            return;
        ed_b(a[0]);
        ed_b(ed_flash_stop() || ed_smp_erase(a[0], cmd == ED_SMP_ERASE) ? 1u : 0u);
        break;
    case ED_SMP_WRITE: {                                   /* slot, off (3 x 7 bit), pack7 data -> slot, off, rc */
        uint32_t off, len, rc = 0, took;
        if (na < 5u || a[0] >= SMP_USER_SLOTS || !flash_ok)
            return;
        off = (uint32_t)a[1] | (uint32_t)a[2] << 7 | (uint32_t)a[3] << 14;
        len = ed_unpack7(a + 4, na - 4u, ed_smp_buf, 256u);
        if (off < SMP_USER_DATA || (off & 0xFFu) || !len || off + len > SMP_SLOT_END(a[0]))
            rc = 1;
        else if (usr_nz[a[0]])
            rc = 4;                                        /* slot in use: SMP_BEGIN first (voices read it) */
        else if (ed_flash_stop())
            rc = 1;
        else {
            if (!(off & 0xFFFu)) {                         /* first write into a sector: erase it */
                audio_silence();
                rc = fl_erase4k(ed_smp_slot(a[0]) + off, &took) ? 2u : 0u;
            }
            if (!rc && fl_write(ed_smp_slot(a[0]) + off, ed_smp_buf, len))
                rc = 3;
        }
        ed_b(a[0]);
        ed_b(off);
        ed_b(off >> 7);
        ed_b(off >> 14);
        ed_b(rc);
        break;
    }
    case ED_SMP_END:                                       /* slot, pack7 header -> slot, rc */
        if (na < 2u || a[0] >= SMP_USER_SLOTS || !flash_ok)
            return;
        ed_b(a[0]);
        ed_b((uint32_t)ed_smp_end(a[0], a + 1, na - 1u));
        break;
    case ED_SMP_INFO:                                      /* -> per slot: zones (0 = empty), name, data KiB */
        ed_b(SMP_USER_SLOTS);
        ed_b(SMP_USER_SIZE / 1024u);
        for (i = 0; i < SMP_USER_SLOTS; i++) {
            const smp_user_hdr_t *h = (const smp_user_hdr_t *)smp_user_xip(i);
            char nm[9] = {0};
            uint32_t j;
            ed_b(usr_nz[i]);
            for (j = 0; usr_nz[i] && j < 8u; j++)
                nm[j] = h->name[j] >= 32 && h->name[j] < 127 ? h->name[j] : 0;
            ed_str(nm, 8);
            ed_b(usr_nz[i] ? (h->data_len + 1023u) / 1024u : 0u);
        }
        break;
    case ED_UP_LIST: {                                     /* start, count -> start, count, total, per slot: used, engine, name;
                                                            * (1.2) then per slot its category (category.c CAT_*, 0 unused):
                                                            * after the entries, so an older editor stops before them */
        uint32_t s0, cnt;
        if (na < 2u)
            return;
        s0 = a[0];
        cnt = a[1] > 16u ? 16u : a[1];
        if (s0 >= UP_SLOTS)
            cnt = 0;
        else if (s0 + cnt > UP_SLOTS)
            cnt = UP_SLOTS - s0;
        ed_b(s0);
        ed_b(cnt);
        ed_b(UP_SLOTS);
        for (i = s0; i < s0 + cnt; i++) {
            char nm[13] = {0};
            uint32_t j, u = (uint32_t)up_used(i);
            for (j = 0; u && j < 12u; j++)
                nm[j] = up_rec(i)->name[j];
            ed_b(u);
            ed_b(u ? up_rec(i)->engine : 0u);
            ed_str(nm, 12);
        }
        for (i = s0; i < s0 + cnt; i++)
            ed_b(up_used(i) ? up_cat(i) : 0u);
        break;
    }
    case ED_UP_GET: {                                      /* slot -> slot, used, engine, name, P_COUNT x v14, 16 x (note,
                                                            * flags), (v5) kind [, 16 x hi], (1.2) category
                                                            * (upreset.c up_parse) */
        int16_t v[P_COUNT];
        char nm[13] = {0};
        const up_rec_t *r;
        uint32_t u;
        if (na < 1u || a[0] >= UP_SLOTS)
            return;
        r = up_rec(a[0]);
        u = (uint32_t)up_used(a[0]);
        if (u)
            up_values(r, v);                               /* today's P_* order, clamped */
        for (i = 0; u && i < 12u; i++)
            nm[i] = r->name[i];
        ed_b(a[0]);
        ed_b(u);
        ed_b(u ? r->engine : 0u);
        ed_str(nm, 12);
        for (i = 0; i < P_COUNT; i++)
            ed_v(u ? v[i] : 0);
        for (i = 0; i < 16u; i++) {
            ed_b(u ? r->note[i] & 0x7Fu : 0u);
            ed_b(u ? r->flags[i] & 0x7Fu : 0u);
        }
        ed_b(u && up_grid(r));                  /* kind: 1 = a drum grid, then bit 7 of each step's */
        for (i = 0; u && up_grid(r) && i < 16u; i++)   /* hits (bit 0) and accents (bit 1) */
            ed_b((uint32_t)(r->note[i] >> 7) | (uint32_t)(r->flags[i] >> 7) << 1);
        ed_b(u ? up_cat_of(r) : 0u);            /* 1.2: the category (an older editor stops before it) */
        break;
    }
    case ED_UP_PUT: {                                      /* slot, engine, name, values, pattern -> slot, rc */
        static up_rec_t r;
        uint32_t slot = 0, rc;
        if (na < 1u)
            return;
        rc = (uint32_t)up_parse(a, na, &r, &slot);
        if (!rc && ed_flash_stop())
            rc = 2;
        if (!rc) {
            int16_t v[P_COUNT];
            up_values(&r, v);                              /* each value inside its range */
            for (i = 0; i < P_COUNT; i++)
                up_set_value(&r, i, v[i]);                 /* the record's own form (v4: a byte each) */
            rc = up_put(slot, &r) ? 2u : 0u;
        }
        ed_b(a[0]);
        ed_b(rc);
        break;
    }
    case ED_UP_STORE: {                                    /* slot, name -> slot, rc */
        char nm[13] = {0};
        uint32_t n0, rc = 1;
        if (na < 1u)
            return;
        for (n0 = 0; 1u + n0 < na && a[1 + n0] && n0 < 13u; n0++)
            ;
        if (a[0] < UP_SLOTS && (!n0 || up_name_ok(a + 1, n0)) &&
            (1u + n0 == na || (2u + n0 == na && !a[1u + n0]))) {   /* "" = automatic name */
            for (i = 0; i < n0; i++)
                nm[i] = (char)a[1 + i];
            int r;
            r = ed_flash_stop() ? 2 : up_store(a[0], nm);
            rc = r ? 2u : 0u;
        }
        ed_b(a[0]);
        ed_b(rc);
        break;
    }
    case ED_UP_LOAD:                                       /* slot -> slot, rc */
        if (na < 1u)
            return;
        ed_b(a[0]);
        ed_b(a[0] < UP_SLOTS && !up_load(a[0]) ? 0u : 1u);
        break;
    case ED_UP_ERASE:
        if (na < 1u)
            return;
        ed_b(a[0]);
        ed_b(a[0] >= UP_SLOTS ? 1u : ed_flash_stop() || up_put(a[0], 0) ? 2u : 0u);
        break;
    case ED_WATCH: {                                       /* on -> on */
        uint32_t keep, v4was = ed_w.v4;
        if (na < 1u)
            return;
        keep = ed_w.on && ed_w.resets == usb.resets && (a[0] & 1u);   /* already watching: the changes not yet */
        ed_w.on = a[0] & 1u;                                          /* pushed stay pending (INFO 53 01 bit 0) */
        ed_w.v4 = (uint8_t)(ed_w.on && (a[0] & 2u));     /* v4: also TRACK_CHANGED; the reply says it is known */
        ed_w.resets = usb.resets;
        if (ed_w.on && !keep)
            ed_shadow();
        else if (keep && ed_w.v4 && !v4was)
            for (i = 0; i < ED_NT; i++)                    /* TRACK_CHANGED newly asked for: from the mix as it is */
                ed_w.tv[i] = trk[i / 3u].p[ED_TIDS[i % 3u]];
        ed_b(ed_w.on | ed_w.v4 << 1);
        break;
    }
    case ED_PING:
        ed_b(0);
        break;
    case ED_TRACK:                                         /* [track] -> selected, NTRK, per track: engine, preset, level, mute, armed */
        if (na >= 1u && a[0] < NTRK && a[0] != song.sel) {
            track_select(a[0]);
            if (ed_w.on)
                ed_shadow();                               /* the editor re-reads it: no RELOAD for this */
        }
        ed_b(song.sel);
        ed_b(NTRK);
        for (i = 0; i < NTRK; i++) {
            ed_b(ed_eng(&trk[i]));
            ed_b(trk[i].preset);
            ed_v(trk[i].p[P_LEVEL]);
            ed_b(trk[i].p[P_MUTE] != 0);
            ed_b((song.rec >> i) & 1u);
        }
        break;
    case ED_TRACK_MIX: {                                   /* track [, level v14, mute] -> track, level, mute */
        track_t *t;
        int16_t *lv;
        if (na < 1u || a[0] >= NTRK)
            return;
        t = &trk[a[0]];
        lv = &t->p[P_LEVEL];
        if (na >= 4u) {
            *lv = (int16_t)clamp(ed_rv(a + 1), 0, 127);
            t->p[P_MUTE] = (int16_t)(a[3] ? 1 : 0);
            ed_known(a[0], P_LEVEL);                       /* the editor's own change: no push */
            ed_known(a[0], P_MUTE);
            ui.force = 1;
        }
        ed_b(a[0]);
        ed_v(*lv);
        ed_b(t->p[P_MUTE] != 0);
        break;
    }
    case ED_TRACK_DUMP:                                    /* track -> track, engine, preset, P_COUNT x v14 */
        if (na < 1u || a[0] >= NTRK)
            return;
        ed_b(a[0]);
        ed_b(ed_eng(&trk[a[0]]));
        ed_b(trk[a[0]].preset);
        for (i = 0; i < P_COUNT; i++)
            ed_v(motion_base_value(&trk[a[0]], i));
        break;
    case ED_TRACK_STEP: {                                  /* track, index [, step] -> track, index, step (as STEP_GET) */
        step_t *st;
        if (na < 2u || a[0] >= NTRK || a[1] >= NSTEP)
            return;
        st = &trk[a[0]].step[a[1]];
        if (na >= 10u && !chain_busy())
            ed_step_put(st, a + 2, na - 2u);
        if (a[0] == song.sel)
            ed_w.st[a[1]] = ed_step_sig(&seq_steps(&trk[a[0]])[a[1]]);
        ed_b(a[0]);
        ed_b(a[1]);
        ed_step_reply(&seq_steps(&trk[a[0]])[a[1]]);
        break;
    }
    case ED_TRACK_PARAM: {                                 /* track, id [, v14] -> track, id, v14 */
        track_t *t;
        if (na < 2u || a[0] >= NTRK || a[1] >= P_COUNT)
            return;
        t = &trk[a[0]];
        d = ed_tdesc(t, a[1]);
        if (na >= 4u && !(chain_busy() && chain_owns(a[1]))) {
            if (d->max > d->min)                           /* as SET: clamped; a fixed value stays */
                t->p[a[1]] = (int16_t)enum_orig(d, clamp(ed_rv(a + 2), d->min, d->max));
            (void)motion_capture(t, a[1], t->p[a[1]]);
            ed_known(a[0], a[1]);
            ui.force = 1;
        }
        ed_b(a[0]);
        ed_b(a[1]);
        ed_v(t->p[a[1]]);
        break;
    }
    case ED_SONG: {                                     /* ops 0..3 rows of one slot (v6); 4..7 the same with a slot
                                                         * per track (1.2, `57 01`) */
        uint32_t rc = 0, op, lanes, w, k;
        chain_config_t c;
        if (!na || a[0] > 7u) return;
        op = a[0] & 3u;
        lanes = a[0] >> 2;
        w = lanes ? NTRK + 1u : 2u;                     /* the bytes of a row */
        if (op == 1u) {
            chain_defaults(&c);
            if (na < 2u || a[1] > CHAIN_ROWS || na != 2u + w * a[1]) rc = 1;
            else {
                c.count = a[1];
                for (i = 0; i < c.count; i++) {
                    const uint8_t *r = a + 2u + w * i;
                    if (lanes) {
                        memcpy(c.row[i].slot, r, NTRK);
                        c.row[i].repeat = r[NTRK];
                    } else if (r[0] < 4u)       /* (a row of one slot: all four tracks on it) */
                        c.row[i] = chain_row_of(r[0], r[1]);
                    else
                        c.row[i].repeat = 0;    /* (invalid) */
                }
                if (!chain_valid(&c)) rc = 1;
                else if (chain_busy()) rc = 2;
                else { chain_config = c; ui.song_row = 0; ui.force = 1; }
            }
        } else if (op == 2u) rc = chain_prepare();
        else if (op == 3u) transport_req = 2;
        ed_b(a[0]); ed_b(rc); ed_b(chain_config.count);
        ed_b(chain.running); ed_b(chain.row); ed_b(chain.remaining);
        for (i = 0; i < chain_config.count; i++) {
            const chain_row_t *r = &chain_config.row[i];
            if (lanes)
                for (k = 0; k < NTRK; k++) ed_b(r->slot[k]);
            else                                         /* v6: the clock track's slot (every track "-": A) */
                ed_b(r->slot[chain_clock(r)] < 4u ? r->slot[chain_clock(r)] : 0u);
            ed_b(r->repeat);
        }
        break;
    }
    default:
        return;
    }
    ed_send();
}

#if FELUCCA_P600
/* Guru-600: the P600 editor's frames, F0 7D 47 36 cmd .. F7 (p600/editeur). The places are 0..254 in two 7-bit bytes,
 * which the Felucca frames (PRESET, NAMES: one byte, 12-letter names, a 664-byte reply) cannot carry:
 *   6 dest dest2       SAVE: the selected track's sound into the place (SAVE > PLACE) -> 6 dest dest2 rc (0 kept,
 *                      1 memory full, 2 the track is not P600)
 *   7 dest dest2 name  RENAME: a kept place's name (ASCII, 11 letters at most) -> 7 dest dest2 rc (0 renamed, 1 memory
 *                      full, 3 a factory sound: save it first)
 *   8 start start2 k   NAMES: k (1..16) places from start -> 8 start start2 k, per place kept (0 / 1) and its name
 *   9 dest dest2       LOAD: the place's sound on the selected track (P600 first if it is not) -> 9 dest dest2 0
 *   10                 STATE -> 10 selected track, engine, preset preset2 (P600's place), kept (0 / 1)
 *   11 b b2 pos        MORPH (EDIT > MORPH): the selected track's sound from A to place b's, pos 0..100 -> 11 b b2 pos rc
 *                      (0, 2 not P600)
 *   12 amt             MUTATE: its amount (1..127, 40 at first), then a variant of the sound -> 12 amt rc (0, 2 not P600)
 *   13                 MORPH's state -> 13 b b2 pos amt
 *   14 (push)          the beat while watched: 14 playing beat armed step (ed_p6_beat)
 *   17 R E S E T        FACTORY: everything of the user's erased, the chip restarts (no answer; project.c factory_reset)
 *   16 tool h s r      TOOL: SEQ TOOLS' action on the selected track (ui_tools.c TL_*: 0 CLEAR, 1 REVERSE, 2 SHIFT <, 3 SHIFT >,
 *                      4 RANDOM, 5 COOK, 6 BEAT, 7 EUCLID with h hits over s steps turned by r, 12 DOUBLE, 13 HALF) -> 16 tool rc (0 done,
 *                      1 nothing done, 2 no tools in this build); then the editor reads the steps (and LEN) again
 *   15 op              TRANSPORT: 0 query, 1 PLAY (as the button: stops what plays), 2 STOP, 3 REC (as a tap: the
 *                      selected track armed or not) -> 15 playing (0 / 1) armed (the tracks armed, bit per track)
 * 1 (import into a place), 2 (RESET SOUNDS) and 3 (forget a place) answer 1 / 2 / 3 dest dest2 rc (ed_service). 1 = handled */
static uint8_t ed_p6o[16u + 16u * 17u];
static uint32_t ed_p6h(uint32_t c)                          /* the answer's head F0 7D 47 36 c into ed_p6o: its length */
{
    ed_p6o[0] = 0xF0; ed_p6o[1] = 0x7D; ed_p6o[2] = 0x47; ed_p6o[3] = 0x36; ed_p6o[4] = (uint8_t)c;
    return 5u;
}
static void ed_p6s(uint32_t k)                              /* ... F7 and sent */
{
    ed_p6o[k++] = 0xF7;
    (void)ota_wire_send(ed_p6o, k);
}
static int ed_p6(const uint8_t *f, uint32_t n)
{
    uint8_t *o = ed_p6o;
    uint32_t c = f[3], d = n >= 6u ? (uint32_t)f[4] | (uint32_t)f[5] << 7 : 0u, k, i, r = 0, p6 = ed_eng(TSEL) == ENGI_P600;
    if (c < 6u || c == 14u || c > 17u)
        return 0;
    if (c == 17u) {                                        /* FACTORY: MENU > SYSTEM > RESET GURU-600 (project.c), only */
        if (n >= 9u && !memcmp(f + 4, "RESET", 5))         /* with its word (the editor asked twice); the chip restarts */
            factory_reset();
        return 1;
    }
    if (c == 16u ? n < 8u : c == 15u ? n < 5u || f[4] > 3u : c == 12u ? n < 5u || !f[4] : c != 10u && c != 13u && (n < 6u || d > (c == 11u ? 254u + UP_SLOTS : 254u) || (c == 8u && (n < 7u || !f[6] || f[6] > 16u)) ||
                                                    (c == 11u && (n < 7u || f[6] > 100u))))
        return 1;                                          /* (malformed: no answer, as the Felucca frames) */
    k = ed_p6h(c);
    if (c == 10u) {
        o[k++] = (uint8_t)song.sel;
        o[k++] = (uint8_t)ed_eng(TSEL);
        d = TSEL->preset;
        r = p6 && p6_find(d) >= 0;
    } else if (c == 13u) {
        d = ui.mph_b;
    } else if (c >= 12u) {
        o[k++] = f[4];
        if (c == 12u) {                                    /* MUTATE */
            ui.mph_amt = f[4];
            if (p6) mph_mutate(); else r = 2;
        } else if (c == 16u) {                             /* TOOL */
#ifdef ED_TOOLS
            r = (uint32_t)ed_tool(f[4], f[5], f[6], f[7]);
#else
            r = 2;
#endif
        } else {                                           /* TRANSPORT */
            if (f[4] == 1u)
                transport_req = song.playing || chain_busy() || seq_counting() ? 2u : 1u;
            else if (f[4] == 2u)
                transport_req = 2u;
            else if (f[4] == 3u && !chain_busy()) {    /* REC as the button's tap (ui_input.c rec_tap): arming while */
                song.rec ^= (uint8_t)(1u << song.sel); /* stopped starts the transport (live recording) */
                ui.force = 1;
                if ((song.rec >> song.sel) & 1u && !song.playing && !seq_counting())
                    transport_req = 1;
            }
            o[k - 1u] = song.playing ? 1u : 0u;        /* (what was asked lands with the next audio block) */
            r = song.rec & 0x7Fu;
        }
        o[k++] = (uint8_t)r;
        ed_p6s(k);
        return 1;
    }
    o[k++] = (uint8_t)(d & 0x7Fu);
    o[k++] = (uint8_t)(d >> 7);
    if (c == 13u) {
        o[k++] = ui.mph_trk == song.sel + 1u && TSEL->preset == ui.mph_apre && TSEL->user == ui.mph_auser ? ui.mph_pos : 0u;
        r = ui.mph_amt ? ui.mph_amt : 40u;
    } else if (c == 11u) {                                 /* MORPH */
        o[k++] = f[6];
        if (p6) { mph_set(d, f[6]); ui.force = 1; } else r = 2;
    } else if (c == 8u) {                                  /* NAMES */
        uint32_t cnt = d + f[6] > 255u ? 255u - d : f[6];
        o[k++] = (uint8_t)cnt;
        for (i = d; i < d + cnt; i++) {
            const char *s = p6_ram[i].name ? p6_ram[i].name : "";
            uint32_t j;
            o[k++] = p6_find(i) >= 0 ? 1u : 0u;
            for (j = 0; s[j] && j < 15u; j++)
                o[k++] = (uint8_t)(s[j] & 0x7F);
            o[k++] = 0;
        }
        ed_p6s(k);
        return 1;
    } else if (c == 9u) {                                  /* LOAD */
        ed_load_t b;
        ed_load_before(&b);
        if (!p6)
            set_engine(ENGI_P600);
        apply_preset(d);
        ed_load_after(&b);
        ui.force = 1;
    } else if (c == 7u) {                                  /* RENAME */
        r = p600_rename(d, f + 6, n - 6u);
        ui.force = 1;
    } else if (c == 6u) {                                  /* SAVE */
        if (!p6) {
            r = 2;
        } else if ((p600_store_track(TSEL, d) & 0xF00u) == P6SX_KEPT) {
            TSEL->preset = (uint8_t)d;
            ed_w.preset = (uint8_t)d;                  /* (the editor knows: no RELOAD echoes back) */
            ui_say("SAVED ", p6_ram[d].name ? p6_ram[d].name : "");
        } else {
            r = 1;
        }
    }
    o[k++] = (uint8_t)r;
    ed_p6s(k);
    return 1;
}
#endif

#if FELUCCA_P600
/* Guru-600: the beat, pushed while watched (the editor's BPM pulse, its PLAY and REC, its playhead): F0 7D 47 36 14 playing
 * (0 / 1) beat (0..3: the bar's beats as the metronome and the ARP LED count them, seq.c beat_n) armed (song.rec) step (the
 * one the selected track plays, 0..63) F7, when one of them changes */
static uint8_t ed_p6b[4] = {0xFFu};
static void ed_p6_beat(void)
{
    uint8_t v[4];
    uint32_t k;
    if (!ed_w.on) {
        ed_p6b[0] = 0xFFu;
        return;
    }
    v[0] = song.playing ? 1u : 0u;
    v[1] = v[0] ? (uint8_t)(beat_n & 3u) : 0u;
    v[2] = (uint8_t)(song.rec & 0x7Fu);
    v[3] = v[0] ? (uint8_t)(TSEL->seq_idx & 0x3Fu) : 0u;
    if (!memcmp(v, ed_p6b, 4u) || !ed_room())
        return;
    memcpy(ed_p6b, v, 4u);
    k = ed_p6h(14u);
    memcpy(ed_p6o + k, v, 4u);
    ed_p6s(k + 4u);
}
/* Guru-600 1.3.1: PLAY push, while watched: F0 7D 47 36 18 (kind track a b)... F7, 8 at most a frame, what a MIDI keyboard
 * plays (midi_control.c play_*): kind 0 a note (a = note, b = velocity, 0: off), 1 the bend (a, b: its 14 bits, low then
 * high), 2 the wheel (a = 0..127). The FM-1's own keys are not in it: they go out as notes (seq.c key_on). */
static void ed_p6_play(void)
{
    uint32_t k = 0, n = 0, tr;
    if (!ed_w.on) {                                        /* (not watched: forgotten) */
        play_qr = play_qw;
        for (tr = 0; tr < NTRK; tr++)
            play_bend_new[tr] = play_wheel_new[tr] = 0;
        return;
    }
    if (!ed_room())
        return;
    k = ed_p6h(18u);
    while (n < 8u && play_qr != play_qw) {
        uint32_t v = play_q[play_qr % PLAYQ];
        play_qr = (uint8_t)(play_qr + 1u);
        ed_p6o[k++] = 0;
        ed_p6o[k++] = (uint8_t)(v >> 16);
        ed_p6o[k++] = (uint8_t)((v >> 8) & 0x7Fu);
        ed_p6o[k++] = (uint8_t)(v & 0x7Fu);
        n++;
    }
    for (tr = 0; tr < NTRK && n < 8u; tr++) {
        if (play_bend_new[tr]) {
            uint32_t b;
            play_bend_new[tr] = 0;
            b = play_bend[tr];
            ed_p6o[k++] = 1;
            ed_p6o[k++] = (uint8_t)tr;
            ed_p6o[k++] = (uint8_t)(b & 0x7Fu);
            ed_p6o[k++] = (uint8_t)((b >> 7) & 0x7Fu);
            n++;
        }
        if (play_wheel_new[tr] && n < 8u) {
            play_wheel_new[tr] = 0;
            ed_p6o[k++] = 2;
            ed_p6o[k++] = (uint8_t)tr;
            ed_p6o[k++] = (uint8_t)(play_wheel[tr] & 0x7Fu);
            ed_p6o[k++] = 0;
            n++;
        }
    }
    if (n)
        ed_p6s(k);
}
#endif

/* main loop: editor frames first; anything else stays for ota_service() */
static void ed_service(void)
{
    const uint8_t *p;
    uint32_t n;
    if (ota_frame_get(&p, &n) && ann_frame(p, n, fm1_ms)) /* Guru-600 1.1: the screen reader's (ui_announce.c) */
        ota_frame_done();
    ann_tick(fm1_ms);
    ed_sync();                                             /* v2 pushes (while watched) */
#if FELUCCA_P600
    ed_p6_beat();                                          /* (Guru-600: the beat) */
    ed_p6_play();                                          /* (Guru-600 1.3.1: a MIDI keyboard's playing) */
#endif
#if FELUCCA_P600
    if (ota_frame_get(&p, &n) && n >= 4u && p[0] == 0x7Du && p[1] == 0x47u && p[2] == 0x36u && ed_p6(p, n)) {
        ed_w.last_ms = fm1_ms;                             /* (they keep WATCH alive too) */
        ota_frame_done();                                  /* Guru-600: the editor's P600 frames (ed_p6) */
        return;
    }
    if (ota_frame_get(&p, &n) && n >= 4u && !(p[0] == ED_HDR0 && p[1] == ED_HDR1 && p[2] == ED_HDR2)) {
        uint32_t s = p600_sysex(p, n);                     /* a Prophet-600 program: into P600's IMPORT bank */
        if (s) {
            uint32_t c = p[0] == 0x7Du && p[1] == 0x47u && p[2] == 0x36u ? p[3] : 0u;
            ota_frame_done();
            if (c == 1u || c == 2u || c == 3u) {           /* Guru-600: the editor's import, reset, forget get an answer */
                uint32_t d = (s & 0xF00u) == P6SX_FULL ? 255u : s & 0xFFu, k = ed_p6h(c);
                ed_p6o[k++] = (uint8_t)(d & 0x7Fu);
                ed_p6o[k++] = (uint8_t)(d >> 7);
                ed_p6o[k++] = d == 255u;
                ed_p6s(k);
            }
            if ((s & 0xF00u) == P6SX_EXPORT || (s & 0xF00u) == P6SX_LIST) {   /* Guru-600: the answer, to the page */
                static uint8_t o[6u + 2u * P6_NIMP + 1u > 60u ? 6u + 2u * P6_NIMP + 1u : 60u];
                (void)ota_wire_send(o, (s & 0xF00u) == P6SX_EXPORT ? p600_export(s & 0xFFu, o) : p600_list(o));
                return;
            }
            if ((s & 0xF00u) == P6SX_KEPT) {                  /* (the kept name begins with its place: once) */
                ui_say("RECEIVED ", p6_ram[s & 0xFFu].name ? p6_ram[s & 0xFFu].name : "");
            } else {
                ui_message((s & 0xF00u) == P6SX_FULL ? "P600: NO FREE PLACE" :
                           (s & 0xF00u) == P6SX_RESET ? "SOUNDS RESET" : "P600 PLACE CLEARED");
            }
            return;
        }
    }
#endif
    if (!ota_frame_get(&p, &n) || n < 4u || p[0] != ED_HDR0 || p[1] != ED_HDR1 || p[2] != ED_HDR2)
        return;
    ed_w.last_ms = fm1_ms;                                 /* any request keeps WATCH alive */
    if (p[3] >= ED_SMP_BEGIN) {                            /* large frames: handled in place, then freed */
        ed_handle(p, n);
        ota_frame_done();
        return;
    }
    {
        static uint8_t f[64];
        uint32_t k = n > sizeof f ? sizeof f : n, i;
        for (i = 0; i < k; i++)
            f[i] = p[i];
        ota_frame_done();                                  /* free the frame buffer before replying */
        ed_handle(f, k);
    }
}
