Guru-600 1.4.0 for the BBL Mod Swapper

Original by MarcGoudy: https://github.com/MarcGoudy/guru-600
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: GURU600-source.zip on the ports page.
