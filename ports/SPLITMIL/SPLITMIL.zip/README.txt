SPLITMILK 1.0 for the BBL Mod Swapper

Original by MammothCheese: https://github.com/MammothCheese/SPLITMILK
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: SPLITMIL-source.zip on the ports page.
