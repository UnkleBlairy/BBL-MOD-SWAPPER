/* SPDX-License-Identifier: GPL-3.0-only */
/* zp12 simulator: the flash is 1 MiB of RAM (sim_flash); the XIP window points into it */
#pragma once
#include <stdint.h>
#include "fm1_cc.h"
#define SIM_FL_LO 0x97000u
#define SIM_FL_N 0x69000u
#ifdef TEENSY_NOR_ADDR                  /* teensy-fm1: real flash, in this ROM's slot: from 0x97000 */
extern int32_t teensy_nor_erase(uint32_t off);
extern int32_t teensy_nor_prog(uint32_t off, const uint8_t *src, uint32_t n);
#define sim_flash ((uint8_t *)TEENSY_NOR_ADDR - SIM_FL_LO)
#else
static uint8_t sim_flash_[SIM_FL_N];
#define sim_flash (sim_flash_ - SIM_FL_LO)
#endif
#define FM1_XIP(off) ((uintptr_t)(sim_flash + ((uint32_t)(off) & 0xFFFFFu)))
FM1_INLINE const uint8_t *fm1_xip_ptr(uint32_t off) { return (const uint8_t *)FM1_XIP(off); }
