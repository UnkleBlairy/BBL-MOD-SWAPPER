#ifdef __arm__
#undef __UINT32_TYPE__
#undef __INT32_TYPE__
#define __UINT32_TYPE__ unsigned int
#define __INT32_TYPE__ int
#endif
/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: ZP-12 2.5 (https://github.com/zvenson/zp12) on the Teensy 4.1: its own browser build (sim/sim.c) inside ports/common's shell */
#include "../../../common/shell_pre.h"
#include <stdlib.h>
#include <time.h>
#ifndef CLOCK_MONOTONIC
#define CLOCK_MONOTONIC 1
static int clock_gettime(int c, struct timespec *t) { (void)c; t->tv_sec = 0; t->tv_nsec = 0; return 0; }
#endif
#define getenv(n) ((char *)0)
#define CO_STACK 24576u
#include "../../../common/coro.h"
#define ZP12_VER "2.5"
#define web_boot o_web_boot
#define web_out_l o_web_out_l
#define web_out_r o_web_out_r
#define web_render o_web_render
#define web_buttons o_web_buttons
#define web_keys o_web_keys
#define web_enc o_web_enc
#define web_master o_web_master
#define web_nor_erase o_web_nor_erase
#define web_ms o_web_ms
#define web_frame o_web_frame
#include "../../sim/sim.c"
#undef __attribute__
#undef EXPORT
#undef memset
#undef memcpy
#undef memcmp
#undef memmove
#undef web_boot
#undef web_out_l
#undef web_out_r
#undef web_render
#undef web_buttons
#undef web_keys
#undef web_enc
#undef web_master
#undef web_nor_erase
#undef web_ms
#undef web_frame
#define SH_FLOAT
#define SH_OUT_L sim_out_l
#define SH_OUT_R sim_out_r
#define SH_RENDERF(n) sim_render(n)
#define SH_ADC(m) sim_master(m)
static void SH_BOOT(void) { sim_init(44100); }
static void SH_FRAME(uint32_t ms)
{ (void)ms; }
#define SH_ENC(e, n) sim_enc((e), (n))
#define SH_BTN(i, d) sim_button((i), (d))
#define SH_KEY(k, d) sim_key((k), (d))
#define SH_KEY_LED(k) (sim_leds_keys() >> (k) & 1u ? 2 : sim_glow_keys() >> (k) & 1u ? 1 : 0)
#define SH_BTN_LED(i) (sim_leds_buttons() >> (i) & 1u ? 2 : 0)
#include "../../../common/shell_post.h"
