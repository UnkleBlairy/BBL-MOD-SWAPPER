/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* ChoralRoot FM-1 (Felucca's) boot and main loop: the splash says CHORALROOT and the version; OCT- + OCT+ held at
 * power-on still runs the panel calibration (panel_setup) and saves it (settings_save). Boot order: WDT first, boot-loop guard, fatal vectors,
 * guards; then LCD, input (TIMER5 IRQ, 10 kHz), audio (ALNK0 IRQ).
 * The boot stub runs before all of this (firmware/stub, docs/BOOT-SAFETY.md: app.bin's first 0xEE0 bytes, where the SPL
 * jumps): it enters crt0.S only when the loader's commit marker and the body's CRC-32 hold and OCT- alone is not held
 * (the rescue key: the staged loader, else the ROM's USB boot). It leaves the watchdog armed, TIMER4 running and the
 * key matrix pins set as fm1_input_init sets them, and it does not read the reset-reason registers: fm1_cstart below
 * finds them as the SPL left them. OCT- + OCT+ at power-on is not the stub's: the calibration here.
 * The boot guard (cr_bootguard.h): a power-on clears it; a watchdog or soft (crash) reset within 30 s of the boot
 * before counts; 2 in a row -> SAFE MODE (cr_safe: no flash object loaded or saved, factory sounds, no USB audio
 * stream; the installer and OCT- + OCT+ 5 s work), 4 -> UBOOT. Every boot step leaves its number in felucca_dbg.stage
 * (.noinit): after a crash prev_stage says where (console `boot`, the SAFE MODE screen, GEEK OUT). */
extern uint32_t _data_start[], _data_end[], _data_load[], _bss_start[], _bss_end[];
extern uint32_t _pool_start[], _pool_end[], _rt_start[], _rt_end[], _rt_load[];


/* TIMER5 outranks ALNK0, so the scan keeps its 100 us pace while a half buffer renders: before,
 * the ticks stopped for the whole render (0.7 ms idle, several ms loaded), the column lit when it
 * began stayed lit that long (a ~16 Hz flicker over all LEDs, beating with the scan) and the
 * encoders lost frames. Nested in ALNK0 it only scans (GPIO + fm1_in, nothing the audio ISR touches)
 * and counts ms; USB and UART polls wait for the first tick after the render, as they always did,
 * and the time spent nested is handed to the audio ISR so its load figures stay render-only.
 * The USB audio stream cannot wait for the render (a packet per 1 ms frame, a render takes up to
 * ~5 ms): ua_service also runs nested, by elapsed time (every 250 us at most: work spanning ticks does not
 * stretch the next deadline). It touches only the audio endpoint (INDEX is set on every access) and the
 * USB side of the capture ring (audio.c copies with the IRQs off), and usb_poll never runs nested, so the
 * two never interleave (Melodee's). */
#if FELUCCA_UAC
/* the recording's endpoint (usb.c ua_service), at most every 250 us by elapsed time, independent of coalesced ticks:
 * from TIMER5 (nested in the render too) and from the audio ISR itself between its blocks, with the IRQs off
 * (audio.c ua_isr_service). The device showed why both: while notes sound the host got about half the packets (a
 * 14 s capture held 6.5 s, the ring ran over), i.e. the endpoint went unserviced for most of each long render; the
 * audio ISR's own calls bound the gap to one block's render whatever the nesting does. The two never interleave
 * in an SIE sequence: usb_sie_owner (usb_audio.c) is taken around TIMER5's USB work, and the audio ISR's IRQ-off
 * call skips while it is held */
static void ua_service_paced(uint32_t t0, int from_isr)
{
    static uint32_t last_ua;
    uint32_t gap = t0 - last_ua;
    if (from_isr)
        ua_dbg.isr_calls++;
    if (ua.cap_overruns != ua_dbg.ovr_seen) {   /* (diagnostics: an overrun into the event log) */
        ua_dbg.ovr_seen = ua.cap_overruns;
        ua_log(fm1_ms, 0xFF000000u | (ua.cap_overruns & 0xFFFFu));
    }
    if (usb.up && usb.config && !usb.suspended && !USB_CDC_ON && ua.cap_alt && !ua_paused) {
        ua_dbg.arm_calls++;                     /* every call, ungated: the packet slot freed -> the next one armed */
        ua_tx_fill();                           /* (the frame bookkeeping stays paced, below) */
    }
    if (!last_ua || gap >= 250u * FM1_TICKS_PER_US) {
        if (from_isr)
            ua_dbg.svc_isr++;
        else
            ua_dbg.svc_t5++;
        if (last_ua && gap > ua.poll_max_ticks)
            ua.poll_max_ticks = gap;
        last_ua = t0;
        ua_service();
        gap = fm1_ticks() - t0;
        if (gap > ua.service_max_ticks)
            ua.service_max_ticks = gap;
    } else if (from_isr) {
        ua_dbg.isr_gated++;
    }
}
#endif

void fm1_timer5_irq(void)
{
    static uint32_t sub, owed;
    uint32_t t0 = fm1_ticks(), usb_due = sub % 5u == 0u;
#ifdef FM1_IRQ_TARGET
    cr_prof_t5(t0, fm1_reti(), fm1_ms);               /* (cr_cpu1.h: the longest stretch without this interrupt, and where) */
#endif
    fm1_timer5_ack();
    felucca_dbg.timer_irqs++;
    fm1_input_tick();
#if BOARD_SMK37
    smk_uart_tx_tick();                         /* the TRS jack's MIDI OUT: the next byte once the last has gone */
#endif
    {   /* milliseconds from the 24 MHz TIMER4 (robust to a late tick) */
        static uint32_t last, acc;
        acc += t0 - last;
        last = t0;
        while (acc >= 1000u * FM1_TICKS_PER_US) {
            acc -= 1000u * FM1_TICKS_PER_US;
            fm1_ms++;
        }
    }
    if (usb_due)
        owed |= 1u;                             /* 2 kHz: all USB SIE traffic lives here */
#if FELUCCA_UART
    if (sub % 5u == 2u)
        owed |= 2u;                             /* 2 kHz: <= ~7 bytes per call at 31250 baud */
#endif
    if (++sub == 10u)
        sub = 0;
#if FELUCCA_UAC
    if (usb_sie_owner) {
        ua_dbg.t5_busy++;                       /* (an SIE sequence under way below us: not entered) */
    } else {
        usb_sie_owner = 1;
        ua_service_paced(t0, 0);
        usb_sie_owner = 0;
    }
#endif
    if (felucca_dbg.in_audio) {
        felucca_dbg.nested++;
#if FELUCCA_UART
        if (owed & 2u) {                        /* (Felucca #258) TRS input timestamped at 2 kHz under a render too:
                                                 * a long render no longer bunches an external clock's pulses. The
                                                 * timer stays the MIDI ring's only producer, the audio ISR its consumer */
            uart_midi_poll();
            owed &= ~2u;
        }
#endif
        t5_nested_ticks += fm1_ticks() - t0;
        return;
    }
#if FELUCCA_UAC
    if (usb_sie_owner)
        return;                                 /* (owed stays: the next tick) */
    usb_sie_owner = 1;
#endif
    if (owed & 1u)
        usb_poll();
#if FELUCCA_UAC
    usb_sie_owner = 0;
#endif
#if FELUCCA_UART
    if (owed & 2u)
        uart_midi_poll();
#endif
#if CR_BLE
    cr_ble_drain();                                 /* the Bluetooth peer's MIDI into the same queue (cr_ble.c) */
#endif
    owed = 0;
}
extern void isr_timer5(void);

static void timer5_start(void)                 /* OSC /4 = 6 MHz, PRD 600 -> 10 kHz */
{
#if defined(CR_SENSE_KEYS) && !BOARD_SMK37         /* (SMK-37: cr_ui.c's stand-in CR_SENSE_KEYS 0, no analog rows) */
#if CR_BLE
    if (!(cr_ble_test() & CRBL_T_NOSCAN))          /* (3y243's bisection: a BLE_DIAG build's switch) */
#endif
    {
    fm1_an.drive = SN_DRIVE;                       /* the analog rows (docs/VELOCITY.md): the tick owns the converter */
    fm1_an.con = FM1_ADC_CON_SCAN;
    }
#endif
    fm1_timer5_start(isr_timer5, 4);   /* above ALNK0 (3): the scan nests into the render (see fm1_timer5_irq) */
}

static void hexs(char *b, uint32_t v)
{
    uint32_t i;
    for (i = 0; i < 8u; i++)
        b[i] = "0123456789ABCDEF"[(v >> (28u - 4u * i)) & 15u];
    b[8] = 0;
}

static void fm1_fault(const fm1_crash_t *c)
{
    char b[12];
    uint32_t t0;
    fm1_audio_stop();
    lcd_fill(0, 0, 240, 240, UI_CRASH_BG);            /* fixed, outside the palettes */
    draw_text_line(0, 8, 240, CR_FONT_M, "CHORALROOT CRASH", UI_CRASH_INK, UI_CRASH_BG, 1);
    hexs(b, c->vec);
    draw_text_line(10, 40, 220, CR_FONT_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->pc);
    draw_text_line(10, 60, 220, CR_FONT_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->emu);
    draw_text_line(10, 84, 220, CR_FONT_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->dbg);
    draw_text_line(10, 102, 220, CR_FONT_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->rets);
    draw_text_line(10, 120, 220, CR_FONT_M, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    t0 = fm1_ticks();
    while ((uint32_t)(fm1_ticks() - t0) < 4000u * 1000u * FM1_TICKS_PER_US)
        ;
    fm1_reboot();
}

/* power-on: the parts with their default sounds (TRK_DEF); the sequencers empty */
static void felucca_init(void)
{
    uint32_t i;
    chain_defaults(&chain_config);
    for (i = 0; i < G_COUNT; i++)
        song.g[i] = GP[i].def;
    undo_depth++;                             /* (no undo copy of the power-on loads) */
    fm6_init();                               /* every track's FM6 patch: the init voice (and the engines' tables) */
    for (i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        track_defaults(t);
        set_engine_of(t, TRK_DEF[i][0]);
        apply_preset_to(t, TRK_DEF[i][1]);    /* with its sends */
        t->engine = t->eng_req;
        track_defaults_steps(t);              /* (a sound load never touches them) */
        if (TRK_DEF[i][2])
            load_pat16(t, PATTERNS[TRK_DEF[i][2] - 1u].note, PATTERNS[TRK_DEF[i][2] - 1u].flags);
        pat_sig[i] = steps_sig(t);            /* a default pattern, not the user's */
        pat_last[i] = TRK_DEF[i][2];
    }
    undo_depth--;
    song.sel = 0;
    song.master_q12 = 2048;                   /* (the pot's level replaces it before the audio starts: master_boot) */
    ui.home = 1;
    ui.force = 1;
}

/* the power-on splash: with the screens in the unit (choralroot.c) ChoralRoot's (cr_shim.c cr_splash: the idle
 * stripes sliding in, the version under them); otherwise (felucca.c) plain text on gfx.c */
static void splash(void)
{
#ifdef CR_A_STRIPES
    cr_splash();
#else
    lcd_fill(0, 0, 240, 240, T_BG);
    draw_text_box(0, 94, 240, &AF_L, "CHORALROOT", T_THEME, 1);
    draw_text_box(0, 134, 240, &AF_S, FELUCCA_VERSION, T_MID, 1);
#endif
}

#ifdef CR_A_STRIPES
/* OCT- + OCT+ held at power-on: Felucca's HARDWARE CALIBRATION (ui_input.c panel_setup, which the ChoralRoot unit
 * does not include) runs on ChoralRoot's screens, from the UI frame (cr_ui.c cu_calib_*: press each printed button,
 * turn each knob right, OCT+ keeps, 30 s idle cancels); it saves the table itself (settings_save). */
static void cr_panel_setup(void) { cc.req = 1; }
#define panel_setup cr_panel_setup
#endif

/* the diagnostics record (audio.c, .noinit): what the last run left, before this boot's breadcrumbs overwrite it */
static void dbg_boot(void)
{
    if (felucca_dbg.magic != DBG_MAGIC) {
        memset(&felucca_dbg, 0, sizeof felucca_dbg);
        felucca_dbg.magic = DBG_MAGIC;
    }
    felucca_dbg.boots++;
    felucca_dbg.max_us = 0;
    felucca_dbg.in_audio = 0;                       /* .noinit: a reset inside the audio ISR left it set, and
                                                       TIMER5 would treat every tick as nested (no USB poll) */
    felucca_dbg.prev_stage = felucca_dbg.stage;     /* a WDT reset leaves the last breadcrumb here */
    felucca_dbg.prev_page = felucca_dbg.page;
    felucca_dbg.prev_home = felucca_dbg.home;
    felucca_dbg.prev_frames = felucca_dbg.ui_frames;
    felucca_dbg.prev_rst = fm1_boot.p3_rst;
    CR_STAGE(BS_GUARD);
}

/* the pot: the scan's sample once TIMER5 owns the converter (hal/fm1_input.h fm1_an; -1 until its first), the
 * blocking read before (master_boot, under the splash) */
#if !BOARD_SMK37                 /* (SMK-37: K1, a virtual pot: hal/smk_input.h fm1_adc_read) */
#define MASTER_POT_READ() (fm1_an.con ? (fm1_an.mvalid ? (int32_t)fm1_an.master : -1) : fm1_adc_read(FM1_ADC_MASTER))
#endif
#include "master.c"              /* the MASTER pot: read before the audio starts (0.19; Felucca 1.1.5, #137) */

#if CR_CPU1 && !BOARD_SMK37
/* the power-on pop (HISTORY 3y268): stock V15's supplies (hal/fm1_power.h fm1_power_stock: the 1.3 V rail on its
 * DC-DC, VDDIO 3.2 V, the core rails at ChoralRoot's caps) on every boot, first, as FM1-Base's main_fm1.c does
 * (Charles Vestal, 5e1e79f) and Melodee 1.6.1. Until 0.32 only a Bluetooth boot set them, just before the audio;
 * every other boot started the I2S clocks on the boot loader's supplies, and the speaker popped under the splash (the
 * spare E81CE2F7, Bluetooth and Dual Core Off, cold starts). Not in SAFE MODE (the boot loader's supplies, as before).
 * -1 not run, else fm1_power_stock's result (a Bluetooth boot takes it: cr_ble_supplies) */
static int cr_boot_supplies = -1;
#endif

static void fm1_main(void)
{
    uint32_t ms;
#if CR_CPU1 && !BOARD_SMK37
    if (!cr_safe)
        cr_boot_supplies = cr_rails_stock();            /* first: before the flash, the screen and the audio */
#endif
    CR_STAGE(BS_AUDIO);
    audio_init();                                       /* the I2S clocks next, ~0.1 s after power-on (HISTORY 3y268: the
                                                         * power-on pop). The DAC popped when its clocks came 1.5 s or
                                                         * more after power-on (6 s: every time); FM1-Base starts them
                                                         * early. The DMA loops the zeroed buffer until the interrupts
                                                         * come on below (fm1_irq_enable_all): silence; the first block
                                                         * is rendered after master_boot, at the knob's level, as before */
    persist_boot();                                     /* (stages BS_FLASH .. BS_SETTINGS; SAFE MODE: no object read) */
#if FELUCCA_OTA
    CR_STAGE(BS_OTA_CLEANUP);
    if (flash_ok)
        ota_boot_cleanup();                             /* the staging area after an update: our loader stays for
                                                           the boot stub's rescue (OCT- at power-on), a record or
                                                           anything else goes (ota.c; in SAFE MODE too) */
#endif
    settings_init();
    CR_STAGE(BS_LCD);
    lcd_init();
    CR_STAGE(BS_SPLASH);
    splash();
    CR_STAGE(BS_INPUT);
    fm1_input_init();
    fm1_adc_init();
#if BOARD_SMK37 && FELUCCA_FLASH
    if (flash_ok)                                   /* the factory key / pad velocity curves (USRTRIM, read only) */
        smk_trim_load(fm1_xip_ptr(SMK_TRIM_FLASH));
#endif
    panel_init();
    CR_STAGE(BS_SOUNDS);
    felucca_init();
#if CR_BLE
    cr_ble_boot();                                      /* Bluetooth: its record, the trims (the radio: below) */
    if (cr_ble_will_start())                            /* a radio boot: stock V15's supplies first, before core 1,
                                                         * as Melodee 1.6.1 (hal/fm1_power.h fm1_power_stock, 3y240);
                                                         * a P33 timeout: no radio this boot */
#if CR_CPU1 && !BOARD_SMK37
        cr_ble_supplies(cr_boot_supplies >= 0 ? cr_boot_supplies : cr_rails_stock());   /* (set at the start) */
#else
        cr_ble_supplies(cr_rails_stock());
#endif
#endif
#if CR_CPU1
    CR_STAGE(BS_CPU1);                                  /* (a hang here: prev_stage "core 1", the boot guard counts it) */
    cr_dbg.prof_on = 1;                                 /* the ISR's stage profile (cr_cpu1.h) */
    cr_c1_power_on(cr_safe, (int)bootguard.counted);    /* the second core: at power-on, before the audio and the
                                                         * timers (started later it does not reach its entry: fm1-x0x,
                                                         * Melodee); no answer in 20 ms: one core (docs/DUALCORE.md).
                                                         * With Dual Core On the core rails go up first, IRQs still
                                                         * off (hal/fm1_power.h, after Melodee PR 21). Not in SAFE
                                                         * MODE, and not when the boot before this one failed
                                                         * (cr_cpu1.h cr_c1_power_on) */
#endif
    master_boot();                            /* the first block already at the knob's level (master.c) */
    CR_STAGE(BS_USB);
    usb_start();
#if FELUCCA_UART
    CR_STAGE(BS_UART);
#if CR_BLE
    if (!(cr_ble_test() & CRBL_T_NOUART))     /* (3y243's bisection) */
#endif
    uart_midi_init();
#endif
#if BOARD_SMK37
    smk_uart_tx_init();                       /* the TRS jack: MIDI OUT (before TIMER5 starts) */
#endif
    CR_STAGE(BS_IRQ);
    timer5_start();
    fm1_guard_lock_top();
#if CR_BLE
    CR_STAGE(BS_BLE);
    cr_ble_start_boot();                      /* the radio, when On was saved: the last step with the interrupts off,
                                               * as Melodee starts it (core 1 idle in RAM, the rails, the audio and USB
                                               * set up), its interrupts served at once below (cr_ble.c, 3y238) */
    CR_STAGE(BS_IRQ);
#endif
    fm1_irq_enable_all();
    fm1_delay_ms(30);
    CR_STAGE(BS_CALIB);
    if ((fm1_in.buttons & FM1_OCT_BOTH) == FM1_OCT_BOTH) {
        panel_setup();                        /* OCT- + OCT+ held at power-on */
        settings_save();
    }
    for (ms = 0; ms < (cr_safe ? 2500u : 400u); ms += 10u) {   /* the splash (SAFE MODE: its screen stays readable); */
        fm1_delay_ms(10);                     /* the pot followed under it */
        master_poll();
    }
    lcd_fill(0, 0, 240, 240, T_BG);

    for (;;) {
        uint32_t m = fm1_ms;
        fm1_wdt_feed();
#if CR_USB_HOST
        uh_task(fm1_ms);                                /* before usb_retry: a host port is not retried as a device */
        if (uh.msg) {                                   /* (usb_host.c's UH_MSG_*: ON / OFF have none, the Options say) */
            static const char *const UH_TEXT[] = {
                [UH_MSG_MIDI] = "USB device connected",
                [UH_MSG_LOST] = "USB device gone",
                [UH_MSG_NOMIDI] = "not a USB MIDI device",
                [UH_MSG_LOW] = "low-speed USB: not supported",
                [UH_MSG_NOLINE] = "nothing on USB: powered hub?",
                [UH_MSG_NOANSWER] = "USB device not answering",
                [UH_MSG_HUB_EMPTY] = "hub found: plug in MIDI",
                [UH_MSG_HUB_NOMIDI] = "no MIDI device on the hub",
            };
            if (uh.msg < sizeof UH_TEXT / sizeof UH_TEXT[0] && UH_TEXT[uh.msg])
                cu_message(UH_TEXT[uh.msg], CR_COL_WHITE);
            uh.msg = 0;
        }
#endif
        usb_retry(fm1_ms);
#if FELUCCA_UAC
        if (ua_off_apply(fm1_ms))                       /* Options > USB Record: the host re-reads (a second off
                                                         * the bus; the setting is saved as any other, cr_settings.c) */
            ui_message("USB RECONNECTING");
#endif
        if (fm1_ms > BG_SETTLE_MS && bootguard.pending)  /* a crash or hang in the first 30 s counts */
            bootguard_settled(&bootguard);              /* (SAFE MODE stays for this session: cr_safe) */
        {
#if BOARD_SMK37
            int32_t b = fm1_adc_read(FM1_ADC_BATT);     /* battery (SMK-37: mux C, hal/smk_input.h): slow IIR */
#else
            int32_t b = fm1_an.bvalid ? (int32_t)fm1_an.batt : -1;   /* battery (the scan's sample): slow IIR */
#endif
            if (b > 0)
                song.batt_raw = song.batt_raw ? song.batt_raw + (b - song.batt_raw) / 32 : b;
        }
        master_poll();                                  /* MASTER: the pot, smoothed (master.c) */
#if defined(CR_A_STRIPES) && FELUCCA_FLASH           /* (ChoralRoot: cr_backup.c is in the unit) */
        cr_update_poll();                               /* OCT- + OCT+ + HOME held 5 s: update mode through the boot
                                                         * stub (cr_backup.c; 0.18: the two OCT keys alone no longer) */
#else
        {   /* OCT- + OCT+ held 5 s: enter UBOOT with RAM intact (debug / update); a countdown
             * shows from 2 s over the whole screen (the menu and the dialogs too: ui_draw), letting
             * go cancels it */
            static uint32_t t0;
            uint32_t both = (1u << panel.btn[B_OCTDN]) | (1u << panel.btn[B_OCTUP]);
            if ((fm1_in.buttons & both) != both) {
                if (ui.uboot) {
                    ui.uboot = 0;
                    ui.force = 1;                       /* what the countdown covered */
                    ui_message("UPDATE CANCELLED");
                }
                t0 = fm1_ms;
            } else if (fm1_ms - t0 > 2000u && fm1_ms - t0 <= 5000u) {
                uint32_t left = (5000u - (fm1_ms - t0) + 999u) / 1000u;
                if (left != ui.uboot) {
                    ui.uboot = (uint8_t)left;
                    ui.force = 1;
                }
            } else if (fm1_ms - t0 > 5000u) {
                fm1_audio_stop();
                lcd_fill(0, 0, 240, 240, T_BG);
                draw_text_box(0, 110, 240, CR_FONT_M, "UBOOT", T_THEME, 1);
                usb_detach();
                fm1_delay_ms(30);
                bootguard_intentional(&bootguard);      /* intentional reset: not a failed boot */
                fm1_enter_uboot();
            }
        }
#endif
#if FELUCCA_OTA
        if (ed_service())                               /* web editor SysEx; OTA only for a held frame not the
                                                         * editor's (Felucca #312) */
            ota_service();                              /* M-UPGRADE handshake */
        if (usb.ota_req) {                              /* M-UPGRADE upgrade command */
            usb.ota_req = 0;
            panic_req = (1u << NTRK) - 1u;               /* every track (bit per track) */
            if (flash_ok)
                ota_session();                          /* returns only if nothing was committed */
            lcd_fill(0, 0, 240, 240, T_BG);
            ui.force = 1;
        }
#endif
        if (usb.uboot_req) {                            /* SysEx F0 22 24 35 7D F7 from the host */
            fm1_audio_stop();
            lcd_fill(0, 0, 240, 240, T_BG);
            draw_text_box(0, 110, 240, CR_FONT_M, "UBOOT (USB)", T_THEME, 1);
            fm1_delay_ms(20);
            usb_detach();
            fm1_delay_ms(30);
            bootguard_intentional(&bootguard);
            fm1_enter_uboot();
        }
#if FELUCCA_CDC
        cdc_task();
#endif
        uint32_t ft0 = fm1_ticks();                   /* (3y60: the frame's own time, audio.c ui_ft) */
        felucca_dbg.ui_frames++;
        felucca_dbg.page = ui.page;
        felucca_dbg.home = ui.home;
        felucca_dbg.stage = BS_LOOP_INPUT;            /* (the first: cr_ui_init, BS_UI_INIT ..) */
        ui_input();
        settings_poll();                              /* queued settings save: only while stopped */
#if CR_BLE
        cr_ble_poll();                                /* Bluetooth: a start owed, its record to save (when quiet) */
#endif
        felucca_dbg.stage = BS_LOOP_DRAW;
        ui_leds();
#if BOARD_SMK37
        cr_smk_frame();                                 /* the faders, the wheels (cr_ui.c) */
        padled_flush();                                 /* the pads' colours, between LCD transfers */
#endif
        ui_draw();
        ui_ft_add(ft0);
#if FELUCCA_GRAIN
        grain_poll();                           /* GRAIN's render: a slice every frame whatever the frame cost (a frame
                                                 * that fills its 15 ms, the wave band's, leaves the idle loop below no
                                                 * turn: 3y138), and a slice a turn of the idle loop */
#endif
        felucca_dbg.stage = BS_LOOP_IDLE;
        while (fm1_ms - m < 15u) {                               /* ~60 UI frames/s at most */
            ui_input();
#if BOARD_SMK37
            cr_smk_wheels();                    /* (bends follow the wheel, not the screen) */
            cr_smk_pedal();                     /* (the pedal jack: its sustain, its expression) */
#endif
#if FELUCCA_OTA
            ed_service();                       /* editor replies without waiting for the next frame */
#endif
#if FELUCCA_GRAIN
            grain_poll();                       /* GRAIN's render, a slice a turn (eng_grain.c, docs/GRAIN.md) */
#endif
        }
    }
}

void fm1_cstart(void)
{
    uint32_t *s, *d, p3, src, wdt, mode;
#if CR_CPU1 && defined(FM1_HAVE_CPU1)
    fm1_cpu1_halt();                            /* core 1 held before the RAM below is cleared (hal/fm1_cpu1.h) */
#endif
    fm1_time_init();
    fm1_reset_reason();
    p3 = fm1_boot.p3_rst;
    src = fm1_boot.rst_src;
    wdt = fm1_boot.wdt_con;                     /* (as the boot stub armed it, no longer the SPL's: console `boot`) */
    fm1_wdt_arm(0x0D);
    /* the boot guard (cr_bootguard.h): power-on clears it, watchdog / soft resets within 30 s of a boot count;
     * 2 -> SAFE MODE, 4 -> UBOOT (the record cleared: a power cycle leaves ROM boot to a clean guard) */
    mode = bootguard_step(&bootguard, bootguard_reason(p3, src));
    if (mode == BOOT_UBOOT)
        fm1_enter_uboot();
    fm1_irq_init();
    for (d = _bss_start; d < _bss_end; d++)
        *d = 0;
    for (d = _pool_start; d < _pool_end; d++)
        *d = 0;
    for (s = _data_load, d = _data_start; d < _data_end; s++, d++)
        *d = *s;
    for (s = _rt_load, d = _rt_start; d < _rt_end; s++, d++)
        *d = *s;                                /* flash driver code that must run from RAM */
    fm1_mailbox_clear();
    fm1_guard_enable(FM1_GUARD_STACK | FM1_GUARD_WRITE | FM1_GUARD_BUS | FM1_GUARD_PC);
    fm1_boot.p3_rst = (uint8_t)p3;
    fm1_boot.rst_src = src;
    fm1_boot.wdt_con = (uint8_t)wdt;
    cr_safe = mode == BOOT_SAFE;                /* (.bss: set after the clear above) */
    dbg_boot();
    fm1_main();
    for (;;)
        ;
}
