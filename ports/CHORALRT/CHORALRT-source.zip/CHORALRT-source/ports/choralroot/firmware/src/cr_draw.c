/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 ChoralRoot FM-1 contributors (a fork of Felucca) */
/* ChoralRoot FM-1: the screen renderer. cr_draw(s, anim_ms) draws a cr_screen_t (cr_screen.h) on the 240 x 240 LCD
 * through gfx.c's canvas, in six strips of 240 x 40 (gfx.c CV_MAX holds 120 rows: choralroot.c CV_ROWS), each drawn with cv_oy = -its
 * top row so the layout is written in screen coordinates and clipped by the canvas.
 * The layout is the designer's (../ChoralRootFM1Designer/index.html renderScreen, cards and knob cards off): the top
 * line rows 0..27, the panel from row 28 to 198 (a footer line at 226) or to 240, the ring round the edge, the
 * message box over the panel. Type: the bold sizes (600..800 in the mock-ups) are Inter Tight 700 resampled from
 * the CRX (104 px, the chord charset) and CRB (40 px) faces (cr_gfx.c); the regular ones (500) are Felucca's own
 * AF_M (15 px) and AF_S (12 px), drawn natively at 12..15 px and resampled below 12. See CR_SCREENS.md.
 * Cache: a signature of the struct, the animation's frame and the palette: unchanged, nothing is drawn; else every
 * strip is drawn and only the tiles whose pixels changed are blitted (cr_draw_invalidate: all of them, once); when
 * only the ring's fraction moved, only the strips its tip crossed are drawn (the ring itself: a const table in flash, cr_ring_draw);
 * when only the editor's parts changed (a row's cells, the band, the hot cell, the title line), only their strips
 * (a knob row's cells and hot cell the same: its row's strips; a free screen's: the strips of the elements whose cells
 * changed or that were or are hot).
 * A blit goes out by DMA from its own buffer while the next strip is drawn (cr_send).
 * Animations are pure functions of (s, anim_ms): anim_ms is the time since the change that started the ones in
 * s->anim (the firmware's tween clock); cr_anim_busy says whether more frames are still to come.
 * Included after gfx.c and cr_gfx.c (felucca.c's single compilation unit). */
#include "cr_screen.h"

/* ChoralRoot's own colours (PLAN.md section 5), not per palette */
#define CR_RGB(r, g, b) ((uint16_t)((((r) >> 3) << 11) | (((g) >> 2) << 5) | ((b) >> 3)))
static const uint16_t CR_NAMED[9] = {
    0, CR_RGB(246, 243, 234), CR_RGB(224, 58, 47), CR_RGB(43, 80, 200), CR_RGB(242, 183, 5),
    CR_RGB(240, 122, 26), CR_RGB(47, 179, 122), CR_RGB(110, 110, 118), CR_RGB(0, 0, 0)};
#define CR_RED CR_NAMED[CR_COL_RED]
#define CR_WHITE CR_NAMED[CR_COL_WHITE]
#define CR_YELLOW CR_NAMED[CR_COL_YELLOW]

/* a colour of the struct; NONE: def */
static uint16_t cr_rgb(uint32_t c, uint16_t def)
{
    if (c > CR_COL_NONE && c <= CR_COL_BLACK) return CR_NAMED[c];
    switch (c) {
    case CR_COL_BG: return T_BG;
    case CR_COL_SURF: return T_SURF;
    case CR_COL_TEXT: return T_TEXT;
    case CR_COL_THEME: return T_THEME;
    case CR_COL_ACCENT: return T_ACCENT;
    case CR_COL_MID: return T_MID;
    case CR_COL_DIM: return T_DIM;
    case CR_COL_LINE: return T_LINE;
    case CR_COL_REC: return T_REC;
    case CR_COL_MAGENTA: return CR_RGB(224, 75, 216);
    case CR_COL_PURPLE: return CR_RGB(180, 140, 255);
    default: return def;
    }
}

/* ------------------------------------------------------------ type --- */
/* a size and weight of the mock-ups -> a face and its scale (Q12); native: drawn by gfx.c cv_text */
typedef struct { const aafont_t *f; int32_t sc; int native; } cr_face_t;
static cr_face_t cr_face(const char *s, uint32_t px, int bold)
{
    cr_face_t r;
    if (bold) {
        r.f = px > 40u && cr_covers(&AF_CRX, s) ? &AF_CRX : &AF_CRB;
        r.native = 0;
    } else if (px >= 13u) {
        r.f = &AF_M;                     /* 13..15 px / 500: Felucca's M (15 px / 500) as it is */
        r.native = 1;
        px = 15u;
    } else {
        r.f = &AF_S;                     /* 12 px: S (12 px / 400); below: S resampled */
        r.native = px == 12u;
    }
    r.sc = (int32_t)((px << 12) / cr_face_px(r.f));
    return r;
}
/* the advance of s (Q8 px) */
static int32_t cr_tw(const char *s, uint32_t px, int bold)
{
    cr_face_t f = cr_face(s, px, bold);
    return f.native ? text_w(f.f, s) << 8 : cr_adv8(f.f, s, f.sc);
}

enum { CR_L, CR_C, CR_R };
/* s on baseline y (Q8) at x (Q8; align: left, centre or right of it), squeezed sq (Q12, 4096 none), colour fg; under:
 * what lies behind it (the native faces blend against it); returns the left x (Q8) */
static int32_t cr_text(int32_t x, int32_t y, const char *s, uint32_t px, int bold, int align, int32_t sq, uint16_t fg,
                       uint16_t under, uint32_t flags)
{
    cr_face_t f = cr_face(s, px, bold);
    int32_t w;
    if (!s[0]) return x;
    if (f.native && sq == 4096) {
        w = text_w(f.f, s) << 8;
        x -= align == CR_C ? w / 2 : align == CR_R ? w : 0;
        cv_text_flags((x + 128) >> 8, ((y + 128) >> 8) - f.f->asc, f.f, s, fg, under, flags);
        return x;
    }
    w = (cr_adv8(f.f, s, f.sc) * sq) >> 12;
    x -= align == CR_C ? w / 2 : align == CR_R ? w : 0;
    cr_text_sc(x, y, f.f, s, (f.sc * sq) >> 12, f.sc, fg, flags);
    return x;
}
/* s into d, at most maxw (Q8) wide at px: the end ellipsised. 1 = cut */
static int cr_fit(char *d, uint32_t n, const char *s, uint32_t px, int bold, int32_t maxw)
{
    cr_face_t f = cr_face(s, px, bold);
    uint32_t k = 0;
    if (f.native) return text_fit(d, n, s, f.f, maxw >> 8);
    while (s[k] && k + 1u < n) { d[k] = s[k]; k++; }
    d[k] = 0;
    if (!s[k] && cr_adv8(f.f, d, f.sc) <= maxw) return 0;
    if (k + 2u > n) k = n - 2u;
    for (;;) {
        while (k && d[k - 1u] == ' ') k--;
        d[k] = ELLIPSIS;
        d[k + 1u] = 0;
        if (!k || cr_adv8(f.f, d, f.sc) <= maxw) return 1;
        k--;
    }
}
/* cr_text of s cut to maxw (Q8) */
static void cr_text_fit(int32_t x, int32_t y, const char *s, uint32_t px, int bold, int align, uint16_t fg,
                        uint16_t under, int32_t maxw)
{
    char b[48];
    int cut = cr_fit(b, sizeof b, s, px, bold, maxw);
    cr_text(x, y, b, px, bold, align, 4096, fg, under, cut ? 9u : 0u);
}

#define P8(v) ((int32_t)(v) * 256)       /* whole px -> Q8 */

/* ------------------------------------------------------- animation --- */
#define CR_SQUEEZE_MS 120u               /* the old name squeezes to a column (half), the new one stretches out */
#define CR_THIN 330                      /* .. the column: 8 % (Q12; cr_gfx.c resamples down to 1/16) */
#define CR_SLIDE_MS 160u                 /* a picker's slide (and the Routing page's blocks making room) */
#define CR_LIFT_MS 120u                  /* the Routing page: a held block rises, a block let go lands */
#define CR_FILL_MS 30u                   /* a meter: a stripe every 30 ms */
#define CR_FILL_MAX 14u                  /* .. more than 14 to light or to darken (a pool's meter: up to 32; a wrap
                                          * from its last preset to INIT, a long jump): all of them in the 420 ms of
                                          * 14, so the meter is at its place inside the popup's 900 ms */
#define CR_INTRO_MS 220u                 /* power-on: each band slides in, 90 ms after the one above */
#define CR_INTRO_GAP 90u
#define CR_INTRO_NAME 300u               /* .. the name lands from 300 ms, over 150 ms */
#define CR_SWEEP_MS 240u                 /* the idle stripes swept off, each band 40 ms after the one above */
typedef struct {
    int32_t sq;                          /* chord: the squeeze of the name drawn (Q12) */
    int32_t slide;                       /* picker: how far the selection still has to slide (Q12 of its pitch) */
    int32_t lift;                        /* route: how far the lift (or the landing) has gone (Q12, 4096 done) */
    int32_t shift;                       /* stripes: Q8 px */
    int32_t sweep[4];                    /* stripes: Q8 px each band is swept right */
    int32_t name_dy;                     /* stripes (CR_A_INTRO): Q8 px the name is still above its place */
    uint8_t name_off;                    /* stripes (CR_A_INTRO): the name not drawn yet */
    uint8_t from;                        /* chord: 1 = `from` is drawn (the first half of the squeeze) */
    uint8_t filled;                      /* meter: stripes filled */
    uint8_t busy;                        /* more frames to come */
} cr_frame_t;

/* 1 - (1 - x)^2 over x = t / d, Q12 */
static int32_t cr_ease_out(uint32_t t, uint32_t d)
{
    int32_t u;
    if (t >= d) return 4096;
    u = 4096 - (int32_t)((t << 12) / d);
    return 4096 - ((u * u) >> 12);
}
static uint32_t cr_segs(const cr_screen_t *s) { return s->segments ? s->segments : 12u; }
static uint32_t cr_filled(const cr_screen_t *s, uint32_t pct)
{
    return (pct * cr_segs(s) + 128u) >> 8;
}

/* a meter's fill (CR_A_FILL) t ms after it started: the stripes lit on the way from a to b of them, one every
 * CR_FILL_MS (up: lit, down: darkened); more than CR_FILL_MAX to go: all of them in the time of CR_FILL_MAX. b once
 * it is there. cr_ui.c cu_animate asks it where a meter stands when its value moves again */
static uint32_t cr_fill_at(uint32_t a, uint32_t b, uint32_t t)
{
    uint32_t n = a < b ? b - a : a - b, done = t / CR_FILL_MS;
    if (n > CR_FILL_MAX)                                           /* a long way: in the time of CR_FILL_MAX stripes */
        done = t < CR_FILL_MAX * CR_FILL_MS ? t * n / (CR_FILL_MAX * CR_FILL_MS) : n;
    return done >= n ? b : a < b ? a + done : a - done;
}

static void cr_frame(const cr_screen_t *s, uint32_t t, cr_frame_t *fr)
{
    uint32_t i, k;
    for (k = 0; k < sizeof *fr; k++)
        ((uint8_t *)fr)[k] = 0;
    fr->sq = 4096;
    fr->lift = 4096;
    fr->filled = (uint8_t)cr_filled(s, s->pct);
    fr->shift = (int32_t)(s->phase & 255u) * 40;
    if (s->kind == CR_K_CHORD && (s->anim & CR_A_SQUEEZE) && t < CR_SQUEEZE_MS) {
        fr->busy = 1;
        if (s->from.root[0] && t < CR_SQUEEZE_MS / 2u) {          /* the old name thins (ease-in) */
            int32_t e = (int32_t)((t << 12) / (CR_SQUEEZE_MS / 2u));
            fr->from = 1;
            fr->sq = 4096 - (((4096 - CR_THIN) * ((e * e) >> 12)) >> 12);
        } else if (s->from.root[0]) {                              /* the new one stretches out (ease-out) */
            fr->sq = CR_THIN + (((4096 - CR_THIN) * cr_ease_out(t - CR_SQUEEZE_MS / 2u, CR_SQUEEZE_MS / 2u)) >> 12);
        } else {
            fr->sq = CR_THIN + (((4096 - CR_THIN) * cr_ease_out(t, CR_SQUEEZE_MS)) >> 12);
        }
    }
    if ((s->kind == CR_K_PICKER || s->kind == CR_K_KNOBROW || s->kind == CR_K_LOOPMENU || s->kind == CR_K_ROUTE) &&
        (s->anim & CR_A_SLIDE) && s->slide && t < CR_SLIDE_MS) {
        fr->busy = 1;
        fr->slide = 4096 - cr_ease_out(t, CR_SLIDE_MS);
    }
    if (s->kind == CR_K_ROUTE && (s->anim & CR_A_LIFT) && t < CR_LIFT_MS) {
        fr->busy = 1;
        fr->lift = cr_ease_out(t, CR_LIFT_MS);
    }
    if (s->kind == CR_K_METER && (s->anim & CR_A_FILL)) {
        uint32_t b = fr->filled;
        fr->filled = (uint8_t)cr_fill_at(cr_filled(s, s->pct_from), b, t);
        fr->busy = fr->filled != b;
    }
    if (s->kind == CR_K_STRIPES) {
        if ((s->anim & CR_A_STRIPES) && s->period_ms) {
            fr->busy = 1;                                          /* (runs until the screen changes) */
            fr->shift = (int32_t)(((s->phase & 255u) + (t % s->period_ms) * 256u / s->period_ms) & 255u) * 40;
        }
        if (s->anim & CR_A_SWEEP)
            for (i = 0; i < 4u; i++) {
                uint32_t d = i * 40u;
                fr->sweep[i] = t <= d ? 0 : (cr_ease_out(t - d, CR_SWEEP_MS) * 300) >> 4;
                if (t < d + CR_SWEEP_MS) fr->busy = 1;
            }
        if (s->anim & CR_A_INTRO) {                                /* (anim_ms settled: the final picture) */
            for (i = 0; i < 4u; i++) {
                uint32_t d = i * CR_INTRO_GAP;
                fr->sweep[i] -= t <= d ? 300 * 256 : ((4096 - cr_ease_out(t - d, CR_INTRO_MS)) * 300) >> 4;
                if (t < d + CR_INTRO_MS) fr->busy = 1;
            }
            fr->name_off = t < CR_INTRO_NAME;
            if (t < CR_INTRO_NAME + 150u) {
                fr->busy = 1;
                if (t >= CR_INTRO_NAME)
                    fr->name_dy = ((4096 - cr_ease_out(t - CR_INTRO_NAME, 150u)) * 24) >> 4;
            }
        }
    }
}
/* 1 while an animation of s still moves at anim_ms (the firmware keeps calling cr_draw with a running clock) */
static int cr_anim_busy(const cr_screen_t *s, uint32_t anim_ms)
{
    cr_frame_t fr;
    cr_frame(s, anim_ms, &fr);
    return fr.busy;
}

/* ----------------------------------------------------------- layout --- */
#define CR_PY0 28                        /* the panel's top row (no knob cards) */
static int32_t cr_ph(const cr_screen_t *s) { return (s->footer[0] ? 198 : 240) - CR_PY0; }
static int cr_key_black(uint32_t k) { return (0x54A >> ((k + 5u) % 12u)) & 1; }

/* the battery: a 16 x 10 case at (rx, 7) with its nub, lvl 0..4 (4 = charging) quarters filled */
static void cr_battery(int32_t rx, uint32_t lvl)
{
    if (lvl > 4u) lvl = 4u;
    cr_fill(rx + 1, 7, 14, 1, T_MID);                                /* the case: 16 x 10, 1 px, round corners */
    cr_fill(rx + 1, 16, 14, 1, T_MID);
    cr_fill(rx, 8, 1, 8, T_MID);
    cr_fill(rx + 15, 8, 1, 8, T_MID);
    cr_frect((rx + 16) * 16 + 8, 9 * 16 + 8, 32, 80, T_MID);          /* the nub */
    if (lvl) cr_frect((rx + 2) * 16, 9 * 16, (int32_t)(12u * 16u * lvl / 4u), 6 * 16, lvl <= 1u ? CR_YELLOW : CR_RED);
}

/* the corner dial (every loop state but the count-in: no ring): Orchid's ring shrunk into the top line's right end,
 * centre (229, 12), r 8, 3 px: the dotted track (10 dots of 2.5 px, about 2 on 3 off: cr_disc, cheaper than a dashed
 * cr_arc's per-sample angles), grey, red while the first take records (CR_DIAL_REC: no loop yet, the whole circle is
 * being made); the progress red clockwise from 12 o'clock (the loop's cycle, or the take's: cr_loop_ring), 5 px on
 * the downbeat's frame; the REC dot (r 3, red) in the middle while dial_dot (the REC LED's twin: lit armed, blinking
 * recording or overdubbing), clear of the band (inner edge r 6.5, 5.5 pulsing). Rows 2..22: strip 0 only (cr_draw
 * redraws that strip alone when only its fraction, pulse, look or dot moved) */
#define CR_DIAL_X (229 * 16)
#define CR_DIAL_Y (12 * 16)
#define CR_DIAL_R (8 * 16)
#define CR_DIAL_DOT (3 * 16)             /* the REC dot's radius */
#define CR_DIAL_SHIFT 22                 /* the header's right text moves this far left while the dial shows */
static void cr_dial(const cr_screen_t *s)
{
    uint32_t sweep = s->dial >= 256u ? 65536u : (uint32_t)s->dial << 8;
    uint32_t k;
    uint16_t tc = s->dial_mode == CR_DIAL_REC ? CR_RED : T_LINE;
    if (cr_row0() > 23) return;          /* (not this strip) */
    for (k = 0; k < 10u; k++) {
        uint32_t a = k * 65536u / 10u;
        cr_disc(CR_DIAL_X + ((CR_DIAL_R * cr_cos(a)) >> 14), CR_DIAL_Y + ((CR_DIAL_R * cr_sin(a)) >> 14), 20, tc);
    }
    if (sweep)
        cr_arc(CR_DIAL_X, CR_DIAL_Y, CR_DIAL_R, s->dial_pulse ? 5 * 16 : 3 * 16, 49152u, sweep, 0, 0, 0, CR_RED);
    if (s->dial_dot)
        cr_disc(CR_DIAL_X, CR_DIAL_Y, CR_DIAL_DOT, CR_RED);
}

/* the home pages' beat chip (the DRUMS plan's v3, mock-up 1): beat_n blocks 5 x 10 (the beat lit: white, magenta with
 * Drums; waiting: none lit), and with Drums the roundel after them (r 8, its ring 2 px, 4 at the kick's thump; its
 * centre white at the snare's flash). x: the chip's left edge; rows 7..21 (strip 0) */
static int32_t cr_chip_w(const cr_screen_t *s)
{
    int32_t n = s->beat_n ? s->beat_n : 4;
    return n * 7 - 2 + 6 + (s->beat_on == 2u ? 22 : 0);
}
static void cr_beat_chip(const cr_screen_t *s, int32_t x)
{
    int32_t n = s->beat_n ? s->beat_n : 4, drums = s->beat_on == 2u;
    if (cr_row0() > 23) return;
    for (int32_t i = 0; i < n; i++)
        cr_fill(x + i * 7, 7, 5, 10, i == s->beat_pos - 1 ? (drums ? CR_RGB(224, 75, 216) : CR_WHITE) : T_DIM);
    if (drums) {
        int32_t cx = (x + n * 7 + 9) * 16 + 8, cy = 12 * 16;
        cr_arc(cx, cy, 8 * 16, 32 + s->beat_pulse * 32 / 255, 0, 65536u, 0, 0, 0, CR_RGB(224, 75, 216));
        cr_disc(cx, cy, 3 * 16, s->beat_flash ? CR_WHITE : CR_RGB(224, 75, 216));
    }
}

static void cr_header(const cr_screen_t *s)
{
    int bare = s->icon == CR_ICON_NONE, px = bare ? 15 : 12;
    int32_t x = 0, rx = 236, rightw = 0, base = bare ? P8(18) : P8(16) + 128;
    if (!s->header) return;
    if (s->icon == CR_ICON_PLAY) {       /* a triangle (8, 6) (19, 12) (8, 18), a row at a time */
        int32_t j;
        for (j = 6; j < 18; j++) {
            int32_t d = j * 16 + 8 - 12 * 16;                          /* the row's centre from the tip's row, Q4 */
            cr_frect(8 * 16, j * 16, 11 * (6 * 16 - (d < 0 ? -d : d)) / 6, 16, T_THEME);
        }
    } else if (s->icon == CR_ICON_REC) {
        cr_disc(14 * 16, 12 * 16, 88, T_REC);
    } else if (s->icon == CR_ICON_LOOP) {                                /* 0.3 rad .. 1.75 pi, 2 px */
        cr_arc(14 * 16, 12 * 16, 5 * 16, 32, 3129u, 57344u - 3129u, 0, 0, 0, T_THEME);
    }
    if (!bare) x = 26;
    if (s->dial_on) {
        rx -= CR_DIAL_SHIFT;
        rightw += CR_DIAL_SHIFT;
    }
    if (s->beat_on) {                    /* the beat chip, left of the dial (cr_beat_chip) */
        int32_t w = cr_chip_w(s);
        cr_beat_chip(s, rx - w + 4);
        rx -= w;
        rightw += w;
    }
    if (s->batt != 255u) rightw += 26;
    if (s->right[0]) rightw += (cr_tw(s->right, 12, 1) >> 8) + 8;
    if (s->mid[0])
        cr_text_fit(P8(x + 8), base, s->mid, (uint32_t)px, 1, CR_L, cr_rgb(s->mid_col, CR_WHITE), T_BG,
                    P8(236 - rightw - x - 10));
    if (s->batt != 255u) {
        rx -= 20;
        cr_battery(rx, s->batt);
        rx -= 6;
    }
    if (s->right[0])
        cr_text(P8(rx), base, s->right, (uint32_t)px, 1, CR_R, 4096, cr_rgb(s->right_col, bare ? CR_WHITE : T_MID),
                T_BG, 0);
    if (s->dial_on)
        cr_dial(s);
}

/* the chord name (Orchid Standard Framework): the root, the quality on its baseline at 0.58, the extensions as a
 * superscript at 0.38; centred at cx on baseline cy (Q8), squeezed to maxw (px) and by sq (Q12) about cx */
static void cr_name(const cr_name_t *n, int32_t cx, int32_t cy, uint32_t size, int32_t maxw, int32_t sq)
{
    uint32_t qs = (size * 58u + 50u) / 100u, ss = (size * 38u + 50u) / 100u;
    int32_t wr = cr_tw(n->root, size, 1), wq = n->quality[0] ? cr_tw(n->quality, qs, 1) : 0, sx, x;
    int32_t w = wr + (n->quality[0] ? wq + P8(2) : 0) + (n->sup[0] ? cr_tw(n->sup, ss, 1) + P8(3) : 0);
    uint16_t cr = cr_rgb(n->col_root, CR_WHITE);
    if (w <= 0) return;
    sx = P8(maxw) < w ? ((P8(maxw) << 12) / w) : 4096;
    sx = (sx * sq) >> 12;
    if (sx < 300) sx = 300;                                       /* (cr_gfx.c CR_KMAX) */
    x = cx - w / 2;
#define CR_SQX(v) (cx + (((v) - cx) * sx >> 12))
    cr_text(CR_SQX(x), cy, n->root, size, 1, CR_L, sx, cr, T_BG, 0);
    x += wr + P8(2);
    if (n->quality[0]) {
        cr_text(CR_SQX(x), cy, n->quality, qs, 1, CR_L, sx, cr_rgb(n->col_quality, cr), T_BG, 0);
        x += wq + P8(2);
    }
    if (n->sup[0])
        cr_text(CR_SQX(x + P8(1)), cy - (int32_t)(size * 133u), n->sup, ss, 1, CR_L, sx, cr_rgb(n->col_sup, CR_RED), T_BG, 0);
#undef CR_SQX
}

/* the 27-key strip: 16 white keys across 224 px from x 8, black keys 8 px over the gaps; y, h px */
static void cr_keyboard(const cr_screen_t *s, int32_t y, int32_t h)
{
    uint32_t k, place = 0;
    int32_t bh16 = h * 16 * 6 / 10;
    for (k = 0; k < CR_KEYS; k++) {
        int lit = (s->lit >> k) & 1u;
        int32_t x;
        if (cr_key_black(k)) continue;
        x = 8 + (int32_t)place * 14;
        cr_frect(x * 16 + 8, y * 16, 13 * 16, h * 16, lit ? cr_rgb(s->lit_col[k], CR_RED) : T_KEY);
        if (s->key_label[k][0])
            cr_text(P8(x) + 7 * 256, P8(y + h - 3), s->key_label[k], 7, 1, CR_C, 4096, T_BG, T_KEY, 0);
        place++;
    }
    for (k = 0, place = 0; k < CR_KEYS; k++) {
        int lit = (s->lit >> k) & 1u;
        int32_t x;
        if (!cr_key_black(k)) { place++; continue; }
        x = 8 + (int32_t)place * 14 - 4;
        cr_frect(x * 16 - 8, y * 16 - 8, 9 * 16, bh16 + 16, T_LINE);
        cr_frect(x * 16 + 8, y * 16 + 8, 7 * 16, bh16 - 16, lit ? cr_rgb(s->lit_col[k], CR_YELLOW) : T_BG);
        if (s->key_label[k][0])
            cr_text(P8(x) + 4 * 256, (y * 16 + bh16) * 16 - P8(2), s->key_label[k], 6, 1, CR_C, 4096, lit ? T_BG : T_MID,
                    T_BG, 0);
    }
}

/* the Chord view's Roman numeral (0.22, the KEY layer's Numerals): the voicing's blue, bold 16 px (the notes line's
 * weight), centred on baseline 44, above the chord name. The big name (104 px) leaves the gap as it is; the arp's
 * (44 px on baseline 78, its superscript's top on row 42) moves down CR_NUM_ARP_DY while numeral_on:
 * 4 px between the numeral and the tallest name */
#define CR_NUM_PX 16u
#define CR_NUM_Y (CR_PY0 + 16)
#define CR_NUM_ARP_DY 6
static void cr_p_chord(const cr_screen_t *s, const cr_frame_t *fr, int32_t ph)
{
    int ringed = s->ring_on;
    uint32_t size = s->size ? s->size : 104u;
    int32_t extra = (s->line[0] ? 256 : 0) + (s->n_notes ? 410 : 0) + (ringed && s->n_notes ? 512 : 0);  /* Q8 */
    int32_t cy = P8(CR_PY0) + P8(ph) / 2 + (int32_t)(size * 87u) - extra * 9, ly = P8(CR_PY0 + ph - 10 - (ringed ? 22 : 0));
    int32_t sq = (s->squeeze ? (int32_t)s->squeeze << 4 : 4096) * fr->sq >> 12;
    uint16_t under = s->block ? cr_rgb(s->block, CR_RED) : T_BG;
    if (s->block) cr_fill(0, CR_PY0, 240, ph, under);
    if (!s->name.root[0] && !(fr->from && s->from.root[0])) return;
    cr_name(fr->from ? &s->from : &s->name, P8(120), cy, size, 224, sq);
    if (s->numeral[0])                   /* the Roman numeral, in the gap between the top line and the name */
        cr_text(P8(120), P8(CR_NUM_Y), s->numeral, CR_NUM_PX, 1, CR_C, 4096, CR_NAMED[CR_COL_BLUE], under, 0);
    if (s->line[0]) {
        cr_text(P8(120), ly, s->line, 14, 0, CR_C, 4096, cr_rgb(s->line_col, T_MID), under, 0);
        ly -= P8(18);
    }
    if (s->n_notes) {                    /* the notes line: plain bold text, extensions marked by a block. Wider
                                          * than 228 px (a progression's 8 notes): 6 px apart, then 11 px type */
        uint32_t i, px = s->n_notes > 5u ? 13u : 16u, pass;
        int32_t w[CR_NOTES_MAX], total = 0, x, y = ly - P8(12), gap = P8(14);
        for (pass = 0; pass < 3u; pass++) {
            if (pass == 1u) gap = P8(6);
            if (pass == 2u) px = 11u;
            for (i = 0, total = 0; i < s->n_notes; i++) {
                w[i] = cr_tw(s->note[i].t, px, 1);
                total += w[i] + (i ? gap : 0);
            }
            if (total <= P8(228)) break;
        }
        x = P8(120) - total / 2;
        for (i = 0; i < s->n_notes; i++) {
            uint16_t c = cr_rgb(s->note[i].col, CR_WHITE);
            cr_text(x, y + P8(5), s->note[i].t, px, 1, CR_L, 4096, c, under, 0);
            if (s->note[i].mark) cr_frect(x >> 4, (y >> 4) + 160, w[i] >> 4, 48, c);
            x += w[i] + gap;
        }
    }
}

static const char *cr_item(const cr_screen_t *s, int32_t i)
{
    int32_t k = i - (int32_t)s->item0;
    return i >= 0 && i < (int32_t)s->n_items && k >= 0 && k < (int32_t)CR_PICK_MAX ? s->item[k] : "";
}

/* the picker's square position marks: n of them centred on x 120 at row y, the selected one in col */
static void cr_pick_marks(int32_t n, int32_t sel, int32_t y, uint16_t col)
{
    int32_t mw = 200 / n - 3, gap = 4, x0, i;
    if (mw > 8) mw = 8;
    if (mw < 1) mw = 1;
    x0 = 120 - (n * mw + (n - 1) * gap) / 2;
    for (i = 0; i < n; i++)
        cr_fill(x0 + i * (mw + gap), y, mw, 4, i == sel ? col : T_LINE);
}
/* a horizontal picker's neighbours: 13 px dim at lx (left) and rx (right), on baseline base - 4 (Q8), cut to room
 * (lx < 0: no left one: the loop editor's playing name stands there, cr_lm_now) */
static void cr_pick_sides(const cr_screen_t *s, int32_t n, int32_t sel, int32_t base, int32_t lx, int32_t rx,
                          int32_t room)
{
    if (sel > 0 && room > P8(24) && lx >= 0)
        cr_text_fit(P8(lx), base - P8(4), cr_item(s, sel - 1), 13, 0, CR_L, T_DIM, T_BG, room);
    if (sel < n - 1 && room > P8(24)) {
        char b[48];
        int cut = cr_fit(b, sizeof b, cr_item(s, sel + 1), 13, 0, room);
        cr_text(P8(rx), base - P8(4), b, 13, 0, CR_R, 4096, T_DIM, T_BG, cut ? 9u : 0u);
    }
}
/* the picker's item, huge, squeezed to maxw, centred on x 120 on baseline base (Q8); sliding (fr->slide): the old
 * one out and the new one in inside the item's box (horiz: x 120 +- maxw / 2; else the rows y0 .. y1, Q8) */
static void cr_pick_item(const cr_screen_t *s, const cr_frame_t *fr, int32_t sel, int32_t size, int32_t maxw,
                         int horiz, int32_t base, int32_t y0, int32_t y1, uint16_t col)
{
    const char *big = cr_item(s, sel);
    int32_t w = cr_tw(big, (uint32_t)size, 1), sx = w > P8(maxw) ? ((P8(maxw) << 12) / w) : 4096;
    if (fr->slide && s->slide) {
        const char *old = cr_item(s, sel - s->slide);
        int32_t wo = cr_tw(old, (uint32_t)size, 1), so = wo > P8(maxw) ? ((P8(maxw) << 12) / wo) : 4096;
        int32_t pitch = horiz ? P8(maxw / 2 + 60) : y1 - y0, d = (pitch * fr->slide) >> 12;
        int32_t dir = s->slide > 0 ? 1 : -1;
        if (horiz) {
            cr_clip_set(120 - maxw / 2 - 4, 0, 120 + maxw / 2 + 4, 240);
            cr_text(P8(120) + dir * d, base, big, (uint32_t)size, 1, CR_C, sx, col, T_BG, 32u);
            cr_text(P8(120) + dir * (d - pitch), base, old, (uint32_t)size, 1, CR_C, so, col, T_BG, 32u);
        } else {
            cr_clip_set(0, y0 >> 8, 240, ((y1 + 255) >> 8) + 4);   /* (+4: descenders) */
            cr_text(P8(120), base + dir * d, big, (uint32_t)size, 1, CR_C, sx, col, T_BG, 32u);
            cr_text(P8(120), base + dir * (d - pitch), old, (uint32_t)size, 1, CR_C, so, col, T_BG, 32u);
        }
        cr_clip_all();
    } else {
        cr_text(P8(120), base, big, (uint32_t)size, 1, CR_C, sx, col, T_BG, 0);
    }
}

/* a favourite's star: five points, the first up, in the role yellow (CR_STAR_COL), centre and outer radius in Q4.
 * Five triangles, each a point with the two inner corners across from it: together the whole star, no seam (a
 * triangle's inner edge lies inside two others). The font has no star and a glyph would be one size */
#define CR_STAR_COL CR_COL_YELLOW
static void cr_star(int32_t cx, int32_t cy, int32_t r)
{
    int32_t x[10], y[10], k;
    for (k = 0; k < 10; k++) {
        int32_t rr = k & 1 ? r * 98 / 256 : r;   /* the inner corners at 0.382 r */
        uint32_t a = (uint32_t)k * 65536u / 10u;
        x[k] = cx + ((rr * cr_sin(a)) >> 14);
        y[k] = cy - ((rr * cr_cos(a)) >> 14);
    }
    for (k = 0; k < 10; k += 2)
        cr_tri(x[k], y[k], x[(k + 3) % 10], y[(k + 3) % 10], x[(k + 7) % 10], y[(k + 7) % 10], cr_rgb(CR_STAR_COL, 0));
}
/* a name with the star before it, the two centred on x = 120: the star's box is 2 r wide, then a gap; returns the
 * name's left edge (Q8). base: the name's baseline (Q8), px its size */
static int32_t cr_star_name(const char *name, int32_t base, uint32_t px, int32_t extra)
{
    int32_t r = (int32_t)px * 3 / 8, gap = (int32_t)px / 4, tw = cr_tw(name, px, 1);
    int32_t x0 = P8(120) - (tw + extra + P8(2 * r + gap)) / 2;
    cr_star((x0 >> 4) + r * 16, (base >> 4) - (int32_t)px * 16 * 9 / 25, r * 16);
    return x0 + P8(2 * r + gap);
}

static void cr_p_picker(const cr_screen_t *s, const cr_frame_t *fr, int32_t ph)
{
    int ringed = s->ring_on, horiz = s->orient == 1;
    int32_t n = s->n_items, sel = s->sel < n ? s->sel : n - 1, size = s->size ? s->size : horiz ? 36 : 40;
    int32_t maxw = horiz ? (ringed ? 120 : 150) : (ringed ? 170 : 224);
    int32_t bigh = size * 282, valh = s->value[0] ? P8(26) : 0, nbh = horiz ? 0 : P8(22);   /* Q8 */
    int32_t labelh = s->label[0] ? P8(18) : 0, marksh = ringed ? 0 : P8(10);
    int32_t stack = nbh + bigh + valh + nbh, top = P8(CR_PY0) + (P8(ph) - labelh - marksh - stack) / 2 - P8(2);
    int32_t base = top + nbh + bigh * 4 / 5;
    uint16_t col = cr_rgb(s->col, CR_WHITE);
    const char *big = cr_item(s, sel);
    if (s->title[0]) cr_text(P8(10), P8(CR_PY0 + 16), s->title, 14, 1, CR_L, 4096, cr_rgb(s->title_col, T_MID), T_BG, 0);
    if (horiz) {
        int32_t lx = ringed ? 36 : 6, rx = ringed ? 204 : 234, bw = cr_tw(big, (uint32_t)size, 1);
        if (bw > P8(maxw)) bw = P8(maxw);
        cr_pick_sides(s, n, sel, base, lx, rx, (P8(rx - lx) - bw) / 2 - P8(10));
    } else {
        if (sel > 0) cr_text_fit(P8(120), top + P8(14), cr_item(s, sel - 1), 15, 0, CR_C, T_DIM, T_BG, P8(maxw));
        if (sel < n - 1)
            cr_text_fit(P8(120), top + nbh + bigh + valh + P8(16), cr_item(s, sel + 1), 15, 0, CR_C, T_DIM, T_BG, P8(maxw));
    }
    cr_pick_item(s, fr, sel, size, maxw, horiz, base, top + nbh, top + nbh + bigh, col);
    if (s->value[0] && s->star)          /* a favourite: the star, then the name */
        cr_text(cr_star_name(s->value, top + nbh + bigh + P8(20), 20, 0), top + nbh + bigh + P8(20), s->value, 20, 1, CR_L,
                4096, col, T_BG, 0);
    else if (s->value[0]) cr_text(P8(120), top + nbh + bigh + P8(20), s->value, 20, 1, CR_C, 4096, col, T_BG, 0);
    if (s->label[0])
        cr_text(P8(120), P8(CR_PY0 + ph) - marksh - P8(ringed ? 34 : 8), s->label, 13, 0, CR_C, 4096, T_MID, T_BG, 0);
    if (n > 1 && !ringed)                /* square position marks */
        cr_pick_marks(n, sel, CR_PY0 + ph - 8, col);
}

static void cr_p_meter(const cr_screen_t *s, const cr_frame_t *fr, int32_t ph)
{
    uint16_t col = cr_rgb(s->col, CR_RED);
    uint32_t size = s->size ? s->size : 104u, n = cr_segs(s), i;
    int32_t vy = P8(CR_PY0) + P8(ph) / 2 + (int32_t)(size * 51u), w = cr_tw(s->value, size, 1);
    int32_t sx = w > P8(232) ? ((P8(232) << 12) / w) : 4096;
    int32_t gap = 4 * 16, sw = (224 * 16 - gap * (int32_t)(n - 1u)) / (int32_t)n, my = CR_PY0 + ph - 46;
    int32_t mh = s->thick ? s->thick : 14;
    cr_text(P8(120), vy, s->value, size, 1, CR_C, sx, col, T_BG, 0);
    if (s->line[0])                      /* a line over the value (a pool's read-out: the part's engine, in orange) */
        cr_text_fit(P8(120), P8(CR_PY0 + 26), s->line, 15, 1, CR_C, cr_rgb(s->line_col, T_MID), T_BG, P8(150));
    if (s->sub[0] && s->star) {         /* a favourite: the star, the name (and its square), centred together */
        int32_t tw = cr_tw(s->sub, 15, 1), x0 = cr_star_name(s->sub, vy + P8(22), 15, s->sub_mark ? P8(9) : 0);
        cr_text(x0, vy + P8(22), s->sub, 15, 1, CR_L, 4096, col, T_BG, 0);
        if (s->sub_mark)
            cr_frect((x0 + tw + P8(4)) >> 4, ((vy + P8(22)) >> 4) - 6 * 16, 5 * 16, 5 * 16, col);
    } else if (s->sub[0] && s->sub_mark) {     /* the name and a 5 px square after it, centred together */
        int32_t tw = cr_tw(s->sub, 15, 1), x0 = P8(120) - (tw + P8(9)) / 2;
        cr_text(x0, vy + P8(22), s->sub, 15, 1, CR_L, 4096, col, T_BG, 0);
        cr_frect((x0 + tw + P8(4)) >> 4, ((vy + P8(22)) >> 4) - 6 * 16, 5 * 16, 5 * 16, col);
    } else if (s->sub[0]) {
        cr_text(P8(120), vy + P8(22), s->sub, 15, 1, CR_C, 4096, col, T_BG, 0);
    }
    for (i = 0; i < n; i++)
        cr_frect(8 * 16 + (int32_t)i * (sw + gap), my * 16, sw, mh * 16, i < fr->filled ? col : T_LINE);
    if (s->label[0])                     /* (the favourites filter on: the line in the star's colour) */
        cr_text(P8(120), P8(CR_PY0 + ph - 10), s->label, 14, 0, CR_C, 4096, s->label_fav ? cr_rgb(CR_STAR_COL, 0) : T_MID,
                T_BG, 0);
    if (s->title[0]) cr_text(P8(10), P8(CR_PY0 + 16), s->title, 14, 1, CR_L, 4096, T_MID, T_BG, 0);
}

static void cr_p_stripes(const cr_screen_t *s, const cr_frame_t *fr, int32_t ph)
{
    int32_t bh = s->band ? s->band : 16, gap = s->gap ? s->gap : 8, nb = s->n_bands ? s->n_bands : 3, i, j;
    int32_t total = nb * bh + (nb - 1) * gap, y0 = CR_PY0 + ph - total - 24;
    for (i = 0; i < nb && i < 4; i++) {
        int32_t yb = y0 + i * (bh + gap);
        uint16_t c = cr_rgb(s->bands[i], CR_RED);
        for (j = 0; j < bh; j++) {       /* a row at a time: the skew shifts each row */
            int32_t x16 = ((-60 * 256 + fr->shift + fr->sweep[i] + s->skew * j) >> 4);
            cr_frect(x16, (yb + j) * 16, 360 * 16, 16, c);
        }
    }
    if (s->title[0] && !fr->name_off) {
        uint32_t px = s->title_px ? s->title_px : 34u;
        int32_t w = cr_tw(s->title, px, 1), sx = w > P8(224) ? ((P8(224) << 12) / w) : 4096;
        cr_text(P8(120), P8(s->title_y ? CR_PY0 + s->title_y : y0 - 22) - fr->name_dy, s->title, px, 1, CR_C, sx,
                cr_rgb(s->title_col, CR_WHITE), T_BG, 0);
    }
    if (s->foot[0]) cr_text(P8(120), P8(CR_PY0 + ph - 8), s->foot, 12, 0, CR_C, 4096, T_MID, T_BG, 0);
}

static void cr_p_keyboard(const cr_screen_t *s, int32_t ph)
{
    int32_t kh = ph - 64 < 52 ? ph - 64 : 52;
    if (s->name.root[0]) cr_name(&s->name, P8(120), P8(CR_PY0 + 40), 40, 224, 4096);
    else if (s->title[0])
        cr_text(P8(120), P8(CR_PY0 + 36), s->title, s->title_px ? s->title_px : 15u, 1, CR_C, 4096,
                cr_rgb(s->col, CR_RED), T_BG, 0);
    cr_keyboard(s, CR_PY0 + ph - kh - 8, kh);
}

static void cr_p_arp(const cr_screen_t *s, int32_t ph)
{
    int32_t n = s->n_notes, by = CR_PY0 + ph - 46, gap16 = n > 1 ? 200 * 16 / (n - 1) : 0, x0, i, pos = s->pos;
    if (gap16 > 52 * 16) gap16 = 52 * 16;
    if (s->name.root[0])                 /* (with a numeral above it the name sits CR_NUM_ARP_DY lower) */
        cr_name(&s->name, P8(120), P8(CR_PY0 + 50 + (s->numeral_on ? CR_NUM_ARP_DY : 0)), s->size ? s->size : 44u, 224, 4096);
    if (s->numeral[0] && s->name.root[0])
        cr_text(P8(120), P8(CR_NUM_Y), s->numeral, CR_NUM_PX, 1, CR_C, 4096, CR_NAMED[CR_COL_BLUE], T_BG, 0);
    cr_fill(14, by + 17, 212, 2, T_LINE);
    x0 = 120 * 16 - (n - 1) * gap16 / 2;                            /* Q4 */
    if (pos >= 0 && pos < n && n > 1) {                            /* the dotted hop to the next note */
        int32_t xa = x0 + pos * gap16, xb = x0 + ((pos + 1) % n) * gap16;
        cr_quad(xa, (by - 22) * 16, (xa + xb) / 2, (by - 70) * 16, xb, (by - 2) * 16, 32, 48, 112,
                cr_rgb(s->hop_col, T_MID));
    }
    for (i = 0; i < n; i++) {
        uint16_t c = cr_rgb(s->note[i].col, CR_WHITE);
        int32_t x = x0 + i * gap16;
        if (i == pos) {                  /* the sounding note on its block */
            int32_t w = (cr_tw(s->note[i].t, 15, 1) >> 8) + 14;
            cv_rrect((x >> 4) - w / 2, by - 22 - 12, w, 24, 3, c, T_BG);
            cr_text(x << 4, P8(by - 22 + 5), s->note[i].t, 15, 1, CR_C, 4096, T_BG, c, 0);
        } else {
            cr_text(x << 4, P8(by + 5), s->note[i].t, 13, 1, CR_C, 4096, c, T_BG, 0);
        }
    }
    if (s->line[0]) cr_text(P8(120), P8(CR_PY0 + ph - 8), s->line, 13, 0, CR_C, 4096, cr_rgb(s->line_col, T_MID), T_BG, 0);
}

/* ------------------------------------------------------ the sound editor --- */
/* CR_K_EDIT8 and CR_K_STACK (../ChoralRootFM1Designer/FORMAT.md "Sound editor panels"): the whole screen, no
 * header. The title line (0..24), then edit8: an optional wide band (24..120: the AHDSR or the filter's response)
 * over two rows of four cells (124..180, 184..240; one row under it: 124..224 at full size; without the band 30..130,
 * 134..234), or stack: column headings
 * at y 36 over N rows sharing 41..239. The active row is in the knob colours (blue orange white green) with a 2 px
 * bar under each cell, the others grey; the hot cell's value sits on a block of its colour. Cheap by design: text,
 * rectangles, small glyphs, at most two polylines of <= 12 segments in the band. No motion: a change is drawn at
 * once, and cr_draw composes only the strips of the parts that changed (the band, a row; cr_ed_strips). A cell
 * whose parameter the matrix modulates has a 4 px mark at its top right (CR_CF_MARK). */
static const uint8_t CR_KC[4] = {CR_COL_BLUE, CR_COL_ORANGE, CR_COL_WHITE, CR_COL_GREEN};

/* the VA's MORPH wave (eng_va.c va_morph, its alignment) at x (Q12 of a cycle, 0..4096; left: the limit from the
 * left at a jump): shape k (0 sine, 1 triangle, 2 saw, 3 ramp, 4 square, 5 the pulse rising at e), +-4096 (up +).
 * Drawn full height each (the device's square is half the saw's: legibility first) */
static int32_t cr_mshape(uint32_t k, int32_t x, int left, int32_t e)
{
    int32_t p = (x + 3072) & 4095;
    switch (k) {
    case 0: return -(cr_sin((uint32_t)x << 4) >> 2);                  /* the sine half a cycle on */
    case 1: return p < 2048 ? 4 * p - 4096 : 12288 - 4 * p;           /* the triangle three quarters on */
    case 2: return 2 * x - 4096;                                      /* the saw */
    case 3: return x < 2048 || (x == 2048 && left) ? -2 * x : 8192 - 2 * x;   /* the ramp: the saw half on, reversed */
    case 4: e = 2048; /* fall through */
    default: return x < e || (x == e && left) ? -4096 : 4096;
    }
}
/* the morph position m (0..127) at x: the crossfade of the neighbouring shapes (the positions 0 24 48 72 96), past 96
 * the pulse narrowing from 50 % to ~5 % (its edge at e) */
static int32_t cr_morph_y(int32_t m, int32_t x, int left, int32_t e)
{
    int32_t k = m / 24, f = m % 24;
    if (m >= 96) return cr_mshape(5, x, left, e);
    return (cr_mshape((uint32_t)k, x, left, e) * (24 - f) + cr_mshape((uint32_t)k + 1u, x, left, e) * f) / 24;
}

/* a stroked rectangle (Q4): its edges lw wide centred on the outline, as four rectangles that do not overlap */
static void cr_srect(int32_t x, int32_t y, int32_t w, int32_t h, int32_t lw, uint16_t col)
{
    cr_frect(x - lw / 2, y - lw / 2, w + lw, lw, col);
    cr_frect(x - lw / 2, y + h - lw / 2, w + lw, lw, col);
    cr_frect(x - lw / 2, y + lw / 2, lw, h - lw, col);
    cr_frect(x + w - lw / 2, y + lw / 2, lw, h - lw, col);
}

/* the moon's lit part: within the circle (cx, cy, r), the right half less the ellipse (rx, r) for k >= 0 (a crescent),
 * the right half plus it for k < 0 (gibbous); 4 x 4 samples a pixel (Q4), a pixel whose four corner samples agree
 * taken whole (the shapes are smooth at a pixel's scale) */
static int cr_moon_in(int32_t dx, int32_t dy, int64_t r2, int64_t rx2, int64_t e, int gib)
{
    int64_t el;
    if ((int64_t)dx * dx + (int64_t)dy * dy > r2) return 0;
    el = (int64_t)dx * dx * r2 + (int64_t)dy * dy * rx2;   /* <= e: inside the ellipse */
    return gib ? (dx >= 0 || el <= e) : (dx >= 0 && el >= e);
}
static void cr_moon_fill(int32_t cx, int32_t cy, int32_t r, int32_t rx, int gib, uint16_t col)
{
    int32_t x0 = (cx - r) >> 4, x1 = (cx + r + 15) >> 4, y0 = (cy - r) >> 4, y1 = (cy + r + 15) >> 4, i, j;
    int64_t r2 = (int64_t)r * r, rx2 = (int64_t)rx * rx, e = r2 * rx2;
    if (y0 < cr_row0()) y0 = cr_row0();
    if (y1 > cr_row1()) y1 = cr_row1();
    for (j = y0; j < y1; j++)
        for (i = x0; i < x1; i++) {
            int32_t ax = i * 16 + CR_SS[0] - cx, bx = i * 16 + CR_SS[3] - cx, ay = j * 16 + CR_SS[0] - cy,
                    by = j * 16 + CR_SS[3] - cy;
            uint32_t n = (uint32_t)(cr_moon_in(ax, ay, r2, rx2, e, gib) + cr_moon_in(bx, ay, r2, rx2, e, gib) +
                                    cr_moon_in(ax, by, r2, rx2, e, gib) + cr_moon_in(bx, by, r2, rx2, e, gib)), a, b;
            if (n == 4u) n = 16u;
            else if (n) {
                for (n = 0, b = 0; b < 4u; b++)
                    for (a = 0; a < 4u; a++)
                        n += (uint32_t)cr_moon_in(i * 16 + CR_SS[a] - cx, j * 16 + CR_SS[b] - cy, r2, rx2, e, gib);
            }
            if (n) cr_blend(i, j, col, n * 16u);
        }
}

/* the parameter pictograms (FORMAT.md "cell glyphs", the designer's drawPicto) in the box x, y, w, h (Q4): flat 2 px
 * strokes in col (cr_poly, round joins; a path that retraces a segment is still one coverage), filled parts in col,
 * 2 px inside the box; pct, pct2 Q8 (256 = 1) */
static void cr_picto(uint32_t g, int32_t x, int32_t y, int32_t w, int32_t h, uint16_t col, int32_t pct, int32_t pct2)
{
    int32_t lw = 32, x0 = x + lw, x1 = x + w - lw, y0 = y + lw, y1 = y + h - lw, W = x1 - x0, H = y1 - y0;
    int32_t cx = x + w / 2, cy = y + h / 2, mn = W < H ? W : H, k;
    int16_t p[48 * 2];
    uint32_t np = 0;
#define CR_PT(px16, py16) (p[2 * np] = (int16_t)(px16), p[2 * np + 1] = (int16_t)(py16), np++)
    switch (g) {
    case CR_G_ROOM: {                               /* one-point perspective: the box is fixed (the glyph box, at most
                                                     * 1.4 : 1); only the far wall changes, 22 % (pct 0) .. 70 % (1)
                                                     * of the box about its centre: a small room's far wall is small,
                                                     * a large room's large (the owner 2026-10-11), never on the box */
        int32_t bw = H * 14 / 10 < W ? H * 14 / 10 : W, bx = cx - bw / 2, by = y0, f = 901 + 1966 * pct / 256;
        int32_t iw = bw * f >> 12, ih = H * f >> 12, ix = cx - iw / 2, iy = cy - ih / 2;
        cr_srect(bx, by, bw, H, lw, col);            /* the box and the far wall: rectangles (cheap), the corner */
        cr_srect(ix, iy, iw, ih, lw, col);           /* lines: four short polylines */
        for (k = 0; k < 4; k++) {
            np = 0;
            CR_PT(k & 1 ? bx + bw : bx, k & 2 ? by + H : by);
            CR_PT(k & 1 ? ix + iw : ix, k & 2 ? iy + ih : iy);
            cr_poly(p, np, lw, 0, 0, col);
        }
        break;
    }
    case CR_G_MOON: {                               /* lit 8 % (a thin crescent) .. 100 % (full); the rim outlined */
        int32_t r = mn / 2, f = 328 + 3768 * pct / 256, kk = 4096 - 2 * f, rx = r * (kk < 0 ? -kk : kk) >> 12;
        cr_moon_fill(cx, cy, r, rx > 0 ? rx : 1, kk < 0, col);
        cr_arc(cx, cy, r, lw, 0, 65536u, 0, 0, 0, col);
        break;
    }
    case CR_G_ECHOES: {                             /* a struck bar and its repeats: spacing pct, feedback pct2 */
        int32_t bw = 48, sp = 80 + ((W - bw) / 2 - 80) * pct / 256, d = 819 + 3072 * pct2 / 256, bh = H, bx;
        if (!pct && !pct2) {                        /* both 0: nothing struck (the loop's Quantize "none"): the
                                                     * baseline alone */
            cr_frect(x0, y1, W, 16, col);
            break;
        }
        if (sp < 64) sp = 64;
        cr_frect(x0, y1 - H, bw, H, col);
        for (bx = x0 + sp; bx + bw <= x1; bx += sp) {
            bh = bh * d >> 12;
            if (bh < 24) break;
            cr_frect(bx, y1 - bh, bw, bh, col);
        }
        cr_frect(x0, y1, W, 16, col);               /* the baseline, 1 px */
        break;
    }
    case CR_G_LFO: {                                /* 1 .. 5 cycles (pct), nearly flat .. full height (pct2) */
        int32_t cyc = 4096 + 16384 * pct / 256, a = (H / 2) * (328 + 3768 * pct2 / 256) >> 12;
        int32_t n = 8 * ((cyc + 4095) >> 12);
        if (n < 16) n = 16;
        if (n > 44) n = 44;
        for (k = 0; k <= n; k++)
            CR_PT(x0 + k * W / n, cy - ((cr_sin((uint32_t)(k * cyc * 16 / n)) * a) >> 14));
        cr_poly(p, np, lw, 0, 0, col);
        break;
    }
    case CR_G_CLIP: {                               /* one sine cycle into a clipper, gain 1 .. 10 */
        int32_t gq = 4096 + 36864 * pct / 256, a = H / 2, v;
        for (k = 0; k <= 32; k++) {
            v = (cr_sin((uint32_t)(k * 65536 / 32)) * gq) >> 12;   /* Q14 */
            v = v > 16384 ? 16384 : v < -16384 ? -16384 : v;
            CR_PT(x0 + k * W / 32, cy - ((v * a) >> 14));
        }
        if (pct > 25)                               /* the clip levels, dashed 1 px (2 on, 2 off) */
            for (k = x0; k < x1; k += 64) {
                int32_t dw = x1 - k < 32 ? x1 - k : 32;
                cr_frect(k, y0 - 8, dw, 16, col);
                cr_frect(k, y1 - 8, dw, 16, col);
            }
        cr_poly(p, np, lw, 0, 0, col);
        break;
    }
    case CR_G_MIX: {                                /* dry (back, outlined) behind wet (front, filled to pct) */
        int32_t s = mn * 72 / 100, off = mn - s, bx = cx - (s + off) / 2, by = cy - (s + off) / 2, fx = bx + off,
                fy = by + off, fh = s * pct / 256;
        cr_srect(bx, by, s, s, lw, col);
        cr_frect(fx - lw, fy - lw, s + 2 * lw, s + 2 * lw, T_BG);   /* the front square hides the back one */
        if (fh > 0) cr_frect(fx, fy + s - fh, s, fh, col);
        cr_srect(fx, fy, s, s, lw, col);
        break;
    }
    case CR_G_GATE: {                               /* a pulse 10 .. 100 % of the box wide */
        int32_t pw = W * (26 + 230 * pct / 256) / 256, top = y0 + H * 12 / 100;
        CR_PT(x0, y1); CR_PT(x0, top); CR_PT(x0 + pw, top); CR_PT(x0 + pw, y1); CR_PT(x1, y1);
        cr_poly(p, np, lw, 0, 0, col);
        break;
    }
    case CR_G_RANGE: {                              /* a span with end stops, a thick segment 10 .. 100 % from the left */
        int32_t t = H / 4;
        CR_PT(x0, cy - t); CR_PT(x0, cy + t); CR_PT(x0, cy); CR_PT(x1, cy); CR_PT(x1, cy - t); CR_PT(x1, cy + t);
        cr_poly(p, np, lw, 0, 0, col);
        cr_frect(x0, cy - 40, W * (26 + 230 * pct / 256) / 256, 80, col);
        break;
    }
    case CR_G_ARROW: {                              /* up / down / up and down / random (three dots) */
        int32_t hd = H * 32 / 100 < W * 30 / 100 ? H * 32 / 100 : W * 30 / 100, n = 0, ax[2], up[2];
        if (pct < 64) ax[0] = cx, up[0] = 1, n = 1;
        else if (pct < 128) ax[0] = cx, up[0] = 0, n = 1;
        else if (pct < 192) {
            int32_t dx = W * 22 / 100 < hd * 14 / 10 ? W * 22 / 100 : hd * 14 / 10;
            ax[0] = cx - dx, up[0] = 1, ax[1] = cx + dx, up[1] = 0, n = 2;
        } else {
            int32_t d = mn * 32 / 100;
            cr_disc(cx, cy - d, 40, col);
            cr_disc(cx - d * 95 / 100, cy + d * 6 / 10, 40, col);
            cr_disc(cx + d * 95 / 100, cy + d * 6 / 10, 40, col);
        }
        for (k = 0; k < n; k++) {
            int32_t t = up[k] ? y0 : y1, b = up[k] ? y1 : y0, sg = up[k] ? 1 : -1;
            np = 0;
            CR_PT(ax[k], b); CR_PT(ax[k], t); CR_PT(ax[k] - hd, t + sg * hd); CR_PT(ax[k], t); CR_PT(ax[k] + hd, t + sg * hd);
            cr_poly(p, np, lw, 0, 0, col);
        }
        break;
    }
    case CR_G_SHIFT: {                              /* five staff lines, a square on line round(4 pct) from the bottom */
        int32_t sq = H / 5 > 64 ? H / 5 : 64, ly0 = y0 + sq / 2, ly1 = y1 - sq / 2, gap = (ly1 - ly0) / 4;
        int32_t l2 = W < H * 16 / 10 ? W : H * 16 / 10, yy;
        for (k = 0; k < 5; k++)
            cr_frect(cx - l2 / 2 - lw / 2, ly0 + k * gap - lw / 2, l2 + lw, lw, col);
        yy = ly1 - ((pct * 4 + 128) >> 8) * gap;
        cr_frect(cx - sq / 2, yy - sq / 2, sq, sq, col);
        break;
    }
    case CR_G_HARM: {                               /* one cycle: a sine at 0.5, + the odd series -> 1, + all -> 0 */
        int32_t so = 2 * pct - 256, sa = 256 - 2 * pct, v[41], mx = 1, j;   /* (Q8) */
        if (so < 0) so = 0;
        if (sa < 0) sa = 0;
        for (k = 0; k <= 40; k++) {
            uint32_t ph = (uint32_t)(k * 65536 / 40);
            int32_t a = cr_sin(ph);                                  /* Q14 */
            for (j = 2; j <= 7; j++)
                a += cr_sin(ph * (uint32_t)j) * ((j & 1 ? so : 0) + sa) / (256 * j);
            v[k] = a;
            if ((a < 0 ? -a : a) > mx) mx = a < 0 ? -a : a;
        }
        for (k = 0; k <= 40; k++) CR_PT(x0 + k * W / 40, cy - v[k] * (H / 2) / mx);
        cr_poly(p, np, lw, 0, 0, col);
        break;
    }
    case CR_G_DETUNE: {                             /* a 16-segment line, the joints jittered by pct, segments dropped */
        /* the designer's sin(i 78.233 + 1.7), Q8: a fixed jitter, the same every frame */
        static const int16_t JT[17] = {254, -252, 227, -180, 117, -42, -36, 111, -175, 223, -251, 255, -235, 193, -133,
                                       61, 17};
        int32_t a = H * 115 / 256 * pct / 256;                       /* 0.45 H pct */
        for (k = 0; k < 16; k++) {
            int skip = pct > 179 ? (k & 1) : pct > 76 ? k % 3 == 2 : 0;
            if (skip) {
                if (np >= 2u) cr_poly(p, np, lw, 0, 0, col);
                np = 0;
                continue;
            }
            if (!np) CR_PT(x0 + W * k / 16, cy + JT[k] * a / 256);
            CR_PT(x0 + W * (k + 1) / 16, cy + JT[k + 1] * a / 256);
        }
        if (np >= 2u) cr_poly(p, np, lw, 0, 0, col);
        break;
    }
    /* the FX layer's (0.18, docs/FX.md): no designer mock-up, drawn here in the same manner (2 px strokes, filled
     * parts, a 1 px baseline) */
    case CR_G_TAIL: {                               /* the struck edge and its decay: each twelfth of the box the curve
                                                     * keeps 0.56 (pct 0: gone in a quarter) .. all (1: level, "Inf") */
        int32_t d = 2300 + 1796 * pct / 256, hh = H;
        CR_PT(x0, y1); CR_PT(x0, y0);
        for (k = 1; k <= 12; k++) {
            hh = hh * d >> 12;
            CR_PT(x0 + k * W / 12, y1 - hh);
        }
        cr_poly(p, np, lw, 0, 0, col);
        cr_frect(x0, y1, W, 16, col);
        break;
    }
    case CR_G_PRE: {                                /* a struck bar, the gap (0 .. 55 % of the box), the reverb's wedge */
        int32_t bw = 48, gx = x0 + bw + 32 + (W * 55 / 100) * pct / 256, top = y1 - H * 8 / 10;
        cr_frect(x0, y0, bw, H, col);
        CR_PT(gx, y1); CR_PT(gx, top); CR_PT(x1, y1);
        cr_poly(p, np, lw, 0, 0, col);
        cr_frect(x0, y1, W, 16, col);
        break;
    }
    case CR_G_CUT: {                                /* a high-pass response: the corner 25 .. 80 % along the box */
        int32_t xc = x0 + W * (64 + 141 * pct / 256) / 256, sw = W * 22 / 100, top = y0 + H * 15 / 100;
        CR_PT(x0, y1); CR_PT(xc - sw, y1); CR_PT(xc, top); CR_PT(x1, top);
        cr_poly(p, np, lw, 0, 0, col);
        break;
    }
    case CR_G_WIDTH: {                              /* two bars leaving the centre mark, 0 .. the box's sides */
        int32_t bw = 48, d = (W / 2 - bw / 2) * pct / 256, bh = H * 7 / 10;
        for (k = y0; k < y1; k += 64)               /* the centre, dashed 1 px (2 on, 2 off) */
            cr_frect(cx - 8, k, 16, y1 - k < 32 ? y1 - k : 32, col);
        cr_frect(cx - d - bw / 2, y1 - bh, bw, bh, col);
        cr_frect(cx + d - bw / 2, y1 - bh, bw, bh, col);
        cr_frect(x0, y1, W, 16, col);
        break;
    }
    case CR_G_SPREAD: {                             /* two rows of echoes (left over right): the upper one's spacing as
                                                     * CR_G_ECHOES', the lower one's 1 .. 1/2 of it */
        int32_t bw = 40, sp = 80 + ((W - bw) / 2 - 80) * pct / 256, rh = H / 2 - 24, r;
        if (sp < 64) sp = 64;
        for (r = 0; r < 2; r++) {
            int32_t by = r ? y1 : y0 + rh, s2 = r ? sp * (512 - pct2) / 512 : sp, bh = rh, bx;
            if (s2 < 56) s2 = 56;
            for (bx = x0; bx + bw <= x1 && bh >= 24; bx += s2) {
                cr_frect(bx, by - bh, bw, bh, col);
                bh = bh * 3 / 4;
            }
            cr_frect(x0, by, W, 16, col);
        }
        break;
    }
    case CR_G_SYNC: {
        if (pct < 128) {                            /* free: a clock face, its hands at three o'clock */
            int32_t r = mn / 2;
            cr_arc(cx, cy, r, lw, 0, 65536u, 0, 0, 0, col);
            CR_PT(cx, cy - r * 6 / 10); CR_PT(cx, cy); CR_PT(cx + r * 45 / 100, cy);
            cr_poly(p, np, lw, 0, 0, col);
        } else {                                    /* the tempo: two beamed notes */
            int32_t hr = H * 16 / 100 > 40 ? H * 16 / 100 : 40, dx = mn * 34 / 100, hy = y1 - hr;
            for (k = -1; k <= 1; k += 2) {
                int32_t sx = cx + k * dx + hr - lw / 2;
                cr_disc(cx + k * dx, hy, hr, col);
                np = 0;
                CR_PT(sx, hy); CR_PT(sx, y0 + lw);
                cr_poly(p, np, lw, 0, 0, col);
            }
            cr_frect(cx - dx + hr - lw, y0, 2 * dx + lw, 56, col);
        }
        break;
    }
    case CR_G_PING: {                               /* two walls and four repeats, each 0.7 of the last: on both walls
                                                     * at once (stereo), or left, right, left, right (ping-pong) */
        int32_t len = W * 42 / 100;
        cr_frect(x0, y0, lw, H, col);
        cr_frect(x1 - lw, y0, lw, H, col);
        for (k = 0; k < 4; k++) {
            int32_t yy = y0 + H * (1 + 2 * k) / 8 - lw / 2;
            if (pct < 128 || !(k & 1)) cr_frect(x0, yy, len, lw, col);
            if (pct < 128 || (k & 1)) cr_frect(x1 - len, yy, len, lw, col);
            len = len * 7 / 10;
        }
        break;
    }
    default: break;
    }
#undef CR_PT
}

/* the LFO wave k (CR_LW_*) at t (Q12 of a cycle, 0..4096), -16384..16384 (up +): the designer's lfowave */
static int32_t cr_lfo_y(uint32_t k, int32_t t)
{
    static const int16_t EX[17] = {16384, 7530, 1052, -3687, -7154, -9691, -11547, -12905, -13898, -14625, -15157,
                                   -15546, -15830, -16039, -16191, -16302, -16384};   /* 2 (e^-5t - e^-5) / (1 - e^-5) - 1 */
    static const int16_t RN[8] = {59, 78, -149, -155, -76, 73, -201, 254};           /* the random steps, Q8 */
    switch (k) {
    case CR_LW_TRI: return t < 1024 ? 16 * t : t < 3072 ? 32768 - 16 * t : 16 * t - 65536;
    case CR_LW_SQUARE: return t < 2048 ? 16384 : -16384;
    case CR_LW_SAW: return 8 * t - 16384;
    case CR_LW_RAMP: return 16384 - 8 * t;
    case CR_LW_EXP: {
        int32_t i = t >> 8, f = t & 255;
        return i >= 16 ? EX[16] : EX[i] + (EX[i + 1] - EX[i]) * f / 256;
    }
    case CR_LW_RANDOM: return RN[(t >> 9) > 7 ? 7 : t >> 9] * 64;
    default: return cr_sin((uint32_t)t << 4);
    }
}

/* CR_G_LFOWAVE in the box x, y, w, h (Q4): cyc cycles (1, or 2 in a span-2 cell) of wave k from pct (Q8) of a cycle on,
 * 2 px strokes 2 px inside the box; a 1.5 px tick at the left marks the start. The points: the breakpoints (corners,
 * both sides of a jump) and, for the smooth waves, 16 samples a cycle: <= 37 */
static void cr_lfowave(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t col, int32_t pct, uint32_t k, int32_t cyc)
{
    static const int16_t B_TRI[2] = {1024, 3072}, B_SQ[2] = {0, 2048}, B_0[1] = {0},
                         B_RN[8] = {0, 512, 1024, 1536, 2048, 2560, 3072, 3584};
    int32_t lw = 32, x0 = x + lw, x1 = x + w - lw, cy = y + h / 2, H = h - 2 * lw, wx0 = x0 + 64, WW = x1 - wx0;
    int32_t U = cyc * 4096, ph = pct * 16, n = 0, i, j, c;
    int32_t u[48];
    uint8_t jmp[48];
    const int16_t *B = B_0;
    int32_t nb = 1, smooth = 0, jumps = 1;
    int16_t p[48 * 2];
    uint32_t np = 0;
#define CR_PT2(px16, py16) (p[2 * np] = (int16_t)(px16), p[2 * np + 1] = (int16_t)(py16), np++)
    if (k >= CR_LW_N) k = CR_LW_SINE;
    switch (k) {
    case CR_LW_TRI: B = B_TRI; nb = 2; jumps = 0; break;
    case CR_LW_SQUARE: B = B_SQ; nb = 2; break;
    case CR_LW_RANDOM: B = B_RN; nb = 8; break;
    case CR_LW_SINE: nb = 0; smooth = 1; break;
    case CR_LW_EXP: smooth = 1; break;
    default: break;                                  /* saw, ramp: the jump at 0 */
    }
    u[n] = 0; jmp[n++] = 0;
    u[n] = U; jmp[n++] = 0;
    if (smooth)
        for (i = 1; i < cyc * 16; i++) u[n] = i * 256, jmp[n++] = 0;
    for (c = -1; c <= cyc; c++)
        for (j = 0; j < nb; j++) {
            int32_t v = c * 4096 + B[j] - ph;
            if (v > 0 && v < U && n < 46) u[n] = v, jmp[n++] = (uint8_t)jumps;
        }
    for (i = 1; i < n; i++)                           /* sort by position (a jump after a sample at the same place) */
        for (j = i; j && (u[j - 1] > u[j] || (u[j - 1] == u[j] && jmp[j - 1] > jmp[j])); j--) {
            int32_t t = u[j]; uint8_t q = jmp[j];
            u[j] = u[j - 1]; jmp[j] = jmp[j - 1];
            u[j - 1] = t; jmp[j - 1] = q;
        }
    for (i = 0; i < n && np + 2u <= 48u; i++) {
        int32_t t = (u[i] + ph) & 4095, px = wx0 + u[i] * WW / U;
        if (i + 1 < n && u[i + 1] == u[i] && !jmp[i]) continue;   /* (a sample under a jump: the jump draws it) */
        if (jmp[i] || i == n - 1)                   /* the value from the left (at the end: the cycle's last value) */
            CR_PT2(px, cy - cr_lfo_y(k, t ? t - 1 : 4096) * (H / 2) / 16384);
        if (i < n - 1)
            CR_PT2(px, cy - cr_lfo_y(k, t) * (H / 2) / 16384);
    }
    cr_poly(p, np, lw, 0, 0, col);
    if (np) cr_frect(x0 - 12, p[1] - 64, 24, 128, col);   /* the start tick, 1.5 px, 8 px tall */
#undef CR_PT2
}

/* ------------------------------------------------------- the p5 primitives --- */
/* The Prophet-5's controls (docs/LAYOUT-TOOL.md "The p5 style"): a free screen's elements (CR_K_FREE) and the P5 cell
 * glyphs (cr_cglyph CR_G_P5*) draw with these */
#define CR_RSQL 0x40u                    /* cr_box's r: the left corners square (a pair's right cap) */
#define CR_RSQR 0x80u                    /* .. the right ones (a pair's left cap) */
#define CR_P5_UNDER 12                   /* the baseline rule: a text under a dial or a cap sits 12 px under it */
/* a rounded outline lw px wide: the sides between the corners, the corners quarter arcs (cr_arc); sq: CR_RSQL / CR_RSQR */
static void cr_rline(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, int32_t lw, uint32_t sq, uint16_t c)
{
    int32_t rc, l, rr;
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    rc = r * 16 - lw * 8;                /* the line's middle, Q4 from the corner's centre */
    l = sq & CR_RSQL ? 0 : r;
    rr = sq & CR_RSQR ? 0 : r;
    cr_fill(x + l, y, w - l - rr, lw, c);
    cr_fill(x + l, y + h - lw, w - l - rr, lw, c);
    cr_fill(x, y + l, lw, h - 2 * l, c);
    cr_fill(x + w - lw, y + rr, lw, h - 2 * rr, c);
    if (rc <= 0) return;
    if (l) {
        cr_arc((x + r) * 16, (y + r) * 16, rc, lw * 16, 32768u, 16384u, 0, 0, 0, c);
        cr_arc((x + r) * 16, (y + h - r) * 16, rc, lw * 16, 16384u, 16384u, 0, 0, 0, c);
    }
    if (rr) {
        cr_arc((x + w - r) * 16, (y + r) * 16, rc, lw * 16, 49152u, 16384u, 0, 0, 0, c);
        cr_arc((x + w - r) * 16, (y + h - r) * 16, rc, lw * 16, 0u, 16384u, 0, 0, 0, c);
    }
}
/* a box: line 0 filled (r & 63 > 0: rounded; CR_RSQL / CR_RSQR: those corners square), else its outline line px wide */
static void cr_box(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c, uint32_t r, uint32_t line)
{
    uint32_t rr = r & 63u;
    if (!line) {
        if (!rr) {
            cr_fill(x, y, w, h, c);
            return;
        }
        cv_rrect(x, y, w, h, (int32_t)rr, c, T_BG);
        if (r & CR_RSQL) cr_fill(x, y, (int32_t)rr, h, c);
        if (r & CR_RSQR) cr_fill(x + w - (int32_t)rr, y, (int32_t)rr, h, c);
    } else if (rr) {
        cr_rline(x, y, w, h, (int32_t)rr, (int32_t)line, r & (CR_RSQL | CR_RSQR), c);
    } else {
        cr_fill(x, y, w, (int32_t)line, c);
        cr_fill(x, y + h - (int32_t)line, w, (int32_t)line, c);
        cr_fill(x, y, (int32_t)line, h, c);
        cr_fill(x + w - (int32_t)line, y, (int32_t)line, h, c);
    }
}
/* the Prophet-5 knob in a size px box centred at (cx, cy): the printed scale (11 ticks, 0..10, over CR_G_KNOB's 270
 * degrees at the box's edge, the end ticks 2 px), the face (radius size / 2 - 6, a 1 px rim), the pointer (2 px, from
 * `from` % of the face's radius to 95 %) at pct (Q8 of 255); bip: tick 5 in the pointer's colour, 2 px */
static void cr_p5knob(int32_t cx, int32_t cy, int32_t size, uint16_t face, uint16_t rim, uint16_t tick, uint16_t ptr,
                      uint32_t pct, int bip, uint32_t from)
{
    uint32_t a0 = 24576u, sweep = 49152u, a = a0 + sweep * pct / 256u, k;
    int32_t ro = size * 8 - 8, ri = ro - 40, rf = (size / 2 - 6) * 16, r0, r1;
    int16_t p[4];
    cx *= 16;
    cy *= 16;
    for (k = 0; k <= 10u; k++) {         /* the scale: 0 .. 10 */
        uint32_t ak = a0 + sweep * k / 10u;
        int bipk = bip && k == 5u;
        p[0] = (int16_t)(cx + ((ri * cr_cos(ak)) >> 14)); p[1] = (int16_t)(cy + ((ri * cr_sin(ak)) >> 14));
        p[2] = (int16_t)(cx + ((ro * cr_cos(ak)) >> 14)); p[3] = (int16_t)(cy + ((ro * cr_sin(ak)) >> 14));
        cr_poly(p, 2u, k == 0u || k == 10u || bipk ? 32 : 16, 0, 0, bipk ? ptr : tick);
    }
    if (rf < 32) return;
    cr_disc(cx, cy, rf, rim);            /* the face and its rim */
    cr_disc(cx, cy, rf - 16, face);
    r0 = rf * (int32_t)from / 100;       /* the pointer */
    r1 = rf * 95 / 100;
    p[0] = (int16_t)(cx + ((r0 * cr_cos(a)) >> 14)); p[1] = (int16_t)(cy + ((r0 * cr_sin(a)) >> 14));
    p[2] = (int16_t)(cx + ((r1 * cr_cos(a)) >> 14)); p[3] = (int16_t)(cy + ((r1 * cr_sin(a)) >> 14));
    cr_poly(p, 2u, 32, 0, 0, ptr);
}
/* ONE cycle of a wave as a 1.5 px line in the box, no baseline, its ink centred in the box (the panel's SHAPE
 * buttons): kind 0 saw (a ramp, straight down), 1 triangle, 2 pulse, 3 sine (one hump), 4 noise */
static void cr_wave1(uint32_t kind, int32_t bx, int32_t by, int32_t bw, int32_t bh, uint16_t c)
{
    static const int8_t NOISE[6] = {60, 10, 85, 30, 100, 45};   /* (x %, y %) is i * 20 %, NOISE[i] % down */
    int32_t x0 = bx * 16 + 12, y0 = by * 16 + 12, w = bw * 16 - 24, h = bh * 16 - 24;
    int32_t a = 32767, b = -32768, t = 32767, u = -32768, dx, dy;
    int16_t p[2 * 9];
    uint32_t np = 0, k;
#define CR_WP(fx, fy) (p[2 * np] = (int16_t)(x0 + (fx)), p[2 * np + 1] = (int16_t)(y0 + (fy)), np++)
    switch (kind) {
    case 0: CR_WP(0, h); CR_WP(w * 8 / 10, 0); CR_WP(w * 8 / 10, h); break;
    case 1: CR_WP(0, h); CR_WP(w / 2, 0); CR_WP(w, h); break;
    case 2: CR_WP(w * 15 / 100, h); CR_WP(w * 15 / 100, 0); CR_WP(w * 85 / 100, 0); CR_WP(w * 85 / 100, h); break;
    case 3:
        for (k = 0; k <= 8u; k++)        /* half a turn of sine in 8 segments */
            CR_WP(w * (int32_t)k / 8, h - ((h * cr_sin(k * 32768u / 8u)) >> 14));
        break;
    default:
        for (k = 0; k < 6u; k++)
            CR_WP(w * (int32_t)k / 5, h * NOISE[k] / 100);
        break;
    }
#undef CR_WP
    for (k = 0; k < np; k++) {
        a = p[2 * k] < a ? p[2 * k] : a; b = p[2 * k] > b ? p[2 * k] : b;
        t = p[2 * k + 1] < t ? p[2 * k + 1] : t; u = p[2 * k + 1] > u ? p[2 * k + 1] : u;
    }
    dx = (2 * x0 + w - a - b) / 2;
    dy = (2 * y0 + h - t - u) / 2;
    for (k = 0; k < np; k++) {
        p[2 * k] = (int16_t)(p[2 * k] + dx);
        p[2 * k + 1] = (int16_t)(p[2 * k + 1] + dy);
    }
    cr_poly(p, np, 24, 0, 0, c);
}
/* text on baseline y at x, whole px; maxw > 0: cut to it with an ellipsis */
static void cr_ftext(int32_t x, int32_t y, const char *s, uint32_t px, int bold, int align, uint16_t c, int32_t maxw)
{
    if (maxw > 0) cr_text_fit(P8(x), P8(y), s, px, bold, align, c, T_BG, P8(maxw));
    else cr_text(P8(x), P8(y), s, px, bold, align, 4096, c, T_BG, 0);
}
/* a text's advance in whole px, rounded up (the layout tool's measure) */
static int32_t cr_twpx(const char *s, uint32_t px, int bold) { return (cr_tw(s, px, bold) + 255) >> 8; }
/* an led's cap, h high at (x, y) (the panel's 18; a P5 cell's 16 or 26): a black window (the LEDs', (h - 2) / 2 high)
 * over a 1 px line, the pad under it, the rim; sq: a pair's square side */
static void cr_cap(int32_t x, int32_t y, int32_t w, int32_t h, uint32_t sq)
{
    int32_t wh = (h - 2) / 2;
    uint32_t r = h >= 24 ? 3u : 2u;
    cr_box(x, y, w, h, T_SURF, r + sq, 0);
    cr_box(x + 1, y + 1, w - 2, wh, CR_NAMED[CR_COL_BLACK], 0, 0);
    cr_box(x + 1, y + 1 + wh, w - 2, 1, T_LINE, 0, 0);
    cr_box(x, y, w, h, T_MID, r + sq, 1);
}

/* the P5 cell glyphs' LED (docs/EDITOR.md section 9): centred on the pixel corner (x, y); lit a 6 px red disc in a
 * 2 px dark-red halo, else a 4 px dark-red dot (the round-5 mock-up's colours, not the palette's) */
static void cr_p5led(int32_t x, int32_t y, int on)
{
    if (on) cr_disc(x * 16, y * 16, 64, CR_RGB(120, 20, 10));
    cr_disc(x * 16, y * 16, on ? 48 : 32, on ? CR_RED : CR_RGB(110, 24, 16));
}
/* a P5 cell's button cap, w x 20 from (cx - w / 2, y): the 2 px rim, the face (surf), the LEDs' window (its top 8 px
 * inside the rim, black) */
static void cr_p5cap(int32_t cx, int32_t y, int32_t w, uint16_t rim)
{
    int32_t x = cx - w / 2;
    cr_fill(x, y, w, 20, rim);
    cr_fill(x + 2, y + 2, w - 4, 16, T_SURF);
    cr_fill(x + 2, y + 2, w - 4, 8, CR_NAMED[CR_COL_BLACK]);
}

/* a two-LED button's value names after the text's NUL in b (n bytes; cr_edit.c ce_cell_p5): *o, 1; none: 0 */
static int cr_p5names(const char *b, int32_t n, const char **o)
{
    int32_t l = 0, i;
    while (l < n && b[l]) l++;
    if (l + 1 >= n || !b[l + 1]) return 0;
    for (i = l + 1; i < n && b[i]; i++)
        ;
    if (i + 1 >= n || !b[i + 1]) return 0;
    o[0] = b + l + 1;
    o[1] = b + i + 1;
    return 1;
}
/* a P5 cell's glyph (CR_G_P5*: docs/EDITOR.md section 9 "A cell"), in an edit8 cell's glyph box x .. x + w, y .. y + h
 * (px). A full-size cell's box (34 high): the owner's round-5 mock-up (design/p5-glyph-mockups-5.html), centred on
 * (x + w / 2, y + 12), the mock-up's 22 px under the label's baseline (the knob 6 px lower, level with the LEDs): K6d (the knob), B1a (the LED button and its
 * wave), S5 (the two-LED lever), R3 (the two-LED button and its names). A 22 px box (two rows under a band): the
 * first pass's small variants. col: the column's colour on the active row, else T_DIM (the dim row's greys) */
static void cr_p5glyph(const cr_cell_t *c, int32_t x, int32_t y, int32_t w, int32_t h, uint16_t col)
{
    static const int8_t ICON[3][9] = {           /* the 14 x 8 icons' points (x, y; a 2 px line), -1 the end */
        {1, 7, 11, 1, 11, 7, -1}, {1, 7, 7, 1, 13, 7, -1}, {2, 7, 2, 1, 12, 1, 12, 7, -1}};
    int32_t cx = x + (w >> 1), on = c->pct >= 128u, act = col != T_DIM, i;
    uint16_t rim = act ? col : T_LINE;
    if (h >= 30) {
        int32_t cy = y + 12, cy16 = cy * 16, cx16 = cx * 16, pos = c->pct < 64u ? 0 : c->pct < 192u ? 1 : 2;
        int16_t p[8];
        switch (c->glyph) {
        case CR_G_P5KNOB: {              /* K6d: 11 ticks (r 14 .. 17, 2 px; the nearest 18 and bright), the rim (r 9 ..
                                          * 11) in the colour, the face its 40 %, the 3 px pointer (r 2 .. 8); centred 6 px
                                          * lower than the buttons' (box + 18: level with their LEDs, the owner's) */
            uint32_t pct = c->pct >= 255u ? 256u : c->pct, a = 24576u + 49152u * pct / 256u, k, near = (pct * 10u + 128u) / 256u;
            cy16 += 6 * 16;
            for (k = 0; k <= 10u; k++) {
                uint32_t ak = 24576u + 49152u * k / 10u;
                int32_t r1 = k == near ? 18 * 16 : 17 * 16;
                p[0] = (int16_t)(cx16 + ((224 * cr_cos(ak)) >> 14)); p[1] = (int16_t)(cy16 + ((224 * cr_sin(ak)) >> 14));
                p[2] = (int16_t)(cx16 + ((r1 * cr_cos(ak)) >> 14)); p[3] = (int16_t)(cy16 + ((r1 * cr_sin(ak)) >> 14));
                cr_poly(p, 2u, 32, 0, 0, k == near ? (act ? CR_WHITE : T_MID) : act ? T_MID : T_DIM);
            }
            cr_disc(cx16, cy16, 11 * 16, rim);
            cr_disc(cx16, cy16, 9 * 16, act ? ux_mix(col, 0, 60) : T_SURF);
            p[0] = (int16_t)(cx16 + ((32 * cr_cos(a)) >> 14)); p[1] = (int16_t)(cy16 + ((32 * cr_sin(a)) >> 14));
            p[2] = (int16_t)(cx16 + ((128 * cr_cos(a)) >> 14)); p[3] = (int16_t)(cy16 + ((128 * cr_sin(a)) >> 14));
            cr_poly(p, 2u, 48, 0, 0, act ? CR_WHITE : T_MID);
            break;
        }
        case CR_G_P5LED: {               /* B1a: the wave (14 x 8, 4 px over the cap: white on, grey off), the 22 x 20
                                          * cap, its LED; no icon: the cap where it is */
            uint32_t ic = c->pct2 % 6u, n;
            if (ic >= CR_P5I_SAW && ic <= CR_P5I_SQUARE) {
                const int8_t *q = ICON[ic - CR_P5I_SAW];
                for (n = 0; q[2 * n] >= 0; n++) {
                    p[2 * n] = (int16_t)((cx - 7 + q[2 * n]) * 16);
                    p[2 * n + 1] = (int16_t)((cy - 15 + q[2 * n + 1]) * 16);
                }
                cr_poly(p, n, 32, 0, 0, on ? (act ? CR_WHITE : T_MID) : act ? T_DIM : T_LINE);
            }
            cr_p5cap(cx, cy - 3, 22, rim);
            cr_p5led(cx, cy + 3, on);
            break;
        }
        case CR_G_P5SWITCH:              /* S5: the 30 x 20 cap, two LEDs counting the position (none, the left, both) */
        case CR_G_P5LED2: {              /* R3: the 30 x 20 cap, the value's LED lit; the names (8 px) over them */
            int32_t lit[2];
            const char *n[2] = {0, 0};
            if (c->glyph == CR_G_P5SWITCH) {
                lit[0] = pos >= 1;
                lit[1] = pos == 2;
            } else {
                lit[0] = !on;
                lit[1] = on;
                if (!cr_p5names(c->label, (int32_t)sizeof c->label, n)) cr_p5names(c->value, (int32_t)sizeof c->value, n);
                if (n[0] && cr_twpx(n[0], 8, 1) + cr_twpx(n[1], 8, 1) > 24) n[0] = n[1] = 0;
            }
            cr_p5cap(cx, cy - 3, 30, rim);
            for (i = 0; i < 2; i++) {
                if (n[i]) cr_ftext(cx + (i ? 7 : -7), cy - 8, n[i], 8, 1, CR_C, act && lit[i] ? CR_WHITE : T_DIM, 0);
                cr_p5led(cx + (i ? 7 : -7), cy + 3, lit[i]);
            }
            break;
        }
        default:
            break;
        }
        return;
    }
    switch (c->glyph) {                  /* the 22 px box */
    case CR_G_P5KNOB: {                  /* the largest even dial whose ring (top) and face or lower ticks fit the box */
        int32_t sz = 2 * h, top, bot;
        for (;; sz -= 2) {
            top = sz * 8 - 8;            /* (Q4: the ticks' outer radius; under the centre the face's or the end ticks') */
            bot = (sz / 2 - 6) * 16 > top * 181 / 256 ? (sz / 2 - 6) * 16 : top * 181 / 256;
            if (top + bot <= h * 16 || sz <= 16) break;
        }
        cr_p5knob(cx, y + ((top + 8) >> 4), sz, T_SURF, T_MID, T_LINE, col, c->pct, (c->flags & CR_CF_BIP) != 0, 15u);
        break;
    }
    case CR_G_P5LED: {                   /* the cap alone, 20 x 16 */
        int32_t cy = y + (h - 16) / 2;
        cr_cap(cx - 10, cy, 20, 16, 0);
        cr_disc(cx * 16, (cy + 1 + 14 / 4) * 16 + 8, on ? 32 : 32 * 3 / 5, on ? CR_RED : T_DIM);
        break;
    }
    case CR_G_P5LED2: {                  /* one wide cap, two LEDs (left red: the minimum, right yellow: the maximum) */
        int32_t cy = y + (h - 16) / 2, d = 34 / 4;
        cr_cap(cx - 17, cy, 34, 16, 0);
        for (i = 0; i < 2; i++) {
            int32_t lx = cx + (i ? d : -d), lit = i == on;
            cr_disc(lx * 16, (cy + 1 + 14 / 4) * 16 + 8, lit ? 32 : 32 * 3 / 5, lit ? (i ? CR_YELLOW : CR_RED) : T_DIM);
        }
        break;
    }
    case CR_G_P5SWITCH: {                /* a slot of three positions the box's height, the lever at the position */
        int32_t ph = h / 3, sw = 8, pos = c->pct < 64u ? 0 : c->pct < 192u ? 1 : 2, sy = y + (h - 3 * ph) / 2;
        cr_box(cx - sw / 2, sy, sw, 3 * ph, T_LINE, 2, 1);
        cr_box(cx - sw / 2 + 2, sy + ph * pos + 2, sw - 4, ph - 4, col, 0, 0);
        for (i = 0; i < 3; i++)          /* the positions' ticks beside the slot */
            cr_fill(cx + sw / 2 + 3, sy + ph * i + ph / 2, 4, 1, i == pos ? col : T_LINE);
        break;
    }
    default:
        break;
    }
}

/* a cell's glyph in the box x .. x + w, y .. y + h (Q4): the designer's drawGlyph scaled by h / 64 */
static void cr_cglyph(const cr_cell_t *c, int32_t x, int32_t y, int32_t w, int32_t h, uint16_t col)
{
    int32_t sc = h * 4, cwg = w * 4096 / sc, k, pct = c->pct, cx = x + w / 2;   /* sc: glyph units -> Q4 (Q12) */
    int16_t p[26 * 2];
    uint32_t np = 0;
#define CR_GU(v) ((int32_t)(v) * sc >> 12)          /* glyph units (Q4) -> px (Q4) */
#define CR_PT(px16, py16) (p[2 * np] = (int16_t)(px16), p[2 * np + 1] = (int16_t)(py16), np++)
    if (pct >= 255) pct = 256;
    switch (c->glyph) {
    case CR_G_BAR: {
        int32_t bh = 56 * 16 * pct / 256;
        if (c->flags & CR_CF_BIP) {                 /* centre-zero: a well with the fill out of its middle */
            int32_t bw = w * 4 / 10 < 14 * 16 ? w * 4 / 10 : 14 * 16, bx = cx - bw / 2, m = y + h / 2;
            int32_t v = (pct - 128) * h / 256;
            cr_frect(bx, y, bw, h, T_LINE);
            if (v > 0) cr_frect(bx, m - v, bw, v, col);
            else if (v < 0) cr_frect(bx, m, bw, -v, col);
            cr_frect(bx - 48, m - 8, bw + 96, 16, col);
            break;
        }
        for (k = 0; k < 7; k++)
            cr_frect(cx - CR_GU(160), y + CR_GU(64 + k * 56 * 16 / 6), CR_GU(320), 13, T_LINE);
        if (bh > 0) cr_frect(cx - CR_GU(144), y + CR_GU(60 * 16 - bh), CR_GU(288), CR_GU(bh), col);
        break;
    }
    case CR_G_DOTS: {
        int32_t n = 1 + (pct * 11 + 128) / 256, cy = y + h / 2;
        for (k = 0; k < 12; k++) {
            uint32_t a = 49152u + (uint32_t)k * 65536u / 12u;
            cr_disc(cx + CR_GU((320 * cr_cos(a)) >> 14), cy + CR_GU((320 * cr_sin(a)) >> 14), CR_GU(k < n ? 56 : 32),
                    k < n ? col : T_LINE);
        }
        break;
    }
    case CR_G_WAVE: {                                /* two cycles of a sine, its amplitude by pct */
        int32_t amp = CR_GU(22 * 16) * (77 + 179 * pct / 256) / 256, x0 = x + CR_GU(96), ww = w - 2 * CR_GU(96);
        for (k = 0; k <= 20; k++)
            CR_PT(x0 + k * ww / 20, y + h / 2 - ((cr_sin((uint32_t)(k * 65536 / 10)) * amp) >> 14));
        cr_poly(p, np, 32, 0, 0, col);
        break;
    }
    case CR_G_SAW: case CR_G_SQUARE: {               /* two cycles */
        int32_t x0 = x + CR_GU(96), sw = (w - 2 * CR_GU(96)) / 2, top = y + CR_GU(160), bot = y + h - CR_GU(160);
        if (c->glyph == CR_G_SAW) {
            CR_PT(x0, bot);
            for (k = 0; k < 2; k++) {
                CR_PT(x0 + (k + 1) * sw, top);
                CR_PT(x0 + (k + 1) * sw, bot);
            }
        } else {
            for (k = 0; k < 2; k++) {
                int32_t xx = x0 + k * sw, d = sw * pct / 256;
                CR_PT(xx, bot); CR_PT(xx, top); CR_PT(xx + d, top); CR_PT(xx + d, bot); CR_PT(xx + sw, bot);
            }
        }
        cr_poly(p, np, 32, 0, 0, col);
        break;
    }
    case CR_G_MORPH: {                               /* two cycles of the morphed wave: <= 23 segments */
        int32_t m = ((int32_t)c->pct * 127 + 127) / 255, x0 = x + CR_GU(96), cw2 = (w - 2 * CR_GU(96)) / 2;
        int32_t top = y + CR_GU(160), bot = y + h - CR_GU(160), mid = (top + bot) / 2, half = (bot - top) / 2;
        int32_t e = m > 96 ? 4096 - (2048 - 1843 * (m - 96) / 31) : 2048, cyc, j, nk, px, py;
        static const int16_t KX[10] = {0, 512, 1024, 1536, 2048, 2048, 2560, 3072, 3584, 4096};
        static const uint8_t KL[10] = {0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
        int16_t kx[12];
        uint8_t kl[12];
        for (j = nk = 0; j < 10; j++) {              /* the eighths, the jump at 1/2 and the pulse's edge e, both sides */
            if (m > 96 && KX[j] > e && (!nk || kx[nk - 1] < e)) {
                kx[nk] = (int16_t)e; kl[nk++] = 1;
                kx[nk] = (int16_t)e; kl[nk++] = 0;
            }
            kx[nk] = KX[j]; kl[nk++] = KL[j];
        }
        for (cyc = 0; cyc < 2; cyc++)
            for (j = 0; j < nk; j++) {
                px = x0 + cyc * cw2 + kx[j] * cw2 / 4096;
                py = mid - cr_morph_y(m, kx[j], kl[j], e) * half / 4096;
                if (np && p[2 * np - 2] == (int16_t)px && p[2 * np - 1] == (int16_t)py)
                    continue;                        /* (no jump here: one point) */
                CR_PT(px, py);
            }
        cr_poly(p, np, 32, 0, 0, col);
        break;
    }
    case CR_G_NOISE: {                               /* white: dense jitter; brown: a wandering line; vinyl: spikes */
        static const int8_t WN[21] = {10, -90, 70, -40, 110, -120, 30, 85, -70, 20, -105, 95, -15, 60, -127, 45, -55,
                                      120, -30, 75, 0};
        static const int8_t BN[11] = {0, 40, 70, 50, 10, -30, -45, -20, 25, 60, 35};
        int32_t x0 = x + CR_GU(96), ww = w - 2 * CR_GU(96), top = y + CR_GU(160), bot = y + h - CR_GU(160);
        int32_t mid = (top + bot) / 2, half = (bot - top) / 2, ty = pct * 3 / 256;
        if (ty == 0) {
            for (k = 0; k < 21; k++) CR_PT(x0 + k * ww / 20, mid - WN[k] * half / 127);
            cr_poly(p, np, 24, 0, 0, col);
        } else if (ty == 1) {
            for (k = 0; k < 11; k++) CR_PT(x0 + k * ww / 10, mid - BN[k] * half / 127);
            cr_poly(p, np, 32, 0, 0, col);
        } else {
            static const int16_t SX[4] = {40, 128, 150, 214};             /* (of 256 across) */
            static const int8_t SY[4] = {110, -70, 127, -100};
            cr_frect(x0, mid - 8, ww, 16, T_LINE);
            for (k = 0; k < 4; k++) {
                int32_t sx = x0 + SX[k] * ww / 256, sy = SY[k] * half / 127;
                cr_frect(sx - 12, sy > 0 ? mid - sy : mid, 24, sy > 0 ? sy : -sy, col);
            }
        }
        break;
    }
    case CR_G_STEPS: {                               /* sample and hold: eight short dashes */
        int32_t sw = (w - 2 * CR_GU(80)) / 8;
        for (k = 0; k < 8; k++)
            cr_frect(x + CR_GU(80) + k * sw + CR_GU(16), y + h - CR_GU(96) - CR_GU(50 * 16 * ((k * 7) % 11) / 11),
                     sw - CR_GU(32), CR_GU(48), k * 256 <= pct * 8 ? col : T_LINE);
        break;
    }
    case CR_G_KNOB: {                                /* a 270-degree arc with its pointer */
        uint32_t a0 = 24576u, sweep = 49152u, a = a0 + sweep * (uint32_t)pct / 256u;
        int32_t r = CR_GU(320), cy = y + h / 2;
        cr_arc(cx, cy, r, 51, a0, sweep, 1, 0, 0, T_LINE);
        if (c->flags & CR_CF_BIP) {                  /* centre-zero: from 12 o'clock to the value, a mark over 12 */
            uint32_t top = 49152u;
            if (a > top) cr_arc(cx, cy, r, 51, top, a - top, 1, 0, 0, col);
            else if (a < top) cr_arc(cx, cy, r, 51, a, top - a, 1, 0, 0, col);
            cr_frect(cx - 13, cy - CR_GU(456), 26, CR_GU(64), col);
        } else if (pct) {
            cr_arc(cx, cy, r, 51, a0, sweep * (uint32_t)pct / 256u, 1, 0, 0, col);
        }
        CR_PT(cx + ((CR_GU(96) * cr_cos(a)) >> 14), cy + ((CR_GU(96) * cr_sin(a)) >> 14));
        CR_PT(cx + ((CR_GU(224) * cr_cos(a)) >> 14), cy + ((CR_GU(224) * cr_sin(a)) >> 14));
        cr_poly(p, np, 38, 0, 0, col);
        break;
    }
    case CR_G_LFOWAVE:                               /* the wave and its start phase (two cycles in a span-2 cell) */
        cr_lfowave(x, y, w, h, col, pct, c->wave, c->flags & CR_CF_SPAN2 ? 2 : 1);
        break;
    case CR_G_RATIO: break;                          /* (the cell draws it: a fraction) */
    case CR_G_P5KNOB: case CR_G_P5LED: case CR_G_P5LED2: case CR_G_P5SWITCH:
        cr_p5glyph(c, x >> 4, y >> 4, w >> 4, h >> 4, col);
        break;
    default:                                         /* the pictograms: drawn at true size (2 px strokes) in the box */
        if (c->glyph >= CR_G_ROOM && c->glyph < CR_G_P5KNOB)
            cr_picto(c->glyph, x, y, w, h, col, pct, c->pct2 >= 255 ? 256 : c->pct2);
        break;
    }
    (void)cwg;
#undef CR_PT
#undef CR_GU
}

/* a text cell's pct as a small horizontal bar (Q4): from the left, or out of the middle when bipolar */
static void cr_hbar(const cr_cell_t *c, int32_t x, int32_t w, int32_t by, int32_t bh, uint16_t col)
{
    int32_t pct = c->pct >= 255 ? 256 : c->pct;
    if (!(c->flags & CR_CF_PCT)) return;
    cr_frect(x, by, w, bh, T_LINE);
    if (c->flags & CR_CF_BIP) {
        int32_t m = x + w / 2, v = (pct - 128) * w / 256;
        if (v > 0) cr_frect(m, by, v, bh, col);
        else if (v < 0) cr_frect(m + v, by, -v, bh, col);
        cr_frect(m - 8, by - 32, 16, bh + 64, col);
    } else if (pct) {
        cr_frect(x, by, w * pct / 256, bh, col);
    }
}

/* the value centred at cx (Q8) on baseline vy (Q8) in a cell w px (Q8) wide; hot: on a block of its colour */
static void cr_cvalue(const cr_cell_t *c, int32_t cx, int32_t vy, int32_t w, uint32_t vpx, uint16_t col, int hot,
                      uint32_t flags)
{
    char b[16], v[sizeof c->value];
    int cut = cr_fit(b, sizeof b, c->value, vpx, 1, w - P8(6));
    uint32_t i, j, bpx = vpx;
    if (cut) {                                       /* too wide: "790 ms" -> "790ms" first, then 2 px smaller */
        for (i = j = 0; c->value[i]; i++)
            if (c->value[i] != ' ') v[j++] = c->value[i];
        v[j] = 0;
        cut = cr_fit(b, sizeof b, v, vpx, 1, w - P8(6));
        for (i = vpx; cut && i >= 11u; i -= 2u)      /* ("ENV2+12", the quick mapping's hot cell) */
            if (!cr_fit(b, sizeof b, v, i - 2u, 1, w - P8(6)))
                cut = 0, vpx = i - 2u;
        if (cut)
            cut = cr_fit(b, sizeof b, v, vpx, 1, w - P8(6));
    }
    if (hot) {
        int32_t x0 = (cx - w / 2 + P8(3) + 128) >> 8, x1 = (cx + w / 2 - P8(3) + 128) >> 8, y0 = ((vy + 128) >> 8) - (int32_t)bpx - 1;
        cv_rrect(x0, y0, x1 - x0, (int32_t)bpx + 5, 2, col, T_BG);
    }
    cr_text(cx, vy, b, vpx, 1, CR_C, 4096, hot ? T_BG : col, hot ? col : T_BG, (cut ? 9u : 0u) | flags);
}

/* CR_CF_WRAP: v on two lines centred at cx (Q8), baselines y1 / y2 (Q8), in a cell w (Q8) wide, broken at the space
 * nearest the middle (dropped), else after the hyphen nearest it with 4 letters each side (kept; "m6-Dim" stays); 15 px, 2 px smaller while a line is too wide
 * (to 11). 0: no break point, nothing drawn (the caller draws one line). hot: both lines on one block */
static int cr_cwrap(const char *v, int32_t cx, int32_t y1, int32_t y2, int32_t w, uint16_t col, int hot)
{
    char a[16], b[16];
    int32_t n = 0, i, k = -1, sp = 0;
    uint32_t px = 15u;
    while (v[n] && n < 15) n++;
    for (i = 1; i < n - 1; i++)                      /* the space nearest the middle; else the hyphen nearest it */
        if (v[i] == ' ' || (v[i] == '-' && !sp && i >= 3 && n - i > 4)) {   /* (a hyphen: 4 letters each side) */
            int better = k < 0 || (v[i] == ' ' && !sp) || (i - n / 2) * (i - n / 2) < (k - n / 2) * (k - n / 2);
            if (better) { k = i; sp = v[i] == ' '; }
        }
    if (k < 0) return 0;
    for (i = 0; i < k + !sp; i++) a[i] = v[i];
    a[i] = 0;
    for (i = k + 1; i < n; i++) b[i - k - 1] = v[i];
    b[n - k - 1] = 0;
    while (px > 11u && (cr_tw(a, px, 1) > w - P8(6) || cr_tw(b, px, 1) > w - P8(6))) px -= 2u;
    if (hot) {
        int32_t x0 = (cx - w / 2 + P8(3) + 128) >> 8, x1 = (cx + w / 2 - P8(3) + 128) >> 8;
        int32_t t = ((y1 + 128) >> 8) - (int32_t)px - 1, bt = ((y2 + 128) >> 8) + 4;
        cv_rrect(x0, t, x1 - x0, bt - t, 2, col, T_BG);
    }
    cr_text(cx, y1, a, px, 1, CR_C, 4096, hot ? T_BG : col, hot ? col : T_BG, 0);
    cr_text(cx, y2, b, px, 1, CR_C, 4096, hot ? T_BG : col, hot ? col : T_BG, 0);
    return 1;
}

/* a number centred at cx (Q8) on baseline vy (Q8) in a cell w (Q8) wide at px: too wide, 2 px smaller at a time (to
 * 7 px), never ellipsised; hot: on a block of its colour */
static void cr_cnum(const char *v, int32_t cx, int32_t vy, int32_t w, uint32_t px, uint16_t col, int hot)
{
    uint32_t bpx = px;
    while (px > 7u && cr_tw(v, px, 1) > w - P8(6)) px -= 2u;
    if (hot) {
        int32_t x0 = (cx - w / 2 + P8(3) + 128) >> 8, x1 = (cx + w / 2 - P8(3) + 128) >> 8, y0 = ((vy + 128) >> 8) - (int32_t)bpx - 1;
        cv_rrect(x0, y0, x1 - x0, (int32_t)bpx + 5, 2, col, T_BG);
    }
    cr_text(cx, vy, v, px, 1, CR_C, 4096, hot ? T_BG : col, hot ? col : T_BG, 0);
}

/* a ratio in quarters (1..255) as "%u.%02u": "0.25", "16.00" */
static void cr_quarters(uint32_t q, char *b)
{
    uint32_t w = q / 4u, f = (q % 4u) * 25u, i = 0;
    if (w >= 10u) b[i++] = (char)('0' + w / 10u);
    b[i++] = (char)('0' + w % 10u);
    b[i++] = '.';
    b[i++] = (char)('0' + f / 10u);
    b[i++] = (char)('0' + f % 10u);
    b[i] = 0;
}

/* CR_G_RATIO: top / bottom (pct / pct2, quarters: QUAD's B2 / B1) as a fraction round mid (Q8), both "%u.%02u":
 * the numerator 13 px over a 1.5 px divider (w - 14 wide) over the denominator 13 px; hot: the whole on a block */
static void cr_cratio(const cr_cell_t *c, int32_t cx, int32_t mid, int32_t w, uint16_t col, int hot)
{
    char nu[8], de[8];
    int32_t dw = w - P8(14);
    uint16_t tc = hot ? T_BG : col;
    cr_quarters(c->pct, nu);
    cr_quarters(c->pct2, de);
    if (hot) {
        int32_t x0 = (cx - w / 2 + P8(3) + 128) >> 8, x1 = (cx + w / 2 - P8(3) + 128) >> 8, y0 = ((mid + 128) >> 8) - 18;
        cv_rrect(x0, y0, x1 - x0, 36, 2, col, T_BG);
    }
    cr_cnum(nu, cx, mid - P8(4), dw + P8(6), 13, tc, 0);
    cr_frect((cx - dw / 2) >> 4, (mid >> 4) - 12, dw >> 4, 24, tc);
    cr_cnum(de, cx, mid + P8(15), dw + P8(6), 13, tc, 0);
}

/* a cell's columns: 2 for a CR_CF_SPAN2 cell starting in column 0..2, else 1 */
static int32_t cr_span(const cr_cell_t *c, int32_t col0) { return (c->flags & CR_CF_ON) && (c->flags & CR_CF_SPAN2) && col0 < 3 ? 2 : 1; }

static void cr_ed_title(const cr_screen_t *s)
{
    int32_t rx = 232, rw;
    if (s->batt != 255u) {                           /* the battery at the right end (the MIX screens) */
        cr_battery(rx - 18, s->batt);
        rx -= 24;
    }
    rw = (s->page[0] ? cr_tw(s->page, 11, 1) : 0) + P8(232 - rx);
    if (s->page[0]) cr_text(P8(rx), P8(17), s->page, 11, 1, CR_R, 4096, T_MID, T_BG, 0);
    if (s->fine) {                                   /* SHIFT on: "snap", small, left of the right text (2: a ratio
                                                      * pair's slow hand B1 steps) */
        const char *ft = s->fine == 2u ? "snap \267 B1" : "snap";
        int32_t fx = P8(232) - rw - (rw ? P8(6) : 0);
        cr_text(fx, P8(16), ft, 9, 1, CR_R, 4096, T_TEXT, T_BG, 0);
        rw += cr_tw(ft, 9, 1) + P8(6);
    }
    if (s->title[0])
        cr_text_fit(P8(8), P8(17), s->title, 13, 1, CR_L, cr_rgb(s->title_col, T_TEXT), T_BG, P8(224) - rw - (rw ? P8(8) : 0));
}

/* log2(v), Q12 (the fraction linear: within 0.09) */
static int32_t cr_log2(uint32_t v)
{
    int32_t e = 31;
    if (!v) return 0;
    while (!(v >> e)) e--;
    return e * 4096 + (int32_t)(((v << (31 - e)) >> 19) & 4095u);
}
/* the 2nd-order response at w = 2^(q / 4) (q quarter octaves from the cutoff), Q = 0.6 + 7 res, of the mix
 * lp LP + bp BP + hp HP (weights Q8; NOTCH = LP + HP): |lp - hp w^2 + j bp g w / Q|^2 / |1 - w^2 + j w / Q|^2, the
 * band-pass made up by g^2 = Q / 0.6 (0 dB at its peak, as before). Its level in dB x 16. 32-bit only: the levels as
 * log2 differences */
static int32_t cr_fdb(int32_t lp, int32_t bp, int32_t hp, int32_t q, int32_t res)
{
    int32_t w2, a, qq = 2458 + res * 7 * 4096 / 255, qq2, inv, term, l, re;
    uint32_t den, num;
    if (q > 14) q = 14;
    if (q < -14) q = -14;
    w2 = q >= 0 ? 256 << (q / 2) : 256 >> (-q / 2);                  /* w^2 = 2^(q / 2), Q8 */
    if (q & 1) w2 = q > 0 ? w2 * 362 / 256 : w2 * 181 / 256;
    a = 256 - w2;
    qq2 = (qq >> 6) * (qq >> 6);                                     /* Q^2, Q12 */
    inv = (int32_t)((1u << 24) / (uint32_t)(qq2 ? qq2 : 1));          /* 1 / Q^2, Q12 */
    term = (w2 * inv) >> 4;                                          /* w^2 / Q^2, Q16 */
    den = (uint32_t)(a * a) + (uint32_t)term;
    re = (lp * 256 - hp * w2) >> 8;                                  /* the real part, Q8 */
    num = (uint32_t)(re * re) + (uint32_t)(((bp * bp) >> 8) * ((term >> 8) * (qq >> 4) / (2458 >> 4)));
    l = cr_log2(num ? num : 1u) - cr_log2(den ? den : 1u);
    return l * 3011 / 256000;                                        /* 10 log10 = 3.0103 log2: dB x 16 */
}

/* QUAD's eight algorithms, the Digitone manual's (Appendix A.3, its diagram; the designer's ALGOS,
 * ../ChoralRootFM1Designer/index.html, the same table): operators C A B1 B2 (0..3); mod: up to four [source, target]
 * arrows; fb: the feedback operator; x / y: the carriers summed into each output (bit per operator), xm / ym the one
 * the label sits under; dir: the direct carriers (full level: a dotted line), the others enveloped (a solid line);
 * side: the carriers whose line leaves the box's right side (an operator below it in its column); rows: 3 or 4;
 * pos: [row 0 top, column 0..2] */
typedef struct { uint8_t nmod, mod[4][2], fb, x, y, xm, ym, dir, side, rows, pos[4][2]; } cr_algo_t;
static const cr_algo_t CR_ALGOS[8] = {
    /* 1: A(fb)>C, B2>B1, B1>C; X C, Y B1 (direct) */
    {3, {{1, 0}, {3, 2}, {2, 0}}, 1, 0x1, 0x4, 0, 2, 0x5, 0, 3, {{2, 0}, {1, 0}, {1, 1}, {0, 1}}},
    /* 2: A>C, B2(fb)>B1; X C, Y B1 (direct) */
    {2, {{1, 0}, {3, 2}}, 3, 0x1, 0x4, 0, 2, 0x5, 0, 3, {{2, 0}, {1, 0}, {2, 1}, {1, 1}}},
    /* 3: A(fb)>C, A>B2, A>B1; X C + B2 (direct), Y B1 (direct) */
    {3, {{1, 0}, {1, 3}, {1, 2}}, 1, 0x9, 0x4, 0, 2, 0xD, 0, 3, {{2, 0}, {1, 1}, {2, 2}, {2, 1}}},
    /* 4: B2(fb)>B1, B1>A, A>C; X C, Y B1 (direct, from its side) */
    {3, {{3, 2}, {2, 1}, {1, 0}}, 3, 0x1, 0x4, 0, 2, 0x5, 0x4, 4, {{3, 0}, {2, 0}, {1, 0}, {0, 0}}},
    /* 5: B1(fb)>A, B2>A, A>C; X C, Y A (direct, from its side) */
    {3, {{2, 1}, {3, 1}, {1, 0}}, 2, 0x1, 0x2, 0, 1, 0x3, 0x2, 3, {{2, 0}, {1, 0}, {0, 0}, {0, 1}}},
    /* 6: A(fb)>C, A>B1, B2>C, B2>B1; X C, Y B1 (direct) */
    {4, {{1, 0}, {1, 2}, {3, 0}, {3, 2}}, 1, 0x1, 0x4, 0, 2, 0x5, 0, 3, {{2, 0}, {1, 0}, {2, 1}, {1, 1}}},
    /* 7: A(fb)>C, B2>B1; X C + A (enveloped, from its side), Y B1 + B2 (enveloped, B2 from its side) */
    {2, {{1, 0}, {3, 2}}, 1, 0x3, 0xC, 0, 2, 0x1, 0xA, 3, {{2, 0}, {1, 0}, {2, 1}, {1, 1}}},
    /* 8: A>C, B1(fb); X C + B2 (enveloped), Y B1 (enveloped) */
    {1, {{1, 0}}, 2, 0x9, 0x4, 0, 2, 0x1, 0, 3, {{2, 0}, {1, 0}, {2, 2}, {2, 1}}},
};
static const char *const CR_OPS[4] = {"C", "A", "B1", "B2"};
#define CR_ALGO_HS (7 * 16)              /* a box's half size (14 px) */
#define CR_ALGO_COL (32 * 16)            /* the column pitch */
#define CR_ALGO_SIDE (15 * 16)           /* a side line: this far right of its box's centre */
#define CR_ALGO_LABY (24 + 92)           /* the X / Y labels' baseline (px) */

/* algorithm n (1..8)'s geometry (Q4): the boxes' centres, the side-line columns, the X / Y labels' x; the diagram
 * centred on x 137 (the band's room right of "ALGO" and its number: 60 .. 214) */
static void cr_algo_geom(uint32_t n, int32_t ox[4], int32_t oy[4], int32_t sx[4], int32_t lx[2])
{
    static const int32_t ROW3[3] = {13, 37, 61}, ROW4[4] = {11, 30, 49, 68};
    const cr_algo_t *al = &CR_ALGOS[(n < 1u ? 1u : n > 8u ? 8u : n) - 1u];
    int32_t mn = 99999, mx = -99999, k, off;
    for (k = 0; k < 4; k++) {
        ox[k] = al->pos[k][1] * CR_ALGO_COL;
        oy[k] = (24 + (al->rows == 4u ? ROW4[al->pos[k][0] & 3u] : ROW3[al->pos[k][0] % 3u])) * 16;
        if (ox[k] - CR_ALGO_HS < mn) mn = ox[k] - CR_ALGO_HS;
        if (ox[k] + (al->side >> k & 1u ? CR_ALGO_SIDE + 16 : CR_ALGO_HS) > mx)
            mx = ox[k] + (al->side >> k & 1u ? CR_ALGO_SIDE + 16 : CR_ALGO_HS);
    }
    off = 137 * 16 - (mn + mx) / 2;
    for (k = 0; k < 4; k++) {
        ox[k] += off;
        sx[k] = al->side >> k & 1u ? ox[k] + CR_ALGO_SIDE : ox[k];
    }
    lx[0] = sx[al->xm];
    lx[1] = sx[al->ym];
}

/* a carrier's line to its output (axis-aligned pieces, 1.5 px; dotted when direct): its main carrier straight down
 * (or from its side, then down) to the label's top; another one down (or from its side, then down) to the label's
 * middle, then across to the label's side */
static void cr_algo_out(int32_t ox, int32_t oy, int32_t sx, int32_t lx, int main_, int dotted, uint16_t c)
{
    const int32_t top = (CR_ALGO_LABY - 10) * 16, midy = (CR_ALGO_LABY - 4) * 16;
    int16_t p[4 * 2];
    uint32_t np = 0;
#define CR_AP(px16, py16) (p[2 * np] = (int16_t)(px16), p[2 * np + 1] = (int16_t)(py16), np++)
    if (sx != ox) {                                  /* from the box's right side */
        CR_AP(ox + CR_ALGO_HS + 16, oy);
        CR_AP(sx, oy);
    } else {
        CR_AP(ox, oy + CR_ALGO_HS + 16);
    }
    if (main_) {
        CR_AP(sx, top);
    } else {
        CR_AP(sx, midy);
        CR_AP(sx > lx ? lx + 6 * 16 : lx - 6 * 16, midy);
    }
#undef CR_AP
    cr_poly(p, np, 24, dotted ? 24 : 0, dotted ? 56 : 0, c);
}

/* the algo band (wv: algo 1..8, fdbk, mix): "ALGO" and the number at the left, the diagram as the manual draws it: the
 * modulation arrows (box edge to box edge, a filled head), each carrier's line to X / Y (dotted: direct, solid:
 * enveloped; a second carrier joins at the label's side; the stronger output by mix in TEXT, the other DIM; both when
 * mix is centred), the four boxes with their letters, the feedback loop over its operator's top left (1..3 px with
 * fdbk). Bounded: <= 4 arrows, 4 lines, 4 boxes, one loop */
static void cr_algo_band(const cr_screen_t *s)
{
    const int32_t hs = CR_ALGO_HS;
    int32_t n = s->wv[0] < 1u ? 1 : s->wv[0] > 8u ? 8 : s->wv[0], fb = s->wv[1], mix = s->wv[2];
    int32_t ox[4], oy[4], sx[4], lx[2], k, o;
    const cr_algo_t *al = &CR_ALGOS[n - 1];
    char num[2] = {(char)('0' + n), 0};
    int16_t p[5 * 2];
    cr_algo_geom((uint32_t)n, ox, oy, sx, lx);
    cr_text(P8(8), P8(24 + 12), "ALGO", 10, 1, CR_L, 4096, T_MID, T_BG, 0);
    cr_text(P8(8), P8(24 + 40), num, 24, 1, CR_L, 4096, T_TEXT, T_BG, 0);
    for (k = 0; k < al->nmod; k++) {                 /* the arrows: 1.5 px, MID, a head <= 4.5 x 5 px at the target */
        int32_t ax = ox[al->mod[k][0]], ay = oy[al->mod[k][0]], tx = ox[al->mod[k][1]], ty = oy[al->mod[k][1]];
        int32_t dx = tx - ax, dy = ty - ay, len = (int32_t)cr_isqrt((uint32_t)(dx * dx + dy * dy)), vx, vy, m, e, bx, by;
        int32_t hl, gap;
        if (!len) continue;
        vx = dx * 4096 / len;                        /* (Q12) */
        vy = dy * 4096 / len;
        m = (vx < 0 ? -vx : vx) > (vy < 0 ? -vy : vy) ? (vx < 0 ? -vx : vx) : (vy < 0 ? -vy : vy);
        e = hs * 4096 / (m ? m : 1) + 16;            /* (Q4) the box edge, +1 px */
        gap = len - 2 * e;
        hl = gap < 72 ? (gap > 32 ? gap : 32) : 72; /* (a short gap: a shorter head) */
        bx = tx - vx * e / 4096;
        by = ty - vy * e / 4096;
        if (gap > hl) {
            p[0] = (int16_t)(ax + vx * e / 4096); p[1] = (int16_t)(ay + vy * e / 4096);
            p[2] = (int16_t)(bx - vx * (hl - 24) / 4096); p[3] = (int16_t)(by - vy * (hl - 24) / 4096);
            cr_poly(p, 2, 24, 0, 0, T_MID);
        }
        cr_tri(bx, by, bx - (vx * hl + vy * 40) / 4096, by - (vy * hl - vx * 40) / 4096,
               bx - (vx * hl - vy * 40) / 4096, by - (vy * hl + vx * 40) / 4096, T_MID);
    }
    for (o = 0; o < 2; o++) {                        /* the outputs */
        uint32_t msk = o ? al->y : al->x, mo = o ? al->ym : al->xm;
        uint16_t c = (o ? mix >= 128 : mix <= 128) ? T_TEXT : T_DIM;
        for (k = 0; k < 4; k++)
            if (msk >> k & 1u)
                cr_algo_out(ox[k], oy[k], sx[k], lx[o], (uint32_t)k == mo, al->dir >> k & 1u, c);
        cr_text(lx[o] * 16, P8(CR_ALGO_LABY), o ? "Y" : "X", 11, 1, CR_C, 4096, c, T_BG, 0);
    }
    for (k = 0; k < 4; k++) {                        /* the boxes: 14 px, a 1.5 px outline, the letter 9 px */
        cr_frect(ox[k] - hs, oy[k] - hs, 2 * hs, 2 * hs, T_BG);
        cr_srect(ox[k] - hs, oy[k] - hs, 2 * hs, 2 * hs, 24, T_TEXT);
        cr_text(ox[k] * 16, oy[k] * 16 + 819, CR_OPS[k], 9, 1, CR_C, 4096, T_TEXT, T_BG, 0);
    }
    {                                                /* the feedback loop: up from the box's top, left past its left
                                                      * edge, down, back in (a head at the edge), as the manual's */
        int32_t j = al->fb, w = 16 + 32 * fb / 255, l = ox[j] - hs, t = oy[j] - hs, ty = t - 3 * 16;
        if (ty < 24 * 16 + w / 2) ty = 24 * 16 + w / 2;
        p[0] = (int16_t)(ox[j] - 2 * 16); p[1] = (int16_t)(t - 16);
        p[2] = (int16_t)(ox[j] - 2 * 16); p[3] = (int16_t)ty;
        p[4] = (int16_t)(l - 4 * 16); p[5] = (int16_t)ty;
        p[6] = (int16_t)(l - 4 * 16); p[7] = (int16_t)(oy[j] - 3 * 16);
        p[8] = (int16_t)(l - 2 * 16); p[9] = (int16_t)(oy[j] - 3 * 16);
        cr_poly(p, 5, w, 0, 0, T_TEXT);
        cr_tri(l, oy[j] - 3 * 16, l - 3 * 16, oy[j] - 6 * 16, l - 3 * 16, oy[j], T_TEXT);
    }
}

/* the ade2 band (wv: A's a d end lev, B's, the lit segment 1..8): A's envelope in x 8..112, B's in 128..232, each a
 * rise to its level over 40 % of its room at a = 1, a fall to its end over 40 % at d = 1, then held; a 4 px level bar
 * at its right (the lit colour when a segment of that half is lit, else MID), its letter top left; the lit segment
 * 4 px in segcol with dots at its ends; a 1 px divider between the halves */
static void cr_ade2_band(const cr_screen_t *s, uint16_t segcol)
{
    const int32_t y0 = 24 * 16, yT = y0 + 18 * 16, yB = y0 + 84 * 16;
    int32_t seg = (int32_t)s->wv[8] - 1, hi;
    cr_frect(8 * 16, yB + 16, 224 * 16, 16, T_LINE);
    for (hi = 0; hi < 2; hi++) {
        const uint8_t *e = s->wv + 4 * hi;
        int32_t hx0 = (hi ? 128 : 8) * 16, hx1 = (hi ? 232 : 112) * 16, barX = hx1 - 64, ex1 = barX - 96, EW = ex1 - hx0;
        int32_t sg = seg >= hi * 4 && seg < hi * 4 + 4 ? seg - hi * 4 : -1;
        int32_t yP = yB - (yB - yT) * e[3] / 255, yE = yB - (yB - yT) * e[2] / 255;
        int32_t xA = hx0 + EW * 2 * e[0] / (5 * 255), xD = xA + EW * 2 * e[1] / (5 * 255);
        int32_t xs[4] = {hx0, xA, xD, ex1}, py[4] = {yB, yP, yE, yE}, i;
        int16_t p[16 * 2];
        uint32_t np = 0, vi[4];
        for (i = 0; i < 4; i++) {                    /* steep runs in pieces <= 26 px tall: small boxes for cr_poly */
            if (i) {
                int32_t dy = py[i] - py[i - 1], m = (dy < 0 ? -dy : dy) / (26 * 16) + 1, k2;
                for (k2 = 1; k2 < m; k2++) {
                    p[2 * np] = (int16_t)(xs[i - 1] + (xs[i] - xs[i - 1]) * k2 / m);
                    p[2 * np + 1] = (int16_t)(py[i - 1] + dy * k2 / m);
                    np++;
                }
            }
            vi[i] = np;
            p[2 * np] = (int16_t)xs[i];
            p[2 * np + 1] = (int16_t)py[i];
            np++;
        }
        cr_poly(p, np, 48, 0, 0, T_TEXT);
        if (sg >= 0 && sg <= 2) {                    /* 0 attack, 1 decay, 2 the hold at the end level */
            cr_poly(p + 2 * vi[sg], vi[sg + 1] - vi[sg] + 1u, 64, 0, 0, segcol);
            cr_disc(xs[sg], py[sg], 56, segcol);
            cr_disc(xs[sg + 1], py[sg + 1], 56, segcol);
        }
        cr_frect(barX, yT, 64, yB - yT, T_LINE);
        if (yB > yP) cr_frect(barX, yP, 64, yB - yP, sg >= 0 ? segcol : T_MID);
        cr_text(hx0 * 16, P8(24 + 10), hi ? "B" : "A", 10, 1, CR_L, 4096, sg >= 0 ? segcol : T_MID, T_BG, 0);
    }
    cr_frect(1912, y0 + 4 * 16, 16, yB - y0 - 4 * 16, T_LINE);
}

/* GRAIN's wave band (CR_W_WAVE, core.h cr_wave_t through cr_wave_src): the buffers' envelopes column by column (a
 * source alone in white on its SRC screen; on the GRAIN screen the mix the grains read: the two envelopes weighted
 * by MORPH, in a colour from A's blue to B's orange), SPRD a dim green span round POS, POS a white line, and the
 * grains sounding as bars of one colour, as tall as their window is open, at their place in the buffer: they move as
 * they read */
static void cr_wave_band(const cr_screen_t *s)
{
    const int32_t L = 8 * 16, W = 224 * 16, y0 = 24 * 16, yc = y0 + 48 * 16, H = 40 * 16;
    const cr_wave_t *w = cr_wave_src ? cr_wave_src(s->wv[1]) : 0;
    uint32_t which = s->wv[0], k = which == 1u ? 1u : 0u, i, cw;
    uint16_t col;
    int32_t pm, x;
    if (!w || !w->cols)
        return;
    cw = W / (int32_t)w->cols;                                   /* a column's width (16: 224 columns) */
    pm = w->morph * 100 / 127;
    col = which == 2u ? ux_mix(T_BG, ux_mix(CR_NAMED[CR_COL_BLUE], CR_NAMED[CR_COL_ORANGE], pm), 55)
                      : ux_mix(T_BG, CR_NAMED[CR_COL_WHITE], 45);
    if (w->sprd) {                                               /* SPRD: the spread round POS */
        int32_t sw = W * w->sprd / 127, sx = L + W * w->pos / 127 - sw / 2;
        if (sx < L) sx = L;
        if (sx + sw > L + W) sw = L + W - sx;
        if (sw > 0) cr_frect(sx, y0 + 6 * 16, sw, 84 * 16, ux_mix(T_BG, CR_NAMED[CR_COL_GREEN], 14));
    }
    for (i = 0; i < w->cols; i++) {                              /* the envelope: a source's, or the mix's (the two
                                                                  * weighted by MORPH: near enough) */
        int32_t lo = w->env[k][2 * i], hi = w->env[k][2 * i + 1], ya, yb;
        if (which == 2u) {
            lo = (lo * (127 - w->morph) + w->env[1][2 * i] * w->morph) / 127;
            hi = (hi * (127 - w->morph) + w->env[1][2 * i + 1] * w->morph) / 127;
        }
        ya = yc - hi * H / 127;
        yb = yc - lo * H / 127;
        if (yb - ya < 16) { ya = yc - 8; yb = yc + 8; }
        cr_frect(L + (int32_t)(i * cw), ya, (int32_t)cw, yb - ya, col);
    }
    for (i = 0; i < w->n; i++) {                                 /* the grains: a bright line each, one colour (each
                                                                  * reads the mix), as strong as its window is open, the
                                                                  * height of the band: they move as they read */
        int32_t gx = L + W * w->gpos[i] / 255 - 16, lv = 35 + (int32_t)w->glev[i] * 65 / 255;
        if (gx < L) gx = L;
        if (gx > L + W - 32) gx = L + W - 32;
        cr_frect(gx, y0 + 6 * 16, 32, 84 * 16, ux_mix(T_BG, CR_NAMED[CR_COL_WHITE], lv));
    }
    x = L + W * w->pos / 127;                                    /* POS: a white line, 1 px */
    cr_frect(x - 8, y0 + 4 * 16, 16, 88 * 16, CR_NAMED[CR_COL_WHITE]);
}

/* the wide band: the AHDSR with its lit segment, or the filter's response over a dashed 0 dB line */
static void cr_wide(const cr_screen_t *s, uint16_t segcol)
{
    const int32_t L = 8 * 16, R = 232 * 16, W = R - L, y0 = 24 * 16;
    int16_t p[40 * 2];          /* (filter: <= 7 segments + 4 crossings + 1 = 13 points; cz: <= 9 segments of <= 4) */
    uint32_t np = 0, i;
#define CR_PT(px16, py16) (p[2 * np] = (int16_t)(px16), p[2 * np + 1] = (int16_t)(py16), np++)
    if (s->wide == CR_W_ALGO) {
        cr_algo_band(s);
    } else if (s->wide == CR_W_WAVE) {
        cr_wave_band(s);
    } else if (s->wide == CR_W_ADE2) {
        cr_ade2_band(s, segcol);
    } else if (s->wide == CR_W_ENV) {
        static const char *const LET[5] = {"A", "H", "D", "S", "R"};
        int32_t u[5], xs[6], sum = 0, yT = y0 + 8 * 16, yB = y0 + 84 * 16, yS = yB - (yB - yT) * s->wv[3] / 255;
        int32_t seg = (int32_t)s->wv[5] - 1;
        int32_t py[6];
        uint32_t vi[6];
        u[0] = 15 + s->wv[0]; u[1] = s->wv[1]; u[2] = 15 + s->wv[2]; u[3] = 77; u[4] = 15 + s->wv[4];
        for (i = 0; i < 5u; i++) sum += u[i];
        xs[0] = L;
        for (i = 0; i < 5u; i++) xs[i + 1] = xs[i] + u[i] * W / sum;
        py[0] = yB; py[1] = yT; py[2] = yT; py[3] = yS; py[4] = yS; py[5] = s->wv[6] ? yS : yB;   /* (REL INF: held to the edge) */
        cr_frect(L, yB + 16, W, 16, T_LINE);
        for (i = 0; i < 6u; i++) {               /* steep runs in pieces <= 26 px tall: small boxes for cr_poly */
            if (i) {
                int32_t dy = py[i] - py[i - 1], m = (dy < 0 ? -dy : dy) / (26 * 16) + 1, k2;
                for (k2 = 1; k2 < m; k2++)
                    CR_PT(xs[i - 1] + (xs[i] - xs[i - 1]) * k2 / m, py[i - 1] + dy * k2 / m);
            }
            vi[i] = np;
            CR_PT(xs[i], py[i]);
        }
        cr_poly(p, np, 48, 0, 0, T_TEXT);
        if (seg >= 0 && seg <= 4) {
            cr_poly(p + 2 * vi[seg], vi[seg + 1] - vi[seg] + 1u, 64, 0, 0, segcol);
            cr_disc(xs[seg], py[seg], 56, segcol);
            cr_disc(xs[seg + 1], py[seg + 1], 56, segcol);
        }
        for (i = 0; i < 5u; i++)
            if (xs[i + 1] - xs[i] >= 16 || (int32_t)i == seg)
                cr_text((xs[i] + xs[i + 1]) * 8, P8(24 + 95), LET[i], 9, 1, CR_C, 4096, (int32_t)i == seg ? segcol : T_DIM,
                        T_BG, 0);
    } else if (s->wide == CR_W_CZ) {
        /* CZ-1's eight-step envelope (wv: R1..R8, L1..L8 0..99, SUS 0..7 / 8 none, END 0..7, the lit step 1..8): from 0
         * to L1 at R1, .. L k at R k, the step END to 0 (the CZ ignores END's level); after the SUS step's point a hold
         * (the key down); the steps after END are not drawn. A step's width grows with its distance and the slowness
         * of its rate (a sketch of the times, as the dx band) */
        static const char *const LET[8] = {"1", "2", "3", "4", "5", "6", "7", "8"};
        int32_t yT = y0 + 8 * 16, yB = y0 + 84 * 16, u[9], xs[10], py[10], sum = 0, lv = 0, d;
        int32_t end = s->wv[17] > 7 ? 7 : s->wv[17], sus = s->wv[16] < end ? s->wv[16] : -1, hot = (int32_t)s->wv[18] - 1;
        int32_t ns = 0, sg[8], k;
        uint32_t vi[10];
        py[0] = yB;
        for (k = 0; k <= end; k++) {             /* segment ns: step k; after the SUS step a hold */
            int32_t r = s->wv[k] > 99 ? 99 : s->wv[k], t = k == end ? 0 : (s->wv[8 + k] > 99 ? 99 : s->wv[8 + k]);
            d = t - lv;
            d = d < 0 ? -d : d;
            sg[k] = ns;
            u[ns] = 6 + (99 - r) * (6 + d) / 24;
            py[ns + 1] = yB - (yB - yT) * t / 99;
            ns++;
            if (k == sus) {
                u[ns] = 30;
                py[ns + 1] = py[ns];
                ns++;
            }
            lv = t;
        }
        for (k = 0; k < ns; k++) sum += u[k];
        xs[0] = L;
        for (k = 0; k < ns; k++) xs[k + 1] = xs[k] + u[k] * W / (sum ? sum : 1);
        cr_frect(L, yB + 16, W, 16, T_LINE);
        for (k = 0; k <= ns; k++) {              /* steep runs in pieces <= 26 px tall: small boxes for cr_poly */
            if (k) {
                int32_t dy = py[k] - py[k - 1], m = (dy < 0 ? -dy : dy) / (26 * 16) + 1, k2;
                for (k2 = 1; k2 < m; k2++)
                    CR_PT(xs[k - 1] + (xs[k] - xs[k - 1]) * k2 / m, py[k - 1] + dy * k2 / m);
            }
            vi[k] = np;
            CR_PT(xs[k], py[k]);
        }
        cr_poly(p, np, 48, 0, 0, T_TEXT);
        if (sus >= 0)                            /* the hold: dashed over its run */
            cr_poly(p + 2 * vi[sg[sus] + 1], vi[sg[sus] + 2] - vi[sg[sus] + 1] + 1u, 48, 32, 64, T_DIM);
        if (hot >= 0 && hot <= end) {            /* step k (R k / L k / SUS / END turned): its segment */
            int32_t a0 = sg[hot], a1 = a0 + 1;
            cr_poly(p + 2 * vi[a0], vi[a1] - vi[a0] + 1u, 64, 0, 0, segcol);
            cr_disc(xs[a0], py[a0], 56, segcol);
            cr_disc(xs[a1], py[a1], 56, segcol);
        }
        for (k = 0; k <= end; k++) {
            int32_t j = sg[k];
            if (xs[j + 1] - xs[j] >= 16 * 16 || k == hot)
                cr_text((xs[j] + xs[j + 1]) * 8, P8(24 + 95), LET[k], 9, 1, CR_C, 4096, k == hot ? segcol : T_DIM,
                        T_BG, 0);
        }
        if (sus >= 0 && xs[sg[sus] + 2] - xs[sg[sus] + 1] >= 16 * 16)
            cr_text((xs[sg[sus] + 1] + xs[sg[sus] + 2]) * 8, P8(24 + 95), "S", 9, 1, CR_C, 4096, T_DIM, T_BG, 0);
    } else if (s->wide == CR_W_DX) {
        /* FM6's DX7 envelope (wv: R1..R4, L1..L4 0..99, the lit segment, the pitch EG flag): from L4 to L1 at R1, L2
         * at R2, L3 at R3, held at L3 (the key down), to L4 at R4; a segment's width grows with its distance and the
         * slowness of its rate (a sketch of the times, not to scale); the pitch EG's levels round a centre line (50) */
        static const char *const LET[4] = {"1", "2", "3", "4"};
        int32_t yT = y0 + 8 * 16, yB = y0 + 84 * 16, lv[5], u[5], xs[6], py[6], sum = 0, d;
        int32_t seg = (int32_t)s->wv[8] - 1, a0, a1;
        uint32_t vi[6], sg[4] = {0, 1, 2, 4};
        lv[0] = s->wv[7] > 99 ? 99 : s->wv[7];
        for (i = 0; i < 4u; i++)
            lv[i + 1] = s->wv[4 + i] > 99 ? 99 : s->wv[4 + i];
        for (i = 0; i < 4u; i++) {                /* R1 R2 R3 (segments 0..2), R4 (segment 4); 3 is the hold */
            uint32_t j = sg[i];
            int32_t r = s->wv[i] > 99 ? 99 : s->wv[i];
            d = i < 3u ? lv[i + 1] - lv[i] : lv[0] - lv[3];
            d = d < 0 ? -d : d;
            u[j] = 6 + (99 - r) * (6 + d) / 24;
        }
        u[3] = 36;
        for (i = 0; i < 5u; i++) sum += u[i];
        xs[0] = L;
        for (i = 0; i < 5u; i++) xs[i + 1] = xs[i] + u[i] * W / sum;
        for (i = 0; i < 4u; i++) py[i] = yB - (yB - yT) * lv[i] / 99;
        py[4] = py[3];
        py[5] = py[0];
        cr_frect(L, yB + 16, W, 16, T_LINE);
        if (s->wv[9])                             /* the pitch EG: its centre (no pitch change) */
            cr_frect(L, yB - (yB - yT) * 50 / 99, W, 16, T_LINE);
        for (i = 0; i < 6u; i++) {               /* steep runs in pieces <= 26 px tall: small boxes for cr_poly */
            if (i) {
                int32_t dy = py[i] - py[i - 1], m = (dy < 0 ? -dy : dy) / (26 * 16) + 1, k2;
                for (k2 = 1; k2 < m; k2++)
                    CR_PT(xs[i - 1] + (xs[i] - xs[i - 1]) * k2 / m, py[i - 1] + dy * k2 / m);
            }
            vi[i] = np;
            CR_PT(xs[i], py[i]);
        }
        cr_poly(p, np, 48, 0, 0, T_TEXT);
        if (seg >= 0 && seg <= 3) {               /* segment k (R k / L k turned): the one ending at L k */
            a0 = (int32_t)sg[seg];
            a1 = a0 + 1;
            cr_poly(p + 2 * vi[a0], vi[a1] - vi[a0] + 1u, 64, 0, 0, segcol);
            cr_disc(xs[a0], py[a0], 56, segcol);
            cr_disc(xs[a1], py[a1], 56, segcol);
        }
        for (i = 0; i < 4u; i++) {
            uint32_t j = sg[i];
            if (xs[j + 1] - xs[j] >= 16 || (int32_t)i == seg)
                cr_text((xs[j] + xs[j + 1]) * 8, P8(24 + 95), LET[i], 9, 1, CR_C, 4096, (int32_t)i == seg ? segcol : T_DIM,
                        T_BG, 0);
        }
    } else if (s->wide == CR_W_FILTER) {
        /* FTYPE: the weights of LP BP HP NOTCH (= LP + HP) at its position, crossfaded round the cycle */
        static const uint8_t TW[4][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {1, 0, 1}};
        /* the response at quarter-octave offsets from the cutoff, the edges extrapolated; 1.4 px a dB round the
         * 0 dB line, clamped to the band with the crossings: <= 13 points */
        static const int8_t Q[7] = {-12, -4, -1, 0, 1, 4, 12};
        /* FM TONE's combs (wv[7] 5 COMB+, 6 COMB-, 3y217): the teeth at f, 2f .. 6f (COMB-: f / 2, 3f / 2 ..), quarter
         * octaves x 16 from the cut, peak and notch by turns; their height by RESO (the feedback g: peak (1 - g / 2) /
         * (1 - g), notch (1 - g / 2) / (1 + g)), the higher ones damped by SHAPE (LPF) */
        static const int16_t CQ[12] = {-64, 0, 37, 64, 85, 101, 116, 128, 139, 149, 157, 165};
        int32_t cut = s->wv[0], res = s->wv[1], ft = s->wv[2] & 127, dr = s->wv[3], y0db = y0 + 38 * 16;
        int32_t sg = ft >> 5, fr = ft & 31, wt[3], comb = s->wv[7] == 5u || s->wv[7] == 6u, np1 = comb ? 12 : 7;
        int32_t ymin = y0 + 4 * 16, ymax = y0 + 90 * 16, cx = L + W * cut / 255, xs[14], ys[14], n = 0, k, j;
        for (k = 0; k < 3; k++)
            wt[k] = (TW[sg][k] * (32 - fr) + TW[(sg + 1) & 3][k] * fr) * 8;   /* (Q8) */
        for (k = 0; k < np1; k++) {
            int32_t db;
            if (comb) {                                              /* (Q12: g, its damped value at tooth k / 2) */
                int32_t g = res * 4034 / 255, h = k / 2, pk = (k & 1) == (s->wv[7] == 5u ? 1 : 0), m = 4096 - g / 2;
                for (j = 0; j < h; j++)
                    g = g * (3072 + (int32_t)s->wv[8] * 8) / 4096;
                db = (cr_log2((uint32_t)m << 8) - cr_log2((uint32_t)(pk ? 4096 - g : 4096 + g) << 8)) * 3011 / 256000;   /* (half
                                                                      * scale: its 30 dB teeth in the band) */
                xs[n + 1] = cx + CQ[k] * W / 576;
            } else if (s->wv[7] == 7u) {                             /* EQ: a bell at the cut, GAIN -18 .. +18 dB, its
                                                                      * width 2 octaves .. 1/4 by SHAPE (Q) */
                int32_t b = 8 - 7 * (int32_t)s->wv[8] / 127;
                db = ((int32_t)s->wv[9] - 64) * 9 / 2 * b * b / (b * b + Q[k] * Q[k]);
                xs[n + 1] = cx + Q[k] * W / 36;
            } else {
                db = s->wv[7] == 1u ? 0 : cr_fdb(wt[0], wt[1], wt[2], Q[k], res);   /* (OFF: flat) */
                xs[n + 1] = cx + Q[k] * W / 36;                      /* (9 octaves across W) */
            }
            if (s->wv[7] == 3u) db *= 2;                             /* (24 dB: two 12 dB stages, twice the slope) */
            ys[n + 1] = y0db - (db + dr * 96 / 255) * 14 / 10;
            if (comb) ys[n + 1] = ys[n + 1] < ymin ? ymin : ys[n + 1] > ymax ? ymax : ys[n + 1];
            n++;
        }
        xs[0] = L < xs[1] ? L : xs[1] - 16;                          /* the edges, on the outer lines (a comb's: level,
                                                                      * between its last tooth and notch) */
        ys[0] = comb ? (ys[1] + ys[2]) / 2 : ys[1] + (ys[2] - ys[1]) * (xs[0] - xs[1]) / (xs[2] - xs[1]);
        xs[np1 + 1] = R > xs[np1] ? R : xs[np1] + 16;
        ys[np1 + 1] = comb ? (ys[np1] + ys[np1 - 1]) / 2
                           : ys[np1] + (ys[np1] - ys[np1 - 1]) * (xs[np1 + 1] - xs[np1]) / (xs[np1] - xs[np1 - 1]);
        for (k = 0; k < np1 + 1; k++) {
            int32_t x0 = xs[k], x1 = xs[k + 1], ya, yb, xa, xb, t[2], nt = 0, lim[2];
            if (x1 <= L || x0 >= R || x1 <= x0) continue;
            xa = x0 < L ? L : x0;
            xb = x1 > R ? R : x1;
            ya = ys[k] + (ys[k + 1] - ys[k]) * (xa - x0) / (x1 - x0);
            yb = ys[k] + (ys[k + 1] - ys[k]) * (xb - x0) / (x1 - x0);
            if (!np) CR_PT(xa, ya < ymin ? ymin : ya > ymax ? ymax : ya);
            for (j = 0; j < 2; j++) {                                /* the band's limits crossed on the way */
                int32_t y = j ? ymax : ymin;
                if ((ya - y) * (yb - y) < 0) {
                    t[nt] = xa + (xb - xa) * (y - ya) / (yb - ya);
                    lim[nt++] = y;
                }
            }
            if (nt == 2 && t[0] > t[1]) {
                int32_t u = t[0]; t[0] = t[1]; t[1] = u;
                u = lim[0]; lim[0] = lim[1]; lim[1] = u;
            }
            for (j = 0; j < nt; j++) CR_PT(t[j], lim[j]);
            yb = yb < ymin ? ymin : yb > ymax ? ymax : yb;
            if (np >= 2 && p[2 * np - 1] == yb && p[2 * np - 3] == yb)
                p[2 * np - 2] = (int16_t)xb;                         /* (a run along a limit: one segment) */
            else
                CR_PT(xb, yb);
        }
        if (s->wv[4]) {                              /* QUAD's base-width window: a dim region (the orange at 12 % over
                                                      * the background: the designer's alpha, as a solid colour) */
            int32_t b = s->wv[5], e = b + s->wv[6] > 255 ? 255 : b + s->wv[6], bx = L + W * b / 255, ex = L + W * e / 255;
            if (ex > bx) cr_frect(bx, ymin, ex - bx, ymax - ymin, ux_mix(T_BG, CR_NAMED[CR_COL_ORANGE], 12));
        }
        {
            int16_t d[4] = {(int16_t)L, (int16_t)y0db, (int16_t)R, (int16_t)y0db};
            cr_poly(d, 2, 16, 48, 112, T_MID);
        }
        if (s->wv[4]) {                              /* .. its edges dashed 1.5 px (3 on, 3 off), B and W under them */
            int32_t b = s->wv[5], e = b + s->wv[6] > 255 ? 255 : b + s->wv[6], bx = L + W * b / 255, ex = L + W * e / 255;
            int32_t close = ex - bx < 12 * 16, xx, yy, k2;
            uint16_t oc = CR_NAMED[CR_COL_ORANGE];
            for (k2 = 0; k2 < 2; k2++)
                for (xx = k2 ? ex : bx, yy = ymin; yy < ymax; yy += 96)
                    cr_frect(xx - 12, yy, 24, ymax - yy < 48 ? ymax - yy : 48, oc);
            xx = bx - (close ? 80 : 0);
            cr_text((xx > L + 48 ? xx : L + 48) * 16, P8(24 + 96), "B", 9, 1, CR_C, 4096, oc, T_BG, 0);
            xx = ex + (close ? 80 : 0);
            cr_text((xx < R - 64 ? xx : R - 64) * 16, P8(24 + 96), "W", 9, 1, CR_C, 4096, oc, T_BG, 0);
        }
        cr_poly(p, np, 48, 0, 0, CR_NAMED[CR_COL_ORANGE]);
        {                                            /* the type: the VA's position name; QUAD's (wv[7]) OFF, the
                                                      * name and its slope "LP12" "HP12" "LP24", a machine's name */
            static const char *const MN[4] = {"MULTI", "COMB+", "COMB-", "EQ"};
            char tn[8];
            const uint32_t mi = s->wv[7] - 4u;
            const char *nm = s->wv[7] == 1u ? "OFF" : mi < 4u ? MN[mi] : cr_ftype_name((uint32_t)ft);
            uint32_t i2 = 0;
            while (nm[i2] && i2 < 5u) { tn[i2] = nm[i2]; i2++; }
            if (s->wv[7] >= 2u && mi >= 4u) { tn[i2++] = s->wv[7] == 3u ? '2' : '1'; tn[i2++] = s->wv[7] == 3u ? '4' : '2'; }
            tn[i2] = 0;
            cr_text(P8(8), P8(24 + 12), tn, 10, 1, CR_L, 4096, T_MID, T_BG, 0);
        }
        if (dr) {
            char b[12] = "DRIVE ";
            int32_t v = (dr * 100 + 127) / 255, i2 = 6;
            if (v >= 100) b[i2++] = '1';
            if (v >= 10) b[i2++] = (char)('0' + v / 10 % 10);
            b[i2++] = (char)('0' + v % 10);
            b[i2] = 0;
            cr_text(P8(232), P8(24 + 12), b, 10, 1, CR_R, 4096, T_MID, T_BG, 0);
        }
    }
#undef CR_PT
}

static uint16_t cr_ccol(uint32_t ci, int on) { return on ? CR_NAMED[CR_KC[ci & 3u]] : T_DIM; }
/* rows y0 .. y1 - 1 (px) cross the strip being drawn: else what lies wholly in them is not even measured */
static int cr_in_strip(int32_t y0, int32_t y1) { return y1 > cr_row0() && y0 < cr_row1(); }
/* the hot cell's block: the knob's colour, or the modulation source's while mapping */
static uint16_t cr_hcol(const cr_screen_t *s, uint16_t col) { return s->hot_col ? cr_rgb(s->hot_col, col) : col; }
/* a cell's modulation mark: a 4 px square, its top right corner at (x1, y0) px */
static void cr_mark(const cr_cell_t *c, int32_t x1, int32_t y0)
{
    uint32_t m = CR_CF_MARKCOL(c->flags);
    if (m) cr_fill(x1 - 4, y0, 4, 4, cr_rgb(m, CR_WHITE));
}

/* edit8 `tall`: one row of four level bars over the panel (the oscillator mixer): the label, a tall well filled from
 * the bottom, the value; the knob bars under them. tall 2, a read-out (Geek Out 2): bright, no knob bars, pct2 (not 0)
 * a 2 px peak tick across the well (the cell's colour over the fill, a darker shade inside it), CR_CF_DIM in the grey */
static void cr_p_tall(const cr_screen_t *s)
{
    int32_t ci;
    int ro = s->tall == 2u;
    for (ci = 0; ci < 4; ci++) {
        const cr_cell_t *c = &s->cell[0][ci];
        int32_t x = ci * 60, cx = P8(x + 30), top = 56, h = 148, f;
        uint16_t col = (c->flags & CR_CF_DIM) ? cr_rgb(CR_COL_GREY, T_DIM) : cr_ccol((uint32_t)ci, ro || s->active == 0u);
        int hot = s->hot_r == 1u && s->hot_c == ci;
        if (!(c->flags & CR_CF_ON)) continue;
        if (c->label[0]) {
            char b[16];
            int cut = cr_fit(b, sizeof b, c->label, 12, 1, P8(56));
            cr_text(cx, P8(46), b, 12, 1, CR_C, 4096, col, T_BG, cut ? 9u : 0u);
        }
        cr_mark(c, x + 56, 32);
        f = h * (c->pct >= 255 ? 256 : c->pct) / 256;
        cr_fill(x + 18, top, 24, h - f, T_LINE);
        if (f > 0) cr_fill(x + 18, top + h - f, 24, f, col);
        if (ro && c->pct2) {                         /* the peak: its top edge at pct2's height */
            int32_t p = h * (c->pct2 >= 255 ? 256 : c->pct2) / 256, y = top + h - p;
            y = y < top ? top : y > top + h - 2 ? top + h - 2 : y;
            cr_fill(x + 18, y, 24, 2, p > f ? col : ux_mix(col, T_BG, 50));
        }
        cr_cvalue(c, cx, P8(226), P8(60), 17, hot ? cr_hcol(s, col) : col, hot, 0);
    }
    if (s->active == 0u && !ro)
        for (ci = 0; ci < 4; ci++)
            if (s->cell[0][ci].flags & CR_CF_ON)
                cr_fill(ci * 60 + 4, 236, 52, 2, cr_ccol((uint32_t)ci, 1));
}

static void cr_p_edit8(const cr_screen_t *s)
{
    int wide = s->wide != CR_W_NONE, big = !wide || s->n_rows == 1u;   /* (one lane under a band: full size) */
    int32_t rowy[2], rowh = big ? 100 : 56, ri, ci;
    uint32_t lpx = big ? 12u : 10u, vpx = big ? 17u : 13u;
    int32_t gh = big ? 34 : 22, ly = big ? 16 : 11, gyo = big ? 26 : 15, vyo = big ? 82 : 51;
    rowy[0] = wide ? 124 : 30;
    rowy[1] = wide ? 184 : 134;
    if (cr_in_strip(0, 26)) cr_ed_title(s);
    if (s->tall) {
        cr_p_tall(s);
        return;
    }
    if (wide && cr_in_strip(22, 124)) {
        uint32_t lit = s->wide == CR_W_DX || s->wide == CR_W_ADE2 ? s->wv[8] : s->wide == CR_W_CZ ? s->wv[18] : s->wv[5];
        uint16_t sc = s->hot_r ? cr_ccol(s->hot_c, 1) : CR_NAMED[CR_KC[(lit ? lit - 1u : 0u) % 4u]];
        cr_wide(s, sc);
    }
    for (ri = 0; ri < (int32_t)s->n_rows && ri < 2; ri++) {
        int on = ri == s->active, y = rowy[ri];
        int32_t col0 = 0, mid = y + (gyo + vyo) / 2;                 /* (mid: the glyph and value's space) */
        if (!cr_in_strip(y - 2, y + rowh + 2)) continue;
        for (ci = 0; ci < 4 && col0 < 4; ci++) {
            const cr_cell_t *c = &s->cell[ri][ci];
            int32_t sp = cr_span(c, col0), x = col0 * 60, w = 60 * sp, cx = P8(x) + P8(w) / 2;
            uint16_t col = cr_ccol((uint32_t)col0, on), vcol;
            int hot = s->hot_r == ri + 1 && s->hot_c == ci, ratio, bigv;
            col0 += sp;
            if (!(c->flags & CR_CF_ON)) continue;
            vcol = hot ? cr_hcol(s, col) : col;
            ratio = c->glyph == CR_G_RATIO && c->pct && c->pct2;
            bigv = !ratio && ((c->flags & CR_CF_BIG) || c->glyph == CR_G_RATIO);
            if (c->label[0]) {
                char b[16];
                int cut = cr_fit(b, sizeof b, c->label, lpx, 1, CR_CF_MARKCOL(c->flags) && !big ? P8(w - 14) : P8(w - 4));
                cr_text(cx, P8(y + ly), b, lpx, 1, CR_C, 4096, col, T_BG, cut ? 9u : 0u);
            }
            cr_mark(c, x + w - 2, y + 1);
            if (ratio) {
                cr_cratio(c, cx, P8(mid), P8(w), vcol, hot);
            } else if (bigv) {                                       /* the value 7 px larger, centred in the space */
                cr_cnum(c->value, cx, P8(mid) + (int32_t)(vpx + 7u) * 92, P8(w), vpx + 7u, vcol, hot);
            } else {
                if (c->glyph != CR_G_NONE) cr_cglyph(c, (x + 30 * sp - 25 * sp) * 16, (y + gyo) * 16, 50 * sp * 16, gh * 16, col);
                else cr_hbar(c, (x + 8) * 16, (w - 16) * 16, (y + gyo + gh / 2 - 2) * 16, 64, col);
                cr_cvalue(c, cx, P8(y + vyo), P8(w), vpx, vcol, hot, 0);
            }
        }
    }
    if (s->active < s->n_rows && s->active < 2u) {               /* the active row's bars (a span's: both columns) */
        int32_t col0 = 0;
        for (ci = 0; ci < 4 && col0 < 4; ci++) {
            const cr_cell_t *c = &s->cell[s->active][ci];
            int32_t sp = cr_span(c, col0);
            if (c->flags & CR_CF_ON)
                cr_fill(col0 * 60 + 4, rowy[s->active] + rowh - 2, 60 * sp - 8, 2, cr_ccol((uint32_t)col0, 1));
            col0 += sp;
        }
    }
}

static void cr_p_stack(const cr_screen_t *s)
{
    uint32_t n = s->n_rows ? (s->n_rows > CR_ED_ROWS ? CR_ED_ROWS : s->n_rows) : 1u;
    int32_t labw = 0, lw, cw, r0 = P8(41), rh = P8(198) / (int32_t)n, ri, ci;
    int compact = rh < P8(30);
    for (ri = 0; ri < (int32_t)n; ri++)
        if (s->rlabel[ri][0]) {
            int32_t w = cr_tw(s->rlabel[ri], 11, 1);
            labw = w > labw ? w : labw;
        }
    lw = labw ? ((labw + 255) & ~255) + P8(12) : 0;
    lw = lw > P8(44) ? P8(44) : lw;
    cw = (P8(240) - lw) / 4;
    if (cr_in_strip(0, 26)) cr_ed_title(s);
    for (ci = 0; ci < 4 && cr_in_strip(24, 41); ci++)
        if (s->head[ci][0]) {
            char b[16];
            int cut = cr_fit(b, sizeof b, s->head[ci], 10, 1, cw - P8(4));
            cr_text(lw + ci * cw + cw / 2, P8(36), b, 10, 1, CR_C, 4096, T_DIM, T_BG, cut ? 9u : 0u);
        }
    for (ri = 0; ri < (int32_t)n; ri++) {
        int32_t y = r0 + ri * rh;                                    /* Q8 */
        int on = ri == s->active;
        if (!cr_in_strip((y >> 8) - 2, ((y + rh) >> 8) + 2)) continue;
        if (ri) cr_frect(4 * 16, (y >> 4) - 8, 232 * 16, 16, T_LINE);
        if (s->rlabel[ri][0])
            cr_text_fit(P8(6), y + rh / 2 + P8(4), s->rlabel[ri], 11, 1, CR_L, on ? T_TEXT : T_DIM, T_BG, lw - P8(6));
        int32_t col0 = 0;
        for (ci = 0; ci < 4 && col0 < 4; ci++) {
            const cr_cell_t *c = &s->cell[ri][ci];
            int32_t sp = cr_span(c, col0), x = lw + col0 * cw, cw1 = cw, cx;
            uint16_t col = cr_ccol((uint32_t)col0, on), vcol;
            int hot = s->hot_r == ri + 1 && s->hot_c == ci;
            int32_t cw = cw1 * sp;                                   /* (this cell's width: a span's two columns) */
            col0 += sp;
            cx = x + cw / 2;
            if (!(c->flags & CR_CF_ON)) continue;
            vcol = hot ? cr_hcol(s, col) : col;
            cr_mark(c, (x + cw) >> 8, (y >> 8) + 2);
            if (compact) {                                           /* ~24 px rows (the mod matrix): text, a thin bar */
                cr_cvalue(c, cx, y + P8(14), cw, 12, vcol, hot, 0);
                cr_hbar(c, (x + P8(6)) >> 4, (cw - P8(12)) >> 4, (y + P8(17) + 128) >> 4, 32, col);
            } else if (c->glyph != CR_G_NONE && c->glyph != CR_G_BAR && c->glyph != CR_G_RATIO) {   /* a glyph over its value */
                int showv = rh >= P8(44) && c->value[0];
                int32_t gh = showv ? rh - P8(24) : rh - P8(10);
                if (gh > P8(40)) gh = P8(40);
                cr_cglyph(c, (x + P8(6)) >> 4, (y + P8(4) + (showv ? 0 : (rh - P8(10) - gh) / 2)) >> 4, (cw - P8(12)) >> 4,
                          gh >> 4, col);
                if (showv)                                           /* (a long name, "SAW>RMP": 9 px) */
                    cr_cvalue(c, cx, y + P8(4) + gh + P8(14), cw, cr_tw(c->value, 11, 1) > cw - P8(6) ? 9u : 11u, vcol, hot,
                              0);
            } else {                                                 /* a value with its bar under it */
                uint32_t vpx = rh >= P8(45) ? 15u : 13u;
                int32_t vy = y + rh / 2 + P8(vpx) / 2 - P8(3);
                cr_cvalue(c, cx, vy, cw, vpx, vcol, hot, 0);
                cr_hbar(c, (x + P8(6)) >> 4, (cw - P8(12)) >> 4, (vy + P8(5)) >> 4, 48, col);
            }
        }
    }
    if (s->active < n) {                                             /* the active row's bars */
        int32_t col0 = 0;
        for (ci = 0; ci < 4 && col0 < 4; ci++) {
            const cr_cell_t *c = &s->cell[s->active][ci];
            int32_t sp = cr_span(c, col0), x = lw + col0 * cw, y = r0 + (int32_t)s->active * rh + rh - P8(3);
            if (c->flags & CR_CF_ON) cr_frect((x + P8(4)) >> 4, y >> 4, (cw * sp - P8(8)) >> 4, 32, cr_ccol((uint32_t)col0, 1));
            col0 += sp;
        }
    }
}

#if CR_LAY_FREE   /* (cr_layout.c: a built design's free screens, or the layout tool's preview) */
/* ---------------------------------------------------------- the free screens --- */
/* CR_K_FREE: a compiled layout's screen (cr_layout.c; docs/LAYOUT-TOOL.md "The p5 style"), drawn from the table and the
 * cells, never the engine: the title line, then the elements in the table's order (frames first), each composed as
 * the layout tool composes it (web/fm1layout.js freeOps / p5Op on these very primitives: web/test_layout.mjs compares
 * the two pictures pixel for pixel). Colours: an element's own token, else on the active lane its knob's colour by
 * slot, on another lane dim, in no lane text. Per strip, an element whose rows (cr_free_ext) miss it is not drawn */
/* the rows an element draws in: its box, a knob's label and value rows, an led's texts, a frame's title, a margin */
static void cr_free_ext(const cr_lay_elem_t *e, int32_t *y0, int32_t *y1)
{
    int32_t b = e->y + e->h;
    if (e->type == CR_E_KNOB && e->y + e->size + 28 > b) b = e->y + e->size + 28;
    if (e->type == CR_E_LED && e->y + 58 > b) b = e->y + 58;
    if (e->type == CR_E_SWITCH && e->y + 58 > b) b = e->y + 58;
    *y0 = e->type == CR_E_FRAME ? e->y - 6 : e->type == CR_E_LABEL && e->y + e->h - e->size - 4 < e->y ?
          e->y + e->h - e->size - 6 : e->y - 2;      /* (a frame's title block from y - 5; a label's ascent) */
    *y1 = b + 4;
}
/* element e (at: its lane * 4 + slot, CR_LAY_EMPTY in none) */
static void cr_free_el(const cr_screen_t *s, const cr_lay_elem_t *e, uint32_t at)
{
    static const uint8_t WAVE[6] = {0, 0, 2, 1, 3, 4};   /* CR_LI_* -> cr_wave1's kinds */
    static const cr_cell_t Z;
    const cr_cell_t *cl = at < CR_LAY_LANES * CR_LAY_SLOTS ? &s->cell[at / 4u][at % 4u] : 0;
    int lit = cl && at / 4u == s->active, hot = cl && s->hot_r == at / 4u + 1u && s->hot_c == at % 4u;
    uint16_t col = cr_rgb(e->colour ? e->colour : !cl ? (uint32_t)CR_COL_TEXT : lit ? (uint32_t)CR_KC[at % 4u] : (uint32_t)CR_COL_DIM, T_TEXT);
    const char *lab = cr_lay_str(e->label), *vt = cl ? cl->value : "", *n;
    int32_t cx = e->x + (e->w >> 1), y, i;
    switch (e->type) {
    case CR_E_FRAME:                     /* a rounded outline, its title in capitals on a bg block in the top border */
        cr_box(e->x, e->y, e->w, e->h, e->colour ? col : T_LINE, e->r, 1);
        if (lab[0]) {
            int32_t tw = cr_twpx(lab, 10, 1);
            if (tw > e->w - 12) tw = e->w - 12;
            cr_box(cx - (tw >> 1) - 3, e->y - 5, tw + 6, 10, T_BG, 0, 0);
            cr_ftext(cx, e->y + 4, lab, 10, 1, CR_C, T_MID, e->w - 12);
        }
        break;
    case CR_E_KNOB: {                    /* the dial; the value inside the face when the widest of its texts fits */
        int32_t size = e->size, cy = e->y + (size >> 1), w9 = cr_twpx(vt, 9, 1), inside;
        for (n = cr_lay_names(e); n; n = cr_lay_next(n))
            if (cr_twpx(n, 9, 1) > w9) w9 = cr_twpx(n, 9, 1);
        inside = w9 <= 2 * ((size >> 1) - 6) - 4;
        cr_p5knob(cx, cy, size, hot ? col : T_SURF, T_MID, T_LINE, hot ? T_BG : col, cl ? cl->pct : 0u,
                  cl && (cl->flags & CR_CF_BIP), inside ? 70u : 30u);
        if (inside) cr_ftext(cx, cy + 3, vt, 9, 1, CR_C, hot ? T_BG : col, 0);
        cr_ftext(cx, e->y + size + CR_P5_UNDER, lab, 10, 1, CR_C, col, e->w - 2);
        if (!inside) {
            if (hot) cr_box(e->x + 3, e->y + size + 15, e->w - 6, 12, col, 2, 0);
            cr_ftext(cx, e->y + size + 24, vt, 10, 1, CR_C, hot ? T_BG : col, e->w - 4);
        }
        break;
    }
    case CR_E_LED: {                     /* the panel's button: the icon / names / label over the cap, the LED(s) */
        int on = cl && cl->pct2, two = (e->flags & CR_LF_LEDS2) != 0, below = (e->flags & CR_LF_BELOW) != 0;
        uint32_t icon = two ? 0u : CR_LF_ICON(e->flags), pair = CR_LF_PAIR(e->flags);
        uint16_t ink = lit ? col : on ? T_MID : T_DIM, labc = two ? col : ink;
        int labtop = lab[0] && !below && !icon;
        int32_t rows = (labtop ? 1 : 0) + (icon || two ? 1 : 0), top, cxl;
        y = rows ? e->y + 12 * rows : e->y + 2;
        cxl = two ? cx : pair == CR_LP_LEFT ? e->x + e->w - 9 : pair == CR_LP_RIGHT ? e->x + 8 : cx;
        if (labtop) cr_ftext(cxl, e->y + 9, lab, 10, 1, CR_C, labc, e->w - 2);
        top = e->y + (labtop ? 12 : 0);
        if (two) {                       /* one parameter of two values: the minimum red, the maximum yellow */
            cr_cap(cx - 15, y, 30, 18, 0);
            for (i = 0, n = cr_lay_names(e); i < 2; i++) {
                int32_t x = i ? cx + 7 : cx - 7;
                cr_ftext(x, top + 9, n ? n : "", 9, 1, CR_C, i == on ? (lit ? col : T_MID) : T_DIM, 0);
                cr_disc(x * 16, (y + 5) * 16, i == on ? 40 : 24, i == on ? (i ? CR_YELLOW : CR_RED) : T_DIM);
                if (n) n = cr_lay_next(n);
            }
        } else {
            if (icon) cr_wave1(WAVE[icon % 6u], cxl - 8, top, 16, 10, ink);
            cr_cap(cxl - 9, y, 18, 18, pair == CR_LP_LEFT ? CR_RSQR : pair == CR_LP_RIGHT ? CR_RSQL : 0u);
            cr_disc(cxl * 16, (y + 5) * 16, on ? 40 : 24, on ? CR_RED : T_DIM);
        }
        if (below && lab[0]) cr_ftext(cxl, y + 18 + CR_P5_UNDER, lab, 10, 1, CR_C, labc, e->w - 2);
        break;
    }
    case CR_E_SWITCH: {                  /* a lever in a slot, the positions' names beside it */
        int32_t np = CR_LF_POS(e->flags) == 3u ? 3 : 2, cur = cl ? cl->pct2 : 0, sx = e->x + 4, sy = e->y + 16;
        if (cur >= np) cur = np - 1;
        cr_ftext(cx, e->y + 10, lab, 10, 1, CR_C, col, e->w - 2);
        cr_box(sx, sy, 8, 12 * np, T_LINE, 2, 1);
        cr_box(sx + 1, sy + 12 * cur + 2, 6, 8, col, 0, 0);
        for (i = 0, n = cr_lay_names(e); i < np; i++) {
            cr_ftext(sx + 13, sy + 12 * i + 10, n ? n : "", 10, 1, CR_L, i == cur ? col : T_DIM, e->w - 18);
            if (n) n = cr_lay_next(n);
        }
        break;
    }
    case CR_E_LABEL: {                   /* its baseline the box's bottom edge */
        uint32_t al = CR_LF_ALIGN(e->flags);
        cr_ftext(al == 1u ? cx : al == 2u ? e->x + e->w : e->x, e->y + e->h, lab, e->size, (e->flags & CR_LF_BOLD) != 0,
                 (int)al, col, e->w);
        break;
    }
    case CR_E_BAR: {                     /* (the flat look) the label, the editor's level bar, the value */
        cr_cell_t b = Z;
        b.flags = (uint16_t)(CR_CF_ON | CR_CF_PCT | (cl ? (cl->flags & CR_CF_BIP) : 0u));
        b.pct = cl ? cl->pct : 0u;
        cr_ftext(cx, e->y + 10, lab, 10, 1, CR_C, col, e->w - 2);
        cr_hbar(&b, (e->x + 4) * 16, (e->w - 8) * 16, (e->y + 14) * 16, 4 * 16, col);
        if (hot) cr_box(e->x + 3, e->y + e->h - 12, e->w - 6, 12, col, 2, 0);
        cr_ftext(cx, e->y + e->h - 2, vt, 10, 1, CR_C, hot ? T_BG : col, e->w - 4);
        break;
    }
    case CR_E_GLYPH: {                   /* a CR_G_* pictogram, its fill from the parameter (unbound: half) */
        cr_cell_t g = Z;
        g.flags = CR_CF_ON;
        g.glyph = e->size;
        g.pct = cl ? cl->pct : 128u;
        cr_cglyph(&g, e->x * 16, e->y * 16, e->w * 16, e->h * 16, col);
        break;
    }
    default:                             /* (a band: refused by tools/gen_layout.py) */
        break;
    }
}
static void cr_p_free(const cr_screen_t *s)
{
    const cr_lay_screen_t *ls = cr_lay_scr(s->fl_eng, s->fl_scr);
    uint32_t i;
    int32_t y0, y1;
    if (cr_in_strip(0, 26)) cr_ed_title(s);
    for (i = 0; ls && i < ls->count; i++) {
        const cr_lay_elem_t *e = cr_lay_el(s->fl_eng, ls, i);
        cr_free_ext(e, &y0, &y1);
        if (cr_in_strip(y0, y1)) cr_free_el(s, e, cr_lay_where(ls, i));
    }
}
#endif /* CR_LAY_FREE */

/* CR_K_KNOBROW (FORMAT.md "knobrow"): a layer screen. The panel above the lowest 72 px is a horizontal picker band
 * (the item 34 px bold in col squeezed to 170 px, its neighbours 13 px dim at the edges, the square marks under it,
 * `label` 11 px dim top left, `value` 13 px bold under the marks); the 72 px are one row of four knob cells,
 * edit8's look made taller: the label 10 px (+11), a 48 x 36 glyph box (+15), the value 13 px bold (+66), the 2 px
 * knob-colour bar (+70). A cell with pct and no glyph draws the bar glyph; a cell not CR_CF_ON a dim dash, a
 * CR_CF_DIM cell all in the grey. kr_band 1: the band is cr_keyboard's strip (KEY) under `label`. The band
 * slides (CR_A_SLIDE) as a picker's; the row has no motion (the hot cell: the value on a block of its colour). */
#define CR_KR_ROW 72
static int32_t cr_kr_rowy(const cr_screen_t *s) { return CR_PY0 + cr_ph(s) - CR_KR_ROW; }

/* the knob row's four cells (cell[0]) at row ry, rh px tall (72: knobrow's; the loop menu's 64 over its foot: every
 * offset scaled by rh / 72): the label (+11), a 48 x 36 glyph box (+15), the value 13 px bold (+66), the 2 px bar at the
 * bottom; a CR_CF_BIG cell: the value 20 px centred where the glyph and the value would be (the loop menu's Keys) */
static void cr_kr_cells(const cr_screen_t *s, int32_t ry, int32_t rh)
{
    int32_t ci;
#define CR_KY(v) (P8(ry) + P8(v) * rh / CR_KR_ROW)   /* a row offset of the 72 px design -> Q8 */
    if (!cr_in_strip(ry - 2, ry + rh + 2)) return;
    for (ci = 0; ci < 4; ci++) {
        cr_cell_t c = s->cell[0][ci];
        int32_t x = ci * 60, cx = P8(x + 30);
        uint16_t kc = (c.flags & CR_CF_DIM) ? cr_rgb(CR_COL_GREY, T_DIM) : cr_ccol((uint32_t)ci, 1);   /* dim: grey */
        int hot = s->hot_r == 1u && s->hot_c == ci;
        if (!(c.flags & CR_CF_ON)) {                 /* no parameter: a dim dash where the value would be */
            cr_frect((x + 26) * 16 + 8, CR_KY(61) >> 4, 7 * 16, 32, T_DIM);
            continue;
        }
        if (c.label[0]) {
            char b[16];
            int cut = cr_fit(b, sizeof b, c.label, 10, 1, CR_CF_MARKCOL(c.flags) ? P8(46) : P8(56));
            cr_text(cx, CR_KY(11), b, 10, 1, CR_C, 4096, kc, T_BG, cut ? 9u : 0u);
        }
        cr_mark(&c, x + 58, ry + 1);
        if (c.flags & CR_CF_BIG) {                   /* a number-only cell: 20 px in the glyph and value's space */
            cr_cnum(c.value, cx, (CR_KY(15) + CR_KY(66)) / 2 + 20 * 92, P8(60), 20u, hot ? cr_hcol(s, kc) : kc, hot);
        } else {
            if (c.glyph == CR_G_NONE && (c.flags & CR_CF_PCT)) c.glyph = CR_G_BAR;
            if (c.glyph != CR_G_NONE) cr_cglyph(&c, (x + 6) * 16, CR_KY(15) >> 4, 48 * 16, (36 * 16) * rh / CR_KR_ROW, kc);
            if (!((c.flags & CR_CF_WRAP) && c.glyph == CR_G_NONE && cr_tw(c.value, 15, 1) > P8(54) &&
                  cr_cwrap(c.value, cx, CR_KY(46), CR_KY(66), P8(60), hot ? cr_hcol(s, kc) : kc, hot)))
                cr_cvalue(&c, cx, CR_KY(66), P8(60), 13, hot ? cr_hcol(s, kc) : kc, hot, 0);
        }
        cr_fill(x + 4, ry + rh - 2, 52, 2, kc);
    }
#undef CR_KY
}

/* kr_band 2: the arp in the knob row's band (PERF while notes are stepped): cr_p_arp fitted to the 98 px over the
 * row. The chord's name 20 px under the label (baseline +32), the notes on a line 26 px over the row (13 px, the
 * rule under them), the sounding one 15 px on its block above the line, the dotted arc to the next. No rate line
 * (the row's cells say it). The hop's rows are by - 40 .. by + 14 (cr_arp_strips): with a footer rows 60 .. 114,
 * strips 1 and 2, never the row's (126 ..) */
#define CR_KA_BY(s) (cr_kr_rowy(s) - 26)
static void cr_kr_arp(const cr_screen_t *s)
{
    int32_t n = s->n_notes, by = CR_KA_BY(s), gap16 = n > 1 ? 200 * 16 / (n - 1) : 0, x0, i, pos = s->pos;
    if (gap16 > 52 * 16) gap16 = 52 * 16;
    if (s->name.root[0]) cr_name(&s->name, P8(120), P8(CR_PY0 + 32), 20, 200, 4096);
    cr_fill(14, by + 11, 212, 2, T_LINE);
    x0 = 120 * 16 - (n - 1) * gap16 / 2;                            /* Q4 */
    if (pos >= 0 && pos < n && n > 1) {
        int32_t xa = x0 + pos * gap16, xb = x0 + ((pos + 1) % n) * gap16;
        cr_quad(xa, (by - 22) * 16, (xa + xb) / 2, (by - 52) * 16, xb, (by - 2) * 16, 32, 48, 112,
                cr_rgb(s->hop_col, T_MID));
    }
    for (i = 0; i < n; i++) {
        uint16_t c = cr_rgb(s->note[i].col, CR_WHITE);
        int32_t x = x0 + i * gap16;
        if (i == pos) {
            int32_t w = (cr_tw(s->note[i].t, 15, 1) >> 8) + 14;
            cv_rrect((x >> 4) - w / 2, by - 22 - 12, w, 24, 3, c, T_BG);
            cr_text(x << 4, P8(by - 22 + 5), s->note[i].t, 15, 1, CR_C, 4096, T_BG, c, 0);
        } else {
            cr_text(x << 4, P8(by + 5), s->note[i].t, 13, 1, CR_C, 4096, c, T_BG, 0);
        }
    }
}

/* kr_band 3's neighbour: its place in the list (1-based), two spaces, the item */
static void cr_kr_numbered(char *b, uint32_t n, int32_t at, const char *item)
{
    uint32_t i = 0, v = (uint32_t)at + 1u;
    if (v >= 10u && i + 1u < n) b[i++] = (char)('0' + v / 10u);
    if (i + 1u < n) b[i++] = (char)('0' + v % 10u);
    if (i + 1u < n) b[i++] = ' ';
    if (i + 1u < n) b[i++] = ' ';
    while (*item && i + 1u < n) b[i++] = *item++;
    b[i] = 0;
}

static void cr_p_knobrow(const cr_screen_t *s, const cr_frame_t *fr, int32_t ph)
{
    int32_t n = s->n_items, sel = s->sel < n ? s->sel : n - 1, size = s->size ? s->size : 34, ry = cr_kr_rowy(s);
    int32_t bandh = P8(ph - CR_KR_ROW), bigh = size * 282, labelh = s->label[0] ? P8(14) : 0;   /* Q8 */
    int32_t stack = bigh + P8(10) + (s->value[0] ? P8(18) : 0), top = P8(CR_PY0) + labelh + (bandh - labelh - stack) / 2;
    int32_t base = top + bigh * 4 / 5, marks = (top + bigh + P8(4) + 128) >> 8;
    uint16_t col = cr_rgb(s->col, T_TEXT);
    if (cr_in_strip(CR_PY0, ry)) {                   /* the band */
        if (s->label[0]) cr_text_fit(P8(8), P8(CR_PY0 + 12), s->label, 11, 0, CR_L, T_DIM, T_BG, P8(224));
        if (s->kr_band == 1u) {                      /* the keyboard (KEY): the 224 px strip, <= 56 px tall, centred */
            int32_t avail = ry - CR_PY0 - 18 - 6, kh = avail < 56 ? avail : 56;
            cr_keyboard(s, CR_PY0 + 18 + (avail - kh) / 2, kh);
        } else if (s->kr_band == 2u) {               /* the arp (PERF, notes stepping) */
            cr_kr_arp(s);
        } else if (s->kr_band == 3u && n > 0) {      /* a vertical picker (KEY page 3): the neighbours above / below */
            int32_t y0 = P8(CR_PY0 + 18), y1 = P8(ry - 4), mid = (y0 + y1) / 2, bh = 27 * 282;   /* (Q8) */
            int32_t vt = mid - bh / 2, vb = mid + bh / 2, vbase = vt + bh * 4 / 5;
            char b[32];
            if (sel > 0) {
                cr_kr_numbered(b, sizeof b, sel - 1, cr_item(s, sel - 1));
                cr_text_fit(P8(120), vt - P8(5), b, 12, 1, CR_C, T_DIM, T_BG, P8(200));
            }
            if (sel < n - 1) {
                cr_kr_numbered(b, sizeof b, sel + 1, cr_item(s, sel + 1));
                cr_text_fit(P8(120), vb + P8(15), b, 12, 1, CR_C, T_DIM, T_BG, P8(200));
            }
            cr_pick_item(s, fr, sel, 27, 200, 0, vbase, vt, vb, col);
        } else if (n > 0) {
            int32_t bw = cr_tw(cr_item(s, sel), (uint32_t)size, 1);
            if (bw > P8(170)) bw = P8(170);
            cr_pick_sides(s, n, sel, base, 6, 234, (P8(228) - bw) / 2 - P8(10));
            cr_pick_item(s, fr, sel, size, 170, 1, base, top, top + bigh, col);
            cr_pick_marks(n, sel, marks, col);
        }
        if (s->value[0] && !s->kr_band) cr_text_fit(P8(120), P8(marks + 19), s->value, 13, 1, CR_C, col, T_BG, P8(224));
    }
    cr_kr_cells(s, ry, CR_KR_ROW);
}

/* CR_K_DRUM (the SEQ layer: the beat's preset and the drums' pages; the DRUMS plan's v3 mock-ups, design/drums-mockups):
 * the page band at the top (the page's name 26 px bold in its colour, the neighbours 13 px dim at the edges, the square
 * marks under it), the middle (rows CR_DR_TOP .. the row), knobrow's row of four knob cells (72 px). The middle:
 *   page 0  the preset: two tiles 84 x 76, Metronome (four beat bars) and Drums (the roundel), the chosen one lit in
 *           its colour (white / magenta) with a 3 px frame, the other dim
 *   page 1  Beat: Grids' 5 x 5 map (tiles 16 px, 4 apart; X to the right, Y up), the four around the dot tinted by their weight in
 *           the blend, the cross through the dot, the dot (a white ring on magenta); right of it the bar's three lanes
 *           (BD, SD, HH), a row a step from the top: a hit magenta, an accent white, a rest a dim tick; the step
 *           playing framed white across the three
 *   page 2..4  Kick, Snare, Hats: the drum's icon in a magenta roundel (r 34; the ring 3 px, 3 more at a hit's
 *           thump), its sound as a filled shape right of it: an attack edge as tall as Tune (the lowest half of it at -12,
 *           the whole at +12), falling over a length set by Decay; Character from smooth (soft) to striped (hard)
 *   page 5..7  Kick Mix, Snare Mix, Hats Mix (3y303): the drum's roundel, its Level the arc; its three sends as rings
 *           in the effects' colours on a wire from it (cr_dr_mix) */
#define CR_DR_TOP 64                     /* the middle's top row */
#define CR_MAG CR_RGB(224, 75, 216)
static void cr_dr_band(const cr_screen_t *s, const cr_frame_t *fr)
{
    int32_t n = s->n_items, sel = s->sel < n ? s->sel : n - 1, base = P8(CR_PY0 + 24), bw;
    uint16_t col = cr_rgb(s->col, T_TEXT);
    if (!cr_in_strip(CR_PY0, CR_DR_TOP) || n < 1) return;
    bw = cr_tw(cr_item(s, sel), 26, 1);
    if (bw > P8(150)) bw = P8(150);
    cr_pick_sides(s, n, sel, base + P8(2), 6, 234, (P8(228) - bw) / 2 - P8(10));
    cr_pick_item(s, fr, sel, 26, 150, 1, base, P8(CR_PY0), P8(CR_PY0 + 28), col);
    if (n > 1) cr_pick_marks(n, sel, CR_PY0 + 30, col);
}
/* the beat bars (Metronome's icon, the chip's blocks): n bars w x h at (x, y), gap g, bar lit - 1 white, the rest c */
static void cr_dr_bars(int32_t x, int32_t y, int32_t w, int32_t h, int32_t g, int32_t n, int32_t lit, uint16_t on,
                       uint16_t c)
{
    for (int32_t i = 0; i < n; i++)
        cr_fill(x + i * (w + g), y, w, h, i == lit - 1 ? on : c);
}
/* the drum roundel at (cx, cy) Q4, radius r Q4: the ring (w Q4) in c, a dot in the middle (dot: its radius, Q4) */
static void cr_dr_roundel(int32_t cx, int32_t cy, int32_t r, int32_t w, int32_t dot, uint16_t c, uint16_t dc)
{
    cr_arc(cx, cy, r, w, 0, 65536u, 0, 0, 0, c);
    if (dot) cr_disc(cx, cy, dot, dc);
}
static void cr_dr_tiles(const cr_screen_t *s)
{
    static const char *const NM[2] = {"Metronome", "Drums"};
    int32_t k, y = CR_DR_TOP + 10;
    for (k = 0; k < 2; k++) {
        int lit = s->dr_preset == (uint8_t)k, x = k ? 128 : 28;
        uint16_t c = lit ? (k ? CR_MAG : CR_WHITE) : T_DIM, fc = lit ? c : T_LINE;
        cr_box(x, y, 84, 82, fc, 6, lit ? 3 : 1);
        if (!k) cr_dr_bars(x + 21, y + 16, 8, 30, 6, 4, 1, lit ? CR_WHITE : T_DIM, lit ? T_MID : T_LINE);
        else cr_dr_roundel((x + 42) * 16, (y + 31) * 16, 15 * 16, 3 * 16, 7 * 16, c, c);
        cr_text(P8(x + 42), P8(y + 72), NM[k], 13, 1, CR_C, 4096, lit ? c : T_DIM, T_BG, 0);
    }
}
static void cr_dr_beat(const cr_screen_t *s)
{
    int32_t mx = 8, my = CR_DR_TOP + 2, i, j, d;
    int32_t fx = ((int32_t)s->dr_x << 2) & 255, fy = ((int32_t)s->dr_y << 2) & 255, ti = s->dr_x >> 6, tj = s->dr_y >> 6;
    int32_t dx = mx + 8 + (int32_t)s->dr_x * 80 / 256, dy = my + 8 + (255 - (int32_t)s->dr_y) * 80 / 256;
    int32_t n = s->dr_steps ? s->dr_steps : 32, rh = 96 / n, ly = my + (98 - rh * n) / 2;
    for (i = 0; i < 5; i++)                      /* the map: x across, y UP (Grids' drum_map[x][y]; the owner: "Map Y
                                                  * ... should go up when turning CW"): row j from the bottom */
        for (j = 0; j < 5; j++) {
            int32_t w = 0;
            if (i == ti && j == tj) w = (255 - fx) * (255 - fy);
            else if (i == ti + 1 && j == tj) w = fx * (255 - fy);
            else if (i == ti && j == tj + 1) w = (255 - fx) * fy;
            else if (i == ti + 1 && j == tj + 1) w = fx * fy;
            cr_box(mx + i * 20, my + (4 - j) * 20, 16, 16, w ? ux_mix(T_SURF, CR_MAG, w * 100 / 65025) : T_SURF, 2, 0);
        }
    cr_fill(mx, dy, 96, 1, T_MID);               /* the cross */
    cr_fill(dx, my, 1, 96, T_MID);
    cr_disc(dx * 16 + 8, dy * 16 + 8, 7 * 16, CR_WHITE);
    cr_disc(dx * 16 + 8, dy * 16 + 8, 5 * 16, CR_MAG);
    for (d = 0; d < 3; d++) {                    /* the lanes */
        int32_t x = 116 + d * 40;
        for (i = 0; i < n; i++) {
            uint32_t b = 1u << i;
            int32_t y = ly + i * rh;
            if (s->dr_acc[d] & b) cr_fill(x, y, 34, rh - 1, CR_WHITE);
            else if (s->dr_lane[d] & b) cr_fill(x, y, 34, rh - 1, CR_MAG);
            else cr_fill(x + 13, y, 8, rh - 1, T_SURF);
        }
    }
    if (s->dr_step && s->dr_step <= n) {         /* the step playing */
        int32_t y = ly + (s->dr_step - 1) * rh;
        cr_box(112, y - 2, 122, rh + 3, CR_WHITE, 0, 1);
    }
}
static void cr_dr_icon(uint32_t page, int32_t cx, int32_t cy, uint16_t c)
{
    if (page == 2u) {                            /* the kick: a target */
        cr_disc(cx, cy, 18 * 16, c);
        cr_disc(cx, cy, 9 * 16, T_BG);
        cr_disc(cx, cy, 4 * 16, c);
    } else if (page == 3u) {                     /* the snare: a drum seen from the side, its wires */
        cr_frect(cx - 18 * 16, cy - 10 * 16, 36 * 16, 20 * 16, c);
        cr_frect(cx - 18 * 16, cy - 3 * 16, 36 * 16, 2 * 16, T_BG);
        cr_frect(cx - 18 * 16, cy + 3 * 16, 36 * 16, 2 * 16, T_BG);
    } else {                                     /* the hats: two cymbals on a stand */
        cr_frect(cx - 19 * 16, cy - 7 * 16, 38 * 16, 5 * 16, c);
        cr_frect(cx - 19 * 16, cy + 2 * 16, 38 * 16, 5 * 16, c);
        cr_frect(cx - 2 * 16, cy - 18 * 16, 4 * 16, 36 * 16, c);
    }
}
static void cr_dr_drum(const cr_screen_t *s)
{
    int32_t cx = 46 * 16, cy = (CR_DR_TOP + 48) * 16, x0 = 92, base = CR_DR_TOP + 96, top = CR_DR_TOP + 6;
    int32_t h = (base - top) * (12 + (int32_t)s->dr_tune) / 36, len = 24 + (int32_t)s->dr_decay * 116 / 127, x;
    int32_t gap = s->dr_chr < 43 ? 0 : s->dr_chr < 86 ? 1 : 2, pul = s->dr_pulse;
    cr_dr_roundel(cx, cy, 34 * 16, (3 * 16) + pul * 48 / 255, 0, CR_MAG, CR_MAG);
    cr_dr_icon(s->dr_page, cx, cy, pul > 128 ? CR_MAG : CR_WHITE);
    cr_fill(x0, base, 236 - x0, 2, T_LINE);
    for (x = 0; x < len && x0 + x < 236; x++) {  /* the shape: (1 - t)^2 under the attack edge */
        int32_t t = (len - x) * 256 / len, v = h * t * t / 65536, y;
        if (!gap) {
            cr_fill(x0 + x, base - v, 1, v, CR_MAG);
            continue;
        }
        for (y = base; y > base - v; y -= 5) {   /* (hard: 5 px stripes, the top 1 or 2 px of each cut) */
            int32_t hh = 5 - gap;
            if (y - hh < base - v) hh = y - (base - v);
            cr_fill(x0 + x, y - hh, 1, hh, CR_MAG);
        }
    }
}
/* pages 5..7, Kick Mix, Snare Mix, Hats Mix (3y303, 3y304): each thing in the colour of what turns it. The drum's icon
 * in its roundel (r 34 at the left: the track dim, the Level green (KNOB 4) clockwise from 12 o'clock, as full as
 * Level / 127, so 64 as voiced is half; 3 px, 3 more at the drum's thump; the icon magenta at the hit); round it the
 * Drive (PRESETS, 3y305) as red spikes, longer and more ragged with more drive, flaring at a hit. A wire from it through a
 * white box, the Filter (ALGORITHM: the master filter's white; a low-pass curve, the box filled as much of the drum as
 * goes through it; dim while the master filter is Off or FX is), and its three sends: rings (r 18), Chorus blue (KNOB 1),
 * Delay orange (KNOB 2), Reverb white (KNOB 3), each as full as its send, its middle a disc on the wire that swells with
 * the send and at the hit by as much as the send carries it; the wire lights magenta at the hit. FX off: the rings grey.
 * Under the roundel the Drive's value, under the box the Filter's (13 px; the encoder just turned: underlined) */
static void cr_dr_mix(const cr_screen_t *s)
{
    static const uint8_t COL[3] = {CR_COL_BLUE, CR_COL_ORANGE, CR_COL_WHITE};
    int32_t k, cy = CR_DR_TOP + 42, pul = s->dr_pulse, drv = s->dr_drv, flt = s->dr_flt;
    int32_t cx = 46 * 16, w = 3 * 16 + pul * 48 / 255, fx0 = 83, fw = 30, fh = 30, fy = cy - fh / 2;
    uint32_t sw = (uint32_t)s->dr_lvl * 65536u / 127u;
    uint16_t fc = s->dr_fon ? CR_WHITE : T_DIM, dc = drv ? ux_mix(CR_RED, CR_WHITE, pul * 40 / 255) : T_DIM;
    char t[8];
    cr_fill(80, cy - 1, 132, 3, ux_mix(T_LINE, CR_MAG, pul * 100 / 255));   /* the wire, under the rings */
    if (drv)                                         /* the Drive: 20 spikes, 2 .. 11 px (+3 at a hit), ragged with it.
                                                      * Each a short line from r 38 (3y305: was an arc each, and an arc
                                                      * tests every pixel of its whole box, 76 px square: the page drew
                                                      * slowly, the owner saw it lag the knobs) */
        for (k = 0; k < 20; k++) {
            int32_t len = 2 * 16 + drv * 9 * 16 / 127 - (k * 7 % 5) * drv * 16 / 254 + pul * 3 * 16 / 255;
            uint32_t a = (uint32_t)k * 3277u + 1574u;    /* (the arc's middle: 1024 + 1100 / 2) */
            int32_t co = cr_cos(a), si = cr_sin(a), r0 = 38 * 16 + 16, r1 = 38 * 16 + len - 16;
            int16_t p[4];
            if (r1 < r0) r1 = r0;
            p[0] = (int16_t)(cx + ((r0 * co) >> 14)); p[1] = (int16_t)(cy * 16 + ((r0 * si) >> 14));
            p[2] = (int16_t)(cx + ((r1 * co) >> 14)); p[3] = (int16_t)(cy * 16 + ((r1 * si) >> 14));
            cr_poly(p, 2u, 3 * 16, 0, 0, dc);
        }
    cr_arc(cx, cy * 16, 34 * 16, 3 * 16, 0, 65536u, 0, 0, 0, T_SURF);
    if (sw) cr_arc(cx, cy * 16, 34 * 16, w, 49152u, sw >= 65536u ? 65535u : sw, 0, 0, 0, CR_NAMED[CR_COL_GREEN]);
    cr_dr_icon((uint32_t)s->dr_page - 3u, cx, cy * 16, pul > 128 ? CR_MAG : s->dr_lvl ? CR_WHITE : T_DIM);
    cr_fill(fx0, fy, fw, fh, T_BG);                  /* the Filter: its box on the wire */
    for (k = 0; k < fw - 6; k++) {                   /* a low-pass: flat, then falling past its corner (2/3 across) */
        int32_t x = fx0 + 3 + k, top = fy + 5 + (k > (fw - 6) * 2 / 3 ? (k - (fw - 6) * 2 / 3) * 2 : 0);
        int32_t bot = fy + fh - 3;
        if (top >= bot) continue;
        cr_fill(x, top, 1, bot - top, ux_mix(T_BG, fc, 15 + flt * 55 / 127));
        cr_fill(x, top, 1, 2, fc);
    }
    cr_box(fx0, fy, fw, fh, fc, 3, 2);
    for (k = 0; k < 3; k++) {
        int32_t x = (135 + k * 41) * 16, v = s->dr_fx[k], r;
        uint16_t c = s->dr_fxoff ? T_DIM : CR_NAMED[COL[k]];
        uint32_t a = (uint32_t)v * 65536u / 127u;
        cr_arc(x, cy * 16, 18 * 16, 4 * 16, 0, 65536u, 0, 0, 0, T_SURF);
        if (!v) continue;
        if (a) cr_arc(x, cy * 16, 18 * 16, 4 * 16 + (s->dr_fxoff ? 0 : pul * v * 32 / (255 * 127)), 49152u,
                      a >= 65536u ? 65535u : a, 0, 0, 0, c);
        r = 3 * 16 + v * 8 * 16 / 127 + (s->dr_fxoff ? 0 : pul * v * 4 * 16 / (255 * 127));
        cr_disc(x, cy * 16, r, c);
    }
    for (k = 0; k < 2; k++) {                        /* the values: the Drive under the roundel, the Filter under the box */
        int32_t v = k ? flt : drv, x = k ? fx0 + fw / 2 : 46, n = 0, p = (v * 100 + 63) / 127;
        uint16_t c = k ? fc : drv ? CR_RED : T_DIM;
        if (p >= 100) t[n++] = '1';
        if (p >= 10) t[n++] = (char)('0' + p / 10 % 10);
        t[n++] = (char)('0' + p % 10);
        t[n++] = '%';
        t[n] = 0;
        cr_text(P8(x), P8(cy + 58), t, 13, 1, CR_C, 4096, c, T_BG, 0);
        if (s->dr_enc == (uint8_t)(k ? 1 : 2))
            cr_fill(x - 14, cy + 61, 28, 2, c);
    }
}
static void cr_p_drum(const cr_screen_t *s, const cr_frame_t *fr)
{
    int32_t ry = cr_kr_rowy(s);
    cr_dr_band(s, fr);
    if (cr_in_strip(CR_DR_TOP, ry)) {
        if (s->dr_page == 0u) cr_dr_tiles(s);
        else if (s->dr_page == 1u) cr_dr_beat(s);
        else if (s->dr_page >= 5u) cr_dr_mix(s);
        else cr_dr_drum(s);
    }
    cr_kr_cells(s, ry, CR_KR_ROW);
}

/* CR_K_LOOPMENU (FORMAT.md "The looper's PLAY menu", docs/LOOPER-MODES.md): the looper's PLAY menu under the top line,
 * red: the slot strip (rows 28..54), the record mode as a horizontal picker band (56..92: the item 28 px bold squeezed
 * to 150, the neighbours 13 px dim, the marks), the middle (92 .. the knob row: the big text `title` with `sub` under
 * it, the record timeline or the step grid), knobrow's row of the four knobs (72 px; 64 over the `foot` line). */
#define CR_LM_TOP 92                     /* the middle's top row */
static int32_t cr_lm_rowy(const cr_screen_t *s) { return 240 - (s->foot[0] ? 14 + 64 : CR_KR_ROW); }
/* the timeline's strip: 200 x 40 at x 20, row sy (px) */
static int32_t cr_lm_tl_y(const cr_screen_t *s)
{
    int32_t h = cr_lm_rowy(s) - CR_LM_TOP, d = (h - 40 - (s->sub[0] ? 16 : 0)) / 2;
    return CR_LM_TOP + (d > 5 ? d : 5);
}
/* the step grid: 4 rows (lm_bars, at most 4) of 7 px, 2 apart, its top row gy (px); the grid is 34 px tall */
static int32_t cr_lm_rows(const cr_screen_t *s) { return s->lm_bars < 1u ? 1 : s->lm_bars > 4u ? 4 : (int32_t)s->lm_bars; }
static int32_t cr_lm_st_y(const cr_screen_t *s)
{
    int32_t h = cr_lm_rowy(s) - CR_LM_TOP, H = cr_lm_rows(s) * 9 - 2;
    return CR_LM_TOP + (h - H - ((s->sub[0] || s->value[0]) ? 18 : 0)) / 2;
}
/* the step grid's steps a bar (lm_beats: the Quantize grid, 0 = 16) and a step's left x (Q4) and width (Q4): 200 px
 * from x 20, 2 px apart, 2 px more between groups of four when the steps a bar are a multiple of four (> 4) */
static int32_t cr_lm_per(const cr_screen_t *s) { return s->lm_beats ? (s->lm_beats > 32u ? 32 : s->lm_beats) : 16; }
static int32_t cr_lm_grp(int32_t per) { return per > 4 && per % 4 == 0 ? 4 : 0; }
static int32_t cr_lm_cw(int32_t per)
{
    int32_t g = cr_lm_grp(per);
    return (200 * 16 - (per - 1) * 32 - (g ? (per / g - 1) * 32 : 0)) / per;
}
static int32_t cr_lm_st_x(int32_t per, int32_t c)
{
    int32_t g = cr_lm_grp(per);
    return 20 * 16 + c * (cr_lm_cw(per) + 32) + (g ? (c / g) * 32 : 0);
}

/* the slot strip: ten cells over x 6..234, bottom row 50; a slot holding a loop filled grey (its number in the
 * background colour), an empty one a 1.5 px outline (the number dim); the selected one red (filled, or a 2 px outline
 * when empty), 5 px taller, its number 13 px; lm_jump: the selection drawn at the target and a 2 px hop arrow under
 * the cells from lm_slot to it */
static void cr_lm_slots(const cr_screen_t *s, uint16_t col)
{
    int32_t sel = s->lm_jump ? s->lm_jump - 1 : s->lm_slot, i, bot = 50;
    if (!cr_in_strip(28, 56)) return;
    for (i = 0; i < 10; i++) {
        int on = i == sel, full = (s->lm_used >> i) & 1u;
        int32_t x16 = 96 + i * 3696 / 10, w16 = 321, top = on ? 29 : 34, cx = x16 * 16 + w16 * 8;   /* cx: Q8 */
        uint32_t npx = on ? 13u : 10u;
        char nb[3];
        nb[0] = (char)(i == 9 ? '1' : '1' + i);
        nb[1] = (char)(i == 9 ? '0' : 0);
        nb[2] = 0;
        if (full) {
            int32_t x0 = (x16 + 8) >> 4, x1 = (x16 + w16 + 8) >> 4;
            cv_rrect(x0, top, x1 - x0, bot - top, 2, on ? col : T_DIM, T_BG);
        } else {
            cr_srect(x16 + 16, top * 16 + 16, w16 - 32, (bot - top - 2) * 16, on ? 32 : 24, on ? col : T_LINE);
        }
        cr_text(cx, P8(top + bot) / 2 + (int32_t)npx * 92, nb, npx, 1, CR_C, 4096, full ? T_BG : on ? col : T_DIM,
                full ? (on ? col : T_DIM) : T_BG, 0);
        if (s->lm_dirty == i + 1)                    /* not saved yet: a 3 px square in the cell's top right corner */
            cr_frect((((x16 + w16 + 8) >> 4) - 6) * 16, (top + 3) * 16, 48, 48, full ? T_BG : on ? col : T_DIM);
    }
    if (s->lm_jump && s->lm_jump - 1 != s->lm_slot && s->lm_slot < 10u) {   /* the hop: down, along, up into the target */
        int32_t a = (96 + (int32_t)s->lm_slot * 3696 / 10) + 160, b = (96 + sel * 3696 / 10) + 160, y = bot * 16 + 40;
        int32_t l = a < b ? a : b, r = a < b ? b : a;
        cr_frect(a - 16, bot * 16 + 8, 32, 48, col);
        cr_frect(l - 16, y - 16, r - l + 32, 32, col);
        cr_tri(b - 48, bot * 16 + 32, b + 48, bot * 16 + 32, b, bot * 16 - 24, col);
    }
}

/* the record timeline (FORMAT.md `timeline`): a 200 x 40 strip of bar boxes (surface, a 1 px grey outline, 2 px apart)
 * with beat ticks at the top and bottom; the lanes' marks (3 px, a lane each; older lanes dimmer, the take's lane
 * bright); Replace's held span a dark band with an edge, the older marks in it struck; the playhead a 2 px line with a
 * triangle on top; lm_free: a bar a quarter of the strip, the last one only up to the playhead; `sub` under it */
static void cr_lm_timeline(const cr_screen_t *s, uint16_t col)
{
    int32_t sy = cr_lm_tl_y(s), sh = 40, nb = s->lm_bars ? s->lm_bars : 1, beats = s->lm_beats ? s->lm_beats : 4;
    int32_t bw = s->lm_free ? 800 : 3200 / nb, pos = s->lm_pos, end = s->lm_free ? pos : nb * 256, k, j, li;
    int32_t L = s->lm_nlane ? s->lm_nlane : 1, lh = (30 * 16) / L, mh = lh - 32 < 32 ? 32 : lh - 32;
    int er = s->lm_erase0 || s->lm_erase1;
    uint32_t c;
#define CR_LX(b8) (20 * 16 + (int32_t)(b8) * bw / 256)  /* a position in Q8 bars -> x (Q4) */
    if (!cr_in_strip(sy - 6, sy + sh + 20)) return;
    for (k = 0; k < nb; k++) {                       /* the bar boxes, the beat ticks */
        int32_t bx = CR_LX(k * 256) + 16, bwk = bw - 32, x0, x1;
        if (s->lm_free && k == nb - 1) {
            bwk = (pos - k * 256) * bw / 256 - 16;
            if (bwk < 32) bwk = 32;
        }
        x0 = bx >> 4;
        x1 = (bx + bwk + 8) >> 4;
        cv_rrect(x0, sy, x1 - x0, sh, 2, T_LINE, T_BG);
        cv_rrect(x0 + 1, sy + 1, x1 - x0 - 2, sh - 2, 1, T_SURF, T_LINE);
        if (bw / beats >= 64)
            for (j = 1; j < beats; j++) {
                int32_t tx = CR_LX(k * 256) + j * bw / beats;
                if (tx > bx + bwk) break;
                cr_frect(tx - 8, sy * 16, 16, 64, T_DIM);
                cr_frect(tx - 8, (sy + sh - 4) * 16, 16, 64, T_DIM);
            }
    }
    if (er) {                                        /* the held span */
        int32_t e0 = CR_LX(s->lm_erase0), e1 = CR_LX(s->lm_erase1 < end ? s->lm_erase1 : end);
        if (e1 > e0) cr_frect(e0, sy * 16 + 16, e1 - e0, (sh - 2) * 16, ux_mix(col, T_BG, 70));
        cr_frect(e0, sy * 16, 24, sh * 16, col);
    }
    for (li = 0; li < L && li < 4; li++) {           /* the marks */
        int fresh = s->lm_newlane == li + 1;
        int32_t age = L - 1 - li, my = (sy + 5) * 16 + li * lh + 16;
        uint16_t mc = fresh ? col : ux_mix(col, T_BG, age * 30 > 62 ? 62 : age * 30);
        for (c = 0; c < 64u; c++) {
            int32_t b8 = (int32_t)c * nb * 4, mx;
            int struck;
            if (!((s->lm_lane[li] >> c) & 1u) || b8 > end) continue;
            mx = CR_LX(b8);
            struck = er && !fresh && b8 >= s->lm_erase0 && b8 <= s->lm_erase1;
            cr_frect(mx - 24, my, 48, mh, struck ? T_DIM : mc);
            if (struck) {
                int16_t p[4] = {(int16_t)(mx - 64), (int16_t)my, (int16_t)(mx + 64), (int16_t)(my + mh)};
                int16_t q[4] = {(int16_t)(mx + 64), (int16_t)my, (int16_t)(mx - 64), (int16_t)(my + mh)};
                cr_poly(p, 2, 24, 0, 0, col);
                cr_poly(q, 2, 24, 0, 0, col);
            }
        }
    }
    {                                                /* the playhead */
        int32_t px = CR_LX(pos);
        cr_frect(px - 16, (sy - 2) * 16, 32, (sh + 4) * 16, col);
        cr_tri(px - 64, (sy - 5) * 16, px + 64, (sy - 5) * 16, px, sy * 16, col);
    }
    if (s->sub[0]) cr_text_fit(P8(120), P8(sy + sh + 15), s->sub, 13, 1, CR_C, T_MID, T_BG, P8(200));
#undef CR_LX
}

/* the step grid (FORMAT.md `steps`): a row per bar (four at most), sixteen steps across (2 px more every four), a
 * cell 7 px tall. A filled step (lm_lane[0]) is coloured by its velocity (lm_cell bits 0-3, cr_lm_cols: the role
 * colour `col` at the default 100, towards a dark plum when softer, towards a light peach when louder); the steps a
 * longer note still sounds in (lm_lane[1]) a dark red, the others grey; the step being played (CR_LM_PLAYED: the loop
 * editor's playhead) white when filled, light grey when not. On a cell, in this order: the strip (lm_cell's chance
 * under 100 % or a condition): its 3 right-hand px over the cell's full height, yellow dimmed towards the background
 * with the chance, blue when the step has a condition; the ratchet (lm_lane[3] / [4]): 2, 3 or 4 ticks, 1 x 2 px in
 * the background's colour, 2 px apart along the cell's top from its second px; the white LENGTH BAR, 2 px along the
 * bottom: on the cursor's cell lm_bar quarters of its width, and whole on the cells its note sounds on into
 * (lm_lane[2]): the selected step's alone. The cursor (lm_pos) a 2 px outline in `col` in a 1 px background ring; its
 * blink (CR_LM_CUR_OFF): not drawn, or with lm_ed (the loop editor) drawn dim, so the selected step is never
 * unmarked. `sub` (the step's chord) 15 px under the grid at the left, what follows a tab in it (the step's voicing)
 * blue after it; `value` 12 px grey at the right; lm_steps: the cells after that many are not drawn (the loop editor:
 * the loop ends there) */
#define CR_LM_SOFT CR_RGB(96, 40, 128)   /* the softest step */
#define CR_LM_HOT CR_RGB(255, 176, 120)  /* the loudest */
static struct {                          /* the grid's colours, mixed once per palette and role colour (no mixing per
                                          * cell or per frame): the 16 velocity levels; the strip's 8 chance levels,
                                          * yellow then blue */
    uint32_t gen;
    uint16_t col, ok, vel[16], strip[16];
} cr_lmc;
static void cr_lm_cols(uint16_t col)
{
    static const uint8_t PCT[8] = {100, 90, 75, 60, 50, 40, 25, 10};   /* (cr_loop.h CRL_CHANCE_PCT) */
    int32_t k;
    if (cr_lmc.ok && cr_lmc.gen == ux.gen && cr_lmc.col == col) return;
    cr_lmc.vel[0] = cr_lmc.vel[12] = col;
    for (k = 1; k < 12; k++) cr_lmc.vel[k] = ux_mix(CR_LM_SOFT, col, (k - 1) * 100 / 11);
    for (k = 13; k < 16; k++) cr_lmc.vel[k] = ux_mix(col, CR_LM_HOT, (k - 12) * 100 / 3);
    for (k = 0; k < 8; k++) {
        cr_lmc.strip[k] = ux_mix(T_BG, CR_YELLOW, PCT[k]);
        cr_lmc.strip[8 + k] = ux_mix(T_BG, CR_NAMED[CR_COL_BLUE], PCT[k]);
    }
    cr_lmc.gen = ux.gen; cr_lmc.col = col; cr_lmc.ok = 1;
}
static void cr_lm_steps(const cr_screen_t *s, uint16_t col)
{
    int32_t gy = cr_lm_st_y(s), rows = cr_lm_rows(s), per = cr_lm_per(s), cw = cr_lm_cw(per), r, c, H = rows * 9 - 2;
    int32_t ny = gy + H + 16;
    uint32_t cur = s->lm_pos & 63u, ph = CR_LM_PLAYED(s->lm_pos);
    int curon = !(s->lm_pos & CR_LM_CUR_OFF);
    uint16_t tail = ux_mix(col, T_BG, 62);
    if (cr_in_strip(gy - 4, gy + H + 4)) {
        cr_lm_cols(col);
        for (r = 0; r < rows; r++)
            for (c = 0; c < per; c++) {
                uint32_t st = (uint32_t)(r * per + c), cb, rat, k;
                int32_t xx = cr_lm_st_x(per, c), yy = (gy + r * 9) * 16;
                if (st > 63u || (s->lm_steps && st >= s->lm_steps)) break;
                int on = (int)((s->lm_lane[0] >> st) & 1u);
                cb = s->lm_cell[st];
                rat = (uint32_t)((s->lm_lane[3] >> st) & 1u) | (uint32_t)((s->lm_lane[4] >> st) & 1u) << 1;
                cr_frect(xx, yy, cw, 7 * 16, ph == st + 1u ? (on ? T_TEXT : T_MID)
                                             : on ? cr_lmc.vel[cb & 15u] : (s->lm_lane[1] >> st) & 1u ? tail : T_LINE);
                if (cb & 0xF0u) {                    /* the strip: whole px, to the cell's right edge */
                    int32_t x0 = (((xx + cw) >> 4) - 3) * 16;
                    cr_frect(x0, yy, xx + cw - x0, 7 * 16, cr_lmc.strip[((cb >> 4) & 7u) | (cb & CR_LMC_COND ? 8u : 0u)]);
                }
                for (k = 0; rat && k <= rat; k++)    /* the ratchet's ticks: x2 two, x3 three, x4 four */
                    cr_frect(((xx >> 4) + 1 + 2 * (int32_t)k) * 16, yy, 16, 2 * 16, T_BG);
                if ((s->lm_lane[2] >> st) & 1u) cr_frect(xx, yy + 5 * 16, cw, 2 * 16, T_TEXT);
                if (st == cur && s->lm_bar)          /* the bar begins ON the selected step (a part: to a whole px) */
                    cr_frect(xx, yy + 5 * 16, s->lm_bar >= 4u ? cw : (((xx + cw * s->lm_bar / 4 + 8) >> 4) << 4) - xx,
                             2 * 16, T_TEXT);
                if (st == cur && (curon || s->lm_ed)) {   /* (the steps after it cover its ring, as the designer's) */
                    cr_srect(xx - 48, yy - 48, cw + 96, 7 * 16 + 96, 16, T_BG);
                    cr_srect(xx - 24, yy - 24, cw + 48, 7 * 16 + 48, 32, curon ? col : ux_mix(col, T_BG, 50));
                }
            }
    }
    if (!cr_in_strip(ny - 16, ny + 4)) return;
    {
        int32_t rw = s->value[0] ? cr_tw(s->value, 12, 1) : 0, maxw = P8(200 - 8) - rw, vw = 0, g = P8(5), i;
        char nm[sizeof s->sub];
        const char *v = "";
        for (i = 0; s->sub[i] && s->sub[i] != '\t'; i++) nm[i] = s->sub[i];
        nm[i] = 0;
        if (s->sub[i] == '\t') v = s->sub + i + 1;
        if (s->value[0]) cr_text(P8(220), P8(ny), s->value, 12, 1, CR_R, 4096, T_MID, T_BG, 0);
        if (v[0]) {                                  /* the voicing keeps its room; a long name: the gaps give way
                                                      * (5 and 8 px to 3 and 3) before the name does */
            vw = cr_tw(v, 15, 1);
            if (cr_tw(nm, 15, 1) + g + vw > maxw) { g = P8(3); maxw += P8(5); }
            vw += g;
        }
        if (nm[0]) cr_text_fit(P8(20), P8(ny), nm, 15, 1, CR_L, T_TEXT, T_BG, maxw - vw);
        if (v[0]) {
            int32_t nw = cr_tw(nm, 15, 1);
            if (nw > maxw - vw) nw = maxw - vw;
            cr_text(P8(20) + nw + g, P8(ny), v, 15, 1, CR_L, 4096, CR_NAMED[CR_COL_BLUE], T_BG, 0);
        }
    }
}

/* the loop editor's playing name (lm_now; the owner, 2026-10-11: "show the name of the playing step chord/notes to the
 * left of the Page Name (don't offset the page name ...) in blue"): the role blue, left-aligned at x 6 on the picker
 * neighbours' baseline, CR_LM_NOW_W px wide at most: the page name ("Step", the wider of the two, 60 px centred on 120)
 * begins at x 90, so 6 px stay clear whatever the name. Bold, the largest of 13 / 11 / 10 px that fits: 13 for most
 * ("D#sus JAZZ" 74 px), 10 for the longest ("G#madd4 JAZZ" 73 px; 95 at 13). Its rows (67 .. 77) are inside one strip */
#define CR_LM_NOW_W 78
static void cr_lm_now(const cr_screen_t *s, int32_t base)
{
    static const uint8_t PX[3] = {13, 11, 10};
    int32_t k = 0;
    while (k < 2 && cr_tw(s->lm_now, PX[k], 1) > P8(CR_LM_NOW_W)) k++;
    cr_text_fit(P8(6), base - P8(4), s->lm_now, PX[k], 1, CR_L, CR_NAMED[CR_COL_BLUE], T_BG, P8(CR_LM_NOW_W));
}

static void cr_p_loopmenu(const cr_screen_t *s, const cr_frame_t *fr)
{
    int32_t n = s->n_items, sel = s->sel < n ? s->sel : n - 1, ry = cr_lm_rowy(s), size = 28;
    int32_t base = P8(56 + 2) + size * 200;          /* (0.78 of the size) */
    uint16_t red = CR_RED, col = cr_rgb(s->col, CR_WHITE);
    cr_lm_slots(s, red);
    if (n > 0 && cr_in_strip(56, 92)) {              /* the record mode */
        int32_t bw = cr_tw(cr_item(s, sel), (uint32_t)size, 1);
        int now = s->lm_now[0] && !(fr->slide && s->slide);   /* (a page sliding in crosses the name's place: 160 ms
                                                               * without it) */
        if (bw > P8(150)) bw = P8(150);
        if (now) cr_lm_now(s, base + P8(1));
        cr_pick_sides(s, n, sel, base + P8(1), s->lm_now[0] ? -1 : 6, 234, (P8(228) - bw) / 2 - P8(10));
        cr_pick_item(s, fr, sel, size, 150, 1, base, P8(56), P8(56) + size * 282, col);
        if (n > 1) cr_pick_marks(n, sel, 56 + 36 - 6, col);
    }
    if (s->lm_mid == CR_LM_TIMELINE) {
        cr_lm_timeline(s, red);
    } else if (s->lm_mid == CR_LM_STEPS) {
        cr_lm_steps(s, red);
    } else if (cr_in_strip(CR_LM_TOP, ry)) {         /* a big text, `sub` under it */
        int32_t h = ry - CR_LM_TOP, subh = s->sub[0] ? 18 : 0, sz = ((h - subh) * 6 + 5) / 10, w, sq;
        int32_t by;
        sz = sz > 40 ? 40 : sz < 14 ? 14 : sz;
        by = P8(CR_LM_TOP) + P8(h - subh) / 2 + sz * 92;
        if (s->title[0]) {
            w = cr_tw(s->title, (uint32_t)sz, 1);
            sq = w > P8(224) ? (P8(224) << 12) / w : 4096;
            cr_text(P8(120), by, s->title, (uint32_t)sz, 1, CR_C, sq, cr_rgb(s->title_col, red), T_BG, 0);
        }
        if (s->sub[0]) cr_text_fit(P8(120), by + P8(18), s->sub, 12, 1, CR_C, T_MID, T_BG, P8(224));
    }
    cr_kr_cells(s, ry, s->foot[0] ? 64 : CR_KR_ROW);
    if (s->foot[0] && cr_in_strip(226, 240)) cr_text_fit(P8(120), P8(237), s->foot, 11, 0, CR_C, T_MID, T_BG, P8(228));
}

/* CR_K_ROUTE (CR_SCREENS.md "The Routing page"; the FX layer's ninth page, GitHub issue 21's second design): the
 * signal flow as boxes, after FIZZ's MidiFX rail (FMToneSeq core/ui/ui_mfx.c: a held slot lifted over its place,
 * the others making room, arrows either side while it can move, landing on release) in cr_draw's shapes. `label`
 * 12 px bold mid at the top left, `title` ("Routing") 15 px bold green at the right. The wires are 2 px FX green
 * with arrowheads, "in" / "out" 12 px bold green at their ends. A block is a rounded box filled with its colour
 * (Chorus blue with white ink, Delay orange, Reverb yellow, Filter white with black), its name bold; the Filter Off:
 * hollow (its colour's 2 px rim, the name in it); FX off: every box hollow and every wire grey.
 * Chain: the four boxes in a row (48 x 64, 10 px apart, rows 86 .. 150, the wire through their middles at 118),
 * each its place 1 .. 4 at 22 px over its name at 13. Parallel: the three effects stacked (92 x 32 at x 30, rows
 * 62 .. 174), the wire fanning into them from "in" and out of them into the sum (a disc with a +), then the Filter
 * (52 x 44) and "out"; the Filter first (rt_order[0]): in, the Filter at x 14, then the fan, the stack, the sum
 * 62 px further right, and out (a move between the two places slides it all). A held block (rt_held) rises
 * CR_RT_LIFT px (Parallel: CR_RT_LIFT_P) over a grey shadow bar at its place, ringed white (the Filter: green),
 * white arrowheads either side where it can still move (Chain; Parallel: the Filter alone, toward its other place);
 * while a move slides (CR_A_SLIDE) every block eases from its rt_from place to its rt_order one; rt_drop lands
 * (CR_A_LIFT). No knob row: the black keys and KNOB 1 are the gesture, the footer says so */
#define CR_RT_LY 118                     /* the wire's row (Chain; Parallel: the sum's) */
#define CR_RT_BW 48                      /* Chain: a box */
#define CR_RT_BH 64
#define CR_RT_GAP 10
#define CR_RT_X0 ((240 - 4 * CR_RT_BW - 3 * CR_RT_GAP) / 2)
#define CR_RT_BY (CR_RT_LY - CR_RT_BH / 2)
#define CR_RT_LIFT 10                    /* px a held block rises (Chain) */
#define CR_RT_LIFT_P 5                   /* .. (Parallel: the stack's gap is 8) */
#define CR_RT_PX 30                      /* Parallel: the stack */
#define CR_RT_PW 92
#define CR_RT_PH 32
#define CR_RT_PP 40                      /* .. a box's pitch */
#define CR_RT_FX 166                     /* .. the Filter's box */
#define CR_RT_FW 52
#define CR_RT_FH 44
#define CR_RT_FX0 14                     /* .. the Filter before the buses: its box, the rest shifted right */
#define CR_RT_SHIFT 62
static const char *const CR_RT_NAME[4] = {"Chorus", "Delay", "Reverb", "Filter"};
static const uint8_t CR_RT_COL[4] = {CR_COL_BLUE, CR_COL_ORANGE, CR_COL_YELLOW, CR_COL_WHITE};
/* bold s centred at cx on baseline y (Q8), squeezed to maxw px where wider */
static void cr_rt_text(int32_t cx, int32_t y, const char *s, uint32_t px, int32_t maxw, uint16_t fg, uint16_t under,
                       uint32_t fl)
{
    int32_t w = cr_tw(s, px, 1);
    cr_text(cx, y, s, px, 1, CR_C, w > P8(maxw) ? (P8(maxw) << 12) / w : 4096, fg, under, fl);
}
/* a right-pointing arrowhead, its tip at (x, y) px, 6 px long, 5 px either side */
static void cr_rt_arrow(int32_t x, int32_t y, int32_t dir, uint16_t c)
{
    cr_tri(x * 16 + 8, y * 16, (x - 6 * dir) * 16 + 8, (y - 5) * 16, (x - 6 * dir) * 16 + 8, (y + 5) * 16, c);
}
/* block b's box at (x, y) w x h; num: its place 1 .. 4 over the name (0: the name alone, npx its size); ring: held;
 * moving: on its way (its texts sliding: 32, as a picker's, the lint lets them cross) */
static void cr_rt_box(const cr_screen_t *s, uint32_t b, int32_t x, int32_t y, int32_t w, int32_t h, int32_t num,
                      uint32_t npx, int ring, int moving)
{
    uint32_t fl = moving ? 32u : 0u;
    int solid = s->rt_fx_on && (b != 3u || s->rt_filter_on);
    uint16_t c = s->rt_fx_on ? CR_NAMED[CR_RT_COL[b & 3u]] : T_DIM, under = T_BG, ink;
    int32_t cx = P8(x) + P8(w) / 2, ty = num ? P8(y + h - 12) : P8(y + h / 2) + (int32_t)npx * 92;
    if (ring) {
        under = b == 3u ? CR_NAMED[CR_COL_GREEN] : CR_WHITE;
        cv_rrect(x - 3, y - 3, w + 6, h + 6, 8, under, T_BG);
    }
    cv_rrect(x, y, w, h, 6, c, under);
    if (solid) {
        ink = b == 0u ? CR_WHITE : CR_NAMED[CR_COL_BLACK];
        under = c;
    } else {                                         /* hollow: the rim, the inside the background */
        cv_rrect(x + 2, y + 2, w - 4, h - 4, 4, T_BG, c);
        ink = c;
        under = T_BG;
    }
    if (num) {
        char n[2] = {(char)('0' + num), 0};
        cr_text(cx, P8(y + 30), n, 22, 1, CR_C, 4096, ink, under, fl);
    }
    cr_rt_text(cx, ty, CR_RT_NAME[b & 3u], npx, w - 6, ink, under, fl);
}
/* block b's place in o (0 .. 3); Parallel's stack (eff): among the three effects only */
static int32_t cr_rt_pos(const uint8_t *o, uint32_t b, int eff)
{
    int32_t k, n = 0;
    for (k = 0; k < 4; k++) {
        if (o[k] == b) return n;
        if (!eff || o[k] != 3u) n++;
    }
    return 0;
}
static void cr_p_route(const cr_screen_t *s, const cr_frame_t *fr)
{
    uint16_t g = s->rt_fx_on ? CR_NAMED[CR_COL_GREEN] : T_DIM;
    int32_t held = s->rt_held ? (int32_t)s->rt_held - 1 : -1, drop = s->rt_drop ? (int32_t)s->rt_drop - 1 : -1;
    int32_t up = held >= 0 ? fr->lift : drop >= 0 ? 4096 - fr->lift : 0, k;   /* Q12 of the lift */
    uint32_t b;
    if (s->label[0]) cr_text_fit(P8(8), P8(CR_PY0 + 16), s->label, 12, 1, CR_L, T_MID, T_BG, P8(150));
    if (s->title[0]) cr_text(P8(232), P8(CR_PY0 + 17), s->title, 15, 1, CR_R, 4096, g, T_BG, 0);
    if (s->rt_mode) {                                /* Chain: in, the four in a row, out */
        int32_t lb = held >= 0 ? held : drop, lx = 0, ly = 0, lm = 0;
        cr_fill(0, CR_RT_LY - 1, 240, 2, g);
        cr_disc(4 * 16, CR_RT_LY * 16, 3 * 16, g);
        for (k = 1; k < 4; k++)
            cr_rt_arrow(CR_RT_X0 + k * (CR_RT_BW + CR_RT_GAP) - 2, CR_RT_LY, 1, g);
        cr_rt_arrow(238, CR_RT_LY, 1, g);
        cr_text(P8(2), P8(168), "in", 12, 1, CR_L, 4096, g, T_BG, 0);
        cr_text(P8(238), P8(168), "out", 12, 1, CR_R, 4096, g, T_BG, 0);
        for (b = 0; b < 4u; b++) {                   /* (the lifted one last: over its neighbours' gaps) */
            int32_t pt = cr_rt_pos(s->rt_order, b, 0), pf = cr_rt_pos(s->rt_from, b, 0);
            int32_t xt = P8(CR_RT_X0 + pt * (CR_RT_BW + CR_RT_GAP)), xf = P8(CR_RT_X0 + pf * (CR_RT_BW + CR_RT_GAP));
            int32_t x = (xt + (((xf - xt) * fr->slide) >> 12) + 128) >> 8;
            if ((int32_t)b == lb) {
                lx = x;
                lm = fr->slide && pt != pf;
                ly = CR_RT_BY - ((CR_RT_LIFT * up + 2048) >> 12);
                if (up > 400) cr_fill(x + 4, CR_RT_BY + CR_RT_BH + 3, CR_RT_BW - 8, 3, T_LINE);   /* its shadow */
                continue;
            }
            cr_rt_box(s, b, x, CR_RT_BY, CR_RT_BW, CR_RT_BH, pt + 1, 13, 0, fr->slide && pt != pf);
        }
        if (lb >= 0) {
            int32_t pt = cr_rt_pos(s->rt_order, (uint32_t)lb, 0);
            cr_rt_box(s, (uint32_t)lb, lx, ly, CR_RT_BW, CR_RT_BH, pt + 1, 13, held >= 0 && up > 2048, lm);
            if (held >= 0 && up > 2048) {            /* where it can still go: white arrowheads in the gaps */
                if (pt > 0) cr_rt_arrow(lx - 6, ly + 16, -1, CR_WHITE);
                if (pt < 3) cr_rt_arrow(lx + CR_RT_BW + 5, ly + 16, 1, CR_WHITE);
            }
        }
    } else {                                         /* Parallel: the buses stacked into the sum, the Filter after
                                                      * the sum or (rt_order[0] the Filter) before the fan */
        int32_t y0 = CR_RT_LY - CR_RT_PP - CR_RT_PH / 2, lb = held >= 0 ? held : drop;
        int32_t ft = s->rt_order[0] == 3u ? 4096 : 0, ff = s->rt_from[0] == 3u ? 4096 : 0;
        int32_t f = ft + (((ff - ft) * fr->slide) >> 12);   /* Q12: 0 the Filter after, 4096 before */
        int32_t dx = (CR_RT_SHIFT * f + 2048) >> 12;        /* the fan, the stack, the sum shift right by this */
        int32_t fx = CR_RT_FX + (((CR_RT_FX0 - CR_RT_FX) * f) >> 12), fan = 13 + dx, px = CR_RT_PX + dx;
        int32_t rx = 135 + dx, sx = 146 + dx, fmove = fr->slide && ft != ff;
        cr_fill(0, CR_RT_LY - 1, 240, 2, g);         /* the row: in .. out, the boxes over it */
        cr_fill(fan, CR_RT_LY - CR_RT_PP - 1, 2, 2 * CR_RT_PP + 2, g);   /* the fan */
        cr_fill(rx, CR_RT_LY - CR_RT_PP - 1, 2, 2 * CR_RT_PP + 2, g);    /* the buses' returns, the sum */
        for (k = 0; k < 3; k++) {
            int32_t my = CR_RT_LY + (k - 1) * CR_RT_PP;
            cr_fill(fan + 1, my - 1, px - fan - 2, 2, g);
            cr_rt_arrow(px - 1, my, 1, g);
            cr_fill(px + CR_RT_PW, my - 1, rx + 1 - px - CR_RT_PW, 2, g);
        }
        cr_rt_arrow(fx - 1, CR_RT_LY, 1, g);
        cr_disc(sx * 16, CR_RT_LY * 16, 10 * 16, g);
        cr_fill(sx - 5, CR_RT_LY - 1, 10, 2, T_BG);   /* the sum's + */
        cr_fill(sx - 1, CR_RT_LY - 5, 2, 10, T_BG);
        cr_rt_arrow(238, CR_RT_LY, 1, g);
        cr_text(P8(1), P8(CR_RT_LY - 10), "in", 12, 1, CR_L, 4096, g, T_BG, 0);
        cr_text(P8(238), P8(CR_RT_LY - 10), "out", 12, 1, CR_R, 4096, g, T_BG, 0);
        for (b = 0; b < 4u; b++) {                   /* (the Filter last: over the stack while it crosses) */
            int32_t yo = (int32_t)b == lb ? (CR_RT_LIFT_P * up + 2048) >> 12 : 0;
            int ring = held == (int32_t)b && up > 2048;
            if (b == 3u) {
                int32_t fy = CR_RT_LY - CR_RT_FH / 2 - yo;
                cr_rt_box(s, b, fx, fy, CR_RT_FW, CR_RT_FH, 0, 15, ring, fmove);
                if (ring && !fmove) {                /* where it can go: the other place */
                    if (ft) cr_rt_arrow(fx + CR_RT_FW + 7, fy + CR_RT_FH / 2, 1, CR_WHITE);
                    else cr_rt_arrow(fx - 8, fy + CR_RT_FH / 2, -1, CR_WHITE);
                }
                continue;
            }
            {
                int32_t pt = cr_rt_pos(s->rt_order, b, 1), pf = cr_rt_pos(s->rt_from, b, 1);
                int32_t yt = P8(y0 + pt * CR_RT_PP), yf = P8(y0 + pf * CR_RT_PP);
                int32_t y = (yt + (((yf - yt) * fr->slide) >> 12) + 128) >> 8;
                cr_rt_box(s, b, px, y - yo, CR_RT_PW, CR_RT_PH, 0, 16, ring, (fr->slide && pt != pf) || fmove);
            }
        }
    }
}

/* Geek Out's name is centred on x 70: 132 px is what stays on the screen there (x 4 .. 136; the notes' column
 * begins past x 200). The longest names ("G#m add4 JAZZ" 154 px at 40 px, Standard's "G#m add9add4") squeeze to it
 * as the other views' squeeze to 224; a name up to 132 px wide is drawn as before */
#define CR_GEEK_NAME_W 132
static void cr_p_geek(const cr_screen_t *s, int32_t ph)
{
    uint32_t i;
    cr_name(&s->name, P8(70), P8(CR_PY0 + 56), 40, CR_GEEK_NAME_W, 4096);
    for (i = 0; i < s->n_notes; i++)
        cr_text(P8(230), P8(CR_PY0 + 30 + 14 * (int32_t)i), s->note[i].t, 12, 1, CR_R, 4096,
                cr_rgb(s->note[i].col, CR_WHITE), T_BG, 0);
    for (i = 0; i < s->n_lines && i < 6u; i++)    /* (the third: the audio ISR's load; the fourth: the second core;
                                                   * the fifth: the ISR's stages, cr_ui.c) */
        cr_text_fit(P8(10), P8(CR_PY0 + 72 + 11 * (int32_t)i), s->lines[i].t, 10, 0, CR_L, T_MID, T_BG, P8(150));
    cr_keyboard(s, CR_PY0 + ph - 30, 26);
}

static void cr_p_text(const cr_screen_t *s)
{
    int32_t y = CR_PY0 + 16, yy;
    uint32_t i;
    if (s->title[0]) {
        cr_text(P8(10), P8(y), s->title, 15, 1, CR_L, 4096, cr_rgb(s->title_col, CR_RED), T_BG, 0);
        y += 8;
    }
    yy = y + 14;
    for (i = 0; i < s->n_lines; i++) {
        const cr_line_t *l = &s->lines[i];
        uint32_t px = l->px ? l->px : 12u;
        yy += (int32_t)px - 12;
        if (l->cur)                       /* the name being typed is never cut (the cursor may be anywhere in it): a
                                           * long one is set smaller, on the same baseline (12 wide letters: 22 px) */
            while (px > 16u && cr_tw(l->t, px, l->bold) > P8(200))
                px -= 2u;
        if (l->t[0])
            cr_text_fit(P8(l->center ? 120 : 10), P8(yy), l->t, px, l->bold, l->center ? CR_C : CR_L,
                        cr_rgb(l->col, CR_WHITE), T_BG, P8(220));
        if (l->cur && !l->center) {       /* the naming cursor: a 3 px bar under the character, 4 px below the baseline */
            char c[32];
            uint32_t k;
            int32_t x, w;
            for (k = 0; k + 1u < l->cur && k + 1u < sizeof c && l->t[k]; k++)
                c[k] = l->t[k];
            c[k] = 0;
            x = P8(10) + cr_tw(c, px, l->bold);
            c[0] = l->t[k] && l->t[k] != ' ' ? l->t[k] : 'n';   /* (a space, the place after the last: a letter's width) */
            c[1] = 0;
            w = cr_tw(c, px, l->bold);
            if (x + w <= P8(236))
                cr_frect(x >> 4, (yy + 4) * 16, w >> 4, 3 * 16, cr_rgb(s->title_col, CR_RED));
        }
        yy += 16;
    }
}

static void cr_p_big(const cr_screen_t *s, int32_t ph)
{
    uint32_t size = s->size ? s->size : 118u;
    int32_t vy = P8(CR_PY0) + P8(ph) / 2 + (int32_t)(size * 87u) - P8(s->sub[0] ? 12 : 4), w = cr_tw(s->value, size, 1);
    int32_t sx = w > P8(228) ? ((P8(228) << 12) / w) : 4096;
    int32_t lift = s->ring_on ? 22 : 0;  /* the ring's band: the lines under the value stay inside it */
    uint16_t under = s->block ? cr_rgb(s->block, CR_RED) : T_BG;
    if (s->block) cr_fill(0, CR_PY0, 240, ph, under);
    cr_text(P8(120), vy - P8(lift / 2), s->value, size, 1, CR_C, sx, s->block ? T_BG : cr_rgb(s->col, CR_WHITE), under, 0);
    if (s->sub[0]) cr_text(P8(120), P8(CR_PY0 + ph - 26 - lift), s->sub, 15, 1, CR_C, 4096, s->block ? T_BG : T_TEXT, under, 0);
    if (s->label[0]) cr_text(P8(120), P8(CR_PY0 + ph - 8 - lift), s->label, 14, 0, CR_C, 4096, s->block ? T_BG : T_MID, under, 0);
    if (s->title[0]) cr_text(P8(10), P8(CR_PY0 + 14), s->title, 12, 1, CR_L, 4096, T_MID, under, 0);
}

/* the scope: the master output as one bold line (3 px, white) over a thin grey centre line. Cheap: a column at a
 * time, the span the polyline covers within a pixel either side (its neighbours' samples) +- 1.5 px, one
 * fractional rectangle per column, only for the columns crossing the strip's rows */
static void cr_p_scope(const cr_screen_t *s, int32_t ph)
{
    int32_t cy = (CR_PY0 + ph / 2) * 16 + 8, amp = (ph / 2 - 6) * 16, r0 = cr_row0() * 16, r1 = cr_row1() * 16, x;
    int32_t prev, cur, next;
    cr_fill(0, CR_PY0 + ph / 2, 240, 1, CR_NAMED[CR_COL_GREY]);
    cur = cy - s->wave[0] * amp / 127;
    prev = cur;
    for (x = 0; x < (int32_t)CR_WAVE_N; x++) {
        int32_t lo, hi;
        next = x + 1 < (int32_t)CR_WAVE_N ? cy - s->wave[x + 1] * amp / 127 : cur;
        lo = cur < prev ? cur : prev;
        lo = next < lo ? next : lo;
        hi = cur > prev ? cur : prev;
        hi = next > hi ? next : hi;
        lo -= 24;
        hi += 24;
        if (hi > r0 && lo < r1)
            cr_frect(x * 16, lo, 16, hi - lo, cr_rgb(s->col, CR_WHITE));
        prev = cur;
        cur = next;
    }
}

/* ------------------------------------------------------------ ring --- */
/* Orchid's ring: a dotted circle round the edge (cr_arc width 5, dash 2 of 6 at R 113, T_LINE) and the progress
 * over it (the same band solid, clockwise from 12 o'clock). cr_ui.c sets it only where the loop is the whole screen
 * (the count-in, the undo screen) and for calibration; every other loop state is the corner dial (cr_dial: playing,
 * armed, recording, overdubbing). Only its colour and fraction change, so the coverage
 * of every pixel of the band is computed once (cr_arc_px, the first time a ring is drawn) into the POOL: per row up
 * to two runs of pixels, a byte a pixel (the solid band's and the dotted circle's sample counts, d <= s, as one
 * index of the 153 pairs). A frame blends the runs of its rows from the table; the progress is decided per run
 * from its end pixels' angles (the angle is monotonic along a row): the runs well inside or outside the sweep take
 * the band's coverage or none, and only the pixels within 64 / 65536 turn of its start or tip (more than a sample's
 * angle can differ from its pixel's) take cr_arc_px's samples. The pixels are cr_arc's (tests/run_cr_draw.sh). */
#define CR_RING_C (120 * 16)
#define CR_RING_R (113 * 16)
#define CR_RING_W (5 * 16)
#define CR_RING_TOP 49152u                /* 12 o'clock */
#define CR_RING_MAX 4352u                 /* the band's pixels (4 232: tests/cr_draw_test.c) */
typedef struct {
    uint16_t off[241];                    /* row j's pixels: cov[off[j] .. off[j + 1]) */
    uint8_t x0[240][2], n[240][2];        /* its runs */
    uint8_t ps[153], pd[153];             /* a pair's solid and dotted sample counts */
    uint8_t cov[CR_RING_MAX];
} cr_ring_t;
/* in flash (XIP), not POOL: firmware/src/cr_ring_table.h, generated by tests/cr_draw_test.c (cr_ring_build;
 * sh tests/run_cr_draw.sh checks it and rewrites it with CR_RING_GEN=1) */
static const cr_ring_t cr_ring = {
#include "cr_ring_table.h"
};

/* the progress over a run of row j from x0 to x1: 0 none, 1 the band's coverage, 2 pixel by pixel */
static int cr_ring_run(int32_t j, int32_t x0, int32_t x1, uint32_t sweep)
{
    int32_t pdy = j * 16 + 8 - CR_RING_C, rf, e, lo, hi;
    uint32_t af, al;
    if (sweep >= 65536u) return 1;
    af = cr_atan2(pdy, x0 * 16 + 8 - CR_RING_C);
    al = cr_atan2(pdy, x1 * 16 + 8 - CR_RING_C);
    rf = (int32_t)((af - CR_RING_TOP) & 65535u);
    e = rf + (int16_t)(uint16_t)(al - af);  /* the run spans under half a turn */
    if (e < 0 || e > 65535) return 2;     /* across 12 o'clock */
    lo = rf < e ? rf : e;
    hi = rf < e ? e : rf;
    if (lo >= 96 && hi + 96 <= (int32_t)sweep) return 1;
    if (lo > (int32_t)sweep + 96 && hi < 65536 - 96) return 0;
    return 2;
}

static void cr_ring_draw(const cr_screen_t *s)
{
    uint16_t lc = T_LINE, pc = s->ring_rec ? T_REC : cr_rgb(s->ring_col, CR_RED);
    uint32_t sweep = !s->ring ? 0u : s->ring >= 256u ? 65536u : (uint32_t)s->ring << 8;
    int32_t j, r0 = cr_row0(), r1 = cr_row1();
    cr_arcg_t gp;
    if (sweep) cr_arc_geom(&gp, CR_RING_C, CR_RING_C, CR_RING_R, CR_RING_W, CR_RING_TOP, sweep, 0, 0, 0);
    for (j = r0; j < r1; j++) {
        uint16_t *row = cv_px + (uint32_t)(j + cv_oy) * cv_w;
        const uint8_t *cv = cr_ring.cov + cr_ring.off[j];
        uint32_t h;
        for (h = 0; h < 2u && cr_ring.n[j][h]; h++) {
            int32_t x0 = cr_ring.x0[j][h], x1 = x0 + cr_ring.n[j][h], i;
            int mode = sweep ? cr_ring_run(j, x0, x1 - 1, sweep) : 0;
            for (i = x0; i < x1; i++) {
                uint32_t q = *cv++, n = 0;
                if (i < cr_clip.x0 || i >= cr_clip.x1) continue;
                if (mode == 1) n = cr_ring.ps[q];
                else if (mode == 2) {
                    uint32_t rel = (cr_atan2(j * 16 + 8 - CR_RING_C, i * 16 + 8 - CR_RING_C) - CR_RING_TOP) & 65535u;
                    if (rel >= 64u && rel + 64u <= sweep) n = cr_ring.ps[q];
                    else if (!(rel > sweep + 64u && rel < 65536u - 64u)) n = cr_arc_px(&gp, i, j);
                }
                if (n >= 16u) {
                    row[i] = swap16(pc);
                    continue;
                }
                if (cr_ring.pd[q]) cr_mix(row + i, lc, cr_ring.pd[q] * 16u);
                if (n) cr_mix(row + i, pc, n * 16u);
            }
        }
    }
}

/* the whole screen into the canvas (its rows only) */
static void cr_compose(const cr_screen_t *s, const cr_frame_t *fr)
{
    int32_t ph = cr_ph(s);
    cr_header(s);
    switch (s->kind) {
    case CR_K_STRIPES: cr_p_stripes(s, fr, ph); break;
    case CR_K_CHORD: cr_p_chord(s, fr, ph); break;
    case CR_K_PICKER: cr_p_picker(s, fr, ph); break;
    case CR_K_METER: cr_p_meter(s, fr, ph); break;
    case CR_K_KEYBOARD: cr_p_keyboard(s, ph); break;
    case CR_K_ARP: cr_p_arp(s, ph); break;
    case CR_K_EDIT8: cr_p_edit8(s); break;
    case CR_K_STACK: cr_p_stack(s); break;
    case CR_K_KNOBROW: cr_p_knobrow(s, fr, ph); break;
    case CR_K_LOOPMENU: cr_p_loopmenu(s, fr); break;
    case CR_K_ROUTE: cr_p_route(s, fr); break;
    case CR_K_DRUM: cr_p_drum(s, fr); break;
#if CR_LAY_FREE
    case CR_K_FREE: cr_p_free(s); break;
#endif
    case CR_K_GEEK: cr_p_geek(s, ph); break;
    case CR_K_TEXT: cr_p_text(s); break;
    case CR_K_BIG: cr_p_big(s, ph); break;
    case CR_K_SCOPE: cr_p_scope(s, ph); break;
    default: break;
    }
    if (s->footer[0]) {
        char b[48];
        int cut = cr_fit(b, sizeof b, s->footer, 12, 0, P8(224));
        cr_text(P8(120), P8(226), b, 12, 0, CR_C, 4096, T_MID, T_BG, cut ? 9u : 0u);
    }
    if (s->ring_on)                      /* Orchid's ring: a dotted circle round the edge, the progress solid */
        cr_ring_draw(s);
    if (s->message[0]) {                 /* a transient message box over the panel */
        int32_t w = (cr_tw(s->message, 16, 1) >> 8) + 28;
        uint16_t c = cr_rgb(s->message_col, CR_WHITE);
        if (w > 228) w = 228;
        cv_rrect(120 - w / 2, 100, w, 40, 8, c, T_BG);
        cr_text(P8(120), P8(125), s->message, 16, 1, CR_C, 4096, T_BG, c, 0);
    }
}

/* ------------------------------------------------------------ cache --- */
#define CR_STRIP_H 40u
#define CR_NSTRIP (240u / CR_STRIP_H)
#define CR_TILE_W 60u                     /* a strip's change tiles: 4 x 5 of 60 x 8 px, hashed; a blit sends the box */
#define CR_TILE_H 8u                      /* .. of the tiles whose pixels changed */
#define CR_NTX (240u / CR_TILE_W)
#define CR_NTY (CR_STRIP_H / CR_TILE_H)
static struct {
    uint32_t sig, base;                  /* base: the signature without the ring's fraction and the editor's parts */
    uint32_t tile[CR_NSTRIP][CR_NTY * CR_NTX];   /* the pixels' hashes, per strip and tile */
    uint32_t row[CR_ED_ROWS], wv, hot, ttl;   /* the editor's parts (cr_ed_strips): each row's cells, the band, the
                                               * hot cell, the title line */
#if CR_LAY_FREE
    uint32_t fcell[CR_ED_ROWS][4];       /* a free screen's: each cell (cr_free_strips: the strips of its element) */
#endif
    uint16_t ring;                       /* .. which was drawn */
    uint32_t dl;                         /* the corner dial drawn (dial | pulse << 16 | mode << 17 | dot << 20) */
    int8_t pos;                          /* the arp screen's sounding note drawn (cr_arp_strips) */
    uint32_t lm, lmr;                    /* the loop menu's moving parts (lm_lane .. lm_erase1), .. but lm_pos */
    uint32_t now;                        /* .. its playing name (lm_now) */
    uint16_t lmpos;                      /* .. lm_pos drawn (the step cursor's old row) */
    uint8_t valid, force;
    uint8_t blits, drawn;                /* strips blitted / composed by the last cr_draw (the host test reads them) */
    uint8_t slot;                        /* the DMA buffer the next blit uses (cr_send) */
    uint32_t bytes;                      /* .. bytes sent to the LCD (the emulator's log: the SPI time) */
} cr_dc __attribute__((section(".pool")));        /* (zero-initialised) */
static uint32_t cr_strip_y;              /* the strip being drawn: its top row */
#ifndef CR_HOOK_STRIP
#define CR_HOOK_STRIP() ((void)0)        /* a strip composed and sent (the emulator: its time passes, tools/emu/README.md) */
#endif

static uint32_t cr_hash(uint32_t h, const void *p, uint32_t n)
{
    const uint8_t *b = (const uint8_t *)p;
    while (n--) h = (h ^ *b++) * 16777619u;
    return h;
}
/* the canvas (one strip) as tiles: the mask of those whose hash changed from t[], t[] updated (all: every tile) */
static uint32_t cr_hash_tiles(uint32_t *t, int all)
{
    uint32_t m = 0, tx, ty, i, j;
    for (ty = 0; ty < CR_NTY; ty++)
        for (tx = 0; tx < CR_NTX; tx++) {
            uint32_t h = 2166136261u, k = ty * CR_NTX + tx;
            for (j = 0; j < CR_TILE_H; j++) {
                const uint16_t *r = cv_px + (ty * CR_TILE_H + j) * 240u + tx * CR_TILE_W;
                for (i = 0; i < CR_TILE_W; i++) h = (h ^ r[i]) * 16777619u;
            }
            if (all || h != t[k]) m |= 1u << k;
            t[k] = h;
        }
    return m;
}
/* the strip's canvas (rows 0 .. CR_STRIP_H - 1 of cv_px), cleared: gfx.c cv_begin without its lcd_sync, since the
 * LCD's DMA reads the blits from cv_px's rows CR_STRIP_H .. 3 CR_STRIP_H - 1 (cr_send), not these */
static void cr_cv_begin(void)
{
    uint32_t i;
    uint16_t c = swap16(T_BG);
    GFX_HOOK_BEGIN();
    cv_w = 240u;
    cv_h = CR_STRIP_H;
    cv_cy0 = 0;
    cv_cy1 = (int16_t)CR_STRIP_H;
    cv_bg = T_BG;
    for (i = 0; i < 240u * CR_STRIP_H; i++) cv_px[i] = c;
}
/* the tiles m of the strip at row y to the LCD: their box copied into one of two DMA buffers (cv_px's rows 40..79,
 * 80..119: CV_MAX holds them, CV_ROWS 120) and sent from there, so the next strip is composed while this one goes out (lcd.c
 * leaves the transfer running; the next blit waits for it, and the buffer it reuses is the one before's) */
static void cr_send(uint32_t m, uint32_t y)
{
    uint32_t x0 = CR_NTX, x1 = 0, y0 = CR_NTY, y1 = 0, k, i, j, w, h;
    uint16_t *d = cv_px + 240u * CR_STRIP_H * (1u + (cr_dc.slot & 1u)), *o = d;
    _Static_assert(240u * CR_STRIP_H * 3u <= CV_MAX, "two DMA buffers after the strip's canvas");
    for (k = 0; k < CR_NTX * CR_NTY; k++)
        if (m >> k & 1u) {
            uint32_t tx = k % CR_NTX, ty = k / CR_NTX;
            if (tx < x0) x0 = tx;
            if (tx + 1u > x1) x1 = tx + 1u;
            if (ty < y0) y0 = ty;
            if (ty + 1u > y1) y1 = ty + 1u;
        }
    if (x1 <= x0) return;
    x0 *= CR_TILE_W; w = x1 * CR_TILE_W - x0;
    y0 *= CR_TILE_H; h = y1 * CR_TILE_H - y0;
    for (j = 0; j < h; j++) {
        const uint16_t *r = cv_px + (y0 + j) * 240u + x0;
        for (i = 0; i < w; i++) *o++ = r[i];
    }
    GFX_HOOK_BLIT(x0, y + y0, 0u);
    lcd_blit(x0, y + y0, w, h, d);
    cr_dc.slot ^= 1u;
    cr_dc.bytes += w * h * 2u;
}

/* the next cr_draw draws and blits the whole screen (after something else drew on it, a palette change) */
static void cr_draw_invalidate(void) { cr_dc.force = 1; }

/* the screen off (cr_ui.c cr_ui_draw): the whole panel black, in one fill (lcd.c: it waits for the last strip's
 * transfer first, and sends from its own buffer). Black pixels with the backlight on is all the "off" there is: the
 * backlight's pin also keeps the key matrix alive (hal/fm1_lcd_hw.h). Nothing of the cache holds after it: the next
 * cr_draw (the wake) draws and blits every strip whole */
static void cr_draw_black(void)
{
    lcd_fill(0, 0, 240, 240, 0);
    cr_dc.force = 1;
}

/* the strips (bit k) holding pixels the ring's progress covers at one fraction and not the other (Q8): the band's
 * rows over the angles between the two tips, widened by the samples' reach (cr_ring_draw) and two pixels */
static uint32_t cr_ring_strips(uint32_t q0, uint32_t q1)
{
    uint32_t w0 = !q0 ? 0u : q0 >= 256u ? 65536u : q0 << 8, w1 = !q1 ? 0u : q1 >= 256u ? 65536u : q1 << 8;
    uint32_t lo = w0 < w1 ? w0 : w1, hi = w0 < w1 ? w1 : w0, a0, len, m = 0, k;
    int32_t s0, s1, smin, smax, rin = CR_RING_R - CR_RING_W / 2 - 12, rout = CR_RING_R + CR_RING_W / 2 + 12;
    int32_t y0, y1;
    if (hi - lo + 256u >= 65536u) return (1u << CR_NSTRIP) - 1u;
    a0 = (CR_RING_TOP + lo - 128u) & 65535u;
    len = hi - lo + 256u;
    s0 = cr_sin(a0);
    s1 = cr_sin(a0 + len);
    smin = s0 < s1 ? s0 : s1;
    smax = s0 < s1 ? s1 : s0;
    if (((16384u - a0) & 65535u) <= len) smax = 16384;       /* the bottom within the angles */
    if (((49152u - a0) & 65535u) <= len) smin = -16384;      /* the top */
    y0 = CR_RING_C + (((smin < 0 ? rout : rin) * smin) >> 14);
    y1 = CR_RING_C + (((smax < 0 ? rin : rout) * smax) >> 14);
    y0 = (y0 >> 4) - 2;
    y1 = (y1 >> 4) + 2;
    for (k = 0; k < CR_NSTRIP; k++)
        if ((int32_t)((k + 1u) * CR_STRIP_H) > y0 && (int32_t)(k * CR_STRIP_H) <= y1) m |= 1u << k;
    return m;
}

/* the strips (bit k) holding rows y0 .. y1 - 1 */
static uint32_t cr_strips_of(int32_t y0, int32_t y1)
{
    uint32_t m = 0, k;
    for (k = 0; k < CR_NSTRIP; k++)
        if ((int32_t)((k + 1u) * CR_STRIP_H) > y0 && (int32_t)(k * CR_STRIP_H) < y1) m |= 1u << k;
    return m;
}
/* the editor's row r (CR_K_EDIT8 / STACK; KNOBROW: row 0, its knob cells): the strips its cells, its hot block, its
 * mark and bars are drawn in */
static uint32_t cr_ed_row_strips(const cr_screen_t *s, uint32_t r)
{
    if (s->kind == CR_K_STACK) {
        uint32_t n = s->n_rows ? (s->n_rows > CR_ED_ROWS ? CR_ED_ROWS : s->n_rows) : 1u;
        int32_t rh = P8(198) / (int32_t)n, y = P8(41) + (int32_t)r * rh;
        return cr_strips_of((y >> 8) - 1, ((y + rh) >> 8) + 1);   /* (its line above it: row - 1) */
    }
    if (s->kind == CR_K_KNOBROW) {                   /* the one row of knob cells (and the strips' edges) */
        int32_t y = cr_kr_rowy(s);
        return r ? 0u : cr_strips_of(y - 2, y + CR_KR_ROW + 2);
    }
    if (s->tall || r > 1u) return (1u << CR_NSTRIP) - 1u;
    if (s->wide) return cr_strips_of((r ? 184 : 124) - 2, (r ? 240 : s->n_rows == 1u ? 224 : 180) + 2);
    return cr_strips_of((r ? 134 : 30) - 2, (r ? 234 : 130) + 2);
}
/* the strips of what changed when only the editor's parts did: a row's cells, the band's values, the hot cell (its
 * old and new rows, and the band: its lit segment follows it) */
static uint32_t cr_ed_strips(const cr_screen_t *s, const uint32_t *row, uint32_t wv, uint32_t hot)
{
    uint32_t m = 0, r, band = s->kind == CR_K_EDIT8 && s->wide && !s->tall ? cr_strips_of(20, 122) : (1u << CR_NSTRIP) - 1u;
    if (s->kind != CR_K_EDIT8 && s->kind != CR_K_STACK && s->kind != CR_K_KNOBROW) return (1u << CR_NSTRIP) - 1u;
    for (r = 0; r < CR_ED_ROWS; r++)
        if (row[r] != cr_dc.row[r]) m |= cr_ed_row_strips(s, r);
    if (wv != cr_dc.wv) m |= band;
    if (hot != cr_dc.hot) {
        if (cr_dc.hot & 255u) m |= cr_ed_row_strips(s, (cr_dc.hot & 255u) - 1u);
        if (hot & 255u) m |= cr_ed_row_strips(s, (hot & 255u) - 1u);
        if (s->wide && s->kind == CR_K_EDIT8) m |= band;
    }
    return m;
}

#if CR_LAY_FREE
/* a free screen's parts changed alone (CR_K_FREE: a cell's value, the hot cell): the strips of the elements whose
 * cells changed, and of the hot element before and now */
static uint32_t cr_free_strips(const cr_screen_t *s, const uint32_t fc[CR_ED_ROWS][4], uint32_t hot)
{
    const cr_lay_screen_t *ls = cr_lay_scr(s->fl_eng, s->fl_scr);
    uint32_t m = 0, r, c, x, h0 = cr_dc.hot & 255u, h1 = hot & 255u;
    int32_t y0, y1;
    for (r = 0; r < CR_ED_ROWS; r++)
        for (c = 0; c < 4u; c++) {
            int ch = fc[r][c] != cr_dc.fcell[r][c];
            if (hot != cr_dc.hot)
                ch |= (h0 == r + 1u && ((cr_dc.hot >> 8) & 255u) == c) || (h1 == r + 1u && ((hot >> 8) & 255u) == c);
            if (!ch || (x = cr_lay_slot(ls, r, c)) == CR_LAY_EMPTY) continue;
            cr_free_ext(cr_lay_el(s->fl_eng, ls, x), &y0, &y1);
            m |= cr_strips_of(y0, y1);
        }
    return m;
}
#endif

/* the loop menu's moving parts changed alone (lm_lane .. lm_erase1: a playhead, a mark, the Replace span, the step
 * cursor and its blink): the middle's strips; the cursor alone (same marks and span): its old and new rows' strips */
static uint32_t cr_lm_strips(const cr_screen_t *s, int marks)
{
    if (s->kind != CR_K_LOOPMENU) return (1u << CR_NSTRIP) - 1u;
    if (s->lm_mid == CR_LM_TIMELINE) {
        int32_t sy = cr_lm_tl_y(s);
        return cr_strips_of(sy - 6, sy + 40 + 3);
    }
    if (s->lm_mid == CR_LM_STEPS) {
        int32_t gy = cr_lm_st_y(s), per = cr_lm_per(s), r0 = (int32_t)(cr_dc.lmpos & 63u) / per, r1 = (int32_t)(s->lm_pos & 63u) / per;
        int32_t p0 = (int32_t)CR_LM_PLAYED(cr_dc.lmpos), p1 = (int32_t)CR_LM_PLAYED(s->lm_pos);
        uint32_t m;
        if (marks) return cr_strips_of(gy - 4, gy + cr_lm_rows(s) * 9 + 2);
        m = cr_strips_of(gy + r0 * 9 - 4, gy + r0 * 9 + 11) | cr_strips_of(gy + r1 * 9 - 4, gy + r1 * 9 + 11);
        if (p0 != p1) {                              /* the playhead's old and new cells (their rows) */
            if (p0) m |= cr_strips_of(gy + (p0 - 1) / per * 9, gy + (p0 - 1) / per * 9 + 7);
            if (p1) m |= cr_strips_of(gy + (p1 - 1) / per * 9, gy + (p1 - 1) / per * 9 + 7);
        }
        return m;
    }
    return 0;                                        /* (a big text: none of them is drawn) */
}

/* the arp screen's hop moved alone (pos: the note on its block, the dotted arc): the rows from the arc's top to the
 * notes' line (cr_p_arp: by - 70 .. by + 9), not the name's */
static uint32_t cr_arp_strips(const cr_screen_t *s)
{
    int32_t by = CR_PY0 + cr_ph(s) - 46;
    if (s->kind == CR_K_KNOBROW && s->kr_band == 2u)             /* the PERF layer's band (cr_kr_arp): not the row's */
        return cr_strips_of(CR_KA_BY(s) - 40, CR_KA_BY(s) + 14);
    if (s->kind != CR_K_ARP) return (1u << CR_NSTRIP) - 1u;
    return cr_strips_of(by - 72, by + 12);
}

static void cr_draw(const cr_screen_t *s, uint32_t anim_ms)
{
    cr_frame_t fr;
    uint32_t sig, base, k, strips = (1u << CR_NSTRIP) - 1u, row[CR_ED_ROWS], wv, hot;
    uint32_t ttl, ed = s->kind == CR_K_EDIT8 || s->kind == CR_K_STACK || s->kind == CR_K_FREE, i, j, o;
#if CR_LAY_FREE
    uint32_t fc[CR_ED_ROWS][4];
#endif
    /* the struct's bytes but these (offset, size), hashed apart: the ring's fraction, the corner dial's fraction,
     * pulse, look and REC dot, the editor's parts (its cells, the hot cell, the band's values, its title line), the
     * arp screen's sounding note */
    uint32_t lm, lmr, now, sk[11][2] = {
        {(uint32_t)__builtin_offsetof(cr_screen_t, pos), sizeof s->pos},
        {(uint32_t)__builtin_offsetof(cr_screen_t, lm_lane), (uint32_t)(__builtin_offsetof(cr_screen_t, lm_used) -
                                                                         __builtin_offsetof(cr_screen_t, lm_lane))},
        {(uint32_t)__builtin_offsetof(cr_screen_t, ring), sizeof s->ring},
        {(uint32_t)__builtin_offsetof(cr_screen_t, dial), sizeof s->dial},
        {(uint32_t)__builtin_offsetof(cr_screen_t, dial_pulse), 3u},
        {(uint32_t)__builtin_offsetof(cr_screen_t, cell), sizeof s->cell},
        {(uint32_t)__builtin_offsetof(cr_screen_t, hot_r), 3u},
        {(uint32_t)__builtin_offsetof(cr_screen_t, wv), sizeof s->wv},
        {(uint32_t)__builtin_offsetof(cr_screen_t, title), sizeof s->title},
        {(uint32_t)__builtin_offsetof(cr_screen_t, page), sizeof s->page},
        {(uint32_t)__builtin_offsetof(cr_screen_t, lm_now), sizeof s->lm_now}};
    _Static_assert(__builtin_offsetof(cr_screen_t, hot_c) == __builtin_offsetof(cr_screen_t, hot_r) + 1 &&
                   __builtin_offsetof(cr_screen_t, hot_col) == __builtin_offsetof(cr_screen_t, hot_r) + 2, "hot_r c col");
    _Static_assert(__builtin_offsetof(cr_screen_t, dial_mode) == __builtin_offsetof(cr_screen_t, dial_pulse) + 1 &&
                   __builtin_offsetof(cr_screen_t, dial_dot) == __builtin_offsetof(cr_screen_t, dial_pulse) + 2,
                   "dial_pulse mode dot");
    _Static_assert(__builtin_offsetof(cr_screen_t, lm_cell) == __builtin_offsetof(cr_screen_t, lm_lane) + 40 &&
                   __builtin_offsetof(cr_screen_t, lm_bar) == __builtin_offsetof(cr_screen_t, lm_lane) + 104 &&
                   __builtin_offsetof(cr_screen_t, lm_pos) == __builtin_offsetof(cr_screen_t, lm_lane) + 106 &&
                   __builtin_offsetof(cr_screen_t, lm_erase0) == __builtin_offsetof(cr_screen_t, lm_pos) + 2 &&
                   __builtin_offsetof(cr_screen_t, lm_used) == __builtin_offsetof(cr_screen_t, lm_erase0) + 4,
                   "lm_lane cell bar ed pos erase0 erase1 used");
    uint32_t dl = (uint32_t)s->dial | (uint32_t)s->dial_pulse << 16 | (uint32_t)s->dial_mode << 17 |
                  (uint32_t)s->dial_dot << 20;
    for (i = 1; i < 11u; i++)                                    /* (in the struct's order) */
        for (j = i; j && sk[j - 1][0] > sk[j][0]; j--) {
            uint32_t a = sk[j][0], c = sk[j][1];
            sk[j][0] = sk[j - 1][0]; sk[j][1] = sk[j - 1][1];
            sk[j - 1][0] = a; sk[j - 1][1] = c;
        }
    cr_frame(s, anim_ms, &fr);
    base = 2166136261u ^ ux.gen;
    for (i = 0, o = 0; i < 11u; o = sk[i][0] + sk[i][1], i++)
        base = cr_hash(base, (const uint8_t *)s + o, sk[i][0] - o);
    base = cr_hash(base, (const uint8_t *)s + o, (uint32_t)sizeof *s - o);
    base = cr_hash(base, &fr, sizeof fr);
    ttl = cr_hash(cr_hash(cr_hash(2166136261u, s->title, sizeof s->title), s->page, sizeof s->page), &s->title_col, 1u);
    if (!ed)                                                     /* (the title line: the editor's top strip only) */
        base = cr_hash(base, &ttl, sizeof ttl);
    lmr = cr_hash(cr_hash(2166136261u, s->lm_lane, 106u), &s->lm_erase0, 4u);   /* (the lanes, lm_cell, lm_bar, lm_ed) */
    lm = cr_hash(lmr, &s->lm_pos, sizeof s->lm_pos);
    now = cr_hash(2166136261u, s->lm_now, sizeof s->lm_now);    /* (the editor's playing name: its strip only) */
    if (s->kind != CR_K_LOOPMENU) {                              /* (the loop menu's moving parts: its middle only) */
        base = cr_hash(base, &lm, sizeof lm);
        base = cr_hash(base, &now, sizeof now);
    }
    for (k = 0; k < CR_ED_ROWS; k++)
        row[k] = cr_hash(2166136261u, s->cell[k], sizeof s->cell[k]);
#if CR_LAY_FREE
    for (k = 0; k < CR_ED_ROWS * 4u && s->kind == CR_K_FREE; k++)
        fc[k / 4u][k % 4u] = cr_hash(2166136261u, &s->cell[k / 4u][k % 4u], sizeof s->cell[0][0]);
#endif
    wv = cr_hash(2166136261u, s->wv, sizeof s->wv);
    hot = (uint32_t)s->hot_r | (uint32_t)s->hot_c << 8 | (uint32_t)s->hot_col << 16;
    sig = cr_hash(cr_hash(cr_hash(cr_hash(cr_hash(cr_hash(base, &s->ring, sizeof s->ring), &dl, sizeof dl), row, sizeof row),
                                  &wv, sizeof wv), &hot, sizeof hot), &ttl, sizeof ttl);
    sig = cr_hash(cr_hash(cr_hash(sig, &lm, sizeof lm), &s->pos, sizeof s->pos), &now, sizeof now);
    cr_dc.blits = cr_dc.drawn = 0;
    if (cr_dc.valid && !cr_dc.force && sig == cr_dc.sig)
        return;                          /* nothing changed: nothing drawn */
    if (cr_dc.valid && !cr_dc.force && base == cr_dc.base) {
        strips = 0;
        if (s->ring_on && s->ring != cr_dc.ring)
            strips = cr_ring_strips(cr_dc.ring, s->ring);   /* the ring's fraction moved: the strips its tip crossed */
        if (ttl != cr_dc.ttl)
            strips |= 1u;                                        /* the editor's title line (rows 0..24) */
        if (dl != cr_dc.dl)
            strips |= 1u;                                        /* the corner dial (rows 2..22; the REC dot's blink) */
        if (lm != cr_dc.lm)
            strips |= cr_lm_strips(s, lmr != cr_dc.lmr);         /* the loop menu: a playhead, a mark, the cursor */
        if (now != cr_dc.now)
            strips |= cr_strips_of(64, 79);                      /* the editor's playing name (and the left neighbour
                                                                  * it stands for): one strip */
        if (s->pos != cr_dc.pos)
            strips |= cr_arp_strips(s);                          /* the arp screen: the hop moved */
#if CR_LAY_FREE
        if (s->kind == CR_K_FREE)
            strips |= cr_free_strips(s, fc, hot);                /* a free screen: the elements that changed */
        else
#endif
        if (wv != cr_dc.wv || hot != cr_dc.hot)
            strips |= cr_ed_strips(s, row, wv, hot);
        else
            for (k = 0; k < CR_ED_ROWS; k++)
                if (row[k] != cr_dc.row[k]) {
                    strips |= cr_ed_strips(s, row, wv, hot);    /* the editor: only the parts that changed */
                    break;
                }
    }
    cr_dc.bytes = 0;
    if (cr_dc.force)
        lcd_sync();                      /* (something else drew: its transfer may read cv_px's first rows) */
    for (k = 0; k < CR_NSTRIP; k++) {
        uint32_t m;
        if (!(strips >> k & 1u))
            continue;
        cr_strip_y = k * CR_STRIP_H;
        cr_cv_begin();
        cv_oy = -(int32_t)cr_strip_y;
        cr_clip_all();
        cr_compose(s, &fr);
        cr_dc.drawn++;
        cv_oy = 0;
        if ((m = cr_hash_tiles(cr_dc.tile[k], cr_dc.force || !cr_dc.valid)) != 0) {
            cr_send(m, cr_strip_y);
            cr_dc.blits++;
        }
        CR_HOOK_STRIP();
        CR_IDLE();                       /* (after each strip: cr_gfx.c cr_draw_idle, the keys) */
    }
    cr_dc.sig = sig;
    cr_dc.base = base;
    cr_dc.ring = s->ring;
    cr_dc.dl = dl;
    cr_dc.lm = lm;
    cr_dc.lmr = lmr;
    cr_dc.now = now;
    cr_dc.lmpos = s->lm_pos;
    cr_dc.pos = s->pos;
    for (k = 0; k < CR_ED_ROWS; k++)
        cr_dc.row[k] = row[k];
#if CR_LAY_FREE
    for (k = 0; k < CR_ED_ROWS * 4u && s->kind == CR_K_FREE; k++)
        cr_dc.fcell[k / 4u][k % 4u] = fc[k / 4u][k % 4u];
#endif
    cr_dc.wv = wv;
    cr_dc.hot = hot;
    cr_dc.ttl = ttl;
    cr_dc.valid = 1;
    cr_dc.force = 0;
}
