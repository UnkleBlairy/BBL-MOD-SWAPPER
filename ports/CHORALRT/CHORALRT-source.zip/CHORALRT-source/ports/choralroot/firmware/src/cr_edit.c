/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 ChoralRoot FM-1 contributors (a fork of Felucca) */
/* ChoralRoot FM-1: the sound editor (design/choralroot-fm1-sound-editor-mockups.json, the normative spec; docs/EDITOR.md;
 * drawn as cr_screen.h CR_K_EDIT8 / CR_K_STACK by cr_draw.c). Included by cr_ui.c (after its sounds, its engine
 * switch and cu_edited): cr_ui.c's gesture engine calls ce_button / ce_owns / ce_leds (CR_EDIT_HOOKS), its knob
 * dispatch ce_knob / ce_select, its screen builder ce_screen.
 *
 * EDIT tap opens it on the chord sound (BASS held + EDIT: the bass sound), EDIT tap or HOME leaves; SHIFT (OPT) +
 * EDIT switches chord <-> bass inside. Navigation: GROUPS -> SCREENS -> LANES. The function buttons are the groups by
 * their PRINTED names: FX = OSC, SEL = FILT, ENV = ENV, LFO = LFO, SEQ = MOD, PLAY = FX (the sends), REC = MIX. A
 * group's button opens it (at its remembered screen and lane), tapped again it cycles the group's screens; held it
 * does nothing (reserved), but SEL (FILT) on an engine with a filter TYPE column: THE FILTER PICKER (3y204, the owner
 * 2026-10-31: "when you are in the edit mode, then hold down the SEL key(Filter pages), which should bring up page for
 * filter selection"): SEL held past the hold time opens FILT and a picker of the types; while SEL is down KNOB 1..4 or
 * SELECT step the type (a knob turned before the hold time opens it at once, as FIZZ's FILTERS key); the release
 * closes it and keeps the choice (ce_fpick). SELECT moves the LANE (the four parameters on KNOB 1..4: a row, an oscillator, a slot)
 * and runs on across the screens (past the last lane: the next screen's first, wrapping), so SELECT alone reaches
 * everything. GLO = SHIFT (OPT): a tap latches it (snap, its LED lit, "snap" in the title line), held it is
 * momentary. KNOB 1..4 edit the active lane's cells (accelerated: cr_pages.c kn_lin; enums and named choices one by one;
 * SHIFT: the value snaps, kn_snap).
 * The editor remembers its group per part, every group its screen and lane (RAM).
 *
 * The screens are built from the engine's deep pages (core.h eng_deep_t: its sections OSC FILTER ENV LFO MOD, pages
 * of four titled "OSC 1", "OSC 1+", "LFO SYN" ..), never from an engine's column names, so pages and columns an
 * engine adds show up by themselves:
 *   OSC, LFO: one STACK screen per kind of page (the pages "OSC n" are one, "OSC n+" another; a page with no number,
 *     "LFO SYN", is a screen whose lane i shows its column i); OSC then has the MIXER: one lane, the LEVEL column of
 *     each oscillator as four tall bars;
 *   FILT, ENV: edit8 screens of the pages that share an instance number ("FILTER", "FILTER+"; "ENV 2", "ENV 2+"),
 *     two lanes a screen, under the wide filter curve / the envelope of that ENV;
 *   MOD: a stack of the matrix's slots (eight lanes a screen);
 *   an engine without deep pages: OSC = EDIT 1, FILT = EDIT 2 (one lane each), ENV = the platform ENV under the
 *   envelope (an engine with its own envelopes, FM6: a message, the group stays), LFO = the platform LFO, MOD = the
 *   platform MOD page as a stack of 4 slots (source and destination fixed, the amount on KNOB 3);
 *   every engine: FX = the sends (one lane), MIX = level pan voice glide | transpose detune priority glide mode.
 * An engine with a screen plan (eng_deep_t.screens, core.h eng_screen_t: QUAD's) has its groups built from the plan
 * instead: each screen one or two pages under a band (ENG_B_*), its title, each cell's label and style (ENG_C_*: big
 * numbers, the ratio fraction, harm / detune glyphs, a wave + phase span cell); an engine without a MOD section (QUAD)
 * has the platform's MOD routes. VA, FM6 and CZ-1 have no plan: their screens are as before.
 * An engine with a compiled CLASSIC layout (build/gen/cr_layouts.h CR_LAYC, docs/LAYOUT-TOOL.md "Step 4": P5's rows)
 * has the layout's pages and screen plan as its own: cr_pages.c cp_deep serves them, each column going through to its
 * built-in (page, column), so the screens are the plan's as above (MOD: the plan's, then EXPR). An engine with a
 * compiled FREE layout (cr_layout.c; only in a build that has one, CR_LAY_FREE: the layout tool's preview) shows its
 * layout's free screens in OSC .. MOD instead (CE_S_FREE, drawn as CR_K_FREE): each a lane per SELECT stop, KNOB 1..4
 * the elements bound in it (an empty slot: nothing), the parameters the engine's own by their built-in (page, column),
 * so the knobs, SHIFT, the hot mark, cu_edited and the blob are the edit8 screens'. MOD's last screen is still EXPR
 * (after the layout's MOD screens); FX and MIX stay the platform's.
 *
 * No motion (the user's feedback, 2026-10-06: responsiveness first; Options > Motion does not apply here): a screen,
 * a lane, a value and the wide band are drawn as they are, in the frame after the detent; only the hot cell (the one
 * just turned) lasts CE_HOT_MS. cr_draw composes only the strips of what changed (the band, a row).
 *
 * Quick modulation mapping (an engine whose eng_deep_t has mod_dst, the VA): ENV or LFO held + a knob turned = the
 * last ENV n / LFO n shown (ENV 2 / LFO 1 before) modulates the parameter under that knob: its matrix slot (that
 * source and destination, else the first free one; none: "matrix full") gets the turn on its AMT, the hot cell
 * showing "LFO1 +24" in the source's colour; OCT- held + a knob = every slot to that parameter cleared. A cell whose
 * parameter the matrix modulates carries a mark in the source's colour (white: several). */

enum { CE_OSC, CE_FILT, CE_ENV, CE_LFO, CE_MOD, CE_FX, CE_MIX, CE_NSEC };   /* (OSC..MOD: eng_deep_t.section 0..4) */
static const char *const CE_SEC_NAME[CE_NSEC] = {"OSC", "FILT", "ENV", "LFO", "MOD", "FX", "MIX"};
static const uint8_t CE_SEC_BTN[CE_NSEC] = {B_FX, B_SCL, B_ENV, B_LFO, B_SEQ, B_PLAY, B_REC};   /* printed ids */
#define CE_HOT_MS 800u                    /* the cell just turned stays hot */

/* a cell's parameter: a deep page's column, a track parameter, a fixed text, a dash (an empty column) */
enum { CE_R_NONE, CE_R_DEEP, CE_R_TRK, CE_R_TXT, CE_R_DASH };
typedef struct { uint8_t k, a, b; } ce_ref_t;             /* DEEP: page a, column b; TRK: id a; TXT: CE_TXT[a] */
static const char *const CE_TXT[] = {"ENV", "LFO", "FILT", "PITCH", "SHAPE", "AMP", "VEL", "AT", "CUT", "auto"};
enum { CE_T_AMP = 5, CE_T_VEL, CE_T_AT, CE_T_CUT, CE_T_AUTO };
static const uint8_t CE_PMOD[4][2] = {{0, 2}, {0, 3}, {0, 4}, {1, 5}};   /* the platform MOD's sources, dests */

/* a screen of a group: what its lanes are */
enum { CE_S_PLAT,                         /* the platform's pages (an engine without deep pages; FX, MIX) */
       CE_S_STACK,                        /* a stack: lane i = deep page pg[i] */
       CE_S_TRANS,                        /* a stack: lane i = column i of the one page pg[0] ("LFO SYN") */
       CE_S_MIXER,                        /* one lane: the LEVEL column of the pages pg[0..n) */
       CE_S_EDIT,                         /* edit8: lane i = deep page pg[i] (n <= 2) */
       CE_S_PAGE,                         /* edit8: one lane, the page pg[0] (a page of no instance: "VOICE") */
       CE_S_EXPR,                         /* the MOD group's last screen on every engine: Expression, two lanes (the
                                           * sound's velocity and aftertouch routings: mod.c slots 3 and 4; after a
                                           * compiled layout's MOD screens too) */
       CE_S_FREE };                       /* a compiled layout's screen (li, ls): lane i = its lane i's elements */
typedef struct { uint8_t type, n, pg[CR_ED_ROWS], hs, li, ls; } ce_scr_t;   /* hs: the plan's screen + 1
                                          * (eng_deep_t.screens); li, ls: the layout and its screen (cr_layout.c) + 1 */

typedef struct {
    uint8_t kind, n, active, wide, tall;  /* CR_K_EDIT8 / STACK, rows, the row on the knobs, CR_W_*, the mixer */
    ce_ref_t ref[CR_ED_ROWS][4];
    char head[4][10];                     /* stack: the column headings */
    char right[16];                       /* the title line's right text */
    uint8_t dp0, np, row0;                /* the band's pages (env: dp0 .. + np; filter: dp0); the first row's number */
    uint8_t hs;                           /* a screen of the engine's plan: its index + 1 (0: the title rules) */
    uint8_t li, ls;                       /* a free screen: the layout and its screen + 1 (cr_screen_t fl_eng, fl_scr) */
    uint8_t expr;                         /* the EXPR screen (ce_knob: an unset slot takes its default when turned) */
} ce_view_t;

static struct {
    uint8_t grp[2], scr[2][CE_NSEC], lane[2][CE_NSEC];   /* per part: the group; per group its screen and lane */
    uint8_t shift;                        /* SHIFT latched (snap: OPT held or latched) */
    uint8_t hot_r, hot_c;                 /* the cell last turned (row + 1, 0 none), its column */
    uint8_t hot_slot, hot_src;            /* .. by a quick mapping: its matrix page + 1 (0: an edit), the source */
    uint32_t hot_t0;
    uint8_t msrc[2][2];                   /* per part: the ENV n / LFO n last shown (0: none yet, ENV 2 / LFO 1) */
    uint8_t fpick;                        /* the filter picker is up (while SEL is held) */
} cx __attribute__((section(".pool")));   /* (zero-initialised: OSC, screen 1, lane 1 for both parts) */

static track_t *ce_trk(void) { return &trk[ce.part ? CR_PART_BASS : CR_PART_CHORD]; }

/* the engine's deep pages when it has the sections OSC FILTER ENV LFO and MOD, or the first four (no MOD: QUAD's;
 * the MOD group is then the platform's routes, as for an engine without deep pages), ascending (eng_deep_t.section) */
static const eng_deep_t *ce_deep(const track_t *t)
{
    const eng_deep_t *d = cp_deep(t);
    uint32_t i;
    if (!d)
        return 0;
    for (i = 0; i < 5u; i++) {
        if (i == 4u && d->section[4] == 0xFFu)
            break;
        if (d->section[i] >= d->npages || (i && d->section[i] <= d->section[i - 1u]))
            return 0;
    }
    return d;
}
#if CR_LAY_FREE
/* the engine's compiled free layout (cr_layout.c): its index + 1, 0 none (an engine without deep pages has none) */
static uint32_t ce_lay(const track_t *t) { return ce_deep(t) ? cr_lay_find(eng_idx(t->eng_req)) : 0u; }
#endif
/* the engine's MOD group is its own pages (else the platform's routes) */
static int ce_has_mod(const eng_deep_t *d) { return d && d->section[4] != 0xFFu; }
/* the plan's screen of a view / a scan, 0 none */
static const eng_screen_t *ce_plan(const eng_deep_t *d, uint32_t hs)
{
    return d && d->screens && hs && hs <= d->nscreens ? &d->screens[hs - 1u] : 0;
}
/* the pages of section g (CE_OSC..CE_MOD): a .. b - 1 */
static void ce_range(const eng_deep_t *d, uint32_t g, uint32_t *a, uint32_t *b)
{
    *a = d->section[g];
    *b = g + 1u < 8u && d->section[g + 1u] < d->npages && d->section[g + 1u] > *a ? d->section[g + 1u] : d->npages;
}
/* a page title's instance number ("OSC 2+" -> 2, "LFO SYN" / "FILTER" -> 0) and what follows it ("+") */
static uint32_t ce_inst(const char *t)
{
    while (*t && *t != ' ')
        t++;
    return t[0] == ' ' && t[1] >= '1' && t[1] <= '9' ? (uint32_t)(t[1] - '0') : 0u;
}
static const char *ce_suf(const char *t)
{
    while (*t && *t != ' ')
        t++;
    if (t[0] == ' ' && t[1] >= '0' && t[1] <= '9')
        for (t++; *t >= '0' && *t <= '9'; t++)
            ;
    return t;
}
/* pages p and q are of one kind: both numbered, with the same name and suffix ("OSC 1" / "OSC 3"; "OSC 1+" /
 * "OSC 4+"; FM6's "OP 2" and "SCALE 2" are two kinds) */
static int ce_kind_eq(const eng_deep_t *d, uint32_t p, uint32_t q)
{
    const char *a = d->pages[p].title, *b = d->pages[q].title;
    if (!ce_inst(a) || !ce_inst(b))
        return p == q;
    while (*a && *a != ' ' && cp_up(*a) == cp_up(*b))
        a++, b++;
    if (*a != ' ' || *b != ' ')
        return 0;
    return cp_eq(ce_suf(a), ce_suf(b));
}
/* page q (no instance) is page p's "+" page ("LFO" / "LFO+", FM6's "FUNC" / "FUNC+"): one screen of two lanes */
static int ce_plus_of(const eng_deep_t *d, uint32_t p, uint32_t q)
{
    const char *a = d->pages[p].title, *b = d->pages[q].title;
    if (ce_inst(a) || ce_inst(b) || q != p + 1u)
        return 0;
    while (*a && cp_up(*a) == cp_up(*b))
        a++, b++;
    return !*a && b[0] == '+' && !b[1];
}
/* the section's pages are matrix slots (SRC DST AMT: the VA's MOD 1..8), else plain pages (FM6's FUNC, CTRL) */
static int ce_is_matrix(const eng_deep_t *d, uint32_t pg)
{
    return cp_dcol(&d->pages[pg], "SRC") >= 0 && cp_dcol(&d->pages[pg], "DST") >= 0 &&
           cp_dcol(&d->pages[pg], "AMT") >= 0;
}
/* the screen's pages are a DX envelope: rates R1..R4 (FM6's ENV n, PITCH EG; the "dx" wide band) */
static int ce_is_dx(const eng_deep_t *d, uint32_t pg)
{
    return cp_dcol(&d->pages[pg], "R1") == 0 && cp_dcol(&d->pages[pg], "R4") == 3;
}

/* pages p and q have one name (the title up to its space or "+": "ENV 2+" / "ENV 2" "ENV"; CZ-1's "DCW 1 B" "DCW") */
static int ce_name_eq(const eng_deep_t *d, uint32_t p, uint32_t q)
{
    const char *a = d->pages[p].title, *b = d->pages[q].title;
    while (*a && *a != ' ' && *a != '+' && cp_up(*a) == cp_up(*b))
        a++, b++;
    return (!*a || *a == ' ' || *a == '+') && (!*b || *b == ' ' || *b == '+');
}
/* the run of pages of one name and instance that page pg is in: its first page, *n its length */
static uint32_t ce_run(const eng_deep_t *d, uint32_t pg, uint32_t *n)
{
    uint32_t a = pg, e = pg;
    while (a && ce_inst(d->pages[a - 1u].title) == ce_inst(d->pages[pg].title) && ce_name_eq(d, a - 1u, pg))
        a--;
    while (e < d->npages && ce_inst(d->pages[e].title) == ce_inst(d->pages[pg].title) && ce_name_eq(d, e, pg))
        e++;
    *n = e - a;
    return a;
}
/* the screen's pages are a CZ-1 envelope: its run (rates and levels R1..R8 / L1..L8 on four pages, SUS and END on a
 * fifth: "DCW 1", "DCW 1+", "DCW 1 B", "DCW 1 B+", "DCW 1 S"; the "cz" wide band): 1, *r0 / *rn the run */
static int ce_is_cz(const eng_deep_t *d, uint32_t pg, uint32_t *r0, uint32_t *rn)
{
    uint32_t q;
    *r0 = ce_run(d, pg, rn);
    for (q = *r0; q < *r0 + *rn; q++)
        if (cp_dcol(&d->pages[q], "SUS") >= 0 && cp_dcol(&d->pages[q], "END") >= 0 && cp_dcol(&d->pages[*r0], "R1") >= 0)
            return 1;
    return 0;
}

/* a page of no instance whose columns are the instances' ("SYNC1" .. "SYNC4": a label ending in a digit) */
static int ce_percol(const eng_page_t *pg)
{
    const char *l = pg->col[0].label;
    uint32_t n = l ? str_len(l) : 0u;
    return n > 1u && l[n - 1u] >= '1' && l[n - 1u] <= '9';
}

/* the group can be shown for this engine (FM6's ENV: its own envelopes, in the patch) */
static int ce_has(const track_t *t, uint32_t g)
{
    return g != CE_ENV || ce_deep(t) || !ENGINES[eng_idx(t->eng_req)]->ownenv;
}

/* screen k of group g: *o; returns the group's number of screens */
static uint32_t ce_scr(const track_t *t, uint32_t g, uint32_t k, ce_scr_t *o)
{
    const eng_deep_t *d = ce_deep(t);
    uint32_t a, b, p, q, e, n = 0;
    o->type = CE_S_PLAT;
    o->n = 0;
    o->hs = o->li = o->ls = 0;
#if CR_LAY_FREE
    if (d && g <= CE_MOD && (a = ce_lay(t)) != 0 && (n = cr_lay_group(a, g, k, &p)) != 0) {   /* a free layout's group */
        if (p) {
            o->type = CE_S_FREE;
            o->n = cr_lay_scr(a, p)->nlanes;
            o->li = (uint8_t)a;
            o->ls = (uint8_t)p;
        } else if (g == CE_MOD && k == n) {      /* (MOD: the layout's screens, then Expression) */
            o->type = CE_S_EXPR;
            o->n = 2;
        }
        return g == CE_MOD ? n + 1u : n;
    }
#endif
    if (!d || g > CE_MOD || (g == CE_MOD && !ce_has_mod(d))) {
        if (g == CE_MOD) {                        /* the platform's routes, then Expression */
            if (k == 1u) {
                o->type = CE_S_EXPR;
                o->n = 2;
            }
            return 2;
        }
        return 1;
    }
    if (d->screens) {                             /* the engine's screen plan for this group (QUAD's; a compiled
                                                   * classic layout's, cr_pages.c cp_deep: P5's rows) */
        for (p = 0; p < d->nscreens; p++)
            if (d->screens[p].sec == g) {
                const eng_screen_t *h = &d->screens[p];
                if (n == k && h->pg[0] < d->npages) {
                    o->type = CE_S_EDIT;
                    o->hs = (uint8_t)(p + 1u);
                    o->pg[0] = h->pg[0];
                    o->pg[1] = h->pg[1];
                    o->n = (uint8_t)(h->pg[1] < d->npages ? 2u : 1u);
                }
                n++;
            }
        if (n && g == CE_MOD) {                   /* (MOD: the plan's screens, then Expression, as every engine) */
            if (n == k) {
                o->type = CE_S_EXPR;
                o->n = 2;
            }
            return n + 1u;
        }
        if (n)
            return n;
    }
    ce_range(d, g, &a, &b);
    if (g == CE_OSC || g == CE_LFO) {             /* stacks: a screen per kind of page */
        for (p = a; p < b; p++) {
            for (q = a; q < p && !ce_kind_eq(d, p, q) && !ce_plus_of(d, q, p); q++)
                ;
            if (q < p)                            /* (a kind seen already; a "+" page: its page's screen) */
                continue;
            if (n == k) {
                if (ce_inst(d->pages[p].title)) {    /* up to eight instances (FM6: its six operators) */
                    o->type = CE_S_STACK;
                    for (q = p; q < b && o->n < CR_ED_ROWS; q++)
                        if (ce_kind_eq(d, p, q))
                            o->pg[o->n++] = (uint8_t)q;
                } else if (p + 1u < b && ce_plus_of(d, p, p + 1u)) {   /* "LFO" and "LFO+": edit8, two lanes */
                    o->type = CE_S_EDIT;
                    o->pg[0] = (uint8_t)p;
                    o->pg[1] = (uint8_t)(p + 1u);
                    o->n = 2;
                } else if (ce_percol(&d->pages[p])) {   /* one page across the instances: lane i = column i */
                    o->type = CE_S_TRANS;
                    o->pg[0] = (uint8_t)p;
                    for (q = 0; q < 4u; q++)
                        if (d->pages[p].col[q].label)
                            o->n = (uint8_t)(q + 1u);
                } else {                          /* a page of its own: one lane */
                    o->type = CE_S_PAGE;
                    o->pg[0] = (uint8_t)p;
                    o->n = 1;
                }
            }
            n++;
        }
        for (q = a, e = 0; q < b; q++)
            e += (uint32_t)ce_kind_eq(d, a, q);
        if (g == CE_OSC && ce_inst(d->pages[a].title) && cp_dcol(&d->pages[a], "LEVEL") >= 0 && e <= 4u) {
            /* the mixer (four tall bars: the oscillators' LEVEL; more than four (FM6's six): the stack has them) */
            if (n == k) {
                o->type = CE_S_MIXER;
                for (q = a; q < b && o->n < 4u; q++)
                    if (ce_kind_eq(d, a, q))
                        o->pg[o->n++] = (uint8_t)q;
            }
            n++;
        }
        return n ? n : 1u;
    }
    if (g == CE_MOD && ce_is_matrix(d, a)) {      /* the matrix: eight slots a screen; then Expression */
        for (p = a; p < b; p += CR_ED_ROWS, n++)
            if (n == k) {
                o->type = CE_S_STACK;
                for (q = p; q < b && q < p + CR_ED_ROWS; q++)
                    o->pg[o->n++] = (uint8_t)q;
            }
        if (n == k) {
            o->type = CE_S_EXPR;
            o->n = 2;
        }
        return n + 1u;
    }
    for (p = a; p < b; p = e) {                   /* FILT, ENV (and MOD's plain pages): the pages of one instance
                                                   * and name, two lanes a screen (CZ-1: "PITCH 1" and "DCW 1" apart) */
        for (e = p; e < b && ce_inst(d->pages[e].title) == ce_inst(d->pages[p].title) && ce_name_eq(d, e, p); e++)
            ;
        for (q = p; q < e; q += 2u, n++)
            if (n == k) {
                o->type = CE_S_EDIT;
                o->pg[0] = (uint8_t)q;
                o->pg[1] = (uint8_t)(q + 1u);
                o->n = (uint8_t)(e - q >= 2u ? 2u : 1u);
            }
    }
    if (g == CE_MOD) {                            /* MOD's plain pages (FM6's FUNC, CZ-1's), then Expression */
        if (n == k) {
            o->type = CE_S_EXPR;
            o->n = 2;
        }
        return n + 1u;
    }
    return n ? n : 1u;
}
/* the lanes of a screen */
static uint32_t ce_lanes(const track_t *t, uint32_t g, const ce_scr_t *s)
{
    if (s->type == CE_S_MIXER)
        return 1u;
    if (s->type != CE_S_PLAT)
        return s->n ? s->n : 1u;
    return g == CE_MOD && !ce_has_mod(ce_deep(t)) ? 4u : g == CE_MIX ? 2u : 1u;
}
/* part p's group, screen and lane brought into range (an engine change, a shorter group): *s its screen */
static uint32_t ce_fix(const track_t *t, uint32_t p, ce_scr_t *s)
{
    uint32_t g = cx.grp[p], ns, nl;
    if (g >= CE_NSEC || !ce_has(t, g))
        g = cx.grp[p] = CE_OSC;
    ns = ce_scr(t, g, cx.scr[p][g], s);
    if (cx.scr[p][g] >= ns) {
        cx.scr[p][g] = 0;
        ce_scr(t, g, 0, s);
    }
    nl = ce_lanes(t, g, s);
    if (cx.lane[p][g] >= nl)
        cx.lane[p][g] = (uint8_t)(nl - 1u);
    return g;
}

static ce_ref_t ce_r(uint32_t k, uint32_t a, uint32_t b)
{
    ce_ref_t r;
    r.k = (uint8_t)k;
    r.a = (uint8_t)a;
    r.b = (uint8_t)b;
    return r;
}
static void ce_row_trk(ce_view_t *v, uint32_t row, uint32_t cp)
{
    uint32_t c;
    for (c = 0; c < 4u; c++)
        v->ref[row][c] = ce_r(CE_R_TRK, CP_PAGES[cp].id[c], 0);
}
static void ce_cat_num(char *d, uint32_t n, uint32_t sz)
{
    char b[4];
    uint32_t i = 0;
    if (n >= 10u)
        b[i++] = (char)('0' + n / 10u % 10u);
    b[i++] = (char)('0' + n % 10u);
    b[i] = 0;
    cu_cat(d, b, sz);
}
static void ce_label(const track_t *t, ce_ref_t r, const param_desc_t *d, char *out, uint32_t n);
static const param_desc_t *ce_param(const track_t *t, ce_ref_t r, int32_t *v);
static uint32_t ce_cstyle(const track_t *t, const ce_view_t *vw, uint32_t r, uint32_t c);
/* a stack's column heading: the long label of what the lanes have in column c ("Wave"; two kinds: "Sync/Ring"), its
 * trailing digits cut ("SYNC1" -> "Sync") */
static void ce_head(const track_t *t, const eng_deep_t *d, const ce_view_t *v, uint32_t c, char *out, uint32_t n)
{
    char a[12], b[12];
    uint32_t i, l;
    out[0] = a[0] = b[0] = 0;
    for (i = 0; i < v->n; i++) {
        ce_ref_t r = v->ref[i][c];
        char x[12];
        const param_desc_t *pd;
        int32_t val;
        if (r.k != CE_R_DEEP || !(pd = ce_param(t, r, &val)))
            continue;
        if (cp_eq(d->pages[r.a].col[r.b & 3u].label, "WAVE"))
            pd = &d->pages[r.a].col[r.b & 3u];   /* (the oscillators' modes: "Wave" over WAVE / MORPH / NOISE) */
        ce_label(t, r, pd, x, sizeof x);
        for (l = str_len(x); l > 1u && x[l - 1u] >= '0' && x[l - 1u] <= '9'; l--)
            x[l - 1u] = 0;
        if (!a[0])
            cu_cpy(a, x, sizeof a);
        else if (!cu_eq(a, x) && !b[0])
            cu_cpy(b, x, sizeof b);
    }
    cu_cpy(out, a, n);
    if (b[0]) {
        cu_cat(out, "/", n);
        cu_cat(out, b, n);
    }
}

/* the view of group g's screen k with lane ln on the knobs (ce_view: part p's current one; the MIDI CC blocks walk
 * the lanes with it, ce_cc_lane: the cells a CC reaches are the cells the knobs reach) */
static void ce_view_at(const track_t *t, uint32_t g, uint32_t k, uint32_t ln, ce_view_t *v)
{
    static const char *const ROLE[4] = {"amp", "filter", "free", "free"};
    static const char *const H_MOD[4] = {"Source", "Dest", "Amount", ""};
    const eng_deep_t *d = ce_deep(t);
    const engine_t *en = ENGINES[eng_idx(t->eng_req)];
    ce_scr_t sc;
    uint32_t i, c;
    ce_scr(t, g, k, &sc);
    for (i = 0; i < sizeof *v; i++)
        ((uint8_t *)v)[i] = 0;
    v->kind = CR_K_EDIT8;
    v->n = 1;
    v->active = (uint8_t)ln;
    switch (sc.type) {
    case CE_S_STACK:                              /* OSC / LFO / MOD: a lane per page; a column some lanes lack: "-" */
        v->kind = CR_K_STACK;
        v->n = sc.n;
        for (c = 0; c < 4u; c++) {
            uint32_t any = 0;
            for (i = 0; i < sc.n; i++)
                any |= d->pages[sc.pg[i]].col[c].label != 0;
            for (i = 0; i < sc.n; i++)
                v->ref[i][c] = d->pages[sc.pg[i]].col[c].label ? ce_r(CE_R_DEEP, sc.pg[i], c)
                             : ce_r(any ? CE_R_DASH : CE_R_NONE, 0, 0);
        }
        if (g == CE_MOD) {
            v->row0 = (uint8_t)(k * CR_ED_ROWS);
            for (i = 0; i < sc.n; i++)
                if (!d->get(t, sc.pg[i], 0)) {                /* an unused slot: the source only, a dash */
                    v->ref[i][0] = i == ln ? ce_r(CE_R_DEEP, sc.pg[i], 0) : ce_r(CE_R_DASH, 0, 0);
                    v->ref[i][1] = v->ref[i][2] = v->ref[i][3] = ce_r(CE_R_NONE, 0, 0);
                }
            for (c = 0; c < 4u; c++)
                cu_cpy(v->head[c], H_MOD[c], sizeof v->head[c]);
            cu_cpy(v->right, "MOD ", sizeof v->right);
            ce_cat_num(v->right, v->row0 + ln + 1u, sizeof v->right);
            break;
        }
        for (c = 0; c < 4u; c++)
            ce_head(t, d, v, c, v->head[c], sizeof v->head[c]);
        cu_cpy(v->right, d->pages[sc.pg[0]].title, sizeof v->right);   /* the pages' name: "OSC", FM6's "OP", "SCALE" */
        for (c = 0; v->right[c] && v->right[c] != ' '; c++)
            ;
        v->right[c] = 0;
        cu_cat(v->right, " ", sizeof v->right);
        ce_cat_num(v->right, ln + 1u, sizeof v->right);
        cu_cat(v->right, k ? " \267 B" : " \267 A", sizeof v->right);
        if (k > 1u)
            v->right[str_len(v->right) - 1u] = (char)('A' + k);
        break;
#if CR_LAY_FREE
    case CE_S_FREE: {                             /* a compiled layout's screen: lane i's slots, its title */
        const cr_lay_screen_t *ls = cr_lay_scr(sc.li, sc.ls);
        v->kind = CR_K_FREE;
        v->n = sc.n;
        v->li = sc.li;
        v->ls = sc.ls;
        for (i = 0; i < sc.n && i < CR_ED_ROWS; i++)
            for (c = 0; c < 4u; c++) {
                const cr_lay_elem_t *e = cr_lay_el(sc.li, ls, cr_lay_slot(ls, i, c));
                v->ref[i][c] = !e || e->page == CR_LAY_NONE ? ce_r(CE_R_NONE, 0, 0)
                             : e->page == CR_LAY_PART ? ce_r(CE_R_TRK, e->col, 0) : ce_r(CE_R_DEEP, e->page, e->col);
            }
        cu_cpy(v->right, cr_lay_str(ls->title), sizeof v->right);
        break;
    }
#endif
    case CE_S_TRANS:                              /* "LFO SYN": lane i = its column i */
        v->kind = CR_K_STACK;
        v->n = sc.n;
        for (i = 0; i < sc.n; i++)
            v->ref[i][0] = d->pages[sc.pg[0]].col[i].label ? ce_r(CE_R_DEEP, sc.pg[0], i) : ce_r(CE_R_DASH, 0, 0);
        ce_head(t, d, v, 0, v->head[0], sizeof v->head[0]);
        cu_cpy(v->right, CE_SEC_NAME[g], sizeof v->right);
        cu_cat(v->right, " ", sizeof v->right);
        ce_cat_num(v->right, ln + 1u, sizeof v->right);
        cu_cat(v->right, " \267 B", sizeof v->right);
        v->right[str_len(v->right) - 1u] = (char)('A' + (k > 25u ? 25u : k));
        break;
    case CE_S_MIXER:                              /* the oscillators' levels, four tall bars */
        v->tall = 1;
        v->active = 0;
        for (i = 0; i < sc.n && i < 4u; i++) {
            int32_t col = cp_dcol(&d->pages[sc.pg[i]], "LEVEL");
            v->ref[0][i] = col >= 0 ? ce_r(CE_R_DEEP, sc.pg[i], (uint32_t)col) : ce_r(CE_R_DASH, 0, 0);
        }
        cu_cpy(v->right, "OSC \267 MIX", sizeof v->right);
        break;
    case CE_S_PAGE:                               /* a page of its own ("VOICE"): one lane, its title on the right */
        for (c = 0; c < 4u; c++)
            v->ref[0][c] = d->pages[sc.pg[0]].col[c].label ? ce_r(CE_R_DEEP, sc.pg[0], c) : ce_r(CE_R_NONE, 0, 0);
        cu_cpy(v->right, d->pages[sc.pg[0]].title, sizeof v->right);
        break;
    case CE_S_EXPR:                               /* Expression: VEL and AT to a destination by an amount (mod.c slots
                                                   * 3 and 4; an unset slot shows its default: "AMP auto" / "CUT auto") */
        v->kind = CR_K_STACK;
        v->n = 2;
        v->expr = 1;
        for (c = 0; c < 4u; c++)
            cu_cpy(v->head[c], H_MOD[c], sizeof v->head[c]);
        for (i = 0; i < 2u; i++) {
            uint32_t src = i ? P_MAT_SRC : P_MVEL_SRC;
            v->ref[i][0] = ce_r(CE_R_TXT, i ? CE_T_AT : CE_T_VEL, 0);
            if (t->p[src]) {
                v->ref[i][1] = ce_r(CE_R_TRK, src + 1u, 0);
                v->ref[i][2] = ce_r(CE_R_TRK, src + 2u, 0);
            } else {
                v->ref[i][1] = ce_r(CE_R_TXT, i ? CE_T_CUT : CE_T_AMP, 0);
                v->ref[i][2] = ce_r(CE_R_TXT, CE_T_AUTO, 0);
            }
        }
        cu_cpy(v->right, "EXPR \267 ", sizeof v->right);
        cu_cat(v->right, ln ? "AT" : "VEL", sizeof v->right);
        break;
    case CE_S_EDIT:                               /* FILT / ENV n: the instance's pages under the wide band */
        v->n = sc.n;
        for (i = 0; i < sc.n; i++)
            for (c = 0; c < 4u; c++)
                v->ref[i][c] = d->pages[sc.pg[i]].col[c].label ? ce_r(CE_R_DEEP, sc.pg[i], c) : ce_r(CE_R_NONE, 0, 0);
        if (ce_plan(d, sc.hs)) {                  /* the engine's plan: its band and title ("SYN 1 \267 A") */
            static const uint8_t W[7] = {CR_W_NONE, CR_W_ENV, CR_W_FILTER, CR_W_FILTER, CR_W_ALGO, CR_W_ADE2, CR_W_WAVE};
            const eng_screen_t *h = ce_plan(d, sc.hs);
            v->hs = sc.hs;
            v->wide = h->band < 7u ? W[h->band] : (uint8_t)CR_W_NONE;
            v->dp0 = sc.pg[0];
            v->np = sc.n;
            cu_cpy(v->right, h->title ? h->title : d->pages[sc.pg[0]].title, sizeof v->right);
            if (h->letter && sc.n > 1u)
                cu_cat(v->right, ln ? " \267 B" : " \267 A", sizeof v->right);
        } else if (g == CE_ENV && ce_is_cz(d, sc.pg[0], &c, &i)) {   /* CZ-1: a step envelope under the "cz" band */
            static const char *const PART[3] = {" \267 1-4", " \267 5-8", " \267 END"};
            v->wide = CR_W_CZ;
            v->dp0 = (uint8_t)c;
            v->np = (uint8_t)i;
            cu_cpy(v->right, d->pages[c].title, sizeof v->right);   /* "DCW 1" */
            cu_cat(v->right, PART[(sc.pg[0] - c) / 2u > 2u ? 2u : (sc.pg[0] - c) / 2u], sizeof v->right);
        } else if (g == CE_ENV && ce_is_dx(d, sc.pg[0])) {   /* FM6: R1..R4 / L1..L4 under the "dx" band */
            uint32_t n = ce_inst(d->pages[sc.pg[0]].title);
            v->wide = CR_W_DX;
            v->dp0 = sc.pg[0];
            v->np = sc.n;
            if (n) {
                cu_cpy(v->right, "ENV ", sizeof v->right);
                ce_cat_num(v->right, n, sizeof v->right);
            } else {
                cu_cpy(v->right, d->pages[sc.pg[0]].title, sizeof v->right);   /* "PITCH EG" */
            }
        } else if (g == CE_ENV) {
            uint32_t n = ce_inst(d->pages[sc.pg[0]].title);
            v->wide = CR_W_ENV;
            v->dp0 = sc.pg[0];
            v->np = sc.n;
            cu_cpy(v->right, "ENV ", sizeof v->right);
            ce_cat_num(v->right, n ? n : k + 1u, sizeof v->right);
            if (n >= 1u && n <= 4u) {
                cu_cat(v->right, " \267 ", sizeof v->right);
                cu_cat(v->right, ROLE[n - 1u], sizeof v->right);
            }
        } else if (g != CE_FILT || cp_dcol(&d->pages[sc.pg[0]], "CUT") < 0) {   /* no filter (FM6's ALGO, LFO,
                                                                              * FUNC): no band, the page's title */
            cu_cpy(v->right, d->pages[sc.pg[0]].title, sizeof v->right);
        } else {
            uint32_t a, b;
            ce_range(d, CE_FILT, &a, &b);
            v->wide = CR_W_FILTER;
            v->dp0 = (uint8_t)a;
            cu_cpy(v->right, "FILTER", sizeof v->right);
            (void)b;
        }
        break;
    default:                                      /* the platform's pages */
        switch (g) {
        case CE_OSC:
            ce_row_trk(v, 0, CP_EDIT1);
            cu_cpy(v->right, en->page_title[0] ? en->page_title[0] : "EDIT 1", sizeof v->right);
            break;
        case CE_FILT:
            ce_row_trk(v, 0, CP_EDIT2);
            cu_cpy(v->right, en->page_title[1] ? en->page_title[1] : "EDIT 2", sizeof v->right);
            break;
        case CE_ENV:
            v->wide = CR_W_ENV;
            ce_row_trk(v, 0, CP_ENV);
            cu_cpy(v->right, "ENV", sizeof v->right);
            break;
        case CE_LFO:
            ce_row_trk(v, 0, CP_LFO);
            cu_cpy(v->right, "LFO", sizeof v->right);
            break;
        case CE_MOD:
            v->kind = CR_K_STACK;
            v->n = 4;
            for (c = 0; c < 4u; c++)
                cu_cpy(v->head[c], H_MOD[c], sizeof v->head[c]);
            for (i = 0; i < 4u; i++) {
                v->ref[i][0] = ce_r(CE_R_TXT, CE_PMOD[i][0], 0);
                v->ref[i][1] = ce_r(CE_R_TXT, CE_PMOD[i][1], 0);
                v->ref[i][2] = ce_r(CE_R_TRK, CP_PAGES[CP_MOD].id[i], 0);
            }
            cu_cpy(v->right, "MOD ", sizeof v->right);
            ce_cat_num(v->right, ln + 1u, sizeof v->right);
            break;
        case CE_FX:
            ce_row_trk(v, 0, CP_FX);
            cu_cpy(v->right, "FX", sizeof v->right);
            break;
        default:
            v->n = 2;
            ce_row_trk(v, 0, CP_MIX);
            ce_row_trk(v, 1, CP_MIX2);
            cu_cpy(v->right, "MIX", sizeof v->right);
            break;
        }
        break;
    }
    if (v->active >= v->n)
        v->active = 0;
}
static void ce_view(const track_t *t, uint32_t p, ce_view_t *v)
{
    ce_scr_t sc;
    uint32_t g = ce_fix(t, p, &sc);
    ce_view_at(t, g, cx.scr[p][g], cx.lane[p][g], v);
}

/* a ref that is one of the part's sends (cr_ui.c cu_send: P_DIST .. P_REV), -1: not one. The FX group's four, and a
 * deep column an engine maps onto the part's parameter: FM TONE's AMP+ DRIVE is P_DIST (eng_quad.c QUAD_XDIST). On an
 * FM TONE part that P_DIST is the SOUND's Drive (cr_ui.c "FM TONE'S DRIVE IS ITS PRESET'S"): cu_send / cu_send_set
 * know, so the AMP cell, the FX group's Drive and the FX layer's Drive are still one value */
static int32_t ce_send_ref(const track_t *t, ce_ref_t r)
{
    if (r.k == CE_R_TRK && r.a >= P_DIST && r.a <= P_REV)
        return (int32_t)r.a;
#if FELUCCA_QUAD
    if (r.k == CE_R_DEEP && eng_idx(t->eng_req) == ENGI_QUAD && quad_index(r.a, r.b & 3u) == QUAD_XDIST)
        return P_DIST;
#endif
    (void)t;
    return -1;
}

/* the parameter of a ref: its descriptor and value (0: none) */
static const param_desc_t *ce_param(const track_t *t, ce_ref_t r, int32_t *v)
{
    const eng_deep_t *d = cp_deep(t);
    int32_t snd = ce_send_ref(t, r);              /* a send: the part's one value, not the track's copy */
    if (r.k == CE_R_DEEP && d && r.a < d->npages && d->pages[r.a].col[r.b & 3u].label) {
        *v = snd >= 0 ? cu_send(t == &trk[CR_PART_BASS], (uint32_t)snd) : d->get(t, r.a, r.b & 3u);
        if (d->desc) {                                          /* a mode-dependent label / names (the VA's MORPH) */
            const param_desc_t *m = d->desc(t, r.a, r.b & 3u);
            if (m)
                return m;
        }
        return &d->pages[r.a].col[r.b & 3u];
    }
    if (r.k == CE_R_TRK && r.a < P_COUNT) {
        *v = snd >= 0 ? cu_send(t == &trk[CR_PART_BASS], (uint32_t)snd) : t->p[r.a];
        return cp_desc(t, r.a);
    }
    return 0;
}

/* the value text as the mock-ups write it: "683 ms", "643 Hz", "+7", "-12", "on" (Felucca's numbers and names) */
static void ce_text(const track_t *t, ce_ref_t r, const param_desc_t *d, int32_t v, char *out, uint32_t n)
{
    char val[12];
    const char *unit;
    uint32_t i, l;
    if (r.k == CE_R_TRK && ce_send_ref(t, r) >= 0) {             /* the FX group's four: a send's one read-out */
        cu_send_text(v, out, n);
        return;
    }
    if (r.k == CE_R_TRK && (r.a == P_MVEL_SRC + 2u || r.a == P_MAT_SRC + 2u)) {   /* the EXPR amounts: the number
                                                                 * (-64 .. +63), a detent reads as one (the owner,
                                                                 * 2026-10-15: the percentage moved by one or two) */
        cu_int(out, v, 1, n);
        return;
    }
    param_format(d, v, val, &unit);
    (void)t;                                                    /* (a synced VA LFO's RATE: its descriptor is the
                                                                 * division list, eng_va.c va_desc) */
    (void)r;
    if (d->fmt == F_SEMI || d->fmt == F_DB || (d->fmt == F_INT && d->unit && cu_eq(d->unit, "ct")))
        unit = "";                                              /* (coarse / fine / transpose / level: the number) */
    if (val[0] == '.') {                                        /* ".69" -> "0.69" */
        for (l = str_len(val) + 1u; l > 0u && l < sizeof val; l--)
            val[l] = val[l - 1u];
        val[0] = '0';
    }
    if (d->fmt == F_INT && d->min < 0 && v > 0) {
        cu_cpy(out, "+", n);
        cu_cat(out, val, n);
    } else {
        cu_cpy(out, val, n);
    }
    if (d->fmt == F_ONOFF)
        for (i = 0; out[i]; i++)
            out[i] = (char)(out[i] >= 'A' && out[i] <= 'Z' ? out[i] + 32 : out[i]);
    l = str_len(out);
    if (unit[0] && l + 1u + str_len(unit) + 1u <= n && (d->fmt == F_TIME || d->fmt == F_TIMEI || d->fmt == F_GLIDE || d->fmt == F_LFOHZ || d->fmt == F_CUTOFF)) {
        cu_cat(out, " ", n);
        cu_cat(out, unit, n);
    } else if (unit[0] && l + str_len(unit) + 1u <= n) {
        cu_cat(out, unit, n);
    }
}

/* a parameter's long label: cr_pages.c's tables, else its short one capitalised ("SYNC1" -> "Sync1") */
#ifdef CR_LAYOUT_PREVIEW
/* (the layout tool's preview only, docs/LAYOUT-TOOL.md: a design's own label for deep page p's column c, 1 = given) */
static int (*ce_label_hook)(const track_t *t, uint32_t p, uint32_t c, char *out, uint32_t n);
/* (.. and a design's own cell style for deep page p's column c (ENG_C_*, 0 = the editor's rule): its p5 styles on an
 * edit8 screen, in place or in a plan (a plan's cell[][] has them too) */
static uint32_t (*ce_style_hook)(const track_t *t, uint32_t p, uint32_t c);
#endif
static void ce_label(const track_t *t, ce_ref_t r, const param_desc_t *d, char *out, uint32_t n)
{
    uint32_t i;
#ifdef CR_LAYOUT_PREVIEW
    if (ce_label_hook && r.k == CE_R_DEEP && ce_label_hook(t, r.a, r.b & 3u, out, n))
        return;
#endif
    if (r.k == CE_R_TRK)
        for (i = 0; i < NELEM(CP_LABEL); i++)
            if (CP_LABEL[i].id == r.a) {
                cu_cpy(out, CP_LABEL[i].label, n);
                return;
            }
    for (i = 0; i < NELEM(CP_DLABEL); i++)
        if (cp_eq(d->label, CP_DLABEL[i].s)) {
            cu_cpy(out, CP_DLABEL[i].l, n);
            return;
        }
    cu_cpy(out, d->label, n);
    for (i = 1; out[i]; i++)
        if (out[i] >= 'A' && out[i] <= 'Z')
            out[i] = (char)(out[i] + 32);
    (void)t;
}

static uint8_t ce_pct(const param_desc_t *d, int32_t v)
{
    uint32_t q = cp_q8(d, v);
    return (uint8_t)(q > 255u ? 255u : q);
}

/* one cell: label (edit8), value, its glyph and fill (the mock-ups' choice by the kind of parameter) */
static void ce_cell(const track_t *t, const ce_view_t *vw, ce_ref_t r, cr_cell_t *c)
{
    const param_desc_t *d;
    int32_t v = 0;
    int stack = vw->kind == CR_K_STACK;
    if (r.k == CE_R_NONE)
        return;
    c->flags = CR_CF_ON;
    if (r.k == CE_R_DASH) {
        cu_cpy(c->value, "-", sizeof c->value);
        return;
    }
    if (r.k == CE_R_TXT) {
        cu_cpy(c->value, CE_TXT[r.a % NELEM(CE_TXT)], sizeof c->value);
        return;
    }
    if (!(d = ce_param(t, r, &v))) {
        c->flags = 0;
        return;
    }
    if (!stack)
        ce_label(t, r, d, c->label, sizeof c->label);
    ce_text(t, r, d, v, c->value, sizeof c->value);
    c->pct = ce_pct(d, v);
    if (r.k == CE_R_DEEP && cp_eq(cp_deep(t)->pages[r.a].col[r.b & 3u].label, "WAVE") && cp_eq(d->label, "MORPH")) {
        const eng_deep_t *dd = cp_deep(t);                       /* the VA's MORPH: the morphed wave at its position */
        int32_t m = d->max > d->min ? (v - d->min) * 127 / (d->max - d->min) : 0, k;
        if (d->fmt == F_ENUM && r.a + 1u < dd->npages && (k = cp_dcol(&dd->pages[r.a + 1u], "SHAPE")) >= 0)
            m = dd->get(t, r.a + 1u, (uint32_t)k);              /* (an older table: the position is OSC n+'s SHAPE) */
        c->glyph = CR_G_MORPH;
        c->pct = (uint8_t)(clamp(m, 0, 127) * 255 / 127);
        if (d->fmt == F_INT && d->names && d->max > d->min) {   /* the position's name, whole ("SAW>RMP"; params.c's
                                                                 * F_INT list: n names over the range) */
            uint32_t n = 0;
            while (d->names[n])
                n++;
            if (n)
                cu_cpy(c->value, d->names[(uint32_t)(clamp(v, d->min, d->max) - d->min) * n / (uint32_t)(d->max - d->min + 1)],
                       sizeof c->value);
        }
    } else if (r.k == CE_R_DEEP && cp_eq(cp_deep(t)->pages[r.a].col[r.b & 3u].label, "WAVE")
               && (cp_eq(d->label, "NOISE") || cp_eq(d->label, "NTYPE"))) {
        c->glyph = CR_G_NOISE;                                    /* NOISE: WHITE BROWN VINYL */
        c->pct = (uint8_t)(cp_has(c->value, "BRO") ? 128u : cp_has(c->value, "VIN") ? 255u : 0u);
    } else if (d->fmt == F_ENUM && cp_has(d->label, "WAVE")) {   /* the selected waveform */
        const char *w = c->value;
        c->pct = 128;
        c->glyph = cp_has(w, "SAW") || cp_has(w, "RMP") ? CR_G_SAW
                 : cp_has(w, "SQ") || cp_has(w, "PUL") || cp_has(w, "PW") ? CR_G_SQUARE
                 : cp_has(w, "NOI") || cp_has(w, "NZ") ? CR_G_DOTS
                 : cp_has(w, "S&H") || cp_has(w, "RND") || cp_has(w, "STEP") ? CR_G_STEPS
                 : cp_has(w, "TRI") ? CR_G_MORPH          /* (the triangle: the morph glyph at 24) */
                 : CR_G_WAVE;
        if (c->glyph == CR_G_MORPH)
            c->pct = 24 * 255 / 127;
        if (cp_has(w, "PW") && r.k == CE_R_DEEP) {               /* PWM: the width is the oscillator's SHAPE */
            const eng_deep_t *dd = cp_deep(t);
            int32_t k = r.a + 1u < dd->npages ? cp_dcol(&dd->pages[r.a + 1u], "SHAPE") : -1;
            if (k >= 0)
                c->pct = ce_pct(&dd->pages[r.a + 1u].col[k], dd->get(t, r.a + 1u, (uint32_t)k));
        }
    } else if (cp_eq(d->label, "FTYPE")) {                      /* the filter's position: its name, a cycle of dots */
        c->glyph = CR_G_DOTS;
        c->flags |= CR_CF_PCT;
        cu_cpy(c->value, cr_ftype_name((uint32_t)v), sizeof c->value);
    } else if (d->fmt == F_ENUM && cp_eq(d->label, "TYPE")) {
        c->glyph = CR_G_DOTS;
        c->flags |= CR_CF_PCT;
    } else if (d->fmt == F_ENUM || d->fmt == F_ONOFF) {
        ;                                                         /* text */
    } else if (d->fmt == F_LFOHZ) {
        c->glyph = CR_G_KNOB;
        c->flags |= CR_CF_PCT;
    } else if (stack && (d->fmt == F_SEMI || d->fmt == F_INT)) {
        ;                                                         /* coarse / fine: the number */
    } else {
        c->glyph = CR_G_BAR;
        c->flags |= CR_CF_PCT | (d->min < 0 ? CR_CF_BIP : 0u);
    }
}

/* ------------------------------------------------------------- the state --- */
/* the ENV n / LFO n the current group shows (its lane's instance), remembered for the quick mapping */
static void ce_msrc_note(void)
{
    track_t *t = ce_trk();
    const eng_deep_t *d = ce_deep(t);
    uint32_t p = ce.part & 1u, g = cx.grp[p] % CE_NSEC, n = 0, ln = cx.lane[p][g];
    ce_scr_t sc;
    if (!d || (g != CE_ENV && g != CE_LFO))
        return;
    ce_scr(t, g, cx.scr[p][g], &sc);
    if (sc.type == CE_S_EDIT || sc.type == CE_S_PAGE)
        n = ce_inst(d->pages[sc.pg[0]].title);
    else if (sc.type == CE_S_STACK)
        n = ce_inst(d->pages[sc.pg[ln < sc.n ? ln : 0u]].title);
    else if (sc.type == CE_S_TRANS)
        n = ln + 1u;
    if (n >= 1u && n <= 9u)
        cx.msrc[p][g == CE_LFO] = (uint8_t)n;
}
static void ce_trace_nav(void)
{
    ce_msrc_note();
    uint32_t p = ce.part & 1u, g = cx.grp[p] % CE_NSEC;
    cu_trace("edit: group %s screen %u lane %u part %u\n", CE_SEC_NAME[g], (unsigned)cx.scr[p][g] + 1u,
             (unsigned)cx.lane[p][g] + 1u, (unsigned)p);
    (void)p;
    (void)g;
}

static void ce_open(uint32_t part)
{
    ce_scr_t sc;
    ce.part = (uint8_t)(part & 1u);
    cu.opt_open = 0;
    cu.lock = L_NONE;
    cu.page = PG_EDIT;
    cx.hot_r = 0;
    cx.shift = 0;
    ce_fix(ce_trk(), ce.part, &sc);
    cu_trace("edit: open part %u\n", (unsigned)ce.part);
    ce_trace_nav();
}
static void ce_close(void)
{
    if (cu.page == PG_EDIT)
        cu.page = PG_NONE;
    cx.shift = 0;
    cu_trace("edit: close\n");
}

/* a group's button tapped: another group opens (where it was left), the same one cycles its screens */
static void ce_group(uint32_t g)
{
    track_t *t = ce_trk();
    uint32_t p = ce.part & 1u, ns, nl;
    ce_scr_t sc;
    if (!ce_has(t, g)) {
        cu_message("FM6: own envelopes", CR_COL_WHITE);
        return;
    }
    if (cx.grp[p] != g) {
        cx.grp[p] = (uint8_t)g;
        ce_fix(t, p, &sc);
    } else {
        ns = ce_scr(t, g, 0, &sc);
        cx.scr[p][g] = (uint8_t)((cx.scr[p][g] + 1u) % ns);
        ce_scr(t, g, cx.scr[p][g], &sc);
        nl = ce_lanes(t, g, &sc);
        if (cx.lane[p][g] >= nl)                  /* (the lane kept: OSC 3 stays OSC 3 on the next stack) */
            cx.lane[p][g] = (uint8_t)(nl - 1u);
    }
    cx.hot_r = 0;
    ce_trace_nav();
}

static int ce_owns(uint32_t b)
{
    uint32_t s;
    if (cu.page != PG_EDIT)
        return 0;
    if (b == B_GLO)
        return 1;
    for (s = 0; s < CE_NSEC; s++)
        if (CE_SEC_BTN[s] == b)
            return 1;
    return 0;
}

/* THE FILTER PICKER: the engine's filter type, the FILT section's F_ENUM column "TYPE" (FM TONE's FILTER+ TYPE); 0
 * none (that engine's SEL hold stays reserved). *col with ENG_COL_RAW where the cell shows another value by the type
 * (FM TONE's machines: MORPH, LPF, Q; 3y217): the picker reads and sets the type itself, the way back to LP / HP / OFF */
static const param_desc_t *ce_ftype(const track_t *t, uint32_t *pg, uint32_t *col)
{
    const eng_deep_t *d = ce_deep(t);
    uint32_t a, b;
    int32_t k;
    if (!d)
        return 0;
    ce_range(d, CE_FILT, &a, &b);
    for (*pg = a; *pg < b; (*pg)++)
        if ((k = cp_dcol(&d->pages[*pg], "TYPE")) >= 0 && d->pages[*pg].col[k].fmt == F_ENUM && d->pages[*pg].col[k].names) {
            const param_desc_t *m = d->desc ? d->desc(t, *pg, (uint32_t)k) : 0;
            *col = (uint32_t)k | (m && m != &d->pages[*pg].col[k] ? ENG_COL_RAW : 0u);
            return &d->pages[*pg].col[k];
        }
    return 0;
}
/* SEL down on an engine with a filter type (the picker's knobs and SELECT) */
static int ce_fheld(void)
{
    uint32_t pg, col;
    return cu.page == PG_EDIT && cu.armed == B_SCL && ((cu.bheld >> B_SCL) & 1u) && ce_ftype(ce_trk(), &pg, &col);
}
/* the picker up (FILT the group), the type stepped s (0: only opened) */
static void ce_fpick(int32_t s)
{
    track_t *t = ce_trk();
    const eng_deep_t *d = ce_deep(t);
    uint32_t pg, col, p = ce.part & 1u;
    const param_desc_t *c = ce_ftype(t, &pg, &col);
    int32_t v0, v;
    ce_scr_t sc;
    if (!c)
        return;
    if (!cx.fpick || cx.grp[p] != CE_FILT) {
        cx.fpick = 1;
        if (cx.grp[p] != CE_FILT) {
            cx.grp[p] = CE_FILT;
            ce_fix(t, p, &sc);
        }
        cx.hot_r = 0;
        cu_trace("edit: filter picker\n");
    }
    if (!s)
        return;
    v0 = d->get(t, pg, col);
    v = clamp(v0 + s, c->min, c->max);
    if (v == v0)
        return;
    d->set(t, pg, col, v);
    ce_ftype(t, &pg, &col);                       /* (into or out of a machine: the type's column again) */
    v = d->get(t, pg, col);
    cu_edited(ce.part);
    cu_trace("deep: part %u page %u %s col %u %s %d -> %d (%s)%s\n", (unsigned)ce.part, (unsigned)pg, d->pages[pg].title,
             (unsigned)(col & 3u), c->label, (int)v0, (int)v, c->names[v], psnd[ce.part].edited ? " edited" : "");
}

static int ce_button(uint32_t b, uint32_t ev)
{
    uint32_t s;
    if (cu.page != PG_EDIT)
        return 0;
    if (ev == CE_SHIFT) {                         /* SHIFT + EDIT: the other part's sound, where it was left */
        ce.part ^= 1u;
        cx.hot_r = 0;
        cu_trace("edit: part %u\n", (unsigned)ce.part);
        ce_trace_nav();
        return 1;
    }
    if (b == BT_EDIT && ev == CE_TAP) {
        ce_close();
        return 1;
    }
    if (b == B_GLO) {                             /* SHIFT: a tap latches / unlatches it; held: momentary */
        if (ev == CE_TAP) {
            cx.shift ^= 1u;
            cu_trace("edit: shift %s\n", cx.shift ? "latched" : "off");
        }
        return 1;
    }
    for (s = 0; s < CE_NSEC; s++)
        if (CE_SEC_BTN[s] == b) {
            if (ev == CE_TAP)                     /* (held: nothing, reserved; SEL: the filter picker) */
                ce_group(s);
            else if (ev == CE_HOLD && b == B_SCL)
                ce_fpick(0);
            return 1;
        }
    return 0;                                     /* SAVE, PERF, HOME, OCT: as outside */
}

/* SELECT: s lanes on (both ways round), across the group's screens (wrapping) */
static void ce_select(int32_t s)
{
    track_t *t = ce_trk();
    uint32_t p = ce.part & 1u, g, ns, k, ln, k0, l0;
    ce_scr_t sc;
    if (ce_fheld()) {                             /* SEL held: the filter picker's */
        ce_fpick(s);
        return;
    }
    g = ce_fix(t, p, &sc);
    ns = ce_scr(t, g, 0, &sc);
    k = k0 = cx.scr[p][g];
    ln = l0 = cx.lane[p][g];
    ce_scr(t, g, k, &sc);
    for (; s > 0; s--) {
        if (ln + 1u < ce_lanes(t, g, &sc)) {
            ln++;
        } else {
            k = (k + 1u) % ns;
            ln = 0;
            ce_scr(t, g, k, &sc);
        }
    }
    for (; s < 0; s++) {
        if (ln) {
            ln--;
        } else {
            k = (k + ns - 1u) % ns;
            ce_scr(t, g, k, &sc);
            ln = ce_lanes(t, g, &sc) - 1u;
        }
    }
    if (k == k0 && ln == l0)
        return;
    cx.scr[p][g] = (uint8_t)k;
    cx.lane[p][g] = (uint8_t)ln;
    cx.hot_r = 0;
    ce_trace_nav();
}

/* ------------------------------------------------- the quick mapping --- */
/* the matrix: the MOD section's pages with SRC DST AMT columns (eng_deep_t; their values are the engine's numbers) */
typedef struct { uint8_t pg; int8_t cs, cd, ca; } ce_slot_t;
static int ce_slot(const eng_deep_t *d, uint32_t pg, ce_slot_t *o)
{
    o->pg = (uint8_t)pg;
    o->cs = (int8_t)cp_dcol(&d->pages[pg], "SRC");
    o->cd = (int8_t)cp_dcol(&d->pages[pg], "DST");
    o->ca = (int8_t)cp_dcol(&d->pages[pg], "AMT");
    return o->cs >= 0 && o->cd >= 0 && o->ca >= 0;
}
/* the matrix's destination of a cell's parameter, -1 none */
static int32_t ce_dst(const track_t *t, ce_ref_t r)
{
    const eng_deep_t *d = ce_deep(t);
    if (!d || !d->mod_dst)
        return -1;
    if (r.k == CE_R_DEEP)
        return d->mod_dst(t, r.a, r.b & 3u);
    return r.k == CE_R_TRK ? d->mod_dst(t, ENG_MOD_TRK, r.a) : -1;
}
/* a source's name in the SRC column ("ENV2", "LFO1"), its value, -1 none */
static int32_t ce_src_of(const eng_deep_t *d, const ce_slot_t *sl, const char *name)
{
    const param_desc_t *c = &d->pages[sl->pg].col[(uint32_t)sl->cs];
    int32_t v;
    for (v = c->min; c->names && v <= c->max; v++)
        if (c->names[v] && cp_eq(c->names[v], name))
            return v;
    return -1;
}
static const char *ce_name_of(const eng_deep_t *d, uint32_t pg, uint32_t col, int32_t v)
{
    const param_desc_t *c = &d->pages[pg].col[col & 3u];
    return c->names && v >= c->min && v <= c->max && c->names[v] ? c->names[v] : "?";
}
/* a destination's name ("CUT") */
static const char *ce_dst_name(const eng_deep_t *d, int32_t dst)
{
    uint32_t a, b, pg;
    ce_slot_t sl;
    ce_range(d, CE_MOD, &a, &b);
    for (pg = a; pg < b; pg++)
        if (ce_slot(d, pg, &sl))
            return ce_name_of(d, pg, (uint32_t)sl.cd, dst);
    return "?";
}
/* a source's colour (its name: ENV yellow, LFO red, the player's VEL KEY RAND MODW blue) */
static uint32_t ce_src_col(const char *n)
{
    return cp_has(n, "ENV") ? CR_COL_YELLOW : cp_has(n, "LFO") ? CR_COL_RED : CR_COL_BLUE;
}
/* "ENV2 -> CUT +12 slot 1" (the trace, the hot cell's "ENV2 +12"); an amount column in hundredths (F_FIX2: the VA's
 * AMT, tenths below 6) without its zeros: "LFO1 +0.3", "LFO1 +12" */
static void ce_amt_text(char *o, const char *src, const param_desc_t *c, int32_t v, uint32_t n)
{
    char b[8];
    uint32_t u = (uint32_t)(v < 0 ? -v : v);
    cu_cpy(o, src, n);
    cu_cat(o, " ", n);
    if (c->fmt != F_FIX2 || !(u % 100u)) {
        cu_int(b, c->fmt == F_FIX2 ? v / 100 : v, 1, sizeof b);
        cu_cat(o, b, n);
        return;
    }
    cu_cat(o, v < 0 ? "-" : "+", n);
    cu_int(b, (int32_t)(u / 100u), 0, sizeof b);
    cu_cat(o, b, n);
    b[0] = '.';
    b[1] = (char)('0' + u / 10u % 10u);
    b[2] = (char)(u % 10u ? '0' + u % 10u : 0);
    b[3] = 0;
    cu_cat(o, b, n);
}

/* ENV (env 1) or LFO (env 0) held + KNOB k turned s: the last ENV n / LFO n shown modulates the parameter under k */
static void ce_map(uint32_t knob, int32_t s, uint32_t snap, uint32_t env)
{
    track_t *t = ce_trk();
    const eng_deep_t *d = ce_deep(t);
    uint32_t p = ce.part & 1u, a, b, pg, n;
    int32_t dst, src = -1, amt0, amt;
    ce_view_t vw;
    ce_slot_t sl, use;
    char nm[8], tx[12];
    ce_view(t, p, &vw);
    dst = ce_dst(t, vw.ref[vw.active][knob & 3u]);
    use.pg = 0xFF;
    if (dst <= 0 || !d) {
        cu_message("not modulatable", CR_COL_WHITE);
        cu_trace("mod: not modulatable\n");
        return;
    }
    n = cx.msrc[p][!env] ? cx.msrc[p][!env] : env ? 2u : 1u;
    cu_cpy(nm, env ? "ENV" : "LFO", sizeof nm);
    ce_cat_num(nm, n, sizeof nm);
    ce_range(d, CE_MOD, &a, &b);
    for (pg = a; pg < b; pg++) {                  /* that source to that destination, else the first free slot */
        if (!ce_slot(d, pg, &sl))
            continue;
        if (src < 0)
            src = ce_src_of(d, &sl, nm);
        if (d->get(t, pg, (uint32_t)sl.cd) == dst && d->get(t, pg, (uint32_t)sl.cs) == src) {
            use = sl;
            break;
        }
        if (use.pg == 0xFF && (!d->get(t, pg, (uint32_t)sl.cs) || !d->get(t, pg, (uint32_t)sl.cd)))
            use = sl;
    }
    if (src <= 0) {
        cu_message("not modulatable", CR_COL_WHITE);
        cu_trace("mod: not modulatable\n");
        return;
    }
    if (use.pg == 0xFF) {
        cu_message("matrix full", CR_COL_RED);
        cu_trace("mod: %s -> %s matrix full\n", nm, ce_dst_name(d, dst));
        return;
    }
    if (d->get(t, use.pg, (uint32_t)use.cs) != src || d->get(t, use.pg, (uint32_t)use.cd) != dst) {   /* a free slot */
        d->set(t, use.pg, (uint32_t)use.ca, 0);
        d->set(t, use.pg, (uint32_t)use.cs, src);
        d->set(t, use.pg, (uint32_t)use.cd, dst);
    }
    amt0 = d->get(t, use.pg, (uint32_t)use.ca);
    amt = cp_dstep(&d->pages[use.pg].col[(uint32_t)use.ca], amt0, s, snap || cx.shift);
    if (amt != amt0)
        d->set(t, use.pg, (uint32_t)use.ca, amt);
    amt = d->get(t, use.pg, (uint32_t)use.ca);
    cu_edited(ce.part);
    cx.hot_r = (uint8_t)(vw.active + 1u);
    cx.hot_c = (uint8_t)(knob & 3u);
    cx.hot_t0 = cu_now();
    cx.hot_slot = (uint8_t)(use.pg + 1u);
    cx.hot_src = (uint8_t)src;
    ce_amt_text(tx, nm, &d->pages[use.pg].col[(uint32_t)use.ca], amt, sizeof tx);
    cu_trace("mod: %s -> %s %s slot %u\n", nm, ce_name_of(d, use.pg, (uint32_t)use.cd, dst), tx + str_len(nm) + 1u,
             (unsigned)(use.pg - a + 1u));
    (void)tx;
}

/* OCT- held + KNOB k turned: every matrix slot to the parameter under k cleared */
static void ce_unmap(uint32_t knob)
{
    track_t *t = ce_trk();
    const eng_deep_t *d = ce_deep(t);
    uint32_t a, b, pg, n = 0;
    int32_t dst;
    ce_view_t vw;
    ce_slot_t sl;
    ce_view(t, ce.part & 1u, &vw);
    dst = ce_dst(t, vw.ref[vw.active][knob & 3u]);
    if (dst <= 0 || !d) {
        cu_message("not modulatable", CR_COL_WHITE);
        cu_trace("mod: not modulatable\n");
        return;
    }
    ce_range(d, CE_MOD, &a, &b);
    for (pg = a; pg < b; pg++)
        if (ce_slot(d, pg, &sl) && d->get(t, pg, (uint32_t)sl.cd) == dst) {
            d->set(t, pg, (uint32_t)sl.ca, 0);
            d->set(t, pg, (uint32_t)sl.cs, 0);
            d->set(t, pg, (uint32_t)sl.cd, 0);
            n++;
        }
    if (n)
        cu_edited(ce.part);
    cx.hot_r = 0;
    cu_message(n ? "cleared" : "no modulation", CR_COL_WHITE);
    cu_trace("mod: clear %s, %u slots\n", ce_dst_name(d, dst), (unsigned)n);
}

/* the editor's modifiers on the knobs: ENV / LFO held (the quick mapping), OCT- held (clear), SEL held (the filter
 * picker); 0 none */
static uint32_t ce_kmod(void)
{
    if ((cu.bheld >> B_OCTDN) & 1u)
        return 3u;
    if (ce_fheld())
        return 4u;
    if (cu.armed == B_ENV && ((cu.bheld >> B_ENV) & 1u))
        return 1u;
    if (cu.armed == B_LFO && ((cu.bheld >> B_LFO) & 1u))
        return 2u;
    return 0;
}

/* a ratio pair (QUAD's RATIO B): an F_INT column of k names over k x k values, v - min = slow x k + fast: the fast
 * hand names[v % k] (the numerator, on top: QUAD's B2), the slow hand names[v / k] (below: B1); k (0: not a pair).
 * The editor needs no engine hook: one detent steps the fast hand (carrying into the slow one on the wrap), SHIFT
 * steps the slow hand (ce_knob: "snap \267 B1"), the cell is a fraction of both (ce_cell_plan) */
static uint32_t ce_pair(const param_desc_t *d)
{
    uint32_t k = 0;
    if (!d || d->fmt != F_INT || !d->names || d->max < d->min)
        return 0;
    while (d->names[k])
        k++;
    return k > 1u && k * k == (uint32_t)(d->max - d->min + 1) ? k : 0u;
}

/* a ratio's text ("0.25", "16.00") in quarters (1 .. 255: the CR_G_RATIO cell's pct / pct2), 0 when it is not one */
static uint32_t ce_quarters(const char *s)
{
    uint32_t w = 0, f = 0, i = 0;
    while (s[i] >= '0' && s[i] <= '9')
        w = w * 10u + (uint32_t)(s[i++] - '0');
    if (s[i] == '.' && s[i + 1] >= '0' && s[i + 1] <= '9' && s[i + 2] >= '0' && s[i + 2] <= '9')
        f = (uint32_t)(s[i + 1] - '0') * 10u + (uint32_t)(s[i + 2] - '0');
    w = w * 4u + f / 25u;
    return w <= 255u ? w : 0u;
}

/* a value's whole text for the "deep:" trace line: a name of a name list uncut (param_format stops at 5 characters),
 * a ratio pair "fast/slow" (QUAD's "B2/B1"; the longest, "16.00/16.00", is 11), else as the cell shows it */
static void ce_trace_value(const param_desc_t *d, int32_t v, char *b, uint32_t n)
{
    uint32_t pk = ce_pair(d);
    if (pk) {
        uint32_t c = (uint32_t)(clamp(v, d->min, d->max) - d->min);
        str_cpy(b, d->names[c % pk], n);
        cu_cat(b, "/", n);
        cu_cat(b, d->names[c / pk], n);
        return;
    }
    if (d->names && (d->fmt == F_ENUM || d->fmt == F_INT) && d->max >= d->min) {
        uint32_t c = (uint32_t)(clamp(v, d->min, d->max) - d->min), k = 0;
        if (d->fmt == F_INT) {                     /* (a 0-terminated list: the range split evenly over it) */
            while (d->names[k])
                k++;
            c = k ? c * k / (uint32_t)(d->max - d->min + 1) : 0u;
        }
        if (d->fmt == F_ENUM || k) {
            str_cpy(b, d->names[d->fmt == F_ENUM ? c + (uint32_t)d->min : c], n);
            return;
        }
    }
    cp_value(d, v, b, n);
}

/* ------------------------------------------------- MIDI CC: in and out --- */
/* (3y269; docs/MANUAL.md section 15 "MIDI in", cr_midi.c crm_cc_*.) A CC on MIDI Perform's channel sets a parameter
 * of the chord sound, on MIDI Bass's the bass sound's, as a knob turn on its cell would: the sound marked edited, the
 * cell hot in the editor when it is on the screen, else the knobs' popup. A knob turned on such a cell sends the CC
 * on the part's channel (Options > MIDI CC Out). Two kinds:
 *   the common CCs, one meaning on every engine that has the thing: 10 Pan (MIX), 92 Drive (the fourth send; FM
 *     TONE: the sound's own Drive, as the FX group's cell), 74 / 71 the filter's cutoff / resonance, 73 75 79 72 the
 *     amp envelope's A D S R, 76 / 77 LFO 1's rate / depth. CE_CCC: the engine's built-in page and column by title
 *     and label (a compiled layout's pages, P5's rows, reach the same column); an engine without deep pages: the
 *     platform's ENV and LFO (WHEEL); CC 7 91 93 94 are cr_ui.c's as before (out: here too);
 *   the editor's blocks: the group's lanes in SELECT order, four CCs a lane (crm_cc_block): the lane found by
 *     walking the group's screens (ce_scr, ce_lanes) and its cell in the view the knobs would have (ce_view_at), so a
 *     CC is always the cell the editor shows there, whatever pages an engine has */
static const struct { uint8_t cc; char page[8], col[7]; } CE_CCC[] = {
    {74, "FILTER", "CUT"}, {74, "FILTER+", "FREQ"}, {71, "FILTER", "RES"}, {71, "FILTER+", "RESO"},
    {73, "ENV 1", "ATK"}, {75, "ENV 1", "DEC"}, {79, "ENV 1", "SUS"}, {72, "ENV 1", "REL"},
    {73, "AMP", "ATK"}, {75, "AMP", "DEC"}, {79, "AMP", "SUS"}, {72, "AMP", "REL"},
    {76, "LFO 1", "RATE"}, {76, "LFO 1", "SPEED"}, {77, "LFO 1", "DEPTH"}, {77, "LFO 1+", "DEPTH"},
    {76, "LFO", "RATE"}, {76, "LFO", "SPEED"}, {77, "LFO", "AMOUNT"}, {77, "LFO", "PMD"},
    {76, "VIB", "RATE"}, {77, "VIB", "DEPTH"}};
/* a common CC's cell on track t (CC 7 91 93 94 too: the out side's), 0 none on this engine */
static int ce_cc_common(const track_t *t, uint32_t cc, ce_ref_t *r)
{
    static const uint8_t TRK[][2] = {{7, P_LEVEL}, {10, P_PAN}, {91, P_REV}, {92, P_DIST}, {93, P_CHOR}, {94, P_DLY},
                                     {73, P_ATK}, {75, P_DEC}, {79, P_SUS}, {72, P_REL}, {76, P_LRATE}, {77, P_LD_PIT}};
    const eng_deep_t *b = ENGINES[eng_idx(t->eng_req)]->deep, *d = cp_deep(t);
    uint32_t i, p;
    int32_t c;
    for (i = 0; i < NELEM(TRK); i++)              /* the part's own (MIX, the sends); an engine without deep pages:
                                                   * the platform's ENV and LFO */
        if (TRK[i][0] == cc && (i < 6u || !d)) {
            *r = ce_r(CE_R_TRK, TRK[i][1], 0);
            return 1;
        }
    if (!b || !d)
        return 0;
    for (i = 0; i < NELEM(CE_CCC); i++) {
        if (CE_CCC[i].cc != cc)
            continue;
        for (p = 0; p < b->npages && !cp_eq(b->pages[p].title, CE_CCC[i].page); p++)
            ;
        if (p == b->npages || (c = cp_dcol(&b->pages[p], CE_CCC[i].col)) < 0)
            continue;
        if (d == b) {
            *r = ce_r(CE_R_DEEP, p, (uint32_t)c);
            return 1;
        }
#if CR_LAYC_N
        {   /* a compiled layout (P5's rows): its column bound to that built-in one */
            uint32_t lp, lc, bp, bc;
            for (lp = 0; lp < d->npages; lp++)
                for (lc = 0; lc < 4u; lc++)
                    if (cp_lay_src(t, lp, lc, &bp, &bc) && bp == p && bc == (uint32_t)c) {
                        *r = ce_r(CE_R_DEEP, lp, lc);
                        return 1;
                    }
        }
#endif
    }
    return 0;
}
/* lane n of group g (SELECT's order across its screens): its screen *k and lane *ln, 0 past the group's last */
static int ce_cc_lane(const track_t *t, uint32_t g, uint32_t n, uint32_t *k, uint32_t *ln)
{
    ce_scr_t sc;
    uint32_t ns = ce_scr(t, g, 0, &sc), nl;
    for (*k = 0; *k < ns; (*k)++) {
        ce_scr(t, g, *k, &sc);
        nl = ce_lanes(t, g, &sc);
        if (n < nl) {
            *ln = n;
            return 1;
        }
        n -= nl;
    }
    return 0;
}
/* the cell CC cc reaches on track t (crm_cc_eng's, and 7 91 93 94), 0 none: a cell with a parameter */
static int ce_cc_ref(const track_t *t, uint32_t cc, ce_ref_t *r)
{
    uint32_t n, c, k, ln;
    int32_t g = crm_cc_block(cc, &n, &c);
    if (g >= 0) {
        ce_view_t vw;
        if (!ce_has(t, (uint32_t)g) || !ce_cc_lane(t, (uint32_t)g, n, &k, &ln))
            return 0;
        ce_view_at(t, (uint32_t)g, k, ln, &vw);
        *r = vw.ref[vw.active][c];
        return r->k == CE_R_DEEP || r->k == CE_R_TRK;   /* (a dash, a text, an empty slot: nothing) */
    }
    return ce_cc_common(t, cc, r);
}
static int ce_cc_list(const param_desc_t *d) { return d->fmt == F_ENUM || d->fmt == F_ONOFF; }
static int ce_ref_eq(ce_ref_t a, ce_ref_t b) { return a.k == b.k && a.a == b.a && (a.b & 3u) == (b.b & 3u); }

static crm_echoes_t cu_echo;                      /* the CCs sent last (the echo guard: cr_midi.c crm_echo_*) */
static uint32_t cu_cc_ch(uint32_t part)           /* the part's MIDI channel + 1, 0 Off */
{
    return cs.ch[part ? CR_STREAM_BASS : CR_STREAM_MAIN];
}
/* Options > MIDI CC Out: CC cc = v on the part's channel (none while its channel is Off), as the notes go out */
static void cu_cc_send(uint32_t part, uint32_t cc, uint32_t v)
{
    uint32_t ch = cu_cc_ch(part & 1u);
    if (!(cs.midi_cc & 2u) || !ch || !cc)
        return;
    crm_echo_note(&cu_echo, ch - 1u, cc, v, cu_now());
    cr_post(CRE_CCOUT, ch - 1u, cc, (int32_t)(v & 0x7Fu));
    cu_trace("cc: out part %u ch %u cc %u %u\n", (unsigned)part, (unsigned)ch, (unsigned)cc, (unsigned)v);
}
/* a cell's value out as its CCs: its block's, given the editor's (g, k, ln, knob) (g past CE_MOD: none), and the
 * common one it is. A send (and FM TONE's AMP+ DRIVE, the part's P_DIST) is its 0..127 as cu_send has it */
static void ce_cc_out(uint32_t part, const track_t *t, ce_ref_t r, uint32_t g, uint32_t k, uint32_t ln, uint32_t knob)
{
    static const uint8_t COMMON[14] = {7, 10, 91, 92, 93, 94, 71, 72, 73, 74, 75, 76, 77, 79};
    const param_desc_t *d;
    int32_t v, snd;
    uint32_t i, n, q, cc, ccv;
    ce_ref_t x;
    ce_scr_t sc;
    if (!(cs.midi_cc & 2u) || !cu_cc_ch(part & 1u) || !(d = ce_param(t, r, &v)))
        return;
    snd = ce_send_ref(t, r);
    ccv = snd >= 0 ? (uint32_t)(v < 0 ? 0 : v > 127 ? 127 : v) : crm_cc_out(v, d->min, d->max, ce_cc_list(d));
    if (g <= CE_MOD) {                            /* the block's: the lanes of the screens before, then this lane */
        for (n = 0, q = 0; q < k; q++) {
            ce_scr(t, g, q, &sc);
            n += ce_lanes(t, g, &sc);
        }
        if ((cc = crm_cc_of(g, n + ln, knob)) != 0)
            cu_cc_send(part, cc, ccv);
    }
    for (i = 0; i < NELEM(COMMON); i++)
        if (ce_cc_common(t, COMMON[i], &x) &&
            (ce_ref_eq(x, r) || (snd >= 0 && x.k == CE_R_TRK && x.a == (uint32_t)snd))) {
            cu_cc_send(part, COMMON[i], ccv);
            return;
        }
}
/* a part's send turned outside the editor (the FX layer, KNOB 4, the bass level, the SMK-37's faders): its CC */
static void cu_cc_send_trk(uint32_t part, uint32_t id)
{
    static const uint8_t CC[][2] = {{P_LEVEL, 7}, {P_PAN, 10}, {P_REV, 91}, {P_DIST, 92}, {P_CHOR, 93}, {P_DLY, 94}};
    uint32_t i;
    int32_t v = id == P_LEVEL || id == P_PAN ? trk[part ? CR_PART_BASS : CR_PART_CHORD].p[id] : cu_send(part, id);
    for (i = 0; i < NELEM(CC); i++)
        if (CC[i][0] == id)
            cu_cc_send(part, CC[i][1], (uint32_t)(id == P_PAN ? v + 64 : v < 0 ? 0 : v > 127 ? 127 : v));
}

/* an incoming CC's value: only on the edit page showing that part's cell (the cell hot, as a knob turn); no popup
 * elsewhere (owner, 2026-11-08) */
static void ce_cc_show(uint32_t part, const track_t *t, ce_ref_t r)
{
    ce_view_t vw;
    uint32_t i, c;
    if (cu.page != PG_EDIT || (ce.part & 1u) != part)
        return;
    ce_view(t, part, &vw);
    for (i = 0; i < vw.n; i++)
        for (c = 0; c < 4u; c++)
            if (ce_ref_eq(vw.ref[i][c], r)) {
                cx.hot_slot = 0;
                cx.hot_r = (uint8_t)(i + 1u);
                cx.hot_c = (uint8_t)c;
                cx.hot_t0 = cu_now();
                return;
            }
}

/* Options > MIDI CC In: CC cc = v (0..127) arrived for part 0 / 1 (cr_ui.c cu_midi_poll, from cr_out.c's pending
 * values): its cell set as a knob turn sets it (ce_knob's three ways: a deep column, a send, a track parameter) */
static void ce_cc_in(uint32_t part, uint32_t cc, uint32_t v)
{
    track_t *t = &trk[part ? CR_PART_BASS : CR_PART_CHORD];
    const param_desc_t *d;
    ce_ref_t r;
    int32_t v0, nv, snd;
    uint32_t ch = cu_cc_ch(part);
    if (ch && crm_echo_hit(&cu_echo, ch - 1u, cc, v, cu_now())) {
        cu_trace("cc: in part %u cc %u %u: our echo\n", (unsigned)part, (unsigned)cc, (unsigned)v);
        return;
    }
    if (!ce_cc_ref(t, cc, &r) || !(d = ce_param(t, r, &v0))) {
        cu_trace("cc: in part %u cc %u %u: no cell\n", (unsigned)part, (unsigned)cc, (unsigned)v);
        return;
    }
    snd = ce_send_ref(t, r);
    nv = crm_cc_val(v, d->min, d->max, ce_cc_list(d));
    if (snd >= 0) {
        cu_send_set(part, (uint32_t)snd, (int32_t)v);   /* (a send: 0..127, the CC itself) */
        nv = cu_send(part, (uint32_t)snd);
    } else if (r.k == CE_R_DEEP) {
        const eng_deep_t *dd = cp_deep(t);
        if (nv != v0) {
            dd->set(t, r.a, r.b, nv);
            cu_edited(part);
        }
        nv = dd->get(t, r.a, r.b);
    } else {
        fm1_irq_off();
        t->p[r.a] = (int16_t)nv;
        fm1_irq_on();
        if (nv != v0)
            cu_edited(part);
    }
    ce_cc_show(part, t, r);
    d = ce_param(t, r, &v0);                      /* (a mode-dependent descriptor: the one the value has now) */
    cu_trace("cc: in part %u cc %u %u -> %s %d%s\n", (unsigned)part, (unsigned)cc, (unsigned)v, d ? d->label : "?",
             (int)nv, psnd[part].edited ? " edited" : "");
}

/* the editor's knob turned cell r of the view: its CCs out (the group's block, the common one) */
static void ce_knob_cc(const track_t *t, const ce_view_t *vw, ce_ref_t r, uint32_t knob)
{
    uint32_t p = ce.part & 1u, g = cx.grp[p] % CE_NSEC;
    ce_cc_out(p, t, r, g, cx.scr[p][g], vw->active, knob & 3u);
}
/* KNOB 1..4 on the active lane's cell (snap: SHIFT latched or held: cr_pages.c kn_snap; else at the knob's speed) */
static void ce_knob(uint32_t knob, int32_t s, uint32_t snap)
{
    track_t *t = ce_trk();
    ce_view_t vw;
    ce_ref_t r;
    const param_desc_t *d;
    int32_t v0 = 0, v;
    uint32_t i, m = ce_kmod(), pk;
    char b[16];                                    /* (the trace's value: up to 11 characters, ce_trace_value) */
    if (m == 3u) {                                 /* OCT- held: clear the parameter's modulation */
        cu.oct_mod = 1;                            /* (its release: no octave step) */
        ce_unmap(knob);
        return;
    }
    if (m == 4u) {                                 /* SEL held: the filter type, a detent a type */
        ce_fpick(s);
        return;
    }
    if (m) {                                       /* ENV / LFO held: map */
        ce_map(knob, s, snap, m == 1u);
        return;
    }
    ce_view(t, ce.part & 1u, &vw);
    r = vw.ref[vw.active][knob & 3u];
    if (vw.expr && r.k == CE_R_TXT && (knob & 3u) >= 1u && (knob & 3u) <= 2u) {   /* an unset slot: its default
                                                                                     * first, then the turn */
        uint32_t src = vw.active ? P_MAT_SRC : P_MVEL_SRC;
        fm1_irq_off();
        t->p[src] = (int16_t)(vw.active ? MS_AT : MS_VEL);
        t->p[src + 1u] = (int16_t)(vw.active ? MD_CUT : MD_AMP);
        t->p[src + 2u] = (int16_t)(vw.active ? cr_touch_at_amt() : CR_TOUCH_VEL_DEF_AMT);
        fm1_irq_on();
        r = ce_r(CE_R_TRK, src + (knob & 3u), 0);
    }
    if (!(d = ce_param(t, r, &v0)))
        return;
    v = cp_dstep(d, v0, s, snap || cx.shift);
    if (r.k == CE_R_DEEP && d->names && (ce_cstyle(t, &vw, vw.active, knob & 3u) == ENG_C_RATIO ||
                                         ce_cstyle(t, &vw, vw.active, knob & 3u) == ENG_C_BIG))
        v = clamp(v0 + s, d->min, d->max);        /* (a ratio: one step a detent, as the Digitone's) */
    if (r.k == CE_R_DEEP && (pk = ce_pair(d)) != 0 && (snap || cx.shift)) {   /* a pair, SHIFT: the slow hand (B1) a step */
        int32_t c = v0 - d->min, b2 = clamp(c / (int32_t)pk + s, 0, (int32_t)pk - 1);
        v = d->min + b2 * (int32_t)pk + c % (int32_t)pk;
    }
    cx.hot_slot = 0;
    cx.hot_r = (uint8_t)(vw.active + 1u);
    cx.hot_c = (uint8_t)(knob & 3u);
    cx.hot_t0 = cu_now();
    if (r.k == CE_R_DEEP && ce_send_ref(t, r) < 0) {
        const eng_deep_t *dd = cp_deep(t);
        if (v != v0) {
            dd->set(t, r.a, r.b, v);
            v = dd->get(t, r.a, r.b);
            cu_edited(ce.part);
            ce_knob_cc(t, &vw, r, knob);
        }
        ce_trace_value(d, v, b, sizeof b);
#if defined(CR_TRACE) && CR_LAYC_N
        {   /* (a compiled classic layout's page: the trace names the built-in page and column, the engine's address) */
            uint32_t tp = r.a, tc = r.b;
            const char *tt = cp_lay_trace_src(t, dd, &tp, &tc);
            cu_trace("deep: part %u page %u %s col %u %s %d -> %d (%s)%s\n", (unsigned)ce.part, (unsigned)tp, tt,
                     (unsigned)tc, d->label, (int)v0, (int)v, b, psnd[ce.part].edited ? " edited" : "");
        }
#else
        cu_trace("deep: part %u page %u %s col %u %s %d -> %d (%s)%s\n", (unsigned)ce.part, (unsigned)r.a,
                 dd->pages[r.a].title, (unsigned)r.b, d->label, (int)v0, (int)v, b, psnd[ce.part].edited ? " edited" : "");
#endif
        return;
    }
    if ((i = (uint32_t)ce_send_ref(t, r)) != (uint32_t)-1) {   /* a send: the part's one value (cr_ui.c cu_send_set:
                                                    * the chord part's are the FX amounts). The part's since 0.18, as
                                                    * the MIX group's Level and Pan: not an edit of the sound; but
                                                    * FM TONE's Drive is the sound's: cu_send_set marks it edited */
        v = cu_send_step(v0, s, snap || cx.shift);                /* (a send's one step, as the FX layer's) */
        cu_send_set(ce.part, i, v);
        if (v != v0)
            ce_knob_cc(t, &vw, r, knob);
        cu_send_text(v, b, sizeof b);
        cu_trace("param: part %u %s %s %d -> %d (%s)%s\n", (unsigned)ce.part, CE_SEC_NAME[cx.grp[ce.part & 1u] % CE_NSEC],
                 d->label, (int)v0, (int)v, b, cu_send_quad(ce.part, i) && psnd[ce.part].edited ? " edited" : "");
        return;
    }
    fm1_irq_off();
    t->p[r.a] = (int16_t)v;
    fm1_irq_on();
    if (v != v0) {
        cu_edited(ce.part);
        ce_knob_cc(t, &vw, r, knob);
    }
    cp_value(d, v, b, sizeof b);
    cu_trace("param: part %u %s %s %d -> %d (%s)\n", (unsigned)ce.part, CE_SEC_NAME[cx.grp[ce.part & 1u] % CE_NSEC],
             d->label, (int)v0, (int)v, b);
}

/* -------------------------------------------------------------- the LEDs --- */
/* EDIT blinks, the group's button lit, the other group buttons dim (cr_leds: every button's dim is on); SHIFT lit
 * while latched (or held) */
static void ce_leds(uint8_t *nl, uint32_t blink)
{
    uint8_t m[FM1_NCOL];
    uint32_t s, k;
    for (k = 0; k < FM1_NCOL; k++)
        m[k] = 0;
    for (s = 0; s < CE_NSEC; s++)
        cu_led(m, panel.btn[CE_SEC_BTN[s]], 1);
    cu_led(m, panel.btn[BT_EDIT], 1);
    for (k = 0; k < FM1_NCOL; k++)
        nl[k] &= (uint8_t)~m[k];
    cu_led(nl, panel.btn[BT_EDIT], (int)blink);
    cu_led(nl, panel.btn[CE_SEC_BTN[cx.grp[ce.part & 1u] % CE_NSEC]], 1);
    if (cx.shift)
        cu_led(nl, panel.btn[B_GLO], 1);
}

/* ------------------------------------------------------------ the screen --- */
/* the band's values from the view: env a h d s r (o[6]: 1 = REL at INF), filter cut res type drive (Q8 of 255) */
static void ce_band(const track_t *t, const ce_view_t *vw, uint8_t *o)
{
    static const char *const EL[5] = {"ATK", "HOLD", "DEC", "SUS", "REL"};
    const eng_deep_t *d = cp_deep(t);
    uint32_t i;
    int32_t k, pg;
    for (i = 0; i < 20u; i++)
        o[i] = 0;
    o[16] = 8;
    if (vw->wide == CR_W_CZ && d && vw->np) {               /* CZ-1: R1..R8, L1..L8, SUS, END from the run's pages */
        for (pg = vw->dp0; pg < vw->dp0 + vw->np; pg++)
            for (i = 0; i < 4u; i++) {
                const char *l = d->pages[pg].col[i].label;
                int32_t v;
                if (!l)
                    continue;
                v = d->get(t, (uint32_t)pg, i);
                if ((l[0] == 'R' || l[0] == 'L') && l[1] >= '1' && l[1] <= '8' && !l[2])
                    o[(l[0] == 'L' ? 8u : 0u) + (uint32_t)(l[1] - '1')] = (uint8_t)clamp(v, 0, 99);
                else if (cp_eq(l, "SUS"))
                    o[16] = (uint8_t)clamp(v, 0, 8);
                else if (cp_eq(l, "END"))
                    o[17] = (uint8_t)clamp(v, 0, 7);
            }
    } else if (vw->wide == CR_W_DX && d && vw->np) {               /* FM6: R1..R4 on the first page, L1..L4 on the second */
        for (i = 0; i < 4u; i++) {
            o[i] = (uint8_t)clamp(d->get(t, vw->dp0, i), 0, 99);
            o[4u + i] = vw->np > 1u ? (uint8_t)clamp(d->get(t, vw->dp0 + 1u, i), 0, 99) : 99u;
        }
        o[9] = !ce_inst(d->pages[vw->dp0].title);           /* (no instance: the pitch EG) */
    } else if (vw->wide == CR_W_ENV && d && ce_deep(t) && vw->np) {
        for (i = 0; i < 5u; i++)
            for (pg = vw->dp0; pg < vw->dp0 + vw->np; pg++)
                if ((k = cp_dcol(&d->pages[pg], EL[i])) >= 0) {
                    int32_t v = d->get(t, (uint32_t)pg, (uint32_t)k);
                    o[i] = ce_pct(&d->pages[pg].col[k], v);
                    if (i == 4u && param_inf(&d->pages[pg].col[k], v))
                        o[6] = 1;                     /* (REL INF: the band's tail held) */
                }
    } else if (vw->wide == CR_W_ENV) {
        static const uint8_t ID[5] = {P_ATK, 0xFF, P_DEC, P_SUS, P_REL};
        for (i = 0; i < 5u; i++)
            if (ID[i] != 0xFFu)
                o[i] = ce_pct(cp_desc(t, ID[i]), t->p[ID[i]]);
    } else if (vw->wide == CR_W_FILTER && d) {               /* cut res ftype drive, from the FILTER section's pages */
        static const char *const FL[6] = {"CUT", "RES", "FTYPE", "DRIVE", "TYPE", "MORPH"};
        int32_t typ = -1, mor = 0;
        uint32_t a, b;
        ce_range(d, CE_FILT, &a, &b);
        for (pg = (int32_t)a; pg < (int32_t)b; pg++)
            for (i = 0; i < 6u; i++)
                if ((k = cp_dcol(&d->pages[pg], FL[i])) >= 0) {
                    int32_t v = d->get(t, (uint32_t)pg, (uint32_t)k);
                    if (i == 2u)
                        o[2] = (uint8_t)(v & 127);
                    else if (i == 4u)
                        typ = clamp(v, 0, 3);
                    else if (i == 5u)
                        mor = v;
                    else
                        o[i] = ce_pct(&d->pages[pg].col[k], v);
                }
        if (typ >= 0)                                         /* (an older table: TYPE, MORPH on from it) */
            o[2] = (uint8_t)((typ * 32 + mor) & 127);
    }
}
/* the CZ-1 step (1..8; 0 none) of the cell just turned: R k / L k, SUS its step, END its step */
static uint32_t ce_cz_step(const track_t *t, ce_ref_t r)
{
    const param_desc_t *d;
    int32_t v;
    if (r.k != CE_R_DEEP || !(d = ce_param(t, r, &v)))
        return 0;
    if ((d->label[0] == 'R' || d->label[0] == 'L') && d->label[1] >= '1' && d->label[1] <= '8' && !d->label[2])
        return (uint32_t)(d->label[1] - '0');
    if (cp_eq(d->label, "SUS") || cp_eq(d->label, "END"))
        return v >= 0 && v < 8 ? (uint32_t)v + 1u : 0u;
    return 0;
}
/* the envelope segment (1 A, 2 H, 3 D, 4 S, 5 R; 0 none) of the cell just turned */
static uint32_t ce_seg(const track_t *t, ce_ref_t r)
{
    static const char *const EL[5] = {"ATK", "HOLD", "DEC", "SUS", "REL"};
    static const uint8_t ID[5] = {P_ATK, 0xFF, P_DEC, P_SUS, P_REL};
    const param_desc_t *d;
    int32_t v;
    uint32_t i;
    if (!(d = ce_param(t, r, &v)))
        return 0;
    if (r.k == CE_R_DEEP && (d->label[0] == 'R' || d->label[0] == 'L') && d->label[1] >= '1' && d->label[1] <= '4' &&
        !d->label[2])                                          /* FM6's R1..R4 / L1..L4: the segment they end */
        return (uint32_t)(d->label[1] - '0');
    for (i = 0; i < 5u; i++)
        if (r.k == CE_R_TRK ? r.a == ID[i] : cp_eq(d->label, EL[i]))
            return i + 1u;
    return 0;
}

/* the battery as Felucca's header showed it (ui_draw.c batt_shown): 4 on USB power, else 0..3 by the smoothed ADC
 * (thresholds 531 / 561 / 591) */


/* the matrix's marks: per destination the colour of its source (white: several), 0 none */
#define CE_NDST 48u
static void ce_marks(const track_t *t, uint8_t *mc)
{
    const eng_deep_t *d = ce_deep(t);
    uint32_t a, b, pg, i;
    uint8_t seen[CE_NDST];
    ce_slot_t sl;
    for (i = 0; i < CE_NDST; i++)
        mc[i] = seen[i] = 0;
    if (!d || !d->mod_dst)
        return;
    ce_range(d, CE_MOD, &a, &b);
    for (pg = a; pg < b; pg++) {
        int32_t sr, ds;
        if (!ce_slot(d, pg, &sl) || !(sr = d->get(t, pg, (uint32_t)sl.cs)) || (ds = d->get(t, pg, (uint32_t)sl.cd)) <= 0 ||
            ds >= (int32_t)CE_NDST || !d->get(t, pg, (uint32_t)sl.ca))
            continue;
        mc[ds] = (uint8_t)(seen[ds] && seen[ds] != sr ? CR_COL_WHITE : ce_src_col(ce_name_of(d, pg, (uint32_t)sl.cs, sr)));
        seen[ds] = (uint8_t)sr;
    }
}

/* ------------------------------------------------- the engine's screen plan --- */
/* the plan's band values (eng_screen_t.band): algo fdbk mix; A's attack decay end level, B's; the filter cut res
 * ftype drive (+ shown, base, width: the window), from the screen's / the FILTER section's columns by label. The
 * number of wv values, 0: not a plan band (the AHDSR: ce_band) */
static int32_t ce_dget(const track_t *t, const eng_deep_t *d, uint32_t a, uint32_t b, const char *l, int32_t *v)
{
    uint32_t pg;
    int32_t k;
    for (pg = a; pg < b && pg < d->npages; pg++)
        if ((k = cp_dcol(&d->pages[pg], l)) >= 0) {
            *v = d->get(t, pg, (uint32_t)k);
            return (int32_t)ce_pct(&d->pages[pg].col[k], *v);
        }
    *v = 0;
    return -1;
}
static uint32_t ce_band_plan(const track_t *t, const ce_view_t *vw, uint8_t *o)
{
    const eng_deep_t *d = ce_deep(t);
    const eng_screen_t *h = ce_plan(d, vw->hs);
    uint32_t i, a, b;
    int32_t v, q;
    if (!h)
        return 0;
    if (h->band == ENG_B_ALGO) {
        a = vw->dp0;
        b = vw->dp0 + vw->np;
        ce_dget(t, d, a, b, "ALGO", &v);
        o[0] = (uint8_t)clamp(v, 1, 8);
        o[1] = (uint8_t)clamp(ce_dget(t, d, a, b, "FDBK", &v), 0, 255);
        q = ce_dget(t, d, a, b, "MIX", &v);
        o[2] = (uint8_t)(q < 0 ? 128 : clamp(q, 0, 255));
        return 3;
    }
    if (h->band == ENG_B_ADE2) {                  /* rows A and B: their four columns each */
        for (i = 0; i < 8u; i++) {
            uint32_t pg = vw->dp0 + i / 4u;
            const param_desc_t *c = pg < d->npages && i / 4u < vw->np ? &d->pages[pg].col[i & 3u] : 0;
            o[i] = c && c->label ? ce_pct(c, d->get(t, pg, i & 3u)) : 0u;
        }
        return 9;
    }
    if (h->band == ENG_B_WAVE) {                  /* GRAIN: the SRC screen shows the active lane's buffer (A or B), the
                                                   * GRAIN screen both, morphed; the part; a count that moves every
                                                   * frame, so the band (the grains over the buffers) redraws each one */
        static uint8_t tick;
        const cr_wave_t *w;
#if FELUCCA_GRAIN
        cr_wave_src = grain_wave;
#endif
        o[0] = (uint8_t)(vw->hs == 1u ? (vw->active ? 1u : 0u) : 2u);
        o[1] = (uint8_t)(ce.part ? CR_PART_BASS : CR_PART_CHORD);
        w = cr_wave_src ? cr_wave_src(o[1]) : 0;
        /* the grains move at a third of the frame rate (a band redraw is ~100 lines over the LCD, most of a frame:
         * every frame would leave the renders no idle time), and while a source renders only when a render lands:
         * the render gets the frames, the band shows each new buffer (3y138; in place, 3y168) */
        o[2] = w && w->busy ? (uint8_t)(0x80u | (w->gen & 0x7Fu)) : (uint8_t)((tick++ / 3u) & 0x7Fu);
        return 3;
    }
    if (h->band == ENG_B_FILTER || h->band == ENG_B_WINDOW) {
        ce_range(d, CE_FILT, &a, &b);
        q = ce_dget(t, d, a, b, "FREQ", &v);
        o[0] = (uint8_t)clamp(q >= 0 ? q : ce_dget(t, d, a, b, "CUT", &v), 0, 255);
        q = ce_dget(t, d, a, b, "RESO", &v);
        o[1] = (uint8_t)clamp(q >= 0 ? q : ce_dget(t, d, a, b, "RES", &v), 0, 255);
        o[2] = 0;
        o[7] = o[8] = o[9] = 0;
        {                                         /* the type by its name: LP 0, BP 32, HP 64 (the band's positions);
                                                   * its slope (o[7]): "OFF" 1 (flat), "..12" 2, "..24" 3; FM TONE's
                                                   * machines 4 MULTI (LP -> BP -> HP by its SHAPE), 5 COMB+, 6 COMB-,
                                                   * 7 EQ, their SHAPE (o[8]) and GAIN + 64 (o[9]); the type's own
                                                   * column (ce_ftype: not the MORPH / LPF / Q its cell shows, 3y217) */
            uint32_t fp, fc;
            const param_desc_t *c = ce_ftype(t, &fp, &fc);
            v = c ? d->get(t, fp, fc) : 0;
            if (c && v >= c->min && v <= c->max) {
                const char *nm = c->names[v - c->min];
                uint32_t ln = str_len(nm);
                int32_t sv, gv;
                o[2] = (uint8_t)(nm[0] == 'H' ? 64 : nm[0] == 'B' ? 32 : 0);
                o[7] = (uint8_t)(cp_eq(nm, "OFF") ? 1 : ln > 2u && nm[ln - 2u] == '1' && nm[ln - 1u] == '2' ? 2
                                 : ln > 2u && nm[ln - 2u] == '2' && nm[ln - 1u] == '4' ? 3 : 0);
                if (cp_eq(nm, "MULTI") || cp_eq(nm, "COMB+") || cp_eq(nm, "COMB-") || cp_eq(nm, "EQ")) {
                    ce_dget(t, d, a, b, "SHAPE", &sv);
                    ce_dget(t, d, a, b, "GAIN", &gv);
                    o[7] = (uint8_t)(nm[0] == 'M' ? 4 : nm[0] == 'E' ? 7 : nm[4] == '+' ? 5 : 6);
                    o[8] = (uint8_t)clamp(sv, 0, 127);
                    o[9] = (uint8_t)clamp(gv + 64, 0, 127);
                    if (nm[0] == 'M')
                        o[2] = (uint8_t)(clamp(sv, 0, 127) * 64 / 127);
                }
            }
        }
        o[3] = (uint8_t)clamp(ce_dget(t, d, a, b, "DRIVE", &v), 0, 255);
        o[4] = o[5] = o[6] = 0;
        if (h->band != ENG_B_WINDOW)
            return 10;
        o[4] = 1;
        o[5] = (uint8_t)clamp(ce_dget(t, d, a, b, "BASE", &v), 0, 255);
        o[6] = (uint8_t)clamp(ce_dget(t, d, a, b, "WIDTH", &v), 0, 255);
        return 10;
    }
    return 0;
}
/* the plan's style of the cell on row r, column c (ENG_C_*) */
static uint32_t ce_cstyle(const track_t *t, const ce_view_t *vw, uint32_t r, uint32_t c)
{
    const eng_screen_t *h = ce_plan(ce_deep(t), vw->hs);
    return h && r < 2u && c < 4u ? h->cell[r][c] : ENG_C_RULE;
}
/* "TRI" -> "Tri", "RAT A" -> "Rat A" (words of min or more capitals; "LP", "x16" stay at 3) */
static void ce_title_case(char *s, uint32_t min)
{
    uint32_t i = 0, j, n;
    while (s[i]) {
        for (n = 0; s[i + n] && s[i + n] != ' '; n++)
            ;
        for (j = 0; j < n && s[i + j] >= 'A' && s[i + j] <= 'Z'; j++)
            ;
        if (n >= min && j == n)
            for (j = 1; j < n; j++)
                s[i + j] = (char)(s[i + j] + 32);
        i += n;
        while (s[i] == ' ')
            i++;
    }
}
/* a value's text as the plan's styles show it: the number (signed), the text without the unit, the whole name */
static void ce_ptext(const param_desc_t *d, int32_t v, uint32_t style, char *out, uint32_t n)
{
    char val[12];
    const char *unit;
    if ((style == ENG_C_BIG || style == ENG_C_RATIO || style == ENG_C_TEXT) && d->fmt == F_INT && d->names) {
        uint32_t k = 0;                           /* (one name a value: the whole name, params.c cuts it at 5) */
        while (d->names[k])
            k++;
        if (k == (uint32_t)(d->max - d->min + 1)) {
            cu_cpy(out, d->names[clamp(v, d->min, d->max) - d->min], n);
            return;
        }
    }
    if (param_inf(d, v)) {                       /* a release at INF: the word, whatever the style */
        cu_cpy(out, "INF", n);
        return;
    }
    if (d->fmt == F_FIX2) {                      /* hundredths: "42.01", "+41.34", whatever the style */
        param_format(d, v, val, &unit);
        cu_cpy(out, val, n);
        return;
    }
    if (style == ENG_C_NUM || style == ENG_C_BAR || style == ENG_C_DETUNE ||
        (style == ENG_C_BIG && d->fmt != F_INT && d->fmt != F_OFS)) {
        cu_int(out, v, d->min < 0, n);
        return;
    }
    param_format(d, v, val, &unit);
    cu_cpy(out, val, n);
    if (d->fmt == F_CUTOFF && unit[0] == 'k')
        cu_cat(out, "k", n);                      /* "2.1k" */
    if (style == ENG_C_TEXT)
        ce_title_case(out, d->fmt == F_ONOFF ? 2u : 3u);   /* ("ON" -> "On"; "LP" stays) */
}
/* a two-LED button's value names after the text's NUL in b (n bytes): 1 when both fit, else none (zeros) */
static int ce_p5names(char *b, uint32_t n, const param_desc_t *d)
{
    uint32_t l = str_len(b), i, j;
    for (i = l + 1u; i < n; i++)
        b[i] = 0;
    for (i = 0; d->names && i < 2u; i++) {
        j = str_len(d->names[i]);
        if (l + 1u + j + 1u > n)
            break;
        cu_cpy(b + l + 1u, d->names[i], j + 1u);
        l += 1u + j;
    }
    if (i < 2u)                                   /* (not both: none) */
        for (i = str_len(b) + 1u; i < n; i++)
            b[i] = 0;
    return i == 2u;
}
/* a cell in one of the Prophet-5's looks (ENG_C_P5*: cr_screen.h CR_G_P5*): its glyph, pct (the dial, an LED on at
 * the maximum, the lever's position), pct2 an LED's icon, the value on the row ("64", "On", "Half", "1/2"); a two-LED
 * button's two value names after its label's NUL, or when they do not fit there after its value's (cr_draw.c
 * cr_p5glyph draws them over the LEDs) */
static void ce_cell_p5(const param_desc_t *d, int32_t v, uint32_t st, cr_cell_t *cl)
{
    static const uint8_t G[7] = {CR_G_P5KNOB, CR_G_P5LED, CR_G_P5LED, CR_G_P5LED, CR_G_P5LED, CR_G_P5LED2, CR_G_P5SWITCH};
    static const uint8_t I[7] = {0, CR_P5I_NONE, CR_P5I_SAW, CR_P5I_TRI, CR_P5I_SQUARE, 0, 0};
    uint32_t k = st - ENG_C_P5KNOB < 7u ? st - ENG_C_P5KNOB : 0u;
    cl->flags = (uint16_t)(CR_CF_ON | (d->min < 0 && d->max > 0 ? CR_CF_BIP : 0u));
    cl->glyph = G[k];
    cl->pct = ce_pct(d, v);
    cl->pct2 = I[k];
    ce_ptext(d, v, d->fmt == F_INT ? ENG_C_VAL : ENG_C_TEXT, cl->value, sizeof cl->value);
    if (cl->glyph == CR_G_P5LED2 && !ce_p5names(cl->label, sizeof cl->label, d))
        ce_p5names(cl->value, sizeof cl->value, d);
}
/* cell c of row r (of ref rf) restyled by the plan; a label of the plan's */
static void ce_cell_plan(const track_t *t, const ce_view_t *vw, uint32_t r, uint32_t c, cr_cell_t *cl)
{
    const eng_screen_t *h = ce_plan(ce_deep(t), vw->hs);
    uint32_t st = ce_cstyle(t, vw, r, c), k;
    ce_ref_t rf = vw->ref[r][c];
    const param_desc_t *d;
    int32_t v = 0;
    if (!h || !(cl->flags & CR_CF_ON) || rf.k != CE_R_DEEP || !(d = ce_param(t, rf, &v)))
        return;
    if (r < 2u && h->label[r][c])
        cu_cpy(cl->label, h->label[r][c], sizeof cl->label);
    k = rf.b & 3u;                                /* (a cell another value by a mode: its label, not the plan's;
                                                   * FM TONE's FILTER+ on a machine "Morph" "Feedback" "LPF" "Gain" "Q") */
    if (d != &ce_deep(t)->pages[rf.a].col[k] && !cp_eq(d->label, ce_deep(t)->pages[rf.a].col[k].label))
        ce_label(t, rf, d, cl->label, sizeof cl->label);
    if (st == ENG_C_RULE)
        return;
    if (st >= ENG_C_P5KNOB) {                     /* the Prophet-5's controls (the layout tool's mock-ups) */
        ce_cell_p5(d, v, st, cl);
        return;
    }
    cl->flags = CR_CF_ON;
    cl->glyph = CR_G_NONE;
    cl->pct = ce_pct(d, v);
    ce_ptext(d, v, st, cl->value, sizeof cl->value);
    switch (st) {
    case ENG_C_BIG: cl->flags |= CR_CF_BIG; break;
    case ENG_C_RATIO:                             /* a pair: the fast hand (B2) over the slow (B1) in quarters
                                                   * (cr_draw formats both "%u.%02u") */
        cl->glyph = CR_G_RATIO;
        if ((k = ce_pair(d)) != 0) {
            uint32_t c = (uint32_t)(clamp(v, d->min, d->max) - d->min);
            cl->pct = (uint8_t)ce_quarters(d->names[c % k]);
            cl->pct2 = (uint8_t)ce_quarters(d->names[c / k]);
            cu_cpy(cl->value, d->names[c % k], sizeof cl->value);
            if (!cl->pct || !cl->pct2)            /* (not a ratio in quarters: the fast hand's name alone, big) */
                cl->pct2 = 0;
        }
        break;
    case ENG_C_HARM: cl->glyph = CR_G_HARM; cl->flags |= CR_CF_PCT; break;
    case ENG_C_DETUNE: cl->glyph = CR_G_DETUNE; cl->flags |= CR_CF_PCT; break;
    case ENG_C_KNOB: cl->glyph = CR_G_KNOB; cl->flags |= CR_CF_PCT | (d->min < 0 ? CR_CF_BIPOLAR : 0u); break;
    case ENG_C_BAR: cl->glyph = CR_G_BAR; cl->flags |= CR_CF_PCT | (d->min < 0 ? CR_CF_BIP : 0u); break;
    case ENG_C_NUM:
    case ENG_C_VAL: cl->flags |= CR_CF_PCT | (d->min < 0 ? CR_CF_BIP : 0u); break;
    case ENG_C_WAVEPH: {                          /* the wave (CR_LW_* order) and the next column's phase: one cell */
        const param_desc_t *pd;
        int32_t ph = 0;
        char w[8], b[6];
        ce_ref_t r2 = c < 3u ? vw->ref[r][c + 1u] : ce_r(CE_R_NONE, 0, 0);
        pd = r2.k == CE_R_DEEP ? ce_param(t, r2, &ph) : 0;
        cl->glyph = CR_G_LFOWAVE;
        cl->flags |= CR_CF_SPAN2;
        cl->wave = (uint8_t)clamp(v - d->min, 0, CR_LW_N - 1);
        cl->pct = (uint8_t)(pd ? clamp(ph - pd->min, 0, 127) * 2 : 0);   /* (0..127 a cycle: Q8 of it) */
        ce_ptext(d, v, ENG_C_TEXT, w, sizeof w);
        cu_int(b, pd ? (ph - pd->min) * 360 / (pd->max - pd->min + 1) : 0, 0, sizeof b);   /* (degrees, as the mock-up) */
        cu_cpy(cl->value, w, sizeof cl->value);
        cu_cat(cl->value, str_len(w) + str_len(b) + 3u < sizeof cl->value ? " \267 " : "\267", sizeof cl->value);
        cu_cat(cl->value, b, sizeof cl->value);
        break;
    }
    default:
        break;
    }
}
/* a plan row's span cell (ENG_C_WAVEPH at column c) takes two columns: the cells after it move a place left (the
 * cell index is not the column: cr_screen.h CR_CF_SPAN2); the column it spans; 4 none */
static uint32_t ce_span_col(const track_t *t, const ce_view_t *vw, uint32_t r)
{
    uint32_t c;
    for (c = 0; c < 3u; c++)
        if (ce_cstyle(t, vw, r, c) == ENG_C_WAVEPH)
            return c;
    return 4u;
}

#if CR_LAY_FREE
/* a free screen's cell (cr_layout.h): its element's label, pct2 its state (an led: 1 on, its value above the minimum;
 * a switch: its position, 0 .. positions - 1, the value's nearest), CR_CF_BIP for a range across 0. The look is the
 * renderer's, by the element (cr_draw.c CR_K_FREE) */
static void ce_cell_free(const track_t *t, const ce_view_t *vw, uint32_t r, uint32_t c, cr_cell_t *cl)
{
    const cr_lay_screen_t *ls = cr_lay_scr(vw->li, vw->ls);
    const cr_lay_elem_t *e = cr_lay_el(vw->li, ls, cr_lay_slot(ls, r, c));
    const param_desc_t *d;
    int32_t v = 0, span;
    if (!e || !(cl->flags & CR_CF_ON) || !(d = ce_param(t, vw->ref[r][c], &v)))
        return;
    cu_cpy(cl->label, cr_lay_str(e->label), sizeof cl->label);
    cl->flags = (uint16_t)(CR_CF_ON | (d->min < 0 && d->max > 0 ? CR_CF_BIP : 0u));
    cl->glyph = CR_G_NONE;
    v = clamp(v, d->min, d->max);
    span = d->max - d->min;
    if (e->type == CR_E_SWITCH) {                 /* (Math.round of web/fm1layout.js p5Op: the nearest position) */
        int32_t n1 = CR_LF_POS(e->flags) == 3u ? 2 : 1;
        cl->pct2 = (uint8_t)(span > 0 ? ((v - d->min) * n1 * 2 + span) / (2 * span) : 0);
    } else {
        cl->pct2 = (uint8_t)(v > d->min);
    }
}
#endif

static void ce_screen(cr_screen_t *s, uint32_t now)
{
    track_t *t = ce_trk();
    uint32_t p = ce.part & 1u, r, c, g;
    ce_view_t vw;
    uint8_t band[20], mc[CE_NDST];
    if (cx.fpick && !ce_fheld())                  /* SEL released: the picker closes, the type kept */
        cx.fpick = 0;
    if (cx.fpick) {
        uint32_t pg, col;
        const param_desc_t *c = ce_ftype(t, &pg, &col);
        int32_t v = clamp(cp_deep(t)->get(t, pg, col), c->min, c->max);
        cu_picker(s, c->names + c->min, (uint32_t)(c->max - c->min + 1), (uint32_t)(v - c->min), CR_COL_ORANGE,
                  "filter type", "");
        cu_cpy(s->title, psnd[p].name, sizeof s->title);
        if (psnd[p].edited)
            cu_cat(s->title, "*", sizeof s->title);
        s->title_col = p ? CR_COL_ORANGE : CR_COL_NONE;
        s->header = 0;
        s->ring_on = 0;
        s->batt = 255;
        (void)now;
        return;
    }
    ce_view(t, p, &vw);
    g = cx.grp[p] % CE_NSEC;
    s->kind = vw.kind;
    s->header = 0;
    s->ring_on = 0;                               /* (the editor has the whole screen) */
    cu_cpy(s->title, psnd[p].name, sizeof s->title);
    if (psnd[p].edited)
        cu_cat(s->title, "*", sizeof s->title);
    if (p)
        cu_cat(s->title, " \267 BASS", sizeof s->title);
    s->title_col = p ? CR_COL_ORANGE : CR_COL_NONE;
    cu_cpy(s->page, vw.right, sizeof s->page);
    s->fine = (uint8_t)(cx.shift || cu_shift());
    for (c = 0; s->fine && c < 4u && vw.active < CR_ED_ROWS; c++) {   /* a ratio pair in the lane: SHIFT steps its B1 */
        int32_t pv;
        if (vw.ref[vw.active][c].k == CE_R_DEEP && ce_pair(ce_param(t, vw.ref[vw.active][c], &pv)))
            s->fine = 2;
    }
    s->batt = 255;                                /* no battery in the editor (it is on the Options page) */
    s->n_rows = vw.n;
    s->active = vw.active;
    s->wide = vw.wide;
    s->tall = vw.tall;
    s->fl_eng = vw.li;
    s->fl_scr = vw.ls;
    for (c = 0; c < 4u; c++)
        cu_cpy(s->head[c], vw.head[c], sizeof s->head[c]);
    ce_marks(t, mc);
    for (r = 0; r < vw.n; r++) {
        if (vw.kind == CR_K_STACK)
            ce_cat_num(s->rlabel[r], vw.row0 + r + 1u, sizeof s->rlabel[r]);
        for (c = 0; c < 4u; c++) {
            int32_t ds;
            ce_cell(t, &vw, vw.ref[r][c], &s->cell[r][c]);
#if CR_LAY_FREE
            if (vw.kind == CR_K_FREE)
                ce_cell_free(t, &vw, r, c, &s->cell[r][c]);
#endif
            if (vw.hs)
                ce_cell_plan(t, &vw, r, c, &s->cell[r][c]);
#ifdef CR_LAYOUT_PREVIEW
            if (ce_style_hook && vw.kind == CR_K_EDIT8 && !vw.tall && vw.ref[r][c].k == CE_R_DEEP &&
                (s->cell[r][c].flags & CR_CF_ON)) {        /* (the layout tool: a design's cell style, in place) */
                uint32_t st = ce_style_hook(t, vw.ref[r][c].a, vw.ref[r][c].b & 3u);
                const param_desc_t *pd;
                int32_t pv;
                if (st >= ENG_C_P5KNOB && (pd = ce_param(t, vw.ref[r][c], &pv))) {
                    ce_cell_p5(pd, pv, st, &s->cell[r][c]);
                    if (st == ENG_C_SKETCH)               /* a sketch: the glyph box left empty (CR_G_N draws nothing) */
                        s->cell[r][c].glyph = CR_G_N;
                }
            }
#endif
            if ((s->cell[r][c].flags & CR_CF_ON) && (ds = ce_dst(t, vw.ref[r][c])) > 0 && ds < (int32_t)CE_NDST && mc[ds])
                s->cell[r][c].flags |= CR_CF_MARK(mc[ds]);
        }
        if (vw.hs && (c = ce_span_col(t, &vw, r)) < 3u) {   /* a span cell: the next column is in it */
            uint32_t j;
            for (j = c + 1u; j < 3u; j++)
                s->cell[r][j] = s->cell[r][j + 1u];
            for (j = 0; j < sizeof s->cell[r][3]; j++)
                ((uint8_t *)&s->cell[r][3])[j] = 0;
        }
    }
    if (vw.tall)                                  /* the mixer: "OSC n" over each level's bar */
        for (c = 0; c < 4u; c++)
            if (s->cell[0][c].flags & CR_CF_ON) {
                cu_cpy(s->cell[0][c].label, "OSC ", sizeof s->cell[0][c].label);
                ce_cat_num(s->cell[0][c].label, c + 1u, sizeof s->cell[0][c].label);
                s->cell[0][c].glyph = CR_G_BAR;
                s->cell[0][c].flags |= CR_CF_PCT;
            }
    if (cx.hot_r && now - cx.hot_t0 < CE_HOT_MS && cx.hot_r == vw.active + 1u) {
        s->hot_r = cx.hot_r;
        s->hot_c = cx.hot_c;
        if (vw.hs && (c = ce_span_col(t, &vw, (cx.hot_r - 1u) % CR_ED_ROWS)) < 3u && cx.hot_c > c)
            s->hot_c = (uint8_t)(cx.hot_c - 1u);  /* (a knob past a span cell: the cell index, not the column) */
        if (cx.hot_slot) {                        /* a quick mapping: "LFO1 +24" in the source's colour */
            const eng_deep_t *d = ce_deep(t);
            ce_slot_t sl;
            cr_cell_t *hc = &s->cell[(cx.hot_r - 1u) % CR_ED_ROWS][cx.hot_c & 3u];
            if (d && cx.hot_slot - 1u < d->npages && ce_slot(d, cx.hot_slot - 1u, &sl)) {
                const char *nm = ce_name_of(d, sl.pg, (uint32_t)sl.cs, cx.hot_src);
                ce_amt_text(hc->value, nm, &d->pages[sl.pg].col[(uint32_t)sl.ca], d->get(t, sl.pg, (uint32_t)sl.ca),
                            sizeof hc->value);
                s->hot_col = (uint8_t)ce_src_col(nm);
            }
        }
    }
    if (vw.wide && vw.hs && (c = ce_band_plan(t, &vw, band)) > 0) {   /* the plan's algo, ade2, filter (+ window) */
        uint32_t j;
        for (j = 0; j < c; j++)
            s->wv[j] = band[j];
        if (vw.wide == CR_W_ADE2)                 /* the segment the cell turned: A's a d end lev 1..4, B's 5..8 */
            s->wv[8] = (uint8_t)(s->hot_r ? ((s->hot_r - 1u) % 2u) * 4u + (cx.hot_c & 3u) + 1u : 0u);
    } else if (vw.wide) {                         /* the band: its values as they are (no tween: the knob leads) */
        ce_band(t, &vw, band);
        for (c = 0; c < (vw.wide == CR_W_CZ ? 18u : vw.wide == CR_W_DX ? 10u : vw.wide == CR_W_ENV ? 5u : 4u); c++)
            s->wv[c] = band[c];
        if (vw.wide == CR_W_CZ && s->hot_r)       /* the step the cell turned (R k, L k; SUS / END: their step) */
            s->wv[18] = (uint8_t)ce_cz_step(t, vw.ref[(s->hot_r - 1u) % CR_ED_ROWS][s->hot_c & 3u]);
        if (vw.wide == CR_W_ENV)                  /* REL INF: the tail held */
            s->wv[6] = band[6];
        if (vw.wide == CR_W_ENV && s->hot_r)
            s->wv[5] = (uint8_t)ce_seg(t, vw.ref[(s->hot_r - 1u) % CR_ED_ROWS][s->hot_c & 3u]);
        if (vw.wide == CR_W_DX && s->hot_r)       /* the segment the cell turned ends (R k, L k: k) */
            s->wv[8] = (uint8_t)ce_seg(t, vw.ref[(s->hot_r - 1u) % CR_ED_ROWS][s->hot_c & 3u]);
    }
}
