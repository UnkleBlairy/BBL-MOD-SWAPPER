ChoralRoot 0.46 for the BBL Mod Swapper

Original by Quixotic7: https://github.com/Quixotic7/ChoralRootFM1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: CHORALRT-source.zip on the ports page.
