Viber 1.2 for the BBL Mod Swapper

Original by ant25fr: https://github.com/ant25fr/viber
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: VIBER-source.zip on the ports page.
