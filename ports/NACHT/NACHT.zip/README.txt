Nachtfahrt 1.0.2 for the BBL Mod Swapper

Original by FartyPants: https://github.com/FartyPants/fm1-nachtfahrt
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: NACHT-source.zip on the ports page.
