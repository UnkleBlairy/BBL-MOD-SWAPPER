/* SPDX-License-Identifier: GPL-3.0-only */
/* MONO2K's effects. Each track has its own delay, as on the Monomachine (time in 1/64 notes, feedback, and a
 * base / width band in the loop); here it runs at half rate in 8-bit mu-law, which is the memory budget and the
 * colour. The bus is the lofi part: a reverb at 22 kHz (a feedback delay network, 0.3 to 24 s), a 4-bit ADPCM crunch
 * and a drive into the soft clip; and PERFORM's effects over them while FX is held (the repeats from the glitch's
 * ring, the tape's wow). 1.5 cut the bus's HISS, TAPE and GLCH for the FM-1's time (the owner's: "the important are
 * ADPC, reverb, drive"): a pattern keeps their bytes, unheard. */

static uint8_t mulaw_enc(int32_t x)
{
    int sign = 0;
    if (x < 0) { sign = 0x80; x = -x; }
    if (x > 32635) x = 32635;
    x += 0x84;                         /* 0x84 .. 0x7FFF: the segment is the top bit's place over bit 7 */
    int exp = x >= 0x800 ? 4 : 0;
    if (x >= (0x200 << exp)) exp += 2;
    if (x >= (0x100 << exp)) exp += 1;
    int man = (x >> (exp + 3)) & 0x0F;
    return (uint8_t)~(sign | (exp << 4) | man);
}

static uint32_t sps_q8 = 1411200;      /* samples per sixteenth, Q8; the sequencer sets it */

/* DUB (PERFORM): the bus thrown into a borrowed track's delay (m2k_fx.c's dub_line), as a delay's own values: a
 * dotted eighth (3/16, the line's clock slowing past its length, darker), feedback 0.75, the band 24 .. 84, ping-pong
 * from the left, at LEVL 110; the send a block late, the echoes out apart (they must not feed the send back) */
#define DUB_TIM 48
#define DUB_FB 48
#define DUB_BAS 24
#define DUB_WID 60
#define DUB_PAN 16
#define DUB_LEV 110
static int32_t (*dub_io(int ti))[M2K_SUB];   /* track ti's DUB send, echoes left and right if the line is DUB's */
static int dub_on(void);
static void dub_end(void);

/* the bus's record of a block (the render's, below: the bus plays a block behind the tracks) */
typedef struct { uint8_t kd, dtim, dfb, dbas, dwid, pan, levl; } dl_par_t;
typedef struct {
    int32_t L[M2K_SUB], R[M2K_SUB], rs[M2K_SUB];   /* the tracks' sums */
    int32_t dds[M2K_SUB];                          /* DUB's track's own send, its line run with the bus */
    dl_par_t dp;                                   /* and that line's settings as the block had them */
    uint32_t sps;                                  /* the tempo (sps_q8) */
    uint8_t glob[G_COUNT];                         /* the pattern's controls */
    uint8_t step[2], nstep;                        /* the pattern's steps that fell in it (bus_step's) */
    uint8_t run, mvol, valid, dt, dsent;           /* playing; the master; filled; DUB's track + 1; its line sent to */
} brec_t;
static brec_t brec[2] POOL;
static uint8_t bcur;                   /* the record this block fills */
static uint8_t dub_snap;               /* DUB's track + 1 as the block began: its line runs with the bus */

/* the tempo and the running the bus plays its block at (the record's; a PERFORM key's, the sequencer's now) */
static uint32_t bsps = 1411200;
static uint8_t brun;

/* one line's sample at a fractional position, Q8 of a line sample (unsigned: it wraps, after minutes) */
static inline int32_t dl_read(const uint8_t *b, uint32_t mask, uint32_t pos)
{
    uint32_t j = pos >> 8;
    int32_t f = (int32_t)(pos & 255);
    return (T_MULAW[b[j & mask]] * (256 - f) + T_MULAW[b[(j + 1) & mask]] * f) >> 8;
}

/* a line's sample, encoded. Under GATE (a feedback under unity's dead band: rounded to the nearest mu-law step, an
 * echo DFB / 64 as loud as the last can round back to it, a pass after a pass, for ever) it takes the step below
 * it instead, so a tail ends in silence */
static inline uint8_t mulaw_line(int32_t x, int32_t gate)
{
    uint8_t q = mulaw_enc(x);
    int32_t a = x < 0 ? -x : x, d = T_MULAW[q];
    if (a < gate && q != 0xFF && q != 0x7F && (d < 0 ? -d : d) >= a) q++;   /* (a code on is a step nearer silence) */
    return q;
}

/* the track's delay, after the Monomachine's (measured): DTIM in 256ths of a note plus 7.6 ms; the send |d| / 64
 * (format 17: the Monomachine's square, (d / 64)^2, left a third of the knob near silent), negative keeping the
 * source's side, positive ping-pong; feedback DFB / 64, unity at 64 and saturating above; the
 * echoes through a one-pole HP at DBAS and a one-pole LP at DBAS + DWID. The line runs at half rate in 8-bit mu-law;
 * a time longer than the line slows its clock instead, the echoes darker, as a tape or a BBD would. Ping-pong
 * keeps a sum and a difference line, each half the memory */
/* a delay's settings as its track has them now */
static void dl_par(int ti, dl_par_t *p)
{
    const trk_t *t = &trk[ti];
    p->kd = PAT(cur_pat)->kit[ti][P_DSND];
    p->dtim = (uint8_t)P7(t, P_DTIM); p->dfb = (uint8_t)P7(t, P_DFB); p->dbas = (uint8_t)P7(t, P_DBAS);
    p->dwid = (uint8_t)P7(t, P_DWID); p->pan = (uint8_t)P7(t, P_PAN); p->levl = (uint8_t)P7(t, P_LEVL);
}

/* a block of track ti's line: its settings p (0: the track's now), sent to this block or not, at tempo sps; DUB's (dub:
 * the bus's side, where it may be DUB's line) */
static void delay_run(int ti, const dl_par_t *p, int sent, uint32_t sps, int dub, const int32_t *restrict in,
                      int32_t *restrict L, int32_t *restrict R)
{
    trk_t *t = &trk[ti];
    dl_par_t now;
    /* DUB's line: the bus's send with the track's own, DUB's values, its echoes apart (its own sum) */
    int32_t (*dio)[M2K_SUB] = dub ? dub_io(ti) : 0, din[M2K_SUB];
    if (dio) {
        for (int i = 0; i < M2K_SUB; i++) din[i] = in[i] + dio[0][i];
        in = din;
        sent |= dub_on();
        L = dio[1];
        R = dio[2];
    }
    if (t->dsleep && !sent) {          /* quiet last block and nothing sent since: it would be again, as it stands */
        if (dio && !dub_on()) dub_end();              /* (DUB's echoes over: the line the track's again) */
        return;
    }
    /* the layout from the kit's DSND, not its locks' or LFOs' (each crossing of 64 wiped the lines), and only past 64
     * by a step (a kit turned to 64 keeps the echoes it has) */
    if (!p) { dl_par(ti, &now); p = &now; }          /* (a line asleep reads none) */
    int kd = p->kd, dual = dio ? 1 : t->dmode ? kd >= 64 : kd > 64;
    if (dual != t->dmode) {            /* the lines change their layout: start them empty */
        m_set(t->dl, 0x7F, DL_LEN);
        t->dmode = (uint8_t)dual;
        t->dacc[0] = t->dacc[1] = t->dn = 0;
        t->dhp[0] = t->dhp[1] = t->dlp[0] = t->dlp[1] = 0;
        t->dhr[0] = t->dhr[1] = t->dlr[0] = t->dlr[1] = 0;
        t->dquiet = DL_LEN;
    }
    if (t->dcut == 1 && !dio) {        /* the CPU guard's cut faded out (m2k_guard): the line wiped, asleep */
        m_set(t->dl, 0x7F, DL_LEN);
        t->dacc[0] = t->dacc[1] = t->dn = 0;
        t->dhp[0] = t->dhp[1] = t->dlp[0] = t->dlp[1] = t->dprev[0] = t->dprev[1] = 0;
        t->dhr[0] = t->dhr[1] = t->dlr[0] = t->dlr[1] = 0;
        t->dquiet = DL_LEN;
        t->dcut = 0;
        t->dsleep = 1;
        mon.dly[ti] = 0;
        return;
    }
    uint32_t n = dual ? DL_LEN / 2 : DL_LEN, mask = n - 1;
    /* nothing sent, every entry of the line written silent since, the filters settled: nothing to hear, nothing to
     * work out (most tracks, most of the time; the FM-1's time) */
    int quiet = t->dquiet >= n;
    for (int i = 0; quiet && i < M2K_SUB; i++) quiet = in[i] == 0;
    if (quiet) {
        int32_t s = 0;
        for (int c = 0; c < 2; c++) {
            int32_t v[4] = {t->dhp[c], t->dlp[c], t->dprev[c], t->dacc[c]};
            for (int k = 0; k < 4; k++) s |= v[k] > 3 || v[k] < -3;
        }
        if (!s) {
            t->dhp[0] = t->dhp[1] = t->dlp[0] = t->dlp[1] = t->dprev[0] = t->dprev[1] = t->dacc[0] = t->dacc[1] = 0;
            t->dhr[0] = t->dhr[1] = t->dlr[0] = t->dlr[1] = 0;
            mon.dly[ti] = 0;
            if (dio && !dub_on()) dub_end();
            t->dsleep = 1;
            t->dcut = 0;
            return;
        }
    }
    t->dsleep = 0;
    /* the time, half-rate samples Q8: whole samples once it settles (a read between two samples dulls the top) */
    int32_t target = dio ? (int32_t)(((uint32_t)DUB_TIM * (sps >> 5) + 128) & ~255u)
                         : ((int32_t)((uint32_t)p->dtim * (sps >> 5)) + (167 << 8) + 128) & ~255;
    int32_t dd = target - t->dt_q8;
    /* a time turned glides (no zipper on what the line holds); a silent line holds nothing: its time at once (in the
     * slowed clock a glide from the last time ran it fast, the first echo 19 ms early at DTIM 127: chain_delay) */
    t->dt_q8 = (dd > -64 && dd < 64) || t->dquiet >= n ? target : t->dt_q8 + (dd >> 5);
    uint32_t th = (uint32_t)t->dt_q8 >> 8, room = n - 4;
    uint32_t rate = th <= room ? 65536u : (room << 16) / th;                  /* the line's clock, Q16 */
    int32_t back = th <= room ? t->dt_q8 : (int32_t)(room << 8);               /* the delay in line samples, Q8 */
    int dfb = dio ? DUB_FB : p->dfb;
    /* mulaw_line's gate: the dead band of mu-law's first segment is 256 / (64 - DFB), the next ones' to 4 x that (DFB 62
     * and 63, a band wide open, can still hold an echo a little over it) */
    int32_t fb = dfb * 512, gate = dfb < 64 ? 1024 / (64 - dfb) : 0;
    int dbas = dio ? DUB_BAS : p->dbas;
    int32_t ahp = T_DLY_HP[dbas], alp = T_DLY_LP[CLAMP(dbas + (dio ? DUB_WID : p->dwid), 0, 127)];
    int pan = dio ? DUB_PAN : p->pan;
    int32_t gl = T_PAN[pan], gr = T_PAN[127 - pan], lev = T_VOL[dio ? DUB_LEV : p->levl], dlev = 0;
    if (t->dcut > 1 && !dio) {         /* the guard's cut (a tail): the echoes straight down over PARK_N blocks, a line
                                        * across each (2^15 by 8 at most) */
        const int32_t l0 = lev * (t->dcut - 1) / PARK_N, l1 = lev * (t->dcut - 2) / PARK_N;
        lev = l0;
        dlev = (l1 - l0) / (M2K_SUB / 2);
        t->dcut--;
    }
    uint8_t *b = t->dl;
    int32_t pk = 0;
    for (int i = 0; i < M2K_SUB; i += 2) {
        int32_t x = (in[i] + in[i + 1]) >> 1;
        uint32_t pos = (t->dw << 8) + (t->dph >> 8) - (uint32_t)back;
        int32_t e[2];
        for (int c = 0; c <= dual; c++) {
            /* the one-poles carry their remainders (as zop_lp does): without, they stalled up to 252 off zero and the
             * delay never went quiet */
            int32_t y = dl_read(b + c * n, mask, pos);
            int32_t q = (y - t->dhp[c]) * ahp + t->dhr[c];
            t->dhp[c] += q >> 15;
            t->dhr[c] = q & 32767;
            q = (y - t->dhp[c] - t->dlp[c]) * alp + t->dlr[c];
            t->dlp[c] += q >> 15;
            t->dlr[c] = q & 32767;
            e[c] = t->dlp[c];
        }
        int32_t l, r;
        if (dual) {                    /* sum and difference: the echo crosses sides on every pass */
            /* the echo comes off its filters past 16 bits and DFB runs to 1.75: its product takes 64 bits */
            uint64_t ef = mul2_q15(fb, e[0], e[1]);
            t->dacc[0] += ((x * (gl + gr)) >> 15) + (int32_t)ef;
            t->dacc[1] += ((x * (gl - gr)) >> 15) - (int32_t)(ef >> 32);
            l = (e[0] - e[1]) >> 1;
            r = (e[0] + e[1]) >> 1;
        } else {
            t->dacc[0] += x + (int32_t)mul_sh(e[0], fb, 15);
            l = (e[0] * gl) >> 15;
            r = (e[0] * gr) >> 15;
        }
        t->dn++;
        t->dph += rate;
        if (t->dph >= 65536u) {        /* the clock ticks: the inputs since the last tick, averaged, go in */
            t->dph -= 65536u;
            int loud = 0;
            for (int c = 0; c <= dual; c++) {
                uint8_t q = mulaw_line(t->dacc[c] / t->dn, gate);
                b[c * n + (t->dw & mask)] = q;
                loud |= q != 0xFF && q != 0x7F;           /* mu-law's two silences */
            }
            t->dquiet = loud ? 0 : t->dquiet < 0x40000000u ? t->dquiet + 1 : t->dquiet;
            t->dw++;
            t->dacc[0] = t->dacc[1] = t->dn = 0;
        }
        l = (l * lev) >> 15;
        r = (r * lev) >> 15;
        lev += dlev;
        L[i] += (t->dprev[0] + l) >> 1;
        R[i] += (t->dprev[1] + r) >> 1;
        L[i + 1] += l;
        R[i + 1] += r;
        t->dprev[0] = l;
        t->dprev[1] = r;
        int32_t a = (l < 0 ? -l : l) + (r < 0 ? -r : r);
        if (a > pk) pk = a;
    }
    if (!dio) mon.dly[ti] = pk;
}

/* a track's line in its own block (DUB's is the bus's: run_track) */
static void delay_block(int ti, const int32_t *restrict in, int32_t *restrict L, int32_t *restrict R)
{
    int sent = trk[ti].dsent;
    trk[ti].dsent = 0;
    delay_run(ti, 0, sent, sps_q8, 0, in, L, R);
}

/* ------------------------------------------------------------------------------------------------ the bus */

#define GL_LEN 16384u
static int16_t gl_buf[GL_LEN][2] POOL;
static int16_t tp_buf[2048][2] POOL;
/* the reverb's four lines at their whole size (22 kHz: 31 .. 47 ms, primes) and its two input diffusers, all in one
 * ring with one write place: each sits its longest (and the sample read past it) behind the next, so none reaches
 * another's, and none needs a wrap of its own */
static const uint16_t RV_LEN[4] = {683, 797, 907, 1031}, RD_LEN[2] = {149, 211};
#define RV_N 4096u
static const uint16_t RV_AT[6] = {685, 685 + 799, 685 + 799 + 909, 685 + 799 + 909 + 1033,
                                  685 + 799 + 909 + 1033 + 151, 685 + 799 + 909 + 1033 + 151 + 213};   /* (3790) */
static int16_t rv_buf[RV_N] POOL;
static const int8_t ADPCM_IDX[8] = {-1, -1, -1, -1, 2, 4, 6, 8};

static struct {
    /* reverb */
    uint32_t rw;                       /* the ring's write place */
    int32_t rlp[4], rlr[4];            /* the lines' damping and its remainders */
    int32_t rq[4], rdq[2], rrq[2];     /* the lines', the diffusers' and the swing's remainders */
    int32_t rbw, rbr;                  /* the input's top, and its remainder */
    int32_t rgo;                       /* its level out, Q12: T_RV_GO's, glided */
    /* DUB: the track whose line it has + 1 (0 none), its send now (Q15), the mix it sends for the next block and its
     * echoes this one */
    uint8_t dub_t;
    int32_t dub_snd, dub_io[3][M2K_SUB];
    /* SHIMMER: the wash on (held, then until it is quiet), the bus's send into it (Q15), its octave's grain phase,
     * the blocks it has been quiet */
    uint8_t sh_on;
    int32_t sh_snd;
    uint32_t sh_ph, sh_q;
    int32_t sh_hp;                     /* its high-pass's low part */
    int32_t rv_l, rv_r;                /* the last output, for the half-rate's in-between */
    uint32_t rsz;                      /* the room's size now, Q12 (it glides to DCAY's) */
    uint32_t rmph;                     /* the swing's phase */
    uint8_t rv_v, rv_d, rsleep;        /* DCAY and DAMP the coefficients were worked out for, rv_s the room */
    uint32_t rv_s;
    int32_t rgh, ra;                   /* the lines' gain / 2 and damping, Q15 */
    int32_t rfade;                     /* turned off: the tail's way out, Q15 */
    uint32_t rquiet;                   /* half-rate samples with nothing in and the lines within a step */
    /* glitch: the ring (half rate) and the one event it plays, a PERFORM key's */
    uint32_t gw;                       /* the ring's write place */
    uint32_t g_start, g_len;           /* the slice (or, stopping, the read's start) and its length */
    uint32_t g_lenq;                   /* a repeat's lap, Q12: the sixteenth's own, to a 4096th of a sample */
    uint32_t g_pos, g_rate;            /* the read: Q12 into the slice; its step Q24 (1 << 24 at pitch) */
    uint32_t g_dec;                    /* a stop's slowing */
    int32_t g_env, g_wet;              /* its level, Q10, fading in and out; the wet's, Q15 (it takes the dry's place) */
    uint8_t g_on, g_mode, g_phase, g_pk, g_next, g_spin;   /* g_pk, g_next: the PERFORM key holding it, waiting (+1) */
    uint8_t g_held;                    /* its key holds it; let go, it fades out */
    int32_t gacc_l, gacc_r, gout_l, gout_r, gprev_l, gprev_r;
    uint32_t g_grid[3];                /* the ring's place at the last sixteenth, eighth and beat */
    uint32_t grng;                     /* FREEZE's and SCATTER's dice: the trigs' chances keep theirs */
    uint16_t g_fi, g_fo;               /* the event's fade in and out, Q10 a sample */
    int32_t g_dip;                     /* a stop let go near rest: its dip before the landing, Q15 */
    /* FREEZE and the octaves: three Hann grains a third apart, g_gl long (g_wst the window's angle a sample); a
     * freeze's grains each start somewhere in its slice */
    uint32_t g_gl, g_g3, g_gph, g_wst, g_gp[3];
    uint8_t g_sc[2], g_rl;             /* SCATTER's slice now and before (0-3, 4 reversed, 8 its first half twice); ROLL's laps */
    int32_t g_srt;                     /* SPIN: its speed, signed, Q24; its ticks, the pull's and the spin's */
    uint32_t g_st, g_t1, g_t2;
    int32_t gtd;                       /* GATE: its depth, Q15; its place in the sixteenth with no grid */
    uint32_t gt_ph;
    int32_t g_tgt, g_lev, g_agc, g_agt;   /* a freeze's level: wanted, followed; its gain (Q15) and the gain it glides to */
    uint8_t g_nb;                      /* (blocks, for its gain) */
    int32_t olev;                      /* the output's level, followed over ~0.4 s (every 8th sample's, Q4) */
    /* LPF and HPF (PERFORM): each a ZDF two-pole a side, its place (Q8 of T_FG's 1/96 octaves) and its share */
    zsvf_t fl[2][2];
    int32_t fpos[2], fmix[2], fgain[2];
    uint8_t fnew;                      /* the low-pass starting: its state set to the first sample (no step in) */
    /* tape: WOW's (PERFORM) */
    uint32_t tw, wow, flut;
    int32_t tlp_l, tlp_r;
    int32_t tq;                        /* the depth now (it glides to WOW's and back to 0) */
    int32_t tp_mix;                    /* the tape's share, Q15: WOW's way in and out */
    uint32_t tp_fill;                  /* samples into the line since WOW started it */
    /* adpcm */
    int32_t ad_pred[2], ad_idx[2], ad_hold[2];
    uint16_t ad_acc;                   /* Q8 samples since the 4-bit sample was taken */
    int32_t ad_mixq;                   /* the mix now, Q8 of the 0..127 one (around CRUSH it glides) */
    uint8_t ad_perf, ad_warm;          /* CRUSH held (until its mix is back); blocks of its coder running unheard */
    /* drive: PERFORM's, glided, its level held to the dry's */
    int32_t dv, dv_e0, dv_e1, dv_g, dv_gp;   /* the gain now, Q8; the two levels; the hold, Q15, and where it ramped to */
    /* bank C (1.12). SKIP (gl_skip): a skip on, its repeats to go, a restart's crossfade (samples left), its share
     * (Q10), the grid seen, a free sixteenth's count, the read before a restart (Q12) and its speed (Q24) */
    uint8_t sk_on, sk_reps, sk_xf;
    int32_t sk_mix;
    uint32_t sk_grid, sk_ph, sk_op, sk_or;
    /* the colours (bus_colour): one still gliding; CONSOLE's amount (Q15) and narrowing (Q12, 4096 mono), its one-poles
     * and their remainders, its DC blocker's low part and remainder; LO-FI's share (Q15), its clock and the period it
     * waits for (Q16), the pair held; DUCK's depth (Q15), its beat's place with no grid; CONSOLE whole (the sum through
     * its left side alone) */
    uint8_t c_run, co_mono;
    int32_t co_a, co_n, co_z[2][2], co_zr[2][2], co_dc[2], co_dr[2];
    int32_t lf_mix, lf_h[2];
    uint32_t lf_ph, lf_nx;
    int32_t dk_d;
    uint32_t dk_ph;
} bus;

static inline int32_t adpcm_step(int c, int32_t x)
{
    int32_t step = T_ADPCM_STEP[bus.ad_idx[c]], diff = x - bus.ad_pred[c];
    int code = 0;
    if (diff < 0) { code = 8; diff = -diff; }
    int32_t delta = step >> 3;
    if (diff >= step) { code |= 4; diff -= step; delta += step; }
    step >>= 1;
    if (diff >= step) { code |= 2; diff -= step; delta += step; }
    step >>= 1;
    if (diff >= step) { code |= 1; delta += step; }
    bus.ad_pred[c] = sat16(bus.ad_pred[c] + ((code & 8) ? -delta : delta));
    bus.ad_idx[c] = CLAMP(bus.ad_idx[c] + ADPCM_IDX[code & 7], 0, 88);
    return bus.ad_pred[c];
}

/* ------------------------------------------------------------------------------ the glitch and PERFORM */

/* the glitch plays one event at a time from the ring, a PERFORM key's (bus_perform). Each fades in and out over
 * GL_XF, and a slice's seam (its end into its start) crossfades over as much, so nothing cuts. The modes: a slice
 * repeated, reversed, gated; the stop, the live sound slowed to a halt as a tape; bank B's; and bank C's SKIP */
enum { GM_RPT, GM_REV, GM_GATE, GM_STOP,                                           /* PERFORM's bank A */
       GM_FRZ, GM_PSU, GM_PSD, GM_SCAT, GM_PROLL, GM_SPIN,                         /* bank B's */
       GM_SKIP, GM_COUNT };                                                        /* and bank C's */
#define GL_XF 64u                      /* 2.9 ms */
#define GL_MAX (GL_LEN - 4 * GL_XF - 512)   /* the longest slice: a quarter from 85 BPM (slower, an eighth) */
#define G_UNITY (1u << 24)

/* PERFORM (FX held): a black key's effect while it is held. Repeats of 1/4 .. 1/32 note, the last beat reversed, a
 * tape stop, a gated stutter (1/32 hits of the last sixteenth): each locked to the sequencer's grid (a repeat's slice
 * the one that began on the last beat, eighth or sixteenth, its first time round the sound coming in; the reverse the
 * beat that ended there), played from where that puts it now, so the repeats fall on the beat however late the key;
 * the crush, the wow and the drive at their most, each gliding in and out, the drive's level held to the dry's; a
 * kill (the bus silent). Let go, each fades out (the stop spins back up first) */
/* Bank B (FX held, OCT+): a freeze (the last eighth held as a sustain, three Hann grains wandering in it), a scatter,
 * a roll, the bus an octave down or up (three Hann grains through the ring), a low-pass and a high-pass swept over a
 * bar while held (gliding open again let go), a gate, a dub throw, a shimmer and a vinyl spin-back */
/* Bank C (1.12, OCT+ from B; AFFINE's, written again in integers: bus_colour, gl_skip): a disc that skips (SKIP), a TV
 * speaker (CONSOLE), the mix pumping on the beat (DUCK, CHOPPAH's idea) and an unsteady converter (LO-FI); its other
 * seven keys empty */
enum { PF_R4, PF_R8, PF_R16, PF_R32, PF_REV, PF_STOP, PF_STUT, PF_CRSH, PF_WOW, PF_DRIV, PF_KILL,
       PF_FRZ, PF_SCAT, PF_ROLL, PF_OCTD, PF_OCTU, PF_LPF, PF_HPF, PF_GATE, PF_DUB, PF_SHIM, PF_SPIN,
       PF_SKIP, PF_CONS, PF_DUCK, PF_LOFI,
#ifdef M2K_SPU
       PF_GRIT,                        /* the Move's alone (m2k_spu.c): the bus through the PS1-era chip's sample codec */
#endif
       PF_COUNT };
#ifdef M2K_SPU
#define PF_KEYS PF_GRIT                /* the effects on the FM-1's black keys: all but the Move's own (GRIT) */
#else
#define PF_KEYS PF_COUNT
#endif
#define PF_BANK 11                     /* the black keys: bank A's 0..10, bank B's 11..21, bank C's 22..25 (26..32 none) */
#define PF_BANKS 3
#define WOW_Q8 32512                   /* WOW's tape depth, Q8: the old TAPE control's at 127 (+-40 c of wow) */
static const char *const PF_NAME[PF_COUNT] = {"RPT 1/4", "RPT 1/8", "RPT 1/16", "RPT 1/32", "REVERSE", "STOP", "STUTTER",
                                              "CRUSH", "WOW", "DRIVE", "KILL", "FREEZE", "SCATTER", "ROLL", "OCT DN",
                                              "OCT UP", "LPF", "HPF", "GATE", "DUB", "SHIMMER", "SPIN", "SKIP",
                                              "CONSOLE", "DUCK", "LO-FI",
#ifdef M2K_SPU
                                              "GRIT",
#endif
                                              };
_Static_assert(PF_COUNT <= PF_BANK * PF_BANKS && PF_COUNT <= 32, "the effects on the banks' keys, a latch bit each (ui.pf_lat)");
static struct { uint8_t on[PF_COUNT]; int32_t kill; } perf = {{0}, 32767};
/* the effects that play from the glitch ring, one at a time */
static int pf_ring(int k)
{
    return k <= PF_STUT || k == PF_FRZ || k == PF_SCAT || k == PF_ROLL || k == PF_OCTD || k == PF_OCTU || k == PF_SPIN ||
           k == PF_SKIP;
}

static int seq_running(void);

static uint32_t gl_rnd(void) { uint32_t x = bus.grng; x ^= x << 13; x ^= x >> 17; x ^= x << 5; return bus.grng = x; }

static void gl_start(uint32_t start, uint32_t len, uint32_t pos, int mode, int32_t wet)
{
    bus.g_start = start;
    bus.g_len = len;
    bus.g_lenq = len << 12;
    bus.g_pos = pos << 12;
    bus.g_rate = G_UNITY;
    bus.g_held = 1;
    bus.g_mode = (uint8_t)mode;
    bus.g_wet = wet;
    bus.g_spin = 0;
    bus.g_fi = bus.g_fo = 8;           /* 2.9 ms */
    bus.g_on = 1;
}

/* FREEZE and the octaves' grains, g long: their window's step and their thirds */
static void gl_grains_init(uint32_t g)
{
    bus.g_gl = g;
    bus.g_g3 = g / 3;
    bus.g_gph = 0;
    bus.g_wst = 0x80000000u / g;       /* (half a turn over a grain: sin^2 is the Hann window) */
}

#define FRZ_MIN 2048u                  /* FREEZE's slice, half-rate samples: an eighth, within 93 .. 279 ms */
#define FRZ_MAX 6144u
#define PS_UP 1536u                    /* the octaves' grains: up 70 ms (the read 70 ms back at most), down 93 ms (46) */
#define PS_DN 2048u
#define PS_DMIN 2u                     /* (the read a sample and its neighbour behind the write) */
static void gl_perform(int k)
{
    uint32_t six = bsps >> 9;                             /* a sixteenth in half-rate samples */
    if (k == PF_FRZ) {                                    /* the last eighth, its grains a half of it each */
        uint32_t r = CLAMP(six * 2, FRZ_MIN, FRZ_MAX);
        gl_start(bus.gw - r - 4, r, 0, GM_FRZ, 32768);
        gl_grains_init(r / 2);
        /* held at the last beat's level, not the eighth's (a kick or a chord's attack held as long as the key would
         * be the loudest of the bar): their mean magnitudes, x 1/4 .. 1.4 */
        uint32_t bt = six * 4 > GL_MAX ? GL_MAX : six * 4, sb = 0, sr = 0;
        for (uint32_t i = 0; i < bt; i++) {               /* (|x| < 2^15, bt < 2^14: the sums a word) */
            const int16_t *x = gl_buf[(bus.gw - 4 - bt + i) & (GL_LEN - 1)];
            uint32_t a = (uint32_t)(x[0] < 0 ? -x[0] : x[0]) + (uint32_t)(x[1] < 0 ? -x[1] : x[1]);
            sb += a >> 1;
            if (i >= bt - r) sr += a >> 1;
        }
        uint32_t mb = sb / bt, mr = sr / r + 1;
        /* that, then held at the output to its level before (~0.4 s): the grains agree more or less as the sound
         * is held or moves (a held bass up to 3 dB), and the drive's knee takes a sustain harder than a beat */
        bus.g_agc = bus.g_agt = (int32_t)CLAMP((mb << 15) / mr, 8192u, 40000u);
        bus.g_tgt = bus.olev;
        bus.g_lev = bus.olev;
        for (int i = 0; i < 3; i++) bus.g_gp[i] = bus.g_start + gl_rnd() % (r - bus.g_gl + 1);
        bus.g_fi = 2;                                     /* in over 12 ms, out over 23 */
        bus.g_fo = 1;
        bus.g_pk = (uint8_t)(k + 1);
        return;
    }
    if (k == PF_OCTU || k == PF_OCTD) {                   /* the live sound through the grains: no slice */
        gl_start(bus.gw, 0, 0, k == PF_OCTU ? GM_PSU : GM_PSD, k == PF_OCTU ? 32768 : 29205);   /* (down: its taps nearer, the bass 1 dB up) */
        gl_grains_init(k == PF_OCTU ? PS_UP : PS_DN);
        bus.g_fi = bus.g_fo = 4;
        bus.g_pk = (uint8_t)(k + 1);
        return;
    }
    if (k == PF_SPIN) {                                   /* the live sound from here, pulled back and spun backwards */
        uint32_t t1 = CLAMP(six >> 1, 256u, 1024u), t2 = six * 4;
        if (t1 + t2 > 12000u) t2 = 12000u - t1;           /* (what it reads back, about t1 + t2: within the ring) */
        gl_start(bus.gw - 2, t1 + t2 + 64, 0, GM_SPIN, 32768);
        bus.g_srt = (int32_t)G_UNITY;
        bus.g_st = 0;
        bus.g_t1 = t1;
        bus.g_t2 = t2;
        bus.g_pk = (uint8_t)(k + 1);
        return;
    }
    if (k == PF_SKIP) {                                   /* the live sound, until a sixteenth's dice skip (gl_skip) */
        gl_start(bus.gw, 0, 0, GM_SKIP, 32768);
        bus.g_env = 0;
        bus.g_fi = 0;                                     /* (its level gl_skip's; let go, out over 2.9 ms) */
        bus.sk_on = bus.sk_xf = 0;
        bus.sk_mix = 0;
        bus.sk_ph = 0;
        bus.sk_grid = bus.g_grid[0];                      /* (the first dice at the next sixteenth) */
        bus.g_pk = (uint8_t)(k + 1);
        return;
    }
    if (k > PF_STUT && k != PF_SCAT && k != PF_ROLL) return;   /* (the rest of bank B and C: no ring) */
    int mk = k == PF_SCAT ? GM_SCAT : k == PF_ROLL ? GM_PROLL : -1;
    if (k == PF_SCAT) k = PF_REV;                         /* (the scatter's slices: the beat the reverse plays) */
    if (k == PF_ROLL) k = PF_R4;                          /* (the roll's: the quarter's, halved a beat at a time) */
    if (k == PF_STOP) {                                   /* the live sound from here, slowing over a beat */
        gl_start(bus.gw - 2, GL_MAX, 0, GM_STOP, 32768);
        bus.g_dec = G_UNITY / (six * 4 > 64 ? six * 4 : 64);
        bus.g_fo = 2;                                     /* (its landing: 12 ms) */
        bus.g_dip = 32767;
        bus.g_pk = (uint8_t)(k + 1);
        return;
    }
    static const uint8_t EIGHTHS[7] = {32, 16, 8, 4, 32, 0, 4};   /* the slice in eighths of a sixteenth */
    static const uint8_t GRID[7] = {2, 1, 0, 0, 2, 0, 0};         /* locked to the last beat, eighth, sixteenth */
    /* its lap to a 4096th of a sample, as the sequencer's sixteenth is (bsps, Q8): a lap of whole samples drifted off
     * the beat, up to 5 ms a minute at 120 BPM, heard once a repeat could be latched for minutes (1.11) */
    uint32_t lq = bsps * EIGHTHS[k], len = lq >> 12;      /* (bsps * 32 under 2^28 down to 30 BPM: a word) */
    int res = GRID[k];
    while (len > GL_MAX) { lq >>= 1; len = lq >> 12; if (res) res--; }   /* (slower than 85 BPM a quarter is too long: an eighth) */
    if (len < 32) { len = 32; lq = 32u << 12; }
    uint32_t space = six << res, e = bus.gw - bus.g_grid[res];
    if (!brun || e >= space + (six >> 1)) e = 0, bus.g_grid[res] = bus.gw;   /* no grid: from now */
    /* a repeat's slice begins on the grid (its first time round the live sound coming in, so it starts on the
     * attack); the reverse plays the beat that ended there */
    uint32_t at = bus.g_grid[res] - (k == PF_REV ? len : 0);
    gl_start(at, len, e % len, mk >= 0 ? mk : k == PF_REV ? GM_REV : k == PF_STUT ? GM_GATE : GM_RPT, 32768);
    bus.g_lenq = lq;
    bus.g_sc[0] = bus.g_sc[1] = (uint8_t)((e % len) / (len >> 2));   /* (a scatter starts where it is, a beat back) */
    bus.g_rl = 0;
    bus.g_pk = (uint8_t)((mk == GM_SCAT ? PF_SCAT : mk == GM_PROLL ? PF_ROLL : k) + 1);
}

static int32_t (*dub_io(int ti))[M2K_SUB] { return bus.dub_t == ti + 1 ? bus.dub_io : 0; }
static int dub_on(void) { return perf.on[PF_DUB] || bus.dub_snd > 0; }
static void dub_end(void) { bus.dub_t = 0; }

/* DUB borrows a track's delay line, one the pattern leaves free: its kit's send 0 (DSND 64), no lock on it, no LFO
 * on it, the line asleep. The track number + 1, 0 when none is */
static int dub_line(void)
{
    if (bus.dub_t) return bus.dub_t;                      /* (still ringing: the same line) */
    const m2k_pattern_t *p = PAT(cur_pat);
    for (int t = M2K_TRACKS - 1; t >= 0; t--) {
        int ok = p->kit[t][P_DSND] == 64 && trk[t].dsleep;
        for (int i = 0; ok && i < M2K_LOCKS; i++) ok = !(p->lock[i].param == P_DSND && p->lock[i].trk == t);
        for (int u = 0; ok && u < M2K_TRACKS; u++)
            for (int l = 0; l < 3; l++) {
                const uint8_t *b = &p->kit[u][P_LFO + 8 * l];
                if (b[L_DEST] == P_DSND + 1 && trck_of(b[L_TRCK]) == t) ok = 0;
            }
        if (ok) return t + 1;
    }
    return 0;
}

/* a key's effect on (down) or off; 0 when it cannot play (the key then holds nothing) */
static int bus_perform(int k, int down)
{
    if (k < 0 || k >= PF_COUNT) return 0;
    if (k == PF_DUB && down) {
        int t = dub_line();
        if (!t) return 0;
        if (!bus.dub_t) {                                 /* the line's from rest: at DUB's time at once */
            trk_t *d = &trk[t - 1];
            d->dt_q8 = (int32_t)(((uint32_t)DUB_TIM * (sps_q8 >> 5) + 128) & ~255u);
        }
        bus.dub_t = (uint8_t)t;
    }
    perf.on[k] = (uint8_t)down;
    if (!pf_ring(k)) return 1;
    if (!down) {                                          /* let go: its own effect ends (a stop spins up first) */
        if (bus.g_next == k + 1) bus.g_next = 0;
        if (bus.g_on && bus.g_pk == k + 1) {
            bus.g_pk = 0;
            /* a stop spins up: from where it is while it still moves, else (under a quarter of the speed) it dips out
             * and lands (gl_stop_land) */
            if (bus.g_mode == GM_STOP) bus.g_spin = bus.g_rate < G_UNITY / 4 ? 2 : 1;
            else bus.g_held = 0;
        }
        return 1;
    }
    if (bus.g_on) {                                       /* the one sounding fades out first, then this begins */
        bus.g_next = (uint8_t)(k + 1);
        bus.g_pk = 0;
        bus.g_spin = 0;
        bus.g_held = 0;
        return 1;
    }
    bsps = sps_q8;                                        /* (a key's: at the tempo now) */
    brun = (uint8_t)seq_running();
    gl_perform(k);
    return 1;
}

/* the sequencer calls this on each of the pattern's steps: the grid's places PERFORM's repeats lock to */
static void bus_step(int s)
{
    bus.g_grid[0] = bus.gw;
    if (!(s & 1)) bus.g_grid[1] = bus.gw;
    if (!(s & 3)) bus.g_grid[2] = bus.gw;
}

/* FREEZE and the octaves, a half-rate sample: three Hann grains a third of one apart (their windows' squares sum to
 * a constant, so the sum holds its level whether the grains agree or not). A freeze's grain reads its own place in
 * the slice at pitch, a new place each time round; up, a grain reads at twice the speed from a grain and a bit back
 * to just behind the write ([1 2 1] first, so the top folds back 6 dB down and more); down, at half from just behind
 * to half a grain back */
#define GR_GAIN 30894                  /* 1 / sqrt(9 / 8): the three windows' power */
static void gl_grains(int32_t *pl, int32_t *pr)
{
    const uint32_t M = GL_LEN - 1, G = bus.g_gl, w = bus.gw - 1;     /* (w: the newest sample written) */
    int mode = bus.g_mode;
    int32_t al = 0, ar = 0;
    for (uint32_t i = 0; i < 3; i++) {
        uint32_t ph = bus.g_gph + i * bus.g_g3;
        if (ph >= G) ph -= G;
        int32_t s = sinp(ph * bus.g_wst), win = (s * s) >> 15;       /* (ph g_wst < 2^31; |s| < 2^15) */
        int32_t xl, xr;
        if (mode == GM_FRZ) {
            if (!ph) bus.g_gp[i] = bus.g_start + gl_rnd() % (bus.g_len - G + 1);
            uint32_t k = bus.g_gp[i] + ph;
            xl = gl_buf[k & M][0];
            xr = gl_buf[k & M][1];
        } else if (mode == GM_PSU) {
            uint32_t k = w - PS_DMIN - G + ph;
            xl = (gl_buf[(k - 1) & M][0] + 2 * gl_buf[k & M][0] + gl_buf[(k + 1) & M][0]) >> 2;
            xr = (gl_buf[(k - 1) & M][1] + 2 * gl_buf[k & M][1] + gl_buf[(k + 1) & M][1]) >> 2;
        } else {
            uint32_t k = w - PS_DMIN - ((ph + 1) >> 1);
            xl = gl_buf[k & M][0];
            xr = gl_buf[k & M][1];
            if (ph & 1) { xl = (xl + gl_buf[(k + 1) & M][0]) >> 1; xr = (xr + gl_buf[(k + 1) & M][1]) >> 1; }
        }
        al += (xl * win) >> 15;
        ar += (xr * win) >> 15;
    }
    bus.g_gph = bus.g_gph + 1 >= G ? 0 : bus.g_gph + 1;
    al = (al * GR_GAIN) >> 15;                            /* (|al| < 1.5 x 2^15) */
    ar = (ar * GR_GAIN) >> 15;
    if (mode == GM_FRZ) {                                 /* (its gain: bus_block's, by the output's level, glided here) */
        bus.g_agc += (bus.g_agt - bus.g_agc) >> 8;
        al = (al * bus.g_agc) >> 15;                      /* (|al| < 2^16, the gain < 2^15.3) */
        ar = (ar * bus.g_agc) >> 15;
        al = CLAMP(al, -32767, 32767);
        ar = CLAMP(ar, -32767, 32767);
    }
    *pl = al;
    *pr = ar;
}

/* a stop let go near rest, dipped out: its read moved (unheard) to where an eighth's spin-up from rest (which reads
 * half an eighth) ends a beat behind the write (half one, slower than 85 BPM), so it lands in time, on the beat as
 * the sound plays it, and fades into it over 12 ms */
static void gl_stop_land(void)
{
    uint32_t t = (bsps >> 8) > 64 ? (bsps >> 8) : 64, back = (bsps >> 9) * 4;
    while (back > GL_MAX - t) back >>= 1;
    bus.g_start = bus.gw - (back - t / 2);
    bus.g_pos = 0;
    bus.g_rate = 0;
    bus.g_spin = 1;
}

/* SCATTER's slice d (0-3 of the beat, 4 reversed, 8 its first half twice), its sample o (past the slice: where it
 * goes on, for the crossfade into the next) */
static inline uint32_t sc_at(uint32_t d, uint32_t o, uint32_t sl)
{
    uint32_t pos = d & 4 ? sl - 1 - o : d & 8 ? (o < sl / 2 ? o : o - sl / 2) : o;
    return bus.g_start + (d & 3) * sl + pos;
}

/* SKIP (bank C, 1.12; AFFINE's, written again): a disc that can't read. At each sixteenth (the sequencer's, bus_step;
 * stopped, a free one at the tempo) 9 times in 10 the sixteenth just played repeats, once to three times, its read
 * slowing as the laser seeks (0.45 of its speed lost a slice, to a quarter at least: AFFINE's SEEK at 0.3, the pitch
 * sagging with it), then the music goes on for a sixteenth at least. In and out, and every restart, crossfaded over
 * GL_XF (AFFINE ramps each cut 32 samples to silence; its own dice are the bus's, bus.grng) */
#define SK_CHANCE 922u                 /* of 1024: 0.9 */
#define SK_SAG 7549747u                /* the speed lost over a slice, Q24: 1.5 x SEEK 0.3 */
#define SK_MAX 4000u                   /* the longest slice (half rate; slower than 83 BPM, a 1/32): three repeats and the
                                        * write on past them stay within the ring */
static void sk_again(void)             /* the slice from its start, the read before it crossfaded out */
{
    bus.sk_op = bus.g_pos;
    bus.sk_or = bus.g_rate;
    bus.sk_xf = (uint8_t)GL_XF;
    bus.g_pos = 0;
}
static __attribute__((noinline)) void gl_skip(void)
{
    const uint32_t M = GL_LEN - 1, six = (bsps >> 9) > 64 ? bsps >> 9 : 64;
    int edge;
    if (brun) { edge = bus.g_grid[0] != bus.sk_grid; bus.sk_grid = bus.g_grid[0]; }
    else if ((edge = ++bus.sk_ph >= six)) bus.sk_ph = 0;
    if (edge) {
        if (bus.sk_on && bus.sk_reps) { bus.sk_reps--; sk_again(); }   /* again */
        else if (bus.sk_on) bus.sk_on = 0;                /* the music goes on */
        else if ((gl_rnd() & 1023u) < SK_CHANCE) {        /* the laser slips: the sixteenth just played, from its start */
            uint32_t len = six;
            while (len > SK_MAX) len >>= 1;
            bus.g_start = (brun ? bus.g_grid[0] : bus.gw) - len;
            bus.g_len = len;
            bus.g_pos = 0;
            bus.g_rate = G_UNITY;
            bus.g_dec = SK_SAG / len;
            bus.sk_reps = (uint8_t)(gl_rnd() % 3u);
            bus.sk_on = 1;
            bus.sk_xf = 0;
        }
    }
    /* its share is the event's level (g_fi 0: bus_block leaves it to this while the key holds; let go, it fades) */
    if (bus.sk_on) { if (bus.sk_mix < 1024) bus.sk_mix += 1024 / (int32_t)GL_XF; }
    else if (bus.sk_mix) bus.sk_mix -= 1024 / (int32_t)GL_XF;
    if (bus.g_held) bus.g_env = bus.sk_mix;
    bus.gprev_l = bus.gout_l;
    bus.gprev_r = bus.gout_r;
    if (!bus.sk_mix) { bus.gout_l = bus.gout_r = 0; return; }   /* (the live sound: nothing read) */
    uint32_t k = bus.g_start + (bus.g_pos >> 12);
    int32_t fr = (int32_t)(bus.g_pos & 4095);
    int32_t l = gl_buf[k & M][0] + (((gl_buf[(k + 1) & M][0] - gl_buf[k & M][0]) * fr) >> 12);
    int32_t r = gl_buf[k & M][1] + (((gl_buf[(k + 1) & M][1] - gl_buf[k & M][1]) * fr) >> 12);
    if (bus.sk_xf) {                                      /* a restart: the read before it goes on, fading out */
        uint32_t j = bus.g_start + (bus.sk_op >> 12);
        int32_t fo = (int32_t)(bus.sk_op & 4095), w = (int32_t)(GL_XF - bus.sk_xf) << 6;   /* (Q12) */
        int32_t ol = gl_buf[j & M][0] + (((gl_buf[(j + 1) & M][0] - gl_buf[j & M][0]) * fo) >> 12);
        int32_t orr = gl_buf[j & M][1] + (((gl_buf[(j + 1) & M][1] - gl_buf[j & M][1]) * fo) >> 12);
        l = ol + (((l - ol) * w) >> 12);                  /* (|l - ol| < 2^17) */
        r = orr + (((r - orr) * w) >> 12);
        bus.sk_op += bus.sk_or >> 12;
        bus.sk_xf--;
    }
    bus.gout_l = l;
    bus.gout_r = r;
    bus.g_pos += bus.g_rate >> 12;                        /* the laser seeks: slower each sample, to a quarter */
    bus.g_rate = bus.g_rate > G_UNITY / 4 + bus.g_dec ? bus.g_rate - bus.g_dec : G_UNITY / 4;
    if ((bus.g_pos >> 12) >= bus.g_len) { sk_again(); bus.g_rate = G_UNITY; }   /* (round a short slice: at speed) */
}

/* one half-rate sample of the event: the wet's next (gout), its read moved on */
static void gl_tick(void)
{
    const uint32_t M = GL_LEN - 1;
    uint32_t p = bus.g_pos >> 12, len = bus.g_len, mode = bus.g_mode;
    int32_t fr = (int32_t)(bus.g_pos & 4095), l, r;
    if (mode == GM_SPIN) {                                /* SPIN: the speed and the read, then out */
        uint32_t st = bus.g_st++, t1 = bus.g_t1, t2 = bus.g_t2;
        if (st < t1) bus.g_srt = (int32_t)G_UNITY - (int32_t)(((st << 12) / t1) << 14);      /* pulled: 1 to -3 */
        else if (st < t1 + t2) {                          /* let spin: -3 to rest, slowing as (1 - u)^2 */
            int32_t v = 4096 - (int32_t)(((st - t1) << 12) / t2);
            bus.g_srt = -(((v * v) >> 12) * 12288);
        } else bus.g_srt = 0;
        uint32_t k = bus.g_start + (bus.g_pos >> 12);
        int32_t a = bus.g_srt < 0 ? -bus.g_srt : bus.g_srt;
        if (a > (int32_t)G_UNITY) {                       /* past its speed: [1 2 1] against the fold */
            l = (gl_buf[(k - 1) & M][0] + 2 * gl_buf[k & M][0] + gl_buf[(k + 1) & M][0]) >> 2;
            r = (gl_buf[(k - 1) & M][1] + 2 * gl_buf[k & M][1] + gl_buf[(k + 1) & M][1]) >> 2;
            a = (int32_t)G_UNITY;
        } else {
            l = gl_buf[k & M][0] + (((gl_buf[(k + 1) & M][0] - gl_buf[k & M][0]) * fr) >> 12);
            r = gl_buf[k & M][1] + (((gl_buf[(k + 1) & M][1] - gl_buf[k & M][1]) * fr) >> 12);
        }
        int32_t sp = a >> 9, g = (sp * (65536 - sp)) >> 15;          /* (as the stop's: s (2 - s)) */
        bus.gprev_l = bus.gout_l;
        bus.gprev_r = bus.gout_r;
        bus.gout_l = (l * g) >> 15;
        bus.gout_r = (r * g) >> 15;
        bus.g_pos += (uint32_t)(bus.g_srt >> 12);
        return;
    }
    if (mode == GM_SCAT) {                                /* SCATTER: a quarter of the beat at a time, from anywhere in it */
        uint32_t sl = len >> 2, o = p % sl, i = p / sl;
        if (!o) {
            uint32_t q = gl_rnd();
            uint8_t d = (q & 7) < 3 ? (uint8_t)i : (uint8_t)((q >> 3) & 3);   /* (3 in 8 where it was) */
            if (d != i && !((q >> 5) & 3)) d |= 4;        /* reversed */
            else if (d != i && !((q >> 7) & 7)) d |= 8;   /* its first half twice */
            bus.g_sc[1] = bus.g_sc[0];
            bus.g_sc[0] = d;
        }
        uint32_t k = sc_at(bus.g_sc[0], o, sl);
        l = gl_buf[k & M][0];
        r = gl_buf[k & M][1];
        if (o < GL_XF) {                                  /* the slice before, on past its end, crossfaded out */
            uint32_t j = sc_at(bus.g_sc[1], o + sl, sl);
            int32_t w = (int32_t)(o << 12) / (int32_t)GL_XF;
            l = gl_buf[j & M][0] + (((l - gl_buf[j & M][0]) * w) >> 12);
            r = gl_buf[j & M][1] + (((r - gl_buf[j & M][1]) * w) >> 12);
        }
        bus.gprev_l = bus.gout_l;
        bus.gprev_r = bus.gout_r;
        bus.gout_l = l;
        bus.gout_r = r;
        bus.g_pos += 1u << 12;
        if ((bus.g_pos >> 12) >= len) bus.g_pos -= len << 12;
        return;
    }
    if (mode == GM_SKIP) { gl_skip(); return; }           /* (out of line: the other modes' code as it was) */
    if (mode == GM_FRZ || mode == GM_PSU || mode == GM_PSD) {
        gl_grains(&l, &r);
        bus.gprev_l = bus.gout_l;
        bus.gprev_r = bus.gout_r;
        bus.gout_l = l;
        bus.gout_r = r;
        return;
    }
    if (mode == GM_STOP) {
        uint32_t k = bus.g_start + p;
        l = gl_buf[k & M][0] + (((gl_buf[(k + 1) & M][0] - gl_buf[k & M][0]) * fr) >> 12);
        r = gl_buf[k & M][1] + (((gl_buf[(k + 1) & M][1] - gl_buf[k & M][1]) * fr) >> 12);
        /* a tape's head gives less as it slows: s (2 - s), nearly its square root, so the fall is heard to the end */
        int32_t sp = (int32_t)(bus.g_rate >> 9), a = (sp * (65536 - sp)) >> 15;        /* Q15 */
        if (bus.g_spin == 2) {                            /* let go near rest: out over 1.5 ms, then the landing */
            bus.g_dip = bus.g_dip > 1024 ? bus.g_dip - 1024 : 0;
            a = (a * bus.g_dip) >> 15;
            if (!bus.g_dip) { gl_stop_land(); bus.g_dip = 32767; }
        }
        l = (l * a) >> 15;
        r = (r * a) >> 15;
        if (bus.g_spin == 1) {                              /* let go: back up to speed over an eighth, then out */
            uint32_t up = G_UNITY / ((bsps >> 8) > 64 ? (bsps >> 8) : 64);
            bus.g_rate = bus.g_rate + up >= G_UNITY ? G_UNITY : bus.g_rate + up;
            if (bus.g_rate == G_UNITY) { bus.g_spin = 3; bus.g_held = 0; }   /* (3: landed, at speed) */
        } else if (!bus.g_spin) bus.g_rate = bus.g_rate > bus.g_dec ? bus.g_rate - bus.g_dec : 0;   /* slowing in a straight line */
    } else {                                              /* (a repeat, at pitch, reads whole samples) */
        int rev = mode == GM_REV;
        uint32_t k = rev ? bus.g_start + len - 1 - p : bus.g_start + p;
        l = gl_buf[k & M][0];
        r = gl_buf[k & M][1];
        uint32_t xf = len >> 2 < GL_XF ? len >> 2 : GL_XF;
        if (p + xf >= len) {                              /* the seam: into what leads to the slice's start */
            uint32_t j = rev ? bus.g_start + 2 * len - 1 - p : bus.g_start + p - len;
            int32_t w = (int32_t)((p + xf - len) << 12) / (int32_t)xf;   /* Q12 */
            l += ((gl_buf[j & M][0] - l) * w) >> 12;
            r += ((gl_buf[j & M][1] - r) * w) >> 12;
        }
        if (mode == GM_GATE) {                            /* open the first half of each time round, edges faded */
            uint32_t on = len >> 1, e = len >> 3 < GL_XF / 2 ? len >> 3 : GL_XF / 2;
            int32_t gt = p < e ? (int32_t)((p << 12) / e) : p < on - e ? 4096 : p < on ? (int32_t)(((on - p) << 12) / e) : 0;
            l = (l * gt) >> 12;
            r = (r * gt) >> 12;
        }
    }
    bus.gprev_l = bus.gout_l;
    bus.gprev_r = bus.gout_r;
    bus.gout_l = l;
    bus.gout_r = r;
    bus.g_pos += bus.g_rate >> 12;
    if (mode != GM_STOP && bus.g_pos >= bus.g_lenq) {     /* (a lap a sample longer now and then: its read reaches
                                                           * len, the seam's crossfade then wholly its start's) */
        bus.g_pos -= bus.g_lenq;
        /* ROLL: halved once its laps make a beat (a quarter, two eighths, four sixteenths), to a 1/32 */
        if (mode == GM_PROLL && ++bus.g_rl >= (bsps >> 9) * 4 / len && len > (bsps >> 10)) {
            bus.g_lenq >>= 1;
            bus.g_len = bus.g_lenq >> 12;
            bus.g_rl = 0;
        }
    }
}

/* the ring's place w is one the event still reads: its slice and seams a lap on (its first time round they are
 * the live sound coming in), or what a stop will read spinning up */
static inline int gl_kept(uint32_t w)
{
    if (bus.g_mode == GM_PSU || bus.g_mode == GM_PSD) return 0;   /* (a grain and a bit behind the write) */
    /* a stop reads behind the write by at most half its beat while it slows, nothing at rest, and lands from fresh
     * sound (gl_stop_land): it keeps nothing (it kept what was ahead of its read from the press, so it slowed down
     * the sound of a ring's lap before, 0.74 s) */
    if (bus.g_mode == GM_STOP) return 0;
    if (bus.g_mode == GM_SKIP && !bus.sk_mix) return 0;  /* (between skips it reads nothing) */
    if (bus.g_mode == GM_SPIN) {                          /* what it spins back over, behind where it began */
        uint32_t d = w - (bus.g_start - bus.g_len - GL_XF);
        return d >= GL_LEN && (d & (GL_LEN - 1)) < bus.g_len + 2 * GL_XF;
    }
    uint32_t d = w - (bus.g_start - GL_XF);
    return d >= GL_LEN && (d & (GL_LEN - 1)) < bus.g_len + 2 * GL_XF;
}

static uint32_t isqrt32(uint32_t x)
{
    uint32_t r = 0, b = 1u << 30;
    while (b > x) b >>= 2;
    while (b) { if (x >= r + b) { x -= r + b; r = (r >> 1) + b; } else r >>= 1; b >>= 2; }
    return r;
}

/* 2^(-e / 65536), Q16: T_EXP2F's 1/256 octaves read between (a long tail's gain a line a pass wants the finer steps) */
static uint32_t exp2neg(uint32_t e)
{
    uint32_t n = e >> 16, g = 65536u - (e & 0xFFFFu);           /* 2^-e = 2^(g / 65536) / 2^(n + 1) */
    if (n > 15) return 0;
    if (g == 65536u) return 65536u >> n;
    uint32_t i = g >> 8, r = g & 255u, a = T_EXP2F[i], b = i < 255 ? T_EXP2F[i + 1] : 131072u;
    return (a + (((b - a) * r) >> 8)) >> (n + 1);
}

/* the reverb's coefficients for DCAY v, DAMP d, the room as it stands, at the lines' mean length (the matrix shares
 * every pass out among them): their gain g for the RT60, and their damping, a one-pole whose loss at the top gives the
 * top DAMP's share a of the bottom's RT60 (there the loop wants g^(1/a): the pole's r = g^(1/a - 1) = (1 - b) /
 * (1 + b)) */
#define RV_MEAN 855                    /* (683 + 797 + 907 + 1031) / 4 */
static void rv_coef(int v, int d)
{
    int32_t len = (int32_t)((RV_MEAN * bus.rsz) >> 4);                                /* Q8 samples */
    uint32_t e = (uint32_t)mul_sh((int32_t)T_RV_K[v], len, 16);                       /* Q16 octaves, < 2^16 */
    bus.rgh = (int32_t)(exp2neg(e) >> 2);
    uint32_t r = exp2neg((e * T_RV_DA[d]) >> 8);                                      /* 1/a - 1 Q8: < 2^28 */
    uint32_t bq = ((65536u - r) << 15) / (65536u + r);
    bus.ra = 32767 - (int32_t)(bq > 31000u ? 31000u : bq);
    bus.rv_v = (uint8_t)v;
    bus.rv_d = (uint8_t)d;
    bus.rv_s = bus.rsz;
}

static void rv_clear(void)
{
    m_set(rv_buf, 0, sizeof rv_buf);
    m_set(bus.rlp, 0, sizeof bus.rlp);
    m_set(bus.rlr, 0, sizeof bus.rlr);
    m_set(bus.rq, 0, sizeof bus.rq);
    bus.rdq[0] = bus.rdq[1] = bus.rrq[0] = bus.rrq[1] = 0;
    bus.rbw = bus.rbr = bus.rv_l = bus.rv_r = 0;
    bus.rquiet = 0;
}

/* a block of the reverb in three passes (each with few enough values live to stay in registers): the input through
 * its top and the diffusers; the lines; out into the mix. Specialised for a room settled (each line's read whole
 * samples behind its write: a read between two dulls the top every pass) or gliding (between them) */
/* SHIMMER (PERFORM): the bus thrown into the reverb at DCAY 92 (7 s) and DAMP 24 (its top a little sooner), the
 * longest line read back an octave up (three Hann grains of 44 ms at twice the speed, its last 1033 samples) into
 * every line's input: each pass round an octave more, as it dies */
#define SH_G 960u
#define SH_V 92
#define SH_D 24
#define SH_FB 3277                     /* the octave's share back in, Q15 (0.1: 0.35 ran away, the loop over unity) */
static inline __attribute__((always_inline)) void rv_run(const int32_t *rsend, int32_t *L, int32_t *R, int v,
                                                         int damp, int32_t fade, int32_t rs_, int32_t rc_, int glide,
                                                         int32_t shim)
{
    int32_t xin[M2K_SUB / 2], ol[M2K_SUB / 2], orr[M2K_SUB / 2];
    int16_t *b = rv_buf;
    const uint32_t M = RV_N - 1;
    uint32_t w0 = bus.rw;
    {
        int32_t gi = T_RV_GI[v], bw = T_RV_BW[damp], rbw = bus.rbw, rbr = bus.rbr, dq0 = bus.rdq[0], dq1 = bus.rdq[1];
        uint32_t w = w0;
        for (int k = 0; k < M2K_SUB / 2; k++, w++) {
            int32_t x = (((rsend[2 * k] + rsend[2 * k + 1]) >> 3) * gi) >> 15;   /* (six tracks' sends at most: < 2^16) */
            if (bw < 32767) {                             /* the input's top, its remainder carried */
                int32_t q = (x - rbw) * bw + rbr;
                rbw += q >> 15;
                rbr = q & 32767;
                x = rbw;
            }
            /* two allpasses smear the attack */
            int32_t d = b[(RV_AT[4] - RD_LEN[0] + w) & M], p = d * 20480 + dq0, u = sat16(x + (p >> 15));
            dq0 = p & 32767;
            b[(RV_AT[4] + w) & M] = (int16_t)u;
            x = d - ((u * 20480 + 16384) >> 15);
            d = b[(RV_AT[5] - RD_LEN[1] + w) & M]; p = d * 20480 + dq1; u = sat16(x + (p >> 15));
            dq1 = p & 32767;
            b[(RV_AT[5] + w) & M] = (int16_t)u;
            xin[k] = d - ((u * 20480 + 16384) >> 15);
        }
        bus.rbw = rbw; bus.rbr = rbr; bus.rdq[0] = dq0; bus.rdq[1] = dq1;
    }
    {
        uint32_t rd[4];
        int32_t fr[4];
        for (int c = 0; c < 4; c++) {
            int32_t d = (int32_t)((RV_LEN[c] * bus.rsz) >> 4);                   /* Q8 */
            if (!glide) d = (d + 128) & ~255;
            rd[c] = RV_AT[c] - (uint32_t)(d >> 8);
            fr[c] = d & 255;
        }
        int32_t a = bus.ra, h = bus.rgh;
        int32_t lp0 = bus.rlp[0], lp1 = bus.rlp[1], lp2 = bus.rlp[2], lp3 = bus.rlp[3];
        int32_t lr0 = bus.rlr[0], lr1 = bus.rlr[1], lr2 = bus.rlr[2], lr3 = bus.rlr[3];
        int32_t q0 = bus.rq[0], q1 = bus.rq[1], q2 = bus.rq[2], q3 = bus.rq[3], rr0 = bus.rrq[0], rr1 = bus.rrq[1];
        uint32_t sph = bus.sh_ph;
        int32_t shp = bus.sh_hp;
        uint32_t w = w0;
#define RV_RD(c) (glide ? b[(rd[c] + w) & M] + (((b[(rd[c] + w - 1) & M] - b[(rd[c] + w) & M]) * fr[c] + 128) >> 8) \
                        : b[(rd[c] + w) & M])
#define RV_LP(s, lp, lr) do { int32_t q_ = ((s) - lp) * a + lr; lp += q_ >> 15; lr = q_ & 32767; } while (0)
        for (int k = 0; k < M2K_SUB / 2; k++, w++) {
            int32_t s0 = RV_RD(0), s1 = RV_RD(1), s2 = RV_RD(2), s3 = RV_RD(3);
            RV_LP(s0, lp0, lr0);                          /* (|s - lp| < 2^16) */
            RV_LP(s1, lp1, lr1);
            RV_LP(s2, lp2, lr2);
            RV_LP(s3, lp3, lr3);
            /* (the angle under 0.2 rad: each sum under 2^31) */
            int32_t p1 = rc_ * lp1 - rs_ * lp3 + rr0, p3 = rs_ * lp1 + rc_ * lp3 + rr1;
            rr0 = p1 & 32767;
            rr1 = p3 & 32767;
            int32_t y1 = p1 >> 15, y3 = p3 >> 15;
            int32_t s01 = lp0 + y1, d01 = lp0 - y1, s23 = lp2 + y3, d23 = lp2 - y3;
            /* the matrix's rows (< 2^17) by the gain / 2 (under 2^14), each with its remainder */
            int32_t f0 = (s01 + s23) * h + q0, f1 = (d01 + d23) * h + q1, f2 = (s01 - s23) * h + q2, f3 = (d01 - d23) * h + q3;
            q0 = f0 & 32767; q1 = f1 & 32767; q2 = f2 & 32767; q3 = f3 & 32767;
            int32_t x = xin[k];
            if (shim) {                                   /* SHIMMER: the longest line an octave up, back in */
                int32_t s = 0;
                for (uint32_t t = 0; t < 3; t++) {
                    uint32_t ph = sph + t * (SH_G / 3), j = RV_AT[3] + w - 1 - 3 - SH_G + ph;
                    if (ph >= SH_G) ph -= SH_G, j -= SH_G;
                    int32_t sn = sinp(ph * (0x80000000u / SH_G)), wn = (sn * sn) >> 15;
                    s += (((b[(j - 1) & M] + 2 * b[j & M] + b[(j + 1) & M]) >> 2) * wn) >> 15;   /* ([1 2 1]: no fold) */
                }
                sph = sph + 1 >= SH_G ? 0 : sph + 1;
                /* a high-pass at 240 Hz first: an octave of the bass's, the taps agreeing, would feed the lines back
                 * more than they lose a pass (DC's stays DC) and grow without end */
                shp += ((s - shp) * 2190) >> 15;
                x += ((s - shp) * shim) >> 15;            /* (|s| < 1.5 x 2^15) */
            }
            b[(RV_AT[0] + w) & M] = (int16_t)sat16(x + (f0 >> 15));
            b[(RV_AT[1] + w) & M] = (int16_t)sat16((f1 >> 15) - x);
            b[(RV_AT[2] + w) & M] = (int16_t)sat16(x + (f2 >> 15));
            b[(RV_AT[3] + w) & M] = (int16_t)sat16((f3 >> 15) - x);
            /* out before the damping: each pass darker than the last, the first as it came in */
            ol[k] = s0 + s2;
            orr[k] = -s1 - s3;
        }
#undef RV_RD
#undef RV_LP
        bus.rw = w;
        bus.rlp[0] = lp0; bus.rlp[1] = lp1; bus.rlp[2] = lp2; bus.rlp[3] = lp3;
        bus.rlr[0] = lr0; bus.rlr[1] = lr1; bus.rlr[2] = lr2; bus.rlr[3] = lr3;
        bus.rq[0] = q0; bus.rq[1] = q1; bus.rq[2] = q2; bus.rq[3] = q3;
        bus.rrq[0] = rr0; bus.rrq[1] = rr1;
        bus.sh_ph = sph;
        bus.sh_hp = shp;
    }
    {
        int32_t go = bus.rgo, pl = bus.rv_l, pr = bus.rv_r;     /* (T_RV_GO[v], glided) */
        if (fade < 32767) go = (go * fade) >> 15;         /* (go < 2^15) */
        for (int k = 0; k < M2K_SUB / 2; k++) {
            int32_t l = (ol[k] * go) >> 12, r = (orr[k] * go) >> 12;           /* (|ol| < 2^16) */
            L[2 * k] += (pl + l) >> 1; R[2 * k] += (pr + r) >> 1;            /* the half rate's in-between */
            L[2 * k + 1] += l; R[2 * k + 1] += r;
            pl = l;
            pr = r;
        }
        bus.rv_l = pl; bus.rv_r = pr;
    }
}

/* the reverb at half rate: four lines through a Hadamard matrix (each feeds all: dense soon, smooth long), damped,
 * two of them turned into each other by a swaying angle. Every recursive product carries its remainder (a tail
 * decays at its rate to the last step, not faster, and holds no DC); once the input and the lines stay within a step
 * for a whole pass it empties and sleeps. Turned to 0 its tail fades in 6 ms */
static void reverb_block(int verb, int damp, const int32_t *rsend, int32_t *L, int32_t *R, int32_t shim)
{
    int v = verb ? verb : bus.rv_v;
    if (!v) return;
    int in = 0;
    for (int i = 0; i < M2K_SUB; i++) in |= rsend[i];
    if (bus.rsleep && !in && verb == bus.rv_v) return;
    bus.rsleep = 0;
    uint32_t tgt = (uint32_t)T_RV_SZ[v] << 4;            /* the room, Q12: it glides a 4096th a block (0.3 .. 1 in 1 s) */
    int from_off = !bus.rv_v;
    if (from_off) bus.rsz = tgt;
    else if (verb && bus.rsz != tgt) bus.rsz += bus.rsz < tgt ? 1 : (uint32_t)-1;
    if (v != bus.rv_v || damp != bus.rv_d || bus.rsz != bus.rv_s) rv_coef(v, damp);
    /* its level out glides an eighth of the way a block to DCAY's (SHIMMER's DCAY and back: no jump in a tail) */
    {
        int32_t got = T_RV_GO[v], d = got - bus.rgo;
        bus.rgo = from_off || (d > -16 && d < 16) ? got : bus.rgo + d / 8;
    }
    int32_t fade = verb ? 32767 : bus.rfade;
    if (!verb) {
        bus.rfade -= 2048;
        if (bus.rfade <= 0) { rv_clear(); bus.rv_v = 0; return; }   /* the lines start empty next time */
    } else bus.rfade = 32767;
    /* the swing: lines 2 and 4 turned into each other by a small angle swaying at 0.7 Hz (energy kept, no line's
     * gain moves: a long tail's modes smeared instead of ringing) */
    bus.rmph += 1090862u;
    uint32_t ang = (uint32_t)(sinp(bus.rmph) * (int32_t)T_RV_MD[v]);
    if (shim) rv_run(rsend, L, R, v, damp, fade, sinp(ang), sinp(ang + 0x40000000u), 1, shim);   /* (gliding: whole reads too) */
    else if (bus.rsz == tgt) rv_run(rsend, L, R, v, damp, fade, sinp(ang), sinp(ang + 0x40000000u), 0, 0);
    else rv_run(rsend, L, R, v, damp, fade, sinp(ang), sinp(ang + 0x40000000u), 1, 0);
    int32_t big = 0;
    for (int c = 0; c < 4; c++) big |= bus.rlp[c] > 1 || bus.rlp[c] < -1;
    /* quiet: nothing in, the lines within a step, a whole pass of the longest */
    bus.rquiet = in || big ? 0 : bus.rquiet + M2K_SUB / 2;   /* (the lines looked at once a block) */
    if (bus.rquiet > RV_LEN[3] + 2u && verb) { rv_clear(); bus.rsleep = 1; }
}

/* LPF and HPF, a block: held, the cutoff moves from open to its far end over a bar (an octave in the same time
 * all the way), the resonance rising with it (Q 0.71 to 2.2); let go, back open in 150 ms; mixed in and out over
 * 5 ms at the open end (the two-poles start from rest unheard). Their bits in the return: the ones to run */
#define FL_LP_OPEN (F_TOP << 8)        /* 18 kHz .. 200 Hz */
#define FL_LP_FAR (443 << 8)
#define FL_HP_OPEN (124 << 8)          /* 20 Hz .. 2 kHz */
#define FL_HP_FAR (762 << 8)
#define FL_K_OPEN 23726566             /* 1 / Q, Q24: 1.414 .. 0.45 */
#define FL_K_FAR 7549747
static int bus_filters(void)
{
    int run = 0;
    for (int f = 0; f < 2; f++) {
        int held = perf.on[f ? PF_HPF : PF_LPF];
        if (!held && !bus.fmix[f]) continue;
        int32_t open = f ? FL_HP_OPEN : FL_LP_OPEN, far = f ? FL_HP_FAR : FL_LP_FAR, span = far > open ? far - open : open - far;
        if (held && !bus.fmix[f]) {                       /* from rest (the low-pass at its first sample's level) */
            m_set(bus.fl[f], 0, sizeof bus.fl[f]);
            bus.fpos[f] = open;
            if (!f) bus.fnew = 1;
        }
        int32_t d = bus.fpos[f] > open ? bus.fpos[f] - open : open - bus.fpos[f];
        if (held) {
            int32_t bar = (int32_t)((bsps >> 8) * 16u / M2K_SUB), st = span / (bar > 0 ? bar : 1) + 1;   /* blocks a bar */
            d = d + st > span ? span : d + st;
        } else {
            int32_t st = span / 413 + 1;                  /* (150 ms of blocks) */
            d = d > st ? d - st : 0;
        }
        bus.fpos[f] = far > open ? open + d : open - d;
        if (held || d) bus.fmix[f] = bus.fmix[f] + 2400 > 32767 ? 32767 : bus.fmix[f] + 2400;
        else bus.fmix[f] = bus.fmix[f] > 2400 ? bus.fmix[f] - 2400 : 0;
        int32_t u = (d << 7) / (span >> 8);              /* the way there, Q15 (d << 7 < 2^25) */
        int32_t k = FL_K_OPEN - (int32_t)mul_sh(FL_K_OPEN - FL_K_FAR, u, 15);
        bus.fgain[f] = f ? 32767 : 32767 - ((u * 9830) >> 15);   /* the low-pass's peak paid back: -3 dB at its end */
        zsvf_set(&bus.fl[f][0], fg_at(T_FG, bus.fpos[f]), (uint32_t)k);
        bus.fl[f][1].a1 = bus.fl[f][0].a1;
        bus.fl[f][1].a2 = bus.fl[f][0].a2;
        bus.fl[f][1].a3 = bus.fl[f][0].a3;
        bus.fl[f][1].k = bus.fl[f][0].k;
        if (bus.fmix[f]) run |= 1 << f;
    }
    return run;
}

/* bank C's colours (1.12; AFFINE's laws, CHOPPAH's DUCK, written again in integers): a pass over the bus's block after
 * its limiter, so none runs (and none costs) while all are off and at rest, the block as it was. In order: LO-FI, an
 * unsteady converter; CONSOLE, a TV speaker (the output's last colour, as AFFINE has it); DUCK, the mix pumping on the
 * beat. Each glides in and out (its key's), each a fixed character */
#ifndef LF_STEP
#define LF_STEP 16384u                 /* LO-FI's clock: 11025 Hz of 44100, Q16 */
#define LF_JIT 29491                   /* its period's wander, Q16: +-0.45 (AFFINE's jitter 0.5, x 0.9) */
#define LF_SH 6                        /* 10 bits: a step of 64 */
#endif
#ifndef DK_A
#define DK_A 22938                     /* DUCK's depth, Q15: 0.7 (AFFINE's 1.0 silences each beat's start) */
#endif
#define DK_FALL 132u                   /* its dip comes in on an S over 3 ms (the cubic alone falls at once: a click a beat) */
#define CO_DC 1494                     /* CONSOLE's DC blocker, Q20: 2 pi 10 Hz / 44.1 kHz */
static __attribute__((noinline)) void bus_colour(int16_t *out)
{
    int run = 0;
    /* LO-FI: a sample held at a clock of 11 kHz whose period wanders (a new one each tick, 0.55 .. 1.45 of four
     * samples), held as 10 bits dithered (TPDF, a step wide, two draws a side: bus.grng); its share in and out over
     * 10 ms */
    int32_t lf0 = bus.lf_mix;
    { int32_t d = (perf.on[PF_LOFI] ? 32767 : 0) - lf0; bus.lf_mix += d > 1214 ? 1214 : d < -1214 ? -1214 : d; }
    if (lf0 || bus.lf_mix) {
        if (!lf0) { bus.lf_ph = 0; bus.lf_nx = 65536; bus.lf_h[0] = out[0]; bus.lf_h[1] = out[1]; }   /* (from rest) */
        const int32_t m1 = bus.lf_mix, dm = m1 - lf0;
        uint32_t ph = bus.lf_ph, nx = bus.lf_nx;
        int32_t hl = bus.lf_h[0], hr = bus.lf_h[1];
        for (int i = 0; i < M2K_SUB; i++) {
            int32_t l = out[2 * i], r = out[2 * i + 1];
            if ((ph += LF_STEP) >= nx) {                  /* the clock ticks: the pair taken, crushed */
                ph -= nx;
                const uint32_t q = gl_rnd();
                /* (the top byte signed: -(q >> 24) + 128 folded into one constant read as a ROM address, build.py) */
                nx = (uint32_t)(65536 + (((int32_t)(int8_t)(q >> 24) * LF_JIT) >> 7));
                hl = sat16(((l + ((int32_t)(q & 63) - (int32_t)(q >> 6 & 63)) * (1 << (LF_SH - 6)) + (1 << (LF_SH - 1))) >> LF_SH) * (1 << LF_SH));
                hr = sat16(((r + ((int32_t)(q >> 12 & 63) - (int32_t)(q >> 18 & 63)) * (1 << (LF_SH - 6)) + (1 << (LF_SH - 1))) >> LF_SH) * (1 << LF_SH));
            }
            if (m1 == 32767 && !dm) { l = hl; r = hr; }
            else {
                const int32_t m = lf0 + ((dm * (i + 1)) >> 4);
                l += ((hl - l) * m) >> 15;                /* (|hl - l| < 2^16) */
                r += ((hr - r) * m) >> 15;
            }
            out[2 * i] = (int16_t)l;
            out[2 * i + 1] = (int16_t)r;
        }
        bus.lf_ph = ph; bus.lf_nx = nx; bus.lf_h[0] = hl; bus.lf_h[1] = hr;
        run |= bus.lf_mix != 0;
    }
    /* CONSOLE: two one-poles (TPT) from 20 kHz down to 8 kHz with its amount, blended in by it; a DC blocker at 10 Hz,
     * likewise; the sides narrowed to mono; then x - 0.1 a x^3 (no gain: 0.9 at full scale). Its amount in and out over
     * 10 ms (the cutoff's step a block), the narrowing over 93 ms (no click) */
    int32_t a = bus.co_a, n0 = bus.co_n;
    { int32_t d = (perf.on[PF_CONS] ? 32768 : 0) - a; bus.co_a = a + (d > 1214 ? 1214 : d < -1214 ? -1214 : d); }
    bus.co_n = perf.on[PF_CONS] ? (n0 < 4096 ? n0 + 16 : 4096) : (n0 > 16 ? n0 - 16 : 0);
    const int whole = a >= 32768 && n0 >= 4096 && bus.co_a >= 32768 && bus.co_n >= 4096;
    if (whole != bus.co_mono) {                           /* (whole, one side: the other's states as the sum's) */
        bus.co_mono = (uint8_t)whole;
        for (int k = 0; k < 2; k++) {
            if (whole) { bus.co_z[0][k] = (bus.co_z[0][k] + bus.co_z[1][k]) >> 1; bus.co_zr[0][k] = (bus.co_zr[0][k] + bus.co_zr[1][k]) >> 1; }
            else { bus.co_z[1][k] = bus.co_z[0][k]; bus.co_zr[1][k] = bus.co_zr[0][k]; }
        }
        if (whole) { bus.co_dc[0] = (bus.co_dc[0] + bus.co_dc[1]) >> 1; bus.co_dr[0] = (bus.co_dr[0] + bus.co_dr[1]) >> 1; }
        else { bus.co_dc[1] = bus.co_dc[0]; bus.co_dr[1] = bus.co_dr[0]; }
    }
    if (whole) {                                          /* held, settled: mono, so the sum through one side (linear:
                                                           * the same as both sides' then summed) */
        const int32_t g = T_CON_G[32];
        int32_t z0 = bus.co_z[0][0], z1 = bus.co_z[0][1], r0 = bus.co_zr[0][0], r1 = bus.co_zr[0][1];
        int32_t dc = bus.co_dc[0], dr = bus.co_dr[0];
        for (int i = 0; i < M2K_SUB; i++) {
            int32_t v = (out[2 * i] + out[2 * i + 1]) >> 1;
            int32_t t = (v - z0) * g + r0, y1 = z0 + (t >> 12);
            r0 = t & 4095;
            z0 = y1 + (t >> 12);
            t = (y1 - z1) * g + r1;
            v = z1 + (t >> 12);
            r1 = t & 4095;
            z1 = v + (t >> 12);
            t = (v - dc) * CO_DC + dr;
            dc += t >> 20;
            dr = t & 0xFFFFF;
            v = sat16(v - dc);
            v -= (v * ((((v * v) >> 15) * 3277) >> 15)) >> 15;
            out[2 * i] = out[2 * i + 1] = (int16_t)v;
        }
        bus.co_z[0][0] = z0; bus.co_z[0][1] = z1; bus.co_zr[0][0] = r0; bus.co_zr[0][1] = r1;
        bus.co_dc[0] = dc; bus.co_dr[0] = dr;
        run = 1;
    } else if (a || n0 || bus.co_a || bus.co_n) {
        if (!a && !n0) {                                  /* from rest: the low-pass where the sound is, no DC yet */
            for (int c = 0; c < 2; c++) bus.co_z[c][0] = bus.co_z[c][1] = out[c];
            m_set(bus.co_zr, 0, sizeof bus.co_zr);
            bus.co_dc[0] = bus.co_dc[1] = bus.co_dr[0] = bus.co_dr[1] = 0;
        }
        a = bus.co_a;
        const int32_t g = T_CON_G[(a + 512) >> 10], a12 = a >> 3, c3 = (3277 * a) >> 15, dn = bus.co_n - n0;
        for (int i = 0; i < M2K_SUB; i++) {
            int32_t x[2];
            for (int c = 0; c < 2; c++) {
                int32_t v = out[2 * i + c], *z = bus.co_z[c], *zr = bus.co_zr[c];
                /* (the states run past the input near 20 kHz, G / (1 - G) of it at most: under 2^19, the products a word) */
                int32_t t = (v - z[0]) * g + zr[0], y1 = z[0] + (t >> 12);
                zr[0] = t & 4095;
                z[0] = y1 + (t >> 12);
                t = (y1 - z[1]) * g + zr[1];
                int32_t y2 = z[1] + (t >> 12);
                zr[1] = t & 4095;
                z[1] = y2 + (t >> 12);
                v = a >= 32768 ? y2 : v + (((y2 - v) * a12) >> 12);
                t = (v - bus.co_dc[c]) * CO_DC + bus.co_dr[c];
                bus.co_dc[c] += t >> 20;
                bus.co_dr[c] = t & 0xFFFFF;
                v -= a >= 32768 ? bus.co_dc[c] : (bus.co_dc[c] * a12) >> 12;
                x[c] = sat16(v);
            }
            const int32_t nn = n0 + ((dn * (i + 1)) >> 4), mid = (x[0] + x[1]) >> 1;
            int32_t sd = (x[0] - x[1]) >> 1;
            sd -= (sd * nn) >> 12;                        /* (the sides narrowed: |sd| < 2^15) */
            for (int c = 0; c < 2; c++) {
                int32_t v = c ? mid - sd : mid + sd, k = (((v * v) >> 15) * c3) >> 15;
                out[2 * i + c] = (int16_t)(v - ((v * k) >> 15));
            }
        }
        run |= bus.co_a || bus.co_n;
    }
    /* DUCK: the mix's gain 1 - 0.7 (1 - its place in the beat)^3, from the beat's start (an S over 3 ms into it) back
     * to whole at its end; the beat the sequencer's (bus_step), stopped a free one at the tempo; its depth in and out
     * over 5 ms */
    int32_t d0 = bus.dk_d;
    bus.dk_d = perf.on[PF_DUCK] ? (d0 + 2400 > 32767 ? 32767 : d0 + 2400) : (d0 > 2400 ? d0 - 2400 : 0);
    if (d0 || bus.dk_d) {
        const uint32_t beat = (bsps >> 8) * 4u > 256u ? (bsps >> 8) * 4u : 256u, inv = (1u << 30) / beat;
        uint32_t el = brun ? (bus.gw - M2K_SUB / 2 - bus.g_grid[2]) * 2u + bus.g_phase : bus.dk_ph;
        if (!brun) bus.dk_ph = bus.dk_ph + M2K_SUB < beat ? bus.dk_ph + M2K_SUB : 0;
        const int32_t dd = bus.dk_d - d0;
        for (int i = 0; i < M2K_SUB; i++, el++) {
            if (el >= beat) continue;                     /* (past the beat, no step yet: whole) */
            int32_t u = (int32_t)(((beat - el) * inv) >> 15);              /* 1 - the place, Q15 (the product < 2^30) */
            int32_t u3 = (((u * u) >> 15) * u) >> 15, dep = (DK_A * (d0 + ((dd * (i + 1)) >> 4))) >> 15;
            int32_t dip = (u3 * dep) >> 15;
            if (el < DK_FALL) {                           /* (u^2 (3 - 2u), as KILL's) */
                int32_t w = (int32_t)el * (int32_t)(32768u / DK_FALL), s2 = (w * w) >> 15;
                dip = (dip * ((s2 * ((98304 - 2 * w) >> 1)) >> 14)) >> 15;
            }
            out[2 * i] = (int16_t)((out[2 * i] * (32768 - dip)) >> 15);
            out[2 * i + 1] = (int16_t)((out[2 * i + 1] * (32768 - dip)) >> 15);
        }
        run |= bus.dk_d != 0;
    }
    bus.c_run = (uint8_t)run;
}

static void bus_block(brec_t *b, int16_t *out)
{
    int32_t *L = b->L, *R = b->R;
    const int32_t *rsend = b->rs;
    const uint8_t *g = b->glob;
    /* DUB: its echoes into the mix; the mix, the send gliding in and out over 12 ms, to its line next block */
    if (bus.dub_t) {
        int32_t s0 = bus.dub_snd;
        bus.dub_snd = perf.on[PF_DUB] ? (s0 + 1024 > 32767 ? 32767 : s0 + 1024) : (s0 > 1024 ? s0 - 1024 : 0);
        for (int i = 0; i < M2K_SUB; i++) {               /* ((L + R) / 4 under 2^16, x s / 2) */
            int32_t s = s0 + (((bus.dub_snd - s0) * (i + 1)) >> 4);
            bus.dub_io[0][i] = (((L[i] + R[i]) >> 2) * (s >> 1)) >> 13;
            L[i] += bus.dub_io[1][i];
            R[i] += bus.dub_io[2][i];
            bus.dub_io[1][i] = bus.dub_io[2][i] = 0;
        }
    }
    /* SHIMMER: held, the bus into the reverb (gliding in and out over 12 ms) at its decay and colour; let go, the
     * wash rings on 4 s, the octaves still climbing, then the pattern's reverb again (its lines are the pattern's too:
     * no level tells the wash from them) */
    int verb = g[G_VERB], damp = g[G_DAMP];
    int32_t shim = 0, rs2[M2K_SUB];
    const int32_t *rs = rsend;
    if (perf.on[PF_SHIM]) bus.sh_on = 1;
    if (bus.sh_on) {
        int32_t s0 = bus.sh_snd;
        bus.sh_snd = perf.on[PF_SHIM] ? (s0 + 1024 > 32767 ? 32767 : s0 + 1024) : (s0 > 1024 ? s0 - 1024 : 0);
        for (int i = 0; i < M2K_SUB; i++) {               /* (a quarter of the mix: (L + R) / 4 under 2^16, x s / 2) */
            int32_t s = s0 + (((bus.sh_snd - s0) * (i + 1)) >> 4);
            rs2[i] = rsend[i] + ((((L[i] + R[i]) >> 2) * (s >> 1)) >> 15);
        }
        rs = rs2;
        if (verb < SH_V) verb = SH_V;
        damp = SH_D;
        shim = SH_FB;
    }
#ifdef M2K_SPU
    /* the Move's: a pattern's reverb type (G_RVTY) plays the PS1-era chip's reverb on the pattern's sends, DCAY and DAMP
     * (m2k_spu.c); the FDN then rests (DCAY 0's fade), or plays SHIMMER's wash alone on SHIMMER's send. Type 0, the
     * FDN: none of this runs past the chip's first test (at rest), the FDN's path as ever */
    const int rvty = (g[G_RVTY] * (SRV_N + 1)) >> 7;
    spu_rv_block(rvty, g[G_VERB], g[G_DAMP], bsps, rsend, L, R);
    if (rvty) {
        if (!bus.sh_on) verb = 0;
        else for (int i = 0; i < M2K_SUB; i++) rs2[i] -= rsend[i];
    }
#endif
    reverb_block(verb, damp, rs, L, R, shim);
    if (bus.sh_on && perf.on[PF_SHIM]) bus.sh_q = 0;
    else if (bus.sh_on && !bus.sh_snd && ++bus.sh_q > 4u * M2K_SR / M2K_SUB) bus.sh_on = 0, bus.sh_q = 0;   /* (4 s on) */
    /* the controls on their laws (tools/gen_tables.py, the bus's controls). The tape runs only for WOW: its depth glides
     * to WOW's (no jump in the line's read); from rest it fills the line, then fades the tape in, and out again once its
     * depth is back down */
    int tape_on = perf.on[PF_WOW] || bus.tp_mix;
    int32_t tq0 = bus.tq, tqd = 0;                  /* (gliding, the depth moves sample by sample over the block) */
    if (!tape_on) bus.tq = 0;
    else {
        int32_t tq_t = perf.on[PF_WOW] ? WOW_Q8 : 0, d = tq_t - bus.tq;
        bus.tq = d > -256 && d < 256 ? tq_t : bus.tq + (d >> 8);
        tqd = bus.tq - tq0;
    }
    if (tape_on) {
        if (!bus.tp_fill && !bus.tp_mix) bus.tlp_l = bus.tlp_r = 0;   /* (from off: the head loss from rest) */
        bus.tp_fill += M2K_SUB;
        int32_t want = perf.on[PF_WOW] || bus.tq > 64 ? 32767 : 0;
        if (bus.tp_fill > 1024 && want != bus.tp_mix)     /* (the line read 420 +- 285 samples back: filled) */
            bus.tp_mix = want > bus.tp_mix ? (bus.tp_mix + 1024 > 32767 ? 32767 : bus.tp_mix + 1024)
                                           : (bus.tp_mix > 1024 ? bus.tp_mix - 1024 : 0);
        if (!bus.tp_mix && !perf.on[PF_WOW]) bus.tp_fill = 0;
    } else bus.tp_fill = 0;
    int32_t tq = bus.tq, tpm = bus.tp_mix;
    /* the crush: its control's at once; CRUSH glides in and out over 10 ms, the coder (idle under ADPC 0) first taking
     * up the sound it meets for 2 ms, unheard, so it comes in tracking it */
    int adpc = perf.on[PF_CRSH] ? 127 : g[G_ADPC];
    int32_t ad_t = (adpc * 2 > 127 ? 127 : adpc * 2) << 8;
    if (perf.on[PF_CRSH] && !bus.ad_perf) {
        bus.ad_perf = 1;
        if (!bus.ad_mixq) {
            bus.ad_pred[0] = sat16(L[0]); bus.ad_pred[1] = sat16(R[0]); bus.ad_idx[0] = bus.ad_idx[1] = 40;
            bus.ad_warm = 6;
        }
    }
    if (!bus.ad_perf) bus.ad_mixq = ad_t;
    else if (bus.ad_warm) bus.ad_warm--;
    else {
        int32_t d = ad_t - bus.ad_mixq;
        bus.ad_mixq += d > 1200 ? 1200 : d < -1200 ? -1200 : d;
        if (!perf.on[PF_CRSH] && bus.ad_mixq == ad_t) bus.ad_perf = 0;
    }
    int32_t ad_mix = bus.ad_mixq >> 8, ad_div = T_ADPC_DIV[adpc], ad_run = ad_mix || bus.ad_warm;
    /* the drive: its control's; DRIVE glides up and down over 20 ms, its output held to the level the control's would
     * give: while it rises, by the gain's own ratio (a small sound's level, a loud one's a little under), then by the
     * two outputs measured (one-poles on both, ~23 ms), rising to it, and so back down; never louder, never at full
     * scale */
    int32_t drv0 = T_DRIV[g[G_DRIV]], drv_t = perf.on[PF_DRIV] ? T_DRIV[127] : drv0;
    if (!bus.dv) bus.dv = drv0, bus.dv_g = bus.dv_gp = 32767;   /* (from init: the control's, nothing held) */
    int32_t dvp = bus.dv;                                  /* (the gain and the hold ramp across the block: stepped */
    { int32_t d = drv_t - bus.dv; bus.dv += d > 24 ? 24 : d < -24 ? -24 : d; }   /*  a block at a time: a +24 dB click) */
    int32_t drv = bus.dv, pdrv = drv != drv0 || dvp != drv0 || bus.dv_g < 32767 || bus.dv_gp < 32767;
    if (!pdrv) bus.dv_e0 = bus.dv_e1 = 0;                 /* (both from 0: their ratio right from the start) */
    int32_t dvg = bus.dv_g, dgp = bus.dv_gp;
    bus.dv_gp = dvg;
    int fl_run = bus_filters();
    /* GATE: its depth in and out over 6 ms; its place in the sixteenth the sequencer's (a free one without it) */
    int32_t gtd0 = bus.gtd;                                /* (ramped across the block) */
    if (perf.on[PF_GATE]) bus.gtd = bus.gtd + 2048 > 32767 ? 32767 : bus.gtd + 2048;
    else bus.gtd = bus.gtd > 2048 ? bus.gtd - 2048 : 0;
    int gate = bus.gtd > 0 || gtd0 > 0;
    uint32_t gsix = (bsps >> 8) > 512 ? (bsps >> 8) : 512, gph = 0;
    if (gate) {
        gph = brun ? (bus.gw - bus.g_grid[0]) * 2u + bus.g_phase : bus.gt_ph;
        gph %= gsix;
        bus.gt_ph = gph + M2K_SUB;
    }
    int32_t mvol = T_MVOL[b->mvol];
    uint32_t wow_inc = 54000, flut_inc = 620000;    /* 0.55 Hz, 6.3 Hz */
    uint8_t g_phase = bus.g_phase;                  /* (a block's in locals: no byte stored a sample) */
    uint32_t e0 = 0, e1 = 0;
    int32_t olv = 0;
    for (int i = 0; i < M2K_SUB; i++) {
        int32_t l = L[i], r = R[i];
        /* glitch: the ring written at half rate (never under the event's read); the event mixed in over the dry */
        if (!(g_phase ^= 1)) {
            if (!bus.g_on || !gl_kept(bus.gw)) {
                gl_buf[bus.gw & (GL_LEN - 1)][0] = (int16_t)sat16((bus.gacc_l + l) >> 1);
                gl_buf[bus.gw & (GL_LEN - 1)][1] = (int16_t)sat16((bus.gacc_r + r) >> 1);
            }
            bus.gw++;
            if (bus.g_on) gl_tick();
        } else {
            bus.gacc_l = l;
            bus.gacc_r = r;
        }
        if (bus.g_on) {
            if (bus.g_held) { if (bus.g_env < 1024) bus.g_env = bus.g_env + bus.g_fi > 1024 ? 1024 : bus.g_env + bus.g_fi; }
            else if ((bus.g_env -= bus.g_fo) <= 0) {      /* faded out: over, or the next key's begins */
                bus.g_env = 0;
                bus.g_on = 0;
                if (bus.g_next) { int k = bus.g_next - 1; bus.g_next = 0; gl_perform(k); }
            }
            /* the wet between its half-rate samples; l + env (wet W - l) (|l| < 2^18, the products < 2^31) */
            int32_t wl = g_phase ? bus.gout_l : (bus.gprev_l + bus.gout_l) >> 1, wr = g_phase ? bus.gout_r : (bus.gprev_r + bus.gout_r) >> 1;
            int32_t env = bus.g_env;                                         /* (whole: exactly the wet) */
            l += ((((wl * bus.g_wet) >> 3) - l * 4096) >> 12) * env >> 10;
            r += ((((wr * bus.g_wet) >> 3) - r * 4096) >> 12) * env >> 10;
        }
        /* tape (WOW): wow and flutter on a short line, head loss, a little compression */
        if (tape_on) {
            tp_buf[bus.tw & 2047][0] = (int16_t)sat16(l);
            tp_buf[bus.tw & 2047][1] = (int16_t)sat16(r);
            bus.wow += wow_inc;
            bus.flut += flut_inc;
            /* the pitch a swing of the line makes grows with its rate: the flutter (6.3 Hz, 11x the wow's) takes 1/48
             * of the wow's swing, so it wobbles about a quarter as far in pitch (WOW: wow ~+-40 c, flutter ~+-10 c) */
            int32_t m = (sinp(bus.wow) * 48 + sinp(bus.flut)) >> 6;           /* +-24600 */
            if (tqd) tq = tq0 + ((tqd * (i + 1)) >> 4);
            int32_t d = (420 << 8) + (int32_t)mul_sh(m, tq * 3, 15);         /* Q8 samples */
            uint32_t pos = (bus.tw << 8) - (uint32_t)d;                       /* unsigned: it wraps after 3 minutes */
            uint32_t j = pos >> 8;
            int32_t f = (int32_t)(pos & 255);
            int32_t tl = (tp_buf[j & 2047][0] * (256 - f) + tp_buf[(j + 1) & 2047][0] * f) >> 8;
            int32_t tr = (tp_buf[j & 2047][1] * (256 - f) + tp_buf[(j + 1) & 2047][1] * f) >> 8;
            bus.tw++;
            int32_t li = 127 * 1024 - tq, lj = li >> 10;                     /* the head loss: 127 - old / 4, Q10 */
            int32_t a = T_OP[lj] + (((T_OP[lj < 127 ? lj + 1 : 127] - T_OP[lj]) * (li & 1023)) >> 10);
            bus.tlp_l += ((tl - bus.tlp_l) * a) >> 15;
            bus.tlp_r += ((tr - bus.tlp_r) * a) >> 15;
            if (tpm >= 32767) { l = bus.tlp_l; r = bus.tlp_r; }
            else { l += (int32_t)mul_sh(bus.tlp_l - l, tpm, 15); r += (int32_t)mul_sh(bus.tlp_r - r, tpm, 15); }
        }
        /* LPF and HPF: the two-poles at 16 x the level (their remainders the finer), mixed in by their shares */
        for (int f = 0; fl_run >> f; f++) {
            if (!((fl_run >> f) & 1)) continue;
            int32_t yl, yr;
            if (!f && bus.fnew) { bus.fnew = 0; bus.fl[0][0].s2 = l * 16; bus.fl[0][1].s2 = r * 16; }
            zsvf_tick(&bus.fl[f][0], l * 16, f ? 0 : &yl, 0, f ? &yl : 0);
            zsvf_tick(&bus.fl[f][1], r * 16, f ? 0 : &yr, 0, f ? &yr : 0);
            yl >>= 4;
            yr >>= 4;
            if (bus.fgain[f] < 32767) { yl = (int32_t)mul_sh(yl, bus.fgain[f], 15); yr = (int32_t)mul_sh(yr, bus.fgain[f], 15); }
            if (bus.fmix[f] >= 32767) { l = yl; r = yr; }
            else { l += (int32_t)mul_sh(yl - l, bus.fmix[f], 15); r += (int32_t)mul_sh(yr - r, bus.fmix[f], 15); }
        }
        /* the 4-bit crunch, its rate falling to a third at the top */
        if (ad_run) {
            bus.ad_acc += 256;
            if (bus.ad_acc >= ad_div) {
                bus.ad_acc -= (uint16_t)ad_div;
                bus.ad_hold[0] = adpcm_step(0, sat16(l));
                bus.ad_hold[1] = adpcm_step(1, sat16(r));
            }
            l += ((bus.ad_hold[0] - l) * ad_mix) >> 7;
            r += ((bus.ad_hold[1] - r) * ad_mix) >> 7;
        }
        if (pdrv) {                                       /* DRIVE: the control's output beside it, for the level */
            uint64_t lr0 = mul2_q15(mvol, (l * drv0) >> 8, (r * drv0) >> 8);
            int32_t l0 = lim_soft((int32_t)lr0) >> 4, r0 = lim_soft((int32_t)(lr0 >> 32)) >> 4;
            e0 += (uint32_t)(l0 * l0 + r0 * r0) >> 5;
        }
        int32_t dri = pdrv ? dvp + (((drv - dvp) * (i + 1)) >> 4) : drv;
        uint64_t lr = mul2_q15(mvol, (l * dri) >> 8, (r * dri) >> 8);
        l = lim_soft((int32_t)lr);
        r = lim_soft((int32_t)(lr >> 32));
        if (pdrv) {
            int32_t dgi = dgp + (((dvg - dgp) * (i + 1)) >> 4);
            e1 += (uint32_t)((l >> 4) * (l >> 4) + (r >> 4) * (r >> 4)) >> 5;
            l = (l * dgi) >> 15;
            r = (r * dgi) >> 15;
        }
        /* KILL: down and back over 6 ms on an S (a straight line's corners were a click's worth of top: +8 dB) */
        if (perf.kill != (perf.on[PF_KILL] ? 0 : 32767)) {
            perf.kill += perf.on[PF_KILL] ? -124 : 124;
            perf.kill = CLAMP(perf.kill, 0, 32767);
        }
        if (perf.kill < 32767) {
            int32_t s = (perf.kill * perf.kill) >> 15, kg = (s * ((98304 - 2 * perf.kill) >> 1)) >> 14;   /* u^2 (3 - 2u) */
            l = (l * kg) >> 15;
            r = (r * kg) >> 15;
        }
        if (gate) {                                       /* GATE: open the first half of each sixteenth */
            uint32_t q = gph + (uint32_t)i;
            while (q >= gsix) q -= gsix;
            int32_t o;
            if (q < 64) { int32_t u = (int32_t)q << 9; o = (((u * u) >> 15) * ((98304 - 2 * u) >> 1)) >> 14; }   /* 1.5 ms on an S */
            else if (q < gsix / 2) o = 32767;
            else if (q < gsix / 2 + 256) o = (int32_t)(gsix / 2 + 256 - q) << 7;
            else o = 0;
            int32_t gd = gtd0 + (((bus.gtd - gtd0) * (i + 1)) >> 4), gg = 32767 - (((32767 - o) * gd) >> 15);
            l = (l * gg) >> 15;
            r = (r * gg) >> 15;
        }
        out[2 * i] = (int16_t)l;
        out[2 * i + 1] = (int16_t)r;
        if ((i & 7) == 0) {
            int32_t m = (l + r) >> 1;
            olv += m < 0 ? -m : m;
        }
    }
    /* the output's level (two samples a block, Q4): over ~0.4 s, and FREEZE's over ~90 ms, its gain toward the
     * level before it every 16 blocks (a quarter of the way: no pumping on a sustain) */
    bus.olev += (olv * 8 - bus.olev) >> 10;
    if (bus.g_on && bus.g_mode == GM_FRZ && bus.g_env >= 1024) {
        bus.g_lev += (olv * 8 - bus.g_lev) >> 8;
        if (!(++bus.g_nb & 15)) {
            uint32_t q = ((uint32_t)bus.g_tgt << 4) / ((uint32_t)bus.g_lev >> 8 | 1u);   /* Q12 (the levels < 2^19) */
            int32_t want = (int32_t)CLAMP((bus.g_agc * (int32_t)(q > 16384u ? 16384u : q)) >> 12, 8192, 40000);
            bus.g_agt += (want - bus.g_agt) >> 2;
        }
    }
    if (pdrv) {                                           /* the level DRIVE may have: the control's, under 31/32 of full */
        bus.dv_e0 += ((int32_t)e0 - bus.dv_e0) >> 6;
        bus.dv_e1 += ((int32_t)e1 - bus.dv_e1) >> 6;
        int32_t want = 32767;
        if (drv != drv0) {                                /* (at least the small signal's: drv0 / drv) */
            uint32_t w = bus.dv_e1 > 0 ? isqrt32(((uint32_t)bus.dv_e0 << 9) / ((uint32_t)bus.dv_e1 >> 11 | 1u)) << 5 : 32767;
            int32_t lo = (drv0 << 15) / drv;
            want = drv < drv_t ? lo : CLAMP((int32_t)w, lo, 31743);   /* (rising, at the gain's ratio) */
        }
        if (want < bus.dv_g) bus.dv_g = want;             /* down at once, up gently */
        else bus.dv_g += (want - bus.dv_g) >> 4;
        if (want == 32767 && bus.dv_g > 32767 - 16) bus.dv_g = 32767;
    }
    bus.g_phase = g_phase;
    mon.glitch = bus.g_on;
#ifdef M2K_SPU
    /* GRIT (the Move's): the bus's output through the PS1-era chip's sample codec, after the limiter, KILL and GATE and
     * before bank C's colours (AFFINE's order: the codec, then the console); 10 ms in and out, idle while off */
    if (perf.on[PF_GRIT] || spu_g.run) spu_grit_block(out, M2K_SUB, perf.on[PF_GRIT], spu_grit_chr);
#endif
    if (bus.c_run || perf.on[PF_LOFI] || perf.on[PF_CONS] || perf.on[PF_DUCK]) bus_colour(out);   /* (bank C's colours) */
}

/* ------------------------------------------------------------------------------------------- the render */

static void seq_block(void);
static int seq_running(void);
static void mx_gates_out(void);

/* the bus a block behind (1.6.1, the owner's: their FM-1's first core had no room): block n's tracks sum into its
 * record (brec), and block n - 1's bus plays from the record before, on the second core beside block n's tracks (on
 * one core, before them), so the sound comes out a block (16 samples, 0.36 ms) later and otherwise as it was. What the
 * bus reads of the sequencer's block goes into the record as the block runs (its tempo, its step for the grid, the
 * pattern's controls, the master, running or not), and DUB's line (a borrowed track's delay, the bus feeding it and fed
 * by it) runs on the bus's side, its track's send and settings recorded. A PERFORM key pressed between two renders
 * reaches the bus a block early (the bus of the block before plays it): the owner's accepted edge */
/* what the bus reads of the block, as it stands now */
static void brec_take(brec_t *b)
{
    b->sps = sps_q8;
    m_cpy(b->glob, PAT(cur_pat)->glob, G_COUNT);
    b->run = (uint8_t)seq_running();
    b->mvol = master_vol;
}

/* the sequencer's step, for the bus of its block (the grid PERFORM's repeats lock to) */
static void bus_step_q(int s)
{
    brec_t *b = &brec[bcur];
    if (b->nstep < 2) b->step[b->nstep++] = (uint8_t)s;
}

/* the platform's clock (the FM-1's ticks), unset elsewhere: each track's time a block, the bus's and the first core's
 * own (the sequencer, the LFOs), measured where it runs and smoothed, Q4 ticks (0: none yet); the split weighs them */
uint32_t (*m2k_clock)(void);
uint32_t m2k_clock_per_ms;
static int32_t par_meas[M2K_TRACKS + 2];   /* the tracks', the bus's (M2K_TRACKS), the first core's own (+1) */
static uint16_t par_mcc[M2K_TRACKS];       /* the estimate a track's measure began at (another: measured again) */
static int8_t clk_k;                       /* what is being timed (the self-test's clock reads it) */
static inline uint32_t clk_now(int k) { clk_k = (int8_t)k; return m2k_clock(); }
static inline void par_note(int k, uint32_t dt)
{
    int32_t v = (int32_t)(dt > 0x3FFFFFu ? 0x3FFFFFu : dt) << 4;
    par_meas[k] = par_meas[k] ? par_meas[k] + ((v - par_meas[k]) >> 3) : v | 1;
}

/* a track's block: its voice and chain, then its delay (DUB's track's with the bus) */
static void run_track(int t, int32_t *L, int32_t *R, int32_t *rs, int32_t *ds)
{
    uint32_t c0 = m2k_clock ? clk_now(t) : 0;
    m_set(ds, 0, M2K_SUB * sizeof *ds);
    track_block(t, L, R, ds, rs);
    if (t + 1 == dub_snap) {
        brec_t *b = &brec[bcur];
        m_cpy(b->dds, ds, sizeof b->dds);
        dl_par(t, &b->dp);
        b->dsent = trk[t].dsent;
        trk[t].dsent = 0;
        b->dt = (uint8_t)(t + 1);
    } else delay_block(t, ds, L, R);
    trk_t *k = &trk[t];                /* how loud it is heard (its peak by its LEVL), for the CPU guard; falling at least
                                        * a step a block, to 0 (the peak under T_CLIP, the level 2^15: a word) */
    int32_t h = (int32_t)(((uint32_t)k->peak * tq_u16(T_VOL, P8(k, P_LEVL))) >> 15), f = k->lvl - (k->lvl >> 8) - (k->lvl > 0);
    k->lvl = h > f ? h : f;
    if (m2k_clock) { par_note(t, m2k_clock() - c0); par_mcc[t] = trk[t].ccost; }
}

/* the bus of the record's block into out: its steps for the grid, DUB's line, then the bus (the first block after
 * init has none before it: silence) */
static void bus_run(brec_t *b, int16_t *out)
{
    if (!b->valid) { m_set(out, 0, 2 * M2K_SUB * sizeof *out); return; }
    uint32_t c0 = m2k_clock ? clk_now(M2K_TRACKS) : 0;
    bsps = b->sps;
    brun = b->run;
    for (int i = 0; i < b->nstep; i++) bus_step(b->step[i]);
    if (b->dt) delay_run(b->dt - 1, &b->dp, b->dsent, b->sps, 1, b->dds, b->L, b->R);
    bus_block(b, out);
    if (m2k_clock) par_note(M2K_TRACKS, m2k_clock() - c0);
}

/* the second core's share of a block: the bus of the block before, then the tracks in par_mask into their own sums
 * (par_L ...); it touches no MIDI (a gate's end only marked, its note-off sent by the first core after both) */
int (*m2k_par_begin)(void (*job)(void));
void (*m2k_par_end)(void);
static uint8_t par_mask;
static int32_t par_L[M2K_SUB], par_R[M2K_SUB], par_rs[M2K_SUB], par_ds[M2K_SUB];
static int16_t *par_out;

static void par_job(void)
{
    bus_run(&brec[bcur ^ 1], par_out);
    m_set(par_L, 0, sizeof par_L);
    m_set(par_R, 0, sizeof par_R);
    m_set(par_rs, 0, sizeof par_rs);
    for (int t = 0; t < M2K_TRACKS; t++) if (par_mask >> t & 1) run_track(t, par_L, par_R, par_rs, par_ds);
}

/* which tracks the second core takes beside the bus: any set of them, as the tracks' sums are plain adds (the same
 * whoever adds them); an FX machine stays with the track it hears (the one before it, FX-RING's EXT the one before
 * that), so the tracks go in groups of those. The work is shared out for the slower core to be as quick as it can: the
 * first core's tracks against the bus and the second's (the sequencer and the LFOs run before, the second core idle:
 * they weigh nothing here). Each track weighs what it measured where a clock is (the FM-1's: par_meas, the others'
 * estimates scaled to it until they have one, or after their machine or stages changed), else its last block's
 * estimate (T_MCOST: its machine, chain and stages, its delay while it rings; in Mac instructions a sample, measured
 * as T_MCOST is: the host and the browser, no clock, the same split every time). Worked out again every eighth block,
 * and at once when the groups change (a machine assigned) */
#define C_IDLE 12                      /* a track that does not sound */
#define C_DLY 92                       /* a delay that rings: one line, ping-pong */
#define C_DLY2 116
#define C_PAR 10                       /* the second core's sums */
#define C_BUS 360                      /* the bus (its reverb, the crunch, the drive, the glitch's ring) */
static int par_force = -1;             /* (the self-test: a set of its own, its groups kept) */
static uint8_t par_tie_last = 0xFF, par_age;
static uint8_t par_split(void)
{
    const uint8_t *mc = rmach;         /* (as they render: a POLY voice its lead's machine) */
    uint8_t tie = 0;                   /* track t's bit: it goes where track t - 1 goes */
    for (int t = 1; t < M2K_TRACKS; t++)
        if (mc[t] == M_FXC || mc[t] == M_FXR || mc[t] == M_FXD || (t + 1 < M2K_TRACKS && mc[t + 1] == M_FXR)) tie |= (uint8_t)(1u << t);
    if (par_force >= 0) {
        uint8_t m = (uint8_t)par_force;
        for (int t = 1; t < M2K_TRACKS; t++) if (tie >> t & 1) m = (uint8_t)((m & ~(1u << t)) | (m >> (t - 1) & 1u) << t);
        return m;
    }
    if (tie == par_tie_last && (++par_age & 7)) return par_mask;
    par_tie_last = tie;
    par_age = 0;
    int32_t est[M2K_TRACKS], es = 0, ms = 0;
    for (int t = 0; t < M2K_TRACKS; t++) {
        est[t] = (trk[t].sounding ? trk[t].ccost : C_IDLE) + (trk[t].dsleep ? 0 : trk[t].dmode ? C_DLY2 : C_DLY);
        if (par_meas[t] && par_mcc[t] != trk[t].ccost) par_meas[t] = 0;   /* (its machine or stages changed) */
        if (m2k_clock && par_meas[t]) { es += est[t]; ms += par_meas[t] >> 4; }
    }
    const int32_t sc = es ? (int32_t)(((uint32_t)ms << 8) / (uint32_t)es) : 0;   /* ticks an estimate's unit, Q8 */
    int32_t bc = sc ? (par_meas[M2K_TRACKS] ? par_meas[M2K_TRACKS] >> 4 : (C_BUS * sc) >> 8) : C_BUS;
    const int32_t cp = sc ? (C_PAR * sc) >> 8 : C_PAR;
    bc += cp;
    int32_t u[M2K_TRACKS], all = 0;    /* the groups' costs */
    uint8_t ub[M2K_TRACKS];            /* and their tracks */
    int n = 0;
    for (int t = 0; t < M2K_TRACKS; t++) {
        int32_t c = !sc ? est[t] : par_meas[t] ? par_meas[t] >> 4 : (est[t] * sc) >> 8;
        if (!(tie >> t & 1) || !n) { u[n] = 0; ub[n] = 0; n++; }
        u[n - 1] += c;
        ub[n - 1] |= (uint8_t)(1u << t);
        all += c;
    }
    /* none of the tracks there (the bus alone), then every set of groups but all, in Gray code order (one group in or
     * out a step); all of them there is never quicker than none */
    int32_t b = 0, best = all > bc ? all : bc;
    uint32_t g = 0, pick = 0;
    for (uint32_t i = 1; i < 1u << n; i++) {
        int k = 0;
        while (!(i >> k & 1)) k++;
        g ^= 1u << k;
        b += g >> k & 1 ? u[k] : -u[k];
        if (g == (1u << n) - 1) continue;
        int32_t a = all - b, w = a > b + bc ? a : b + bc;
        if (w < best) { best = w; pick = g; }
    }
    uint8_t m = 0;
    for (int k = 0; k < n; k++) if (pick >> k & 1) m |= ub[k];
    return m;
}

/* a track's cost a block, for the CPU guard and CPU FULL: what it measured where a clock is (Q4 ticks: the FM-1's),
 * else its estimate (par_split's) */
static int32_t trk_cost(int t)
{
    if (m2k_clock && par_meas[t]) return par_meas[t];
    return (trk[t].sounding ? trk[t].ccost : C_IDLE) + (trk[t].dsleep ? 0 : trk[t].dmode ? C_DLY2 : C_DLY);
}

/* the dearest track (CPU FULL names it: the one to lighten) */
static int trk_dearest(void)
{
    int best = 0;
    for (int t = 1; t < M2K_TRACKS; t++) if (trk_cost(t) > trk_cost(best)) best = t;
    return best;
}

void m2k_render(int16_t *lr, int frames)
{
    static int32_t ds[M2K_SUB];
    for (int f = 0; f + M2K_SUB <= frames; f += M2K_SUB) {
        PROF_START();
        brec_t *rc = &brec[bcur];
        uint32_t c0 = m2k_clock ? clk_now(M2K_TRACKS + 1) : 0;
        rc->nstep = 0;
        rc->dt = 0;
        seq_block();
        for (int t = 0; t < M2K_TRACKS; t++) lfo_block(t);
        mod_apply();
        brec_take(rc);
        m_set(rc->L, 0, sizeof rc->L);
        m_set(rc->R, 0, sizeof rc->R);
        m_set(rc->rs, 0, sizeof rc->rs);
        hold_bpm = ext_bpm ? ext_bpm : 30u + PAT(cur_pat)->glob[G_TMPO];
        dub_snap = bus.dub_t;
        if (m2k_clock) par_note(M2K_TRACKS + 1, m2k_clock() - c0);
        PROF(0);
        /* the second core: the bus of the block before and its share of this one's tracks; else this core, the bus
         * first */
        int two = 0;
        if (m2k_par_begin) {
            par_mask = par_split();
            par_out = lr + 2 * f;
            two = m2k_par_begin(par_job);
        }
        if (!two) bus_run(&brec[bcur ^ 1], lr + 2 * f);
        PROF(4);
        for (int t = 0; t < M2K_TRACKS; t++) {
            if (two && (par_mask >> t & 1)) continue;
            run_track(t, rc->L, rc->R, rc->rs, ds);
            PROF(3);
        }
        if (two) {
            m2k_par_end();
            for (int i = 0; i < M2K_SUB; i++) { rc->L[i] += par_L[i]; rc->R[i] += par_R[i]; rc->rs[i] += par_rs[i]; }
        }
        mx_gates_out();                /* the gates ended on either core: their notes out, in track order */
        rc->valid = 1;
        bcur ^= 1;
    }
}
