/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: MONO2K 1.13 (https://github.com/InigoHernandez/mono2k) on the Teensy 4.1: its core (firmware/src) in ports/common's shell */
#include "../../../common/shell_pre.h"
#define M2K_VER "1.13"
#define M2K_FW 1
#define POOL
#include "m2k_core.c"
/* the store's stream (m2k_fm1.c's flash): not kept here */
int m2k_fw_store_put(uint32_t off, const uint8_t *p, uint32_t n) { (void)off; (void)p; (void)n; return -1; }
int m2k_fw_store_get(uint32_t off, uint8_t *p, uint32_t n) { (void)off; (void)p; (void)n; return -1; }

static int sh_btn(uint32_t id) { return id == 0 ? B_OCTD : id == 1 ? B_OCTU : (int)id - 2; }
static const uint8_t SH_ENCS[7] = {E_SELECT, E_ALGO, E_K1, E_K2, E_K3, E_K4, E_PRESET};
static int sh_lv(int v) { return v >= 64 ? 2 : v >= 8 ? 1 : 0; }
#define SH_BLK 64u
#define SH_LEVEL 1.0f
#define SH_RENDER(b, n) m2k_render((b), (int)(n))
#define SH_KEY(k, d) m2k_key((int)(k), (d))
#define SH_BTN(i, d) m2k_button(sh_btn(i), (d))
#define SH_ENC(e, n) m2k_encoder(SH_ENCS[e], (int)(n))
#define SH_KEY_LED(k) sh_lv(m2k_leds()[k])
#define SH_BTN_LED(i) sh_lv(m2k_leds()[27 + sh_btn(i)])

static void SH_BOOT(void) { m2k_init(1u); }
static void SH_FRAME(uint32_t ms)
{
    const uint8_t *f = m2k_frame(ms);
    uint32_t i, k;
    for (i = 0; i < 7200u; i++)
        for (k = 0; k < 8u; k++) sh_put(i * 8u + k, f[i] >> (7u - k) & 1u ? 0x0000u : 0xFFFFu);
}
#include "../../../common/shell_post.h"
