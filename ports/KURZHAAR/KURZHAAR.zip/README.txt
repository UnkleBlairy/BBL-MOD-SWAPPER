Kurzhaar, der Basshund 1.1 for the BBL Mod Swapper

Original by kurzhaar168: https://github.com/kurzhaar168/kurzhaar
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: KURZHAAR-source.zip on the ports page.
