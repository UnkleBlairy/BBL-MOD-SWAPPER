/* SPDX-License-Identifier: GPL-3.0-only */
/* A fake FM-1 on a computer: KAWA (firmware/src/kawa.c) runs unchanged on it. platform.c includes this
 * file instead of the hardware when DINGHY_HOST is set. A script presses keys and buttons and turns
 * knobs over time; out come the screens (PPM, when the script says "shot") and the sound (WAV, as the
 * FM-1 sends it over USB). After Dinghy's tests/host.c (zvenson).
 *
 *   tests/run_host.sh [script]           (-> build/host/kawa.wav and the screens as PNG)
 *
 * Script lines: "T keys MASK" (bit k = key k, 0 = F3), "T press ID" / "T release ID" / "T btn ID" (a tap),
 * "T enc ID STEPS", "T lang L" (0 FR, 1 EN, 2 ES), "T shot NAME", "T sysex F0..F7" (a frame in hex; the
 * replies are printed), "T end". T in milliseconds. */
#include <stdint.h>

#ifndef APP_NAME
#define APP_NAME "KAWA"
#endif
#ifndef APP_VER
#define APP_VER "0.0"
#endif
#define FS 44100u
#define HALF_FRAMES 256u
#define FM1_TICKS_PER_US 24u
#define RING_PUBLISH() ((void)0)
#define STORE_LO 0x00097000u
#define STORE_HI 0x000E0000u

static volatile uint32_t fm1_ms;
static struct { uint32_t notes, buttons; } fm1_in;
/* teensy-fm1: the panel and the screen are the Teensy's */
static uint32_t din_press, din_rel, din_nedge, din_px;
static int32_t din_enc[8];
static uint8_t din_led[64], din_glow[64];
static uint32_t fm1_input_edges(uint32_t *released) { uint32_t b = din_press; din_press = 0; if (released) *released = din_rel; din_rel = 0; return b; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = din_nedge; din_nedge = 0; return e; }
static int32_t fm1_enc_take(uint32_t e) { int32_t v = din_enc[e & 7u]; din_enc[e & 7u] = 0; return v; }
static void fm1_led_key(uint32_t id, int on) { din_led[id & 63u] = (uint8_t)!!on; }
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    for (j = y; j < y + h && j < 240u; j++)
        for (i = x; i < x + w && i < 240u; i++)
            sh_put(j * 240u + i, sh_be16(c));
    din_px += w * h;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            sh_put((y + j) * 240u + x + i, px[j * w + i]);      /* (gfx.c's pixels are high byte first already) */
    din_px += w * h;
}

static uint32_t host_pressed, host_released, host_note_edges;
static int32_t host_enc[7];
static uint32_t fm1_ticks(void) { return fm1_ms * 24000u; }



static uint8_t host_led_state[41];
static void host_leds(const uint8_t *w) { memcpy(host_led_state, w, 41); }
static unsigned str_len(const char *s) { return (unsigned)strlen(s); }

/* the screen: 240 x 240 RGB565, as the ST7789 gets it (byte-swapped) */
#define fb shl_fb


#define CV_MAX (240u * 64u)
#include "gfx.c"

static uint8_t host_settings[260];
static int settings_load(void *p, uint32_t n)   /* (as platform.c: the length saved must be n) */
{
    if (!host_settings[0] || n > 256u || host_settings[1] != n) return -1;
    memcpy(p, host_settings + 4, n);
    return 0;
}
static int settings_save(const void *p, uint32_t n) { host_settings[0] = 1; host_settings[1] = (uint8_t)n; memcpy(host_settings + 4, p, n); return 0; }
static int midi_get(uint8_t *st, uint8_t *d1, uint8_t *d2) { (void)st; (void)d1; (void)d2; return 0; }
static uint32_t host_midi_out[3];               /* MIDI out: counts of clock ticks, starts, stops (tests) */
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2)
{
    (void)d1; (void)d2;
    if (st == 0xF8) host_midi_out[0]++;
    else if (st == 0xFA) { host_midi_out[1]++; printf("%6u ms  midi start\n", fm1_ms); }
    else if (st == 0xFC) { host_midi_out[2]++; printf("%6u ms  midi stop, %u clock ticks\n", fm1_ms, host_midi_out[0]); }
}

static void app_audio(int32_t *out, uint32_t n);
static void app_main(void);
