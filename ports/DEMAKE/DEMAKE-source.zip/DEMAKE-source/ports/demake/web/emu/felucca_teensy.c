/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: Demake 0.4.25 (https://github.com/InigoHernandez/demake-synth) on the Teensy 4.1: its core (firmware/src) in ports/common's shell */
#include "../../../common/shell_pre.h"
#include "dmk_core.c"
/* the store, in RAM */
static uint8_t store[65536];
static int ws_read(uint32_t at, void *p, uint32_t n)
{
    if (at > sizeof store || n > sizeof store - at) return -1;
    memcpy(p, store + at, n);
    return 0;
}
static int ws_write(uint32_t at, const void *p, uint32_t n)
{
    if ((at & 4095u) || n > 4096u || at + 4096u > sizeof store) return -1;
    memset(store + at, 0xFF, 4096);
    memcpy(store + at, p, n);
    return 0;
}

static int sh_btn(uint32_t id) { return id == 0 ? B_OCTD : id == 1 ? B_OCTU : (int)id - 2; }
static const uint8_t SH_ENCS[7] = {E_SELECT, E_ALGO, E_K1, E_K2, E_K3, E_K4, E_PRESET};
static int sh_lv(int v) { return v >= 64 ? 2 : v >= 8 ? 1 : 0; }
#define SH_BLK 64u
#define SH_LEVEL 1.0f
#define SH_RENDER(b, n) dmk_render((b), (int)(n))
#define SH_KEY(k, d) dmk_key((int)(k), (d))
#define SH_BTN(i, d) dmk_button(sh_btn(i), (d))
#define SH_ENC(e, n) dmk_encoder(SH_ENCS[e], (int)(n))
#define SH_KEY_LED(k) sh_lv(dmk_leds()[k])
#define SH_BTN_LED(i) sh_lv(dmk_leds()[27 + sh_btn(i)])

static void SH_BOOT(void) { memset(store, 0xFF, sizeof store); dmk_store_read = ws_read; dmk_store_write = ws_write; dmk_init(1u); }
static void SH_FRAME(uint32_t ms)
{
    const uint8_t *f = dmk_frame(ms);
    const uint16_t *pal = dmk_palette565();
    uint16_t c[16];
    uint32_t i;
    for (i = 0; i < 16u; i++) c[i] = sh_be16(pal[i]);
    for (i = 0; i < 28800u; i++) { sh_put(i * 2u, c[f[i] >> 4]); sh_put(i * 2u + 1u, c[f[i] & 15u]); }
}
#include "../../../common/shell_post.h"
