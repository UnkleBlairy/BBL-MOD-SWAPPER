/* SPDX-License-Identifier: GPL-3.0-only */
/* Chipbox's platform: everything an FM-1 firmware needs before it can be fun, taken unchanged from
 * SLOOP / Felucca / sloopDX and wired up here. You should not need to touch this file.
 *
 *   boot + boot guard   a firmware that crashes at boot falls back to the USB rescue, then to the ROM
 *   USB rescue          OCT- held at power-on: no audio, only the updater (the web installer still works)
 *   updater             the M-UPGRADE SysEx path: the web installer / the hub can always reach the FM-1
 *   USB-MIDI            in and out (midi_get, midi_send)
 *   USB audio           the output as a class-compliant 16-bit stereo input, 44.1 or 48 kHz
 *   keys, knobs, LEDs   fm1_in.notes / buttons, fm1_input_edges, fm1_enc_take, fm1_led_key (hal/fm1_input.h)
 *   screen              240 x 240, lcd_fill, draw_text_box with FONT_S (16 px) / FONT_L (32 px) (gfx.c)
 *   settings            one 4 KiB flash sector with a CRC (settings_load / settings_save)
 *   crash screen        the PC of a fault, then a reboot
 *
 * The app (chipbox.c) includes this file first and supplies:
 *   static void app_audio(int32_t *out, uint32_t n)   audio ISR: n stereo frames, L R L R, Q15 (+-32767), out is zero
 *   static void app_main(void)                        never returns; calls platform_poll() often (every few ms)
 */
/* the panel by name: buttons (fm1_in.buttons, fm1_input_edges, fm1_led_key: bit / id), the encoders
 * (fm1_enc_take); the 27 note keys are fm1_in.notes bit 0 (F3) .. 26 (G5), LED id 14 + key */
enum { BTN_OCT_DOWN = 0, BTN_OCT_UP = 1, BTN_FX = 2, BTN_SEL = 3, BTN_ENV = 4, BTN_LFO = 5, BTN_EDIT = 6,
       BTN_GLO = 7, BTN_HOME = 8, BTN_SAVE = 9, BTN_ARP = 10, BTN_SEQ = 11, BTN_PLAY = 12, BTN_REC = 13 };
enum { ENC_SELECT = 0, ENC_ALGORITHM = 1, ENC_KNOB1 = 2, ENC_KNOB2 = 3, ENC_KNOB3 = 4, ENC_KNOB4 = 5, ENC_PRESETS = 6 };
#define KEY_LED(k) (14u + (k))

/* the projects' flash: 8 slots, two banks each (a save writes the other bank, so a cut keeps the old one), inside Felucca's data area */
#define PROJ_AT 0x00097000u
#define PROJ_BANK 0x3000u                       /* 12 KB: 64 steps in every page of every track fits */
#define PROJ_SLOTS 12u
#define PROJ_DEMOS 2u                           /* the first two slots are the demos: Korobeiniki and the console symphony */
#define PROJ_LEN (PROJ_SLOTS * 2u * PROJ_BANK)

#ifdef CHIPBOX_HOST
#include "../../tests/host.c"                  /* on a computer: a fake FM-1 (tests/host.c) */
#else
#include <stdint.h>
#include "fm1_time.h"
#include "fm1_sys.h"
#include "fm1_irq.h"
#include "fm1_guard.h"
#include "fm1_input.h"
#include "fm1_timer.h"
#include "fm1_lcd_hw.h"
#include "fm1_audio.h"
#include "fm1_adc.h"
#include "bootguard.h"

#ifndef APP_NAME
#define APP_NAME "DRUMLAB"
#endif
#ifndef FELUCCA_ID
#define FELUCCA_ID "FM-1_337"                   /* package identity (tools/build.py) */
#endif
#ifndef APP_VER
#define APP_VER "0.0"
#endif
#ifndef APP_REPO
#define APP_REPO "github.com/pbarilla/drumlab"
#endif

bootguard_t bootguard __attribute__((unused));
static volatile uint32_t fm1_ms;                /* milliseconds since power-on (TIMER5) */

#define RING_PUBLISH() __asm__ volatile("" ::: "memory")
#include "libc.c"
#include "lcd.c"
#define CV_MAX (240u * 124u)                    /* the biggest thing drawn at once: a screen section (Drumlab: up to 124 rows) */
#include "gfx.c"

#define FS 44100u                               /* the sample rate */
#define HALF_FRAMES 256u                        /* I2S half buffer: 5.8 ms (as sloopDX: the USB audio band is set for it) */
#define HALF_WORDS (HALF_FRAMES * 2u)
#define FELUCCA_OTA 1
#define FELUCCA_CDC 0
#define FELUCCA_UAC 1
#define FELUCCA_UART 0
#include "usb.c"

/* ---- flash: read anywhere; erase / program only the update's staging area and the settings sector */
#define SETTINGS_AT 0x000FC000u                 /* one 4 KiB sector of Felucca's globals area */
#define FL_RANGE_OK(off, n) (FL_IN(off, n, FL_OTA_LO, FL_OTA_HI) || FL_IN(off, n, SETTINGS_AT, SETTINGS_AT + 0x1000u) || FL_IN(off, n, PROJ_AT, PROJ_AT + PROJ_LEN))
#include "fm1_flash.h"
static uint8_t flash_ok;
static uint32_t flash_id;                       /* JEDEC id, for the crash screen */
static int st_read(uint32_t off, void *dst, uint32_t n)
{
    uint8_t *d = dst;
    while (n) {
        uint32_t k = n > 256u ? 256u : n, f = irq_save();
        int rc = FL_FAR(fl_read_ram)(off, d, k);
        irq_restore(f);
        if (rc)
            return rc;
        off += k;
        d += k;
        n -= k;
    }
    return 0;
}

static uint8_t recovery_active;
#define OTA_IDENTITY (recovery_active ? "FM-1_000" : FELUCCA_ID)
#define APP_OTA_HIT 1                               /* (the app only: ota.c notes when the installer talks; the update loader does not define this) */
static volatile uint32_t ota_hit_ms;            /* when the installer last sent a request: the main loop switches the Bluetooth radio off while it does */
#include "ota.c"
static void recovery_poll(void);
static uint32_t ota_now_ms(void) { return fm1_ms; }
static void ota_idle(void)
{
    fm1_wdt_feed();
    if (recovery_active) recovery_poll();
}
static int ota_in_area(uint32_t off, uint32_t n) { return FL_IN(off, n, OTA_AREA, OTA_AREA + OTA_AREA_LEN); }
static int ota_erase(uint32_t off)
{
    uint32_t took;
    if (!ota_in_area(off, 0x1000u) || (off & 0xFFFu))
        return -8;
    return fl_erase4k(off, &took);
}
static int ota_prog(uint32_t off, const void *p, uint32_t n)
{
    if (!ota_in_area(off, n))
        return -8;
    return fl_write(off, p, n);
}
static int ota_fread(uint32_t off, void *p, uint32_t n) { return st_read(off, p, n); }
static void ota_show(uint32_t step, int32_t code)
{
    static const char *const STEP[] = {"", "READING THE PACKAGE", "CHECKING IT", "PREPARING", "ALMOST THERE", "RESTARTING"};
    uint32_t i;
    if (recovery_active) return;
    lcd_fill(0, 0, 240, 240, C_BLACK);
    if (step < 9u) {                                            /* an update is under way: the screen says so, and it stays up as far into the restart as the display keeps it */
        draw_text_box(0, 70, 240, &FONT_S, "UPDATING", C_WHITE, 1);
        draw_text_box(0, 96, 240, &FONT_S, "PLEASE WAIT", C_WHITE, 1);
        draw_text_box(0, 118, 240, &FONT_S, "DO NOT UNPLUG", C_WHITE, 1);
        draw_text_box(0, 160, 240, &FONT_S, STEP[step < 6u ? step : 0], C_WHITE, 1);
        for (i = 0; i < 5u; i++) lcd_fill((int)(40 + i * 32), 186, 28, 8, i < step ? C_WHITE : 0x2104u);      /* five steps */
    } else {
        draw_text_box(0, 92, 240, &FONT_S, code == 1 ? "TEST RUN" : "UPDATE DID NOT FINISH", C_WHITE, 1);
        draw_text_box(0, 124, 240, &FONT_S, code == 1 ? "ALL FINE" : "TRY AGAIN", C_WHITE, 1);
    }
}
static void ota_commit(const uint8_t *parm)
{
    bootguard_clear(&bootguard);
    usb_detach();
    fm1_delay_ms(30);
    fm1_enter_update(parm);
}
#include "recovery.c"

/* ---- the projects' flash, as the app sees it (tests/host.c has a file-backed copy) */
static int pf_read(uint32_t off, void *dst, uint32_t n) { return flash_ok ? st_read(off, dst, n) : -1; }
static int pf_erase(uint32_t off)               /* one 4 KB sector, ~50 ms with the interrupts off: the sound drops out */
{
    uint32_t took;
    return flash_ok ? fl_erase4k(off, &took) : -1;
}
static int pf_write(uint32_t off, const void *p, uint32_t n) { return flash_ok ? fl_write(off, p, n) : -1; }

/* ---- settings: [magic][length][crc32] then the bytes; settings_save erases the sector (~50 ms with
 * the interrupts off: the sound drops out), so save when nothing plays, not on every knob step */
#define SETTINGS_MAGIC 0x59474E44u              /* "DNGY" */
static uint32_t crc32(const uint8_t *p, uint32_t n)
{
    uint32_t c = 0xFFFFFFFFu, k;
    while (n--) {
        c ^= *p++;
        for (k = 0; k < 8u; k++)
            c = c & 1u ? (c >> 1) ^ 0xEDB88320u : c >> 1;
    }
    return ~c;
}
static int settings_load(void *p, uint32_t n)   /* 0: loaded; else p is untouched */
{
    static uint8_t buf[256];
    uint32_t h[3];
    if (!flash_ok || n > sizeof buf || st_read(SETTINGS_AT, h, sizeof h) || h[0] != SETTINGS_MAGIC || h[1] != n)
        return -1;
    if (st_read(SETTINGS_AT + sizeof h, buf, n) || crc32(buf, n) != h[2])
        return -1;
    memcpy(p, buf, n);
    return 0;
}
static int settings_save(const void *p, uint32_t n)   /* p in RAM, n <= 256 */
{
    uint32_t h[3] = {SETTINGS_MAGIC, n, 0}, took;
    int rc;
    if (!flash_ok || n > 256u)
        return -1;
    h[2] = crc32(p, n);
    if ((rc = fl_erase4k(SETTINGS_AT, &took)) != 0)
        return rc;
    if ((rc = fl_write(SETTINGS_AT + sizeof h, p, n)) != 0)
        return rc;
    return fl_write(SETTINGS_AT, (const uint8_t *)h, sizeof h);   /* the header last: a cut save stays invalid */
}

/* ---- MIDI over USB: 4-byte USB-MIDI packets, cable 0 */
static int midi_get(uint8_t *st, uint8_t *d1, uint8_t *d2)   /* 1: a message (status, data 1, data 2) */
{
    uint32_t pk;
    if (mi_r == mi_w)
        return 0;
    pk = midi_in_q[mi_r % MQ];
    mi_r++;
    *st = (uint8_t)(pk >> 8);
    *d1 = (uint8_t)(pk >> 16);
    *d2 = (uint8_t)(pk >> 24);
    return 1;
}
static void midi_send(uint32_t st, uint32_t d1, uint32_t d2)   /* from the main loop only: the audio ISR is held off while it writes the ring */
{
    uint32_t f = irq_save();
    midi_out_event((st >> 4) | st << 8 | (d1 & 0x7Fu) << 16 | (d2 & 0x7Fu) << 24);
    irq_restore(f);
}
static void midi_isr_send(uint32_t st, uint32_t d1, uint32_t d2)   /* from the audio ISR only (the MIDI clock): the main loop's midi_send keeps out of its way */
{
    midi_out_event((st >> 4) | st << 8 | (d1 & 0x7Fu) << 16 | (d2 & 0x7Fu) << 24);
}

/* ---- the timer: 10 kHz key scan, milliseconds, USB at 2 kHz. It outranks the audio ISR; nested in a
 * render it only scans, counts and feeds the USB audio stream (as sloopDX main.c) */
static volatile uint8_t in_audio;
void fm1_timer5_irq(void)
{
    static uint32_t sub, owed, last, acc;
    uint32_t t0 = fm1_ticks(), usb_due = sub % 5u == 0u;
    fm1_timer5_ack();
    fm1_input_tick();
    acc += t0 - last;
    last = t0;
    while (acc >= 1000u * FM1_TICKS_PER_US) {
        acc -= 1000u * FM1_TICKS_PER_US;
        fm1_ms++;
    }
    if (usb_due)
        owed = 1;
    if (++sub == 10u)
        sub = 0;
    if (in_audio) {
        if (usb_due)
            uac_service();
        return;
    }
    if (owed)
        usb_poll();
    owed = 0;
}
extern void isr_timer5(void);

/* ---- the sound: ALNK0 I2S, two halves; the app renders, the MASTER knob scales, Q15 -> 24 bit (-6 dBFS ceiling) */
static int32_t abuf[2u * HALF_WORDS] __attribute__((aligned(4)));
static volatile int32_t master_q12 = 2048;
static void app_audio(int32_t *out, uint32_t n);
static void app_main(void);

void fm1_alnk0_irq(void)                       /* via isr_alnk0 (hal/fm1_isr.S) */
{
    uint8_t p;
    in_audio = 1;
    p = fm1_audio_pending();
    fm1_audio_ack_aux(p);
    if (p & FM1_AUDIO_HALF) {
        int32_t *o = &abuf[fm1_audio_free_half() * HALF_WORDS];
        uint32_t i, b;
        for (i = 0; i < HALF_WORDS; i++)
            o[i] = 0;
        uac_render_start();
        app_audio(o, HALF_FRAMES);
        for (i = 0; i < HALF_WORDS; i++) {
            int32_t v = (o[i] * master_q12) >> 12;
            o[i] = v > 32767 ? 32767 : v < -32767 ? -32767 : v;
        }
        for (b = 0; b < HALF_FRAMES; b += 32u)
            uac_tap(o + 2u * b, 32u);           /* the computer records what the speaker plays */
        for (i = 0; i < HALF_WORDS; i++)
            o[i] <<= 7;
        fm1_audio_ack_half();
    }
    in_audio = 0;
}
extern void isr_alnk0(void);

/* ---- the main loop's duties: watchdog, USB, the installer's update request, the MASTER knob */
static volatile uint8_t ota_back;                /* an install session ended without committing: its message is on the screen */
static void platform_poll(void)
{
    static int32_t knob_avg = 512 * 16;
    int32_t a;
    fm1_wdt_feed();
    usb_retry(fm1_ms);
    ota_service();
    if (usb.ota_req) {
        usb.ota_req = 0;
        ota_hit_ms = fm1_ms | 1u;
        if (flash_ok) {
            ota_session();                      /* returns only if nothing was committed */
            ota_back = 1;                       /* it drew UPDATE / FAILED over the whole screen: the app repaints everything */
        }
    }
    if (usb.uboot_req) {
        fm1_audio_stop();
        lcd_fill(0, 0, 240, 240, C_BLACK);
        draw_text_box(0, 110, 240, &FONT_S, "UBOOT (USB)", C_WHITE, 1);
        usb_detach();
        fm1_delay_ms(30);
        bootguard.pending = 0;
        fm1_enter_uboot();
    }
    if (fm1_ms >= 30000u && bootguard.pending)
        bootguard_clear(&bootguard);            /* 30 s up: this firmware boots */
    if ((a = fm1_adc_read(FM1_ADC_MASTER)) >= 0) {
        uint32_t k10;
        knob_avg += (a * 16 - knob_avg) / 8;
        k10 = (uint32_t)(knob_avg / 16);
        master_q12 = (int32_t)((k10 * k10) >> 8);
    }
}

/* The crash screen: 15 rows of 30 characters, all of it for the report that comes back to us. Any button restarts. */
extern void brothers_dbg(uint32_t *o);          /* ble/ble.c: where the radio was */
extern char _etext[];
static char *fm1_cat(char *p, const char *s) { while (*s) *p++ = *s++; return p; }
static char *fm1_cath(char *p, uint32_t v, uint32_t n)
{
    uint32_t k;
    for (k = 0; k < n; k++) *p++ = "0123456789ABCDEF"[(v >> (4u * (n - 1u - k))) & 15u];
    return p;
}
static char *fm1_catd(char *p, uint32_t v)
{
    char t[10];
    uint32_t n = 0;
    do { t[n++] = (char)('0' + v % 10u); v /= 10u; } while (v && n < 10u);
    while (n) *p++ = t[--n];
    return p;
}
static char *fm1_cats(char *p, uint32_t b)       /* a signed byte */
{
    if (b & 0x80u) { *p++ = '-'; b = 256u - b; }
    return fm1_catd(p, b);
}
static void fm1_row(uint32_t i, const char *s, uint16_t c, int centre)
{
    cv_begin(240, 16, RGB(160, 0, 0));
    cv_text(centre ? (240 - text_w(&FONT_S, s)) / 2 : 4, 0, &FONT_S, s, c);
    cv_blit(0, i * 16u);
    lcd_sync();
}

static void fm1_fault(const fm1_crash_t *c)
{
    char r[34], *p;
    const uint32_t *bl = fm1_crash.bl;
    uint32_t t0, armed = 0, up = c->uptime_ms;
    const uint16_t PINK = RGB(255, 185, 185), AMBER = RGB(255, 205, 40);
    fm1_audio_stop();
    lcd_fill(0, 0, 240, 240, RGB(160, 0, 0));
    if (!fm1_crash.bl_ok) {                     /* the radio as it was at the fault, kept for a redraw after a reset */
        brothers_dbg(fm1_crash.bl);
        fm1_crash.bl_ok = 1;
    }
    fm1_row(0, APP_NAME " CRASH", C_WHITE, 1);
    p = fm1_cat(r, "v" APP_VER " T"); p = fm1_cath(p, (uint32_t)(uintptr_t)_etext, 6);
    p = fm1_cat(p, " #"); p = fm1_catd(p, c->count); p = fm1_cat(p, " EARLY "); p = fm1_catd(p, c->early); *p = 0;
    fm1_row(1, r, PINK, 0);
    p = fm1_cat(r, "UP "); p = fm1_catd(p, up / 1000u); *p++ = '.'; p = fm1_catd(p, up / 100u % 10u);
    p = fm1_cat(p, "S RST "); p = fm1_cath(p, fm1_boot.p3_rst, 2); p = fm1_cat(p, " FL "); p = fm1_cath(p, flash_id, 6); *p = 0;
    fm1_row(2, r, PINK, 0);
    p = fm1_cat(r, "VEC "); p = fm1_cath(p, c->vec, 2); p = fm1_cat(p, "  PC "); p = fm1_cath(p, c->pc, 8); *p = 0;
    fm1_row(3, r, C_WHITE, 0);
    p = fm1_cat(r, "RETS "); p = fm1_cath(p, c->rets, 8); p = fm1_cat(p, " SP "); p = fm1_cath(p, c->sp, 8); *p = 0;
    fm1_row(4, r, C_WHITE, 0);
    p = fm1_cat(r, "DBG "); p = fm1_cath(p, c->dbg, 8); p = fm1_cat(p, " EMU "); p = fm1_cath(p, c->emu, 8); *p = 0;
    fm1_row(5, r, C_WHITE, 0);
    p = r;
    if (c->dbg & (1u << 12)) p = fm1_cat(p, "PC LIMIT ");
    if (c->dbg & (1u << 13)) p = fm1_cat(p, "WRITE LIMIT ");
    if (c->dbg & ((3u << 4) | (0x3Fu << 16))) p = fm1_cat(p, "BUS ");
    if (c->emu & 8u) p = fm1_cat(p, "STACK ");
    if (p == r) p = fm1_cat(p, "CPU FAULT");
    *p = 0;
    fm1_row(6, r, AMBER, 0);
    p = fm1_cat(r, "ETM "); p = fm1_cath(p, c->etm[0], 8); *p++ = ' '; p = fm1_cath(p, c->etm[1], 8); *p = 0;
    fm1_row(7, r, C_WHITE, 0);
    p = fm1_cat(r, "    "); p = fm1_cath(p, c->etm[2], 8); *p++ = ' '; p = fm1_cath(p, c->etm[3], 8); *p = 0;
    fm1_row(8, r, C_WHITE, 0);
    if (c->nested) {
        p = fm1_cat(r, "2ND PC "); p = fm1_cath(p, c->pc2, 8); p = fm1_cat(p, " R "); p = fm1_cath(p, c->rets2, 8); *p = 0;
        fm1_row(9, r, AMBER, 0);
    } else {
        p = fm1_cat(r, "PSR "); p = fm1_cath(p, c->psr, 8); p = fm1_cat(p, " ICFG "); p = fm1_cath(p, c->icfg, 8); *p = 0;
        fm1_row(9, r, C_WHITE, 0);
    }
    if (bl[0] & 16u) {
        p = fm1_cat(r, "BL "); p = fm1_cat(p, (bl[0] & 15u) == 1u ? "LEAD" : (bl[0] & 15u) == 2u ? "FOLLOW" : "OFF");
        p = fm1_cat(p, " GRP "); p = fm1_catd(p, bl[0] >> 8 & 255u); p = fm1_cat(p, " OPS "); p = fm1_catd(p, bl[6]); *p = 0;
    } else {
        p = fm1_cat(r, "BL RADIO NEVER STARTED"); *p = 0;
    }
    fm1_row(10, r, C_WHITE, 0);
    p = fm1_cat(r, "ADDR "); p = fm1_cath(p, bl[3], 8); p = fm1_cat(p, " IRQ "); p = fm1_cath(p, bl[2], 8); *p = 0;
    fm1_row(11, r, C_WHITE, 0);
    p = fm1_cat(r, "SCAN "); p = fm1_cats(p, bl[5] & 255u);
    p = fm1_cat(p, " TRIM "); p = fm1_cats(p, bl[5] >> 8 & 255u);
    p = fm1_cat(p, " MID "); p = fm1_catd(p, bl[5] >> 16 & 255u);
    p = fm1_cat(p, " TO "); p = fm1_catd(p, bl[4] & 0xFFFFu); *p++ = '/'; p = fm1_catd(p, bl[4] >> 16); *p = 0;
    fm1_row(12, r, C_WHITE, 0);
    fm1_row(13, "PRESS ANY BUTTON TO RESTART", C_WHITE, 1);
    fm1_row(14, APP_REPO, PINK, 1);
    lcd_sync();
    t0 = fm1_ticks();
    for (;;) {                                  /* interrupts are off: read the panel by hand */
        fm1_wdt_feed();
        fm1_input_tick();
        fm1_delay_us(200);
        if (!(fm1_in.buttons | fm1_in.notes))
            armed = 1;
        else if (armed && (uint32_t)(fm1_ticks() - t0) > 1000u * 1000u * FM1_TICKS_PER_US)
            break;
    }
    fm1_crash.armed = 0;
    fm1_reboot();
}

void fm1_cstart(void)
{
    extern uint32_t _data_start[], _data_end[], _data_load[], _bss_start[], _bss_end[];
    extern uint32_t _pool_start[], _pool_end[], _rt_start[], _rt_end[], _rt_load[];
    uint32_t *s, *d, p3, boot_mode;
    fm1_time_init();
    fm1_reset_reason();
    p3 = fm1_boot.p3_rst;
    fm1_wdt_arm(0x0D);
    if ((p3 & 1u) && !(p3 & (4u | 0x40u)))
        bootguard_clear(&bootguard);
    boot_mode = bootguard_begin(&bootguard);
    if (boot_mode == BOOT_ROM)
        fm1_enter_uboot();
    fm1_irq_init();
    for (d = _bss_start; d < _bss_end; d++) *d = 0;
    for (d = _pool_start; d < _pool_end; d++) *d = 0;
    for (s = _data_load, d = _data_start; d < _data_end; s++, d++) *d = *s;
    for (s = _rt_load, d = _rt_start; d < _rt_end; s++, d++) *d = *s;
    fm1_mailbox_clear();
    fm1_guard_enable(FM1_GUARD_STACK | FM1_GUARD_WRITE | FM1_GUARD_BUS | FM1_GUARD_PC);
    fm1_boot.p3_rst = (uint8_t)p3;
    if (boot_mode == BOOT_RECOVERY || recovery_key())
        recovery_main();                        /* OCT- at power-on: the USB rescue */
    flash_id = FL_FAR(fl_jedec_ram)();
    flash_ok = FL_JEDEC_OK(flash_id);
    ota_boot_cleanup();
    lcd_init();
    lcd_fill(0, 0, 240, 240, C_BLACK);
    fm1_input_init();
    if (fm1_crash.magic == FM1_CRASH_MAGIC && fm1_crash.armed == FM1_REPORT_MAGIC)
        fm1_fault(&fm1_crash);                  /* a report nobody ack'd (a reset cut it short): show it now */
    fm1_adc_init();
    fm1_audio_init(abuf, HALF_WORDS, isr_alnk0, 3);   /* (abuf is zero: .bss) */
    usb_start();
    fm1_timer5_start(isr_timer5, 4);
    fm1_guard_lock_top();
    fm1_irq_enable_all();
    app_main();
    for (;;)
        platform_poll();
}
#endif
