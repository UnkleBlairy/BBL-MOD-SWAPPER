/* SPDX-License-Identifier: GPL-3.0-only */
/* teensy-fm1: Drumlab 1.0.0-graduationday (https://github.com/pbarilla/drumlab) on the Teensy 4.1: the app on tests/host.c's fake FM-1, inside ports/common's shell */
#ifdef __arm__                          /* (the FM-1's clang: uint32_t is unsigned int; newlib's is unsigned long) */
#undef __UINT32_TYPE__
#undef __INT32_TYPE__
#define __UINT32_TYPE__ unsigned int
#define __INT32_TYPE__ int
#endif
#include "../../../common/shell_pre.h"
#define CO_STACK 16384u
#include "../../../common/coro.h"
#include <stdlib.h>
#define getenv(n) ((char *)0)
#include "../../../common/miniprintf.h"
static int din_noprint(const char *f, ...) { (void)f; return 0; }
static int din_nofile(const void *f, ...) { (void)f; return 0; }
static void *din_nofile0(const void *f, ...) { (void)f; return 0; }
typedef struct { int none; } din_file_t;
#define printf din_noprint
#define fprintf din_nofile
#define fputs(s, f) ((void)(s))
#define fputc(c, f) ((void)(c))
#define SEEK_SET 0
#define SEEK_END 2
#define ftell(f) 0L
#define puts(s) ((void)(s))
#define putchar(c) ((void)(c))
#define FILE din_file_t
#define fopen(...) ((FILE *)din_nofile0(__VA_ARGS__))
#define fread(...) ((unsigned)din_nofile(__VA_ARGS__))
#define fwrite(...) ((unsigned)din_nofile(__VA_ARGS__))
#define fseek(...) din_nofile(__VA_ARGS__)
#define fclose(f) ((void)(f))
#define fflush(f) ((void)(f))
#define stdout ((FILE *)0)
#define stderr ((FILE *)0)
#define perror(s) ((void)(s))
struct din_ts { long tv_sec, tv_nsec; };
#define timespec din_ts
#define CLOCK_MONOTONIC 1
#define clock_gettime(c, t) ((t)->tv_sec = 0, (t)->tv_nsec = 0, 0)
#ifdef __arm__
#define exit(n) do { for (;;) ; } while (0)
#define abort() do { for (;;) ; } while (0)
#endif
#define CHIPBOX_HOST 1
static void platform_poll(void);
#include "../../firmware/src/lab.c"
#undef __attribute__
#undef memset
#undef memcpy
static void platform_poll(void) { co_yield(); }

static int32_t din_master = 4096;
static int32_t din_blk[2u * HALF_FRAMES];
static float din_l[1024], din_r[1024];
static float *din_lp(void) { return din_l; }
static float *din_rp(void) { return din_r; }
static void din_render(uint32_t n)
{
    static uint32_t at = HALF_FRAMES, ms, busy;
    uint32_t i, j;
    for (i = 0; i < n; i++) {
        if (at >= HALF_FRAMES) {
            memset(din_blk, 0, sizeof din_blk);
            app_audio(din_blk, HALF_FRAMES);
            for (j = 0; j < 2u * HALF_FRAMES; j++) {
                int32_t v = (int32_t)(((int64_t)din_blk[j] * din_master) >> 12);
                din_blk[j] = v > 32767 ? 32767 : v < -32767 ? -32767 : v;
            }
            at = 0;
        }
        din_l[i] = (float)din_blk[2u * at] * (1.0f / 32768.0f);
        din_r[i] = (float)din_blk[2u * at + 1u] * (1.0f / 32768.0f);
        at++;
        if ((ms += 1000u) >= 44100u) {
            ms -= 44100u;
            fm1_ms++;
            if (busy) busy--;
            else { din_px = 0; co_resume(); busy = din_px / 750u; }   /* (the FM-1's screen: ~1.33 us a pixel) */
        }
    }
}
#define SH_FLOAT
#define SH_OUT_L din_lp
#define SH_OUT_R din_rp
#define SH_RENDERF(n) din_render(n)
#define SH_ADC(m) (din_master = (int32_t)((m * m) >> 8))
static void SH_BOOT(void) { co_start(app_main); co_resume(); }
static void SH_FRAME(uint32_t ms) { (void)ms; }
#define SH_ENC(e, n) (din_enc[e] += (n))
#define SH_BTN(i, d) do { if (d) { fm1_in.buttons |= 1u << (i); din_press |= 1u << (i); } else { fm1_in.buttons &= ~(1u << (i)); din_rel |= 1u << (i); } } while (0)
#define SH_KEY(k, d) do { if (d) { fm1_in.notes |= 1u << (k); din_nedge |= 1u << (k); } else fm1_in.notes &= ~(1u << (k)); } while (0)
#define SH_KEY_LED(k) (din_led[14u + (k)] ? 2 : din_glow[14u + (k)] ? 1 : 0)
#define SH_BTN_LED(i) (din_led[i] ? 2 : din_glow[i] ? 1 : 0)
#include "../../../common/shell_post.h"
