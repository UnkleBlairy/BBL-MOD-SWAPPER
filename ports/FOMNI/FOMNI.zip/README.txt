FoMni 0.5 for the BBL Mod Swapper

Original by charlesvestal: https://github.com/charlesvestal/fm1-fomni
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: FOMNI-source.zip on the ports page.
