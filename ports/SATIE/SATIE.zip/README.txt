Satie-1 0.1.3 for the BBL Mod Swapper

Original by OCKM-STUDIO: https://github.com/OCKM-STUDIO/SATIE-1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: SATIE-source.zip on the ports page.
