/* SPDX-License-Identifier: GPL-3.0-only */
/* The instrument: HYP-1, hypnotic techno and acid for the FM-1 (a fork of AMB-1), built like a small
 * modular: generative voices you shape over time, over drums you sequence. The voices draw on one pool
 * of notes (a scale) and one chord that drifts slowly through it:
 *
 *   PAD     four breathing voices (Rhodes or Voices), each breath its own envelope (attack, hold, release,
 *           rest) and the chord forming and dissolving through them; an LFO on its filter, level, pan or pitch.
 *   NOISE   a bed of noise in eight colours (white to black), filtered, pumping with the kick.
 *   DRONE   three detuned saws and a sub-octave through a 24 dB low-pass, on the chord's root; an envelope
 *           on its filter (on each chord, or every 1 .. 8 bars) and an LFO (16 bars, a sine, by default).
 *   ACID    a generative 303-style line: a loop of 1 .. 16 sixteenths of chord tones with accents and
 *           slides, a resonant low-pass with an envelope; MUTATE re-rolls its steps as it goes.
 *   DRUMS   a sixteen-step sequencer, six lanes (kick, snare, clap, closed hat, open hat, perc), six
 *           patterns; a new pattern waits for the end of the bar. The kick ducks everything else.
 *
 * The sections are the player's: a breakdown, a build, the drop (en_section). Over it all the ARC, a slow
 * tide between sparse and full (MOTION). Then a tempo-synced tape echo and an Echoplex, Dattorro's plate,
 * and the held performance effects (en_fx).
 *
 * Threads: en_render() runs in the audio interrupt. Everything else posts commands, which the render
 * drains at the start of a block; the state below marked (UI) is written by the render and only read
 * elsewhere (the drum patterns, en_pats, are the exception: the UI edits them, the render reads them).
 * Float only, no libm: fastmath.h. */
#pragma once
#include <stdint.h>

#define EN_SR 44100.0f
#define EN_NDRUM 6                     /* the drum lanes: kick, snare, clap, closed hat, open hat, perc */
#define EN_NLANE EN_NDRUM
#define EN_NPAT 6                      /* drum patterns */
#define EN_NSTEP 16
#define EN_NPAD 4                      /* pad voices */
#define EN_NTHEME 6                    /* the screen's colour themes (the UI's; kept with the settings) */
#define EN_NSTYLE 5                    /* the old styles (before 1.0.27): a stored piece's is turned into sounds
                                        * and a kit (en_style_sounds); they were kits 0..4 */
#define EN_NSOUND 24                   /* the sounds each of pad and drone can play */
#define EN_NACID 31                    /* the acid's (more: supersaws, CZs, minis) */
#define EN_NFMFACT 30                  /* the DX7 voices of fm6.inc built in */
#define EN_NUSER 16                     /* and the ones the player loads (SysEx, en_user_voice), after them */
#define EN_NCMFM (EN_NFMFACT + EN_NUSER)   /* the counter-melody's six-operator FM sounds: after the plain ones */
#define EN_NCMSND (12 + EN_NCMFM)      /* the counter-melody's sounds */
#define EN_NCMSTYLE 6                  /* its styles */
#ifdef EN_SATIE1
#define EN_NKIT 15
#define EN_KIT_BRUSH 14
#define EN_SATIE_DUB_BASS 8             /* Ghost's dedicated sub, selected by P_DR_INST */
#else
#define EN_NKIT 14                      /* the sounds each drum (kick, snare + clap, hats, perc) can play */
#endif
enum { EN_V_PAD, EN_V_DRONE, EN_V_ACID, EN_V_SAMPLE, EN_V_PLUCK };   /* the voices the keys can play (en_note) */

/* modes: pools relative to the root (bit i: root + i semitones) */
enum { MODE_IONIAN, MODE_DORIAN, MODE_PHRYGIAN, MODE_LYDIAN, MODE_MIXOLYDIAN, MODE_AEOLIAN, MODE_PENT_MAJ,
       MODE_PENT_MIN, EN_NMODES };
extern const char *const EN_MODE_NAME[EN_NMODES];
extern const uint16_t EN_MODE_POOL[EN_NMODES];
extern const char *const EN_NOTE_NAME[12];
extern const char *const EN_LANE_NAME[EN_NLANE];
extern const char *const EN_PAD_SOUND[EN_NSOUND], *const EN_DRONE_SOUND[EN_NSOUND], *const EN_ACID_SOUND[EN_NACID];
extern const char *const EN_KIT_NAME[EN_NKIT];
extern const char *EN_CM_SOUND[EN_NCMSND];     /* (the user voices' names change as they are loaded) */
extern const char *const EN_CM_STYLE[EN_NCMSTYLE], *const EN_CM_RATE[4];
/* the player's own DX7 voices: up to EN_NUSER, 128-byte packed records (the DX7's bulk-dump format: a 32-voice bank is 32 of them). en_user_voice may be
 * called from the main loop; the engine takes the voice between chunks. Slots fill in order (a slot may be replaced, or appended at en_user_count()). */
int en_user_voice(int slot, const uint8_t *packed128);   /* 1 taken; 0 not (busy, or slot past the end) */
void en_user_clear(void);                      /* all of them gone */
int en_user_count(void);                       /* how many are loaded */
int en_user_next(void);                        /* the slot a single voice goes to: the next free one, or the last when all are in use */
int en_ncm_snd(void);                          /* how many pluck sounds can be chosen now: the plain ones, the built-in DX voices, the loaded ones */
const uint8_t *en_user_get(int slot);          /* a loaded voice's 128 bytes (to store) */
void en_voice_unpack(const uint8_t *packed128, uint8_t *voice155);   /* the DX7's two formats: for single-voice dumps (155 bytes) and the tests */
void en_voice_pack(const uint8_t *voice155, uint8_t *packed128);
extern volatile float en_cm_level;             /* the counter-melody's level, for the screen */
void en_style_sounds(int16_t *par);             /* a piece stored with a style (before 1.0.27): its sounds and
                                                 * kit set as the style had them, the style cleared */

/* parameters: value ranges in en_param_info() */
enum {
    P_PAD, P_ACID, P_BASS, P_PULSE, P_NOISE,              /* the layers' levels (the drone, the drums, and the vinyl) */
    P_TEMPO, P_EVOLVE, P_MOTION, P_DRIFT,                 /* tempo */
    P_BRIGHT, P_PADTONE, P_DETUNE,                        /* pad */
    P_PE_ATK, P_PE_HOLD, P_PE_REL, P_PE_REST,             /* pad envelope (the breath) */
    P_PL_RATE, P_PL_DEPTH, P_PL_SHAPE, P_PL_DEST,         /* pad LFO */
    P_NZ_COLOR, P_AC_EVERY, P_NZ_PUMP,                    /* the vinyl (P_NOISE is its level): its wear, (P_AC_EVERY took the old unused tone's place, the bank was full: the acid's answer, every 2nd .. 8th time round), how hard the kick ducks it */
    P_BASSOCT, P_DR_CUT, P_DR_RES,                        /* drone */
    P_DE_TRIG, P_DE_ATK, P_DE_DEC, P_DE_AMT,              /* drone envelope */
    P_DL_RATE, P_DL_DEPTH, P_DL_SHAPE, P_DL_DEST,         /* drone LFO */
    P_AC_CUT, P_AC_RES, P_AC_ENV,                         /* acid */
    P_AC_DEC, P_AC_ACC, P_AC_SLIDE, P_AC_WAVE,            /* acid envelope */
    P_AC_DENS, P_AC_LEN, P_AC_RANGE, P_AC_MUT,            /* acid line */
    P_AC_OCT,                                             /* OCT- / OCT+ */
    P_DRIVE, P_SWING, P_PATTERN,                          /* drums */
    P_LANE,                                               /* each lane's level, tune, decay: P_LANE + 3 * lane + 0..2 */
    P_ECHO = P_LANE + 3 * EN_NLANE, P_ETIME, P_REVERB, P_SIZE,   /* space */
    P_ROOT, P_MODE, P_TUNE, P_MIDI, P_THEME,              /* global (the mode on ALGORITHM) */
    P_STYLE,                                              /* kept for the bank's layout: a piece stored before
                                                           * 1.0.27 has its style here (read once, then 0) */
    P_LINKS, P_LK_KICK, P_LK_SNARE, P_LK_HAT, P_LK_PERC,  /* the drums into the voices: on / off (SEL + SEQ);
                                                           * kick > drone, snare and clap > pad, hats > acid
                                                           * accents, perc > the acid's clock */
    P_OCT, P_PAD_OCT,                                     /* the whole song's octave; the pad's (OCT- / OCT+;
                                                           * the drone's is P_BASSOCT, the acid's P_AC_OCT) */
    P_DR_INST,                                            /* the drone's sound (the pad's: P_PADTONE, the acid's:
                                                           * P_AC_WAVE) */
    P_KIT_KICK, P_KIT_SNARE, P_KIT_HAT, P_KIT_PERC,       /* the kit: each drum's sound (snare: and the clap;
                                                           * hats: closed and open) */
    P_PAD_MAN, P_DR_MAN, P_AC_MAN,                        /* a voice off the algorithm (SEL + ENV on its page):
                                                           * silent but for the keys (en_note) */
    P_CHORD, P_VOICING,                                   /* the pad's chords: their kind (EN_CH_*), close or
                                                           * open (drop 2) */
    P_DD_CHANGE, P_DD_EVERY, P_DD_POOL, P_DD_MUTATE,      /* drum drift: the patterns change by themselves (Off,
                                                           * Next, Random), when (with the chord, or every 4-64
                                                           * bars), from patterns 1..pool, a fill the bar before;
                                                           * and mutate (Off, Shift, Morph): hits move, come, go */
    P_CM_LVL, P_CM_SND, P_CM_DENS, P_CM_OCT,              /* the counter-melody (PLUCK): level, sound, density, octave */
    P_CM_DEC, P_CM_STYLE, P_CM_RATE, P_CM_RANGE,          /* decay, style (up, down, ..), rate (1/8, 1/16, 1/4, 3/16), range in octaves */
    P_PROB, P_PROB1, P_PROB2, P_PROB3, P_PROB4, P_PROB5,  /* each drum lane's chance a hit sounds (P_PROB + lane), 100 always: thinned from the sequencer */
    P_PAN, P_PAN1, P_PAN2, P_PAN3, P_PAN4,                /* the mixer: each layer's place (pad, drone, acid, pluck, drums; 50 the middle) */
    P_SEND, P_SEND1, P_SEND2, P_SEND3, P_SEND4,           /* and how much of it goes to the echo and the reverb (50 as it was) */
    P_CM_MAN,                                             /* the pluck off the algorithm (the JAM page plays it by hand: engine-only, the page sets it) */
    P_RV_TYPE, P_RV_DAMP, P_RV_PRE, P_RV_X,               /* the reverb: Plate / Shimmer / Gated, its damping, its predelay, and the type's own amount (the shimmer's, the gate's hold) */
    P_PL_CHO,                                             /* the pad's ensemble chorus: three modulated delays a side, how much of them */
    P_MC_RATIO, P_MC_THR, P_MC_MAKE, P_ML_CEIL,           /* the master bus: compressor ratio (Off .. 10:1), threshold, make-up gain, and the limiter's ceiling */
    P_LLEN, P_LLEN1, P_LLEN2, P_LLEN3, P_LLEN4, P_LLEN5,  /* each drum lane's length in steps (P_LLEN + lane), 16 the bar: shorter ones run against it (polymeter) */
    P_DENS, P_DENS1, P_DENS2, P_DENS3, P_DENS4, P_DENS5,  /* each drum lane's busyness (P_DENS + lane): 50 plays the pattern as written, less takes the least important hits out, more puts hits on the most important empty steps (the pattern itself is never edited) */
    P_LSRC, P_LSRC1, P_LSRC2, P_LSRC3, P_LSRC4, P_LSRC5,  /* the pattern each lane plays (P_LSRC + lane): 0 follows the piece's pattern, 1..6 holds that pattern's lane (from the next bar) */
    P_CH_LOOP,                                            /* the progression: 0 a fresh walk, 1..3 the last 2, 4 or 8 chords repeat, 4..6 the same with now and then one drawn anew */
    P_AC_RESP,                                            /* the acid's answer: every second time round the line is transformed (type * 5 + direction: 0 off; types 1 octave, 2 fifth, 3 third (in the scale), 4 mirror, 5 reverse, 6 rotate, 7 sparse, 8 accents; direction 0 .. 4: down 2, down, same, up, up 2) */
    P_BL_MODE, P_BL_LEN, P_BL_MOVE, P_BL_GLIDE,           /* the drone as a bass line: its mode (0 drone, 1 root on the genre's rhythm, 2 on the kick, 3 eighths, 4 off-beat, 5 walking, 6 the genre's riff), how long a note holds, how much it moves (octaves, fifths, approach notes), its glide */
    P_CM_VU, P_CM_LOOP, P_CM_LEAP,                        /* the pluck's deja vu: how often a note is the one the loop heard last time round (0 always new .. 100 locked), the loop's length in notes (4, 8, 16, 32), and how often a new note leaps an octave */
    P_AC_CHG,                                             /* what the acid's Mutate changes: 0 everything, 1 the notes, 2 the rhythm, 3 the accents and slides */
    P_PAD_COMP,                                           /* the pad's comping: 0 auto (a stab sound plays its genre's rhythm), 1 hold (never stabs), 2 .. 8 stabs on a rhythm (off-beat, on-beat, 3-3-2, Charleston, syncopated, sparse, eighths) */
    P_GHOST, P_ACCENT, P_HUMAN,                           /* the feel: how often the genre's ghost notes sound (snare, kick), how much the steps' accents and ghosts (en_mod levels) count (50 as marked), and a little looseness in time and velocity */
    P_CHAIN, P_SLICE, P_TIME,                             /* the phrase: a chain of patterns by bar (0 off, 1 .. 9 a preset), a slice permutation of the drum steps (0 off, 1 .. 8, 9 a new one each fourth bar), the pattern's time (0 normal, 1 half, 2 double) */
    P_COND, P_COND1, P_COND2, P_COND3, P_COND4, P_COND5,  /* each drum lane's condition (P_COND + lane): 0 always, 1 odd bars, 2 even bars, 1 of 4, 4 of 4, 1 of 8, fill bars only, not in fills */
    P_AC_LOCK,                                            /* the acid line held: 0 free (it evolves with Mutate, a new one with each piece), 1 frozen (as it is: Mutate leaves it, and it is stored with the piece) */
    P_CM_MOTIF,                                           /* the pluck's motif (0.14.9): how often a bar of an 8-bar phrase develops the phrase's first bar (its rhythm and intervals: sequenced, inverted, re-ended, restated) instead of inventing; 0 off */
    P_CM_LOCK,                                            /* the pluck line held (0.14.21): 0 free (deja vu's loop comes and goes), 1 frozen (the loop's first sixteen slots are the line, a sixteenth a step, stored with the piece) */
    P_NPARAMS
};
#define P_AC_CHANCE P_STYLE                           /* the acid answer's sync (0: it counts bars, 1: loops of the line); it took the place of the old style, which only the oldest banks have */
#define P_LANE_LVL(l) (P_LANE + 3 * (l))
#define P_LANE_TUNE(l) (P_LANE + 3 * (l) + 1)
#define P_LANE_DEC(l) (P_LANE + 3 * (l) + 2)
typedef struct {
    const char *name;
    int16_t lo, hi, def;
} en_param_t;
const en_param_t *en_param_info(int i);
void en_param_text(int i, int v, char *buf);   /* the value as the screen shows it (10 bytes) */

/* commands (main loop -> render) */
void en_init(void);
/* The experimental second core: the plate reverb as a job another core can run (see render_chunk). submit runs
 * fn(ctx) there and returns 1, or returns 0 (run it here); join returns 1 when the job is done, 0 when that core was
 * lost (its results are dropped, the reverb restarts). Without it, or after a loss, the same job runs in place. fence publishes
 * memory between the cores (the job's stages); alive says whether the other core still runs (0: join it, it is retired). */
void en_core2_attach(int (*submit)(void (*fn)(void *), void *ctx), int (*join)(void), void (*fence)(void), int (*alive)(void));
extern volatile float en_comp_gr, en_lim_gr, en_out_peak;   /* the master bus now: the compressor's and the limiter's gain reduction (dB, positive), the output's peak (0..1 of full scale) */
void en_shed(int level);                       /* the load is too high: 0 none, 1 the DX voices to four and no chorus, 2 to two, 3 also no Echoplex, no vinyl noise and the cheap output clip (the UI watches the CPU and says) */
extern volatile uint8_t en_shed_level;
void en_flex_select(int pat);                  /* the Flex Beat pattern the FX_FLEX bit plays (0..EN_NFLEX-1): sent before the bit is set */
#define EN_NFLEX 27                            /* a pattern for each of the 27 keys */
void en_flx_hold(int on);                      /* a Flex Beat pad is held down (not latched): a one shot goes on, bar after bar, while it is, and ends on the bar line after it is let go */
void en_fill_next(void);                       /* a drum fill in the next bar (the auto-DJ asks one bar ahead: the fill is the last bar before the break) */
void en_dj_sync(int on);                       /* the auto-DJ follows the chord changes: the engine fills the bar before one and breaks on it */
/* MIDI OUT MAPS (0.15.7, the USB & MIDI page): where each part's notes go, so a sampler or groovebox plays them as it comes. GM: pad 1, pluck 2, bass 3, acid 4,
 * the drums on 10 with GM notes (as before). The others: amb.c MAPS. */
enum { EN_MAP_GM, EN_MAP_MS, EN_MAP_MPC, EN_MAP_SP404, EN_NMAP };
extern const char *const EN_MAP_NAME[EN_NMAP];
void en_midi_map(int m);
void en_midi_cc(uint32_t cc, uint32_t v);      /* a control change on every channel the MIDI map uses (MIDI out on) */
int en_build_len(void);                        /* the genre's build, in bars (the auto-DJ keeps its phrases on 8 bars with it) */
void en_drum_tap(int d, int vel);               /* a drum hit by hand (a pad on MIDI in): lane d (kick, snare, clap, closed hat, open hat, perc), velocity 1-127 */
void en_chord_deg(int d);                       /* the chord to the scale's degree d (0 the home chord) at once (a pad on MIDI in) */                        /* (the notes sounding are let go on the old map's channels first) */
void en_intro(int secs);                       /* the intro (a setting): from Play the tracks come in one by one over this many seconds (the pad first, then hats, perc, kick, snare, bass, pluck, acid); 0 none */
extern volatile float en_intro_k;              /* how far the intro is, 0..1 (1: in, or none) */
extern volatile float en_drift_bars;           /* bars to the next chord change (the drift's), 99 when none is coming */
extern uint32_t en_c2_jobs, en_c2_lost;          /* chunks reverbed on the other core; times it was lost */
void en_set(int param, int value);
void en_pool(uint32_t pool);                   /* the scale, relative to the root (bit 0 always set) */
void en_play(int on);                          /* play / stop (the tails ring on) */
void en_next(void);                            /* the next chord: on the next bar (now while resting) */
void en_freeze(int on);
void en_trim(int g, int piece);                /* the playing piece's level: the loudest pieces turned down to the rest (0.16.6) */
void en_seed(uint32_t s);                      /* stir some entropy into the generators */
void en_note_v(int voice, int note, int vel);   /* the same, with a velocity (1 .. 127; 0 the note off; en_note's is 100): the pluck's, bass's and acid's level and accent (0.15.23) */
void en_note(int voice, int note, int on);
void en_bend(int voice, int bend);              /* a keyboard's pitch bend on a voice played by hand (pluck, drone, acid): -8192 .. 8191, two semitones each way (0.15.26) */
void en_modw(int voice, int depth);             /* its mod wheel: a vibrato on that voice, 0 .. 127 (up to half a semitone each way) */      /* a key played on the page of a voice off the algorithm (P_*_MAN):
                                                 * EN_V_*, MIDI note, on / off */
void en_mute(int on);                          /* remote: silent, no MIDI out (1) or back (0), in turn */
void en_hush(int on);                          /* a store while playing: fade out (1), back in (0) */
extern volatile uint8_t en_hushed;             /* faded right out (the flash can be written) */
void en_panic(void);                           /* everything quiet, now */
void en_regrow(void);                          /* a new piece: fresh loops, the home chord */
#ifdef EN_SATIE1
enum { ST_LEAD_TONE, ST_LEAD_CHAR, ST_BASS_TONE, ST_BASS_ATTACK, ST_BASS_LENGTH,
       ST_DRUM_TONE, ST_DRUM_PATTERN, ST_INNER_LEVEL, ST_DELAY_FB, ST_DELAY_TONE, ST_WIDTH, ST_NEDIT };
void en_satie_edit(int control, int value); /* audio-queue edit; continuous values slew */
void en_satie_start(int source, unsigned seed);
void en_satie_voicing(int voices);
/* Mix fades accompaniment in first, then the third musical part. */
#define EN_SATIE_MIX_BASS_START 10
#define EN_SATIE_MIX_BASS_FULL 40
#define EN_SATIE_MIX_INNER_START 55
#define EN_SATIE_MIX_INNER_FULL 80
void en_satie_arrangement(int mix);
extern volatile uint8_t en_satie_source, en_satie_section, en_satie_voices;
extern volatile uint16_t en_satie_seed, en_satie_step, en_satie_length;
#endif

/* the sections: a breakdown, a build, the drop, each taken on the next bar. A breakdown lasts until
 * a build (four bars, then the drop) or a drop is asked for; a build cut short by a drop drops. */
enum { EN_SEC_GROOVE, EN_SEC_BREAK, EN_SEC_BUILD };
enum { EN_CMD_BREAK, EN_CMD_BUILD, EN_CMD_DROP };
void en_section(int cmd);
extern volatile uint8_t en_sec;                /* the section now: EN_SEC_* (UI) */
extern volatile uint8_t en_sec_bars;           /* a build's bars left, 0 otherwise (UI) */
extern volatile uint8_t en_cm_note, en_cm_count;   /* the pluck's last note, and a count of its notes (UI) */
extern volatile uint8_t en_sec_req;            /* a command waiting for the bar: EN_CMD_* + 1, or 0 (UI) */

/* performance effects, held: one bit each, all at once as a mask (the UI sends it every frame). The
 * tracks, for mute and solo: kick; hats (closed and open); snare (snare and clap); perc; drone; acid;
 * pad (and the vinyl). The FX menu holds the four drums' mutes; every track's mute and solo, latched,
 * is en_trk (GLO held, on the keys). Bits 59..62 are spare; 63 is the UI's "no effect". */
enum {
    FX_RPT2, FX_RPT4, FX_RPT6, FX_RPT8, FX_RPT16, FX_RPT32,   /* beat repeat: the last 1/2 .. 1/32 note, looped */
    FX_REV, FX_STOP,                                          /* reverse; tape stop */
    FX_MUTE_KICK, FX_MUTE_HATS, FX_MUTE_SNARE, FX_MUTE_PERC,  /* the drums' mutes (momentary) */
    FX_LP, FX_HP,                                             /* the filters closing in */
    FX_GATE16, FX_GATE8, FX_GATEX,                            /* a trance gate on the synths: 1/16, 1/8, a pattern */
    FX_THROW, FX_FILL,                                        /* an echo throw; a drum fill */
    FX_PHASER, FX_FLANGER, FX_TAPE,                           /* a phaser; a flanger; tape wow and flutter */
    FX_ROLL, FX_PUMP, FX_RISER, FX_VINYL,                     /* a roll that speeds up; a sidechain pump; a build; vinyl dust */
    FX_SCATTER, FX_BRAKE, FX_SPIN, FX_HALF,                   /* the last slices shuffled; a vinyl brake; a spin-back; half time */
    FX_SWEEP,                                                 /* a filter swept in time with the tempo */
    FX_SCRATCH, FX_FREEZE, FX_RVSWELL, FX_RING,               /* an automatic scratch; a granular freeze; a reverse swell; a ring modulator */
    FX_RPT8T, FX_RPT16T,                                      /* beat repeats in triplets: 1/8, 1/16 */
    FX_FLEX,                                                  /* Flex Beat: one bit; the pattern (a one-bar table, en_flex_step) is en_flex_select's */
    FX_TFILT, FX_TDELAY, FX_TPHASE, FX_MDRUMS,                /* (0.15.19, on the first page's G4 A4 B4 C5, where the drums' mutes were) punch-ins on the tracks
                                                               * chosen (each page's Targets): a multimode filter, a delay, a phaser; and all four drums muted */
    FX_SPARE5, FX_SPARE6, FX_SPARE7,                          /* bits the Flex pads used to take: free for new effects */
    FX_SPARE8, FX_SPARE9, FX_SPARE10, FX_SPARE11, FX_SPARE12, FX_SPARE13, FX_SPARE14,
    FX_TALK, FX_WAH,                                          /* a vowel filter sweeping across everything; an auto-wah that follows the loudness */
    FX_HATROLL, FX_HATTRIP, FX_SNROLL, FX_FLAM, FX_DBLKICK,   /* drum rolls (held): the hats in 32nds; in triplets; a snare roll; flams on snare and clap; a double kick */
    EN_NFX = 64                                               /* the mask is 64 bits: FXB(bit) */
};
#define FXB(x) (1ull << (x))
enum { EN_TR_KICK, EN_TR_HATS, EN_TR_SNARE, EN_TR_PERC, EN_TR_DRONE, EN_TR_ACID, EN_TR_PAD, EN_TR_PLUCK, EN_NTRACK };
extern const char *const EN_FX_NAME[EN_NFX];   /* short names, for the screen */
void en_fx(uint64_t mask);
void en_trk(uint32_t mute, uint32_t solo);     /* the tracks' mutes and solos, a bit a track (EN_TR_*), latched */
uint32_t en_trk_heard(void);                    /* the mutes the engine has taken (en_trk, after the next block) */
void en_gate_pat(uint32_t steps);              /* the pattern gate (FX_GATEX): bit s, step s of its loop open */
/* the effects'' settings (the player''s, not a piece''s; not stored): en_fxs(i, v). Gate: the loop''s length in
 * sixteenths (2..16; the pattern, en_gate_pat, repeats every that many: 12 or 10 against a bar of 16 is a
 * polymeter), the tracks it closes (a bit a track, EN_TR_*), how far it closes them (0..100); the rest 0..100:
 * the phaser''s rate, depth, feedback and mix; the flanger''s; the vinyl''s level, crackle (pops a second),
 * hiss and tone. */
enum {
    EN_FXS_GX_LEN, EN_FXS_GX_TGT, EN_FXS_GX_DEPTH,
    EN_FXS_PH_RATE, EN_FXS_PH_DEPTH, EN_FXS_PH_FB, EN_FXS_PH_MIX,
    EN_FXS_FL_RATE, EN_FXS_FL_DEPTH, EN_FXS_FL_FB, EN_FXS_FL_MIX,
    EN_FXS_VN_LEVEL, EN_FXS_VN_CRACK, EN_FXS_VN_HISS, EN_FXS_VN_TONE,
    EN_FXS_TP_WOW, EN_FXS_TP_FLUT, EN_FXS_TP_DRIVE, EN_FXS_TP_DULL,      /* the tape: slow wobble, flutter, drive, dullness */
    EN_FXS_RL_START, EN_FXS_RL_END, EN_FXS_RL_TIME, EN_FXS_RL_SWELL,     /* the roll: its first and last rate (0..6: 1/2 .. 1/32, 1/64),
                                                                          * beats at each (0..3: 1/2, 1, 2, 4), its swell */
    EN_FXS_PM_DEPTH, EN_FXS_PM_REL, EN_FXS_PM_RATE, EN_FXS_PM_TGT,       /* the pump: depth, release, its period (0..3: 1/2 note,
                                                                          * 1/4, 1/8, 1/16), the tracks (a bit a track) */
    EN_FXS_RS_TIME, EN_FXS_RS_FILT, EN_FXS_RS_WASH, EN_FXS_RS_ECHO,      /* the riser: time to the top, high-pass, reverb, echo */
    EN_FXS_SC_CHAOS, EN_FXS_SC_REV, EN_FXS_SC_SIZE, EN_FXS_SC_LEN,       /* the scatter: how many slices move, how many play backwards,
                                                                          * the slice (0..2: 1/32, 1/16, 1/8), how many slices (2..8) */
    EN_FXS_BR_TIME, EN_FXS_BR_BACK, EN_FXS_BR_RET, EN_FXS_BR_DULL,       /* the brake and the spin-back: time to stop, the spin-back's speed,
                                                                          * time to spin back up, how dull it goes as it slows */
    EN_FXS_HF_SPEED, EN_FXS_HF_SLIDE,                                    /* half time: its speed (0..2: x1.5, x2, x4), the slide into it */
    EN_FXS_SW_RATE, EN_FXS_SW_DEPTH, EN_FXS_SW_RESO, EN_FXS_SW_TYPE,     /* the sweep: its period (0..4: 2 bars, 1 bar, 1/2, 1/4, 1/8),
                                                                          * how far (to 7 octaves), resonance, low-pass / high-pass / band-pass (0..2) */
    EN_FXS_SR_EVERY, EN_FXS_SR_REACH, EN_FXS_SR_STYLE,                   /* the scratch: its period (0..3: 1/4, 1/8, 1/16, 1/32 note), how much of
                                                                          * the past it works (0..3: 1/16, 1/8, 1/4, 1/2 note), baby or pull (0..1) */
    EN_FXS_FZ_SIZE, EN_FXS_FZ_SPREAD, EN_FXS_FZ_GRAINS,                  /* the freeze: grain size, how far back it draws, how many grains (0..3: 1..4) */
    EN_FXS_RV_LEN, EN_FXS_RV_MIX,                                        /* the reverse swell: its length (0..2: 1/2, 1, 2 beats), how much it replaces */
    EN_FXS_RM_FREQ, EN_FXS_RM_MIX,                                       /* the ring mod: its tone (40 .. 800 Hz), its mix */
    EN_FXS_FX_QUANT, EN_FXS_FX_MODE, EN_FXS_FX_MIX,                      /* Flex Beat: when it starts (0 off, 1 beat, 2 bar), one shot (0) or loop (1), its mix (0..100) */
    EN_FXS_TK_RATE, EN_FXS_TK_DEPTH, EN_FXS_TK_RESO, EN_FXS_TK_MIX,      /* talk: its period (0..4: 2 bars .. 1/8), how far through the vowels, resonance, mix */
    EN_FXS_WH_SENS, EN_FXS_WH_RANGE, EN_FXS_WH_RESO, EN_FXS_WH_MIX,      /* wah: how it follows the loudness, how far it sweeps, resonance, mix */
    EN_FXS_SM_MODE, EN_FXS_SM_LOOP, EN_FXS_SM_LEN, EN_FXS_SM_MIX,        /* the sampler: pitch (0) or slice (1), one shot (0) or loop (1), the window (0 full, 1 half, 2 quarter), its mix */
    EN_FXS_RP_PITCH, EN_FXS_RP_DECAY, EN_FXS_RP_GATE, EN_FXS_RP_REFRESH,   /* the beat repeats (0.14.10): the pitch reached over four beats held (0..24: -12..+12 semitones), a decay a repeat (0..100: 0..6 dB), the gate (0..3: all, 3/4, half, a quarter of the slice), the slip refresh (0 off, 1 each beat, 2 each bar: the slice is the newest again) */
    EN_FXS_FT_PAD, EN_FXS_FT_BASS, EN_FXS_FT_ACID,                       /* the synths' filter types (0.15.15, the FILTERS page, after Caustic's MultiFilter): 0 low-pass (as before),
                                                                          * 1 high-pass, 2 band-pass, 3 notch, 4 peak; the pad's for its saw sounds (the others have none) */
    EN_FXS_TF_TYPE, EN_FXS_TF_CUT, EN_FXS_TF_RESO, EN_FXS_TF_TGT,        /* (0.15.19) the punch-in FILTER: its type (as above), cutoff (40 Hz .. 16 kHz), resonance, targets (EN_PT_*) */
    EN_FXS_TD_SEND, EN_FXS_TD_FB, EN_FXS_TD_TGT,                         /* the punch-in DELAY (into the echo, at the piece's echo time): how much, how long it repeats, targets */
    EN_FXS_TP_RATE, EN_FXS_TP_DEPTH, EN_FXS_TP_MIX, EN_FXS_TP_TGT,       /* the punch-in PHASER: rate, depth, mix, targets */
    EN_FXS_SQ_DRIVE, EN_FXS_SQ_AMT, EN_FXS_SQ_WOW, EN_FXS_SQ_TGT,        /* (0.16.4) SCREAM, for the YouTube commenter who wanted the filters to scream: the voice driven harder into its
                                                                          * filter, the resonance taken towards singing (both stages), an accent opening it further, and which voice
                                                                          * (0 acid, 1 bass, 2 both); all at 0 the voices are as before */
    EN_FXS_AF_AMT, EN_FXS_AF_EVERY, EN_FXS_AF_LEN, EN_FXS_AF_PICK,       /* (0.16.8) AUTO FX, the UI's (ui.c af_tick; the engine keeps them only): how much (0 off,
                                                                          * 1 gentle, 2 medium, 3 wild), every 4/8/16/32 bars, the longest (a beat, half a bar,
                                                                          * a bar, two bars), the genre's own first or any */
    EN_NFXS
};
#define EN_FXS_DEFAULTS {16, 0xF0, 100, 40, 80, 55, 100, 35, 50, 50, 70, 40, 45, 40, 45, \
                         70, 45, 20, 50, 3, 5, 1, 0, 88, 35, 1, 0xF0, 56, 100, 100, 0, \
                         60, 25, 1, 4, 55, 50, 30, 50, 1, 30, 3, 70, 55, 0, \
                         1, 2, 0, 50, 60, 2, 1, 70, 45, 100, 2, 0, 100, 1, 70, 60, 100, 60, 60, 55, 100, 0, 1, 1, 80, \
                         12, 0, 0, 0, 0, 0, 0, 2, 50, 40, 2, 60, 60, 7, 40, 70, 60, 3, 0, 0, 0, 0, 0, 1, 2, 0}
extern const int16_t EN_FXS_DEF[EN_NFXS];
void en_fxs(int i, int v);
/* the punch-ins' targets (0.15.19): all, the drums, the synths, the pad, the bass, the acid, the pluck, acid and pluck, pad and pluck, bass and acid */
#define EN_NPT 10
extern const char *const EN_PT_NAME[EN_NPT];
uint8_t en_flex_step(int pat, int step);       /* Flex Beat pattern pat (0..EN_NFLEX-1), step 0..15: e | rev << 4 | mute << 5 | div << 6 (e 15: live) */
extern volatile uint8_t en_flx_state;          /* 0 idle, 1 armed, 2 playing */
extern volatile uint32_t en_flx_done;          /* one shots played out so far */
extern volatile uint8_t en_smp_active;       /* the DJ snips sounding */
const char *en_dj_name(int key);              /* the name of the snip on a key (0..26) */
void en_spectrum(float *out, int nb);          /* the master's spectrum, nb bands (70 Hz .. 10 kHz), each 0..1: for the screen */
/* the FX knobs: 0 filter (-50 low-pass .. +50 high-pass, 0 off), 1 crush, 2 throw, 3 wash (0..100) */
enum { EN_FXK_FILTER, EN_FXK_CRUSH, EN_FXK_THROW, EN_FXK_WASH, EN_NFXK };
void en_fxk(int k, int v);
/* MIDI clock in (as FoMni): ticks drive the 1/16 grid (6 a step) while they keep coming */
enum { EN_CLK_TICK, EN_CLK_START, EN_CLK_CONTINUE, EN_CLK_STOP };
void en_clock(int msg);

/* the render (audio ISR): n stereo frames, 24-bit in int32; gain Q12 (the MASTER pot) */
void en_render(int32_t *out_lr, uint32_t n, uint32_t gain_q12);

/* MIDI out, from the render: the app sends it (USB); status, data 1, data 2 */
void en_midi_out(uint32_t st, uint32_t d1, uint32_t d2);

/* state for the screen (UI) */
extern volatile uint8_t en_playing, en_frozen, en_ext;
extern volatile uint8_t en_chord[EN_NPAD];     /* the chord's notes (MIDI), pad voices' targets */
extern volatile uint8_t en_chord_root;         /* the chord's root, MIDI pitch class 0..11 */
extern volatile uint8_t en_chord_n;            /* its distinct tones: 3 or 4 */
extern volatile float en_drift;                /* 0..1: how far to the next chord */
extern volatile float en_pad_level, en_bass_level;
extern volatile float en_acid_level;
extern volatile uint8_t en_acid_len, en_acid_pos;    /* the acid loop's length and step */
extern volatile uint8_t en_acid_off[EN_NSTEP], en_acid_oct[EN_NSTEP];   /* the line's steps: scale steps above the chord, the octave */
extern volatile uint16_t en_acid_slide;        /* the steps that slide into the next */
void en_acid_step(int s, int off, int oct, int gate, int accent, int slide);   /* set a step of the line (the Acid steps page); the line is then the player's, until a new piece */
void en_pluck_step(int s, int rung, int level);   /* set a step of the pluck's line (the Pluck steps page): a rung of the chord's ladder (0 .. 11) and a level (0 rest, 1 soft, 2 note, 3 accent) */
int en_pluck_pack(uint8_t *b12);               /* the line as stored: 16 steps of six bits (12 bytes); 0 when empty */
void en_pluck_unpack(const uint8_t *b12);      /* and back into the engine (a stored piece's frozen line) */
extern volatile uint8_t en_cm_rung[16], en_cm_lvl[16], en_cm_pos;   /* the loop's first sixteen slots: each one's rung and level (0 a rest), and the slot playing */
/* THE PROGRESSION (the Progression page, 0.15.6): eight slots of chords set by hand, stored with the piece in six bytes (EN_PRG_LEN):
 * bits 3s..3s+2 slot s's chord (0 empty: the chord before goes on; 1..7 the scale's degree I..VII), bits 24+2s..25+2s its bars (1, 2, 4, 8),
 * bit 40 Play (0 the genre's walk, 1 the slots in turn, up to the last one set), bits 41..42 Drift's unit (0 the genre's, 1 bars, 2 seconds) */
#define EN_PRG_LEN 6
#define EN_PRG_N 8
#define EN_PRG_PLAY 40
#define EN_PRG_UNIT 41
static inline int en_prg_get(const uint8_t *b, int bit, int n) { return (int)((b[bit >> 3] | (uint32_t)(bit >> 3 < EN_PRG_LEN - 1 ? b[(bit >> 3) + 1] : 0) << 8) >> (bit & 7) & ((1u << n) - 1u)); }
static inline void en_prg_put(uint8_t *b, int bit, int n, int v)
{
    int k;
    for (k = 0; k < n; k++, bit++)
        b[bit >> 3] = (uint8_t)((b[bit >> 3] & ~(1u << (bit & 7))) | (uint32_t)(v >> k & 1) << (bit & 7));
}
void en_prog(const uint8_t *b6);                /* a piece's progression (as stored) into the engine */
/* THE SLOTS' CHORD TYPES (0.16.6, GitHub issue 2: "set each chord type individually"): three bits a slot, slot s at bits 3s..3s+2; 0 the piece's
 * (the Pad page's Chord, P_CHORD), else an EN_CH_* kind. Stored beside the progression in their own flash object (project.c, OBJ_KINDS). */
#define EN_PRK_LEN 3
void en_prog_kinds(const uint8_t *b3);          /* a piece's slot types into the engine */
void en_prog_capture(uint8_t *b6);              /* the chords heard last (the chord loop, else the last four), as the slots and their bars (Play and the unit kept) */
int en_prog_chord(int deg, int kind, int *pcs);   /* (kind: a slot type, 0 the piece's) the scale degree's chord as the engine plays it (the chord kind, a cadence's raised seventh): its tones */
extern volatile int8_t en_prog_pos;             /* the slot playing (-1: the genre's walk) */
int en_genre_bars(void);                        /* 1: the genre counts its chords in bars (Drift's own unit), 0: in seconds (hypno) */
void en_acid_capture(int s, int note, int accent, int slide);   /* Capture: a note played by hand (MIDI) into step s, as the nearest offset and octave the chord and scale of now give; the step sounds */
void en_pluck_capture(int s, int note);         /* Capture: a note (or a rest, note < 0) into slot s of the pluck's loop; the loop's slot 0 is the next bar's first step */
int en_acid_pack(uint8_t *b18);                /* the line as stored: 16 steps of nine bits (18 bytes) */
void en_acid_unpack(const uint8_t *b18);       /* and back into the engine (a stored piece's frozen line) */
extern volatile uint16_t en_acid_gate, en_acid_acc;  /* its steps that play; those accented */
extern volatile float en_acid_glow;
extern volatile uint8_t en_held;              /* keys held playing the voices (en_note) */
#define EN_NPROF 10                            /* the first core's stages (amb.c render_chunk PT): ticks summed since cleared, and the chunk count last */
extern volatile uint8_t en_bass_c1;            /* 1: the drone and the acid are rendered by the other core */
extern volatile uint8_t en_usb_fixed;          /* 1: the USB audio is rendered at unity gain (the master knob is the speakers' alone) */
extern volatile uint8_t en_fm_dy;              /* 1: the DY voices (human-made DX7 voices) stand in for the thirty DX voices */
void en_fm_set_dy(int on);                     /* sets it, and the sound names (the engine reloads the patch between chunks) */
extern int16_t *en_usb_out;                    /* where en_render writes that second output (stereo 16-bit frames, the USB stream's scale), or NULL for none this render */
extern volatile uint8_t en_chorus_c0;          /* 1: the pad's chorus runs on the first core (it decides, from its waits); */
void en_fm_float_path(int v);                  /* tests: the DX voices' MARK I on float buses (1), or integer (0, as the firmware runs it) */
void en_balance_force(int v);                  /* tests: -1 it decides, 0 / 1 as told */
extern uint32_t (*en_prof_clock)(void);        /* the firmware's tick counter, for them (0: not measured) */
extern volatile uint32_t en_prof[EN_NPROF];
extern volatile uint32_t en_prof_sm[11];     /* the chunks shorter than 256 frames: their nine stages (ticks), their count, their frames (since cleared) */
#ifndef EN_DIAG
#define EN_DIAG 0                              /* 1 (EN_DIAG=1 at build): the diagnostic frame below and its timers inside the stages (0.14.3's hunt for the fixed cost a chunk); off, the status log's first two frames stay */
#endif
#if EN_DIAG
extern volatile uint32_t en_diag[36];        /* the diagnostic frame: fourteen pieces inside the stages (ticks; all chunks, then the short ones), four chunk sizes, four pieces between chunks */
#endif
extern volatile uint32_t en_peak_stage[9], en_peak_total, en_peak_info;   /* the slowest chunk since cleared: its stage times, total (ticks) and info (step, size, moved work, shed, section) */
extern volatile uint8_t en_drum_pos;           /* the step playing (0..15) */
extern volatile uint8_t en_acid_ans;           /* this bar the acid answers (UI) */
int en_acid_preview(int step, int answer);     /* the acid line's note at a step as the call (answer 0) or an answer (P_AC_RESP's value) would play it, -1: a rest */
uint16_t en_lane_mask(int lane, int pat, int dens);   /* a lane of pattern pat as it plays at density dens (50: as written; the screen's preview too) */
extern volatile uint8_t en_lane_src[EN_NLANE]; /* the pattern each lane plays now */
extern volatile uint8_t en_lane_pos[EN_NLANE]; /* each lane's step (its own length: P_LLEN + lane) */
extern volatile float en_drum_glow[EN_NDRUM];
extern volatile uint8_t en_pat_now, en_pat_next;
extern volatile int8_t en_dd_left;             /* drum drift: bars to the change (1: the fill bar), -1 none */
extern volatile uint32_t en_dd_changes, en_dd_mutations;   /* changes made and mutations since start */      /* the pattern playing; the one waiting for the bar */
extern volatile uint8_t en_mod[EN_NLANE][16];   /* a piece's step tricks: ratchet (bits 0-2: off, x2, x3, x4, x6, flam, swell x3, swell x4), push (3-5: n/12 of a step late), level (6-7: normal, ghost, soft, accent) */
extern volatile uint16_t en_pats[EN_NPAT][EN_NLANE];   /* the patterns: bit s, a hit on step s (the UI edits) */
extern volatile uint32_t en_bars;              /* sixteenths played since start (for tests) */
extern volatile float en_arc;                  /* the arc, -1 sparse .. +1 full (times Motion) */
extern volatile uint8_t en_pulse_rest;         /* the pulse is out (a breakdown) */
extern volatile uint8_t en_pad_note[EN_NPAD];  /* the note each voice sings now (MIDI) */
extern volatile float en_pad_amp[EN_NPAD];     /* and how loud */

/* the pure parts, for the tests and the screen */
uint32_t en_euclid(int k, int n, int rot);     /* Bjorklund's pattern, as a bitmask (bit 0 = step 0) */
int en_par_global(int p);                      /* the player's, not a piece's: Tune, MIDI, Theme */
int en_par_now(int p);                         /* the engine's own value of a parameter (what the UI has sent it: the mood's, the JAM page's hand switch) */
int en_par_sticky(int p);                      /* kept across pieces and genres: the player's, and the drum drift's settings */
int en_scale(uint32_t pool, int *steps);       /* the pool's pitch classes (relative), ascending; count */
/* the chord on scale degree deg: its tones (MIDI pitch classes, absolute), 3 or 4 of them; count */
int en_chord_tones(uint32_t pool, int root, int deg, int *pcs);
/* the kinds of chord (P_CHORD): as the scale has it (sevenths on a 7-note scale, else triads); triads;
 * sevenths; ninths (1 3 7 9); sus (1 4 5 b7); dub (a minor 9 shape on each degree, the scale or not);
 * fourths (stacked fourths: an m11 sound) */
enum { EN_CH_AUTO, EN_CH_TRIAD, EN_CH_7TH, EN_CH_9TH, EN_CH_SUS, EN_CH_DUB, EN_CH_4THS, EN_CH_11TH, EN_NCHORD };   /* (11ths: 0.16.6) */
extern const char *const EN_CHORD_NAME[EN_NCHORD];
int en_chord_kind(uint32_t pool, int root, int deg, int kind, int *pcs);   /* en_chord_tones, of a kind */
/* voice leading: new pad notes for the tones, each voice moving as little as possible, all in lo..hi */
void en_voice_lead(const int *from, const int *pcs, int ntones, int *to, int lo, int hi);
const char *en_chord_name(const int *pcs, int n, char *buf);   /* "Em7", "Dsus4", "C" ... */

/* the pieces: recipes for everything but Tune, MIDI out and Theme (the player's), and six drum patterns
 * each. Named by number, 01 .. 10. */
#define EN_NPIECES 10
const char *en_piece_name(int i);
void en_piece(int i, int16_t *par, uint16_t *pool);
/* genres: banks of ten pieces, each with its own recipes and drum patterns (the first, 0, is the original techno and acid
 * set; the others are factory sets, kept in RAM while the power is on). */
#define EN_NGENRE 19
const char *en_genre_name(int g);
void en_genre(int g);                          /* the genre playing: its chords move in its own habits (the first bank keeps the original walk) */
const char *en_piece_name_g(int g, int i);
void en_piece_g(int g, int i, int16_t *par, uint16_t *pool);
void en_piece_pats_g(int g, int i, uint16_t pats[EN_NPAT][EN_NLANE]);
void en_piece_mods_g(int g, int i, uint8_t mod[EN_NLANE][16]);   /* its factory step tricks (en_mod) */
void en_piece_pats(int i, uint16_t pats[EN_NPAT][EN_NLANE]);   /* its factory drum patterns */
