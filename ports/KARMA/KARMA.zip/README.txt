KARMA 3.1.6 for the BBL Mod Swapper

Original by eatyourgreensstudio-dotcom: https://github.com/eatyourgreensstudio-dotcom/karma-fm1
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: KARMA-source.zip on the ports page.
