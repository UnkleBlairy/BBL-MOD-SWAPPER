/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
 * Portions Copyright (C) 2026 Juan Ignacio Antonucci (Juan Jiant): the USB STEMS capture / the half acked first (JIANT FM) */
/* Effects: per-track DIST insert, then sends into three shared buses (chorus, tempo delay, reverb).
 * Stereo dry mix; the chorus and the reverb come back in stereo, the delay in the middle. */
#define DLY_LEN 65536u           /* 1.49 s: 1/4 down to 41 BPM, 1/8 dotted down to 31, 1/4 dotted down to 61 (clamped below) */
#define CHO_LEN 2048u
#include "cloud.c"               /* the CLOUD send effect (Clouds' grains), in mix_block below */
static int16_t dly_buf[DLY_LEN] __attribute__((unused));
static int16_t cho_buf[CHO_LEN] __attribute__((unused));
/* the reverb: two input diffusers, then four delay lines mixed by a Hadamard matrix (a feedback delay
 * network: every echo feeds all four, so it thickens instead of ringing like a comb), damped in the
 * loop, one line slowly modulated (no metallic tone on long tails); left and right take different lines */
#define REV_MOD 12               /* samples the modulated line moves (+-) */
static const uint16_t REV_LINE[4] = {1559, 1931, 2389, 2791};   /* 35..63 ms, coprime */
static const uint16_t REV_AP[2] = {556, 441};
static int16_t rev_line[1559 + 1931 + 2389 + 2791 + REV_MOD + 2];   /* (.bss: the pool is full) */
static int16_t rev_ap[556 + 441] __attribute__((unused));
static struct {
    uint32_t dly_w, cho_w, cho_ph, rev_ph;
    int32_t dly_lp;
    uint16_t line_i[4], ap_i[2];
    int32_t line_lp[4];
} fx;
static volatile uint8_t rev_frz;         /* punch-in FREEZE (punch.c): the reverb holds, no loss, no damping */
static int32_t rev_l[CTL], rev_r[CTL];   /* the reverb's own return of this block (FREEZE plays it) */

/* DIST: low cut -> drive (1x..8x, exponential) -> asymmetric soft clip
 * (a little bias = even harmonics) -> tone low-pass that closes with drive ->
 * make-up gain. State per part (track_t dist_*). */
static void track_dist(track_t *t, int32_t *b, uint32_t n)
{
    int32_t d = t->p[P_DIST], i, g, k, mk, bias = 2400, b0;
    if (!d) {
        t->dist_on = 0;
        return;
    }
    if (!t->dist_on) {                                  /* coming on: no stale high-pass state (a thump) */
        t->dist_on = 1;
        t->dist_hp = b[0];
        t->dist_lp1 = t->dist_lp2 = 0;
    }
    g = 4096 + d * d * 2;                                /* Q12: 1x .. ~9x, gentle at first */
    k = 32000 - d * 95;                                  /* tone: transparent at low drive .. ~3 kHz, Q15 */
    mk = 30000 - d * 120;                                /* make-up */
    b0 = softclip(bias);
    for (i = 0; i < (int32_t)n; i++) {
        int32_t x = b[i], y;
        t->dist_hp += (x - t->dist_hp + 64) >> 7;           /* ~55 Hz low cut: keep the bass out of the clipper */
        x = clamp(x - t->dist_hp, -230000, 230000);         /* (x >> 2) * g fits 32 bits; the clip is flat out there */
        y = softclip(MULQ12R(x, g, 2) + bias) - b0;         /* (as (x >> 2) * g >> 10 in 32 bits: no overflow for loud
                                                             * poly; 3.0.4 after SLOOP 2.8.4: rounded) */
        t->dist_lp1 += mulq15(y - t->dist_lp1, k);         /* two poles: tames the fizz */
        t->dist_lp2 += mulq15(t->dist_lp1 - t->dist_lp2, k);
        b[i] = mulq15(t->dist_lp2, mk);
    }
}

/* master: peak limiter in front of the soft clipper, a 35 ms hold then ~46 ms release (2.6), threshold where tanh is still nearly linear,
 * so chords get quieter instead of crushed. SLOOP 2.6: it looks one block ahead (lim_block): the output is the mix
 * CTL samples late (0.73 ms) and the gain glides over each block to what the loudest sample of it and of the next one
 * needs, so a hot kick or bass is already turned down when it comes. Before, the gain caught up in ~4 samples and the
 * first ones went through the tanh knee at up to 4x: a crackle on the beats with the MASTER up (in headphones most) */
#define LIM_T 18000
typedef struct {
    int32_t dl[CTL], dr[CTL];           /* the mix of the last block (the delay) */
    uint32_t w;                         /* its oldest sample (the next out) */
    int32_t env;                        /* the peak the gain fits under LIM_T (LIM_T: none) */
    int32_t g;                          /* the gain at the end of the last block, Q15 (32768: 1) */
    uint32_t hold;                      /* blocks before the release starts (LIM_HOLD after a peak near env) */
} lim_t;
/* (2.6, a whistle on loud basses) the release waits LIM_HOLD blocks after the last peak near the envelope: a held bass
 * (down to ~29 Hz, a period under 35 ms) keeps one gain, instead of the gain dipping and creeping back at every cycle
 * (a sawtooth at the bass's pitch with a corner at every block: tones around 1.4 kHz and up) */
#define LIM_HOLD 48u
#define LIM_REL 11                      /* the release after the hold: ~46 ms (12 before the hold: ~93 ms; the same loudness) */
static lim_t lim_dac = {.env = LIM_T, .g = 32768}, lim_usb = {.env = LIM_T, .g = 32768};
/* l, r: n (<= CTL) samples in; out: the n samples of CTL before, limited (before the knee) */
static void lim_block(lim_t *s, int32_t *l, int32_t *r, uint32_t n)
{
    uint32_t i, w = s->w;
    int32_t pk = 0, a, g0 = s->g, g1, dg, e = s->env;
    for (i = 0; i < CTL; i++) {                         /* the samples going out now and the ones after them (the
                                                         * rest of the delay, then this block): CTL ahead */
        a = s->dl[i] < 0 ? -s->dl[i] : s->dl[i], pk = a > pk ? a : pk;
        a = s->dr[i] < 0 ? -s->dr[i] : s->dr[i], pk = a > pk ? a : pk;
    }
    for (i = 0; i < n; i++) {
        a = l[i] < 0 ? -l[i] : l[i], pk = a > pk ? a : pk;
        a = r[i] < 0 ? -r[i] : r[i], pk = a > pk ? a : pk;
    }
    if ((int64_t)pk * 17 >= (int64_t)e * 16)           /* a peak within ~0.5 dB of the envelope: the hold again */
        s->hold = LIM_HOLD;
    if (s->hold)
        s->hold--;
    else if (e > LIM_T)                                 /* the release (after the hold), a block at a time */
        e -= (int32_t)((((int64_t)(e - LIM_T) * (int32_t)n) >> LIM_REL) + 1);
    if (e < LIM_T)
        e = LIM_T;
    if (pk > e)
        e = pk, s->hold = LIM_HOLD;
    s->env = e;
    g1 = e > LIM_T ? (int32_t)(((uint32_t)LIM_T << 15) / (uint32_t)e) : 32768;
    s->g = g1;
    dg = (g1 - g0) / (int32_t)(n ? n : 1u);             /* (towards 0: the gain never above both ends' bound) */
    for (i = 0; i < n; i++) {
        int32_t xl = s->dl[w], xr = s->dr[w], g = g0 + dg * (int32_t)(i + 1u);
        s->dl[w] = l[i], s->dr[w] = r[i];
        w = (w + 1u) & (CTL - 1u);
        if (i + 1u == n)
            g = g1;
        if (g < 32768) {                                /* (64-bit: |x| may be far above Q15. 2.6 fix: x >> 4 first cut
                                                         * the limited signal to 12 bits, a whistle on loud basses) */
            xl = (int32_t)(((int64_t)xl * g) >> 15);
            xr = (int32_t)(((int64_t)xr * g) >> 15);
        }
        l[i] = xl, r[i] = xr;
    }
    s->w = w;
}
static volatile uint8_t fx_lowcut;     /* settings: 12 dB/oct ~110 Hz for the small speaker */
static int32_t lc_l1, lc_l2, lc_r1, lc_r2, dc_l, dc_r, dce_l, dce_r;

/* DC blocker (~2 Hz), always on: a leaky integrator of the input (Q6 state) subtracted from it.
 * The >> 12 step keeps its remainder (error feedback, 0..4095) and adds it to the next one, so no
 * part of the step is lost: the state follows the input exactly, down to 0 after the sound stops.
 * (It was rounded, and a rounded step of (x - dc) / 4096 stops moving at |x - dc| < 2048: a
 * constant offset of up to +-31 stayed at the output after silence.) */
static inline int32_t dc_block(int32_t x, int32_t *dc, int32_t *err)
{
    int32_t e = (x << 6) - *dc + *err, d = e >> 12;
    *err = e - (d << 12);
    *dc += d;
    return x - ((*dc + 32) >> 6);
}

static int32_t lce[4];
static inline int32_t lowcut1(int32_t x, int32_t *lc, int32_t *err)   /* x minus its one-pole low-pass */
{
    int32_t e = x - *lc + *err, d = e >> 6;
    *err = e - (d << 6);
    *lc += d;
    return x - *lc;
}

/* the output stage: linear up to KNEE (a clean low end: no tanh harmonics on a loud sine), above it
 * a tanh knee with the same slope at the joint, to full scale */
#define KNEE 16384
static inline int32_t knee(int32_t x)
{
    int32_t a = x < 0 ? -x : x;
    if (a <= KNEE)
        return x;
    a = KNEE + (softclip((a - KNEE) * 2) >> 1);
    return x < 0 ? -a : a;
}

/* the USB audio input at full level (menu USB AUDIO = FULL): the same output stage with its own state,
 * fed as if MASTER were all the way up, so the recording level does not follow the knob. The DAC path
 * (master_pre, lim_dac) is untouched. audio.c sets usb_full_now for a render while the computer records. */
static uint8_t usb_full;                 /* menu USB AUDIO: 0 MASTER (follows the knob), 1 FULL (panel.c lights_word) */
static uint8_t usb_full_now;             /* this render fills usb_out (audio.c) */
static int32_t usb_out[2u * CTL];
/* the visualiser's input (audio.c fills the scope with it): the mix as if MASTER were all the way up, so the
 * picture does not follow the volume knob, even at 0 (2.4). The same soft knee as the output, no limiter state */
static int16_t vis_tap[2u * CTL];
static struct { int32_t dc[2], dce[2], lc[4], lce[4]; } uo;
static void master_pre_usb(int32_t *l, int32_t *r)      /* (USB AUDIO = FULL: its own state) */
{
    *l = dc_block(*l, &uo.dc[0], &uo.dce[0]);
    *r = dc_block(*r, &uo.dc[1], &uo.dce[1]);
    if (fx_lowcut) {
        *l = lowcut1(*l, &uo.lc[0], &uo.lce[0]);
        *l = lowcut1(*l, &uo.lc[1], &uo.lce[1]);
        *r = lowcut1(*r, &uo.lc[2], &uo.lce[2]);
        *r = lowcut1(*r, &uo.lc[3], &uo.lce[3]);
    }
}

/* the output stage before the limiter: the DC blocker, the low cut */
static inline void master_pre(int32_t *l, int32_t *r)
{
    *l = dc_block(*l, &dc_l, &dce_l);
    *r = dc_block(*r, &dc_r, &dce_r);
    if (fx_lowcut) {                  /* two one-pole high-passes, error feedback as dc_block (the */
        *l = lowcut1(*l, &lc_l1, &lce[0]);          /* rounded step stopped at |x - lc| < 32: an offset) */
        *l = lowcut1(*l, &lc_l2, &lce[1]);
        *r = lowcut1(*r, &lc_r1, &lce[2]);
        *r = lowcut1(*r, &lc_r2, &lce[3]);
    }
}



static uint32_t delay_samples(void)
{
    uint32_t s = dly_samples((uint32_t)song.g[G_DTIME]);
    return s < 16u ? 16u : s >= DLY_LEN ? DLY_LEN - 1u : s;
}

/* process the three buses for one block; sends in, wet out (stereo). The LFOs (chorus, reverb line)
 * are computed per block and ramped: no sine per sample */
#define HALF0(v) ((v) >= 0 ? (v) >> 1 : -(-(v) >> 1))   /* v / 2 towards zero */
static void fx_buses(const int32_t *cho_in, const int32_t *dly_in, const int32_t *rev_in, int32_t *wet_l,
                     int32_t *wet_r, uint32_t n)
{
    uint32_t i, k, dl = delay_samples();
    int32_t fb = song.g[G_DFDBK] * 230, col = 2000 + song.g[G_DCOLOR] * 240;
    if (thr_dly && fb < 89 * 230)                       /* ECHO THROW: FDBK at least 70 %, gliding with it (2.6) */
        fb += ((89 * 230 - fb) * thr_dly) >> 15;
    int32_t dmix = song.g[G_DMIX] * 258;
    int32_t g = 17000 + song.g[G_RSIZE] * 104, lpk = 32767 - song.g[G_RDAMP] * 200;   /* loop gain (RT60 ~0.4..4 s), damping */
    int32_t frnd = rev_frz ? 128 : 0;                  /* FREEZE: what is in the lines stays there (below: no
                                                         * loss, rounded to nearest; 0: as always, bit for bit) */
    int32_t cdepth = song.g[G_CDEPTH] * 6;
    int32_t ca0, ca1, cb0, cb1, ma, mb, dca, dcb;
    const uint32_t L0 = REV_LINE[0] + REV_MOD + 2u, B1 = L0, B2 = B1 + REV_LINE[1], B3 = B2 + REV_LINE[2];
    {   /* the chorus' two read points (Q8 samples back) and line 0's extra length, at both ends of the block */
        int32_t s0 = osc_sine(fx.cho_ph), s1, m0 = osc_sine(fx.rev_ph), m1;
        fx.cho_ph += LFO_INC[song.g[G_CRATE] & 127];
        fx.rev_ph += LFO_INC[30];
        s1 = osc_sine(fx.cho_ph);
        m1 = osc_sine(fx.rev_ph);
        ca0 = (400 << 8) + ((s0 + 32768) * cdepth >> 8), ca1 = (400 << 8) + ((s1 + 32768) * cdepth >> 8);
        cb0 = (400 << 8) + ((32767 - s0) * cdepth >> 8), cb1 = (400 << 8) + ((32767 - s1) * cdepth >> 8);
        ma = (REV_MOD << 8) + ((m0 * REV_MOD) >> 7), mb = (REV_MOD << 8) + ((m1 * REV_MOD) >> 7);
        dca = (ca1 - ca0) >> CTL_LOG2, dcb = (cb1 - cb0) >> CTL_LOG2;
    }
    for (i = 0; i < n; i++) {
        int32_t yl, yr, x, a, o0, o1, o2, o3;
        /* chorus: two modulated short delays, 5..15 ms, the LFO half a turn apart: left and right move apart */
        cho_buf[fx.cho_w & (CHO_LEN - 1u)] = (int16_t)clamp(cho_in[i] >> 1, -32768, 32767);
        {
            int32_t r0 = ca0 + dca * (int32_t)i, r1 = cb0 + dcb * (int32_t)i;
            uint32_t i0 = (uint32_t)r0 >> 8, i1 = (uint32_t)r1 >> 8;
            int32_t c0 = cho_buf[(fx.cho_w - i0) & (CHO_LEN - 1u)], c1 = cho_buf[(fx.cho_w - i0 - 1u) & (CHO_LEN - 1u)];
            int32_t d0 = cho_buf[(fx.cho_w - i1) & (CHO_LEN - 1u)], d1 = cho_buf[(fx.cho_w - i1 - 1u) & (CHO_LEN - 1u)];
            yl = (c0 + (((c1 - c0) * (r0 & 255)) >> 8)) << 1;
            yr = (d0 + (((d1 - d0) * (r1 & 255)) >> 8)) << 1;
        }
        fx.cho_w++;
        /* delay with a low-passed feedback (in the middle) */
        x = dly_buf[(fx.dly_w - dl) & (DLY_LEN - 1u)];
        fx.dly_lp += mulq15(x - fx.dly_lp, col);
        dly_buf[fx.dly_w & (DLY_LEN - 1u)] =
            (int16_t)clamp((dly_in[i] >> 1) + mulq15(fx.dly_lp, fb), -32768, 32767);
        fx.dly_w++;
        x = mulq15(x << 1, dmix);
        yl += x;
        yr += x;
        /* reverb: two diffusers, then the four lines */
        a = mulq15(rev_in[i], 13000);
        {
            int16_t *c = rev_ap;
            for (k = 0; k < 2u; k++) {
                int32_t b = c[fx.ap_i[k]], v = a + (b >> 1);
                c[fx.ap_i[k]] = (int16_t)clamp(v, -32768, 32767);
                a = b - (v >> 1);
                if (++fx.ap_i[k] >= REV_AP[k])
                    fx.ap_i[k] = 0;
                c += REV_AP[k];
            }
        }
        {
            int16_t *c = rev_line;
            int32_t s0, s1, d0, d1, r = ma + (((mb - ma) * (int32_t)i) >> CTL_LOG2);   /* (between the two: never below 0) */
            uint32_t ri = fx.line_i[0] + ((uint32_t)r >> 8), rj;
            if (ri >= L0)                                   /* (the oldest sample is at line_i: reading */
                ri -= L0;                                   /* past it shortens line 0 by 0..2 REV_MOD) */
            rj = ri + 1u >= L0 ? 0u : ri + 1u;
            o0 = c[ri] + (((c[rj] - c[ri]) * (r & 255) + frnd) >> 8);
            o1 = c[B1 + fx.line_i[1]];
            o2 = c[B2 + fx.line_i[2]];
            o3 = c[B3 + fx.line_i[3]];
            s0 = o0 + o1, d0 = o0 - o1, s1 = o2 + o3, d1 = o2 - o3;   /* Hadamard / 2: each feeds all four */
            if (!frnd) {
                fx.line_lp[0] += mulq15(((s0 + s1) >> 1) - fx.line_lp[0], lpk);
                fx.line_lp[1] += mulq15(((d0 + d1) >> 1) - fx.line_lp[1], lpk);
                fx.line_lp[2] += mulq15(((s0 - s1) >> 1) - fx.line_lp[2], lpk);
                fx.line_lp[3] += mulq15(((d0 - d1) >> 1) - fx.line_lp[3], lpk);
                c[fx.line_i[0]] = (int16_t)clamp(mulq15(fx.line_lp[0], g) + a, -32768, 32767);
                c[B1 + fx.line_i[1]] = (int16_t)clamp(mulq15(fx.line_lp[1], g) - a, -32768, 32767);
                c[B2 + fx.line_i[2]] = (int16_t)clamp(mulq15(fx.line_lp[2], g) + a, -32768, 32767);
                c[B3 + fx.line_i[3]] = (int16_t)clamp(mulq15(fx.line_lp[3], g) - a, -32768, 32767);
            } else {                                    /* FREEZE: a loop gain of exactly 1, so no rounding that
                                                         * leans one way (a DC that would grow while held): the
                                                         * halves towards zero, no damping or gain multiply */
                fx.line_lp[0] = HALF0(s0 + s1), fx.line_lp[1] = HALF0(d0 + d1);
                fx.line_lp[2] = HALF0(s0 - s1), fx.line_lp[3] = HALF0(d0 - d1);
                c[fx.line_i[0]] = (int16_t)clamp(fx.line_lp[0] + a, -32768, 32767);
                c[B1 + fx.line_i[1]] = (int16_t)clamp(fx.line_lp[1] - a, -32768, 32767);
                c[B2 + fx.line_i[2]] = (int16_t)clamp(fx.line_lp[2] + a, -32768, 32767);
                c[B3 + fx.line_i[3]] = (int16_t)clamp(fx.line_lp[3] - a, -32768, 32767);
            }
            if (++fx.line_i[0] >= L0) fx.line_i[0] = 0;
            if (++fx.line_i[1] >= REV_LINE[1]) fx.line_i[1] = 0;
            if (++fx.line_i[2] >= REV_LINE[2]) fx.line_i[2] = 0;
            if (++fx.line_i[3] >= REV_LINE[3]) fx.line_i[3] = 0;
        }
        wet_l[i] = yl + o0 + o2;
        wet_r[i] = yr + o1 - o3;
        rev_l[i] = o0 + o2;
        rev_r[i] = o1 - o3;
    }
}

/* one block of the whole mix (shared with tests/hostsim.c): events -> each part
 * -> dist -> SLICER -> level / pan / sends -> drums (-> SLICER) -> buses -> master; out: stereo Q15 */
static void events_block(uint32_t n);                    /* seq.c */
static int32_t send_c[CTL], send_d[CTL], send_r[CTL], wet_l[CTL], wet_r[CTL], mix_l[CTL], mix_r[CTL], part_buf[CTL];

/* ---- mute / solo: a track that goes silent fades out over ~6 ms (and back in) */
#define MUTE_STEP 4096                                  /* Q15 per block: 8 blocks */
static int32_t gain_next(track_t *t)                    /* the track's mute gain at the end of this block */
{
    int32_t to = trk_silent(t) ? 32767 : 0, a = t->att;
    t->att = a < to ? (to - a > MUTE_STEP ? a + MUTE_STEP : to) : (a - to > MUTE_STEP ? a - MUTE_STEP : to);
    return 32767 - t->att;
}

/* ---- DUCK: every kick (the drum track's KICK / KICK 2) dips the synth parts, which come back over an
 * eighth note: depth G_DUCK, the curve (1 - t / T)^2. drum_on sets drums.kick. */
static struct {
    uint32_t t;                                         /* units since the kick */
    int32_t g0, g1;                                     /* the parts' gain at the block start, end (Q15) */
} duck = {0xFFFFFFFFu, 32767, 32767};

static void duck_block(uint32_t adv)
{
    int32_t depth = song.g[G_DUCK] * 258, x;
    uint32_t len = BEAT_U / 2u;
    duck.g0 = duck.g1;
    if (drums.kick) {
        drums.kick = 0;
        duck.t = 0;
    }
    if (!depth || duck.t >= len) {
        duck.g1 = 32767;
        return;
    }
    x = 32767 - (int32_t)((duck.t << 10) / (len >> 5));      /* 1 - t / T, Q15 (t < len < 2^21) */
    if (x < 0)
        x = 0;
    duck.g1 = 32767 - mulq15(depth, mulq15(x, x));
    duck.t = duck.t + adv < duck.t ? 0xFFFFFFFFu : duck.t + adv;
}

/* ---- the DJ filter: v < 0 a low-pass closing, > 0 a high-pass opening, 0 off. The cutoff glides
 * to the knob (no zipper); at 0 it opens fully, then the filter is bypassed. On the master (G_FILT)
 * and, SLOOP 2.4, on each track (P_TFLT: a synth part's mono signal, the drum track's left, right,
 * reverb send and, 2.5, delay send) */
typedef struct {
    int32_t cut;                                        /* now, 0..127 << 8 (CUTOFF_HZ index) */
    int8_t mode;                                        /* -1 LP, 1 HP, 0 off */
    uint8_t seed;                                       /* (2.6) bit per channel: the LP's state from its next sample */
    int32_t z[4][2];                                    /* the SVF states, per channel */
} djf_t;
static djf_t djf, tflt[NTRK];

/* the knob v -> this block's coefficients in *c; 0 = bypassed (nothing to do) */
static int djf_block(djf_t *f, int32_t v, tsvf_t *c)
{
    int32_t to;
    if (v < 0 && f->mode >= 0) {                        /* (switching side: from open) */
        f->mode = -1;
        f->cut = 127 << 8;
        memset(f->z, 0, sizeof f->z);
        f->seed = 15;                                   /* (2.6) the low-pass starts where the signal is: from rest
                                                         * its output began at 0 under a sounding note (a click) */
    } else if (v > 0 && f->mode <= 0) {
        f->mode = 1;
        f->cut = 0;
        memset(f->z, 0, sizeof f->z);
    }
    if (!f->mode)
        return 0;
    to = f->mode < 0 ? (v < 0 ? (127 << 8) + v * 90 * 4 : 127 << 8) : (v > 0 ? v * 90 * 4 : 0);
    f->cut += clamp(to - f->cut, -384, 384);            /* ~1.5 index a block */
    if (!v && f->cut == to) {
        f->mode = 0;                                    /* fully open again: off */
        return 0;
    }
    tsvf_coef(c, f->cut, 40);
    return 1;
}
/* n samples of channel ch through the filter (x within +-140000) */
static void djf_run(djf_t *f, const tsvf_t *c, int32_t *b, uint32_t n, uint32_t ch)
{
    uint32_t i;
    int32_t *z = f->z[ch];
    if ((f->seed >> ch) & 1u) {
        f->seed &= (uint8_t)~(1u << ch);
        if (f->mode < 0 && n) {
            z[0] = 0;                                   /* at rest on this input: the output is it (DC: exact) */
            z[1] = clamp(b[0], -140000, 140000);
        }
    }
    for (i = 0; i < n; i++) {
        int32_t x = clamp(b[i], -140000, 140000), y = tsvf_lp(c, x, &z[0], &z[1]);
        b[i] = f->mode < 0 ? y : x - y;
    }
}
/* a track's filter on a signal at 4x its level (b >> 2 into the filter's range, back << 2) */
static void tflt_run(djf_t *f, const tsvf_t *c, int32_t *b, uint32_t n, uint32_t ch)
{
    uint32_t i;
    for (i = 0; i < n; i++)
        b[i] >>= 2;
    djf_run(f, c, b, n, ch);
    for (i = 0; i < n; i++)
        b[i] <<= 2;
}

/* INSERT (SLOOP 2.6, after Felucca 1.5 by Leo Kuroshita, Discussions #78 and #177): one effect per track, after DIST
 * and before the SLICER, with a dry / wet MIX. TYPE (P_ITYPE, N_ITYPE; stored, append-only) and its three values A B C
 * (P_IA .. P_IC, what they mean: params.c ins_desc):
 *   SOFT HARD FOLD FUZZ  DRIVE (1x .. ~13x, squared), TONE (two one-pole low-passes at F_CUTOFF), LEVEL (F_DB, as the
 *                        track's LEVEL: 112 is 0 dB). A slow low cut in front (~27 Hz), a DC blocker after (FUZZ is
 *                        lopsided). SOFT tanh, HARD a flat clip at a voice's level, FOLD a triangle folder (the wave
 *                        reflected at +-16384: every fold more harmonics), FUZZ a hard top and a soft, halved bottom;
 *   CRUSH                BITS (1 .. 16, of a voice's full scale), RATE (a held sample, 689 Hz .. 44.1 kHz, INS_HOLD:
 *                        aliasing as the old samplers), LPF (two one-pole low-passes at F_CUTOFF after them);
 *   PHASR                RATE (F_LFOHZ), DEPTH (the sweep around ~850 Hz: 0 still .. the whole 150 Hz .. 4.8 kHz),
 *                        FDBK (0 .. 0.7): four all-pass stages, mono, per track;
 *   FLANG CHOR           RATE, DEPTH, FDBK: a 256-sample line per track (5.8 ms); FLANG swept 0.25 .. 5 ms (a squared
 *                        triangle), feedback 0 .. 0.85; CHOR a sine around 3.2 ms (+-2.3 ms at DEPTH 127), feedback
 *                        0 .. 0.4. A DC blocker on the swept copy (a clipped loud input is lopsided).
 * The swept ones are the pedals': their wet is (dry + swept) / 2, the notches need both, so MIX 100 % is the whole
 * effect and less a lighter one. MIX (P_IMIX) blends dry and wet linearly; MIX 0 or TYPE OFF: the track bit for bit
 * as before (nothing runs). MIX glides (2.9 ms, SL_SLOPE); a TYPE change fades the old one out, clears the state,
 * fades the new one in; so does a start from MIX 0 (no stale line or filter).
 * The drum track (SLOOP): its left, right, reverb send and delay send each through their own state, the same settings
 * (fx.c mix_block). State in RAM (.bss): 580 B a channel; noinline, its own loops */
enum { IT_OFF, IT_SOFT, IT_HARD, IT_FOLD, IT_FUZZ, IT_CRUSH, IT_PHASER, IT_FLANGER, IT_CHORUS, IT_N };
_Static_assert(IT_N == sizeof N_ITYPE / sizeof N_ITYPE[0], "the INSERT's types as params.c names them");
#define IL_LEN 256u                     /* FLANG / CHOR: the line, samples (a power of 2: masked) */
#define PH_ST 4u                        /* PHASR: all-pass stages (two notches, the classic pedal's) */
static const uint8_t INS_HOLD[16] = {64, 48, 40, 32, 24, 20, 16, 12, 10, 8, 6, 5, 4, 3, 2, 1};   /* CRUSH RATE */
/* PHASR: the stages' coefficient over the sweep (Q14), 33 points */
static const int16_t PH_A[33] = {
    -16038, -15998, -15955, -15906, -15853, -15793, -15727, -15653, -15572, -15481, -15381, -15270, -15147, -15012,
    -14862, -14696, -14514, -14313, -14092, -13849, -13582, -13290, -12970, -12621, -12240, -11825, -11375, -10886,
    -10356, -9784, -9166, -8500, -7783,
};
typedef struct {
    int32_t w;                          /* the wet share now, Q15 */
    uint8_t type;                       /* the type running */
    uint8_t cnt;                        /* CRUSH: samples left of the held one */
    uint16_t wp;                        /* FLANG / CHOR: the line's next write */
    uint32_t ph;                        /* the sweep's phase */
    int32_t hp, lp1, lp2, dc, hold;     /* low cut (Q8), the two low-passes, DC blocker (Q8), CRUSH's held sample */
    int32_t px[PH_ST], py[PH_ST], fb;   /* PHASR: each stage's last input and output, the fed back */
    int16_t line[IL_LEN];               /* FLANG / CHOR, at a quarter (headroom) */
} ins_t;
/* (in .bss, not the pool: tools/build.py keeps 8 KiB of the pool spare; RAM has room) */
static ins_t ins[NPART + 4u];                    /* the parts; the drum track's L, R, REV, DLY */

static inline int32_t ins_mixq(int32_t m) { return m >= 127 ? 32768 : m <= 0 ? 0 : m * 258; }   /* MIX -> Q15 */
static inline int32_t ins_mix(int32_t x, int32_t y, int32_t w) { return w == 32768 ? y : x + mulq16(y - x, (uint32_t)w << 1); }
static inline uint32_t ins_tri(uint32_t q) { uint32_t t = q >> 16; return t < 32768u ? t << 1 : (65535u - t) << 1; }
/* the one-pole low-pass (topology-preserving) coefficient of cutoff index c, Q16: G = g / (1 + g), g = tan(pi fc / FS) */
static int32_t ins_lpk(int32_t c)
{
    uint32_t g = SVF_G[clamp(c, 0, 127)];
    return (int32_t)((g << 16) / (4096u + g));
}
/* the drives' and CRUSH's shape of v (a voice's full scale 32768; v already through DRIVE) */
static inline int32_t ins_shape(uint32_t ty, int32_t v, uint32_t sh)
{
    switch (ty) {
    case IT_SOFT:
        return softclip(v);
    case IT_HARD:
        return clamp(v, -24000, 24000);
    case IT_FOLD: {
        int32_t u = (int32_t)((uint32_t)(v + 16384) & 0xFFFFu) - 32768;   /* a triangle of period 65536: +-16384 */
        u = 16384 - (u < 0 ? -u : u);
        return u + (u >> 1);                            /* x 1.5 (no divide) */
    }
    case IT_FUZZ:
        return v > 0 ? (v > 20000 ? 20000 : v) : softclip(v) >> 1;
    case IT_CRUSH:                                      /* sh: 16 - BITS; to the nearest step */
        return sh ? ((v + (1 << (sh - 1u))) >> sh) << sh : v;
    default:
        return v;
    }
}
static inline uint32_t ins_bits_sh(int32_t a) { return 15u - (uint32_t)(clamp(a, 0, 127) >> 3); }   /* BITS 1..16 */

/* SOFT .. FUZZ: low cut -> DRIVE -> shape -> TONE -> LEVEL -> DC blocker; CRUSH: held sample -> bits -> LPF. The state
 * in locals for the block (b may alias it as far as the compiler knows: no load / store a sample), written back */
static __attribute__((noinline)) void ins_drive(ins_t *s, const int16_t *p, int32_t *b, uint32_t n, int32_t tw)
{
    uint32_t i, ty = s->type, sh = ins_bits_sh(p[P_IA]);
    uint32_t hold = INS_HOLD[clamp(p[P_IB], 0, 127) >> 3];
    int32_t a = clamp(p[P_IA], 0, 127), g = 4096 + a * a * 3;   /* DRIVE, Q12: 1x .. 12.8x, gentle at first */
    int32_t w = s->w, lp1 = s->lp1, lp2 = s->lp2, x, y, v;
    if (ty == IT_CRUSH) {
        uint32_t k = (uint32_t)ins_lpk(p[P_IC]), cnt = s->cnt;
        int32_t hd = s->hold;
        for (i = 0; i < n; i++) {
            x = b[i];
            w += clamp(tw - w, -SL_SLOPE, SL_SLOPE);
            if (!cnt) {
                hd = ins_shape(IT_CRUSH, clamp(x, -262144, 262143), sh);
                cnt = hold;
            }
            cnt--;
            y = hd << 4;                                /* (x16: the low cutoffs' rounding leaves no offset) */
            v = mulq16(y - lp1, k);                     /* LPF: two one-pole low-passes */
            y = v + lp1;
            lp1 = y + v;
            v = mulq16(y - lp2, k);
            y = v + lp2;
            lp2 = y + v;
            b[i] = ins_mix(x, (y + 8) >> 4, w);
        }
        s->cnt = (uint8_t)cnt;
        s->hold = hd;
    } else {
        uint32_t k = (uint32_t)ins_lpk(p[P_IB]);
        int32_t lvl = LEVEL_Q12[p[P_IC] & 127], hp = s->hp, dc = s->dc;
        for (i = 0; i < n; i++) {
            x = b[i];
            w += clamp(tw - w, -SL_SLOPE, SL_SLOPE);
            hp += ((x << 8) - hp) >> 8;                 /* ~27 Hz low cut (Q8: no offset left by the rounding) */
            v = clamp(x - (hp >> 8), -230000, 230000);
            y = ins_shape(ty, ((v >> 3) * g) >> 9, 0) << 4;   /* (>> 3 first: 32 bits; x16 as CRUSH) */
            v = mulq16(y - lp1, k);                     /* TONE: two one-pole low-passes */
            y = v + lp1;
            lp1 = y + v;
            v = mulq16(y - lp2, k);
            y = v + lp2;
            lp2 = y + v;
            y = (((y + 8) >> 4) * lvl) >> 12;           /* LEVEL */
            dc += ((y << 8) - dc) >> 9;                 /* DC blocker, ~14 Hz (FUZZ's lopsided halves) */
            b[i] = ins_mix(x, y - (dc >> 8), w);
        }
        s->hp = hp;
        s->dc = dc;
    }
    s->w = w;
    s->lp1 = lp1;
    s->lp2 = lp2;
}

/* PHASR, FLANG, CHOR: the sweep at RATE (one LFO per state), DEPTH, FDBK; the state in locals for the block */
static __attribute__((noinline)) void ins_swept(ins_t *s, const int16_t *p, int32_t *b, uint32_t n, int32_t tw)
{
    uint32_t i, inc = LFO_INC[clamp(p[P_IA], 0, 127)] / CTL, dep = (uint32_t)clamp(p[P_IB], 0, 127);
    int32_t c = clamp(p[P_IC], 0, 127), w = s->w, dc = s->dc;
    if (s->type == IT_PHASER) {                         /* the coefficients a block at a time (at its middle) */
        uint32_t tr = ins_tri(s->ph + (n >> 1) * inc), q = 32768u + (uint32_t)(((int32_t)tr - 32768) * (int32_t)dep / 127);
        int32_t a = PH_A[q >> 11] + (((PH_A[(q >> 11) + 1u] - PH_A[q >> 11]) * (int32_t)(q & 2047u)) >> 11);
        int32_t fbk = c * 180, fb = s->fb;              /* 0 .. 0.7, Q15 */
        int32_t x0 = s->px[0], x1 = s->px[1], x2 = s->px[2], x3 = s->px[3];
        int32_t y0 = s->py[0], y1 = s->py[1], y2 = s->py[2], y3 = s->py[3];
        _Static_assert(PH_ST == 4u, "ins_swept: four all-pass stages");
        for (i = 0; i < n; i++) {
            int32_t x = b[i], u = clamp((x + 4) >> 3, -16383, 16383) + ((fb * fbk + 16384) >> 15), y;
            w += clamp(tw - w, -SL_SLOPE, SL_SLOPE);
            /* y = a (u - y1) + u1, four times */
            y = clamp(x0 + ((a * (u - y0) + 8192) >> 14), -65535, 65535), x0 = u, y0 = y, u = y;
            y = clamp(x1 + ((a * (u - y1) + 8192) >> 14), -65535, 65535), x1 = u, y1 = y, u = y;
            y = clamp(x2 + ((a * (u - y2) + 8192) >> 14), -65535, 65535), x2 = u, y2 = y, u = y;
            y = clamp(x3 + ((a * (u - y3) + 8192) >> 14), -65535, 65535), x3 = u, y3 = y;
            fb = clamp(y, -32767, 32767);
            y <<= 2;                                    /* (y: at an eighth) */
            dc += ((y << 8) - dc) >> 9;                 /* DC blocker, ~14 Hz (a clipped loud input is lopsided) */
            b[i] = ins_mix(x, (x >> 1) + y - (dc >> 8), w);   /* (dry + all-passed) / 2 */
        }
        s->px[0] = x0, s->px[1] = x1, s->px[2] = x2, s->px[3] = x3;
        s->py[0] = y0, s->py[1] = y1, s->py[2] = y2, s->py[3] = y3;
        s->fb = fb;
        s->ph += n * inc;
    } else {
        int32_t chorus = s->type == IT_CHORUS, fbk = c * (chorus ? 103 : 219);   /* 0 .. 0.4 / 0 .. 0.85, Q15 */
        uint32_t dq = dep * 516u, ph = s->ph, wp = s->wp; /* DEPTH, Q16 */
        int16_t *line = s->line;
        for (i = 0; i < n; i++, ph += inc) {
            int32_t x = b[i], r0, r1, v, fr;
            uint32_t d;                                 /* the delay, Q16 samples */
            w += clamp(tw - w, -SL_SLOPE, SL_SLOPE);
            if (chorus) {
                d = (uint32_t)((140 << 16) + ((osc_sine(ph) * (int32_t)dep * 50) >> 5));   /* 3.2 +- 2.3 ms */
            } else {
                uint32_t tr = ins_tri(ph), sw = (tr * tr) >> 16;   /* longer near the short end */
                d = (11u << 16) + 209u * (((sw >> 1) * dq) >> 15);  /* 0.25 .. 5 ms */
            }
            r0 = (int32_t)(wp - (d >> 16)) & (int32_t)(IL_LEN - 1u);
            r1 = (r0 - 1) & (int32_t)(IL_LEN - 1u);
            fr = (int32_t)((d >> 1) & 0x7FFFu);
            v = line[r0] + (((line[r1] - line[r0]) * fr) >> 15);
            line[wp] = (int16_t)clamp((x >> 2) + softclip(mulq15(v, fbk)), -32767, 32767);
            wp = (wp + 1u) & (IL_LEN - 1u);
            v <<= 1;                                    /* (v: at a quarter) */
            dc += ((v << 8) - dc) >> 9;                 /* DC blocker (the line's clip on a loud lopsided wave) */
            b[i] = ins_mix(x, (x >> 1) + v - (dc >> 8), w);   /* (dry + delayed) / 2 */
        }
        s->ph = ph;
        s->wp = (uint16_t)wp;
    }
    s->w = w;
    s->dc = dc;
}

/* the INSERT of the settings p on one channel b through state s: 1 while it runs (or fades out); 0: dry, bit for bit */
static __attribute__((noinline)) int ins_run(ins_t *s, const int16_t *p, int32_t *b, uint32_t n)
{
    int32_t ty = clamp(p[P_ITYPE], 0, IT_N - 1), tw;
    if (s->type != ty && !s->w)                         /* faded out: the new type from rest */
        s->type = (uint8_t)ty;
    tw = s->type == ty && ty ? ins_mixq(p[P_IMIX]) : 0;
    if (!s->w) {
        if (!tw)
            return 0;                                   /* dry: bit for bit */
        memset(s, 0, sizeof *s);                        /* starting: no stale line or filter */
        s->type = (uint8_t)ty;
    }
    if (s->type >= IT_PHASER)
        ins_swept(s, p, b, n, tw);
    else
        ins_drive(s, p, b, n, tw);
    return s->w != 0;
}
/* a part's INSERT on its block b (mix_part): nothing while TYPE is OFF or MIX is 0 and faded */
static void track_insert(track_t *t, int32_t *b, uint32_t n)
{
    t->ins_run = (uint8_t)ins_run(&ins[(uint32_t)(t - trk) % NPART], t->p, b, n);
}
/* the INSERT at rest at once (mix_part: TYPE turned OFF while the part was silent, its fade never ran) */
static __attribute__((noinline)) void ins_rest(track_t *t)
{
    memset(&ins[(uint32_t)(t - trk) % NPART], 0, sizeof(ins_t));
    t->ins_run = 0;
}

/* one synth part into the dry mix and the sends; a part with no voice sounding costs
 * the LFO tick and a cleared buffer only (after the DIST tail has run out) */
/* where a part's sound goes: the mix and the sends, its scratch block (KARMA_DUAL_CORE: CPU1 renders into buses of its
 * own, CPU0 adds them after; one core: the mix's own) */
typedef struct {
    int32_t *l, *r, *c, *d, *v, *cl, *b;
    int16_t *pnew;
} mixbus_t;
static int16_t pnew0[P_COUNT];
static const mixbus_t BUS0 = {mix_l, mix_r, send_c, send_d, send_r, cloud_bus, part_buf, pnew0};
static void mix_part_run(track_t *t, uint32_t n, const mixbus_t *o);
/* (2.6) a preset's fade (voice.c sound_change): the whole part rendered with the sound it had, then the new one back */
static void mix_part_to(track_t *t, uint32_t n, const mixbus_t *o)
{
    if (!(t->pold && t->xf_on && t->xf)) {
        mix_part_run(t, n, o);
        return;
    }
    memcpy(o->pnew, t->p, sizeof pnew0);
    memcpy(t->p, t->p_old, sizeof t->p);
    mix_part_run(t, n, o);
    memcpy(t->p, o->pnew, sizeof pnew0);
}
static void mix_part(track_t *t, uint32_t n) { mix_part_to(t, n, &BUS0); }
#define STEM_Q11 181                            /* a part's stem: (L + R) x 181 / 2048, ~15 dB down (2026-10-28, Ariel: they came
                                                 * hot, the drums clipping, then 12 dB down. 3.0.5, 2026-11-07: PLAITS' SWARM
                                                 * at full scale in a pattern, the four summed to 1.6: white noise in Ariel's
                                                 * mix. 6 dB more was clean but low; 3 dB, Ariel's pick. The FX return with
                                                 * them. ((L + R) is under 2^22 here: x 181 fits 32 bits.) */
#define STEM_OF(x) (((x) * STEM_Q11) >> 11)
#if KARMA_DUAL_CORE
/* CPU1's job (2026-10-28, Ariel: a busy section overloaded one core): tracks 2 and 3 (ELEMENTS, PLAITS) into buses of its
 * own while CPU0 renders track 1 and the drums; CPU0 joins before the effects and adds them. What the two share is read
 * only, or the random numbers (a race there only changes which random number comes) */
#ifndef KARMA_CPU1_HEX                                  /* (3.1.5) the HEX voices on CPU1 again (3.1.3's, off in 3.1.4: tested on
                                                         * Ariel's FM-1, 2026-11-15, alone they are clean: KARMA_CPU1_HEX=1 FX=0
                                                         * played without the distortion, and the drums cost CPU0 65 us, not 200).
                                                         * The effects stay on CPU0: on CPU1 (3.1.3, KARMA_CPU1_FX=1) an FM-1
                                                         * distorted after a while, a clash the host cannot show (ThreadSanitizer
                                                         * finds none): to be found before they go back */
#define KARMA_CPU1_HEX 1
#endif
#ifndef KARMA_CPU1_FX
#define KARMA_CPU1_FX 0
#endif
#ifndef KARMA_FX_WAIT                                   /* (3.1.5 test 8) CPU0 runs the effects (on the last block's sends, as
                                                         * 3.1.3) in its wait for CPU1, not after the join: measured on Ariel's
                                                         * FM-1 (2026-11-17) CPU0 waited ~150 us a block for CPU1, then ran
                                                         * ~150 us of effects. One core does both: nothing shared with CPU1 */
#define KARMA_FX_WAIT 1
#endif
#if KARMA_CPU1_FX
#undef KARMA_FX_WAIT
#define KARMA_FX_WAIT 0
#endif
static int32_t w_l[CTL], w_r[CTL], w_c[CTL], w_d[CTL], w_v[CTL], w_cl[CTL], w_b[CTL];
#if KARMA_CPU1_FX
#define FXP_C w_c                               /* (3.1.3: the last block's sends, between the blocks: fx_prev on CPU1, which
                                                 * reads them before its parts write this block's) */
#define FXP_D w_d
#define FXP_R w_v
#define FXP_CL w_cl
#endif
static int16_t pnew1[P_COUNT];
static const mixbus_t BUS1 = {w_l, w_r, w_c, w_d, w_v, w_cl, w_b, pnew1};
static uint8_t w_fx;                           /* (3.1.3) CPU1 runs the effects this block (fx_prev) */
static uint8_t w_hex;                          /* (3.1.3) CPU1 renders the HEX voices this block (drums.c drums_hex_pre) */
static uint32_t w_n, w_job;                     /* the block's length, the tracks CPU1 renders in it (bit k: track k + 1) */
/* the cores balanced (2026-10-28, Ariel): each part's render time (and the drums') is measured as it runs, a running
 * mean of ticks; after each block CPU0 picks the tracks CPU1 renders next so that the two finish together (the larger
 * of the two loads the least), a change only when it is clearly better (by 1/16: no back and forth) */
static uint32_t w_mask = 6u;                    /* tracks 2 and 3 to start */
#ifndef KARMA_BAL_MEAS
#define KARMA_BAL_MEAS 1                        /* (3.1.5 test 10) the split from the cores' measured finish times */
#endif
#if KARMA_BAL_MEAS
static volatile uint32_t w_end;                 /* (test 10) the tick CPU1's job ended */
#endif
static uint32_t core_cost[NPART + 2];           /* ticks x 8: the three parts, the drums (a running mean: the console's) */
/* (3.0.4, 2026-11-06: Ariel's FM-1 moved its tracks between the cores every second or so: the 8-block mean swung from a
 * held note's cost to nothing between notes, and the split chased it.) The balance now takes each part's PEAK: up at
 * once to a block that cost more, down slowly (~0.4 s, 2^9 blocks), so a part is weighed by what it costs when it
 * sounds; and a split stays at least CORE_DWELL blocks */
/* (3.0.5, 2026-11-07: switching PLAITS presets with a song playing, the split went back and forth six times in five
 * seconds, each move a burst of late blocks and USB dropouts: a part that moves runs slowly a while on the other
 * core (its code not in that core's cache). A preset's set-up made one block cost far more, the split followed it,
 * then came back as the peak fell.) Now the peak rises by a quarter of the gap a block (~90 % in 8 blocks: a held
 * sound's cost, not one block's set-up), a split stays ~0.75 s, and a new one must be better by a quarter */
static uint32_t core_peak[NPART + 2];           /* ticks x 16: the parts, the drums on CPU0, (3.1.3) the HEX voices on CPU1 */
#define CORE_DWELL 1024u                        /* blocks (~0.75 s) */
static uint32_t core_max[NPART + 2];            /* (3.1.3) each one's longest block since the last read (editor command 94) */
/* (3.1.5) a part's peak is kept in CPU1's time: the same engine took CPU0 ~1.8 x as long, measured on an FM-1 (2026-11-15:
 * JUNO SUB 106 ~150 us a block on CPU1, 270 .. 330 on CPU0; ELEMENTS alike), CPU0 running far more code between (the
 * effects, the notes' starts, the mix, USB) and its interrupts. Weighed as one, the split left the heaviest part on
 * CPU0 at its CPU0 price: now a part on CPU0 counts CPU0_NUM / CPU0_DEN of its time, and CPU0's load the inverse */
#define CPU0_NUM 9u
#define CPU0_DEN 16u
static inline void cost_put(uint32_t k, uint32_t ticks)
{
    if (ticks > core_max[k])
        core_max[k] = ticks;
    uint32_t c = ticks << 4, p = core_peak[k];
    core_cost[k] += ticks - (core_cost[k] >> 3);
    core_peak[k] = c >= p ? p + ((c - p) >> 2) : p - ((p - c) >> 9);
}
static inline void cost_put0(uint32_t k, uint32_t ticks)   /* (3.1.5) a part on CPU0: its longest as it ran (editor 94),
                                                            * its peak in CPU1's time */
{
    uint32_t m = core_max[k];
    cost_put(k, ticks * CPU0_NUM / CPU0_DEN);
    core_max[k] = ticks > m ? ticks : m;
}
static int32_t stem_buf[NTRK][CTL];            /* (below: USB STEMS) */
static uint8_t fx_stems;
static int32_t stem_pre1[CTL];                  /* CPU1's own (stem_take's is CPU0's) */
#endif
#if KARMA_DUAL_CORE && KARMA_FX_WAIT
static int32_t fxp_c[CTL], fxp_d[CTL], fxp_r[CTL], fxp_cl[CTL];   /* (test 8) the last block's sends, held for CPU0's wait */
#define FXP_C fxp_c
#define FXP_D fxp_d
#define FXP_R fxp_r
#define FXP_CL fxp_cl
#elif !KARMA_DUAL_CORE || !KARMA_CPU1_FX                /* (3.1.5) the effects on CPU0 (one core, or KARMA_CPU1_FX 0): on this
                                                 * block's sends, as 3.1.2, no block behind and no copy (3.1.4 held them in
                                                 * fxp_*: 512 B of RAM, now each track's ACID GEN and envelope steps) */
#define FXP_C send_c
#define FXP_D send_d
#define FXP_R send_r
#define FXP_CL cloud_bus
#endif
/* (3.1.3) the effects a block behind: the reverb, the delay, the chorus and the CLOUD run on the last block's sends
 * (held in FXP_*) into wet_l / wet_r, which this block adds. Measured on an FM-1, they were 0.08 .. 0.16 ms of CPU0's
 * 0.73 ms block, after the join, with nothing beside them; now CPU1 runs them first in its job (one core: CPU0, the
 * same; the output does not depend on the split). Their return is 32 samples (0.73 ms) later than before */
static uint32_t fxp_n;                          /* the held sends' length (0: none yet) */
static void fx_prev(void)
{
    uint32_t i, n = fxp_n;
    if (!n) {
        for (i = 0; i < CTL; i++)
            wet_l[i] = wet_r[i] = 0;
        return;
    }
    fx_buses(FXP_C, FXP_D, FXP_R, wet_l, wet_r, n);
    cloud_process(FXP_CL, wet_l, wet_r, n);           /* (adds into wet, takes FXP_CL to 0) */
    for (i = n; i < CTL; i++)
        wet_l[i] = wet_r[i] = 0;
}
#if KARMA_DUAL_CORE
/* (3.1.5 test 4) melodee#17: on some FM-1s CPU1 reads SRAM wrong under load (a clean flip of bit 20 or 21, 0 read as
 * 0x00200000). A track shrugs one bad sample off; the reverb, delay and CLOUD feed it back (3.1.3's "distortion after
 * a while"?). Each core re-reads 4 KB that holds zeros once a block and counts what is not (editor ED_STAT) */
#ifndef KARMA_FLIPS
#define KARMA_FLIPS 0   /* (test 4: 0 flips in 3.1e9 reads on Ariel's FM-1; off: it cost ~1 % a core) */
#endif
#if KARMA_FLIPS
#define FLIP_N 1024u
#ifdef FM1_TICKS_PER_US                                /* (the FM-1: in RAM's spare code space; the host: anywhere) */
static volatile uint32_t flip_zero[FLIP_N] __attribute__((unused, aligned(32)));
#else
static volatile uint32_t flip_zero[FLIP_N];
#endif
static volatile uint32_t flip_bad[2], flip_last[2], flip_reads[2];
static __attribute__((noinline)) void flip_probe(uint32_t c)
{
    uint32_t i, v, bad = 0, last = 0;
    for (i = 0; i < FLIP_N; i++)
        if ((v = flip_zero[i]) != 0u)
            bad++, last = v;
    if (bad) {
        flip_bad[c] += bad;
        flip_last[c] = last;
    }
    flip_reads[c] += FLIP_N;
}
#endif
static void core1_parts(void *ctx)
{
    uint32_t i, k, n = w_n, m = w_job, t0;
    (void)ctx;
#if KARMA_FLIPS
    flip_probe(1);
#endif
    t0 = fm1_ticks();
    if (w_fx)                                   /* (3.1.3) the effects on the last block's sends (fx_prev), */
        fx_prev();
    if (w_hex)                                  /* .. the drums' HEX voices (CPU0 mixes them after the join) */
        drums_hex_pre(n);
    if (w_fx | w_hex)
        cost_put(NPART + 1u, fm1_ticks() - t0);   /* (CPU1's own work, for the balance) */
    for (i = 0; i < n; i++)
        w_l[i] = w_r[i] = w_c[i] = w_d[i] = w_v[i] = w_cl[i] = 0;
    for (k = 0; k < NPART; k++)
        if ((m >> k) & 1u) {
            t0 = fm1_ticks();
            if (fx_stems)                       /* USB STEMS: what this part adds to CPU1's bus, as stem_take */
                for (i = 0; i < n; i++)
                    stem_pre1[i] = w_l[i] + w_r[i];
            mix_part_to(&trk[k], n, &BUS1);
            if (fx_stems)
                for (i = 0; i < n; i++)
                    stem_buf[k][i] = STEM_OF(w_l[i] + w_r[i] - stem_pre1[i]);
            cost_put(k, fm1_ticks() - t0);
        }
#if KARMA_BAL_MEAS
    w_end = fm1_ticks();                        /* (test 10) when CPU1's job ended: CPU0 compares it with its own */
#endif
}
#if KARMA_BAL_MEAS
/* (3.1.5 test 10) the split from what the two cores did, not from adding up estimates (test 9 put all three tracks on
 * CPU1: one core running three engines is slower than their costs added). Each block CPU0 notes how much later than
 * itself CPU1 finished (+: CPU0 waited, -: CPU1 sat idle); every CORE_DWELL blocks, if the mean is off by more than
 * BAL_THR, one track moves to the core that finished first, only when its cost (both cores' prices) brings the gap to
 * under 3/4 of what it was, and CPU1 never gets all of them */
static int32_t bal_sum;
static uint32_t bal_n;
static int32_t bal_last;                        /* the last window's mean gap, ticks (editor ED_STAT) */
#ifdef FM1_TICKS_PER_US
#define BAL_THR (40 * FM1_TICKS_PER_US)
#else
#define BAL_THR (40 * 24)
#endif
static void core_balance(void)                  /* CPU0, after the join: the next block's split */
{
    static uint32_t since;
    uint32_t k, best = w_mask, all = (1u << NPART) - 1u;
    int32_t d, ad, bd;
    if (++since < CORE_DWELL || bal_n < 64u)
        return;
    d = bal_sum / (int32_t)bal_n;
    bal_last = d;
    bal_sum = 0;
    bal_n = 0;
    since = 0;
    ad = d < 0 ? -d : d;
    if (ad < BAL_THR)
        return;
    bd = ad;
    for (k = 0; k < NPART; k++) {
        uint32_t bit = 1u << k;
        int32_t c1 = (int32_t)(core_peak[k] >> 4), c = c1 + c1 * (int32_t)CPU0_DEN / (int32_t)CPU0_NUM, nd, an;
        if (d > 0 && (w_mask & bit) && (w_mask & ~bit))
            nd = d - c;                             /* CPU1 slower: this one of its tracks to CPU0 */
        else if (d < 0 && !(w_mask & bit) && (w_mask | bit) != all)
            nd = d + c;                             /* CPU0 slower: this one of its tracks to CPU1 */
        else
            continue;
        an = nd < 0 ? -nd : nd;
        if (an * 4 < ad * 3 && an < bd)
            bd = an, best = w_mask ^ bit;
    }
    w_mask = best;
}
#else
static void core_balance(void)                  /* CPU0, after the join: the next block's split */
{
    static uint32_t since;
    uint32_t m, best = w_mask, k, bl = 0xFFFFFFFFu, cur = 0;
    if (since < CORE_DWELL) {
        since++;
        return;
    }
    for (m = 1; m < (1u << NPART); m++) {               /* (CPU1 always has one: else nothing would measure it) */
        /* (3.1.3) the HEX voices are CPU1's; the drums' mix and the effects run after the join on CPU0 whatever the
         * split, so they weigh on neither side: the split only evens CPU0's parts against CPU1's job */
        uint32_t l0 = 0u, l1 = w_hex ? core_peak[NPART + 1u] : 0u, l;
        for (k = 0; k < NPART; k++)
            if ((m >> k) & 1u)
                l1 += core_peak[k];
            else
                l0 += core_peak[k];
        l0 = l0 * CPU0_DEN / CPU0_NUM + (w_hex ? 0u : core_peak[NPART]);   /* (3.1.5: CPU0's parts at CPU0's price) */
        l = l0 > l1 ? l0 : l1;
        if (m == w_mask)
            cur = l;
        if (l < bl)
            bl = l, best = m;
    }
    if (best != w_mask && bl + (cur >> 2) < cur) {     /* clearly better (by 1/4) */
        w_mask = best;
        since = 0;
    }
}
#endif
#endif
static void mix_part_run(track_t *t, uint32_t n, const mixbus_t *o)
{
    int32_t *b = o->b;
    uint32_t i;
    int32_t g0 = 32767 - t->att, g1;
    if (t->att >= 32767 && trk_silent(t)) {             /* (3.1.3) muted (or another track soloed) all through: nothing
                                                         * heard, nothing computed (measured on an FM-1: muted tracks
                                                         * cost as much as playing ones). Its notes end, silently */
        for (i = 0; i < NVOICE; i++) {
            voice_t *v = &t->v[i];
            v->gate = 0;
            v->env = 0;
            v->stage = 0;
            v->kill = 0;
            v->active = 0;
        }
        t->nmono = 0;
        t->mono_note = 0;
        slicer_track(t, 0, n);                          /* (its step clock runs on) */
        return;
    }
    g1 = gain_next(t);
    if (track_render(t, b, n))
        t->tail = t->p[P_ITYPE] ? 64 : 16, t->ins_xt = 0;              /* blocks of DIST / INSERT state to run out after the last
                                                         * voice (the INSERT's: 46 ms, a flanger's feedback) */
    else if ((!t->tail || !(t->p[P_DIST] | t->p[P_ITYPE]) || !--t->tail) && !slicer_busy(t) &&
             !(t->ins_run && t->ins_res > 16u && t->ins_xt < 255u && ++t->ins_xt)) {   /* (2.6: the INSERT's DC
                                                         * blocker run out first, up to 255 blocks more: no step) */
        slicer_track(t, 0, n);                          /* (the SLICER's step clock runs on) */
        if (t->ins_run && !t->p[P_ITYPE])
            ins_rest(t);                                /* TYPE OFF while silent: no fade-out left for the next note */
        return;
    }
    if (!g0 && !g1) {                                   /* silent (MUTE / SOLO): the voices run, nothing is heard */
        slicer_track(t, 0, n);
        return;
    }
    {
        int32_t lvl = LEVEL_Q12[t->p[P_LEVEL] ? clamp(t->p[P_LEVEL] + t->p[P_ED_FX], 1, 127) : 0], pan = t->p[P_PAN];   /* (+ the sound's trim: 1/2 dB steps, as LEVEL's) */
        int32_t gl = 4096 - (pan > 0 ? pan * 64 : 0), gr = 4096 + (pan < 0 ? pan * 64 : 0);
        int32_t c = t->p[P_CHOR] * 258, d = send_thr(t->p[P_DLY] * 258, thr_dly), r = send_thr(t->p[P_REV] * 258, thr_rev);
        int32_t cs = cloud_send[(uint32_t)(t - trk) % NPART] * 258;   /* the track's send to the CLOUD (cloud.c) */
        int32_t pk = t->peak;
        int32_t xmax = c > d ? c : d;
        int32_t ga = mulq15(g0, duck.g0), gb = mulq15(g1, duck.g1);   /* mute x duck, ramped over the block */
        xmax = 0x7FFFFFFF / ((xmax > r ? xmax : r) | 1);   /* sends: loud chords at a high LEVEL */
        track_dist(t, b, n);
        if (t->p[P_ITYPE] | t->ins_run) {
            track_insert(t, b, n);                      /* the INSERT (2.6): off, nothing */
            t->ins_res = (uint16_t)(b[n - 1u] < 0 ? (-b[n - 1u] > 65535 ? 65535 : -b[n - 1u])
                                                  : (b[n - 1u] > 65535 ? 65535 : b[n - 1u]));   /* (its tail's end) */
        }
        slicer_track(t, b, n);                          /* slicer.c: before the level, pan and sends */
        {
            tsvf_t fc;                                  /* the track's FILTER (P_TFLT), after the SLICER */
            djf_t *f = &tflt[(uint32_t)(t - trk) % NTRK];
            if (djf_block(f, t->p[P_TFLT], &fc))
                tflt_run(f, &fc, b, n, 0);
        }
        int32_t lvl0 = t->lvl ? t->lvl : lvl, dl = (lvl - lvl0) >> CTL_LOG2;   /* a new sound's trim: ramped */
        t->lvl = lvl;
        for (i = 0; i < n; i++) {
            int32_t lv = lvl0 + dl * (int32_t)i, bi = b[i], x = MULQ12R(bi, lv, 2), a;   /* (3.0.4 after SLOOP 2.8.4)
                                                         * rounded, all of b: 8 loud voices in 32 bits as ((b >> 2) * lv) >> 10 was */
            int32_t xs, g = ga + (((gb - ga) * (int32_t)i) >> CTL_LOG2);
            if (g < 32767) {                            /* (always, at rest: mulq15(32767, 32767) is 32766) */
                g >>= 3;                                /* (Q12: no 32-bit overflow) */
                x = MULQ12R(x, g, 4);
            }
            a = x < 0 ? -x : x;
            xs = clamp(x, -xmax, xmax);                 /* sends: mulq15 would overflow */
            if (a > pk)
                pk = a;
            if (c)
                o->c[i] += mulq15(xs, c);
            if (d)
                o->d[i] += mulq15(xs, d);
            if (r)
                o->v[i] += mulq15(xs, r);
            if (cs)
                o->cl[i] += mulq15(xs, cs);
            o->l[i] += (x * (gl >> 4) + 128) >> 8;      /* (x may pass 2^19: PAN's Q12 to Q8, exact at rest; 3.0.4 after
                                                         * SLOOP 2.8.4: x >> 4 floored the part to 16 LSB) */
            o->r[i] += (x * (gr >> 4) + 128) >> 8;
        }
        t->peak = pk;
    }
}

/* ---- DUST: the master through an old sampler and a record. G_DUST 0..127 turns up together: drive
 * into a soft clip, a lower sample rate (held samples, 44.1 -> 11 kHz), fewer bits (15 -> 8), a
 * one-pole low-pass (open -> ~3 kHz), a little hiss and crackle. The hiss and the crackle are the
 * record turning: they fade in with PLAY and out (~0.1 s) at STOP, so a stopped SLOOP is silent.
 * Stereo, ~25 ops a sample. */
static struct {
    int32_t hl, hr, hn;                                 /* held samples, samples left to hold */
    int32_t ll, lr;                                     /* low-pass states */
    int32_t rnd, click;                                 /* noise state, a crackle decaying */
    int32_t bed;                                        /* hiss / crackle level, Q15: 0 stopped, 32767 playing */
} dust = {0, 0, 0, 0, 0, 0x2545F491, 0, 0};

static int32_t crush_bits(int32_t v, int32_t shift)    /* fewer bits, rounded toward 0: no DC from tails */
{
    return v >= 0 ? (v >> shift) << shift : -((-v >> shift) << shift);
}

static void dust_process(int32_t *l, int32_t *r, uint32_t n)
{
    int32_t d = song.g[G_DUST], hold, shift, a, drive, hiss, i, bed0, bed1;
    uint32_t pc;
    if (!d) {
        dust.bed = 0;
        return;
    }
    hold = 1 + d * 3 / 127;
    shift = d / 18;
    a = 32767 - d * 165;                                /* one-pole coefficient, Q15 */
    drive = 4096 + d * 24;                              /* Q12: 1x .. 1.75x */
    hiss = d * 2;
    pc = (uint32_t)d * 7u;                              /* crackle: chance per sample, x 2^-22 */
    bed0 = dust.bed;                                    /* ~0.1 s from 0 to full (238 a block of 32) */
    bed1 = dust.bed = clamp(dust.bed + (song.playing ? 238 : -238), 0, 32767);
    for (i = 0; i < (int32_t)n; i++) {
        int32_t x = l[i], y = r[i];
        int32_t bed = bed0 + (((bed1 - bed0) * i) >> CTL_LOG2);
        uint32_t nz = noise32(&dust.rnd);
        if (--dust.hn <= 0) {                           /* sample and hold, then the bits */
            dust.hn = hold;
            dust.hl = softclip(((x >> 2) * drive) >> 10);
            dust.hr = softclip(((y >> 2) * drive) >> 10);
            if (shift) {
                dust.hl = crush_bits(dust.hl, shift);
                dust.hr = crush_bits(dust.hr, shift);
            }
        }
        dust.ll += mulq15(dust.hl - dust.ll, a);
        dust.lr += mulq15(dust.hr - dust.lr, a);
        if ((nz >> 10) < pc)                            /* a speck of dust */
            dust.click = mulq15(((int32_t)(nz & 0x3FFu) - 512) * d / 8, bed);
        x = dust.ll + dust.click + mulq15(((int32_t)(nz >> 16) - 32768) * hiss >> 15, bed);
        y = dust.lr + dust.click + mulq15(((int32_t)(nz & 0xFFFFu) - 32768) * hiss >> 15, bed);
        dust.click -= dust.click >> 2;
        l[i] = x;
        r[i] = y;
    }
}

static void djf_process(int32_t *l, int32_t *r, uint32_t n)
{
    tsvf_t c;
    if (!djf_block(&djf, song.g[G_FILT], &c))
        return;
    djf_run(&djf, &c, l, n, 0);
    djf_run(&djf, &c, r, n, 1);
}

#include "punch.c"            /* PUNCH-IN FX on the whole mix (FX held + a white key) */
static int32_t master_cur = -1;                        /* the volume knob, ramped per sample (no zipper) */
/* the drum track's INSERT (2.6): its left, right and the two sends, each through its own state, the same settings */
static void drum_insert(int32_t *l, int32_t *r, int32_t *v, int32_t *d, uint32_t n)
{
    track_t *t = TDRUM;
    int run;
    if (!(t->p[P_ITYPE] | t->ins_run))
        return;
    run = ins_run(&ins[NPART], t->p, l, n);
    run |= ins_run(&ins[NPART + 1u], t->p, r, n);
    run |= ins_run(&ins[NPART + 2u], t->p, v, n);
    run |= ins_run(&ins[NPART + 3u], t->p, d, n);
    t->ins_run = (uint8_t)run;
}
/* ---- TEXTURE (SLOOP 2.6, GLO > TEXTURE): a looping bed under the mix, the glue of lo-fi and ambient tracks, without
 * taking a track. SRC: a generated noise (no memory, nothing to load) or a user sample slot looped (USR1..4, its first
 * zone at its own pitch; a looped zone from its loop, else whole), LEVEL, TONE (the DJ filter: left a low-pass, right a
 * high-pass), MOVE: how much it breathes over RATE (1 .. 16 bars of the tempo; its level and brightness, a sine from the
 * transport's start), WHEN: PLAY (fades in and out with the transport) or ALWAYS, DUCK: the kick pumps it as the
 * parts (GLO > MASTER > DUCK). Into the dry mix (no sends), before DUST, the punch-ins and the master filter.
 *   VINYL  hiss, rumble, crackle and the odd pop, each crackle somewhere left to right
 *   TAPE   hiss tilted dark, its level drifting slowly (flutter)
 *   RAIN   a soft bed and droplets, left and right apart
 *   WIND   noise through two resonant low-passes wandering slowly, gusts
 *   RADIO  a band of static (500 Hz .. 3 kHz), coarse, in bursts that come and go
 *   ROOM   room tone: a low rumble and a little air
 * Its level: x * LEVEL^2 / 16384 into the mix (the sources at about 8000 rms: LEVEL 64 about -30 dBFS rms out, 127
 * about -18). Off (and faded out): nothing runs, the mix bit for bit as without */
enum { TX_OFF, TX_VINYL, TX_TAPE, TX_RAIN, TX_WIND, TX_RADIO, TX_ROOM, TX_USR1, TX_N = TX_USR1 + 4 };
static struct {
    int32_t rnd;                                        /* noise state (never 0) */
    int32_t g;                                          /* gain now (Q15 of the LEVEL target), ramped a block */
    uint8_t src, play;                                  /* the source running; the transport as last seen */
    uint32_t ph;                                        /* MOVE's phase (a turn per RATE) */
    int32_t a[2], b[2], c[2], d[2], e[2];               /* per side: the sources' states (see texture_gen) */
    int32_t lpm[2];                                     /* MOVE's brightness (one-pole) */
    int32_t t0, t1, t2;                                 /* slow random walks / timers */
    tsvf_t wc[2];                                       /* WIND: this block's filters */
    int32_t wz[2][2];
    uint32_t upos, ufrac;                               /* USR: the read position, Q16 fraction */
    int32_t up, ui, us0, us1;                           /* USR: ADPCM predictor, step index, the two samples interpolated */
    uint32_t ugen;                                      /* USR: the slots' scan count (an upload restarts it) */
    int32_t ulast, uoff;                                /* USR: the last value out; the step at a wrap, gliding to 0
                                                         * (a sample that does not end where it starts: no click) */
    uint8_t uwrap;                                      /* USR: tx_usr_next went round */
    djf_t f;                                            /* TONE */
} tx = {.rnd = 0x2545F491};
static inline int32_t tx_n16(void) { return (int32_t)(noise32(&tx.rnd) >> 16) - 32768; }   /* -32768 .. 32767 */
static void texture_reset(uint32_t src)
{
    int32_t rnd = tx.rnd, g = tx.g;
    uint32_t ph = tx.ph;
    uint8_t play = tx.play;
    memset(&tx, 0, sizeof tx);
    tx.rnd = rnd ? rnd : 0x2545F491;
    tx.g = g, tx.ph = ph, tx.play = play;
    tx.src = (uint8_t)src;
    tx.t0 = 50 << 8, tx.t1 = 60 << 8;                  /* (WIND: the two cutoffs, RADIO / TAPE: the level) */
    tx.ugen = smp_user_gen - 1u;                        /* (USR: the zone looked up on the first block) */
}
/* USR k: the next sample of its first zone, looped (sample_next's decoder, its own state) */
static inline int32_t tx_usr_next(const smp_zone_t *z)
{
    uint32_t pos = tx.upos, b = SMP_AT(z->off + (pos >> 1));
    uint32_t code = (pos & 1u) ? (b >> 4) : (b & 15u);
    int32_t step = IMA_STEP[(uint32_t)tx.ui <= 88u ? tx.ui : 88], vd = step >> 3;
    if (code & 4u) vd += step;
    if (code & 2u) vd += step >> 1;
    if (code & 1u) vd += step >> 2;
    tx.up = clamp(tx.up + ((code & 8u) ? -vd : vd), -32768, 32767);
    tx.ui = clamp(tx.ui + IMA_IDX[code & 7u], 0, 88);
    if (++pos > (z->looped ? z->le : z->n - 1u)) {      /* round again: from the loop (its state), or the top */
        pos = z->looped ? z->ls : 0u;
        tx.up = z->looped ? z->pred : 0;
        tx.ui = z->looped ? z->idx : 0;
        tx.uwrap = 1;
    }
    tx.upos = pos;
    return tx.up;
}
/* n samples of source src (both sides) into l, r, at about 8000 rms */
static void texture_gen(uint32_t src, int32_t *l, int32_t *r, uint32_t n)
{
    uint32_t i, k;
    if (src >= TX_USR1) {
        uint32_t s = src - TX_USR1;
        const smp_zone_t *z = usr_nz[s] ? &usr_zone[s][0] : 0;
        if (!z || !z->n) {
            for (i = 0; i < n; i++)
                l[i] = r[i] = 0;
            return;
        }
        if (tx.ugen != smp_user_gen) {                  /* a new upload (or the first block): from the top */
            tx.ugen = smp_user_gen;
            tx.upos = 0, tx.ufrac = 0, tx.up = tx.ui = 0;
            tx.us0 = 0, tx.us1 = tx_usr_next(z);
            tx.uwrap = 1;                               /* (from where the old one was: no click) */
        }
        for (i = 0; i < n; i++) {
            int32_t v;
            tx.ufrac += z->rate;                        /* (its own rate: Q16 of 44.1 kHz) */
            while (tx.ufrac >= 65536u) {
                tx.ufrac -= 65536u;
                tx.us0 = tx.us1;
                tx.us1 = tx_usr_next(z);
            }
            v = (tx.us0 + (((tx.us1 - tx.us0) * (int32_t)(tx.ufrac >> 1)) >> 15)) >> 1;
            if (tx.uwrap) {                             /* (2.6) round again: from the value it was at */
                tx.uwrap = 0;
                tx.uoff = tx.ulast - v;
            }
            tx.uoff -= (tx.uoff >> 6) + (tx.uoff > 0) - (tx.uoff < 0);   /* (~1.5 ms) */
            l[i] = r[i] = tx.ulast = v + tx.uoff;
        }
        return;
    }
    switch (src) {
    case TX_VINYL:                                      /* a: rumble, b: crackle, c: its decay, d: hiss tilt */
        for (i = 0; i < n; i++) {
            uint32_t z = noise32(&tx.rnd);
            int32_t w = (int32_t)(z >> 16) - 32768, h;
            tx.a[0] += (w >> 5) - (tx.a[0] >> 7);       /* rumble: integrated, leaky */
            if ((z & 0xFFFFu) < 60u) {                  /* crackle, ~40 a second, anywhere left to right */
                int32_t amp = 6000 + (int32_t)((z >> 8) & 0x3FFFu) + ((z & 1u) ? 0 : 12000 * ((z & 0x30u) == 0u));
                int32_t pan = (int32_t)((z >> 20) & 0xFFu);
                amp = (z & 0x100u) ? -amp : amp;
                tx.b[0] = (amp * (256 - pan)) >> 8;
                tx.b[1] = (amp * pan) >> 8;
            }
            for (k = 0; k < 2u; k++) {
                h = (k ? (int32_t)(noise32(&tx.rnd) >> 16) - 32768 : w);
                tx.d[k] += (h - tx.d[k]) >> 2;          /* the hiss: dark, low (the crackle on top) */
                (k ? r : l)[i] = (tx.d[k] >> 4) + (tx.a[0] >> 2) + tx.b[k];
                tx.b[k] -= tx.b[k] >> 2;                /* (a click: a few samples) */
            }
        }
        break;
    case TX_TAPE:                                       /* t0: the level drifting (Q8), t2: its next target */
        if (!(tx.t1++ & 31))
            tx.t2 = (24 << 8) + (int32_t)((noise32(&tx.rnd) >> 20) & 0x7FFu) * 4;
        tx.t0 += (tx.t2 - tx.t0) >> 6;
        for (i = 0; i < n; i++)
            for (k = 0; k < 2u; k++) {
                int32_t w = tx_n16();
                tx.a[k] += (w - tx.a[k]) >> 2;          /* tilted dark: mostly the low-passed part */
                (k ? r : l)[i] = (((tx.a[k] >> 1) + (w >> 3)) * (tx.t0 >> 8)) >> 5;
            }
        break;
    case TX_RAIN:                                       /* a: the bed's low-pass, b: a droplet's level, c: its noise */
        for (i = 0; i < n; i++)
            for (k = 0; k < 2u; k++) {
                uint32_t z = noise32(&tx.rnd);
                int32_t w = (int32_t)(z >> 16) - 32768;
                tx.a[k] += (w - tx.a[k]) >> 4;          /* the bed: ~450 Hz */
                if ((z & 0xFFFFu) < 420u)               /* a droplet: ~280 a second a side */
                    tx.b[k] = 4000 + (int32_t)((z >> 4) & 0x3FFFu);
                tx.c[k] += (w - tx.c[k]) >> 1;
                (k ? r : l)[i] = (tx.a[k] >> 1) + (((w - tx.c[k]) * tx.b[k]) >> 14);
                tx.b[k] -= tx.b[k] >> 5;
            }
        break;
    case TX_WIND: {                                     /* t0, t1: the cutoffs wandering (Q8 index), t2: their targets */
        if (!(noise32(&tx.rnd) & 31u))
            tx.t2 = (int32_t)(noise32(&tx.rnd) & 0xFFFFu);   /* new targets now and then: 34 .. 78 */
        tx.t0 += (((34 << 8) + (tx.t2 & 0xFF) * 44) - tx.t0) >> 7;
        tx.t1 += (((34 << 8) + (tx.t2 >> 8) * 44) - tx.t1) >> 7;
        tsvf_coef(&tx.wc[0], tx.t0, 95);
        tsvf_coef(&tx.wc[1], tx.t1, 95);
        for (i = 0; i < n; i++)
            for (k = 0; k < 2u; k++) {
                int32_t y = tsvf_lp(&tx.wc[k], tx_n16() >> 2, &tx.wz[k][0], &tx.wz[k][1]);
                (k ? r : l)[i] = clamp(y, -32767, 32767);
            }
        break;
    }
    case TX_RADIO:                                      /* a, b: the band's two low-passes, t0: the burst level (Q8),
                                                         * t1: samples left of the burst, c: the held sample */
        if ((tx.t1 -= (int32_t)n) <= 0) {
            uint32_t z = noise32(&tx.rnd);
            tx.t1 = 1500 + (int32_t)((z >> 8) & 0x3FFFu);   /* 35 .. 400 ms */
            tx.t2 = (z & 3u) == 0u ? 40 << 8 : (110 + (int32_t)((z >> 24) & 0x7Fu)) << 8;   /* (a gap now and then) */
        }
        tx.t0 += (tx.t2 - tx.t0) >> 2;
        for (i = 0; i < n; i++) {
            int32_t w = tx_n16(), y;
            if (!(i & 3u))
                tx.c[0] = w;                            /* coarse: held four samples */
            tx.a[0] += (tx.c[0] - tx.a[0]) >> 1;        /* < ~3 kHz */
            tx.b[0] += (tx.a[0] - tx.b[0]) >> 4;        /* the lows taken out: > ~500 Hz */
            y = (((tx.a[0] - tx.b[0]) >> 1) * (tx.t0 >> 8)) >> 6;
            l[i] = y;
            r[i] = y - (y >> 2);
        }
        break;
    case TX_ROOM:                                       /* a: the rumble, b: its low-pass, c: air */
        for (i = 0; i < n; i++)
            for (k = 0; k < 2u; k++) {
                int32_t w = tx_n16();
                tx.a[k] += (w >> 4) - (tx.a[k] >> 8);
                tx.b[k] += (tx.a[k] - tx.b[k]) >> 5;
                (k ? r : l)[i] = (tx.b[k] >> 1) + (w >> 6);
            }
        break;
    default:
        for (i = 0; i < n; i++)
            l[i] = r[i] = 0;
        break;
    }
}
static void texture_mix(int32_t *l, int32_t *r, uint32_t n)
{
    static int32_t tl[CTL], tr[CTL];
    static const uint8_t BARS[5] = {1, 2, 4, 8, 16};
    uint32_t src = (uint32_t)clamp(song.g[G_TXSRC], 0, TX_N - 1), i, bar;
    /* the sources to about 8000 rms (VINYL ~5000: its crackle peaks), Q8; the user slots as they are (/ 2) */
    static const int16_t TX_SCALE[TX_USR1 + 1] = {0, 800, 301, 693, 1918, 149, 343, 256};
    int32_t lvl = clamp(song.g[G_TXLVL], 0, 127), on, g0, g1, mv, depth, u, lfo, k0, k1, sc;
    tsvf_t fc;
    if (song.playing && !tx.play)
        tx.ph = 0;                                      /* MOVE from the transport's start */
    tx.play = (uint8_t)song.playing;
    on = src && src == tx.src && (song.playing || song.g[G_TXWHEN]) && lvl;
    if (!tx.g && !on) {                                 /* silent: nothing runs (and a new source starts from rest) */
        if (src != tx.src)
            texture_reset(src);
        return;
    }
    if (n > CTL)
        return;
    g0 = tx.g;                                          /* fades over ~0.1 s (238 a block), as DUST's bed */
    g1 = tx.g = clamp(tx.g + (on ? 238 : -238), 0, 32767);
    bar = (uint32_t)FS * 240u / (uint32_t)clamp(song.g[G_BPM], 20, 300);   /* a bar of 4/4, samples */
    tx.ph += (uint32_t)((0xFFFFFFFFu / (bar * BARS[clamp(song.g[G_TXRATE], 0, 4)])) * n);
    lfo = sine_i(tx.ph - 0x40000000u);                  /* (from its top: a start at full) */
    depth = clamp(song.g[G_TXMOVE], 0, 127) * 258;
    u = mulq15(depth, (32767 - lfo) >> 1);              /* 0 .. depth, the dip */
    mv = 32767 - mulq15(u, 21000);                      /* the level breathing: down to ~36 % */
    k0 = 32767 - mulq15(u, 28000);                      /* the brightness: a one-pole closing */
    texture_gen(tx.src, tl, tr, n);
    sc = TX_SCALE[tx.src < TX_USR1 ? tx.src : TX_USR1];
    for (i = 0; i < n; i++) {                           /* each source to its level, MOVE's colour (Q13: no overflow */
        tx.lpm[0] += ((((tl[i] * sc) >> 8) - tx.lpm[0]) >> 2) * (k0 >> 2) >> 11;   /* up to +-260000) */
        tx.lpm[1] += ((((tr[i] * sc) >> 8) - tx.lpm[1]) >> 2) * (k0 >> 2) >> 11;
        tl[i] = tx.lpm[0], tr[i] = tx.lpm[1];
    }
    if (djf_block(&tx.f, clamp(song.g[G_TXTONE], -64, 63), &fc)) {
        djf_run(&tx.f, &fc, tl, n, 0);
        djf_run(&tx.f, &fc, tr, n, 1);
    }
    k1 = mulq15(lvl * lvl * 2, mv);                     /* LEVEL^2 (x 2: Q15 of 4096 at 127 .. ) x MOVE */
    for (i = 0; i < n; i++) {
        int32_t g = g0 + (((g1 - g0) * (int32_t)i) >> CTL_LOG2), gk = mulq15(g, k1);
        if (song.g[G_TXDUCK])
            gk = mulq15(gk, duck.g0 + (((duck.g1 - duck.g0) * (int32_t)i) >> CTL_LOG2));
        l[i] += (tl[i] * (gk >> 4)) >> 11;              /* x LEVEL^2 / 16384: (x * gk / 32768) at full */
        r[i] += (tr[i] * (gk >> 4)) >> 11;
    }
    if (!g1 && src != tx.src)
        texture_reset(src);                             /* faded out: the new source from rest */
}

/* KARMA 3.0, after JIANT FM 0.7.1 (Juan Jiant, GPL-3.0-only): menu USB AUDIO = STEMS, the USB audio input as 6
 * channels (usb.c uac_tap6): each track mono (its LEVEL, DIST, SLICER, INSERT, FILTER and MUTE in, its PAN not: what
 * it adds to the dry mix, L + R halved), tracks 1..3 then the drums, and the FX return L R (the CHORUS, DELAY and
 * REVERB buses, the CLOUD, TEXTURE), all before the master (no DUST, punch-in, DJ filter, limiter or MASTER: the
 * mix's own scale); the metronome in none. fx_stems: this render feeds them (audio.c) */
static int32_t stem_buf[NTRK][CTL], stem_fx[2][CTL], stem_pre[CTL];
static uint8_t fx_stems;
#define UAC_STEMS_SRC 1
static __attribute__((noinline)) void stem_take(uint32_t k, uint32_t n, int post)
{
    uint32_t i;
    if (!post)
        for (i = 0; i < n; i++)
            stem_pre[i] = mix_l[i] + mix_r[i];
    else
        for (i = 0; i < n; i++)
            stem_buf[k][i] = STEM_OF(mix_l[i] + mix_r[i] - stem_pre[i]);
}

/* where a block's time goes (2026-10-28: the FM-1 overloaded with HEX drums and three tracks): the timer's ticks summed
 * per part of mix_block since the last read (console.c `prof`, which zeroes them). The host has no timer: 0 */
enum { PF_EVENTS, PF_T1, PF_T2, PF_T3, PF_DRUMS, PF_BUSES, PF_CLOUD, PF_OUT, PF_N };
static uint32_t prof_ticks[PF_N], prof_blocks, prof_max[PF_N], prof_blk_max, prof_blk[PF_N], prof_worst[PF_N];   /* (and the worst block) */
#ifdef FM1_TICKS_PER_US
#define PROF_NOW() fm1_ticks()
#else
#define PROF_NOW() 0u
#endif
#define PROF(k) do { uint32_t pt_ = PROF_NOW(), d_ = pt_ - prof_t0; prof_ticks[k] += d_; prof_blk[k] = d_; \
                     if (d_ > prof_max[k]) prof_max[k] = d_; prof_t0 = pt_; } while (0)
static void mix_block(int32_t *out, uint32_t n)
{
    uint32_t i, prof_t0 = PROF_NOW();
    int32_t m0, m1;
    int fx_done = 0;                                    /* (3.1.3) CPU1 ran this block's effects (fx_prev) */
    int fx_wait = 0;                                    /* (test 8) CPU0 ran them in its wait */
    for (i = 0; i < n; i++)
        send_c[i] = send_d[i] = send_r[i] = mix_l[i] = mix_r[i] = 0;
    {   /* REV / ECHO THROW (2.6): the sends glide to full and back over ~12 ms (17 blocks) */
        uint32_t q = thr_req;
        thr_rev = (q & 1u) ? (thr_rev + 1928 > 32767 ? 32767 : thr_rev + 1928) : (thr_rev > 1928 ? thr_rev - 1928 : 0);
        thr_dly = (q & 2u) ? (thr_dly + 1928 > 32767 ? 32767 : thr_dly + 1928) : (thr_dly > 1928 ? thr_dly - 1928 : 0);
    }
#if KARMA_PCOST
    {
        uint32_t ev_t0 = fm1_ticks();
        events_block(n);
        karma_pc_add(PC_EV_ALL, ev_t0);                 /* (3.1.5 test 13) */
    }
#else
    events_block(n);
#endif
    duck_block(n * (uint32_t)song.g[G_BPM]);
    prof_blocks++;
    PROF(PF_EVENTS);
#if KARMA_DUAL_CORE
    int w_on = 0;
    audio_worker_check();                               /* (a CPU1 that faulted or misread: retired, one core) */
    if (n <= CTL && w_mask) {                           /* (USB STEMS too: each core takes its parts' stems) */
        w_n = n;
        w_job = w_mask;
        w_hex = (uint8_t)(KARMA_CPU1_HEX && !(TDRUM->att >= 32767 && trk_silent(TDRUM)));   /* (3.1.3: muted all through:
                                                         * nothing to render) */
        w_fx = KARMA_CPU1_FX;                           /* (3.1.3: the effects on the last block's sends, fx_prev) */
        w_on = audio_worker_submit(core1_parts, 0);
    }
    if (w_on) {
#if KARMA_FLIPS
        flip_probe(0);                                  /* (test 4: the same reads on CPU0, at the same time) */
#endif
        for (i = 0; i < NPART; i++)                     /* CPU0's parts, measured as CPU1's are */
            if (!((w_job >> i) & 1u)) {
                uint32_t t0 = PROF_NOW();
                if (fx_stems)
                    stem_take(i, n, 0);
                mix_part(&trk[i], n);
                if (fx_stems)
                    stem_take(i, n, 1);
                cost_put0(i, PROF_NOW() - t0);              /* (3.1.5: the balance in CPU1's time) */
            }
        PROF(PF_T1);
#if KARMA_FX_WAIT
        fx_prev();                                      /* (test 8) the effects while CPU1 still renders */
        fx_wait = 1;
        PROF(PF_CLOUD);                                 /* (karma_prof "cloud": the effects in the wait) */
#endif
    } else
#endif
    for (i = 0; i < NPART; i++) {
        if (fx_stems)
            stem_take(i, n, 0);
        mix_part(&trk[i], n);
        if (fx_stems)
            stem_take(i, n, 1);
        PROF(PF_T1 + i);
    }
#if KARMA_DUAL_CORE
    if (w_on) {                                         /* CPU1's tracks: wait, then into the mix and the sends */
#if KARMA_BAL_MEAS
        uint32_t c0_end = fm1_ticks();                  /* (test 10) CPU0 ready to join */
#endif
        if (!audio_worker_join()) {
            hx_pre_mask = 0;                            /* (3.1.3: CPU1 gave up mid-job: the drums render here, */
            if (w_fx) {                                 /*  its effects' block is lost: silence for one block) */
                for (i = 0; i < CTL; i++)
                    wet_l[i] = wet_r[i] = 0;
                fx_done = 1;
            }
        } else {
            fx_done = w_fx;                             /* (3.1.4: only when CPU1 ran them; else CPU0 runs them below) */
#if KARMA_BAL_MEAS
            bal_sum += (int32_t)(w_end - c0_end);       /* (test 10) + CPU0 waited, - CPU1 was done first */
            bal_n++;
#endif
        }
        if (audio_worker_online)
            for (i = 0; i < n; i++) {
                mix_l[i] += w_l[i], mix_r[i] += w_r[i];
                send_c[i] += w_c[i], send_d[i] += w_d[i], send_r[i] += w_v[i], cloud_bus[i] += w_cl[i];
            }
        PROF(PF_T2);                                    /* (CPU0's wait and the sum; track3: 0) */
        core_balance();
    }
#endif
    if (fx_wait)
        fx_done = 1;
    /* (3.1.3) the drums after the join: their HEX voices may be CPU1's block (drums.c hx_pre_buf) */
    if (fx_stems)
        stem_take(TRK_DRUM, n, 0);
    drums.a0 = TDRUM->att;                              /* the drum track's mute / solo fade */
    drums.a1 = 32767 - gain_next(TDRUM);
    {
        static int32_t dl[CTL], dr[CTL], dv[CTL], dd[CTL];
        tsvf_t fc;
        djf_t *f = &tflt[TRK_DRUM];
        if (n <= CTL && djf_block(f, TDRUM->p[P_TFLT], &fc)) {   /* the drum track's FILTER: left, right, the sends */
            for (i = 0; i < n; i++)
                dl[i] = dr[i] = dv[i] = dd[i] = 0;
            slicer_drums(dl, dr, dv, dd, n);
            drum_insert(dl, dr, dv, dd, n);
            tflt_run(f, &fc, dl, n, 0);
            tflt_run(f, &fc, dr, n, 1);
            tflt_run(f, &fc, dv, n, 2);
            tflt_run(f, &fc, dd, n, 3);
            for (i = 0; i < n; i++) {
                mix_l[i] += dl[i];
                mix_r[i] += dr[i];
                send_r[i] += dv[i];
                send_d[i] += dd[i];
            }
        } else if (n <= CTL && (TDRUM->p[P_ITYPE] | TDRUM->ins_run)) {   /* the INSERT (2.6), no FILTER */
            for (i = 0; i < n; i++)
                dl[i] = dr[i] = dv[i] = dd[i] = 0;
            slicer_drums(dl, dr, dv, dd, n);
            drum_insert(dl, dr, dv, dd, n);
            for (i = 0; i < n; i++) {
                mix_l[i] += dl[i];
                mix_r[i] += dr[i];
                send_r[i] += dv[i];
                send_d[i] += dd[i];
            }
        } else {
            slicer_drums(mix_l, mix_r, send_r, send_d, n);   /* drums_render, through the SLICER when on */
        }
    }
    if (fx_stems)
        stem_take(TRK_DRUM, n, 1);                      /* the drums' stem */
#if KARMA_DUAL_CORE
    cost_put(NPART, PROF_NOW() - prof_t0);              /* (the drums' time, for the balance) */
#endif
    PROF(PF_DRUMS);
    click_render(mix_l, mix_r, n);                      /* the metronome: its own voice (drums.c), any kit, any mute */
    if (fx_stems)                                       /* the FX return: what is added from here (not the metronome) */
        for (i = 0; i < n; i++)
            stem_fx[0][i] = mix_l[i], stem_fx[1][i] = mix_r[i];
    texture_mix(mix_l, mix_r, n);                       /* GLO > TEXTURE (2.6): the bed, dry */
    punch_freeze_feed(send_r, mix_l, mix_r, n);         /* punch-in FREEZE: the dry mix into the held reverb */
#if !KARMA_DUAL_CORE || (!KARMA_CPU1_FX && !KARMA_FX_WAIT)
    fxp_n = n;                                          /* (3.1.5) the effects on this block's sends, here */
#endif
    if (!fx_done)                                       /* (3.1.3) one core, CPU0's effects, or no CPU1 this block */
        fx_prev();
    for (i = 0; i < n; i++) {                           /* the effects' return */
        mix_l[i] += wet_l[i];
        mix_r[i] += wet_r[i];
    }
    PROF(PF_BUSES);
#if KARMA_DUAL_CORE && (KARMA_CPU1_FX || KARMA_FX_WAIT)
    for (i = 0; i < n; i++) {                           /* this block's sends, for the next block's effects (CPU1 / CPU0's wait) */
        FXP_C[i] = send_c[i];
        FXP_D[i] = send_d[i];
        FXP_R[i] = send_r[i];
        FXP_CL[i] = cloud_bus[i];
        cloud_bus[i] = 0;
    }
    fxp_n = n;
#endif
    PROF(PF_CLOUD);
    if (fx_stems)                                       /* ... what the buses, the CLOUD and TEXTURE added */
        for (i = 0; i < n; i++)
            stem_fx[0][i] = STEM_OF(2 * (mix_l[i] - stem_fx[0][i])), stem_fx[1][i] = STEM_OF(2 * (mix_r[i] - stem_fx[1][i]));   /* (as far down) */
    dust_process(mix_l, mix_r, n);
    punch_process(mix_l, mix_r, n);
    djf_process(mix_l, mix_r, n);
    m1 = (int32_t)song.master_q12;
    m0 = master_cur < 0 ? m1 : master_cur;
    master_cur = m1;
    if (n > CTL)
        n = CTL;                                        /* (the buffers' size) */
    {
        static int32_t ol[CTL], orr[CTL], ul[CTL], ur[CTL];
        static uint8_t usb_was;
        for (i = 0; i < n; i++) {
            int32_t m = m0 + (((m1 - m0) * (int32_t)i) >> CTL_LOG2);
            ol[i] = MULQ12R(mix_l[i], m, 2);           /* (3.0.4 after SLOOP 2.8.4: rounded; (x >> 2) * m >> 10 floored
                                                         * to 4 LSB) */
            orr[i] = MULQ12R(mix_r[i], m, 2);
            master_pre(&ol[i], &orr[i]);
            if ((i & 1u)) {                             /* the visualiser: every other sample, as audio.c reads it */
                vis_tap[2u * i] = (int16_t)knee(mix_l[i]);
                vis_tap[2u * i + 1u] = (int16_t)knee(mix_r[i]);
            }
            if (usb_full_now) {                         /* USB AUDIO = FULL: MASTER all the way up (4096) */
                ul[i] = mix_l[i], ur[i] = mix_r[i];     /* (3.0.4 after SLOOP 2.8.4: x 4096 / 4096, every bit; it was
                                                         * floored to 4 LSB) */
                master_pre_usb(&ul[i], &ur[i]);
            }
        }
        lim_block(&lim_dac, ol, orr, n);
        for (i = 0; i < n; i++) {
            out[2u * i] = knee(ol[i]);
            out[2u * i + 1u] = knee(orr[i]);
        }
        if (usb_full_now && !usb_was) {                 /* (a new recording: no old block in its delay) */
            memset(&lim_usb, 0, sizeof lim_usb);
            lim_usb.env = LIM_T, lim_usb.g = 32768, lim_usb.hold = 0;
        }
        usb_was = usb_full_now;
        if (usb_full_now) {
            lim_block(&lim_usb, ul, ur, n);
            for (i = 0; i < n; i++) {
                usb_out[2u * i] = knee(ul[i]);
                usb_out[2u * i + 1u] = knee(ur[i]);
            }
        }
    }    PROF(PF_OUT);
    {   /* the worst block whole, and what each part took in it */
        uint32_t k, all = 0;
        for (k = 0; k < PF_N; k++)
            all += prof_blk[k];
        if (all > prof_blk_max) {
            prof_blk_max = all;
            for (k = 0; k < PF_N; k++)
                prof_worst[k] = prof_blk[k];
        }
    }
}
