/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* SLOOP (based on FELUCCA): one compilation unit (the HAL is header-only). Order matters. */
#include <stdint.h>
#define PR_WAVES_FROM_PLX 1      /* PLAITS WAVE (prism_dsp.c) reads Plaits' own 50 KB wavetable: one copy (plx.cc) */
#ifndef KARMA_DUAL_CORE                  /* (before the HAL: fm1_sys.h holds CPU1 at every reset with it) */
#define KARMA_DUAL_CORE 1        /* CPU1 renders tracks 2 and 3 (fx.c mix_block; the worker after Melodee). On Ariel's FM-1
                                  * 2026-10-28: clean where one core overloaded. KARMA_DUAL_CORE=0 build.sh -> one core,
                                  * build/karma-single.fwsc (an FM-1 whose CPU1 misbehaves; it also retires itself) */
#endif
/* (3.1.5) FM1_HOT: code TIMER5 runs every tick (10 kHz on CPU0: the key and LED scan, the USB audio packets) in RAM
 * (.ram_text), not in XIP through the cache: each tick fetched ~2 KB from the flash and pushed the engines' code out of
 * CPU0's cache. TIMER5 never runs while the flash is written (fm1_flash.h: interrupts off) */
#ifndef KARMA_T5_RAM
#define KARMA_T5_RAM 1
#endif
#if KARMA_T5_RAM
#define FM1_HOT __attribute__((unused))
#else
#define FM1_HOT
#endif
#define FM1_RAMBSS __attribute__((unused))   /* (3.1.5) big buffers in RAM's spare code space (app.ld) */
#include "fm1_time.h"
#include "fm1_sys.h"
#include "fm1_irq.h"
#include "fm1_guard.h"
#if KARMA_DUAL_CORE
#include "fm1_multicore.h"
#endif
#include "fm1_input.h"
#include "fm1_timer.h"
#include "fm1_audio.h"
#include "fm1_adc.h"
#include "fm1_lcd_hw.h"
#include "felucca_tables.h"

#include "libc.c"
#include "lcd.c"
#include "gfx.c"
#include "core.h"
#include "engines.c"
#include "drums.c"
#include "params.c"
#include "voice.c"
#include "slicer.c"          /* per-track SLICER insert, used by fx.c */
#include "fx.c"
#ifndef FELUCCA_OTA
#define FELUCCA_OTA 1            /* M-UPGRADE update entry; needs FELUCCA_FLASH */
#endif
#ifndef FELUCCA_OTA_DRYRUN
#define FELUCCA_OTA_DRYRUN 0     /* 1 = stage, ask "success", then undo: no record, no reset */
#endif
#ifndef FELUCCA_ID
#define FELUCCA_ID "FM-1_926"    /* package identity, KARMA's own (build.py: the .fwsc marker string) */
#endif
#ifndef FELUCCA_CDC
#define FELUCCA_CDC 1            /* USB CDC-ACM serial console */
#endif
#ifndef FELUCCA_UAC                      /* (before usb.c: it defaults to 0) */
#define FELUCCA_UAC 1            /* USB audio input: the master output, 16-bit stereo 44.1 kHz (usb.c, after Felucca 1.0) */
#endif
#ifndef FELUCCA_UAC_TONE
#define FELUCCA_UAC_TONE 0       /* bench: the USB input sends test triangles instead of the music */
#endif
#include "usb.c"
#ifndef FELUCCA_UART
#define FELUCCA_UART 1           /* TRS MIDI IN on UART1 (3.5 mm jack) */
#endif
#if FELUCCA_UART
#include "midi_uart.c"
#endif
#define FELUCCA_ARRANGER 1
#include "arranger.c"
#include "seq.c"
#include "audio.c"
#include "panel.c"
#ifndef KARMA_ANN
#define KARMA_ANN 1              /* a screen reader on the computer (fm1-reader): announce.c, ui_speak.c */
#endif
#include "ui.c"
#if KARMA_ANN
#include "ann_words.h"           /* the link to KARMA's words file (tools/gen_words.py, firmware/words.tsv) */
#define ANN_NAME FELUCCA_VERSION
#define ANN_MAX 160u             /* a SAY in the SysEx queue as it is (SXQ 64 packets: (160 + 9) / 3 = 56) */
#include "announce.c"
#endif
#include "ui_song.c"
#include "ui_studio.c"
#include "ui_op.c"            /* the bands the LIVE screens share: header, knob readouts, track bar */
#include "icons.c"           /* parameter icons (FELUCCA_ICONS), used by ui_draw.c */
#include "ui_draw.c"
#include "ui_vis.c"           /* the full-screen visualiser (HOME on HOME, 2.4) */
#include "ui_layers.c"       /* hold a function button: what the keys and knobs do (TE style) */
#include "ui_menu.c"
#include "ui_input.c"
#if KARMA_ANN
#include "ui_speak.c"            /* what the screen shows, for the screen reader */
#endif
#ifndef FELUCCA_FLASH
#define FELUCCA_FLASH 1          /* flash driver + storage.c */
#endif
#if FELUCCA_OTA && !FELUCCA_FLASH
#error "FELUCCA_OTA needs FELUCCA_FLASH"
#endif
#if FELUCCA_FLASH
#define FL_QUIET() audio_dma_silence()     /* (audio.c: the DMA halves silent while the flash is written) */
#include "fm1_flash.h"
static uint8_t flash_ok;                 /* JEDEC id matched at boot (persist_boot) */
static int st_read(uint32_t off, void *dst, uint32_t n)   /* 256-byte IRQ-off windows: audio keeps up */
{
    uint8_t *d = dst;
    while (n) {
        uint32_t k = n > 256u ? 256u : n, f = irq_save();
        int rc = FL_FAR(fl_read_ram)(off, d, k);
        irq_restore(f);
        if (rc)
            return rc;
        off += k;
        d += k;
        n -= k;
    }
    return 0;
}
static void audio_silence(void)                 /* IRQs off: the DMA would loop stale audio (buzz) */
{
    uint32_t i;
    for (i = 0; i < sizeof abuf / sizeof abuf[0]; i++)
        abuf[i] = 0;
}
/* a sector erase with the audio silenced inside the same interrupts-off window (silenced before it, the
 * audio interrupt could render a fresh half that the DMA then loops for the whole erase: a buzz) */
static int fl_erase4k_quiet(uint32_t off, uint32_t *took)
{
    uint32_t f = irq_save();
    int rc;
    audio_silence();
    rc = FL_FAR(fl_erase4k_ram)(off, took);
    irq_restore(f);
    return rc;
}
static int st_erase(uint32_t off)
{
    uint32_t took;
    if (!FL_STORE_OK(off, 0x1000u))
        return -8;
    return fl_erase4k_quiet(off, &took);
}
static int st_prog(uint32_t off, const void *src, uint32_t n)
{
    if (!FL_STORE_OK(off, n))
        return -8;
    return fl_write(off, src, n);
}
#include "storage.c"
#endif
#include "upreset.c"          /* user presets (RAM mirror; flash with FELUCCA_FLASH) */
#include "project.c"
#if FELUCCA_OTA
static uint8_t recovery_active;
#define OTA_IDENTITY (recovery_active ? "FM-1_000" : FELUCCA_ID)
#include "ota.c"
static void recovery_poll(void);
static uint32_t ota_now_ms(void) { return fm1_ms; }
static void ota_idle(void)
{
    fm1_wdt_feed();
    if (recovery_active) recovery_poll();
}
static int ota_in_area(uint32_t off, uint32_t n) { return FL_IN(off, n, OTA_AREA, OTA_AREA + OTA_AREA_LEN); }
static int ota_erase(uint32_t off)
{
    uint32_t took;
    if (!ota_in_area(off, 0x1000u) || (off & 0xFFFu))
        return -8;
    return fl_erase4k_quiet(off, &took);
}
static int ota_prog(uint32_t off, const void *p, uint32_t n)
{
    if (!ota_in_area(off, n))
        return -8;
    return fl_write(off, p, n);
}
static int ota_fread(uint32_t off, void *p, uint32_t n) { return st_read(off, p, n); }
static void ota_show(uint32_t step, int32_t code)
{
    static const char *const STEP[] = {"", "PACKAGE", "CHECK HEAD", "LOADER", "CONFIRM", "RESTART"};
    char b[24];
    if (recovery_active) return;             /* keep polled USB alive during OTA */
    lcd_fill(0, 0, 240, 240, C_BLACK);
    draw_text_box(0, 92, 240, &FONT_S, "UPDATE", C_WHITE, 1);
    if (step < 9u) {
        draw_text_box(0, 124, 240, &FONT_S, STEP[step < 6u ? step : 0], C_HI, 1);
        return;
    }
    if (code == 1)
        str_cpy(b, "DRY RUN OK", sizeof b);
    else {
        uint32_t k = 0, v = (uint32_t)-code;
        str_cpy(b, "FAILED  -", sizeof b);
        while (b[k])
            k++;
        if (v >= 10u)
            b[k++] = (char)('0' + v / 10u);
        b[k++] = (char)('0' + v % 10u);
        b[k] = 0;
    }
    draw_text_box(0, 124, 240, &FONT_S, b, C_HI, 1);
    fm1_delay_ms(1500);
}
static void ota_commit(const uint8_t *parm)
{
    bootguard_clear(&bootguard);                        /* intentional update reset */
    usb_detach();
    fm1_delay_ms(30);
    fm1_enter_update(parm);                             /* record into RAM, core reset (fm1_sys.h) */
}
#endif
#if FELUCCA_OTA
#include "editor.c"          /* web editor SysEx (needs the OTA SysEx plumbing) */
#if KARMA_ANN
static int ann_wire_send(const uint8_t *p, uint32_t n)   /* never waits: no room (nobody reading), not sent */
{
    if (!usb.config || usb.suspended || sx_busy || SXQ - (so_w - so_r) < (n + 2u) / 3u)
        return -1;
    return ota_wire_send(p, n);
}
#endif
#endif
#if FELUCCA_CDC
#include "console.c"
#endif
#if FELUCCA_OTA
#include "recovery.c"        /* early, polled USB updater; no synth or settings */
#endif
#include "splash.c"          /* SLOOP boot logo (build/gen/sloop_logo.h) */
#include "main.c"
