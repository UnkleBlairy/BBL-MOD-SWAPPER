/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* FELUCCA boot and main loop. Boot order: WDT first, boot-loop guard, fatal
 * vectors, guards; then LCD, input (TIMER5 IRQ, 10 kHz), audio (ALNK0 IRQ). */
extern uint32_t _data_start[], _data_end[], _data_load[], _bss_start[], _bss_end[];
extern uint32_t _pool_start[], _pool_end[], _rt_start[], _rt_end[], _rt_load[];


/* TIMER5 outranks ALNK0 (timer5_start): the scan keeps its pace while a half buffer renders. Nested in
 * the render it only scans and counts ms; the USB and UART polls wait for the first tick after the
 * render, so usb_poll never runs nested. The USB audio stream cannot wait (one packet per 1 ms frame, a
 * render takes up to a few ms): uac_service also runs nested. It touches only EP4 (INDEX set on every
 * access) and the consumer side of the audio ring, and usb_poll never runs nested, so the two never
 * interleave. The time spent nested is handed to the audio ISR: its load figures stay render-only.
 * (After Felucca 1.0.) */
#if KARMA_T5_RAM                                /* (3.1.5) RAM code reaches XIP only through a pointer (a direct call
                                                 * spans too far): the two 2 kHz polls stay in XIP */
static void (*volatile const t5_usb_poll)(void) = usb_poll;
#if FELUCCA_UART
static void (*volatile const t5_uart_poll)(void) = uart_midi_poll;
#endif
#else
#define t5_usb_poll usb_poll
#define t5_uart_poll uart_midi_poll
#endif
FM1_HOT void fm1_timer5_irq(void)
{
    static uint32_t sub, owed;
    uint32_t t0 = fm1_ticks(), usb_due = sub % 5u == 0u;
    fm1_timer5_ack();
    felucca_dbg.timer_irqs++;
    fm1_input_tick();
    {   /* milliseconds from the 24 MHz TIMER4 (robust to a late tick) */
        static uint32_t last, acc;
        acc += t0 - last;
        last = t0;
        while (acc >= 1000u * FM1_TICKS_PER_US) {
            acc -= 1000u * FM1_TICKS_PER_US;
            fm1_ms++;
        }
    }
    if (usb_due)
        owed |= 1u;                             /* 2 kHz: all USB SIE traffic lives here */
#if FELUCCA_UART
    if (sub % 5u == 2u)
        owed |= 2u;                             /* 2 kHz: <= ~7 bytes per call at 31250 baud */
#endif
    if (++sub == 10u)
        sub = 0;
    if (felucca_dbg.in_audio) {
        felucca_dbg.nested++;
#if FELUCCA_UAC
        uac_service();                          /* (every tick: KARMA 3.0 after JIANT FM 0.9.10, the stems' packets) */
#endif
        t5_nested_ticks += fm1_ticks() - t0;
        t5_all_ticks += fm1_ticks() - t0;
        return;
    }
    if (owed & 1u)
        t5_usb_poll();
#if FELUCCA_UAC
    uac_service();                              /* (3.1.5: here, not at usb_poll's end: it runs from RAM) */
#endif
#if FELUCCA_UART
    if (owed & 2u)
        t5_uart_poll();
#endif
    owed = 0;
    t5_all_ticks += fm1_ticks() - t0;
}
extern void isr_timer5(void);

static void timer5_start(void)                 /* OSC /4 = 6 MHz, PRD 600 -> 10 kHz */
{
    /* above ALNK0 (3): the tick may nest into the audio render (a few us; plain registers, the
     * MIDI rings are single-producer / single-consumer). Below it, a tick waited for the render
     * and the column it had lit stayed on longer: the LEDs shimmered, beating against the audio
     * blocks (1378 / s against the 909 / s scan) */
    fm1_timer5_start(isr_timer5, 4);
}

static void hexs(char *b, uint32_t v)
{
    uint32_t i;
    for (i = 0; i < 8u; i++)
        b[i] = "0123456789ABCDEF"[(v >> (28u - 4u * i)) & 15u];
    b[8] = 0;
}

static void fm1_fault(const fm1_crash_t *c)
{
    char b[12];
    uint32_t t0;
#if KARMA_DUAL_CORE
    if (audio_worker_online)
        fm1_core1_bar_set();                            /* (CPU0 crashed with CPU1 working: one core until power-off) */
#endif
    fm1_audio_stop();
    lcd_fill(0, 0, 240, 240, RGB(160, 0, 0));
    draw_text_box(0, 8, 240, &FONT_S, "FELUCCA CRASH", C_WHITE, 1);
    hexs(b, c->vec);
    draw_text_box(10, 40, 220, &FONT_S, b, C_WHITE, 0);
    hexs(b, c->pc);
    draw_text_box(10, 60, 220, &FONT_S, b, C_WHITE, 0);
    hexs(b, c->emu);
    draw_text_box(10, 84, 220, &FONT_S, b, C_WHITE, 0);
    hexs(b, c->dbg);
    draw_text_box(10, 102, 220, &FONT_S, b, C_WHITE, 0);
    hexs(b, c->rets);
    draw_text_box(10, 120, 220, &FONT_S, b, C_WHITE, 0);
    t0 = fm1_ticks();
    while ((uint32_t)(fm1_ticks() - t0) < 4000u * 1000u * FM1_TICKS_PER_US)
        ;
    fm1_reboot();
}

/* power-on: three parts with their default sounds (TRK_DEF), the drum track, empty patterns */
static void felucca_init(void)
{
    uint32_t i;
    for (i = 0; i < G_COUNT; i++)
        song.g[i] = GP[i].def;
    for (i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        track_defaults(t);
        if (i < NPART) {
            set_engine_of(t, TRK_DEF[i][0]);
            apply_preset_to(t, TRK_DEF[i][1]);   /* with its sends */
            t->engine = t->eng_req;
        }
        track_defaults_steps(t);              /* the sequencers start empty */
    }
    TDRUM->p[P_E0] = DRUM_DEFAULT_KIT;        /* the 808 kit */
    song.sel = 0;
    song.master_q12 = 2048;
    autosave_resume();                        /* the project as it was left (project.c) */
    song.g[G_SYNC] = (int16_t)lights_sync;    /* a setting of the FM-1 (panel.c) */
    song.g[G_MIDI] = (int16_t)lights_mout;
    song.g[G_ROUTE] = (int16_t)lights_min;
    song.g[G_KNOBS] = (int16_t)midi_knobs;
    song.g[G_CH1] = midi_set[0], song.g[G_CH2] = midi_set[1], song.g[G_CH3] = midi_set[2];   /* (2.6: GLO > MIDI, */
    song.g[G_DRCH] = midi_set[3], song.g[G_CHOTH] = midi_set[4], song.g[G_BEND] = midi_set[5];   /* settings of the FM-1) */
    layers_init();                            /* the panel's layer buttons for the keys (ui_layers.c) */
    go_home();
    ui.force = 1;
}

static void fm1_main(void)
{
    int32_t knob = 512 * 16;
    uint32_t healthy_since;
    persist_boot();
#if FELUCCA_OTA
    if (flash_ok)
        ota_boot_cleanup();                             /* staging area left by an update */
#endif
    settings_init();
    lcd_init();
    lcd_fill(0, 0, 240, 240, C_BLACK);                  /* (no logo screen first: 2026-10-28, Ariel; the credits are in
                                                         * MENU > ABOUT) */
    boot_t = 0;                                         /* the boot animation (ui_vis.c), the UI's first ~2.5 s */
    if (felucca_dbg.magic != DBG_MAGIC) {
        memset(&felucca_dbg, 0, sizeof felucca_dbg);
        felucca_dbg.magic = DBG_MAGIC;
    }
    felucca_dbg.boots++;
    felucca_dbg.max_us = 0;
    felucca_dbg.in_audio = 0;                       /* .noinit: a reset inside the audio ISR left it set, and
                                                       TIMER5 would treat every tick as nested (no USB poll) */
    felucca_dbg.prev_stage = felucca_dbg.stage;     /* a WDT reset leaves the last breadcrumb here */
    felucca_dbg.prev_page = felucca_dbg.page;
    felucca_dbg.prev_home = felucca_dbg.home;
    felucca_dbg.prev_frames = felucca_dbg.ui_frames;
    felucca_dbg.prev_rst = fm1_boot.p3_rst;
    fm1_input_init();
    fm1_adc_init();
    panel_init();
    felucca_init();
#if KARMA_DUAL_CORE
    if (!fm1_core1_barred())                            /* (retired earlier this session: one core until power-off) */
        fm1_multicore_start();                          /* CPU1 up: a bounded handshake, else one core */
    fm1_guard_enable(FM1_GUARD_PC);                     /* (CPU1 boots through mask ROM: the PC limits after it) */
#endif
    audio_init();
#if FELUCCA_CDC
    usb_cdc_on = usb_serial;                            /* menu USB SERIAL (persist_boot read it): before USB starts */
#endif
#if FELUCCA_UAC
    usb_stems = (uint8_t)(FELUCCA_UAC_STEMS && usb_stems_set);   /* menu USB AUDIO = STEMS: 6 channels, no console */
#if FELUCCA_CDC
    if (usb_stems)
        usb_cdc_on = 0;
#endif
#endif
#if FELUCCA_UAC
    usb_ring_clear();                                   /* (3.1.5: the ring is in RAM's code space, FM1_RAMBSS) */
#endif
    usb_start();
#if FELUCCA_UART
    uart_midi_init();
#endif
    timer5_start();
    fm1_guard_lock_top();
    fm1_irq_enable_all();
    fm1_delay_ms(30);
    if ((fm1_in.buttons & 3u) == 3u) {
        panel_setup();                        /* OCT- + OCT+ held at power-on */
        settings_save();
    }
    healthy_since = fm1_ms;                             /* (no 0.9 s for a logo any more: the boot animation, 2026-10-28) */
    for (;;) {
        uint32_t m = fm1_ms;
        fm1_wdt_feed();
#if KARMA_DUAL_CORE
        fm1_core1_poll();                               /* (a worker retired: one core until power-off) */
#endif
        usb_retry(fm1_ms);
        if ((uint32_t)(m - healthy_since) >= 30000u && bootguard.pending) {
            bootguard_clear(&bootguard);     /* 30 s of this boot, even if TIMER4 survived reset */
        }
        {
            int32_t b = fm1_adc_read(FM1_ADC_BATT);     /* battery: slow IIR */
            if (b > 0)
                song.batt_raw = song.batt_raw ? song.batt_raw + (b - song.batt_raw) / 32 : b;
        }
        {
            static int32_t applied = -100;
            int32_t a = fm1_adc_read(FM1_ADC_MASTER);
            if (a >= 0) {
                uint32_t k10;
                knob += (a * 16 - knob) / 8;
                k10 = (uint32_t)(knob / 16);
                if ((int32_t)k10 - applied > 6 || applied - (int32_t)k10 > 6) {   /* (moved: a MIDI controller's
                                                         * MASTER, KNOBS = PANEL, holds until the pot turns) */
                    applied = (int32_t)k10;
                    song.master_q12 = (k10 * k10) >> 8;        /* 0 .. ~4096 */
                }
            }
        }
        {   /* OCT- + OCT+ held 5 s, stopped: enter UBOOT with RAM intact (debug / update); a countdown
             * shows from 2 s, letting go cancels it. Not while playing: on the drum track these are the
             * ghost / hard modifiers, held for a long time */
            static uint32_t t0, shown;
            uint32_t both = (1u << panel.btn[B_OCTDN]) | (1u << panel.btn[B_OCTUP]);
            if ((fm1_in.buttons & both) != both || song.playing) {
                if (shown)
                    ui_say("UPDATE MODE ", "CANCELLED");
                shown = 0;
                t0 = fm1_ms;
            } else if (fm1_ms - t0 > 2000u && fm1_ms - t0 <= 5000u) {
                uint32_t left = (5000u - (fm1_ms - t0) + 999u) / 1000u;
                if (left != shown) {
                    char d[4] = {(char)('0' + left), '.', '.', 0};
                    ui_say("UPDATE MODE IN ", d);
                    shown = left;
                }
            } else if (fm1_ms - t0 > 5000u) {
                fm1_audio_stop();
#if FELUCCA_ARRANGER
                persist_flush_now();                    /* (live sections, song, project: RAM-only so far) */
#endif
                lcd_fill(0, 0, 240, 240, C_BLACK);
                draw_text_box(0, 110, 240, &FONT_S, "UBOOT", RGB(80, 120, 255), 1);
                usb_detach();
                fm1_delay_ms(30);
                bootguard.pending = 0;                  /* intentional reset: not a failed boot */
                fm1_enter_uboot();
            }
        }
#if FELUCCA_OTA
#if KARMA_ANN
        {   /* a screen reader's SysEx (announce.c), before the editor and the updater look */
            const uint8_t *p;
            uint32_t n;
            if (ota_frame_get(&p, &n) && ann_frame(p, n, fm1_ms))
                ota_frame_done();
        }
#endif
        ed_service();                                   /* web editor SysEx */
        ota_service();                                  /* M-UPGRADE handshake */
        if (usb.ota_req) {                              /* M-UPGRADE upgrade command */
            usb.ota_req = 0;
            panic_req = (1u << NTRK) - 1u;               /* every track (bit per track) */
#if FELUCCA_ARRANGER
            persist_flush_now();                        /* an update ends in a reset: RAM-only work first */
#endif
            if (flash_ok)
                ota_session();                          /* returns only if nothing was committed */
            lcd_fill(0, 0, 240, 240, C_BLACK);
            ui.force = 1;
        }
#endif
        if (usb.uboot_req) {                            /* SysEx F0 22 24 35 7D F7 from the host */
            fm1_audio_stop();
#if FELUCCA_ARRANGER
            persist_flush_now();                    /* (live sections, song, project: RAM-only so far) */
#endif
            lcd_fill(0, 0, 240, 240, C_BLACK);
            draw_text_box(0, 110, 240, &FONT_S, "UBOOT (USB)", C_WHITE, 1);
            fm1_delay_ms(20);
            usb_detach();
            fm1_delay_ms(30);
            bootguard.pending = 0;
            fm1_enter_uboot();
        }
#if FELUCCA_CDC
        cdc_task();
#endif
        felucca_dbg.ui_frames++;
        felucca_dbg.page = ui.page;
        felucca_dbg.home = ui.home;
        felucca_dbg.stage = 1;
        ui_input();
        felucca_dbg.stage = 2;
        ui_leds();
        ui_draw();
#if KARMA_ANN
        speak(fm1_ms);                                  /* the screen reader: what changed */
        ann_tick(fm1_ms);
#endif
        felucca_dbg.stage = 8;
        autosave_tick();                                /* the working project into flash, when quiet */
#if FELUCCA_ARRANGER
        sections_flush();                               /* live sections / the recorded song, when quiet */
#endif
        felucca_dbg.stage = 9;
        while (fm1_ms - m < 15u) {                               /* ~60 UI frames/s at most */
            ui_input();
#if FELUCCA_OTA
#if KARMA_ANN
            {
                const uint8_t *p;
                uint32_t n;
                if (ota_frame_get(&p, &n) && ann_frame(p, n, fm1_ms))
                    ota_frame_done();
            }
#endif
            ed_service();                       /* editor replies without waiting for the next frame */
#endif
        }
    }
}

void fm1_cstart(void)
{
    uint32_t *s, *d, p3, src, wdt, boot_mode;
    fm1_time_init();
    fm1_core1_stop();                                   /* (KARMA_DUAL_CORE: CPU1 held before RAM is cleared) */
    fm1_reset_reason();
    p3 = fm1_boot.p3_rst;
    src = fm1_boot.rst_src;
    wdt = fm1_boot.wdt_con;
    fm1_wdt_arm(0x0D);
    if ((p3 & 1u) && !(p3 & (4u | 0x40u)))
        bootguard_clear(&bootguard);           /* a power-on (not a watchdog or soft reset): no failed boot to count */
    boot_mode = bootguard_begin(&bootguard);
    if (boot_mode == BOOT_ROM) {
        fm1_enter_uboot();
    }
    fm1_irq_init();
    for (d = _bss_start; d < _bss_end; d++)
        *d = 0;
    for (d = _pool_start; d < _pool_end; d++)
        *d = 0;
    for (s = _data_load, d = _data_start; d < _data_end; s++, d++)
        *d = *s;
    for (s = _rt_load, d = _rt_start; d < _rt_end; s++, d++)
        *d = *s;                                /* flash driver code that must run from RAM */
    fm1_mailbox_clear();
    fm1_guard_enable(FM1_GUARD_STACK | FM1_GUARD_WRITE | FM1_GUARD_BUS | (KARMA_DUAL_CORE ? 0u : FM1_GUARD_PC));
    fm1_boot.p3_rst = (uint8_t)p3;
    fm1_boot.rst_src = src;
    fm1_boot.wdt_con = (uint8_t)wdt;
#if FELUCCA_OTA
    if (boot_mode == BOOT_RECOVERY || recovery_key())
        recovery_main();
#else
    if (boot_mode == BOOT_RECOVERY) fm1_enter_uboot();
#endif
    fm1_main();
    for (;;)
        ;
}
