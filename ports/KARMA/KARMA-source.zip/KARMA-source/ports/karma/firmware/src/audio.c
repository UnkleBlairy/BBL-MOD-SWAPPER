/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
 * Portions Copyright (C) 2026 Juan Ignacio Antonucci (Juan Jiant): the USB STEMS capture / the half acked first (JIANT FM) */
/* I2S output (ALNK0 -> external codec) and the audio ISR: each half buffer is
 * rendered in blocks of CTL samples by mix_block (fx.c: events -> each synth part
 * -> dist -> level / pan -> sends -> drums -> buses -> master), then scaled to 24-bit stereo. */
/* registers: hal/fm1_audio.h */
#define HALF_WORDS (HALF_FRAMES * 2u)
#define OUT_SHIFT 7               /* Q15 -> 24-bit, -6 dBFS ceiling */

static int32_t abuf[2u * HALF_WORDS] __attribute__((aligned(32)));   /* (DMA: 32-byte lines, as M-VAVE's) */
#if FM1_AUDIO_RX_CLOCK
static int32_t abuf_rx[2u * HALF_WORDS] __attribute__((aligned(32)));   /* the RX channel's, unused: its pendings are the clock */
#endif
/* before a flash erase or program (fm1_flash.h FL_QUIET): the halves the DMA loops while the interrupts are off,
 * silent */
static void audio_dma_silence(void)
{
    uint32_t i;
    for (i = 0; i < 2u * HALF_WORDS; i++)
        abuf[i] = 0;
}

/* diagnostics, kept across resets and UBOOT entry: read with `fm1t memr` */
#define DBG_MAGIC 0x44424731u                       /* "DBG1" */
struct felucca_dbg {
    uint32_t magic, halves, max_us, nested;
    volatile uint32_t in_audio;           /* TIMER5 reads it to decide what may nest in the render */
    uint32_t late, timer_irqs, ui_frames;
    uint32_t last_us, cpu_q8, boots;
    uint32_t stage, page, home;           /* where the main loop is (breadcrumbs) */
    uint32_t prev_stage, prev_page, prev_home, prev_rst, prev_frames;   /* as found at boot */
} felucca_dbg __attribute__((unused));
static volatile uint32_t audio_halves, audio_max_us;
static volatile uint32_t t5_nested_ticks;              /* TIMER4 ticks TIMER5 spent nested in this ISR (main.c) */
static uint32_t t5_all_ticks;                          /* (3.1.5) TIMER4 ticks spent in TIMER5, all of it (editor ED_STAT) */
#define SCOPE_N 512u
static int16_t scope_buf[SCOPE_N], scope_bufr[SCOPE_N];   /* left, right (the visualiser): the mix at full level */
static uint32_t scope_w;

static void audio_block(int32_t *out, uint32_t n)       /* mix (fx.c), then Q15 -> 24 bit */
{
    uint32_t i;
    mix_block(out, n);
#if FELUCCA_UAC
    if (fx_stems)
        uac_tap6(n);                                    /* menu USB AUDIO = STEMS: 6 channels (fx.c stem_buf) */
    else
        uac_tap(usb_full_now ? usb_out : out, n);       /* the USB audio input: the master output, or at full level */
#endif
    for (i = 0; i < n; i++) {
        if (i & 1u)
        {
            scope_bufr[scope_w & (SCOPE_N - 1u)] = vis_tap[2u * i + 1u];   /* (fx.c: MASTER all the way up) */
            scope_buf[scope_w++ & (SCOPE_N - 1u)] = vis_tap[2u * i];
        }
        out[2u * i] <<= OUT_SHIFT;
        out[2u * i + 1u] <<= OUT_SHIFT;
    }
}

static uint32_t audio_lost;                     /* halves rendered twice in a row: one was lost (a late render) */
static uint8_t audio_last_half = 0xFF;
/* overload: shed_voice (voice.c) */
static volatile uint8_t shed_req;
static uint8_t shed_over;                      /* bit k: the half k halves ago was over 85 % */
static uint8_t shed_hot;                       /* (3.1.3) bit k: ... over 95 % */

void fm1_alnk0_irq(void)                       /* via isr_alnk0 (hal/fm1_isr.S) */
{
    uint8_t p;
    uint32_t t0;
    felucca_dbg.in_audio = 1;                   /* first: TIMER5 nests from here on (main.c) */
    p = fm1_audio_pending();
    t0 = fm1_ticks();
    t5_nested_ticks = 0;
    fm1_audio_ack_aux(p);
    if (p & FM1_AUDIO_HALF) {
        uint32_t half = fm1_audio_free_half(), b, us;
        int32_t *o = &abuf[half * HALF_WORDS];
        fm1_audio_ack_half();                           /* first (KARMA 3.0, after JIANT FM 0.8.9): a flip during a late
                                                         * render stays pending and this ISR runs again for the other
                                                         * half at once; acked after the render, every late half lost the
                                                         * next one (its stale audio played again, USB packets short) */
        if (half == audio_last_half)
            audio_lost++;
        audio_last_half = (uint8_t)half;
        if (shed_req) {
            shed_voice(shed_req > 1u);                  /* (3.1.3) 1 = light (effects, quiet tails), 2 = notes too */
            shed_req = 0;
        }
#if FELUCCA_UAC
        uac_render_start();
        usb_full_now = (uint8_t)(usb_full && uac.feed);  /* menu USB AUDIO = FULL, while the computer records */
        fx_stems = (uint8_t)(usb_stems && uac.feed);    /* menu USB AUDIO = STEMS, while the computer records */
#endif
        for (b = 0; b < HALF_FRAMES; b += CTL)
            audio_block(o + 2u * b, CTL);
        audio_halves++;
        {   /* the deadline sees the render and TIMER5 nested in it (the USB audio stream); the load
             * figures the render alone (after Felucca 1.0) */
            uint32_t all = fm1_ticks() - t0;
            us = (all - t5_nested_ticks) / FM1_TICKS_PER_US;
            uint32_t pct = all / FM1_TICKS_PER_US * 100u;   /* (no divide more in the ISR) */
            shed_over = (uint8_t)(shed_over << 1 | (pct > (HALF_FRAMES * 1000000u / FS) * 85u));
            shed_hot = (uint8_t)(shed_hot << 1 | (pct > (HALF_FRAMES * 1000000u / FS) * 95u));
        }
        if (us > audio_max_us)
            audio_max_us = us;
        if ((shed_hot & 3u) == 3u || fm1_audio_free_half() != half)
            shed_req = 2;                               /* (3.1.3) two in a row over 95 %, or this one late: a note */
        else if ((shed_over & 3u) == 3u)
            shed_req = 1;                               /* two in a row over 85 %: effects and quiet tails only
                                                         * (Ariel 2026-11-14: OMEN BELL + drums lost notes at ~85 %) */
        {
            int calm_no = (int)(shed_over & 1u) | guard_hold_half();   /* (3.1.5 test 12: not in a stop's first ~10 s) */
            drum_calm_half(calm_no);                    /* (3.1.2: the drums' voices come back after ~2 s calm, */
            cloud_calm_half(calm_no);                   /*  the CLOUD's grains after ~1 s, */
            modal_calm_half(calm_no);                   /*  MODAL's modes after ~1 s) */
        }
        song.cpu_q8 = (song.cpu_q8 * 15u + (us * 256u) / (HALF_FRAMES * 1000000u / FS)) / 16u;
        if (fm1_audio_free_half() != half)
            felucca_dbg.late++;                         /* the DMA moved on while we rendered */
        felucca_dbg.halves++;
        felucca_dbg.last_us = us;
        if (us > felucca_dbg.max_us)
            felucca_dbg.max_us = us;
        felucca_dbg.cpu_q8 = song.cpu_q8;
    }
    felucca_dbg.in_audio = 0;
}
extern void isr_alnk0(void);

static void audio_init(void)                   /* hal/fm1_audio.h */
{
    uint32_t i;
    for (i = 0; i < 2u * HALF_WORDS; i++)
        abuf[i] = 0;
#if FM1_AUDIO_RX_CLOCK
    fm1_audio_init(abuf, HALF_WORDS, isr_alnk0, 3, abuf_rx);
#else
    fm1_audio_init(abuf, HALF_WORDS, isr_alnk0, 3, 0);
#endif
}
