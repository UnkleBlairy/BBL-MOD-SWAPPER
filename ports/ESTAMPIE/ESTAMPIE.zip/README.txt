ESTAMPIE 0.4.0 for the BBL Mod Swapper

Original by ocean: https://github.com/ocean/estampie
Licence: GPL (the original's). Ported by Blairy (blairysbeatlab).
Status: UNTESTED on hardware.

Copy the ROMS folder to the top of your SD card. Keep all three files.
Source for this build: ESTAMPIE-source.zip on the ports page.
