/* SPDX-License-Identifier: GPL-3.0-only */
/* The palettes and the real canvas/text renderer (src/gfx.c): GREY stays gray in every token and blend, MONO is
 * black and white in every token (one grey: DIM LINE RAISE LANE) and neutral in every blend,
 * every palette's text contrast, the alpha blend, the ramp cache, the fonts' metrics and the ellipsis.
 * Optional: a palette sheet (PPM). */
#include <stdint.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string.h>
#define __attribute__(x)
static void lcd_sync(void) {}
static void lcd_power(uint32_t s) { (void)s; }   /* (MENU > SCREEN OFF: lcd.c) */
static void lcd_wake_now(void) {}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *p)
{ (void)x; (void)y; (void)w; (void)h; (void)p; }
#include "../firmware/src/gfx.c"

#define SHEET_W 960u
#define SHEET_H (((NPALETTES + 3u) / 4u) * 124u)
static uint16_t sheet[SHEET_W * SHEET_H];
static unsigned channel(uint16_t c, unsigned n)
{ return n == 0 ? c >> 11 : n == 1 ? (c >> 5) & 63 : c & 31; }
static int gray(uint16_t c) { return channel(c, 0) == channel(c, 2) && channel(c, 1) == channel(c, 0) * 2u; }
/* MONO's blends: R = B, G within 2 of 2 R (blended per channel, the 5-6-5 rounding) */
static int neutral(uint16_t c)
{ return channel(c, 0) == channel(c, 2) && (int)channel(c, 1) - 2 * (int)channel(c, 0) >= -2 && (int)channel(c, 1) - 2 * (int)channel(c, 0) <= 2; }
static double luminance(uint16_t color)
{
    const double weight[] = {0.2126, 0.7152, 0.0722};
    double result = 0;
    for (unsigned c = 0; c < 3; c++) {
        double v = channel(color, c) / (c == 1 ? 63.0 : 31.0);
        result += weight[c] * (v <= 0.04045 ? v / 12.92 : pow((v + 0.055) / 1.055, 2.4));
    }
    return result;
}
static double contrast(uint16_t fg, uint16_t bg)
{
    double a = luminance(fg), b = luminance(bg);
    return a > b ? (a + 0.05) / (b + 0.05) : (b + 0.05) / (a + 0.05);
}

int main(int argc, char **argv)
{
    static const aag_t pg[1] = {{0, 48, 0, 0, 3, 1}};   /* one glyph 'A': 3 px, alpha 0, 8, 15 */
    static const uint8_t pd[] = {0x08, 0xf0};
    const aafont_t probe = {1, 1, 'A', 'A', 0, 0, pg, pd, 0, 0, 0};
    double worst = 100;
    assert(NPALETTES == 13u && !strcmp(UI_PALETTES[0].name, "GREY") && !strcmp(UI_PALETTES[7].name, "HI-CON") &&
           !strcmp(UI_PALETTES[8].name, "CRYPT") && UI_CRYPT_INDEX == 8u &&
           !strcmp(UI_PALETTES[9].name, "NIGHT") && !strcmp(UI_PALETTES[10].name, "MONO") && UI_BW_INDEX == 10u &&
           !strcmp(UI_PALETTES[11].name, "VELLUM") && UI_VELLUM_INDEX == 11u &&
           !strcmp(UI_PALETTES[12].name, "TAVERN") && UI_TAVERN_INDEX == 12u);
    /* (#50, 1.0.2: appended, the ids stay; GREY is the MONO of 1.0.1, id 0; GHOULBOX's CRYPT keeps its id 8;
     * ESTAMPIE's VELLUM and TAVERN are appended as ids 11 and 12) */
    for (unsigned st = ST_FLAT; st <= ST_LINE; st++) {   /* MONO: every token black or white, in FLAT and LINE */
        uint16_t *tok = &ux.bg;
        ux.style = (uint8_t)st;
        palette_set(UI_BW_INDEX);
        assert(&ux.grid - tok == 15);
        for (unsigned i = 0; i < 16; i++) {
            /* the one grey: DIM (inactive), LINE (tracks), RAISE (wells under white text), LANE (the piano roll) */
            int grey_ok = tok[i] == UI_BW_GREY && (&tok[i] == &ux.dim || &tok[i] == &ux.line || &tok[i] == &ux.raise ||
                                                   &tok[i] == &ux.lane);
            if (!(tok[i] == 0x0000u || tok[i] == 0xFFFFu || grey_ok))
                printf("MONO (%s): token %u = %04x is not black or white\n", st ? "LINE" : "FLAT", i, tok[i]);
            assert(tok[i] == 0x0000u || tok[i] == 0xFFFFu || grey_ok);
        }
        assert(T_BG == 0u && T_SURF == 0u && T_TEXT == 0xFFFFu && T_SEL == 0xFFFFu && T_INK == 0u && T_REC == 0xFFFFu);
        assert(T_STONE == 0u && T_EDGE == UI_BW_GREY);   /* GHOULBOX's stone: black specks, the grey outer line */
    }
    ux.style = ST_FLAT;
    for (unsigned p = 0; p < NPALETTES; p++) {
        uint16_t *tok = &ux.bg;
        palette_set(p);
        if (p == UI_GREY_INDEX)
            for (unsigned i = 0; i < 14; i++) assert(gray(tok[i]));      /* every token, derived ones too (RAISE, KEY the last) */
        if (p == UI_GREY_INDEX)
            assert(gray(T_STONE) && gray(T_EDGE));                     /* GHOULBOX's tokens too */
        assert(contrast(T_TEXT, T_STONE) >= 7.0 && contrast(T_THEME, T_STONE) >= 3.5);   /* text on the stone */
        /* text and the things read on the screen; the generator checks the same (tools/gen_ui_palettes.py) */
        struct { uint16_t fg, bg; double min; } c[] = {
            {T_TEXT, T_BG, 12.0}, {T_TEXT, T_SURF, 9.0}, {T_MID, T_BG, 5.0}, {T_MID, T_SURF, 4.0},
            {T_THEME, T_BG, 4.5}, {T_THEME, T_SURF, 4.5}, {T_ACCENT, T_BG, 4.5}, {T_ACCENT, T_SURF, 4.5},
            {T_INK, T_SEL, 4.5}, {T_INK, T_THEME, 4.5}, {T_DIM, T_BG, 2.2}, {T_LINE, T_BG, 1.25}, {T_REC, T_BG, 3.0},
            {T_INK, T_KEY, 4.5}, {T_KEY, T_BG, 3.0}, {T_KEY, T_SURF, 2.5}, {T_INK, T_DIM, 1.8}, {T_INK, T_ACCENT, 4.5},
            {T_TEXT, T_RAISE, 7.0}};
        double min = 100;
        for (unsigned i = 0; i < sizeof c / sizeof c[0]; i++) {
            double r = contrast(c[i].fg, c[i].bg);
            if (r < c[i].min) printf("%s: pairing %u contrast %.2f < %.2f\n", UI_PALETTES[p].name, i, r, c[i].min);
            assert(r >= c[i].min);
            if (r / c[i].min < min) min = r / c[i].min;
        }
        if (min < worst) worst = min;
        printf("%-7s text %.1f:1, labels %.1f:1, values %.1f:1, selection %.1f:1\n", UI_PALETTES[p].name,
               contrast(T_TEXT, T_BG), contrast(T_MID, T_BG), contrast(T_THEME, T_BG), contrast(T_INK, T_SEL));
        assert((p == 6u || p == UI_VELLUM_INDEX) == ux.light);   /* PAPER and VELLUM are the light ones */
        assert(T_REC == (p == UI_GREY_INDEX || p == UI_BW_INDEX ? T_ACCENT : ux.light ? UI_REC_LIGHT : UI_REC_DARK));
        /* the blend: transparent, solid and an edge between the two, on two backgrounds */
        for (unsigned b = 0; b < 2; b++) {
            uint16_t under = b ? T_SEL : T_BG, ink = b ? T_INK : T_THEME;
            cv_begin(3, 1, under);
            cv_text_on(0, 0, &probe, "A", ink, under);
            assert(swap16(cv_px[0]) == under && swap16(cv_px[2]) == ink);
            for (unsigned k = 0; k < 3; k++) {
                unsigned a = channel(under, k), z = channel(ink, k), m = channel(swap16(cv_px[1]), k);
                assert(m >= (a < z ? a : z) && m <= (a > z ? a : z));   /* no halo */
            }
            if (p == UI_GREY_INDEX) assert(gray(swap16(cv_px[1])));
            if (p == UI_BW_INDEX) assert(neutral(swap16(cv_px[1])));
        }
        assert(text_w(&AF_S, UI_PALETTES[p].name) <= 60);     /* the COLOR row's value */
        cv_begin(240, 124, T_BG);
        cv_text(4, 2, &AF_M, UI_PALETTES[p].name, T_TEXT);
        for (unsigned k = 0; k < 5; k++) cv_rect(150 + k * 16, 4, 12, 12, tok[k]);
        cv_text(4, 26, &AF_S, "LABEL", T_MID);
        cv_text(70, 22, &AF_M, "VALUE 127", T_THEME);
        cv_text(170, 22, &AF_M, "HOT", T_ACCENT);
        cv_text(4, 46, &AF_S, "INACTIVE", T_DIM);
        cv_rect(80, 44, 150, 17, T_SEL);
        cv_text_on(86, 45, &AF_S, "SELECTED ROW", T_INK, T_SEL);
        cv_rect(4, 66, 232, 1, T_LINE);
        cv_rect(4, 72, 120, 3, T_LINE);
        cv_rect(4, 72, 70, 3, T_SEL);
        cv_rect(74, 70, 1, 7, T_THEME);
        cv_text(136, 66, &AF_S, "REC", T_REC);
        cv_text(4, 82, &AF_L, "124", T_THEME);
        cv_text(80, 92, &AF_S, "Mixed case text", T_TEXT);
        cv_key_hint(80, 108, KC_OCTUP, "LOAD", 1, T_BG);          /* keycaps: available, unavailable */
        cv_key_hint(150, 108, KC_OCTDN, "BACK", 0, T_BG);
        for (unsigned y = 0; y < 124; y++)
            for (unsigned x = 0; x < 240; x++) {
                uint16_t v = swap16(cv_px[y * 240 + x]);
                if (p == UI_GREY_INDEX) assert(gray(v));          /* every blended pixel of GREY */
                if (p == UI_BW_INDEX) assert(neutral(v));         /* and of MONO */
                sheet[(p / 4 * 124 + y) * 960 + p % 4 * 240 + x] = v;
            }
    }
    /* the ramp cache follows the palette (a stale ramp would blend toward the old background) */
    palette_set(1);
    cv_begin(3, 1, T_BG); cv_text(0, 0, &probe, "A", T_THEME);
    uint16_t green = swap16(cv_px[1]);
    palette_set(6);
    cv_begin(3, 1, T_BG); cv_text(0, 0, &probe, "A", T_THEME);
    assert(swap16(cv_px[1]) != green);
    /* fonts: Alegreya Sans S 14 px and M 16 px, Cinzel L 26 px (ESTAMPIE; GHOULBOX: VT323 throughout; Felucca: Inter
     * Tight 12 / 15 / 28); tabular digits; the ellipsis; L has capitals only */
    assert(AF_S.h == 16 && AF_S.asc == 12 && AF_M.h == 20 && AF_M.asc == 15 && AF_L.h == 36 && AF_L.asc == 26);
    assert(text_w(&AF_M, "0000") == text_w(&AF_M, "1111") && text_w(&AF_S, "1.25") == text_w(&AF_S, "8.75"));
    assert(glyph(&AF_S, (uint8_t)ELLIPSIS) != glyph(&AF_S, '?') && glyph(&AF_M, (uint8_t)ELLIPSIS) != glyph(&AF_M, '?'));
    assert(text_w(&AF_L, "abc") == text_w(&AF_L, "ABC"));
    {
        char b[32];
        assert(!text_fit(b, sizeof b, "KICK", &AF_S, 60) && !strcmp(b, "KICK"));
        assert(text_fit(b, sizeof b, "A VERY LONG PRESET NAME", &AF_S, 60) && text_w(&AF_S, b) <= 60);
        assert(b[strlen(b) - 1] == ELLIPSIS && b[strlen(b) - 2] != ' ');
        assert(text_fit(b, sizeof b, "WWWWWWWW", &AF_M, 1) && b[0] == ELLIPSIS && !b[1]);
    }
    if (argc > 1) {
        FILE *f = fopen(argv[1], "wb"); assert(f);
        fprintf(f, "P6\n%u %u\n255\n", (unsigned)SHEET_W, (unsigned)SHEET_H);
        for (unsigned i = 0; i < SHEET_W * SHEET_H; i++) {
            fputc(channel(sheet[i], 0) * 255 / 31, f);
            fputc(channel(sheet[i], 1) * 255 / 63, f);
            fputc(channel(sheet[i], 2) * 255 / 31, f);
        }
        fclose(f);
    }
    {   /* GHOULBOX primitives */
        static uint16_t a[60 * 40], b[60 * 40];
        palette_set(UI_CRYPT_INDEX);
        cv_begin(60, 40, T_BG);
        cv_window(0, 0, 60, 40, 3);
        memcpy(a, cv_px, sizeof a);
        cv_begin(60, 40, T_BG);
        cv_window(0, 0, 60, 40, 3);
        assert(!memcmp(a, cv_px, sizeof a));                           /* the same every time: no flicker */
        assert(swap16(cv_px[0]) == T_ACCENT && swap16(cv_px[59]) == T_ACCENT);   /* corner studs */
        assert(swap16(cv_px[20 * 60 + 0]) == T_EDGE);                  /* the outer line */
        assert(swap16(cv_px[20 * 60 + 2]) == T_THEME);                 /* the border */
        {
            unsigned specks = 0, other = 0;
            for (unsigned y = 3; y < 37; y++)
                for (unsigned x = 3; x < 57; x++) {
                    uint16_t c = swap16(cv_px[y * 60 + x]);
                    specks += c == T_STONE;
                    other += c != T_STONE && c != T_SURF;
                }
            assert(specks > 50 && specks < 600 && !other);             /* stone: SURF with specks, nothing else */
        }
        /* drawn as two canvases (the menu's passes), the texture continues across the seam */
        cv_begin(60, 40, T_BG);
        cv_stone(0, 0, 60, 40, 0, 0);
        memcpy(a, cv_px, sizeof a);
        cv_begin(60, 20, T_BG);
        cv_stone(0, 0, 60, 20, 0, 0);
        memcpy(b, cv_px, 60 * 20 * 2);
        cv_begin(60, 20, T_BG);
        cv_stone(0, 0, 60, 20, 0, 20);
        memcpy(b + 60 * 20, cv_px, 60 * 20 * 2);
        assert(!memcmp(a, b, sizeof a));
        {   /* a sprite: '.' leaves the canvas, digits pick colours */
            static const char *const R[2] = {"0.", ".1"};
            const uint16_t pal[2] = {T_THEME, T_ACCENT};
            cv_begin(2, 2, T_BG);
            cv_sprite(0, 0, R, 2u, pal);
            assert(swap16(cv_px[0]) == T_THEME && swap16(cv_px[1]) == T_BG && swap16(cv_px[3]) == T_ACCENT);
        }
        printf("primitives: window, stone (seamless), sprite ok\n");
    }
    {   /* ESTAMPIE: the UI faces are anti-aliased (Alegreya Sans; GHOULBOX's VT323 was crisp, its alpha only 0 or 15) */
        unsigned bad_alpha = 0;
        for (unsigned i = 0; i < sizeof AF_S_DATA; i++) {
            unsigned hi = AF_S_DATA[i] >> 4, lo = AF_S_DATA[i] & 15u;
            bad_alpha += (hi != 0u && hi != 15u) + (lo != 0u && lo != 15u);
        }
        printf("faces: S alpha values other than 0 / 15 (smoothing): %u\n", bad_alpha);
        assert(bad_alpha > 0u);
    }
    printf("Palettes: GREY gray, MONO black and white, contrast (worst margin x%.2f), blending, ramp cache, font metrics and ellipsis passed.\n", worst);
    return 0;
}
