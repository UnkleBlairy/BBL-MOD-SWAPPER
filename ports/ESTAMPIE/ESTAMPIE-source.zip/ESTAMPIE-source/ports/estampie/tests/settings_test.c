/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#define __attribute__(x)
#define NENGINES 9u
#define UP_SLOTS 32u
#define ENGI_SAMPLE 4u                           /* (core.h: SAMPLE, DRUM, the retired PERC set) */
#define ENGI_DRUM 10u
#define SMP_SET_PERC 4u
static uint8_t fx_lowcut;
static void fm1_led_key(unsigned k, int on) { (void)k; (void)on; }
static int fm1_enc_take(unsigned k) { (void)k; return 0; }
static void lcd_sync(void) {}
static void lcd_power(uint32_t s) { (void)s; }   /* (MENU > SCREEN OFF: lcd.c) */
static void lcd_wake_now(void) {}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *p)
{ (void)x; (void)y; (void)w; (void)h; (void)p; }
#include "../firmware/src/gfx.c"
#include "../firmware/src/panel.c"
static void settings_save(void) {}
#if __has_include("../firmware/src/favorites.c")
#include "../firmware/src/favorites.c"
#endif
#include "../firmware/src/settings_persist.c"
int main(void)
{
    persist_t original = {0}, p;
    original.magic = PERSIST_MAGIC;
    original.palette = 4; original.bold = original.lowcut = original.zoom = 1;   /* old id 4: MONO, now GREY */
    original.panel = PANEL_DEFAULT; original.panel.enc[0] = 3;
    original.favorites.factory[8][0] = 1;
    original.favorites.user = 1u << 31; original.favorites.filter = 1;
    {   /* GHOULBOX: USB SERIAL off once (MIDI hosts and macOS audio), favorites.factory[15][28] bit 0 marks it done */
        persist_t q = original;
        q.favorites.factory[15][30] = 0;  q.favorites.factory[15][28] = 0;             /* 1.0 / Felucca: ON, unmarked */
        assert(settings_import(&q, sizeof q) == 1 && (favorites.factory[15][30] & GB_SERIAL_OFF) &&
               (favorites.factory[15][28] & GB_MIG_SERIAL));
        q = original; q.favorites.factory[15][30] = 0; q.favorites.factory[15][28] = GB_MIG_SERIAL;   /* chose ON since */
        assert(settings_import(&q, sizeof q) == 1 && !(favorites.factory[15][30] & GB_SERIAL_OFF));
        q = original; q.favorites.factory[15][30] = GB_SERIAL_OFF | 16u; q.favorites.factory[15][28] = 0;   /* OFF, BPM LOCK */
        assert(settings_import(&q, sizeof q) == 1 &&
               (favorites.factory[15][30] & ~GB_RESTORE_OFF) == (GB_SERIAL_OFF | 16u));   /* (RESTORE: below) */
        memset(&favorites, 0, sizeof favorites);
        settings_fresh();                                                               /* a device never saved */
        assert((favorites.factory[15][30] & GB_SERIAL_OFF) && (favorites.factory[15][28] & GB_MIG_SERIAL));
        puts("settings: GHOULBOX USB SERIAL off once (unmarked ON -> OFF; marked ON kept; OFF kept; fresh OFF)");
    }
    {   /* GHOULBOX 1.5 set RESTORE LAST OFF once (factory[15][28] bit 1); 2.1 sets it back ON once (bit 2), after it */
        persist_t q = original;
        uint8_t all = GB_MIG_SERIAL | GB_MIG_RESTORE | GB_MIG_RESTORE_ON | GB_MIG_LEARN | GB_MIG_KT;   /* (ESTAMPIE: + MIDI
                                                                                     * LEARN's row, KEY TOUCH's row) */
        q.favorites.factory[15][30] = 0;  q.favorites.factory[15][28] = GB_MIG_SERIAL;   /* GHOULBOX 1.4: ON, unmarked */
        assert(settings_import(&q, sizeof q) == 1 && !(favorites.factory[15][30] & GB_RESTORE_OFF) &&
               favorites.factory[15][28] == all);
        q = original; q.favorites.factory[15][30] = GB_SERIAL_OFF | GB_RESTORE_OFF;     /* 1.5 .. 2.0: OFF: ON once */
        q.favorites.factory[15][28] = GB_MIG_SERIAL | GB_MIG_RESTORE;
        assert(settings_import(&q, sizeof q) == 1 && favorites.factory[15][30] == GB_SERIAL_OFF &&
               favorites.factory[15][28] == all);
        q = original; q.favorites.factory[15][30] = GB_SERIAL_OFF | GB_RESTORE_OFF;     /* chose OFF since 2.1: kept */
        q.favorites.factory[15][28] = all;
        assert(settings_import(&q, sizeof q) == 1 && favorites.factory[15][30] == (GB_SERIAL_OFF | GB_RESTORE_OFF));
        memset(&favorites, 0, sizeof favorites);
        settings_fresh();                                                               /* a device never saved: ON */
        assert(!(favorites.factory[15][30] & GB_RESTORE_OFF) && favorites.factory[15][28] == all);
        puts("settings: GHOULBOX RESTORE LAST ON once in 2.1 (1.4 ON; 1.5..2.0 OFF -> ON; OFF chosen since kept; fresh ON)");
    }
    {   /* ESTAMPIE (the Felucca 1.6.1 merge): MIDI LEARN's table is favorites.factory[ML_ROW] (SLICE's row): a record
         * without the GB_MIG_LEARN mark gets the row cleared once (stray favourite bits are no learned CCs); marked, the
         * row is kept as saved (what was learned) */
        persist_t q = original;
        q.favorites.factory[15][28] = GB_MIG_SERIAL | GB_MIG_RESTORE | GB_MIG_RESTORE_ON;
        memset(q.favorites.factory[ML_ROW], 0xA5, sizeof q.favorites.factory[ML_ROW]);
        assert(settings_import(&q, sizeof q) == 1 && (favorites.factory[15][28] & GB_MIG_LEARN) &&
               !favorites.factory[ML_ROW][0] && !memcmp(favorites.factory[ML_ROW], favorites.factory[ML_ROW] + 1, 31));
        q = original; q.favorites.factory[15][28] = GB_MIG_SERIAL | GB_MIG_RESTORE | GB_MIG_RESTORE_ON | GB_MIG_LEARN;
        q.favorites.factory[ML_ROW][0] = 0x14; q.favorites.factory[ML_ROW][1] = 0x2A;
        assert(settings_import(&q, sizeof q) == 1 && favorites.factory[ML_ROW][0] == 0x14 && favorites.factory[ML_ROW][1] == 0x2A);
        puts("settings: MIDI LEARN's row (SLICE's) cleared once in older records, kept once marked");
    }
    p = original;
    assert(settings_import(&p, sizeof p) == 1); settings_init();
    assert(settings.palette == UI_GREY_INDEX && fx_lowcut && settings.zoom && panel.enc[0] == 3);
    assert(p.palette == palette_to_stored(UI_GREY_INDEX));        /* migrated in place */
    {   /* every old id maps to a palette; tagged ids round trip; anything else is GREY */
        persist_t q = original;
        for (uint32_t i = 0; i < 20u; i++) assert(palette_from_stored(i) < NPALETTES);
        assert(palette_from_stored(13) == 6u && palette_from_stored(11) == 7u && palette_from_stored(19) == 7u);
        for (uint32_t i = 0; i < NPALETTES; i++) assert(palette_from_stored(palette_to_stored(i)) == i);
        assert(palette_from_stored(40) == UI_GREY_INDEX && !palette_stored_ok(40) && palette_stored_ok(3));
        /* 1.0.2: the old MONO keeps its id as GREY (a saved MONO looks the same); the new black and white MONO is
         * appended, a new id */
        assert(palette_from_stored(UI_PAL_TAG + 0u) == UI_GREY_INDEX && !strcmp(UI_PALETTES[UI_GREY_INDEX].name, "GREY"));
        assert(UI_BW_INDEX == 10u && UI_VELLUM_INDEX == 11u && UI_TAVERN_INDEX == NPALETTES - 1u && !strcmp(UI_PALETTES[UI_BW_INDEX].name, "MONO") &&
               palette_from_stored(UI_PAL_TAG + UI_BW_INDEX) == UI_BW_INDEX && palette_stored_ok(UI_PAL_TAG + UI_BW_INDEX));
        q.palette = palette_to_stored(5);
        assert(settings_import(&q, sizeof q) == 1 && settings.palette == 5u);
        settings.magic = SETTINGS_MAGIC_OLD; settings.palette = 13; settings_init();   /* retained SET3 */
        assert(settings.magic == SETTINGS_MAGIC && settings.palette == 6u);
        p = original; assert(settings_import(&p, sizeof p) == 1); settings_init();
    }
#ifdef FELUCCA_FAVORITES
    assert(favorite_has(8, 0) && favorite_has(NENGINES, 31) && favorites.filter);
    {   /* SAMPLE's PERC starred (preset 4, retired): DRUM's kit (preset 0) instead; SAMPLE's others kept; twice the same */
        persist_t q = original;
        q.favorites.factory[ENGI_SAMPLE][0] = 1u << SMP_SET_PERC | 1u << 2;
        assert(settings_import(&q, sizeof q) == 1 && favorites.factory[ENGI_SAMPLE][0] == 1u << 2 &&
               favorites.factory[ENGI_DRUM][0] == 1u);
        settings_export(&q);
        assert(settings_import(&q, sizeof q) == 1 && favorites.factory[ENGI_SAMPLE][0] == 1u << 2 &&
               favorites.factory[ENGI_DRUM][0] == 1u);
        p = original; assert(settings_import(&p, sizeof p) == 1);
    }
#endif
    settings.lowcut = 0;
    settings_export(&p);
    assert(!p.lowcut && p.bold == 1 && p.favorites.user == (1u << 31));   /* bold: kept as saved */
    assert(p.favorites.factory[8][0] == 1 && p.favorites.filter == 1);
    assert(p.panel.enc[0] == 3); /* saving one feature preserves the other */
    p = original; p.magic = 0x50455233u;
    assert(settings_import(&p, sizeof p - sizeof p.favorites) == 2);
    assert(p.bold == 1 && !p.favorites.user && !p.favorites.filter);
    settings_export(&p); assert(p.bold == 1); /* favorites-only preserves PER3 font */
    p = original; p.magic = 0x50455232u;
    assert(settings_import(&p, sizeof p - sizeof p.favorites - sizeof p.bold) == 2);
    assert(!p.bold && !p.favorites.user && settings.zoom && panel.enc[0] == 3);
    p = original; p.magic = 0x50455231u;
    memcpy((uint8_t *)&p + 8, &PANEL_DEFAULT, sizeof(panel_t));
    assert(settings_import(&p, 8 + sizeof(panel_t)) == 2);
    assert(!p.bold && !p.zoom && !p.lowcut && !p.favorites.user && panel.magic == PANEL_MAGIC);
    {   /* HOLD: in the retired bold field; older records (bold 0 / 1) are 0.4 s, and stay as saved */
        p = original; p.bold = 0;
        assert(settings_import(&p, sizeof p) == 1 && settings_hold == HOLD_DEF && HOLD_MS[settings_hold] == 400u);
        p = original;
        assert(settings_import(&p, sizeof p) == 1 && settings_hold == HOLD_DEF);
        settings_hold = 3;
        settings_export(&p);
        assert(hold_stored_ok(p.bold) && p.bold != 1u);
        settings_hold = 0;
        assert(settings_import(&p, sizeof p) == 1 && settings_hold == 3u && HOLD_MS[settings_hold] == 600u);
        settings_hold = HOLD_DEF;
        settings_export(&p);
        assert(p.bold == 0u && settings_import(&p, sizeof p) == 1 && settings_hold == HOLD_DEF);
        assert(!hold_stored_ok(2u) && !hold_stored_ok(HOLD_TAG + 4u) && hold_stored_ok(HOLD_TAG | 2u));
        p = original; p.magic = 0x50455231u;
        memcpy((uint8_t *)&p + 8, &PANEL_DEFAULT, sizeof(panel_t));
        settings_hold = 2;
        assert(settings_import(&p, 8 + sizeof(panel_t)) == 2 && settings_hold == HOLD_DEF);
    }
    {   /* LEDS: in the retired zoom field; older records (zoom 0 / 1) are DIM, and stay as saved; idempotent */
        persist_t q;
        p = original;                                   /* zoom 1: an older record's large readout */
        assert(settings_import(&p, sizeof p) == 1 && settings_leds == LEDS_DIM);
        q = p; settings_export(&q); assert(q.zoom == 1u);                  /* DIM: kept as saved */
        settings_leds = LEDS_INV;
        settings_export(&p);
        assert(p.zoom == (LEDS_TAG | LEDS_INV) && leds_stored_ok(p.zoom));
        q = p; settings_export(&q); assert(!memcmp(&q, &p, sizeof q));   /* a second save: the same record */
        settings_leds = LEDS_DIM;
        assert(settings_import(&p, sizeof p) == 1 && settings_leds == LEDS_INV);
        q = p; assert(settings_import(&q, sizeof q) == 1 && !memcmp(&q, &p, sizeof q));   /* import twice: the same */
        settings_leds = LEDS_DIM;
        settings_export(&p);
        assert(p.zoom == 0u && settings_import(&p, sizeof p) == 1 && settings_leds == LEDS_DIM);
        assert(leds_stored_ok(0u) && leds_stored_ok(1u) && !leds_stored_ok(2u) && leds_stored_ok(LEDS_TAG | 2u) &&
               leds_stored_ok(LEDS_TAG | 3u) && !leds_stored_ok(LEDS_TAG + 4u) && leds_from_stored(LEDS_TAG + 4u) == LEDS_DIM &&
               leds_from_stored(7u) == LEDS_DIM && leds_from_stored(2u) == LEDS_DIM);
        /* the modes appended (append-only: DIM 0, INV 1 as before): OFF 2, DIM LO 3, each saved and read back,
         * twice the same */
        {
            uint32_t m;
            static const uint32_t ADDED[2] = {LEDS_OFF, LEDS_DIM_LO};
            assert(LEDS_DIM == 0 && LEDS_INV == 1 && LEDS_OFF == 2 && LEDS_DIM_LO == 3 && LEDS_COUNT == 4);
            for (m = 0; m < 2u; m++) {
                settings_leds = (uint8_t)ADDED[m];
                settings_export(&p);
                assert(p.zoom == (LEDS_TAG | ADDED[m]) && leds_stored_ok(p.zoom));
                q = p; settings_export(&q); assert(!memcmp(&q, &p, sizeof q));
                settings_leds = LEDS_DIM;
                assert(settings_import(&p, sizeof p) == 1 && settings_leds == ADDED[m]);
            }
            settings_leds = LEDS_DIM;
            settings_export(&p);
            assert(p.zoom == 0u);
        }
        p = original; p.magic = 0x50455231u;           /* PER1: no zoom field, DIM */
        memcpy((uint8_t *)&p + 8, &PANEL_DEFAULT, sizeof(panel_t));
        settings_leds = LEDS_INV;
        assert(settings_import(&p, 8 + sizeof(panel_t)) == 2 && settings_leds == LEDS_DIM);
    }
#ifdef FELUCCA_FAVORITES
    {   /* 1.1 CLICK / CLICK LEVEL / COUNT-IN (ui.c ui_rec_prefs, favorites.factory[15][12]: GHOULBOX's
         * byte for them, Felucca's [15][28] holds GHOULBOX's marks): 0 in every older record
         * (the defaults: OFF / MID / OFF); each field 0..2 kept, 3 (no value) back to 0, bits 6-7 kept; twice the same */
        persist_t q;
        uint32_t b;
        p = original; p.magic = 0x50455233u;            /* PER3 (no favorites): 0 */
        assert(settings_import(&p, sizeof p - sizeof p.favorites) == 2 && favorites.factory[15][12] == 0u);
        for (b = 0; b < 256u; b++) {
            uint32_t f, want = b;
            for (f = 0; f < 3u; f++)
                if (((b >> (2u * f)) & 3u) == 3u) want &= ~(3u << (2u * f));
            p = original; p.favorites.factory[15][12] = (uint8_t)b;
            assert(settings_import(&p, sizeof p) == 1 && favorites.factory[15][12] == want && p.favorites.factory[15][12] == want);
            q = p; assert(settings_import(&q, sizeof q) == 1 && !memcmp(&q, &p, sizeof q));
            settings_export(&q); assert(q.favorites.factory[15][12] == want);
        }
        p = original; assert(settings_import(&p, sizeof p) == 1);
    }
    {   /* 1.2 RESTORE LAST (ui.c PREF_RESTORE_OFF, bit 7 of MENU's flags, favorites.factory[15][30]): GHOULBOX 2.1: an
         * older record (no GB_MIG_RESTORE_ON mark) ends ON (clear, Felucca's default) once; set = OFF, kept as saved
         * with the other flags once the marks say it was chosen */
        persist_t q;
        p = original; p.magic = 0x50455233u;
        assert(settings_import(&p, sizeof p - sizeof p.favorites) == 2 && !(favorites.factory[15][30] & 128u));
        p = original; p.favorites.factory[15][30] = 128u | 64u | 1u;
        p.favorites.factory[15][28] |= GB_MIG_SERIAL | GB_MIG_RESTORE | GB_MIG_RESTORE_ON;
        assert(settings_import(&p, sizeof p) == 1 && favorites.factory[15][30] == (128u | 64u | 1u));
        q = p; settings_export(&q); assert(q.favorites.factory[15][30] == (128u | 64u | 1u));
        p = original; assert(settings_import(&p, sizeof p) == 1);
    }
    {   /* 1.2 the FX layer's key map (ui_layer.c fx_keys, favorites.factory[15][14..23], 16 x 5 bits, 0 = the key's
         * default): 0 in every older record; any bytes kept as saved (codes of a later firmware too), the bytes around
         * them untouched; twice the same */
        persist_t q;
        uint32_t i;
        p = original; p.magic = 0x50455233u;
        assert(settings_import(&p, sizeof p - sizeof p.favorites) == 2);
        for (i = 14; i < 24u; i++) assert(favorites.factory[15][i] == 0u);
        p = original;
        for (i = 14; i < 24u; i++) p.favorites.factory[15][i] = (uint8_t)(i * 37u + 5u);
        assert(settings_import(&p, sizeof p) == 1);
        for (i = 14; i < 24u; i++) assert(favorites.factory[15][i] == (uint8_t)(i * 37u + 5u));
        assert(favorites.factory[15][13] == original.favorites.factory[15][13] && favorites.factory[15][24] == original.favorites.factory[15][24]);
        memset(&q, 0, sizeof q); settings_export(&q); assert(!memcmp(&q.favorites, &p.favorites, sizeof q.favorites));
        assert(settings_import(&q, sizeof q) == 1);
        for (i = 14; i < 24u; i++) assert(favorites.factory[15][i] == (uint8_t)(i * 37u + 5u));
        p = original; assert(settings_import(&p, sizeof p) == 1);
    }
    {   /* 1.5 MIDI LEARN's map (midi_control.c, favorites.factory[ML_ROW]: ESTAMPIE's row 13, SLICE's; Felucca's 14 is GURDY's here): 0 = nothing learned in every older
         * record; kept as saved, byte for byte (an entry of a later firmware too), the rows around it untouched; an
         * export / import round trip and importing twice change nothing */
        persist_t q;
        uint32_t i;
        p = original; p.magic = 0x50455233u;
        assert(settings_import(&p, sizeof p - sizeof p.favorites) == 2);
        for (i = 0; i < 32u; i++) assert(favorites.factory[ML_ROW][i] == 0u);
        p = original;
        p.favorites.factory[15][28] |= GB_MIG_SERIAL | GB_MIG_RESTORE | GB_MIG_RESTORE_ON | GB_MIG_LEARN;   /* (marked: kept) */
        for (i = 0; i < 32u; i++) p.favorites.factory[ML_ROW][i] = (uint8_t)(i * 29u + 3u);
        assert(settings_import(&p, sizeof p) == 1);
        for (i = 0; i < 32u; i++) assert(favorites.factory[ML_ROW][i] == (uint8_t)(i * 29u + 3u));
        assert(!memcmp(favorites.factory[ML_ROW - 1u], original.favorites.factory[ML_ROW - 1u], 32) &&
               !memcmp(favorites.factory[ML_ROW + 1u], original.favorites.factory[ML_ROW + 1u], 32));
        memset(&q, 0, sizeof q); settings_export(&q); assert(!memcmp(&q.favorites, &p.favorites, sizeof q.favorites));
        assert(settings_import(&q, sizeof q) == 1 && settings_import(&q, sizeof q) == 1);
        for (i = 0; i < 32u; i++) assert(favorites.factory[ML_ROW][i] == (uint8_t)(i * 29u + 3u));
        p = original; assert(settings_import(&p, sizeof p) == 1);
    }
#endif
    assert(settings_import(&p, 3) == 0 && settings_import(&p, -1) == 0);
    assert(settings_import(&p, sizeof p - 1) == 0);
    puts("Settings: PER1/PER2/PER3 migration, palette ids, calibration, HOLD, LEDS, CLICK / COUNT-IN, the FX key map, MIDI LEARN's map and independent feature preservation passed.");
}
