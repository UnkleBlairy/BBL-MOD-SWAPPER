<p align="center"><img src="docs/readme/estampie.jpg" width="880" alt="ESTAMPIE: the M-VAVE FM-1 playing the TROTTO in its vellum look, on an illuminated page with vines, ivy leaves and the calligraphic Estampie wordmark"></p>

# ESTAMPIE: a mediæval groovebox for the FM-1

[**ESTAMPIE**](https://fm-1.drewr.dev/estampie/) is custom firmware for the **M-VAVE FM-1**, named after the [*estampie*](https://en.wikipedia.org/wiki/Estampie),
a fast dance of the 13th and 14th centuries. It is a groovebox for lively mediæval music: tavern and court dances
and celebrations, with plucked lutes and citoles, buzzing hurdy-gurdies, shawms and bagpipes over drones, frame drums,
tabors and nakers, chant, and the mediæval modes. This is inspired by the idea of teenage engineering's EP-1320 *medieval*
(but not affiliated with them, and none of their sounds are used).

It started as a fork of [GHOULBOX](https://github.com/jasonpersinger/ghoulbox-fm1-dungeon-synth) by Jason Persinger, the
"dungeon-synth" firmware, which is itself a fork of [Felucca](https://github.com/hugelton/Felucca) by Leo Kuroshita
(Hügelton Instruments). Nearly everything here is their work: Felucca's engines, sequencer, effects, editor,
installer and tests, and GHOULBOX's hurdy-gurdy, medieval tunings, drone latch, dungeon sounds and browser synth.
Thank you both!

ESTAMPIE is on Felucca 1.6.1 (Maybe Felucca's last feature release? Leo says he has stepped back from active
development), with Felucca's ANALOG, LOFI, TRIO, WHEEL and NOISE engines from
[Felucca-Engines](https://github.com/hugelton/Felucca-Engines) (MIT) in `firmware/engines/`. The browser emulator
follows the design of Charles Vestal's [X0X](https://github.com/charlesvestal/fm1-x0x), and HOME's chord readout (the
chord or notes you are playing) is ported from Kerem Kilic's [Melodee](https://github.com/keremimo/melodee), another
Felucca fork. Felucca's second-core renderer (MENU > SYSTEM > 2ND CORE, a beta, off by default) was contributed by
gospodindilly-ops and builds on X0X, Melodee and zednaked's [Jangada](https://github.com/zednaked/jangada). The full
history of both projects is kept in this repository.

**Status: 0.4.0, early but ready for use.** So far: the VELLUM look (parchment, iron-gall ink, vermilion rubrics, lapis), the
screen's type (Alegreya Sans, with Cinzel's Roman capitals for the large text), the illuminated boot screen and the
browser emulator page; KEY TOUCH, velocity and aftertouch from the FM-1's own keys (after Charles Vestal's Velo and
MONK-1), with a calibration anyone can run; the screen reader; and the web installer, editor and site. The sounds are still mostly
GHOULBOX's, with ESTAMPIE's TROTTO and ESTAMPIE scenes, the DANCE drum kit and mediæval presets, among them a
rauschpfeife, a crumhorn, a psaltery, a bray harp and a portative organ. See [the screens](docs/screens/) and [ROADMAP.md](ROADMAP.md).

The full site is <https://fm-1.drewr.dev/estampie/>: play it in the browser, install it, edit sounds and
read the guide. This is beside my other FM-1 projects, [FM1Kit](https://fm-1.drewr.dev/fm1kit/) and [FM-SWITCH](https://fm-1.drewr.dev/fm-switch/).

## What it does

Thirteen engines (virtual analog, 6-operator FM, phase distortion, chiptune, real recordings, sung vowels, three
oscillators, tonewheel organ, granular, physical models, GHOULBOX's hurdy-gurdy, noise and drums) on four tracks, each
with a 64-step sequencer, an arpeggiator, chord keys, scales and mediæval temperaments (Pythagorean, meantone, just).
The hurdy-gurdy's drones can keep sounding through the sequencer's rests, as a real one's do while the wheel turns
(RING, from GHOULBOX 2.3). **KEY TOUCH** (MENU › AUDIO, calibrated in MENU › SYSTEM › CALIBRATION) measures how hard 20 of
the FM-1's own keys are pressed, for velocity and aftertouch with no hardware change: Charles Vestal's trick from his
[Velo](https://github.com/charlesvestal/fm1-velocity) and [MONK-1](https://github.com/charlesvestal/fm1-monk) firmwares
(new, not yet tried widely). A **screen reader** on the computer can read the FM-1's screen: open Charles Vestal's
[FM-1 Screen Reader](https://charlesvestal.github.io/fm1-reader/) page with the FM-1 plugged in. Pages, knobs as they
turn, the menu, messages and questions are read, with ESTAMPIE's own words (`firmware/words.tsv`, published at
`/estampie/words/`); the browser emulator reads its screen too ([fm1-reader](https://github.com/charlesvestal/fm1-reader)).

**Scenes** (MENU › SYSTEM › SCENE) set up all four tracks at once: sounds, parts, levels, tuning, tempo, reverb and
tape. OCT+ there loads one while the FM-1 runs; it asks first, since it replaces all four tracks. The power-on scene is the
TROTTO, a 14th-century Italian dance. The ESTAMPIE scene plays a whole piece, *La Quinte Estampie Real* (Paris,
c. 1300), on a rauschpfeife, a lute, a hurdy-gurdy's drones and the tabor, in Pythagorean tuning: two sections, each
twice, a tabor solo, then both again faster, streamed from the firmware section by section with a tempo for each.
GHOULBOX's dungeon scenes are all still there.

From Felucca 1.5–1.6.1 (merged into ESTAMPIE 0.1):

- **Sound:** an INSERT effect on every track (drives, a bit crusher, phaser, flanger, chorus) with a dry / wet MIX;
  ANALOG's band- and high-pass filter; PHASE's wavefolder; envelopes in note values (ENV SYNC); humanize (MOD VEL and
  TIME); three more drum kits.
- **Sequencer:** SEQ › DETAIL (each step's chance, ratchet, nudge and velocity); conditional steps (1:2 .. 4:4) and
  FILL; a note's length on the piano roll; EUCLID, DOUBLE and HALF; QNT SEQ+T; a roll that follows the playhead.
- **MIDI:** MIDI LEARN on the device; Program Change; a channel per track; AUTO SELECT; reverb and echo throws.
- **The panel:** on-screen HELP, SELECT as a page knob, mod wheel or velocity, your own colours, PROJECT ERASE and
  CLEAN INIT, dimmer INV LEDs, and the chip's second core as an opt-in beta (MENU › SYSTEM › 2ND CORE).

The user guide is [docs/guide/guide.html](docs/guide/guide.html), Jason Persinger's GHOULBOX User Guide reworked for
ESTAMPIE: `python3 docs/guide/make_guide.py html OUTDIR` builds it as a page (the site has it at `guide/`), `pdf
OUT.pdf` prints it. `tools/guide_shots.sh` draws its screenshots with the firmware's own UI code.

## Screens

ESTAMPIE playing its TROTTO, in the VELLUM look (parchment) and TAVERN (dark): the boot screen, HOME, the mixer, the
piano roll, the drum grid, FX, SCALE, ENV, LFO, MENU and ABOUT. They are the firmware's own screens, taken in the
simulator by `tools/screens.sh`. Each one on its own, at 720 × 720: [VELLUM](docs/screens/vellum/) ·
[TAVERN](docs/screens/tavern/).

<p align="center"><a href="docs/screens/vellum/"><img src="docs/screens/vellum.png" width="880" alt="Eleven ESTAMPIE screens in the VELLUM look, red and blue ink on parchment: the illuminated Estampie boot screen, HOME's waveform as the TROTTO plays, the four-track mixer, the hurdy-gurdy's melody on the piano roll, the DANCE kit's drum grid, the FX, scale, envelope and LFO pages, the menu and ABOUT"></a></p>

<p align="center"><a href="docs/screens/tavern/"><img src="docs/screens/tavern.png" width="880" alt="The same eleven ESTAMPIE screens in the TAVERN look, orange and blue on dark brown"></a></p>

## Your projects and other firmwares

ESTAMPIE opens the projects Felucca and GHOULBOX saved. It saves in GHOULBOX 2.3's format, which Felucca and
GHOULBOX before 2.3 can't read: a slot holding an ESTAMPIE project shows EMPTY there, but stays in the flash
until that slot is saved over. To keep your projects safe when you change firmware, back them up first with the
[web editor](https://fm-1.drewr.dev/estampie/webapp/editor/).

## Newer FM-1s

FM-1s sold since autumn 2026 have a different flash chip: UCUN's UC25HQ80 rather than Puya's P25Q80. ESTAMPIE
knows it from 0.3.8. Earlier versions don't, and on these units:

- nothing you save survives switching off;
- the recovery screen says UNKNOWN FLASH;
- ESTAMPIE can't be updated over USB, so it can't install a newer ESTAMPIE or anything else itself.

If your FM-1 is new and still on V15, install ESTAMPIE as usual. If it already has an earlier ESTAMPIE and acts as
above, there's no tested way off it yet: please [open an issue](https://github.com/ocean/estampie/issues) and we'll
work it out with you. FM1Kit and other installers that ask for the full identity can tell you which chip yours has
(0xB36014 is the newer one). 0.3.8 and later have only been tested on an FM-1 with the older chip so far, so a
report from a newer one, good or bad, is very welcome.

## Building

Everything the build needs is fetched into the repository (`.toolchain/`, `.venv/`, both git-ignored), so
nothing is installed in your home directory. Needs [uv](https://docs.astral.sh/uv/), Docker Desktop and git:

```sh
tools/setup_toolchain.sh     # every tool, pinned by hash (tools/toolchain.lock); Python 3.14 from uv.lock
tools/osv_scan.sh            # known vulnerabilities in everything the build runs (docs/SECURITY.md)
./build.sh                   # build/estampie.fwsc: the firmware package (Docker runs the JieLi tools on macOS)
sh web/emu/build.sh          # build/emu/: the browser emulator (zig cc to WebAssembly)
python3 -m http.server -d build/emu 8790     # open http://localhost:8790/
```

Docker Desktop must be running for `./build.sh` on macOS.

## Testing

Three levels, cheapest first:

1. **Browser emulator** (`web/emu/`): the firmware's own C sources compiled to WebAssembly against a simulated
   FM-1. The quick loop for designing sounds and screens.
2. **Host tests**: `tests/run_tests.sh` (with `AC79_SDK=.toolchain/ac79-sdk` and the venv on `PATH`): golden
   renders of every sound, the UI's layout lint, CPU budgets and more. The reverb's HALL cost check fails on
   Apple silicon hosts (it measures host instructions; CI has no counter and skips it); this is inherited.
3. **Emulated hardware**: `tools/hw_check.sh` boots the real `build/estampie.fwsc` on an emulation of the
   AC791N's pi32v2 cores and the board
   ([shcherbakov7/m-wave-fm1-browser-emulator](https://github.com/shcherbakov7/m-wave-fm1-browser-emulator), Rust),
   and saves the screen to `build/hw/screen.png`. This checks the real image: memory layout, start-up, timing.

Then a real FM-1. M-VAVE's own updater returns it to stock firmware.

## AI / LLM disclaimer

ESTAMPIE is developed with the help of LLM coding agents (code, tests, documentation and maintenance). Its idea,
design, features, sounds and direction are mine, or the work of the people credited above, and I put as much care
and thought into refining and iterating on the design and features as I personally can, and review output
as much as possible. See [On AI-assisted development](docs/AI.md), inspired by Leo Kuroshita's
[note for Felucca](https://github.com/hugelton/Felucca/discussions/166).

## Licence

GPL-3.0-only, as GHOULBOX and Felucca. The engines in `firmware/engines/` are MIT (Felucca-Engines) and the Hügelton
Sample Pack is CC0 1.0. See [LICENSING.md](LICENSING.md) for the parts under other licences.
GHOULBOX's own README is kept at [docs/GHOULBOX-README.md](docs/GHOULBOX-README.md).

M-VAVE and FM-1 are trademarks of their respective owners. ESTAMPIE, GHOULBOX and Felucca are not affiliated with
or endorsed by them.
