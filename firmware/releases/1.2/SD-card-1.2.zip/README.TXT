BBL Mod Swapper card

ROMS\     firmware images the menu lists
SAMPLES\  the shared sample library, any folders inside, every firmware can pull from it
DATA\     each firmware's own saves (presets, patterns, projects)
STATES\   save states (FX + SAVE), 16 per firmware
